import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Lock, 
  Unlock, 
  Package, 
  ShoppingBag, 
  Wrench, 
  Settings, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  MessageCircle, 
  RotateCcw, 
  Save, 
  Eye, 
  EyeOff,
  Download,
  AlertTriangle
} from 'lucide-react';
import { Product, ProductCategory, SavedOrder, SavedBooking, ShopSettings } from '../types';

export const AdminModal: React.FC = () => {
  const { 
    isAdminModalOpen, 
    setIsAdminModalOpen, 
    isAdminAuthenticated, 
    loginAdmin, 
    logoutAdmin,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleStock,
    resetSampleProducts,
    savedOrders,
    updateOrderStatus,
    savedBookings,
    updateBookingStatus,
    shopSettings,
    updateShopSettings,
    language,
    t
  } = useApp();

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'services' | 'settings'>('products');

  // Product Add / Edit State
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product>>({
    name: { en: '', hi: '' },
    category: 'laptops_refurbished',
    price: 15000,
    originalPrice: 20000,
    condition: 'refurbished',
    inStock: true,
    brand: 'Dell',
    image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80',
    specs: { en: ['Intel Core i5', '8GB RAM', '256GB SSD'], hi: ['इंटेल Core i5', '8GB रैम', '256GB एसएसडी'] },
    warranty: { en: '6 Months Shop Warranty', hi: '6 महीने शॉप वारंटी' }
  });

  // Settings State Form
  const [settingsForm, setSettingsForm] = useState<ShopSettings>(shopSettings);
  const [settingsSavedNotice, setSettingsSavedNotice] = useState(false);

  if (!isAdminModalOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = loginAdmin(pinInput);
    if (success) {
      setPinError(false);
      setPinInput('');
    } else {
      setPinError(true);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct.name?.en || !editingProduct.price) return;

    if (editingProduct.id) {
      updateProduct(editingProduct as Product);
    } else {
      const newProduct: Product = {
        ...(editingProduct as Product),
        id: `prod-${Date.now()}`
      };
      addProduct(newProduct);
    }
    setIsEditingProduct(false);
  };

  const handleStartEdit = (product: Product) => {
    setEditingProduct(product);
    setIsEditingProduct(true);
  };

  const handleStartNewProduct = () => {
    setEditingProduct({
      id: '',
      name: { en: '', hi: '' },
      category: 'laptops_refurbished',
      price: 10000,
      originalPrice: 15000,
      condition: 'new',
      inStock: true,
      brand: 'Generic',
      image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80',
      specs: { en: ['Specification 1', 'Specification 2'], hi: ['विशेषता 1', 'विशेषता 2'] },
      warranty: { en: '1 Year Warranty', hi: '1 साल वारंटी' }
    });
    setIsEditingProduct(true);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateShopSettings(settingsForm);
    setSettingsSavedNotice(true);
    setTimeout(() => setSettingsSavedNotice(false), 3000);
  };

  const exportOrdersCSV = () => {
    const headers = 'Order ID,Date,Customer,Phone,Address,Total Amount,Status,Assigned WhatsApp\n';
    const rows = savedOrders.map(o => 
      `"${o.id}","${o.timestamp}","${o.customerName}","${o.phoneNumber}","${o.deliveryAddress}","${o.totalAmount}","${o.status}","${o.assignedNumber}"`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AK_Golu_Orders_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-7 my-6 max-h-[92vh] flex flex-col">
        {/* Close */}
        <button
          onClick={() => setIsAdminModalOpen(false)}
          className="absolute top-4 right-4 rounded-full p-2 text-slate-400 hover:text-white hover:bg-slate-800 transition z-10"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Not Authenticated Screen */}
        {!isAdminAuthenticated ? (
          <div className="py-12 max-w-md mx-auto text-center space-y-5">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-2xl font-bold text-white">{t.admin.title}</h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t.admin.lockSubtitle}
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3.5">
              <div className="relative">
                <input
                  type={showPin ? 'text' : 'password'}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder={t.admin.pinPlaceholder}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-xl text-center text-lg font-mono tracking-widest text-white focus:outline-none focus:border-blue-500"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {pinError && (
                <p className="text-xs text-red-400 font-medium">
                  {t.admin.incorrectPin}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition flex items-center justify-center gap-2"
              >
                <Unlock className="w-4 h-4" />
                <span>{t.admin.loginBtn}</span>
              </button>
            </form>

            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300">
              <span className="font-semibold text-blue-400">💡 {language === 'hi' ? 'दुकानदार सूचना:' : 'Owner Tip:'}</span>{' '}
              {t.admin.defaultPinNotice}
            </div>
          </div>
        ) : (
          /* Authenticated Admin Dashboard */
          <div className="flex-1 flex flex-col min-h-0 space-y-4">
            {/* Top Navigation Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-600 text-white">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">
                    {shopSettings.shopName} - {t.admin.title}
                  </h3>
                  <p className="text-[11px] text-emerald-400">● Admin Session Active</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={logoutAdmin}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
                >
                  {t.admin.logout}
                </button>
              </div>
            </div>

            {/* Dashboard Tabs */}
            <div className="flex rounded-xl bg-slate-800 p-1 gap-1 overflow-x-auto text-xs font-semibold">
              <button
                onClick={() => { setActiveTab('products'); setIsEditingProduct(false); }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap ${
                  activeTab === 'products' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>{t.admin.tabs.products} ({products.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('orders'); setIsEditingProduct(false); }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap ${
                  activeTab === 'orders' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{t.admin.tabs.orders} ({savedOrders.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('services'); setIsEditingProduct(false); }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap ${
                  activeTab === 'services' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Wrench className="w-4 h-4" />
                <span>{t.admin.tabs.services} ({savedBookings.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('settings'); setIsEditingProduct(false); }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap ${
                  activeTab === 'settings' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>{t.admin.tabs.settings}</span>
              </button>
            </div>

            {/* Tab 1: Products Management */}
            {activeTab === 'products' && (
              <div className="flex-1 overflow-y-auto space-y-4 pr-1">
                {!isEditingProduct ? (
                  <>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="text-xs text-slate-400">
                        {language === 'hi'
                          ? 'दुकान का कोई भी सामान बदलें, नया जोड़ें या स्टॉक चालू/बंद करें।'
                          : 'Manage store catalog, update prices, photos or toggle stock.'}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={resetSampleProducts}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1"
                          title="Restore original sample products"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{t.admin.resetSample}</span>
                        </button>
                        <button
                          onClick={handleStartNewProduct}
                          className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow"
                        >
                          <Plus className="w-4 h-4" />
                          <span>{t.admin.addNewProduct}</span>
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      {products.map(prod => (
                        <div
                          key={prod.id}
                          className="p-3 sm:p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <img
                              src={prod.image}
                              alt={prod.name.en}
                              className="w-12 h-12 object-cover rounded-lg bg-slate-900 flex-shrink-0"
                            />
                            <div className="min-w-0">
                              <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                                {prod.name[language] || prod.name.en}
                              </h4>
                              <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400 flex-wrap">
                                <span className="font-semibold text-blue-400">
                                  ₹{prod.price.toLocaleString('en-IN')}
                                </span>
                                <span>•</span>
                                <span className="uppercase text-[10px] bg-slate-800 px-1.5 py-0.5 rounded">
                                  {prod.condition}
                                </span>
                                <span>•</span>
                                <span className="text-[11px] text-slate-400">{prod.brand}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0">
                            {/* Stock Toggle */}
                            <button
                              onClick={() => toggleStock(prod.id)}
                              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition ${
                                prod.inStock
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
                              }`}
                            >
                              {prod.inStock ? 'In Stock' : 'Out of Stock'}
                            </button>

                            {/* Edit */}
                            <button
                              onClick={() => handleStartEdit(prod)}
                              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                              title="Edit product"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => deleteProduct(prod.id)}
                              className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800 transition"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  /* Add / Edit Product Form */
                  <form onSubmit={handleSaveProduct} className="space-y-4 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <h4 className="font-bold text-white text-base">
                        {editingProduct.id ? 'Edit Product' : 'Add New Product'}
                      </h4>
                      <button
                        type="button"
                        onClick={() => setIsEditingProduct(false)}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Product Name (English) *
                        </label>
                        <input
                          type="text"
                          required
                          value={editingProduct.name?.en || ''}
                          onChange={(e) => setEditingProduct({
                            ...editingProduct,
                            name: { ...editingProduct.name, en: e.target.value, hi: editingProduct.name?.hi || e.target.value }
                          })}
                          placeholder="e.g. Dell Latitude 7490"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          नाम (हिंदी में)
                        </label>
                        <input
                          type="text"
                          value={editingProduct.name?.hi || ''}
                          onChange={(e) => setEditingProduct({
                            ...editingProduct,
                            name: { ...editingProduct.name, hi: e.target.value, en: editingProduct.name?.en || '' }
                          })}
                          placeholder="उदा. डेल लैटीट्यूड 7490"
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                        <select
                          value={editingProduct.category}
                          onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value as ProductCategory })}
                          className="w-full px-2 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                        >
                          <option value="laptops_refurbished">Refurbished Laptop</option>
                          <option value="laptops_new">New Laptop</option>
                          <option value="computers_desktops">Computer / Desktop</option>
                          <option value="cctv_surveillance">CCTV / Surveillance</option>
                          <option value="printers_toner">Printer / Toner</option>
                          <option value="accessories_networking">Accessories / Wi-Fi</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Our Price (₹) *</label>
                        <input
                          type="number"
                          required
                          value={editingProduct.price || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Original MRP (₹)</label>
                        <input
                          type="number"
                          value={editingProduct.originalPrice || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">Brand</label>
                        <input
                          type="text"
                          value={editingProduct.brand || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">Product Photo URL</label>
                      <input
                        type="url"
                        value={editingProduct.image || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Specifications (Comma-separated)
                      </label>
                      <input
                        type="text"
                        value={(editingProduct.specs?.en || []).join(', ')}
                        onChange={(e) => {
                          const items = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                          setEditingProduct({
                            ...editingProduct,
                            specs: { en: items, hi: items }
                          });
                        }}
                        placeholder="Core i5 8th Gen, 8GB RAM, 256GB SSD..."
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">Warranty Details</label>
                      <input
                        type="text"
                        value={editingProduct.warranty?.en || ''}
                        onChange={(e) => setEditingProduct({
                          ...editingProduct,
                          warranty: { en: e.target.value, hi: e.target.value }
                        })}
                        placeholder="e.g. 6 Months Shop Warranty"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsEditingProduct(false)}
                        className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow"
                      >
                        Save Product
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* Tab 2: Orders Log */}
            {activeTab === 'orders' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="text-xs text-slate-400">
                    {language === 'hi'
                      ? 'ग्राहकों द्वारा व्हाट्सएप पर भेजे गए ऑर्डर्स का रिकॉर्ड:'
                      : 'Real inquiries & orders submitted to WhatsApp:'}
                  </div>
                  {savedOrders.length > 0 && (
                    <button
                      onClick={exportOrdersCSV}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export CSV</span>
                    </button>
                  )}
                </div>

                {savedOrders.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    No orders logged yet. Orders submitted by customers through the cart will appear here automatically!
                  </div>
                ) : (
                  <div className="space-y-3">
                    {savedOrders.map(order => (
                      <div
                        key={order.id}
                        className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3"
                      >
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-blue-400">{order.id}</span>
                            <span className="text-[11px] text-slate-500">{order.timestamp}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <select
                              value={order.status}
                              onChange={(e) => updateOrderStatus(order.id, e.target.value as any)}
                              className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                            >
                              <option value="Pending">Pending (पेंडिंग)</option>
                              <option value="Contacted">Contacted (बात हुई)</option>
                              <option value="Dispatched">Dispatched (भेजा गया)</option>
                              <option value="Delivered">Delivered (डिलीवर हुआ)</option>
                              <option value="Cancelled">Cancelled (रद्द)</option>
                            </select>

                            <a
                              href={`https://wa.me/91${order.phoneNumber.replace(/\D/g, '')}?text=${encodeURIComponent(`नमस्ते ${order.customerName} जी, A K Golu Computer से आपके ऑर्डर ${order.id} के सम्बंध में संपर्क कर रहे हैं।`)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                          <div>
                            <span className="text-slate-500">Customer:</span> <strong className="text-white">{order.customerName}</strong> ({order.phoneNumber})
                          </div>
                          <div>
                            <span className="text-slate-500">Address:</span> {order.deliveryAddress} - {order.cityPincode}
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-900 text-xs">
                          <div className="text-slate-400 mb-1 font-semibold">Items:</div>
                          <ul className="space-y-1">
                            {order.items.map((it, idx) => (
                              <li key={idx} className="flex justify-between text-slate-300">
                                <span>{it.quantity}x {it.name}</span>
                                <span className="font-medium text-white">₹{(it.price * it.quantity).toLocaleString('en-IN')}</span>
                              </li>
                            ))}
                          </ul>
                          <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-900 font-bold text-white">
                            <span>Total Estimated:</span>
                            <span className="text-sm text-blue-400">₹{order.totalAmount.toLocaleString('en-IN')}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: Service Bookings Log */}
            {activeTab === 'services' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                <div className="text-xs text-slate-400">
                  {language === 'hi'
                    ? 'ग्राहकों द्वारा बुक की गई सर्विस व रिपेयर रिक्वेस्ट्स:'
                    : 'Customer repair & technical service booking inquiries:'}
                </div>

                {savedBookings.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    No service bookings logged yet. Service requests submitted through the service form will appear here!
                  </div>
                ) : (
                  <div className="space-y-3">
                    {savedBookings.map(booking => (
                      <div
                        key={booking.id}
                        className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5"
                      >
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-emerald-400">{booking.id}</span>
                            <span className="text-[11px] text-slate-500">{booking.timestamp}</span>
                            <span className="text-[10px] bg-slate-800 text-blue-300 px-2 py-0.5 rounded">
                              {booking.serviceMode === 'home_service' ? '🏠 Home Service' : '🏬 Shop Visit'}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <select
                              value={booking.status}
                              onChange={(e) => updateBookingStatus(booking.id, e.target.value as any)}
                              className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                            >
                              <option value="Received">Received</option>
                              <option value="Assigned">Assigned</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>

                            <a
                              href={`https://wa.me/91${booking.phoneNumber.replace(/\D/g, '')}?text=${encodeURIComponent(`नमस्ते ${booking.customerName} जी, A K Golu Computer से आपकी सर्विस रिक्वेस्ट ${booking.id} (${booking.deviceType}) के सिलसिले में संपर्क कर रहे हैं।`)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                          <div>
                            <span className="text-slate-500">Customer:</span> <strong className="text-white">{booking.customerName}</strong> ({booking.phoneNumber})
                          </div>
                          <div>
                            <span className="text-slate-500">Device:</span> <span className="text-white font-medium">{booking.deviceType}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Address:</span> {booking.address}
                          </div>
                          <div>
                            <span className="text-slate-500">Preferred Slot:</span> {booking.preferredDate} ({booking.preferredSlot})
                          </div>
                        </div>

                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300">
                          <span className="text-slate-400 font-semibold">Problem: </span>
                          "{booking.problem}"
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 4: Shop Settings */}
            {activeTab === 'settings' && (
              <form onSubmit={handleSaveSettings} className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs sm:text-sm">
                {settingsSavedNotice && (
                  <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-semibold flex items-center gap-2">
                    <Check className="w-4 h-4" />
                    <span>Settings successfully saved!</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Shop Name
                    </label>
                    <input
                      type="text"
                      value={settingsForm.shopName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, shopName: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Admin Secret PIN
                    </label>
                    <input
                      type="text"
                      value={settingsForm.adminPin}
                      onChange={(e) => setSettingsForm({ ...settingsForm, adminPin: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Primary Phone / WhatsApp (7054304313)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.phone1}
                      onChange={(e) => setSettingsForm({ ...settingsForm, phone1: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Secondary Phone / WhatsApp (8726356413)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.phone2}
                      onChange={(e) => setSettingsForm({ ...settingsForm, phone2: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Address Line 1
                    </label>
                    <input
                      type="text"
                      value={settingsForm.addressLine1}
                      onChange={(e) => setSettingsForm({ ...settingsForm, addressLine1: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        City / State
                      </label>
                      <input
                        type="text"
                        value={settingsForm.cityState}
                        onChange={(e) => setSettingsForm({ ...settingsForm, cityState: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Pincode
                      </label>
                      <input
                        type="text"
                        value={settingsForm.pincode}
                        onChange={(e) => setSettingsForm({ ...settingsForm, pincode: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Landmark
                      </label>
                      <input
                        type="text"
                        value={settingsForm.landmark}
                        onChange={(e) => setSettingsForm({ ...settingsForm, landmark: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Google Maps Directions Link
                  </label>
                  <input
                    type="url"
                    value={settingsForm.googleMapsDirectionsUrl}
                    onChange={(e) => setSettingsForm({ ...settingsForm, googleMapsDirectionsUrl: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Google Maps Embed IFrame URL
                  </label>
                  <input
                    type="text"
                    value={settingsForm.googleMapsEmbedUrl}
                    onChange={(e) => setSettingsForm({ ...settingsForm, googleMapsEmbedUrl: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-md flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Store Settings</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
