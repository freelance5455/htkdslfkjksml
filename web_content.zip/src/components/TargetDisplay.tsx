import React from 'react';
import { ColorOption } from '../types';
import { Sparkles, Flame } from 'lucide-react';

interface TargetDisplayProps {
  targetColor: ColorOption;
  timeRemainingRatio: number; // 0.0 to 1.0
  isGolden: boolean;
  isFever: boolean;
  feverTimeRemainingRatio: number; // 0.0 to 1.0
  score: number;
}

export const TargetDisplay: React.FC<TargetDisplayProps> = ({
  targetColor,
  timeRemainingRatio,
  isGolden,
  isFever,
  feverTimeRemainingRatio,
  score,
}) => {
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - timeRemainingRatio);
  const isLowTime = timeRemainingRatio < 0.28;

  return (
    <div className="flex w-full flex-col items-center justify-center px-4 py-1 select-none">
      {/* Directive / Event Banner */}
      <div className="mb-2 flex items-center gap-1.5 text-xs font-black uppercase tracking-wider">
        {isFever ? (
          <div className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-500/30 via-red-500/30 to-rose-500/30 px-3 py-1 border border-orange-500/50 text-orange-400 animate-pulse">
            <Flame className="h-4 w-4 fill-orange-400" />
            <span>FEVER MODE 2x ACTIVE!</span>
            <Flame className="h-4 w-4 fill-orange-400" />
          </div>
        ) : isGolden ? (
          <div className="flex items-center gap-1 rounded-full bg-amber-500/20 px-3 py-0.5 border border-amber-500/40 text-amber-300 animate-pulse">
            <Sparkles className="h-3.5 w-3.5 fill-amber-300" />
            <span>GOLDEN BONUS ROUND (+5 PTS)</span>
            <Sparkles className="h-3.5 w-3.5 fill-amber-300" />
          </div>
        ) : (
          <span className="text-slate-400 font-semibold tracking-widest text-[11px]">
            MATCH THIS TARGET COLOR
          </span>
        )}
      </div>

      {/* Target Color Orb with Circular Progress Ring */}
      <div className="relative flex items-center justify-center">
        {/* Ambient Glow Backdrop */}
        <div
          className={`absolute h-36 w-36 rounded-full blur-2xl transition-all duration-300 ${
            isFever
              ? 'scale-125 opacity-90 bg-gradient-to-r from-orange-500 to-rose-500'
              : isGolden
              ? 'scale-110 opacity-90 bg-amber-400'
              : 'opacity-60'
          }`}
          style={{
            backgroundColor: isFever ? '#F97316' : isGolden ? '#FBBF24' : targetColor.hex,
            boxShadow: `0 0 50px ${
              isFever ? '#EA580C' : isGolden ? '#FBBF24' : targetColor.glow
            }`,
          }}
        />

        {/* Circular SVG Timer */}
        <svg
          className="relative h-36 w-36 -rotate-90 transform"
          viewBox="0 0 136 136"
        >
          {/* Background circle track */}
          <circle
            cx="68"
            cy="68"
            r={radius}
            className="stroke-slate-800/80"
            strokeWidth="7"
            fill="transparent"
          />
          {/* Animated depletion stroke */}
          <circle
            cx="68"
            cy="68"
            r={radius}
            stroke={
              isFever
                ? '#F97316'
                : isGolden
                ? '#F59E0B'
                : isLowTime
                ? '#EF4444'
                : targetColor.hex
            }
            strokeWidth="7"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-[stroke-dashoffset] duration-75 ease-linear"
            style={{
              filter: `drop-shadow(0 0 7px ${
                isFever ? '#F97316' : isGolden ? '#FBBF24' : isLowTime ? '#EF4444' : targetColor.hex
              })`,
            }}
          />
        </svg>

        {/* Center Target Color Disc */}
        <div
          className={`absolute flex h-24 w-24 items-center justify-center rounded-full shadow-inner transition-transform duration-150 ${
            isFever
              ? 'animate-pulse ring-4 ring-orange-500 ring-offset-2 ring-offset-slate-950'
              : isGolden
              ? 'animate-gold-pulse'
              : 'active:scale-95'
          }`}
          style={{
            backgroundColor: targetColor.hex,
            boxShadow: isFever
              ? '0 0 35px rgba(249,115,22,0.9), inset 0 2px 14px rgba(255,255,255,0.8)'
              : isGolden
              ? '0 0 30px rgba(251,191,36,0.9), inset 0 2px 12px rgba(255,255,255,0.8)'
              : `0 6px 20px ${targetColor.glow}, inset 0 2px 8px rgba(255,255,255,0.45)`,
          }}
        >
          {/* Glossy top highlight */}
          <div className="pointer-events-none absolute inset-x-2 top-1.5 h-8 rounded-full bg-gradient-to-b from-white/40 to-transparent" />

          {/* Golden bonus or fever star icon */}
          {isGolden ? (
            <div className="relative flex flex-col items-center justify-center text-amber-950 font-black">
              <Sparkles className="h-8 w-8 text-amber-950 fill-amber-300 drop-shadow-sm" />
              <span className="text-[10px] font-black tracking-wider uppercase text-amber-950">
                +5 PTS
              </span>
            </div>
          ) : isFever ? (
            <div className="relative flex flex-col items-center justify-center text-white font-black">
              <Flame className="h-8 w-8 text-white fill-orange-200 drop-shadow-md animate-bounce" />
              <span className="text-[9px] font-black tracking-wider uppercase text-white drop-shadow">
                2X FEVER
              </span>
            </div>
          ) : null}
        </div>
      </div>

      {/* Target Color Name & Speed indicator */}
      <div className="mt-2.5 flex items-center gap-2 text-center">
        <span
          className="text-base font-bold tracking-tight text-white transition-colors duration-150"
          style={{ textShadow: `0 0 10px ${targetColor.hex}` }}
        >
          {targetColor.name}
        </span>
        <span className="text-slate-500">·</span>
        <span className="text-xs font-mono tabular-nums text-slate-400">
          {(Math.max(1, 1 + Math.floor(score / 5) * 0.15)).toFixed(1)}x Speed
        </span>
      </div>

      {/* Fever Mode Duration Meter if Fever is active */}
      {isFever && (
        <div className="mt-2 w-48 h-1.5 bg-slate-800 rounded-full overflow-hidden border border-orange-500/40">
          <div
            className="h-full bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 transition-all duration-75"
            style={{ width: `${Math.max(0, feverTimeRemainingRatio * 100)}%` }}
          />
        </div>
      )}
    </div>
  );
};
