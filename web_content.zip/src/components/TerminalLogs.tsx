import { useState } from 'react';
import { Terminal, ChevronDown, ChevronUp, Trash2, Cpu, ShieldCheck } from 'lucide-react';
import type { TerminalLogEntry } from '../types';
import { cyberAudio } from '../audio';

interface Props {
  logs: TerminalLogEntry[];
  onClear: () => void;
}

export default function TerminalLogs({ logs, onClear }: Props) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-[#040609] border border-emerald-500/30 rounded-2xl overflow-hidden font-mono text-xs box-glow-green">
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-black/80 border-b border-emerald-500/20">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span className="font-cyber font-bold text-xs text-emerald-300">
            HACKER TERMINAL LOGS // লাইভ অ্যালগোরিদম কনসোল
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            {logs.length} EVENTS
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              cyberAudio.playClick();
              onClear();
            }}
            title="লগ ক্লিয়ার করুন"
            className="p-1 rounded text-emerald-600 hover:text-emerald-400 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              cyberAudio.playClick();
              setIsExpanded(!isExpanded);
            }}
            className="flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 cursor-pointer px-2 py-1 rounded bg-emerald-950/40 border border-emerald-500/30"
          >
            <span>{isExpanded ? 'MINIMIZE' : 'EXPAND'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Log items container */}
      <div
        className={`p-3 space-y-1.5 overflow-y-auto bg-black/95 transition-all duration-300 ${
          isExpanded ? 'h-64' : 'h-24'
        }`}
      >
        {logs.map((log) => {
          let colorClass = 'text-emerald-400/90';
          if (log.level === 'success') colorClass = 'text-emerald-300 font-bold';
          if (log.level === 'warn') colorClass = 'text-amber-400';
          if (log.level === 'error') colorClass = 'text-red-400';

          return (
            <div key={log.id} className="flex items-start gap-2 leading-relaxed text-[11px]">
              <span className="text-emerald-600 select-none">[{log.time}]</span>
              <span className="text-cyan-500 select-none">&gt;&gt;</span>
              <span className={colorClass}>{log.text}</span>
            </div>
          );
        })}
        <div className="flex items-center gap-1 text-emerald-500 animate-pulse text-[11px]">
          <span>&gt;&gt;</span>
          <span className="w-1.5 h-3.5 bg-emerald-400 inline-block" />
        </div>
      </div>
    </div>
  );
}
