import React, { useId } from 'react';

export const YinYangIcon: React.FC<{ className?: string; size?: number }> = ({ className = "w-5 h-5", size = 20 }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className} fill="none">
      <defs>
        <linearGradient id={`yyGold_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="50%" stopColor="#e2b054" />
          <stop offset="100%" stopColor="#b45309" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="47" stroke={`url(#yyGold_${uid})`} strokeWidth="4" fill="#071a14" />
      <path d="M 50,3 A 47,47 0 0,1 50,97 A 23.5,23.5 0 0,1 50,50 A 23.5,23.5 0 0,0 50,3 Z" fill={`url(#yyGold_${uid})`} />
      <circle cx="50" cy="26.5" r="7.5" fill="#071a14" />
      <circle cx="50" cy="73.5" r="7.5" fill="#fef08a" />
    </svg>
  );
};

export const SpiritStoneIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`stoneGrad_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#e0f2fe" />
          <stop offset="45%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#0369a1" />
        </linearGradient>
      </defs>
      <polygon points="7 2 17 2 22 8.5 12 22 2 8.5 7 2" fill={`url(#stoneGrad_${uid})`} stroke="#7dd3fc" strokeWidth="1.2" strokeLinejoin="round" />
      <polygon points="7 2 12 8.5 17 2" fill="#e0f2fe" opacity="0.55" />
      <polygon points="2 8.5 12 8.5 12 22" fill="#0284c7" opacity="0.35" />
      <path d="M2 8.5h20M12 22V8.5M7 2l5 6.5L17 2" stroke="#bae6fd" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

export const QiOrbIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <radialGradient id={`qiGrad_${uid}`} cx="38%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#ecfdf5" />
          <stop offset="35%" stopColor="#4ade80" />
          <stop offset="75%" stopColor="#16a34a" />
          <stop offset="100%" stopColor="#064e3b" />
        </radialGradient>
      </defs>
      <circle cx="12" cy="12" r="9.5" fill={`url(#qiGrad_${uid})`} stroke="#86efac" strokeWidth="1.1" />
      <ellipse cx="9.2" cy="8.4" rx="2.8" ry="1.5" transform="rotate(-25 9.2 8.4)" fill="#ffffff" opacity="0.65" />
      <path d="M6.5 13c2-3.2 5.2-2.6 7.5 0s3.8 2.8 3.2 4.5" stroke="#bbf7d0" strokeWidth="1.4" strokeLinecap="round" opacity="0.85" />
    </svg>
  );
};

export const PillFlaskIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`pillGrad_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#99f6e4" />
          <stop offset="50%" stopColor="#14b8a6" />
          <stop offset="100%" stopColor="#115e59" />
        </linearGradient>
      </defs>
      <rect x="8.5" y="2" width="7" height="2.6" rx="1" fill="#e2b054" stroke="#92400e" strokeWidth="0.8" />
      <path d="M10 4.5v3.2L5.2 15.8a3.2 3.2 0 0 0 2.7 4.9h8.2a3.2 3.2 0 0 0 2.7-4.9L14 7.7V4.5" fill={`url(#pillGrad_${uid})`} stroke="#5eead4" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M7.3 15.2c2.5-1.1 6.9 1.1 9.4 0" stroke="#ccfbf1" strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="10.5" cy="17.2" r="1.3" fill="#fef08a" />
      <circle cx="14" cy="16.4" r="0.9" fill="#ffffff" opacity="0.85" />
    </svg>
  );
};

export const MeritScrollIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`scrollGrad_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef3c7" />
          <stop offset="60%" stopColor="#e2b054" />
          <stop offset="100%" stopColor="#92400e" />
        </linearGradient>
      </defs>
      <path d="M7.5 2.5H19c1.1 0 2 .9 2 2v13.5c0 1.1-.9 2-2 2H6c-1.7 0-3-1.3-3-3V5.5c0-1.7 1.3-3 3-3h1.5Z" fill={`url(#scrollGrad_${uid})`} stroke="#b45309" strokeWidth="1.3" />
      <circle cx="5.5" cy="17.5" r="2.2" fill="#92400e" stroke="#fde047" strokeWidth="1" />
      <path d="M8 7.5h9.5M8 11h8M8 14.5h5.5" stroke="#451a03" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="17" cy="14.5" r="1.4" fill="#b91c1c" />
    </svg>
  );
};

export const DaoSwordIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`bladeGrad_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f8fafc" />
          <stop offset="50%" stopColor="#7dd3fc" />
          <stop offset="100%" stopColor="#0284c7" />
        </linearGradient>
      </defs>
      <path d="M3 3l3.8.6L16.5 13.3l-3.2 3.2L3.6 6.8L3 3Z" fill={`url(#bladeGrad_${uid})`} stroke="#bae6fd" strokeWidth="1.2" strokeLinejoin="round" />
      <path d="M5 5l9 9" stroke="#ffffff" strokeWidth="1" opacity="0.85" />
      <path d="M12.2 18.2l6-6 1.5 1.5-6 6z" fill="#e2b054" stroke="#78350f" strokeWidth="1" />
      <path d="M17.5 17.5l3 3" stroke="#b45309" strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="20.8" cy="20.8" r="1.2" fill="#fde047" />
    </svg>
  );
};

export const SectPagodaIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`roofGrad_${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#b45309" />
        </linearGradient>
      </defs>
      <path d="M12 1.8l-9 5.7h18L12 1.8z" fill={`url(#roofGrad_${uid})`} stroke="#fce18b" strokeWidth="1.1" strokeLinejoin="round" />
      <path d="M5.5 7.5v3.5h13V7.5" fill="#184838" stroke="#e2b054" strokeWidth="1.2" />
      <path d="M3 11h18l-2 4H5l-2-4z" fill={`url(#roofGrad_${uid})`} stroke="#fce18b" strokeWidth="1.1" strokeLinejoin="round" />
      <path d="M6 15v6.5h12V15" fill="#123d30" stroke="#e2b054" strokeWidth="1.2" />
      <path d="M10 21.5v-4.2h4v4.2" fill="#e2b054" />
    </svg>
  );
};

export const ThunderCloudIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`cloudGrad_${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#64748b" />
          <stop offset="100%" stopColor="#1e293b" />
        </linearGradient>
      </defs>
      <path d="M17.5 16.5H8.5a5.5 5.5 0 1 1 5.3-7.1h1.5a3.8 3.8 0 1 1 2.2 7.1z" fill={`url(#cloudGrad_${uid})`} stroke="#94a3b8" strokeWidth="1.3" />
      <path d="M13.5 12.5l-3.2 5h3.6l-2 4.8" stroke="#fde047" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

export const CauldronIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <defs>
        <linearGradient id={`cauldronGrad_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fbbf24" />
          <stop offset="50%" stopColor="#b45309" />
          <stop offset="100%" stopColor="#451a03" />
        </linearGradient>
      </defs>
      <rect x="4" y="7" width="16" height="2" rx="1" fill="#fde047" />
      <path d="M5 9c0 6.2 3.2 9.8 7 9.8s7-3.6 7-9.8" fill={`url(#cauldronGrad_${uid})`} stroke="#e2b054" strokeWidth="1.2" />
      <path d="M7.5 18.2l-2 3.5M16.5 18.2l2 3.5M12 18.8v3" stroke="#e2b054" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M9.5 4.8a2.5 2.5 0 0 1 5 0" stroke="#5eead4" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="12" cy="13.5" r="1.5" fill="#fde047" />
    </svg>
  );
};

export const BaguaIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
    <polygon points="8.5 2 15.5 2 21.5 8 21.5 16 15.5 22 8.5 22 2.5 16 2.5 8" stroke="#e2b054" fill="rgba(18, 61, 48, 0.78)" />
    <circle cx="12" cy="12" r="4.2" stroke="#fce18b" fill="#071a14" />
    <path d="M12 7.8v8.4M7.8 12h8.4" stroke="#fce18b" strokeWidth="1.1" />
  </svg>
);
