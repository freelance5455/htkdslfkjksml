import React from 'react';

export const YinYangIcon: React.FC<{ className?: string; size?: number }> = ({ className = "w-5 h-5", size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className} fill="none">
    <circle cx="50" cy="50" r="48" stroke="currentColor" strokeWidth="4" />
    <path d="M 50,2 A 48,48 0 0,1 50,98 A 24,24 0 0,1 50,50 A 24,24 0 0,0 50,2 Z" fill="currentColor" />
    <circle cx="50" cy="26" r="8" fill="#0b261d" />
    <circle cx="50" cy="74" r="8" fill="currentColor" />
  </svg>
);

export const SpiritStoneIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="6 3 18 3 22 9 12 22 2 9 6 3" fill="rgba(56, 189, 248, 0.25)" stroke="#38bdf8" />
    <path d="M12 22V9" stroke="#7dd3fc" />
    <path d="M2 9h20" stroke="#7dd3fc" />
    <path d="M6 3l6 6 6-6" stroke="#bae6fd" />
  </svg>
);

export const QiOrbIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none">
    <defs>
      <radialGradient id="qiGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#86efac" />
        <stop offset="70%" stopColor="#22c55e" />
        <stop offset="100%" stopColor="#15803d" />
      </radialGradient>
    </defs>
    <circle cx="12" cy="12" r="9" fill="url(#qiGrad)" />
    <path d="M7 12c1.5-3 5-3 7 0s4 3 3 5" stroke="#dcfce7" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
  </svg>
);

export const PillFlaskIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M9 3h6M10 3v4l-5 9a3 3 0 0 0 2.6 4.5h8.8a3 3 0 0 0 2.6-4.5l-5-9V3" stroke="#2dd4bf" fill="rgba(45, 212, 191, 0.2)" />
    <path d="M7.5 15h9" stroke="#5eead4" strokeWidth="1.5" strokeDasharray="2 2" />
    <circle cx="12" cy="16" r="1.5" fill="#5eead4" />
  </svg>
);

export const MeritScrollIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M8 2H19C20.1 2 21 2.9 21 4V18C21 19.1 20.1 20 19 20H6C4.3 20 3 18.7 3 17V5C3 3.3 4.3 2 6 2H8Z" fill="rgba(226, 176, 84, 0.25)" stroke="#e2b054" />
    <path d="M3 17C3 18.7 4.3 20 6 20H19" stroke="#e2b054" />
    <path d="M7 7H17M7 11H15M7 15H13" stroke="#fce18b" strokeLinecap="round" strokeWidth="1.5" />
  </svg>
);

export const DaoSwordIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M14.5 17.5L3 6V3h3l11.5 11.5" stroke="#93c5fd" />
    <path d="M13 19l2 2 4-4-2-2" stroke="#e2b054" />
    <path d="M19 21l2-2" stroke="#e2b054" />
    <path d="M3 3l6 6" stroke="#93c5fd" />
  </svg>
);

export const SectPagodaIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M12 2L2 8h20L12 2z" fill="rgba(226, 176, 84, 0.3)" stroke="#e2b054" />
    <path d="M5 8v4h14V8" stroke="#e2b054" />
    <path d="M3 12h18l-2 4H5l-2-4z" fill="rgba(226, 176, 84, 0.2)" stroke="#e2b054" />
    <path d="M6 16v6h12v-6" stroke="#e2b054" />
    <path d="M10 22v-4h4v4" stroke="#fce18b" />
  </svg>
);

export const ThunderCloudIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9z" fill="rgba(100, 116, 139, 0.3)" stroke="#94a3b8" />
    <path d="M13 15l-3 5h4l-2 5" stroke="#facc15" strokeLinecap="round" strokeLinejoin="round" fill="#facc15" />
  </svg>
);

export const CauldronIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M4 8h16" stroke="#e2b054" />
    <path d="M5 8c0 7 3.5 11 7 11s7-4 7-11" fill="rgba(226, 176, 84, 0.15)" stroke="#e2b054" />
    <path d="M7 19l-2 3M17 19l2 3" stroke="#e2b054" strokeLinecap="round" />
    <path d="M9 4a3 3 0 0 1 6 0" stroke="#fce18b" strokeLinecap="round" />
  </svg>
);

export const BaguaIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
    <polygon points="8.5 2 15.5 2 21.5 8 21.5 16 15.5 22 8.5 22 2.5 16 2.5 8" stroke="#e2b054" fill="rgba(18, 61, 48, 0.6)" />
    <circle cx="12" cy="12" r="4" stroke="#fce18b" />
    <path d="M12 8v8M8 12h8" stroke="#fce18b" strokeWidth="1" />
  </svg>
);
