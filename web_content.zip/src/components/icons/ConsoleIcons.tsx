import React, { useId } from 'react';

interface IconProps {
  className?: string;
}

/**
 * Console-style Game Store icon:
 * Clean geometric storefront bag with a true masked-cutout gamepad silhouette inside.
 */
export const ConsoleStoreIcon: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => {
  const maskId = useId().replace(/:/g, '');
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <mask id={`pad-cutout-${maskId}`}>
          <rect x="0" y="0" width="32" height="32" fill="white" />
          <rect x="12.6" y="18.1" width="2.2" height="0.9" fill="black" />
          <rect x="13.25" y="17.45" width="0.9" height="2.2" fill="black" />
          <circle cx="18.6" cy="18.1" r="0.68" fill="black" />
          <circle cx="17.5" cy="19.1" r="0.68" fill="black" />
        </mask>
      </defs>
      {/* Store bag handle */}
      <path
        d="M11 10V7.5C11 5.01472 13.0147 3 15.5 3H16.5C18.9853 3 21 5.01472 21 7.5V10"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="square"
      />
      {/* Store bag chassis */}
      <path
        d="M4.5 10H27.5L26.2 28H5.8L4.5 10Z"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinejoin="miter"
      />
      {/* Console controller emblem inside bag with true cutouts */}
      <path
        d="M11.2 17.5C11.5 16.3 12.5 15.5 13.7 15.5H18.3C19.5 15.5 20.5 16.3 20.8 17.5L21.5 20.8C21.7 21.8 20.9 22.7 19.9 22.5L18.2 21.6C17.8 21.4 17.4 21.3 17 21.3H15C14.6 21.3 14.2 21.4 13.8 21.6L12.1 22.5C11.1 22.7 10.3 21.8 10.5 20.8L11.2 17.5Z"
        fill="currentColor"
        mask={`url(#pad-cutout-${maskId})`}
      />
    </svg>
  );
};

/**
 * Console-style Game Library icon:
 * Classic gaming dashboard collection grid + stacked game case shelves.
 */
export const ConsoleLibraryIcon: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Top-left game tile */}
    <rect
      x="4"
      y="4"
      width="10.5"
      height="10.5"
      stroke="currentColor"
      strokeWidth="2.1"
    />
    {/* Top-right game tile */}
    <rect
      x="17.5"
      y="4"
      width="10.5"
      height="10.5"
      stroke="currentColor"
      strokeWidth="2.1"
    />
    {/* Bottom-left game tile with mini play indicator */}
    <rect
      x="4"
      y="17.5"
      width="10.5"
      height="10.5"
      stroke="currentColor"
      strokeWidth="2.1"
    />
    <path d="M8 20.6L11.4 22.75L8 24.9V20.6Z" fill="currentColor" />
    {/* Bottom-right stacked library spines / shelves */}
    <rect x="17.5" y="17.5" width="3" height="10.5" fill="currentColor" />
    <rect x="22" y="17.5" width="2.4" height="10.5" fill="currentColor" />
    <path
      d="M25.8 18.2L28.6 27.6"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="square"
    />
  </svg>
);
