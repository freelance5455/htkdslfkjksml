import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import {
  Activity,
  Zap,
  DollarSign,
  TrendingUp,
  Sliders,
  Cpu,
  Flame,
  ShieldCheck,
  Sparkles,
  Info,
  Calendar,
  Layers,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import { ImsiWalletBalances } from '../lib/imsiEngine';
import { currencyConverter, DisplayCurrency } from '../lib/currencyConverter';

interface MiningEfficiencyDashboardProps {
  wallet?: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenBiometricAuth?: () => void;
}

export interface MiningDataPoint {
  timestamp: Date;
  label: string;
  hashRateTh: number; // TH/s
  powerWatts: number; // Watts
  electricityCostPerDayUsd: number; // $ / day
  grossRevenueUsd: number; // $ / day
  netProfitUsd: number; // $ / day
  profitMarginPercent: number; // %
  efficiencyJoulesPerTh: number; // J/TH
}

interface HardwareProfile {
  id: string;
  name: string;
  manufacturer: string;
  baseHashRate: number; // TH/s
  baseWatts: number; // W
  joulesPerTh: number;
}

const HARDWARE_PROFILES: HardwareProfile[] = [
  {
    id: 's21_pro',
    name: 'Antminer S21 Pro Hydro',
    manufacturer: 'Bitmain ASIC Matrix',
    baseHashRate: 234,
    baseWatts: 3510,
    joulesPerTh: 15.0
  },
  {
    id: 'm60s',
    name: 'Whatsminer M60S+',
    manufacturer: 'MicroBT Deep Cooling',
    baseHashRate: 186,
    baseWatts: 3440,
    joulesPerTh: 18.5
  },
  {
    id: 'sovereign_hydro',
    name: 'Sovereign Altar Hydro Cluster',
    manufacturer: 'JUHNKRIX Custom ASIC Pod',
    baseHashRate: 350,
    baseWatts: 4900,
    joulesPerTh: 14.0
  },
  {
    id: 'eco_undervolt',
    name: 'Eco-Green Undervolt Pod',
    manufacturer: 'Solar-Assisted Efficiency Array',
    baseHashRate: 145,
    baseWatts: 1885,
    joulesPerTh: 13.0
  }
];

export const MiningEfficiencyDashboard: React.FC<MiningEfficiencyDashboardProps> = ({
  wallet,
  onShowToast,
  onOpenBiometricAuth
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const [selectedProfileId, setSelectedProfileId] = useState<string>('s21_pro');
  const [electricityRateKwh, setElectricityRateKwh] = useState<number>(0.06); // $0.06 per kWh
  const [timeframe, setTimeframe] = useState<'24H' | '7D' | '30D'>('24H');
  const [overclockMode, setOverclockMode] = useState<'ECO' | 'NORMAL' | 'TURBO'>('NORMAL');
  const [hoveredPoint, setHoveredPoint] = useState<MiningDataPoint | null>(null);

  const activeProfile = HARDWARE_PROFILES.find((p) => p.id === selectedProfileId) || HARDWARE_PROFILES[0];

  // Multiplier from overclock mode
  const modeMultiplier = useMemo(() => {
    if (overclockMode === 'ECO') return { hash: 0.85, watts: 0.72 };
    if (overclockMode === 'TURBO') return { hash: 1.18, watts: 1.28 };
    return { hash: 1.0, watts: 1.0 };
  }, [overclockMode]);

  const currentHashRate = activeProfile.baseHashRate * modeMultiplier.hash;
  const currentWatts = activeProfile.baseWatts * modeMultiplier.watts;
  const currentJoulesPerTh = +(currentWatts / currentHashRate).toFixed(1);

  // Revenue rate: ~0.00000085 BTC per TH/day * $96,420 / BTC ~= $0.082 per TH/day
  const REVENUE_PER_TH_DAY_USD = 0.085;

  // Generate continuous time-series data for D3 chart
  const chartData = useMemo<MiningDataPoint[]>(() => {
    const pointsCount = timeframe === '24H' ? 24 : timeframe === '7D' ? 28 : 30;
    const data: MiningDataPoint[] = [];
    const now = new Date();

    for (let i = pointsCount - 1; i >= 0; i--) {
      const d = new Date(now);
      if (timeframe === '24H') {
        d.setHours(d.getHours() - i);
      } else if (timeframe === '7D') {
        d.setHours(d.getHours() - i * 6);
      } else {
        d.setDate(d.getDate() - i);
      }

      // Natural continuous fluctuations (ambient temperature & pool difficulty drift)
      const noiseHash = Math.sin(i * 0.4) * (currentHashRate * 0.03) + (Math.random() - 0.5) * (currentHashRate * 0.02);
      const noiseWatts = Math.cos(i * 0.3) * (currentWatts * 0.02) + (Math.random() - 0.5) * (currentWatts * 0.015);

      const hashRate = Math.max(10, currentHashRate + noiseHash);
      const watts = Math.max(100, currentWatts + noiseWatts);
      const kwhPerDay = (watts * 24) / 1000;
      const powerCostUsd = kwhPerDay * electricityRateKwh;
      const grossRevUsd = hashRate * REVENUE_PER_TH_DAY_USD;
      const netProfit = grossRevUsd - powerCostUsd;
      const profitMargin = grossRevUsd > 0 ? (netProfit / grossRevUsd) * 100 : 0;
      const effJth = +(watts / hashRate).toFixed(1);

      let label = '';
      if (timeframe === '24H') {
        label = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } else {
        label = d.toLocaleDateString([], { month: 'short', day: 'numeric' });
      }

      data.push({
        timestamp: d,
        label,
        hashRateTh: +hashRate.toFixed(1),
        powerWatts: +watts.toFixed(0),
        electricityCostPerDayUsd: +powerCostUsd.toFixed(2),
        grossRevenueUsd: +grossRevUsd.toFixed(2),
        netProfitUsd: +netProfit.toFixed(2),
        profitMarginPercent: +profitMargin.toFixed(1),
        efficiencyJoulesPerTh: effJth
      });
    }

    return data;
  }, [currentHashRate, currentWatts, electricityRateKwh, timeframe]);

  // Current Live Aggregates
  const latest = chartData[chartData.length - 1] || chartData[0];
  const dailyKwh = ((latest.powerWatts * 24) / 1000).toFixed(1);
  const breakevenBtcPrice = latest.grossRevenueUsd > 0
    ? Math.round((latest.electricityCostPerDayUsd / latest.grossRevenueUsd) * 96420)
    : 22000;

  // D3 Chart Rendering Engine
  useEffect(() => {
    if (!svgRef.current || !containerRef.current || chartData.length === 0) return;

    const containerWidth = containerRef.current.clientWidth;
    const width = Math.max(containerWidth, 500);
    const height = 340;
    const margin = { top: 25, right: 60, bottom: 45, left: 60 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg.attr('viewBox', `0 0 ${width} ${height}`).attr('width', '100%').attr('height', height);

    // Definitions for gradients & glow filters
    const defs = svg.append('defs');

    // Gradient for Net Profit Area
    const profitGrad = defs
      .append('linearGradient')
      .attr('id', 'profitAreaGradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    profitGrad.append('stop').attr('offset', '0%').attr('stop-color', '#10b981').attr('stop-opacity', 0.45);
    profitGrad.append('stop').attr('offset', '100%').attr('stop-color', '#10b981').attr('stop-opacity', 0.02);

    // Gradient for Power Consumption Area
    const powerGrad = defs
      .append('linearGradient')
      .attr('id', 'powerAreaGradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    powerGrad.append('stop').attr('offset', '0%').attr('stop-color', '#f59e0b').attr('stop-opacity', 0.25);
    powerGrad.append('stop').attr('offset', '100%').attr('stop-color', '#f59e0b').attr('stop-opacity', 0.01);

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale: Time
    const timeExtent = d3.extent(chartData, (d: MiningDataPoint) => d.timestamp);
    const xScale = d3
      .scaleTime()
      .domain([timeExtent[0] || new Date(), timeExtent[1] || new Date()])
      .range([0, innerWidth]);

    // Left Y Scale: Net Profit ($/Day) & Revenue
    const maxProfit = d3.max(chartData, (d: MiningDataPoint) => Math.max(d.grossRevenueUsd, d.netProfitUsd * 1.25)) || 30;
    const yProfitScale = d3.scaleLinear().domain([0, maxProfit]).nice().range([innerHeight, 0]);

    // Right Y Scale: Hash Rate (TH/s)
    const maxHash = d3.max(chartData, (d: MiningDataPoint) => d.hashRateTh * 1.2) || 300;
    const yHashScale = d3.scaleLinear().domain([0, maxHash]).nice().range([innerHeight, 0]);

    // Gridlines (Horizontal)
    const yAxisGrid = d3.axisLeft(yProfitScale).tickSize(-innerWidth).tickFormat(() => '');
    g.append('g')
      .attr('class', 'grid-lines')
      .call(yAxisGrid)
      .selectAll('line')
      .attr('stroke', '#334155')
      .attr('stroke-opacity', 0.25)
      .attr('stroke-dasharray', '3,3');

    // Axes
    const xAxis = d3
      .axisBottom(xScale)
      .ticks(Math.min(6, chartData.length))
      .tickFormat((d: any) => {
        const dt = d as Date;
        return timeframe === '24H'
          ? dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          : dt.toLocaleDateString([], { month: 'short', day: 'numeric' });
      });

    const yAxisLeft = d3
      .axisLeft(yProfitScale)
      .ticks(5)
      .tickFormat((d) => `$${d}`);

    const yAxisRight = d3
      .axisRight(yHashScale)
      .ticks(5)
      .tickFormat((d) => `${d}T`);

    // Render X Axis
    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .selectAll('text')
      .attr('fill', '#94a3b8')
      .attr('font-size', '10px')
      .attr('font-weight', '600');

    // Render Left Y Axis (Profit $/day)
    g.append('g')
      .call(yAxisLeft)
      .selectAll('text')
      .attr('fill', '#34d399')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold');

    // Render Right Y Axis (Hash Rate TH/s)
    g.append('g')
      .attr('transform', `translate(${innerWidth},0)`)
      .call(yAxisRight)
      .selectAll('text')
      .attr('fill', '#38bdf8')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold');

    // Area: Net Profit Margin Area
    const profitArea = d3
      .area<MiningDataPoint>()
      .x((d) => xScale(d.timestamp))
      .y0(innerHeight)
      .y1((d) => yProfitScale(d.netProfitUsd))
      .curve(d3.curveMonotoneX);

    g.append('path')
      .datum(chartData)
      .attr('fill', 'url(#profitAreaGradient)')
      .attr('d', profitArea);

    // Line: Hash Rate (Cyan)
    const hashLine = d3
      .line<MiningDataPoint>()
      .x((d) => xScale(d.timestamp))
      .y((d) => yHashScale(d.hashRateTh))
      .curve(d3.curveMonotoneX);

    g.append('path')
      .datum(chartData)
      .attr('fill', 'none')
      .attr('stroke', '#38bdf8')
      .attr('stroke-width', 2.5)
      .attr('d', hashLine);

    // Line: Net Profit Margin (Emerald Green)
    const profitLine = d3
      .line<MiningDataPoint>()
      .x((d) => xScale(d.timestamp))
      .y((d) => yProfitScale(d.netProfitUsd))
      .curve(d3.curveMonotoneX);

    g.append('path')
      .datum(chartData)
      .attr('fill', 'none')
      .attr('stroke', '#10b981')
      .attr('stroke-width', 3)
      .attr('d', profitLine);

    // Line: Electricity Cost ($/Day) (Amber Dashed)
    const powerLine = d3
      .line<MiningDataPoint>()
      .x((d) => xScale(d.timestamp))
      .y((d) => yProfitScale(d.electricityCostPerDayUsd))
      .curve(d3.curveMonotoneX);

    g.append('path')
      .datum(chartData)
      .attr('fill', 'none')
      .attr('stroke', '#f59e0b')
      .attr('stroke-width', 1.8)
      .attr('stroke-dasharray', '4,3')
      .attr('d', powerLine);

    // Interactive Overlay & Hover Crosshair
    const focusGroup = g.append('g').style('display', 'none');

    // Vertical dashed scanline
    const verticalLine = focusGroup
      .append('line')
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', '#fbbf24')
      .attr('stroke-width', 1.5)
      .attr('stroke-dasharray', '3,3');

    const profitCircle = focusGroup.append('circle').attr('r', 5).attr('fill', '#10b981').attr('stroke', '#ffffff').attr('stroke-width', 2);
    const hashCircle = focusGroup.append('circle').attr('r', 4.5).attr('fill', '#38bdf8').attr('stroke', '#ffffff').attr('stroke-width', 2);

    const bisectDate = d3.bisector<MiningDataPoint, Date>((d) => d.timestamp).left;

    // Invisible mouse event tracking rect
    g.append('rect')
      .attr('class', 'overlay')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'transparent')
      .on('mouseover', () => focusGroup.style('display', null))
      .on('mouseout', () => {
        focusGroup.style('display', 'none');
        setHoveredPoint(null);
      })
      .on('mousemove', (event) => {
        const [mx] = d3.pointer(event);
        const x0 = xScale.invert(mx);
        const idx = bisectDate(chartData, x0, 1);
        const d0 = chartData[idx - 1];
        const d1 = chartData[idx];
        let d = d0;
        if (d1 && d0) {
          d = x0.getTime() - d0.timestamp.getTime() > d1.timestamp.getTime() - x0.getTime() ? d1 : d0;
        }

        if (d) {
          const cx = xScale(d.timestamp);
          verticalLine.attr('x1', cx).attr('x2', cx);
          profitCircle.attr('cx', cx).attr('cy', yProfitScale(d.netProfitUsd));
          hashCircle.attr('cx', cx).attr('cy', yHashScale(d.hashRateTh));
          setHoveredPoint(d);
        }
      });
  }, [chartData, timeframe]);

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Activity className="w-4 h-4 text-amber-400" />
            <span>D3.JS MINING EFFICIENCY & THERMAL PROFIT ENGINE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Hash Rate, Electricity & Net Margin Metrics
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Interactive D3.js visualization plotting real-time ASIC computing power (TH/s), electrical wattage consumption, and net profit margins at dynamic tariff rates.
          </p>
        </div>

        {/* Timeframe & Mode Selectors */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Overclock Switch */}
          <div className="flex rounded-xl bg-slate-950 p-1 border border-amber-500/30">
            {(['ECO', 'NORMAL', 'TURBO'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setOverclockMode(mode)}
                className={`px-3 py-1 rounded-lg text-[10px] font-black transition-all ${
                  overclockMode === mode
                    ? mode === 'TURBO'
                      ? 'bg-rose-500 text-slate-950 shadow-md'
                      : mode === 'ECO'
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-amber-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Timeframe Selector */}
          <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800">
            {(['24H', '7D', '30D'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${
                  timeframe === tf
                    ? 'bg-slate-800 text-amber-300 font-black'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Hash Rate */}
        <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-3.5 space-y-1">
          <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider flex items-center space-x-1">
            <Cpu className="w-3 h-3 text-cyan-400" />
            <span>Hash Computing</span>
          </span>
          <div className="text-xl font-black text-cyan-100 font-mono">
            {latest.hashRateTh.toFixed(1)} <span className="text-xs text-cyan-400">TH/s</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">Profile: {activeProfile.name.split(' ')[0]}</p>
        </div>

        {/* Power Watts */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-3.5 space-y-1">
          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-1">
            <Flame className="w-3 h-3 text-amber-400" />
            <span>Power Draw</span>
          </span>
          <div className="text-xl font-black text-amber-100 font-mono">
            {latest.powerWatts.toLocaleString()} <span className="text-xs text-amber-400">W</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">{dailyKwh} kWh / Day</p>
        </div>

        {/* Energy Cost */}
        <div className="bg-slate-900/90 border border-rose-500/30 rounded-2xl p-3.5 space-y-1">
          <span className="text-[10px] font-bold text-rose-300 uppercase tracking-wider flex items-center space-x-1">
            <Zap className="w-3 h-3 text-rose-400" />
            <span>Electricity Cost</span>
          </span>
          <div className="text-xl font-black text-rose-200 font-mono">
            ${latest.electricityCostPerDayUsd.toFixed(2)}<span className="text-xs text-slate-400">/day</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">@ ${electricityRateKwh}/kWh</p>
        </div>

        {/* Gross Revenue */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-3.5 space-y-1">
          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-1">
            <DollarSign className="w-3 h-3 text-amber-400" />
            <span>Gross Revenue</span>
          </span>
          <div className="text-xl font-black text-amber-100 font-mono">
            ${latest.grossRevenueUsd.toFixed(2)}<span className="text-xs text-slate-400">/day</span>
          </div>
          <p className="text-[9px] text-emerald-400 font-mono">BTC $96,420 Peg</p>
        </div>

        {/* Net Profit Margin */}
        <div className="bg-slate-900/90 border border-emerald-500/40 rounded-2xl p-3.5 space-y-1 bg-emerald-950/20">
          <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-1">
            <TrendingUp className="w-3 h-3 text-emerald-400" />
            <span>Net Profit</span>
          </span>
          <div className="text-xl font-black text-emerald-200 font-mono">
            +${latest.netProfitUsd.toFixed(2)}<span className="text-xs text-emerald-400">/day</span>
          </div>
          <p className="text-[9px] text-emerald-400 font-bold font-mono">
            {latest.profitMarginPercent.toFixed(1)}% Margin
          </p>
        </div>

        {/* Efficiency Ratio */}
        <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-3.5 space-y-1">
          <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider flex items-center space-x-1">
            <Sparkles className="w-3 h-3 text-purple-400" />
            <span>Efficiency (J/TH)</span>
          </span>
          <div className="text-xl font-black text-purple-200 font-mono">
            {currentJoulesPerTh} <span className="text-xs text-purple-400">J/TH</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">Breakeven: ${breakevenBtcPrice.toLocaleString()}</p>
        </div>
      </div>

      {/* D3.js Chart Viewport Container */}
      <div className="bg-slate-950/90 border-2 border-amber-500/30 rounded-3xl p-4 sm:p-6 space-y-4 shadow-2xl relative">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Legend */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block shadow-sm shadow-emerald-500/50" />
              <span className="font-bold text-emerald-300">Net Profit Margin ($/Day)</span>
            </div>

            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-sky-400 inline-block shadow-sm shadow-sky-400/50" />
              <span className="font-bold text-sky-300">Hash Rate (TH/s)</span>
            </div>

            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-1.5 bg-amber-400 inline-block border-t border-dashed border-amber-300" />
              <span className="font-bold text-amber-300">Electricity Cost ($/Day)</span>
            </div>
          </div>

          {/* Hover Value Badge */}
          {hoveredPoint ? (
            <div className="px-3 py-1 bg-slate-900 border border-amber-400/60 rounded-xl text-[11px] font-mono text-amber-200 flex items-center space-x-3 animate-fadeIn">
              <span>Time: <strong className="text-slate-100">{hoveredPoint.label}</strong></span>
              <span>Hash: <strong className="text-sky-300">{hoveredPoint.hashRateTh} TH/s</strong></span>
              <span>Power: <strong className="text-amber-300">{hoveredPoint.powerWatts} W</strong></span>
              <span>Profit: <strong className="text-emerald-400">+${hoveredPoint.netProfitUsd}/d ({hoveredPoint.profitMarginPercent}%)</strong></span>
            </div>
          ) : (
            <span className="text-[10px] text-slate-500 italic">Hover over chart for precise timeline inspection</span>
          )}
        </div>

        {/* D3 SVG Canvas */}
        <div ref={containerRef} className="w-full overflow-hidden">
          <svg ref={svgRef} className="w-full cursor-crosshair select-none" />
        </div>
      </div>

      {/* Interactive Sliders & Hardware Pod Configurator */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
        {/* Hardware Matrix Selector */}
        <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span>Mining Hardware Matrix Selection:</span>
            </label>
            <span className="text-[10px] text-amber-400 font-mono font-bold">
              {activeProfile.joulesPerTh} J/TH Base
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {HARDWARE_PROFILES.map((prof) => {
              const isSelected = selectedProfileId === prof.id;
              return (
                <button
                  key={prof.id}
                  onClick={() => setSelectedProfileId(prof.id)}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    isSelected
                      ? 'bg-slate-950 border-amber-400 shadow-md ring-1 ring-amber-400'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-amber-500/30'
                  }`}
                >
                  <p className={`text-xs font-black truncate ${isSelected ? 'text-amber-200' : 'text-slate-300'}`}>
                    {prof.name}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {prof.baseHashRate} TH/s • {prof.baseWatts}W
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Electricity Tariff Slider */}
        <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-5 space-y-3 flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Electricity Cost Tariff Rate ($/kWh):</span>
            </label>
            <span className="text-sm font-black text-amber-300 font-mono">
              ${electricityRateKwh.toFixed(3)} / kWh
            </span>
          </div>

          <div className="space-y-2">
            <input
              type="range"
              min="0.01"
              max="0.20"
              step="0.005"
              value={electricityRateKwh}
              onChange={(e) => setElectricityRateKwh(parseFloat(e.target.value))}
              className="w-full accent-amber-400 bg-slate-950 cursor-pointer h-2 rounded-lg"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>$0.01 (Hydro/Geothermal)</span>
              <span>$0.06 (Industrial Avg)</span>
              <span>$0.20 (Commercial Peak)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
            <span className="text-slate-400">Net Profit Sensitivity:</span>
            <span className="font-bold text-emerald-400">
              +${(latest.grossRevenueUsd - (latest.powerWatts * 24 / 1000) * electricityRateKwh).toFixed(2)}/day at ${electricityRateKwh}/kWh
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
