import { Component } from 'react'

export function CrashScreen({ title, detail, onReload }) {
  return (
    <div className="crash">
      <div className="crash-card">
        <h2>{title}</h2>
        <p className="muted">
          Aapka data safe hai — sab kuch phone me hi save hota hai. Sirf app reload karo.
        </p>
        {detail && <pre className="crash-detail">{String(detail).slice(0, 400)}</pre>}
        <button className="btn btn-primary btn-big" onClick={onReload}>
          Reload karo
        </button>
      </div>
    </div>
  )
}

export default class ErrorBoundary extends Component {
  state = { error: null }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    console.error('App crash ho gaya:', error, info?.componentStack)
  }

  render() {
    if (!this.state.error) return this.props.children
    return (
      <CrashScreen
        title="Kuch gadbad ho gayi"
        detail={this.state.error?.message || this.state.error}
        onReload={() => window.location.reload()}
      />
    )
  }
}
