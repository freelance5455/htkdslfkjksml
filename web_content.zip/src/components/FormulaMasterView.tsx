import React, { useState } from 'react';
import { Compass, Zap, Flame, Globe2, ArrowUpRight, Copy, Check } from 'lucide-react';
import { audioService } from '../services/audioService';
import { historyStorage } from '../services/historyStorage';

interface FormulaMasterViewProps {
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  onSendToCalculator: (val: string) => void;
}

type FormulaTab = 'quadratic' | 'ohms' | 'kinetic' | 'geometry';

export const FormulaMasterView: React.FC<FormulaMasterViewProps> = ({
  onShowToast,
  onSendToCalculator,
}) => {
  const [activeTab, setActiveTab] = useState<FormulaTab>('quadratic');

  // --- 1. Quadratic State ---
  const [quadA, setQuadA] = useState<number>(2);
  const [quadB, setQuadB] = useState<number>(5);
  const [quadC, setQuadC] = useState<number>(-3);

  const discriminant = quadB * quadB - 4 * quadA * quadC;
  let root1 = '';
  let root2 = '';
  let rawNumericRoot: number | null = null;

  if (quadA !== 0) {
    if (discriminant > 0) {
      const r1 = (-quadB + Math.sqrt(discriminant)) / (2 * quadA);
      const r2 = (-quadB - Math.sqrt(discriminant)) / (2 * quadA);
      root1 = `x₁ = ${r1.toFixed(4)}`;
      root2 = `x₂ = ${r2.toFixed(4)}`;
      rawNumericRoot = r1;
    } else if (discriminant === 0) {
      const r = -quadB / (2 * quadA);
      root1 = `x = ${r.toFixed(4)} (Double Root)`;
      rawNumericRoot = r;
    } else {
      const real = (-quadB / (2 * quadA)).toFixed(4);
      const imag = (Math.sqrt(-discriminant) / (2 * Math.abs(quadA))).toFixed(4);
      root1 = `x₁ = ${real} + ${imag}i`;
      root2 = `x₂ = ${real} - ${imag}i`;
    }
  }

  const vertexX = quadA !== 0 ? -quadB / (2 * quadA) : 0;
  const vertexY = quadA * vertexX * vertexX + quadB * vertexX + quadC;

  // --- 2. Ohm's Law & Power State ---
  const [voltage, setVoltage] = useState<number>(12); // Volts
  const [resistance, setResistance] = useState<number>(4); // Ohms

  const current = resistance > 0 ? voltage / resistance : 0; // Amperes
  const power = voltage * current; // Watts

  // --- 3. Kinetic Energy State ---
  const [massKg, setMassKg] = useState<number>(1200); // kg
  const [velocityKmH, setVelocityKmH] = useState<number>(100); // km/h

  const velocityMS = (velocityKmH * 1000) / 3600; // m/s
  const kineticJoules = 0.5 * massKg * velocityMS * velocityMS;
  const kineticKiloJoules = kineticJoules / 1000;

  // --- 4. Geometry (Sphere & Cylinder) ---
  const [geomRadius, setGeomRadius] = useState<number>(5);
  const [geomHeight, setGeomHeight] = useState<number>(12);
  const [geomShape, setGeomShape] = useState<'sphere' | 'cylinder'>('cylinder');

  // Sphere: V = 4/3 π r^3, A = 4 π r^2
  const sphereVol = (4 / 3) * Math.PI * Math.pow(geomRadius, 3);
  const sphereArea = 4 * Math.PI * Math.pow(geomRadius, 2);

  // Cylinder: V = π r^2 h, A = 2πrh + 2πr^2
  const cylVol = Math.PI * Math.pow(geomRadius, 2) * geomHeight;
  const cylArea = 2 * Math.PI * geomRadius * geomHeight + 2 * Math.PI * Math.pow(geomRadius, 2);

  const handleTabChange = (tab: FormulaTab) => {
    audioService.playKeyClick();
    setActiveTab(tab);
  };

  const handleSendVal = (val: number, label: string) => {
    audioService.playKeyClick();
    const formatted = val.toFixed(4).replace(/\.?0+$/, '');
    onSendToCalculator(formatted);
    historyStorage.add({
      type: 'formula',
      title: label,
      expression: `${label}`,
      result: formatted,
      numericResult: Number(formatted),
    });
    onShowToast(`Sent ${formatted} to Calculator!`, 'success');
  };

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto p-3.5 space-y-3.5 overflow-y-auto">
      {/* Sub-Tabs */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-[#0a0c12] rounded-xl border border-zinc-800 text-[11px] font-mono">
        <button
          onClick={() => handleTabChange('quadratic')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'quadratic'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Quadratic
        </button>
        <button
          onClick={() => handleTabChange('ohms')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'ohms'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Ohm's Law
        </button>
        <button
          onClick={() => handleTabChange('kinetic')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'kinetic'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Kinetic E
        </button>
        <button
          onClick={() => handleTabChange('geometry')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'geometry'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Geometry
        </button>
      </div>

      {/* 1. Quadratic Formula */}
      {activeTab === 'quadratic' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>Quadratic Formula & Root Solver</span>
            </h4>

            <div className="p-2.5 rounded-xl bg-[#090b10] border border-amber-500/15 font-mono text-xs text-amber-200/90 text-center">
              ax² + bx + c = 0
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Coeff a:</span>
                <input
                  type="number"
                  value={quadA}
                  onChange={(e) => setQuadA(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400 text-center font-bold"
                />
              </div>
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Coeff b:</span>
                <input
                  type="number"
                  value={quadB}
                  onChange={(e) => setQuadB(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400 text-center font-bold"
                />
              </div>
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Const c:</span>
                <input
                  type="number"
                  value={quadC}
                  onChange={(e) => setQuadC(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400 text-center font-bold"
                />
              </div>
            </div>
          </div>

          {/* Solution Roots Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">
                  Calculated Roots
                </span>
                <div className="text-lg sm:text-xl font-mono font-bold gold-gradient-text">
                  {root1}
                </div>
                {root2 && (
                  <div className="text-lg sm:text-xl font-mono font-bold gold-gradient-text">
                    {root2}
                  </div>
                )}
              </div>
              {rawNumericRoot !== null && (
                <button
                  onClick={() => handleSendVal(rawNumericRoot!, 'Quadratic Root')}
                  className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
                >
                  <span>To Calc</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Discriminant (Δ = b² - 4ac)</span>
                <span
                  className={`font-semibold text-sm ${
                    discriminant > 0
                      ? 'text-emerald-400'
                      : discriminant === 0
                      ? 'text-amber-300'
                      : 'text-purple-400'
                  }`}
                >
                  {discriminant} ({discriminant > 0 ? '2 Real Roots' : discriminant === 0 ? '1 Real Root' : 'Complex Roots'})
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Vertex Coordinates (h, k)</span>
                <span className="text-amber-200 font-semibold text-sm">
                  ({vertexX.toFixed(2)}, {vertexY.toFixed(2)})
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Ohm's Law & Electrical Power */}
      {activeTab === 'ohms' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Ohm's Law & Circuit Power Hub</span>
            </h4>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="text-zinc-400">Voltage (V):</span>
                  <span className="text-amber-200 font-bold">{voltage} V</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="480"
                  value={voltage}
                  onChange={(e) => setVoltage(Number(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="text-zinc-400">Resistance (R):</span>
                  <span className="text-amber-200 font-bold">{resistance} Ω</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="100"
                  step="0.5"
                  value={resistance}
                  onChange={(e) => setResistance(Number(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Ohm's Results Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Current (I = V/R)</span>
                <div className="text-2xl font-mono font-bold text-cyan-300">
                  {current.toFixed(3)} A
                </div>
                <button
                  onClick={() => handleSendVal(current, 'Current')}
                  className="mt-1 text-[10px] text-amber-400 font-mono hover:underline flex items-center gap-0.5"
                >
                  <span>To Calc</span> <ArrowUpRight className="w-2.5 h-2.5" />
                </button>
              </div>

              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Power (P = V × I)</span>
                <div className="text-2xl font-mono font-bold gold-gradient-text">
                  {power.toFixed(2)} W
                </div>
                <button
                  onClick={() => handleSendVal(power, 'Power')}
                  className="mt-1 text-[10px] text-amber-400 font-mono hover:underline flex items-center gap-0.5"
                >
                  <span>To Calc</span> <ArrowUpRight className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400 flex justify-between">
              <span>Energy Dissipation Rate:</span>
              <span className="text-amber-200 font-bold">{(power / 1000).toFixed(4)} kW</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. Kinetic Energy */}
      {activeTab === 'kinetic' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Kinetic Energy Dynamics (Eₖ = ½mv²)</span>
            </h4>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Object Mass (m):</span>
                <span className="text-amber-200 font-bold">{massKg.toLocaleString()} kg</span>
              </div>
              <input
                type="range"
                min="1"
                max="5000"
                step="10"
                value={massKg}
                onChange={(e) => setMassKg(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Velocity (v):</span>
                <span className="text-amber-200 font-bold">{velocityKmH} km/h ({velocityMS.toFixed(1)} m/s)</span>
              </div>
              <input
                type="range"
                min="1"
                max="300"
                value={velocityKmH}
                onChange={(e) => setVelocityKmH(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>
          </div>

          {/* Kinetic Energy Results */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Kinetic Energy Output</span>
                <div className="text-2xl sm:text-3xl font-mono font-bold gold-gradient-text">
                  {kineticKiloJoules.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} kJ
                </div>
                <div className="text-xs text-zinc-400 font-mono">
                  {kineticJoules.toLocaleString('en-US', { maximumFractionDigits: 0 })} Joules
                </div>
              </div>
              <button
                onClick={() => handleSendVal(kineticJoules, 'Kinetic Energy')}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
              >
                <span>To Calc</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Geometry: Sphere & Cylinder */}
      {activeTab === 'geometry' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Globe2 className="w-4 h-4 text-amber-400" />
                <span>3D Spatial Geometry Master</span>
              </h4>
              <div className="flex gap-1 text-[10px] font-mono">
                <button
                  onClick={() => setGeomShape('cylinder')}
                  className={`px-2 py-0.5 rounded border transition ${
                    geomShape === 'cylinder'
                      ? 'bg-amber-400 text-black border-amber-300 font-bold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                  }`}
                >
                  Cylinder
                </button>
                <button
                  onClick={() => setGeomShape('sphere')}
                  className={`px-2 py-0.5 rounded border transition ${
                    geomShape === 'sphere'
                      ? 'bg-amber-400 text-black border-amber-300 font-bold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                  }`}
                >
                  Sphere
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Radius (r):</span>
                <input
                  type="number"
                  value={geomRadius}
                  onChange={(e) => setGeomRadius(Math.max(0.1, parseFloat(e.target.value) || 0))}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              {geomShape === 'cylinder' && (
                <div>
                  <span className="text-zinc-400 text-xs font-mono block mb-1">Height (h):</span>
                  <input
                    type="number"
                    value={geomHeight}
                    onChange={(e) => setGeomHeight(Math.max(0.1, parseFloat(e.target.value) || 0))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Geometry Results Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Volume (V)</span>
                <div className="text-2xl font-mono font-bold gold-gradient-text">
                  {(geomShape === 'cylinder' ? cylVol : sphereVol).toFixed(2)}
                </div>
                <button
                  onClick={() => handleSendVal(geomShape === 'cylinder' ? cylVol : sphereVol, 'Volume')}
                  className="mt-1 text-[10px] text-amber-400 font-mono hover:underline flex items-center gap-0.5"
                >
                  <span>To Calc</span> <ArrowUpRight className="w-2.5 h-2.5" />
                </button>
              </div>

              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Surface Area (A)</span>
                <div className="text-2xl font-mono font-bold text-cyan-300">
                  {(geomShape === 'cylinder' ? cylArea : sphereArea).toFixed(2)}
                </div>
                <button
                  onClick={() => handleSendVal(geomShape === 'cylinder' ? cylArea : sphereArea, 'Surface Area')}
                  className="mt-1 text-[10px] text-amber-400 font-mono hover:underline flex items-center gap-0.5"
                >
                  <span>To Calc</span> <ArrowUpRight className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
