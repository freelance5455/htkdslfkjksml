import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';
import {
  X,
  Download,
  Smartphone,
  Monitor,
  CheckCircle2,
  FolderArchive,
  Info,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Copy,
  Check
} from 'lucide-react';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const { language } = useApp();
  const [copiedLink, setCopiedLink] = useState<'apk' | 'exe' | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const apkUrl = '/downloads/Khatavahi-v2.0.0.apk';
  const exeUrl = '/downloads/Khatavahi-Windows-Setup-x64.exe';

  const handleCopyLink = (type: 'apk' | 'exe') => {
    const fullUrl = window.location.origin + (type === 'apk' ? apkUrl : exeUrl);
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(type);
    setTimeout(() => setCopiedLink(null), 2500);
  };

  const handlePWAInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstallable(false);
      setDeferredPrompt(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-stone-950 text-white px-6 py-4 flex items-center justify-between border-b border-amber-500/50">
          <div>
            <div className="text-[11px] font-semibold text-amber-300 tracking-widest">
              || શ્રી ગણેશાય નમઃ || ૧૦૦% ઓફલાઇન ||
            </div>
            <h2 className="text-base sm:text-lg font-bold text-amber-100 flex items-center gap-2 mt-0.5">
              <span>{t('downloadAppModalTitle', language)}</span>
            </h2>
            <p className="text-xs text-amber-200/80">
              {t('projectFilesNotice', language)}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-stone-300 hover:bg-red-800 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Project files banner */}
          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 flex items-start gap-2.5">
            <FolderArchive className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                {language === 'gu'
                  ? 'પ્રોજેક્ટ ફાઇલ્સમાં APK અને EXE પેકેજીસ સીધા ઉપલબ્ધ છે:'
                  : 'APK & EXE packages are generated directly inside your project files:'}
              </p>
              <div className="mt-1 font-mono text-[11px] text-amber-900 space-y-0.5 bg-amber-100/60 p-2 rounded border border-amber-300/60">
                <div>• /public/downloads/Khatavahi-v2.0.0.apk</div>
                <div>• /public/downloads/Khatavahi-Windows-Setup-x64.exe</div>
                <div>• /downloads/Khatavahi-v2.0.0.apk</div>
                <div>• /downloads/Khatavahi-Windows-Setup-x64.exe</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 1. Android APK Card */}
            <div className="rounded-2xl border-2 border-emerald-500/40 bg-emerald-50/20 p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                    Android 7.0+
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className="text-sm font-bold text-stone-900">
                    {t('downloadApkTitle', language)}
                  </h3>
                  <p className="text-xs text-stone-500 mt-0.5">
                    com.khatavahi.ledger • v2.0.0
                  </p>
                </div>

                {/* Instructions */}
                <div className="mt-3 text-[11px] text-stone-600 space-y-1 bg-white p-2.5 rounded-xl border border-stone-200">
                  <p className="font-semibold text-stone-800">
                    {language === 'gu' ? 'ઇન્સ્ટોલેશન પગલાં:' : 'Installation Steps:'}
                  </p>
                  <ol className="list-decimal pl-4 space-y-0.5 text-stone-600">
                    <li>{language === 'gu' ? 'APK ડાઉનલોડ બટન દબાવો.' : 'Click Download APK.'}</li>
                    <li>{language === 'gu' ? 'મોબાઇલમાં ફાઇલ ખોલી Install કરો.' : 'Open downloaded file and tap Install.'}</li>
                    <li>{language === 'gu' ? '૧૦૦% ઓફલાઇન વાપરો.' : 'Use 100% offline.'}</li>
                  </ol>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <a
                  href={apkUrl}
                  download="Khatavahi-v2.0.0.apk"
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-md active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>{t('downloadApkButton', language)}</span>
                </a>

                <button
                  type="button"
                  onClick={() => handleCopyLink('apk')}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg border border-emerald-300 bg-white hover:bg-emerald-50 text-emerald-800 text-[11px] font-medium transition-colors"
                >
                  {copiedLink === 'apk' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{language === 'gu' ? 'લિંક કોપી થઈ ગઈ!' : 'Direct Link Copied!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{language === 'gu' ? 'APK ડાઉનલોડ લિંક કોપી કરો' : 'Copy Direct APK Link'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 2. Windows EXE Card */}
            <div className="rounded-2xl border-2 border-blue-500/40 bg-blue-50/20 p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                    <Monitor className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-300">
                    Windows 10 / 11
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className="text-sm font-bold text-stone-900">
                    {t('downloadExeTitle', language)}
                  </h3>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Khatavahi-Windows-Setup-x64.exe • v2.0.0
                  </p>
                </div>

                {/* Instructions */}
                <div className="mt-3 text-[11px] text-stone-600 space-y-1 bg-white p-2.5 rounded-xl border border-stone-200">
                  <p className="font-semibold text-stone-800">
                    {language === 'gu' ? 'ઇન્સ્ટોલેશન પગલાં:' : 'Installation Steps:'}
                  </p>
                  <ol className="list-decimal pl-4 space-y-0.5 text-stone-600">
                    <li>{language === 'gu' ? 'EXE સેટઅપ ફાઇલ ડાઉનલોડ કરો.' : 'Click Download Windows Setup.'}</li>
                    <li>{language === 'gu' ? 'ડબલ ક્લિક કરી એપ રન/ઇન્સ્ટોલ કરો.' : 'Double-click executable to run.'}</li>
                    <li>{language === 'gu' ? 'ડેસ્કટોપ પરથી ઓફલાઇન ચલાવો.' : 'Run offline from desktop.'}</li>
                  </ol>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <a
                  href={exeUrl}
                  download="Khatavahi-Windows-Setup-x64.exe"
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-all shadow-md active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>{t('downloadExeButton', language)}</span>
                </a>

                <button
                  type="button"
                  onClick={() => handleCopyLink('exe')}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg border border-blue-300 bg-white hover:bg-blue-50 text-blue-800 text-[11px] font-medium transition-colors"
                >
                  {copiedLink === 'exe' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-blue-600" />
                      <span>{language === 'gu' ? 'લિંક કોપી થઈ ગઈ!' : 'Direct Link Copied!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{language === 'gu' ? 'EXE ડાઉનલોડ લિંક કોપી કરો' : 'Copy Direct EXE Link'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Direct PWA Install in Browser option */}
          {isInstallable && (
            <div className="p-3.5 rounded-xl bg-stone-100 border border-stone-200 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-stone-800">
                  {language === 'gu' ? 'બ્રાઉઝરમાંથી સીધું ઇન્સ્ટોલ (PWA)' : 'Instant Browser Install (PWA)'}
                </p>
                <p className="text-[11px] text-stone-500">
                  {language === 'gu' ? 'કોઈ ફાઇલ ડાઉનલોડ કર્યા વિના હોમ સ્ક્રીન પર મૂકો' : 'Add to home screen without file download'}
                </p>
              </div>
              <button
                type="button"
                onClick={handlePWAInstall}
                className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs"
              >
                {language === 'gu' ? 'સીધું ઇન્સ્ટોલ કરો' : 'Install Directly'}
              </button>
            </div>
          )}
        </div>

        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
          <span className="flex items-center gap-1 text-emerald-800 font-semibold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>૧૦૦% ઓફલાઇન અને શૂન્ય ટ્રેકિંગ / 100% Offline Zero Tracking</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-900 text-white font-semibold"
          >
            {language === 'gu' ? 'બંધ કરો' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
