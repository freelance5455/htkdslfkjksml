import React from 'react';
import { Trophy, X, Check, Lock, Sparkles, Zap, Sun, Flame, Crown, Star, Award, Grid, Shield } from 'lucide-react';
import { Achievement } from '../../types/game';

interface AchievementsModalProps {
  achievements: Achievement[];
  onClose: () => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Sparkles,
  Zap,
  Sun,
  Flame,
  Crown,
  Star,
  Award,
  Grid,
  Shield,
  Trophy,
};

export const AchievementsModal: React.FC<AchievementsModalProps> = ({ achievements, onClose }) => {
  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const progressPercent = Math.round((unlockedCount / achievements.length) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md max-h-[85vh] rounded-3xl bg-[#0b1329] border border-cyan-500/30 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)] flex flex-col relative text-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 sticky top-0 bg-[#0b1329] z-10">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold font-display text-white">Achievements</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Achievements"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Bar Banner */}
        <div className="p-3.5 rounded-2xl bg-[#111c38] border border-slate-800 mb-4">
          <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
            <span className="text-slate-300">Trophy Room Progress</span>
            <span className="text-cyan-400 font-mono-numbers">{unlockedCount} / {achievements.length} Unlocked</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-amber-400 rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Achievements List */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2.5">
          {achievements.map((ach) => {
            const IconComponent = ICON_MAP[ach.icon] || Trophy;

            return (
              <div
                key={ach.id}
                className={`flex items-center gap-3.5 p-3 rounded-2xl border transition-all ${
                  ach.unlocked
                    ? 'bg-[#122144]/80 border-cyan-500/40 shadow-sm'
                    : 'bg-[#091122]/60 border-slate-800/60 opacity-60'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    ach.unlocked
                      ? 'bg-amber-500/20 border-amber-400/40 text-amber-300'
                      : 'bg-slate-800/60 border-slate-700/40 text-slate-500'
                  }`}
                >
                  {ach.unlocked ? (
                    <IconComponent className="w-5 h-5" />
                  ) : (
                    <Lock className="w-4 h-4" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <div
                      className={`text-sm font-bold truncate ${
                        ach.unlocked ? 'text-white' : 'text-slate-400'
                      }`}
                    >
                      {ach.title}
                    </div>
                    {ach.unlocked && (
                      <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-0.5 shrink-0">
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                    {ach.description}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="w-full mt-4 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm tracking-wide transition-all"
        >
          Close
        </button>
      </div>
    </div>
  );
};
