import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Music,
  Smartphone,
  Trash2,
  X,
  Check,
  Palette,
  Vibrate,
  Lock,
  Sparkles,
  Sliders,
} from 'lucide-react';
import { AudioSettings, BlockVisualEffect, GameStats, ThemeId } from '../../types/game';
import { GAME_THEMES, BLOCK_STYLES } from '../../constants/themes';
import { BlockCell } from '../BlockPiece';
import { soundEngine } from '../../services/soundEngine';

interface SettingsModalProps {
  settings: AudioSettings;
  stats: GameStats;
  onUpdateSettings: (newSettings: AudioSettings) => void;
  onClearStats: () => void;
  onClose: () => void;
  defaultTab?: 'themes' | 'audio';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  stats,
  onUpdateSettings,
  onClearStats,
  onClose,
  defaultTab = 'themes',
}) => {
  const [activeTab, setActiveTab] = useState<'themes' | 'audio'>(defaultTab);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const handleToggleSfx = () => {
    onUpdateSettings({ ...settings, sfxEnabled: !settings.sfxEnabled });
  };

  const handleSfxVolume = (val: number) => {
    onUpdateSettings({ ...settings, sfxVolume: val, sfxEnabled: val > 0 });
  };

  const handleToggleMusic = () => {
    onUpdateSettings({ ...settings, musicEnabled: !settings.musicEnabled });
  };

  const handleMusicVolume = (val: number) => {
    onUpdateSettings({ ...settings, musicVolume: val, musicEnabled: val > 0 });
  };

  const handleToggleTouchOffset = () => {
    onUpdateSettings({ ...settings, touchOffsetEnabled: !settings.touchOffsetEnabled });
  };

  const handleToggleHaptics = () => {
    onUpdateSettings({ ...settings, hapticsEnabled: !settings.hapticsEnabled });
  };

  const handleSelectTheme = (themeId: ThemeId) => {
    soundEngine.playClick();
    onUpdateSettings({ ...settings, activeTheme: themeId });
  };

  const handleSelectBlockStyle = (styleId: BlockVisualEffect) => {
    const config = BLOCK_STYLES[styleId];
    if (!config.isUnlocked(stats)) return;
    soundEngine.playDrop();
    onUpdateSettings({ ...settings, activeBlockStyle: styleId });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md max-h-[92vh] rounded-3xl bg-[#0b1329] border border-cyan-500/30 shadow-[0_24px_60px_rgba(0,0,0,0.9)] flex flex-col relative text-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-slate-800 bg-[#0b1329] z-10 shrink-0">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold font-display text-white">Settings &amp; Styles</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Settings"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex px-5 pt-3 pb-2 gap-2 bg-[#080e1e] border-b border-slate-800 shrink-0">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('themes');
            }}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs font-display tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
              activeTab === 'themes'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <Palette className="w-4 h-4" />
            Themes &amp; Visuals
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('audio');
            }}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs font-display tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
              activeTab === 'audio'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <Volume2 className="w-4 h-4" />
            Audio &amp; Game
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-5 text-sm">
          {activeTab === 'themes' && (
            <div className="flex flex-col gap-6">
              {/* SECTION 1: BLOCK VISUAL STYLES */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <h3 className="font-bold text-white text-sm font-display uppercase tracking-wide">
                      Block Visual Styles
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Unlock with achievements &amp; high scores
                  </span>
                </div>

                <div className="flex flex-col gap-3">
                  {Object.values(BLOCK_STYLES).map((style) => {
                    const isUnlocked = style.isUnlocked(stats);
                    const isEquipped = settings.activeBlockStyle === style.id;
                    const progressPct = style.progressPercent(stats);
                    const progressLabel = style.progressText(stats);

                    return (
                      <div
                        key={style.id}
                        className={`p-3.5 rounded-2xl border transition-all relative overflow-hidden ${
                          isEquipped
                            ? 'bg-[#122347]/90 border-cyan-400 shadow-[0_4px_20px_rgba(6,182,212,0.25)]'
                            : isUnlocked
                            ? 'bg-[#0e172e]/80 border-slate-700/80 hover:border-slate-600'
                            : 'bg-[#091122]/60 border-slate-800/60 opacity-80'
                        }`}
                      >
                        <div className="flex items-start gap-3.5">
                          {/* Live 3-Block Preview of the style */}
                          <div className="flex flex-col items-center justify-center shrink-0 p-2 rounded-xl bg-slate-950/70 border border-slate-800 shadow-inner">
                            <div className="grid grid-cols-3 gap-1">
                              <div className="w-6 h-6">
                                <BlockCell color="cyan" size={24} visualStyle={style.id} />
                              </div>
                              <div className="w-6 h-6">
                                <BlockCell color="purple" size={24} visualStyle={style.id} />
                              </div>
                              <div className="w-6 h-6">
                                <BlockCell color="amber" size={24} visualStyle={style.id} />
                              </div>
                            </div>
                            <span className="text-[9px] font-semibold text-slate-400 mt-1 uppercase tracking-tight">
                              Sample
                            </span>
                          </div>

                          {/* Info & Requirements */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-1 mb-0.5">
                              <span className="font-bold text-white text-sm font-display">
                                {style.name}
                              </span>
                              {isEquipped ? (
                                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 flex items-center gap-1 uppercase tracking-wider">
                                  <Check className="w-3 h-3 text-cyan-400" />
                                  Active
                                </span>
                              ) : isUnlocked ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 uppercase tracking-wider">
                                  Unlocked
                                </span>
                              ) : (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-1 uppercase tracking-wider">
                                  <Lock className="w-3 h-3 text-amber-400" />
                                  Locked
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-300 line-clamp-1 mb-1">
                              {style.subtitle}
                            </p>

                            {/* Unlock condition / Progress */}
                            {!isUnlocked ? (
                              <div className="mt-2 p-2 rounded-lg bg-black/40 border border-slate-800 text-[11px]">
                                <div className="flex items-center justify-between text-slate-400 mb-1">
                                  <span>Unlock: {style.unlockCondition}</span>
                                  <span className="font-mono-numbers text-amber-300 font-bold">
                                    {progressPct}%
                                  </span>
                                </div>
                                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden mb-1">
                                  <div
                                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full"
                                    style={{ width: `${progressPct}%` }}
                                  />
                                </div>
                                <span className="text-[10px] text-slate-400 font-mono-numbers">
                                  {progressLabel}
                                </span>
                              </div>
                            ) : (
                              <button
                                onClick={() => handleSelectBlockStyle(style.id)}
                                disabled={isEquipped}
                                className={`mt-2 py-1.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                                  isEquipped
                                    ? 'bg-cyan-500 text-slate-950 shadow-sm cursor-default'
                                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95'
                                }`}
                              >
                                {isEquipped ? 'Equipped Style' : 'Equip Style'}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SECTION 2: COSMIC ARENA THEMES */}
              <div className="pt-2 border-t border-slate-800">
                <div className="flex items-center gap-2 mb-2">
                  <Palette className="w-4 h-4 text-cyan-400" />
                  <h3 className="font-bold text-white text-sm font-display uppercase tracking-wide">
                    Cosmic Arena Skins
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {Object.values(GAME_THEMES).map((th) => {
                    const isSelected = settings.activeTheme === th.id;

                    return (
                      <button
                        key={th.id}
                        onClick={() => handleSelectTheme(th.id)}
                        className={`p-3 rounded-xl border flex flex-col gap-2 transition-all text-left ${
                          isSelected
                            ? 'bg-slate-800/90 border-cyan-400 shadow-md ring-1 ring-cyan-400/50'
                            : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 opacity-80'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div
                            className="w-5 h-5 rounded-full border border-white/40 shadow-sm"
                            style={{ backgroundColor: th.previewColor }}
                          />
                          {isSelected && (
                            <span className="text-[10px] font-black text-cyan-400 uppercase">
                              Active
                            </span>
                          )}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white truncate">{th.name}</div>
                          <div className="text-[10px] text-slate-400 truncate">{th.subtitle}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'audio' && (
            <div className="flex flex-col gap-5">
              {/* Sound FX */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {settings.sfxEnabled ? (
                      <Volume2 className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-500" />
                    )}
                    <span className="font-semibold text-slate-200">Sound Effects</span>
                  </div>
                  <button
                    onClick={handleToggleSfx}
                    className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                      settings.sfxEnabled ? 'bg-cyan-500 justify-end' : 'bg-slate-700 justify-start'
                    }`}
                  >
                    <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                  </button>
                </div>
                {settings.sfxEnabled && (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.sfxVolume}
                    onChange={(e) => handleSfxVolume(parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                )}
              </div>

              {/* Background Ambient Music */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Music
                      className={`w-4 h-4 ${
                        settings.musicEnabled ? 'text-purple-400' : 'text-slate-500'
                      }`}
                    />
                    <span className="font-semibold text-slate-200">Cosmic Ambient Music</span>
                  </div>
                  <button
                    onClick={handleToggleMusic}
                    className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                      settings.musicEnabled ? 'bg-purple-600 justify-end' : 'bg-slate-700 justify-start'
                    }`}
                  >
                    <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                  </button>
                </div>
                {settings.musicEnabled && (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.musicVolume}
                    onChange={(e) => handleMusicVolume(parseFloat(e.target.value))}
                    className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                )}
              </div>

              {/* Haptic Feedback */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <div className="flex items-center gap-2">
                  <Vibrate className="w-4 h-4 text-amber-400" />
                  <span className="font-semibold text-slate-200">Haptic Vibration</span>
                </div>
                <button
                  onClick={handleToggleHaptics}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                    settings.hapticsEnabled ? 'bg-amber-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                </button>
              </div>

              {/* Mobile Touch Drag Offset */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span className="font-semibold text-slate-200">Thumb Visibility Lift</span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    Elevates piece 75px above finger on touchscreen
                  </span>
                </div>
                <button
                  onClick={handleToggleTouchOffset}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                    settings.touchOffsetEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                </button>
              </div>

              {/* Reset Stats */}
              <div className="pt-2 border-t border-slate-800/80">
                {showConfirmReset ? (
                  <div className="flex flex-col gap-2 p-3 rounded-xl bg-rose-950/40 border border-rose-800/60">
                    <p className="text-xs text-rose-300">
                      Are you sure? This resets all high scores &amp; stats.
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          onClearStats();
                          setShowConfirmReset(false);
                        }}
                        className="flex-1 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center justify-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Confirm Reset
                      </button>
                      <button
                        onClick={() => setShowConfirmReset(false)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-medium"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowConfirmReset(true)}
                    className="w-full py-2.5 px-3 rounded-xl bg-slate-800/50 hover:bg-rose-900/30 text-slate-400 hover:text-rose-300 text-xs font-semibold border border-slate-700/60 transition-colors flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Reset Scores &amp; History
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Done Button */}
        <div className="p-4 border-t border-slate-800 bg-[#091122] shrink-0">
          <button
            onClick={onClose}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide shadow-md active:scale-[0.98] transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
