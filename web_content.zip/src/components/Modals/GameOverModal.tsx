import React from 'react';
import { RotateCcw, Home, Trophy, Sparkles, Flame } from 'lucide-react';
import { ExploreOffersButton } from '../ExploreOffersButton';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHighScore: boolean;
  linesCleared: number;
  maxCombo: number;
  blocksPlaced: number;
  onPlayAgain: () => void;
  onGoHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHighScore,
  linesCleared,
  maxCombo,
  blocksPlaced,
  onPlayAgain,
  onGoHome,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#0b1329] border border-cyan-500/30 p-5 sm:p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)] flex flex-col items-center text-center relative overflow-hidden">
        {/* Glow ambient background behind modal */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-32 bg-cyan-500/15 rounded-full filter blur-2xl pointer-events-none" />

        {isNewHighScore ? (
          <div className="flex flex-col items-center mb-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center mb-1.5 animate-bounce">
              <Trophy className="w-7 h-7 text-[#091122] fill-[#091122]" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-black tracking-widest uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              New High Score!
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center mb-1.5">
            <div className="text-[11px] font-semibold tracking-widest uppercase text-slate-400 mb-0.5">
              Run Completed
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-display tracking-tight text-white">
              Game Over
            </h2>
          </div>
        )}

        {/* Big Final Score */}
        <div className="my-2 flex flex-col items-center">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest mb-0.5">
            Final Score
          </span>
          <div className="text-4xl sm:text-5xl font-black font-display tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-cyan-100 to-cyan-400 font-mono-numbers">
            {score}
          </div>
          <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
            <span>Best:</span>
            <span className="font-bold text-amber-400 font-mono-numbers">{highScore}</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-1.5 w-full my-2.5 py-2 px-2 rounded-2xl bg-[#101a35] border border-slate-700/60 text-center">
          <div>
            <div className="text-[9px] text-slate-400 uppercase font-medium">Lines</div>
            <div className="text-base sm:text-lg font-bold text-cyan-400 font-mono-numbers">{linesCleared}</div>
          </div>
          <div className="border-x border-slate-700/60">
            <div className="text-[9px] text-slate-400 uppercase font-medium flex items-center justify-center gap-0.5">
              <Flame className="w-2.5 h-2.5 text-orange-400" />
              Combo
            </div>
            <div className="text-base sm:text-lg font-bold text-orange-400 font-mono-numbers">
              {maxCombo > 0 ? `x${maxCombo}` : '0'}
            </div>
          </div>
          <div>
            <div className="text-[9px] text-slate-400 uppercase font-medium">Blocks</div>
            <div className="text-base sm:text-lg font-bold text-purple-400 font-mono-numbers">{blocksPlaced}</div>
          </div>
        </div>

        {/* Optional Explore Offers Button below final score & stats, clearly separated */}
        <div className="w-full my-1">
          <ExploreOffersButton variant="gameover" />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 w-full mt-2">
          <button
            onClick={onPlayAgain}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Play Again
          </button>

          <button
            onClick={onGoHome}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs sm:text-sm border border-slate-700/80 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5"
          >
            <Home className="w-4 h-4" />
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
