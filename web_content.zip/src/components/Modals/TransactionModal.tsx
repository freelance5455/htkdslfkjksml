import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Transaction } from '../../types';
import { t } from '../../utils/translations';
import { X, ArrowDownRight, ArrowUpRight, Calendar, Tag, Wallet, User, Hash } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editTransaction?: Transaction | null;
  defaultType?: 'income' | 'expense';
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  editTransaction,
  defaultType = 'income'
}) => {
  const { language, categories, accounts, addTransaction, updateTransaction } = useApp();

  const [type, setType] = useState<'income' | 'expense'>(defaultType);
  const [amount, setAmount] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [categoryId, setCategoryId] = useState<string>('');
  const [accountId, setAccountId] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [partyName, setPartyName] = useState<string>('');
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (editTransaction) {
      setType(editTransaction.type);
      setAmount(editTransaction.amount.toString());
      setDate(editTransaction.date);
      setCategoryId(editTransaction.categoryId);
      setAccountId(editTransaction.accountId);
      setTitle(editTransaction.title);
      setPartyName(editTransaction.partyName || '');
      setReferenceNo(editTransaction.referenceNo || '');
      setNotes(editTransaction.notes || '');
    } else {
      setType(defaultType);
      setAmount('');
      setDate(new Date().toISOString().split('T')[0]);
      setTitle('');
      setPartyName('');
      setReferenceNo('');
      setNotes('');
      // Set default category and account
      const availableCats = categories.filter((c) => c.type === defaultType);
      if (availableCats.length > 0) setCategoryId(availableCats[0].id);
      if (accounts.length > 0) setAccountId(accounts[0].id);
    }
  }, [editTransaction, defaultType, isOpen, categories, accounts]);

  // When type changes, ensure valid category is selected
  const handleTypeChange = (newType: 'income' | 'expense') => {
    setType(newType);
    const availableCats = categories.filter((c) => c.type === newType);
    if (availableCats.length > 0) {
      setCategoryId(availableCats[0].id);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!parsedAmount || parsedAmount <= 0) return;

    if (editTransaction) {
      updateTransaction(editTransaction.id, {
        type,
        amount: parsedAmount,
        date,
        categoryId,
        accountId,
        title: title.trim() || (type === 'income' ? 'આવક' : 'ખર્ચ'),
        partyName: partyName.trim() || undefined,
        referenceNo: referenceNo.trim() || undefined,
        notes: notes.trim() || undefined
      });
    } else {
      addTransaction({
        type,
        amount: parsedAmount,
        date,
        categoryId,
        accountId,
        title: title.trim() || (type === 'income' ? 'આવક' : 'ખર્ચ'),
        partyName: partyName.trim() || undefined,
        referenceNo: referenceNo.trim() || undefined,
        notes: notes.trim() || undefined
      });
    }
    onClose();
  };

  const filteredCategories = categories.filter((c) => c.type === type);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-900 to-red-950 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/40">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-bold">|| ૧ ||</span>
            <h2 className="text-base font-bold text-amber-100">
              {editTransaction
                ? t('edit', language)
                : type === 'income'
                ? t('income', language)
                : t('expense', language)}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-stone-300 hover:bg-red-800 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Income / Expense Tabs */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 rounded-xl">
            <button
              type="button"
              onClick={() => handleTypeChange('income')}
              className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${
                type === 'income'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <ArrowDownRight className="w-4 h-4" />
              <span>{t('income', language)} (જમા)</span>
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('expense')}
              className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${
                type === 'expense'
                  ? 'bg-rose-700 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>{t('expense', language)} (ઉધાર)</span>
            </button>
          </div>

          {/* Amount & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('amount', language)} *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-stone-500 font-bold">₹</span>
                <input
                  type="number"
                  step="any"
                  required
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-stone-300 text-lg font-bold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('date', language)} *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>
          </div>

          {/* Category & Account */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('category', language)} *
              </label>
              <div className="relative">
                <Tag className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <select
                  required
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
                >
                  {filteredCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {language === 'gu' ? c.nameGu : c.nameEn}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('account', language)} *
              </label>
              <div className="relative">
                <Wallet className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <select
                  required
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Title / Description */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              {language === 'gu' ? 'વિગત / શીર્ષક' : 'Title / Description'} *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={language === 'gu' ? 'દા.ત. કરિયાણાનો સામાન, વેતન' : 'e.g. Monthly Grocery, Salary'}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Party Name & Reference No */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-stone-600 mb-1">
                {t('partyName', language)}
              </label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder={language === 'gu' ? 'વેપારી કે વ્યક્તિનું નામ' : 'Party name'}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-600 mb-1">
                {language === 'gu' ? 'રેફરન્સ / ચેક / બિલ નં.' : 'Ref / Cheque / Bill #'}
              </label>
              <div className="relative">
                <Hash className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  value={referenceNo}
                  onChange={(e) => setReferenceNo(e.target.value)}
                  placeholder="UPI / Cheque / Ref"
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-stone-600 mb-1">
              {t('notes', language)}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={language === 'gu' ? 'વધારાની કોઈપણ નોંધ...' : 'Any additional remarks...'}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-100 transition-colors"
            >
              {t('cancel', language)}
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-lg text-xs font-bold text-white transition-all shadow-md ${
                type === 'income'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-rose-700 hover:bg-rose-800'
              }`}
            >
              {t('save', language)}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
