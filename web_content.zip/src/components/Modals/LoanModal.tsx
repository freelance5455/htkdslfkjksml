import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Loan, LoanType, InterestType, RatePeriod, CompoundingFrequency } from '../../types';
import { t, formatCurrency } from '../../utils/translations';
import { isLeapYear, calculateExactPeriodInterest, addYearsAnniversary } from '../../utils/interestCalculator';
import { X, User, Phone, MapPin, Calculator, Calendar, Percent, Sparkles, AlertCircle } from 'lucide-react';

interface LoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  editLoan?: Loan | null;
  defaultType?: LoanType;
}

export const LoanModal: React.FC<LoanModalProps> = ({
  isOpen,
  onClose,
  editLoan,
  defaultType = 'lent'
}) => {
  const { language, accounts, addLoan, updateLoan } = useApp();

  const [type, setType] = useState<LoanType>(defaultType);
  const [partyName, setPartyName] = useState('');
  const [partyPhone, setPartyPhone] = useState('');
  const [partyAddress, setPartyAddress] = useState('');
  const [initialPrincipal, setInitialPrincipal] = useState<string>('');
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [interestType, setInterestType] = useState<InterestType>('simple');
  const [interestRate, setInterestRate] = useState<string>('1.5');
  const [ratePeriod, setRatePeriod] = useState<RatePeriod>('monthly');
  const [compoundingFrequency, setCompoundingFrequency] = useState<CompoundingFrequency>('monthly');
  const [accountId, setAccountId] = useState<string>('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editLoan) {
      setType(editLoan.type);
      setPartyName(editLoan.partyName);
      setPartyPhone(editLoan.partyPhone || '');
      setPartyAddress(editLoan.partyAddress || '');
      setInitialPrincipal(editLoan.initialPrincipal.toString());
      setStartDate(editLoan.startDate);
      setInterestType(editLoan.interestType);
      setInterestRate(editLoan.interestRate.toString());
      setRatePeriod(editLoan.ratePeriod);
      setCompoundingFrequency(editLoan.compoundingFrequency);
      setAccountId(editLoan.accountId || '');
      setNotes(editLoan.notes || '');
    } else {
      setType(defaultType);
      setPartyName('');
      setPartyPhone('');
      setPartyAddress('');
      setInitialPrincipal('');
      setStartDate(new Date().toISOString().split('T')[0]);
      setInterestType('simple');
      setInterestRate('1.5');
      setRatePeriod('monthly');
      setCompoundingFrequency('monthly');
      setAccountId(accounts.length > 0 ? accounts[0].id : '');
      setNotes('');
    }
  }, [editLoan, defaultType, isOpen, accounts]);

  if (!isOpen) return null;

  const startYear = parseInt(startDate.split('-')[0], 10) || new Date().getFullYear();
  const startYearIsLeap = isLeapYear(startYear);
  const nextAnnivDate = addYearsAnniversary(startDate, 1);

  // Quick 1-year interest projection calculation
  const numPrincipal = parseFloat(initialPrincipal) || 0;
  const numRate = parseFloat(interestRate) || 0;
  const projection = calculateExactPeriodInterest(
    numPrincipal,
    startDate,
    nextAnnivDate,
    numRate,
    ratePeriod
  );

  const annualEquivalentRate = ratePeriod === 'monthly' ? numRate * 12 : numRate;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyName.trim() || numPrincipal <= 0 || numRate < 0) return;

    if (editLoan) {
      updateLoan(editLoan.id, {
        type,
        partyName: partyName.trim(),
        partyPhone: partyPhone.trim() || undefined,
        partyAddress: partyAddress.trim() || undefined,
        initialPrincipal: numPrincipal,
        startDate,
        interestType,
        interestRate: numRate,
        ratePeriod,
        compoundingFrequency,
        accountId: accountId || undefined,
        notes: notes.trim() || undefined
      });
    } else {
      addLoan({
        type,
        partyName: partyName.trim(),
        partyPhone: partyPhone.trim() || undefined,
        partyAddress: partyAddress.trim() || undefined,
        initialPrincipal: numPrincipal,
        startDate,
        interestType,
        interestRate: numRate,
        ratePeriod,
        compoundingFrequency,
        accountId: accountId || undefined,
        notes: notes.trim() || undefined,
        status: 'active'
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-amber-950 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-bold">|| શ્રી ||</span>
            <h2 className="text-base font-bold text-amber-100">
              {editLoan ? t('edit', language) : t('newLoan', language)}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-stone-300 hover:bg-red-800 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Loan Type (Lent vs Borrowed) */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 rounded-xl">
            <button
              type="button"
              onClick={() => setType('lent')}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold transition-all ${
                type === 'lent'
                  ? 'bg-emerald-700 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <span>{t('lentBadge', language)}</span>
              <span className="text-[10px] opacity-80">(નાણાં ધીર્યા / લેણું)</span>
            </button>
            <button
              type="button"
              onClick={() => setType('borrowed')}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold transition-all ${
                type === 'borrowed'
                  ? 'bg-red-800 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <span>{t('borrowedBadge', language)}</span>
              <span className="text-[10px] opacity-80">(નાણાં લીધા / દેવું)</span>
            </button>
          </div>

          {/* Party Details */}
          <div className="space-y-2.5">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('partyName', language)} *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  required
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder={language === 'gu' ? 'દા.ત. રમેશભાઈ પટેલ' : 'Party / Person full name'}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  autoFocus
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  {language === 'gu' ? 'મોબાઇલ નંબર' : 'Phone Number'}
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    value={partyPhone}
                    onChange={(e) => setPartyPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  {language === 'gu' ? 'સરનામું / ગામ' : 'Address / Village'}
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    value={partyAddress}
                    onChange={(e) => setPartyAddress(e.target.value)}
                    placeholder="ગામ / શહેર"
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Principal & Start Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-stone-100">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('principal', language)} (₹) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-stone-500 font-bold">₹</span>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  value={initialPrincipal}
                  onChange={(e) => setInitialPrincipal(e.target.value)}
                  placeholder="100000"
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-stone-300 text-base font-bold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('startDate', language)} *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
              <p className="mt-1 text-[10px] text-amber-700 font-medium">
                {startYearIsLeap ? '★ આ વર્ષ ૨૦૨૪ લીપ વર્ષ (૩૬૬ દિવસ) છે' : '૩૬૫ દિવસનું વાર્ષિક ચક્ર'}
              </p>
            </div>
          </div>

          {/* Interest Configuration */}
          <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200/80 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
              <Calculator className="w-4 h-4 text-amber-700" />
              <span>{language === 'gu' ? 'વ્યાજ ગણતરી શરતો' : 'Interest Calculation Terms'}</span>
            </div>

            {/* Simple vs Compound */}
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center gap-2 p-2 rounded-lg border bg-white cursor-pointer hover:border-amber-400">
                <input
                  type="radio"
                  name="interestType"
                  checked={interestType === 'simple'}
                  onChange={() => setInterestType('simple')}
                  className="text-amber-600 focus:ring-amber-500"
                />
                <span className="text-xs font-semibold text-stone-800">
                  {t('simpleInterest', language)}
                </span>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg border bg-white cursor-pointer hover:border-amber-400">
                <input
                  type="radio"
                  name="interestType"
                  checked={interestType === 'compound'}
                  onChange={() => setInterestType('compound')}
                  className="text-amber-600 focus:ring-amber-500"
                />
                <span className="text-xs font-semibold text-stone-800">
                  {t('compoundInterest', language)}
                </span>
              </label>
            </div>

            {/* Rate & Frequency */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  {t('interestRate', language)} (%)
                </label>
                <div className="relative">
                  <Percent className="absolute right-3 top-2.5 w-4 h-4 text-stone-400" />
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    placeholder="1.5"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-semibold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  {t('ratePeriod', language)}
                </label>
                <select
                  value={ratePeriod}
                  onChange={(e) => setRatePeriod(e.target.value as RatePeriod)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
                >
                  <option value="monthly">{t('monthlyRate', language)}</option>
                  <option value="yearly">{t('yearlyRate', language)}</option>
                </select>
              </div>
            </div>

            {/* Compounding frequency if compound */}
            {interestType === 'compound' && (
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  {t('compoundingFrequency', language)}
                </label>
                <select
                  value={compoundingFrequency}
                  onChange={(e) => setCompoundingFrequency(e.target.value as CompoundingFrequency)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
                >
                  <option value="monthly">{t('monthly', language)}</option>
                  <option value="quarterly">{t('quarterly', language)}</option>
                  <option value="yearly">{t('yearly', language)}</option>
                  <option value="daily">{t('daily', language)}</option>
                </select>
              </div>
            )}

            {/* Live Calculation Preview Banner */}
            {numPrincipal > 0 && numRate > 0 && (
              <div className="rounded-lg bg-amber-100/70 p-2.5 border border-amber-300/80 text-xs text-amber-950 space-y-1">
                <div className="flex items-center justify-between font-bold">
                  <span>૧ વર્ષનું અંદાજિત વ્યાજ:</span>
                  <span className="text-sm font-extrabold text-amber-900">
                    {formatCurrency(Math.round(projection.interest), language)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-amber-800">
                  <span>વાર્ષિક સમકક્ષ દર: {annualEquivalentRate.toFixed(2)}% p.a.</span>
                  <span>{projection.totalDays} દિવસ ({projection.leapDaysCount > 0 ? 'લીપ વર્ષ સહિત' : 'સામાન્ય વર્ષ'})</span>
                </div>
              </div>
            )}
          </div>

          {/* Account Selection */}
          <div>
            <label className="block text-xs font-medium text-stone-600 mb-1">
              {language === 'gu' ? 'ક્યા ખાતામાંથી રકમ આપી/મળી?' : 'Disbursement Account (Cash/Bank)'}
            </label>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
            >
              <option value="">-- {language === 'gu' ? 'ખાતું પસંદ કરો (વૈકલ્પિક)' : 'Select Account (Optional)'} --</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-stone-600 mb-1">
              {t('notes', language)}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={language === 'gu' ? 'શરતો, સાક્ષીનું નામ કે અન્ય વિગત...' : 'Terms, conditions, notes...'}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Precision Note */}
          <div className="flex items-start gap-1.5 p-2 rounded-lg bg-stone-50 border border-stone-200 text-[11px] text-stone-600">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <span>
              {t('anniversaryNote', language)}
            </span>
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-100 transition-colors"
            >
              {t('cancel', language)}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-amber-700 hover:bg-amber-800 transition-all shadow-md"
            >
              {t('save', language)}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
