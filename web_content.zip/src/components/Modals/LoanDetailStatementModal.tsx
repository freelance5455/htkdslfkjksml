import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Loan } from '../../types';
import { t, formatCurrency, formatDateDisplay } from '../../utils/translations';
import { calculateLoanDetailed } from '../../utils/interestCalculator';
import {
  X,
  Printer,
  Calendar,
  Percent,
  Plus,
  CheckCircle,
  FileText,
  Clock,
  Trash2,
  AlertCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface LoanDetailStatementModalProps {
  isOpen: boolean;
  onClose: () => void;
  loan: Loan;
  onRecordRepayment: () => void;
  onSettleLoan: () => void;
}

export const LoanDetailStatementModal: React.FC<LoanDetailStatementModalProps> = ({
  isOpen,
  onClose,
  loan,
  onRecordRepayment,
  onSettleLoan
}) => {
  const { language, deleteLoanRepayment } = useApp();
  const [activeTab, setActiveTab] = useState<'annual_report' | 'timeline' | 'repayments'>('annual_report');

  if (!isOpen) return null;

  const calc = calculateLoanDetailed(loan);

  const handlePrint = () => {
    window.print();
  };

  const handleDeleteRepayment = (repId: string) => {
    const confirmMsg =
      language === 'gu'
        ? 'શું તમે આ ચૂકવણી રદ કરવા માંગો છો? વ્યાજ આપોઆપ ફરીથી ગણાશે.'
        : 'Delete this repayment? Interest will be automatically recalculated from that date.';
    if (window.confirm(confirmMsg)) {
      deleteLoanRepayment(loan.id, repId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Top Auspicious & Khatavahi Header (Printable) */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-stone-950 text-white px-6 py-4 flex items-center justify-between border-b border-amber-500/50">
          <div>
            <div className="text-[11px] font-semibold text-amber-300 tracking-widest">
              || શ્રી ગણેશાય નમઃ || શ્રી ૧ ||
            </div>
            <h2 className="text-lg font-bold text-amber-100 flex items-center gap-2 mt-0.5">
              <span>{loan.partyName}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40">
                {loan.type === 'lent' ? t('lentBadge', language) : t('borrowedBadge', language)}
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              {loan.partyPhone && `ફોન: ${loan.partyPhone} • `}
              શરૂઆત તારીખ: {formatDateDisplay(loan.startDate, language)} • દર: {loan.interestRate}% ({loan.ratePeriod === 'monthly' ? 'માસિક' : 'વાર્ષિક'})
            </p>
          </div>

          <div className="flex items-center gap-2 print-hide">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-900/80 hover:bg-red-800 text-amber-200 text-xs font-semibold border border-amber-500/30 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t('print', language)}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-stone-400 hover:text-white hover:bg-red-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Financial Executive Summary Cards */}
        <div className="p-4 bg-amber-50/50 border-b border-amber-200/70 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-stone-500 block">{t('currentPrincipal', language)}</span>
            <span className="text-base font-bold text-stone-900 mt-0.5 block">
              {formatCurrency(calc.currentPrincipal, language)}
            </span>
            <span className="text-[10px] text-stone-400">
              મૂળ: {formatCurrency(loan.initialPrincipal, language)}
            </span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-amber-800 block">{t('accruedInterest', language)}</span>
            <span className="text-base font-bold text-amber-800 mt-0.5 block">
              {formatCurrency(calc.currentAccruedInterest, language)}
            </span>
            <span className="text-[10px] text-amber-600">૧૦૦% ચોક્કસ લીપ વર્ષ</span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-emerald-800 block">{t('totalRepaid', language)}</span>
            <span className="text-base font-bold text-emerald-800 mt-0.5 block">
              {formatCurrency(calc.totalRepaid, language)}
            </span>
            <span className="text-[10px] text-emerald-600">
              વ્યાજ: {formatCurrency(calc.totalInterestRepaid, language)} | મુદ્દલ: {formatCurrency(calc.totalPrincipalRepaid, language)}
            </span>
          </div>

          <div className="bg-gradient-to-br from-red-950 to-stone-900 text-white p-3 rounded-xl border border-amber-500/40 shadow-xs">
            <span className="text-[11px] text-amber-200/90 block">{t('totalOutstanding', language)}</span>
            <span className="text-lg font-black text-amber-300 mt-0.5 block">
              {formatCurrency(calc.totalBalanceRemaining, language)}
            </span>
            <span className="text-[10px] text-amber-200/70">
              {calc.isSettled ? 'ચૂકતે થયેલ' : 'કુલ ચૂકવવાપાત્ર'}
            </span>
          </div>
        </div>

        {/* View Switcher Tabs (Print Hide) */}
        <div className="px-5 pt-3 pb-1 border-b border-stone-200 flex items-center justify-between print-hide bg-white">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('annual_report')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'annual_report'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              {t('annualInterestReport', language)}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('timeline')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'timeline'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              {language === 'gu' ? 'દૈનિક સમયરેખા (Timeline)' : 'Chronological Timeline'}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('repayments')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'repayments'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              {language === 'gu' ? 'જમા રકમ વિગત' : 'Repayments Log'} ({loan.repayments?.length || 0})
            </button>
          </div>

          <div className="flex items-center gap-2">
            {loan.status === 'active' && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onRecordRepayment();
                  }}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('recordRepayment', language)}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSettleLoan();
                  }}
                  className="px-3 py-1 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold"
                >
                  {language === 'gu' ? 'ચૂકતે કરો' : 'Settle'}
                </button>
              </>
            )}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: Annual Interest Report */}
          {activeTab === 'annual_report' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-stone-600">
                <span className="font-bold text-stone-800 text-sm">
                  {t('annualInterestReport', language)}
                </span>
                <span className="text-[11px] text-amber-800">
                  {t('anniversaryNote', language)}
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-stone-200">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-amber-50 text-stone-700 font-bold border-b border-amber-200">
                    <tr>
                      <th className="p-3 w-36">{t('anniversaryYear', language)}</th>
                      <th className="p-3 text-right">{t('openingPrincipal', language)}</th>
                      <th className="p-3 text-right text-amber-800">{t('yearInterest', language)}</th>
                      <th className="p-3 text-right text-emerald-800">{language === 'gu' ? 'કુલ જમા હપ્તા' : 'Payments'}</th>
                      <th className="p-3 text-right">{t('clearedInterestLabel', language)}</th>
                      <th className="p-3 text-right">{t('deductedPrincipalLabel', language)}</th>
                      <th className="p-3 text-right">{t('closingPrincipal', language)}</th>
                      <th className="p-3 text-right text-red-800">{t('totalOutstanding', language)}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200">
                    {calc.anniversaryYears.map((yr) => (
                      <tr key={yr.yearIndex} className="hover:bg-amber-50/30">
                        <td className="p-3 font-semibold text-stone-900">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold">વર્ષ {yr.yearIndex}</span>
                            {yr.isLeapYear && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 text-[10px] font-bold border border-amber-300">
                                લીપ વર્ષ (૩૬૬ દિ.)
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-stone-500 mt-0.5">
                            {formatDateDisplay(yr.startDate, language)} → {formatDateDisplay(yr.endDate, language)}
                          </div>
                          <div className="text-[10px] text-stone-400">
                            કુલ {yr.daysInYear} દિવસ
                          </div>
                        </td>

                        <td className="p-3 text-right font-medium text-stone-800">
                          {formatCurrency(yr.openingPrincipal, language)}
                        </td>

                        <td className="p-3 text-right font-bold text-amber-700">
                          {formatCurrency(yr.interestAccrued, language)}
                        </td>

                        <td className="p-3 text-right font-bold text-emerald-700">
                          {yr.repaymentsTotal > 0 ? formatCurrency(yr.repaymentsTotal, language) : '-'}
                        </td>

                        <td className="p-3 text-right font-medium text-stone-600">
                          {yr.repaymentsToInterest > 0 ? formatCurrency(yr.repaymentsToInterest, language) : '-'}
                        </td>

                        <td className="p-3 text-right font-medium text-stone-600">
                          {yr.repaymentsToPrincipal > 0 ? formatCurrency(yr.repaymentsToPrincipal, language) : '-'}
                        </td>

                        <td className="p-3 text-right font-semibold text-stone-800">
                          {formatCurrency(yr.closingPrincipal, language)}
                        </td>

                        <td className="p-3 text-right font-black text-red-900">
                          {formatCurrency(yr.closingTotalDue, language)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-stone-100 font-bold border-t-2 border-stone-300">
                    <tr>
                      <td className="p-3 uppercase tracking-wider text-stone-700">કુલ સરવાળો / Total:</td>
                      <td className="p-3 text-right">-</td>
                      <td className="p-3 text-right text-amber-800 font-black">
                        {formatCurrency(calc.totalInterestAccruedAllTime, language)}
                      </td>
                      <td className="p-3 text-right text-emerald-800 font-black">
                        {formatCurrency(calc.totalRepaid, language)}
                      </td>
                      <td className="p-3 text-right font-bold text-stone-700">
                        {formatCurrency(calc.totalInterestRepaid, language)}
                      </td>
                      <td className="p-3 text-right font-bold text-stone-700">
                        {formatCurrency(calc.totalPrincipalRepaid, language)}
                      </td>
                      <td className="p-3 text-right font-black text-stone-900">
                        {formatCurrency(calc.currentPrincipal, language)}
                      </td>
                      <td className="p-3 text-right font-black text-red-900">
                        {formatCurrency(calc.totalBalanceRemaining, language)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Explanatory note */}
              <div className="rounded-xl bg-amber-50 p-3 border border-amber-200 text-xs text-amber-950 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-semibold">
                    {language === 'gu' ? 'ખાતાવહી વ્યાજ ગણતરીનો કડક નિયમ:' : 'Strict Interest Ledger Rules:'}
                  </p>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    {language === 'gu'
                      ? '૧. લોન આપ્યાની તારીખ એ વાર્ષિક ચક્રનો પ્રારંભ ગણાય છે. ૨. લીપ વર્ષમાં ૩૬૬ દિવસ પ્રમાણે વ્યાજ ગણાય છે. ૩. જ્યારે કોઈ હપ્તો જમા થાય, ત્યારે નિયમ મુજબ પ્રથમ ચડેલ વ્યાજ કપાય છે, ત્યારબાદ વધેલી રકમ મુદ્દલમાંથી બાદ થાય છે. ૪. તે જ દિવસથી બાકી રહેલ મુદ્દલ પર આગળનું વ્યાજ ચાલુ રહે છે.'
                      : '1. Day of loan taken/given is anniversary year beginning. 2. Leap years calculate on exact 366-day basis. 3. Repayments clear accrued interest first, then remainder deducts from principal. 4. Interest continues on remaining balance from that specific day onwards.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Chronological Timeline */}
          {activeTab === 'timeline' && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-stone-800">
                {language === 'gu' ? 'દરેક વ્યવહાર અને વ્યાજ ચઢવાની વિગતવાર સમયરેખા' : 'Event Timeline'}
              </h3>

              <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-amber-300">
                {calc.timeline.map((ev) => (
                  <div key={ev.id} className="relative text-xs">
                    {/* Bullet */}
                    <div
                      className={`absolute -left-6 top-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center ${
                        ev.type === 'start'
                          ? 'bg-red-800'
                          : ev.type === 'repayment'
                          ? 'bg-emerald-600'
                          : ev.type === 'anniversary_mark'
                          ? 'bg-amber-500'
                          : 'bg-stone-500'
                      }`}
                    />

                    <div className="bg-stone-50 border border-stone-200/80 rounded-xl p-3 space-y-1.5 shadow-2xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900">{ev.title}</span>
                        <span className="text-[11px] text-stone-500">
                          {formatDateDisplay(ev.date, language)}
                        </span>
                      </div>

                      <p className="text-[11px] text-stone-600">{ev.description}</p>

                      <div className="pt-1 border-t border-stone-200 flex items-center justify-between text-[11px] text-stone-500 font-medium">
                        <span>બાકી મુદ્દલ: {formatCurrency(ev.principalAfter, language)}</span>
                        <span>બાકી વ્યાજ: {formatCurrency(ev.interestAfter, language)}</span>
                        <span className="font-bold text-red-900">
                          કુલ બાકી: {formatCurrency(ev.totalBalanceAfter, language)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Repayments Log */}
          {activeTab === 'repayments' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-stone-800">
                  {language === 'gu' ? 'જમા મળેલ / ચૂકવેલ તમામ હપ્તાઓ' : 'All Recorded Repayments'}
                </h3>
                {loan.status === 'active' && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onRecordRepayment();
                    }}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t('recordRepayment', language)}</span>
                  </button>
                )}
              </div>

              {!loan.repayments || loan.repayments.length === 0 ? (
                <div className="p-8 text-center text-stone-400 text-xs">
                  {language === 'gu' ? 'અત્યાર સુધી કોઈ હપ્તો જમા થયો નથી.' : 'No repayments logged yet.'}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-stone-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                      <tr>
                        <th className="p-2.5">{t('date', language)}</th>
                        <th className="p-2.5 text-right">{t('amount', language)}</th>
                        <th className="p-2.5 text-right">{t('clearedInterestLabel', language)}</th>
                        <th className="p-2.5 text-right">{t('deductedPrincipalLabel', language)}</th>
                        <th className="p-2.5">{t('notes', language)}</th>
                        <th className="p-2.5 text-center w-16 print-hide">{language === 'gu' ? 'ક્રિયા' : 'Action'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200">
                      {loan.repayments.map((rep) => (
                        <tr key={rep.id} className="hover:bg-amber-50/30">
                          <td className="p-2.5 font-medium text-stone-800">
                            {formatDateDisplay(rep.date, language)}
                          </td>
                          <td className="p-2.5 text-right font-black text-emerald-700">
                            {formatCurrency(rep.amount, language)}
                          </td>
                          <td className="p-2.5 text-right font-semibold text-amber-700">
                            {rep.clearedInterest ? formatCurrency(rep.clearedInterest, language) : '-'}
                          </td>
                          <td className="p-2.5 text-right font-semibold text-stone-700">
                            {rep.deductedPrincipal ? formatCurrency(rep.deductedPrincipal, language) : '-'}
                          </td>
                          <td className="p-2.5 text-stone-600 truncate max-w-xs">
                            {rep.note || '-'}
                          </td>
                          <td className="p-2.5 text-center print-hide">
                            <button
                              type="button"
                              onClick={() => handleDeleteRepayment(rep.id)}
                              className="p-1 rounded text-stone-400 hover:text-rose-600 hover:bg-stone-100"
                              title={t('delete', language)}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-100 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
          <span>ખાતાવહી ઓળખ: #{loan.id}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-stone-800 hover:bg-stone-900 text-white font-semibold shadow-xs"
          >
            {language === 'gu' ? 'બંધ કરો' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
