import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Loan } from '../../types';
import { t, formatCurrency } from '../../utils/translations';
import { calculateLoanDetailed } from '../../utils/interestCalculator';
import { X, Calendar, Wallet, CheckCircle2, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';

interface LoanRepaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  loan: Loan;
}

export const LoanRepaymentModal: React.FC<LoanRepaymentModalProps> = ({
  isOpen,
  onClose,
  loan
}) => {
  const { language, accounts, addLoanRepayment } = useApp();

  const [amount, setAmount] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [accountId, setAccountId] = useState<string>(accounts[0]?.id || '');
  const [note, setNote] = useState<string>('');

  if (!isOpen) return null;

  // Calculate status as of the selected repayment date
  const statusAsOfDate = calculateLoanDetailed(loan, date);
  const payNum = parseFloat(amount) || 0;

  // Exact rule breakdown: Interest cleared first, then remaining deducted from principal
  const interestDue = statusAsOfDate.currentAccruedInterest;
  const principalDue = statusAsOfDate.currentPrincipal;

  const clearedInterest = Math.min(interestDue, payNum);
  const remainingAfterInterest = Math.max(0, payNum - interestDue);
  const deductedPrincipal = Math.min(principalDue, remainingAfterInterest);

  const remainingInterestAfter = Math.max(0, interestDue - payNum);
  const remainingPrincipalAfter = Math.max(0, principalDue - deductedPrincipal);
  const totalBalanceAfter = remainingInterestAfter + remainingPrincipalAfter;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (payNum <= 0) return;

    addLoanRepayment(loan.id, {
      date,
      amount: payNum,
      accountId: accountId || undefined,
      note: note.trim() || undefined,
      clearedInterest,
      deductedPrincipal
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-amber-950 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
          <div>
            <h2 className="text-base font-bold text-amber-100 flex items-center gap-1.5">
              <span>{t('recordRepayment', language)}</span>
            </h2>
            <p className="text-xs text-amber-200/80 truncate max-w-xs">{loan.partyName}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-stone-300 hover:bg-red-800 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Current Due status banner */}
          <div className="rounded-xl bg-stone-50 border border-stone-200 p-3 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <p className="text-stone-500 text-[11px]">{t('currentPrincipal', language)}</p>
              <p className="font-bold text-stone-800 mt-0.5">
                {formatCurrency(principalDue, language)}
              </p>
            </div>
            <div>
              <p className="text-stone-500 text-[11px]">{t('accruedInterest', language)}</p>
              <p className="font-bold text-amber-700 mt-0.5">
                {formatCurrency(interestDue, language)}
              </p>
            </div>
            <div>
              <p className="text-stone-500 text-[11px]">{t('totalOutstanding', language)}</p>
              <p className="font-extrabold text-red-800 mt-0.5">
                {formatCurrency(principalDue + interestDue, language)}
              </p>
            </div>
          </div>

          {/* Amount & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {language === 'gu' ? 'જમા કરાવેલ રકમ' : 'Repayment Amount (₹)'} *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-stone-500 font-bold">₹</span>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="5000"
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-stone-300 text-base font-bold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('date', language)} *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>
          </div>

          {/* Real-Time Rule Breakdown Card */}
          {payNum > 0 && (
            <div className="rounded-xl bg-amber-50/80 border border-amber-300/80 p-3.5 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                <span>{language === 'gu' ? 'ચૂકવણીની પારદર્શક ફાળવણી' : 'Transparent Payment Allocation'}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <span className="text-[11px] text-stone-500 block">
                    ૧. {t('clearedInterestLabel', language)}:
                  </span>
                  <span className="text-sm font-extrabold text-amber-700">
                    {formatCurrency(clearedInterest, language)}
                  </span>
                  <p className="text-[10px] text-stone-400 mt-0.5">
                    (પ્રથમ વ્યાજ કપાયું)
                  </p>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <span className="text-[11px] text-stone-500 block">
                    ૨. {t('deductedPrincipalLabel', language)}:
                  </span>
                  <span className="text-sm font-extrabold text-emerald-700">
                    {formatCurrency(deductedPrincipal, language)}
                  </span>
                  <p className="text-[10px] text-stone-400 mt-0.5">
                    (મુદ્દલમાંથી બાદ)
                  </p>
                </div>
              </div>

              {/* Next Cycle Note */}
              <div className="flex items-center justify-between pt-1 border-t border-amber-200/60 text-xs">
                <span className="text-stone-600">
                  {language === 'gu' ? 'આ તારીખ પછી નવી બાકી મુદ્દલ:' : 'Remaining Principal from today:'}
                </span>
                <span className="font-bold text-stone-900">
                  {formatCurrency(remainingPrincipalAfter, language)}
                </span>
              </div>
              <p className="text-[10px] text-amber-800 leading-tight">
                {language === 'gu'
                  ? 'આ તારીખ પછી હવે પછીનું વ્યાજ આ બાકી રહેલ મુદ્દલ પર જ ગણાશે.'
                  : 'Interest will continue on this remaining balance from this specific day onwards.'}
              </p>
            </div>
          )}

          {/* Account & Notes */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              {t('account', language)}
            </label>
            <div className="relative">
              <Wallet className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
              <select
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 mb-1">
              {t('notes', language)}
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={language === 'gu' ? 'દા.ત. રોકડેથી, ગુગલ પે દ્વારા...' : 'e.g. In cash, UPI...'}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          {/* Rule statement */}
          <div className="flex items-start gap-1.5 p-2 rounded-lg bg-stone-50 border border-stone-200 text-[11px] text-stone-600">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <span>{t('repaymentRule', language)}</span>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-100 transition-colors"
            >
              {t('cancel', language)}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 transition-all shadow-md"
            >
              {t('confirm', language)} (જમા કરો)
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
