import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';
import { X, ArrowRightLeft, Calendar, Wallet } from 'lucide-react';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TransferModal: React.FC<TransferModalProps> = ({ isOpen, onClose }) => {
  const { language, accounts, addTransfer } = useApp();

  const [fromAccountId, setFromAccountId] = useState(accounts[0]?.id || '');
  const [toAccountId, setToAccountId] = useState(accounts[1]?.id || accounts[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!parsedAmount || parsedAmount <= 0 || fromAccountId === toAccountId) return;

    addTransfer({
      fromAccountId,
      toAccountId,
      amount: parsedAmount,
      date,
      notes: notes.trim() || undefined
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        <div className="bg-gradient-to-r from-red-950 to-red-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-amber-400" />
            <h2 className="text-base font-bold text-amber-100">{t('transferFunds', language)}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-stone-300 hover:bg-red-800 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('fromAccount', language)} *
              </label>
              <select
                value={fromAccountId}
                onChange={(e) => setFromAccountId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('toAccount', language)} *
              </label>
              <select
                value={toAccountId}
                onChange={(e) => setToAccountId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id} disabled={a.id === fromAccountId}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('amount', language)} (₹) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-stone-500 font-bold">₹</span>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="5000"
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-stone-300 text-base font-bold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                  autoFocus
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('date', language)} *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 mb-1">
              {t('notes', language)}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={language === 'gu' ? 'દા.ત. એટીએમમાંથી રોકડ ઉપાડ, બેંકમાં રોકડ જમા' : 'e.g. Cash withdrawal, ATM, deposit'}
              className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-100"
            >
              {t('cancel', language)}
            </button>
            <button
              type="submit"
              disabled={fromAccountId === toAccountId}
              className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50"
            >
              {t('confirm', language)}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
