import React from 'react';
import { Sparkles, Clock, ShieldAlert, X, Trophy } from 'lucide-react';
import { GameMode, GameStats } from '../../types/game';

interface ModeSelectModalProps {
  stats: GameStats;
  onSelectMode: (mode: GameMode) => void;
  onClose: () => void;
}

export const ModeSelectModal: React.FC<ModeSelectModalProps> = ({ stats, onSelectMode, onClose }) => {
  const modes: {
    id: GameMode;
    title: string;
    subtitle: string;
    description: string;
    icon: React.ElementType;
    colorClasses: {
      border: string;
      bg: string;
      iconBg: string;
      iconText: string;
      badge: string;
    };
    highScore: number;
  }[] = [
    {
      id: 'CLASSIC',
      title: 'Classic Blast',
      subtitle: 'Zen Endless Puzzle',
      description: 'The pure, relaxing block blast puzzle. Place shapes, blast lines, and build infinite combos.',
      icon: Sparkles,
      colorClasses: {
        border: 'border-cyan-500/40 hover:border-cyan-400',
        bg: 'bg-[#101b38]/90 hover:bg-[#14234b]',
        iconBg: 'bg-cyan-500/20 border-cyan-400/40',
        iconText: 'text-cyan-400',
        badge: 'text-cyan-300 bg-cyan-950/60',
      },
      highScore: stats.highScore,
    },
    {
      id: 'RUSH',
      title: 'Cosmic Rush',
      subtitle: '90s Time Attack',
      description: 'Fast-paced adrenaline challenge! Race against the clock; every line cleared extends your remaining time.',
      icon: Clock,
      colorClasses: {
        border: 'border-amber-500/40 hover:border-amber-400',
        bg: 'bg-[#24170a]/90 hover:bg-[#33200e]',
        iconBg: 'bg-amber-500/20 border-amber-400/40',
        iconText: 'text-amber-400',
        badge: 'text-amber-300 bg-amber-950/60',
      },
      highScore: stats.rushHighScore,
    },
    {
      id: 'BOMB',
      title: 'Solar Bomb',
      subtitle: 'Tactical Mine Clearance',
      description: 'Cosmic bombs spawn with countdown timers! Line-blast their rows or columns to defuse them before detonation.',
      icon: ShieldAlert,
      colorClasses: {
        border: 'border-rose-500/40 hover:border-rose-400',
        bg: 'bg-[#260e15]/90 hover:bg-[#38141f]',
        iconBg: 'bg-rose-500/20 border-rose-400/40',
        iconText: 'text-rose-400',
        badge: 'text-rose-300 bg-rose-950/60',
      },
      highScore: stats.bombHighScore,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md rounded-3xl bg-[#0b1329] border border-cyan-500/30 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)] flex flex-col relative text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div>
            <h2 className="text-xl font-bold font-display text-white">Select Game Mode</h2>
            <p className="text-xs text-slate-400 mt-0.5">Pick your cosmic challenge style</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Cards */}
        <div className="flex flex-col gap-3">
          {modes.map((mode) => {
            const Icon = mode.icon;

            return (
              <button
                key={mode.id}
                onClick={() => onSelectMode(mode.id)}
                className={`p-4 rounded-2xl border text-left transition-all duration-150 active:scale-[0.98] flex items-start gap-3.5 ${mode.colorClasses.bg} ${mode.colorClasses.border}`}
              >
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border mt-0.5 ${mode.colorClasses.iconBg} ${mode.colorClasses.iconText}`}
                >
                  <Icon className="w-6 h-6" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <span className="font-bold text-white text-base font-display">
                      {mode.title}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${mode.colorClasses.badge}`}
                    >
                      {mode.subtitle}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-2">
                    {mode.description}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-amber-300 font-bold font-mono-numbers">
                    <Trophy className="w-3.5 h-3.5 text-amber-400" />
                    <span>Best: {mode.highScore}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
