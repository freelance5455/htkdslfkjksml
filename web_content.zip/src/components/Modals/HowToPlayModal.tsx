import React from 'react';
import { X, Grid, Sparkles, Flame, AlertCircle } from 'lucide-react';
import { BlockCell } from '../BlockPiece';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl bg-[#0b1329] border border-cyan-500/30 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)] flex flex-col relative text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 sticky top-0 bg-[#0b1329] z-10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold font-display text-white">How To Play</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Rules"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Rules Guide */}
        <div className="flex flex-col gap-4 text-xs sm:text-sm">
          {/* Rule 1 */}
          <div className="flex gap-3.5 p-3.5 rounded-2xl bg-[#111c38] border border-slate-800/80 items-start">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center shrink-0 mt-0.5">
              <Grid className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <div className="font-bold text-white text-sm mb-1">1. Drag & Place Blocks</div>
              <p className="text-slate-300 leading-relaxed">
                Drag any of the 3 available shapes from your bottom tray into the 10×10 cosmic grid. The ghost preview shows where the piece will land.
              </p>
            </div>
          </div>

          {/* Rule 2 */}
          <div className="flex gap-3.5 p-3.5 rounded-2xl bg-[#111c38] border border-slate-800/80 items-start">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="font-bold text-white text-sm mb-1">2. Blast Full Lines</div>
              <p className="text-slate-300 leading-relaxed">
                Fill an entire horizontal row or vertical column to vaporize it! Clear multiple rows and columns at once for massive multi-line score bonuses.
              </p>
              {/* Mini visual indicator */}
              <div className="flex items-center gap-1.5 mt-2.5">
                {['cyan', 'cyan', 'cyan', 'cyan', 'cyan'].map((col, idx) => (
                  <div key={idx} className="w-5 h-5">
                    <BlockCell color={col as any} size={20} />
                  </div>
                ))}
                <span className="text-[11px] text-cyan-300 font-semibold ml-2">Full Line = BLAST!</span>
              </div>
            </div>
          </div>

          {/* Rule 3 */}
          <div className="flex gap-3.5 p-3.5 rounded-2xl bg-[#111c38] border border-slate-800/80 items-start">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 border border-orange-400/40 flex items-center justify-center shrink-0 mt-0.5">
              <Flame className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <div className="font-bold text-white text-sm mb-1">3. Build Combos</div>
              <p className="text-slate-300 leading-relaxed">
                Clear lines on consecutive moves to raise your Combo Multiplier! Each combo level increases the points earned and plays an escalating chime fanfare.
              </p>
            </div>
          </div>

          {/* Rule 4 */}
          <div className="flex gap-3.5 p-3.5 rounded-2xl bg-[#111c38] border border-slate-800/80 items-start">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-400/40 flex items-center justify-center shrink-0 mt-0.5">
              <AlertCircle className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <div className="font-bold text-white text-sm mb-1">4. Avoid Grid Lock</div>
              <p className="text-slate-300 leading-relaxed">
                The round ends when none of your remaining pieces can fit anywhere on the board. Keep corners clear and always plan ahead for 3×3 cubes!
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={onClose}
          className="w-full mt-5 py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all"
        >
          Got It! Let&apos;s Play
        </button>
      </div>
    </div>
  );
};
