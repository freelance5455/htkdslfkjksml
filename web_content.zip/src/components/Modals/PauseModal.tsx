import React from 'react';
import { Play, RotateCcw, Settings, Home } from 'lucide-react';

interface PauseModalProps {
  score: number;
  highScore: number;
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onGoHome: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  score,
  highScore,
  onResume,
  onRestart,
  onOpenSettings,
  onGoHome,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#0b1329] border border-cyan-500/30 p-6 shadow-[0_20px_50px_rgba(0,0,0,0.8)] flex flex-col items-center text-center">
        <h2 className="text-2xl font-black font-display tracking-tight text-white mb-1">
          Game Paused
        </h2>
        <p className="text-xs text-slate-400 mb-6">Take a breath, your cosmic board is waiting.</p>

        {/* Score summaries */}
        <div className="grid grid-cols-2 gap-3 w-full mb-6">
          <div className="bg-[#121c38] rounded-2xl p-3 border border-slate-700/60">
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Score</div>
            <div className="text-2xl font-black text-white font-mono-numbers">{score}</div>
          </div>
          <div className="bg-[#121c38] rounded-2xl p-3 border border-amber-500/30">
            <div className="text-[11px] font-medium text-amber-400 uppercase tracking-wider">Best</div>
            <div className="text-2xl font-black text-amber-400 font-mono-numbers">{highScore}</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          <button
            onClick={onResume}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            Resume Game
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-cyan-400" />
            Restart Run
          </button>

          <button
            onClick={onOpenSettings}
            className="w-full py-3 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            Audio & Settings
          </button>

          <button
            onClick={onGoHome}
            className="w-full py-3 px-4 rounded-xl bg-transparent hover:bg-slate-800/50 text-slate-400 hover:text-white font-semibold text-sm transition-all flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" />
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
