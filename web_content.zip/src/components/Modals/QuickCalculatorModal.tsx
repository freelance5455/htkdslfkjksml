import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { InterestType, RatePeriod, CompoundingFrequency } from '../../types';
import { t, formatCurrency, formatDateDisplay } from '../../utils/translations';
import { quickCalculateInterest } from '../../utils/interestCalculator';
import { X, Calculator, Calendar, Percent, Sparkles, Plus, Trash2, ArrowRight } from 'lucide-react';

interface QuickCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuickCalculatorModal: React.FC<QuickCalculatorModalProps> = ({ isOpen, onClose }) => {
  const { language } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const lastYearDate = new Date();
  lastYearDate.setFullYear(lastYearDate.getFullYear() - 1);
  const defaultStartDate = lastYearDate.toISOString().split('T')[0];

  const [principal, setPrincipal] = useState<string>('100000');
  const [startDate, setStartDate] = useState<string>(defaultStartDate);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [interestType, setInterestType] = useState<InterestType>('simple');
  const [interestRate, setInterestRate] = useState<string>('1.5');
  const [ratePeriod, setRatePeriod] = useState<RatePeriod>('monthly');
  const [compoundingFrequency, setCompoundingFrequency] = useState<CompoundingFrequency>('yearly');

  // Intermediate partial payments test
  const [payments, setPayments] = useState<{ id: string; date: string; amount: number }[]>([]);
  const [newPayDate, setNewPayDate] = useState<string>(todayStr);
  const [newPayAmount, setNewPayAmount] = useState<string>('');

  if (!isOpen) return null;

  const numPrincipal = parseFloat(principal) || 0;
  const numRate = parseFloat(interestRate) || 0;

  // Run detailed calculation
  const result = quickCalculateInterest({
    principal: numPrincipal,
    startDate,
    endDate,
    interestType,
    interestRate: numRate,
    ratePeriod,
    compoundingFrequency,
    payments: payments.map((p) => ({ date: p.date, amount: p.amount }))
  });

  const handleAddPayment = () => {
    const amt = parseFloat(newPayAmount);
    if (!amt || amt <= 0) return;
    setPayments((prev) => [
      ...prev,
      { id: `p-${Date.now()}`, date: newPayDate, amount: amt }
    ]);
    setNewPayAmount('');
  };

  const handleRemovePayment = (id: string) => {
    setPayments((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-amber-950 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-amber-100">{t('instantCalculator', language)}</h2>
              <p className="text-[11px] text-amber-200/80">૧૦૦% ચોક્કસ લીપ વર્ષ ગણતરી / 100% Accurate Leap-Year Engine</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-stone-300 hover:bg-red-800 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('principal', language)} (₹)
              </label>
              <input
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-bold text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {t('startDate', language)}
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                {language === 'gu' ? 'અંતિમ તારીખ (આજ સુધી)' : 'End Date (As of Date)'}
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600"
              />
            </div>
          </div>

          {/* Rate & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 bg-amber-50/70 rounded-xl border border-amber-200">
            <div>
              <label className="block text-[11px] font-bold text-stone-700 mb-1">
                {t('interestType', language)}
              </label>
              <select
                value={interestType}
                onChange={(e) => setInterestType(e.target.value as InterestType)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold bg-white"
              >
                <option value="simple">{t('simpleInterest', language)}</option>
                <option value="compound">{t('compoundInterest', language)}</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-stone-700 mb-1">
                {t('interestRate', language)} (%)
              </label>
              <input
                type="number"
                step="0.01"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-bold bg-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-stone-700 mb-1">
                {t('ratePeriod', language)}
              </label>
              <select
                value={ratePeriod}
                onChange={(e) => setRatePeriod(e.target.value as RatePeriod)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold bg-white"
              >
                <option value="monthly">{t('monthlyRate', language)}</option>
                <option value="yearly">{t('yearlyRate', language)}</option>
              </select>
            </div>

            {interestType === 'compound' && (
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  {t('compoundingFrequency', language)}
                </label>
                <select
                  value={compoundingFrequency}
                  onChange={(e) => setCompoundingFrequency(e.target.value as CompoundingFrequency)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold bg-white"
                >
                  <option value="monthly">{t('monthly', language)}</option>
                  <option value="quarterly">{t('quarterly', language)}</option>
                  <option value="yearly">{t('yearly', language)}</option>
                  <option value="daily">{t('daily', language)}</option>
                </select>
              </div>
            )}
          </div>

          {/* Partial Payments Section */}
          <div className="rounded-xl border border-stone-200 p-3 bg-stone-50/70 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800">
                {language === 'gu' ? 'વચગાળાની ચૂકવણી (હપ્તો ઉમેરો):' : 'Add Partial Repayments:'}
              </span>
              <span className="text-[10px] text-amber-700 font-medium">
                (વ્યાજ પ્રથમ કપાઈને બાકી મુદ્દલ પરથી ગણતરી આગળ ચાલશે)
              </span>
            </div>

            <div className="flex gap-2">
              <input
                type="date"
                value={newPayDate}
                onChange={(e) => setNewPayDate(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs bg-white"
              />
              <input
                type="number"
                placeholder="Amount (₹)"
                value={newPayAmount}
                onChange={(e) => setNewPayAmount(e.target.value)}
                className="w-32 px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-bold bg-white"
              />
              <button
                type="button"
                onClick={handleAddPayment}
                className="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs font-bold hover:bg-amber-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t('add', language)}</span>
              </button>
            </div>

            {payments.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {payments.map((p) => (
                  <span
                    key={p.id}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs bg-emerald-50 border border-emerald-300 text-emerald-900"
                  >
                    <span>{formatDateDisplay(p.date, language)}: {formatCurrency(p.amount, language)}</span>
                    <button
                      type="button"
                      onClick={() => handleRemovePayment(p.id)}
                      className="text-stone-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Result Highlight Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
            <div className="rounded-xl bg-stone-100 p-3 border border-stone-200">
              <span className="text-[11px] text-stone-500 block">{t('currentPrincipal', language)}</span>
              <span className="text-base font-bold text-stone-900 mt-1 block">
                {formatCurrency(result.currentPrincipal, language)}
              </span>
            </div>

            <div className="rounded-xl bg-amber-50 p-3 border border-amber-200">
              <span className="text-[11px] text-amber-800 block">{t('accruedInterest', language)}</span>
              <span className="text-base font-bold text-amber-800 mt-1 block">
                {formatCurrency(result.currentAccruedInterest, language)}
              </span>
            </div>

            <div className="rounded-xl bg-emerald-50 p-3 border border-emerald-200">
              <span className="text-[11px] text-emerald-800 block">{t('totalRepaid', language)}</span>
              <span className="text-base font-bold text-emerald-800 mt-1 block">
                {formatCurrency(result.totalRepaid, language)}
              </span>
            </div>

            <div className="rounded-xl bg-red-50 p-3 border border-red-200">
              <span className="text-[11px] text-red-800 block">{t('totalOutstanding', language)}</span>
              <span className="text-lg font-extrabold text-red-900 mt-1 block">
                {formatCurrency(result.totalBalanceRemaining, language)}
              </span>
            </div>
          </div>

          {/* Annual Interest Report Table */}
          {result.anniversaryYears.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-stone-200">
              <h3 className="text-xs font-bold text-stone-800 flex items-center justify-between">
                <span>{t('annualInterestReport', language)}</span>
                <span className="text-[11px] font-normal text-stone-500">
                  {language === 'gu' ? 'વાર્ષિક ચક્ર મુજબ વિભાજન' : 'Anniversary Year Cycles'}
                </span>
              </h3>

              <div className="overflow-x-auto rounded-xl border border-stone-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 text-stone-700 font-semibold border-b border-stone-200">
                    <tr>
                      <th className="p-2">{t('anniversaryYear', language)}</th>
                      <th className="p-2">{t('openingPrincipal', language)}</th>
                      <th className="p-2">{t('yearInterest', language)}</th>
                      <th className="p-2">{t('paymentsReceived', language)}</th>
                      <th className="p-2">{t('closingPrincipal', language)}</th>
                      <th className="p-2">{t('closingInterest', language)}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200">
                    {result.anniversaryYears.map((yr) => (
                      <tr key={yr.yearIndex} className="hover:bg-amber-50/40">
                        <td className="p-2 font-medium text-stone-900">
                          <div>વર્ષ {yr.yearIndex}</div>
                          <div className="text-[10px] text-stone-500 flex items-center gap-1">
                            <span>{formatDateDisplay(yr.startDate, language)} → {formatDateDisplay(yr.endDate, language)}</span>
                            {yr.isLeapYear && (
                              <span className="px-1 py-0.2 rounded bg-amber-200 text-amber-900 text-[9px] font-bold">
                                {t('leapYearBadge', language)}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2 font-semibold text-stone-800">
                          {formatCurrency(yr.openingPrincipal, language)}
                        </td>
                        <td className="p-2 font-bold text-amber-700">
                          {formatCurrency(yr.interestAccrued, language)}
                        </td>
                        <td className="p-2 text-emerald-700 font-medium">
                          {yr.repaymentsTotal > 0 ? formatCurrency(yr.repaymentsTotal, language) : '-'}
                        </td>
                        <td className="p-2 font-semibold text-stone-800">
                          {formatCurrency(yr.closingPrincipal, language)}
                        </td>
                        <td className="p-2 font-semibold text-amber-800">
                          {formatCurrency(yr.closingAccruedInterest, language)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
