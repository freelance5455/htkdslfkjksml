export function SigningGuideView() {
  return (
    <section className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
      <div className="p-6">
        <h2 className="text-lg font-display font-semibold text-slate-900">
          APK Compilation, Monetization, Offline Mode & Deployment Guide
        </h2>
        <p className="text-sm text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Every build produces two synchronized artifacts: a directly compiled, RSA-2048 signed Android binary (<code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">.apk</code>) and a complete Android Studio Gradle project (<code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">.zip</code>).
        </p>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-sm font-display font-semibold text-slate-900">
            01. Offline APK Creation & PWA Support
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Web2APK Studio runs an isomorphic pure-TypeScript binary compiler (<code className="font-mono text-xs">AndroidManifest.xml</code> AXML, <code className="font-mono text-xs">resources.arsc</code>, Dalvik <code className="font-mono text-xs">classes.dex</code>, and PKCS#7 RSA-2048 signing) directly inside your browser. When offline, the Service Worker serves the cached app shell and builds/downloads both <code className="font-mono text-xs">.apk</code> and Gradle <code className="font-mono text-xs">.zip</code> files locally from memory.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-display font-semibold text-slate-900">
            02. In-App Purchases & Subscriptions
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Enabling Play Billing adds <code className="font-mono text-xs">com.android.vending.BILLING</code> to the binary manifest and wires <code className="font-mono text-xs">BillingClient 7.0</code> plus <code className="font-mono text-xs">window.AndroidNative.purchase(sku, type)</code> into the Gradle project. Because Google Play Billing validates SKUs against Google Play Console, publish an <code className="font-mono text-xs">.aab</code> from the Gradle export to process live Google Play payments (or use web checkout inside the standalone <code className="font-mono text-xs">.apk</code>).
          </p>
        </div>

        <div>
          <h3 className="text-sm font-display font-semibold text-slate-900">
            03. Paid Ads (AdMob Native vs. Web Ads)
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Web-based ad networks work inside any standalone <code className="font-mono text-xs">.apk</code> WebView. For native Google AdMob Banner, Interstitial, and Rewarded ads, configure your AdMob App ID and unit IDs in step 05—your binary manifest receives the <code className="font-mono text-xs">APPLICATION_ID</code> and <code className="font-mono text-xs">AD_ID</code> declarations, and the Gradle export wires the full <code className="font-mono text-xs">play-services-ads</code> SDK and <code className="font-mono text-xs">AndroidNative</code> triggers.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-display font-semibold text-slate-900">
            04. Launch Events & Device Installation
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Cold-start launch events detect first-time installs via <code className="font-mono text-xs">SharedPreferences</code>, dispatch <code className="font-mono text-xs">android:launch</code> events to your web code, and optionally POST JSON telemetry to your webhook or Firebase Analytics. To sideload any compiled <code className="font-mono text-xs">.apk</code> over USB, run:
          </p>
          <pre className="mt-3 p-3 rounded-lg bg-slate-900 text-slate-100 text-xs font-mono overflow-x-auto">
            adb install -r your-app-v1.0.0.apk
          </pre>
        </div>
      </div>
    </section>
  );
}
