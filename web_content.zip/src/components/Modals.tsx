import React, { useState } from 'react';
import { sound } from '../game/audio';
import { ARMORS, ITEMS, MONSTERS, QUESTS, REGIONS, WEAPONS } from '../game/constants';
import { usePWAInstall } from '../game/usePWAInstall';
import {
  ArmorDef,
  GameSaveData,
  PlayerStats,
  QuestDef,
  RegionId,
  WeaponClass,
  WeaponDef,
} from '../game/types';

interface ModalsProps {
  activeModal: 'forge' | 'camp' | 'quest' | 'bestiary' | 'inventory' | 'settings' | 'pause' | 'victory' | 'defeat' | null;
  saveData: GameSaveData;
  playerStats: PlayerStats;
  currentRegion: RegionId;
  victoryDetails?: { quest: QuestDef; monsterId: string; timeSec: number; carves: string[] } | null;
  defeatReason?: string | null;
  onClose: () => void;
  onFastTravel: (regionId: RegionId) => void;
  onEquipWeapon: (weaponId: string) => void;
  onCraftWeapon: (weapon: WeaponDef) => void;
  onCraftArmor: (armor: ArmorDef) => void;
  onAcceptQuest: (quest: QuestDef) => void;
  onRestAtCamp: () => void;
  onSaveGame: () => void;
  onReturnToTitle: () => void;
  onUpdateSettings: (settings: GameSaveData['settings']) => void;
}

export const Modals: React.FC<ModalsProps> = ({
  activeModal,
  saveData,
  playerStats,
  currentRegion,
  victoryDetails,
  defeatReason,
  onClose,
  onFastTravel,
  onEquipWeapon,
  onCraftWeapon,
  onCraftArmor,
  onAcceptQuest,
  onRestAtCamp,
  onSaveGame,
  onReturnToTitle,
  onUpdateSettings,
}) => {
  const [forgeTab, setForgeTab] = useState<'weapons' | 'armors'>('weapons');
  const [selectedWeaponClass, setSelectedWeaponClass] = useState<WeaponClass>('greatsword');
  const [selectedBestiaryId, setSelectedBestiaryId] = useState<string>('mossback');
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (!activeModal) return null;

  // Helper: check if player has materials
  const hasMaterials = (materials: { itemId: string; count: number }[]) => {
    return materials.every((req) => {
      const slot = playerStats.pouch.find((s) => s.itemId === req.itemId);
      return slot && slot.count >= req.count;
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 select-none font-mono">
      {/* ========================================================= */}
      {/* 1. BLACKSMITH & FORGE MODAL */}
      {/* ========================================================= */}
      {activeModal === 'forge' && (
        <div className="bg-stone-950 border border-stone-800 text-stone-100 rounded-lg p-5 max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl">
          <div className="flex justify-between items-center border-b border-stone-800 pb-3">
            <div>
              <h2 className="text-xl font-bold text-amber-500 uppercase tracking-wider">
                OAKHAVEN GUILD BLACKSMITH
              </h2>
              <p className="text-xs text-stone-400">Forge and upgrade behemoth weapons & armor</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm font-bold text-amber-400">{playerStats.zenny.toLocaleString()}z</span>
              <button
                onClick={onClose}
                aria-label="Close"
                className="text-stone-400 hover:text-white px-2.5 py-1 bg-stone-900 border border-stone-800 rounded cursor-pointer"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Subtabs: Weapons vs Armors */}
          <div className="flex gap-2 my-3 border-b border-stone-800 pb-2">
            <button
              onClick={() => {
                sound.play('ui_click');
                setForgeTab('weapons');
              }}
              className={`px-4 py-1.5 rounded text-xs font-bold uppercase cursor-pointer ${
                forgeTab === 'weapons'
                  ? 'bg-amber-500 text-stone-950'
                  : 'bg-stone-900 text-stone-400 hover:text-stone-200'
              }`}
            >
              WEAPONS (6 CLASSES)
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                setForgeTab('armors');
              }}
              className={`px-4 py-1.5 rounded text-xs font-bold uppercase cursor-pointer ${
                forgeTab === 'armors'
                  ? 'bg-amber-500 text-stone-950'
                  : 'bg-stone-900 text-stone-400 hover:text-stone-200'
              }`}
            >
              ARMOR SETS
            </button>
          </div>

          {/* Tab 1: Weapons List */}
          {forgeTab === 'weapons' && (
            <div className="flex flex-col flex-1 overflow-hidden">
              {/* Weapon Class Selector */}
              <div className="flex gap-1.5 overflow-x-auto pb-2 border-b border-stone-800/80">
                {(['greatsword', 'dualblades', 'hammer', 'longsword', 'bow', 'lance'] as WeaponClass[]).map(
                  (wc) => (
                    <button
                      key={wc}
                      onClick={() => {
                        sound.play('ui_click');
                        setSelectedWeaponClass(wc);
                      }}
                      className={`px-2.5 py-1 text-[11px] font-bold uppercase rounded cursor-pointer ${
                        selectedWeaponClass === wc
                          ? 'bg-stone-800 text-amber-400 border border-amber-500/50'
                          : 'bg-stone-900 text-stone-400 hover:text-stone-200'
                      }`}
                    >
                      {wc}
                    </button>
                  )
                )}
              </div>

              {/* Weapons Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 overflow-y-auto my-3 pr-1">
                {Object.values(WEAPONS)
                  .filter((w) => w.weaponClass === selectedWeaponClass)
                  .map((w) => {
                    const isCrafted = saveData.craftedEquipment.includes(w.id);
                    const isEquipped = playerStats.equippedWeaponId === w.id;
                    const canAfford = playerStats.zenny >= w.cost && hasMaterials(w.materials);

                    return (
                      <div
                        key={w.id}
                        className={`p-3 rounded border flex flex-col justify-between ${
                          isEquipped
                            ? 'border-amber-500 bg-amber-950/20'
                            : 'border-stone-800 bg-stone-900/60'
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-bold text-sm text-stone-100">{w.name}</h3>
                              <span className="text-[10px] text-amber-400">RARE {w.rarity} · {w.weaponClass.toUpperCase()}</span>
                            </div>
                            <span className="text-xs text-stone-300 font-bold">{w.cost}z</span>
                          </div>

                          <div className="grid grid-cols-3 gap-1 my-2 text-[11px] text-stone-300 bg-stone-950/70 p-2 rounded">
                            <div>ATK: <span className="font-bold text-amber-400">{w.attack}</span></div>
                            <div>CRIT: <span className="font-bold text-stone-100">{w.affinity}%</span></div>
                            <div>ELEM: <span className="font-bold text-cyan-400">{w.element !== 'none' ? `${w.element} +${w.elementDamage}` : 'NONE'}</span></div>
                          </div>

                          <p className="text-[10px] text-stone-400 italic mb-2">{w.description}</p>

                          {/* Material Requirements */}
                          <div className="text-[10px] text-stone-400">
                            <span>REQUIRED:</span>
                            <div className="flex flex-wrap gap-2 mt-0.5">
                              {w.materials.map((mat) => {
                                const slot = playerStats.pouch.find((s) => s.itemId === mat.itemId);
                                const count = slot ? slot.count : 0;
                                const isMet = count >= mat.count;
                                return (
                                  <span
                                    key={mat.itemId}
                                    className={isMet ? 'text-emerald-400' : 'text-red-400'}
                                  >
                                    {ITEMS[mat.itemId]?.name || mat.itemId} ({count}/{mat.count})
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Action: Equip or Forge */}
                        <div className="mt-3 pt-2 border-t border-stone-800 flex justify-end">
                          {isEquipped ? (
                            <span className="text-xs text-amber-400 font-bold py-1">EQUIPPED</span>
                          ) : isCrafted ? (
                            <button
                              onClick={() => {
                                sound.play('ui_click');
                                onEquipWeapon(w.id);
                              }}
                              className="px-3 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded cursor-pointer"
                            >
                              EQUIP
                            </button>
                          ) : (
                            <button
                              disabled={!canAfford}
                              onClick={() => {
                                sound.play('part_break');
                                onCraftWeapon(w);
                              }}
                              className={`px-4 py-1.5 text-xs font-bold uppercase rounded cursor-pointer ${
                                canAfford
                                  ? 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                                  : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                              }`}
                            >
                              FORGE WEAPON
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {/* Tab 2: Armors List */}
          {forgeTab === 'armors' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 overflow-y-auto my-3 pr-1">
              {Object.values(ARMORS).map((armor) => {
                const isCrafted = saveData.craftedEquipment.includes(armor.id);
                const isEquipped = playerStats.equippedArmor[armor.slot] === armor.id;
                const canAfford = playerStats.zenny >= armor.cost && hasMaterials(armor.materials);

                return (
                  <div
                    key={armor.id}
                    className={`p-3 rounded border flex flex-col justify-between ${
                      isEquipped
                        ? 'border-amber-500 bg-amber-950/20'
                        : 'border-stone-800 bg-stone-900/60'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold text-sm text-stone-100">{armor.name}</h3>
                          <span className="text-[10px] text-amber-400 uppercase">
                            {armor.slot} · DEF {armor.defense}
                          </span>
                        </div>
                        <span className="text-xs text-stone-300 font-bold">{armor.cost}z</span>
                      </div>

                      <div className="my-2 p-2 rounded bg-stone-950/70 text-[11px]">
                        <span className="text-emerald-400 font-bold">{armor.skillName}:</span>{' '}
                        <span className="text-stone-300">{armor.skillDescription}</span>
                      </div>

                      {/* Material Requirements */}
                      <div className="text-[10px] text-stone-400">
                        <span>REQUIRED:</span>
                        <div className="flex flex-wrap gap-2 mt-0.5">
                          {armor.materials.map((mat) => {
                            const slot = playerStats.pouch.find((s) => s.itemId === mat.itemId);
                            const count = slot ? slot.count : 0;
                            const isMet = count >= mat.count;
                            return (
                              <span
                                key={mat.itemId}
                                className={isMet ? 'text-emerald-400' : 'text-red-400'}
                              >
                                {ITEMS[mat.itemId]?.name || mat.itemId} ({count}/{mat.count})
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-stone-800 flex justify-end">
                      {isEquipped ? (
                        <span className="text-xs text-amber-400 font-bold py-1">EQUIPPED</span>
                      ) : (
                        <button
                          disabled={!canAfford && !isCrafted}
                          onClick={() => {
                            sound.play('part_break');
                            onCraftArmor(armor);
                          }}
                          className={`px-4 py-1.5 text-xs font-bold uppercase rounded cursor-pointer ${
                            isCrafted
                              ? 'bg-stone-800 hover:bg-stone-700 text-stone-200'
                              : canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                              : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                          }`}
                        >
                          {isCrafted ? 'EQUIP' : 'FORGE PIECE'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. CAMP & FAST TRAVEL WORLD MAP MODAL */}
      {/* ========================================================= */}
      {activeModal === 'camp' && (
        <div className="bg-stone-950 border border-stone-800 text-stone-100 rounded-lg p-5 max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl">
          <div className="flex justify-between items-center border-b border-stone-800 pb-3">
            <div>
              <h2 className="text-xl font-bold text-amber-500 uppercase tracking-wider">
                HUNTING EXPEDITION & WORLD MAP
              </h2>
              <p className="text-xs text-stone-400">Fast travel between wilderness regions and camps</p>
            </div>
            <button
              onClick={onClose}
              aria-label="Close"
              className="text-stone-400 hover:text-white px-2.5 py-1 bg-stone-900 border border-stone-800 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>

          {/* Quick Camp Actions */}
          <div className="grid grid-cols-2 gap-3 my-3">
            <button
              onClick={() => {
                sound.play('potion');
                onRestAtCamp();
              }}
              className="py-2.5 px-4 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/70 rounded text-emerald-300 font-bold text-xs uppercase cursor-pointer"
            >
              REST AT CAMP (RESTORE HP & STAMINA)
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onSaveGame();
              }}
              className="py-2.5 px-4 bg-stone-900 hover:bg-stone-800 border border-stone-700 rounded text-amber-400 font-bold text-xs uppercase cursor-pointer"
            >
              SAVE PROGRESS TO LOCAL STORAGE
            </button>
          </div>

          {/* Regions List */}
          <div className="flex flex-col gap-2.5 overflow-y-auto my-2">
            {(Object.keys(REGIONS) as RegionId[]).map((rId) => {
              const reg = REGIONS[rId];
              const isUnlocked = saveData.unlockedRegions.includes(rId);
              const isCurrent = currentRegion === rId;

              return (
                <div
                  key={rId}
                  className={`p-3.5 rounded border flex justify-between items-center ${
                    isCurrent
                      ? 'border-amber-500 bg-amber-950/20'
                      : isUnlocked
                      ? 'border-stone-800 bg-stone-900/60 hover:border-stone-700'
                      : 'border-stone-900 bg-stone-950 opacity-50'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: reg.themeColor }} />
                      <h3 className="font-bold text-sm text-stone-100">{reg.name}</h3>
                      {isCurrent && (
                        <span className="text-[10px] bg-amber-500 text-stone-950 font-bold px-1.5 py-0.2 rounded">
                          CURRENT
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-stone-400 mt-0.5">{reg.tagline}</p>
                    <span className="text-[10px] text-stone-500">Camp: {reg.campName}</span>
                  </div>

                  <div>
                    {isUnlocked ? (
                      <button
                        disabled={isCurrent}
                        onClick={() => {
                          sound.play('ui_click');
                          onFastTravel(rId);
                          onClose();
                        }}
                        className={`px-4 py-2 rounded text-xs font-bold uppercase cursor-pointer ${
                          isCurrent
                            ? 'bg-stone-800 text-stone-500 cursor-default'
                            : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                        }`}
                      >
                        {isCurrent ? 'HERE' : 'FAST TRAVEL'}
                      </button>
                    ) : (
                      <span className="text-xs text-stone-600 font-bold uppercase">LOCKED (GUILD HR)</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. QUEST GUILD BOARD MODAL */}
      {/* ========================================================= */}
      {activeModal === 'quest' && (
        <div className="bg-stone-950 border border-stone-800 text-stone-100 rounded-lg p-5 max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl">
          <div className="flex justify-between items-center border-b border-stone-800 pb-3">
            <div>
              <h2 className="text-xl font-bold text-amber-500 uppercase tracking-wider">
                OAKHAVEN GUILD QUEST BOARD
              </h2>
              <p className="text-xs text-stone-400">Accept guild contracts, story hunts, and gathering requests</p>
            </div>
            <button
              onClick={onClose}
              aria-label="Close"
              className="text-stone-400 hover:text-white px-2.5 py-1 bg-stone-900 border border-stone-800 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 overflow-y-auto my-3 pr-1">
            {QUESTS.map((q) => {
              const isCompleted = saveData.completedQuestIds.includes(q.id);
              const isActive = saveData.activeQuestId === q.id;
              const isEligible = playerStats.hunterRank >= q.rank;

              return (
                <div
                  key={q.id}
                  className={`p-3.5 rounded border flex flex-col sm:flex-row justify-between sm:items-center gap-3 ${
                    isActive
                      ? 'border-amber-500 bg-amber-950/20'
                      : isCompleted
                      ? 'border-stone-800 bg-stone-900/40'
                      : 'border-stone-800 bg-stone-900/70'
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-sm text-stone-100">{q.title}</h3>
                      {q.isStory && (
                        <span className="text-[9px] bg-red-950 border border-red-700 text-red-300 px-1.5 py-0.2 rounded uppercase font-bold">
                          MAIN STORY
                        </span>
                      )}
                      {isCompleted && (
                        <span className="text-[9px] bg-emerald-950 border border-emerald-700 text-emerald-300 px-1.5 py-0.2 rounded uppercase font-bold">
                          COMPLETED
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-400 mt-1">{q.description}</p>

                    <div className="flex items-center gap-4 mt-2 text-[11px] text-stone-300">
                      <span>REGION: <span className="text-amber-400 uppercase">{REGIONS[q.region].name}</span></span>
                      <span>REWARD: <span className="text-emerald-400 font-bold">{q.rewardZenny}z</span></span>
                      <span>EXP: <span className="text-cyan-400 font-bold">+{q.rewardHunterXp} XP</span></span>
                      <span>LIMIT: <span className="text-stone-400">{Math.round(q.timeLimit / 60)} min</span></span>
                    </div>
                  </div>

                  <div>
                    {isActive ? (
                      <span className="text-xs text-amber-400 font-bold px-3 py-1.5 border border-amber-500/50 rounded bg-amber-950/30">
                        ACTIVE CONTRACT
                      </span>
                    ) : isEligible ? (
                      <button
                        onClick={() => {
                          sound.play('ui_click');
                          onAcceptQuest(q);
                          onClose();
                        }}
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase rounded cursor-pointer"
                      >
                        ACCEPT QUEST
                      </button>
                    ) : (
                      <span className="text-xs text-stone-600 font-bold uppercase">
                        REQUIRES HR {q.rank}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. HUNTER BESTIARY & FIELD GUIDE MODAL */}
      {/* ========================================================= */}
      {activeModal === 'bestiary' && (
        <div className="bg-stone-950 border border-stone-800 text-stone-100 rounded-lg p-5 max-w-4xl w-full max-h-[85vh] flex flex-col shadow-2xl">
          <div className="flex justify-between items-center border-b border-stone-800 pb-3">
            <div>
              <h2 className="text-xl font-bold text-amber-500 uppercase tracking-wider">
                GUILD HUNTER BESTIARY
              </h2>
              <p className="text-xs text-stone-400">Field notes on all 12 original behemoth species & variants</p>
            </div>
            <button
              onClick={onClose}
              className="text-stone-400 hover:text-white px-2.5 py-1 bg-stone-900 border border-stone-800 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>

          <div className="flex flex-col md:flex-row gap-4 my-3 overflow-hidden flex-1">
            {/* Left Species List */}
            <div className="w-full md:w-56 overflow-y-auto flex md:flex-col gap-1.5 border-r border-stone-800 pr-2">
              {Object.values(MONSTERS).map((m) => {
                const kills = saveData.bestiaryKills[m.id] || 0;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      sound.play('ui_click');
                      setSelectedBestiaryId(m.id);
                    }}
                    className={`p-2.5 rounded text-left flex items-center justify-between cursor-pointer ${
                      selectedBestiaryId === m.id
                        ? 'bg-amber-500 text-stone-950 font-bold'
                        : 'bg-stone-900/60 hover:bg-stone-800 text-stone-300'
                    }`}
                  >
                    <div>
                      <div className="text-xs uppercase">{m.name}</div>
                      <div className={`text-[10px] ${selectedBestiaryId === m.id ? 'text-stone-800' : 'text-stone-500'}`}>
                        {m.species}
                      </div>
                    </div>
                    <span className="text-[10px] tabular-nums">x{kills}</span>
                  </button>
                );
              })}
            </div>

            {/* Right Species Details */}
            {(() => {
              const def = MONSTERS[selectedBestiaryId] || MONSTERS['mossback'];
              const kills = saveData.bestiaryKills[def.id] || 0;

              return (
                <div className="flex-1 overflow-y-auto p-3 bg-stone-900/40 rounded border border-stone-800 flex flex-col gap-3">
                  <div className="flex justify-between items-start border-b border-stone-800 pb-2">
                    <div>
                      <h3 className="text-lg font-bold text-stone-100">{def.name}</h3>
                      <p className="text-xs text-amber-400 italic">{def.title}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-stone-400">HUNTS LOGGED:</span>
                      <div className="text-base font-bold text-emerald-400 tabular-nums">{kills} KILLS</div>
                    </div>
                  </div>

                  <p className="text-xs text-stone-300 leading-relaxed">{def.description}</p>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[10px] text-stone-500">HABITAT</span>
                      <div className="font-bold text-amber-400 capitalize">{REGIONS[def.region].name}</div>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[10px] text-stone-500">WEAKNESS</span>
                      <div className="font-bold text-red-400 capitalize">{def.weakness}</div>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[10px] text-stone-500">RESISTANCE</span>
                      <div className="font-bold text-stone-300 capitalize">{def.resistance}</div>
                    </div>
                    <div className="bg-stone-950 p-2 rounded border border-stone-800">
                      <span className="text-[10px] text-stone-500">BASE HEALTH</span>
                      <div className="font-bold text-stone-100">{def.baseHp} HP</div>
                    </div>
                  </div>

                  {/* Breakable Parts & Drops */}
                  <div>
                    <h4 className="text-xs font-bold text-amber-500 uppercase mb-1">
                      BREAKABLE BODY PARTS
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {def.parts.map((p) => (
                        <div key={p.id} className="bg-stone-950 p-2 rounded border border-stone-800">
                          <div className="font-bold text-stone-200">{p.name}</div>
                          <span className="text-[10px] text-stone-400">
                            Break drop: {ITEMS[p.breakBonusDrop]?.name || p.breakBonusDrop} {p.severable ? '(Severable Tail)' : ''}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 5. VICTORY / STAGE CLEAR MODAL */}
      {/* ========================================================= */}
      {activeModal === 'victory' && victoryDetails && (
        <div className="bg-stone-950 border-2 border-amber-500 text-stone-100 rounded-lg p-6 max-w-md w-full shadow-2xl flex flex-col text-center animate-fade-in">
          <span className="text-xs font-mono tracking-widest text-amber-400 uppercase">
            HUNT CONTRACT COMPLETED
          </span>
          <h2 className="text-2xl font-black text-amber-500 uppercase mt-1">
            TARGET BEHEMOTH SLAYED!
          </h2>

          <div className="my-4 p-4 rounded bg-stone-900 border border-stone-800 flex flex-col gap-2 text-xs">
            <div className="flex justify-between">
              <span className="text-stone-400">QUEST:</span>
              <span className="font-bold text-stone-200">{victoryDetails.quest.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">CLEAR TIME:</span>
              <span className="font-bold text-stone-200 tabular-nums">
                {Math.floor(victoryDetails.timeSec / 60)}m {victoryDetails.timeSec % 60}s
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">REWARD ZENNY:</span>
              <span className="font-bold text-emerald-400">+{victoryDetails.quest.rewardZenny}z</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">HUNTER XP:</span>
              <span className="font-bold text-cyan-400">+{victoryDetails.quest.rewardHunterXp} XP</span>
            </div>
          </div>

          <button
            data-start="true"
            onClick={() => {
              sound.play('ui_click');
              onClose();
            }}
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm tracking-wider uppercase rounded cursor-pointer"
          >
            CLAIM REWARDS & CONTINUE [ENTER]
          </button>
        </div>
      )}

      {/* ========================================================= */}
      {/* 6. DEFEAT / FAINTED MODAL */}
      {/* ========================================================= */}
      {activeModal === 'defeat' && (
        <div className="bg-stone-950 border-2 border-red-600 text-stone-100 rounded-lg p-6 max-w-md w-full shadow-2xl flex flex-col text-center">
          <span className="text-xs font-mono tracking-widest text-red-400 uppercase">
            HUNTER COLLAPSED
          </span>
          <h2 className="text-2xl font-black text-red-500 uppercase mt-1">
            HUNT FAILED
          </h2>
          <p className="text-xs text-stone-400 my-4">
            {defeatReason || 'The behemoth overpowered you. Guild felynes safely returned you to camp.'}
          </p>

          <button
            data-start="true"
            onClick={() => {
              sound.play('ui_click');
              onClose();
            }}
            className="w-full py-3 bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-sm tracking-wider uppercase rounded cursor-pointer"
          >
            RESPAWN AT CAMP [ENTER]
          </button>
        </div>
      )}

      {/* ========================================================= */}
      {/* 7. PAUSE / SETTINGS MODAL */}
      {/* ========================================================= */}
      {(activeModal === 'pause' || activeModal === 'settings') && (
        <div className="bg-stone-950 border border-stone-800 text-stone-100 rounded-lg p-5 max-w-sm w-full shadow-2xl flex flex-col gap-4 text-center">
          <h2 className="text-lg font-bold text-amber-500 uppercase tracking-wider">
            GAME PAUSED
          </h2>

          <div className="flex flex-col gap-2.5">
            <button
              onClick={() => {
                sound.play('ui_click');
                onClose();
              }}
              className="py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase rounded cursor-pointer"
            >
              RESUME HUNT [ESC]
            </button>

            <button
              onClick={() => {
                sound.play('ui_click');
                onSaveGame();
              }}
              className="py-2.5 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 font-bold text-xs uppercase rounded cursor-pointer"
            >
              MANUAL SAVE PROGRESS
            </button>

            {isInstallable && !isInstalled && (
              <button
                onClick={install}
                className="py-2.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/80 text-emerald-300 font-bold text-xs uppercase tracking-wider rounded cursor-pointer"
              >
                📥 INSTALL TO ANDROID (APK / APP)
              </button>
            )}

            <button
              onClick={() => {
                const nextMute = !sound.getMuted();
                sound.setMuted(nextMute);
                onUpdateSettings({ ...saveData.settings, soundVolume: nextMute ? 0 : 0.5 });
              }}
              className="py-2.5 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 font-bold text-xs uppercase rounded cursor-pointer"
            >
              {sound.getMuted() ? 'UNMUTE AUDIO' : 'MUTE AUDIO'}
            </button>

            <button
              onClick={() => {
                sound.play('ui_click');
                onReturnToTitle();
              }}
              className="py-2.5 bg-red-950 hover:bg-red-900 border border-red-700/60 text-red-200 font-bold text-xs uppercase rounded cursor-pointer"
            >
              RETURN TO TITLE SCREEN
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
