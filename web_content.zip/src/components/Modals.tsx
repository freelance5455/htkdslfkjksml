import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';

export const Modals: React.FC = () => {
  const {
    coins,
    diamonds,
    ign,
    setIgn,
    uid,
    guild,
    setGuild,
    bio,
    setBio,
    upiId,
    setUpiId,
    deductCoins,
    addLedgerEntry,
    isJoinModalOpen,
    selectedMatch,
    closeJoinModal,
    isDepositModalOpen,
    setIsDepositModalOpen,
    isOtpModalOpen,
    otpPayoutData,
    closeOtpModal,
    isEditProfileOpen,
    setIsEditProfileOpen,
    isEditUpiOpen,
    setIsEditUpiOpen,
    setCurrentTab,
    toast,
    showToast,
    addCoins,
  } = useApp();

  // Join Modal State
  const [joinIgn, setJoinIgn] = useState(ign);
  const [joinUid, setJoinUid] = useState(uid);
  const [isJoining, setIsJoining] = useState(false);

  // Quick Deposit Modal State
  const [quickDepositAmt, setQuickDepositAmt] = useState(50);
  const [quickDepositUtr, setQuickDepositUtr] = useState('');

  // OTP Modal State
  const [otpDigits, setOtpDigits] = useState(['4', '9', '2', '8', '1', '0']);
  const [otpTimer, setOtpTimer] = useState(42);
  const [isDisbursing, setIsDisbursing] = useState(false);

  // Edit Profile Form State
  const [editIgn, setEditIgn] = useState(ign);
  const [editGuild, setEditGuild] = useState(guild);
  const [editBio, setEditBio] = useState(bio);

  // Edit UPI State
  const [editUpiInput, setEditUpiInput] = useState(upiId || 'player@okaxis');

  useEffect(() => {
    setJoinIgn(ign);
    setJoinUid(uid);
    setEditIgn(ign);
    setEditGuild(guild);
    setEditBio(bio);
    setEditUpiInput(upiId || 'player@okaxis');
  }, [ign, uid, guild, bio, upiId]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isOtpModalOpen && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isOtpModalOpen, otpTimer]);

  const handleConfirmJoin = () => {
    if (!selectedMatch) return;
    const fee = selectedMatch.entryFee;
    const success = deductCoins(fee);
    if (!success) return;

    setIsJoining(true);
    setTimeout(() => {
      setIsJoining(false);
      closeJoinModal();
      addLedgerEntry({
        title: `Joined ${selectedMatch.mode === 'squad' ? 'Squad' : 'Solo'} ${selectedMatch.matchNumber}`,
        subtitle: `${selectedMatch.map} Scrims`,
        amount: fee,
        type: 'entry',
        timestamp: 'Just now',
        isPositive: false,
      });
      showToast(`Slot Reserved in ${selectedMatch.title}! Deducted ₹${fee} coins.`);
      setCurrentTab('match-room');
    }, 800);
  };

  const handleQuickDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickDepositUtr || quickDepositUtr.length !== 12) {
      showToast('Please enter a valid 12-digit UPI UTR.', 'error');
      return;
    }
    addCoins(quickDepositAmt, 'coins');
    setIsDepositModalOpen(false);
    setQuickDepositUtr('');
  };

  const handleConfirmWithdrawalOtp = () => {
    setIsDisbursing(true);
    setTimeout(() => {
      setIsDisbursing(false);
      closeOtpModal();
      addLedgerEntry({
        title: `₹${otpPayoutData.amount} Withdrawal Dispatched`,
        subtitle: `${otpPayoutData.destination} • BOI Gateway`,
        amount: otpPayoutData.amount,
        type: 'withdrawal',
        timestamp: 'Just now',
        isPositive: false,
      });
      showToast(
        `Withdrawal Verified & Dispatched! Payout UTR generated via BOI Instant Gateway.`
      );
    }, 1200);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIgn(editIgn);
    setGuild(editGuild);
    setBio(editBio);
    setIsEditProfileOpen(false);
    showToast(`Profile updated! In-game persona: ${editIgn}`);
  };

  const handleSaveUpi = (e: React.FormEvent) => {
    e.preventDefault();
    setUpiId(editUpiInput);
    setIsEditUpiOpen(false);
    showToast(`UPI ID successfully updated: ${editUpiInput}`);
  };

  return (
    <>
      {/* 1. MATCH REGISTRATION MODAL */}
      {isJoinModalOpen && selectedMatch && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-surface-container p-6 rounded shadow-2xl flex flex-col gap-4 border border-primary-container/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#ff5e00]">sports_esports</span>
                <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                  Register: {selectedMatch.title}
                </span>
              </div>
              <button
                onClick={closeJoinModal}
                className="p-1 rounded bg-[#191c22] text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-base">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-1.5 bg-[#0b0e14] p-4 rounded">
              <div className="flex justify-between font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                <span>Wallet Balance:</span>
                <span className="text-[#00dbe9] font-bold">
                  {diamonds} Diamonds | {coins} Coins
                </span>
              </div>
              <div className="flex justify-between font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                <span>Required Fee:</span>
                <span className="text-primary font-bold">
                  ₹{selectedMatch.entryFee} Coins ({selectedMatch.mode === 'squad' ? 'Squad Entry' : 'Solo Entry'})
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                In-Game Free Fire UID
              </label>
              <input
                type="text"
                value={joinUid}
                onChange={(e) => setJoinUid(e.target.value)}
                placeholder="Enter Free Fire Numeric UID"
                className="w-full bg-[#0b0e14] px-4 py-2 rounded text-on-surface font-label-md text-label-md focus:outline-none focus:bg-surface-container-high transition-colors"
              />
              <span className="font-label-sm text-label-sm text-on-surface-variant">
                UID must strictly match your account inside Free Fire lobby.
              </span>
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                In-Game IGN (Nickname)
              </label>
              <input
                type="text"
                value={joinIgn}
                onChange={(e) => setJoinIgn(e.target.value)}
                placeholder="e.g. ALPHA_V7"
                className="w-full bg-[#0b0e14] px-4 py-2 rounded text-on-surface font-label-md text-label-md focus:outline-none focus:bg-surface-container-high transition-colors"
              />
            </div>

            <div className="flex items-center gap-2 text-on-surface-variant font-label-sm text-label-sm">
              <span className="material-symbols-outlined text-sm text-[#00dbe9]">verified_user</span>
              <span>Room credentials will be posted on Match Room tab 15 mins before kick-off.</span>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={closeJoinModal}
                className="px-4 py-2 rounded font-label-md text-label-md uppercase text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmJoin}
                disabled={isJoining}
                className="px-6 py-2 rounded font-label-md text-label-md uppercase tracking-wider font-bold bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] transition-all shadow-md cursor-pointer disabled:opacity-50"
              >
                {isJoining ? 'Reserving...' : `Confirm & Pay (₹${selectedMatch.entryFee})`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. SMS / OTP WITHDRAWAL VERIFICATION MODAL */}
      {isOtpModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#191c22] border-2 border-primary-container/40 w-full max-w-md rounded-xl p-6 shadow-2xl relative flex flex-col gap-4 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-container via-secondary to-tertiary"></div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-[#ff5e00]/20 flex items-center justify-center text-primary-container shrink-0">
                  <span className="material-symbols-outlined text-lg">verified_user</span>
                </div>
                <div>
                  <h3 className="font-headline-sm text-headline-sm uppercase text-on-surface leading-tight font-bold">
                    Security Verification
                  </h3>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase tracking-wider font-semibold">
                    2-Step Payout Authorization
                  </span>
                </div>
              </div>
              <button
                onClick={closeOtpModal}
                className="text-on-surface-variant hover:text-on-surface transition-colors p-1 rounded hover:bg-surface-container cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>

            <p className="font-body-sm text-body-sm text-on-surface-variant">
              We have dispatched a 6-digit one-time passcode (OTP) to your registered mobile number ending in{' '}
              <strong className="text-on-surface font-semibold">••••••4910</strong> linked with Free Fire UID{' '}
              <span className="text-primary font-semibold">#{uid}</span>.
            </p>

            <div className="bg-surface-container p-3 rounded-lg flex flex-col gap-1">
              <div className="flex justify-between items-center font-label-sm text-label-sm">
                <span className="text-on-surface-variant uppercase font-semibold">Withdrawal Amount:</span>
                <span className="font-headline-sm text-headline-sm text-secondary font-bold">
                  ₹{Number(otpPayoutData.amount).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center font-label-sm text-xs text-on-surface-variant">
                <span>Payout Destination:</span>
                <span className="text-[#00dbe9] font-semibold">{otpPayoutData.destination}</span>
              </div>
              <div className="flex justify-between items-center font-label-sm text-xs text-on-surface-variant">
                <span>Platform Fee / TDS:</span>
                <span className="text-[#00dbe9]">₹0.00 (Zero Fee)</span>
              </div>
            </div>

            {/* OTP 6-Box Display */}
            <div className="flex flex-col gap-2 items-center">
              <label className="font-label-sm text-label-sm uppercase text-on-surface-variant w-full text-left flex justify-between font-semibold">
                <span>Enter 6-Digit SMS Code</span>
                <span className="text-primary-container text-xs font-bold">Auto-Read Active</span>
              </label>
              <div className="flex gap-2 justify-center w-full">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => {
                      const newArr = [...otpDigits];
                      newArr[idx] = e.target.value;
                      setOtpDigits(newArr);
                    }}
                    className="w-12 h-12 text-center text-xl font-headline-sm font-bold bg-[#0b0e14] border-2 border-primary-container text-primary rounded outline-none shadow-md"
                  />
                ))}
              </div>
            </div>

            <div className="flex justify-between items-center font-label-sm text-xs px-1">
              <div className="flex items-center gap-1 text-on-surface-variant">
                <span className="material-symbols-outlined text-sm text-[#00dbe9] animate-spin">sync</span>
                <span>
                  Resend code in <strong className="text-[#00dbe9]">00:{otpTimer < 10 ? '0' : ''}{otpTimer}s</strong>
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOtpTimer(45);
                  showToast('New 6-digit OTP code dispatched via SMS & WhatsApp.', 'info');
                }}
                className="text-primary hover:text-on-surface uppercase font-bold transition-colors cursor-pointer"
              >
                Resend via SMS
              </button>
            </div>

            <div className="flex flex-col gap-2 mt-1">
              <button
                type="button"
                onClick={handleConfirmWithdrawalOtp}
                disabled={isDisbursing}
                className="w-full py-3 px-4 rounded bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline-sm text-headline-sm uppercase transition-all flex items-center justify-center gap-2 shadow-md active:scale-[0.99] font-bold cursor-pointer disabled:opacity-50"
              >
                <span className="material-symbols-outlined text-base">lock_open</span>
                <span>{isDisbursing ? 'DISBURSING...' : 'CONFIRM & DISBURSE WITHDRAWAL'}</span>
              </button>
              <button
                type="button"
                onClick={closeOtpModal}
                className="w-full py-1.5 rounded font-label-sm text-label-sm uppercase text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer font-semibold"
              >
                Edit Payout Details / Cancel
              </button>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-on-surface-variant font-label-sm text-xs text-center border-t border-surface-variant/50 pt-2">
              <span className="material-symbols-outlined text-xs text-[#00dbe9]">security</span>
              <span>128-bit Encrypted Transaction • BOI Payout Gateway</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. INSTANT UPI DEPOSIT MODAL */}
      {isDepositModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-surface-container p-6 rounded-xl shadow-2xl flex flex-col gap-4 border border-primary-container/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00dbe9] text-2xl">qr_code_2</span>
                <span className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                  Instant Coin Deposit
                </span>
              </div>
              <button
                className="text-on-surface-variant hover:text-on-surface p-1 rounded bg-surface-container-high cursor-pointer"
                onClick={() => setIsDepositModalOpen(false)}
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>

            <div className="p-3 rounded bg-[#0b0e14] text-center flex flex-col items-center gap-2">
              <div className="w-48 h-48 rounded bg-surface-bright p-2 flex items-center justify-center">
                <img
                  className="w-full h-full object-contain rounded"
                  alt="UPI QR payment code"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuB7qgbwx_YZjq7tGEckQquFH_P71SW_oWkZiFB4S4ZCokBSqWALwozJpF9Id1CuHQEQVVftnpTJQlUrfKcd2CnAOAbdj9YjgghtfUUjrFq0ckmrK7iS0WrX5UQV7krHOG5S1y1I98UyGLi0YvMCoiBI3MVCKK3Eao19LAGbOe79Bcr9WeR6vUEsUUHC_UfeO656Qalgz-KkEodpPVgWbBD69NmejXY-cdMxG-uhIG48dxHAsVjBfOTBwQ"
                />
              </div>
              <div className="font-label-md text-label-md text-on-surface uppercase font-bold">
                UPI ID: igniteesports@icici
              </div>
              <div className="font-label-sm text-label-sm text-secondary font-bold">
                RATE: ₹1 = 1 COIN • MIN ₹30
              </div>
            </div>

            <form onSubmit={handleQuickDepositSubmit} className="flex flex-col gap-3">
              <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                Amount in Rupees (₹)
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[30, 50, 100, 250].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setQuickDepositAmt(amt)}
                    className={`py-1.5 rounded font-label-md text-label-md cursor-pointer font-bold ${
                      quickDepositAmt === amt
                        ? 'bg-[#ff5e00] text-[#531900]'
                        : 'bg-surface-container-high hover:bg-surface-bright text-on-surface'
                    }`}
                  >
                    ₹{amt}
                  </button>
                ))}
              </div>

              <input
                type="text"
                value={quickDepositUtr}
                onChange={(e) => setQuickDepositUtr(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="Enter 12-Digit UPI UTR / Ref No."
                maxLength={12}
                required
                className="w-full px-4 py-2 bg-[#0b0e14] text-on-surface rounded font-body-sm text-body-sm focus:outline-none"
              />

              <button
                type="submit"
                className="w-full py-2.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-lg text-label-lg uppercase rounded shadow-lg transition-all font-bold cursor-pointer"
              >
                Verify &amp; Add Coins
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 4. EDIT PROFILE MODAL */}
      {isEditProfileOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-surface-container p-6 rounded max-w-lg w-full shadow-2xl relative flex flex-col gap-4 border border-primary-container/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary-container text-2xl">tune</span>
                <h3 className="font-headline-md text-headline-md uppercase text-on-surface font-bold">
                  Edit Competitor Profile
                </h3>
              </div>
              <button
                onClick={() => setIsEditProfileOpen(false)}
                className="text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-2xl">close</span>
              </button>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Update your tournament persona details. IGN changes require Free Fire sync validation.
            </p>

            <form onSubmit={handleSaveProfile} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                  In-Game Name (IGN)
                </label>
                <input
                  type="text"
                  value={editIgn}
                  onChange={(e) => setEditIgn(e.target.value)}
                  required
                  className="bg-[#0b0e14] text-on-surface px-4 py-2 rounded focus:outline-none focus:ring-1 focus:ring-primary-container font-headline-sm text-headline-sm font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                  Team / Guild Name
                </label>
                <input
                  type="text"
                  value={editGuild}
                  onChange={(e) => setEditGuild(e.target.value)}
                  required
                  className="bg-[#0b0e14] text-on-surface px-4 py-2 rounded focus:outline-none focus:ring-1 focus:ring-primary-container font-body-md text-body-md"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                  Competitive Bio / Tagline
                </label>
                <input
                  type="text"
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="bg-[#0b0e14] text-on-surface px-4 py-2 rounded focus:outline-none focus:ring-1 focus:ring-primary-container font-body-sm text-body-sm"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditProfileOpen(false)}
                  className="px-6 py-2 rounded bg-surface-container-high text-on-surface font-label-md text-label-md uppercase font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-md text-label-md uppercase font-bold transition-all shadow-[0_0_12px_rgba(255,94,0,0.35)] cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. EDIT UPI MODAL */}
      {isEditUpiOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-surface-container p-6 rounded max-w-md w-full shadow-2xl relative flex flex-col gap-4 border border-secondary/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary text-2xl">qr_code_2</span>
                <h3 className="font-headline-md text-headline-md uppercase text-on-surface font-bold">
                  Update UPI VPA
                </h3>
              </div>
              <button
                onClick={() => setIsEditUpiOpen(false)}
                className="text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-2xl">close</span>
              </button>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Enter a valid UPI ID (e.g. yourname@okhdfcbank, mobile@paytm) for instant bounty payouts.
            </p>

            <form onSubmit={handleSaveUpi} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                  New UPI VPA
                </label>
                <input
                  type="text"
                  value={editUpiInput}
                  onChange={(e) => setEditUpiInput(e.target.value)}
                  placeholder="player@okaxis"
                  required
                  className="bg-[#0b0e14] text-on-surface px-4 py-2 rounded focus:outline-none focus:ring-1 focus:ring-secondary font-headline-sm text-headline-sm font-bold"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditUpiOpen(false)}
                  className="px-6 py-2 rounded bg-surface-container-high text-on-surface font-label-md text-label-md uppercase font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded bg-[#ffa504] hover:bg-[#ffb95c] text-[#462a00] font-label-md text-label-md uppercase font-bold transition-all shadow-[0_0_12px_rgba(255,165,4,0.35)] cursor-pointer"
                >
                  Link UPI
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. TOAST NOTIFICATION CONTAINER */}
      <div
        className={`fixed bottom-6 right-6 z-50 transform transition-all duration-300 pointer-events-none flex items-center gap-3 px-6 py-3 rounded shadow-2xl ${
          toast.isVisible ? 'translate-y-0 opacity-100' : 'translate-y-24 opacity-0'
        } ${
          toast.type === 'error'
            ? 'bg-error-container text-on-error-container border border-error/50'
            : toast.type === 'info'
            ? 'bg-surface-container-high text-on-surface border border-tertiary/40'
            : 'bg-surface-container-highest text-on-surface border border-primary-container/40'
        }`}
      >
        <span
          className={`material-symbols-outlined text-xl ${
            toast.type === 'error' ? 'text-error' : toast.type === 'info' ? 'text-[#00dbe9]' : 'text-[#ff5e00]'
          }`}
        >
          {toast.type === 'error' ? 'warning' : toast.type === 'info' ? 'info' : 'check_circle'}
        </span>
        <span className="font-label-md text-label-md font-bold">{toast.message}</span>
      </div>
    </>
  );
};
