import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { SearchResult } from '../types.js';
import {
  LogOut,
  AlertTriangle,
  Trash2,
  Edit2,
  Search,
  X,
  MessageSquare,
  Calendar,
  ArrowRight,
  Loader2,
  Keyboard,
  Sparkles,
} from 'lucide-react';

interface ModalsProps {
  logoutModalOpen: boolean;
  setLogoutModalOpen: (open: boolean) => void;
  deleteAccountModalOpen: boolean;
  setDeleteAccountModalOpen: (open: boolean) => void;
  clearHistoryModalOpen: boolean;
  setClearHistoryModalOpen: (open: boolean) => void;
  renameModal: { open: boolean; conversationId: string; currentTitle: string };
  setRenameModal: (state: { open: boolean; conversationId: string; currentTitle: string }) => void;
  onRenameSuccess: (id: string, newTitle: string) => void;
  onClearHistorySuccess: () => void;
  searchModalOpen: boolean;
  setSearchModalOpen: (open: boolean) => void;
  onSelectSearchResult: (conversationId: string) => void;
  shortcutsModalOpen?: boolean;
  setShortcutsModalOpen?: (open: boolean) => void;
}

export const Modals: React.FC<ModalsProps> = ({
  logoutModalOpen,
  setLogoutModalOpen,
  deleteAccountModalOpen,
  setDeleteAccountModalOpen,
  clearHistoryModalOpen,
  setClearHistoryModalOpen,
  renameModal,
  setRenameModal,
  onRenameSuccess,
  onClearHistorySuccess,
  searchModalOpen,
  setSearchModalOpen,
  onSelectSearchResult,
  shortcutsModalOpen = false,
  setShortcutsModalOpen,
}) => {
  const { logout, authFetch, setCurrentPage } = useAuth();

  // Rename state
  const [newTitle, setNewTitle] = useState('');
  const [renameLoading, setRenameLoading] = useState(false);

  useEffect(() => {
    if (renameModal.open) {
      setNewTitle(renameModal.currentTitle);
    }
  }, [renameModal]);

  // Delete account state
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  // Clear history state
  const [clearLoading, setClearLoading] = useState(false);

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  // Search debounced
  useEffect(() => {
    if (!searchModalOpen || !searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setSearchLoading(true);
      try {
        const res = await authFetch(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`);
        if (res.ok) {
          const data = await res.json();
          setSearchResults(data.results || []);
        }
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setSearchLoading(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery, searchModalOpen]);

  // Handle Logout
  const handleConfirmLogout = async () => {
    setLogoutModalOpen(false);
    await logout();
  };

  // Handle Rename
  const handleConfirmRename = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setRenameLoading(true);
    try {
      const res = await authFetch(`/api/conversations/${renameModal.conversationId}`, {
        method: 'PATCH',
        body: JSON.stringify({ title: newTitle.trim() }),
      });
      if (res.ok) {
        onRenameSuccess(renameModal.conversationId, newTitle.trim());
        setRenameModal({ open: false, conversationId: '', currentTitle: '' });
      }
    } catch (err) {
      console.error('Failed to rename conversation:', err);
    } finally {
      setRenameLoading(false);
    }
  };

  // Handle Clear History
  const handleConfirmClear = async () => {
    setClearLoading(true);
    try {
      const res = await authFetch('/api/conversations', { method: 'DELETE' });
      if (res.ok) {
        onClearHistorySuccess();
        setClearHistoryModalOpen(false);
      }
    } catch (err) {
      console.error('Failed to clear conversations:', err);
    } finally {
      setClearLoading(false);
    }
  };

  // Handle Delete Account
  const handleConfirmDeleteAccount = async () => {
    if (deleteConfirmText !== 'DELETE') {
      setDeleteError('Please type DELETE in all capital letters to confirm.');
      return;
    }
    setDeleteLoading(true);
    setDeleteError('');
    try {
      const res = await authFetch('/api/auth/delete-account', {
        method: 'DELETE',
        body: JSON.stringify({ confirmText: 'DELETE' }),
      });
      if (res.ok) {
        setDeleteAccountModalOpen(false);
        await logout();
        setCurrentPage('landing');
      } else {
        const data = await res.json();
        setDeleteError(data.error || 'Failed to delete account.');
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Error occurred.');
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <>
      {/* 1. LOGOUT CONFIRMATION MODAL */}
      {logoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <LogOut className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Sign Out?</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Are you sure you want to log out of AI Pocket Chat? You will need to enter your email and password to access your chats again.
              </p>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setLogoutModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmLogout}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-sm font-semibold text-white shadow-sm shadow-rose-600/30 transition"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. RENAME CHAT MODAL */}
      {renameModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Rename Chat</h3>
              </div>
              <button
                onClick={() => setRenameModal({ open: false, conversationId: '', currentTitle: '' })}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleConfirmRename} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                  Chat Title
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g. Science Experiment Notes"
                  autoFocus
                  required
                />
              </div>
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRenameModal({ open: false, conversationId: '', currentTitle: '' })}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={renameLoading || !newTitle.trim()}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm font-semibold text-white transition flex items-center gap-2"
                >
                  {renameLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Title'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. CLEAR ALL CHATS MODAL */}
      {clearHistoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Clear All Chat History?</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                This will permanently remove all your saved conversations and messages. This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setClearHistoryModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmClear}
                disabled={clearLoading}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-sm font-semibold text-white shadow-sm shadow-amber-600/30 transition flex items-center justify-center gap-1.5"
              >
                {clearLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Clear All'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. DELETE ACCOUNT MODAL */}
      {deleteAccountModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 shadow-xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-rose-600 dark:text-rose-400">Delete Account Permanently</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                This will delete your user profile, passwords, sessions, preferences, all conversations, and all chat history. This is completely irreversible.
              </p>
            </div>

            {deleteError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-300 text-xs">
                {deleteError}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Type <span className="font-mono font-bold text-rose-600 dark:text-rose-400">DELETE</span> to confirm:
              </label>
              <input
                type="text"
                value={deleteConfirmText}
                onChange={e => setDeleteConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3.5 py-2.5 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/50 dark:bg-rose-950/20 text-slate-900 dark:text-white font-mono text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setDeleteAccountModalOpen(false);
                  setDeleteConfirmText('');
                  setDeleteError('');
                }}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAccount}
                disabled={deleteLoading || deleteConfirmText !== 'DELETE'}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-sm font-semibold text-white shadow-sm shadow-rose-600/30 transition flex items-center justify-center gap-1.5"
              >
                {deleteLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Delete Everything'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. SEARCH CHATS MODAL */}
      {searchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-8 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            {/* Search Input Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <Search className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search conversations, titles, or messages..."
                className="w-full bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
                autoFocus
              />
              {searchLoading && <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />}
              <button
                onClick={() => {
                  setSearchModalOpen(false);
                  setSearchQuery('');
                  setSearchResults([]);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Results list */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {!searchQuery.trim() && (
                <div className="text-center py-10 text-slate-400 text-xs">
                  Type words to search your conversation titles and message history.
                </div>
              )}

              {searchQuery.trim() && !searchLoading && searchResults.length === 0 && (
                <div className="text-center py-10 text-slate-400 text-xs">
                  No conversations found matching "{searchQuery}".
                </div>
              )}

              {searchResults.map((res, i) => (
                <button
                  key={`${res.conversationId}-${res.messageId || i}`}
                  onClick={() => {
                    onSelectSearchResult(res.conversationId);
                    setSearchModalOpen(false);
                    setSearchQuery('');
                  }}
                  className="w-full text-left p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800/60 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20 transition group"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-semibold text-xs text-slate-900 dark:text-white flex items-center gap-1.5 truncate">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                      {res.conversationTitle}
                    </span>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(res.date).toLocaleDateString()}
                    </span>
                  </div>

                  {res.messageContent && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 pl-5">
                      "{res.messageContent}"
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-indigo-600 dark:text-indigo-400 pt-1.5 pl-5 opacity-0 group-hover:opacity-100 transition">
                    <span>Open chat</span>
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </button>
              ))}
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>OWNER NAME: Ali ABDULLAH</span>
              <span>ESC to close</span>
            </div>
          </div>
        </div>
      )}

      {/* 6. KEYBOARD SHORTCUTS MODAL */}
      {shortcutsModalOpen && setShortcutsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                  <Keyboard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">Keyboard Shortcuts</h3>
                  <p className="text-[11px] text-slate-400">Desktop productivity controls</p>
                </div>
              </div>
              <button
                onClick={() => setShortcutsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs divide-y divide-slate-100 dark:divide-slate-800/80">
              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-600 dark:text-slate-300 font-medium">Send message</span>
                <div className="flex items-center gap-1">
                  <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                    Cmd / Ctrl + Enter
                  </kbd>
                  <span className="text-slate-400">or</span>
                  <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                    Enter
                  </kbd>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">New chat</span>
                <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                  Cmd / Ctrl + N
                </kbd>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">Search conversations</span>
                <div className="flex items-center gap-1">
                  <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                    Cmd / Ctrl + K
                  </kbd>
                  <span className="text-slate-400">/</span>
                  <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                    Cmd / Ctrl + F
                  </kbd>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">Regenerate AI response</span>
                <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                  Cmd / Ctrl + Shift + R
                </kbd>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">New line in input</span>
                <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                  Shift + Enter
                </kbd>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">Open shortcuts helper</span>
                <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                  Cmd / Ctrl + /
                </kbd>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-600 dark:text-slate-300 font-medium">Close modals / Stop response</span>
                <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 shadow-xs">
                  Esc
                </kbd>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-800">
              <span>OWNER NAME: Ali ABDULLAH</span>
              <button
                onClick={() => setShortcutsModalOpen(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
