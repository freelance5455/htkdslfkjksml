import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  AnimalMark,
  ArrowRight,
  AwardIcon,
  BookIcon,
  CheckIcon,
  CloseIcon,
  CopyIcon,
  CrosshairIcon,
  DownloadIcon,
  InfoIcon,
  LeafIcon,
  LocateIcon,
  LockIcon,
  MountainMark,
  PlayIcon,
  ReloadIcon,
  RifleIcon,
  SmartphoneIcon,
  TargetIcon,
  TrophyIcon,
  WindIcon,
} from "@/components/Icons";
import { LOADOUTS, MAPS, SPECIES, mapById, type ControlSettings, type HuntRecord, type Loadout, type MapId, type TouchLayout } from "@/data";

/* ---------------------------------- shell --------------------------------- */

interface ShellProps {
  kicker: string;
  title: string;
  onClose: () => void;
  children: ReactNode;
  size?: "md" | "lg" | "xl";
}

function Shell({ kicker, title, onClose, children, size = "lg" }: ShellProps) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.code === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const width = size === "md" ? "max-w-xl" : "max-w-5xl";

  return (
    <div className="fixed inset-0 z-[82] flex items-center justify-center px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-[max(0.75rem,env(safe-area-inset-top))] sm:p-6">
      <button
        aria-label="Close dialog"
        className="absolute inset-0 animate-fade cursor-default bg-bark-950/78 backdrop-blur-md"
        onClick={onClose}
        tabIndex={-1}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`relative z-10 flex max-h-[92dvh] w-full ${width} animate-rise flex-col overflow-hidden rounded-sm border border-sand-100/16 bg-bark-900 shadow-[0_40px_120px_-30px_rgba(0,0,0,0.9)]`}
      >
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brass-300/60 to-transparent" />
        <header className="flex shrink-0 items-center justify-between gap-4 border-b border-sand-100/10 px-5 py-3 sm:px-7 sm:py-4">
          <div className="flex items-center gap-3.5">
            <span className="hidden h-9 w-9 items-center justify-center rounded-sm border border-brass-300/25 text-brass-300 sm:flex">
              <MountainMark size={23} />
            </span>
            <div>
              <p className="eyebrow text-[0.56rem] text-brass-300">{kicker}</p>
              <h2 className="mt-1 font-serif text-xl leading-none text-sand-100 sm:text-2xl">{title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-9 w-9 items-center justify-center rounded-sm border border-sand-100/14 text-sand-300 transition hover:border-brass-300/50 hover:bg-sand-100/6 hover:text-white"
          >
            <CloseIcon size={16} />
          </button>
        </header>
        <div className="overflow-y-auto overscroll-contain">{children}</div>
      </div>
    </div>
  );
}

/* -------------------------------- field guide ------------------------------ */

export function FieldGuideModal({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState(SPECIES[0].key);
  const species = useMemo(() => SPECIES.find((item) => item.key === selected) ?? SPECIES[0], [selected]);

  return (
    <Shell kicker="Field guide · Northern Range" title="Six species. One wilderness." onClose={onClose} size="xl">
      <div className="grid lg:grid-cols-[330px_1fr]">
        <div className="border-b border-sand-100/10 p-3 sm:p-4 lg:border-b-0 lg:border-r">
          <div className="no-scrollbar flex gap-2 overflow-x-auto lg:flex-col">
            {SPECIES.map((item) => {
              const active = item.key === selected;
              return (
                <button
                  key={item.key}
                  onClick={() => setSelected(item.key)}
                  className={`group flex min-w-[172px] items-center gap-3 rounded-sm border px-3 py-3 text-left transition lg:min-w-0 ${
                    active
                      ? "border-brass-300/40 bg-brass-300/8"
                      : "border-transparent hover:border-sand-100/12 hover:bg-sand-100/4"
                  }`}
                >
                  <span className={`transition ${active ? "text-brass-300" : "text-sand-400 group-hover:text-sand-200"}`}>
                    <AnimalMark species={item.key} size={38} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block truncate font-condensed text-[0.92rem] uppercase tracking-[0.08em] ${active ? "text-sand-100" : "text-sand-200"}`}>
                      {item.name}
                    </span>
                    <span className="eyebrow mt-1 block text-[0.46rem] text-sand-400">{item.status}</span>
                  </span>
                  <span className={`num text-sm ${active ? "text-brass-300" : "text-sand-400"}`}>{item.points}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-4 hidden rounded-sm border border-sand-100/10 bg-bark-950/45 p-4 lg:block">
            <div className="flex items-center gap-2 text-brass-300">
              <LeafIcon size={14} />
              <p className="eyebrow text-[0.5rem]">Fair chase</p>
            </div>
            <p className="mt-2 text-[0.72rem] leading-relaxed text-sand-300/80">
              Take only what you need. Every animal in this unit is part of a longer story than your score.
            </p>
          </div>
        </div>

        <div className="p-5 sm:p-7">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
            <div className="relative flex h-[150px] w-full shrink-0 items-center justify-center overflow-hidden rounded-sm border border-sand-100/12 bg-gradient-to-br from-bark-700 to-bark-900 sm:w-[190px]">
              <div className="absolute inset-0 sight-grid opacity-40" />
              <div className="absolute left-1/2 top-1/2 h-24 w-24 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass-300/10 blur-2xl" />
              <span className="relative z-10 text-brass-300 drop-shadow-[0_6px_20px_rgba(0,0,0,0.4)]">
                <AnimalMark species={species.key} size={112} />
              </span>
              <span className="num absolute bottom-2.5 right-3 text-[0.58rem] tracking-wider text-sand-400">FIG. {String(SPECIES.indexOf(species) + 1).padStart(2, "0")}</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-brass-300/30 bg-brass-300/8 px-2.5 py-1 font-condensed text-[0.55rem] uppercase tracking-[0.16em] text-brass-300">
                  {species.status}
                </span>
                <span className="rounded-full border border-sand-100/14 px-2.5 py-1 font-condensed text-[0.55rem] uppercase tracking-[0.16em] text-sand-300">
                  Difficulty {"●".repeat(species.difficulty)}{"○".repeat(3 - species.difficulty)}
                </span>
              </div>
              <h3 className="mt-3 font-serif text-3xl leading-none text-sand-100 sm:text-4xl">{species.name}</h3>
              <p className="mt-1.5 font-serif text-sm italic text-sand-400">{species.latin}</p>
              <p className="mt-3 max-w-xl text-[0.82rem] leading-relaxed text-sand-200/80">{species.note}</p>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-sand-100/10 bg-sand-100/10 sm:grid-cols-4">
            {[
              ["Harvest value", `${species.points} pts`],
              ["Typical weight", species.weight],
              ["Habitat", species.habitat],
              ["Found", species.range],
            ].map(([label, value]) => (
              <div key={label} className="bg-bark-900 px-3.5 py-3.5">
                <p className="eyebrow text-[0.46rem] text-sand-400">{label}</p>
                <p className="mt-1.5 text-[0.76rem] leading-snug text-sand-200">{value}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 flex gap-3 rounded-sm border border-brass-500/20 bg-brass-500/6 p-3.5">
            <TargetIcon size={18} className="mt-0.5 shrink-0 text-brass-300" />
            <p className="text-[0.74rem] leading-relaxed text-sand-200/85">
              <span className="font-semibold text-brass-300">Guide note.</span> Hold the centre of the shoulder for a
              clean vital shot. A head shot earns a bonus, but it is never the ethical first choice.
            </p>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-sm border border-sand-100/10 bg-bark-950/30 p-3.5">
              <div className="flex items-center gap-2 text-brass-300">
                <LocateIcon size={14} />
                <p className="eyebrow text-[0.48rem]">Where to look</p>
              </div>
              <div className="relative mt-3 h-[86px] overflow-hidden rounded-sm border border-sand-100/10 bg-bark-800">
                <div className="absolute inset-0 sight-grid opacity-40" />
                <div className="absolute left-[18%] top-[30%] h-9 w-12 rounded-[50%] bg-moss-500/30 blur-[1px]" />
                <div className="absolute bottom-[18%] right-[22%] h-7 w-16 rounded-[50%] bg-brass-500/20" />
                <div className="absolute left-[46%] top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-brass-300 bg-bark-950">
                  <span className="absolute inset-[-5px] rounded-full border border-brass-300/40" />
                </div>
                <span className="absolute left-2 top-1.5 font-condensed text-[0.45rem] uppercase tracking-[0.16em] text-sand-400">Ridge</span>
                <span className="absolute bottom-1.5 right-2 font-condensed text-[0.45rem] uppercase tracking-[0.16em] text-sand-400">Lake</span>
                <span className="absolute right-2 top-1.5 font-condensed text-[0.45rem] uppercase tracking-[0.14em] text-brass-300">You are here</span>
              </div>
              <p className="mt-2 text-[0.67rem] leading-relaxed text-sand-400">Move along the tree line, keep the sun at your back, and pause often to listen.</p>
            </div>
            <div className="rounded-sm border border-sand-100/10 bg-bark-950/30 p-3.5">
              <div className="flex items-center gap-2 text-brass-300">
                <RifleIcon size={14} />
                <p className="eyebrow text-[0.48rem]">Field craft</p>
              </div>
              <ul className="mt-3 space-y-2">
                {[
                  ["Approach", species.key === "elk" ? "Glass the high meadow first" : species.key === "boar" ? "Stay downwind of thick cover" : "Walk the shaded edge of the timber"],
                  ["Range", species.key === "hare" || species.key === "pheasant" ? "Take your time inside 60 m" : "Steady aim, then breathe out"],
                  ["After the shot", "Mark the spot and give it time"],
                ].map(([label, value]) => (
                  <li key={label} className="flex gap-2.5">
                    <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-brass-300/80" />
                    <p className="text-[0.68rem] leading-snug text-sand-300/80">
                      <span className="font-condensed uppercase tracking-[0.1em] text-sand-200">{label}</span>
                      <span className="mx-1 text-sand-400/50">—</span>
                      {value}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3 border-t border-sand-100/10 bg-bark-950/35 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-7">
        <p className="flex items-center gap-2 text-[0.66rem] text-sand-400">
          <InfoIcon size={14} className="text-brass-300/80" />
          Species availability is managed for a healthy, balanced range.
        </p>
        <p className="eyebrow text-[0.5rem] text-sand-400">Unit 12 · Season 04</p>
      </div>
    </Shell>
  );
}

/* --------------------------------- records -------------------------------- */

export function RecordsModal({ records, onClose }: { records: HuntRecord[]; onClose: () => void }) {
  const bestScore = records.reduce((max, record) => Math.max(max, record.score), 0);
  const totalHarvest = records.reduce((sum, record) => sum + record.harvested, 0);
  const completed = records.filter((record) => record.completed).length;
  const bestAccuracy = records.reduce((max, record) => Math.max(max, record.accuracy), 0);

  return (
    <Shell kicker="Record book · Kept locally" title="A ledger of quiet mornings." onClose={onClose}>
      <div className="p-5 sm:p-7">
        <div className="grid gap-px overflow-hidden rounded-sm border border-sand-100/10 bg-sand-100/10 sm:grid-cols-4">
          {[
            { label: "Personal best", value: bestScore > 0 ? bestScore.toLocaleString() : "—", accent: true },
            { label: "Assignments closed", value: records.length > 0 ? String(completed) : "—" },
            { label: "Total harvest", value: records.length > 0 ? String(totalHarvest) : "—" },
            { label: "Best accuracy", value: bestAccuracy > 0 ? `${Math.round(bestAccuracy)}%` : "—" },
          ].map((item) => (
            <div key={item.label} className="bg-bark-900 px-4 py-4">
              <p className="eyebrow text-[0.48rem] text-sand-400">{item.label}</p>
              <p className={`num mt-2 text-3xl leading-none ${item.accent ? "text-brass-300" : "text-sand-100"}`}>{item.value}</p>
            </div>
          ))}
        </div>

        {records.length === 0 ? (
          <div className="relative mt-6 flex flex-col items-center justify-center overflow-hidden rounded-sm border border-dashed border-sand-100/18 px-6 py-14 text-center">
            <div className="absolute inset-0 sight-grid opacity-30" />
            <span className="relative flex h-14 w-14 items-center justify-center rounded-full border border-brass-300/25 bg-brass-300/5 text-brass-300">
              <AwardIcon size={26} />
            </span>
            <h3 className="relative mt-4 font-serif text-2xl text-sand-100">No expeditions logged</h3>
            <p className="relative mt-2 max-w-sm text-sm leading-relaxed text-sand-400">
              Every hunt writes its own page. Close an assignment and the mountain will remember it here.
            </p>
            <p className="relative eyebrow mt-5 text-[0.5rem] text-brass-300/80">Your ledger is stored on this device</p>
          </div>
        ) : (
          <div className="mt-6">
            <div className="flex items-end justify-between">
              <div>
                <p className="eyebrow text-[0.52rem] text-brass-300">Recent expeditions</p>
                <h3 className="mt-1 font-serif text-xl text-sand-100">The last few mornings</h3>
              </div>
              <span className="eyebrow hidden text-[0.5rem] text-sand-400 sm:block">{records.length} logged</span>
            </div>
            <div className="mt-3 overflow-hidden rounded-sm border border-sand-100/10">
              <div className="hidden grid-cols-[1fr_0.8fr_0.7fr_0.7fr_0.9fr_0.8fr] gap-3 border-b border-sand-100/10 bg-bark-950/50 px-4 py-2.5 sm:grid">
                {["Date", "Rifle", "Harvest", "Accuracy", "Best shot", "Score"].map((label) => (
                  <span key={label} className="eyebrow text-[0.45rem] text-sand-400">
                    {label}
                  </span>
                ))}
              </div>
              {records.map((record) => (
                <div
                  key={record.id}
                  className="grid grid-cols-2 gap-2 border-b border-sand-100/8 px-4 py-3 text-[0.74rem] text-sand-200 transition last:border-b-0 hover:bg-sand-100/4 sm:grid-cols-[1fr_0.8fr_0.7fr_0.7fr_0.9fr_0.8fr] sm:items-center sm:gap-3"
                >
                  <div className="flex items-center gap-2">
                    <span className={`h-1.5 w-1.5 rounded-full ${record.completed ? "bg-brass-300" : "bg-sand-400/60"}`} />
                    <span className="num whitespace-nowrap text-sand-100">
                      {new Date(record.date).toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}
                    </span>
                  </div>
                  <span className="text-sand-300 sm:text-sand-200">{record.loadout}</span>
                  <span className="num">{record.harvested} / 3</span>
                  <span className="num">{Math.round(record.accuracy)}%</span>
                  <span className="num">{record.bestDistance > 0 ? `${record.bestDistance} m` : "—"}</span>
                  <span className="num text-right text-brass-300 sm:text-left">{record.score.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5 flex gap-3 rounded-sm border border-brass-500/20 bg-brass-500/6 p-3.5">
          <TrophyIcon size={19} className="mt-0.5 shrink-0 text-brass-300" />
          <p className="text-[0.74rem] leading-relaxed text-sand-200/85">
            <span className="font-semibold text-brass-300">Club standard.</span> A hunt is scored on the whole morning —
            accuracy, distance, and the decisions you make when the ridge goes quiet.
          </p>
        </div>
      </div>
    </Shell>
  );
}

/* --------------------------------- armoury -------------------------------- */

export function LoadoutModal({
  current,
  onEquip,
  onClose,
}: {
  current: Loadout;
  onEquip: (loadout: Loadout) => void;
  onClose: () => void;
}) {
  const [selectedId, setSelectedId] = useState(current.id);
  const selected = LOADOUTS.find((item) => item.id === selectedId) ?? LOADOUTS[0];

  return (
    <Shell kicker="Armoury · Camp store" title="Choose your instrument." onClose={onClose}>
      <div className="p-5 sm:p-7">
        <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
          <p className="max-w-xl text-[0.82rem] leading-relaxed text-sand-300/85">
            Three rifles, three ways to read the ridge. Every calibre is provided with a full magazine and reserve
            ammunition — choose for the country ahead, not the louder shot.
          </p>
          <p className="eyebrow shrink-0 text-[0.48rem] text-sand-400">Equipped · {current.name}</p>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-3">
          {LOADOUTS.map((item) => {
            const active = item.id === selectedId;
            const equipped = item.id === current.id;
            return (
              <button
                key={item.id}
                onClick={() => setSelectedId(item.id)}
                aria-pressed={active}
                className={`relative flex flex-col overflow-hidden rounded-sm border p-4 text-left transition ${
                  active
                    ? "border-brass-300/60 bg-gradient-to-b from-brass-300/10 to-bark-900"
                    : "border-sand-100/12 bg-bark-950/30 hover:border-sand-100/25 hover:bg-sand-100/4"
                }`}
              >
                {active && <span className="absolute right-0 top-0 h-6 w-6 rounded-bl-sm bg-brass-300/90 text-bark-950"> <CheckIcon size={14} className="ml-1.5 mt-1" /></span>}
                <div className="flex items-start justify-between gap-2 pr-6">
                  <div>
                    <p className="eyebrow text-[0.48rem] text-sand-400">{item.role}</p>
                    <p className="mt-1.5 font-serif text-2xl leading-none text-sand-100">{item.name}</p>
                  </div>
                  <span className={active ? "text-brass-300" : "text-sand-400"}>
                    <RifleIcon size={30} />
                  </span>
                </div>
                <p className="num mt-2 text-[0.7rem] tracking-[0.12em] text-brass-300">{item.calibre}</p>
                <p className="mt-2.5 min-h-[54px] text-[0.71rem] leading-relaxed text-sand-300/75">{item.description}</p>

                <div className="mt-3 space-y-2 border-t border-sand-100/10 pt-3">
                  {[
                    ["Reach", Math.min(5, item.id === "scout" ? 3 : item.id === "timberwolf" ? 5 : 4)],
                    ["Stability", item.stability],
                  ].map(([label, value]) => (
                    <div key={label as string} className="flex items-center gap-2">
                      <span className="w-14 font-condensed text-[0.52rem] uppercase tracking-[0.14em] text-sand-400">{label}</span>
                      <span className="flex flex-1 gap-1">
                        {[1, 2, 3, 4, 5].map((step) => (
                          <span key={step} className={`h-1 flex-1 ${step <= (value as number) ? (active ? "bg-brass-300" : "bg-sand-300/60") : "bg-sand-100/12"}`} />
                        ))}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-3 grid grid-cols-3 gap-1 border-t border-sand-100/10 pt-2.5">
                  <div>
                    <p className="eyebrow text-[0.42rem] text-sand-400">Mag</p>
                    <p className="num mt-0.5 text-[0.72rem] text-sand-200">{item.magazine} + {item.reserve}</p>
                  </div>
                  <div>
                    <p className="eyebrow text-[0.42rem] text-sand-400">Weight</p>
                    <p className="num mt-0.5 text-[0.72rem] text-sand-200">{item.weight}</p>
                  </div>
                  <div>
                    <p className="eyebrow text-[0.42rem] text-sand-400">Reach</p>
                    <p className="num mt-0.5 text-[0.72rem] text-sand-200">{item.range}</p>
                  </div>
                </div>
                {equipped && <p className="eyebrow mt-2.5 flex items-center gap-1.5 text-[0.46rem] text-brass-300"><CheckIcon size={10} /> In the field</p>}
              </button>
            );
          })}
        </div>

        <div className="mt-4 flex flex-col items-start justify-between gap-3 rounded-sm border border-sand-100/10 bg-bark-950/35 p-3.5 sm:flex-row sm:items-center">
          <div className="flex items-center gap-2.5">
            <InfoIcon size={16} className="text-brass-300/80" />
            <p className="text-[0.7rem] text-sand-300/80">
              Selected <span className="text-sand-100">{selected.name} {selected.calibre}</span> · {selected.magazine} round magazine
            </p>
          </div>
          <div className="flex w-full gap-2 sm:w-auto">
            <button onClick={onClose} className="btn-ghost h-10 flex-1 px-4 text-[0.66rem] sm:flex-none">
              Cancel
            </button>
            <button
              onClick={() => {
                onEquip(selected);
                onClose();
              }}
              className="btn-primary h-10 flex-1 px-5 text-[0.66rem] sm:flex-none"
            >
              <CheckIcon size={13} /> Equip rifle
            </button>
          </div>
        </div>
      </div>
    </Shell>
  );
}

/* ---------------------------------- android -------------------------------- */

const BUILD_COMMANDS = `npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug`;

export function AndroidAppModal({
  installed,
  canInstall,
  native,
  android,
  onInstall,
  onControls,
  onStart,
  onClose,
}: {
  installed: boolean;
  canInstall: boolean;
  native: boolean;
  android: boolean;
  onInstall: () => void;
  onControls: () => void;
  onStart: () => void;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(BUILD_COMMANDS);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  return (
    <Shell kicker="Android app · Install or build" title="Take the ridge with you." onClose={onClose} size="lg">
      <div className="p-5 sm:p-7">
        <div className="grid gap-4 md:grid-cols-[1fr_0.95fr]">
          <div className="relative overflow-hidden rounded-sm border border-brass-300/30 bg-gradient-to-br from-bark-700/60 via-bark-900 to-bark-950 p-4 sm:p-5">
            <div className="pointer-events-none absolute inset-0 sight-grid opacity-20" />
            <div className="relative flex items-start gap-4">
              <img
                src="/icons/icon-192.png"
                width={76}
                height={76}
                alt="Ridgeline app icon"
                className="h-[76px] w-[76px] shrink-0 rounded-[16px] border border-brass-300/30 shadow-[0_10px_30px_rgba(0,0,0,0.5)]"
              />
              <div className="min-w-0">
                <p className="eyebrow text-[0.46rem] text-brass-300">Ridgeline Hunting Club</p>
                <h3 className="mt-1 font-serif text-[1.7rem] leading-none text-sand-100">The Golden Ridge</h3>
                <p className="mt-1.5 flex flex-wrap items-center gap-1.5 font-condensed text-[0.6rem] uppercase tracking-[0.1em] text-sand-400">
                  <span>v1.0</span>
                  <span className="h-2 w-px bg-sand-100/20" />
                  <span>Android 8.0+</span>
                  <span className="h-2 w-px bg-sand-100/20" />
                  <span>Offline ready</span>
                </p>
              </div>
            </div>

            <div className="relative mt-4 grid grid-cols-3 gap-px overflow-hidden rounded-sm border border-sand-100/10 bg-sand-100/10">
              {[
                ["Maps", "4"],
                ["Species", "6"],
                ["Drives", "5"],
              ].map(([label, value]) => (
                <div key={label} className="bg-bark-950/55 px-2 py-2 text-center">
                  <p className="num text-xl leading-none text-brass-300">{value}</p>
                  <p className="eyebrow mt-1 text-[0.4rem] text-sand-400">{label}</p>
                </div>
              ))}
            </div>

            <div className="relative mt-4">
              {native || installed ? (
                <div className="flex h-11 items-center justify-center gap-2 rounded-sm border border-brass-300/45 bg-brass-300/12 font-condensed text-[0.72rem] uppercase tracking-[0.14em] text-brass-200">
                  <CheckIcon size={14} /> Installed — you’re in the field
                </div>
              ) : (
                <button
                  onClick={onInstall}
                  disabled={!canInstall}
                  className={`h-11 w-full rounded-sm font-condensed text-[0.74rem] uppercase tracking-[0.14em] transition ${
                    canInstall
                      ? "bg-gradient-to-b from-sand-100 to-sand-300 text-bark-900 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.8)] hover:from-white hover:to-sand-100"
                      : "cursor-default border border-sand-100/18 bg-bark-950/40 text-sand-300/80"
                  }`}
                >
                  <span className="flex items-center justify-center gap-2">
                    {canInstall ? <DownloadIcon size={15} /> : <SmartphoneIcon size={15} />}
                    {canInstall ? "Install on this device" : android ? "Use Chrome menu · Install app" : "Open on Android to install"}
                  </span>
                </button>
              )}
              <p className="mt-2 text-center text-[0.6rem] leading-relaxed text-sand-400">
                {native
                  ? "Running as the native Android build."
                  : installed
                    ? "Launching from your home screen. Works without a connection."
                    : android
                      ? "Chrome: ⋮ menu → “Install app” or “Add to Home screen”."
                      : "On a phone, open this page in Chrome and choose Install app."}
              </p>
            </div>
          </div>

          <div className="rounded-sm border border-sand-100/10 bg-bark-950/30 p-4 sm:p-5">
            <div className="flex items-center gap-2 text-brass-300">
              <DownloadIcon size={14} />
              <p className="eyebrow text-[0.46rem]">Build the APK</p>
            </div>
            <p className="mt-2 text-[0.74rem] leading-relaxed text-sand-300/85">
              A native <span className="text-sand-100">Capacitor Android project</span> is included in the{" "}
              <code className="rounded-[2px] bg-sand-100/10 px-1 py-0.5 font-mono text-[0.66rem] text-brass-200">android/</code>{" "}
              folder. Run these commands on a machine with Android Studio to produce an installable APK.
            </p>
            <div className="relative mt-2.5 overflow-hidden rounded-sm border border-sand-100/12 bg-bark-950/80">
              <div className="flex items-center justify-between border-b border-sand-100/10 px-2.5 py-1.5">
                <span className="eyebrow text-[0.4rem] text-sand-400">Terminal · debug APK</span>
                <button
                  onClick={copy}
                  className="flex items-center gap-1 rounded-[2px] border border-sand-100/15 px-1.5 py-0.5 font-condensed text-[0.5rem] uppercase tracking-[0.1em] text-sand-300 transition hover:border-brass-300/40 hover:text-brass-300"
                >
                  {copied ? <CheckIcon size={9} /> : <CopyIcon size={9} />} {copied ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="overflow-x-auto px-2.5 py-2 font-mono text-[0.62rem] leading-[1.65] text-sand-200">
                <code>{BUILD_COMMANDS}</code>
              </pre>
            </div>
            <p className="mt-2 text-[0.62rem] leading-relaxed text-sand-400">
              Output:{" "}
              <code className="font-mono text-[0.58rem] text-brass-200">android/app/build/outputs/apk/debug/app-debug.apk</code>.
              Sign a release build with <code className="font-mono text-[0.58rem] text-sand-300">./gradlew assembleRelease</code>.
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <a
                href="./android-build-guide.html"
                target="_blank" rel="noreferrer"
                className="flex items-center gap-1.5 rounded-sm border border-sand-100/18 px-2 py-1 font-condensed text-[0.54rem] uppercase tracking-[0.12em] text-sand-200 transition hover:border-brass-300/40 hover:text-brass-300"
              >
                <BookIcon size={10} /> Full build guide
              </a>
              <span className="font-condensed text-[0.52rem] uppercase tracking-[0.08em] text-sand-400/80">
                JDK 21 + Android SDK 35 required
              </span>
            </div>
            <div className="mt-2.5 flex items-center gap-2 rounded-sm border border-sand-100/10 px-2.5 py-2">
              <SmartphoneIcon size={13} className="shrink-0 text-brass-300/80" />
              <p className="text-[0.62rem] leading-snug text-sand-300/75">
                Or open the <span className="text-sand-100">android/</span> folder in Android Studio → Build → Build APK(s).
              </p>
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-3">
          {[
            { label: "Home-screen icon", detail: "Standalone, fullscreen, no browser bars" },
            { label: "Offline play", detail: "The whole ridge is cached after first load" },
            { label: "Touch first", detail: "Option A thumbstick + unlimited ammo" },
          ].map((item) => (
            <div key={item.label} className="rounded-sm border border-sand-100/10 px-3 py-2.5">
              <p className="flex items-center gap-1.5 font-condensed text-[0.66rem] uppercase tracking-[0.1em] text-sand-100">
                <CheckIcon size={10} className="text-brass-300" /> {item.label}
              </p>
              <p className="mt-1 text-[0.62rem] leading-snug text-sand-400">{item.detail}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-col gap-2 border-t border-sand-100/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <button onClick={onControls} className="btn-ghost h-10 px-4 text-[0.64rem]">
            <CrosshairIcon size={13} /> Controls, maps & ammo
          </button>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button onClick={onStart} className="btn-primary h-10 px-5 text-[0.66rem]">
              <PlayIcon size={12} /> {native || installed ? "Open the hunt" : "Play in browser"}
            </button>
            <button onClick={onClose} className="btn-ghost h-10 px-4 text-[0.64rem]">
              Close
            </button>
          </div>
        </div>
      </div>
    </Shell>
  );
}

/* ------------------------------ android controls ---------------------------- */

export function ControlsModal({
  settings,
  preview,
  onPreview,
  onChange,
  onClose,
}: {
  settings: ControlSettings;
  preview: MapId | null;
  onPreview: (id: MapId) => void;
  onChange: (settings: ControlSettings) => void;
  onClose: () => void;
}) {
  const layouts: { id: TouchLayout; title: string; subtitle: string; body: string }[] = [
    {
      id: "A",
      title: "Option A · Thumbstick",
      subtitle: "Recommended for Android",
      body: "An analog stick under your left thumb for smooth, variable-speed walking. Tap the scope to steady, then use Fire with your right thumb.",
    },
    {
      id: "B",
      title: "Option B · Field D-pad",
      subtitle: "Precise on smaller screens",
      body: "Four firm directions for careful stalking. Familiar and forgiving on compact phones or when wearing gloves.",
    },
  ];

  const sensitivities = [
    { value: 0.65, label: "Slow" },
    { value: 1, label: "Normal" },
    { value: 1.45, label: "Fast" },
  ];

  return (
    <Shell kicker="Option A · Android field setup" title="Pick up. Walk quietly." onClose={onClose}>
      <div className="p-5 sm:p-7">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
          <div className="max-w-lg">
            <div className="flex items-center gap-2 text-brass-300">
              <LocateIcon size={14} />
              <p className="eyebrow text-[0.48rem]">Touch controls · Android & tablet</p>
            </div>
            <p className="mt-2 text-[0.82rem] leading-relaxed text-sand-300/85">
              Layout <span className="font-semibold text-brass-300">Option A</span> is selected by default. Walk with the
              left thumbstick, drag the right side of the scene to look, and keep your right thumb near the trigger.
              Extra maps and unlimited ammunition are set here too.
            </p>
          </div>
          <span className="shrink-0 self-start rounded-sm border border-brass-300/30 bg-brass-300/8 px-3 py-1.5">
            <span className="eyebrow text-[0.46rem] text-brass-300">Current · Option {settings.layout}</span>
          </span>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {layouts.map((layout) => {
            const active = settings.layout === layout.id;
            return (
              <button
                key={layout.id}
                onClick={() => onChange({ ...settings, layout: layout.id })}
                aria-pressed={active}
                className={`relative flex flex-col rounded-sm border p-4 text-left transition ${
                  active ? "border-brass-300/60 bg-gradient-to-b from-brass-300/10 to-bark-900" : "border-sand-100/12 bg-bark-950/30 hover:border-sand-100/24"
                }`}
              >
                {active && (
                  <span className="absolute right-0 top-0 flex h-6 w-6 items-center justify-center rounded-bl-sm bg-brass-300/90 text-bark-950">
                    <CheckIcon size={13} />
                  </span>
                )}
                <div className="flex items-start justify-between gap-3 pr-6">
                  <div>
                    <p className="font-serif text-xl leading-none text-sand-100">{layout.title}</p>
                    <p className="eyebrow mt-1.5 text-[0.44rem] text-brass-300">{layout.subtitle}</p>
                  </div>
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-sand-100/16 bg-bark-950/50">
                    {layout.id === "A" ? (
                      <span className="relative flex h-8 w-8 items-center justify-center rounded-full border border-brass-300/50">
                        <span className="absolute h-4 w-4 -translate-x-1 -translate-y-1 rounded-full bg-brass-300/70" />
                      </span>
                    ) : (
                      <span className="grid grid-cols-3 grid-rows-2 gap-0.5">
                        <span />
                        <span className="h-2 w-2 rounded-[1px] bg-brass-300/70" />
                        <span />
                        <span className="h-2 w-2 rounded-[1px] bg-brass-300/70" />
                        <span className="h-2 w-2 rounded-[1px] bg-brass-300/70" />
                        <span className="h-2 w-2 rounded-[1px] bg-brass-300/70" />
                      </span>
                    )}
                  </div>
                </div>
                <p className="mt-3 text-[0.72rem] leading-relaxed text-sand-300/75">{layout.body}</p>
              </button>
            );
          })}
        </div>

        <div className="mt-5">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 text-brass-300">
                <MountainMark size={14} />
                <p className="eyebrow text-[0.46rem]">Hunting grounds · Extra maps</p>
              </div>
              <p className="mt-1 text-[0.7rem] text-sand-400">Four distinct ranges. The whole herd and all five drives come with each map.</p>
            </div>
            <span className="rounded-sm border border-brass-300/25 bg-brass-300/8 px-2.5 py-1">
              <span className="eyebrow text-[0.42rem] text-brass-300">Selected · {mapById(settings.map).name}</span>
            </span>
          </div>
          <div className="mt-2.5 flex h-24 overflow-hidden rounded-sm border border-sand-100/12 bg-bark-950/40">
            <div className="relative w-[46%] shrink-0 overflow-hidden" aria-hidden>
              <div
                className="absolute inset-0"
                style={{
                  background: `linear-gradient(180deg, ${mapById(preview ?? settings.map).swatch[0]} 0%, ${mapById(preview ?? settings.map).swatch[2]} 62%, ${mapById(preview ?? settings.map).swatch[1]} 100%)`,
                }}
              />
              <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-bark-950/70 to-transparent" />
              <div className="absolute bottom-0 left-[8%] h-[42%] w-[30%] opacity-80" style={{ background: `linear-gradient(135deg, transparent 50%, ${mapById(preview ?? settings.map).swatch[1]} 51%)` }} />
              <div className="absolute bottom-0 left-[26%] h-[62%] w-[34%] opacity-70" style={{ background: `linear-gradient(135deg, transparent 50%, ${mapById(preview ?? settings.map).swatch[1]} 51%)` }} />
              <div className="absolute bottom-0 right-[8%] h-[50%] w-[26%] opacity-60" style={{ background: `linear-gradient(135deg, transparent 50%, ${mapById(preview ?? settings.map).swatch[2]} 51%)` }} />
              <div className="absolute right-2 top-2 rounded-[2px] border border-sand-100/25 bg-bark-950/55 px-1.5 py-0.5">
                <span className="eyebrow text-[0.38rem] text-sand-200">Terrain study</span>
              </div>
            </div>
            <div className="flex min-w-0 flex-1 flex-col justify-center gap-1 p-3">
              <div className="flex flex-wrap items-baseline gap-1.5">
                <p className="font-serif text-[1.05rem] leading-none text-sand-100">{mapById(preview ?? settings.map).name}</p>
                <p className="eyebrow text-[0.4rem] text-brass-300">{mapById(preview ?? settings.map).subtitle}</p>
              </div>
              <p className="text-[0.64rem] leading-snug text-sand-300/75">{mapById(preview ?? settings.map).description}</p>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                {[["Temp", mapById(preview ?? settings.map).temperature], ["Wind", mapById(preview ?? settings.map).wind], ["Region", mapById(preview ?? settings.map).region]].map(([label, value]) => (
                  <span key={label} className="flex items-center gap-1">
                    <span className="eyebrow text-[0.38rem] text-sand-400">{label}</span>
                    <span className="num text-[0.56rem] text-sand-200">{value}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-2 grid grid-cols-2 gap-2 lg:grid-cols-4">
            {MAPS.map((map) => {
              const active = settings.map === map.id;
              const shown = (preview ?? settings.map) === map.id;
              return (
                <button
                  key={map.id}
                  onClick={() => {
                    onChange({ ...settings, map: map.id });
                    onPreview(map.id);
                  }}
                  aria-pressed={active}
                  className={`group relative overflow-hidden rounded-sm border text-left transition ${
                    active ? "border-brass-300/60 bg-brass-300/8" : shown ? "border-brass-300/35 bg-brass-300/4" : "border-sand-100/12 bg-bark-950/30 hover:border-sand-100/26"
                  }`}
                >
                  <span
                    className="block h-11 w-full"
                    style={{ background: `linear-gradient(115deg, ${map.swatch[0]} 0%, ${map.swatch[1]} 56%, ${map.swatch[2]} 100%)` }}
                  >
                    <span className="flex h-full items-end justify-between bg-gradient-to-t from-bark-950/55 to-transparent px-2 pb-1">
                      <span className="font-condensed text-[0.5rem] uppercase tracking-[0.16em] text-sand-100/90">{map.subtitle}</span>
                      {active && <CheckIcon size={12} className="text-brass-200" />}
                    </span>
                  </span>
                  <span className="block px-2.5 py-2">
                    <span className={`block font-serif text-[1.02rem] leading-none ${active ? "text-brass-200" : "text-sand-100"}`}>{map.name}</span>
                    <span className="mt-1 block font-condensed text-[0.48rem] uppercase tracking-[0.1em] text-sand-400">{map.conditions}</span>
                    <span className="mt-1.5 flex items-center justify-between border-t border-sand-100/10 pt-1">
                      <span className="num text-[0.52rem] text-sand-300">{map.temperature}</span>
                      <span className="num text-[0.52rem] text-sand-400">{map.wind}</span>
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => onChange({ ...settings, infiniteAmmo: !settings.infiniteAmmo })}
          aria-pressed={settings.infiniteAmmo}
          className={`mt-3 flex w-full items-center justify-between gap-3 rounded-sm border p-3.5 text-left transition ${
            settings.infiniteAmmo ? "border-brass-300/45 bg-brass-300/8" : "border-sand-100/12 bg-bark-950/30 hover:border-sand-100/24"
          }`}
        >
          <span className="flex items-center gap-3">
            <span className={`flex h-9 w-9 items-center justify-center rounded-full border ${settings.infiniteAmmo ? "border-brass-300/50 bg-brass-300/15 text-brass-300" : "border-sand-100/20 text-sand-300"}`}>
              <RifleIcon size={17} />
            </span>
            <span>
              <span className="block font-condensed text-[0.82rem] uppercase tracking-[0.12em] text-sand-100">
                Infinite ammunition {settings.infiniteAmmo ? "· on" : "· off"}
              </span>
              <span className="mt-0.5 block text-[0.66rem] text-sand-400">
                {settings.infiniteAmmo ? "The magazine refills after every shot. Focus on the herd, not the count." : "Classic limited rounds with reserve ammunition and reloads."}
              </span>
            </span>
          </span>
          <span className={`flex h-6 w-11 shrink-0 items-center rounded-full border px-[3px] transition ${settings.infiniteAmmo ? "justify-end border-brass-300/60 bg-brass-300/35" : "justify-start border-sand-100/25 bg-sand-100/10"}`}>
            <span className={`h-4 w-4 rounded-full transition ${settings.infiniteAmmo ? "bg-brass-200" : "bg-sand-300/80"}`} />
          </span>
        </button>

        <div className="mt-4 rounded-sm border border-sand-100/10 bg-bark-950/30 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="eyebrow text-[0.46rem] text-brass-300">Look sensitivity</p>
              <p className="mt-1 text-[0.68rem] text-sand-400">How far the view swings when you drag the right side of the screen.</p>
            </div>
            <span className="num text-lg text-sand-100">{settings.sensitivity.toFixed(2)}×</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-1.5">
            {sensitivities.map((item) => (
              <button
                key={item.label}
                onClick={() => onChange({ ...settings, sensitivity: item.value })}
                aria-pressed={Math.abs(settings.sensitivity - item.value) < 0.01}
                className={`rounded-sm border px-3 py-2 font-condensed text-[0.66rem] uppercase tracking-[0.14em] transition ${
                  Math.abs(settings.sensitivity - item.value) < 0.01
                    ? "border-brass-300/60 bg-brass-300/12 text-brass-200"
                    : "border-sand-100/12 text-sand-300 hover:border-sand-100/24 hover:text-sand-100"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {[
            ["Walk", "Left thumbstick"],
            ["Look", "Drag right side"],
            ["Fire / steady", "Right action buttons"],
          ].map(([label, value]) => (
            <div key={label} className="rounded-sm border border-sand-100/10 px-3 py-2.5">
              <p className="eyebrow text-[0.42rem] text-sand-400">{label}</p>
              <p className="mt-1 text-[0.7rem] text-sand-200">{value}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-between gap-3 border-t border-sand-100/10 pt-3.5">
          <p className="flex items-center gap-2 text-[0.64rem] text-sand-400">
            <InfoIcon size={13} className="text-brass-300/80" />
            Keyboard and mouse remain active on desktop.
          </p>
          <button onClick={onClose} className="btn-primary h-10 px-5 text-[0.66rem]">
            <CheckIcon size={13} /> Apply & close
          </button>
        </div>
      </div>
    </Shell>
  );
}

/* ---------------------------------- how to -------------------------------- */

export function HowToModal({ onStart, onClose, onControls }: { onStart: () => void; onClose: () => void; onControls: () => void }) {
  return (
    <Shell kicker="Camp briefing · Assignment 04" title="How to hunt the ridge." onClose={onClose}>
      <div className="p-5 sm:p-7">
        <div className="grid gap-3 md:grid-cols-3">
          {[
            {
              step: "01",
              title: "Move quietly",
              icon: <LocateIcon size={19} />,
              body: "Walk with W A S D. Drag the scene to look around — slowly. Heavy footfall spooks game long before you see it.",
              keys: ["W", "A", "S", "D"],
            },
            {
              step: "02",
              title: "Read the wind",
              icon: <WindIcon size={19} />,
              body: "Hold Shift or the aim button to steady your breath and bring the optic up. A steadier view means a cleaner vital shot.",
              keys: ["SHIFT", "RMB"],
            },
            {
              step: "03",
              title: "Work the drives",
              icon: <CrosshairIcon size={19} />,
              body: "Five driven waves sweep the ridge. Meet each drive's quota before the timer runs out. Click or tap Fire, or press Space.",
              keys: ["CLICK", "SPACE", "R"],
            },
          ].map((item) => (
            <div key={item.step} className="rounded-sm border border-sand-100/12 bg-bark-950/30 p-4">
              <div className="flex items-center justify-between">
                <span className="flex h-9 w-9 items-center justify-center rounded-full border border-brass-300/30 text-brass-300">{item.icon}</span>
                <span className="num text-2xl text-sand-100/20">{item.step}</span>
              </div>
              <h3 className="mt-3 font-serif text-xl text-sand-100">{item.title}</h3>
              <p className="mt-2 text-[0.75rem] leading-relaxed text-sand-300/80">{item.body}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {item.keys.map((key) => (
                  <kbd key={key} className="rounded-sm border border-sand-100/18 bg-bark-900 px-2 py-1 font-condensed text-[0.6rem] uppercase tracking-[0.12em] text-sand-200">
                    {key}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_0.75fr]">
          <div className="rounded-sm border border-sand-100/10 p-4">
            <p className="eyebrow text-[0.5rem] text-brass-300">The assignment</p>
              <h3 className="mt-1.5 font-serif text-xl text-sand-100">Five drives. Thirty animals. One clean morning.</h3>
              <ul className="mt-3 space-y-2">
                {[
                  "Clear three of the five driven waves before last light.",
                  "Hunt four grounds — Ridge, Hollow, Frost Basin and Ember Draw.",
                  "Unlimited ammo is on by default; land one shot beyond 150 metres.",
                ].map((line, index) => (
                <li key={line} className="flex items-start gap-2.5 text-[0.75rem] leading-snug text-sand-200/85">
                  <span className="num mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full border border-brass-300/30 text-[0.55rem] text-brass-300">
                    {index + 1}
                  </span>
                  {line}
                </li>
              ))}
            </ul>
          </div>
          <div className="relative overflow-hidden rounded-sm border border-brass-500/20 bg-gradient-to-br from-brass-500/12 to-bark-900 p-4">
            <LockIcon size={18} className="text-brass-300" />
            <p className="mt-2 font-serif text-lg italic leading-snug text-sand-100">“The wilderness owes you nothing. Not even a shot.”</p>
            <p className="eyebrow mt-2 text-[0.46rem] text-sand-400">Guide’s code · art. 2</p>
          </div>
        </div>

        <div className="mt-4 flex flex-col items-start justify-between gap-3 rounded-sm border border-brass-300/25 bg-brass-300/6 p-3.5 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-brass-300/35 text-brass-300">
              <LocateIcon size={16} />
            </span>
            <div>
              <p className="font-condensed text-[0.76rem] uppercase tracking-[0.12em] text-sand-100">Android Option A · 4 maps · ∞ ammo</p>
              <p className="mt-0.5 text-[0.66rem] text-sand-400">Thumbstick to walk, drag to look, right-thumb fire. Switch grounds and ammo inside.</p>
            </div>
          </div>
          <button onClick={onControls} className="btn-ghost h-9 w-full shrink-0 px-4 text-[0.62rem] sm:w-auto">
            Adjust controls <ArrowRight size={12} />
          </button>
        </div>

        <div className="mt-4 flex flex-col items-center justify-between gap-3 border-t border-sand-100/10 pt-4 sm:flex-row">
          <p className="flex items-center gap-2 text-[0.68rem] text-sand-400">
            <BookIcon size={14} className="text-brass-300/80" />
            Your rifle and reserve ammunition are waiting at camp.
          </p>
          <button onClick={onStart} className="btn-primary h-11 w-full px-6 text-xs sm:w-auto">
            <PlayIcon size={12} /> Begin the hunt <ArrowRight size={13} />
          </button>
        </div>
      </div>
    </Shell>
  );
}

/* --------------------------------- generic -------------------------------- */

export function RestartHint({ onClose }: { onClose: () => void }) {
  return (
    <button onClick={onClose} className="btn-ghost h-10 px-4 text-[0.66rem]">
      <ReloadIcon size={13} /> Reset view
    </button>
  );
}
