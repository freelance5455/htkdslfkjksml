// Quick RBAC User Role Switcher Modal
import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { ROLE_PERMISSIONS } from '../../server/auth/roles';
import { User, RoleType } from '../../types';
import { X, Check, Shield, User as UserIcon } from 'lucide-react';

interface UserRoleSwitcherProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserRoleSwitcher: React.FC<UserRoleSwitcherProps> = ({ isOpen, onClose }) => {
  const { availableUsers, currentUser, switchUser } = useAuth();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800/80">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Switch Operator Role (RBAC Testing)</h2>
              <p className="text-[11px] text-slate-400">
                Select an authorized account to verify granular role permissions in real-time.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Role List */}
        <div className="p-5 space-y-2.5 max-h-[65vh] overflow-y-auto">
          {availableUsers.map((user) => {
            const isCurrent = currentUser?.id === user.id;
            const permsCount = ROLE_PERMISSIONS[user.role]?.length || 0;

            return (
              <button
                key={user.id}
                onClick={() => {
                  switchUser(user.id);
                  onClose();
                }}
                className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                  isCurrent
                    ? 'bg-emerald-950/40 border-emerald-600/80 text-white'
                    : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/60 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs ${
                      isCurrent ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-xs flex items-center gap-2">
                      {user.name}
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-emerald-400 border border-slate-700">
                        {user.role}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                      <span>Username: @{user.username}</span>
                      <span>•</span>
                      <span>{permsCount} Permissions</span>
                    </div>
                  </div>
                </div>

                {isCurrent && (
                  <div className="p-1 rounded-full bg-emerald-600 text-white">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/40 text-[11px] text-slate-400 flex items-center justify-between">
          <span>Password hashes & session tokens securely preserved</span>
          <button
            onClick={onClose}
            className="text-xs text-slate-300 hover:text-white font-medium underline"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
