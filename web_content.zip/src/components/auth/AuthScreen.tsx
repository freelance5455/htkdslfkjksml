import React, { useState } from 'react';
import { Shield, Lock, AtSign, User, AlertCircle, ArrowRight, Settings, Loader2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

type AuthScreenProps = {
  onOpenSetup: () => void;
};

export const AuthScreen: React.FC<AuthScreenProps> = ({ onOpenSetup }) => {
  const { login, register, isConfigured } = useAuth();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleUsernameChange = (raw: string) => {
    // If the browser or user autofills/pastes an email (e.g. name@domain.com) or @name:
    let val = raw.trim().toLowerCase();
    if (val.includes('@')) {
      // Strip everything from @ onwards to isolate pure local handle
      val = val.split('@')[0];
    }
    // Only allow letters, numbers, underscores, and periods (NO @ in stored username)
    const clean = val.replace(/[^a-z0-9_.]/g, '').slice(0, 24);
    setUsername(clean);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanUsername = username.trim().toLowerCase().replace(/^@+/, '');

    if (!cleanUsername) {
      setErrorMessage('Please enter your Nexa username.');
      return;
    }

    if (cleanUsername.length < 3 || cleanUsername.length > 24 || !/^[a-z0-9_.]+$/.test(cleanUsername)) {
      setErrorMessage('Username must be 3-24 characters and only contain letters, numbers, underscores or periods.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    if (mode === 'register') {
      if (!displayName.trim()) {
        setErrorMessage('Please enter a display name.');
        return;
      }
      if (password.length < 6) {
        setErrorMessage('Password must be at least 6 characters.');
        return;
      }
    }

    setLoading(true);

    try {
      if (mode === 'login') {
        await login(cleanUsername, password);
      } else {
        await register(cleanUsername, displayName.trim() || cleanUsername, password);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="auth-screen-container"
      className="min-h-screen w-full flex flex-col justify-center items-center bg-neutral-950 px-4 py-8 relative overflow-hidden"
    >
      {/* Subtle ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main card */}
      <div
        id="auth-card"
        className="w-full max-w-md bg-neutral-900/90 border border-neutral-800 rounded-3xl p-8 shadow-2xl backdrop-blur-xl relative z-10 space-y-6"
      >
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 mb-1 shadow-inner">
            <Shield className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Nexa Messenger</h1>
          <p className="text-xs text-neutral-400 max-w-xs mx-auto">
            End-to-end private 1-to-1 realtime messenger & calls
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex p-1 bg-neutral-950/80 rounded-2xl border border-neutral-800/80">
          <button
            id="tab-login"
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
              mode === 'login'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Sign In
          </button>
          <button
            id="tab-register"
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
              mode === 'register'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Error notification */}
        {errorMessage && (
          <div
            id="auth-error-alert"
            className="p-3.5 bg-red-500/10 border border-red-500/20 rounded-2xl text-xs text-red-400 flex items-start space-x-2.5 animate-in fade-in"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{errorMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} autoComplete="off" noValidate className="space-y-4">
          {/* Honeypot / Anti-autofill decoy */}
          <input
            type="text"
            name="prevent_browser_email_autofill"
            style={{ display: 'none' }}
            tabIndex={-1}
            autoComplete="off"
            aria-hidden="true"
          />

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="input-username" className="text-xs font-medium text-neutral-300">
                Username
              </label>
              <span className="text-[11px] text-neutral-500 font-mono">
                {username ? `@${username}` : '3–24 chars'}
              </span>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-emerald-400 font-mono font-semibold text-sm select-none">
                @
              </div>
              <input
                id="input-username"
                name="nexa_username"
                type="text"
                required
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                data-lpignore="true"
                data-1p-ignore="true"
                data-form-type="other"
                placeholder="username"
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                className="w-full pl-8 pr-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-mono"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label htmlFor="input-display-name" className="block text-xs font-medium text-neutral-300 mb-1.5">
                Display Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="input-display-name"
                  name="nexa_display_name"
                  type="text"
                  required
                  autoComplete="nickname"
                  placeholder="e.g. Samena"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          <div>
            <label htmlFor="input-password" className="block text-xs font-medium text-neutral-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="input-password"
                name="nexa_auth_key"
                type="password"
                required
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            {mode === 'register' && (
              <p className="text-[11px] text-neutral-500 mt-1">Minimum 6 characters</p>
            )}
          </div>

          <button
            id="btn-auth-submit"
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition-all shadow-lg shadow-emerald-950/40 flex items-center justify-center space-x-2 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Please wait...</span>
              </>
            ) : (
              <>
                <span>{mode === 'login' ? 'Sign In to Nexa' : 'Create Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Backend configuration prompt if not configured */}
        {!isConfigured && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-xs text-amber-300 flex items-center justify-between">
            <span>Supabase credentials not configured</span>
            <button
              id="btn-open-setup-warning"
              type="button"
              onClick={onOpenSetup}
              className="text-amber-400 font-semibold underline hover:text-amber-300"
            >
              Configure
            </button>
          </div>
        )}

        {/* Footer configuration button */}
        <div className="pt-2 text-center border-t border-neutral-800/60">
          <button
            id="btn-open-setup-footer"
            type="button"
            onClick={onOpenSetup}
            className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors inline-flex items-center space-x-1.5"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Supabase Connection & Database SQL</span>
          </button>
        </div>
      </div>
    </div>
  );
};
