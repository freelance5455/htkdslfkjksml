import React, { useState } from 'react';
import { X, AlertCircle, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { OmazifyLogo } from '../common/OmazifyLogo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'signup';
  initialMode?: 'login' | 'otp' | 'register' | string;
}

const GoogleGLogo: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path
      fill="#4285F4"
      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    />
    <path
      fill="#34A853"
      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
    />
    <path
      fill="#FBBC05"
      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
    />
    <path
      fill="#EA4335"
      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
    />
  </svg>
);

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { loginWithGoogle } = useAuth();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  const [activeAction, setActiveAction] = useState<'google' | null>(null);

  if (!isOpen) return null;

  const handleSignIn = async () => {
    try {
      setErrorMessage(null);
      setActiveAction('google');
      await loginWithGoogle();
      setSuccess(true);
      setTimeout(() => {
        onClose();
        setSuccess(false);
        setActiveAction(null);
      }, 700);
    } catch (err: unknown) {
      const friendlyMsg =
        err instanceof Error ? err.message : 'Unable to sign in. Please try again.';
      setErrorMessage(friendlyMsg);
      setActiveAction(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden my-auto border border-[#EAEAEA] flex flex-col animate-in zoom-in-95 duration-200">
        {/* Header: OMAZIFY Branding */}
        <div className="relative bg-[#000000] p-6 sm:p-7 text-white text-center overflow-hidden border-b border-neutral-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close login dialog"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="inline-block bg-white rounded-2xl p-2.5 shadow-sm mb-3">
            <OmazifyLogo size="md" showText={false} />
          </div>
          <div className="space-y-1">
            <span className="text-[10px] font-black uppercase tracking-widest text-[#FFD400]">
              OMAZIFY
            </span>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Welcome to OMAZIFY
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 font-medium">
              Sign in to continue securely
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 space-y-4">
          {success && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-900 font-semibold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>Signed in successfully! Welcome to OMAZIFY.</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-900 font-medium animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">
                <span>{errorMessage}</span>
              </div>
            </div>
          )}

          {/* Authentication Action Button */}
          <div className="space-y-3 pt-1">
            <button
              type="button"
              disabled={activeAction !== null}
              onClick={handleSignIn}
              className="w-full h-13 flex items-center justify-center gap-3 px-5 bg-white hover:bg-neutral-50 active:bg-neutral-100 text-[#111111] font-bold text-sm sm:text-base rounded-2xl border-2 border-[#EAEAEA] hover:border-[#000000] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed group"
            >
              {activeAction === 'google' ? (
                <Loader2 className="w-5 h-5 text-[#000000] animate-spin" />
              ) : (
                <GoogleGLogo className="w-5 h-5 group-hover:scale-105 transition-transform" />
              )}
              <span>Continue with Google</span>
            </button>
          </div>

          <div className="pt-3 border-t border-[#EAEAEA] space-y-1.5 text-center">
            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#111111]">
              <ShieldCheck className="w-4 h-4 text-[#FFD400]" />
              <span>Secure sign-in</span>
            </div>
            <p className="text-[11px] text-[#666666] leading-relaxed max-w-xs mx-auto">
              Your account is securely authenticated and protected.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
