import { useState } from 'react';
import { X, Lock, Mail, User, Phone, Globe, Shield, Sparkles } from 'lucide-react';
import { UserProfile, Language, Currency, UserRole } from '../../types';
import { translations } from '../../i18n/translations';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  language: Language;
}

export function AuthModal({ isOpen, onClose, currentUser, onUpdateUser, language }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'profile'>('login');
  const [formData, setFormData] = useState({
    fullName: currentUser.fullName,
    email: currentUser.email,
    phone: currentUser.phone,
    passportNumber: currentUser.passportNumber || '',
    nationality: currentUser.nationality,
    password: '',
    confirmPassword: '',
    role: currentUser.role,
    currency: currentUser.currency,
    language: currentUser.language,
  });
  const [successMessage, setSuccessMessage] = useState('');

  if (!isOpen) return null;

  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login' || mode === 'register' || mode === 'profile') {
      const updated: UserProfile = {
        ...currentUser,
        fullName: formData.fullName || currentUser.fullName,
        email: formData.email || currentUser.email,
        phone: formData.phone || currentUser.phone,
        passportNumber: formData.passportNumber || currentUser.passportNumber,
        nationality: formData.nationality || currentUser.nationality,
        role: formData.role,
        currency: formData.currency,
        language: formData.language,
        isLoggedIn: true,
      };
      onUpdateUser(updated);
      setSuccessMessage(language === 'ar' ? 'تم الحفظ وتحديث الحساب بنجاح!' : 'Profile saved successfully!');
      setTimeout(() => {
        setSuccessMessage('');
        onClose();
      }, 1000);
    } else if (mode === 'forgot') {
      setSuccessMessage(language === 'ar' ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.' : 'Password reset link sent to your email.');
      setTimeout(() => {
        setSuccessMessage('');
        setMode('login');
      }, 1800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-[#0a1027] border border-cyan-500/25 rounded-3xl p-6 text-white shadow-[0_10px_50px_rgba(0,102,255,0.35)] overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {mode === 'login' && (language === 'ar' ? 'تسجيل الدخول' : 'Sign In')}
                {mode === 'register' && (language === 'ar' ? 'إنشاء حساب جديد' : 'Create Account')}
                {mode === 'forgot' && (language === 'ar' ? 'استعادة كلمة المرور' : 'Reset Password')}
                {mode === 'profile' && (language === 'ar' ? 'تعديل الملف الشخصي' : 'Edit Profile')}
              </h3>
              <p className="text-[11px] text-cyan-400 font-mono">TAKI-GO Secure Identity</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success Alert */}
        {successMessage && (
          <div className="my-3 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          {(mode === 'register' || mode === 'profile') && (
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                {language === 'ar' ? 'الاسم الكامل' : 'Full Name'}
              </label>
              <div className="relative">
                <User className="absolute right-3 top-3 w-4 h-4 text-slate-500 rtl:right-3 ltr:left-3" />
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder={language === 'ar' ? 'أحمد بن علي' : 'Ahmed Benali'}
                  className="w-full h-11 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 rounded-xl px-9 text-xs text-white placeholder-slate-500 outline-none transition-colors"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs text-slate-300 mb-1">
              {language === 'ar' ? 'البريد الإلكتروني' : 'Email Address'}
            </label>
            <div className="relative">
              <Mail className="absolute right-3 top-3 w-4 h-4 text-slate-500 rtl:right-3 ltr:left-3" />
              <input
                type="email"
                required
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                placeholder="client@tourismbytaki.com"
                className="w-full h-11 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 rounded-xl px-9 text-xs text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>
          </div>

          {(mode === 'register' || mode === 'profile') && (
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-slate-300 mb-1">
                  {language === 'ar' ? 'رقم الهاتف' : 'Phone'}
                </label>
                <div className="relative">
                  <Phone className="absolute right-3 top-3 w-4 h-4 text-slate-500 rtl:right-3 ltr:left-3" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+213 550 00 00 00"
                    className="w-full h-11 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 rounded-xl px-9 text-xs text-white placeholder-slate-500 outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">
                  {language === 'ar' ? 'رقم جواز السفر' : 'Passport No.'}
                </label>
                <input
                  type="text"
                  value={formData.passportNumber}
                  onChange={e => setFormData({ ...formData, passportNumber: e.target.value })}
                  placeholder="21DZ9988..."
                  className="w-full h-11 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 rounded-xl px-3 text-xs text-white placeholder-slate-500 outline-none transition-colors uppercase font-mono"
                />
              </div>
            </div>
          )}

          {mode !== 'profile' && (
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                {language === 'ar' ? 'كلمة المرور' : 'Password'}
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-3 w-4 h-4 text-slate-500 rtl:right-3 ltr:left-3" />
                <input
                  type="password"
                  required
                  value={formData.password}
                  onChange={e => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••••••"
                  className="w-full h-11 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 rounded-xl px-9 text-xs text-white placeholder-slate-500 outline-none transition-colors"
                />
              </div>
            </div>
          )}

          {/* Account Role Selector (Client vs Agency Admin) */}
          <div className="pt-2 border-t border-slate-800">
            <label className="block text-xs text-slate-400 mb-1.5 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === 'ar' ? 'نوع الحساب / الصلاحيات' : 'Account Role'}</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, role: 'client' })}
                className={`py-2 px-3 rounded-xl text-xs font-medium border transition-colors ${
                  formData.role === 'client'
                    ? 'bg-blue-600/30 border-blue-400 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                {language === 'ar' ? '👤 مسافر (عميل)' : '👤 Traveler (Client)'}
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, role: 'agency_admin' })}
                className={`py-2 px-3 rounded-xl text-xs font-medium border transition-colors ${
                  formData.role === 'agency_admin'
                    ? 'bg-cyan-600/30 border-cyan-400 text-cyan-200'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                {language === 'ar' ? '🏢 وكيل Tourism By Taki' : '🏢 Agency Admin'}
              </button>
            </div>
          </div>

          {/* Primary Action Button */}
          <button
            type="submit"
            className="w-full h-11 mt-4 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-semibold text-xs tracking-wide shadow-[0_0_20px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.99] transition-all"
          >
            {mode === 'login' && (language === 'ar' ? 'تسجيل الدخول' : 'Sign In')}
            {mode === 'register' && (language === 'ar' ? 'إنشاء حساب جديد' : 'Create Account')}
            {mode === 'forgot' && (language === 'ar' ? 'إرسال رابط الاستعادة' : 'Send Reset Link')}
            {mode === 'profile' && (language === 'ar' ? 'حفظ التعديلات' : 'Save Changes')}
          </button>
        </form>

        {/* Footer Mode Switchers */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          {mode === 'login' ? (
            <>
              <button
                onClick={() => setMode('forgot')}
                className="hover:text-cyan-400 transition-colors"
              >
                {language === 'ar' ? 'نسيت كلمة المرور؟' : 'Forgot Password?'}
              </button>
              <button
                onClick={() => setMode('register')}
                className="text-cyan-400 font-semibold hover:underline"
              >
                {language === 'ar' ? 'إنشاء حساب جديد' : 'Sign Up'}
              </button>
            </>
          ) : (
            <button
              onClick={() => setMode('login')}
              className="text-cyan-400 font-semibold hover:underline w-full text-center"
            >
              {language === 'ar' ? 'العودة لتسجيل الدخول' : 'Back to Sign In'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
