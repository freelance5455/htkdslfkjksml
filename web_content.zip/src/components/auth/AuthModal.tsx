import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES, COUNTRY_CODES } from '../../services/api';
import { Smartphone, Mail, ShieldCheck, RefreshCw, KeyRound, ArrowRight, UserCheck, CheckCircle2, AlertCircle, X } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    currentUser,
    isAuthModalOpen,
    setAuthModalOpen,
    authModalTab,
    setAuthModalTab,
    login,
    availableDemoUsers,
    switchUser
  } = useAuth();

  // Mode: 'phone' or 'email'
  const [method, setMethod] = useState<'phone' | 'email'>('phone');
  const [countryCode, setCountryCode] = useState('+244');
  const [phoneOrEmail, setPhoneOrEmail] = useState('');
  const [step, setStep] = useState<'input' | 'verify' | 'profile'>('input');

  // Verification
  const [code, setCode] = useState('');
  const [devCode, setDevCode] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 mins
  const [timerActive, setTimerActive] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Profile setup after verification
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [province, setProvince] = useState('Luanda');
  const [bio, setBio] = useState('Orgulhosamente conectado ao Angola Connect 🇦🇴');

  // Countdown timer
  useEffect(() => {
    let interval: any;
    if (timerActive && countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    } else if (countdown === 0) {
      setTimerActive(false);
      setErrorMsg('O código de verificação expirou. Por favor solicite um novo.');
    }
    return () => clearInterval(interval);
  }, [timerActive, countdown]);

  if (!isAuthModalOpen && currentUser) return null;

  const fullPhone = method === 'phone' ? `${countryCode}${phoneOrEmail.replace(/\D/g, '')}` : phoneOrEmail.trim();

  // Send Code
  const handleSendCode = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!phoneOrEmail.trim()) {
      setErrorMsg(method === 'phone' ? 'Insira o seu número de telefone.' : 'Insira o seu endereço de e-mail.');
      return;
    }

    try {
      setIsSending(true);
      const res = await api.sendVerificationCode(fullPhone, countryCode);
      setSuccessMsg(res.message);
      if (res.devDebugCode) {
        setDevCode(res.devDebugCode);
      }
      setCountdown(300);
      setTimerActive(true);
      setStep('verify');
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSending(false);
    }
  };

  // Verify Code
  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!code || code.length !== 6) {
      setErrorMsg('O código de verificação deve conter 6 dígitos.');
      return;
    }

    try {
      setIsVerifying(true);
      const res = await api.verifyCode(fullPhone, code);

      if (res.userExists && res.user) {
        // User already has an account, log in
        setSuccessMsg('Verificação concluída com sucesso! A iniciar sessão...');
        setTimeout(() => {
          login(res.user);
        }, 600);
      } else {
        // Need to create profile
        setStep('profile');
      }
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsVerifying(false);
    }
  };

  // Finish Registration
  const handleRegisterProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!name.trim() || !username.trim()) {
      setErrorMsg('Preencha o seu nome e nome de utilizador (@).');
      return;
    }

    try {
      setIsVerifying(true);
      const res = await api.register({
        name,
        username,
        phone: method === 'phone' ? fullPhone : undefined,
        email: method === 'email' ? fullPhone : undefined,
        phoneCountryCode: countryCode,
        province,
        bio,
        avatar: '/src/assets/images/angola_user_manuel_1793388060300.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg'
      });

      setSuccessMsg('Conta criada com sucesso no Angola Connect! 🇦🇴');
      setTimeout(() => {
        login(res.user);
      }, 700);
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsVerifying(false);
    }
  };

  // Quick Direct Login
  const handleQuickLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!phoneOrEmail.trim()) {
      setErrorMsg('Insira o seu número, e-mail ou nome de utilizador.');
      return;
    }

    try {
      setIsVerifying(true);
      const res = await api.login(fullPhone);
      login(res.user);
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsVerifying(false);
    }
  };

  // Recovery
  const handleRecover = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!phoneOrEmail.trim()) {
      setErrorMsg('Insira o seu contacto registado.');
      return;
    }

    try {
      setIsVerifying(true);
      const res = await api.recoverAccount(fullPhone);
      setSuccessMsg(res.message);
      login(res.user);
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsVerifying(false);
    }
  };

  const minutes = Math.floor(countdown / 60);
  const seconds = countdown % 60;
  const formattedTimer = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-200">

        {/* Close button if user already logged in */}
        {currentUser && (
          <button
            onClick={() => setAuthModalOpen(false)}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-800/80 bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 via-amber-500 to-amber-400 flex items-center justify-center font-bold text-slate-950 text-xl shadow-lg shadow-amber-500/20">
              🇦🇴
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white font-display">ANGOLA CONNECT</h2>
              <p className="text-xs text-amber-400/90 font-medium">Conectando Angola ao mundo</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-5 p-1 bg-slate-950/60 rounded-xl border border-slate-800/60 text-xs font-medium">
            <button
              onClick={() => { setAuthModalTab('login'); setStep('input'); setErrorMsg(null); }}
              className={`flex-1 py-2 rounded-lg transition-all ${authModalTab === 'login' ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              Entrar
            </button>
            <button
              onClick={() => { setAuthModalTab('register'); setStep('input'); setErrorMsg(null); }}
              className={`flex-1 py-2 rounded-lg transition-all ${authModalTab === 'register' ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              Criar Conta
            </button>
            <button
              onClick={() => { setAuthModalTab('recover'); setStep('input'); setErrorMsg(null); }}
              className={`flex-1 py-2 rounded-lg transition-all ${authModalTab === 'recover' ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              Recuperar
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-4">

          {/* Error & Success Alerts */}
          {errorMsg && (
            <div className="flex items-start gap-2.5 p-3.5 bg-red-950/40 border border-red-800/60 rounded-xl text-red-300 text-xs leading-relaxed animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="flex items-start gap-2.5 p-3.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-emerald-300 text-xs leading-relaxed animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* TAB: REGISTER OR VERIFY STEP */}
          {authModalTab === 'register' && (
            <>
              {step === 'input' && (
                <form onSubmit={handleSendCode} className="space-y-4">
                  {/* Method Picker */}
                  <div className="flex items-center gap-2 p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs">
                    <button
                      type="button"
                      onClick={() => setMethod('phone')}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-md transition-colors ${method === 'phone' ? 'bg-slate-800 text-amber-400 font-medium' : 'text-slate-400'}`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      Número de Telefone (SMS)
                    </button>
                    <button
                      type="button"
                      onClick={() => setMethod('email')}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-md transition-colors ${method === 'email' ? 'bg-slate-800 text-amber-400 font-medium' : 'text-slate-400'}`}
                    >
                      <Mail className="w-3.5 h-3.5" />
                      E-mail
                    </button>
                  </div>

                  {method === 'phone' ? (
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">Número de Telefone</label>
                      <div className="flex gap-2">
                        <select
                          value={countryCode}
                          onChange={(e) => setCountryCode(e.target.value)}
                          className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500 shrink-0"
                        >
                          {COUNTRY_CODES.map((c) => (
                            <option key={c.code} value={c.code}>
                              {c.flag} {c.code}
                            </option>
                          ))}
                        </select>
                        <input
                          type="tel"
                          placeholder="923 000 000"
                          value={phoneOrEmail}
                          onChange={(e) => setPhoneOrEmail(e.target.value)}
                          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                          required
                        />
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1.5">
                        Irá receber um código SMS único com validade de 5 minutos.
                      </p>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">Endereço de E-mail</label>
                      <input
                        type="email"
                        placeholder="seu.nome@exemplo.ao"
                        value={phoneOrEmail}
                        onChange={(e) => setPhoneOrEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSending}
                    className="w-full h-11 bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    {isSending ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <>
                        <span>Enviar Código de Verificação</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* Step 2: Verify Code */}
              {step === 'verify' && (
                <form onSubmit={handleVerifyCode} className="space-y-4">
                  <div className="text-center space-y-1">
                    <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h3 className="text-sm font-semibold text-white">Introduza o Código de 6 Dígitos</h3>
                    <p className="text-xs text-slate-400">
                      Enviado para <span className="font-mono text-amber-400">{fullPhone}</span>
                    </p>
                  </div>

                  {/* Dev Sandbox Helper Note */}
                  {devCode && (
                    <div className="p-3 bg-amber-950/30 border border-amber-600/40 rounded-xl text-xs text-amber-200 flex items-center justify-between">
                      <span className="font-mono font-medium">SMS Simulado (Dev): {devCode}</span>
                      <button
                        type="button"
                        onClick={() => setCode(devCode)}
                        className="text-[11px] underline font-semibold text-amber-400 hover:text-white"
                      >
                        Auto-preencher
                      </button>
                    </div>
                  )}

                  <div>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="000000"
                      value={code}
                      onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-center tracking-[0.5em] font-mono text-2xl font-bold bg-slate-950 border border-slate-700 rounded-xl py-3 text-amber-400 focus:outline-none focus:border-amber-500"
                      autoFocus
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>
                      Expira em: <strong className="text-amber-400 font-mono">{formattedTimer}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => handleSendCode()}
                      disabled={isSending || countdown > 240}
                      className="text-amber-400 hover:underline disabled:opacity-40 disabled:no-underline"
                    >
                      Reenviar novo código
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={isVerifying || code.length !== 6}
                    className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    {isVerifying ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <>
                        <span>Validar Código</span>
                        <CheckCircle2 className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep('input')}
                    className="w-full text-xs text-slate-400 hover:text-white text-center py-1"
                  >
                    Alterar número ou e-mail
                  </button>
                </form>
              )}

              {/* Step 3: Profile Setup */}
              {step === 'profile' && (
                <form onSubmit={handleRegisterProfile} className="space-y-3.5">
                  <div className="text-center">
                    <h3 className="text-sm font-semibold text-white">Criar o seu Perfil no Angola Connect</h3>
                    <p className="text-xs text-slate-400">Contacto verificado com sucesso!</p>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Nome Completo</label>
                    <input
                      type="text"
                      placeholder="Ex: João Baptista"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Nome de Utilizador (@)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-500">@</span>
                      <input
                        type="text"
                        placeholder="joaobaptista"
                        value={username}
                        onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Província</label>
                    <select
                      value={province}
                      onChange={(e) => setProvince(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                    >
                      {ANGOLA_PROVINCES.filter(p => p !== 'Todas').map((p) => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Biografia</label>
                    <textarea
                      rows={2}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="w-full h-11 bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition-all active:scale-[0.98]"
                  >
                    {isVerifying ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <>
                        <span>Concluir e Entrar</span>
                        <CheckCircle2 className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </>
          )}

          {/* TAB: LOGIN */}
          {authModalTab === 'login' && (
            <form onSubmit={handleQuickLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Número de Telefone, E-mail ou @Username
                </label>
                <input
                  type="text"
                  placeholder="+244923000001 ou admin ou admin@angolaconnect.ao"
                  value={phoneOrEmail}
                  onChange={(e) => setPhoneOrEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {isVerifying ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                ) : (
                  <>
                    <span>Iniciar Sessão</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => { setAuthModalTab('recover'); setErrorMsg(null); }}
                  className="hover:text-amber-400 underline"
                >
                  Esqueceu-se do acesso?
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthModalTab('register'); setStep('input'); setErrorMsg(null); }}
                  className="hover:text-amber-400 font-medium"
                >
                  Criar conta nova
                </button>
              </div>
            </form>
          )}

          {/* TAB: RECOVER */}
          {authModalTab === 'recover' && (
            <form onSubmit={handleRecover} className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-10 h-10 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto">
                  <KeyRound className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-semibold text-white">Recuperação Segura de Conta</h3>
                <p className="text-xs text-slate-400">
                  Insira o número de telefone ou e-mail associado à sua conta.
                </p>
              </div>

              <div>
                <input
                  type="text"
                  placeholder="+244923000001 ou email@exemplo.ao"
                  value={phoneOrEmail}
                  onChange={(e) => setPhoneOrEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full h-11 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                {isVerifying ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <>
                    <span>Recuperar Conta</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* QUICK DEMO USER SWITCHER FOR IMMEDIATE MULTI-USER TESTING */}
          <div className="pt-4 border-t border-slate-800/80">
            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
              <span className="font-medium text-slate-300 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                Troca Rápida de Utilizador (Teste Multi-Utilizador Real):
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {availableDemoUsers.slice(0, 3).map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => switchUser(u)}
                  className={`flex flex-col items-center p-2 rounded-xl border text-center transition-all ${currentUser?.id === u.id ? 'bg-amber-500/10 border-amber-500/40 text-amber-300' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'}`}
                >
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-7 h-7 rounded-full object-cover mb-1 border border-slate-700"
                  />
                  <span className="text-[11px] font-semibold truncate w-full">{u.name.split(' ')[0]}</span>
                  <span className="text-[9px] text-slate-500 font-mono">@{u.username}</span>
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
