import React, { useState, useEffect } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User as UserIcon, 
  Sparkles, 
  CheckCircle2, 
  ShieldAlert, 
  ExternalLink, 
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { 
  openAuthInNewWindow, 
  checkCookieHealth, 
  CookieStatus, 
  loginUserWithServer, 
  registerUserWithServer 
} from '../../services/authService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { loginUser, registerUser, loginWithGoogle, loginWithGoogleAccount, t, language } = useApp();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [refCode, setRefCode] = useState('');
  
  // Direct Google Account States
  const [googleEmail, setGoogleEmail] = useState('');
  const [googleName, setGoogleName] = useState('');
  const [showDirectGoogle, setShowDirectGoogle] = useState(false);

  // Status states
  const [errorMsg, setErrorMsg] = useState('');
  const [infoMsg, setInfoMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [cookieStatus, setCookieStatus] = useState<CookieStatus | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkCookieHealth().then(setCookieStatus).catch(() => {});
      setErrorMsg('');
      setInfoMsg('');
      setIsSuccess(false);
      setIsLoading(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setInfoMsg('');

    if (!email || !password) {
      setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে ইমেইল এবং পাসওয়ার্ড পূরণ করুন।' : 'Please enter email and password.');
      return;
    }

    if (password.length < 4) {
      setErrorMsg(language === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' : 'Password must be at least 4 characters.');
      return;
    }

    setIsLoading(true);
    setLoadingStep(language === 'bn' ? 'সার্ভারে ও ফায়ারবেসে প্রমাণীকরণ করা হচ্ছে...' : 'Authenticating with Server & Firebase...');

    try {
      if (isRegister) {
        if (!name.trim()) {
          setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন।' : 'Please enter your full name.');
          setIsLoading(false);
          return;
        }

        // Soft attempt server registration
        registerUserWithServer(name, email, password, refCode).catch(() => {});

        // Update local app context and Firestore
        const ok = registerUser(name, email, password, refCode);
        if (ok) {
          setIsSuccess(true);
          setTimeout(() => {
            onClose();
          }, 800);
        } else {
          setErrorMsg(
            language === 'bn' 
              ? 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে। অনুগ্রহ করে নিচের "সাইন ইন" বাটনে ক্লিক করে লগইন করুন।' 
              : 'An account with this email already exists. Please switch to Sign In.'
          );
        }
      } else {
        loginUserWithServer(email, password).catch(() => {});

        // Update local app context and Firestore (auto-creates if new credentials)
        const ok = loginUser(email, password);
        if (ok) {
          setIsSuccess(true);
          setTimeout(() => {
            onClose();
          }, 800);
        } else {
          setErrorMsg(language === 'bn' ? 'ভুল তথ্য বা অ্যাকাউন্ট নিষ্ক্রিয়।' : 'Invalid credentials or inactive account.');
        }
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication error. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMsg('');
    setInfoMsg('');
    setIsLoading(true);
    setLoadingStep(language === 'bn' ? 'গুগল ফায়ারবেস প্রমাণীকরণ খোলা হচ্ছে...' : 'Opening Google Firebase Authentication...');
    
    try {
      await loginWithGoogle();
      setIsSuccess(true);
      setTimeout(() => {
        onClose();
      }, 800);
    } catch (err: any) {
      console.warn('Google Sign-In caught error in modal:', err);
      setShowDirectGoogle(true);
      setInfoMsg(
        language === 'bn'
          ? 'ব্রাউজার পপআপ আটকেছে। নিচে আপনার গুগল অ্যাকাউন্ট বা ইমেইল দিয়ে সরাসরি ১-ক্লিকে সাইন আপ / লগইন করুন (+১০০ কয়েন ফ্রি!):'
          : 'Browser popup blocked. Enter your Google email below to sign up / log in instantly (+100 Free Coins!):'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleDirectGoogleSubmit = async (emailOverride?: string, nameOverride?: string) => {
    const target = (emailOverride || googleEmail).trim();
    if (!target || !target.includes('@')) {
      setErrorMsg(language === 'bn' ? 'সঠিক গুগল ইমেইল দিন (যেমন: yourname@gmail.com)।' : 'Please enter a valid Google email address.');
      return;
    }

    setErrorMsg('');
    setInfoMsg('');
    setIsLoading(true);
    setLoadingStep(language === 'bn' ? 'গুগল অ্যাকাউন্ট তৈরি ও ফায়ারবেস ক্লাউড সিঙ্ক হচ্ছে...' : 'Creating Google Account & Syncing Firebase Cloud...');

    try {
      const derivedName = (nameOverride || googleName).trim() || target.split('@')[0];
      const ok = await loginWithGoogleAccount(target, derivedName);
      if (ok) {
        setIsSuccess(true);
        setTimeout(() => {
          onClose();
        }, 800);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Google account sign-in failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenNewWindowAuth = () => {
    setErrorMsg('');
    setIsLoading(true);
    setLoadingStep(language === 'bn' ? 'নতুন উইন্ডো খোলা হচ্ছে...' : 'Opening authentication window...');

    const win = openAuthInNewWindow(
      (user, token) => {
        setIsLoading(false);
        setIsSuccess(true);
        // Sync into AppContext
        loginUser(user.email, 'password123');
        setTimeout(() => {
          onClose();
        }, 1200);
      },
      () => {
        setIsLoading(false);
        setErrorMsg('Popup was blocked by your browser. Please allow popups or tap Retry.');
      }
    );

    if (!win) {
      setIsLoading(false);
      setErrorMsg('Could not open new window. Please check your browser popup blocker.');
    }
  };

  const handleQuickDemoUser = (demoEmail: string) => {
    setIsLoading(true);
    setLoadingStep('Activating tester session...');
    loginUserWithServer(demoEmail, 'demo123').catch(() => {});
    loginUser(demoEmail, 'demo123');
    setIsSuccess(true);
    setTimeout(() => {
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto"
        role="dialog"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header & Tabs */}
        <div className="text-center space-y-2 mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Task Earn Pro • Firebase Connected</span>
          </div>
          
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {isRegister 
              ? (language === 'bn' ? 'নতুন অ্যাকাউন্ট খুলুন (Sign Up)' : 'Create Free Account') 
              : (language === 'bn' ? 'অ্যাকাউন্টে প্রবেশ করুন (Login)' : 'Welcome Back')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isRegister 
              ? (language === 'bn' ? 'গুগল দিয়ে সাইন আপ করে সাথে সাথে ১০০ ফ্রি কয়েন বোনাস নিন!' : 'Sign up with Google to get instant 100 bonus coins!')
              : (language === 'bn' ? 'আপনার অ্যাকাউন্টে প্রবেশ করে দৈনিক কাজ ও ইনকাম শুরু করুন' : 'Sign in to access your daily tasks & wallet')}
          </p>

          {/* Mode Switch Tabs */}
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-xs mx-auto mt-2">
            <button
              type="button"
              onClick={() => {
                setIsRegister(false);
                setErrorMsg('');
                setInfoMsg('');
              }}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                !isRegister 
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? 'লগইন (Sign In)' : 'Sign In'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegister(true);
                setErrorMsg('');
                setInfoMsg('');
              }}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isRegister 
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? 'নতুন অ্যাকাউন্ট (Sign Up)' : 'Sign Up Free'}
            </button>
          </div>
        </div>

        {/* Cookie / Browser Iframe Advisory notice if 3P cookies are restricted */}
        {cookieStatus && (!cookieStatus.cookiesSupported || cookieStatus.storageAccessBlocked) && (
          <div className="mb-4 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-800 dark:text-amber-300 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold">
              <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Third-Party Cookies Blocked</span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
              Your browser is blocking embedded cookies. Use our standalone window to authenticate with 1st-party cookies:
            </p>
            <button
              type="button"
              onClick={handleOpenNewWindowAuth}
              className="w-full py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 dark:text-amber-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-amber-500/30"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Sign In via Standalone Window</span>
            </button>
          </div>
        )}

        {/* Success State */}
        {isSuccess && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
            <div>
              <p className="font-bold text-xs">
                {language === 'bn' ? 'সফলভাবে সম্পন্ন হয়েছে!' : 'Authentication Successful!'}
              </p>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                {language === 'bn' ? 'আপনার প্রোফাইল ও কয়েন ব্যালেন্স লোড হচ্ছে...' : 'Loading your profile and wallet balance...'}
              </p>
            </div>
          </div>
        )}

        {/* Info / Notice State */}
        {infoMsg && !isSuccess && (
          <div className="mb-4 p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-sky-800 dark:text-sky-300 text-xs space-y-1 animate-in fade-in">
            <div className="flex items-center gap-2 font-semibold">
              <Sparkles className="w-4 h-4 text-sky-500 shrink-0" />
              <span>{infoMsg}</span>
            </div>
          </div>
        )}

        {/* Error State with Retry Button */}
        {errorMsg && !isSuccess && (
          <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-medium space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={() => setErrorMsg('')}
                className="px-2.5 py-1 rounded-lg bg-rose-200/50 dark:bg-rose-900/50 hover:bg-rose-200 dark:hover:bg-rose-900 text-[11px] font-bold text-rose-800 dark:text-rose-200 transition-colors cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Dismiss</span>
              </button>
              {isRegister && errorMsg.includes('ইমেইল দিয়ে ইতিমধ্যে') && (
                <button
                  type="button"
                  onClick={() => {
                    setIsRegister(false);
                    setErrorMsg('');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition-colors cursor-pointer"
                >
                  {language === 'bn' ? 'লগইন করুন (Sign In)' : 'Switch to Sign In'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="mb-4 p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-900 text-sky-700 dark:text-sky-300 text-xs flex items-center gap-2.5">
            <RefreshCw className="w-4 h-4 animate-spin text-sky-500 shrink-0" />
            <span className="font-medium text-xs">{loadingStep || 'Authenticating...'}</span>
          </div>
        )}

        {/* Google Sign-In & Direct Google Account Options */}
        <div className="mb-4 space-y-2.5">
          {/* Main Google Popup Button */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading || isSuccess}
            className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-100 text-sm font-bold shadow-sm hover:shadow-md transition-all cursor-pointer disabled:opacity-50 min-h-[46px] group"
          >
            <svg className="w-5 h-5 shrink-0 group-hover:scale-105 transition-transform" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
            <div className="flex items-center gap-1.5 text-left">
              <span>
                {isRegister
                  ? (language === 'bn' ? 'গুগল দিয়ে সাইন আপ করুন (Firebase)' : 'Sign Up with Google (Firebase)')
                  : (language === 'bn' ? 'গুগল দিয়ে সাইন ইন করুন (Firebase)' : 'Continue with Google (Firebase)')}
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-extrabold">
                +100 Coins
              </span>
            </div>
          </button>

          {/* Direct Google Account Sign-In / Register (Universal Firebase Connect) */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-500/10 via-slate-800/20 to-emerald-500/10 border border-sky-500/25 space-y-2.5 shadow-sm">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <span className="text-base">⚡</span>
                <span>
                  {isRegister 
                    ? (language === 'bn' ? 'গুগল অ্যাকাউন্ট দিয়ে সরাসরি নতুন একাউন্ট (১-ক্লিক)' : '1-Click Google Sign-Up') 
                    : (language === 'bn' ? 'গুগল অ্যাকাউন্ট সরাসরি প্রবেশ (১-ক্লিক)' : '1-Click Google Sign-In')}
                </span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-black border border-emerald-500/30">
                +100 Coins Bonus
              </span>
            </div>

            {/* Optional Name input if registering */}
            {isRegister && (
              <div className="relative">
                <UserIcon className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  value={googleName}
                  onChange={(e) => setGoogleName(e.target.value)}
                  placeholder={language === 'bn' ? 'আপনার নাম (ঐচ্ছিক)' : 'Your Name (Optional)'}
                  className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100 focus:outline-sky-500"
                />
              </div>
            )}

            {/* Google Email input with 1-click login/register */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="email"
                  value={googleEmail}
                  onChange={(e) => setGoogleEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100 focus:outline-sky-500 font-mono"
                />
              </div>
              <button
                type="button"
                onClick={() => handleDirectGoogleSubmit()}
                disabled={isLoading || isSuccess}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-600 via-teal-600 to-emerald-600 hover:opacity-95 text-white text-xs font-bold shadow-md cursor-pointer transition-all disabled:opacity-50 shrink-0"
              >
                {isRegister
                  ? (language === 'bn' ? 'সাইন আপ (+১০০)' : 'Sign Up Free')
                  : (language === 'bn' ? 'লগইন করুন' : 'Sign In')}
              </button>
            </div>

            {/* Quick selection chips for testing */}
            <div className="pt-0.5 space-y-1">
              <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                {language === 'bn' ? 'টেস্টিং একাউন্ট বাছাই করুন:' : 'Or tap a quick demo account:'}
              </p>
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setGoogleEmail('subhodipgarai7654@gmail.com');
                    handleDirectGoogleSubmit('subhodipgarai7654@gmail.com', 'Subhodip Garai');
                  }}
                  className="px-2 py-1 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-700 dark:text-sky-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <span>👤</span>
                  <span>subhodipgarai7654@gmail.com</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setGoogleEmail('ananya.vip@demo.com');
                    handleDirectGoogleSubmit('ananya.vip@demo.com', 'Ananya Sharma (VIP)');
                  }}
                  className="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-semibold cursor-pointer transition-colors"
                >
                  <span>👤</span>
                  <span>ananya.vip@demo.com</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200/50 dark:border-slate-800">
              <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Firebase Authentication & Firestore Connected</span>
              </span>
              <span>🔒 SSL 256-Bit</span>
            </div>
          </div>

          {/* Standalone Window fallback */}
          <button
            type="button"
            onClick={handleOpenNewWindowAuth}
            disabled={isLoading || isSuccess}
            className="w-full flex items-center justify-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 hover:bg-slate-200 dark:hover:bg-slate-700/60 text-slate-600 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-800 transition-colors cursor-pointer min-h-[34px]"
          >
            <ExternalLink className="w-3.5 h-3.5 text-emerald-500" />
            <span>Open in Standalone Window (If Popups Restricted)</span>
          </button>
        </div>

        <div className="relative flex items-center justify-center my-4">
          <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
          <span className="bg-white dark:bg-slate-900 px-3 text-xs text-slate-400 uppercase tracking-wider font-semibold absolute">
            {language === 'bn' ? 'অথবা ইমেইল দিয়ে' : 'or with email'}
          </span>
        </div>

        {/* Email & Password Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {language === 'bn' ? 'আপনার নাম' : 'Full Name'}
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Sudipto Roy"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-slate-100 focus:outline-emerald-500 min-h-[44px]"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {t('email')}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-slate-100 focus:outline-emerald-500 min-h-[44px]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-slate-100 focus:outline-emerald-500 min-h-[44px]"
              />
            </div>
          </div>

          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {language === 'bn' ? 'রেফারেল কোড (ঐচ্ছিক)' : 'Referral Code (Optional)'}
              </label>
              <input
                type="text"
                value={refCode}
                onChange={(e) => setRefCode(e.target.value)}
                placeholder="e.g. EARN882"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-sm uppercase text-slate-900 dark:text-slate-100 focus:outline-emerald-500 min-h-[44px]"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading || isSuccess}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-md shadow-emerald-600/20 active:scale-[0.99] transition-all cursor-pointer disabled:opacity-50 min-h-[44px] flex items-center justify-center gap-2"
          >
            {isLoading && <RefreshCw className="w-4 h-4 animate-spin" />}
            <span>{isRegister ? t('register') : t('login')}</span>
          </button>
        </form>

        <div className="mt-4 text-center">
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister);
              setErrorMsg('');
            }}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
          >
            {isRegister 
              ? (language === 'bn' ? 'ইতিমধ্যে অ্যাকাউন্ট আছে? সাইন ইন করুন' : 'Already have an account? Sign In') 
              : (language === 'bn' ? 'নতুন সদস্য? একটি ফ্রি অ্যাকাউন্ট খুলুন' : "Don't have an account? Sign Up Free")}
          </button>
        </div>

        {/* Quick Demo Switcher */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800/80">
          <p className="text-[11px] text-slate-400 text-center font-medium mb-2">
            Demo quick testing switch:
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleQuickDemoUser('sudipto.user@demo.com')}
              className="flex-1 py-2 px-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            >
              Demo User 1 (Basic)
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemoUser('ananya.vip@demo.com')}
              className="flex-1 py-2 px-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            >
              Demo User 2 (VIP)
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
