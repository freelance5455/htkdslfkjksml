import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { UserRole } from '../../types';
import { KARACHI_AREAS } from '../../utils/geo';
import { authService } from '../../services/authService';
import { adminService } from '../../services/adminService';
import {
  X,
  User,
  Wrench,
  ShieldCheck,
  Lock,
  Phone,
  Mail,
  MapPin,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  KeyRound,
  ShieldAlert,
  Settings,
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    showAuthModal,
    closeAuthModal,
    authModalConfig,
    loginUser,
    adminLoginUser,
    registerUser,
    categories,
    selectedArea,
  } = useMohalla();

  // Role selection: 'customer' | 'provider' | 'admin'
  const [selectedRole, setSelectedRole] = useState<UserRole>(authModalConfig.role || 'customer');
  // Mode: 'login' | 'signup' | 'forgot' | 'admin_setup'
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot' | 'admin_setup'>(authModalConfig.mode || 'login');

  // Common Form Fields
  const [identifier, setIdentifier] = useState(''); // email, username, or phone
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [area, setArea] = useState(selectedArea.name);

  // Provider-Specific Fields
  const [businessName, setBusinessName] = useState('');
  const [providerCategory, setProviderCategory] = useState('electrician');
  const [subServices, setSubServices] = useState('Wiring & Breakers, Short Circuit Repair, Ceiling Fan');
  const [visitCharge, setVisitCharge] = useState(500);
  const [cnicMasked, setCnicMasked] = useState('42101-*******-5');

  // Admin Custom Setup Fields
  const [setupUsername, setSetupUsername] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [setupPassword, setSetupPassword] = useState('');

  // Forgot Password / OTP State
  const [resetStep, setResetStep] = useState<1 | 2>(1);
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otpSentNotice, setOtpSentNotice] = useState<string | null>(null);

  // Status & Error
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!showAuthModal) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      if (selectedRole === 'admin') {
        await adminLoginUser(identifier, password);
      } else {
        await loginUser(identifier, password, selectedRole);
      }
      setSuccessMessage('Authentication verified successfully! Opening dashboard...');
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed. Please verify your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      if (selectedRole === 'admin') {
        throw new Error('Admin registration is strictly forbidden via public sign up.');
      }

      await registerUser({
        name,
        phone,
        email: email || undefined,
        password,
        role: selectedRole,
        city: 'Karachi',
        area,
        providerDetails:
          selectedRole === 'provider'
            ? {
                businessName: businessName || `${name} Services`,
                category: providerCategory,
                subServices: subServices.split(',').map((s) => s.trim()).filter(Boolean),
                visitCharge: Number(visitCharge) || 500,
                cnicMasked: cnicMasked || '42101-*******-1',
                serviceAreas: [area, 'PECHS', 'Clifton'],
              }
            : undefined,
      });

      setSuccessMessage('Account created and logged in successfully!');
    } catch (err: any) {
      setErrorMessage(err.message || 'Registration failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdminSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await adminService.setupAdminCredentials({
        username: setupUsername,
        email: setupEmail,
        password: setupPassword,
      });
      setSuccessMessage(res.message || 'Admin account successfully configured on the server!');
      setIdentifier(setupUsername || setupEmail);
      setPassword(setupPassword);
      setMode('login');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to configure admin credentials on the server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await authService.requestPasswordReset(resetIdentifier);
      setOtpSentNotice(res.message);
      if (res.testOtp) {
        setOtpCode(res.testOtp);
      }
      setResetStep(2);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to send OTP code.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      await authService.resetPassword(resetIdentifier, otpCode, newPassword);
      setSuccessMessage('Password reset successfully! Please log in now.');
      setMode('login');
      setPassword(newPassword);
      setIdentifier(resetIdentifier);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to reset password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header with App Branding & Close */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-sm">
              M
            </div>
            <div>
              <h2 className="text-base font-bold flex items-center gap-1.5">
                <span>Welcome to Mohalla</span>
                <span className="text-[10px] font-bold bg-emerald-500/30 text-emerald-300 px-1.5 py-0.2 rounded uppercase">
                  PK
                </span>
              </h2>
              <p className="text-[11px] text-slate-300">Trusted Local Services in Pakistan</p>
            </div>
          </div>

          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 3 ROLE SELECTOR TABS (Customer, Service Provider, Admin) */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 shrink-0">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 px-1">
            Select User Portal:
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {/* 1. Customer */}
            <button
              type="button"
              onClick={() => {
                setSelectedRole('customer');
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`p-2 sm:p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                selectedRole === 'customer'
                  ? 'border-emerald-600 bg-white text-emerald-950 font-bold shadow-xs ring-2 ring-emerald-500/20'
                  : 'border-slate-200 hover:bg-white/80 text-slate-600'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                  selectedRole === 'customer'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                <User className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs">Customer</span>
            </button>

            {/* 2. Service Provider */}
            <button
              type="button"
              onClick={() => {
                setSelectedRole('provider');
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`p-2 sm:p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                selectedRole === 'provider'
                  ? 'border-amber-500 bg-white text-amber-950 font-bold shadow-xs ring-2 ring-amber-500/20'
                  : 'border-slate-200 hover:bg-white/80 text-slate-600'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                  selectedRole === 'provider'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                <Wrench className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs">Technician</span>
            </button>

            {/* 3. Admin (Clearly Visible) */}
            <button
              type="button"
              onClick={() => {
                setSelectedRole('admin');
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`p-2 sm:p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                selectedRole === 'admin'
                  ? 'border-purple-600 bg-white text-purple-950 font-bold shadow-xs ring-2 ring-purple-500/20'
                  : 'border-slate-200 hover:bg-white/80 text-slate-600'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                  selectedRole === 'admin'
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs">Admin Login</span>
            </button>
          </div>
        </div>

        {/* Mode Switcher: Login / Sign Up */}
        {selectedRole !== 'admin' && mode !== 'forgot' && (
          <div className="flex border-b border-slate-200 bg-white text-xs font-bold text-slate-500 shrink-0">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
              }}
              className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
                mode === 'login'
                  ? 'border-emerald-600 text-emerald-800'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Log In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('signup');
                setErrorMessage(null);
              }}
              className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
                mode === 'signup'
                  ? 'border-emerald-600 text-emerald-800'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              {selectedRole === 'provider' ? 'Register as Technician' : 'Create Customer Account'}
            </button>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* Alerts */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">Authentication Notice</span>
                <span className="leading-snug">{errorMessage}</span>
              </div>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">Success</span>
                <span className="leading-snug">{successMessage}</span>
              </div>
            </div>
          )}

          {/* 1. REAL ADMIN LOGIN FORM */}
          {selectedRole === 'admin' && mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-purple-50 border border-purple-200 text-purple-900">
                <span className="font-bold flex items-center gap-1.5 text-xs text-purple-950">
                  <ShieldCheck className="w-4 h-4 text-purple-700" />
                  Real Server-Side Administrative Authentication
                </span>
                <p className="text-[11px] text-purple-800 mt-1 leading-relaxed">
                  Credentials are authenticated on the backend server using salted cryptographic scrypt hashing. Passwords are never exposed in JavaScript or APK assets.
                </p>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Admin Username or Email <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Enter admin username or email"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-purple-600 outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Admin Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your secure password"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-purple-600 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md cursor-pointer transition-all disabled:opacity-50"
                >
                  {isLoading ? 'Verifying Credentials on Server...' : 'Log In to Admin Operations HQ'}
                </button>
              </div>

              {/* Server Admin Configuration Helper */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Need to initialize or update Admin credentials?</span>
                <button
                  type="button"
                  onClick={() => {
                    setMode('admin_setup');
                    setErrorMessage(null);
                  }}
                  className="font-bold text-purple-700 hover:underline cursor-pointer flex items-center gap-1"
                >
                  <Settings className="w-3 h-3" />
                  <span>Configure Admin</span>
                </button>
              </div>
            </form>
          )}

          {/* 1B. ADMIN SERVER INITIAL SETUP FORM */}
          {selectedRole === 'admin' && mode === 'admin_setup' && (
            <form onSubmit={handleAdminSetup} className="space-y-3.5 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-purple-950 text-sm">Configure Admin Credentials</span>
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-purple-700 hover:underline font-semibold"
                >
                  Back to Login
                </button>
              </div>

              <p className="text-slate-500 leading-relaxed text-[11px]">
                This updates the primary administrative account directly in the persistent SQLite database using salted scrypt hashing.
              </p>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Admin Username <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={setupUsername}
                  onChange={(e) => setSetupUsername(e.target.value)}
                  placeholder="e.g. admin or operations_head"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Admin Official Email <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={setupEmail}
                  onChange={(e) => setSetupEmail(e.target.value)}
                  placeholder="e.g. admin@mohalla.pk or aliakberchutta12@gmail.com"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  New Admin Secure Password <span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={setupPassword}
                  onChange={(e) => setSetupPassword(e.target.value)}
                  placeholder="Enter strong password"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold shadow-md cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? 'Saving...' : 'Save to Database'}
                </button>
              </div>
            </form>
          )}

          {/* 2. CUSTOMER / PROVIDER LOGIN FORM */}
          {selectedRole !== 'admin' && mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Mobile Number or Email <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="0300-XXXXXXX or user@email.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700">
                    Password <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      setResetIdentifier(identifier);
                    }}
                    className="text-[11px] text-emerald-700 hover:underline font-semibold"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-3 rounded-xl text-white font-bold text-xs shadow-md cursor-pointer transition-all disabled:opacity-50 ${
                    selectedRole === 'provider'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'bg-emerald-700 hover:bg-emerald-800'
                  }`}
                >
                  {isLoading
                    ? 'Authenticating...'
                    : `Log In as ${selectedRole === 'provider' ? 'Technician' : 'Customer'}`}
                </button>
              </div>
            </form>
          )}

          {/* 3. SIGN UP FORM (Customer or Provider) */}
          {selectedRole !== 'admin' && mode === 'signup' && (
            <form onSubmit={handleRegister} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Tariq Mehmood"
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Mobile Phone <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="03XX-XXXXXXX"
                      className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Karachi Neighborhood <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden font-medium"
                  >
                    {KARACHI_AREAS.map((a) => (
                      <option key={a.id} value={a.name}>
                        {a.name} ({a.zone})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Email Address (Optional)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@email.com"
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Create Password (min 6 characters) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2 rounded-xl border border-slate-300 text-slate-900 text-xs focus:border-emerald-600 outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* EXTRA FIELDS FOR SERVICE PROVIDER SIGN UP */}
              {selectedRole === 'provider' && (
                <div className="pt-2 border-t border-slate-200 space-y-3">
                  <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider block">
                    🔧 Technician Business Profile
                  </span>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Business or Workshop Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      placeholder="e.g. Tariq Electric & Inverter Care"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        Primary Category <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={providerCategory}
                        onChange={(e) => setProviderCategory(e.target.value)}
                        className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs capitalize"
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        Base Visit Fee (PKR) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="number"
                        min="200"
                        step="50"
                        required
                        value={visitCharge}
                        onChange={(e) => setVisitCharge(Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Sub-Services & Skills (comma separated)
                    </label>
                    <input
                      type="text"
                      value={subServices}
                      onChange={(e) => setSubServices(e.target.value)}
                      placeholder="Wiring, Breakers, Fan Fixing, Short Circuit"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Masked CNIC Format (for verification identity)
                    </label>
                    <input
                      type="text"
                      value={cnicMasked}
                      onChange={(e) => setCnicMasked(e.target.value)}
                      placeholder="42101-*******-5"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900 text-xs font-mono"
                    />
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Full document will be reviewed securely by Admin in KYC queue.
                    </p>
                  </div>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-3 rounded-xl text-white font-bold text-xs shadow-md cursor-pointer transition-all disabled:opacity-50 ${
                    selectedRole === 'provider'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'bg-emerald-700 hover:bg-emerald-800'
                  }`}
                >
                  {isLoading
                    ? 'Creating Account...'
                    : selectedRole === 'provider'
                    ? 'Complete Technician Registration'
                    : 'Create Customer Account'}
                </button>
              </div>
            </form>
          )}

          {/* 4. FORGOT PASSWORD FLOW */}
          {mode === 'forgot' && (
            <div className="space-y-3.5 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-800">Password Recovery</span>
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-emerald-700 hover:underline font-semibold"
                >
                  Back to Login
                </button>
              </div>

              {resetStep === 1 ? (
                <form onSubmit={handleRequestOtp} className="space-y-3">
                  <p className="text-slate-500">
                    Enter the phone number or email registered with your Mohalla account:
                  </p>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Registered Phone / Email</label>
                    <input
                      type="text"
                      required
                      value={resetIdentifier}
                      onChange={(e) => setResetIdentifier(e.target.value)}
                      placeholder="0300-8245199 or email"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer"
                  >
                    {isLoading ? 'Sending Code...' : 'Send Verification Code'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetPassword} className="space-y-3">
                  {otpSentNotice && (
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                      {otpSentNotice}
                    </div>
                  )}

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Enter 6-Digit Verification Code
                    </label>
                    <input
                      type="text"
                      required
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      placeholder="123456"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 font-mono tracking-widest text-center text-sm font-bold"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">New Password</label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new secure password"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer"
                  >
                    {isLoading ? 'Updating Password...' : 'Save New Password & Login'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
