import React, { useState } from 'react';
import {
  Mail,
  Lock,
  Cloud,
  CheckCircle,
  AlertCircle,
  LogOut,
  RefreshCw,
  X,
  Sparkles,
  Smartphone,
  ShieldCheck,
  User as UserIcon,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const {
    currentUser,
    isSyncing,
    lastSyncTime,
    loginWithGoogleAction,
    loginWithEmailAction,
    registerWithEmailAction,
    logoutAction,
    triggerManualSync,
    cloudSyncError,
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await loginWithGoogleAction();
      setSuccessMsg('تم تسجيل الدخول وربط الحساب بنجاح!');
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'تعذر تسجيل الدخول بواسطة Google';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email.trim() || !password.trim()) {
      setErrorMsg('يرجى كتابة البريد الإلكتروني وكلمة المرور.');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('كلمة المرور يجب ألا تقل عن 6 أحرف.');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signin') {
        await loginWithEmailAction(email, password);
        setSuccessMsg('تم تسجيل الدخول وتحديث المزامنة السحابية بنجاح!');
      } else {
        await registerWithEmailAction(email, password);
        setSuccessMsg('تم إنشاء الحساب وربط بياناتك بالسحابة بنجاح!');
      }
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: unknown) {
      let msg = 'حدث خطأ أثناء المصادقة';
      if (err instanceof Error) {
        if (err.message.includes('auth/invalid-credential') || err.message.includes('wrong-password')) {
          msg = 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
        } else if (err.message.includes('email-already-in-use')) {
          msg = 'هذا البريد مسجل بالفعل، يمكنك تسجيل الدخول به.';
        } else if (err.message.includes('invalid-email')) {
          msg = 'صيغة البريد الإلكتروني غير صحيحة.';
        } else {
          msg = err.message;
        }
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncNow = async () => {
    setErrorMsg(null);
    try {
      await triggerManualSync();
      setSuccessMsg('تمت مزامنة جميع البيانات مع السحابة بنجاح!');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'فشلت المزامنة');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-white dark:bg-[#1c101a] rounded-3xl shadow-2xl border border-rose-200/60 dark:border-rose-900/40 overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 p-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Cloud className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold">ربط الحساب بالميل للمزامنة</h2>
              <p className="text-xs text-rose-100">
                حفظ بياناتك والوصول إليها من أي هاتف أندرويد أو جهاز
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          {currentUser ? (
            /* Logged in state */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-rose-500 to-pink-400 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                  {currentUser.displayName
                    ? currentUser.displayName.charAt(0).toUpperCase()
                    : currentUser.email?.charAt(0).toUpperCase() || 'U'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
                      متصل ومزامن
                    </span>
                    <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  </div>
                  <p className="font-semibold text-slate-900 dark:text-rose-100 truncate mt-1">
                    {currentUser.displayName || 'مستخدم يومي المنظم'}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-rose-300/80 truncate font-mono">
                    {currentUser.email}
                  </p>
                </div>
              </div>

              {/* Sync status info */}
              <div className="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-600 dark:text-rose-200/80">
                  <span>حالة المزامنة السحابية:</span>
                  <span className="font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    محفوظ في السحابة
                  </span>
                </div>
                {lastSyncTime && (
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                    <span>آخر مزامنة ناجحة:</span>
                    <span className="font-mono tabular-nums">{lastSyncTime}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={handleSyncNow}
                  disabled={isSyncing}
                  className="w-full py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-medium text-sm flex items-center justify-center gap-2 shadow-sm shadow-rose-500/25 transition disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'جارٍ المزامنة الآن...' : 'مزامنة البيانات الآن'}</span>
                </button>

                <button
                  onClick={async () => {
                    await logoutAction();
                    setSuccessMsg('تم تسجيل الخروج بنجاح');
                  }}
                  className="w-full py-2.5 px-4 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-medium text-sm flex items-center justify-center gap-2 transition"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل الخروج من هذا الجهاز</span>
                </button>
              </div>
            </div>
          ) : (
            /* Logged out state */
            <div className="space-y-4">
              {/* Feature highlight */}
              <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/70 dark:border-amber-900/50 flex items-start gap-3 text-xs text-amber-900 dark:text-amber-200">
                <Smartphone className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  سجل دخولك ببريدك الإلكتروني لتتم مزامنة جدولك وموادك ومواعيد أدويتك تلقائياً
                  بين هاتفك الأندرويد وحاسوبك وأي جهاز آخر دون فقدان أي بيانات!
                </p>
              </div>

              {/* Google Fast Sign-in button */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-white font-semibold text-sm flex items-center justify-center gap-3 transition shadow-xs disabled:opacity-50"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>المتابعة باستخدام حساب Google</span>
              </button>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
                <span className="bg-white dark:bg-[#1c101a] px-3 text-xs text-slate-400 uppercase">
                  أو بالبريد الإلكتروني
                </span>
              </div>

              {/* Email / Password Form */}
              <form onSubmit={handleEmailSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    البريد الإلكتروني
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    كلمة المرور
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                    />
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/50 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/50 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-semibold text-sm shadow-md shadow-rose-500/25 transition disabled:opacity-50"
                >
                  {loading
                    ? 'جارٍ التحقق...'
                    : mode === 'signin'
                    ? 'تسجيل الدخول ومزامنة البيانات'
                    : 'إنشاء حساب جديد وحفظ البيانات'}
                </button>

                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setMode(mode === 'signin' ? 'signup' : 'signin');
                      setErrorMsg(null);
                    }}
                    className="text-xs text-rose-600 dark:text-rose-400 hover:underline font-medium"
                  >
                    {mode === 'signin'
                      ? 'ليس لديك حساب؟ أنشئ حساباً جديداً بنقرة واحدة'
                      : 'لديك حساب بالفعل؟ تسجيل الدخول'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {cloudSyncError && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-200">
              ملاحظة: {cloudSyncError}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
