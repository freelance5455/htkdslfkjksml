import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { User } from '../../types';
import {
  ChefHat,
  Lock,
  User as UserIcon,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Smartphone,
  Info,
} from 'lucide-react';

interface LoginViewProps {
  onOpenApkInfo: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onOpenApkInfo }) => {
  const { login, quickLogin } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const users = storageService.getUsers();
  const adminUser = users.find((u) => u.role === 'ADMIN');
  const sampleEmployees = users.filter((u) => u.role === 'EMPLEADO').slice(0, 4);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setErrorMsg('Por favor ingresa usuario y contraseña.');
      return;
    }

    const result = login(username.trim(), password.trim());
    if (!result.success) {
      setErrorMsg(result.message || 'Error al iniciar sesión.');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 flex flex-col justify-between p-4 sm:p-6 text-neutral-100 selection:bg-orange-500">
      {/* Top Bar with APK Guide button */}
      <div className="max-w-md w-full mx-auto flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-600 flex items-center justify-center text-white font-bold">
            <ChefHat className="w-5 h-5" />
          </div>
          <span className="font-extrabold text-base tracking-tight text-white">
            RestoTurno
          </span>
        </div>

        <button
          onClick={onOpenApkInfo}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-300 border border-neutral-700 active:scale-95 transition-all"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>Info APK Android</span>
        </button>
      </div>

      {/* Center Box */}
      <div className="max-w-md w-full mx-auto my-6 space-y-5">
        <div className="text-center space-y-1">
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Iniciar Sesión
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400">
            Control de turnos, tareas por área, pendientes y faltantes
          </p>
        </div>

        {/* Credentials Form */}
        <div className="bg-neutral-800/90 rounded-3xl p-5 sm:p-6 border border-neutral-700/80 shadow-2xl space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-xl text-xs text-red-200 font-medium">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider mb-1">
                Usuario
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  id="login-username-input"
                  type="text"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    if (errorMsg) setErrorMsg('');
                  }}
                  placeholder="Ej. admin o carlos"
                  className="w-full pl-10 pr-4 py-3 bg-neutral-900/90 border border-neutral-700 rounded-xl text-sm text-white placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-orange-500/40 focus:border-orange-500 transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider mb-1">
                Contraseña
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  id="login-password-input"
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMsg) setErrorMsg('');
                  }}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 bg-neutral-900/90 border border-neutral-700 rounded-xl text-sm text-white placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-orange-500/40 focus:border-orange-500 transition-all font-medium"
                />
              </div>
            </div>

            <button
              id="btn-login-submit"
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-orange-600/30 active:scale-[0.98] transition-all"
            >
              <span>Ingresar al Sistema</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>
        </div>

        {/* Quick Demo Login Chips (Makes testing effortless for evaluator/manager) */}
        <div className="bg-neutral-800/40 rounded-2xl p-4 border border-neutral-800 space-y-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-400 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Acceso Rápido de Prueba (1 Clic)</span>
          </div>

          <div className="space-y-1.5">
            {/* Admin Quick Button */}
            {adminUser && (
              <button
                id="btn-quick-admin"
                onClick={() => quickLogin(adminUser)}
                className="w-full p-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 flex items-center justify-between text-left active:scale-[0.99] transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-amber-500 text-neutral-900 flex items-center justify-center font-bold text-xs">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-amber-300">
                      {adminUser.name}
                    </div>
                    <div className="text-[11px] text-neutral-400">
                      Rol: Administrador General • Usuario: {adminUser.username}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded">
                  Entrar
                </span>
              </button>
            )}

            {/* Employee quick buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
              {sampleEmployees.map((emp) => (
                <button
                  key={emp.id}
                  id={`btn-quick-${emp.username}`}
                  onClick={() => quickLogin(emp)}
                  className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700/80 flex items-center justify-between text-left active:scale-[0.99] transition-all"
                >
                  <div className="min-w-0 pr-1">
                    <div className="text-xs font-bold text-neutral-200 truncate">
                      {emp.name}
                    </div>
                    <div className="text-[10px] text-neutral-400 truncate">
                      {emp.areaName} • {emp.shift}
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-orange-400 shrink-0">
                    Probar →
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center text-[11px] text-neutral-500 pb-2">
        RestoTurno v1.0 • Diseñado para dispositivos Android y pantallas táctiles de cocina
      </div>
    </div>
  );
};
