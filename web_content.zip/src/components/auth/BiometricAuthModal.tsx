/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck,
  Fingerprint,
  ScanFace,
  KeyRound,
  Lock,
  Unlock,
  AlertCircle,
  X,
  ArrowRight,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import {
  ProtectedSection,
  BiometricMethod,
  getBiometricSettings,
  unlockSection,
  verifyPin,
  performBiometricScan,
  DEFAULT_PIN,
} from '../../utils/biometrics';

interface BiometricAuthModalProps {
  section: ProtectedSection;
  isOpen: boolean;
  onSuccess: () => void;
  onCancel: () => void;
  lang?: 'ar' | 'en' | 'fr';
}

export const BiometricAuthModal: React.FC<BiometricAuthModalProps> = ({
  section,
  isOpen,
  onSuccess,
  onCancel,
  lang = 'ar',
}) => {
  const [settings, setSettings] = useState(getBiometricSettings());
  const [mode, setMode] = useState<'biometric' | 'pin'>('biometric');
  const [isScanning, setIsScanning] = useState(false);
  const [scanSuccess, setScanSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [pinDigits, setPinDigits] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      const currentSettings = getBiometricSettings();
      setSettings(currentSettings);
      setMode(currentSettings.method === 'pin' ? 'pin' : 'biometric');
      setPinDigits('');
      setErrorMessage(null);
      setScanSuccess(false);

      if (currentSettings.method !== 'pin') {
        // Auto-trigger biometric authentication when modal opens
        startScan(currentSettings.method);
      }
    }
  }, [isOpen]);

  const sectionTitles = {
    wallet: {
      ar: 'محفظة السفر والوثائق المشفرة',
      en: 'Encrypted Travel Vault',
      fr: 'Coffre de Voyage Sécurisé',
    },
    profile: {
      ar: 'الملف الشخصي والبيانات الحساسة',
      en: 'Profile & Sensitive Data',
      fr: 'Profil & Données Sensibles',
    },
  };

  const texts = {
    ar: {
      title: 'التحقق البيومتري مطلوب',
      subtitle: `لحماية خصوصيتك، يرجى تأكيد الهوية للوصول إلى ${sectionTitles[section].ar}`,
      faceIdPrompt: 'جاري مسح ملامح الوجه ثلاثي الأبعاد...',
      touchIdPrompt: 'ضع إصبعك على مستشعر البصمة للتحقق...',
      scanBtn: 'إعادة المسح البيومتري',
      switchToPin: 'استخدام رمز PIN الاحتياطي (1234)',
      switchToBiometric: 'التبديل إلى المسح البيومتري',
      enterPin: 'أدخل رمز الأمان المكون من 4 أرقام',
      pinHint: 'الرمز الافتراضي: 1234',
      invalidPin: 'رمز PIN غير صحيح. يرجى المحاولة مرة أخرى.',
      cancel: 'إلغاء والعودة للرئيسية',
      verifying: 'جاري التحقق...',
      success: 'تم تأكيد الهوية بنجاح',
      securedBy: 'محمي بتقنية TAKI SecureVault المشفرة محلياً',
    },
    en: {
      title: 'Biometric Verification Required',
      subtitle: `To protect your privacy, authenticate to access ${sectionTitles[section].en}`,
      faceIdPrompt: 'Scanning 3D Facial Geometry...',
      touchIdPrompt: 'Place finger on biometric scanner...',
      scanBtn: 'Retry Biometric Scan',
      switchToPin: 'Use Backup PIN (1234)',
      switchToBiometric: 'Switch to Biometric Scan',
      enterPin: 'Enter 4-digit security PIN',
      pinHint: 'Default PIN: 1234',
      invalidPin: 'Incorrect PIN. Please try again.',
      cancel: 'Cancel & Return Home',
      verifying: 'Verifying...',
      success: 'Identity Confirmed',
      securedBy: 'Protected by TAKI SecureVault local encryption',
    },
    fr: {
      title: 'Vérification Biométrique Requise',
      subtitle: `Pour votre confidentialité, authentifiez-vous pour accéder à ${sectionTitles[section].fr}`,
      faceIdPrompt: 'Analyse géométrique du visage 3D...',
      touchIdPrompt: 'Posez votre doigt sur le capteur...',
      scanBtn: 'Réessayer le scan',
      switchToPin: 'Utiliser le code PIN (1234)',
      switchToBiometric: 'Passer au scan biométrique',
      enterPin: 'Entrez le code PIN à 4 chiffres',
      pinHint: 'PIN par défaut : 1234',
      invalidPin: 'Code PIN incorrect. Veuillez réessayer.',
      cancel: 'Annuler et revenir',
      verifying: 'Vérification en cours...',
      success: 'Identité confirmée',
      securedBy: 'Protégé par le chiffrement local TAKI SecureVault',
    },
  }[lang];

  const startScan = async (method: BiometricMethod = settings.method) => {
    setIsScanning(true);
    setErrorMessage(null);
    try {
      const res = await performBiometricScan(method);
      if (res.success) {
        setScanSuccess(true);
        unlockSection(section);
        setTimeout(() => {
          setIsScanning(false);
          onSuccess();
        }, 600);
      } else {
        setIsScanning(false);
        setErrorMessage(res.error || 'فشل التحقق البيومتري');
      }
    } catch {
      setIsScanning(false);
      setErrorMessage('تعذر إكمال المسح');
    }
  };

  const handlePinInput = (num: string) => {
    if (pinDigits.length >= 4) return;
    const nextPin = pinDigits + num;
    setPinDigits(nextPin);
    setErrorMessage(null);

    if (nextPin.length === 4) {
      // Validate PIN
      if (verifyPin(nextPin, settings.pin || DEFAULT_PIN)) {
        setScanSuccess(true);
        unlockSection(section);
        setTimeout(() => {
          onSuccess();
        }, 500);
      } else {
        setTimeout(() => {
          setErrorMessage(texts.invalidPin);
          setPinDigits('');
        }, 300);
      }
    }
  };

  const handlePinBackspace = () => {
    setPinDigits((prev) => prev.slice(0, -1));
    setErrorMessage(null);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-sm rounded-3xl bg-[#090d1f] border border-cyan-500/30 p-6 text-white shadow-[0_0_50px_rgba(0,240,255,0.18)] overflow-hidden"
          dir={lang === 'ar' ? 'rtl' : 'ltr'}
        >
          {/* Ambient Glow */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

          {/* Close / Return Button */}
          <button
            onClick={onCancel}
            className="absolute top-4 left-4 rtl:left-auto rtl:right-4 p-2 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            title={texts.cancel}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="text-center mt-2 mb-6">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-3 shadow-[0_0_20px_rgba(0,240,255,0.25)]">
              {scanSuccess ? (
                <Unlock className="w-7 h-7 text-emerald-400" />
              ) : (
                <Lock className="w-7 h-7 text-cyan-400" />
              )}
            </div>
            <h3 className="text-xl font-bold tracking-tight text-white">{texts.title}</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-[280px] mx-auto leading-relaxed">
              {texts.subtitle}
            </p>
          </div>

          {/* Content: Biometric Mode */}
          {mode === 'biometric' && (
            <div className="flex flex-col items-center">
              {/* Scanner Graphic Frame */}
              <div
                onClick={() => !isScanning && !scanSuccess && startScan()}
                className={`relative w-36 h-36 rounded-3xl border-2 flex items-center justify-center cursor-pointer transition-all duration-300 ${
                  scanSuccess
                    ? 'border-emerald-400 bg-emerald-500/10 shadow-[0_0_30px_rgba(16,185,129,0.3)]'
                    : isScanning
                    ? 'border-cyan-400 bg-cyan-500/10 shadow-[0_0_30px_rgba(0,240,255,0.35)]'
                    : 'border-slate-700 bg-slate-900/60 hover:border-cyan-500/50'
                }`}
              >
                {/* Corner reticles for futuristic scanner feel */}
                <span className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
                <span className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
                <span className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
                <span className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />

                {/* Animated Scanner Laser Beam */}
                {isScanning && !scanSuccess && (
                  <motion.div
                    className="absolute inset-x-2 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#00f0ff]"
                    animate={{ top: ['10%', '85%', '10%'] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
                  />
                )}

                {/* Main Icon */}
                {scanSuccess ? (
                  <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-emerald-400 flex flex-col items-center"
                  >
                    <CheckCircle2 className="w-14 h-14" />
                  </motion.div>
                ) : settings.method === 'touchid' ? (
                  <motion.div
                    animate={isScanning ? { scale: [1, 1.08, 1] } : {}}
                    transition={{ repeat: Infinity, duration: 1.2 }}
                    className="text-cyan-400"
                  >
                    <Fingerprint className="w-16 h-16" />
                  </motion.div>
                ) : (
                  <motion.div
                    animate={isScanning ? { scale: [1, 1.05, 1] } : {}}
                    transition={{ repeat: Infinity, duration: 1.4 }}
                    className="text-cyan-400"
                  >
                    <ScanFace className="w-16 h-16" />
                  </motion.div>
                )}
              </div>

              {/* Status Message */}
              <div className="mt-4 text-center min-h-[44px]">
                {scanSuccess ? (
                  <p className="text-emerald-400 text-sm font-semibold flex items-center justify-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    {texts.success}
                  </p>
                ) : isScanning ? (
                  <p className="text-cyan-400 text-xs font-medium animate-pulse">
                    {settings.method === 'touchid' ? texts.touchIdPrompt : texts.faceIdPrompt}
                  </p>
                ) : errorMessage ? (
                  <p className="text-rose-400 text-xs font-medium flex items-center justify-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errorMessage}
                  </p>
                ) : (
                  <p className="text-slate-400 text-xs">
                    {settings.method === 'touchid'
                      ? 'انقر على المستشعر للمسح'
                      : 'انقر على المستشعر لمسح الوجه'}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="w-full mt-4 space-y-2">
                {!scanSuccess && (
                  <>
                    <button
                      onClick={() => startScan()}
                      disabled={isScanning}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(0,240,255,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <Fingerprint className="w-4 h-4" />
                      {texts.scanBtn}
                    </button>

                    <button
                      onClick={() => setMode('pin')}
                      className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 font-medium text-xs border border-slate-700/60 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <KeyRound className="w-4 h-4 text-cyan-400" />
                      {texts.switchToPin}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Content: PIN Keypad Mode */}
          {mode === 'pin' && (
            <div className="flex flex-col items-center">
              <p className="text-xs text-slate-300 font-medium mb-3">{texts.enterPin}</p>

              {/* 4 PIN Dots */}
              <div className="flex items-center gap-3 mb-4">
                {[0, 1, 2, 3].map((idx) => {
                  const filled = pinDigits.length > idx;
                  return (
                    <motion.div
                      key={idx}
                      initial={false}
                      animate={{
                        scale: filled ? 1.15 : 1,
                        backgroundColor: scanSuccess
                          ? '#10b981'
                          : filled
                          ? '#00f0ff'
                          : '#1e293b',
                      }}
                      className={`w-4 h-4 rounded-full border ${
                        scanSuccess
                          ? 'border-emerald-400 shadow-[0_0_10px_#10b981]'
                          : filled
                          ? 'border-cyan-400 shadow-[0_0_10px_#00f0ff]'
                          : 'border-slate-600'
                      }`}
                    />
                  );
                })}
              </div>

              {/* Error or Hint */}
              <div className="min-h-[22px] mb-2 text-center">
                {errorMessage ? (
                  <p className="text-rose-400 text-xs font-medium flex items-center justify-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errorMessage}
                  </p>
                ) : (
                  <p className="text-slate-500 text-[11px]">{texts.pinHint}</p>
                )}
              </div>

              {/* Numeric Keypad Grid */}
              <div className="grid grid-cols-3 gap-2.5 w-full max-w-[260px] mb-3" dir="ltr">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                  <button
                    key={digit}
                    onClick={() => handlePinInput(digit)}
                    disabled={scanSuccess}
                    className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 active:bg-cyan-500/20 text-white font-bold text-lg border border-slate-700/50 hover:border-cyan-500/40 transition-all flex items-center justify-center cursor-pointer disabled:opacity-50"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  onClick={() => setMode('biometric')}
                  disabled={scanSuccess}
                  className="h-12 rounded-xl bg-slate-800/40 hover:bg-slate-800 text-cyan-400 font-medium text-xs border border-slate-700/40 transition-colors flex items-center justify-center cursor-pointer"
                  title={texts.switchToBiometric}
                >
                  <Fingerprint className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handlePinInput('0')}
                  disabled={scanSuccess}
                  className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 active:bg-cyan-500/20 text-white font-bold text-lg border border-slate-700/50 hover:border-cyan-500/40 transition-all flex items-center justify-center cursor-pointer disabled:opacity-50"
                >
                  0
                </button>
                <button
                  onClick={handlePinBackspace}
                  disabled={scanSuccess || pinDigits.length === 0}
                  className="h-12 rounded-xl bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors flex items-center justify-center cursor-pointer disabled:opacity-30"
                >
                  <ArrowRight className="w-5 h-5 rtl:rotate-180" />
                </button>
              </div>

              <button
                onClick={() => setMode('biometric')}
                className="text-xs text-cyan-400 hover:text-cyan-300 underline font-medium cursor-pointer transition-colors"
              >
                {texts.switchToBiometric}
              </button>
            </div>
          )}

          {/* Footer Security Badge */}
          <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[10px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>{texts.securedBy}</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
