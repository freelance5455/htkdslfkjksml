import React, { useState, useEffect } from 'react';
import { ShieldAlert, ShieldCheck, RefreshCw, ExternalLink, X, CheckCircle2, Lock } from 'lucide-react';
import { checkCookieHealth, openAuthInNewWindow, CookieStatus } from '../../services/authService';
import { useApp } from '../../context/AppContext';

export const CookieSecurityBanner: React.FC = () => {
  const { currentUser, language } = useApp();
  const [cookieStatus, setCookieStatus] = useState<CookieStatus | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [isDismissed, setIsDismissed] = useState(() => {
    return sessionStorage.getItem('taskearn_cookie_banner_dismissed') === 'true';
  });
  const [authSuccessNotice, setAuthSuccessNotice] = useState(false);

  const runCheck = async () => {
    setIsChecking(true);
    try {
      const status = await checkCookieHealth();
      setCookieStatus(status);
    } catch (e) {
      console.warn('Cookie health check error:', e);
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    runCheck();
  }, []);

  const handleDismiss = () => {
    setIsDismissed(true);
    sessionStorage.setItem('taskearn_cookie_banner_dismissed', 'true');
  };

  const handleOpenAuthWindow = () => {
    openAuthInNewWindow(
      (user, token) => {
        setAuthSuccessNotice(true);
        setTimeout(() => setAuthSuccessNotice(false), 4000);
        runCheck();
      },
      () => {
        console.warn(
          language === 'bn'
            ? 'পপআপ ব্লক হয়েছে। অনুগ্রহ করে ব্রাউজার সেটিংসে পপআপ অনুমোদন করুন।'
            : 'Popup was blocked by your browser. Please allow popups to open the secure login window.'
        );
      }
    );
  };

  // If dismissed or everything is verified active and user is logged in without issues, hide
  if (isDismissed) {
    return null;
  }

  // Only show if storage access is explicitly blocked
  const hasIssue = cookieStatus && cookieStatus.storageAccessBlocked;

  // If no issue detected and user is logged in, don't clutter the UI
  if (!hasIssue && !authSuccessNotice) {
    return null;
  }

  return (
    <div className="w-full bg-slate-900/95 border-b border-amber-500/30 text-slate-100 px-4 py-3 shadow-md relative z-40 animate-in fade-in slide-in-from-top duration-300">
      <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        
        {/* Left message & status icon */}
        <div className="flex items-start gap-2.5 min-w-0">
          <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0 mt-0.5">
            {authSuccessNotice ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            )}
          </div>

          <div className="space-y-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-black text-amber-300 text-xs">
                {authSuccessNotice
                  ? (language === 'bn' ? 'নিরাপদ প্রমাণীকরণ সম্পন্ন!' : 'Secure Authentication Successful!')
                  : (language === 'bn' ? 'ব্রাউজার কুকি ও নিরাপত্তা বিজ্ঞপ্তি' : 'Cookie & Security Notice')}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                HTTPS SameSite=None
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              {authSuccessNotice
                ? (language === 'bn'
                    ? 'আপনার অধিবেশন সংরক্ষিত হয়েছে এবং স্বয়ংক্রিয়ভাবে সিঙ্ক হয়েছে।'
                    : 'Session authenticated and securely synchronized via top-level HTTPS.')
                : (language === 'bn'
                    ? 'আপনার ব্রাউজার (যেমন Android Chrome) তৃতীয় পক্ষের কুকি সীমাবদ্ধ করতে পারে। টাস্ক আর্ন প্রো নিরাপদ টোকেন মোডে সচল রয়েছে।'
                    : 'Your browser or iframe may block third-party cookies. Task Earn Pro uses token preservation and secure window authentication.')}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-end pt-1 sm:pt-0">
          <button
            type="button"
            onClick={runCheck}
            disabled={isChecking}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700 disabled:opacity-50"
            title="Retry cookie probe"
          >
            <RefreshCw className={`w-3 h-3 ${isChecking ? 'animate-spin text-amber-400' : ''}`} />
            <span>{isChecking ? 'Checking...' : 'Retry'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAuthWindow}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95 whitespace-nowrap"
          >
            <Lock className="w-3 h-3" />
            <span>Open Auth Window</span>
            <ExternalLink className="w-2.5 h-2.5 opacity-70" />
          </button>

          <button
            type="button"
            onClick={handleDismiss}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Dismiss notice"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
