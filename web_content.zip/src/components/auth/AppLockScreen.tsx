import React, { useState } from 'react';
import { Lock, Delete, Fingerprint, Shield, AlertCircle } from 'lucide-react';
import { useLock } from '../../contexts/LockContext';

export const AppLockScreen: React.FC = () => {
  const { unlockWithPin, isBiometricsAvailable, unlockWithBiometrics } = useLock();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleKeyPress = (num: string) => {
    if (pin.length >= 6) return;
    const nextPin = pin + num;
    setPin(nextPin);
    setError(false);

    if (nextPin.length >= 4) {
      // Check PIN
      setTimeout(() => {
        const ok = unlockWithPin(nextPin);
        if (!ok) {
          setError(true);
          setPin('');
        }
      }, 50);
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleBiometrics = async () => {
    const success = await unlockWithBiometrics();
    if (!success) {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-neutral-950 text-white p-6 select-none font-sans">
      {/* Top Header */}
      <div className="pt-8 flex flex-col items-center space-y-3">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-xl shadow-emerald-950/60 animate-pulse">
          <Shield className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold tracking-tight text-neutral-100">Nexa Messenger Locked</h2>
        <p className="text-xs text-neutral-400">Enter your 4 or 6-digit security PIN</p>
      </div>

      {/* PIN Dots Display */}
      <div className="flex flex-col items-center my-6">
        <div className={`flex items-center space-x-4 ${error ? 'animate-shake' : ''}`}>
          {[0, 1, 2, 3].map((i) => {
            const filled = pin.length > i;
            return (
              <div
                key={i}
                className={`w-4 h-4 rounded-full border-2 transition-all duration-150 ${
                  filled
                    ? 'bg-emerald-500 border-emerald-400 scale-110 shadow-md shadow-emerald-500/50'
                    : 'bg-transparent border-neutral-700'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <div className="flex items-center space-x-1.5 text-xs text-red-400 mt-4 font-medium animate-fade-in">
            <AlertCircle className="w-4 h-4" />
            <span>Incorrect PIN. Try again.</span>
          </div>
        )}
      </div>

      {/* Keypad */}
      <div className="w-full max-w-xs pb-8">
        <div className="grid grid-cols-3 gap-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-16 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 active:scale-95 border border-neutral-800 text-xl font-semibold text-white flex items-center justify-center transition-all cursor-pointer"
            >
              {digit}
            </button>
          ))}

          {/* Biometrics button or empty */}
          {isBiometricsAvailable ? (
            <button
              type="button"
              onClick={handleBiometrics}
              className="h-16 rounded-2xl bg-neutral-900/40 hover:bg-neutral-800 active:scale-95 text-emerald-400 flex items-center justify-center transition-all cursor-pointer"
              title="Unlock with Biometrics"
            >
              <Fingerprint className="w-7 h-7" />
            </button>
          ) : (
            <div className="h-16" />
          )}

          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-16 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 active:scale-95 border border-neutral-800 text-xl font-semibold text-white flex items-center justify-center transition-all cursor-pointer"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleDelete}
            disabled={pin.length === 0}
            className="h-16 rounded-2xl bg-neutral-900/40 hover:bg-neutral-800 active:scale-95 text-neutral-400 hover:text-white disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
