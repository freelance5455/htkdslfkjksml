import React, { useState } from 'react';
import { Flag, Minus, Pause, Play, Plus, RotateCcw } from 'lucide-react';
import type { Language, LapRecord } from '../types/study';
import { TimerVectorIcon } from './LiquidIcons';

interface CustomTimerStopwatchProps {
  lang: Language;
  // Today's study tracking vs daily target
  todayStudiedSec: number;
  dailyGoalMinutes: number;
  onSetDailyGoalMinutes: (minutes: number) => void;

  // Custom countdown props
  customHours: number;
  customMinutes: number;
  customSeconds: number;
  customRemainingMs: number;
  customTotalMs: number;
  customRunning: boolean;
  onSetCustomInputs: (h: number, m: number, s: number) => void;
  onToggleCustom: () => void;
  onResetCustom: () => void;
  onApplyPresetMinutes: (minutes: number) => void;

  // Stopwatch props
  swElapsedMs: number;
  swRunning: boolean;
  swLaps: LapRecord[];
  onToggleSw: () => void;
  onResetSw: () => void;
  onRecordLap: () => void;
}

function formatStudiedDuration(totalSec: number, lang: Language): string {
  const safe = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  if (lang === 'en') {
    if (h === 0 && m === 0) return `${s}s`;
    if (h === 0) return `${m}m`;
    if (m === 0) return `${h}h`;
    return `${h}h ${m}m`;
  }
  if (h === 0 && m === 0) return `${s} সে.`;
  if (h === 0) return `${m} মি.`;
  if (m === 0) return `${h} ঘণ্টা`;
  return `${h} ঘ. ${m} মি.`;
}

function formatHMS(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function formatStopwatch(ms: number): string {
  const safe = Math.max(0, Math.floor(ms));
  const minutes = Math.floor(safe / 60000);
  const seconds = Math.floor((safe % 60000) / 1000);
  const centis = Math.floor((safe % 1000) / 10);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(centis).padStart(2, '0')}`;
}

export const CustomTimerStopwatch: React.FC<CustomTimerStopwatchProps> = ({
  lang,
  todayStudiedSec,
  dailyGoalMinutes,
  onSetDailyGoalMinutes,
  customHours,
  customMinutes,
  customSeconds,
  customRemainingMs,
  customTotalMs,
  customRunning,
  onSetCustomInputs,
  onToggleCustom,
  onResetCustom,
  onApplyPresetMinutes,
  swElapsedMs,
  swRunning,
  swLaps,
  onToggleSw,
  onResetSw,
  onRecordLap,
}) => {
  const [mode, setMode] = useState<'countdown' | 'stopwatch'>('countdown');
  const isBn = lang === 'bn';

  const progressPct =
    customTotalMs > 0
      ? Math.max(0, Math.min(100, (customRemainingMs / customTotalMs) * 100))
      : 0;

  const goalSec = Math.max(30 * 60, dailyGoalMinutes * 60);
  const goalPct = Math.min(100, Math.round((todayStudiedSec / goalSec) * 100));
  const remainingGoalSec = Math.max(0, goalSec - todayStudiedSec);

  return (
    <div className="mx-auto max-w-3xl">
      <section className="liquid-glass rounded-3xl p-5 sm:p-8">
        <div className="mb-5 flex items-center justify-center gap-2.5 text-slate-200">
          <TimerVectorIcon active className="h-5 w-5 text-sky-300" />
          <h2 className="text-base font-semibold text-white">
            {isBn ? 'পড়ার সময়' : 'Study Time'}
          </h2>
        </div>

        {/* Studied Today vs Study Goal */}
        <div className="mb-6 rounded-2xl border border-white/14 bg-white/[0.04] p-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <p className="text-xs text-slate-300">
                {isBn ? 'আজ কতক্ষণ পড়ছি' : 'Studied Today'}
              </p>
              <p className="font-mono-tabular mt-1 text-2xl font-bold text-sky-200">
                {formatStudiedDuration(todayStudiedSec, lang)}
              </p>
              <p className="mt-0.5 text-[11px] text-slate-400 tabular-nums">
                {remainingGoalSec === 0
                  ? isBn
                    ? 'লক্ষ্য সম্পন্ন'
                    : 'Goal Complete'
                  : isBn
                    ? `বাকি: ${formatStudiedDuration(remainingGoalSec, lang)}`
                    : `Remaining: ${formatStudiedDuration(remainingGoalSec, lang)}`}
              </p>
            </div>

            <div className="sm:text-right">
              <p className="text-xs text-slate-300">
                {isBn ? 'কতক্ষণ পড়বো (লক্ষ্য)' : 'Study Goal'}
              </p>
              <div className="mt-1.5 flex items-center gap-2 sm:justify-end">
                <button
                  type="button"
                  onClick={() => onSetDailyGoalMinutes(Math.max(30, dailyGoalMinutes - 30))}
                  aria-label={isBn ? 'কমান' : 'Decrease'}
                  className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/18 bg-white/8 text-slate-200 transition hover:bg-white/18"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-mono-tabular min-w-[90px] text-center text-lg font-bold text-white">
                  {formatStudiedDuration(dailyGoalMinutes * 60, lang)}
                </span>
                <button
                  type="button"
                  onClick={() => onSetDailyGoalMinutes(Math.min(16 * 60, dailyGoalMinutes + 30))}
                  aria-label={isBn ? 'বাড়ান' : 'Increase'}
                  className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/18 bg-white/8 text-slate-200 transition hover:bg-white/18"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          <div className="mt-3.5">
            <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-sky-400 to-emerald-300 transition-all duration-300"
                style={{ width: `${goalPct}%` }}
              />
            </div>
            <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-300 tabular-nums">
              <span>{goalPct}%</span>
              <span>{formatStudiedDuration(dailyGoalMinutes * 60, lang)}</span>
            </div>
          </div>
        </div>

        {/* Segmented Switch */}
        <div className="mx-auto flex max-w-md items-center gap-1.5 rounded-2xl border border-white/20 bg-white/6 p-1.5 backdrop-blur-md">
          <button
            type="button"
            onClick={() => setMode('countdown')}
            className={`min-h-[42px] flex-1 rounded-xl px-3 py-2 text-xs font-semibold transition whitespace-nowrap ${
              mode === 'countdown'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            {isBn ? 'কতক্ষণ পড়বো (টাইমার)' : 'Timer'}
          </button>
          <button
            type="button"
            onClick={() => setMode('stopwatch')}
            className={`min-h-[42px] flex-1 rounded-xl px-3 py-2 text-xs font-semibold transition whitespace-nowrap ${
              mode === 'stopwatch'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            {isBn ? 'কতক্ষণ পড়ছি (স্টপওয়াচ)' : 'Stopwatch'}
          </button>
        </div>

        {mode === 'countdown' ? (
          <div className="mt-7">
            <div className="text-center">
              <div className="font-mono-tabular text-5xl font-bold tracking-tight text-white sm:text-6xl">
                {formatHMS(customRemainingMs)}
              </div>
              <div className="mx-auto mt-5 h-2 w-full max-w-md overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-sky-400 transition-all duration-300"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
            </div>

            <div className="mx-auto mt-7 grid max-w-md grid-cols-3 gap-3">
              <div>
                <label htmlFor="custom-hours" className="block text-center text-xs text-slate-300">
                  {isBn ? 'ঘণ্টা' : 'Hours'}
                </label>
                <input
                  id="custom-hours"
                  type="number"
                  min={0}
                  max={23}
                  disabled={customRunning}
                  value={customHours}
                  onChange={(e) =>
                    onSetCustomInputs(
                      Math.max(0, Math.min(23, Number(e.target.value) || 0)),
                      customMinutes,
                      customSeconds
                    )
                  }
                  className="glass-input font-mono-tabular mt-1.5 w-full min-h-[46px] rounded-xl text-center text-lg font-semibold disabled:opacity-50"
                />
              </div>
              <div>
                <label htmlFor="custom-minutes" className="block text-center text-xs text-slate-300">
                  {isBn ? 'মিনিট' : 'Minutes'}
                </label>
                <input
                  id="custom-minutes"
                  type="number"
                  min={0}
                  max={59}
                  disabled={customRunning}
                  value={customMinutes}
                  onChange={(e) =>
                    onSetCustomInputs(
                      customHours,
                      Math.max(0, Math.min(59, Number(e.target.value) || 0)),
                      customSeconds
                    )
                  }
                  className="glass-input font-mono-tabular mt-1.5 w-full min-h-[46px] rounded-xl text-center text-lg font-semibold disabled:opacity-50"
                />
              </div>
              <div>
                <label htmlFor="custom-seconds" className="block text-center text-xs text-slate-300">
                  {isBn ? 'সেকেন্ড' : 'Seconds'}
                </label>
                <input
                  id="custom-seconds"
                  type="number"
                  min={0}
                  max={59}
                  disabled={customRunning}
                  value={customSeconds}
                  onChange={(e) =>
                    onSetCustomInputs(
                      customHours,
                      customMinutes,
                      Math.max(0, Math.min(59, Number(e.target.value) || 0))
                    )
                  }
                  className="glass-input font-mono-tabular mt-1.5 w-full min-h-[46px] rounded-xl text-center text-lg font-semibold disabled:opacity-50"
                />
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              {[10, 20, 30, 45, 60].map((min) => (
                <button
                  key={min}
                  type="button"
                  disabled={customRunning}
                  onClick={() => onApplyPresetMinutes(min)}
                  className="min-h-[38px] rounded-xl border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-medium text-slate-200 transition hover:bg-white/15 disabled:opacity-40 whitespace-nowrap"
                >
                  {isBn ? `${min} মিনিট` : `${min}m`}
                </button>
              ))}
            </div>

            <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onResetCustom}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>{isBn ? 'রিসেট' : 'Reset'}</span>
              </button>

              <button
                type="button"
                onClick={onToggleCustom}
                disabled={customRemainingMs <= 0 && !customRunning}
                className="inline-flex min-h-[48px] min-w-[160px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition hover:bg-sky-300 disabled:opacity-45 whitespace-nowrap"
              >
                {customRunning ? (
                  <>
                    <Pause className="h-4 w-4" aria-hidden="true" />
                    <span>{isBn ? 'পজ' : 'Pause'}</span>
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>{isBn ? 'শুরু' : 'Start'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-7">
            <div className="text-center">
              <div className="font-mono-tabular text-5xl font-bold tracking-tight text-white sm:text-6xl">
                {formatStopwatch(swElapsedMs)}
              </div>
            </div>

            <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onResetSw}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>{isBn ? 'রিসেট' : 'Reset'}</span>
              </button>

              <button
                type="button"
                onClick={onToggleSw}
                className="inline-flex min-h-[48px] min-w-[150px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition hover:bg-sky-300 whitespace-nowrap"
              >
                {swRunning ? (
                  <>
                    <Pause className="h-4 w-4" aria-hidden="true" />
                    <span>{isBn ? 'পজ' : 'Pause'}</span>
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" aria-hidden="true" />
                    <span>{isBn ? 'শুরু' : 'Start'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onRecordLap}
                disabled={!swRunning && swElapsedMs === 0}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-white/20 disabled:opacity-40 whitespace-nowrap"
              >
                <Flag className="h-4 w-4" aria-hidden="true" />
                <span>{isBn ? 'ল্যাপ' : 'Lap'}</span>
              </button>
            </div>

            {swLaps.length > 0 && (
              <div className="mt-7 border-t border-white/10 pt-4">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>{isBn ? 'ল্যাপ' : 'Laps'}</span>
                  <span className="tabular-nums">{swLaps.length}</span>
                </div>

                <div className="mt-3 max-h-56 overflow-y-auto divide-y divide-white/10">
                  {swLaps.map((lap) => (
                    <div
                      key={lap.id}
                      className="flex items-center justify-between py-2.5 text-xs text-slate-200"
                    >
                      <span className="font-mono-tabular text-slate-300">
                        {isBn ? 'ল্যাপ' : 'Lap'} {String(lap.id).padStart(2, '0')}
                      </span>
                      <span className="font-mono-tabular text-sky-300">
                        +{formatStopwatch(lap.lapTimeMs)}
                      </span>
                      <span className="font-mono-tabular font-semibold text-white">
                        {formatStopwatch(lap.totalTimeMs)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
