import { useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import {
  Apple,
  ArrowUp,
  Backpack,
  Bike,
  Carrot,
  CloudRain,
  Coins,
  Droplets,
  Hand,
  Heart,
  MapPin,
  Sprout,
  Store,
  Sun,
  Users,
  Utensils,
  Volume2,
  VolumeX,
  Wheat,
  X,
  Zap,
} from "lucide-react";
import { APPLE_COST, HOTBAR, PLANTS, SAVE_KEY, cleanName } from "@/game/plants";
import { valleyStore } from "@/game/store";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import type { ValleyEngine } from "@/game/engine";

export function ValleyApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<ValleyEngine | null>(null);
  const [booted, setBooted] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let engine: ValleyEngine | undefined;
    void import("@/game/engine")
      .then(({ ValleyEngine }) => {
        if (dead) return;
        engine = new ValleyEngine(canvas);
        engineRef.current = engine;
        setBooted(true);
      })
      .catch(() => {
        if (!dead) setFailed(true);
      });
    return () => {
      dead = true;
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  return (
    <div className="valley-root fixed inset-0 overflow-hidden bg-ink text-cream">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      <LookPad engineRef={engineRef} />
      <Hud engineRef={engineRef} />
      <Shop engineRef={engineRef} />
      <Sell engineRef={engineRef} />
      <Bag engineRef={engineRef} />
      <StartScreen engineRef={engineRef} booted={booted} failed={failed} />
      <p className="portrait-hint pointer-events-none absolute top-20 left-1/2 z-20 -translate-x-1/2 rounded-full bg-ink/80 px-3 py-2 text-xs text-cream">
        Gire para a horizontal — a câmera do vale foi feita assim
      </p>
    </div>
  );
}

function LookPad({ engineRef }: { engineRef: RefObject<ValleyEngine | null> }) {
  const drag = useRef({ on: false, x: 0, y: 0 });
  return (
    <div
      className="absolute inset-0 z-10"
      onPointerDown={(e) => {
        if (e.button !== 0) return;
        drag.current = { on: true, x: e.clientX, y: e.clientY };
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      }}
      onPointerMove={(e) => {
        if (!drag.current.on) return;
        const dx = e.clientX - drag.current.x;
        const dy = e.clientY - drag.current.y;
        drag.current.x = e.clientX;
        drag.current.y = e.clientY;
        engineRef.current?.addLook(dx, dy);
      }}
      onPointerUp={() => {
        drag.current.on = false;
      }}
      onPointerCancel={() => {
        drag.current.on = false;
      }}
    />
  );
}

function StartScreen({
  engineRef,
  booted,
  failed,
}: {
  engineRef: RefObject<ValleyEngine | null>;
  booted: boolean;
  failed: boolean;
}) {
  const playing = valleyStore((s) => s.playing);
  const [name, setName] = useState("Oliver");
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw) as { name?: string };
      if (data.name) setName(cleanName(data.name));
    } catch {
      /* ignore */
    }
  }, []);
  if (playing) return null;
  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center p-4 md:items-center md:justify-start md:p-10">
      <section className="w-full max-w-md rounded-3xl border border-cream/20 bg-ink/85 p-6 shadow-2xl backdrop-blur-md md:ml-4">
        <p className="text-xs font-bold tracking-widest text-gold uppercase">Mundo aberto</p>
        <h1 className="font-display mt-1 text-4xl leading-none text-cream md:text-5xl">EcoValley</h1>
        <p className="mt-3 text-base leading-relaxed text-cream/80">
          Plante na fazenda, siga a estrada e venda a colheita na cidade. A câmera fica na altura do
          horizonte. Outros fazendeiros aparecem no mesmo vale.
        </p>
        <label className="mt-5 block text-sm text-cream/75">
          Seu nome
          <input
            value={name}
            maxLength={16}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full rounded-xl border border-cream/25 bg-ink px-3 py-3 text-base text-cream outline-none"
          />
        </label>
        <button
          id="start-btn"
          type="button"
          disabled={!booted || failed}
          onClick={() => engineRef.current?.start(name)}
          className="mt-4 w-full rounded-2xl bg-leaf px-4 py-3 text-base font-extrabold text-cream disabled:opacity-60"
        >
          {failed ? "Não foi possível abrir" : booted ? "Entrar no vale" : "Abrindo o vale…"}
        </button>
        <ul className="mt-4 grid grid-cols-3 gap-2 text-center text-xs leading-snug text-cream/80">
          <li className="rounded-xl bg-cream/10 px-2 py-2">WASD anda</li>
          <li className="rounded-xl bg-cream/10 px-2 py-2">Arraste e olhe</li>
          <li className="rounded-xl bg-cream/10 px-2 py-2">E planta e vende</li>
        </ul>
      </section>
    </div>
  );
}

function Hud({ engineRef }: { engineRef: RefObject<ValleyEngine | null> }) {
  const hud = valleyStore();
  if (!hud.playing) return null;
  return (
    <>
      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex flex-wrap items-start justify-between gap-2 p-3 md:p-4">
        <div className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-cream/15 bg-ink/80 px-3 py-2 backdrop-blur-md">
          <div className="flex size-10 items-center justify-center rounded-xl bg-leaf text-cream">
            <Sprout className="size-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold text-cream">{hud.name}</span>
              <span className="inline-flex items-center gap-1 rounded-full bg-cream/10 px-2 py-0.5 text-xs text-cream/80">
                {hud.weather === "rain" ? <CloudRain className="size-3" /> : <Sun className="size-3" />}
                {hud.weather === "rain" ? "Chuva" : hud.period}
              </span>
            </div>
            <div className="mt-1 flex items-center gap-2">
              <Meter value={hud.health} tone="bg-heart" label="Saúde">
                <Heart className="size-3 text-heart" />
              </Meter>
              <Meter value={hud.stamina} tone="bg-gold" label="Energia">
                <Zap className="size-3 text-gold" />
              </Meter>
              <Meter value={hud.hunger} tone="bg-leaf" label="Fome">
                <Utensils className="size-3 text-leaf" />
              </Meter>
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2 rounded-2xl border border-cream/15 bg-ink/80 px-3 py-2 text-sm backdrop-blur-md">
          <MapPin className="size-4 text-gold" />
          <span className="font-extrabold text-gold">{hud.location}</span>
          <span className="text-cream/40">·</span>
          <span className="text-cream/85">{hud.clock}</span>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-2xl border border-cream/15 bg-ink/80 px-3 py-2 backdrop-blur-md">
            <Coins className="size-5 text-gold" />
            <span className="text-lg font-extrabold text-gold">{hud.coins}</span>
          </div>
          <div className="flex items-center gap-1 rounded-2xl border border-cream/15 bg-ink/80 px-3 py-2 text-xs text-cream/85 backdrop-blur-md">
            <Users className="size-4 text-leaf" />
            {hud.net === "online" ? (hud.peers > 0 ? `${hud.peers} no vale` : "Vale online") : hud.net === "solo" ? "Solo" : "Conectando"}
          </div>
          <button
            type="button"
            aria-label={hud.sound ? "Silenciar" : "Ativar som"}
            onClick={() => engineRef.current?.setSound(!hud.sound)}
            className="flex size-11 items-center justify-center rounded-2xl border border-cream/15 bg-ink/80 text-cream"
          >
            {hud.sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          </button>
          <button
            type="button"
            aria-label="Mochila"
            onClick={() => engineRef.current?.toggleBag()}
            className="flex size-11 items-center justify-center rounded-2xl border border-cream/15 bg-ink/80 text-cream"
          >
            <Backpack className="size-4" />
          </button>
        </div>
      </header>

      <div className="pointer-events-none absolute top-28 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full border border-cream/15 bg-ink/75 px-3 py-1.5 text-xs text-cream backdrop-blur-md md:top-20">
        <span
          className="inline-flex size-6 items-center justify-center text-gold"
          style={{ transform: `rotate(${hud.goalAngle}rad)` }}
        >
          <ArrowUp className="size-4" />
        </span>
        <span className="font-bold">{hud.goalLabel}</span>
        <span className="text-cream/70">{hud.goalMeters} m</span>
      </div>

      {hud.toast ? (
        <div className="pointer-events-none absolute top-40 left-1/2 z-20 max-w-sm -translate-x-1/2 rounded-2xl bg-cream px-4 py-2 text-center text-sm font-bold text-ink md:top-32">
          {hud.toast}
        </div>
      ) : null}

      <div className="pointer-events-none absolute inset-x-0 bottom-36 z-20 flex flex-col items-center gap-2 px-3 md:bottom-28">
        <p className="max-w-md rounded-full bg-ink/70 px-3 py-1 text-center text-xs text-cream/85">{hud.tip}</p>
        {hud.prompt ? (
          <button
            type="button"
            onClick={() => engineRef.current?.interact()}
            className={`pointer-events-auto inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-extrabold text-cream ${hud.promptLive ? "bg-leaf" : "bg-ink/80"}`}
          >
            <Hand className="size-4" />
            {hud.prompt}
            <span className="rounded-md bg-cream/15 px-1.5 py-0.5 text-xs font-bold">E</span>
          </button>
        ) : null}
      </div>

      <div className="absolute inset-x-0 bottom-3 z-20 flex items-end justify-between gap-3 px-3 md:bottom-5 md:justify-center">
        <Joystick
          onChange={(x, y) => engineRef.current?.setStick(x, y)}
        />
        <div className="pointer-events-auto mb-2 flex gap-1.5 rounded-2xl border border-cream/15 bg-ink/75 p-1.5 backdrop-blur-md">
          {HOTBAR.map((slot) => {
            const on = hud.slot === slot.id;
            const count =
              slot.type === "seed" ? (hud.seeds[slot.itemId] ?? 0) : slot.type === "food" ? hud.apples : null;
            return (
              <button
                key={slot.id}
                type="button"
                onClick={() => engineRef.current?.selectSlot(slot.id)}
                className={`hotbar-slot relative flex size-12 flex-col items-center justify-center rounded-xl md:size-14 ${on ? "is-on" : ""}`}
                aria-label={slot.label}
              >
                <span className="absolute top-0.5 left-1 text-xs font-bold text-cream/50">{slot.id}</span>
                <SlotIcon id={slot.itemId} />
                {count !== null ? (
                  <span className="absolute right-1 bottom-0.5 text-xs font-extrabold text-gold">{count}</span>
                ) : null}
              </button>
            );
          })}
        </div>
        <div className="touch-only mb-1 flex flex-col gap-2">
          <Round
            label={hud.riding ? "Desmontar" : "Bicicleta"}
            onClick={() => engineRef.current?.toggleBike()}
          >
            <Bike className="size-5" />
          </Round>
          <Round label="Correr" onPointerDown={() => engineRef.current?.setSprint(true)} onPointerUp={() => engineRef.current?.setSprint(false)}>
            <Zap className="size-5" />
          </Round>
        </div>
      </div>
      <Online name={hud.name} engineRef={engineRef} />
    </>
  );
}

function Meter({ value, tone, label, children }: { value: number; tone: string; label: string; children: ReactNode }) {
  return (
    <div className="flex items-center gap-1" title={label}>
      {children}
      <div className="h-2 w-12 overflow-hidden rounded-full bg-ink md:w-16">
        <div className={`h-full ${tone}`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
    </div>
  );
}

function Round({
  children,
  label,
  onClick,
  onPointerDown,
  onPointerUp,
}: {
  children: ReactNode;
  label: string;
  onClick?: () => void;
  onPointerDown?: () => void;
  onPointerUp?: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      className="flex size-14 items-center justify-center rounded-full border border-cream/20 bg-ink/80 text-cream"
    >
      {children}
    </button>
  );
}

function SlotIcon({ id }: { id: string }) {
  const cls = "size-5";
  if (id === "water") return <Droplets className={`${cls} text-cream`} />;
  if (id === "apple") return <Apple className={`${cls} text-heart`} />;
  if (id === "carrot" || id === "potato") return <Carrot className={`${cls} text-gold`} />;
  if (id === "wheat" || id === "corn") return <Wheat className={`${cls} text-gold`} />;
  return <Sprout className={`${cls} text-leaf`} />;
}

function Joystick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const zoneRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const changeRef = useRef(onChange);
  changeRef.current = onChange;
  useEffect(() => {
    const zone = zoneRef.current;
    const knob = knobRef.current;
    if (!zone || !knob) return;
    let id: number | null = null;
    let sx = 0;
    let sy = 0;
    const start = (e: TouchEvent) => {
      const t = e.changedTouches[0];
      if (!t) return;
      id = t.identifier;
      sx = t.clientX;
      sy = t.clientY;
    };
    const move = (e: TouchEvent) => {
      for (const t of e.changedTouches) {
        if (t.identifier !== id) continue;
        const dx = t.clientX - sx;
        const dy = t.clientY - sy;
        const dist = Math.min(42, Math.hypot(dx, dy));
        const ang = Math.atan2(dy, dx);
        knob.style.transform = `translate(${Math.cos(ang) * dist}px, ${Math.sin(ang) * dist}px)`;
        changeRef.current(Math.cos(ang) * (dist / 42), -Math.sin(ang) * (dist / 42));
      }
    };
    const end = () => {
      id = null;
      knob.style.transform = "translate(0px, 0px)";
      changeRef.current(0, 0);
    };
    zone.addEventListener("touchstart", start, { passive: true });
    zone.addEventListener("touchmove", move, { passive: true });
    zone.addEventListener("touchend", end);
    zone.addEventListener("touchcancel", end);
    return () => {
      zone.removeEventListener("touchstart", start);
      zone.removeEventListener("touchmove", move);
      zone.removeEventListener("touchend", end);
      zone.removeEventListener("touchcancel", end);
    };
  }, []);
  return (
    <div ref={zoneRef} className="joy touch-only" aria-hidden="true">
      <div ref={knobRef} className="joy-knob" />
    </div>
  );
}

function Online({ name, engineRef }: { name: string; engineRef: RefObject<ValleyEngine | null> }) {
  const p2p = useP2PRoom({ room: "ecovalley", name: cleanName(name) });
  useEffect(() => {
    const connected = p2p.peers.filter((p) => p.connectionState === "connected").length;
    if (p2p.joined) valleyStore.setState({ net: "online", peers: connected });
    else if (valleyStore.getState().net === "online") valleyStore.setState({ net: "conectando", peers: 0 });
  }, [p2p.joined, p2p.peers]);

  useEffect(() => {
    const t = window.setTimeout(() => {
      if (!p2p.joined && valleyStore.getState().net === "conectando") valleyStore.setState({ net: "solo" });
    }, 7000);
    return () => window.clearTimeout(t);
  }, [p2p.joined]);

  useEffect(
    () =>
      p2p.onMessage((from, data, channel) => {
        if (channel !== "state") return;
        engineRef.current?.applyRemote(from, data);
      }),
    [p2p.onMessage, engineRef],
  );

  useEffect(() => {
    engineRef.current?.setRemoteIds(p2p.peers.map((p) => p.id));
  }, [p2p.peers, engineRef]);

  useEffect(() => {
    let raf = 0;
    let last = 0;
    const loop = (now: number) => {
      if (now - last >= 100) {
        last = now;
        const snap = engineRef.current?.getNetSnapshot();
        if (snap) p2p.broadcast(snap);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [p2p.broadcast, engineRef]);

  return null;
}

function Shell({
  title,
  icon,
  onClose,
  children,
}: {
  title: string;
  icon: ReactNode;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink/75 p-4">
      <div className="flex max-h-[86vh] w-full max-w-3xl flex-col gap-4 overflow-hidden rounded-3xl border border-ink/10 bg-cream p-5 text-ink">
        <header className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {icon}
            <h2 className="font-display text-2xl">{title}</h2>
          </div>
          <button type="button" aria-label="Fechar" onClick={onClose} className="flex size-11 items-center justify-center rounded-xl text-ink">
            <X className="size-5" />
          </button>
        </header>
        <div className="overflow-y-auto pr-1">{children}</div>
      </div>
    </div>
  );
}

function Shop({ engineRef }: { engineRef: RefObject<ValleyEngine | null> }) {
  const open = valleyStore((s) => s.modal === "shop");
  const coins = valleyStore((s) => s.coins);
  const seeds = valleyStore((s) => s.seeds);
  const apples = valleyStore((s) => s.apples);
  if (!open) return null;
  return (
    <Shell title="Mercado de sementes" icon={<Store className="size-6 text-leaf" />} onClose={() => engineRef.current?.closeModal()}>
      <p className="mb-3 text-sm text-ink/70">Barnaby vende o que a fazenda ainda não tem. Você tem {coins} moedas.</p>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <article className="flex items-center justify-between gap-3 rounded-2xl border border-ink/10 bg-ink/5 p-3">
          <div className="flex items-center gap-2">
            <Apple className="size-5 text-heart" />
            <div>
              <p className="font-extrabold">Maçã</p>
              <p className="text-xs text-ink/60">Enche a fome · você tem {apples}</p>
            </div>
          </div>
          <button
            type="button"
            disabled={coins < APPLE_COST}
            onClick={() => engineRef.current?.buyApple()}
            className="rounded-xl bg-leaf px-3 py-2 text-sm font-extrabold text-cream disabled:opacity-40"
          >
            {APPLE_COST}
          </button>
        </article>
        {PLANTS.map((plant) => (
          <article key={plant.id} className="flex items-center justify-between gap-3 rounded-2xl border border-ink/10 bg-ink/5 p-3">
            <div>
              <p className="font-extrabold">{plant.name}</p>
              <p className="text-xs text-ink/60">
                {plant.rarity} · vende {plant.sellValue} · tem {seeds[plant.id] ?? 0}
              </p>
            </div>
            <button
              type="button"
              disabled={coins < plant.seedCost}
              onClick={() => engineRef.current?.buy(plant.id)}
              className="rounded-xl bg-gold px-3 py-2 text-sm font-extrabold text-ink disabled:opacity-40"
            >
              {plant.seedCost}
            </button>
          </article>
        ))}
      </div>
    </Shell>
  );
}

function Sell({ engineRef }: { engineRef: RefObject<ValleyEngine | null> }) {
  const open = valleyStore((s) => s.modal === "sell");
  const crops = valleyStore((s) => s.crops);
  if (!open) return null;
  const rows = PLANTS.filter((p) => (crops[p.id] ?? 0) > 0);
  const total = rows.reduce((sum, p) => sum + (crops[p.id] ?? 0) * p.sellValue, 0);
  return (
    <Shell title="Atacado da Beatriz" icon={<Coins className="size-6 text-gold" />} onClose={() => engineRef.current?.closeModal()}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-sm text-ink/70">Ela paga na hora. Volte à fazenda com as moedas.</p>
        <button
          type="button"
          disabled={total <= 0}
          onClick={() => engineRef.current?.sellAll()}
          className="rounded-xl bg-leaf px-3 py-2 text-sm font-extrabold text-cream disabled:opacity-40"
        >
          Vender tudo · {total}
        </button>
      </div>
      {rows.length === 0 ? (
        <p className="rounded-2xl bg-ink/5 px-4 py-8 text-center text-sm text-ink/70">
          Mochila vazia. Colha nos canteiros da fazenda e volte pela estrada.
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {rows.map((plant) => {
            const n = crops[plant.id] ?? 0;
            return (
              <article key={plant.id} className="flex items-center justify-between gap-3 rounded-2xl border border-ink/10 bg-ink/5 p-3">
                <div>
                  <p className="font-extrabold">{plant.name}</p>
                  <p className="text-xs text-ink/60">
                    {n} × {plant.sellValue} = {n * plant.sellValue}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => engineRef.current?.sell(plant.id)}
                  className="rounded-xl bg-gold px-3 py-2 text-sm font-extrabold text-ink"
                >
                  Vender
                </button>
              </article>
            );
          })}
        </div>
      )}
    </Shell>
  );
}

function Bag({ engineRef }: { engineRef: RefObject<ValleyEngine | null> }) {
  const open = valleyStore((s) => s.modal === "bag");
  const seeds = valleyStore((s) => s.seeds);
  const crops = valleyStore((s) => s.crops);
  const apples = valleyStore((s) => s.apples);
  if (!open) return null;
  const seedRows = PLANTS.filter((p) => (seeds[p.id] ?? 0) > 0);
  const cropRows = PLANTS.filter((p) => (crops[p.id] ?? 0) > 0);
  return (
    <Shell title="Mochila" icon={<Backpack className="size-6 text-leaf" />} onClose={() => engineRef.current?.closeModal()}>
      <p className="mb-2 text-sm font-extrabold">Sementes</p>
      {seedRows.length === 0 ? <p className="mb-4 text-sm text-ink/60">Nenhuma. A loja fica na cidade.</p> : null}
      <ul className="mb-4 grid grid-cols-2 gap-2">
        {seedRows.map((p) => (
          <li key={p.id} className="rounded-xl bg-ink/5 px-3 py-2 text-sm">
            {p.name} · {seeds[p.id]}
          </li>
        ))}
      </ul>
      <p className="mb-2 text-sm font-extrabold">Colheita</p>
      {cropRows.length === 0 ? <p className="mb-4 text-sm text-ink/60">Nada colhido ainda.</p> : null}
      <ul className="mb-4 grid grid-cols-2 gap-2">
        {cropRows.map((p) => (
          <li key={p.id} className="rounded-xl bg-ink/5 px-3 py-2 text-sm">
            {p.name} · {crops[p.id]} · vale {(crops[p.id] ?? 0) * p.sellValue}
          </li>
        ))}
      </ul>
      <p className="text-sm">Maçãs: {apples}</p>
    </Shell>
  );
}
