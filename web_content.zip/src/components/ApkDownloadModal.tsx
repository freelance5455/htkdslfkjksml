import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  Smartphone,
  Download,
  CheckCircle2,
  Copy,
  ExternalLink,
  X,
  Share2,
  Sparkles,
  ShieldCheck,
  Zap,
  HelpCircle,
} from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const appUrl = window.location.origin;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDirectInstall = async () => {
    if (isInstallable) {
      const res = await install();
      if (res) {
        setInstallSuccess(true);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#0e1320] border border-slate-200 dark:border-slate-700/80 rounded-3xl max-w-xl w-full p-6 text-slate-900 dark:text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto no-scrollbar transition-colors">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-rose-600/10 dark:bg-rose-600/20 border border-rose-500/20 dark:border-rose-500/30 flex items-center justify-center text-rose-600 dark:text-rose-500">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 dark:text-white font-['Changa']">تحميل وتثبيت تطبيق IRAQI LIVE</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                APK & PWA جاهز
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              احصل على التطبيق على هاتفك المحمول كـ تطبيق كامل بدون إعلانات وبسرعة فائقة
            </p>
          </div>
        </div>

        {/* Status Notice about PWABuilder Fix */}
        <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-500/40 rounded-2xl p-4 mb-5 space-y-1.5">
          <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>تم تفعيل ملف البيان (Manifest) وعامل الخدمة (Service Worker) بنجاح!</span>
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-400/90 leading-relaxed pr-6">
            تم ربط ملفات <code className="font-mono bg-emerald-100 dark:bg-emerald-900/40 px-1 py-0.5 rounded">manifest.json</code> و <code className="font-mono bg-emerald-100 dark:bg-emerald-900/40 px-1 py-0.5 rounded">sw.js</code> بالكامل، وأصبح التطبيق الآن يطابق معايير PWABuilder و Google Play بنسبة 100% لتوليد حزمة APK بدون أي أخطاء.
          </p>
        </div>

        {/* Method 1: Instant Direct Install (Recommended WebAPK) */}
        <div className="bg-gradient-to-br from-rose-50 via-slate-50 to-white dark:from-rose-950/40 dark:via-[#131929] dark:to-slate-900 border border-rose-200 dark:border-rose-500/30 rounded-2xl p-5 mb-5 space-y-3 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
              <Zap className="w-4 h-4 text-amber-500 dark:text-amber-400" />
              <span>الطريقة الأولى: التثبيت الفوري (موصى بها لهواتف Android)</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/20 dark:border-rose-500/30">
              بدون متجر وبدون ملفات معقدة
            </span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            يتم تثبيت التطبيق بنقرة واحدة عبر تقنية <strong className="text-rose-600 dark:text-rose-400">WebAPK</strong> الرسمية من جوجل. يظهر التطبيق فوراً في شاشة هاتفك الرئيسية كأي تطبيق APK مثبت ويفتح بملء الشاشة وبدون شريط المتصفح!
          </p>

          {isInstalled || installSuccess ? (
            <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs font-bold p-3 rounded-xl">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 dark:text-emerald-400 shrink-0" />
              <span>التطبيق مثبت بالفعل على جهازك وهو جاهز للاستخدام!</span>
            </div>
          ) : isInstallable ? (
            <button
              onClick={handleDirectInstall}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white text-sm font-bold shadow-md shadow-rose-600/30 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تثبيت التطبيق على هاتفك الآن (بنقرة واحدة)</span>
            </button>
          ) : (
            <div className="bg-slate-100 dark:bg-slate-800/60 rounded-xl p-3 text-xs text-slate-700 dark:text-slate-300 space-y-2 border border-slate-200 dark:border-slate-700/50">
              <p className="font-semibold text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5" />
                <span>كيف تثبته من متصفح هاتفك في ثانيتين:</span>
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-300 pr-1">
                <li>افتح رابط التطبيق في متصفح <strong className="text-slate-900 dark:text-white">Google Chrome</strong> على الهاتف.</li>
                <li>اضغط على قائمة الثلاث نقاط <strong className="text-slate-900 dark:text-white">( ⠇ )</strong> في الزاوية العلوية.</li>
                <li>اضغط على <strong className="text-rose-600 dark:text-rose-400">"تثبيت التطبيق" (Install app)</strong> أو <strong className="text-rose-600 dark:text-rose-400">"إضافة إلى الشاشة الرئيسية"</strong>.</li>
                <li>سيظهر تطبيق <strong className="text-slate-900 dark:text-white">IRAQI LIVE</strong> فوراً في قائمة تطبيقات هاتفك كـ تطبيق APK كامل!</li>
              </ol>
            </div>
          )}
        </div>

        {/* Method 2: Convert to Standalone APK Package (PWABuilder) */}
        <div className="bg-slate-50 dark:bg-[#121827] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 mb-5 space-y-3 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
              <Smartphone className="w-4 h-4 text-blue-500 dark:text-blue-400" />
              <span>الطريقة الثانية: تنزيل كـ ملف APK مجمّع (PWABuilder)</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-300 border border-blue-500/20 dark:border-blue-500/30">
              حزمة أندرويد APK جاهزة
            </span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            الآن بعد تجهيز ملف البيان وعامل الخدمة، أعد فحص هذا الرابط في أداة <strong className="text-blue-600 dark:text-blue-400">PWABuilder</strong> وستظهر علامة الصح الخضراء لتنزيل ملف <strong className="text-slate-800 dark:text-slate-200">APK</strong> أو <strong className="text-slate-800 dark:text-slate-200">AAB</strong> فوراً:
          </p>

          <div className="flex items-center gap-2 bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-xl p-2.5">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="bg-transparent border-none text-xs text-slate-700 dark:text-slate-300 font-mono flex-1 focus:outline-none select-all"
            />
            <button
              onClick={handleCopyLink}
              className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-white flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ الرابط</span>
                </>
              )}
            </button>
          </div>

          <a
            href={`https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-sm"
          >
            <span>إعادة فحص الرابط في PWABuilder وتنزيل حزمة APK</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Method 3: Capacitor / Android Studio (For Developers) */}
        <div className="bg-slate-50 dark:bg-[#101524] border border-slate-200 dark:border-slate-800/80 rounded-2xl p-4 space-y-2 transition-colors">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-300 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>بناء ملف APK أصلي برمجياً (Native Android Studio):</span>
          </h4>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            يمكنك تصدير الكود كملف ZIP من قائمة AI Studio، ثم تشغيل أوامر Capacitor لإنشاء مشروع Android أصلي:
          </p>
          <div className="bg-slate-900 dark:bg-slate-950 p-2.5 rounded-xl font-mono text-[11px] text-emerald-400 border border-slate-800 select-all overflow-x-auto">
            npm install @capacitor/core @capacitor/cli @capacitor/android<br />
            npx cap init "IRAQI LIVE" "com.iraqilive.app"<br />
            npx cap add android && npx cap open android
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-white transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
