import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  ShieldCheck,
  Sparkles,
  X,
  Layers,
  ArrowRight
} from 'lucide-react';
import { sound } from '../services/sound';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt?: any;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
}) => {
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [installStatus, setInstallStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const appUrl = typeof window !== 'undefined'
    ? window.location.origin
    : 'https://ais-pre-cfhkigzgkebfywkokwcovg-494938916164.asia-northeast1.run.app';

  const manifestUrl = `${appUrl}/manifest.json`;

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        if (choice.outcome === 'accepted') {
          sound.triggerCelebration(80, 70);
          sound.levelUp();
          setInstallStatus('Android WebAPK installation initiated!');
        } else {
          setInstallStatus('Installation was dismissed.');
        }
      } catch (err) {
        console.error(err);
      }
    } else {
      // Fallback instructions for Android Chrome / Edge
      setInstallStatus('Open this URL in Chrome on your Android device and tap "Install app" or "Add to Home Screen" to install the native WebAPK.');
    }
  };

  const handleCopyCliCommand = async () => {
    const cmd = `npx @bubblewrap/cli init --manifest="${manifestUrl}" && npx @bubblewrap/cli build`;
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedCmd(true);
      sound.correct();
      setTimeout(() => setCopiedCmd(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleOpenPwaBuilder = () => {
    sound.triggerCelebration(50, 40);
    const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;
    window.open(pwaBuilderUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-800 dark:text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="apk-modal-title"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-black text-xl shadow-inner">
              🤖
            </div>
            <div>
              <h2 id="apk-modal-title" className="text-base sm:text-lg font-black tracking-tight leading-tight">
                VocabMuse Android APK Center
              </h2>
              <p className="text-xs text-emerald-100 font-medium leading-tight">
                Native Android Installation & Standalone APK Package
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition-all"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 smooth-scroll text-left">
          
          {/* Method 1: Instant Native Android WebAPK Installation */}
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-300 dark:border-emerald-700/80 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                  1
                </span>
                <span className="font-black text-sm text-slate-900 dark:text-white">
                  Direct Android Install (WebAPK)
                </span>
              </div>
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200">
                Recommended
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
              অ্যান্ড্রয়েড ডিভাইসে ক্রোম স্বয়ংক্রিয়ভাবে গুগল সার্টিফাইড <strong>WebAPK</strong> তৈরি করে হোমস্ক্রিনে ইনস্টল করে। এটি কোনো ব্রাউজার বার ছাড়া সম্পূর্ণ অফলাইনে একটি দেশীয় অ্যাপের মতো চলে।
            </p>

            <button
              onClick={handleNativeInstall}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-extrabold text-xs sm:text-sm shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Smartphone className="w-4 h-4" />
              <span>Install Directly on Android Phone</span>
            </button>

            {installStatus && (
              <div className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 p-2 rounded-lg bg-emerald-100/60 dark:bg-emerald-900/40 animate-in fade-in">
                {installStatus}
              </div>
            )}
          </div>

          {/* Method 2: 1-Click Standalone Signed APK via PWABuilder */}
          <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                  2
                </span>
                <span className="font-black text-sm text-slate-900 dark:text-white">
                  Download Standalone .APK File (PWABuilder)
                </span>
              </div>
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-indigo-200 dark:bg-indigo-900 text-indigo-900 dark:text-indigo-200">
                Google TWA
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
              মাইক্রোসফট ও গুগলের অফিসিয়াল <strong>PWABuilder</strong> এই অ্যাপটির লাইভ ইউআরএল থেকে সাইন করা ইনস্টলেবল <code>.apk</code> প্যাকেজ তৈরি করে। আপনি সরাসরি ডাউনলোড করে যেকোনো অ্যান্ড্রয়েড ফোনে সাইডলোড (Sideload) করতে পারেন।
            </p>

            <button
              onClick={handleOpenPwaBuilder}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white font-extrabold text-xs sm:text-sm shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Generate & Download APK on PWABuilder</span>
            </button>
          </div>

          {/* Method 3: Command Line APK Package Generator (Bubblewrap CLI) */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-700 text-white font-black text-xs flex items-center justify-center shrink-0">
                  3
                </span>
                <span className="font-black text-sm text-slate-900 dark:text-white">
                  Local Terminal Command (Bubblewrap CLI)
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Generate a production Google Play Store compatible APK / AAB locally with Google's Bubblewrap CLI:
            </p>

            <div className="relative bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-[10px] sm:text-[11px] overflow-x-auto flex items-center justify-between gap-2">
              <code>npx @bubblewrap/cli init --manifest="{manifestUrl}"</code>
              <button
                onClick={handleCopyCliCommand}
                className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white shrink-0 flex items-center gap-1 transition-all"
                title="Copy terminal command"
              >
                {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Features in this Android Build */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
            <div className="font-black text-slate-900 dark:text-white flex items-center gap-1.5 text-[11px] uppercase tracking-wide">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Verified Android Capabilities:
            </div>
            <ul className="grid grid-cols-2 gap-1 text-[11px]">
              <li className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                ✓ 100% Offline Caching (Service Worker)
              </li>
              <li className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                ✓ Fullscreen Standalone Viewport
              </li>
              <li className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                ✓ 512px High-DPI Maskable Icon
              </li>
              <li className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                ✓ Local Audio Synthesis Engine
              </li>
            </ul>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-extrabold text-xs hover:opacity-90 active:scale-95 transition-all"
          >
            Close Center
          </button>
        </div>

      </div>
    </div>
  );
};
