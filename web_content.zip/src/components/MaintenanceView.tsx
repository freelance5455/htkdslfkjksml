import React, { useState, useRef } from 'react';
import {
  Wrench,
  Plus,
  Search,
  Printer,
  Download,
  Edit2,
  Trash2,
  Camera,
  Upload,
  CheckCircle2,
  XCircle,
  Clock,
  Package,
  Image as ImageIcon,
  Check,
  AlertTriangle,
  X,
  Loader2,
  Share2,
  ArrowLeft,
  Home,
  FileSpreadsheet,
  ArrowRight,
  ChevronRight
} from 'lucide-react';
import { MaintenanceReport, SparePartUsed, MaintenanceImage, MaintenanceOutcome, MaintenanceType, MaintenancePlantLine } from '../types/domain';
import { compressImage } from '../services/storage';
import { downloadElementAsPdf, printHtmlSafely, generateElementPdfBlob } from '../utils/pdfGenerator';
import { generateMaintenanceExcelBlob } from '../services/industryStorage';
import { ShareFileModal } from './ShareFileModal';

interface Props {
  reports: MaintenanceReport[];
  onSaveReport: (report: MaintenanceReport) => void;
  onDeleteReport: (id: string) => void;
  onOpenPhotoLightbox: (url: string, caption: string, title: string) => void;
  onBackToMenu?: () => void;
}

export const MaintenanceView: React.FC<Props> = ({
  reports,
  onSaveReport,
  onDeleteReport,
  onOpenPhotoLightbox,
  onBackToMenu
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [lineFilter, setLineFilter] = useState<string>('all');
  const [outcomeFilter, setOutcomeFilter] = useState<string>('all');
  const [selectedReport, setSelectedReport] = useState<MaintenanceReport | null>(reports[0] || null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<MaintenanceReport | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const sheetRef = useRef<HTMLDivElement>(null);

  // Filtered list
  const filteredReports = reports.filter((r) => {
    if (lineFilter !== 'all' && r.plantName !== lineFilter) return false;
    if (outcomeFilter !== 'all' && r.outcome !== outcomeFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.plantName.toLowerCase().includes(q) ||
      (r.equipmentServiced && r.equipmentServiced.toLowerCase().includes(q)) ||
      r.protocolNumber.toLowerCase().includes(q) ||
      r.interventionType.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      r.operatorName.toLowerCase().includes(q)
    );
  });

  const handleCreateNew = () => {
    setEditingReport(null);
    setIsFormOpen(true);
  };

  const handleEdit = (report: MaintenanceReport) => {
    setEditingReport(report);
    setIsFormOpen(true);
  };

  // Direct PDF Download
  const handleDownloadPdf = async (report: MaintenanceReport) => {
    if (!sheetRef.current) return;
    setIsGeneratingPdf(true);
    setActionFeedback('Generazione PDF manutenzione in corso...');
    try {
      const safeName = `Verbale_Manutenzione_${report.plantName.replace(/\s+/g, '_')}_${report.protocolNumber}`;
      await downloadElementAsPdf(sheetRef.current, safeName);
      setActionFeedback('PDF manutenzione salvato regolarmente.');
    } catch (err) {
      console.error(err);
      setActionFeedback('Errore generazione PDF. Apertura dialogo di stampa...');
      if (sheetRef.current) {
        printHtmlSafely(sheetRef.current.innerHTML, `Verbale Manutenzione ${report.protocolNumber}`);
      }
    } finally {
      setIsGeneratingPdf(false);
      setTimeout(() => setActionFeedback(null), 4000);
    }
  };

  // Native Print
  const handleNativePrint = (report: MaintenanceReport) => {
    if (sheetRef.current) {
      printHtmlSafely(sheetRef.current.innerHTML, `Verbale Manutenzione ${report.protocolNumber}`);
    } else {
      window.print();
    }
  };

  return (
    <div className="space-y-6 pb-16 sm:pb-0">
      {/* Mobile Top Back Banner for Google Pixel 9 */}
      {onBackToMenu && (
        <div className="flex items-center justify-between bg-neutral-900 text-white px-3.5 py-2.5 rounded-2xl shadow-sm md:hidden">
          <button
            onClick={onBackToMenu}
            className="inline-flex items-center gap-2 text-xs font-bold hover:text-amber-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Torna al Menù Principale</span>
          </button>
          <span className="text-[10px] font-mono text-neutral-400">Google Pixel 9</span>
        </div>
      )}

      {/* Top Banner (no-print) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-neutral-200 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-neutral-900">
              Registro Manutenzioni Impianti
            </h1>
            <span className="text-[11px] font-mono text-neutral-500 bg-neutral-200 px-2 py-0.5 rounded">
              Sabbiatura & Verniciatura a Liquido
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Tracciamento interventi su LINEA 1, LINEA 2, LINEA 3, LINEA 4, LINEA 6, POLIN, ALTRO, attrezzature revisionate, ricambi e verbali PDF
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleCreateNew}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Nuova Manutenzione</span>
          </button>
        </div>
      </div>

      {/* Action feedback banner */}
      {actionFeedback && (
        <div className="p-3 bg-neutral-900 text-white text-xs rounded-lg flex items-center justify-between no-print shadow-sm">
          <div className="flex items-center gap-2">
            {isGeneratingPdf ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            <span>{actionFeedback}</span>
          </div>
          {!isGeneratingPdf && (
            <button onClick={() => setActionFeedback(null)} className="text-neutral-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* VIEW MODE CONDITIONAL: LISTATA PRINCIPALE O DETTAGLIO */}
      {viewMode === 'list' ? (
        /* ================= LISTATA PRINCIPALE MANUTENZIONI ================= */
        <div className="space-y-4 max-w-4xl mx-auto no-print">
          {/* Search & Filters */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cerca per linea, attrezzatura revisionata, ricambio..."
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-900"
                />
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 text-xs font-mono text-neutral-600">
                <span className="bg-neutral-100 px-3 py-1.5 rounded-xl font-semibold">
                  {filteredReports.length} {filteredReports.length === 1 ? 'Intervento' : 'Interventi'}
                </span>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Nuova Manutenzione</span>
                </button>
              </div>
            </div>

            {/* Line Filter Combobox Buttons */}
            <div className="pt-2 border-t border-neutral-100 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-neutral-600 uppercase">
                <span>Impianto / Linea:</span>
                {lineFilter !== 'all' && (
                  <button
                    onClick={() => setLineFilter('all')}
                    className="text-neutral-500 hover:text-neutral-900 underline text-[11px] font-medium"
                  >
                    Mostra tutti gli impianti
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(['all', 'LINEA 1', 'LINEA 2', 'LINEA 3', 'LINEA 4', 'LINEA 6', 'POLIN', 'ALTRO'] as const).map((line) => {
                  const isSelected = lineFilter === line;
                  const label = line === 'all' ? 'Tutti gli Impianti' : line;
                  return (
                    <button
                      key={line}
                      onClick={() => setLineFilter(line)}
                      className={`px-3 py-1.5 text-xs rounded-xl transition-all font-bold font-mono ${
                        isSelected
                          ? 'bg-neutral-900 text-white shadow-xs'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Outcome Filter */}
            <div className="flex items-center gap-2 pt-2 border-t border-neutral-100 text-xs">
              <span className="text-[10px] font-bold text-neutral-500 uppercase mr-1">Esito Intervento:</span>
              <button
                onClick={() => setOutcomeFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  outcomeFilter === 'all' ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                Tutti
              </button>
              <button
                onClick={() => setOutcomeFilter('positivo')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  outcomeFilter === 'positivo' ? 'bg-emerald-700 text-white' : 'text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                ✓ Positivo / Risolto
              </button>
              <button
                onClick={() => setOutcomeFilter('negativo')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  outcomeFilter === 'negativo' ? 'bg-rose-700 text-white' : 'text-rose-700 hover:bg-rose-50'
                }`}
              >
                ✗ Negativo / In corso
              </button>
            </div>
          </div>

          {/* List of Maintenance Cards */}
          <div className="space-y-3">
            {filteredReports.length === 0 ? (
              <div className="p-10 bg-white border border-neutral-200 rounded-3xl text-center space-y-3 shadow-xs">
                <Wrench className="w-10 h-10 text-neutral-300 mx-auto" />
                <h3 className="text-sm font-bold text-neutral-800">Nessuna Manutenzione registrata</h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                  Nessun intervento registrato con i filtri selezionati. Modifica i filtri o inserisci una nuova manutenzione.
                </p>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Registra nuova manutenzione</span>
                </button>
              </div>
            ) : (
              filteredReports.map((rep) => {
                const isPos = rep.outcome === 'positivo';
                const totalParts = (rep.spareParts || []).reduce((acc, p) => acc + (p.quantity || 0), 0);
                const totalPhotos = (rep.images || []).length;

                return (
                  <div
                    key={rep.id}
                    onClick={() => {
                      setSelectedReport(rep);
                      setViewMode('detail');
                    }}
                    className="bg-white border border-neutral-200 hover:border-neutral-400 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-neutral-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs sm:text-sm font-bold text-white bg-neutral-900 px-2.5 py-1 rounded-lg shadow-2xs">
                          {rep.plantName}
                        </span>
                        <span className="font-mono text-xs font-bold text-neutral-700 bg-neutral-100 px-2.5 py-1 rounded-lg border border-neutral-200">
                          {rep.protocolNumber}
                        </span>
                        <span className="text-[11px] font-mono text-neutral-500">
                          📅 {rep.date} {rep.time ? `· ⏰ ${rep.time}` : ''}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 self-start sm:self-auto">
                        <span
                          className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                            isPos
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}
                        >
                          {isPos ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Risolto</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              <span>In corso</span>
                            </>
                          )}
                        </span>
                      </div>
                    </div>

                    <div className="py-2.5 space-y-1.5">
                      {rep.equipmentServiced && (
                        <div className="flex items-center gap-2 text-xs font-bold text-neutral-900">
                          <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono text-[10px] uppercase border border-amber-200">
                            Attrezzatura
                          </span>
                          <span className="group-hover:text-amber-700 transition-colors">
                            {rep.equipmentServiced}
                          </span>
                        </div>
                      )}

                      <div className="text-xs text-neutral-700 font-medium">
                        Tipo: <strong className="text-neutral-900">{rep.interventionType}</strong>
                      </div>

                      <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
                        {rep.description}
                      </p>
                    </div>

                    <div className="pt-2.5 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3 text-xs text-neutral-500 font-medium">
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <Clock className="w-3 h-3 text-neutral-700" />
                          {rep.timeSpentHours}h {rep.timeSpentMinutes}m
                        </span>
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <Package className="w-3 h-3 text-neutral-700" />
                          {totalParts} Ricambi
                        </span>
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <ImageIcon className="w-3 h-3 text-neutral-700" />
                          {totalPhotos} Foto
                        </span>
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        {/* Instant WhatsApp / App Share Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReport(rep);
                            setIsShareModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                          title="Condividi subito questo verbale su WhatsApp o altre App"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Condividi</span>
                        </button>

                        {/* Open Report Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReport(rep);
                            setViewMode('detail');
                          }}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                        >
                          <span>Apri Verbale</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        /* ================= DETTAGLIO VERBALE A PIENO SCHERMO ================= */
        <div className="space-y-4 max-w-5xl mx-auto">
          {/* Top Back Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-neutral-900 text-white p-3 rounded-2xl shadow-sm no-print">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-colors"
              >
                <ArrowLeft className="w-4 h-4 text-amber-400" />
                <span>← Torna all'Elenco Manutenzioni</span>
              </button>

              {onBackToMenu && (
                <button
                  type="button"
                  onClick={onBackToMenu}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Menù Principale</span>
                </button>
              )}
            </div>

            {selectedReport && (
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-neutral-400 hidden sm:inline">Verbale:</span>
                <span className="bg-neutral-800 text-sky-300 font-bold px-2.5 py-1 rounded-lg">
                  {selectedReport.protocolNumber} · {selectedReport.plantName}
                </span>
              </div>
            )}
          </div>
          {selectedReport ? (
            <>
              {/* Action Bar (no-print) */}
              <div className="bg-white border border-neutral-200 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 no-print shadow-xs">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded font-mono">
                    {selectedReport.plantName}
                  </span>
                  <span className="text-xs text-neutral-500 font-mono">
                    {selectedReport.protocolNumber}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Share on WhatsApp / Native Android Share Sheet */}
                  <button
                    onClick={() => setIsShareModalOpen(true)}
                    title="Condividi verbale PDF o Excel su WhatsApp o altre App"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-md transition-colors shadow-xs"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Condividi (WhatsApp / App)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadPdf(selectedReport)}
                    disabled={isGeneratingPdf}
                    title="Scarica PDF verbale di manutenzione"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors disabled:opacity-50"
                  >
                    {isGeneratingPdf ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Download className="w-3.5 h-3.5" />
                    )}
                    <span>{isGeneratingPdf ? 'Generazione PDF...' : 'Scarica PDF'}</span>
                  </button>

                  <button
                    onClick={() => handleNativePrint(selectedReport)}
                    title="Stampa documento"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded-md transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Stampa</span>
                  </button>

                  <button
                    onClick={() => handleEdit(selectedReport)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Modifica</span>
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm('Eliminare definitivamente questo report di manutenzione?')) {
                        onDeleteReport(selectedReport.id);
                        setSelectedReport(reports.find((r) => r.id !== selectedReport.id) || null);
                      }
                    }}
                    className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Printable PDF Recap Document (with ref for jsPDF capture) */}
              <div
                ref={sheetRef}
                id="printable-maintenance-report"
                className="bg-white border border-neutral-300 rounded-lg p-8 text-neutral-900 shadow-sm print:p-0 print:border-none print:shadow-none text-xs font-sans space-y-5"
              >
                {/* PDF Header */}
                <div className="border-b-2 border-neutral-900 pb-4 flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-3">
                      <div className="border-2 border-neutral-900 px-2.5 py-1 text-sm font-extrabold tracking-tighter uppercase font-mono bg-neutral-900 text-white">
                        Sfiller
                      </div>
                      <div className="text-[10px] text-neutral-600 font-medium">
                        SABBIATURA E VERNICIATURA A LIQUIDO<br />
                        <span className="text-[9px] text-neutral-400">Servizio Tecnico & Manutenzione Impianti</span>
                      </div>
                    </div>
                    <h2 className="text-base font-black uppercase tracking-wider text-neutral-900 mt-2">
                      Verbale di Manutenzione Impianti
                    </h2>
                  </div>

                  <div className="text-right">
                    <div className="font-mono text-sm font-bold text-neutral-900">
                      {selectedReport.protocolNumber}
                    </div>
                    <div className="text-[11px] text-neutral-600 font-mono mt-0.5">
                      DATA: <strong className="text-neutral-900">{selectedReport.date}</strong> {selectedReport.time && `ore ${selectedReport.time}`}
                    </div>
                  </div>
                </div>

                {/* Key Information Box (Nome Impianto [LINEA 1, 2, 3], Attrezzatura revisionata, Tipo, Esito, Tempo) */}
                <div className="border border-neutral-900 rounded overflow-hidden">
                  <div className="bg-neutral-100 px-3 py-1.5 font-bold text-[11px] uppercase tracking-wider border-b border-neutral-900 flex justify-between">
                    <span>Dati Principali dell&apos;Intervento</span>
                    <span className="font-mono font-bold text-neutral-900">{selectedReport.plantName}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-neutral-900 text-[11px]">
                    <div className="p-3 bg-neutral-50/70">
                      <span className="text-[10px] text-neutral-500 font-bold uppercase block">
                        Nome Impianto
                      </span>
                      <span className="font-black text-base text-neutral-900 block mt-0.5 font-mono">
                        {selectedReport.plantName}
                      </span>
                    </div>

                    <div className="p-3">
                      <span className="text-[10px] text-neutral-500 font-bold uppercase block">
                        Tipo Intervento
                      </span>
                      <span className="font-semibold text-neutral-900 block mt-0.5">
                        {selectedReport.interventionType}
                      </span>
                    </div>

                    <div className={`p-3 ${selectedReport.outcome === 'positivo' ? 'bg-emerald-50' : 'bg-rose-50'}`}>
                      <span className="text-[10px] text-neutral-500 font-bold uppercase block">
                        Esito Collaudo
                      </span>
                      <span className={`font-black text-sm block mt-0.5 uppercase ${
                        selectedReport.outcome === 'positivo' ? 'text-emerald-800' : 'text-rose-800'
                      }`}>
                        {selectedReport.outcome === 'positivo' ? '✓ POSITIVO (COLLAUDATO)' : '✗ NEGATIVO (DA RIPETERE)'}
                      </span>
                    </div>
                  </div>

                  {/* FIELD DIRECTLY UNDER NOME IMPIANTO: Attrezzatura revisionata */}
                  <div className="p-3 border-t border-neutral-900 bg-amber-50/50">
                    <span className="text-[10px] text-amber-900 font-bold uppercase tracking-wider block">
                      Attrezzatura revisionata:
                    </span>
                    <span className="font-bold text-sm text-neutral-900 block mt-0.5">
                      {selectedReport.equipmentServiced || 'Nessuna specifica attrezzatura registrata'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 divide-x divide-neutral-900 border-t border-neutral-900 text-[11px] bg-neutral-50/60">
                    <div className="p-2.5">
                      <span className="text-[10px] text-neutral-500 font-semibold block">Tempo Impiegato</span>
                      <span className="font-mono font-bold text-neutral-900 text-xs">
                        {selectedReport.timeSpentHours} ore e {selectedReport.timeSpentMinutes} minuti
                      </span>
                    </div>
                    <div className="p-2.5">
                      <span className="text-[10px] text-neutral-500 font-semibold block">Tecnico Operatore</span>
                      <span className="font-semibold text-neutral-900">
                        {selectedReport.operatorName}
                      </span>
                    </div>
                    <div className="p-2.5">
                      <span className="text-[10px] text-neutral-500 font-semibold block">Supervisore / Responsabile</span>
                      <span className="font-semibold text-neutral-900">
                        {selectedReport.supervisorName || 'M. Preato'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Descrizione Intervento Eseguito */}
                <div className="space-y-1.5">
                  <h3 className="font-bold text-[11px] uppercase tracking-wider text-neutral-800">
                    Descrizione Dettagliata dell&apos;Intervento e Diagnosi Guasto
                  </h3>
                  <div className="p-3 bg-neutral-50 border border-neutral-300 rounded text-xs leading-relaxed text-neutral-800 whitespace-pre-wrap">
                    {selectedReport.description}
                  </div>
                </div>

                {/* Elenco Ricambi Utilizzati */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-[11px] uppercase tracking-wider text-neutral-800">
                      Elenco Ricambi e Componenti Sostituiti ({selectedReport.spareParts.length})
                    </h3>
                  </div>

                  {selectedReport.spareParts.length === 0 ? (
                    <div className="p-3 border border-neutral-200 rounded text-center text-[11px] text-neutral-400 bg-neutral-50">
                      Nessun pezzo di ricambio sostituito (solo manutenzione, pulizia o taratura).
                    </div>
                  ) : (
                    <div className="border border-neutral-900 rounded overflow-hidden">
                      <table className="w-full text-left text-[11px] border-collapse">
                        <thead>
                          <tr className="bg-neutral-100 border-b border-neutral-900 font-bold text-[10px] uppercase text-neutral-700">
                            <th className="p-2 w-32">Codice Ricambio</th>
                            <th className="p-2">Descrizione Materiale</th>
                            <th className="p-2 w-20 text-center">Quantità</th>
                            <th className="p-2">Note / Destinazione</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-200">
                          {selectedReport.spareParts.map((sp) => (
                            <tr key={sp.id} className="hover:bg-neutral-50">
                              <td className="p-2 font-mono font-semibold text-neutral-900">
                                {sp.code}
                              </td>
                              <td className="p-2 font-medium text-neutral-800">
                                {sp.description}
                              </td>
                              <td className="p-2 font-mono text-center font-bold text-neutral-900">
                                {sp.quantity} {sp.unit}
                              </td>
                              <td className="p-2 text-neutral-600 italic">
                                {sp.notes || '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Fotografie Allegate */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-[11px] uppercase tracking-wider text-neutral-800">
                      Documentazione Fotografica Intervento ({selectedReport.images.length})
                    </h3>
                  </div>

                  {selectedReport.images.length === 0 ? (
                    <div className="p-3 border border-neutral-200 rounded text-center text-[11px] text-neutral-400 bg-neutral-50">
                      Nessun rilievo fotografico allegato a questo intervento.
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      {selectedReport.images.map((img) => (
                        <div
                          key={img.id}
                          className="border border-neutral-300 rounded overflow-hidden cursor-pointer"
                          onClick={() => onOpenPhotoLightbox(img.url, img.caption, `${selectedReport.plantName} - ${selectedReport.equipmentServiced}`)}
                        >
                          <div className="relative aspect-16/9 bg-neutral-100">
                            <img
                              src={img.url}
                              alt={img.caption}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute top-1 left-1 text-[9px] font-bold text-white bg-black/70 px-1.5 py-0.5 rounded">
                              {img.tag}
                            </div>
                          </div>
                          <div className="p-1.5 bg-neutral-50 text-[10px] text-neutral-800">
                            {img.caption || 'Nessuna didascalia'}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Firme */}
                <div className="pt-3 border-t border-neutral-300">
                  <div className="grid grid-cols-2 divide-x divide-neutral-900 border border-neutral-900 text-center text-[10px]">
                    <div className="p-3 flex flex-col justify-between h-20">
                      <span className="font-bold text-neutral-800 uppercase">
                        Firma Tecnico Esecutore
                      </span>
                      <span className="font-semibold text-neutral-900">
                        {selectedReport.operatorName}
                      </span>
                    </div>

                    <div className="p-3 flex flex-col justify-between h-20">
                      <span className="font-bold text-neutral-800 uppercase">
                        Visto Responsabile Impianti & Riconsegna
                      </span>
                      <span className="font-semibold text-emerald-800">
                        F.to: {selectedReport.supervisorName || 'M. Preato'} (Collaudato)
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 bg-white border border-neutral-200 rounded-lg text-center space-y-3">
              <Wrench className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="text-sm font-semibold text-neutral-900">
                Nessuna Manutenzione Selezionata
              </h3>
              <p className="text-xs text-neutral-500">
                Seleziona un intervento dall&apos;elenco a sinistra per visualizzare la scheda dettagliata e stampare il PDF recap.
              </p>
              <button
                onClick={() => setViewMode('list')}
                className="px-4 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-xl"
              >
                Torna all'Elenco Manutenzioni
              </button>
            </div>
          )}
        </div>
      )}

      {/* Modal Condivisione File su WhatsApp / Altre App */}
      {selectedReport && (
        <ShareFileModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          title={`Verbale Manutenzione ${selectedReport.plantName}`}
          subtitle={`${selectedReport.equipmentServiced || selectedReport.interventionType} · Esito ${selectedReport.outcome.toUpperCase()}`}
          codeOrNumber={selectedReport.protocolNumber}
          getPdfBlob={() => generateElementPdfBlob(sheetRef.current!)}
          getExcelBlob={() => generateMaintenanceExcelBlob(selectedReport)}
        />
      )}

      {/* Modal Form for Creating / Editing Maintenance */}
      {isFormOpen && (
        <MaintenanceFormModal
          isOpen={isFormOpen}
          initialReport={editingReport}
          onClose={() => {
            setIsFormOpen(false);
            setEditingReport(null);
          }}
          onSave={(rep) => {
            onSaveReport(rep);
            setSelectedReport(rep);
            setViewMode('detail');
            setIsFormOpen(false);
            setEditingReport(null);
          }}
        />
      )}

      {/* Google Pixel 9 Mobile Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-neutral-200 p-2 sm:hidden z-40 flex items-center justify-around gap-1 shadow-lg">
        {viewMode === 'detail' ? (
          <>
            <button
              onClick={() => setViewMode('list')}
              className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
            >
              <ArrowLeft className="w-4 h-4 mb-0.5 text-amber-600" />
              <span>← Elenco</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>Nuovo</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => {
                  const blob = generateMaintenanceExcelBlob(selectedReport);
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `Verbale_${selectedReport.protocolNumber}.xls`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-emerald-800 active:bg-emerald-50 rounded-lg"
              >
                <FileSpreadsheet className="w-4 h-4 mb-0.5" />
                <span>Excel</span>
              </button>
            )}
            {selectedReport && (
              <button
                onClick={() => handleDownloadPdf(selectedReport)}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-800 active:bg-neutral-100 rounded-lg"
              >
                <Download className="w-4 h-4 mb-0.5" />
                <span>PDF</span>
              </button>
            )}
          </>
        ) : (
          <>
            {onBackToMenu && (
              <button
                onClick={onBackToMenu}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
              >
                <Home className="w-4 h-4 mb-0.5" />
                <span>Menù</span>
              </button>
            )}
            {reports.length > 0 && (
              <button
                onClick={() => {
                  setSelectedReport(reports[0]);
                  setIsShareModalOpen(true);
                }}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>+ Nuovo</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ======================== MODAL FORM FOR MAINTENANCE ========================

interface MFormProps {
  isOpen: boolean;
  initialReport: MaintenanceReport | null;
  onClose: () => void;
  onSave: (report: MaintenanceReport) => void;
}

const MaintenanceFormModal: React.FC<MFormProps> = ({
  isOpen,
  initialReport,
  onClose,
  onSave
}) => {
  if (!isOpen) return null;

  const [date, setDate] = useState(initialReport?.date || new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState(initialReport?.time || new Date().toTimeString().slice(0, 5));

  // Nome Impianto Combobox with LINEA 1, LINEA 2, LINEA 3
  const [plantName, setPlantName] = useState<MaintenancePlantLine>(
    (initialReport?.plantName as MaintenancePlantLine) || 'LINEA 1'
  );

  // Attrezzatura revisionata field directly underneath
  const [equipmentServiced, setEquipmentServiced] = useState(
    initialReport?.equipmentServiced || ''
  );

  const [interventionType, setInterventionType] = useState<MaintenanceType>(
    initialReport?.interventionType || 'Programmata Ordinaria'
  );
  const [outcome, setOutcome] = useState<MaintenanceOutcome>(initialReport?.outcome || 'positivo');
  const [hours, setHours] = useState(initialReport?.timeSpentHours ?? 1);
  const [minutes, setMinutes] = useState(initialReport?.timeSpentMinutes ?? 30);
  const [description, setDescription] = useState(initialReport?.description || '');
  const [operatorName, setOperatorName] = useState(initialReport?.operatorName || 'Gianni Moretti');
  const [supervisorName, setSupervisorName] = useState(initialReport?.supervisorName || 'M. Preato');

  // Elenco Ricambi Dinamico
  const [spareParts, setSpareParts] = useState<SparePartUsed[]>(
    initialReport?.spareParts || []
  );

  // Immagini
  const [images, setImages] = useState<MaintenanceImage[]>(initialReport?.images || []);
  const [isProcessingImg, setIsProcessingImg] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAddSparePart = () => {
    setSpareParts([
      ...spareParts,
      {
        id: `sp-${Date.now()}`,
        code: '',
        description: '',
        quantity: 1,
        unit: 'pz',
        notes: ''
      }
    ]);
  };

  const handleUpdateSparePart = (id: string, updated: Partial<SparePartUsed>) => {
    setSpareParts(
      spareParts.map((sp) => (sp.id === id ? { ...sp, ...updated } : sp))
    );
  };

  const handleRemoveSparePart = (id: string) => {
    setSpareParts(spareParts.filter((sp) => sp.id !== id));
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessingImg(true);
    try {
      const newImgs: MaintenanceImage[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith('image/')) continue;
        const comp = await compressImage(file, 1600, 1600, 0.85);
        newImgs.push({
          id: `mimg-${Date.now()}-${i}`,
          url: comp.dataUrl,
          caption: '',
          tag: 'Impianto Ripristinato',
          uploadedAt: new Date().toISOString(),
          fileName: comp.originalName
        });
      }
      setImages((prev) => [...prev, ...newImgs]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessingImg(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const report: MaintenanceReport = {
      id: initialReport?.id || `maint-${Date.now()}`,
      protocolNumber:
        initialReport?.protocolNumber ||
        `MAN-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 900) + 100)}`,
      date,
      time,
      plantName,
      equipmentServiced: equipmentServiced.trim(),
      interventionType,
      outcome,
      timeSpentHours: Number(hours),
      timeSpentMinutes: Number(minutes),
      description: description.trim(),
      spareParts,
      operatorName: operatorName.trim(),
      supervisorName: supervisorName.trim(),
      images,
      createdAt: initialReport?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(report);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-neutral-300 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden my-auto text-xs">
        {/* Header */}
        <div className="px-6 py-3.5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50 shrink-0">
          <div>
            <h2 className="text-sm font-bold text-neutral-900">
              {initialReport ? 'Modifica Intervento di Manutenzione' : 'Registra Nuova Manutenzione Impianto'}
            </h2>
            <p className="text-[11px] text-neutral-500">
              Seleziona la linea, specifica l&apos;attrezzatura revisionata, esito, tempo impiegato e ricambi
            </p>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-700 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Section 1: Data, Impianto (Combobox LINEA 1/2/3), Attrezzatura revisionata, Tipo Intervento, Esito */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-4">
            <h3 className="font-bold text-neutral-900 uppercase text-[11px] pb-1 border-b border-neutral-100">
              1. Localizzazione e Tipo Intervento
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  DATA Intervento *
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Ora Inizio
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Esito Intervento *
                </label>
                <select
                  value={outcome}
                  onChange={(e) => setOutcome(e.target.value as MaintenanceOutcome)}
                  className={`w-full px-2.5 py-1.5 border rounded font-bold ${
                    outcome === 'positivo'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                      : 'border-rose-600 bg-rose-50 text-rose-800'
                  }`}
                >
                  <option value="positivo">✓ Positivo (Impianto Funzionante & Collaudato)</option>
                  <option value="negativo">✗ Negativo (Anomalia Persistente / Impianto Fermo)</option>
                  <option value="in_attesa_collaudo">⏳ In attesa di Collaudo</option>
                </select>
              </div>

              {/* NOME IMPIANTO: Combobox strictly with LINEA 1, LINEA 2, LINEA 3 */}
              <div className="sm:col-span-1">
                <label className="block text-[11px] font-semibold text-neutral-800 mb-1">
                  Nome Impianto *
                </label>
                <select
                  required
                  value={plantName}
                  onChange={(e) => setPlantName(e.target.value as MaintenancePlantLine)}
                  className="w-full px-2.5 py-1.5 border border-neutral-900 rounded font-bold font-mono text-xs bg-amber-50/40 text-neutral-900"
                >
                  <option value="LINEA 1">LINEA 1</option>
                  <option value="LINEA 2">LINEA 2</option>
                  <option value="LINEA 3">LINEA 3</option>
                  <option value="LINEA 4">LINEA 4</option>
                  <option value="LINEA 6">LINEA 6</option>
                  <option value="POLIN">POLIN</option>
                  <option value="ALTRO">ALTRO</option>
                </select>
              </div>

              {/* FIELD DIRECTLY UNDER NOME IMPIANTO: Attrezzatura revisionata */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-neutral-800 mb-1">
                  Attrezzatura revisionata *
                </label>
                <input
                  type="text"
                  required
                  value={equipmentServiced}
                  onChange={(e) => setEquipmentServiced(e.target.value)}
                  placeholder="es. Pompa airless Graco King Xtreme 68:1, Pistola XTR-7, Filtri cabina..."
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-medium text-xs focus:ring-1 focus:ring-neutral-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Tipo di Intervento Effettuato *
                </label>
                <select
                  value={interventionType}
                  onChange={(e) => setInterventionType(e.target.value as MaintenanceType)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                >
                  <option value="Programmata Ordinaria">Programmata Ordinaria</option>
                  <option value="Riparazione Guasto Straordinaria">Riparazione Guasto Straordinaria</option>
                  <option value="Sostituzione Ugelli / Tubazioni">Sostituzione Ugelli / Tubazioni</option>
                  <option value="Revisione Pompa Airless / Pistoni">Revisione Pompa Airless / Pistoni</option>
                  <option value="Sostituzione Filtri a Maniche / Cartucce">Sostituzione Filtri a Maniche / Cartucce</option>
                  <option value="Taratura Pressioni e Manometri">Taratura Pressioni e Manometri</option>
                  <option value="Altro">Altro</option>
                </select>
              </div>

              {/* Tempo Impiegato */}
              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Tempo Impiegato
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={hours}
                    onChange={(e) => setHours(Number(e.target.value))}
                    className="w-14 px-1.5 py-1 border border-neutral-300 rounded font-mono font-bold text-center"
                  />
                  <span className="text-[10px] text-neutral-500">h</span>
                  <input
                    type="number"
                    min="0"
                    max="59"
                    step="5"
                    value={minutes}
                    onChange={(e) => setMinutes(Number(e.target.value))}
                    className="w-14 px-1.5 py-1 border border-neutral-300 rounded font-mono font-bold text-center"
                  />
                  <span className="text-[10px] text-neutral-500">min</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Descrizione Intervento */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-2">
            <label className="block text-[11px] font-semibold text-neutral-700">
              Descrizione Dettagliata dell&apos;Intervento Effettuato
            </label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descrivi il guasto riscontrato, la diagnosi, i controlli effettuati e le prove di collaudo..."
              className="w-full px-2.5 py-1.5 border border-neutral-300 rounded text-xs"
            />
          </div>

          {/* Section 3: Elenco Ricambi Utilizzati */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-neutral-100">
              <div>
                <h3 className="font-bold text-neutral-900 uppercase text-[11px]">
                  Elenco Ricambi Utilizzati ({spareParts.length})
                </h3>
                <p className="text-[10px] text-neutral-500">
                  Aggiungi codici e quantità dei componenti installati (guarnizioni, ugelli, filtri, valvole)
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddSparePart}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Aggiungi Ricambio</span>
              </button>
            </div>

            {spareParts.length === 0 ? (
              <div className="p-4 border border-dashed border-neutral-200 rounded text-center text-[11px] text-neutral-400">
                Nessun ricambio aggiunto. Clicca &quot;Aggiungi Ricambio&quot; se sono stati sostituiti componenti.
              </div>
            ) : (
              <div className="space-y-2">
                {spareParts.map((sp) => (
                  <div key={sp.id} className="flex flex-col sm:flex-row items-center gap-2 p-2 bg-neutral-50 border border-neutral-200 rounded">
                    <input
                      type="text"
                      placeholder="Codice (es. GRC-244851)"
                      value={sp.code}
                      onChange={(e) => handleUpdateSparePart(sp.id, { code: e.target.value })}
                      className="w-full sm:w-32 px-2 py-1 bg-white border border-neutral-300 rounded font-mono font-semibold text-[11px]"
                    />
                    <input
                      type="text"
                      placeholder="Descrizione (es. Kit V-Packing teflon)"
                      value={sp.description}
                      onChange={(e) => handleUpdateSparePart(sp.id, { description: e.target.value })}
                      className="w-full sm:flex-1 px-2 py-1 bg-white border border-neutral-300 rounded text-[11px]"
                    />
                    <div className="flex items-center gap-1 w-full sm:w-auto">
                      <input
                        type="number"
                        min="1"
                        value={sp.quantity}
                        onChange={(e) => handleUpdateSparePart(sp.id, { quantity: Number(e.target.value) })}
                        className="w-16 px-1.5 py-1 bg-white border border-neutral-300 rounded font-mono text-center font-bold text-[11px]"
                      />
                      <select
                        value={sp.unit}
                        onChange={(e) => handleUpdateSparePart(sp.id, { unit: e.target.value })}
                        className="px-1.5 py-1 bg-white border border-neutral-300 rounded text-[11px]"
                      >
                        <option value="pz">pz</option>
                        <option value="kit">kit</option>
                        <option value="m">m</option>
                        <option value="kg">kg</option>
                        <option value="l">l</option>
                      </select>
                    </div>
                    <input
                      type="text"
                      placeholder="Note / Destinazione..."
                      value={sp.notes || ''}
                      onChange={(e) => handleUpdateSparePart(sp.id, { notes: e.target.value })}
                      className="w-full sm:w-44 px-2 py-1 bg-white border border-neutral-300 rounded text-[11px]"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveSparePart(sp.id)}
                      className="text-neutral-400 hover:text-rose-600 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 4: Immagini e Foto dell'Intervento */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-neutral-100">
              <h3 className="font-bold text-neutral-900 uppercase text-[11px] flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-neutral-700" />
                <span>Immagini Allegate ({images.length})</span>
              </h3>
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e.target.files)}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingImg}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Carica Foto Intervento</span>
                </button>
              </div>
            </div>

            {images.length === 0 ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-neutral-200 hover:border-neutral-400 rounded-lg p-6 text-center cursor-pointer bg-neutral-50/50"
              >
                <Camera className="w-7 h-7 text-neutral-400 mx-auto mb-1" />
                <div className="text-xs font-medium text-neutral-700">
                  Carica foto del guasto, pezzo usurato, ricambio montato o collaudo finale
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {images.map((img, i) => (
                  <div key={img.id} className="p-2 border border-neutral-200 rounded-lg bg-neutral-50 flex gap-2">
                    <img
                      src={img.url}
                      alt={img.caption}
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 object-cover rounded shrink-0 border border-neutral-300"
                    />
                    <div className="flex-1 space-y-1.5">
                      <div className="flex justify-between items-center">
                        <select
                          value={img.tag}
                          onChange={(e) =>
                            setImages(
                              images.map((m, idx) => (idx === i ? { ...m, tag: e.target.value as any } : m))
                            )
                          }
                          className="px-1.5 py-0.5 text-[10px] bg-white border border-neutral-300 rounded font-semibold"
                        >
                          <option value="Guasto / Anomalia">Guasto / Anomalia</option>
                          <option value="Pezzo Usurato">Pezzo Usurato</option>
                          <option value="Ricambio Installato">Ricambio Installato</option>
                          <option value="Impianto Ripristinato">Impianto Ripristinato</option>
                          <option value="Collaudo Finale">Collaudo Finale</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                          className="text-neutral-400 hover:text-rose-600 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <input
                        type="text"
                        placeholder="Didascalia foto..."
                        value={img.caption}
                        onChange={(e) =>
                          setImages(
                            images.map((m, idx) => (idx === i ? { ...m, caption: e.target.value } : m))
                          )
                        }
                        className="w-full px-2 py-1 text-[11px] bg-white border border-neutral-300 rounded"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 5: Operatore e Responsabile */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                Tecnico Manutentore Esecutore *
              </label>
              <input
                type="text"
                required
                value={operatorName}
                onChange={(e) => setOperatorName(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                Responsabile Impianti / Convalida
              </label>
              <input
                type="text"
                value={supervisorName}
                onChange={(e) => setSupervisorName(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
              />
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50"
            >
              Annulla
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>Salva Intervento di Manutenzione</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
