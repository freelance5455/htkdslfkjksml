import React, { useState, useEffect } from 'react';
import { ExternalLink, Check, Copy, X, Sparkles, Download, Search, Timer, CheckSquare, Music, Calculator } from 'lucide-react';
import { ExecutedAction } from '../types';

interface ToolActionModalProps {
  lastAction: ExecutedAction | null;
  allActions: ExecutedAction[];
  onDismiss: () => void;
}

export const ToolActionModal: React.FC<ToolActionModalProps> = ({
  lastAction,
  allActions,
  onDismiss,
}) => {
  const [copied, setCopied] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    if (lastAction) {
      const timer = setTimeout(() => {
        // Auto-dismiss notification after 8 seconds
      }, 8000);
      return () => clearTimeout(timer);
    }
  }, [lastAction]);

  if (!lastAction && allActions.length === 0) return null;

  const handleCopy = (text: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderActiveNotification = () => {
    if (!lastAction) return null;

    if (lastAction.type === 'downloadZip') {
      return (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="relative overflow-hidden rounded-2xl bg-zinc-950/95 border border-pink-500/50 p-4 shadow-2xl backdrop-blur-xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-pink-500/20 text-pink-400 border border-pink-500/30">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-pink-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Voice Action
                  </span>
                  <h4 className="text-sm font-bold text-white">Full Project ZIP Ready</h4>
                </div>
              </div>
              <button
                onClick={onDismiss}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="mt-2 text-xs text-zinc-300">
              Download started! You can also click below to download directly.
            </p>
            <div className="mt-3">
              <a
                href="/api/download-zip"
                download="roxy-voice-assistant.zip"
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white font-semibold text-xs shadow-lg shadow-pink-500/25 transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download roxy-voice-assistant.zip</span>
              </a>
            </div>
          </div>
        </div>
      );
    }

    if (lastAction.type === 'openWebsite') {
      const url = lastAction.data?.url || '';
      const siteName = lastAction.data?.siteName || url;
      const comment = lastAction.data?.comment || '';

      return (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="relative overflow-hidden rounded-2xl bg-zinc-950/95 border border-pink-500/40 p-4 shadow-2xl backdrop-blur-xl">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 animate-pulse" />
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-pink-500/20 text-pink-400 border border-pink-500/30">
                  <ExternalLink className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold uppercase tracking-wider text-pink-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Voice Action
                    </span>
                    {lastAction.status === 'blocked' && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Popup Blocked
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-[240px]">
                    Opening {siteName}
                  </h4>
                </div>
              </div>
              <button
                onClick={onDismiss}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {comment && (
              <p className="mt-2 text-xs italic text-zinc-300 bg-white/5 rounded-lg p-2 border border-white/10">
                "{comment}"
              </p>
            )}
            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={() => window.open(url, '_blank', 'noopener,noreferrer')}
                className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 text-white font-semibold text-xs shadow-lg shadow-pink-500/25 transition-all cursor-pointer"
              >
                <span>Launch {siteName}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleCopy(url)}
                className="flex items-center justify-center p-2 rounded-xl bg-white/10 hover:bg-white/15 text-zinc-200 border border-white/15 text-xs cursor-pointer"
                title="Copy Link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (lastAction.type === 'searchWeb') {
      const { query, platform, url } = lastAction.data;
      return (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="relative overflow-hidden rounded-2xl bg-zinc-950/95 border border-cyan-500/40 p-4 shadow-2xl backdrop-blur-xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Web Search ({platform})
                  </span>
                  <h4 className="text-sm font-bold text-white truncate max-w-[240px]">
                    "{query}"
                  </h4>
                </div>
              </div>
              <button
                onClick={onDismiss}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-3">
              <button
                onClick={() => window.open(url, '_blank')}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-lg transition-all cursor-pointer"
              >
                <span>View Results on {platform}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <>
      {renderActiveNotification()}

      {/* History Drawer / Modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-md rounded-2xl bg-zinc-900 border border-zinc-700/60 p-5 shadow-2xl flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-pink-400" />
                Voice Commands Executed
              </h3>
              <button
                onClick={() => setShowHistory(false)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-zinc-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto mt-3 space-y-2.5 pr-1">
              {allActions.length === 0 ? (
                <p className="text-xs text-zinc-500 text-center py-6">No voice actions yet. Try speaking!</p>
              ) : (
                allActions.map((act) => (
                  <div
                    key={act.id}
                    className="p-3 rounded-xl bg-zinc-800/60 border border-zinc-700/50 flex flex-col gap-1 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-pink-300">
                        {act.type === 'openWebsite'
                          ? `🌐 Open: ${act.data.siteName || act.data.url}`
                          : act.type === 'searchWeb'
                          ? `🔍 Search: "${act.data.query}"`
                          : act.type === 'downloadZip'
                          ? `💾 Download Project ZIP`
                          : act.type === 'setTimer'
                          ? `⏱️ Timer: ${act.data.seconds}s (${act.data.label})`
                          : act.type === 'takeNote'
                          ? `📝 Note: "${act.data.text}"`
                          : act.type === 'playMusicVibe'
                          ? `🎵 Music: ${act.data.vibe} (${act.data.action})`
                          : act.type === 'calculateMath'
                          ? `🧮 Math: ${act.data.calculation} = ${act.data.result}`
                          : act.type === 'changeMoodTheme'
                          ? `🎨 Theme: ${act.data.theme}`
                          : `😏 Expression: ${act.data.expression}`}
                      </span>
                      <span className="text-[10px] text-zinc-500">
                        {new Date(act.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    {act.type === 'openWebsite' && (
                      <a
                        href={act.data.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:underline truncate mt-1 flex items-center gap-1 text-[11px]"
                      >
                        {act.data.url}
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      </a>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Log Trigger Button (bottom-right) */}
      {allActions.length > 0 && !showHistory && (
        <button
          onClick={() => setShowHistory(true)}
          className="fixed bottom-4 right-4 z-40 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-pink-500/30 hover:border-pink-500/60 text-xs text-zinc-300 hover:text-white shadow-lg backdrop-blur-md transition-all active:scale-95 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-pink-400" />
          <span>Actions ({allActions.length})</span>
        </button>
      )}
    </>
  );
};
