import React, { useEffect, useState } from 'react';
import { Crown, Sparkles, RefreshCw } from 'lucide-react';
import { soundFX } from '../utils/soundEffects';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(15);
  const [statusText, setStatusText] = useState('جارِ فحص الجلسة وأمان الحساب...');
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          soundFX.playVictoryFanfare();
          setTimeout(() => {
            onComplete();
          }, 400);
          return 100;
        }

        const next = prev + 5;
        if (next === 30) setStatusText('جارِ الاتصال بسيرفر الألعاب الملكية...');
        else if (next === 60) setStatusText('جارِ مزامنة بيانات اللوبي والتصنيف...');
        else if (next === 80) setStatusText('جارِ تحميل اللوبي... يرجى الانتظار');
        else if (next === 95) setStatusText('اكتمل التجهيز... مرحبًا بك في تابِيونا');

        return next;
      });
    }, 120);

    return () => clearInterval(timer);
  }, [onComplete]);

  const handleRetry = () => {
    setFailed(false);
    setProgress(20);
    setStatusText('إعادة المحاولة...');
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#040806] flex items-center justify-center select-none text-white font-sans">
      {/* Dark luxury atmospheric felt background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_#0b3720_0%,_#051c10_55%,_#020a06_100%)] opacity-90" />

      {/* Decorative Casino Table Perspective Rim */}
      <div className="absolute inset-x-12 bottom-0 top-24 rounded-t-[140px] border-t-8 border-x-8 border-[#2d2110] bg-[#072415]/70 table-wood-rail shadow-2xl flex flex-col items-center justify-center overflow-hidden">
        {/* Subtle Felt Texture Lines */}
        <div className="absolute inset-0 bg-[radial-gradient(#15803d_1px,transparent_1px)] [background-size:24px_24px] opacity-15" />

        {/* Fanned Decorative Cards along left rim */}
        <div className="absolute -left-12 bottom-12 w-48 h-64 pointer-events-none hidden md:block opacity-70 rotate-12">
          {['A♠', 'K♥', 'Q♦', 'J♣', '10♠'].map((c, i) => (
            <div
              key={i}
              className="absolute w-20 h-28 bg-gradient-to-br from-amber-50 to-amber-100 text-gray-900 rounded-lg shadow-2xl border border-amber-300 font-bold p-1 text-xs flex flex-col justify-between"
              style={{
                transform: `rotate(${i * 12 - 30}deg) translate(${i * 14}px, ${i * 4}px)`,
              }}
            >
              <span>{c}</span>
              <div className="text-center text-lg">{c.slice(-1)}</div>
              <span className="text-right">{c}</span>
            </div>
          ))}
        </div>

        {/* Fanned Decorative Cards along right rim */}
        <div className="absolute -right-8 bottom-12 w-48 h-64 pointer-events-none hidden md:block opacity-70 -rotate-12">
          {['A♥', 'K♦', 'Q♠', 'J♥', '9♣'].map((c, i) => (
            <div
              key={i}
              className="absolute w-20 h-28 bg-gradient-to-br from-[#0c2a1a] to-[#04130b] text-amber-300 rounded-lg shadow-2xl border border-amber-500/60 font-bold p-1 text-xs flex flex-col justify-between"
              style={{
                transform: `rotate(${-(i * 12) + 20}deg) translate(-${i * 14}px, ${i * 4}px)`,
              }}
            >
              <Crown className="w-3 h-3 text-amber-400" />
              <div className="text-center font-cinzel text-amber-400">TABEONA</div>
              <div className="text-right text-[10px] text-amber-500">👑</div>
            </div>
          ))}
        </div>

        {/* Scattered 3D Chips & Dice Effect */}
        <div className="absolute bottom-8 left-1/4 flex gap-2 pointer-events-none opacity-80">
          <div className="w-8 h-8 rounded-full border-2 border-dashed border-amber-400 bg-emerald-800 text-amber-300 text-[10px] font-bold flex items-center justify-center shadow-lg">
            100
          </div>
          <div className="w-8 h-8 rounded-full border-2 border-dashed border-amber-400 bg-amber-600 text-black text-[10px] font-bold flex items-center justify-center shadow-lg -ml-4">
            500
          </div>
        </div>

        <div className="absolute bottom-10 right-1/4 flex gap-3 pointer-events-none opacity-80">
          <div className="w-6 h-6 bg-gradient-to-br from-amber-400 to-amber-600 rounded rotate-12 shadow-md flex items-center justify-center text-black text-xs font-black">
            ⚄
          </div>
          <div className="w-6 h-6 bg-gradient-to-br from-amber-300 to-amber-500 rounded -rotate-6 shadow-md flex items-center justify-center text-black text-xs font-black">
            ⚂
          </div>
        </div>

        {/* Center Logo & Loading Box - Exactly matching IMG-20261009-WA0002.jpg */}
        <div className="relative z-10 flex flex-col items-center max-w-xl w-full px-6 text-center">
          {/* Royal Crown */}
          <div className="relative mb-1">
            <Crown className="w-16 h-16 text-amber-400 drop-shadow-[0_0_15px_rgba(245,158,11,0.8)] animate-pulse" />
            <Sparkles className="w-5 h-5 text-emerald-300 absolute -top-1 -right-2 animate-bounce" />
          </div>

          {/* TABEONA Ornate Wordmark */}
          <h1 className="font-cinzel text-5xl md:text-6xl tracking-widest font-black bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)] gold-glow select-none">
            TABEONA
          </h1>
          <p className="text-emerald-400 text-sm md:text-base font-semibold tracking-wide mt-1">
            لعبة الطرنيب الملكية
          </p>

          {/* Subtitle in Gold/Emerald */}
          <div className="mt-6 mb-2">
            <span className="text-[12px] font-cinzel tracking-widest text-amber-300/90 uppercase font-semibold">
              INITIALIZING LOBBY...
            </span>
          </div>

          {/* Ornate Gold Border Framed Glowing Progress Bar */}
          <div className="w-full max-w-md p-1 rounded-full bg-gradient-to-r from-amber-700 via-amber-400 to-amber-700 shadow-[0_0_20px_rgba(217,119,6,0.5)]">
            <div className="relative h-5 md:h-6 bg-[#04140b] rounded-full overflow-hidden p-0.5 border border-amber-900">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-green-300 transition-all duration-300 relative shadow-[0_0_15px_#10b981]"
                style={{ width: `${progress}%` }}
              >
                {/* Glowing light sweep inside progress bar */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse" />
              </div>
            </div>
          </div>

          {/* Real Percentage Display */}
          <div className="mt-3 flex items-center justify-between w-full max-w-md px-2 text-xs">
            <span className="font-bold text-amber-400 font-cinzel text-base">{progress}%</span>
            <span className="text-emerald-300/90 font-medium text-xs md:text-sm">{statusText}</span>
          </div>

          {/* Fallback Retry in case of slow connection */}
          {failed && (
            <button
              onClick={handleRetry}
              className="mt-4 px-5 py-2 rounded-lg bg-red-900/60 hover:bg-red-800 text-white text-xs flex items-center gap-2 border border-red-500 shadow-lg"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              فشل الاتصال بالخادم، إعادة المحاولة
            </button>
          )}

          {/* Quick enter skip button for developer testing */}
          <button
            onClick={onComplete}
            className="mt-6 text-[11px] text-amber-400/60 hover:text-amber-300 underline tracking-wider transition-colors"
          >
            تخطي شاشة البداية والدخول للّوبي &larr;
          </button>
        </div>
      </div>

      {/* Footer copyright note */}
      <div className="absolute bottom-2 text-center text-[10px] text-emerald-600/70">
        TABEONA &bull; جميع الحقوق محفوظة &bull; إصدار v1.0
      </div>
    </div>
  );
};
