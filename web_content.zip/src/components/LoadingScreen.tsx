/**
 * SPR - SAHIL POWERFUL RUN
 * Official New Vertical Mobile Loading Screen Artwork & Progression
 * Created by Sahil Gupta on 15 September 2026
 */

import React, { useEffect, useState, useRef } from 'react';

interface LoadingScreenProps {
  onComplete: () => void;
}

const LOADING_DURATION_MS = 3600; // Smooth 3.6s loading animation
const FADE_OUT_DURATION_MS = 450; // Smooth cross-fade to Home Screen

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState<number>(0);
  const [isFadingOut, setIsFadingOut] = useState<boolean>(false);

  const startTimeRef = useRef<number>(0);
  const animFrameRef = useRef<number | null>(null);
  const failsafeTimeoutRef = useRef<number | null>(null);
  const completedRef = useRef<boolean>(false);

  // Preload and decode the new local vertical loading screen image
  useEffect(() => {
    const img = new Image();
    img.src = '/spr_loading_screen.jpg';
    if ('decode' in img) {
      img.decode().catch(() => {});
    }
  }, []);

  // Smooth realistic loading progression (0% -> 100%)
  useEffect(() => {
    startTimeRef.current = performance.now();

    const finishLoading = () => {
      if (completedRef.current) return;
      completedRef.current = true;

      setProgress(100);
      setIsFadingOut(true);

      setTimeout(() => {
        onComplete();
      }, FADE_OUT_DURATION_MS);
    };

    const updateLoop = (now: number) => {
      const elapsed = now - startTimeRef.current;
      const ratio = Math.min(elapsed / LOADING_DURATION_MS, 1.0);

      // Nonlinear smooth curve: fast initial acceleration, steady mid-pace, crisp finish
      const easedRatio = Math.pow(ratio, 0.88);
      const percent = Math.min(100, Math.floor(easedRatio * 100));
      setProgress(percent);

      if (ratio >= 1.0) {
        finishLoading();
      } else {
        animFrameRef.current = requestAnimationFrame(updateLoop);
      }
    };

    animFrameRef.current = requestAnimationFrame(updateLoop);

    // Failsafe timeout
    failsafeTimeoutRef.current = window.setTimeout(() => {
      finishLoading();
    }, LOADING_DURATION_MS + 800);

    return () => {
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
      }
      if (failsafeTimeoutRef.current !== null) {
        clearTimeout(failsafeTimeoutRef.current);
      }
    };
  }, [onComplete]);

  return (
    <div
      id="spr-loading-screen"
      className={`fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-slate-950 select-none transition-opacity duration-500 ease-out ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ willChange: 'opacity' }}
    >
      {/* Blurred ambient background for tablets and wide desktop viewports */}
      <div
        className="absolute inset-0 bg-cover bg-center filter blur-3xl scale-110 opacity-50 hidden sm:block pointer-events-none"
        style={{ backgroundImage: "url('/spr_loading_screen.jpg')" }}
      />

      {/* Main Vertical Mobile Screen Container - Preserves 9:16 vertical composition without horizontal stretch */}
      <div className="relative w-full h-full max-w-[500px] flex flex-col justify-between overflow-hidden shadow-2xl bg-black">
        
        {/* Background Artwork: Official SPR Vertical Phone Loading Screen */}
        <div className="absolute inset-0 z-0 flex items-center justify-center">
          <img
            id="spr-official-loading-img"
            src="/spr_loading_screen.jpg"
            alt="SPR – SAHIL POWERFUL RUN Loading Artwork"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center pointer-events-none select-none"
          />

          {/* Top subtle vignette for header contrast */}
          <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/70 via-black/30 to-transparent pointer-events-none" />

          {/* Bottom vignette to frame loading bar with high contrast */}
          <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent pointer-events-none" />
        </div>

        {/* Top Header: SPR RUN · SAHIL POWERFULL RUN */}
        <div className="relative z-20 pt-4 px-4 flex justify-between items-center safe-inset-top">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/70 border border-amber-400/50 backdrop-blur-md shadow-lg">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <div className="flex flex-col">
              <span className="text-[11px] sm:text-xs font-black text-white tracking-widest uppercase font-display leading-tight">
                SPR RUN
              </span>
              <span className="text-[9px] font-bold text-amber-300 tracking-wider uppercase font-mono leading-none">
                SAHIL POWERFULL RUN
              </span>
            </div>
          </div>

          <div className="px-2.5 py-1 rounded-full bg-slate-950/70 border border-white/20 backdrop-blur text-[10px] font-mono text-amber-200 tracking-wider shadow">
            OFFLINE · 60 FPS
          </div>
        </div>

        {/* Bottom Loading Progress Area */}
        <div className="relative z-20 w-full px-5 pb-8 sm:pb-10 safe-inset-bottom flex flex-col items-center">
          
          {/* Main Stylized Progress Bar */}
          <div
            id="loading-progress-bar-container"
            className="w-full h-11 sm:h-12 rounded-2xl bg-gradient-to-b from-amber-950/90 via-slate-950/95 to-slate-950 border-3 border-amber-400/90 p-1 shadow-[0_0_25px_rgba(251,191,36,0.6)] backdrop-blur-md relative overflow-hidden ring-2 ring-amber-300/40"
          >
            {/* Active Cyan-Blue Progress Fill */}
            <div
              id="loading-progress-fill"
              className="h-full rounded-xl bg-gradient-to-r from-sky-600 via-cyan-400 to-sky-400 relative overflow-hidden transition-all duration-100 ease-out shadow-[0_0_18px_rgba(56,189,248,0.9)]"
              style={{ width: `${Math.max(4, progress)}%` }}
            >
              {/* Shimmer Light Pulse */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-pulse" />
            </div>

            {/* Centered Loading Label with percentage: 0% → 100% */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none px-4">
              <span
                id="loading-progress-label"
                className="font-display font-black text-sm sm:text-base tracking-widest text-white uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,1)]"
                style={{
                  textShadow: '0 2px 4px #000, 0 0 10px rgba(0,0,0,0.9), 0 0 2px #000',
                }}
              >
                LOADING... {progress}%
              </span>
            </div>
          </div>

          {/* Subtitle Information */}
          <div className="mt-2.5 flex items-center gap-1.5 text-xs text-amber-200/95 font-bold tracking-wider uppercase font-display drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] text-center">
            <span>SAHIL POWERFULL RUN · GET READY FOR AN EPIC RUN!</span>
          </div>
        </div>

      </div>
    </div>
  );
};
