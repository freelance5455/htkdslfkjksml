/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { soundManager } from '../audio/SoundManager';
import {
  ShieldAlert,
  Terminal,
  Volume2,
  Cpu,
  Radio,
  Crosshair,
  Skull,
  Zap,
} from 'lucide-react';

interface LoadingScreenProps {
  onLoaded: () => void;
}

const BOOT_LOGS = [
  'INITIALIZING SYSTEM SUBSYSTEMS...',
  'CALIBRATING 3D SHADER COMPILER & PBR TEXTURES...',
  'DETECTING BIO-CONTAMINATION IN SECTOR 7...',
  'DEPLOYING TACTICAL INFECTED AI HEURISTICS...',
  'SYNCHRONIZING BALLISTIC RAYCAST TELEMETRY...',
  'ESTABLISHING HELIPAD EXTRACTION FREQUENCY...',
  'NEURAL SURVIVOR RIG SYNCHRONIZED 100%...',
  'QUARANTINE BREACH DETECTED - SURVIVAL PROTOCOL ENGAGED.',
];

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onLoaded }) => {
  const [progress, setProgress] = useState(0);
  const [logIndex, setLogIndex] = useState(0);
  const [isReady, setIsReady] = useState(false);
  const [pulseGlow, setPulseGlow] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setIsReady(true);
          return 100;
        }
        const next = Math.min(100, prev + Math.floor(Math.random() * 8) + 4);
        return next;
      });
    }, 120);

    const logTimer = setInterval(() => {
      setLogIndex((prev) => (prev < BOOT_LOGS.length - 1 ? prev + 1 : prev));
    }, 380);

    const glowInterval = setInterval(() => {
      setPulseGlow((p) => !p);
    }, 1000);

    return () => {
      clearInterval(timer);
      clearInterval(logTimer);
      clearInterval(glowInterval);
    };
  }, []);

  const handleStart = () => {
    soundManager.unlockAudio();
    soundManager.playObjectiveCompleted();
    onLoaded();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#05070a] text-slate-100 flex flex-col justify-between p-6 select-none overflow-hidden font-mono">
      {/* Dynamic background atmospheric scanline grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, rgba(239, 68, 68, 0.15) 0%, transparent 70%), linear-gradient(rgba(14, 165, 233, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(14, 165, 233, 0.05) 1px, transparent 1px)',
          backgroundSize: '100% 100%, 40px 40px, 40px 40px',
        }}
      />

      {/* Animated Top Header & Mission Specs */}
      <div className="relative z-10 flex items-center justify-between border-b border-red-500/20 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded border border-red-500/40 bg-red-950/40 flex items-center justify-center text-red-400 animate-pulse">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs tracking-widest text-red-500 font-bold uppercase">
              SECTOR 09 EMERGENCY QUARANTINE
            </div>
            <div className="text-sm font-semibold text-slate-300 tracking-wider">
              PROJECT DEADZONE: OUTBREAK
            </div>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-6 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>CORE: ONLINE (60 FPS)</span>
          </div>
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span>BEACON: ACTIVE</span>
          </div>
        </div>
      </div>

      {/* Center Cinematic Stage: Bespoke Animated Branding for Rehanx */}
      <div className="relative z-10 my-auto flex flex-col items-center text-center max-w-xl mx-auto w-full">
        {/* Animated Cybernetic Reticle */}
        <div className="relative w-36 h-36 mb-6 flex items-center justify-center">
          <div
            className={`absolute inset-0 rounded-full border-2 border-dashed border-red-500/40 transition-transform duration-1000 ${
              pulseGlow ? 'rotate-90 scale-105' : '-rotate-90 scale-95'
            }`}
          />
          <div className="absolute inset-2 rounded-full border border-cyan-500/30 animate-spin" style={{ animationDuration: '14s' }} />
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-red-900/60 via-slate-900/80 to-red-600/40 border border-red-500 flex items-center justify-center shadow-lg shadow-red-900/50">
            <Skull className="w-10 h-10 text-red-400 animate-pulse" />
          </div>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping" />
        </div>

        {/* Game Title */}
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white uppercase drop-shadow-[0_0_20px_rgba(239,68,68,0.5)]">
          DEADZONE<span className="text-red-500">:</span> OUTBREAK
        </h1>

        {/* USER SPECIAL HIGHLIGHT: MADE BY REHANX */}
        <div className="mt-4 px-6 py-2.5 rounded-full bg-gradient-to-r from-red-950/80 via-slate-900 to-red-950/80 border-2 border-red-500/60 shadow-[0_0_25px_rgba(239,68,68,0.35)] flex items-center gap-3">
          <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400 animate-bounce" />
          <div className="text-sm sm:text-base font-black tracking-widest uppercase text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-200 to-red-400">
            MADE BY REHANX
          </div>
          <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400 animate-bounce" />
        </div>

        <p className="mt-3 text-xs sm:text-sm text-slate-400 tracking-wide max-w-md">
          Tactical 3D Zombie Survival & Evacuation Simulator. Prepare for high-intensity urban combat.
        </p>

        {/* Animated Loading Bar */}
        <div className="w-full mt-8 bg-slate-950/80 border border-slate-800 rounded-lg p-3 shadow-inner">
          <div className="flex justify-between items-center text-xs mb-2 text-slate-400">
            <span className="flex items-center gap-1 text-cyan-400">
              <Terminal className="w-3.5 h-3.5" />
              {BOOT_LOGS[logIndex]}
            </span>
            <span className="font-bold text-white tabular-nums">{progress}%</span>
          </div>

          <div className="w-full h-3 bg-slate-900 rounded overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-400 transition-all duration-150 ease-out shadow-[0_0_15px_rgba(239,68,68,0.8)]"
              style={{ width: `${progress}%` }}
            />
            {/* Scanline stripe */}
            <div
              className="absolute inset-0 opacity-20 pointer-events-none"
              style={{
                backgroundImage: 'repeating-linear-gradient(45deg, #000 0, #000 5px, transparent 5px, transparent 10px)',
              }}
            />
          </div>
        </div>

        {/* Ready Deploy CTA */}
        {isReady && (
          <button
            onClick={handleStart}
            className="mt-6 px-8 py-3.5 rounded-lg bg-gradient-to-r from-red-600 via-red-500 to-amber-600 text-white font-bold text-sm sm:text-base tracking-widest uppercase shadow-[0_0_30px_rgba(239,68,68,0.6)] hover:brightness-110 active:scale-95 transition-all flex items-center gap-3 cursor-pointer animate-pulse"
          >
            <Crosshair className="w-5 h-5 text-white" />
            <span>DEPLOY SURVIVOR TO SECTOR</span>
          </button>
        )}
      </div>

      {/* Footer System Diagnostics & Sound indicator */}
      <div className="relative z-10 flex items-center justify-between text-xs text-slate-500 border-t border-slate-800/80 pt-3">
        <div className="flex items-center gap-2">
          <Volume2 className="w-3.5 h-3.5 text-slate-400" />
          <span>PROURAL WEB AUDIO ENGINE READY</span>
        </div>
        <div className="tracking-widest text-slate-400 uppercase font-semibold">
          DIRECTED BY <span className="text-yellow-400 font-bold">REHANX</span>
        </div>
      </div>
    </div>
  );
};
