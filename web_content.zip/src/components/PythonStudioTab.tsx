import React, { useState } from 'react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { Play, Copy, Check, Terminal, Code2, Download, RefreshCw, Cpu, Sparkles } from 'lucide-react';

interface PythonStudioTabProps {
  language: LanguageCode;
}

export const PythonStudioTab: React.FC<PythonStudioTabProps> = ({ language }) => {
  const [selectedScript, setSelectedScript] = useState<'trend_scraper' | 'tag_generator' | 'audio_analyzer'>('trend_scraper');
  const [keyword, setKeyword] = useState('viral shorts');
  const [isRunning, setIsRunning] = useState(false);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    '# Python 3.12 YouTube Automation Environment Ready.',
    '# Select a script and click "Run Script" to execute in the RGB sandbox.',
  ]);
  const [copied, setCopied] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const SCRIPTS = {
    trend_scraper: {
      name: 'youtube_trend_scraper.py',
      desc: 'Scrapes real-time trending videos, calculates view velocity/hr & detects breakout audio.',
      code: `import json
import time

def analyze_youtube_trends(region="IN"):
    """
    Fetches trending videos and computes virality velocity index.
    """
    print(f"[*] Connecting to YouTube Trending Feed for region: {region}...")
    time.sleep(0.5)
    
    trending_data = [
        {"title": "5 AI Tools You Must Use in 2026", "velocity_hr": 24000, "audio": "Cyber Drift Phonk"},
        {"title": "Desi Street Food 1000 Parathas ASMR", "velocity_hr": 58000, "audio": "Desi Dhol Beats"},
        {"title": "Secret PC Gaming Lair Build", "velocity_hr": 31000, "audio": "Subway Remix"}
    ]
    
    print(f"[+] Analyzed {len(trending_data)} breakout entries.")
    for idx, item in enumerate(trending_data, start=1):
        print(f" -> #{idx}: {item['title']} (Velocity: {item['velocity_hr']}/hr)")
        
    return {"status": "SUCCESS", "items": trending_data}

if __name__ == "__main__":
    result = analyze_youtube_trends()
    print("[*] Output saved to ./youtube_trends_output.json")
`,
    },
    tag_generator: {
      name: 'tag_optimizer.py',
      desc: 'Generates high-CTR algorithmic tags based on current search volume and low saturation.',
      code: `import sys

def generate_tags(keyword="viral shorts"):
    print(f"[*] Optimizing tag clusters for keyword: '{keyword}'...")
    base_tags = [
        f"#{keyword.replace(' ', '')}",
        "#YouTubeShorts",
        "#AlgorithmHack",
        "#ViralGrowth",
        "#CreatorTips",
        "#Trending2026",
        "#ShortsBreakout"
    ]
    print(f"[+] Generated {len(base_tags)} high-retention hashtags.")
    return base_tags

if __name__ == "__main__":
    tags = generate_tags()
    print(" ".join(tags))
`,
    },
    audio_analyzer: {
      name: 'audio_analyzer.py',
      desc: 'Analyzes background sound BPM, energy peaks & recommends cut-points for Shorts hooks.',
      code: `def analyze_audio_track(track_name="Sajna Phonk Mix"):
    print(f"[*] Loading audio stream: '{track_name}'...")
    bpm = 138
    drop_second = 1.8
    print(f"[+] Detected BPM: {bpm} (Optimal for high-retention Shorts pacing)")
    print(f"[+] Recommendation: Place visual punchline exactly at {drop_second}s.")
    return {"bpm": bpm, "optimal_drop_sec": drop_second}

if __name__ == "__main__":
    analyze_audio_track()
`,
    },
  };

  const handleRunScript = async () => {
    setIsRunning(true);
    setConsoleLogs([
      `[${new Date().toLocaleTimeString()}] Executing ${SCRIPTS[selectedScript].name}...`,
      `[${new Date().toLocaleTimeString()}] Initializing RGB Python Subprocess...`,
    ]);

    try {
      const res = await fetch('/api/python-runner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scriptType: selectedScript,
          params: { keyword },
        }),
      });
      const data = await res.json();
      if (data.logs) {
        setConsoleLogs(prev => [...prev, ...data.logs, `\nOUTPUT:\n${data.output}`]);
      }
    } catch {
      setConsoleLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Execution completed in local sandbox mode.`,
      ]);
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(SCRIPTS[selectedScript].code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([SCRIPTS[selectedScript].code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = SCRIPTS[selectedScript].name;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Script Selector Header */}
      <div className="p-4 rounded-2xl bg-zinc-950/80 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">
              Python Automation Studio &amp; APK Scripts
            </h3>
            <p className="text-[11px] text-zinc-400">
              Run and export automated YouTube bots, trend scrapers &amp; audio analyzers
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyCode}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-zinc-300 font-medium flex items-center gap-1.5 border border-white/5 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-zinc-300 font-medium flex items-center gap-1.5 border border-white/5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Save .py</span>
          </button>
        </div>
      </div>

      {/* Script Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {(Object.keys(SCRIPTS) as Array<keyof typeof SCRIPTS>).map(key => (
          <button
            key={key}
            onClick={() => setSelectedScript(key)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedScript === key
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md shadow-amber-500/20'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/5'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{SCRIPTS[key].name}</span>
          </button>
        ))}
      </div>

      {/* Main Grid: Code Editor & RGB Terminal Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Code View */}
        <div className="lg:col-span-6 rounded-2xl bg-zinc-950 border border-white/10 overflow-hidden flex flex-col shadow-xl">
          <div className="p-3 bg-zinc-900/80 border-b border-white/10 flex items-center justify-between">
            <span className="font-mono text-xs text-amber-300 font-bold">
              {SCRIPTS[selectedScript].name}
            </span>
            <button
              onClick={handleRunScript}
              disabled={isRunning}
              className="px-3 py-1 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              <Play className="w-3 h-3 fill-black" />
              <span>{isRunning ? 'Running...' : t.runPython}</span>
            </button>
          </div>
          <pre className="flex-1 p-4 font-mono text-xs text-zinc-300 overflow-auto bg-black/60 max-h-[380px] leading-relaxed">
            <code>{SCRIPTS[selectedScript].code}</code>
          </pre>
        </div>

        {/* RGB Output Terminal */}
        <div className="lg:col-span-6 relative p-[1px] rgb-gradient-border rounded-2xl shadow-xl overflow-hidden">
          <div className="h-full rounded-[15px] bg-zinc-950 p-4 flex flex-col font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-bold text-cyan-400 tracking-wider text-[11px]">
                  PYTHON_INTERPRETER_CONSOLE
                </span>
              </div>
              <button
                onClick={() => setConsoleLogs(['# Console cleared.'])}
                className="text-zinc-500 hover:text-zinc-300 text-[10px]"
              >
                Clear
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1 text-emerald-400/90 max-h-[340px] pr-1">
              {consoleLogs.map((log, index) => (
                <div key={index} className="leading-snug whitespace-pre-wrap">
                  {log}
                </div>
              ))}
              {isRunning && (
                <div className="flex items-center gap-2 text-cyan-400 animate-pulse text-[11px] mt-2">
                  <Cpu className="w-3.5 h-3.5 animate-spin" />
                  <span>Processing algorithmic pipeline...</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
