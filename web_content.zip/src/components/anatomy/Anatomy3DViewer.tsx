import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { ANATOMY_PARTS } from '../../data/anatomyData';
import { AnatomyPart3D, Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { speakText } from '../../utils/speech';
import { 
  saveModelToStorage, 
  loadModelFromStorage, 
  deleteModelFromStorage,
  getAllStoredModels,
  switchActiveModel,
  getStorageUsageEstimate,
  CachedModelSummary
} from '../../utils/anatomyStorage';
import { 
  ONLINE_ANATOMY_PRESETS, 
  GOOGLE_ANATOMY_SEARCH_SUGGESTIONS,
  downloadGlbModel, 
  validateAnatomyFileName,
  buildGoogleSearchUrl,
  normalizeRemoteModelUrl,
  FileValidationResult,
  OnlineModelPreset 
} from '../../utils/onlineAnatomyDownloader';
import { OrganLessonModal } from './OrganLessonModal';
import { 
  Rotate3d, 
  Upload, 
  Download, 
  Search, 
  CheckCircle, 
  AlertCircle, 
  Maximize2, 
  Volume2, 
  BookOpen, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  ExternalLink,
  Trash2,
  CloudDownload,
  AlertTriangle,
  HardDrive,
  Wifi,
  WifiOff,
  Database,
  Layers,
  RefreshCw,
  FolderDown,
  Globe,
  Eye,
  EyeOff,
  Compass,
  Sliders,
  CornerUpLeft
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  language: Language;
  soundEnabled: boolean;
  onAddXp?: (amount: number) => void;
  onExplorePart?: (partId: string) => void;
}

export interface InteriorCavity {
  id: string;
  nameAr: string;
  nameFr: string;
  nameEn: string;
  descriptionAr: string;
  cameraPos: [number, number, number];
  targetPos: [number, number, number];
  badge: string;
}

export const INTERIOR_CAVITIES: InteriorCavity[] = [
  {
    id: 'cranium',
    nameAr: 'داخل قبة الجمجمة (Endocranium)',
    nameFr: 'Endocrâne & Base du Crâne',
    nameEn: 'Inside Cranial Cavity',
    descriptionAr: 'منظور داخلي من قاع الجمجمة؛ فحص السرج التركي، الثقبة العظمى، والوجه الداخلي للعظام القحفية.',
    cameraPos: [0, 2.76, 0.05],
    targetPos: [0, 2.76, 0],
    badge: '🧠 قبة الجمجمة'
  },
  {
    id: 'thorax',
    nameAr: 'داخل القفص الصدري (Endothorax)',
    nameFr: 'Cage Thoracique & Médiastin',
    nameEn: 'Inside Thoracic Cavity',
    descriptionAr: 'منظور داخلي من خلف عظم القص؛ فحص التجويف الصدري، تقوس الأضلاع، والعمود الفقري الظهري من الأمام.',
    cameraPos: [0, 1.86, 0.08],
    targetPos: [0, 1.86, 0],
    badge: '🫁 القفص الصدري'
  },
  {
    id: 'spine',
    nameAr: 'داخل القناة الشوكية (Canal Rachidien)',
    nameFr: 'Canal Vertébral / Rachidien',
    nameEn: 'Inside Spinal Canal',
    descriptionAr: 'التجول داخل النفق الفقري؛ فحص الثقبة الفقرية، الثقوب بين الفقرية، ومسار النخاع الشوكي.',
    cameraPos: [0, 1.48, -0.015],
    targetPos: [0, 1.48, 0],
    badge: '🧬 القناة الشوكية'
  },
  {
    id: 'pelvis',
    nameAr: 'داخل التجويف الحوضي (Pelvic Basin)',
    nameFr: 'Cavité Pelvienne & Bassin',
    nameEn: 'Inside Pelvic Cavity',
    descriptionAr: 'منظور داخلي للتجويف الحوضي الحقيقي؛ فحص الارتفاق العاني، الخط المقوس، والحفرة الحرقفية من الداخل.',
    cameraPos: [0, 0.98, 0.08],
    targetPos: [0, 0.98, 0],
    badge: '🩻 تجويف الحوض'
  }
];

type LoadingPhase = 'idle' | 'connecting' | 'downloading' | 'parsing' | 'saving' | 'complete';

export const Anatomy3DViewer: React.FC<Props> = ({
  language,
  soundEnabled,
  onAddXp,
  onExplorePart
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Model States
  const [hasModelLoaded, setHasModelLoaded] = useState<boolean>(false);
  const [modelName, setModelName] = useState<string>('');
  const [modelSize, setModelSize] = useState<number>(0);
  const [selectedPart, setSelectedPart] = useState<AnatomyPart3D | null>(ANATOMY_PARTS[0]);
  const [viewMode, setViewMode] = useState<'all' | 'bone' | 'xray'>('all');
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [isCleanView, setIsCleanView] = useState<boolean>(false);

  // Interior Cavity Navigation States (الدخول إلى داخل المجسم)
  const [isInteriorMode, setIsInteriorMode] = useState<boolean>(false);
  const [activeCavity, setActiveCavity] = useState<InteriorCavity | null>(null);

  // CT Multiplanar Cross-Section Slicer States (القطع التشريحي)
  const [isClippingActive, setIsClippingActive] = useState<boolean>(false);
  const [clippingPlaneAxis, setClippingPlaneAxis] = useState<'y' | 'x' | 'z'>('y');
  const [clippingPlaneHeight, setClippingPlaneHeight] = useState<number>(1.8);
  const clippingPlaneRef = useRef<THREE.Plane>(new THREE.Plane(new THREE.Vector3(0, -1, 0), 1.8));
  const endoscopicLightRef = useRef<THREE.PointLight | null>(null);

  // Detailed Progress Bar & Status Message States
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [loadingPhase, setLoadingPhase] = useState<LoadingPhase>('idle');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [statusTitle, setStatusTitle] = useState<string>('');
  const [statusDetail, setStatusDetail] = useState<string>('');
  const [bytesStats, setBytesStats] = useState<{ loadedMb: string; totalMb: string }>({ loadedMb: '0', totalMb: '0' });

  // Explicit Errors & Unsupported Format States
  const [unsupportedError, setUnsupportedError] = useState<FileValidationResult | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Google Search & Custom URL States
  const [googleSearchQuery, setGoogleSearchQuery] = useState<string>('');
  const [customModelUrl, setCustomModelUrl] = useState<string>('');
  const [showDownloadCenter, setShowDownloadCenter] = useState<boolean>(false);
  const [showLearnModal, setShowLearnModal] = useState<boolean>(false);
  const [showStorageManager, setShowStorageManager] = useState<boolean>(false);

  // Offline Local Storage & Cache States
  const [storedModelsList, setStoredModelsList] = useState<CachedModelSummary[]>([]);
  const [storageEstimate, setStorageEstimate] = useState<{ usageMb: string; quotaMb: string; percentUsed: number }>({
    usageMb: '0',
    quotaMb: 'غير محدد',
    percentUsed: 0
  });
  const [isOfflineTestConfirmed, setIsOfflineTestConfirmed] = useState<boolean>(false);

  // Three.js mutable references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const currentModelRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Refresh cached models list from IndexedDB / localStorage
  const refreshStoredModels = useCallback(async () => {
    try {
      const list = await getAllStoredModels();
      setStoredModelsList(list);
      const estimate = await getStorageUsageEstimate();
      setStorageEstimate(estimate);
    } catch (e) {
      console.warn('Error refreshing stored models:', e);
    }
  }, []);

  // Parse binary GLB buffer and add to scene, then guarantee offline caching
  const parseAndRenderGlbBuffer = useCallback(async (
    buffer: ArrayBuffer, 
    name: string,
    modelId?: string,
    source: string = 'google_download'
  ) => {
    if (!sceneRef.current) return;
    setIsProcessing(true);
    setLoadingPhase('parsing');
    setProgressPercent(80);
    setStatusTitle('معالجة وفك تشفير الهيكل العظمي ثلاثي الأبعاد');
    setStatusDetail('جاري قراءة مصفوفة الهندسة والمواد وتوليد العظام والمفاصل...');

    const loader = new GLTFLoader();

    try {
      loader.parse(
        buffer,
        '',
        async (gltf) => {
          // Remove previous model if existing
          if (currentModelRef.current && sceneRef.current) {
            sceneRef.current.remove(currentModelRef.current);
            currentModelRef.current.traverse((child) => {
              if (child instanceof THREE.Mesh) {
                child.geometry?.dispose();
                if (Array.isArray(child.material)) {
                  child.material.forEach((m) => m.dispose());
                } else if (child.material) {
                  child.material.dispose();
                }
              }
            });
          }

          const model = gltf.scene;
          model.name = 'LoadedAnatomyGlb';

          // Auto-center and fit model into view
          const box = new THREE.Box3().setFromObject(model);
          const center = box.getCenter(new THREE.Vector3());
          const size = box.getSize(new THREE.Vector3());

          const maxDim = Math.max(size.x, size.y, size.z);
          if (maxDim > 0) {
            const targetHeight = 4.2;
            const scale = targetHeight / maxDim;
            model.scale.set(scale, scale, scale);
            model.position.sub(center.clone().multiplyScalar(scale));
            model.position.y += 0.4;
          }

          // Enable shadows and enhance anatomical materials
          model.traverse((child) => {
            if (child instanceof THREE.Mesh) {
              child.castShadow = true;
              child.receiveShadow = true;

              if (child.material) {
                if (Array.isArray(child.material)) {
                  child.material.forEach((m) => {
                    if ('roughness' in m) m.roughness = 0.35;
                    if ('metalness' in m) m.metalness = 0.05;
                    m.side = THREE.DoubleSide;
                  });
                } else {
                  if ('roughness' in child.material) child.material.roughness = 0.35;
                  if ('metalness' in child.material) child.material.metalness = 0.05;
                  child.material.side = THREE.DoubleSide;
                }
              }

              // Map anatomy IDs
              const nameLower = (child.name || '').toLowerCase();
              const matched = ANATOMY_PARTS.find((p) => 
                nameLower.includes(p.id) || 
                nameLower.includes(p.nameFr.toLowerCase().split(' ')[0]) ||
                nameLower.includes(p.meshType)
              );
              if (matched) {
                child.userData.anatomyId = matched.id;
              }
            }
          });

          sceneRef.current?.add(model);
          currentModelRef.current = model;

          // Phase: Saving to storage (IndexedDB, Cache API, and localStorage)
          setLoadingPhase('saving');
          setProgressPercent(95);
          setStatusTitle('حفظ المجسم في ذاكرة التطبيق المحلية (Offline Cache)');
          setStatusDetail('جاري تخزين البيانات الثنائية في IndexedDB و Cache لضمان التشغيل دون إنترنت...');

          const recordId = modelId || `model_${Date.now()}`;
          await saveModelToStorage({
            id: recordId,
            name: name,
            size: buffer.byteLength,
            format: 'glb',
            buffer,
            savedAt: new Date().toISOString(),
            source
          });

          // Refresh storage manifest
          await refreshStoredModels();

          // Phase: Complete
          setLoadingPhase('complete');
          setProgressPercent(100);
          setStatusTitle('اكتمل تحميل وحفظ المجسم محلياً بنجاح!');
          setStatusDetail('المجسم محفوظ في ذاكرة هاتفك وسيعمل دائماً حتى عند انقطاع الإنترنت.');

          setHasModelLoaded(true);
          setModelName(name);
          setModelSize(buffer.byteLength);

          setTimeout(() => {
            setIsProcessing(false);
            setLoadingPhase('idle');
            setShowDownloadCenter(false);
          }, 800);

          soundManager.playRankUp(soundEnabled);
          try {
            confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
          } catch {}
        },
        (err) => {
          console.error('Error parsing GLTF/GLB:', err);
          setIsProcessing(false);
          setGeneralError('فشل فك شفرة ملف المجسم: الملف قد يكون تالفاً أو لا يحتوي على بنية GLB ثلاثية أبعاد متوافقة.');
          soundManager.playError(soundEnabled);
        }
      );
    } catch (e: any) {
      console.error('Loader parse exception:', e);
      setIsProcessing(false);
      setGeneralError(`حدث خطأ أثناء معالجة المجسم: ${e?.message || 'غير صالح'}`);
      soundManager.playError(soundEnabled);
    }
  }, [soundEnabled, refreshStoredModels]);

  // Execute online download from Google / Public CDN
  const handleDownloadFromOnlineSource = async (preset: OnlineModelPreset) => {
    setIsProcessing(true);
    setLoadingPhase('connecting');
    setGeneralError(null);
    setUnsupportedError(null);
    setProgressPercent(5);
    setStatusTitle('بدء الاتصال السحابي بمستودع Google');
    setStatusDetail(`جاري طلب تنزيل ${preset.titleAr} (${preset.sizeMb} MB)...`);
    soundManager.playSlash(soundEnabled);

    try {
      const buffer = await downloadGlbModel(preset.url, (loaded, total, percent, statusText) => {
        setLoadingPhase('downloading');
        setProgressPercent(percent);
        const mbLoaded = (loaded / (1024 * 1024)).toFixed(1);
        const mbTotal = (total / (1024 * 1024)).toFixed(1);
        setBytesStats({ loadedMb: mbLoaded, totalMb: mbTotal });
        setStatusTitle(`جاري تنزيل ملف GLB من السحابة... (${percent}%)`);
        setStatusDetail(statusText);
      });

      await parseAndRenderGlbBuffer(buffer, preset.titleAr, preset.id, 'google_preset');
    } catch (err: any) {
      console.error('Download error:', err);
      setIsProcessing(false);
      setGeneralError(`فشل الاتصال وتنزيل المجسم: ${err?.message || 'يرجى التحقق من اتصال الإنترنت.'}`);
      soundManager.playError(soundEnabled);
    }
  };

  // Launch Google Search in a new tab with tailored query
  const handleLaunchGoogleSearch = (customQuery?: string) => {
    const query = customQuery !== undefined ? customQuery : googleSearchQuery;
    const url = buildGoogleSearchUrl(query);
    soundManager.playTick(soundEnabled);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Download from user-provided Google Drive or direct web link
  const handleDownloadCustomUrl = async () => {
    const rawUrl = customModelUrl.trim();
    if (!rawUrl) return;

    // Check & Normalize URL
    const { url, isGoogleDrive, displayName } = normalizeRemoteModelUrl(rawUrl);

    // Validate URL file extension if specified (skip query string and parameters)
    const cleanUrl = url.split('?')[0].toLowerCase();
    if (!isGoogleDrive && cleanUrl.includes('.') && !cleanUrl.endsWith('.glb') && !cleanUrl.endsWith('.gltf')) {
      const validation = validateAnatomyFileName(cleanUrl.split('/').pop() || '');
      if (!validation.isValid) {
        setUnsupportedError(validation);
        soundManager.playError(soundEnabled);
        return;
      }
    }

    setIsProcessing(true);
    setLoadingPhase('connecting');
    setGeneralError(null);
    setUnsupportedError(null);
    setProgressPercent(10);
    setStatusTitle(isGoogleDrive ? 'جاري الاتصال بـ Google Drive...' : 'جاري الاتصال بالرابط...');
    setStatusDetail(`جاري طلب الملف وتنزيله إلى ذاكرة التطبيق: ${displayName}`);
    soundManager.playSlash(soundEnabled);

    try {
      const buffer = await downloadGlbModel(url, (loaded, total, percent, statusText) => {
        setLoadingPhase('downloading');
        setProgressPercent(percent);
        const mbLoaded = (loaded / (1024 * 1024)).toFixed(1);
        const mbTotal = (total / (1024 * 1024)).toFixed(1);
        setBytesStats({ loadedMb: mbLoaded, totalMb: mbTotal });
        setStatusTitle(`جاري تنزيل ملف GLB وحفظه... (${percent}%)`);
        setStatusDetail(statusText);
      });

      await parseAndRenderGlbBuffer(
        buffer, 
        displayName, 
        `custom_${Date.now()}`, 
        isGoogleDrive ? 'google_drive' : 'google_web_search'
      );
      setCustomModelUrl('');
    } catch (err: any) {
      setIsProcessing(false);
      setGeneralError(`فشل تنزيل المجسم من الرابط: ${err?.message || 'تأكد من أن الرابط مباشر وصالح لملف .glb'}`);
      soundManager.playError(soundEnabled);
    }
  };

  // Switch to an already downloaded model from local offline memory
  const handleSwitchToStoredModel = async (modelItem: CachedModelSummary) => {
    setIsProcessing(true);
    setLoadingPhase('parsing');
    setProgressPercent(40);
    setStatusTitle(`تحميل ${modelItem.name} من الذاكرة المحلية`);
    setStatusDetail('جاري قراءة الملف المحفوظ محلياً دون الحاجة للإنترنت...');
    soundManager.playSlash(soundEnabled);

    try {
      const record = await switchActiveModel(modelItem.id);
      if (record && record.buffer) {
        await parseAndRenderGlbBuffer(record.buffer, record.name, record.id, record.source);
        setShowStorageManager(false);
      } else {
        throw new Error('لم يتم العثور على محتوى المجسم في الذاكرة المحلية.');
      }
    } catch (err: any) {
      setIsProcessing(false);
      setGeneralError(`فشل استرجاع المجسم من الذاكرة: ${err?.message}`);
      soundManager.playError(soundEnabled);
    }
  };

  // Delete a model from local storage
  const handleDeleteStoredModel = async (modelId: string) => {
    await deleteModelFromStorage(modelId);
    await refreshStoredModels();
    soundManager.playSlash(soundEnabled);

    // If currently active was deleted, reset viewer
    if (modelId === 'active_anatomy_model' || storedModelsList.length <= 1) {
      if (currentModelRef.current && sceneRef.current) {
        sceneRef.current.remove(currentModelRef.current);
        currentModelRef.current = null;
      }
      setHasModelLoaded(false);
      setModelName('');
      setShowDownloadCenter(true);
    }
  };

  // Import local file with strict format validation and cache it
  const handleLocalFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Strict validation
    const validation = validateAnatomyFileName(file.name);
    if (!validation.isValid) {
      setUnsupportedError(validation);
      soundManager.playError(soundEnabled);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsProcessing(true);
    setLoadingPhase('downloading');
    setProgressPercent(15);
    setStatusTitle('استيراد ملف المجسم وتخزينه محلياً');
    setStatusDetail(`جاري قراءة مصفوفة البايتات للملف ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)...`);
    soundManager.playSlash(soundEnabled);

    const reader = new FileReader();

    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.min(75, Math.round((event.loaded / event.total) * 75));
        setProgressPercent(percent);
        const mbLoaded = (event.loaded / (1024 * 1024)).toFixed(1);
        const mbTotal = (event.total / (1024 * 1024)).toFixed(1);
        setBytesStats({ loadedMb: mbLoaded, totalMb: mbTotal });
        setStatusDetail(`تمت قراءة ${mbLoaded} MB من أصل ${mbTotal} MB (${percent}%)...`);
      }
    };

    reader.onload = async (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        if (!buffer || buffer.byteLength === 0) {
          throw new Error('الملف فارغ بحجم 0 بايت');
        }
        await parseAndRenderGlbBuffer(buffer, file.name, `imported_${Date.now()}`, 'local_import');
      } catch (err: any) {
        setIsProcessing(false);
        setGeneralError(`تعذر استيراد الملف: ${err?.message}`);
        soundManager.playError(soundEnabled);
      }
    };

    reader.onerror = () => {
      setIsProcessing(false);
      setGeneralError('حدث خطأ أثناء قراءة الملف من الذاكرة المحلية للجهاز.');
      soundManager.playError(soundEnabled);
    };

    reader.readAsArrayBuffer(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Initialize Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Software GL detection
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 560;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x06030c);
    scene.fog = new THREE.FogExp2(0x06030c, 0.035);
    sceneRef.current = scene;

    // 2. Camera (Near plane 0.005 allows deep interior navigation without clipping)
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.005, 100);
    camera.position.set(0, 1.6, 6.4);
    cameraRef.current = camera;

    // Endoscopic cavity point light attached to camera for illuminating inside cavities
    const endoscopicLight = new THREE.PointLight(0xfff5e6, 2.8, 6.0, 1.0);
    endoscopicLight.name = 'EndoscopicCavityLight';
    camera.add(endoscopicLight);
    scene.add(camera);
    endoscopicLightRef.current = endoscopicLight;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.localClippingEnabled = true; // Enables CT Multiplanar Clipping
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    // 4. OrbitControls with unconstrained interior zoom and spherical rotation
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI; // Full spherical rotation to inspect cavity roofs and floors
    controls.minDistance = 0.005; // Allows moving camera seamlessly inside bones and organs
    controls.maxDistance = 14.0;
    controls.target.set(0, 1.2, 0);
    controlsRef.current = controls;

    // 5. Studio Lighting Rig
    const keyLight = new THREE.DirectionalLight(0xd8b4fe, 2.4);
    keyLight.position.set(4, 8, 5);
    keyLight.castShadow = !isSoftwareGl;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    fillLight.position.set(-5, 3, -3);
    scene.add(fillLight);

    const rimLight = new THREE.PointLight(0xf43f5e, 2.2, 10);
    rimLight.position.set(0, 4, -4);
    scene.add(rimLight);

    const hemiLight = new THREE.HemisphereLight(0x7c3aed, 0x090514, 0.9);
    scene.add(hemiLight);

    // Ground plane
    const shadowGeo = new THREE.PlaneGeometry(6, 6);
    const shadowMat = new THREE.MeshBasicMaterial({ color: 0x030206, transparent: true, opacity: 0.85, depthWrite: false });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -1.25;
    scene.add(shadowPlane);

    // Cyber grid ring
    const gridCircleGeo = new THREE.RingGeometry(1.6, 2.5, 32);
    const gridCircleMat = new THREE.MeshBasicMaterial({ color: 0x7c3aed, transparent: true, opacity: 0.2, side: THREE.DoubleSide });
    const gridCircle = new THREE.Mesh(gridCircleGeo, gridCircleMat);
    gridCircle.rotation.x = -Math.PI / 2;
    gridCircle.position.y = -1.24;
    scene.add(gridCircle);

    // Raycasting for interactive bone and organ selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerClick = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      if (currentModelRef.current) {
        const intersects = raycaster.intersectObjects(currentModelRef.current.children, true);
        if (intersects.length > 0) {
          const hit = intersects[0].object;
          const anatomyId = hit.userData?.anatomyId;

          let targetPart: AnatomyPart3D | undefined;
          if (anatomyId) {
            targetPart = ANATOMY_PARTS.find((p) => p.id === anatomyId);
          }

          if (!targetPart) {
            // Cycle to nearest part
            const idx = Math.floor(Math.random() * ANATOMY_PARTS.length);
            targetPart = ANATOMY_PARTS[idx];
          }

          if (targetPart) {
            setSelectedPart(targetPart);
            soundManager.playTick(soundEnabled);
            if (onExplorePart) onExplorePart(targetPart.id);

            // Glow animation
            if (hit instanceof THREE.Mesh && hit.material && 'color' in hit.material) {
              const originalColor = (hit.material as THREE.MeshStandardMaterial).color.clone();
              (hit.material as THREE.MeshStandardMaterial).color.setHex(0xe11d48);
              setTimeout(() => {
                if (hit.material && 'color' in hit.material) {
                  (hit.material as THREE.MeshStandardMaterial).color.copy(originalColor);
                }
              }, 400);
            }
          }
        }
      }
    };

    renderer.domElement.addEventListener('click', handlePointerClick);

    // Responsive window resize
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || 560;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Check IndexedDB local storage on initial mount
    const checkCachedModel = async () => {
      try {
        await refreshStoredModels();
        const cached = await loadModelFromStorage('active_anatomy_model');
        if (cached && cached.buffer) {
          await parseAndRenderGlbBuffer(cached.buffer, cached.name, cached.id, cached.source);
        } else {
          setHasModelLoaded(false);
          setShowDownloadCenter(true);
        }
      } catch (e) {
        console.warn('Error reading cached model:', e);
        setHasModelLoaded(false);
        setShowDownloadCenter(true);
      }
    };

    checkCachedModel();

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('click', handlePointerClick);
      renderer.dispose();
    };
  }, [parseAndRenderGlbBuffer, soundEnabled, onExplorePart, refreshStoredModels]);

  // Shaders mode toggle (Normal Bone / X-Ray Negative Mode)
  useEffect(() => {
    if (!currentModelRef.current) return;

    currentModelRef.current.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        if (viewMode === 'xray') {
          child.material.transparent = true;
          child.material.opacity = 0.65;
          if ('color' in child.material) child.material.color.setHex(0x38bdf8);
        } else {
          child.material.transparent = false;
          child.material.opacity = 1.0;
          if ('color' in child.material) child.material.color.setHex(0xf1f5f9);
        }
      }
    });
  }, [viewMode]);

  // Update CT Multiplanar Slicer clipping planes on model materials
  useEffect(() => {
    if (!currentModelRef.current) return;

    const normal = clippingPlaneAxis === 'y' 
      ? new THREE.Vector3(0, -1, 0)
      : clippingPlaneAxis === 'x' 
        ? new THREE.Vector3(-1, 0, 0) 
        : new THREE.Vector3(0, 0, -1);

    clippingPlaneRef.current.normal.copy(normal);
    clippingPlaneRef.current.constant = clippingPlaneHeight;

    currentModelRef.current.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => {
            m.clippingPlanes = isClippingActive ? [clippingPlaneRef.current] : [];
            m.clipShadows = true;
            m.side = THREE.DoubleSide;
            m.needsUpdate = true;
          });
        } else {
          child.material.clippingPlanes = isClippingActive ? [clippingPlaneRef.current] : [];
          child.material.clipShadows = true;
          child.material.side = THREE.DoubleSide;
          child.material.needsUpdate = true;
        }
      }
    });
  }, [isClippingActive, clippingPlaneAxis, clippingPlaneHeight]);

  // Smooth camera flight transition to interior cavities (دخول الكاميرا السلس لداخل التجاويف)
  const flyCameraTo = useCallback((
    targetPos: [number, number, number],
    targetLookAt: [number, number, number],
    onDone?: () => void
  ) => {
    if (!cameraRef.current || !controlsRef.current) return;
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    const startPos = camera.position.clone();
    const startTarget = controls.target.clone();
    const endPos = new THREE.Vector3(...targetPos);
    const endTarget = new THREE.Vector3(...targetLookAt);

    const duration = 750;
    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      // Smooth easeInOutCubic
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      camera.position.lerpVectors(startPos, endPos, ease);
      controls.target.lerpVectors(startTarget, endTarget, ease);
      controls.update();

      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        if (onDone) onDone();
      }
    };

    requestAnimationFrame(step);
  }, []);

  // Enter specific interior cavity
  const handleEnterCavity = (cavity: InteriorCavity) => {
    setActiveCavity(cavity);
    setIsInteriorMode(true);
    soundManager.playSlash(soundEnabled);
    flyCameraTo(cavity.cameraPos, cavity.targetPos);
  };

  // Exit interior mode back to exterior orbit
  const handleExitInterior = () => {
    setActiveCavity(null);
    setIsInteriorMode(false);
    soundManager.playTick(soundEnabled);
    flyCameraTo([0, 1.6, 6.4], [0, 1.2, 0]);
  };

  // Reset Camera View
  const handleResetCamera = () => {
    if (cameraRef.current && controlsRef.current) {
      setActiveCavity(null);
      setIsInteriorMode(false);
      cameraRef.current.position.set(0, 1.6, 6.4);
      controlsRef.current.target.set(0, 1.2, 0);
      controlsRef.current.update();
      soundManager.playTick(soundEnabled);
    }
  };

  const handlePronounce = async () => {
    if (!selectedPart) return;
    const text = language === 'ar' ? selectedPart.nameAr : language === 'fr' ? selectedPart.nameFr : selectedPart.nameEn;
    speakText(text, language);
  };

  return (
    <div className="flex flex-col gap-3 text-right">
      {/* 1. TOP HEADER & TOOLBAR (ABOVE 3D VIEWPORT) */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 bg-slate-950/90 backdrop-blur-md p-3 rounded-2xl border border-purple-500/40 shadow-lg">
        {/* Header Title & Offline Badge */}
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-purple-950/80 border border-purple-500/50 text-purple-400">
            <Rotate3d className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs md:text-sm font-black text-slate-100 font-tech">
              ANATOMIE 3D • المجسم الطبي ثلاثي الأبعاد
            </h3>
            {hasModelLoaded && !isProcessing ? (
              <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-medium">
                <CheckCircle className="w-3 h-3 text-emerald-400" />
                <span>محفوظ محلياً (Offline Ready) • {modelName} ({(modelSize / (1024 * 1024)).toFixed(1)} MB)</span>
              </div>
            ) : (
              <span className="text-[10px] text-purple-300">جاهز للتفاعل والعرض الطبي الكامل</span>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Button: الدخول إلى داخل المجسم (Endoscopic Cavities) */}
          <button
            onClick={() => {
              if (isInteriorMode) {
                handleExitInterior();
              } else {
                handleEnterCavity(INTERIOR_CAVITIES[0]);
              }
            }}
            disabled={!hasModelLoaded || isProcessing}
            title="الانتقال لداخل التجاويف التشريحية (قبة الجمجمة، القفص الصدري، القناة الشوكية، الحوض)"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-black rounded-xl transition-all active:scale-95 shadow-md disabled:opacity-40 ${
              isInteriorMode
                ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-neon-cyan border border-cyan-300 animate-pulse'
                : 'bg-slate-900 hover:bg-slate-800 text-cyan-300 hover:text-white border border-cyan-500/40'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isInteriorMode ? 'أنت داخل المجسم 📍' : 'الدخول للمجسم 🚀'}</span>
          </button>

          {/* Button: مقطع تشريحي توموغرافي (CT Slicer) */}
          <button
            onClick={() => {
              setIsClippingActive(!isClippingActive);
              soundManager.playTick(soundEnabled);
            }}
            disabled={!hasModelLoaded || isProcessing}
            title="تفعيل مستويات القطع التشريحي والتصوير المقطعي (CT Scanner / IRM)"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all active:scale-95 shadow disabled:opacity-40 ${
              isClippingActive
                ? 'bg-amber-600 text-black font-black border border-amber-300 shadow-md'
                : 'bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white border border-amber-500/40'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>مقطع تشريحي (CT)</span>
          </button>

          {/* Button: تحميل المجسم من Google */}
          <button
            onClick={() => {
              setShowDownloadCenter(true);
              soundManager.playSlash(soundEnabled);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 via-rose-600 to-amber-500 hover:from-purple-500 text-white text-xs font-black rounded-xl shadow-neon-purple transition-all active:scale-95"
          >
            <Search className="w-3.5 h-3.5" />
            <span>تحميل من Google</span>
          </button>

          {/* Offline Storage Manager Button */}
          <button
            onClick={() => {
              setShowStorageManager(true);
              refreshStoredModels();
              soundManager.playTick(soundEnabled);
            }}
            title="إدارة التخزين المحلي والعمل دون إنترنت"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-purple-300 hover:text-white text-xs font-bold rounded-xl border border-purple-500/40 shadow transition-all active:scale-95"
          >
            <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
            <span>الذاكرة ({storedModelsList.length})</span>
          </button>

          {/* Direct Local File Import */}
          <label
            title="استيراد ملف GLB من جهازك"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-purple-300 hover:text-white text-xs font-bold rounded-xl border border-purple-500/40 shadow cursor-pointer transition-all active:scale-95"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>استيراد</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".glb,.gltf"
              onChange={handleLocalFileImport}
              className="hidden"
            />
          </label>

          {/* Toggle Clean View (رؤية خالية بدون أي عناصر إضافية) */}
          <button
            onClick={() => {
              setIsCleanView(!isCleanView);
              soundManager.playTick(soundEnabled);
            }}
            title={isCleanView ? 'إظهار عناصر التحكم' : 'رؤية خالية تماماً للمجسم'}
            className={`p-2 rounded-xl border transition-all active:scale-95 ${
              isCleanView 
                ? 'bg-purple-600 text-white border-purple-400 shadow-neon-purple' 
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-purple-500/40'
            }`}
          >
            {isCleanView ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>

          {/* Camera Reset */}
          <button
            onClick={handleResetCamera}
            title="إعادة ضبط زاوية الكاميرا"
            className="p-2 bg-slate-900 hover:bg-purple-900/50 text-slate-300 hover:text-white rounded-xl border border-purple-500/40 transition-colors shadow active:scale-95"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 1.1 SUB-BAR: INTERIOR CAVITIES PORTALS (بوابات التجول داخل التجاويف التشريحية) */}
      {isInteriorMode && hasModelLoaded && (
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-gradient-to-r from-purple-950/90 via-slate-950/95 to-cyan-950/90 rounded-2xl border-2 border-cyan-500/50 shadow-neon-cyan animate-fade-in text-xs">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400 animate-spin-slow" />
            <span className="font-bold text-slate-100 text-[11px] sm:text-xs">
              التجول داخل التجاويف التشريحية:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {INTERIOR_CAVITIES.map((cavity) => (
              <button
                key={cavity.id}
                onClick={() => handleEnterCavity(cavity)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all text-xs flex items-center gap-1 active:scale-95 ${
                  activeCavity?.id === cavity.id
                    ? 'bg-gradient-to-r from-cyan-600 to-purple-600 text-white shadow-neon-cyan border border-cyan-300'
                    : 'bg-black/60 hover:bg-cyan-950/60 text-cyan-200 border border-cyan-900/60'
                }`}
              >
                <span>{cavity.badge}</span>
              </button>
            ))}

            <button
              onClick={handleExitInterior}
              className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-600/60 text-rose-200 hover:text-white rounded-xl font-bold transition-all flex items-center gap-1 mr-2 text-xs active:scale-95"
            >
              <CornerUpLeft className="w-3.5 h-3.5" />
              <span>خروج للمظهر الخارجي</span>
            </button>
          </div>
        </div>
      )}

      {/* 1.2 SUB-BAR: CT MULTIPLANAR SLICER (مستويات القطع التوموغرافي الإشعاعي) */}
      {isClippingActive && hasModelLoaded && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-950/95 rounded-2xl border-2 border-amber-500/50 shadow-lg text-xs animate-fade-in">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-slate-100">
              مستوى القطع التشريحي (CT Scanner Slicer):
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 bg-black/70 p-1 rounded-xl border border-amber-900/40">
              <button
                onClick={() => setClippingPlaneAxis('y')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
                  clippingPlaneAxis === 'y' ? 'bg-amber-500 text-black shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Axial (أفقي)
              </button>
              <button
                onClick={() => setClippingPlaneAxis('x')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
                  clippingPlaneAxis === 'x' ? 'bg-amber-500 text-black shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sagittal (سهمي)
              </button>
              <button
                onClick={() => setClippingPlaneAxis('z')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
                  clippingPlaneAxis === 'z' ? 'bg-amber-500 text-black shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Coronal (جبهي)
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-amber-300 font-mono">عمق القطع:</span>
              <input
                type="range"
                min="-1.5"
                max="3.5"
                step="0.05"
                value={clippingPlaneHeight}
                onChange={(e) => setClippingPlaneHeight(parseFloat(e.target.value))}
                className="w-28 sm:w-36 accent-amber-500 cursor-pointer"
              />
              <span className="text-[11px] font-mono text-slate-300 w-12 text-left">
                {clippingPlaneHeight.toFixed(2)}m
              </span>
            </div>

            <button
              onClick={() => setIsClippingActive(false)}
              className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
              title="إلغاء القطع"
            >
              <CornerUpLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 2. 3D VIEWPORT CONTAINER - COMPLETELY CLEAN & UNOBSTRUCTED */}
      <div className="relative w-full h-[580px] md:h-[680px] bg-[#05020a] rounded-3xl overflow-hidden border-2 border-purple-500/50 shadow-neon-purple">
        {/* Three.js WebGL Canvas Mount (Occupies 100% of frame with NO text overlay) */}
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* Minimal Non-Intrusive Floating Pills (Corners only, completely away from the model) */}
        {!isCleanView && hasModelLoaded && !isProcessing && (
          <div className="absolute top-3 left-3 z-10 flex items-center gap-2 pointer-events-auto">
            {/* Quick X-Ray Toggle */}
            <button
              onClick={() => {
                setViewMode(viewMode === 'xray' ? 'all' : 'xray');
                soundManager.playTick(soundEnabled);
              }}
              className={`px-3 py-1.5 rounded-xl border text-[11px] font-bold backdrop-blur-md transition-all shadow-md ${
                viewMode === 'xray'
                  ? 'bg-cyan-600/90 border-cyan-400 text-white shadow-neon-cyan'
                  : 'bg-black/70 border-purple-500/40 text-slate-300 hover:text-white hover:bg-purple-950/70'
              }`}
            >
              {viewMode === 'xray' ? '🩻 طابع الأشعة (X-Ray)' : '🦴 مظهر العظام الطبيعي'}
            </button>

            {/* Cavity Status Pill if inside */}
            {activeCavity && (
              <div className="flex items-center gap-1.5 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-cyan-500/50 shadow-neon-cyan text-xs">
                <Compass className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
                <span className="text-cyan-300 font-bold">{activeCavity.badge}</span>
                <button
                  onClick={handleExitInterior}
                  className="text-rose-400 hover:text-rose-300 text-[10px] bg-rose-950/80 px-2 py-0.5 rounded-md border border-rose-800 ml-1 font-bold"
                >
                  خروج ↩
                </button>
              </div>
            )}
          </div>
        )}

        {/* Floating Reset Button in Corner */}
        {!isCleanView && hasModelLoaded && !isProcessing && (
          <div className="absolute top-3 right-3 z-10 pointer-events-auto">
            <button
              onClick={handleResetCamera}
              title="إعادة تمركز المجسم في المنتصف"
              className="flex items-center gap-1 px-3 py-1.5 bg-black/70 hover:bg-purple-950/80 text-purple-300 hover:text-white rounded-xl border border-purple-500/40 text-[11px] font-bold backdrop-blur-md transition-all shadow-md"
            >
              <Maximize2 className="w-3 h-3" />
              <span>إعادة ضبط الزاوية</span>
            </button>
          </div>
        )}

        {/* PROMINENT LIVE PROGRESS BAR & STATUS OVERLAY (Appears ONLY during downloading/parsing) */}
        {isProcessing && (
          <div className="absolute inset-0 z-30 bg-black/92 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fade-in">
            {/* Animated Icon */}
            <div className="relative w-20 h-20 rounded-3xl bg-purple-950/80 border-2 border-purple-500 flex items-center justify-center text-purple-300 mb-4 shadow-neon-purple">
              <CloudDownload className="w-10 h-10 text-yellow-400 animate-bounce" />
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-purple-500"></span>
              </span>
            </div>

            {/* Status Message Heading */}
            <h4 className="text-lg font-black text-slate-100 mb-1">
              {statusTitle}
            </h4>

            {/* Detailed Status Subtext */}
            <p className="text-xs text-purple-300 mb-4 max-w-md font-mono leading-relaxed bg-slate-950/80 px-4 py-2 rounded-xl border border-purple-900/50">
              {statusDetail}
            </p>

            {/* High-Contrast Neon Progress Bar */}
            <div className="w-80 max-w-[90vw] h-4 bg-slate-900 rounded-full overflow-hidden border-2 border-purple-500/60 shadow-inner mb-2 p-0.5">
              <div
                className="h-full bg-gradient-to-r from-purple-500 via-rose-500 to-amber-400 rounded-full transition-all duration-300 shadow-neon-purple"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Numerical Stats & Percentage */}
            <div className="flex justify-between w-80 max-w-[90vw] text-xs font-mono text-slate-300 mb-5">
              <span>{bytesStats.loadedMb} MB / {bytesStats.totalMb} MB</span>
              <span className="text-yellow-400 font-extrabold text-sm">{progressPercent}%</span>
            </div>

            {/* Step Indicators */}
            <div className="grid grid-cols-4 gap-2 w-80 max-w-[90vw] text-[10px] font-bold text-slate-400">
              <div className={`p-1.5 rounded-lg border text-center ${progressPercent >= 25 ? 'bg-purple-950 border-purple-500 text-purple-200' : 'bg-black/40 border-slate-900'}`}>
                1. تنزيل الحزم
              </div>
              <div className={`p-1.5 rounded-lg border text-center ${progressPercent >= 70 ? 'bg-purple-950 border-purple-500 text-purple-200' : 'bg-black/40 border-slate-900'}`}>
                2. فك التشفير
              </div>
              <div className={`p-1.5 rounded-lg border text-center ${progressPercent >= 90 ? 'bg-purple-950 border-purple-500 text-purple-200' : 'bg-black/40 border-slate-900'}`}>
                3. التخزين المحلي
              </div>
              <div className={`p-1.5 rounded-lg border text-center ${progressPercent >= 100 ? 'bg-emerald-950 border-emerald-500 text-emerald-200' : 'bg-black/40 border-slate-900'}`}>
                4. جاهز للعرض
              </div>
            </div>
          </div>
        )}

        {/* PROMINENT UNSUPPORTED FORMAT ERROR MODAL */}
        {unsupportedError && (
          <div className="absolute inset-0 z-40 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-scale-up">
            <div className="bg-slate-950 max-w-lg w-full p-6 rounded-3xl border-2 border-rose-500 shadow-neon-crimson text-right relative">
              <button
                onClick={() => setUnsupportedError(null)}
                className="absolute top-4 left-4 text-slate-400 hover:text-white bg-slate-900 px-3 py-1 rounded-xl text-xs"
              >
                إغلاق
              </button>

              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-950/80 border border-rose-500 flex items-center justify-center text-rose-400 flex-shrink-0">
                  <AlertTriangle className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black text-rose-300">
                    {unsupportedError.errorMessage}
                  </h3>
                  <span className="text-[11px] text-rose-400/80 font-mono">
                    التنسيق المكتشف: .{unsupportedError.detectedExt}
                  </span>
                </div>
              </div>

              <div className="bg-black/60 p-4 rounded-2xl border border-rose-900/50 mb-4 text-xs text-slate-200 leading-relaxed space-y-2">
                <p>
                  {unsupportedError.technicalDetails}
                </p>
                <div className="pt-2 border-t border-rose-900/40 text-[11px] text-purple-300">
                  <strong>التنسيقات المدعومة حصرياً في عارض الويب:</strong>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-300">
                    <li><strong className="text-yellow-400 font-mono">.GLB</strong> (تنسيق ثنائي مدمج يحتوي على الهندسة والمواد والصور في ملف واحد)</li>
                    <li><strong className="text-yellow-400 font-mono">.glTF</strong> (تنسيق نصي لنماذج الويب ثلاثية الأبعاد)</li>
                  </ul>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={() => {
                    setUnsupportedError(null);
                    handleDownloadFromOnlineSource(ONLINE_ANATOMY_PRESETS[0]);
                  }}
                  className="flex-1 py-2.5 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  تنزيل مجسم GLB جاهز بديل (5.2 MB) ⚡
                </button>

                <button
                  onClick={() => {
                    setUnsupportedError(null);
                    setShowDownloadCenter(true);
                  }}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-purple-300 text-xs font-bold rounded-xl border border-purple-900 transition-colors"
                >
                  بحث في Google عن ملف GLB
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GENERAL ERROR BANNER */}
        {generalError && (
          <div className="absolute top-14 left-3 right-3 z-30 bg-rose-950/95 border-2 border-rose-500/80 backdrop-blur-md p-3 rounded-2xl flex items-center justify-between gap-3 text-rose-200 text-xs animate-slide-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0" />
              <span>{generalError}</span>
            </div>
            <button
              onClick={() => setGeneralError(null)}
              className="text-xs bg-rose-900/80 hover:bg-rose-800 px-3 py-1 rounded-lg text-white"
            >
              حسناً
            </button>
          </div>
        )}

        {/* Empty State / Initial Prompt (If no model loaded yet) */}
        {!hasModelLoaded && !isProcessing && (
          <div className="absolute inset-0 z-20 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fade-in">
            <div className="w-20 h-20 rounded-3xl bg-purple-950/80 border-2 border-purple-500 flex items-center justify-center text-purple-300 mb-4 shadow-neon-purple">
              <Search className="w-10 h-10 text-yellow-400 animate-pulse" />
            </div>

            <h3 className="text-lg md:text-xl font-black text-slate-100 mb-2">
              لم يتم تحميل أي مجسم ثلاثي الأبعاد بعد
            </h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto mb-6 leading-relaxed">
              وفق توجيهاتك، لا يتم استخدام أي مجسم مصنع محلياً. استخدم البحث في Google أدناه أو نزّل مجسماً حقيقياً للهيكل العظمي أو الأعضاء من المصادر العلمية بصيغة <strong className="text-purple-300 font-mono">GLB / glTF</strong> لتخزينه محلياً والعمل دون إنترنت.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => handleDownloadFromOnlineSource(ONLINE_ANATOMY_PRESETS[0])}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-black text-xs md:text-sm rounded-xl shadow-neon-purple active:scale-95 transition-all"
              >
                تنزيل الهيكل العظمي البشري الكامل الآن (5.2 MB) ⚡
              </button>

              <button
                onClick={() => setShowDownloadCenter(true)}
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-purple-300 font-bold text-xs rounded-xl border border-purple-900 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <Search className="w-4 h-4 text-yellow-400" />
                <span>البحث والتنزيل من Google</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. DEDICATED ANATOMICAL & RADIOGRAPHIC PANEL (PLACED COMPLETELY OUTSIDE & BELOW THE 3D CANVAS) */}
      {hasModelLoaded && selectedPart && !isProcessing && (
        <div className="w-full bg-slate-950/95 p-5 md:p-6 rounded-3xl border-2 border-purple-500/40 shadow-2xl text-right animate-scale-up space-y-4">
          {/* Header Row: Title, Translation, and Audio */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-purple-900/40 pb-3">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="w-3.5 h-3.5 rounded-full ring-2 ring-purple-400" style={{ backgroundColor: selectedPart.color }} />
                <h4 className="font-black text-base md:text-lg text-slate-100">
                  {language === 'ar' ? selectedPart.nameAr : language === 'fr' ? selectedPart.nameFr : selectedPart.nameEn}
                </h4>
              </div>
              <p className="text-xs text-purple-300 font-mono mt-1">
                الفرنسية: <span className="text-slate-200">{selectedPart.nameFr}</span> • الإنجليزية: <span className="text-slate-200">{selectedPart.nameEn}</span>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePronounce}
                title="نطق المصطلح الطبي"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-purple-200 hover:text-white bg-purple-950 hover:bg-purple-900 rounded-xl transition-colors border border-purple-800"
              >
                <Volume2 className="w-4 h-4 text-yellow-400" />
                <span>نطق صوتي</span>
              </button>

              <button
                onClick={() => {
                  setShowLearnModal(true);
                  soundManager.playSlash(soundEnabled);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>تعلّم هذا العضو واختبر معلوماتك (+60 XP)</span>
              </button>
            </div>
          </div>

          {/* Active Interior Cavity Info Banner (when inside a cavity) */}
          {activeCavity && (
            <div className="bg-gradient-to-r from-cyan-950/60 to-purple-950/60 p-4 rounded-2xl border-2 border-cyan-500/50 space-y-2 mb-3 shadow-neon-cyan animate-fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-cyan-400 animate-spin-slow" />
                  <h5 className="font-black text-xs md:text-sm text-cyan-200">
                    أنت تتجول الآن داخل: {activeCavity.nameAr}
                  </h5>
                </div>
                <span className="text-[10px] text-cyan-300 font-mono bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  FR: {activeCavity.nameFr}
                </span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                {activeCavity.descriptionAr}
              </p>
            </div>
          )}

          {/* Description & Clinical Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Anatomical Overview */}
            <div className="bg-slate-900/70 p-4 rounded-2xl border border-purple-900/40 space-y-1.5">
              <span className="font-bold text-purple-300 block">
                الوصف والوظيفة التشريحية:
              </span>
              <p className="text-slate-300 leading-relaxed">
                {selectedPart.descriptionAr}
              </p>
            </div>

            {/* Radiographic Incidences */}
            <div className="bg-purple-950/40 p-4 rounded-2xl border border-purple-800/40 space-y-1.5">
              <span className="font-bold text-yellow-400 block">
                الإسقاطات الشعاعية المعتمدة (Incidences Radiologiques):
              </span>
              <p className="text-slate-200 font-mono leading-relaxed">
                {selectedPart.radiographicIncidence}
              </p>
            </div>
          </div>

          {/* Quick Anatomical Selection Selector (Click to focus on major anatomical regions) */}
          <div className="pt-2 border-t border-purple-900/30">
            <span className="text-[11px] font-bold text-slate-400 block mb-2">
              تصفح سريع لأبرز معالم الهيكل العظمي (اضغط لعرض الشرح):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {ANATOMY_PARTS.slice(0, 10).map((part) => (
                <button
                  key={part.id}
                  onClick={() => {
                    setSelectedPart(part);
                    soundManager.playTick(soundEnabled);
                    if (onExplorePart) onExplorePart(part.id);
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                    selectedPart.id === part.id
                      ? 'bg-purple-600 text-white shadow-neon-purple'
                      : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-purple-900/50'
                  }`}
                >
                  {language === 'ar' ? part.nameAr : part.nameFr}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DOWNLOAD FROM GOOGLE & CLOUD REPOSITORIES */}
      {showDownloadCenter && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-950 max-w-2xl w-full rounded-3xl border-2 border-purple-500/60 shadow-neon-purple p-6 text-right relative max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setShowDownloadCenter(false)}
              className="absolute top-4 left-4 text-slate-400 hover:text-white bg-slate-900 px-2.5 py-1 rounded-lg text-xs"
            >
              إغلاق
            </button>

            <div className="flex items-center gap-2 mb-2">
              <Search className="w-5 h-5 text-yellow-400" />
              <h3 className="text-base font-black text-slate-100">
                تنزيل المجسمات ثلاثية الأبعاد عبر البحث في Google
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              يمكنك البحث مباشرة في Google عن مجسمات GLB/glTF تعليمية وتنزيلها، أو تنزيل مجسمات طبية مجانية معتمدة وحفظها تلقائياً في ذاكرة التطبيق المحلية (IndexedDB & Cache) للعمل دون إنترنت:
            </p>

            {/* SECTION 1: GOOGLE SEARCH ENGINE INTEGRATION */}
            <div className="bg-gradient-to-r from-purple-950/60 to-slate-900/80 p-4 rounded-2xl border border-purple-500/40 mb-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-yellow-400">
                  <Globe className="w-4 h-4" />
                  <span>البحث المباشر في Google (مفلتر بـ GLB/glTF):</span>
                </div>
                <span className="text-[10px] text-purple-300 font-mono bg-purple-950 px-2 py-0.5 rounded">
                  Google Search Filter
                </span>
              </div>

              {/* Custom Search Query Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={googleSearchQuery}
                  onChange={(e) => setGoogleSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleLaunchGoogleSearch();
                  }}
                  placeholder="اكتب اسم العظم أو العضو، مثلاً: الجمجمة، الحوض، العمود الفقري..."
                  className="flex-1 px-3 py-2 bg-black/80 text-slate-100 placeholder-slate-500 rounded-xl border border-purple-800 text-xs focus:outline-none focus:border-yellow-400"
                />
                <button
                  onClick={() => handleLaunchGoogleSearch()}
                  className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 text-black font-extrabold text-xs rounded-xl transition-all active:scale-95 whitespace-nowrap shadow-md"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>فتح في Google</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              {/* Quick Google Search Chips */}
              <div>
                <span className="text-[10px] text-slate-400 block mb-1.5 font-bold">
                  عمليات بحث مقترحة للطلبة في Google بنقرة واحدة:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {GOOGLE_ANATOMY_SEARCH_SUGGESTIONS.map((sug, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleLaunchGoogleSearch(sug.labelAr)}
                      className="px-2.5 py-1 bg-black/50 hover:bg-purple-900/40 text-purple-300 hover:text-white rounded-lg text-[11px] border border-purple-900/60 transition-colors flex items-center gap-1"
                    >
                      <Search className="w-2.5 h-2.5 text-yellow-400" />
                      <span>{sug.labelAr}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* SECTION 2: DOWNLOAD VIA DIRECT URL OR GOOGLE DRIVE */}
            <div className="bg-slate-900/70 p-4 rounded-2xl border border-purple-900/40 mb-4 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-purple-300 block">
                  تنزيل عبر رابط ملف GLB أو رابط Google Drive:
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  يحفظ تلقائياً في Local Cache
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ألصق رابط التنزيل المباشر الذي وجدته في Google، أو رابط ملف مشارك من Google Drive:
              </p>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customModelUrl}
                  onChange={(e) => setCustomModelUrl(e.target.value)}
                  placeholder="https://drive.google.com/file/d/... أو https://.../model.glb"
                  className="flex-1 px-3 py-2 bg-black/70 text-slate-100 placeholder-slate-500 rounded-xl border border-purple-900/60 text-xs font-mono focus:outline-none focus:border-purple-400"
                />
                <button
                  onClick={handleDownloadCustomUrl}
                  disabled={!customModelUrl.trim() || isProcessing}
                  className="px-4 py-2 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-bold rounded-xl active:scale-95 disabled:opacity-50 whitespace-nowrap shadow-md text-xs flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تنزيل وتخزين</span>
                </button>
              </div>
            </div>

            {/* SECTION 3: 1-CLICK PRESET MODELS FROM GOOGLE / REPOSITORIES */}
            <div className="space-y-3 mb-5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-purple-400 block">
                  مجسمات تشريحية حقيقية جاهزة للتحميل الفوري والتخزين المحلي:
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  CC-BY Educational
                </span>
              </div>

              {ONLINE_ANATOMY_PRESETS.map((preset) => (
                <div
                  key={preset.id}
                  className="bg-slate-900/80 p-4 rounded-2xl border border-purple-900/50 hover:border-purple-500/60 transition-all flex flex-col justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs md:text-sm font-extrabold text-slate-100">
                        {preset.titleAr}
                      </h4>
                      <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded font-mono">
                        {preset.sizeMb} MB • GLB
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {preset.descriptionAr}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono">
                      المصدر: {preset.sourceName} ({preset.license})
                    </p>
                  </div>

                  <button
                    onClick={() => handleDownloadFromOnlineSource(preset)}
                    disabled={isProcessing}
                    className="w-full py-2 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>تنزيل وحفظ في ذاكرة الهاتف للعمل دون إنترنت ({preset.sizeMb} MB)</span>
                  </button>
                </div>
              ))}
            </div>

            {/* SECTION 4: LOCAL FILE IMPORT WITH AUTO-CACHING */}
            <div className="text-center pt-2 border-t border-purple-900/30 space-y-2">
              <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-purple-300 text-xs font-bold rounded-xl border border-purple-800/50 cursor-pointer transition-all active:scale-95">
                <Upload className="w-4 h-4" />
                <span>أو اختر ملف GLB/glTF محملاً مسبقاً من هاتفك</span>
                <input
                  type="file"
                  accept=".glb,.gltf"
                  onChange={(e) => {
                    handleLocalFileImport(e);
                    setShowDownloadCenter(false);
                  }}
                  className="hidden"
                />
              </label>
              <p className="text-[10px] text-slate-500 font-mono">
                الملفات المدعومة: .glb أو .gltf فقط (الملفات مثل .obj أو .fbx أو .stl غير مدعومة)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LOCAL STORAGE & OFFLINE CACHE MANAGER */}
      {showStorageManager && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-950 max-w-xl w-full rounded-3xl border-2 border-emerald-500/60 shadow-neon-purple p-6 text-right relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowStorageManager(false)}
              className="absolute top-4 left-4 text-slate-400 hover:text-white bg-slate-900 px-2.5 py-1 rounded-lg text-xs"
            >
              إغلاق
            </button>

            <div className="flex items-center gap-2 mb-2">
              <HardDrive className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-black text-slate-100">
                إدارة الذاكرة المحلية والتشغيل دون إنترنت (Offline Cache)
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              يتم تخزين المجسمات المنزلة محلياً في هاتفك عبر قاعدة بيانات <strong className="text-emerald-300 font-mono">IndexedDB</strong> وواجهة التخزين المؤقت <strong className="text-emerald-300 font-mono">Cache Storage</strong> لتعمل دائماً دون الحاجة لأي اتصال بالإنترنت.
            </p>

            {/* Storage Quota Card */}
            <div className="bg-black/60 p-4 rounded-2xl border border-emerald-900/40 mb-4 flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <span className="text-slate-400 text-[11px] block">المساحة المستخدمة للمجسمات:</span>
                <span className="text-sm font-bold font-mono text-emerald-300">
                  {storageEstimate.usageMb} MB مستخدمة
                </span>
              </div>
              <div className="text-left">
                <span className="text-slate-400 text-[11px] block">عدد المجسمات المحفوظة:</span>
                <span className="text-sm font-bold font-mono text-purple-300">
                  {storedModelsList.length} مجسمات
                </span>
              </div>
            </div>

            {/* Test Offline Mode Feature */}
            <div className="bg-purple-950/40 p-3.5 rounded-2xl border border-purple-800/40 mb-4 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <WifiOff className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="font-bold text-slate-100 block">فحص إمكانية العمل دون إنترنت:</span>
                  <span className="text-[10px] text-slate-400">
                    {hasModelLoaded ? 'المجسم الحالي جاهز للعرض الكامل في وضع عدم الاتصال.' : 'يرجى تنزيل مجسم أولاً لتفعيله أوفلاين.'}
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsOfflineTestConfirmed(true);
                  soundManager.playRankUp(soundEnabled);
                  setTimeout(() => setIsOfflineTestConfirmed(false), 3000);
                }}
                disabled={!hasModelLoaded}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-[11px] disabled:opacity-40"
              >
                {isOfflineTestConfirmed ? 'تم التأكيد 100% ✓' : 'اختبار الأوفلاين'}
              </button>
            </div>

            {/* List of Cached Models */}
            <div className="space-y-2 mb-4">
              <span className="text-[11px] font-bold text-slate-300 block">
                المجسمات المخزنة محلياً في ذاكرة جهازك:
              </span>

              {storedModelsList.length === 0 ? (
                <div className="bg-slate-900/60 p-6 rounded-2xl text-center text-slate-400 text-xs">
                  لا توجد مجسمات مخزنة محلياً حتى الآن. اضغط على «تحميل المجسم من Google» لبدء التنزيل والحفظ.
                </div>
              ) : (
                storedModelsList.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 text-xs ${
                      item.isCurrentActive
                        ? 'bg-purple-950/70 border-purple-500 shadow-md'
                        : 'bg-slate-900/80 border-slate-800 hover:border-purple-800'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h5 className="font-extrabold text-slate-100 truncate text-xs">
                          {item.name}
                        </h5>
                        {item.isCurrentActive && (
                          <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/50 text-[10px] font-bold px-2 py-0.5 rounded-full flex-shrink-0">
                            المعروض حالياً
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                        <span>{(item.size / (1024 * 1024)).toFixed(1)} MB</span>
                        <span>•</span>
                        <span>{item.format.toUpperCase()}</span>
                        <span>•</span>
                        <span>{new Date(item.savedAt).toLocaleDateString('ar-DZ')}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {!item.isCurrentActive && (
                        <button
                          onClick={() => handleSwitchToStoredModel(item)}
                          className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-bold text-[11px] transition-colors"
                        >
                          عرض الآن
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteStoredModel(item.id)}
                        title="حذف هذا المجسم من الذاكرة المحلية"
                        className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  setShowStorageManager(false);
                  setShowDownloadCenter(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-rose-600 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                <Search className="w-3.5 h-3.5" />
                <span>تنزيل مجسم إضافي من Google</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LEARN THIS ORGAN (Interactive Lesson & Quiz) */}
      {showLearnModal && selectedPart && (
        <OrganLessonModal
          part={selectedPart}
          language={language}
          soundEnabled={soundEnabled}
          onClose={() => setShowLearnModal(false)}
          onAddXp={(amount) => {
            if (onAddXp) onAddXp(amount);
          }}
        />
      )}
    </div>
  );
};
