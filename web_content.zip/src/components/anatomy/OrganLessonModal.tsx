import React, { useState } from 'react';
import { AnatomyPart3D, Language, MedicalTerm } from '../../types';
import { ALL_MEDICAL_TERMS } from '../../data/medicalTerms';
import { soundManager } from '../../utils/audio';
import { speakText } from '../../utils/speech';
import { 
  BookOpen, 
  CheckCircle, 
  AlertCircle, 
  X, 
  Award, 
  Volume2, 
  Radio, 
  Sparkles,
  Zap,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  part: AnatomyPart3D;
  language: Language;
  soundEnabled: boolean;
  onClose: () => void;
  onAddXp: (amount: number) => void;
}

interface OrganQuestion {
  questionAr: string;
  questionFr: string;
  optionsAr: string[];
  optionsFr: string[];
  correctIndex: number;
  explanationAr: string;
}

export const OrganLessonModal: React.FC<Props> = ({
  part,
  language,
  soundEnabled,
  onClose,
  onAddXp
}) => {
  const [activeTab, setActiveTab] = useState<'lesson' | 'quiz' | 'terms'>('lesson');
  const [quizIndex, setQuizIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);

  // Dynamic high-yield questions based on selected anatomical part
  const organQuestions: OrganQuestion[] = [
    {
      questionAr: `ما هي الوضعية القياسية الأهم لتصوير ${part.nameAr} واستبعاد الكسور الحادة؟`,
      questionFr: `Quelle est l'incidence standard pour explorer ${part.nameFr} ?`,
      optionsAr: [
        part.radiographicIncidence.split(',')[0] || 'الوجه والجانب المتعامدان (Face et Profil)',
        'صورة مائلة فقط بزاوية 80 درجة دون تحضير',
        'صورة مستلقية دون مراعاة المسافة البؤرية',
        'فحص فلوروسكوبي مستمر دون لوح'
      ],
      optionsFr: [
        part.radiographicIncidence.split(',')[0] || 'Face et Profil orthogonaux',
        'Incidence oblique seule à 80°',
        'Cliché en décubitus sans centrage',
        'Radioscopie continue'
      ],
      correctIndex: 0,
      explanationAr: `الإسقاط الأساسي المعتمد هو: ${part.radiographicIncidence}. القاعدة الذهبية في الرضوض تتطلب دائماً إسقاطين متعامدين (Face et Profil).`
    },
    {
      questionAr: `ما هو المعيار السريري الأساسي لتقني الأشعة عند فحص ${part.nameAr}؟`,
      questionFr: `Quel est le critère technique fondamental lors de l'examen de ${part.nameFr} ?`,
      optionsAr: [
        part.clinicalNoteAr,
        'إلغاء استخدام مآزر الرصاص للمريض ومرافقيه',
        'مضاعفة الجرعة الإشعاعية دون ضبط المسافة',
        'تصوير العضو مبتوراً دون المفصلين المجاورين'
      ],
      optionsFr: [
        'Respect scrupuleux du centrage et des repères anatomiques',
        'Suppression des tabliers plombés',
        'Doublement inutile de la dose sans collimation',
        'Omission des articulations sus et sous-jacentes'
      ],
      correctIndex: 0,
      explanationAr: part.clinicalNoteAr
    },
    {
      questionAr: `في أي جهاز تصوير طبي تظهر تفاصيل الأنسجة الرخوة والأوتار المحيطة بـ ${part.nameAr} بأعلى دقة تباين؟`,
      questionFr: `Quelle modalité d'imagerie offre le meilleur contraste pour les tissus mous de ${part.nameFr} ?`,
      optionsAr: [
        'الرنين المغناطيسي (IRM) والموجات فوق الصوتية',
        'الأشعة السينية البسيطة غير المفلترة',
        'صورة الأسنان البانورامية فقط',
        'التنظير التألقي اليدوي'
      ],
      optionsFr: [
        'IRM et Échographie haute résolution',
        'Radiographie standard sans filtre',
        'Panoramique dentaire',
        'Radioscopie classique'
      ],
      correctIndex: 0,
      explanationAr: 'الرنين المغناطيسي (IRM) والإيكوغرافيا هما الأداتان الرائدتان لدراسة الأربطة، الغضاريف، والأنسجة الرخوة بدقة دون إشعاع مؤين.'
    }
  ];

  // Find linked terms in the 1000+ medical terms database
  const linkedTerms: MedicalTerm[] = ALL_MEDICAL_TERMS.filter((t) => {
    const qFr = part.nameFr.toLowerCase();
    const qAr = part.nameAr.toLowerCase();
    return (
      t.termFr.toLowerCase().includes(qFr) ||
      t.termAr.toLowerCase().includes(qAr) ||
      t.definitionFr.toLowerCase().includes(qFr) ||
      t.definitionAr.toLowerCase().includes(qAr)
    );
  }).slice(0, 8);

  const handleCheckAnswer = () => {
    if (selectedAnswer === null) return;
    const isCorrect = selectedAnswer === organQuestions[quizIndex].correctIndex;
    setIsAnswerChecked(true);

    if (isCorrect) {
      setScore((s) => s + 1);
      soundManager.playSuccess(soundEnabled);
    } else {
      soundManager.playError(soundEnabled);
    }
  };

  const handleNextQuiz = () => {
    if (quizIndex + 1 < organQuestions.length) {
      setQuizIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerChecked(false);
      soundManager.playTick(soundEnabled);
    } else {
      setIsQuizCompleted(true);
      const earnedXp = score * 20 + 20;
      onAddXp(earnedXp);
      soundManager.playRankUp(soundEnabled);
      try {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.5 } });
      } catch {}
    }
  };

  const handlePronounce = (text: string, lang: 'ar' | 'fr' | 'en') => {
    soundManager.playTick(soundEnabled);
    speakText(text, lang);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 md:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-slate-950 max-w-2xl w-full rounded-3xl border-2 border-purple-500/60 shadow-neon-purple p-5 md:p-6 text-right relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 bg-slate-900 hover:bg-rose-900/60 text-slate-300 hover:text-white rounded-xl border border-purple-900 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="border-b border-purple-900/40 pb-4 mb-4">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: part.color }} />
            <span className="text-[10px] bg-purple-900/60 text-purple-300 font-mono px-2 py-0.5 rounded border border-purple-700">
              {part.system.toUpperCase()} • 3D ANATOMIE
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-xl md:text-2xl font-black text-slate-100">
                {part.nameAr}
              </h2>
              <button
                onClick={() => handlePronounce(part.nameAr, 'ar')}
                className="p-1.5 text-purple-300 hover:text-white bg-purple-950/60 rounded-lg"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          <p className="text-xs text-purple-300 font-mono mt-0.5">
            FR: {part.nameFr} | EN: {part.nameEn}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 mb-4 bg-black/60 p-1.5 rounded-xl border border-purple-900/40 text-xs">
          <button
            onClick={() => setActiveTab('lesson')}
            className={`flex-1 py-2 rounded-lg font-bold transition-all ${
              activeTab === 'lesson'
                ? 'bg-purple-600 text-white shadow-neon-purple'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            الدرس والوظيفة التشريحية
          </button>
          <button
            onClick={() => setActiveTab('terms')}
            className={`flex-1 py-2 rounded-lg font-bold transition-all ${
              activeTab === 'terms'
                ? 'bg-purple-600 text-white shadow-neon-purple'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            المصطلحات المرتبطة ({linkedTerms.length})
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex-1 py-2 rounded-lg font-bold transition-all ${
              activeTab === 'quiz'
                ? 'bg-rose-600 text-white shadow-neon-crimson'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            اختبار سريع (+60 XP)
          </button>
        </div>

        {/* TAB 1: LESSON */}
        {activeTab === 'lesson' && (
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1 text-xs md:text-sm">
            <div className="bg-slate-900/60 p-4 rounded-2xl border border-purple-900/30">
              <h4 className="font-extrabold text-purple-300 mb-1.5 text-xs uppercase">
                الوصف التشريحي والوظيفة الحيوية:
              </h4>
              <p className="text-slate-200 leading-relaxed mb-2">
                {part.descriptionAr}
              </p>
              <p className="text-slate-400 text-xs italic font-mono">
                🇫🇷 {part.descriptionFr}
              </p>
            </div>

            <div className="bg-purple-950/30 p-4 rounded-2xl border border-purple-800/40">
              <div className="flex items-center gap-2 font-bold text-purple-300 mb-1.5 text-xs">
                <Radio className="w-4 h-4 text-purple-400" />
                <span>الإسقاطات الشعاعية المعتمدة (Incidences Radiologiques) :</span>
              </div>
              <p className="text-slate-100 font-mono text-xs leading-relaxed">
                {part.radiographicIncidence}
              </p>
            </div>

            <div className="bg-emerald-950/20 p-4 rounded-2xl border border-emerald-800/40 text-xs">
              <span className="font-bold text-emerald-400 block mb-1">
                نصيحة تقني الأشعة في المستشفى الجزائري:
              </span>
              <p className="text-slate-200 leading-relaxed">
                {part.clinicalNoteAr}
              </p>
            </div>
          </div>
        )}

        {/* TAB 2: LINKED MEDICAL TERMS */}
        {activeTab === 'terms' && (
          <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
            <p className="text-xs text-slate-400">
              المصطلحات الطبية المرتبطة بـ <strong className="text-purple-300">{part.nameAr}</strong> من قاعدة بيانات التطبيق:
            </p>

            {linkedTerms.length === 0 ? (
              <div className="text-center py-10 bg-slate-900/40 rounded-xl border border-purple-900/30 text-xs text-slate-400">
                لا توجد مصطلحات مرتبطة مباشرة، تصفح القاموس لمزيد من التفاصيل.
              </div>
            ) : (
              linkedTerms.map((term) => (
                <div
                  key={term.id}
                  className="bg-slate-900/70 p-3 rounded-xl border border-purple-900/40 text-right text-xs"
                >
                  <div className="flex items-center justify-between border-b border-purple-900/30 pb-1.5 mb-1.5">
                    <div>
                      <span className="font-extrabold text-purple-300 font-tech">
                        {term.termFr}
                      </span>
                      <span className="text-slate-200 mr-2 font-bold">
                        ({term.termAr})
                      </span>
                    </div>
                    <button
                      onClick={() => handlePronounce(term.termFr, 'fr')}
                      className="p-1 text-purple-300 hover:text-white"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {term.definitionAr}
                  </p>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 3: ORGAN MINI QUIZ */}
        {activeTab === 'quiz' && (
          <div className="space-y-4">
            {!isQuizCompleted ? (
              <>
                <div className="flex justify-between items-center text-xs font-mono text-purple-400 border-b border-purple-900/30 pb-2">
                  <span>السؤال {quizIndex + 1} من {organQuestions.length}</span>
                  <span className="text-yellow-400">النقاط: {score}</span>
                </div>

                <h4 className="text-sm md:text-base font-black text-slate-100 leading-relaxed">
                  {organQuestions[quizIndex].questionAr}
                </h4>

                <div className="space-y-2">
                  {organQuestions[quizIndex].optionsAr.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        if (!isAnswerChecked) {
                          setSelectedAnswer(idx);
                          soundManager.playTick(soundEnabled);
                        }
                      }}
                      disabled={isAnswerChecked}
                      className={`w-full text-right p-3 rounded-xl border text-xs font-semibold transition-all ${
                        selectedAnswer === idx
                          ? 'bg-purple-600/40 border-purple-400 text-white shadow-neon-purple'
                          : 'bg-slate-900/60 border-purple-900/30 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full border border-purple-400/50 flex items-center justify-center text-[10px] font-mono">
                          {idx + 1}
                        </span>
                        <span>{opt}</span>
                      </div>
                    </button>
                  ))}
                </div>

                {isAnswerChecked && (
                  <div
                    className={`p-3 rounded-xl border text-xs leading-relaxed ${
                      selectedAnswer === organQuestions[quizIndex].correctIndex
                        ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200'
                        : 'bg-rose-950/60 border-rose-500 text-rose-200'
                    }`}
                  >
                    <div className="font-bold mb-1 flex items-center gap-1.5">
                      {selectedAnswer === organQuestions[quizIndex].correctIndex ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                          <span>إجابة صحيحة ومتقنة!</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                          <span>إجابة خاطئة! التفسير:</span>
                        </>
                      )}
                    </div>
                    <p>{organQuestions[quizIndex].explanationAr}</p>
                  </div>
                )}

                {!isAnswerChecked ? (
                  <button
                    onClick={handleCheckAnswer}
                    disabled={selectedAnswer === null}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-black text-xs rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50"
                  >
                    تأكيد الإجابة
                  </button>
                ) : (
                  <button
                    onClick={handleNextQuiz}
                    className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-black text-xs rounded-xl shadow-lg transition-all active:scale-95"
                  >
                    {quizIndex + 1 < organQuestions.length ? 'السؤال التالي' : 'إنهاء الاختبار وحصد الـ XP'}
                  </button>
                )}
              </>
            ) : (
              <div className="text-center py-6 space-y-3">
                <Award className="w-16 h-16 text-yellow-400 mx-auto animate-bounce" />
                <h3 className="text-lg font-black text-slate-100">
                  تهانينا! أتقنت دراسة {part.nameAr}
                </h3>
                <p className="text-xs text-purple-300">
                  نتيجتك: {score} من {organQuestions.length} • كسبت{' '}
                  <span className="font-bold text-yellow-400 font-mono">
                    +{score * 20 + 20} XP
                  </span>
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-neon-purple active:scale-95"
                >
                  العودة إلى المجسم 3D
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
