import React, { useState } from 'react';
import { GameEngine } from '../game/engine';
import { SKILLS, getSkillRank, canUnlockSkill, SkillDefinition } from '../game/skills';
import { SkillBranch, SkillId } from '../types/game';
import { X, Shield, Sword, Compass, Pickaxe, Hammer, Waves, Sparkles, Check, Lock } from 'lucide-react';

interface SkillTreeModalProps {
  engine: GameEngine;
  onClose: () => void;
}

const BRANCHES: { id: SkillBranch; nameAr: string; icon: React.ReactNode; color: string }[] = [
  { id: 'survival', nameAr: 'البقاء', icon: <Shield className="w-4 h-4" />, color: 'text-emerald-400' },
  { id: 'combat', nameAr: 'القتال', icon: <Sword className="w-4 h-4" />, color: 'text-red-400' },
  { id: 'exploration', nameAr: 'الاستكشاف', icon: <Compass className="w-4 h-4" />, color: 'text-amber-400' },
  { id: 'gathering', nameAr: 'الجمع', icon: <Pickaxe className="w-4 h-4" />, color: 'text-yellow-400' },
  { id: 'crafting', nameAr: 'الصناعة', icon: <Hammer className="w-4 h-4" />, color: 'text-cyan-400' },
  { id: 'aquatic', nameAr: 'المائي', icon: <Waves className="w-4 h-4" />, color: 'text-blue-400' },
];

export const SkillTreeModal: React.FC<SkillTreeModalProps> = ({ engine, onClose }) => {
  const [selectedBranch, setSelectedBranch] = useState<SkillBranch>('survival');
  const [, setRefresh] = useState(0);

  const player = engine.player;
  const xpNeeded = Math.floor(75 * Math.pow(1.3, player.level - 1));
  const xpPercent = Math.min(100, Math.round((player.xp / xpNeeded) * 100));

  const branchSkills = SKILLS.filter((s) => s.branch === selectedBranch);

  const handleUnlock = (skillId: string) => {
    const success = engine.unlockPlayerSkill(skillId as SkillId);
    if (success) {
      setRefresh((r) => r + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 select-none font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-neutral-950 border-4 border-amber-600/80 rounded-xl shadow-2xl text-neutral-100 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-3 sm:p-4 border-b-2 border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border-2 border-amber-500 flex items-center justify-center text-amber-400 shadow">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-wide text-amber-400">شجرة المهارات والترقيات</h2>
              <p className="text-xs text-neutral-400">طوّر قدرات شخصيتك لتعزيز فرص النجاة ومواجهة الأخطار</p>
            </div>
          </div>

          <button
            id="btn-close-skilltree"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center transition active:scale-95 border border-neutral-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Player Level & Skill Points Status Bar */}
        <div className="p-3 bg-neutral-900/50 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Level & XP */}
          <div className="flex items-center gap-3">
            <div className="px-2.5 py-1 rounded bg-amber-950/80 border border-amber-500/60 font-black text-amber-300">
              المستوى {player.level}
            </div>
            <div className="flex flex-col gap-1 w-32 sm:w-44">
              <div className="flex justify-between text-[10px] text-neutral-400 font-mono">
                <span>الخبرة (XP)</span>
                <span>{player.xp}/{xpNeeded}</span>
              </div>
              <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden border border-neutral-700">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-amber-400 transition-all duration-300"
                  style={{ width: `${xpPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Available Skill Points */}
          <div className="flex items-center gap-2 bg-neutral-950 px-3 py-1.5 rounded-lg border border-amber-500/50">
            <span className="text-amber-400 font-bold">نقاط المهارة المتاحة:</span>
            <span className={`font-mono font-black text-sm px-2 py-0.5 rounded ${player.skillPoints > 0 ? 'bg-amber-500 text-neutral-950 animate-pulse' : 'bg-neutral-800 text-neutral-400'}`}>
              {player.skillPoints}
            </span>
          </div>
        </div>

        {/* Branch Selector Tabs */}
        <div className="flex items-center gap-1.5 p-2 bg-neutral-900/70 border-b border-neutral-800 overflow-x-auto scrollbar-none">
          {BRANCHES.map((b) => {
            const isActive = selectedBranch === b.id;
            return (
              <button
                key={b.id}
                id={`tab-branch-${b.id}`}
                onClick={() => setSelectedBranch(b.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer border ${
                  isActive
                    ? 'bg-amber-950/60 border-amber-500 text-amber-200 shadow-sm'
                    : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700 text-neutral-400'
                }`}
              >
                <span className={b.color}>{b.icon}</span>
                <span>{b.nameAr}</span>
              </button>
            );
          })}
        </div>

        {/* Skills Grid List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 flex flex-col gap-2.5">
          {branchSkills.map((skill: SkillDefinition) => {
            const rank = getSkillRank(player, skill.id);
            const check = canUnlockSkill(player, skill.id);
            const isMax = rank >= skill.maxRank;
            const canUnlock = check.can && player.skillPoints >= skill.requiredPoints;

            return (
              <div
                key={skill.id}
                id={`skill-card-${skill.id}`}
                className={`p-3 rounded-lg border-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition ${
                  isMax
                    ? 'bg-neutral-900/80 border-emerald-600/60'
                    : canUnlock
                    ? 'bg-neutral-900/90 border-amber-500/80 shadow-md shadow-amber-500/10'
                    : 'bg-neutral-950/70 border-neutral-800 opacity-80'
                }`}
              >
                <div className="flex items-start gap-3 flex-1">
                  {/* Rank indicator badge */}
                  <div className={`w-10 h-10 rounded-lg flex flex-col items-center justify-center border font-mono font-black shrink-0 ${
                    isMax
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                      : rank > 0
                      ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                      : 'bg-neutral-900 border-neutral-700 text-neutral-500'
                  }`}>
                    <span className="text-[10px]">مستوى</span>
                    <span className="text-xs">{rank}/{skill.maxRank}</span>
                  </div>

                  <div className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xs sm:text-sm font-black text-neutral-100">{skill.nameAr}</h3>
                      {isMax && (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-900/80 border border-emerald-500 text-emerald-300 text-[9px] font-bold flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" /> مكتملة
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-300 leading-relaxed">{skill.descAr}</p>

                    {/* Requirements & Cost details */}
                    <div className="flex flex-wrap items-center gap-2 mt-1 text-[10px] text-neutral-400">
                      <span>يتطلب: مستوى {skill.requiredLevel}</span>
                      <span>•</span>
                      <span>التكلفة: {skill.requiredPoints} نقطة</span>
                      {skill.prerequisiteId && (
                        <>
                          <span>•</span>
                          <span className={getSkillRank(player, skill.prerequisiteId) > 0 ? 'text-emerald-400' : 'text-red-400 flex items-center gap-0.5'}>
                            {getSkillRank(player, skill.prerequisiteId) === 0 && <Lock className="w-2.5 h-2.5" />}
                            يتطلب فتح المهارة السابقة
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Unlock / Upgrade Button */}
                <div className="shrink-0 self-end sm:self-center">
                  {isMax ? (
                    <div className="px-3 py-1.5 rounded bg-neutral-900 border border-emerald-600 text-emerald-400 text-xs font-bold text-center">
                      المستوى الأقصى ✓
                    </div>
                  ) : (
                    <button
                      id={`btn-unlock-${skill.id}`}
                      disabled={!canUnlock}
                      onClick={() => handleUnlock(skill.id)}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition cursor-pointer border flex items-center gap-1.5 shadow ${
                        canUnlock
                          ? 'bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-white border-yellow-300 active:scale-95'
                          : 'bg-neutral-900 text-neutral-500 border-neutral-800 cursor-not-allowed'
                      }`}
                    >
                      {!check.can && <Lock className="w-3 h-3" />}
                      <span>{rank > 0 ? 'ترقية للمستوى التالي' : 'تفعيل المهارة'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-neutral-900 border-t border-neutral-800 flex justify-between items-center text-xs text-neutral-400">
          <span>نصيحة: احصل على نقاط المهارات من خلال هزيمة الوحوش والجمع والاستكشاف</span>
          <button
            id="btn-close-skilltree-footer"
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-bold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
