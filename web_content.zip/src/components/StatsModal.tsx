import React from 'react';
import { Flame, Plus, Shield, Swords, X, Zap } from 'lucide-react';
import { PlayerStats } from '../types/game';

interface StatsModalProps {
  stats: PlayerStats;
  onClose: () => void;
  onAllocate: (statKey: 'melee' | 'defense' | 'sword' | 'fruit', points: number) => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({ stats, onClose, onAllocate }) => {
  const statRows: Array<{
    id: 'melee' | 'defense' | 'sword' | 'fruit';
    name: string;
    icon: any;
    color: string;
    value: number;
    description: string;
    bonus: string;
  }> = [
    {
      id: 'melee',
      name: 'Melee',
      icon: Zap,
      color: 'text-amber-400',
      value: stats.meleeStat,
      description: 'Strengthens martial punches, kicks, and boosts maximum Energy.',
      bonus: `+${stats.meleeStat * 20} Max Energy · +${(stats.meleeStat * 3.2).toFixed(1)} Punch DMG`,
    },
    {
      id: 'defense',
      name: 'Defense',
      icon: Shield,
      color: 'text-emerald-400',
      value: stats.defenseStat,
      description: 'Increases resilience against pirate attacks and maximizes Health.',
      bonus: `+${stats.defenseStat * 25} Max Health`,
    },
    {
      id: 'sword',
      name: 'Sword',
      icon: Swords,
      color: 'text-sky-400',
      value: stats.swordStat,
      description: 'Mastery with single, dual katanas, and legendary sabers.',
      bonus: `+${(stats.swordStat * 3.5).toFixed(1)} Sword Slash DMG`,
    },
    {
      id: 'fruit',
      name: 'Blox Fruit',
      icon: Flame,
      color: 'text-orange-400',
      value: stats.fruitStat,
      description: 'Amplifies all Devil Fruit projectile and transformation skills.',
      bonus: `+${(stats.fruitStat * 4.2).toFixed(1)} Fruit Ability DMG`,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Character Stats</h2>
            <p className="text-xs text-slate-400 mt-0.5">Allocate skill points earned from leveling up</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Stat Points Available Banner */}
          <div className="bg-slate-950 border border-amber-500/30 rounded-xl p-3 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-semibold uppercase">Available Points</span>
              <div className="text-2xl font-mono font-black text-amber-400 tabular-nums">
                {stats.statPoints} <span className="text-xs text-slate-300 font-sans font-semibold">PTS</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400 font-semibold uppercase">Current Level</span>
              <div className="text-2xl font-mono font-black text-white tabular-nums">
                Lv. {stats.level}
              </div>
            </div>
          </div>

          {/* Stats List */}
          <div className="space-y-3">
            {statRows.map((row) => {
              const Icon = row.icon;
              return (
                <div
                  key={row.id}
                  className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 flex items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                      <Icon className={`w-5 h-5 ${row.color}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{row.name}</span>
                        <span className="font-mono text-sm font-extrabold text-amber-300">
                          {row.value}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{row.description}</p>
                      <p className="text-[10px] font-mono text-emerald-400 mt-1 font-semibold">{row.bonus}</p>
                    </div>
                  </div>

                  {/* Allocate Buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onAllocate(row.id, 1)}
                      disabled={stats.statPoints < 1}
                      className="flex items-center justify-center w-8 h-8 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      title="Add 1 point"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onAllocate(row.id, 5)}
                      disabled={stats.statPoints < 5}
                      className="px-2 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs font-bold border border-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      title="Add 5 points"
                    >
                      +5
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
