import React, { useState } from 'react';
import { Quiz, Question, SUBJECTS_DATA } from '../types';
import { generateQuestionsAI } from '../api';
import {
  X,
  Sparkles,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  FileText,
  Lightbulb,
  Image as ImageIcon,
  Check
} from 'lucide-react';

interface CreateQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveQuiz: (quiz: Quiz) => Promise<void>;
}

export const CreateQuizModal: React.FC<CreateQuizModalProps> = ({ isOpen, onClose, onSaveQuiz }) => {
  const [subjectId, setSubjectId] = useState('rajasthan_gk');
  const [subCategoryId, setSubCategoryId] = useState('raj_art_culture');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  // AI Generator state
  const [aiTopic, setAiTopic] = useState('');
  const [aiCount, setAiCount] = useState<number>(5);
  const [aiDifficulty, setAiDifficulty] = useState('मध्यम (Moderate)');
  const [selectedImage, setSelectedImage] = useState<{ file: File; base64: string; preview: string } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiError, setAiError] = useState('');
  const [aiSuccessMsg, setAiSuccessMsg] = useState('');

  // Draft questions list
  const [draftQuestions, setDraftQuestions] = useState<Question[]>([]);

  // Manual Question modal state
  const [manualModalOpen, setManualModalOpen] = useState(false);
  const [manualText, setManualText] = useState('');
  const [manualOptions, setManualOptions] = useState<string[]>(['', '', '', '']);
  const [manualCorrectIndex, setManualCorrectIndex] = useState(0);
  const [manualExplanation, setManualExplanation] = useState('');

  if (!isOpen) return null;

  const currentSubject = SUBJECTS_DATA.find((s) => s.id === subjectId) || SUBJECTS_DATA[0];

  const handleSubjectChange = (newSubjectId: string) => {
    setSubjectId(newSubjectId);
    const subj = SUBJECTS_DATA.find((s) => s.id === newSubjectId);
    if (subj && subj.subcategories.length > 0) {
      setSubCategoryId(subj.subcategories[0].id);
    }
  };

  // Convert image to base64
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const res = reader.result as string;
      setSelectedImage({
        file,
        base64: res,
        preview: res,
      });
    };
    reader.readAsDataURL(file);
  };

  // Call server-side Gemini AI
  const handleGenerateAI = async () => {
    if (!aiTopic.trim() && !selectedImage) {
      setAiError('कृपया कोई विषय (Topic), टेक्स्ट लिखें या प्रश्न-पत्र की फोटो अपलोड करें।');
      return;
    }

    setAiError('');
    setAiSuccessMsg('');
    setIsGenerating(true);

    try {
      const generated = await generateQuestionsAI({
        topic: aiTopic.trim(),
        image: selectedImage
          ? {
              mimeType: selectedImage.file.type,
              data: selectedImage.base64,
            }
          : undefined,
        count: aiCount,
        subjectName: currentSubject.name,
        difficulty: aiDifficulty,
      });

      if (generated && generated.length > 0) {
        setDraftQuestions((prev) => [...prev, ...generated]);
        setAiSuccessMsg(`सफलता! Gemini AI ने ${generated.length} प्रश्न व्याख्या सहित तैयार कर दिए हैं।`);
        setAiTopic('');
        setSelectedImage(null);

        // Auto-fill title if empty
        if (!title.trim() && aiTopic.trim()) {
          setTitle(`${aiTopic.trim()} (मॉक टेस्ट)`);
        }
      } else {
        setAiError('AI द्वारा कोई प्रश्न प्राप्त नहीं हुए। कृपया पुनः प्रयास करें।');
      }
    } catch (err: any) {
      console.error('AI error:', err);
      setAiError(err.message || 'AI प्रश्न निर्माण विफल रहा।');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddManualQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualText.trim() || manualOptions.some((o) => !o.trim())) {
      alert('कृपया प्रश्न और चारों विकल्प भरें।');
      return;
    }

    const newQ: Question = {
      text: manualText.trim(),
      options: manualOptions.map((o) => o.trim()),
      correctIndex: manualCorrectIndex,
      explanation: manualExplanation.trim() || `सही उत्तर विकल्प ${String.fromCharCode(65 + manualCorrectIndex)} है।`,
    };

    setDraftQuestions((prev) => [...prev, newQ]);
    setManualText('');
    setManualOptions(['', '', '', '']);
    setManualCorrectIndex(0);
    setManualExplanation('');
    setManualModalOpen(false);
  };

  const handleRemoveDraftQuestion = (index: number) => {
    setDraftQuestions((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveFullQuiz = async () => {
    if (!title.trim()) {
      alert('कृपया क्विज़ का शीर्षक (Title) दर्ज करें।');
      return;
    }
    if (draftQuestions.length === 0) {
      alert('कृपया कम से कम एक प्रश्न जोड़ें (AI से जनरेट करें या मैन्युअल जोड़ें)।');
      return;
    }

    const newQuiz: Quiz = {
      id: `quiz_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      subjectId,
      subCategoryId,
      title: title.trim(),
      description: description.trim() || `${currentSubject.name} पर आधारित अभ्यास टेस्ट`,
      questions: draftQuestions,
      createdAt: Date.now(),
    };

    try {
      await onSaveQuiz(newQuiz);
      onClose();
    } catch (err: any) {
      alert('त्रुटि: ' + err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-100">
        {/* Modal Top Bar */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-5 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg leading-tight">नया टेस्ट बनाएं (Create New Quiz)</h3>
              <p className="text-xs text-blue-100">विषय चुनें, Gemini AI द्वारा प्रश्न बनाएं और तुरंत प्रकाशित करें</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:text-white transition">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Quiz Info & AI Generator Form */}
          <div className="lg:col-span-5 space-y-5">
            {/* 1. Category & Details */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3.5">
              <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                1. टेस्ट विवरण (Quiz Details)
              </h4>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  विषय ब्लॉक (Subject Block)
                </label>
                <select
                  value={subjectId}
                  onChange={(e) => handleSubjectChange(e.target.value)}
                  className="w-full p-2.5 text-xs sm:text-sm font-medium bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {SUBJECTS_DATA.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.num}. {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  सब-ब्लॉक (Sub-Block)
                </label>
                <select
                  value={subCategoryId}
                  onChange={(e) => setSubCategoryId(e.target.value)}
                  className="w-full p-2.5 text-xs sm:text-sm font-medium bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {currentSubject.subcategories.map((sc) => (
                    <option key={sc.id} value={sc.id}>
                      {sc.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  क्विज़ शीर्षक (Title) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="उदा. राजस्थान के प्रमुख दुर्ग एवं स्थापत्य मॉक 1"
                  className="w-full p-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  विवरण (Description - वैकल्पिक)
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="परीक्षा उपयोगी महत्वपूर्ण प्रश्नों का संकलन..."
                  className="w-full p-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            {/* 2. AI Question Generator Card */}
            <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-4 rounded-2xl border border-indigo-200 space-y-3.5 shadow-xs relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                <div className="flex items-center gap-1.5 font-bold text-sm text-indigo-950">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>Gemini AI प्रश्न जनरेटर</span>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  ⚡ API Ready
                </span>
              </div>

              <p className="text-xs text-indigo-800 leading-snug">
                किसी भी टॉपिक का नाम लिखें या प्रश्न-पत्र की तस्वीर अपलोड करें। AI सटीक 4 विकल्प और पूर्ण व्याख्या तैयार कर देगा!
              </p>

              {aiError && (
                <div className="p-2.5 rounded-xl bg-red-100 border border-red-200 text-red-800 text-xs flex items-start gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{aiError}</span>
                </div>
              )}

              {aiSuccessMsg && (
                <div className="p-2.5 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-1.5">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{aiSuccessMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  टॉपिक या सामग्री लिखें (Topic / Text)
                </label>
                <textarea
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  rows={2}
                  placeholder="उदा. समय और कार्य के 5 कठिन प्रश्न, या 1857 की क्रांति के प्रश्न..."
                  className="w-full p-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              {/* Photo Upload */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  या प्रश्न-पत्र की फोटो अपलोड करें (Image of Questions)
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 cursor-pointer flex items-center justify-center gap-2 py-2 px-3 border border-dashed border-indigo-300 rounded-xl bg-white hover:bg-indigo-50/50 text-indigo-700 text-xs font-medium transition">
                    <Upload className="w-4 h-4" />
                    <span>{selectedImage ? selectedImage.file.name : 'तस्वीर चुनें (Choose Image)'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                  {selectedImage && (
                    <button
                      type="button"
                      onClick={() => setSelectedImage(null)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg text-xs"
                      title="तस्वीर हटाएं"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                {selectedImage && (
                  <div className="mt-2 relative w-full h-24 rounded-lg overflow-hidden border border-indigo-200 bg-black/5">
                    <img
                      src={selectedImage.preview}
                      alt="Question snippet"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">प्रश्नों की संख्या</label>
                  <select
                    value={aiCount}
                    onChange={(e) => setAiCount(parseInt(e.target.value, 10))}
                    className="w-full p-2 text-xs bg-white border border-slate-300 rounded-xl font-medium"
                  >
                    <option value={3}>3 प्रश्न (Quick)</option>
                    <option value={5}>5 प्रश्न (Standard)</option>
                    <option value={10}>10 प्रश्न (Full Test)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">कठिनाई स्तर</label>
                  <select
                    value={aiDifficulty}
                    onChange={(e) => setAiDifficulty(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-slate-300 rounded-xl font-medium"
                  >
                    <option value="सरल (Basic)">सरल (Basic)</option>
                    <option value="मध्यम (Moderate)">मध्यम (Moderate)</option>
                    <option value="कठिन (Advanced)">कठिन (Advanced)</option>
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleGenerateAI}
                disabled={isGenerating}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold text-xs sm:text-sm rounded-xl transition shadow-md flex items-center justify-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Gemini AI प्रश्न बना रहा है...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>⚡ AI द्वारा प्रश्न जनरेट करें</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Draft Questions List */}
          <div className="lg:col-span-7 flex flex-col bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div>
                <h4 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>प्रश्नों की सूची ({draftQuestions.length})</span>
                </h4>
                <p className="text-xs text-slate-500">
                  नीचे प्रश्नों का पूर्वावलोकन देखें, या खुद से नया प्रश्न जोड़ें।
                </p>
              </div>
              <button
                type="button"
                onClick={() => setManualModalOpen(true)}
                className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs rounded-xl shadow-2xs transition flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>मैन्युअल प्रश्न जोड़ें</span>
              </button>
            </div>

            {/* Questions Container */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[460px]">
              {draftQuestions.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-slate-200 rounded-2xl bg-white text-slate-400 space-y-2">
                  <Sparkles className="w-8 h-8 text-indigo-300" />
                  <p className="font-medium text-slate-600 text-sm">अभी कोई प्रश्न नहीं जुड़ा है।</p>
                  <p className="text-xs text-slate-400 max-w-xs">
                    बाईं ओर विषय लिखकर <strong>"AI द्वारा प्रश्न जनरेट करें"</strong> पर क्लिक करें या मैन्युअल जोड़ें।
                  </p>
                </div>
              ) : (
                draftQuestions.map((q, qIndex) => (
                  <div
                    key={qIndex}
                    className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2.5 relative group hover:border-blue-400 transition"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-md bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center shrink-0">
                          {qIndex + 1}
                        </span>
                        <h5 className="font-bold text-slate-900 text-sm leading-snug">
                          {q.text}
                        </h5>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveDraftQuestion(qIndex)}
                        className="text-slate-400 hover:text-red-600 p-1 rounded-md transition"
                        title="प्रश्न हटाएं"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Options list */}
                    <div className="grid grid-cols-2 gap-1.5 pl-7">
                      {q.options.map((opt, oIdx) => {
                        const isCorrect = oIdx === q.correctIndex;
                        return (
                          <div
                            key={oIdx}
                            className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                              isCorrect
                                ? 'bg-emerald-50 text-emerald-900 font-semibold border border-emerald-300'
                                : 'bg-slate-50 text-slate-600 border border-slate-100'
                            }`}
                          >
                            <span className="font-bold text-[11px]">{String.fromCharCode(65 + oIdx)}.</span>
                            <span className="truncate">{opt}</span>
                            {isCorrect && <Check className="w-3 h-3 text-emerald-600 shrink-0 ml-auto" />}
                          </div>
                        );
                      })}
                    </div>

                    {/* Explanation */}
                    {q.explanation && (
                      <div className="ml-7 p-2 rounded-lg bg-amber-50/80 border border-amber-200 text-[11px] text-amber-950 flex items-start gap-1.5">
                        <Lightbulb className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>व्याख्या:</strong> {q.explanation}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Modal Bottom Save Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500 font-medium">
            कुल प्रश्न: <strong className="text-slate-800">{draftQuestions.length}</strong>
          </span>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-100 transition"
            >
              रद्द करें (Cancel)
            </button>
            <button
              type="button"
              onClick={handleSaveFullQuiz}
              disabled={draftQuestions.length === 0 || !title.trim()}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition shadow-md flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>क्विज़ सेव करें (Save Quiz)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Nested Manual Question Modal */}
      {manualModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-5 space-y-4 border border-slate-100">
            <div className="flex justify-between items-center border-b pb-2">
              <h4 className="font-bold text-slate-800 text-base">मैन्युअल प्रश्न जोड़ें</h4>
              <button onClick={() => setManualModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddManualQuestion} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">प्रश्न का पाठ (Question Text)</label>
                <textarea
                  value={manualText}
                  onChange={(e) => setManualText(e.target.value)}
                  rows={2}
                  required
                  placeholder="यहाँ प्रश्न लिखें..."
                  className="w-full p-2 text-xs sm:text-sm border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">विकल्प भरें और सही विकल्प चुनें</label>
                {manualOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="manual_correct"
                      checked={manualCorrectIndex === idx}
                      onChange={() => setManualCorrectIndex(idx)}
                      className="w-4 h-4 text-blue-600"
                    />
                    <span className="w-6 font-bold text-xs text-slate-500">{String.fromCharCode(65 + idx)}:</span>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const copy = [...manualOptions];
                        copy[idx] = e.target.value;
                        setManualOptions(copy);
                      }}
                      required
                      placeholder={`Option ${String.fromCharCode(65 + idx)}`}
                      className="flex-1 p-2 text-xs sm:text-sm border border-slate-300 rounded-xl outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  विस्तृत व्याख्या (Explanation - परीक्षा हेतु)
                </label>
                <textarea
                  value={manualExplanation}
                  onChange={(e) => setManualExplanation(e.target.value)}
                  rows={2}
                  placeholder="सही उत्तर क्यों है? इसकी व्याख्या लिखें..."
                  className="w-full p-2 text-xs sm:text-sm border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setManualModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded-xl text-xs font-medium text-slate-600"
                >
                  रद्द करें
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold"
                >
                  प्रश्न जोड़ें
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
