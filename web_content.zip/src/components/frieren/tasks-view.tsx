import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { TaskPriority, TaskStatus } from "@/lib/frieren/types";
import { useFrieren } from "@/lib/frieren/store";
import { formatRelative } from "@/lib/utils";

const PRIORITIES: TaskPriority[] = ["urgent", "high", "normal", "low"];

function toneFor(status: TaskStatus) {
  if (status === "completed") return "ok" as const;
  if (status === "failed") return "danger" as const;
  if (status === "running") return "accent" as const;
  if (status === "blocked") return "warn" as const;
  return "muted" as const;
}

export function TasksView() {
  const tasks = useFrieren((s) => s.tasks);
  const createTask = useFrieren((s) => s.createTask);
  const setTaskStatus = useFrieren((s) => s.setTaskStatus);
  const runReadyTasks = useFrieren((s) => s.runReadyTasks);
  const addMessage = useFrieren((s) => s.addMessage);
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState<TaskPriority>("normal");
  const [confirmRun, setConfirmRun] = useState(false);

  const ready = tasks.filter((t) => t.status === "pending");

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="space-y-3 border-b border-border px-4 py-4">
        <form
          className="flex flex-col gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!title.trim()) return;
            createTask(title, { priority });
            setTitle("");
          }}
        >
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Create a task…" />
          <div className="flex flex-wrap gap-1.5">
            {PRIORITIES.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPriority(p)}
                className={
                  priority === p
                    ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg"
                    : "rounded-full bg-elevated px-3 py-1 text-xs text-muted"
                }
              >
                {p}
              </button>
            ))}
            <Button type="submit" size="sm" className="ml-auto">
              Create
            </Button>
          </div>
        </form>
        {ready.length > 0 && !confirmRun && (
          <Button
            variant="secondary"
            className="w-full"
            onClick={() => setConfirmRun(true)}
          >
            Run {ready.length} ready task{ready.length === 1 ? "" : "s"}
          </Button>
        )}
        {confirmRun && (
          <div className="rounded-2xl border border-warn/30 bg-elevated p-3">
            <p className="text-sm">Confirmation required before executing ready tasks.</p>
            <div className="mt-2 flex gap-2">
              <Button
                size="sm"
                onClick={() => {
                  const done = runReadyTasks();
                  setConfirmRun(false);
                  addMessage({
                    role: "frieren",
                    text: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`,
                    status: "completed",
                  });
                }}
              >
                Confirm run
              </Button>
              <Button size="sm" variant="secondary" onClick={() => setConfirmRun(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
      <ul className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-3">
        {tasks.length === 0 && (
          <li className="rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted">
            No tasks yet. Ready tasks never run without confirmation.
          </li>
        )}
        {tasks.map((t) => (
          <li key={t.id} className="rounded-2xl bg-surface px-4 py-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-medium">{t.title}</p>
                <p className="text-[11px] tabular-nums text-subtle">{formatRelative(t.updatedAt)}</p>
              </div>
              <Badge tone={toneFor(t.status)}>{t.status}</Badge>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              <Badge>{t.priority}</Badge>
              {t.status === "pending" && (
                <Button size="sm" variant="ghost" onClick={() => setTaskStatus(t.id, "cancelled")}>
                  Cancel
                </Button>
              )}
              {t.status === "failed" && (
                <Button size="sm" variant="ghost" onClick={() => setTaskStatus(t.id, "pending")}>
                  Retry
                </Button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
