import { Download, Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import type { AndroidCapability } from "@/lib/frieren/types";
import { systemStatus, useFrieren } from "@/lib/frieren/store";
import { formatRelative } from "@/lib/utils";

const CAPS: { id: AndroidCapability; label: string; risk: "low" | "high" }[] = [
  { id: "notification", label: "Notifications", risk: "low" },
  { id: "clipboard", label: "Clipboard", risk: "low" },
  { id: "tts", label: "Speech", risk: "low" },
  { id: "battery", label: "Battery", risk: "low" },
  { id: "open_url", label: "Open URL", risk: "high" },
  { id: "call", label: "Calls", risk: "high" },
  { id: "message", label: "Messages", risk: "high" },
  { id: "volume", label: "Volume", risk: "high" },
];

export function SystemView() {
  const granted = useFrieren((s) => s.granted);
  const grant = useFrieren((s) => s.grant);
  const revoke = useFrieren((s) => s.revoke);
  const dryRun = useFrieren((s) => s.dryRun);
  const setDryRun = useFrieren((s) => s.setDryRun);
  const agents = useFrieren((s) => s.agents);
  const audit = useFrieren((s) => s.audit);
  const addRecovery = useFrieren((s) => s.addRecovery);
  const resetDemo = useFrieren((s) => s.resetDemo);
  const stats = systemStatus();

  async function probeBattery() {
    try {
      const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number }> };
      if (!nav.getBattery) {
        useFrieren.getState().addMessage({
          role: "system",
          text: "Battery API is not available here. The Android package can read it via the allowlisted tool.",
        });
        return;
      }
      const b = await nav.getBattery();
      useFrieren.getState().addMessage({
        role: "frieren",
        text: `Battery ${(b.level * 100).toFixed(0)}%.`,
        status: "completed",
      });
    } catch {
      useFrieren.getState().addMessage({
        role: "system",
        text: "Battery probe failed.",
      });
    }
  }

  return (
    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4">
      <section className="rounded-2xl bg-surface p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-lg">Install Android package</h2>
            <p className="mt-1 text-sm text-muted">
              Signed debug APK of the FRIEREN command center. Sideload it, then enable unknown sources if asked.
            </p>
          </div>
          <Radio className="size-5 text-accent" />
        </div>
        <a
          href="/frieren.apk"
          download="FRIEREN.apk"
          className="mt-4 inline-flex h-11 items-center justify-center gap-2 rounded-[12px] bg-accent px-4 text-sm font-medium text-accent-fg transition-transform duration-150 active:scale-[0.98]"
        >
          <Download className="size-4" />
          Download APK
        </a>
      </section>

      <section className="rounded-2xl bg-surface p-4">
        <h2 className="font-display text-lg">Kernel</h2>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="text-subtle">Memory</dt>
            <dd className="tabular-nums font-medium">{stats.memory}</dd>
          </div>
          <div>
            <dt className="text-subtle">Graph</dt>
            <dd className="tabular-nums font-medium">
              {stats.knowledge.nodes}/{stats.knowledge.edges}
            </dd>
          </div>
          <div>
            <dt className="text-subtle">Agents</dt>
            <dd className="tabular-nums font-medium">{stats.agents}</dd>
          </div>
          <div>
            <dt className="text-subtle">Audit</dt>
            <dd className="tabular-nums font-medium">{stats.auditEvents}</dd>
          </div>
        </dl>
        <div className="mt-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium">Dry-run tools</p>
            <p className="text-xs text-muted">Device actions are simulated until you turn this off.</p>
          </div>
          <Switch checked={dryRun} onCheckedChange={setDryRun} label="Dry-run" />
        </div>
      </section>

      <section className="rounded-2xl bg-surface p-4">
        <h2 className="font-display text-lg">Tools / permissions</h2>
        <ul className="mt-3 space-y-2">
          {CAPS.map((c) => {
            const on = granted.includes(c.id);
            return (
              <li key={c.id} className="flex items-center justify-between gap-3 rounded-xl bg-elevated px-3 py-2.5">
                <div>
                  <p className="text-sm">{c.label}</p>
                  <Badge tone={c.risk === "high" ? "warn" : "muted"}>{c.risk} risk</Badge>
                </div>
                <Switch
                  checked={on}
                  onCheckedChange={(v) => (v ? grant(c.id) : revoke(c.id))}
                  label={c.label}
                />
              </li>
            );
          })}
        </ul>
        <Button className="mt-3 w-full" variant="secondary" onClick={() => void probeBattery()}>
          Probe battery
        </Button>
      </section>

      <section className="rounded-2xl bg-surface p-4">
        <h2 className="font-display text-lg">Agents</h2>
        <ul className="mt-3 space-y-2">
          {agents.map((a) => (
            <li key={a.name} className="flex items-center justify-between rounded-xl bg-elevated px-3 py-2">
              <span className="text-sm">{a.name}</span>
              <Badge tone={a.status === "idle" ? "muted" : "accent"}>{a.status}</Badge>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-2xl bg-surface p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg">Audit</h2>
          <Button
            size="sm"
            variant="ghost"
            onClick={() =>
              addRecovery({ step: 2, reason: "Simulated interrupted execution for recovery practice." })
            }
          >
            Simulate recovery
          </Button>
        </div>
        <ul className="mt-3 space-y-2">
          {audit.length === 0 && <li className="text-sm text-muted">No commands recorded yet.</li>}
          {[...audit].reverse().slice(0, 12).map((e) => (
            <li key={e.id} className="flex items-start justify-between gap-3 text-sm">
              <span>{e.message}</span>
              <span className="shrink-0 text-[11px] tabular-nums text-subtle">{formatRelative(e.at)}</span>
            </li>
          ))}
        </ul>
        <Button className="mt-4 w-full" variant="secondary" onClick={resetDemo}>
          Reset local kernel
        </Button>
      </section>
    </div>
  );
}
