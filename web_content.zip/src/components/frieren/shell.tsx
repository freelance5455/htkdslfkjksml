import { useEffect, useState } from "react";
import { Bot, Command, Network, ScrollText, Settings2 } from "lucide-react";
import { CommandView } from "./command-view";
import { GraphView } from "./graph-view";
import { MemoryView } from "./memory-view";
import { SystemView } from "./system-view";
import { TasksView } from "./tasks-view";
import { cn } from "@/lib/utils";
import { useFrieren } from "@/lib/frieren/store";

const TABS = [
  { id: "command", label: "Command", icon: Command },
  { id: "memory", label: "Memory", icon: ScrollText },
  { id: "tasks", label: "Tasks", icon: Bot },
  { id: "graph", label: "Graph", icon: Network },
  { id: "system", label: "System", icon: Settings2 },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function FrierenShell() {
  const [tab, setTab] = useState<TabId>("command");
  const dryRun = useFrieren((s) => s.dryRun);
  const recovery = useFrieren((s) => s.recovery);

  useEffect(() => {
    void useFrieren.persist.rehydrate();
  }, []);

  return (
    <div className="flex min-h-dvh justify-center bg-bg text-fg">
      <div className="flex w-full max-w-5xl flex-col md:my-6 md:min-h-[min(860px,calc(100dvh-3rem))] md:flex-row md:overflow-hidden md:rounded-[28px] md:border md:border-border md:shadow-[var(--shadow-panel)]">
        <aside className="hidden w-56 shrink-0 flex-col border-r border-border bg-surface md:flex">
          <div className="px-5 pt-6 pb-4">
            <p className="text-[11px] tracking-[0.22em] text-subtle uppercase">Local kernel</p>
            <h1 className="font-display text-[28px] leading-none tracking-tight">FRIEREN</h1>
            <p className="mt-2 flex items-center gap-1.5 text-[11px] text-subtle">
              <span
                className={cn("inline-block size-1.5 rounded-full", recovery.length ? "bg-warn" : "bg-ok")}
              />
              Phase 80 · {dryRun ? "dry-run" : "live tools"}
            </p>
          </div>
          <nav className="flex flex-1 flex-col gap-1 px-3 pb-4">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex min-h-11 items-center gap-3 rounded-[14px] px-3 text-sm",
                    active ? "bg-elevated text-accent" : "text-muted hover:bg-elevated/60 hover:text-fg",
                  )}
                >
                  <Icon className="size-4" strokeWidth={active ? 2.2 : 1.7} />
                  {t.label}
                </button>
              );
            })}
          </nav>
        </aside>

        <div className="flex min-h-0 min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between gap-3 border-b border-border px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-3 md:hidden">
            <div>
              <p className="text-[11px] tracking-[0.22em] text-subtle uppercase">Local kernel</p>
              <h1 className="font-display text-[28px] leading-none tracking-tight">FRIEREN</h1>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted">Phase 80</p>
              <p className="flex items-center justify-end gap-1.5 text-[11px] text-subtle">
                <span
                  className={cn(
                    "inline-block size-1.5 rounded-full",
                    recovery.length ? "bg-warn" : "bg-ok",
                  )}
                />
                {dryRun ? "dry-run" : "live tools"}
              </p>
            </div>
          </header>

          <main className="flex min-h-0 flex-1 flex-col">
            {tab === "command" && <CommandView />}
            {tab === "memory" && <MemoryView />}
            {tab === "tasks" && <TasksView />}
            {tab === "graph" && <GraphView />}
            {tab === "system" && <SystemView />}
          </main>

          <nav className="grid grid-cols-5 border-t border-border pb-[max(0.5rem,env(safe-area-inset-bottom))] md:hidden">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]",
                    active ? "text-accent" : "text-subtle",
                  )}
                >
                  <Icon className="size-4" strokeWidth={active ? 2.2 : 1.7} />
                  {t.label}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
