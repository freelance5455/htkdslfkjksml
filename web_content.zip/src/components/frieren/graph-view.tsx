import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import type { NodeKind } from "@/lib/frieren/types";
import { useFrieren } from "@/lib/frieren/store";

const KINDS: NodeKind[] = ["concept", "person", "place", "project", "event", "note"];

export function GraphView() {
  const nodes = useFrieren((s) => s.nodes);
  const edges = useFrieren((s) => s.edges);
  const upsertNode = useFrieren((s) => s.upsertNode);
  const addEdge = useFrieren((s) => s.addEdge);
  const deleteNode = useFrieren((s) => s.deleteNode);
  const [label, setLabel] = useState("");
  const [kind, setKind] = useState<NodeKind>("concept");
  const [from, setFrom] = useState(nodes[0]?.id ?? "");
  const [to, setTo] = useState(nodes[1]?.id ?? "");

  const layout = useMemo(() => {
    const n = nodes.length || 1;
    return nodes.map((node, i) => {
      const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
      const r = 38;
      return {
        ...node,
        x: 50 + Math.cos(angle) * r,
        y: 50 + Math.sin(angle) * r,
      };
    });
  }, [nodes]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="relative mx-4 mt-4 h-56 overflow-hidden rounded-2xl bg-surface">
        <svg viewBox="0 0 100 100" className="size-full">
          {edges.map((e) => {
            const a = layout.find((n) => n.id === e.sourceId);
            const b = layout.find((n) => n.id === e.targetId);
            if (!a || !b) return null;
            return (
              <line
                key={e.id}
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                stroke="currentColor"
                className="text-border-strong"
                strokeWidth="0.6"
              />
            );
          })}
          {layout.map((n) => (
            <g key={n.id}>
              <circle cx={n.x} cy={n.y} r="5.2" className="fill-accent/25 stroke-accent" strokeWidth="0.6" />
              <text
                x={n.x}
                y={n.y + 9}
                textAnchor="middle"
                className="fill-muted"
                fontSize="3.4"
              >
                {n.label.slice(0, 16)}
              </text>
            </g>
          ))}
        </svg>
      </div>
      <form
        className="space-y-2 px-4 py-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (!label.trim()) return;
          upsertNode(label, kind);
          setLabel("");
        }}
      >
        <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Add a node…" />
        <div className="flex flex-wrap gap-1.5">
          {KINDS.map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setKind(k)}
              className={
                kind === k
                  ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg"
                  : "rounded-full bg-elevated px-3 py-1 text-xs text-muted"
              }
            >
              {k}
            </button>
          ))}
          <Button type="submit" size="sm" className="ml-auto">
            Add
          </Button>
        </div>
      </form>
      {nodes.length >= 2 && (
        <div className="flex items-center gap-2 px-4 pb-3">
          <select
            className="h-11 flex-1 rounded-[12px] border border-border bg-elevated px-2 text-sm"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          >
            {nodes.map((n) => (
              <option key={n.id} value={n.id}>
                {n.label}
              </option>
            ))}
          </select>
          <span className="text-xs text-subtle">to</span>
          <select
            className="h-11 flex-1 rounded-[12px] border border-border bg-elevated px-2 text-sm"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          >
            {nodes.map((n) => (
              <option key={n.id} value={n.id}>
                {n.label}
              </option>
            ))}
          </select>
          <Button size="sm" variant="secondary" onClick={() => addEdge(from, to, "related_to")}>
            Link
          </Button>
        </div>
      )}
      <ul className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 pb-4">
        {nodes.map((n) => (
          <li key={n.id} className="flex items-start justify-between gap-3 rounded-2xl bg-surface px-4 py-3">
            <div>
              <p className="text-sm font-medium">{n.label}</p>
              {n.description && <p className="text-xs text-muted">{n.description}</p>}
              <Badge className="mt-2">{n.kind}</Badge>
            </div>
            <Button size="sm" variant="ghost" onClick={() => deleteNode(n.id)}>
              Remove
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
