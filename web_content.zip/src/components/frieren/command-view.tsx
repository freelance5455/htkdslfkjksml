import { useEffect, useRef, useState } from "react";
import { Mic, Send, ShieldAlert, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { askFrieren } from "@/lib/frieren/ask";
import { formatPlan, routeCommand } from "@/lib/frieren/commands";
import { systemStatus, useFrieren } from "@/lib/frieren/store";
import { cn, formatRelative } from "@/lib/utils";

function useVoice(onHeard: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const recRef = useRef<SpeechRecognition | null>(null);

  function toggle() {
    const SR =
      typeof window !== "undefined" &&
      (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR) {
      onHeard("");
      return;
    }
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.onresult = (e: SpeechRecognitionEvent) => {
      const said = e.results[0]?.[0]?.transcript ?? "";
      onHeard(said);
    };
    rec.onend = () => setListening(false);
    rec.start();
    recRef.current = rec;
    setListening(true);
  }

  return { listening, toggle };
}

declare global {
  interface Window {
    SpeechRecognition?: typeof SpeechRecognition;
    webkitSpeechRecognition?: typeof SpeechRecognition;
  }
}

export function CommandView() {
  const messages = useFrieren((s) => s.messages);
  const addMessage = useFrieren((s) => s.addMessage);
  const patchMessage = useFrieren((s) => s.patchMessage);
  const logAudit = useFrieren((s) => s.logAudit);
  const runReady = useFrieren((s) => s.runReadyTasks);
  const wakeWord = useFrieren((s) => s.wakeWord);
  const setVoiceArmed = useFrieren((s) => s.setVoiceArmed);
  const addTimeline = useFrieren((s) => s.addTimeline);
  const timeline = useFrieren((s) => s.timeline);
  const recovery = useFrieren((s) => s.recovery);
  const approvals = useFrieren((s) => s.approvals);
  const removeRecovery = useFrieren((s) => s.removeRecovery);
  const removeApproval = useFrieren((s) => s.removeApproval);
  const addApproval = useFrieren((s) => s.addApproval);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  async function submit(text: string, confirmed = false) {
    const value = text.trim();
    if (!value || busy) return;
    setDraft("");
    addMessage({ role: "user", text: value });
    const routed = routeCommand(value, confirmed);
    if (routed) {
      const msg = addMessage({
        role: routed.status === "needs_confirmation" ? "approval" : "frieren",
        text: routed.message,
        status: routed.status,
        data: routed.data,
        pendingConfirm: routed.pendingConfirm,
      });
      logAudit(routed.message, routed.status);
      if (routed.pendingConfirm?.kind === "android") {
        addApproval({ tool: routed.pendingConfirm.payload, reason: routed.message });
      }
      void msg;
      return;
    }

    setBusy(true);
    const thinking = addMessage({ role: "frieren", text: "Thinking…", status: "accepted" });
    const ctx = JSON.stringify(systemStatus());
    try {
      const res = await askFrieren({ data: { prompt: value, context: ctx } });
      if (res.ok) {
        patchMessage(thinking.id, { text: res.text, status: "completed" });
        logAudit("brain reply", "completed");
      } else {
        patchMessage(thinking.id, {
          text: `${formatPlan(value)}\n\n${res.error}`,
          status: "accepted",
        });
        logAudit("brain unavailable — plan accepted", "accepted");
      }
    } catch {
      patchMessage(thinking.id, { text: formatPlan(value), status: "accepted" });
    } finally {
      setBusy(false);
    }
  }

  const voice = useVoice((said) => {
    if (!said) {
      addMessage({
        role: "system",
        text: "Voice is unavailable in this browser. Type instead, or install the Android package.",
      });
      return;
    }
    const low = said.toLowerCase();
    if (low.includes(wakeWord)) {
      setVoiceArmed(true);
      const stripped = said.replace(new RegExp(wakeWord, "ig"), "").replace(/^[,.\s]+/, "");
      void submit(stripped || said);
    } else {
      addMessage({
        role: "system",
        text: `Heard “${said}”. Prefix with the wake word “${wakeWord}” to send.`,
      });
    }
  });

  function confirm(kind: "run_tasks" | "android", payload: string, id: string) {
    if (kind === "run_tasks") {
      const done = runReady();
      patchMessage(id, {
        status: "completed",
        pendingConfirm: undefined,
        text: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`,
        role: "frieren",
      });
      logAudit("ready tasks executed", "completed");
    } else {
      patchMessage(id, {
        status: "completed",
        pendingConfirm: undefined,
        text: `Approved: ${payload}. Dry-run still applies unless you disable it in System.`,
        role: "frieren",
      });
      addTimeline({ label: "Android", status: "approved", detail: payload });
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      {(recovery.length > 0 || approvals.length > 0) && (
        <div className="space-y-2 border-b border-border px-4 py-3">
          {recovery.map((r) => (
            <div key={r.id} className="rounded-xl bg-elevated px-3 py-2.5">
              <p className="text-sm font-medium">Interrupted run</p>
              <p className="text-xs text-muted">
                Step {r.step} · {r.reason}
              </p>
              <div className="mt-2 flex gap-2">
                <Button size="sm" onClick={() => { addTimeline({ label: "Recovery", status: "resumed", detail: r.id }); removeRecovery(r.id); }}>
                  Resume
                </Button>
                <Button size="sm" variant="secondary" onClick={() => removeRecovery(r.id)}>
                  Discard
                </Button>
              </div>
            </div>
          ))}
          {approvals.map((a) => (
            <div key={a.id} className="rounded-xl border border-warn/30 bg-elevated px-3 py-2.5">
              <p className="flex items-center gap-2 text-sm font-medium">
                <ShieldAlert className="size-4 text-warn" />
                Pending approval
              </p>
              <p className="text-xs text-muted">{a.reason}</p>
              <div className="mt-2 flex gap-2">
                <Button size="sm" onClick={() => removeApproval(a.id)}>Approve</Button>
                <Button size="sm" variant="secondary" onClick={() => removeApproval(a.id)}>Deny</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div ref={scroller} className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {messages.map((m) => (
          <article
            key={m.id}
            className={cn(
              "max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
              m.role === "user"
                ? "ml-auto bg-accent text-accent-fg"
                : m.role === "approval"
                  ? "border border-warn/35 bg-elevated"
                  : m.role === "system"
                    ? "bg-surface text-muted"
                    : "bg-surface",
            )}
          >
            <header className="mb-1 flex items-center justify-between gap-3">
              <span className="font-display text-[13px] tracking-wide text-current/80">
                {m.role === "user" ? "You" : m.role === "approval" ? "Approval" : m.role === "system" ? "System" : "FRIEREN"}
              </span>
              <span className={cn("text-[11px] tabular-nums", m.role === "user" ? "text-accent-fg/70" : "text-subtle")}>
                {formatRelative(m.createdAt)}
              </span>
            </header>
            <p className="whitespace-pre-wrap">{m.text}</p>
            {m.pendingConfirm && (
              <div className="mt-3 flex gap-2">
                <Button
                  size="sm"
                  variant={m.role === "user" ? "secondary" : "default"}
                  onClick={() => confirm(m.pendingConfirm!.kind, m.pendingConfirm!.payload, m.id)}
                >
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() =>
                    patchMessage(m.id, {
                      pendingConfirm: undefined,
                      status: "failed",
                      text: "Denied. Nothing was executed.",
                    })
                  }
                >
                  Deny
                </Button>
              </div>
            )}
          </article>
        ))}
        {timeline.slice(-4).map((t) => (
          <p key={t.id} className="px-1 text-xs text-subtle">
            {t.label} · {t.status} — {t.detail}
          </p>
        ))}
      </div>

      <form
        className="border-t border-border bg-bg/80 p-3 backdrop-blur-sm"
        onSubmit={(e) => {
          e.preventDefault();
          void submit(draft);
        }}
      >
        <div className="flex items-end gap-2">
          <label className="sr-only" htmlFor="frieren-input">
            Ask FRIEREN
          </label>
          <textarea
            id="frieren-input"
            rows={1}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void submit(draft);
              }
            }}
            placeholder="Ask FRIEREN…"
            className="max-h-32 min-h-11 flex-1 resize-none rounded-[14px] border border-border bg-elevated px-3.5 py-2.5 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
          />
          <Button
            type="button"
            size="icon"
            variant={voice.listening ? "danger" : "secondary"}
            aria-label={voice.listening ? "Stop listening" : "Voice"}
            onClick={() => voice.toggle()}
          >
            {voice.listening ? <Square className="size-4" /> : <Mic className="size-4" />}
          </Button>
          <Button type="submit" size="icon" disabled={busy || !draft.trim()} aria-label="Send">
            <Send className="size-4" />
          </Button>
        </div>
        <p className="mt-2 flex items-center gap-2 px-1 text-[11px] text-subtle">
          <Badge tone="accent">Phase 80</Badge>
          Local kernel · confirmation-gated · wake word {wakeWord}
        </p>
      </form>
    </div>
  );
}
