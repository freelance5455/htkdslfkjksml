import { useState } from "react";
import { Search, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { MemoryKind } from "@/lib/frieren/types";
import { useFrieren } from "@/lib/frieren/store";
import { formatRelative } from "@/lib/utils";

const KINDS: MemoryKind[] = ["note", "fact", "preference", "event", "skill", "task"];

export function MemoryView() {
  const memories = useFrieren((s) => s.memories);
  const remember = useFrieren((s) => s.remember);
  const forget = useFrieren((s) => s.forget);
  const [q, setQ] = useState("");
  const [draft, setDraft] = useState("");
  const [kind, setKind] = useState<MemoryKind>("note");

  const shown = q
    ? memories.filter(
        (m) =>
          m.content.toLowerCase().includes(q.toLowerCase()) ||
          m.tags.some((t) => t.includes(q.toLowerCase())),
      )
    : memories;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="space-y-3 border-b border-border px-4 py-4">
        <form
          className="flex flex-col gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!draft.trim()) return;
            remember(draft, kind);
            setDraft("");
          }}
        >
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Remember something explicitly…"
          />
          <div className="flex flex-wrap gap-1.5">
            {KINDS.map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setKind(k)}
                className={
                  kind === k
                    ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg"
                    : "rounded-full bg-elevated px-3 py-1 text-xs text-muted"
                }
              >
                {k}
              </button>
            ))}
            <Button type="submit" size="sm" className="ml-auto">
              Remember
            </Button>
          </div>
        </form>
        <div className="relative">
          <Search className="pointer-events-none absolute top-3 left-3 size-4 text-subtle" />
          <Input
            className="pl-9"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Recall…"
          />
        </div>
      </div>
      <ul className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-3">
        {shown.length === 0 && (
          <li className="rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted">
            Memory is explicit. Nothing is stored from ordinary chat.
          </li>
        )}
        {shown.map((m) => (
          <li key={m.id} className="rounded-2xl bg-surface px-4 py-3">
            <div className="flex items-start justify-between gap-3">
              <p className="text-sm leading-relaxed">{m.content}</p>
              <button
                type="button"
                aria-label="Forget"
                className="mt-0.5 text-subtle hover:text-danger"
                onClick={() => forget(m.id)}
              >
                <Trash2 className="size-4" />
              </button>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <Badge>{m.kind}</Badge>
              <span className="text-[11px] tabular-nums text-subtle">{formatRelative(m.createdAt)}</span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
