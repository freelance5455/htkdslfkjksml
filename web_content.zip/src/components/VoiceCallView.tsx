import React, { useRef, useState } from 'react';
import {
  AlertCircle,
  Camera,
  Globe,
  Layers,
  MessageSquare,
  Mic,
  MicOff,
  Monitor,
  Paperclip,
  Pause,
  Phone,
  PhoneOff,
  Play,
  RefreshCw,
  Send,
  ShieldCheck,
  Volume2,
  X,
} from 'lucide-react';
import type {
  ChatMessage,
  ScreenShareSource,
  ScreenShareStatus,
} from '../types';

const CALL_LANGUAGES = [
  'English',
  'Urdu',
  'Roman Urdu',
  'Hindi',
  'Punjabi',
  'Pashto',
  'Arabic',
  'Turkish',
  'Spanish',
  'French',
  'German',
  'Japanese',
  'Chinese',
  'Korean',
  'Bengali',
];

interface VoiceCallViewProps {
  callActive: boolean;
  callConnecting: boolean;
  reconnectAttempt?: number;
  muted: boolean;
  micLevel?: number;
  durationSeconds: number;
  assistantSpeaking: boolean;
  callLanguage: string;
  visualMode: 'none' | 'screen' | 'camera';
  screenShareSource: ScreenShareSource;
  screenShareStatus: ScreenShareStatus;
  screenShareError: string | null;
  visionFrameCount: number;
  lastVisionTimestamp?: number | null;
  nativeAndroidAvailable: boolean;
  nativeCameraXAvailable?: boolean;
  nativeOverlayGranted: boolean;
  screenImagePreviewUrl: string | null;
  screenPreviewRef: React.RefObject<HTMLVideoElement | null>;
  callTranscript: ChatMessage[];
  onStartCall: () => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onChangeCallLanguage: (lang: string) => void;
  onToggleScreenShare: () => void;
  onTogglePauseScreenShare: () => void;
  onRequestOverlayIndicator: () => void;
  onDismissScreenShareError: () => void;
  onToggleCamera: () => void;
  onSwitchCameraLens?: () => void;
  onAttachCallMedia: (file: File) => void;
  onSendCallText: (text: string) => void;
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60)
    .toString()
    .padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export const VoiceCallView: React.FC<VoiceCallViewProps> = ({
  callActive,
  callConnecting,
  reconnectAttempt = 0,
  muted,
  micLevel = 0,
  durationSeconds,
  assistantSpeaking,
  callLanguage,
  visualMode,
  screenShareSource,
  screenShareStatus,
  screenShareError,
  visionFrameCount,
  lastVisionTimestamp,
  nativeAndroidAvailable,
  nativeCameraXAvailable = false,
  nativeOverlayGranted,
  screenImagePreviewUrl,
  screenPreviewRef,
  callTranscript,
  onStartCall,
  onEndCall,
  onToggleMute,
  onChangeCallLanguage,
  onToggleScreenShare,
  onTogglePauseScreenShare,
  onRequestOverlayIndicator,
  onDismissScreenShareError,
  onToggleCamera,
  onSwitchCameraLens,
  onAttachCallMedia,
  onSendCallText,
}) => {
  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const mediaInputRef = useRef<HTMLInputElement | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!draft.trim()) return;
    onSendCallText(draft.trim());
    setDraft('');
  };

  if (!callActive && !callConnecting) {
    return (
      <div className="flex flex-col items-center justify-center text-center min-h-[520px] py-10 px-4 gap-6">
        <div className="w-16 h-16 rounded-2xl border border-zinc-800 bg-zinc-950 flex items-center justify-center text-cyan-400">
          <Phone className="w-7 h-7" />
        </div>

        <div className="space-y-2 max-w-md">
          <h2 className="text-xl font-semibold text-white">Voice Call &amp; Live Vision</h2>
          <p className="text-sm text-zinc-400 leading-relaxed">
            Starts in English and switches to Urdu, Hindi, Arabic, or any language on request. Share
            your full Android screen or use live Cam vision during the call.
          </p>
        </div>

        <button
          type="button"
          onClick={onStartCall}
          className="inline-flex items-center justify-center gap-2 min-h-[46px] px-7 py-3 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-purple-600 hover:brightness-110 text-white text-sm font-medium transition-all cursor-pointer whitespace-nowrap"
        >
          <Phone className="w-4 h-4" />
          <span>Start Call</span>
        </button>

        <div className="flex items-center justify-center gap-1.5 text-xs text-zinc-500 max-w-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>
            {nativeAndroidAvailable
              ? 'Native Android MediaProjection & CameraX bridges active'
              : 'Camera ready · Compile /android APK for system-wide Android screen sharing'}
          </span>
        </div>
      </div>
    );
  }

  const isVisualActive = visualMode !== 'none';
  const isScreenSharing = visualMode === 'screen';
  const isCameraActive = visualMode === 'camera';
  const isPaused = screenShareStatus === 'paused';

  const connectionLabel = callConnecting
    ? reconnectAttempt > 0
      ? `Reconnecting (${reconnectAttempt}/3)`
      : 'Connecting'
    : callActive
    ? 'Connected'
    : 'Disconnected';

  const sharingLabel = isCameraActive
    ? screenShareSource === 'android_camerax'
      ? 'CameraX Live'
      : 'Cam Active'
    : isScreenSharing
    ? isPaused
      ? 'Sharing Paused'
      : 'Sharing Live'
    : screenShareStatus === 'requesting'
    ? 'Requesting Permission'
    : 'Screen Idle';

  const visionLabel =
    isScreenSharing && isPaused
      ? 'AI Vision Paused'
      : isVisualActive && visionFrameCount > 0
      ? `AI Vision Active (${visionFrameCount})`
      : isVisualActive
      ? 'AI Vision Active'
      : 'AI Vision Standby';

  const languageOptions = CALL_LANGUAGES.includes(callLanguage)
    ? CALL_LANGUAGES
    : [callLanguage, ...CALL_LANGUAGES];

  return (
    <div className="flex flex-col items-center justify-between min-h-[520px] py-4 px-2 gap-4">
      {/* Clean Audio Status Header (No Orb) */}
      <div className="flex flex-col items-center gap-2.5 text-center w-full max-w-md">
        <div
          className={`w-14 h-14 rounded-2xl border flex items-center justify-center transition-colors ${
            callConnecting
              ? 'border-amber-600/50 bg-amber-950/30 text-amber-300'
              : assistantSpeaking
              ? 'border-cyan-500/70 bg-cyan-950/40 text-cyan-300'
              : muted
              ? 'border-zinc-800 bg-zinc-950 text-zinc-500'
              : 'border-emerald-600/50 bg-emerald-950/30 text-emerald-300'
          }`}
        >
          {assistantSpeaking ? (
            <Volume2 className="w-6 h-6" />
          ) : muted ? (
            <MicOff className="w-6 h-6" />
          ) : (
            <Mic className="w-6 h-6" />
          )}
        </div>

        <div className="space-y-1.5">
          <p className="text-sm font-medium text-zinc-200">
            {callConnecting
              ? reconnectAttempt > 0
                ? `Reconnecting (${reconnectAttempt}/3)...`
                : 'Connecting...'
              : assistantSpeaking
              ? 'Speaking...'
              : muted
              ? 'Muted'
              : 'Listening...'}
          </p>

          <div className="flex items-center justify-center gap-2.5 flex-wrap">
            <span className="text-xs text-zinc-400 font-mono tabular-nums">
              {formatDuration(durationSeconds)}
            </span>
            <span className="text-zinc-700" aria-hidden="true">
              |
            </span>
            <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-zinc-800 bg-zinc-950 text-xs text-zinc-200 min-h-[32px]">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <select
                value={callLanguage}
                onChange={(e) => onChangeCallLanguage(e.target.value)}
                aria-label="Call language"
                className="bg-transparent text-zinc-100 focus:outline-none cursor-pointer"
              >
                {languageOptions.map((lang) => (
                  <option key={lang} value={lang} className="bg-zinc-950 text-zinc-100">
                    {lang}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="flex items-center justify-center flex-wrap gap-x-2 gap-y-1 text-xs pt-0.5 tabular-nums">
            <span className={callActive ? 'text-emerald-400' : 'text-amber-400'}>
              {connectionLabel}
            </span>
            <span className="text-zinc-700" aria-hidden="true">
              |
            </span>
            <span
              className={
                (isScreenSharing || isCameraActive) && !isPaused
                  ? 'text-cyan-400 font-medium'
                  : isPaused
                  ? 'text-amber-400 font-medium'
                  : 'text-zinc-400'
              }
            >
              {sharingLabel}
            </span>
            <span className="text-zinc-700" aria-hidden="true">
              |
            </span>
            <span
              className={
                isVisualActive && !isPaused ? 'text-emerald-400 font-medium' : 'text-zinc-400'
              }
            >
              {visionLabel}
            </span>
          </div>
          {isVisualActive && lastVisionTimestamp && (
            <p className="text-[11px] text-zinc-500 tabular-nums">
              Latest frame synced {new Date(lastVisionTimestamp).toLocaleTimeString()}
            </p>
          )}
        </div>

        {!callConnecting && (
          <div className="w-36 h-1.5 rounded-full bg-zinc-900 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-purple-500 transition-all duration-75"
              style={{ width: `${muted ? 0 : Math.max(6, Math.round(micLevel * 100))}%` }}
            />
          </div>
        )}
      </div>

      {/* Inline Diagnostic Error */}
      {screenShareError && (
        <div className="w-full max-w-md rounded-xl border border-red-900/70 bg-red-950/30 p-3 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5 min-w-0">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-medium text-red-200 leading-relaxed">{screenShareError}</p>
              {nativeAndroidAvailable && (
                <button
                  type="button"
                  onClick={() => {
                    onDismissScreenShareError();
                    onToggleScreenShare();
                  }}
                  className="text-xs font-medium text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                >
                  Retry Screen Sharing
                </button>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onDismissScreenShareError}
            className="p-1 text-zinc-400 hover:text-white cursor-pointer shrink-0"
            aria-label="Dismiss error"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Live Preview (Android MediaProjection Frame, Android CameraX Frame, or Browser Cam Video) */}
      {isVisualActive && (
        <div className="w-full max-w-sm rounded-xl border border-zinc-800 bg-zinc-950 overflow-hidden">
          {(screenShareSource === 'android_mediaprojection' ||
            screenShareSource === 'android_camerax') &&
          screenImagePreviewUrl ? (
            <img
              src={screenImagePreviewUrl}
              alt={
                screenShareSource === 'android_camerax'
                  ? 'Live CameraX preview'
                  : 'Live shared Android screen'
              }
              className={`w-full h-44 object-contain bg-black ${isPaused ? 'opacity-40' : ''}`}
            />
          ) : (
            <video
              ref={screenPreviewRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-44 object-contain bg-black ${isPaused ? 'opacity-40' : ''}`}
            />
          )}
          <div className="px-3 py-2 bg-zinc-900 border-t border-zinc-800 text-xs text-zinc-300 flex items-center justify-between gap-2">
            <span className="truncate">
              {isCameraActive
                ? screenShareSource === 'android_camerax'
                  ? 'Fast CameraX Vision'
                  : 'Cam Active'
                : isPaused
                ? 'Sharing Paused'
                : 'Sharing Entire Android Screen'}
            </span>
            <div className="flex items-center gap-3 shrink-0">
              {isCameraActive && onSwitchCameraLens && (
                <button
                  type="button"
                  onClick={onSwitchCameraLens}
                  className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>{nativeCameraXAvailable ? 'Flip Lens' : 'Flip Cam'}</span>
                </button>
              )}
              {isScreenSharing && (
                <button
                  type="button"
                  onClick={onTogglePauseScreenShare}
                  className="text-blue-400 hover:text-blue-300 font-medium cursor-pointer"
                >
                  {isPaused ? 'Resume' : 'Pause'}
                </button>
              )}
              <button
                type="button"
                onClick={isCameraActive ? onToggleCamera : onToggleScreenShare}
                className="text-red-400 hover:text-red-300 font-medium cursor-pointer"
              >
                {isCameraActive ? 'Stop Cam' : 'Stop Sharing'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Slide-in Call Chat */}
      {chatDrawerOpen && (
        <div className="w-full max-w-md rounded-xl border border-zinc-800 bg-zinc-950 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 bg-black">
            <span className="text-xs font-medium text-zinc-300">Call Chat</span>
            <button
              type="button"
              onClick={() => setChatDrawerOpen(false)}
              className="p-1 rounded hover:bg-zinc-900 text-zinc-400 cursor-pointer"
              aria-label="Close call chat"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="max-h-40 overflow-y-auto p-3 space-y-2 text-xs">
            {callTranscript.length === 0 ? (
              <p className="text-zinc-500 text-center py-3">
                Ask &quot;What is showing on my screen?&quot; or &quot;What am I showing you?&quot;
              </p>
            ) : (
              callTranscript.map((m) => (
                <div
                  key={m.id}
                  className={`p-2 rounded-lg ${
                    m.role === 'user'
                      ? 'bg-blue-600 text-white ml-6'
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-200 mr-6'
                  }`}
                >
                  <span>{m.text}</span>
                </div>
              ))
            )}
          </div>
          <form onSubmit={handleSubmit} className="flex items-center gap-2 p-2 border-t border-zinc-800">
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Ask about your screen/camera or switch language..."
              className="flex-1 text-xs px-3 py-2 rounded-lg border border-zinc-800 bg-black text-zinc-100 focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              className="p-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
              aria-label="Send message"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}

      {/* Privacy & Security Notice */}
      {privacyOpen && (
        <div className="w-full max-w-md rounded-xl border border-zinc-800 bg-zinc-950 p-3 text-xs text-zinc-400 space-y-1.5">
          <div className="flex items-center justify-between text-zinc-200 font-medium">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Vision &amp; Call Privacy</span>
            </span>
            <button
              type="button"
              onClick={() => setPrivacyOpen(false)}
              className="text-zinc-400 hover:text-white cursor-pointer"
              aria-label="Close privacy info"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="leading-relaxed">
            Android requests explicit permission before screen or camera capture starts, keeps a
            visible notification running while active, respects protected windows (FLAG_SECURE), and
            stops immediately when you press Stop.
          </p>
        </div>
      )}

      {/* Direct Call Controls */}
      <div className="w-full max-w-md space-y-3 flex flex-col items-center">
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={onToggleScreenShare}
            className={`inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              isScreenSharing
                ? 'border-red-600/70 bg-red-950/50 text-red-200 hover:bg-red-900/50'
                : 'border-blue-500/70 bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-110 text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>{isScreenSharing ? 'Stop Sharing' : 'Screen Sharing'}</span>
          </button>

          {isScreenSharing && (
            <button
              type="button"
              onClick={onTogglePauseScreenShare}
              className={`inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                isPaused
                  ? 'border-blue-500 bg-blue-950/60 text-blue-200'
                  : 'border-zinc-800 bg-zinc-950 text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              <span>{isPaused ? 'Resume' : 'Pause'}</span>
            </button>
          )}

          {nativeAndroidAvailable && (
            <button
              type="button"
              onClick={onRequestOverlayIndicator}
              className={`inline-flex items-center gap-1.5 min-h-[44px] px-3 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                nativeOverlayGranted
                  ? 'border-emerald-700/60 bg-emerald-950/30 text-emerald-300'
                  : 'border-zinc-800 bg-zinc-950 text-zinc-300 hover:bg-zinc-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{nativeOverlayGranted ? 'Floating Indicator On' : 'Floating Indicator'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onToggleCamera}
            className={`inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              isCameraActive
                ? 'border-cyan-500 bg-cyan-950/50 text-cyan-200'
                : 'border-zinc-800 bg-zinc-950 text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{isCameraActive ? 'Stop Cam' : 'Cam'}</span>
          </button>

          <input
            ref={mediaInputRef}
            type="file"
            accept="image/*,video/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onAttachCallMedia(file);
              e.target.value = '';
            }}
          />
          <button
            type="button"
            onClick={() => mediaInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 rounded-xl border border-zinc-800 bg-zinc-950 text-xs font-medium text-zinc-200 hover:bg-zinc-900 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Paperclip className="w-3.5 h-3.5" />
            <span>Attach Pic / Video</span>
          </button>
        </div>

        <div className="flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={onToggleMute}
            className={`flex flex-col items-center justify-center gap-1 min-h-[48px] px-4 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
              muted
                ? 'border-amber-600/60 bg-amber-950/60 text-amber-300'
                : 'border-zinc-800 bg-zinc-950 text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            {muted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>{muted ? 'Unmute' : 'Mute'}</span>
          </button>

          <button
            type="button"
            onClick={() => setChatDrawerOpen((v) => !v)}
            className={`flex flex-col items-center justify-center gap-1 min-h-[48px] px-4 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
              chatDrawerOpen
                ? 'border-blue-500 bg-blue-950/60 text-blue-300'
                : 'border-zinc-800 bg-zinc-950 text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat</span>
          </button>

          <button
            type="button"
            onClick={() => setPrivacyOpen((v) => !v)}
            className={`flex flex-col items-center justify-center gap-1 min-h-[48px] px-4 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
              privacyOpen
                ? 'border-emerald-600/60 bg-emerald-950/40 text-emerald-300'
                : 'border-zinc-800 bg-zinc-950 text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Privacy</span>
          </button>

          <button
            type="button"
            onClick={onEndCall}
            className="flex flex-col items-center justify-center gap-1 min-h-[48px] px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-medium transition-colors cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>End Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};
