import React, { useState } from 'react';
import { SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { ChevronDown, HelpCircle } from 'lucide-react';

interface FaqSectionProps {
  currentLang: SupportedLanguage;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ currentLang }) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const t = translations[currentLang];

  const faqs = [
    {
      q: 'Do I need to pay or create an account to download TikTok videos?',
      a: 'No! SSSTik is 100% free and requires no registration, subscription, or software installation. You can download as many videos as you want without restrictions.',
    },
    {
      q: 'Where are downloaded TikTok videos saved on my phone or PC?',
      a: 'When you download a video, it is usually saved into your device\'s default "Downloads" folder. On Android and iPhone (iOS), you can open your Photos or Files app to view the saved MP4 or MP3 file.',
    },
    {
      q: 'How do I download TikTok videos on iPhone / iPad (iOS)?',
      a: 'On iOS 13 or later, open the Safari browser, paste the TikTok link into SSSTik, and tap Download. Safari will prompt you to download the file directly to your Files app, which you can then save to your Camera Roll.',
    },
    {
      q: 'Can I download TikTok music and audio as MP3?',
      a: 'Yes! SSSTik automatically extracts the original sound and background music from the TikTok video. Simply click the "Download MP3 Audio" button to save it as a high quality MP3 audio file.',
    },
    {
      q: 'Does SSSTik keep a copy of downloaded videos or track my activity?',
      a: 'No. SSSTik does not store videos or keep copies on its servers. All videos are hosted on TikTok\'s content delivery network (CDN), and we do not track or save your download history on our servers.',
    },
    {
      q: 'Can I download videos from private TikTok accounts?',
      a: 'No, due to TikTok\'s privacy policies and security settings, videos from private accounts cannot be accessed or downloaded by third-party tools. The video must be set to public.',
    },
  ];

  return (
    <section id="faq" className="py-16 sm:py-24 px-4 sm:px-6 bg-slate-950/60 border-t border-slate-800/80">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <div className="hidden items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 text-cyan-400 border border-cyan-800/50 text-xs font-semibold mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            Got Questions?
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            {t.faqTitle}
          </h2>
          <p className="text-slate-400 text-sm mt-2">
            Everything you need to know about downloading TikTok videos without watermark
          </p>
        </div>

        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="bg-slate-900/80 border border-slate-800 hover:border-slate-700/80 rounded-2xl overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full px-5 sm:px-6 py-4 sm:py-5 flex items-center justify-between gap-4 text-left cursor-pointer"
                >
                  <span className="font-bold text-white text-sm sm:text-base">
                    {faq.q}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center shrink-0 text-cyan-400 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-cyan-500/10' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-slate-300 text-xs sm:text-sm leading-relaxed border-t border-slate-800/60 animate-in fade-in duration-200">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
