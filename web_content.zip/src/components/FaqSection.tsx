import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const { data } = useData();
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = data.faqs && data.faqs.length > 0 ? data.faqs : [
    {
      id: 'faq-1',
      question: 'What services does Cubix Studio offer?',
      answer: 'Cubix Studio specializes in four core areas: modern website development, graphic design and brand systems, custom Minecraft server plugins and systems, and Discord bot development and community automation.'
    },
    {
      id: 'faq-2',
      question: 'How do I start a project?',
      answer: 'Click the "Start a Project" button to access our dedicated project brief page. You can specify your project requirements, budget, timeline, and references.'
    },
    {
      id: 'faq-3',
      question: 'Can I request a custom solution?',
      answer: 'Yes. Every project we undertake is custom-built to match your exact technical specifications, whether that is a specialized server plugin, a proprietary Discord bot, or a custom web application.'
    },
    {
      id: 'faq-4',
      question: 'How can I view previous projects?',
      answer: 'You can explore our Projects page organized into Website Development, Graphic Design, Minecraft Development, and Discord Solutions with downloadable assets and live details.'
    },
    {
      id: 'faq-5',
      question: 'How do project updates and communication work?',
      answer: 'We provide structured milestones and direct communication through Discord and email. You receive regular status updates and preview demonstrations before final delivery.'
    }
  ];

  return (
    <section id="faq" className="py-12 sm:py-16 max-w-[1120px] mx-auto px-4 sm:px-6">
      <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          QUESTIONS &amp; ANSWERS
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-4 mb-3 font-['Plus_Jakarta_Sans']">
          Frequently Asked Questions
        </h2>
        <p className="text-slate-300 text-sm sm:text-base">
          Common inquiries about working with Cubix Studio, delivery timelines, and technical scope.
        </p>
      </div>

      <div className="max-w-3xl mx-auto space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIdx === idx;
          return (
            <div
              key={faq.id || idx}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                isOpen
                  ? 'bg-[#081528] border-cyan-500/40 shadow-[0_5px_20px_rgba(0,210,255,0.08)]'
                  : 'bg-[#040c17]/80 border-white/10 hover:border-cyan-500/30'
              }`}
            >
              <button
                onClick={() => setOpenIdx(isOpen ? null : idx)}
                className="w-full flex items-center justify-between p-5 sm:p-6 text-left cursor-pointer"
                aria-expanded={isOpen}
              >
                <div className="flex items-center gap-3.5 pr-4">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/20">
                    <HelpCircle className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-base sm:text-lg text-white">
                    {faq.question}
                  </span>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-cyan-400 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-6 sm:px-6 sm:pb-6 text-slate-300 text-sm sm:text-base leading-relaxed pl-16 border-t border-white/5 pt-4">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
