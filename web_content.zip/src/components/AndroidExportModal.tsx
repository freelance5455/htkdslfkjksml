import { useState } from 'react';
import {
  CheckCircle2,
  Download,
  ExternalLink,
  FileArchive,
  Smartphone,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AndroidExportModal({ isOpen, onClose }: AndroidExportModalProps) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadDone, setDownloadDone] = useState(false);

  if (!isOpen) return null;

  const isInIframe =
    typeof window !== 'undefined' && window.self !== window.top;

  const handleInstallNow = async () => {
    await install();
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    setDownloadError(null);
    setDownloadDone(false);

    try {
      const origin = encodeURIComponent(window.location.origin);
      const response = await fetch(`/api/export/android?origin=${origin}`);
      if (!response.ok) {
        const errBody = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        throw new Error(errBody.error || 'Could not generate Android export bundle.');
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'dawitai-android-export.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setDownloadDone(true);
    } catch (err) {
      setDownloadError(
        err instanceof Error ? err.message : 'Download failed. Please try again.'
      );
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/50 backdrop-blur-xs sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="android-export-title"
    >
      <div
        className="fixed inset-0"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative z-10 flex max-h-[90dvh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:max-w-lg sm:rounded-2xl">
        <div className="mx-auto mt-2.5 h-1.5 w-10 rounded-full bg-slate-300 sm:hidden" />

        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div className="flex items-center gap-2.5">
            <Smartphone className="h-5 w-5 text-[#0F766E]" aria-hidden="true" />
            <h2
              id="android-export-title"
              className="text-base font-bold text-slate-900"
            >
              Install or Export Dawitai
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close install and export dialog"
            className="-mr-2 flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto overscroll-contain p-5">
          {/* Option 1: Direct Android PWA Install */}
          <section className="rounded-2xl border border-slate-200 bg-[#F8FAFC] p-4">
            <h3 className="text-sm font-semibold text-slate-900">
              1. Install Directly on Android (Instant App)
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-600">
              Install Dawitai straight onto your Android home screen with its own app icon, full-screen window, and offline chat history—no computer needed.
            </p>

            <div className="mt-3.5">
              {isInstalled ? (
                <div className="flex items-center gap-2 text-xs font-semibold text-teal-800">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-[#0F766E]" aria-hidden="true" />
                  <span>Dawitai is already installed on this device.</span>
                </div>
              ) : isInstallable ? (
                <button
                  type="button"
                  onClick={() => void handleInstallNow()}
                  className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F766E] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#0D655E] active:scale-[0.99]"
                >
                  <Download className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Install Dawitai App</span>
                </button>
              ) : isIOS ? (
                <ol className="space-y-1.5 text-xs leading-relaxed text-slate-700">
                  <li>1. Tap the <strong>Share</strong> icon in Safari.</li>
                  <li>2. Scroll down and tap <strong>Add to Home Screen</strong>.</li>
                </ol>
              ) : (
                <div className="space-y-2.5">
                  <ol className="space-y-1 text-xs leading-relaxed text-slate-700">
                    <li>1. Open Dawitai in <strong>Chrome on Android</strong>.</li>
                    <li>
                      2. Tap the <strong>⋮ menu</strong> (top right) and select{' '}
                      <strong>Install app</strong> or <strong>Add to Home screen</strong>.
                    </li>
                  </ol>
                  {isInIframe && (
                    <a
                      href={window.location.href}
                      target="_top"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100"
                    >
                      <span>Open full window to install</span>
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  )}
                </div>
              )}
            </div>
          </section>

          {/* Option 2: Download Exportable Android Package (.zip) */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4">
            <h3 className="text-sm font-semibold text-slate-900">
              2. Download Android Export Bundle (.zip)
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-600">
              Download a ready-to-build ZIP package containing the full Dawitai source code, PWA manifest &amp; Android icons, <code className="rounded bg-slate-100 px-1 py-0.5 text-[11px]">capacitor.config.json</code>, and <code className="rounded bg-slate-100 px-1 py-0.5 text-[11px]">twa-manifest.json</code> to compile a standalone <code className="rounded bg-slate-100 px-1 py-0.5 text-[11px]">.apk</code> file.
            </p>

            <div className="mt-3.5 space-y-2.5">
              <button
                type="button"
                onClick={() => void handleDownloadZip()}
                disabled={downloading}
                className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800 disabled:opacity-60 active:scale-[0.99]"
              >
                <FileArchive className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>
                  {downloading
                    ? 'Preparing ZIP bundle...'
                    : 'Download dawitai-android-export.zip'}
                </span>
              </button>

              {downloadDone && (
                <p className="flex items-center gap-1.5 text-xs font-medium text-teal-800">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-[#0F766E]" aria-hidden="true" />
                  <span>
                    Downloaded! Open <strong>ANDROID-INSTALL-GUIDE.md</strong> inside the ZIP for APK build steps.
                  </span>
                </p>
              )}

              {downloadError && (
                <p className="text-xs font-medium text-red-700">
                  {downloadError}
                </p>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
