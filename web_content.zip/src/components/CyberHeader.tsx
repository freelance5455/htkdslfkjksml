import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Shield, Send, Terminal, Lock } from 'lucide-react';
import { cyberAudio } from '../audio';

interface CyberHeaderProps {
  onOpenTelegram: () => void;
  onOpenLogs: () => void;
  onLock: () => void;
  customLogoUrl?: string | null;
}

export const CyberHeader: React.FC<CyberHeaderProps> = ({
  onOpenTelegram,
  onOpenLogs,
  onLock,
  customLogoUrl,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-US', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const toggleSound = () => {
    const muted = cyberAudio.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      cyberAudio.playClick();
    }
  };

  const logoSrc = customLogoUrl || 'https://i.ibb.co.com/vxGQ7hV9/IMG-20260823-131044-063.jpg';

  return (
    <header className="w-full bg-[#020d08]/90 border-b border-emerald-900/60 backdrop-blur-md sticky top-0 z-40 px-3 py-2 flex items-center justify-between shadow-[0_4px_20px_rgba(0,0,0,0.8)]">
      {/* Brand & Logo */}
      <div className="flex items-center gap-2.5">
        <div className="relative w-9 h-9 rounded-xl overflow-hidden border border-emerald-400/80 shadow-[0_0_12px_rgba(34,197,94,0.5)] shrink-0 bg-black">
          <img
            src={logoSrc}
            alt="GX TEAM Logo"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <span className="absolute inset-0 bg-emerald-500/10 pointer-events-none" />
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="gx-team-brand-glow text-sm font-black tracking-wider text-emerald-400">
              GX TEAM
            </span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <div className="flex items-center gap-1 text-[9px] text-emerald-300/70 font-mono">
            <span className="text-emerald-400 font-bold">ONLINE</span>
            <span>•</span>
            <span className="text-slate-300">{timeStr} UTC</span>
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-1.5">
        {/* Telegram VIP Support */}
        <button
          onClick={onOpenTelegram}
          className="flex items-center gap-1 bg-gradient-to-r from-sky-600/30 to-blue-600/30 hover:from-sky-600/50 hover:to-blue-600/50 border border-sky-500/40 text-sky-300 text-[10px] font-bold px-2 py-1 rounded-lg transition-all active:scale-95 cursor-pointer shadow-[0_0_8px_rgba(2,132,199,0.2)]"
          title="VIP Support & Passkey"
        >
          <Send className="w-3 h-3 text-sky-400" />
          <span className="hidden sm:inline">VIP</span>
        </button>

        {/* Audio Toggle */}
        <button
          onClick={toggleSound}
          className="p-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-400 transition-all active:scale-95 cursor-pointer"
          title={isMuted ? 'Unmute Cyber Audio' : 'Mute Cyber Audio'}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5 text-slate-400" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>

        {/* Diagnostic Logs */}
        <button
          onClick={onOpenLogs}
          className="p-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-400 transition-all active:scale-95 cursor-pointer"
          title="System Logs"
        >
          <Terminal className="w-3.5 h-3.5" />
        </button>

        {/* Lock Screen */}
        <button
          onClick={onLock}
          className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/80 border border-red-500/30 text-red-400 transition-all active:scale-95 cursor-pointer"
          title="Lock Terminal"
        >
          <Lock className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
export default CyberHeader;
