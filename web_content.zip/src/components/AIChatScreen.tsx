import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Send,
  Mic,
  MicOff,
  Sparkles,
  Volume2,
  Trash2,
  Check,
  Plus,
  ArrowRight,
  Calendar,
  Wallet,
  Clock,
  HelpCircle,
  Brain,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const AIChatScreen: React.FC = () => {
  const {
    chatMessages,
    sendMessage,
    executeChatAction,
    clearChatHistory,
    isBuddyThinking,
    isListening,
    speechSupported,
    startSpeechRecognition,
    stopSpeechRecognition,
    speakText,
    isSpeaking,
    profile,
  } = useApp();

  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isBuddyThinking]);

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input.trim());
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const starterPrompts = [
    { label: "☀️ Morning Briefing", text: "What's my day looking like today?" },
    { label: "⚡ Plan Deep Work", text: "Schedule a 90-minute focus block for design polish" },
    { label: "☕ Log $7 Coffee", text: "I bought an iced latte for $7.25 at the cafe" },
    { label: "🧠 Save Memory", text: "Remember that I prefer green tea over coffee after 2 PM" },
    { label: "🎯 Habit Motivation", text: "How can I maintain my 19-day streak?" },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-8.5rem)] max-w-md mx-auto">
      {/* 1. Assistant Status Banner */}
      <div className="px-4 py-2 bg-gradient-to-r from-indigo-50/90 via-violet-50/70 to-sky-50/90 dark:from-slate-900 dark:via-indigo-950/40 dark:to-slate-900 border-b border-indigo-100/70 dark:border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-full overflow-hidden ring-2 ring-indigo-500/30">
              <img
                src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                alt="HiBuddy Orb"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                HiBuddy AI
              </span>
              <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-100/70 dark:bg-indigo-900/50 px-1.5 py-0.2 rounded-md">
                Active
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              Personal Copilot · {profile.aiTone} mode
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            clearChatHistory();
          }}
          title="Clear Conversation"
          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-white dark:hover:bg-slate-800 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. Messages List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {chatMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            {/* Bubble */}
            <div className="flex items-end gap-2 max-w-[88%]">
              {msg.sender === 'buddy' && (
                <div className="w-6 h-6 rounded-full overflow-hidden shrink-0 mb-1 ring-1 ring-indigo-400/40">
                  <img
                    src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                    alt="HiBuddy"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}

              <div
                className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-br-xs shadow-md shadow-indigo-600/15'
                    : 'bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-slate-800 dark:text-slate-100 rounded-bl-xs shadow-xs'
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>

                {/* Voice audio replay for Buddy's messages */}
                {msg.sender === 'buddy' && (
                  <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-mono">{msg.timestamp}</span>
                    <button
                      onClick={() => {
                        sound.playClick();
                        speakText(msg.text);
                      }}
                      className="hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition-colors"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Speak</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* AI Action Suggestions */}
            {msg.actions && msg.actions.length > 0 && (
              <div className="mt-2 ml-8 space-y-1.5 w-[85%]">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Quick Actions
                </span>
                <div className="flex flex-col gap-1.5">
                  {msg.actions.map((act) => (
                    <button
                      key={act.id}
                      disabled={act.executed}
                      onClick={() => executeChatAction(act, msg.id)}
                      className={`text-left p-2.5 rounded-xl text-xs font-medium border flex items-center justify-between transition-all ${
                        act.executed
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                          : 'bg-indigo-50/90 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 active:scale-[0.98]'
                      }`}
                    >
                      <span className="truncate pr-2">{act.label}</span>
                      {act.executed ? (
                        <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 shrink-0">
                          <Check className="w-3.5 h-3.5" />
                          <span>Applied</span>
                        </div>
                      ) : (
                        <ArrowRight className="w-3.5 h-3.5 shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}

        {/* Thinking indicator */}
        {isBuddyThinking && (
          <div className="flex items-center gap-2 text-slate-400 text-xs pl-8">
            <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-violet-500 animate-bounce delay-100" />
            <div className="w-2 h-2 rounded-full bg-sky-500 animate-bounce delay-200" />
            <span className="text-[11px] text-slate-400 ml-1">HiBuddy is composing...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3. Starter Prompt Carousel */}
      <div className="px-4 py-1.5 overflow-x-auto flex gap-1.5 no-scrollbar shrink-0">
        {starterPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => {
              sound.playClick();
              sendMessage(p.text);
            }}
            className="whitespace-nowrap px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* 4. Active Listening Visualizer Bar */}
      {isListening && (
        <div className="mx-4 mb-2 p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex items-center justify-between text-xs text-rose-600 dark:text-rose-400 animate-pulse">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            <span className="font-medium">Listening to your voice... Speak now</span>
          </div>
          <button
            onClick={stopSpeechRecognition}
            className="text-[11px] font-semibold underline"
          >
            Done
          </button>
        </div>
      )}

      {/* 5. Input Bar */}
      <div className="p-3 bg-white/95 dark:bg-slate-900/95 border-t border-slate-200/80 dark:border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          {/* Voice Input Mic */}
          <button
            onClick={() => {
              if (isListening) {
                stopSpeechRecognition();
              } else {
                startSpeechRecognition();
              }
            }}
            title={isListening ? 'Stop Listening' : 'Voice Input'}
            className={`p-2.5 rounded-xl border transition-all ${
              isListening
                ? 'bg-rose-500 border-rose-600 text-white animate-pulse'
                : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text input */}
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask Buddy, schedule, or log expenses..."
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-100/90 dark:bg-slate-800/90 border border-transparent focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none transition-all"
          />

          {/* Send Button */}
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className={`p-2.5 rounded-xl font-medium transition-all ${
              input.trim()
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-600/20 active:scale-95'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
