import React, { useState } from 'react';
import { Logo } from './Logo';
import { Project, UserSession } from '../types';
import { 
  FolderGit2, 
  Search, 
  Terminal as TerminalIcon, 
  Download, 
  GraduationCap, 
  ShieldCheck, 
  User, 
  Check, 
  Copy, 
  LogOut, 
  Sun, 
  Moon,
  Plus,
  Github,
  UploadCloud
} from 'lucide-react';

interface DesktopHeaderProps {
  projects: Project[];
  currentProjectId: string;
  session: UserSession | null;
  siteTheme: string;
  isTerminalOpen: boolean;
  onSelectProject: (id: string) => void;
  onCreateProject: () => void;
  onToggleTerminal: () => void;
  onExportZip: () => void;
  onToggleTheme: () => void;
  onSignOut: () => void;
  onOpenSearch: () => void;
  onNavigateTab: (tab: string) => void;
  activeTab: string;
  onOpenGitHubImport?: () => void;
  onOpenGitHubPush?: () => void;
}

export const DesktopHeader: React.FC<DesktopHeaderProps> = ({
  projects,
  currentProjectId,
  session,
  siteTheme,
  isTerminalOpen,
  onSelectProject,
  onCreateProject,
  onToggleTerminal,
  onExportZip,
  onToggleTheme,
  onSignOut,
  onOpenSearch,
  onNavigateTab,
  activeTab,
  onOpenGitHubImport,
  onOpenGitHubPush,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const isLight = siteTheme === 'vscode-light' || siteTheme === 'github-light';

  const copyClassKey = () => {
    if (session?.classKey) {
      navigator.clipboard.writeText(session.classKey);
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  return (
    <header className="h-12 theme-bg-header border-b theme-border px-3 flex items-center justify-between shrink-0 theme-text-main z-30 transition-colors select-none">
      {/* Zone 1: Logo & Project Switcher */}
      <div className="flex items-center space-x-3">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            onNavigateTab(activeTab === 'home' ? 'editor' : 'home');
          }}
          className="cursor-pointer hover:opacity-85 transition-opacity flex items-center"
          title="Toggle Home / Editor"
        >
          <Logo size="sm" showName={true} />
        </a>

        {/* Project Selector */}
        <div className="flex items-center space-x-2 border-l theme-border pl-3 ml-1">
          <FolderGit2 className="w-4 h-4 text-[#359efe] shrink-0" />
          <select
            value={currentProjectId}
            onChange={(e) => {
              if (e.target.value === 'NEW_PROJECT') {
                onCreateProject();
              } else {
                onSelectProject(e.target.value);
              }
            }}
            className="bg-transparent border-none text-xs font-semibold theme-text-main outline-none cursor-pointer hover:opacity-80 max-w-[150px] truncate"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id} className="theme-bg-main theme-text-main">
                {p.name}
              </option>
            ))}
            <option value="NEW_PROJECT" className="theme-bg-main text-[#359efe] font-bold">
              + New Project...
            </option>
          </select>
        </div>
      </div>

      {/* Zone 2: Search Project Files */}
      <div
        onClick={onOpenSearch}
        className="hidden lg:flex items-center space-x-2 theme-bg-surface hover:theme-bg-surface-hover px-3 py-1.5 rounded-xl border theme-border theme-text-muted text-xs w-64 cursor-pointer transition-all"
        title="Search project files (Ctrl/Cmd + P)"
      >
        <Search className="w-3.5 h-3.5 theme-text-muted shrink-0" />
        <span className="flex-grow truncate">Search project files...</span>
        <span className="text-[10px] border theme-border px-1.5 py-0.5 rounded font-mono text-slate-400">
          ⌘P
        </span>
      </div>

      {/* Zone 3: Right Action Controls */}
      <div className="flex items-center space-x-2.5">
        {/* Assignments Nav Button */}
        <button
          onClick={() => onNavigateTab(activeTab === 'assignments' ? 'editor' : 'assignments')}
          className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
            activeTab === 'assignments'
              ? 'bg-[#359efe] text-white border-[#359efe]'
              : 'theme-bg-surface theme-text-muted hover:theme-text-main border-transparent'
          }`}
          title="Classroom Assignments"
        >
          <GraduationCap className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Assignments</span>
        </button>

        {/* Terminal Toggle Button */}
        <button
          onClick={onToggleTerminal}
          className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
            isTerminalOpen
              ? 'bg-cyan-500 text-white border-cyan-400'
              : 'theme-bg-surface theme-text-muted hover:theme-text-main border-transparent'
          }`}
          title="Toggle Console Terminal"
        >
          <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Terminal</span>
        </button>

        {/* Import from GitHub Button */}
        {onOpenGitHubImport && (
          <button
            onClick={onOpenGitHubImport}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all theme-bg-surface theme-text-muted hover:theme-text-main border theme-border hover:theme-bg-surface-hover"
            title="Import Project from GitHub Repository"
          >
            <Github className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">Import from GitHub</span>
            <span className="xl:hidden hidden sm:inline">Import</span>
          </button>
        )}

        {/* Push to GitHub Button */}
        {onOpenGitHubPush && (
          <button
            onClick={onOpenGitHubPush}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all bg-[#24292e] hover:bg-[#2f363d] text-white border border-[#444d56] shadow-xs"
            title="Push Project to GitHub Repository"
          >
            <UploadCloud className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden xl:inline">Push to GitHub</span>
            <span className="xl:hidden hidden sm:inline">Push</span>
          </button>
        )}

        {/* Export ZIP Button */}
        <button
          onClick={onExportZip}
          className="flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all bg-[#359efe] hover:bg-[#2563eb] text-white shadow-xs"
          title="Export Entire Project as ZIP (HTML, CSS, JS & Images)"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export ZIP</span>
        </button>

        {/* Theme Switcher Toggle */}
        <button
          onClick={onToggleTheme}
          className="p-1.5 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded-lg transition-colors cursor-pointer"
          title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
        >
          {isLight ? (
            <Moon className="w-4 h-4 text-indigo-400" />
          ) : (
            <Sun className="w-4 h-4 text-amber-400" />
          )}
        </button>

        {/* User Session Profile */}
        {session && (
          <div className="flex items-center space-x-2 theme-bg-surface px-2.5 py-1 rounded-lg border theme-border">
            {session.photoUrl ? (
              <img
                src={session.photoUrl}
                alt="avatar"
                className="w-5 h-5 rounded-full object-cover border theme-border"
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-[#359efe] flex items-center justify-center font-bold text-[9px] text-white">
                {session.role === 'teacher' ? (
                  <ShieldCheck className="w-3 h-3" />
                ) : session.role === 'student' ? (
                  <GraduationCap className="w-3 h-3" />
                ) : (
                  <User className="w-3 h-3" />
                )}
              </div>
            )}
            <span className="text-xs font-medium theme-text-main truncate max-w-[85px]">
              {session.name}
            </span>

            {/* Class key copy */}
            {session.classKey && (
              <button
                onClick={copyClassKey}
                className="p-0.5 theme-text-muted hover:theme-text-main cursor-pointer"
                title={`Class Key: ${session.classKey} (Click to copy)`}
              >
                {copiedKey ? (
                  <Check className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
        )}

        {/* Sign out */}
        {session && (
          <button
            onClick={onSignOut}
            className="p-1.5 theme-text-muted hover:text-red-400 hover:theme-bg-surface-hover rounded-lg transition-colors cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </header>
  );
};
