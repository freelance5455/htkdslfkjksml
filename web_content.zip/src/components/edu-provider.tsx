import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  getProfile,
  getProgress,
  markLessonRead,
  saveProfile,
  submitExam,
  submitQuiz,
  updateLocale,
  type Profile,
  type ProgressRow,
} from "@/lib/edu.functions";
import { useLocale, type Locale } from "@/lib/locale";
import {
  enqueue,
  readMirror,
  readQueue,
  upsertMirror,
  writeMirror,
  writeQueue,
  type PendingSync,
} from "@/lib/offline";
import {
  findChapter,
  findExam,
  lessonItemId,
  quizItemId,
} from "@/content/catalog";
import { gradeAttempt } from "@/lib/score";

type EduValue = {
  profile: Profile | null;
  progress: ProgressRow[];
  loading: boolean;
  refresh: () => Promise<void>;
  saveStudent: (input: { fullName: string; grade: number; locale: Locale }) => Promise<Profile>;
  setLanguage: (locale: Locale) => void;
  recordLesson: (subjectId: string, chapterId: string) => Promise<{ synced: boolean }>;
  recordQuiz: (
    subjectId: string,
    chapterId: string,
    answers: number[],
  ) => Promise<{ score: number; total: number; marks: boolean[]; synced: boolean }>;
  recordExam: (
    examId: string,
    answers: number[],
  ) => Promise<{ score: number; total: number; marks: boolean[]; synced: boolean }>;
};

const EduContext = createContext<EduValue | null>(null);

function mergeRow(rows: ProgressRow[], row: ProgressRow) {
  return [...rows.filter((item) => !(item.kind === row.kind && item.itemId === row.itemId)), row];
}

export function EduProvider({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const setLocale = useLocale((state) => state.setLocale);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [progress, setProgress] = useState<ProgressRow[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const nextProfile = await getProfile();
    setProfile(nextProfile);
    if (nextProfile) setLocale(nextProfile.locale);
    let queue = readQueue();
    for (const item of queue) {
      try {
        if (item.type === "lesson") await markLessonRead({ data: item });
        if (item.type === "quiz") await submitQuiz({ data: item });
        if (item.type === "exam") await submitExam({ data: item });
        queue = queue.filter((queued) => queued !== item);
        writeQueue(queue);
      } catch {
        break;
      }
    }
    const rows = await getProgress();
    setProgress(rows);
    writeMirror(rows);
  }, [setLocale]);

  useEffect(() => {
    if (import.meta.env.PROD && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = useLocale.getState().locale === "am" ? "am" : "en";
  });

  useEffect(() => {
    if (isPending) return;
    if (!user) {
      setProfile(null);
      setProgress([]);
      setLoading(false);
      return;
    }
    let cancel = false;
    setLoading(true);
    refresh()
      .catch(() => {
        if (!cancel) setProgress(readMirror());
      })
      .finally(() => {
        if (!cancel) setLoading(false);
      });
    return () => {
      cancel = true;
    };
  }, [user?.id, isPending, refresh]);

  const saveStudent = useCallback(
    async (input: { fullName: string; grade: number; locale: Locale }) => {
      const saved = await saveProfile({ data: input });
      setProfile(saved);
      setLocale(saved.locale);
      return saved;
    },
    [setLocale],
  );

  const setLanguage = useCallback(
    (locale: Locale) => {
      setLocale(locale);
      document.documentElement.lang = locale === "am" ? "am" : "en";
      if (profile) void updateLocale({ data: locale }).catch(() => undefined);
    },
    [profile, setLocale],
  );

  const remember = useCallback((row: ProgressRow) => {
    setProgress((current) => mergeRow(current, row));
    upsertMirror(row);
  }, []);

  const recordLesson = useCallback(
    async (subjectId: string, chapterId: string) => {
      const row: ProgressRow = {
        kind: "lesson",
        itemId: lessonItemId(subjectId, chapterId),
        score: null,
        total: null,
        completed: true,
      };
      remember(row);
      try {
        await markLessonRead({ data: { subjectId, chapterId } });
        return { synced: true };
      } catch {
        enqueue({ type: "lesson", subjectId, chapterId });
        return { synced: false };
      }
    },
    [remember],
  );

  const recordQuiz = useCallback(
    async (subjectId: string, chapterId: string, answers: number[]) => {
      const found = findChapter(subjectId, chapterId);
      const local = gradeAttempt(
        found.chapter?.questions.map((question) => question.answer) ?? [],
        answers,
      );
      remember({
        kind: "quiz",
        itemId: quizItemId(subjectId, chapterId),
        score: local.score,
        total: local.total,
        completed: true,
      });
      remember({
        kind: "lesson",
        itemId: lessonItemId(subjectId, chapterId),
        score: null,
        total: null,
        completed: true,
      });
      try {
        const saved = await submitQuiz({ data: { subjectId, chapterId, answers } });
        if (saved.ok) return { score: saved.score, total: saved.total, marks: saved.marks, synced: true };
      } catch {
        /* queued below */
      }
      const pending: PendingSync = { type: "quiz", subjectId, chapterId, answers };
      enqueue(pending);
      return { ...local, synced: false };
    },
    [remember],
  );

  const recordExam = useCallback(
    async (examId: string, answers: number[]) => {
      const exam = findExam(examId);
      const local = gradeAttempt(
        exam?.questions.map((question) => question.answer) ?? [],
        answers,
      );
      remember({
        kind: "exam",
        itemId: examId,
        score: local.score,
        total: local.total,
        completed: true,
      });
      try {
        const saved = await submitExam({ data: { examId, answers } });
        if (saved.ok) return { score: saved.score, total: saved.total, marks: saved.marks, synced: true };
      } catch {
        /* queued below */
      }
      enqueue({ type: "exam", examId, answers });
      return { ...local, synced: false };
    },
    [remember],
  );

  const value = useMemo(
    () => ({
      profile,
      progress,
      loading: isPending || loading,
      refresh,
      saveStudent,
      setLanguage,
      recordLesson,
      recordQuiz,
      recordExam,
    }),
    [
      profile,
      progress,
      isPending,
      loading,
      refresh,
      saveStudent,
      setLanguage,
      recordLesson,
      recordQuiz,
      recordExam,
    ],
  );

  return <EduContext.Provider value={value}>{children}</EduContext.Provider>;
}

export function useEdu() {
  const value = useContext(EduContext);
  if (!value) throw new Error("useEdu must be used inside EduProvider");
  return value;
}
