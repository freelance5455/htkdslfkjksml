import React, { useEffect, useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Send, Bot, AlertCircle, Loader2 } from 'lucide-react';
import { LangMode } from '../data/types';
import { VIDEO_LESSONS } from '../data/installationAndDubai';
import { BiTextBlock, SafeImage } from './BilingualBlock';

export const MediaLessonsPanel: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [selectedLessonId, setSelectedLessonId] = useState(VIDEO_LESSONS[0].id);
  const [frameIdx, setFrameIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const lesson = VIDEO_LESSONS.find((l) => l.id === selectedLessonId) || VIDEO_LESSONS[0];
  const frame = lesson.frames[frameIdx] || lesson.frames[0];

  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setFrameIdx((prev) => {
        if (prev >= lesson.frames.length - 1) {
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, 3500);
    return () => clearInterval(timer);
  }, [isPlaying, lesson.frames.length]);

  const selectLesson = (id: string) => {
    setSelectedLessonId(id);
    setFrameIdx(0);
    setIsPlaying(false);
  };

  const galleryPhotos = [
    {
      src: '/src/assets/images/hero_plumbing_workshop.jpg',
      title: lang === 'hi' ? 'प्रेशर गेज के साथ कॉपर व PPR मैनिफोल्ड' : 'PPR & Copper Supply Manifold with Gauges',
    },
    {
      src: '/src/assets/images/dubai_bathroom_roughin.jpg',
      title: lang === 'hi' ? 'दुबई कंसील्ड टैंक और गर्म-ठंडा राफ-इन' : 'Dubai Concealed Cistern & Hot/Cold Rough-In',
    },
    {
      src: '/src/assets/images/fittings_pipes_collection.jpg',
      title: lang === 'hi' ? 'uPVC, PPR व ब्रास फिटिंग्स पहचान' : 'uPVC, PPR & Brass Fittings Identification',
    },
    {
      src: '/src/assets/images/pressure_test_pump.jpg',
      title: lang === 'hi' ? '10 Bar हाइड्रोस्टैटिक प्रेशर टेस्ट पंप' : '10 Bar Hydrostatic Pressure Test Pump Setup',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Interactive Video-Style Step Walkthrough Player */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50">
          <div>
            <h3 className="font-bold text-slate-900 text-base sm:text-lg">
              {lang === 'hi' ? 'स्टेप-बाय-स्टेप प्रैक्टिकल वीडियो लेसन प्लेयर' : 'Interactive Step-by-Step Visual Lesson Player'}
            </h3>
            <p className="text-xs text-slate-500">
              {lang === 'hi'
                ? 'प्ले दबाएं या हर स्टेप पर क्लिक करके फोटो के साथ काम सीखें'
                : 'Press Play or step through real site frames with guided callouts'}
            </p>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {VIDEO_LESSONS.map((l) => (
              <button
                key={l.id}
                onClick={() => selectLesson(l.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors min-h-[38px] ${
                  selectedLessonId === l.id
                    ? 'bg-blue-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {l.category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Stage Frame with Callout Pin */}
          <div className="lg:col-span-7 relative bg-slate-900 overflow-hidden min-h-[260px] sm:min-h-[340px]">
            <SafeImage
              src={lesson.thumbnail}
              alt={lesson.title.en}
              className="w-full h-full max-h-[380px] object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent" />

            {/* Interactive Step Hotspot Pin */}
            <div
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
              style={{ left: `${frame.calloutX}%`, top: `${frame.calloutY}%` }}
            >
              <div className="w-9 h-9 rounded-full bg-blue-600 text-white border-2 border-white shadow-lg flex items-center justify-center font-mono-num text-sm font-bold">
                {frame.stepNumber}
              </div>
            </div>

            {/* Bottom Scrim Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white space-y-1">
              <div className="text-xs font-mono-num text-blue-300 font-semibold">
                Step {frame.stepNumber} of {lesson.frames.length} · {frame.technicalNote}
              </div>
              <div className="text-sm sm:text-base font-semibold leading-snug">
                {lang === 'hi' ? frame.caption.hi : frame.caption.en}
              </div>
              {lang === 'both' && <div className="text-xs text-slate-200">{frame.caption.hi}</div>}
            </div>
          </div>

          {/* Controls & Step Playlist */}
          <div className="lg:col-span-5 p-4 sm:p-5 flex flex-col justify-between gap-4 border-t lg:border-t-0 lg:border-l border-slate-200">
            <div className="space-y-3">
              <BiTextBlock
                text={lesson.title}
                lang={lang}
                className="font-bold text-slate-900 text-base"
                hiClassName="text-sm font-medium text-blue-700"
              />
              <div className="space-y-2">
                {lesson.frames.map((f, idx) => (
                  <button
                    key={f.stepNumber}
                    onClick={() => {
                      setFrameIdx(idx);
                      setIsPlaying(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl border transition-colors flex items-start gap-2.5 ${
                      idx === frameIdx
                        ? 'bg-blue-50 border-blue-300 text-blue-950'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span
                      className={`w-6 h-6 rounded-md text-xs font-mono-num font-bold flex items-center justify-center shrink-0 mt-0.5 ${
                        idx === frameIdx ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {f.stepNumber}
                    </span>
                    <span className="text-xs leading-relaxed">
                      {lang === 'hi' ? f.caption.hi : f.caption.en}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  setIsPlaying(false);
                  setFrameIdx((i) => Math.max(0, i - 1));
                }}
                disabled={frameIdx === 0}
                className="h-11 px-3 rounded-xl border border-slate-300 text-slate-700 disabled:opacity-40 flex items-center gap-1 text-xs font-semibold"
              >
                <SkipBack className="w-4 h-4" />
                <span>Prev</span>
              </button>

              <button
                onClick={() => {
                  if (frameIdx >= lesson.frames.length - 1 && !isPlaying) setFrameIdx(0);
                  setIsPlaying((p) => !p);
                }}
                className="h-11 px-5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white flex items-center gap-2 text-xs font-semibold"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlaying ? (lang === 'hi' ? 'रोकें' : 'Pause') : (lang === 'hi' ? 'प्ले करें' : 'Play Lesson')}</span>
              </button>

              <button
                onClick={() => {
                  setIsPlaying(false);
                  setFrameIdx((i) => Math.min(lesson.frames.length - 1, i + 1));
                }}
                disabled={frameIdx === lesson.frames.length - 1}
                className="h-11 px-3 rounded-xl border border-slate-300 text-slate-700 disabled:opacity-40 flex items-center gap-1 text-xs font-semibold"
              >
                <span>Next</span>
                <SkipForward className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Site Reference Photo Gallery */}
      <div className="space-y-3">
        <h3 className="font-bold text-slate-900 text-base">
          {lang === 'hi' ? 'प्रैक्टिकल साइट फोटो गैलरी' : 'Practical Field Reference Photos'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {galleryPhotos.map((photo) => (
            <div key={photo.src} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <SafeImage src={photo.src} alt={photo.title} className="w-full h-44 object-cover" />
              <div className="p-3 text-xs font-semibold text-slate-800">{photo.title}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const STARTER_QUESTIONS = [
  '25mm PPR pipe welding heating time kitna hota hai?',
  'Dubai site par 10 Bar pressure test kaise karte hain?',
  'Bathroom mixer hot & cold height aur center distance kya hai?',
  '110mm toilet pipe mein slope kitna rakhna chahiye?',
  'What is the difference between P-Trap, S-Trap and Floor Trap?',
];

export const AiPlumberAssistant: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text:
        lang === 'hi'
          ? 'नमस्ते! मैं उस्ताद फरीद (AI Plumbing Mentor) हूँ। आप हिंदी, हिंग्लिश या अंग्रेजी में पाइप साइज, फिटिंग, दुबई साइट नियम, प्रेशर टेस्ट या किसी भी प्लंबिंग समस्या के बारे में पूछ सकते हैं।'
          : 'Assalamu Alaikum / Hello! I am Ustad Farid, your AI Plumbing Mentor. Ask me anything about pipe sizes, PPR welding, bathroom rough-in heights, UAE/Dubai standards, or troubleshooting in Hindi, Hinglish, or English.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendQuestion = async (questionText: string) => {
    const trimmed = questionText.trim();
    if (!trimmed || loading) return;

    setError(null);
    const updatedMessages: ChatMessage[] = [...messages, { role: 'user', text: trimmed }];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/plumbing-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: trimmed,
          language: lang,
          history: updatedMessages.slice(-8),
        }),
      });

      const data = (await response.json()) as { answer?: string; error?: string };
      if (!response.ok || !data.answer) {
        throw new Error(data.error || 'Failed to get response from AI Plumber Assistant.');
      }

      setMessages((prev) => [...prev, { role: 'model', text: data.answer! }]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Network error connecting to AI Assistant.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col max-w-4xl mx-auto">
      <div className="px-4 sm:px-6 py-4 bg-blue-700 text-white flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base">
              {lang === 'hi' ? 'AI प्लंबर उस्ताद (हिंदी व अंग्रेजी)' : 'AI Plumber Assistant — Ustad Farid'}
            </h3>
            <p className="text-xs text-blue-100">
              {lang === 'hi'
                ? 'प्लंबिंग से जुड़ा कोई भी सवाल पूछें · भारत व दुबई साइट गाइड'
                : 'Ask any plumbing question in Hindi, Hinglish, or English'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Starter Chips */}
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {STARTER_QUESTIONS.map((q) => (
          <button
            key={q}
            onClick={() => sendQuestion(q)}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 hover:border-blue-400 hover:text-blue-700 text-xs font-medium text-slate-700 whitespace-nowrap shrink-0 min-h-[36px]"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Chat Thread */}
      <div className="p-4 sm:p-6 space-y-4 max-h-[460px] overflow-y-auto bg-white">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[88%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                m.role === 'user'
                  ? 'bg-blue-700 text-white'
                  : 'bg-slate-100 text-slate-900 border border-slate-200'
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 border border-slate-200 rounded-2xl px-4 py-3 text-xs text-slate-600 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-700" />
              <span>{lang === 'hi' ? 'उस्ताद जवाब लिख रहे हैं...' : 'Ustad Farid is preparing your answer...'}</span>
            </div>
          </div>
        )}

        {error && (
          <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendQuestion(input);
        }}
        className="p-3 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center gap-2.5"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            lang === 'hi'
              ? 'अपना सवाल लिखें (जैसे: 110mm पाइप स्लोप कितना रखें?)...'
              : 'Ask your plumbing question in Hindi or English...'
          }
          className="flex-1 h-12 px-4 rounded-xl border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="h-12 px-5 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-semibold text-sm flex items-center gap-2 shrink-0"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">{lang === 'hi' ? 'पूछें' : 'Ask'}</span>
        </button>
      </form>
    </div>
  );
};
