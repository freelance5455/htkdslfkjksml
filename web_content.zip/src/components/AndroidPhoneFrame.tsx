import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Zap, Flame, ShieldCheck, Gamepad2, Volume2, VolumeX, Sparkles, RefreshCw, Smartphone } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundFX } from '../utils/audio';
import { NetworkStats, AndroidToast } from '../types';

interface AndroidPhoneFrameProps {
  stats: NetworkStats;
  isBoosting: boolean;
  onBoost: () => void;
  toasts: AndroidToast[];
  selectedIsp: string;
  onSelectIsp: (id: string) => void;
  language: 'en' | 'ur';
}

export const AndroidPhoneFrame: React.FC<AndroidPhoneFrameProps> = ({
  stats,
  isBoosting,
  onBoost,
  toasts,
  selectedIsp,
  language,
}) => {
  const [currentTime, setCurrentTime] = useState('12:47');
  const [wifiBlinkingOff, setWifiBlinkingOff] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 10000);
    return () => clearInterval(interval);
  }, []);

  // When boosting starts, simulate the Android wifiManager.isWifiEnabled = false -> true transition
  useEffect(() => {
    if (isBoosting) {
      setWifiBlinkingOff(true);
      const timer = setTimeout(() => {
        setWifiBlinkingOff(false);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isBoosting]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundFX.setMuted(!next);
    if (next) soundFX.playToast();
  };

  const handleBoostClick = () => {
    if (isBoosting) return;
    soundFX.triggerHaptic('boost');
    soundFX.playBoost();
    onBoost();

    // Trigger gamer confetti after boost
    setTimeout(() => {
      soundFX.playSuccess();
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#f59e0b', '#10b981', '#3b82f6', '#ef4444'],
      });
    }, 1400);
  };

  // Text computed exactly as in the user's Kotlin code:
  // Initial: "Signal: $level% | Ping: ${rssi}dBm"
  // Boosted: "Boosted! 🔥 Signal: ${level+15}% | FF Ping: LOW"
  const signalDisplayText = stats.isBoosted
    ? `Boosted! 🔥 Signal: ${Math.min(100, stats.signalLevel + 15)}% | FF Ping: LOW`
    : `Signal: ${stats.signalLevel}% | Ping: ${stats.rssi}dBm`;

  return (
    <div className="relative mx-auto w-full max-w-[380px] select-none">
      {/* Device Outer Chassis */}
      <div className="relative rounded-[46px] p-3.5 bg-gradient-to-b from-slate-800 via-slate-900 to-slate-950 shadow-2xl shadow-amber-500/10 border border-slate-700/60">
        {/* Speaker Notch & Camera Pin */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
          <div className="w-12 h-1 bg-slate-700 rounded-full"></div>
          <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-700 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-900/60"></div>
          </div>
        </div>

        {/* Volume & Power button accents */}
        <div className="absolute -left-1 top-24 w-1 h-10 bg-slate-700 rounded-l-sm"></div>
        <div className="absolute -left-1 top-38 w-1 h-14 bg-slate-700 rounded-l-sm"></div>
        <div className="absolute -right-1 top-28 w-1 h-12 bg-slate-700 rounded-r-sm"></div>

        {/* Screen Area (19.5:9 aspect ratio standard Android) */}
        <div className="relative flex flex-col justify-between overflow-hidden rounded-[38px] bg-slate-950 text-slate-100 min-h-[640px] border border-slate-800/80">
          {/* Top Status Bar */}
          <div className="flex items-center justify-between px-6 pt-3 pb-2 text-xs font-mono text-slate-400">
            <span className="font-semibold text-slate-200">{currentTime}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] tracking-wide text-amber-400 font-bold">4G+ PK</span>
              {wifiBlinkingOff ? (
                <WifiOff className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
              ) : (
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span className="text-[11px] font-bold text-slate-300">98%</span>
            </div>
          </div>

          {/* App Header (Android ActionBar / Toolbar) */}
          <div className="px-5 py-2.5 border-b border-slate-800/80 bg-slate-900/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-sm shadow-amber-500/20">
                47
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                  OPKING47 Booster
                  <span className="text-xs" title="Pakistan Server">🇵🇰</span>
                </h1>
                <p className="text-[10px] text-slate-400 font-mono">com.opking47.networkbooster</p>
              </div>
            </div>

            <button
              onClick={toggleSound}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
              title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
              aria-label="Toggle sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>
          </div>

          {/* Main App Content matching R.layout.activity_main */}
          <div className="flex-1 px-5 py-4 flex flex-col justify-between">
            {/* Top Info Card */}
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                  {language === 'ur' ? 'نیٹ ورک اسٹیٹس' : 'Active Network'}
                </span>
                <span className="font-semibold text-emerald-400 text-xs flex items-center gap-1">
                  🇵🇰 {selectedIsp.toUpperCase()}
                </span>
              </div>

              {/* R.id.signalText: The central status string from Kotlin code */}
              <div
                id="signalText"
                className={`p-3 rounded-xl border font-mono text-center transition-all duration-300 ${
                  stats.isBoosted
                    ? 'bg-amber-950/30 border-amber-500/50 text-amber-300 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-950/60 border-slate-800 text-slate-200'
                }`}
              >
                <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-0.5">
                  android:id="@+id/signalText"
                </div>
                <div className="text-sm font-bold tracking-tight">
                  {wifiBlinkingOff ? (
                    <span className="text-rose-400 animate-pulse">Reconnecting WiFi Radio...</span>
                  ) : (
                    signalDisplayText
                  )}
                </div>
              </div>
            </div>

            {/* Central Signal Visualizer & Ping Dial */}
            <div className="relative py-4 flex flex-col items-center justify-center">
              <div className="relative w-44 h-44 flex items-center justify-center">
                {/* Outer Ring */}
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    className="stroke-slate-800/80"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    className={`transition-all duration-700 ${
                      stats.isBoosted ? 'stroke-amber-400' : 'stroke-emerald-500'
                    }`}
                    strokeWidth="8"
                    strokeDasharray={264}
                    strokeDashoffset={264 - (264 * Math.min(100, stats.isBoosted ? stats.signalLevel + 15 : stats.signalLevel)) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                </svg>

                {/* Dial Content */}
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <div className="flex items-center gap-1 text-slate-400 text-xs mb-0.5">
                    {stats.isBoosted ? (
                      <Flame className="w-4 h-4 text-orange-500 animate-bounce" />
                    ) : (
                      <Wifi className="w-4 h-4 text-emerald-400" />
                    )}
                    <span className="font-medium text-[11px]">Free Fire Ping</span>
                  </div>
                  <div className="text-3xl font-extrabold tracking-tight font-mono text-white">
                    {stats.isBoosted ? (
                      <span className="text-emerald-400">18<span className="text-sm font-normal text-slate-400">ms</span></span>
                    ) : (
                      <span>{stats.pingMs}<span className="text-sm font-normal text-slate-400">ms</span></span>
                    )}
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 mt-1">
                    RSSI: <span className="text-slate-200">{stats.rssi} dBm</span>
                  </div>
                </div>
              </div>

              {/* Free Fire Specific Node Info */}
              <div className="mt-2 text-center">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                  <Gamepad2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Target: Garena Free Fire PK Server</span>
                </span>
              </div>
            </div>

            {/* Quick Feature Grid */}
            <div className="grid grid-cols-3 gap-2 my-1 text-center">
              <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <div className="text-[10px] text-slate-400">DNS Mode</div>
                <div className="text-xs font-semibold text-slate-200 truncate mt-0.5">1.1.1.1 WARP</div>
              </div>
              <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <div className="text-[10px] text-slate-400">Jitter</div>
                <div className="text-xs font-semibold text-emerald-400 font-mono mt-0.5">
                  {stats.isBoosted ? '1.2ms' : `${stats.jitterMs}ms`}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <div className="text-[10px] text-slate-400">Packet Loss</div>
                <div className="text-xs font-semibold text-emerald-400 font-mono mt-0.5">
                  {stats.isBoosted ? '0.0%' : `${stats.packetLossPercent}%`}
                </div>
              </div>
            </div>

            {/* R.id.boostBtn: The primary button from Kotlin code */}
            <div className="pt-2">
              <button
                id="boostBtn"
                onClick={handleBoostClick}
                disabled={isBoosting}
                className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm tracking-wide transition-all transform active:scale-95 flex items-center justify-center gap-2 shadow-xl ${
                  isBoosting
                    ? 'bg-amber-600 text-white cursor-wait opacity-90'
                    : stats.isBoosted
                    ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 shadow-amber-500/25 hover:brightness-110'
                    : 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-orange-500/20 hover:brightness-110'
                }`}
              >
                {isBoosting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>{language === 'ur' ? 'بوسٹنگ جاری ہے...' : 'OPKING47 BOOSTING...'}</span>
                  </>
                ) : (
                  <>
                    <Flame className="w-4 h-4 text-slate-950 fill-current" />
                    <span>
                      {stats.isBoosted
                        ? (language === 'ur' ? 'دوبارہ بوسٹ کریں 🔥' : 'RE-BOOST NETWORK 🔥')
                        : (language === 'ur' ? 'نیٹ ورک بوسٹ کریں 🔥' : 'BOOST NETWORK NOW 🔥')}
                    </span>
                  </>
                )}
              </button>

              <div className="mt-1.5 text-center text-[10px] text-slate-500 font-mono">
                android:id="@+id/boostBtn"
              </div>
            </div>
          </div>

          {/* Android System Navigation Bar (Gesture pill) */}
          <div className="py-2.5 flex justify-center items-center">
            <div className="w-28 h-1 bg-slate-700 rounded-full"></div>
          </div>

          {/* Realistic Android Toast Popups container */}
          <div className="absolute bottom-12 left-0 right-0 px-4 pointer-events-none flex flex-col items-center gap-2 z-50">
            {toasts.map((toast) => (
              <div
                key={toast.id}
                className="animate-in fade-in slide-in-from-bottom-4 duration-300 px-4 py-2 rounded-full bg-slate-900/95 text-slate-100 text-xs font-medium border border-slate-700 shadow-2xl backdrop-blur-md flex items-center gap-2 text-center"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{toast.message}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
