import React, { useState, useEffect } from 'react';

interface SplashScreenIntroProps {
  onComplete?: () => void;
  durationMs?: number;
}

export const SplashScreenIntro: React.FC<SplashScreenIntroProps> = ({ 
  onComplete,
  durationMs = 2000 
}) => {
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [isDone, setIsDone] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);

  useEffect(() => {
    // Start fade out slightly before completion
    const fadeTimer = setTimeout(() => {
      setIsFadingOut(true);
    }, Math.max(durationMs - 350, 500));

    // Fully complete and unmount
    const doneTimer = setTimeout(() => {
      setIsDone(true);
      onComplete?.();
    }, durationMs);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(doneTimer);
    };
  }, [durationMs, onComplete]);

  if (isDone) return null;

  return (
    <div 
      className={`fixed inset-0 z-[99999] flex flex-col items-center justify-center bg-[#05060a] select-none transition-opacity duration-300 ease-out ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ touchAction: 'none' }}
    >
      {/* 2-Second Silent Video Player (if supported by device) */}
      <video
        src="/splash.mp4"
        autoPlay
        muted
        playsInline
        webkit-playsinline="true"
        onLoadedData={() => setVideoLoaded(true)}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
          videoLoaded ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* High-Fidelity Animated Vector Fallback (Zero delay, instant render, matches video 1:1) */}
      <div 
        className={`relative flex flex-col items-center justify-center w-full max-w-sm px-6 transition-opacity duration-200 ${
          videoLoaded ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
      >
        {/* Ambient Neon Atmosphere Bloom */}
        <div className="absolute w-64 h-64 rounded-full bg-gradient-to-tr from-cyan-500/25 via-purple-600/30 to-rose-500/20 blur-3xl animate-pulse pointer-events-none" />

        {/* The Exact Glowing Logo (Animated 3D Orbit & Wave) */}
        <div className="relative w-44 h-44 sm:w-52 sm:h-52 flex items-center justify-center animate-in zoom-in-75 duration-700">
          <svg 
            viewBox="0 0 100 100" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full drop-shadow-[0_0_24px_rgba(6,182,212,0.7)]"
          >
            <defs>
              <radialGradient id="splashSphereGrad" cx="38%" cy="32%" r="65%">
                <stop offset="0%" stopColor="#67e8f9" />
                <stop offset="28%" stopColor="#06b6d4" />
                <stop offset="68%" stopColor="#4f46e5" />
                <stop offset="92%" stopColor="#0f172a" />
                <stop offset="100%" stopColor="#05070f" />
              </radialGradient>

              <linearGradient id="splashRingCyan" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="50%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#f43f5e" />
              </linearGradient>

              <linearGradient id="splashRingViolet" x1="100%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#c084fc" />
                <stop offset="60%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#4f46e5" />
              </linearGradient>

              <linearGradient id="splashWhisperWave" x1="0%" y1="50%" x2="100%" y2="50%">
                <stop offset="0%" stopColor="#a5f3fc" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="1" />
                <stop offset="100%" stopColor="#c084fc" stopOpacity="0.3" />
              </linearGradient>
            </defs>

            {/* Shockwave expanding ring */}
            <circle 
              cx="50" 
              cy="50" 
              r="47" 
              stroke="url(#splashRingCyan)" 
              strokeWidth="1.2" 
              strokeDasharray="4 6"
              className="animate-spin"
              style={{ animationDuration: '8s' }}
            />

            {/* Orbital Ellipse 1 (Tilted West-East) */}
            <ellipse 
              cx="50" 
              cy="50" 
              rx="45" 
              ry="20" 
              transform="rotate(-28 50 50)" 
              stroke="url(#splashRingCyan)" 
              strokeWidth="2.2" 
              strokeLinecap="round"
              className="opacity-90"
            />

            {/* Orbital Ellipse 2 (Counter-tilted) */}
            <ellipse 
              cx="50" 
              cy="50" 
              rx="44" 
              ry="19" 
              transform="rotate(42 50 50)" 
              stroke="url(#splashRingViolet)" 
              strokeWidth="1.6" 
              strokeDasharray="6 4"
              className="opacity-75"
            />

            {/* Solid Holographic Sphere Body */}
            <circle 
              cx="50" 
              cy="50" 
              r="32" 
              fill="url(#splashSphereGrad)" 
              stroke="#38bdf8" 
              strokeWidth="1.6"
              strokeOpacity="0.9"
            />

            {/* Sphere Specular Highlight (Glass Shine) */}
            <ellipse 
              cx="40" 
              cy="36" 
              rx="12" 
              ry="7" 
              transform="rotate(-30 40 36)" 
              fill="#ffffff" 
              fillOpacity="0.4" 
            />

            {/* Internal Secret Frequency / Whispering Voice Waveform */}
            <path 
              d="M 28 50 Q 34 40, 40 50 T 50 50 T 60 50 T 72 50" 
              stroke="url(#splashWhisperWave)" 
              strokeWidth="2.4" 
              strokeLinecap="round"
            />
            <path 
              d="M 33 50 Q 42 32, 50 50 T 67 50" 
              stroke="#ffffff" 
              strokeWidth="1.5" 
              strokeLinecap="round"
              fill="none"
              className="opacity-85"
            />

            {/* Orbiting Secret Nodes */}
            <circle cx="82" cy="33" r="3" fill="#22d3ee" className="animate-ping" style={{ animationDuration: '2s' }} />
            <circle cx="20" cy="65" r="2.5" fill="#f43f5e" />
            <circle cx="50" cy="50" r="3" fill="#ffffff" />
          </svg>
        </div>

        {/* Brand Text Reveal (Like Instagram/Netflix opening) */}
        <div className="mt-8 flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-3 duration-500 delay-150">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-1">
            Secret<span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-cyan-400">Gossip</span>
          </h1>
          <p className="text-[11px] uppercase tracking-[0.25em] text-slate-400 font-medium mt-1.5">
            Where Campus Secrets Find a Voice
          </p>
        </div>
      </div>
    </div>
  );
};
