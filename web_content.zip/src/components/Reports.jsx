import { useState, useEffect } from 'react'
import { recentBills, salesBetween, voidBill, db } from '../db/database'
import { inr, today, localDate, monthKey, fmtDate, fmtTime } from '../lib/format'
import BillReceipt from './BillReceipt'

function dayBounds(dateStr) {
  const start = new Date(`${dateStr}T00:00:00`).toISOString()
  const end = new Date(`${dateStr}T23:59:59.999`).toISOString()
  return { start, end }
}

export default function Reports({ refreshTick = 0, onChange }) {
  const [range, setRange] = useState('today')
  const [fromD, setFromD] = useState(() => `${monthKey()}-01`)
  const [toD, setToD] = useState(() => today())
  const [bills, setBills] = useState([])
  const [history, setHistory] = useState([])
  const [error, setError] = useState('')
  const [reprint, setReprint] = useState(null)

  useEffect(() => {
    let start, end
    if (range === 'today') {
      const b = dayBounds(today())
      start = b.start
      end = b.end
    } else if (range === 'month') {
      start = new Date(`${monthKey()}-01T00:00:00`).toISOString()
      end = new Date().toISOString()
    } else if (range === 'custom') {
      if (!fromD || !toD || fromD > toD) {
        setBills([])
        return
      }
      const s = dayBounds(fromD)
      const e = dayBounds(toD)
      start = s.start
      end = e.end
    } else {
      start = '0000'
      end = '9999'
    }
    salesBetween(start, end).then(setBills)
  }, [range, refreshTick, fromD, toD])

  useEffect(() => {
    recentBills(50).then(setHistory)
  }, [refreshTick])

  async function openReprint(b) {
    const s = await db.settings.bulkGet(['shopName', 'shopAddress', 'shopPhone'])
    setReprint({
      ...b,
      shopName: s[0]?.value || 'Mera Kirana',
      shopAddress: s[1]?.value || '',
      shopPhone: s[2]?.value || '',
    })
  }

  async function handleVoid(bill) {
    const ok = window.confirm(
      `Bill #${bill.billNo} (${inr(bill.total)}) void karein?\nStock wapas aa jayega aur udhar hat jayega.`,
    )
    if (!ok) return
    const reason = window.prompt('Void ka reason (optional):', 'Galat bill')
    if (reason === null) return
    try {
      await voidBill(bill.id, reason.trim())
      setError('')
      if (onChange) onChange()
    } catch (e) {
      setError(e.message || 'Void nahi hua')
    }
  }

  const total = bills.reduce((s, b) => s + b.total, 0)
  const cash = bills.filter((b) => b.payMode === 'CASH').reduce((s, b) => s + b.total, 0)
  const upi = bills.filter((b) => b.payMode === 'UPI').reduce((s, b) => s + b.total, 0)
  const udhar = bills.filter((b) => b.payMode === 'UDHAR').reduce((s, b) => s + b.total, 0)

  const byDay = {}
  for (const b of bills) {
    const d = localDate(b.createdAt)
    byDay[d] = (byDay[d] || 0) + b.total
  }
  const days = Object.entries(byDay).sort((a, b) => (a[0] < b[0] ? 1 : -1))

  return (
    <div>
      <div className="seg">
        {[
          ['today', 'Aaj'],
          ['month', 'Is Mahine'],
          ['custom', 'Custom'],
          ['all', 'Sab'],
        ].map(([id, label]) => (
          <button
            key={id}
            className={`seg-btn ${range === id ? 'active' : ''}`}
            onClick={() => setRange(id)}
          >
            {label}
          </button>
        ))}
      </div>

      {range === 'custom' && (
        <div className="row">
          <label className="field grow">
            <span className="field-label">Se</span>
            <input
              className="input"
              type="date"
              value={fromD}
              max={toD || undefined}
              onChange={(e) => setFromD(e.target.value)}
            />
          </label>
          <label className="field grow">
            <span className="field-label">Tak</span>
            <input
              className="input"
              type="date"
              value={toD}
              min={fromD || undefined}
              onChange={(e) => setToD(e.target.value)}
            />
          </label>
        </div>
      )}
      {range === 'custom' && (!fromD || !toD || fromD > toD) && (
        <p className="small balance-due">Date range sahih nahi — Se, Tak se pehle ki ho nahi sakti</p>
      )}

      <div className="stat-grid">
        <div className="stat-card highlight">
          <div className="stat-label">Total Sale</div>
          <div className="stat-value">{inr(total)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Bills</div>
          <div className="stat-value">{bills.length}</div>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card cash">
          <div className="stat-label">Cash</div>
          <div className="stat-value">{inr(cash)}</div>
        </div>
        <div className="stat-card upi">
          <div className="stat-label">UPI</div>
          <div className="stat-value">{inr(upi)}</div>
        </div>
        <div className="stat-card udhar">
          <div className="stat-label">Udhar</div>
          <div className="stat-value">{inr(udhar)}</div>
        </div>
      </div>

      <h3>Roz ka</h3>
      <ul className="list">
        {days.length === 0 && <li className="muted">Koi bill nahi</li>}
        {days.map(([d, amt]) => (
          <li key={d} className="list-item">
            <div className="item-main">
              <div className="item-title">{fmtDate(d)}</div>
            </div>
            <div className="item-price">{inr(amt)}</div>
          </li>
        ))}
      </ul>

      <h3>Haal ke bill</h3>
      {error && <p className="error">{error}</p>}
      <ul className="list">
        {history.length === 0 && <li className="muted">Abhi tak koi bill nahi</li>}
        {history.map((b) => (
          <li key={b.id} className={`list-item ${b.voidedAt ? 'voided' : ''}`}>
            <div className="item-main">
              <div className="item-title">#{b.billNo}</div>
              <div className="item-sub muted">
                {fmtTime(b.createdAt)} · {b.payMode}
                {b.customerName ? ` · ${b.customerName}` : ''}
              </div>
              {b.voidedAt && (
                <div className="item-sub small balance-due">
                  VOID{b.voidReason ? ` — ${b.voidReason}` : ''}
                </div>
              )}
            </div>
            <div className="item-price">{inr(b.total)}</div>
            {!b.voidedAt && (
              <div className="item-actions">
                <button className="btn btn-small" onClick={() => openReprint(b)}>
                  🖨 Print
                </button>
                <button
                  className="btn btn-small btn-danger"
                  onClick={() => handleVoid(b)}
                >
                  Void
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>

      {reprint && (
        <div className="scanner-overlay" role="dialog" aria-modal="true">
          <div className="scanner-card receipt-modal">
            <BillReceipt
              bill={reprint}
              onNewBill={() => setReprint(null)}
              onBack={() => setReprint(null)}
            />
          </div>
        </div>
      )}
    </div>
  )
}