import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Crown, 
  Sparkles, 
  MessageCircle, 
  Check, 
  Zap 
} from 'lucide-react';

export const PremiumModal: React.FC = () => {
  const { 
    isPremiumModalOpen, 
    setIsPremiumModalOpen, 
    upgradeToPremium, 
    user 
  } = useApp();

  if (!isPremiumModalOpen) return null;

  const handleUpgrade = () => {
    upgradeToPremium();
    setTimeout(() => {
      setIsPremiumModalOpen(false);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-gradient-to-b from-[#151226] via-[#0d1020] to-[#090b14] border border-amber-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-amber-950/40 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400" />
            <h3 className="font-display font-black text-base sm:text-lg text-slate-100">
              Secret Gossip+ VIP
            </h3>
          </div>
          <button
            onClick={() => setIsPremiumModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Hero badge */}
        <div className="my-5 text-center space-y-2">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-500 to-purple-600 p-[2px] mx-auto shadow-xl shadow-amber-500/20">
            <div className="w-full h-full rounded-3xl bg-[#090b14] flex items-center justify-center text-3xl">
              👑
            </div>
          </div>
          <h4 className="font-display font-black text-lg text-slate-100">
            Supercharge Your Whisper Influence
          </h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Get post boosts, unlock unlimited anonymous direct whispers, and wear the VIP badge.
          </p>
        </div>

        {/* Feature List */}
        <div className="space-y-2.5 my-4">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">
                Post Boost (Glowing Neon Halo)
              </p>
              <p className="text-[10px] text-slate-400">
                Pushes your confession to the top of trending feeds with 5x visibility.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
              <MessageCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">
                Unlimited Anonymous DMs
              </p>
              <p className="text-[10px] text-slate-400">
                Directly whisper with confession authors with zero identity risk.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">
                Exclusive VIP Profile Insignia
              </p>
              <p className="text-[10px] text-slate-400">
                Displays golden crown aura next to your masked persona.
              </p>
            </div>
          </div>
        </div>

        {/* Pricing / Activate button */}
        <div className="pt-2">
          {user.isPremium ? (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-center text-xs text-emerald-300 font-semibold flex items-center justify-center gap-2">
              <Check className="w-4 h-4" />
              <span>Secret Gossip+ VIP Active on this Account</span>
            </div>
          ) : (
            <button
              onClick={handleUpgrade}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-slate-950 text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-amber-500/25 active:scale-98 flex items-center justify-center gap-2"
            >
              <Crown className="w-4 h-4" />
              <span>Activate Free VIP Student Pass</span>
            </button>
          )}
          <p className="text-[10px] text-slate-500 text-center mt-2">
            No credit card needed • Free for verified college student beta
          </p>
        </div>
      </div>
    </div>
  );
};
