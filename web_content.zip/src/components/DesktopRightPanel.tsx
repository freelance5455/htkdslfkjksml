import React, { useState, useEffect } from 'react';
import { Flame, TrendingUp, Award, Users } from 'lucide-react';
import { Post, UserProfile } from '../types';
import { getAllUsers, toggleFollowUser, calculateStudioAnalytics } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface DesktopRightPanelProps {
  posts: Post[];
  onSelectCreator: (username: string) => void;
  onOpenCertificate: (id: string) => void;
  onOpenStudio: () => void;
}

export const DesktopRightPanel: React.FC<DesktopRightPanelProps> = ({
  posts,
  onSelectCreator,
  onOpenCertificate,
  onOpenStudio,
}) => {
  const { userProfile } = useAuth();
  const [suggested, setSuggested] = useState<UserProfile[]>([]);
  const [followedMap, setFollowedMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    async function load() {
      const users = await getAllUsers(5);
      setSuggested(users.filter((u) => u.id !== userProfile?.id && u.username !== userProfile?.username));
    }
    load();
  }, [userProfile?.id, userProfile?.username]);

  const userPosts = posts.filter(
    (p) => p.userId === userProfile?.id || (userProfile?.username && p.username === userProfile.username)
  );
  const studioStats = calculateStudioAnalytics(userPosts, '7d');

  const handleToggleFollow = async (target: UserProfile) => {
    if (!userProfile) return;
    const isCurrentlyFollowed = followedMap[target.id] || false;
    const newStatus = !isCurrentlyFollowed;

    setFollowedMap((prev) => ({ ...prev, [target.id]: newStatus }));
    try {
      await toggleFollowUser(userProfile.id, userProfile, target.id, isCurrentlyFollowed);
    } catch {
      // ignore
    }
  };

  // Derive unique hashtags from real posts
  const realTags = Array.from(
    new Set(posts.flatMap((p) => p.hashtags || []))
  ).slice(0, 5);

  return (
    <aside className="hidden xl:flex flex-col w-80 h-screen sticky top-0 bg-[#050505] border-l border-[#19191F] p-6 space-y-6 overflow-y-auto no-scrollbar z-20 select-none">
      {/* Studio Mini Widget with real metrics */}
      <div
        onClick={onOpenStudio}
        className="p-4 rounded-3xl bg-gradient-to-br from-[#101014] to-[#19191F] border border-[#272730] cursor-pointer hover:border-[#FF008C]/50 transition-all shadow-lg group text-left"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-[#FF008C]" />
            <span className="text-xs font-bold text-white">ClipShare Studio</span>
          </div>
          <span className="text-[10px] font-bold text-[#20E060] bg-[#20E060]/10 px-2 py-0.5 rounded-full">
            {studioStats.views.numericValue > 0 ? '+15%' : '0%'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-left">
          <div className="p-2 rounded-xl bg-black/40">
            <span className="text-[10px] text-[#A1A1AA] block">Visualizações</span>
            <span className="text-sm font-black text-white">{studioStats.views.value}</span>
          </div>
          <div className="p-2 rounded-xl bg-black/40">
            <span className="text-[10px] text-[#A1A1AA] block">Alcance</span>
            <span className="text-sm font-black text-white">{studioStats.reach.value}</span>
          </div>
        </div>
        <span className="text-[11px] font-semibold text-[#FF008C] group-hover:underline mt-2.5 block">
          Abrir painel completo de criador →
        </span>
      </div>

      {/* Suggested Creators (Real community only) */}
      <div className="p-4 rounded-3xl bg-[#101014] border border-[#19191F] text-left">
        <h3 className="text-xs font-bold text-white mb-3 flex items-center gap-1.5">
          <Users size={16} className="text-[#FF008C]" />
          <span>Criadores para seguir</span>
        </h3>

        {suggested.length === 0 ? (
          <p className="text-xs text-[#A1A1AA] py-2">
            Nenhum outro criador registrado ainda.
          </p>
        ) : (
          <div className="space-y-3">
            {suggested.map((user) => {
              const isFollowed = followedMap[user.id] || false;
              return (
                <div key={user.id} className="flex items-center justify-between">
                  <div
                    onClick={() => onSelectCreator(user.username)}
                    className="flex items-center gap-2.5 cursor-pointer overflow-hidden"
                  >
                    <img
                      src={user.photoURL}
                      alt={user.displayName}
                      className="w-9 h-9 rounded-full object-cover border border-[#272730] shrink-0"
                    />
                    <div className="truncate">
                      <p className="text-xs font-bold text-white truncate">
                        {user.displayName}
                      </p>
                      <p className="text-[10px] text-[#A1A1AA] truncate">
                        @{user.username}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggleFollow(user)}
                    className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all cursor-pointer shrink-0 ${
                      isFollowed
                        ? 'bg-[#19191F] text-white border border-[#272730]'
                        : 'bg-clipshare-gradient text-white hover:opacity-95'
                    }`}
                  >
                    {isFollowed ? 'Seguindo' : 'Seguir'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Trending Hashtags from real posts */}
      {realTags.length > 0 && (
        <div className="p-4 rounded-3xl bg-[#101014] border border-[#19191F] text-left">
          <h3 className="text-xs font-bold text-white mb-3 flex items-center gap-1.5">
            <Flame size={16} className="text-[#FF3B30]" />
            <span>Tendências de clipes</span>
          </h3>

          <div className="space-y-2">
            {realTags.map((tag) => (
              <div key={tag} className="flex items-center justify-between cursor-pointer group">
                <div>
                  <span className="text-xs font-bold text-white group-hover:text-[#FF008C] transition-colors block">
                    #{tag}
                  </span>
                </div>
                <span className="text-[10px] text-[#A1A1AA]">🔥 Ativo</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Influencer Certificate Callout */}
      <div
        onClick={() => onOpenCertificate(userProfile?.certificateId || 'cert-joaovibes-10k')}
        className="p-4 rounded-3xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-purple-500/10 border border-amber-500/30 cursor-pointer hover:border-amber-400/50 transition-all text-left"
      >
        <div className="flex items-center gap-2 mb-1.5">
          <Award size={18} className="text-amber-400" />
          <h4 className="text-xs font-bold text-amber-300">Certificado ClipShare</h4>
        </div>
        <p className="text-[11px] text-white/80 leading-relaxed mb-2">
          Atinja 10 seguidores reais e conquiste o certificado oficial verificado.
        </p>
        <span className="text-[11px] font-bold text-amber-400 underline">
          Verificar status →
        </span>
      </div>

      {/* Footer copyright */}
      <div className="text-[11px] text-[#A1A1AA] text-center pt-2">
        <p>© 2026 ClipShare Web. Todos os direitos reservados.</p>
        <p className="mt-1">Sua vibe. Seu clipe. Seu mundo.</p>
      </div>
    </aside>
  );
};
