import { cn } from "@/lib/cn";
import type { ReactNode } from "react";

export function Sheet({
  title,
  onClose,
  children,
  wide,
}: {
  title?: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-end">
      <button
        type="button"
        aria-label="Close"
        className="absolute inset-0 bg-studio/70"
        onClick={onClose}
      />
      <div
        className={cn(
          "relative z-10 flex max-h-[90%] flex-col rounded-t-2xl border-t border-border bg-card shadow-soft",
          wide && "max-h-[94%]",
        )}
      >
        <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-border" />
        {title ? (
          <div className="flex items-center justify-between px-5 pt-3 pb-1">
            <h2 className="text-lg font-medium tracking-tight">{title}</h2>
            <button
              type="button"
              onClick={onClose}
              className="text-sm text-muted-foreground"
            >
              Close
            </button>
          </div>
        ) : null}
        <div className="overflow-y-auto px-5 pt-2 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
          {children}
        </div>
      </div>
    </div>
  );
}
