import React, { useState, useEffect } from 'react';
import { Contact } from '../types/jarvis';
import { hardwareBridge } from '../utils/hardwareBridge';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  MessageSquare,
  MessageCircle,
  Send,
  User,
  Star,
  Grid,
  ShieldCheck,
  Radio,
  X,
} from 'lucide-react';

interface CommsDialerProps {
  contacts: Contact[];
  activeCall: {
    contactName: string;
    phoneNumber: string;
    startTime: number;
    isEncrypted: boolean;
  } | null;
  onInitiateCall: (contactName: string, phoneNumber: string) => void;
  onEndCall: () => void;
  onSendMessage: (contactName: string, phoneNumber: string, message: string, app: 'sms' | 'whatsapp') => void;
}

export const CommsDialer: React.FC<CommsDialerProps> = ({
  contacts,
  activeCall,
  onInitiateCall,
  onEndCall,
  onSendMessage,
}) => {
  const [commsTab, setCommsTab] = useState<'contacts' | 'dialer' | 'messenger'>('contacts');

  // Dialer keypad state
  const [dialedNumber, setDialedNumber] = useState('');

  // Messenger state
  const [selectedContact, setSelectedContact] = useState<Contact>(contacts[0] || { id: 'c1', name: 'Pepper Potts', phone: '+1-310-555-0101', role: 'CEO' });
  const [messageText, setMessageText] = useState('');
  const [messengerApp, setMessengerApp] = useState<'sms' | 'whatsapp'>('whatsapp');

  // In-call local states
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);
  const [callDuration, setCallDuration] = useState(0);

  // Active call duration timer
  useEffect(() => {
    if (!activeCall) {
      setCallDuration(0);
      return;
    }
    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [activeCall]);

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handleKeypadPress = (digit: string) => {
    hardwareBridge.playJarvisTone('ack');
    hardwareBridge.vibrate(30);
    setDialedNumber((prev) => prev + digit);
  };

  const handleManualCall = () => {
    if (!dialedNumber.trim()) return;
    onInitiateCall(`Direct Dial (${dialedNumber})`, dialedNumber);
  };

  const handleSendMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    onSendMessage(selectedContact.name, selectedContact.phone, messageText.trim(), messengerApp);
    setMessageText('');
  };

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400">
              <PhoneCall className="w-5 h-5" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Comms & Phone Hub
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Hands-free cellular calling, WhatsApp direct link & SMS dispatcher
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 bg-gray-950 p-1 rounded-xl border border-gray-800 self-start sm:self-auto">
          <button
            onClick={() => setCommsTab('contacts')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all ${
              commsTab === 'contacts'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            Contacts
          </button>
          <button
            onClick={() => setCommsTab('dialer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all ${
              commsTab === 'dialer'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            Keypad
          </button>
          <button
            onClick={() => setCommsTab('messenger')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-orbitron transition-all ${
              commsTab === 'messenger'
                ? 'bg-cyan-500 text-gray-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            Dispatch SMS
          </button>
        </div>
      </div>

      {/* TAB 1: CONTACTS LIST */}
      {commsTab === 'contacts' && (
        <div className="space-y-3">
          <span className="text-xs font-mono-code text-cyan-400 uppercase tracking-wider block">
            Stark Secure Contacts Directory
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                className="p-3 rounded-xl bg-gray-950/80 border border-gray-800 hover:border-cyan-500/40 transition flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/30 flex items-center justify-center font-orbitron font-bold text-cyan-300 text-sm">
                    {contact.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-semibold text-slate-100 group-hover:text-cyan-200 transition">
                        {contact.name}
                      </h4>
                      {contact.favorite && <Star className="w-3 h-3 text-amber-400 fill-amber-400" />}
                    </div>
                    <p className="text-[11px] font-mono-code text-slate-400">
                      {contact.role} // <span className="text-cyan-300">{contact.phone}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onInitiateCall(contact.name, contact.phone)}
                    aria-label={`Call ${contact.name}`}
                    className="p-2 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600 hover:text-gray-950 transition"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedContact(contact);
                      setCommsTab('messenger');
                    }}
                    aria-label={`Message ${contact.name}`}
                    className="p-2 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-600 hover:text-gray-950 transition"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: KEYPAD DIALER */}
      {commsTab === 'dialer' && (
        <div className="max-w-xs mx-auto space-y-4">
          <div className="p-3 rounded-xl bg-gray-950 border border-cyan-500/40 text-center">
            <span className="text-[10px] font-mono-code text-slate-500 uppercase tracking-widest block">
              Direct Frequency / Dial
            </span>
            <div className="text-2xl font-mono-code text-cyan-300 tracking-wider h-8 overflow-hidden">
              {dialedNumber || '—'}
            </div>
          </div>

          {/* 12 Key Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((digit) => (
              <button
                key={digit}
                onClick={() => handleKeypadPress(digit)}
                className="py-3 rounded-xl bg-gray-950/90 border border-gray-800 hover:border-cyan-500/60 active:bg-cyan-950 text-slate-100 font-orbitron text-lg font-bold transition shadow-sm"
              >
                {digit}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={() => setDialedNumber((prev) => prev.slice(0, -1))}
              className="flex-1 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-slate-400 hover:text-slate-200 text-xs font-mono-code transition"
            >
              Backspace
            </button>
            <button
              onClick={handleManualCall}
              disabled={!dialedNumber.trim()}
              className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/30"
            >
              <Phone className="w-4 h-4" />
              Call Now
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: DISPATCH MESSENGER */}
      {commsTab === 'messenger' && (
        <form onSubmit={handleSendMessageSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono-code text-slate-300 mb-1">
                Recipient Contact
              </label>
              <select
                value={selectedContact.id}
                onChange={(e) => {
                  const match = contacts.find((c) => c.id === e.target.value);
                  if (match) setSelectedContact(match);
                }}
                className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
              >
                {contacts.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.phone})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono-code text-slate-300 mb-1">
                Dispatch Protocol
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMessengerApp('whatsapp')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                    messengerApp === 'whatsapp'
                      ? 'bg-emerald-600 text-gray-950 font-bold'
                      : 'bg-gray-950 border border-gray-800 text-slate-400'
                  }`}
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </button>
                <button
                  type="button"
                  onClick={() => setMessengerApp('sms')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                    messengerApp === 'sms'
                      ? 'bg-blue-600 text-white font-bold'
                      : 'bg-gray-950 border border-gray-800 text-slate-400'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  Android SMS
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono-code text-slate-300 mb-1">
              Message Payload
            </label>
            <textarea
              rows={3}
              required
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="e.g. Tony here. Advancing mark LXXXV diagnostics, meeting at the lab at 4."
              className="w-full bg-gray-950 border border-gray-700 rounded-xl p-3 text-sm text-slate-100 focus:outline-none focus:border-cyan-400 resize-none"
            />
          </div>

          {/* Quick message chips */}
          <div className="flex flex-wrap gap-1.5">
            {[
              "I'm on my way.",
              "In a meeting right now, will call back shortly.",
              "Please check the latest telemetry report.",
              "Can you confirm our dinner reservations?",
            ].map((snippet) => (
              <button
                key={snippet}
                type="button"
                onClick={() => setMessageText(snippet)}
                className="text-xs font-mono-code px-2 py-1 rounded bg-gray-950 border border-gray-800 hover:border-cyan-500/40 text-slate-400 hover:text-cyan-300 transition"
              >
                "{snippet}"
              </button>
            ))}
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-cyan-600/30"
            >
              <Send className="w-4 h-4" />
              Launch & Transmit Message
            </button>
          </div>
        </form>
      )}

      {/* IN-CALL HOLOGRAPHIC OVERLAY MODAL */}
      {activeCall && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pb-24 sm:pb-8 bg-gray-950/90 backdrop-blur-md overflow-y-auto">
          <div className="w-full max-w-sm bg-gray-900 border-2 border-cyan-500 rounded-3xl p-5 sm:p-6 text-center shadow-2xl shadow-cyan-900/60 relative overflow-hidden my-auto">
            {/* Top Status */}
            <div className="flex items-center justify-between mb-4">
              <span className="flex items-center gap-1.5 text-xs font-mono-code text-cyan-400 uppercase tracking-widest">
                <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
                COMMS ACTIVE
              </span>
              <span className="flex items-center gap-1 text-[11px] font-mono-code text-emerald-400 border border-emerald-500/40 bg-emerald-950/40 px-2 py-0.5 rounded-full">
                <ShieldCheck className="w-3 h-3" />
                ENCRYPTED
              </span>
            </div>

            {/* Avatar Pulse */}
            <div className="relative my-6 flex justify-center">
              <div className="w-24 h-24 rounded-full bg-cyan-950 border-2 border-cyan-400 flex items-center justify-center font-orbitron text-2xl font-bold text-cyan-200 animate-pulse">
                {activeCall.contactName.slice(0, 2).toUpperCase()}
              </div>
              <div className="absolute inset-0 rounded-full border border-cyan-500/30 animate-ping pointer-events-none" />
            </div>

            <h3 className="font-orbitron text-xl font-bold text-slate-100">
              {activeCall.contactName}
            </h3>
            <p className="text-xs font-mono-code text-cyan-400 mt-1">
              {activeCall.phoneNumber}
            </p>

            {/* Duration */}
            <div className="mt-3 inline-block px-3 py-1 rounded-full bg-gray-950 border border-gray-800 text-sm font-mono-code text-slate-300">
              {formatSeconds(callDuration)}
            </div>

            {/* Call Controls */}
            <div className="grid grid-cols-3 gap-3 my-6">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1 text-xs font-mono-code transition ${
                  isMuted ? 'bg-red-950 text-red-300 border border-red-500' : 'bg-gray-950 text-slate-300 border border-gray-800'
                }`}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                <span>{isMuted ? 'Muted' : 'Mute'}</span>
              </button>

              <button
                onClick={() => setIsSpeaker(!isSpeaker)}
                className={`p-3 rounded-2xl flex flex-col items-center gap-1 text-xs font-mono-code transition ${
                  isSpeaker ? 'bg-cyan-950 text-cyan-300 border border-cyan-500' : 'bg-gray-950 text-slate-300 border border-gray-800'
                }`}
              >
                {isSpeaker ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                <span>Speaker</span>
              </button>

              <button
                onClick={() => {
                  window.location.href = `tel:${activeCall.phoneNumber}`;
                }}
                className="p-3 rounded-2xl bg-gray-950 text-emerald-400 border border-gray-800 hover:border-emerald-500 flex flex-col items-center gap-1 text-xs font-mono-code transition"
              >
                <Phone className="w-5 h-5" />
                <span>Native Tel</span>
              </button>
            </div>

            {/* End Call Button */}
            <button
              onClick={onEndCall}
              className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold font-orbitron text-sm uppercase tracking-widest transition flex items-center justify-center gap-2 shadow-lg shadow-red-600/40"
            >
              <PhoneOff className="w-5 h-5" />
              Disconnect Comms
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
