import { formatLat } from "@/lib/astro";
import { useVespera } from "@/lib/store";

export function PolarisLab() {
  const lat = useVespera((s) => s.lat);
  const setLat = useVespera((s) => s.setLat);
  const north = lat >= 0;
  const alt = Math.abs(lat);
  const y = 118 - (alt / 90) * 100;

  return (
    <figure className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
      <figcaption className="text-xs uppercase tracking-widest text-gold">Latitude, measured in the sky</figcaption>
      <div className="mt-4 grid gap-5 sm:grid-cols-[180px_1fr] sm:items-center">
        <svg viewBox="0 0 200 150" className="w-full" role="img" aria-label="Horizon diagram">
          <path d="M20 118 A80 80 0 0 1 180 118" fill="#10161d" stroke="#2c3a48" />
          <line x1="16" y1="118" x2="184" y2="118" stroke="#efe7d6" strokeOpacity="0.45" />
          <text x="100" y="140" textAnchor="middle" fill="#7d8b9c" fontSize="11">
            horizon
          </text>
          {north ? (
            <>
              <circle cx="100" cy={y} r="4" fill="#e2b15a" />
              <text x="112" y={y + 4} fill="#efe7d6" fontSize="11">
                Polaris
              </text>
            </>
          ) : (
            <>
              <circle cx="100" cy={y} r="3" fill="#7d8b9c" />
              <text x="108" y={y - 6} fill="#a7b0bd" fontSize="11">
                south pole
              </text>
            </>
          )}
          <text x="100" y="18" textAnchor="middle" fill="#e2b15a" fontSize="12">
            {alt.toFixed(0)}°
          </text>
        </svg>
        <div>
          <p className="font-display text-2xl text-fg">{north ? `Polaris is ${alt.toFixed(0)}° up` : `Pole is ${alt.toFixed(0)}° up, with no bright star`}</p>
          <p className="mt-2 text-sm text-muted">
            {north
              ? "That angle is your latitude. Slide until it matches the pole star outside — or pick the parallel you actually live on."
              : "South of the equator the north star is below the ground. The south celestial pole stands this high, but Sigma Octantis is too faint to steer by. Use the Southern Cross."}
          </p>
          <label className="mt-4 block text-sm text-muted">
            <span className="flex items-baseline justify-between">
              Latitude
              <span className="font-display text-base text-fg tabular-nums">{formatLat(lat)}</span>
            </span>
            <input
              className="mt-2 w-full"
              type="range"
              min={-60}
              max={70}
              step={1}
              value={lat}
              onChange={(e) => setLat(Number(e.target.value))}
            />
          </label>
        </div>
      </div>
    </figure>
  );
}
