import React, { useState } from 'react';
import { ShieldCheck, Lock, ArrowLeft, AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useStoreData } from '../context/StoreDataContext';

interface AdminLoginViewProps {
  onSuccess: () => void;
  onBackToStore: () => void;
}

export function AdminLoginView({ onSuccess, onBackToStore }: AdminLoginViewProps) {
  const { user, isAdmin, signInWithGoogle, signInWithEmail, logout, refreshAdminStatus } = useAuth();
  const { notify } = useStoreData();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleGoogleAdminSignIn = async () => {
    setErrorMsg('');
    setLoading(true);
    try {
      const signedInUser = await signInWithGoogle();
      const authorized = await refreshAdminStatus(signedInUser);
      if (authorized) {
        notify('Authorized as Fashion Hub Administrator.', 'success');
        onSuccess();
      } else {
        setErrorMsg('This Google account is not authorized for Admin Dashboard access.');
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Admin authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAdminSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    try {
      const signedInUser = await signInWithEmail(email, password);
      const authorized = await refreshAdminStatus(signedInUser);
      if (authorized) {
        notify('Authorized as Fashion Hub Administrator.', 'success');
        onSuccess();
      } else {
        setErrorMsg('This account does not have administrator permissions.');
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Admin sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-[82vh] flex items-center justify-center px-6 py-16 bg-neutral-50">
      <div className="w-full max-w-md bg-white border border-neutral-200 p-8 sm:p-10 shadow-sm">
        <button
          type="button"
          onClick={onBackToStore}
          className="inline-flex items-center gap-1.5 text-xs text-neutral-500 hover:text-[#0A0A0A] mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Storefront</span>
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-[#0A0A0A] text-white flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.2em] text-neutral-500">
              Fashion Hub Management
            </p>
            <h1 className="font-display text-2xl font-semibold text-[#0A0A0A]">
              Admin Portal Login
            </h1>
          </div>
        </div>

        <p className="text-xs text-neutral-600 mb-6 leading-relaxed">
          Sign in with an authorized administrator account verified via Firebase Authentication.
        </p>

        {user && isAdmin ? (
          <div className="space-y-4">
            <div className="p-4 border border-neutral-200 bg-neutral-50 text-xs">
              <p className="font-semibold text-[#0A0A0A]">Active Admin Session</p>
              <p className="text-neutral-600 mt-0.5">{user.email}</p>
            </div>
            <button
              type="button"
              onClick={onSuccess}
              className="w-full py-3.5 px-6 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              Enter Admin Dashboard
            </button>
          </div>
        ) : (
          <>
            {user && !isAdmin && (
              <div className="mb-5 p-3.5 border border-amber-300 bg-amber-50 text-xs text-amber-900 space-y-2">
                <p className="font-semibold">
                  Signed in as {user.email} (Customer Account)
                </p>
                <p>
                  This account is not listed in the authorized admin registry. Sign out to switch to an authorized admin account.
                </p>
                <button
                  type="button"
                  onClick={logout}
                  className="underline font-semibold cursor-pointer"
                >
                  Sign out current account
                </button>
              </div>
            )}

            <button
              type="button"
              disabled={loading}
              onClick={handleGoogleAdminSignIn}
              className="w-full py-3.5 px-6 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer mb-5"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              <span>Sign in with Google Admin Account</span>
            </button>

            <div className="relative flex py-2 items-center mb-5">
              <div className="flex-grow border-t border-neutral-200" />
              <span className="shrink mx-4 text-[11px] uppercase tracking-wider text-neutral-400">
                or admin email
              </span>
              <div className="flex-grow border-t border-neutral-200" />
            </div>

            <form onSubmit={handleEmailAdminSignIn} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Admin Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@company.com"
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>

              {errorMsg && (
                <div className="p-3 border border-red-200 bg-red-50 text-xs text-red-700 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-6 rounded-full border border-[#0A0A0A] text-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                {loading ? 'Verifying...' : 'Sign In to Admin Portal'}
              </button>
            </form>
          </>
        )}
      </div>
    </section>
  );
}
