import React, { useState } from 'react';
import { X, CheckCircle, XCircle, Sparkles, Award, RotateCcw, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { QUIZ_QUESTIONS } from '../data/learningData';
import { QuizQuestion } from '../types/curriculum';
import { sound } from '../utils/sound';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  childName: string;
  onEarnStar: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  isOpen,
  onClose,
  childName,
  onEarnStar,
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentQ: QuizQuestion = QUIZ_QUESTIONS[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;

    setSelectedOption(idx);
    setIsAnswered(true);

    const option = currentQ.options[idx];
    if (option.isCorrect) {
      setIsCorrect(true);
      setScore((s) => s + 1);
      sound.playSuccessSound();
      onEarnStar();

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    } else {
      setIsCorrect(false);
      sound.playPopSound();
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setIsCorrect(false);
    } else {
      setQuizFinished(true);
      sound.playSuccessSound();
      confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.5 },
      });
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
    setScore(0);
    setQuizFinished(false);
  };

  const handleSpeakQuestion = () => {
    sound.speakText(currentQ.questionUrdu, 'ur');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden border-4 border-emerald-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-300" />
            <h3 className="font-urdu text-lg font-bold">
              مزے دار کوئز کلاس برائے {childName} 🎯
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        {!quizFinished ? (
          <div className="p-6 space-y-6">
            {/* Question Progress bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>سوال {currentIdx + 1} از {QUIZ_QUESTIONS.length}</span>
                <span>اسکور: {score} ⭐</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                  style={{ width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Question Box */}
            <div className="bg-emerald-50/80 p-5 rounded-2xl border-2 border-emerald-200 text-center space-y-2">
              <p className="font-urdu text-xl font-black text-emerald-950 leading-relaxed">
                {currentQ.questionUrdu}
              </p>
              <p className="text-xs text-emerald-700 font-sans font-medium">
                {currentQ.questionEnglish}
              </p>
              <button
                onClick={handleSpeakQuestion}
                className="inline-flex items-center gap-1.5 text-xs text-emerald-800 bg-white px-3 py-1 rounded-full shadow-xs hover:bg-emerald-100 cursor-pointer font-bold mt-1"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>سوال کی آواز سنیں</span>
              </button>
            </div>

            {/* Answer Options */}
            <div className="grid grid-cols-1 gap-3">
              {currentQ.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                let btnStyle = 'bg-white border-2 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50';

                if (isAnswered) {
                  if (opt.isCorrect) {
                    btnStyle = 'bg-emerald-500 text-white border-2 border-emerald-600 shadow-lg scale-102';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-500 text-white border-2 border-rose-600';
                  } else {
                    btnStyle = 'bg-slate-50 text-slate-400 border-2 border-slate-200 opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleSelectOption(idx)}
                    className={`p-4 rounded-2xl flex items-center justify-between transition-all duration-200 cursor-pointer ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{opt.emoji}</span>
                      <div className="text-right">
                        <span className="font-urdu text-xl font-bold block">
                          {opt.label}
                        </span>
                        {opt.sublabel && (
                          <span className="text-xs opacity-90 block">
                            {opt.sublabel}
                          </span>
                        )}
                      </div>
                    </div>

                    {isAnswered && (
                      <div>
                        {opt.isCorrect && <CheckCircle className="w-6 h-6 text-white" />}
                        {isSelected && !opt.isCorrect && <XCircle className="w-6 h-6 text-white" />}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation & Next */}
            {isAnswered && (
              <div className="pt-2 flex items-center justify-between">
                <p className="font-urdu text-sm font-bold text-emerald-800">
                  {currentQ.explanationUrdu}
                </p>

                <button
                  onClick={handleNextQuestion}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md cursor-pointer"
                >
                  <span>اگلا سوال ➜</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Finished Screen */
          <div className="p-8 text-center space-y-5">
            <div className="w-24 h-24 mx-auto bg-amber-100 rounded-full flex items-center justify-center text-5xl shadow-inner animate-bounce">
              🏆
            </div>

            <h4 className="font-urdu text-2xl font-black text-slate-800">
              شاباش پیارے {childName}! آپ نے کوئز مکمل کر لیا! 🎉
            </h4>

            <p className="font-urdu text-lg font-bold text-emerald-700">
              آپ کا شاندار اسکور: {score} از {QUIZ_QUESTIONS.length}
            </p>

            <p className="text-xs sm:text-sm text-slate-600">
              استاد میاں بھالو آپ کی محنت سے بہت خوش ہیں! آپ ہمارے ستارے ہیں! 🌟
            </p>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={handleRestart}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs sm:text-sm transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>دوبارہ کھیلیں</span>
              </button>

              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md cursor-pointer"
              >
                <span>کلاس روم واپس جائیں</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
