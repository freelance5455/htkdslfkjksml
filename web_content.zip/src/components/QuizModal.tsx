import React, { useState } from 'react';
import { Question } from '../types';
import { sound } from '../utils/audio';
import { CheckCircle2, XCircle, Sparkles, ArrowLeft, BookOpen } from 'lucide-react';

interface QuizModalProps {
  stationIndex: number;
  question: Question;
  totalStations: number;
  onAnswerComplete: (isCorrect: boolean) => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  stationIndex,
  question,
  totalStations,
  onAnswerComplete,
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);

  const letters = ['A', 'B', 'C', 'D'];
  const isLastQuestion = stationIndex === totalStations - 1;

  const handleSelectAnswer = (index: number) => {
    if (hasSubmitted) return;
    setSelectedAnswer(index);
    setHasSubmitted(true);

    const isCorrect = index === question.c;
    if (isCorrect) {
      sound.play('correct');
    } else {
      sound.play('wrong');
    }
  };

  const handleContinue = () => {
    const isCorrect = selectedAnswer === question.c;
    onAnswerComplete(isCorrect);
  };

  const isCorrect = selectedAnswer === question.c;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#030615d9] backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#142352] to-[#091029] border border-[#68eeff80] shadow-[0_0_40px_rgba(74,109,255,0.25)] p-5 sm:p-7 text-center text-white relative">
        {/* Lab Station Header */}
        <div className="flex items-center justify-between border-b border-[#2d4280] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{hasSubmitted ? (isCorrect ? '🥳' : '🧠') : '🧪'}</span>
            <div className="text-right">
              <span className="text-xs uppercase tracking-wider text-[#ffe18a] font-bold block">
                LAB STATION {String(stationIndex + 1).padStart(2, '0')} / {totalStations}
              </span>
              {question.topic && (
                <span className="text-xs text-slate-400 font-medium">{question.topic}</span>
              )}
            </div>
          </div>

          <div className="text-xs font-bold px-2.5 py-1 rounded-lg bg-[#0e193e] border border-[#4cf5ff4d] text-[#4cf5ff]">
            +100 نقطة
          </div>
        </div>

        {/* Question Text */}
        <div className="text-right my-4">
          <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed font-latin" dir="ltr">
            {question.q}
          </h2>
        </div>

        {/* Answer Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-5" dir="ltr">
          {question.a.map((option, idx) => {
            const isSelected = selectedAnswer === idx;
            const isCorrectOption = idx === question.c;

            let buttonStyle =
              'bg-[#101e45] border-[#4462a8] text-slate-100 hover:border-[#4cf5ff] hover:bg-[#172c63]';

            if (hasSubmitted) {
              if (isCorrectOption) {
                buttonStyle = 'bg-[#084534] border-[#38ef7d] text-white ring-2 ring-[#38ef7d]/50';
              } else if (isSelected && !isCorrectOption) {
                buttonStyle = 'bg-[#521929] border-[#ff5e7e] text-white opacity-90';
              } else {
                buttonStyle = 'bg-[#0b142e] border-slate-700 text-slate-400 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                disabled={hasSubmitted}
                onClick={() => handleSelectAnswer(idx)}
                className={`min-h-[58px] p-3 rounded-2xl border text-left font-latin text-sm font-medium transition-all flex items-start gap-2.5 cursor-pointer disabled:cursor-default ${buttonStyle}`}
              >
                <span className="w-6 h-6 rounded-lg bg-[#081026] border border-current text-xs font-bold flex items-center justify-center shrink-0 text-[#ffe18a]">
                  {letters[idx]}
                </span>
                <span className="leading-snug pt-0.5 flex-1">{option}</span>
                {hasSubmitted && isCorrectOption && (
                  <CheckCircle2 className="w-5 h-5 text-[#38ef7d] shrink-0" />
                )}
                {hasSubmitted && isSelected && !isCorrectOption && (
                  <XCircle className="w-5 h-5 text-[#ff5e7e] shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback & Explanation Box */}
        {hasSubmitted && (
          <div
            className={`p-4 rounded-2xl text-right text-sm leading-relaxed my-4 border ${
              isCorrect
                ? 'bg-[#063328]/90 border-[#38ef7d]/70 text-[#d6ffe9]'
                : 'bg-[#3b1523]/90 border-[#ff6482]/70 text-[#ffe5ea]'
            }`}
          >
            <div className="flex items-center gap-2 mb-2 font-bold text-base">
              {isCorrect ? (
                <>
                  <Sparkles className="w-5 h-5 text-[#ffe18a]" />
                  <span className="text-[#38ef7d]">إجابة صحيحة! أحسنت يا دكتور (+100 نقطة)</span>
                </>
              ) : (
                <>
                  <BookOpen className="w-5 h-5 text-[#ffe18a]" />
                  <span className="text-[#ff7b95]">إجابة غير دقيقة! دعنا نتعلمها معاً</span>
                </>
              )}
            </div>

            <p className="text-slate-100 font-semibold mb-2">
              <strong className="text-[#ffe18a]">💡 الإجابة الصحيحة: </strong>
              <span className="font-latin text-[#4cf5ff]" dir="ltr">
                {question.a[question.c]}
              </span>
            </p>

            <p className="text-slate-200 text-xs sm:text-sm pt-1 border-t border-white/15">
              <strong className="text-[#ffe18a]">الشرح الصيدلي: </strong>
              {question.e}
            </p>
          </div>
        )}

        {/* Action Button */}
        {hasSubmitted && (
          <div className="mt-4 pt-2">
            <button
              onClick={handleContinue}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#4cf5ff] to-[#a38bff] text-[#07112b] font-bold text-base shadow-[0_4px_16px_rgba(76,245,255,0.3)] hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{isLastQuestion ? '🏆 إنهاء المغامرة وحساب النتيجة' : 'فهمت، كمّل مغامرة المعمل'}</span>
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
