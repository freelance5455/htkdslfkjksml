import React, { useState } from 'react';
import { X, CheckCircle2, XCircle, HelpCircle, Sparkles, RefreshCw, Trophy, Lightbulb, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuizQuestion, evaluateQuizScore } from '../utils/quiz-state';
import { TutorPersonaId, AcademicLevel, TUTOR_PERSONAS } from '../utils/tutor-prompts';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTopic?: string;
  currentPersona: TutorPersonaId;
  currentLevel: AcademicLevel;
}

const DEFAULT_QUIZ_QUESTIONS: Record<TutorPersonaId, QuizQuestion[]> = {
  general: [
    {
      id: 'g1',
      question: 'What is the primary function of ribosomes in a biological cell?',
      options: ['DNA replication', 'Protein synthesis', 'Lipid breakdown', 'ATP cellular respiration'],
      correctOptionIndex: 1,
      explanation: 'Ribosomes translate mRNA sequences into polypeptide chains, synthesizing proteins.',
      hint: 'Think about building blocks of enzymes and tissues.',
    },
    {
      id: 'g2',
      question: 'Which cognitive principle describes the tendency to remember the first and last items in a series best?',
      options: ['Serial Position Effect', 'Confirmation Bias', 'Spacing Effect', 'Hedonic Treadmill'],
      correctOptionIndex: 0,
      explanation: 'The Serial Position Effect consists of the primacy effect (first items) and recency effect (last items).',
      hint: 'It refers to the position of items in a serial order.',
    },
  ],
  math: [
    {
      id: 'm1',
      question: 'What is the derivative of f(x) = ln(x) with respect to x?',
      options: ['e^x', '1/x', 'x ln(x)', '1/(x^2)'],
      correctOptionIndex: 1,
      explanation: 'By standard calculus differentiation rules, d/dx[ln(x)] = 1/x for x > 0.',
      hint: 'The rate of change of the natural log is inversely proportional to x.',
    },
    {
      id: 'm2',
      question: 'If a quadratic equation ax² + bx + c = 0 has a discriminant b² - 4ac < 0, what can be concluded about its roots?',
      options: ['Two identical real roots', 'Two distinct real roots', 'Two complex conjugate roots', 'No mathematical solutions exist'],
      correctOptionIndex: 2,
      explanation: 'A negative discriminant results in the square root of a negative number, yielding two complex conjugate roots.',
      hint: 'Think about what happens under the square root in the quadratic formula.',
    },
  ],
  code: [
    {
      id: 'c1',
      question: 'What is the average time complexity of searching an element in a balanced Binary Search Tree (AVL / Red-Black)?',
      options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
      correctOptionIndex: 1,
      explanation: 'Because balanced BSTs halve the search space at each comparison step, the depth and search time are O(log n).',
      hint: 'Every comparison cuts the remaining nodes in half.',
    },
    {
      id: 'c2',
      question: 'In JavaScript / TypeScript, what will `typeof null` evaluate to?',
      options: ['"null"', '"undefined"', '"object"', '"boolean"'],
      correctOptionIndex: 2,
      explanation: 'In JavaScript, `typeof null === "object"` is a famous legacy design quirk dating back to JS version 1.0.',
      hint: 'It is a known historical bug in the language type representation.',
    },
  ],
  science: [
    {
      id: 's1',
      question: 'According to Newton’s Third Law of Motion, action and reaction forces:',
      options: ['Act on the same object and cancel out', 'Act on different interacting objects', 'Occur at different times sequentially', 'Only apply to gravitational systems'],
      correctOptionIndex: 1,
      explanation: 'Action and reaction forces always act on two different interacting bodies, so they never cancel each other out on a single body.',
      hint: 'If you push against a wall, the wall pushes back on your hand.',
    },
    {
      id: 's2',
      question: 'Which subatomic particle directly determines the chemical identity and atomic number of an element?',
      options: ['Neutron', 'Proton', 'Electron', 'Positron'],
      correctOptionIndex: 1,
      explanation: 'The number of protons in an atom’s nucleus uniquely identifies the element and corresponds to its atomic number.',
      hint: 'Found in the nucleus with positive charge.',
    },
  ],
  language: [
    {
      id: 'l1',
      question: 'Which rhetorical device is exemplified by: "Ask not what your country can do for you — ask what you can do for your country"?',
      options: ['Metaphor', 'Chiasmus / Antimetabole', 'Hyperbole', 'Oxymoron'],
      correctOptionIndex: 1,
      explanation: 'Chiasmus (specifically antimetabole) is a figure of speech in which words or grammatical structures are repeated in reverse order.',
      hint: 'The phrase structure reverses like an X or mirror reflection.',
    },
    {
      id: 'l2',
      question: 'What is the role of a clear topic sentence in an academic paragraph?',
      options: ['To provide concluding citations', 'To declare the primary claim or focus of that paragraph', 'To introduce completely unrelated tangents', 'To list opposing rebuttals only'],
      correctOptionIndex: 1,
      explanation: 'A topic sentence establishes the central controlling idea of a paragraph, guiding the reader and structuring arguments.',
      hint: 'It usually appears near the beginning of the paragraph.',
    },
  ],
  history: [
    {
      id: 'h1',
      question: 'Which 1215 document first established the principle that everyone, even the king, is subject to the rule of law?',
      options: ['The Magna Carta', 'The Treaty of Westphalia', 'The Code of Hammurabi', 'The Declaration of the Rights of Man'],
      correctOptionIndex: 0,
      explanation: 'The Magna Carta (Great Charter) was signed at Runnymede in 1215, placing legal limits on royal monarchical power.',
      hint: 'Signed by King John of England.',
    },
    {
      id: 'h2',
      question: 'What was the primary trade network connecting East Asia to the Mediterranean during antiquity and the Middle Ages?',
      options: ['The Trans-Saharan Route', 'The Silk Road', 'The Amber Road', 'The Northwest Passage'],
      correctOptionIndex: 1,
      explanation: 'The Silk Road was an expansive network of Eurasian trade routes facilitating goods, spices, silk, and ideas exchange.',
      hint: 'Named after a luxurious Chinese textile.',
    },
  ],
};

export const QuizModal: React.FC<QuizModalProps> = ({
  isOpen,
  onClose,
  initialTopic = '',
  currentPersona,
  currentLevel,
}) => {
  const defaultSubjectName = TUTOR_PERSONAS[currentPersona]?.name || 'General Science & Logic';
  const [topic, setTopic] = useState(initialTopic || defaultSubjectName);
  const [questions, setQuestions] = useState<QuizQuestion[]>(
    DEFAULT_QUIZ_QUESTIONS[currentPersona] || DEFAULT_QUIZ_QUESTIONS.general
  );
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showHints, setShowHints] = useState<Record<string, boolean>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [validationWarning, setValidationWarning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerateQuiz = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const targetTopic = topic.trim() || defaultSubjectName;

    setIsGenerating(true);
    setError(null);
    setQuizSubmitted(false);
    setSelectedAnswers({});
    setShowHints({});
    setValidationWarning(null);

    try {
      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: targetTopic,
          persona: currentPersona,
          level: currentLevel,
          count: 4,
        }),
      });

      if (!res.ok) throw new Error('Failed to generate quiz');

      const data = await res.json();
      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
      }
    } catch (err: any) {
      console.error(err);
      setError('Using curated subject questions for this practice session.');
      setQuestions(DEFAULT_QUIZ_QUESTIONS[currentPersona] || DEFAULT_QUIZ_QUESTIONS.general);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (quizSubmitted) return;
    setValidationWarning(null);
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex,
    }));
  };

  const toggleHint = (questionId: string) => {
    setShowHints((prev) => ({
      ...prev,
      [questionId]: !prev[questionId],
    }));
  };

  const handleSubmitQuiz = () => {
    // Check if any question is unanswered
    const unansweredIndex = questions.findIndex((q) => selectedAnswers[q.id] === undefined);
    if (unansweredIndex !== -1) {
      setValidationWarning(`Please answer Question ${unansweredIndex + 1} before submitting.`);
      return;
    }

    setQuizSubmitted(true);
    setValidationWarning(null);
    const summary = evaluateQuizScore(selectedAnswers, questions);
    if (summary.percentage >= 70) {
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // Fallback
      }
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setShowHints({});
    setQuizSubmitted(false);
    setValidationWarning(null);
  };

  const summary = evaluateQuizScore(selectedAnswers, questions);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Practice Quiz Arena</h3>
              <p className="text-[11px] text-slate-500">Active recall & conceptual mastery checks</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close quiz dialog"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Generate topic bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <form onSubmit={handleGenerateQuiz} className="flex gap-2">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter any topic to generate a quiz (e.g. Organic Chemistry, Calculus)"
              aria-label="Quiz topic input"
              className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-2xs"
            />
            <button
              type="submit"
              disabled={isGenerating}
              aria-label="Generate quiz questions"
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 transition shrink-0 shadow-2xs cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate</span>
                </>
              )}
            </button>
          </form>
          {error && <p className="text-xs text-indigo-700 mt-2 font-medium">{error}</p>}
        </div>

        {/* Quiz Questions List */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {quizSubmitted && (
            <div
              className={`p-4 rounded-xl border flex items-center justify-between ${
                summary.percentage >= 70
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Trophy className="w-6 h-6 text-amber-500 shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">
                    Score: {summary.correct} / {summary.total} ({summary.percentage}%)
                  </h4>
                  <p className="text-xs mt-0.5">{summary.feedbackMessage}</p>
                </div>
              </div>
              <button
                onClick={handleReset}
                aria-label="Try quiz again"
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition cursor-pointer"
              >
                Try Again
              </button>
            </div>
          )}

          {questions.map((q, qIndex) => {
            const userAnswer = selectedAnswers[q.id];
            const isAnswered = userAnswer !== undefined;

            return (
              <div
                key={q.id || qIndex}
                className="border border-slate-200 rounded-xl p-4 bg-white shadow-2xs"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start space-x-2">
                    <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {qIndex + 1}
                    </span>
                    <h4 className="text-sm font-semibold text-slate-800 leading-snug">
                      {q.question}
                    </h4>
                  </div>

                  {q.hint && !quizSubmitted && (
                    <button
                      type="button"
                      onClick={() => toggleHint(q.id)}
                      aria-label={showHints[q.id] ? 'Hide hint' : 'Show hint'}
                      className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center space-x-1 shrink-0 ml-2 cursor-pointer"
                    >
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span>{showHints[q.id] ? 'Hide Hint' : 'Hint'}</span>
                    </button>
                  )}
                </div>

                {showHints[q.id] && q.hint && !quizSubmitted && (
                  <div className="mb-3 p-2.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-xs text-indigo-800 italic">
                    💡 <strong>Hint:</strong> {q.hint}
                  </div>
                )}

                {/* Options rendered as native interactive buttons */}
                <div className="space-y-2">
                  {q.options.map((opt, optIndex) => {
                    const isSelected = userAnswer === optIndex;
                    let optionClasses =
                      'w-full text-left p-3 rounded-lg border text-xs font-medium transition cursor-pointer flex items-center justify-between ';

                    if (quizSubmitted) {
                      if (optIndex === q.correctOptionIndex) {
                        optionClasses += 'bg-emerald-50 border-emerald-400 text-emerald-900';
                      } else if (isSelected) {
                        optionClasses += 'bg-rose-50 border-rose-300 text-rose-800';
                      } else {
                        optionClasses += 'bg-slate-50/60 border-slate-200 text-slate-500 opacity-60';
                      }
                    } else {
                      if (isSelected) {
                        optionClasses += 'bg-indigo-50 border-indigo-500 text-indigo-950 font-semibold shadow-2xs ring-1 ring-indigo-400';
                      } else {
                        optionClasses += 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300';
                      }
                    }

                    return (
                      <button
                        type="button"
                        key={optIndex}
                        onClick={() => handleSelectOption(q.id, optIndex)}
                        aria-label={`Select Option ${String.fromCharCode(65 + optIndex)}: ${opt}`}
                        className={optionClasses}
                      >
                        <div className="flex items-center space-x-2.5">
                          <span className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] font-mono font-semibold ${
                            isSelected ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-300 text-slate-500'
                          }`}>
                            {String.fromCharCode(65 + optIndex)}
                          </span>
                          <span>{opt}</span>
                        </div>
                        {quizSubmitted && optIndex === q.correctOptionIndex && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        )}
                        {quizSubmitted && isSelected && optIndex !== q.correctOptionIndex && (
                          <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Explanation on submit */}
                {quizSubmitted && (
                  <div className="mt-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700">
                    <p className="font-semibold text-slate-800 mb-0.5">Explanation:</p>
                    <p>{q.explanation}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Validation warning if user clicks Submit before completing */}
        {validationWarning && (
          <div className="px-4 py-2 bg-amber-50 border-t border-amber-200 text-amber-800 text-xs font-medium flex items-center space-x-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>{validationWarning}</span>
          </div>
        )}

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500 font-medium">
            {Object.keys(selectedAnswers).length} of {questions.length} answered
          </div>
          <div className="flex items-center space-x-2">
            {!quizSubmitted ? (
              <button
                type="button"
                onClick={handleSubmitQuiz}
                aria-label="Submit quiz answers"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition shadow-2xs cursor-pointer"
              >
                Submit Answers
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                aria-label="Close quiz"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition shadow-2xs cursor-pointer"
              >
                Done
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
