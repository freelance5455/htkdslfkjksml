import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Building2, CreditCard, Plus, Trash2, CheckCircle2, ShieldCheck, Wallet, Sparkles, AlertCircle } from 'lucide-react';

export interface PayoutMethod {
  id: string;
  type: 'bank' | 'crypto';
  title: string;
  detail: string;
  holderName: string;
  isDefault: boolean;
}

interface PayoutMethodManagerProps {
  onSelectMethod?: (method: PayoutMethod) => void;
  onShowToast?: (msg: string) => void;
}

const DEFAULT_PAYOUT_METHODS: PayoutMethod[] = [
  {
    id: 'pm-1',
    type: 'bank',
    title: 'Opay Mobile Bank',
    detail: '7071918280',
    holderName: 'JUHNKRIX STEPHEN',
    isDefault: true
  },
  {
    id: 'pm-2',
    type: 'crypto',
    title: 'Bitcoin Altar Vault',
    detail: 'bc1qjuhnkrixaltarvaultbitcoin999777888',
    holderName: 'Prophet JUHNKRIX SYNVAGORD',
    isDefault: true
  }
];

export const PayoutMethodManager: React.FC<PayoutMethodManagerProps> = ({ onSelectMethod, onShowToast }) => {
  const [methods, setMethods] = useState<PayoutMethod[]>(() => {
    const saved = localStorage.getItem('juhnkrix_payout_methods');
    return saved ? JSON.parse(saved) : DEFAULT_PAYOUT_METHODS;
  });

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [methodType, setMethodType] = useState<'bank' | 'crypto'>('bank');
  const [titleInput, setTitleInput] = useState<string>('');
  const [detailInput, setDetailInput] = useState<string>('');
  const [holderInput, setHolderInput] = useState<string>('JUHNKRIX STEPHEN');

  useEffect(() => {
    localStorage.setItem('juhnkrix_payout_methods', JSON.stringify(methods));
  }, [methods]);

  const handleAddMethod = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleInput || !detailInput) {
      onShowToast?.('❌ Please fill in all payout account details.');
      return;
    }

    const newMethod: PayoutMethod = {
      id: `pm-${Date.now()}`,
      type: methodType,
      title: titleInput,
      detail: detailInput,
      holderName: holderInput || 'JUHNKRIX STEPHEN',
      isDefault: methods.length === 0
    };

    setMethods([...methods, newMethod]);
    setShowAddModal(false);
    setTitleInput('');
    setDetailInput('');
    onShowToast?.(`✓ Added new ${methodType === 'bank' ? 'bank account' : 'crypto wallet'} payout destination!`);
  };

  const handleDelete = (id: string) => {
    setMethods(methods.filter(m => m.id !== id));
    onShowToast?.('✓ Payout destination removed.');
  };

  const handleSetDefault = (id: string) => {
    setMethods(methods.map(m => ({
      ...m,
      isDefault: m.id === id ? true : m.type === methods.find(x => x.id === id)?.type ? false : m.isDefault
    })));
    onShowToast?.('✓ Default payout destination updated.');
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-lg">
            <Building2 className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/30">
                SECURE FAST WITHDRAWALS
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 mt-1">
              Payout Method Manager
            </h3>
            <p className="text-xs text-slate-400">
              Save and manage multiple bank accounts and crypto wallet addresses for one-click fast withdrawals.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black flex items-center space-x-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Add Payout Destination</span>
        </button>
      </div>

      {/* Methods List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {methods.map((m) => (
          <div
            key={m.id}
            className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
              m.isDefault
                ? 'bg-gradient-to-br from-slate-900 to-amber-950/30 border-amber-500/50 shadow-lg shadow-amber-500/10'
                : 'bg-slate-950/80 border-slate-800 hover:border-amber-500/30'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className={`p-2.5 rounded-xl border ${m.type === 'bank' ? 'bg-amber-500/20 text-amber-300 border-amber-400/30' : 'bg-purple-500/20 text-purple-300 border-purple-400/30'}`}>
                  {m.type === 'bank' ? <Building2 className="w-5 h-5" /> : <Wallet className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="text-sm font-bold text-amber-100">{m.title}</h4>
                    {m.isDefault && (
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500 text-slate-950">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-mono text-amber-300/80 truncate max-w-[240px] mt-0.5">{m.detail}</p>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                {!m.isDefault && (
                  <button
                    onClick={() => handleSetDefault(m.id)}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 text-xs transition-colors"
                    title="Set as Default"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => handleDelete(m.id)}
                  className="p-1.5 rounded-lg bg-slate-900 hover:bg-rose-950/50 text-slate-400 hover:text-rose-300 text-xs transition-colors"
                  title="Delete Destination"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-[11px]">
              <span className="text-slate-400">Account Holder: <strong className="text-slate-200">{m.holderName}</strong></span>
              <button
                onClick={() => {
                  onSelectMethod?.(m);
                  onShowToast?.(`✓ Selected "${m.title}" for withdrawal!`);
                }}
                className="px-3 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold border border-amber-500/30 transition-colors"
              >
                Use for Withdraw
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Method Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-6 text-left"
          >
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
              <h3 className="text-lg font-bold font-serif text-amber-100 flex items-center space-x-2">
                <Plus className="w-5 h-5 text-amber-400" />
                <span>Add Payout Destination</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-amber-200 text-xs font-bold"
              >
                ✕ Close
              </button>
            </div>

            <form onSubmit={handleAddMethod} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Destination Type</label>
                <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setMethodType('bank')}
                    className={`flex-1 py-2 rounded-lg font-bold transition-all ${methodType === 'bank' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-amber-200'}`}
                  >
                    Bank Account
                  </button>
                  <button
                    type="button"
                    onClick={() => setMethodType('crypto')}
                    className={`flex-1 py-2 rounded-lg font-bold transition-all ${methodType === 'crypto' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-amber-200'}`}
                  >
                    Crypto Wallet
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  {methodType === 'bank' ? 'Bank Name & Branch' : 'Crypto Network / Currency'}
                </label>
                <input
                  type="text"
                  required
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  placeholder={methodType === 'bank' ? 'e.g., Opay, GTBank, FirstBank' : 'e.g., Bitcoin Mainnet / USDT TRC20'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  {methodType === 'bank' ? 'Account Number' : 'Wallet Address'}
                </label>
                <input
                  type="text"
                  required
                  value={detailInput}
                  onChange={(e) => setDetailInput(e.target.value)}
                  placeholder={methodType === 'bank' ? '7071918280' : 'bc1q... or 0x...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Account / Beneficiary Holder Name</label>
                <input
                  type="text"
                  required
                  value={holderInput}
                  onChange={(e) => setHolderInput(e.target.value)}
                  placeholder="JUHNKRIX STEPHEN"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2 flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black shadow-lg shadow-amber-500/20 cursor-pointer"
                >
                  Save Payout Destination
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};
