import React, { useEffect } from 'react';
import { DialogueNode, Language, CharacterId } from '../types/game';
import { soundEngine } from '../audio/soundSystem';

interface DialogueModalProps {
  dialogueList: DialogueNode[];
  currentIndex: number;
  language: Language;
  onNext: () => void;
  onSelectChoice: (choiceId: string, nextIndex: number, points?: number) => void;
  onClose: () => void;
}

const CHARACTER_PROFILES: Record<
  CharacterId,
  { emoji: string; color: string; border: string; bg: string; title: string }
> = {
  ayush: {
    emoji: '🧢',
    color: 'text-sky-400',
    border: 'border-sky-400',
    bg: 'bg-sky-950/90',
    title: 'Ayush (Hero)',
  },
  arav: {
    emoji: '🏏',
    color: 'text-orange-400',
    border: 'border-orange-400',
    bg: 'bg-orange-950/90',
    title: 'Arav (Brother)',
  },
  akshhara: {
    emoji: '🎀',
    color: 'text-pink-400',
    border: 'border-pink-400',
    bg: 'bg-pink-950/90',
    title: 'Akshhara (Sister)',
  },
  ripin: {
    emoji: '👓',
    color: 'text-blue-300',
    border: 'border-blue-400',
    bg: 'bg-blue-950/90',
    title: 'Mr. Ripin (Papa)',
  },
  anjeeta: {
    emoji: '🪔',
    color: 'text-amber-400',
    border: 'border-amber-400',
    bg: 'bg-amber-950/90',
    title: 'Mrs. Anjeeta (Mummy)',
  },
};

export const DialogueModal: React.FC<DialogueModalProps> = ({
  dialogueList,
  currentIndex,
  language,
  onNext,
  onSelectChoice,
}) => {
  const node = dialogueList[currentIndex];

  useEffect(() => {
    if (node) {
      soundEngine.playSpeechBlip(node.speaker);
    }
  }, [currentIndex, node]);

  if (!node) return null;

  const profile = CHARACTER_PROFILES[node.speaker] || CHARACTER_PROFILES.ayush;
  const speakerName = node.speakerName[language];
  const dialogueText = node.text[language];
  const choices = node.choices;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center pb-8 px-4 pointer-events-auto bg-black/40 animate-fade-in">
      <div
        className={`w-full max-w-2xl ${profile.bg} border-2 ${profile.border} rounded-3xl p-5 shadow-2xl relative text-white`}
      >
        {/* Character Header Badge */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-2xl bg-black/40 border-2 ${profile.border} flex items-center justify-center text-2xl shadow-md`}
            >
              {profile.emoji}
            </div>
            <div>
              <div className={`text-lg font-bold ${profile.color}`}>{speakerName}</div>
              <div className="text-xs text-slate-400 font-medium">{profile.title}</div>
            </div>
          </div>

          <div className="text-xs font-semibold px-3 py-1 bg-white/10 rounded-full text-slate-300">
            {currentIndex + 1} / {dialogueList.length}
          </div>
        </div>

        {/* Dialogue Bubble Text */}
        <div className="text-base md:text-lg font-medium leading-relaxed min-h-[60px] text-slate-100">
          "{dialogueText}"
        </div>

        {/* Choice Options (e.g. Sibling Dispute Arbitration) */}
        {choices && choices.length > 0 ? (
          <div className="mt-4 flex flex-col gap-2">
            <div className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-1">
              {language === 'hinglish' ? 'Apna decision chuno:' : 'Choose your response:'}
            </div>
            {choices.map((c) => (
              <button
                key={c.id}
                onClick={() => onSelectChoice(c.id, c.nextIndex, c.points)}
                className="w-full text-left p-3 rounded-2xl bg-amber-500/20 hover:bg-amber-500/35 active:scale-[0.99] border border-amber-400/50 text-amber-100 hover:text-white font-semibold transition-all text-sm md:text-base flex items-center justify-between shadow-md"
              >
                <span>{c.label[language]}</span>
                <span className="text-xs bg-amber-400 text-slate-950 font-bold px-2 py-1 rounded-lg">
                  SELECT
                </span>
              </button>
            ))}
          </div>
        ) : (
          /* Continue / Next Button */
          <div className="mt-4 flex justify-end">
            <button
              onClick={onNext}
              className="px-6 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-extrabold shadow-lg transition-transform flex items-center gap-2 text-sm md:text-base border border-amber-300"
            >
              <span>{currentIndex + 1 >= dialogueList.length ? (language === 'hinglish' ? 'Khel Shuru!' : 'Start Mission!') : (language === 'hinglish' ? 'Aage Badho' : 'Continue')}</span>
              <span>➔</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
