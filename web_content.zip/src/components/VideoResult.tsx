import React, { useState } from 'react';
import { TikTokVideoData, SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { formatNumber, formatDuration, downloadMediaFile } from '../services/tiktokService';
import { 
  Download, 
  Music, 
  Sparkles, 
  RotateCcw, 
  Heart, 
  MessageCircle, 
  Share2, 
  Eye, 
  Image as ImageIcon,
  CheckCircle2,
  ExternalLink,
  Volume2,
  Copy,
  Check
} from 'lucide-react';
import { AdBanner } from './AdBanner';
import { InterstitialAdModal } from './InterstitialAdModal';

interface VideoResultProps {
  videoData: TikTokVideoData;
  currentLang: SupportedLanguage;
  onReset: () => void;
}

export const VideoResult: React.FC<VideoResultProps> = ({
  videoData,
  currentLang,
  onReset,
}) => {
  const [downloadingType, setDownloadingType] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [copiedLink, setCopiedLink] = useState(false);
  const [pendingDownload, setPendingDownload] = useState<{
    url: string;
    filename: string;
    typeKey: string;
  } | null>(null);
  const [isAdOpen, setIsAdOpen] = useState(false);
  const t = translations[currentLang];

  const executeActualDownload = async (url: string, filename: string, typeKey: string) => {
    try {
      setDownloadingType(typeKey);
      setDownloadProgress(20);
      await downloadMediaFile(url, filename, (pct) => setDownloadProgress(pct));
      setTimeout(() => {
        setDownloadingType(null);
        setDownloadProgress(0);
      }, 1500);
    } catch {
      // Direct open in new tab fallback
      window.open(url, '_blank');
      setDownloadingType(null);
      setDownloadProgress(0);
    }
  };

  const handleDownload = (url: string, filename: string, typeKey: string) => {
    setPendingDownload({ url, filename, typeKey });
    setIsAdOpen(true);
  };

  const handleAdFinished = () => {
    if (pendingDownload) {
      executeActualDownload(pendingDownload.url, pendingDownload.filename, pendingDownload.typeKey);
      setPendingDownload(null);
    }
  };

  const handleCopyLink = () => {
    const shareUrl = `https://www.tiktok.com/@${videoData.author?.unique_id}/video/${videoData.id}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const isSlideShow = Boolean(videoData.images && videoData.images.length > 0);
  const videoStreamUrl = videoData.play || videoData.hdplay || '';

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 mb-16 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="bg-slate-900/90 border border-slate-700/80 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-cyan-950/40 backdrop-blur-xl">
        
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-800 gap-4 mb-6">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src={videoData.author?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120'}
                alt={videoData.author?.nickname || 'Creator'}
                className="w-13 h-13 rounded-full border-2 border-cyan-400 object-cover shadow-md"
              />
              <div className="absolute -bottom-1 -right-1 bg-cyan-500 rounded-full p-0.5 text-white">
                <CheckCircle2 className="w-3.5 h-3.5 fill-cyan-400 text-slate-900" />
              </div>
            </div>
            <div>
              <h3 className="font-bold text-white text-base sm:text-lg flex items-center gap-1.5">
                {videoData.author?.nickname || 'TikTok User'}
              </h3>
              <p className="text-xs sm:text-sm text-cyan-400 font-medium">
                @{videoData.author?.unique_id || 'user'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
              title="Copy TikTok link"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
            </button>

            <button
              onClick={onReset}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700/80 transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.searchAnother}</span>
            </button>
          </div>
        </div>

        {/* Video & Download Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start">
          
          {/* Media Preview Column */}
          <div className="md:col-span-5 flex flex-col items-center">
            {isSlideShow ? (
              <div className="w-full">
                <div className="text-xs font-semibold text-cyan-400 mb-2 flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Photo Slideshow ({videoData.images?.length} photos)</span>
                </div>
                <div className="rounded-2xl overflow-hidden bg-black aspect-[9/16] max-h-[440px] w-full border border-slate-800 relative shadow-inner">
                  <img
                    src={videoData.images?.[0]}
                    alt="TikTok slide"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            ) : (
              <div className="w-full">
                <div className="rounded-2xl overflow-hidden bg-black aspect-[9/16] max-h-[450px] w-full border border-slate-800 shadow-2xl relative flex items-center justify-center">
                  <video
                    src={videoStreamUrl}
                    poster={videoData.cover}
                    controls
                    playsInline
                    preload="metadata"
                    className="w-full h-full object-contain"
                  >
                    Your browser does not support the video tag.
                  </video>
                </div>
                {videoData.duration > 0 && (
                  <div className="mt-2 text-center text-xs text-slate-400">
                    Duration: <span className="text-slate-200 font-medium">{formatDuration(videoData.duration)}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Details & Actions Column */}
          <div className="md:col-span-7 flex flex-col justify-between h-full space-y-6">
            
            {/* Caption / Title */}
            <div>
              <h4 className="text-xs uppercase font-bold tracking-wider text-slate-400 mb-2">
                Video Title & Description
              </h4>
              <p className="text-sm text-slate-200 bg-slate-950/70 p-4 rounded-xl border border-slate-800/90 leading-relaxed max-h-32 overflow-y-auto">
                {videoData.title || '(No caption provided for this video)'}
              </p>
            </div>

            {/* Video Stats Cards */}
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/70">
                <Heart className="w-4 h-4 text-rose-500 mx-auto mb-1" />
                <div className="text-[11px] text-slate-400">Likes</div>
                <div className="text-xs sm:text-sm font-bold text-white">{formatNumber(videoData.digg_count)}</div>
              </div>
              <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/70">
                <MessageCircle className="w-4 h-4 text-sky-400 mx-auto mb-1" />
                <div className="text-[11px] text-slate-400">Comments</div>
                <div className="text-xs sm:text-sm font-bold text-white">{formatNumber(videoData.comment_count)}</div>
              </div>
              <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/70">
                <Share2 className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                <div className="text-[11px] text-slate-400">Shares</div>
                <div className="text-xs sm:text-sm font-bold text-white">{formatNumber(videoData.share_count)}</div>
              </div>
              <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/70">
                <Eye className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                <div className="text-[11px] text-slate-400">Plays</div>
                <div className="text-xs sm:text-sm font-bold text-white">{formatNumber(videoData.play_count)}</div>
              </div>
            </div>

            {/* Audio info if available */}
            {videoData.music_info && (
              <div className="flex items-center gap-2.5 bg-slate-950/50 p-3 rounded-xl border border-slate-800/70 text-xs text-slate-300">
                <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="truncate">
                  Audio: <strong className="text-white">{videoData.music_info.title || 'Original Sound'}</strong> - {videoData.music_info.author}
                </span>
              </div>
            )}

            {/* Download Progress Bar */}
            {downloadingType && (
              <div className="bg-slate-950 p-3 rounded-xl border border-cyan-500/40">
                <div className="flex justify-between text-xs text-cyan-300 mb-1 font-semibold">
                  <span>Saving {downloadingType}...</span>
                  <span>{downloadProgress}%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-200"
                    style={{ width: `${downloadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Google Ad Unit 2: 1065264026 */}
            <AdBanner slotId="1065264026" client="ca-app-pub-9247061906860945" className="my-3" />

            {/* Download Buttons Section */}
            <div className="space-y-3 pt-1">
              {/* Button 1: Without Watermark (Primary MP4) */}
              {videoData.play && (
                <button
                  onClick={() =>
                    handleDownload(
                      videoData.play,
                      `tiktok_${videoData.author?.unique_id || 'video'}_nowatermark.mp4`,
                      'No Watermark Video'
                    )
                  }
                  className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:via-sky-400 hover:to-blue-500 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all duration-200 active:scale-98 cursor-pointer"
                >
                  <Download className="w-5 h-5" />
                  <span>{t.noWatermark}</span>
                </button>
              )}

              {/* Button 2: Without Watermark (HD) */}
              {videoData.hdplay && (
                <button
                  onClick={() =>
                    handleDownload(
                      videoData.hdplay!,
                      `tiktok_${videoData.author?.unique_id || 'video'}_hd.mp4`,
                      'HD Video'
                    )
                  }
                  className="w-full py-3.5 px-5 rounded-2xl bg-slate-800/90 hover:bg-slate-700/90 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 transition cursor-pointer"
                >
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  <span>{t.downloadHd}</span>
                  <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    1080p Full HD
                  </span>
                </button>
              )}

              {/* Button 3: Download MP3 */}
              {videoData.music && (
                <button
                  onClick={() =>
                    handleDownload(
                      videoData.music!,
                      `tiktok_audio_${videoData.author?.unique_id || 'sound'}.mp3`,
                      'MP3 Audio'
                    )
                  }
                  className="w-full py-3 px-5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 hover:border-emerald-500/40 text-emerald-300 font-semibold text-sm flex items-center justify-center gap-2.5 transition cursor-pointer"
                >
                  <Music className="w-4 h-4 text-emerald-400" />
                  <span>{t.downloadMp3}</span>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    MP3 320kbps
                  </span>
                </button>
              )}

              {/* Button 4: Cover Image */}
              {videoData.cover && (
                <button
                  onClick={() =>
                    handleDownload(
                      videoData.cover,
                      `tiktok_cover_${videoData.id}.jpg`,
                      'Cover Photo'
                    )
                  }
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-300 font-medium text-xs flex items-center justify-center gap-2 border border-slate-800 transition cursor-pointer"
                >
                  <ImageIcon className="w-4 h-4 text-slate-400" />
                  <span>{t.downloadCover}</span>
                </button>
              )}
            </div>

            {/* If slideshow: list all individual photos */}
            {isSlideShow && videoData.images && (
              <div className="pt-4 border-t border-slate-800">
                <h5 className="text-xs font-bold text-slate-300 mb-3 uppercase tracking-wider">
                  Download All Slideshow Photos ({videoData.images.length})
                </h5>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-48 overflow-y-auto pr-1">
                  {videoData.images.map((imgUrl, i) => (
                    <div key={i} className="group relative rounded-xl overflow-hidden aspect-square border border-slate-800 bg-slate-950">
                      <img src={imgUrl} alt={`Slide ${i + 1}`} className="w-full h-full object-cover" />
                      <button
                        onClick={() => handleDownload(imgUrl, `tiktok_slide_${i + 1}.jpg`, `Image ${i + 1}`)}
                        className="absolute inset-0 bg-slate-950/80 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-cyan-300 text-xs font-bold transition cursor-pointer"
                      >
                        <Download className="w-4 h-4 mb-1" />
                        <span>Save #{i + 1}</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Google Interstitial Ad on Download Click */}
      <InterstitialAdModal
        isOpen={isAdOpen}
        adSlotId="3882999054"
        publisherId="ca-app-pub-9247061906860945"
        onClose={() => setIsAdOpen(false)}
        onAdCompleted={handleAdFinished}
        title="Your TikTok Video is preparing... Please watch this short ad to support free downloads."
      />
    </section>
  );
};
