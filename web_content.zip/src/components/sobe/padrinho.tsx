import { useMemo, useState } from "react";
import { Badge, Button, Card, Field, NeedHistory, TextArea, TextInput } from "@/components/sobe/bits";
import { PigChart } from "@/components/sobe/charts";
import { denomInfo, lineValueCents, normalizeLines, summarize } from "@/lib/finance/denoms";
import { latestSnapshot, pigSeries } from "@/lib/finance/engine";
import { SOURCE_LABEL } from "@/lib/finance/labels";
import { formatCents, formatDate, formatRangeCents, todayISO } from "@/lib/finance/money";
import { mergeImport, parseAnnotations } from "@/lib/finance/parser";
import { addCashMovement, pushSnapshot, useFinance } from "@/lib/finance/store";
import type { DenomLine, Endpoint } from "@/lib/finance/types";

export function PadrinhoPage() {
  const data = useFinance((state) => state.data);
  const snap = latestSnapshot(data);
  const lines = snap ? normalizeLines(snap.lines) : normalizeLines([]);
  const summary = summarize(lines);
  const [mode, setMode] = useState<"view" | "count" | "import" | "pieces">("view");

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm text-muted">Cofrinho físico</p>
            <h1 className="font-display text-4xl">Meu Padrinho</h1>
          </div>
          <Badge state={snap?.status === "confirmed" && summary.complete ? "confirmed" : snap?.status === "estimated" ? "estimated" : "partial"} />
        </div>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
          {snap?.status === "estimated"
            ? "Valor estimado, aguardando conferência física. A faixa das moedas de R$ 1 não foi arredondada. O que não foi anotado continua em branco — branco não é zero."
            : "A última leitura está abaixo. Uma nova contagem guarda a anterior no histórico."}
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Info label="Valor estimado nas peças conhecidas" value={summary.minCents === 0 && summary.hasUnknown && summary.maxCents === 0 ? "Ainda desconhecido" : formatRangeCents(summary.minCents, summary.maxCents)} />
          <Info label="Valor confirmado" value={snap?.status === "confirmed" && summary.complete ? formatCents(summary.minCents) : "Pendente da próxima contagem física"} />
          <Info label="Moedas conhecidas" value={summary.coinPiecesMin === summary.coinPiecesMax ? String(summary.coinPiecesMin) : `${summary.coinPiecesMin} a ${summary.coinPiecesMax}`} />
          <Info label="Cédulas conhecidas" value={summary.notePiecesMin === summary.notePiecesMax ? String(summary.notePiecesMin) : `${summary.notePiecesMin} a ${summary.notePiecesMax}`} />
          <Info label="Peças conhecidas" value={summary.pieceMin === summary.pieceMax ? String(summary.pieceMin) : `${summary.pieceMin} a ${summary.pieceMax}`} />
          <Info label="Origem" value={snap ? SOURCE_LABEL[snap.source] : "Nenhuma"} />
        </div>
        {summary.hasUnknown ? <p className="mt-3 text-sm text-muted">Denominações sem contagem ficam fora da soma. O total pode ser maior.</p> : null}
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="primary" onClick={() => setMode("pieces")}>Adicionar ou retirar</Button>
          <Button onClick={() => setMode("count")}>Nova contagem</Button>
          <Button onClick={() => setMode("import")}>Importar anotações</Button>
        </div>
      </Card>

      {mode === "pieces" ? <PiecesForm lines={lines} status={snap?.status ?? "estimated"} onClose={() => setMode("view")} /> : null}
      {mode === "count" ? <CountForm lines={lines} onClose={() => setMode("view")} /> : null}
      {mode === "import" ? <ImportForm lines={lines} onClose={() => setMode("view")} /> : null}

      <Card>
        <h2 className="mb-3 font-display text-xl">Peças</h2>
        <div className="grid gap-2">
          {lines.map((line) => {
            const value = lineValueCents(line);
            const info = denomInfo(line.faceCents);
            const qty = line.status === "exact" ? String(line.quantity) : line.status === "range" ? `${line.min} a ${line.max}` : "não contada";
            return (
              <div key={line.faceCents} className="grid grid-cols-[1fr_auto] items-center gap-3 border-b border-line py-2 text-sm">
                <div>
                  <p>{info.kind === "moeda" ? "Moeda" : "Cédula"} {info.label}</p>
                  <p className="text-muted">{qty === "não contada" ? "Quantidade desconhecida" : `${qty} ${info.kind === "moeda" ? "moedas" : "cédulas"}`}</p>
                </div>
                <p>{value ? formatRangeCents(value.min, value.max) : "fora do total"}</p>
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 font-display text-xl">Evolução</h2>
        <PigChart points={pigSeries(data.padrinhoSnapshots)} />
      </Card>

      <Card>
        <h2 className="mb-3 font-display text-xl">Histórico de contagens</h2>
        <div className="grid gap-3">
          {data.padrinhoSnapshots.slice().reverse().map((item, index, all) => {
            const current = summarize(item.lines);
            const older = all[index + 1];
            const before = older ? summarize(older.lines) : null;
            const bothExact = before && current.exact && before.exact && !current.hasUnknown && !before.hasUnknown;
            return (
              <article key={item.id} className="rounded-2xl border border-line p-3">
                <p className="text-sm text-muted">{formatDate(item.date)} · {SOURCE_LABEL[item.source]} · {item.status === "confirmed" ? "contagem" : "estimativa"}</p>
                <p className="mt-1 font-display text-2xl">{current.minCents === 0 && current.hasUnknown && current.maxCents === 0 ? "Sem total" : formatRangeCents(current.minCents, current.maxCents)}</p>
                {bothExact ? <p className="text-sm text-muted">Diferença para a leitura anterior: {formatCents(current.minCents - before.minCents)}. Isso é ajuste de contagem, não rendimento.</p> : before ? <p className="text-sm text-muted">Antes: {formatRangeCents(before.minCents, before.maxCents)}. Sem diferença única porque havia faixa ou peça em branco.</p> : null}
                {item.note ? <p className="mt-2 text-sm leading-relaxed text-muted">{item.note}</p> : null}
              </article>
            );
          })}
        </div>
      </Card>
      <NeedHistory>
        A primeira leitura guardada é a das suas anotações: cédulas de 20 somavam R$ 100 (5 notas), de 10 somavam R$ 340 (34), de 5 somavam R$ 220 (44), de 2 somavam R$ 70 (35), moedas de R$ 1 entre R$ 180 e R$ 200, de 50 centavos R$ 100 (200 moedas) e de 25 centavos R$ 20 (80 moedas).
      </NeedHistory>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 text-lg">{value}</p>
    </div>
  );
}

function PiecesForm({ lines, status, onClose }: { lines: DenomLine[]; status: "estimated" | "confirmed"; onClose: () => void }) {
  const commit = useFinance((state) => state.commit);
  const exact = lines.filter((line) => line.status === "exact");
  const [face, setFace] = useState(exact[0]?.faceCents ?? 100);
  const [qty, setQty] = useState("1");
  const [dir, setDir] = useState<"add" | "remove">("add");
  const [source, setSource] = useState<"novo" | "corrente" | "reserva" | "correcao" | "gasto">("novo");
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("");
  const [worked, setWorked] = useState(false);
  const [error, setError] = useState("");
  const current = lines.find((line) => line.faceCents === face);

  return (
    <Card>
      <h2 className="font-display text-xl">Adicionar ou retirar peças</h2>
      <p className="mt-2 text-sm text-muted">Só denominações já contadas com número exato. Faixa e linha em branco pedem uma contagem, para o zero não ser inventado.</p>
      <form
        className="mt-3 grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          const count = Number(qty);
          if (!Number.isInteger(count) || count <= 0) {
            setError("Informe uma quantidade inteira.");
            return;
          }
          if (!current || current.status !== "exact" || current.quantity == null) {
            setError("Esta denominação ainda não tem quantidade exata.");
            return;
          }
          if (dir === "remove" && count > current.quantity) {
            setError("Não há peças suficientes nesta denominação.");
            return;
          }
          const nextQty = dir === "add" ? current.quantity + count : current.quantity - count;
          const value = count * face;
          commit("Ajuste do Meu Padrinho", (draft) => {
            const base = draft.padrinhoSnapshots[draft.padrinhoSnapshots.length - 1]?.lines ?? lines;
            const next = normalizeLines(base).map((line) => line.faceCents === face ? { ...line, status: "exact" as const, quantity: nextQty, min: null, max: null } : line);
            pushSnapshot(draft, next, status, "ajuste", note || "Ajuste de peças sobre a leitura anterior.", date);
            const endpoint: Endpoint | null = source === "corrente" ? "corrente" : source === "reserva" ? "reserva" : null;
            if (dir === "add" && (source === "novo" || source === "corrente" || source === "reserva")) {
              addCashMovement(draft, {
                date,
                kind: "aporte",
                amountCents: value,
                from: source === "novo" ? "externo" : endpoint,
                to: "padrinho",
                category: "Meu Padrinho",
                description: `Entrou no cofrinho: ${count} × ${denomInfo(face).label}`,
                note,
                isAporte: true,
                workedDay: source === "novo" && worked,
              });
            }
            if (dir === "remove" && source === "gasto") {
              addCashMovement(draft, {
                date,
                kind: "expense",
                amountCents: value,
                from: "padrinho",
                to: "externo",
                category: "Meu Padrinho",
                description: `Saíram do cofrinho: ${count} × ${denomInfo(face).label}`,
                note,
                isAporte: false,
                workedDay: false,
              });
            }
            if (dir === "remove" && (source === "corrente" || source === "reserva") && endpoint) {
              addCashMovement(draft, {
                date,
                kind: "transfer",
                amountCents: value,
                from: "padrinho",
                to: endpoint,
                category: "Meu Padrinho",
                description: `Do cofrinho para ${endpoint === "corrente" ? "a conta" : "a reserva"}`,
                note,
                isAporte: false,
                workedDay: false,
              });
            }
          });
          onClose();
        }}
      >
        <Field label="Denominação">
          <select className="min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={face} onChange={(event) => setFace(Number(event.target.value))}>
            {lines.map((line) => (
              <option key={line.faceCents} value={line.faceCents} disabled={line.status !== "exact"}>
                {denomInfo(line.faceCents).label} {line.status === "exact" ? "" : "— sem quantidade exata"}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Quantidade de peças">
            <TextInput inputMode="numeric" value={qty} onChange={(event) => setQty(event.target.value)} />
          </Field>
          <Field label="Movimento">
            <select className="min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={dir} onChange={(event) => setDir(event.target.value as "add" | "remove")}>
              <option value="add">Adicionar</option>
              <option value="remove">Retirar</option>
            </select>
          </Field>
        </div>
        <Field label="De onde vem ou para onde vai">
          <select className="min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={source} onChange={(event) => setSource(event.target.value as typeof source)}>
            <option value="novo">Dinheiro novo</option>
            <option value="corrente">Conta corrente</option>
            <option value="reserva">Reserva</option>
            <option value="gasto">Gastei este dinheiro</option>
            <option value="correcao">Só correção da contagem</option>
          </select>
        </Field>
        <Field label="Data">
          <TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} />
        </Field>
        <Field label="Motivo">
          <TextInput value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
        {dir === "add" && source === "novo" ? (
          <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
            <input type="checkbox" checked={worked} onChange={(event) => setWorked(event.target.checked)} />
            Dia de trabalho
          </label>
        ) : null}
        {error ? <p className="text-sm text-loss">{error}</p> : null}
        <div className="flex gap-2">
          <Button variant="primary" type="submit">Salvar peças</Button>
          <Button onClick={onClose}>Cancelar</Button>
        </div>
      </form>
    </Card>
  );
}

function CountForm({ lines, onClose }: { lines: DenomLine[]; onClose: () => void }) {
  const commit = useFinance((state) => state.commit);
  const initial = useMemo(() => {
    const values: Record<number, string> = {};
    for (const line of lines) values[line.faceCents] = line.status === "exact" && line.quantity != null ? String(line.quantity) : "";
    return values;
  }, [lines]);
  const [values, setValues] = useState(initial);
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("Contagem física.");
  const [error, setError] = useState("");

  function fillZeros() {
    if (!window.confirm("Isso marca as linhas em branco como zero. Só faça se você viu que elas estão vazias.")) return;
    setValues((current) => {
      const next = { ...current };
      for (const line of lines) if (!next[line.faceCents].trim()) next[line.faceCents] = "0";
      return next;
    });
  }

  return (
    <Card>
      <h2 className="font-display text-xl">Nova contagem física</h2>
      <p className="mt-2 text-sm text-muted">Campo vazio continua desconhecido. Digite 0 só se a denominação estiver vazia de verdade. A leitura anterior permanece no histórico.</p>
      <div className="mt-3 grid gap-2">
        {lines.map((line) => (
          <label key={line.faceCents} className="grid grid-cols-[1fr_6rem] items-center gap-3 text-sm">
            <span>{denomInfo(line.faceCents).plural}{line.status === "range" ? ` · antes ${line.min} a ${line.max}` : ""}</span>
            <TextInput inputMode="numeric" value={values[line.faceCents] ?? ""} placeholder="em branco" onChange={(event) => setValues((current) => ({ ...current, [line.faceCents]: event.target.value }))} />
          </label>
        ))}
      </div>
      <div className="mt-3 grid gap-3">
        <Field label="Data da contagem">
          <TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} />
        </Field>
        <Field label="Observação">
          <TextInput value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
      </div>
      {error ? <p className="mt-2 text-sm text-loss">{error}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <Button variant="primary" onClick={() => {
          const next: DenomLine[] = [];
          for (const line of lines) {
            const raw = (values[line.faceCents] ?? "").trim();
            if (!raw) {
              next.push({ ...line, status: "unknown", quantity: null, min: null, max: null });
              continue;
            }
            if (!/^\d+$/.test(raw)) {
              setError(`“${denomInfo(line.faceCents).label}” precisa de um número inteiro ou ficar em branco.`);
              return;
            }
            next.push({ ...line, status: "exact", quantity: Number(raw), min: null, max: null });
          }
          const summary = summarize(next);
          commit("Contagem do Meu Padrinho", (draft) => {
            pushSnapshot(draft, next, summary.complete ? "confirmed" : "estimated", "contagem", note || "Contagem física.", date);
          });
          onClose();
        }}>Salvar contagem</Button>
        <Button onClick={fillZeros}>Marcar em branco como zero</Button>
        <Button onClick={onClose}>Cancelar</Button>
      </div>
    </Card>
  );
}

function ImportForm({ lines, onClose }: { lines: DenomLine[]; onClose: () => void }) {
  const commit = useFinance((state) => state.commit);
  const [text, setText] = useState("20 Reais 100\n10 Reais 340\n5 Reais 220\n2 Reais 70\n1 Real 180 - 200\n50 Cent 100\n25 Cent 20");
  const [ack, setAck] = useState(false);
  const [error, setError] = useState("");
  const result = parseAnnotations(text);

  return (
    <Card>
      <h2 className="font-display text-xl">Importar anotações do Meu Padrinho</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Escreva a denominação e o valor total das peças, não a quantidade. “2 Reais 70” vira 35 cédulas. “1 Real 180 - 200” permanece uma faixa. Nada é salvo antes desta prévia.
      </p>
      <div className="mt-3">
        <TextArea value={text} onChange={(event) => setText(event.target.value)} />
      </div>
      <div className="mt-3 grid gap-2">
        {result.ready.map((item) => (
          <p key={item.faceCents} className="text-sm">
            {denomInfo(item.faceCents).label}: {item.line.status === "range" ? `${item.line.min} a ${item.line.max} peças` : `${item.line.quantity} peças`} · linha “{item.raw}”
          </p>
        ))}
        {result.issues.map((issue) => (
          <p key={issue.raw} className="text-sm text-loss">{issue.raw}: {issue.error}</p>
        ))}
        {!result.ready.length ? <p className="text-sm text-muted">Nenhuma linha pronta.</p> : null}
      </div>
      {result.issues.length ? (
        <label className="mt-3 flex items-start gap-2 text-sm text-muted">
          <input type="checkbox" checked={ack} onChange={(event) => setAck(event.target.checked)} />
          Entendi que as linhas com dúvida não serão aplicadas. O resto da contagem atual permanece.
        </label>
      ) : null}
      {error ? <p className="mt-2 text-sm text-loss">{error}</p> : null}
      <div className="mt-3 flex gap-2">
        <Button variant="primary" onClick={() => {
          if (!result.ready.length) {
            setError("Não há linha segura para salvar.");
            return;
          }
          if (result.issues.length && !ack) {
            setError("Confirme que as linhas duvidosas ficarão de fora.");
            return;
          }
          if (!window.confirm("Guardar esta leitura como nova estimativa? A contagem anterior fica no histórico.")) return;
          commit("Importar anotações", (draft) => {
            const current = draft.padrinhoSnapshots[draft.padrinhoSnapshots.length - 1]?.lines ?? lines;
            pushSnapshot(draft, mergeImport(current, result.ready), "estimated", "importacao", "Importado das anotações. Ainda não é contagem física.", todayISO());
          });
          onClose();
        }}>Usar esta estimativa</Button>
        <Button onClick={onClose}>Cancelar</Button>
      </div>
    </Card>
  );
}
