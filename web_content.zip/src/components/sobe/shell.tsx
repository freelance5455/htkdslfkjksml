import type { ReactNode } from "react";
import {
  Bitcoin,
  BookOpen,
  Landmark,
  LayoutDashboard,
  PiggyBank,
  Settings,
  Sprout,
  Target,
  Wallet,
} from "lucide-react";
import { Mark } from "@/components/sobe/bits";
import { cn } from "@/lib/utils";

export type View = "inicio" | "reserva" | "conta" | "padrinho" | "cripto" | "aportes" | "livro" | "metas" | "ajustes";

const NAV: { id: View; label: string; icon: typeof Landmark }[] = [
  { id: "inicio", label: "Visão geral", icon: LayoutDashboard },
  { id: "reserva", label: "Reserva", icon: Landmark },
  { id: "conta", label: "Conta corrente", icon: Wallet },
  { id: "padrinho", label: "Meu Padrinho", icon: PiggyBank },
  { id: "cripto", label: "Criptomoedas", icon: Bitcoin },
  { id: "aportes", label: "Aportes", icon: Sprout },
  { id: "livro", label: "Livro-caixa", icon: BookOpen },
  { id: "metas", label: "Metas", icon: Target },
  { id: "ajustes", label: "Dados e backup", icon: Settings },
];

export function Shell({
  view,
  onView,
  onLaunch,
  undoLabel,
  onUndo,
  children,
}: {
  view: View;
  onView: (view: View) => void;
  onLaunch: () => void;
  undoLabel: string | null;
  onUndo: () => void;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="mx-auto grid max-w-6xl md:grid-cols-[220px_1fr]">
        <aside className="hidden border-r border-line px-4 py-6 md:block">
          <div className="mb-8 flex items-center gap-3 px-2">
            <Mark />
            <div>
              <p className="font-display text-xl leading-none">Sobé</p>
              <p className="text-xs tracking-widest text-muted">FINANCEIRO</p>
            </div>
          </div>
          <nav className="grid gap-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onView(item.id)}
                  className={cn(
                    "flex min-h-11 items-center gap-3 rounded-2xl px-3 text-left text-sm",
                    active ? "bg-surface-2 text-lime" : "text-muted",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </aside>
        <div className="min-w-0">
          <header className="flex items-center justify-between gap-3 px-4 py-4 md:px-8">
            <div className="flex items-center gap-3 md:hidden">
              <Mark className="size-7" />
              <p className="font-display text-lg">Sobé</p>
            </div>
            <p className="hidden text-sm text-muted md:block">Seu dinheiro, neste aparelho.</p>
            {undoLabel ? (
              <button type="button" onClick={onUndo} className="min-h-11 rounded-full px-3 text-sm text-lime">
                Desfazer: {undoLabel}
              </button>
            ) : (
              <span className="text-xs text-faint">Sem nuvem</span>
            )}
          </header>
          <main className="px-4 pb-28 md:px-8 md:pb-16">{children}</main>
        </div>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg px-2 py-2 md:hidden">
        <div className="grid grid-cols-5 gap-1">
          <Tab icon={LayoutDashboard} label="Início" active={view === "inicio"} onClick={() => onView("inicio")} />
          <Tab icon={PiggyBank} label="Padrinho" active={view === "padrinho"} onClick={() => onView("padrinho")} />
          <button type="button" onClick={onLaunch} className="flex min-h-11 flex-col items-center justify-center text-lime-ink">
            <span className="flex size-10 items-center justify-center rounded-full bg-lime text-sm font-medium">+</span>
          </button>
          <Tab icon={Bitcoin} label="Cripto" active={view === "cripto"} onClick={() => onView("cripto")} />
          <Tab icon={Settings} label="Mais" active={!["inicio", "padrinho", "cripto"].includes(view)} onClick={() => onView("ajustes")} />
        </div>
      </nav>
    </div>
  );
}

function Tab({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: typeof Landmark;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className={cn("flex min-h-11 flex-col items-center justify-center gap-1 text-xs", active ? "text-lime" : "text-muted")}>
      <Icon className="size-4" aria-hidden="true" />
      {label}
    </button>
  );
}

export function MoreMenu({ onView }: { onView: (view: View) => void }) {
  const extra = NAV.filter((item) => !["inicio", "padrinho", "cripto"].includes(item.id));
  return (
    <div className="grid gap-2 md:hidden">
      {extra.map((item) => (
        <button key={item.id} type="button" onClick={() => onView(item.id)} className="min-h-11 rounded-2xl border border-line bg-surface px-4 text-left">
          {item.label}
        </button>
      ))}
    </div>
  );
}
