import { useState } from "react";
import { Button, Card, Field, SelectInput, TextArea, TextInput } from "@/components/sobe/bits";
import { deadlineISO, goalReading, monthlyPace, projectMonths } from "@/lib/finance/engine";
import { PRIORITY_LABEL } from "@/lib/finance/labels";
import { formatCents, formatDate, formatRangeCents, isIsoDate, parseBrlToCents, todayISO } from "@/lib/finance/money";
import { useFinance } from "@/lib/finance/store";
import type { Goal, GoalLink, Priority } from "@/lib/finance/types";
import { uid } from "@/lib/finance/money";

export function GoalsPage({ openForm, onFormClose }: { openForm: boolean; onFormClose: () => void }) {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const [creating, setCreating] = useState(openForm);
  const today = todayISO();

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <h1 className="font-display text-4xl">Metas</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          O prazo estimado usa só aportes já registrados. Rendimento hipotético só entra se você ligar e informar a taxa. Dá para desligar.
        </p>
        <Button className="mt-4" variant="primary" onClick={() => setCreating(true)}>Criar meta</Button>
      </Card>
      {(creating || openForm) ? (
        <GoalForm
          onClose={() => {
            setCreating(false);
            onFormClose();
          }}
          onSave={(goal) => {
            commit("Nova meta", (draft) => void draft.goals.push(goal));
            setCreating(false);
            onFormClose();
          }}
        />
      ) : null}
      {data.goals.length === 0 && !(creating || openForm) ? <Card><p className="text-sm text-muted">Nenhuma meta ainda. Casa, reserva, Meu Padrinho — o nome é seu.</p></Card> : null}
      {data.goals.map((goal) => {
        const reading = goalReading(data, goal);
        const pace = monthlyPace(data, goal, today);
        const current = reading.currentMin;
        const months = current == null ? null : projectMonths(current, goal.targetCents, pace ?? 0, goal.hypotheticalYield ? goal.monthlyRatePct : null);
        const width = Math.max(0, Math.min(100, Math.round((reading.progressMin ?? 0) * 100)));
        return (
          <Card key={goal.id}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-sm text-lime">{PRIORITY_LABEL[goal.priority]}</p>
                <h2 className="font-display text-2xl">{goal.name}</h2>
              </div>
              <Button variant="danger" onClick={() => {
                if (window.confirm(`Apagar a meta “${goal.name}”?`)) commit("Apagar meta", (draft) => {
                  draft.goals = draft.goals.filter((item) => item.id !== goal.id);
                });
              }}>Apagar</Button>
            </div>
            <p className="mt-2 text-sm text-muted">
              Alvo {formatCents(goal.targetCents)}
              {goal.deadline ? ` · prazo ${formatDate(goal.deadline)}` : ""}
              {goal.baselineCents != null ? ` · você já contava ${formatCents(goal.baselineCents)} no início` : ""}
            </p>
            <p className="mt-2 font-display text-3xl">
              {reading.currentMin == null || reading.currentMax == null ? "Sem valor atual" : formatRangeCents(reading.currentMin, reading.currentMax)}
            </p>
            <div className="mt-3 h-2 rounded-full bg-surface-3" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={width}>
              <div className="h-2 rounded-full bg-emerald" style={{ width: `${width}%` }} />
            </div>
            <p className="mt-2 text-sm text-muted">{reading.label} {width}% do alvo, pela base mais baixa quando há faixa.</p>
            <p className="mt-2 text-sm text-muted">
              {pace == null
                ? "Ainda não há aportes neste destino para estimar um prazo."
                : months == null
                  ? "Com a média atual, sem rendimento, o prazo não fecha."
                  : months === 0
                    ? "O valor atual já cobre o alvo."
                    : `No ritmo de ${formatCents(pace)} por mês, cerca de ${months} meses (${formatDate(deadlineISO(today, months))}). ${goal.hypotheticalYield && goal.monthlyRatePct ? `Premissa extra: ${goal.monthlyRatePct}% ao mês, taxa que você informou. Não é promessa.` : "Premissa: repetir a média dos aportes já feitos, sem rendimento hipotético."}`}
            </p>
            {goal.notes ? <p className="mt-2 text-sm text-muted">{goal.notes}</p> : null}
          </Card>
        );
      })}
    </div>
  );
}

function GoalForm({ onClose, onSave }: { onClose: () => void; onSave: (goal: Goal) => void }) {
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [baseline, setBaseline] = useState("");
  const [link, setLink] = useState<GoalLink>("reserva");
  const [deadline, setDeadline] = useState("");
  const [priority, setPriority] = useState<Priority>("media");
  const [notes, setNotes] = useState("");
  const [hypo, setHypo] = useState(false);
  const [rate, setRate] = useState("");
  const [manual, setManual] = useState("");
  const [error, setError] = useState("");

  return (
    <Card>
      <h2 className="font-display text-xl">Nova meta</h2>
      <form
        className="mt-3 grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          const targetCents = parseBrlToCents(target);
          const baselineCents = baseline.trim() ? parseBrlToCents(baseline) : null;
          const manualCurrentCents = manual.trim() ? parseBrlToCents(manual) : null;
          const monthlyRatePct = rate.trim() ? Number(rate.replace(",", ".")) : null;
          if (!name.trim() || targetCents == null || targetCents <= 0) {
            setError("Dê um nome e um valor alvo.");
            return;
          }
          if ((baseline.trim() && baselineCents == null) || (manual.trim() && manualCurrentCents == null)) {
            setError("Há um valor que não consegui ler.");
            return;
          }
          if (deadline && !isIsoDate(deadline)) {
            setError("Prazo inválido.");
            return;
          }
          if (hypo && (monthlyRatePct == null || !Number.isFinite(monthlyRatePct) || monthlyRatePct < 0)) {
            setError("Informe a taxa mensal ou desligue o rendimento hipotético.");
            return;
          }
          onSave({
            id: uid(),
            name: name.trim(),
            targetCents,
            baselineCents,
            link,
            manualCurrentCents,
            deadline: deadline || null,
            priority,
            notes,
            hypotheticalYield: hypo,
            monthlyRatePct: hypo ? monthlyRatePct : null,
            createdAt: new Date().toISOString(),
          });
        }}
      >
        <Field label="Nome"><TextInput value={name} onChange={(event) => setName(event.target.value)} placeholder="Reserva de emergência" /></Field>
        <Field label="Valor alvo"><TextInput inputMode="decimal" value={target} onChange={(event) => setTarget(event.target.value)} /></Field>
        <Field label="Acompanhar">
          <SelectInput value={link} onChange={(event) => setLink(event.target.value as GoalLink)}>
            <option value="reserva">Reserva</option>
            <option value="corrente">Conta</option>
            <option value="padrinho">Meu Padrinho</option>
            <option value="cripto">Criptomoedas</option>
            <option value="patrimonio">Patrimônio estimado</option>
            <option value="manual">Valor manual</option>
          </SelectInput>
        </Field>
        {link === "manual" ? <Field label="Valor atual manual"><TextInput inputMode="decimal" value={manual} onChange={(event) => setManual(event.target.value)} /></Field> : null}
        <Field label="Valor que você já tinha" hint="Opcional. Não muda o cálculo do saldo, só o contexto.">
          <TextInput inputMode="decimal" value={baseline} onChange={(event) => setBaseline(event.target.value)} placeholder="em branco" />
        </Field>
        <Field label="Prazo" hint="Opcional">
          <TextInput type="date" value={deadline} onChange={(event) => setDeadline(event.target.value)} />
        </Field>
        <Field label="Prioridade">
          <SelectInput value={priority} onChange={(event) => setPriority(event.target.value as Priority)}>
            <option value="alta">Alta</option>
            <option value="media">Média</option>
            <option value="baixa">Baixa</option>
          </SelectInput>
        </Field>
        <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
          <input type="checkbox" checked={hypo} onChange={(event) => setHypo(event.target.checked)} />
          Incluir rendimento hipotético
        </label>
        {hypo ? <Field label="Taxa ao mês (%)" hint="Você informa. O painel não supõe taxa fixa."><TextInput value={rate} onChange={(event) => setRate(event.target.value)} /></Field> : null}
        <Field label="Observações"><TextArea value={notes} onChange={(event) => setNotes(event.target.value)} /></Field>
        {error ? <p className="text-sm text-loss">{error}</p> : null}
        <div className="flex gap-2">
          <Button variant="primary" type="submit">Salvar meta</Button>
          <Button onClick={onClose}>Cancelar</Button>
        </div>
      </form>
    </Card>
  );
}
