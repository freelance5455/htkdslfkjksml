import { useState } from "react";
import { Badge, Button, Card, Field, TextArea, TextInput } from "@/components/sobe/bits";
import { assetPnl, cryptoPosition, inconsistentCost, simulate } from "@/lib/finance/engine";
import { COINGECKO_IDS } from "@/lib/finance/labels";
import { formatCents, formatDate, formatQty, parseBrlToCents, todayISO, uid } from "@/lib/finance/money";
import { addCashMovement, applyPositionBuy, rememberPrice, useFinance } from "@/lib/finance/store";
import { reducePosition } from "@/lib/finance/engine";
import type { BucketId, CryptoAsset } from "@/lib/finance/types";

export function CryptoPage() {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const pos = cryptoPosition(data.assets);
  const [showAdd, setShowAdd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function refresh() {
    const ids = [...new Set(data.assets.map((asset) => asset.coingeckoId).filter(Boolean))];
    if (!ids.length) {
      setMessage("Cadastre o código CoinGecko do ativo. Sem isso, só a cotação manual funciona.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(ids.join(","))}&vs_currencies=brl`);
      if (!response.ok) throw new Error("A cotação pública não respondeu.");
      const json = (await response.json()) as Record<string, { brl?: number }>;
      commit("Cotações", (draft) => {
        for (const asset of draft.assets) {
          const brl = json[asset.coingeckoId]?.brl;
          if (typeof brl === "number") rememberPrice(asset, Math.round(brl * 100), "coingecko");
        }
      });
      setMessage("Cotações atualizadas. Só o código da moeda saiu do aparelho, nenhum saldo.");
    } catch {
      setMessage("Sem conexão ou a cotação falhou. Continua valendo o último preço salvo.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm text-muted">Carteira</p>
            <h1 className="font-display text-4xl">Criptomoedas</h1>
          </div>
          <Badge state={pos.marketCents != null && pos.unpriced === 0 ? "confirmed" : data.cryptoEstimate.active ? "estimated" : "unknown"} />
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Valor de mercado e valor investido ficam separados. Sem cotação salva, não há lucro inventado.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Block label="Mercado" value={pos.marketCents == null ? "Sem cotação" : formatCents(pos.marketCents)} />
          <Block label="Investido" value={pos.investedCents == null ? "Custo desconhecido" : formatCents(pos.investedCents)} />
          <Block label="Resultado estimado" value={pos.pnlCents == null ? "Indisponível" : formatCents(pos.pnlCents)} />
        </div>
        {data.cryptoEstimate.active ? (
          <div className="mt-4 rounded-2xl border border-line p-3 text-sm text-muted">
            Lembrança antiga: {formatCents(data.cryptoEstimate.minCents)} a {formatCents(data.cryptoEstimate.maxCents)}. {data.cryptoEstimate.note} Ela não é somada a ativos que você cadastrar.
            <div className="mt-2">
              <Button onClick={() => {
                if (window.confirm("Descartar a faixa de R$ 550 a R$ 600? Os ativos cadastrados permanecem.")) {
                  commit("Descartar estimativa cripto", (draft) => void (draft.cryptoEstimate.active = false));
                }
              }}>Descartar faixa</Button>
            </div>
          </div>
        ) : null}
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="primary" onClick={() => setShowAdd(true)}>Cadastrar ativo</Button>
          <Button onClick={refresh} disabled={busy}>{busy ? "Consultando…" : "Atualizar cotações"}</Button>
        </div>
        {message ? <p className="mt-3 text-sm text-muted">{message}</p> : null}
      </Card>
      {showAdd ? <AssetForm onClose={() => setShowAdd(false)} /> : null}
      {data.assets.map((asset) => (
        <AssetCard key={asset.id} asset={asset} />
      ))}
      {!data.assets.length ? <Card><p className="text-sm text-muted">Nenhum ativo cadastrado. A faixa aproximada não vira Bitcoin, Ethereum nem qualquer quantidade.</p></Card> : null}
      <Lab />
    </div>
  );
}

function Block({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-sm text-muted">{label}</p>
      <p className="font-display text-2xl">{value}</p>
    </div>
  );
}

function AssetForm({ onClose }: { onClose: () => void }) {
  const commit = useFinance((state) => state.commit);
  const [name, setName] = useState("");
  const [symbol, setSymbol] = useState("");
  const [qty, setQty] = useState("");
  const [avg, setAvg] = useState("");
  const [invested, setInvested] = useState("");
  const [market, setMarket] = useState("");
  const [gecko, setGecko] = useState("");
  const [notes, setNotes] = useState("");
  const [strategy, setStrategy] = useState("");
  const [date, setDate] = useState(todayISO());
  const [error, setError] = useState("");

  return (
    <Card>
      <h2 className="font-display text-xl">Posição que você já tem</h2>
      <p className="mt-2 text-sm text-muted">Isto não tira dinheiro da reserva nem da conta. É o registro da posição, como um saldo inicial.</p>
      <form
        className="mt-3 grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          const quantity = Number(qty.replace(",", "."));
          if (!name.trim() || !symbol.trim() || !Number.isFinite(quantity) || quantity < 0) {
            setError("Nome, símbolo e quantidade são necessários. Não invento saldo.");
            return;
          }
          const avgCents = avg.trim() ? parseBrlToCents(avg) : null;
          const investedCents = invested.trim() ? parseBrlToCents(invested) : null;
          const marketCents = market.trim() ? parseBrlToCents(market) : null;
          if ((avg.trim() && avgCents == null) || (invested.trim() && investedCents == null) || (market.trim() && marketCents == null)) {
            setError("Há um valor em reais que não consegui ler.");
            return;
          }
          if (inconsistentCost(quantity, avgCents, investedCents)) {
            setError("Preço médio e valor investido não fecham. Deixe um dos dois em branco ou ajuste.");
            return;
          }
          const id = symbol.trim().toLowerCase();
          commit("Novo ativo", (draft) => {
            const asset: CryptoAsset = {
              id: uid(),
              name: name.trim(),
              symbol: symbol.trim().toUpperCase(),
              coingeckoId: gecko.trim() || COINGECKO_IDS[id] || "",
              quantity,
              avgPriceCents: avgCents,
              investedCents: investedCents ?? (avgCents != null ? Math.round(quantity * avgCents) : null),
              marketPriceCents: marketCents,
              priceUpdatedAt: marketCents != null ? new Date().toISOString() : null,
              priceSource: marketCents != null ? "manual" : null,
              notes,
              strategyNote: strategy,
              txs: [{ id: uid(), date, kind: "opening", quantity, priceCents: avgCents, feeCents: 0, totalCents: investedCents, bucket: null, note: "Posição inicial", createdAt: new Date().toISOString() }],
              priceHistory: marketCents != null ? [{ at: new Date().toISOString(), priceCents: marketCents, source: "manual" }] : [],
            };
            draft.assets.push(asset);
          });
          onClose();
        }}
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome"><TextInput value={name} onChange={(event) => setName(event.target.value)} placeholder="Bitcoin" /></Field>
          <Field label="Símbolo"><TextInput value={symbol} onChange={(event) => setSymbol(event.target.value)} placeholder="BTC" /></Field>
        </div>
        <Field label="Quantidade" hint="Pode ser fracionária. Exemplo: 0,0012">
          <TextInput inputMode="decimal" value={qty} onChange={(event) => setQty(event.target.value)} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Preço médio, se souber"><TextInput inputMode="decimal" value={avg} onChange={(event) => setAvg(event.target.value)} placeholder="opcional" /></Field>
          <Field label="Valor investido, se souber"><TextInput inputMode="decimal" value={invested} onChange={(event) => setInvested(event.target.value)} placeholder="opcional" /></Field>
        </div>
        <Field label="Cotação manual agora"><TextInput inputMode="decimal" value={market} onChange={(event) => setMarket(event.target.value)} placeholder="opcional" /></Field>
        <Field label="Código CoinGecko" hint="Opcional. BTC, ETH e LINK são reconhecidos pelo símbolo.">
          <TextInput value={gecko} onChange={(event) => setGecko(event.target.value)} placeholder="bitcoin" />
        </Field>
        <Field label="Data da posição"><TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} /></Field>
        <Field label="Estratégia"><TextArea value={strategy} onChange={(event) => setStrategy(event.target.value)} /></Field>
        <Field label="Observações"><TextArea value={notes} onChange={(event) => setNotes(event.target.value)} /></Field>
        {error ? <p className="text-sm text-loss">{error}</p> : null}
        <div className="flex gap-2">
          <Button variant="primary" type="submit">Salvar ativo</Button>
          <Button onClick={onClose}>Cancelar</Button>
        </div>
      </form>
    </Card>
  );
}

function AssetCard({ asset }: { asset: CryptoAsset }) {
  const commit = useFinance((state) => state.commit);
  const market = asset.marketPriceCents == null ? null : Math.round(asset.quantity * asset.marketPriceCents);
  const pnl = assetPnl(asset);
  const [price, setPrice] = useState("");
  const [trade, setTrade] = useState<"buy" | "sell" | null>(null);

  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm text-muted">{asset.symbol}</p>
          <h2 className="font-display text-2xl">{asset.name}</h2>
          <p className="text-sm text-muted">{formatQty(asset.quantity)} unidades</p>
        </div>
        <div className="text-right">
          <p className="font-display text-2xl">{market == null ? "Sem cotação" : formatCents(market)}</p>
          <p className="text-xs text-faint">{asset.priceUpdatedAt ? `Preço de ${new Date(asset.priceUpdatedAt).toLocaleString("pt-BR")} · ${asset.priceSource === "coingecko" ? "CoinGecko" : "manual"}` : "Preço nunca informado"}</p>
        </div>
      </div>
      <div className="mt-3 grid gap-2 text-sm text-muted sm:grid-cols-3">
        <p>Preço médio: {asset.avgPriceCents == null ? "desconhecido" : formatCents(asset.avgPriceCents)}</p>
        <p>Investido: {asset.investedCents == null ? "desconhecido" : formatCents(asset.investedCents)}</p>
        <p>Resultado: {pnl == null ? "sem base" : formatCents(pnl)}</p>
      </div>
      {asset.strategyNote ? <p className="mt-3 text-sm text-muted">{asset.strategyNote}</p> : null}
      <form
        className="mt-3 flex flex-wrap items-end gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = parseBrlToCents(price);
          if (cents == null || cents < 0) return;
          commit("Cotação manual", (draft) => {
            const found = draft.assets.find((item) => item.id === asset.id);
            if (found) rememberPrice(found, cents, "manual");
          });
          setPrice("");
        }}
      >
        <Field label="Nova cotação manual">
          <TextInput inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="0,00" />
        </Field>
        <Button type="submit" variant="primary">Salvar preço</Button>
        <Button onClick={() => setTrade(trade === "buy" ? null : "buy")}>Compra</Button>
        <Button onClick={() => setTrade(trade === "sell" ? null : "sell")}>Venda</Button>
        <Button variant="danger" onClick={() => {
          if (window.confirm(`Apagar ${asset.name} da carteira? O histórico deste ativo sai junto.`)) {
            commit("Apagar ativo", (draft) => {
              draft.assets = draft.assets.filter((item) => item.id !== asset.id);
            });
          }
        }}>Apagar</Button>
      </form>
      {trade ? <TradeForm asset={asset} kind={trade} onClose={() => setTrade(null)} /> : null}
      {asset.txs.length ? (
        <div className="mt-4 grid gap-1 text-sm text-muted">
          {asset.txs.slice().reverse().slice(0, 6).map((tx) => (
            <p key={tx.id}>{formatDate(tx.date)} · {tx.kind} · {formatQty(tx.quantity)}{tx.totalCents != null ? ` · ${formatCents(tx.totalCents)}` : ""}</p>
          ))}
        </div>
      ) : null}
    </Card>
  );
}

function TradeForm({ asset, kind, onClose }: { asset: CryptoAsset; kind: "buy" | "sell"; onClose: () => void }) {
  const commit = useFinance((state) => state.commit);
  const [qty, setQty] = useState("");
  const [price, setPrice] = useState("");
  const [fee, setFee] = useState("0");
  const [date, setDate] = useState(todayISO());
  const [bucket, setBucket] = useState<BucketId | "externo">("corrente");
  const [note, setNote] = useState("");
  const [usePrice, setUsePrice] = useState(true);
  const [aporte, setAporte] = useState(false);
  const [error, setError] = useState("");

  return (
    <form
      className="mt-4 grid gap-3 rounded-2xl border border-line p-3"
      onSubmit={(event) => {
        event.preventDefault();
        const quantity = Number(qty.replace(",", "."));
        const priceCents = parseBrlToCents(price);
        const feeCents = fee.trim() ? parseBrlToCents(fee) : 0;
        if (!Number.isFinite(quantity) || quantity <= 0 || priceCents == null || priceCents < 0 || feeCents == null || feeCents < 0) {
          setError("Quantidade, preço e taxa precisam ser números válidos.");
          return;
        }
        if (kind === "sell") {
          const check = reducePosition(asset, quantity);
          if ("error" in check) {
            setError(check.error);
            return;
          }
        }
        const gross = Math.round(quantity * priceCents);
        commit(kind === "buy" ? "Compra de cripto" : "Venda de cripto", (draft) => {
          const found = draft.assets.find((item) => item.id === asset.id);
          if (!found) return;
          if (kind === "buy") {
            const total = gross + feeCents;
            applyPositionBuy(found, { quantity, totalCents: total, priceCents, feeCents, date, bucket, note });
            if (bucket === "reserva" || bucket === "corrente") {
              addCashMovement(draft, {
                date,
                kind: "conversion",
                amountCents: total,
                from: bucket,
                to: null,
                category: "Cripto",
                description: `Compra de ${found.symbol}`,
                note,
                isAporte: aporte,
                workedDay: false,
                assetId: found.id,
              });
            }
            if (usePrice) rememberPrice(found, priceCents, "manual");
          } else {
            const next = reducePosition(found, quantity);
            if ("error" in next) return;
            const proceeds = Math.max(0, gross - feeCents);
            found.quantity = next.quantity;
            found.investedCents = next.investedCents;
            found.avgPriceCents = next.avgPriceCents;
            found.txs.push({ id: uid(), date, kind: "sell", quantity, priceCents, feeCents, totalCents: proceeds, bucket, note, createdAt: new Date().toISOString() });
            if (bucket === "reserva" || bucket === "corrente") {
              addCashMovement(draft, {
                date,
                kind: "conversion",
                amountCents: proceeds,
                from: null,
                to: bucket,
                category: "Cripto",
                description: `Venda de ${found.symbol}`,
                note,
                isAporte: false,
                workedDay: false,
                assetId: found.id,
              });
            }
            if (usePrice) rememberPrice(found, priceCents, "manual");
          }
        });
        onClose();
      }}
    >
      <p className="text-sm text-muted">{kind === "buy" ? "Compra" : "Venda"} de {asset.symbol}. A taxa entra no custo. Venda não vira rendimento automático.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Quantidade"><TextInput inputMode="decimal" value={qty} onChange={(event) => setQty(event.target.value)} /></Field>
        <Field label="Preço por unidade"><TextInput inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} /></Field>
        <Field label="Taxa"><TextInput inputMode="decimal" value={fee} onChange={(event) => setFee(event.target.value)} /></Field>
        <Field label="Data"><TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} /></Field>
      </div>
      <Field label={kind === "buy" ? "Pagou com" : "Recebeu em"}>
        <select className="min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={bucket} onChange={(event) => setBucket(event.target.value as BucketId | "externo")}>
          <option value="corrente">Conta corrente</option>
          <option value="reserva">Reserva</option>
          <option value="externo">Fora do painel</option>
        </select>
      </Field>
      <Field label="Nota"><TextInput value={note} onChange={(event) => setNote(event.target.value)} /></Field>
      <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
        <input type="checkbox" checked={usePrice} onChange={(event) => setUsePrice(event.target.checked)} />
        Usar este preço como cotação atual
      </label>
      {kind === "buy" ? (
        <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
          <input type="checkbox" checked={aporte} onChange={(event) => setAporte(event.target.checked)} />
          Contar o valor pago como aporte
        </label>
      ) : null}
      {error ? <p className="text-sm text-loss">{error}</p> : null}
      <div className="flex gap-2">
        <Button variant="primary" type="submit">Registrar</Button>
        <Button onClick={onClose}>Cancelar</Button>
      </div>
    </form>
  );
}

function Lab() {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const priced = data.assets.filter((asset) => asset.marketPriceCents != null);
  const [assetId, setAssetId] = useState(priced[0]?.id ?? "");
  const [pct, setPct] = useState("-10");
  const [extra, setExtra] = useState("");
  const [pctB, setPctB] = useState("10");
  const [extraB, setExtraB] = useState("");
  const [rule, setRule] = useState(data.strategy.personalRule);
  const asset = data.assets.find((item) => item.id === assetId) ?? priced[0];

  function run(change: string, extraValue: string) {
    if (!asset) return null;
    const changePct = Number(change.replace(",", "."));
    const extraCents = extraValue.trim() ? parseBrlToCents(extraValue) : 0;
    if (!Number.isFinite(changePct) || extraCents == null) return null;
    return simulate({
      quantity: asset.quantity,
      avgPriceCents: asset.avgPriceCents,
      investedCents: asset.investedCents,
      marketPriceCents: asset.marketPriceCents,
      changePct,
      extraCents,
    });
  }

  const left = run(pct, extra);
  const right = run(pctB, extraB);

  return (
    <Card>
      <h2 className="font-display text-2xl">Laboratório de estratégia</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Simulação hipotética. Uma queda não é ordem de compra. Cripto pode perder uma parte grande do valor. Sua regra pessoal fica anotada, sem virar recomendação automática.
      </p>
      {!asset ? <p className="mt-4 text-sm text-muted">Cadastre um ativo com cotação para simular. A faixa de R$ 550 a R$ 600 não vira quantidade.</p> : (
        <>
          <div className="mt-4 grid gap-3">
            <Field label="Ativo">
              <select className="min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={asset.id} onChange={(event) => setAssetId(event.target.value)}>
                {priced.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
              </select>
            </Field>
            <div className="flex flex-wrap gap-2">
              {["-5", "-10", "-15", "-20", "10", "20"].map((value) => (
                <Button key={value} onClick={() => setPct(value)}>{value}%</Button>
              ))}
            </div>
            <div className="grid gap-4 lg:grid-cols-2">
              <Scenario title="Cenário A" pct={pct} setPct={setPct} extra={extra} setExtra={setExtra} result={left} />
              <Scenario title="Cenário B" pct={pctB} setPct={setPctB} extra={extraB} setExtra={setExtraB} result={right} />
            </div>
          </div>
        </>
      )}
      <Field label="Minha regra em momentos de queda">
        <TextArea value={rule} onChange={(event) => setRule(event.target.value)} placeholder="Escreva a sua regra. O painel não compra nada por você." />
      </Field>
      <Button className="mt-3" onClick={() => commit("Regra pessoal", (draft) => void (draft.strategy.personalRule = rule))}>Guardar regra</Button>
    </Card>
  );
}

function Scenario({
  title,
  pct,
  setPct,
  extra,
  setExtra,
  result,
}: {
  title: string;
  pct: string;
  setPct: (value: string) => void;
  extra: string;
  setExtra: (value: string) => void;
  result: ReturnType<typeof simulate> | null;
}) {
  return (
    <div className="rounded-2xl border border-line p-3">
      <p className="text-sm text-lime">{title}</p>
      <div className="mt-2 grid gap-2">
        <Field label="Variação %">
          <TextInput value={pct} onChange={(event) => setPct(event.target.value)} />
        </Field>
        <Field label="Aporte extra em reais">
          <TextInput inputMode="decimal" value={extra} onChange={(event) => setExtra(event.target.value)} placeholder="0,00" />
        </Field>
      </div>
      {result?.ok ? (
        <div className="mt-3 grid gap-1 text-sm text-muted">
          <p>Preço simulado: {formatCents(result.simulatedPriceCents ?? 0)}</p>
          <p>Moedas do aporte: {formatQty(result.extraQty ?? 0)}</p>
          <p>Quantidade nova: {formatQty(result.newQty ?? 0)}</p>
          <p>Preço médio novo: {result.newAvgCents == null ? "sem custo anterior" : formatCents(result.newAvgCents)}</p>
          <p>Mercado simulado: {formatCents(result.newMarketCents ?? 0)}</p>
          <p>Resultado contra o custo: {result.pnlCents == null ? "sem custo conhecido" : formatCents(result.pnlCents)}</p>
          <p>{result.note}</p>
        </div>
      ) : <p className="mt-3 text-sm text-muted">{result?.note ?? "Preencha a variação."}</p>}
    </div>
  );
}
