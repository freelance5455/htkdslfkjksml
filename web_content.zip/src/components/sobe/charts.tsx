import { Bar, BarChart, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { NeedHistory } from "@/components/sobe/bits";
import type { CashPoint, PigPoint, WealthReport } from "@/lib/finance/engine";
import { formatCents, formatDate, monthKey, monthLabel } from "@/lib/finance/money";
import type { Movement } from "@/lib/finance/types";
import { aporteMovements } from "@/lib/finance/engine";

const tip = {
  contentStyle: {
    background: "var(--color-surface)",
    border: "1px solid var(--color-line)",
    borderRadius: 12,
    color: "var(--color-fg)",
  },
};

export function CashChart({ points }: { points: CashPoint[] }) {
  if (points.length < 2) {
    return (
      <NeedHistory>
        Ainda não há histórico suficiente para a linha do patrimônio em caixa. Registre movimentações em dias
        diferentes. Um único saldo não vira gráfico.
      </NeedHistory>
    );
  }
  const data = points.map((point) => ({
    label: formatDate(point.date).slice(0, 5),
    reserva: point.reserva / 100,
    conta: point.corrente / 100,
    total: point.total / 100,
  }));
  return (
    <div className="h-60 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="label" stroke="var(--color-faint)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <YAxis hide />
          <Tooltip {...tip} formatter={(value) => formatCents(Math.round(Number(value) * 100))} />
          <Line type="monotone" dataKey="total" name="Caixa" stroke="var(--color-lime)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="reserva" name="Reserva" stroke="var(--color-emerald)" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function PigChart({ points }: { points: PigPoint[] }) {
  if (points.length < 2 || points.some((point) => !point.exact)) {
    return (
      <NeedHistory>
        A evolução do Meu Padrinho aparece quando houver pelo menos duas contagens com total exato. Faixa e
        denominação em branco não viram uma linha, para o gráfico não parecer mais preciso do que a contagem.
      </NeedHistory>
    );
  }
  const data = points.map((point) => ({ label: formatDate(point.date).slice(0, 5), total: point.minCents / 100 }));
  return (
    <div className="h-60 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="label" stroke="var(--color-faint)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <YAxis hide />
          <Tooltip {...tip} formatter={(value) => formatCents(Math.round(Number(value) * 100))} />
          <Line type="monotone" dataKey="total" name="Meu Padrinho" stroke="var(--color-lime)" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function FlowChart({ movements }: { movements: Movement[] }) {
  const months = new Map<string, { entradas: number; saidas: number }>();
  for (const movement of movements) {
    if (movement.voided) continue;
    if (movement.kind !== "income" && movement.kind !== "expense" && !(movement.kind === "aporte" && movement.from === "externo")) continue;
    const key = monthKey(movement.date);
    const row = months.get(key) ?? { entradas: 0, saidas: 0 };
    if (movement.kind === "expense") row.saidas += movement.amountCents;
    else row.entradas += movement.amountCents;
    months.set(key, row);
  }
  const data = [...months.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, row]) => ({ label: monthLabel(key).split(" ")[0].slice(0, 3), entradas: row.entradas / 100, saidas: row.saidas / 100 }));
  if (!data.length) {
    return <NeedHistory>Nenhuma entrada ou saída lançada ainda. Transferência interna não entra neste gráfico.</NeedHistory>;
  }
  return (
    <div className="h-60 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="label" stroke="var(--color-faint)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <YAxis hide />
          <Tooltip {...tip} formatter={(value) => formatCents(Math.round(Number(value) * 100))} />
          <Bar dataKey="entradas" name="Entradas" fill="var(--color-lime)" radius={6} />
          <Bar dataKey="saidas" name="Saídas" fill="var(--color-emerald-deep)" radius={6} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AporteChart({ movements }: { movements: Movement[] }) {
  const months = new Map<string, number>();
  for (const movement of aporteMovements(movements)) {
    const key = monthKey(movement.date);
    months.set(key, (months.get(key) ?? 0) + movement.amountCents);
  }
  const data = [...months.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, total]) => ({ label: monthLabel(key).split(" ")[0].slice(0, 3), total: total / 100 }));
  if (!data.length) {
    return <NeedHistory>Nenhum aporte registrado. Dias sem lançamento não são desenhados como falha.</NeedHistory>;
  }
  return (
    <div className="h-60 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="label" stroke="var(--color-faint)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <YAxis hide />
          <Tooltip {...tip} formatter={(value) => formatCents(Math.round(Number(value) * 100))} />
          <Bar dataKey="total" name="Aportes" fill="var(--color-emerald)" radius={6} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

const SLICE = ["var(--color-lime)", "var(--color-emerald)", "var(--color-emerald-deep)", "var(--color-muted)"];

export function AllocationChart({ report }: { report: WealthReport }) {
  const parts = report.parts.filter((part) => part.inEstimated);
  const allExact = parts.length > 0 && parts.every((part) => part.minCents != null && part.minCents === part.maxCents && part.minCents > 0);
  if (!allExact) {
    return (
      <NeedHistory>
        A pizza fica para quando cada parte tiver um valor exato. Com faixa ou item não conferido, uma fatia única
        esconderia o intervalo.
      </NeedHistory>
    );
  }
  const data = parts.map((part) => ({ name: part.label, value: (part.minCents ?? 0) / 100 }));
  return (
    <div className="h-60 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius={48} outerRadius={80} paddingAngle={2}>
            {data.map((entry, index) => (
              <Cell key={entry.name} fill={SLICE[index % SLICE.length]} />
            ))}
          </Pie>
          <Tooltip {...tip} formatter={(value) => formatCents(Math.round(Number(value) * 100))} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
