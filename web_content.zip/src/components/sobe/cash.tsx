import { useState } from "react";
import { Badge, Button, Card, Field, Stat, TextInput } from "@/components/sobe/bits";
import { CashChart } from "@/components/sobe/charts";
import type { MoveRequest } from "@/components/sobe/dialogs";
import { availableChecking, bucketBalance, cashSeries, monthFlows, reserveGrowth } from "@/lib/finance/engine";
import { KIND_LABEL } from "@/lib/finance/labels";
import { formatCents, formatDate, monthKey, parseBrlToCents, todayISO } from "@/lib/finance/money";
import { blankBill, useFinance } from "@/lib/finance/store";
import type { BucketId } from "@/lib/finance/types";

export function CashPage({ bucket, onMove }: { bucket: BucketId; onMove: (request: MoveRequest) => void }) {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const balance = bucketBalance(data.movements, bucket);
  const today = todayISO();
  const flows = monthFlows(data.movements.filter((item) => item.from === bucket || item.to === bucket), monthKey(today));
  const rows = data.movements.filter((item) => item.from === bucket || item.to === bucket).slice().reverse();
  const growth = reserveGrowth(data);
  const avail = availableChecking(data);
  const [billName, setBillName] = useState("");
  const [billAmount, setBillAmount] = useState("");
  const [billDue, setBillDue] = useState("");
  const [billError, setBillError] = useState("");

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm text-muted">{bucket === "reserva" ? "Reserva principal" : "Conta corrente"}</p>
            <p className="font-display text-4xl sm:text-5xl">{formatCents(balance)}</p>
          </div>
          <Badge state={data.accounts[bucket].certainty === "confirmed" ? "confirmed" : "approximate"} />
        </div>
        {bucket === "reserva" ? (
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <Stat label="Desde o saldo inicial" value={formatCents(growth.delta)} hint={`Inicial ${formatCents(growth.opening)}`} />
            <Stat label="Rendimentos lançados" value={growth.yields ? formatCents(growth.yields) : "Nenhum"} />
            <Stat label="Aportes para a reserva" value={growth.aportes ? formatCents(growth.aportes) : "Nenhum"} />
          </div>
        ) : (
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <Stat label="Comprometido em contas" value={formatCents(avail.committed)} hint="Soma das contas ainda não pagas." />
            <Stat label="Sobra depois das contas" value={formatCents(avail.free)} hint="Não inclui gasto que você ainda não lançou." />
            <Stat label="Movimento do mês nesta conta" value={formatCents(flows.incomeCents - flows.expenseCents)} />
          </div>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          {bucket === "reserva" ? (
            <>
              <Button variant="primary" onClick={() => onMove({ preset: "aporte", to: "reserva" })}>Aporte</Button>
              <Button onClick={() => onMove({ preset: "yield", to: "reserva" })}>Rendimento</Button>
              <Button onClick={() => onMove({ preset: "transfer", from: "reserva", to: "corrente" })}>Para a conta</Button>
            </>
          ) : (
            <>
              <Button variant="primary" onClick={() => onMove({ preset: "expense", from: "corrente" })}>Gasto</Button>
              <Button onClick={() => onMove({ preset: "income", to: "corrente" })}>Entrada</Button>
              <Button onClick={() => onMove({ preset: "transfer", from: "corrente", to: "reserva" })}>Para a reserva</Button>
            </>
          )}
          <Button onClick={() => onMove({ preset: "set-balance", bucket })}>Atualizar saldo</Button>
          {data.accounts[bucket].certainty !== "confirmed" ? (
            <Button onClick={() => commit("Confirmar saldo", (draft) => void (draft.accounts[bucket].certainty = "confirmed"))}>Confirmar valor</Button>
          ) : null}
        </div>
      </Card>
      <Card>
        <h2 className="mb-3 font-display text-xl">Evolução</h2>
        <CashChart points={cashSeries(data.movements).map((point) => (bucket === "reserva" ? { ...point, total: point.reserva } : { ...point, total: point.corrente }))} />
      </Card>
      {bucket === "corrente" ? (
        <Card>
          <h2 className="font-display text-xl">Contas pendentes</h2>
          <form
            className="mt-3 grid gap-3 sm:grid-cols-4"
            onSubmit={(event) => {
              event.preventDefault();
              const cents = parseBrlToCents(billAmount);
              if (!billName.trim() || cents == null || cents <= 0) {
                setBillError("Nome e valor da conta são obrigatórios.");
                return;
              }
              setBillError("");
              commit("Nova conta", (draft) => {
                draft.bills.push(blankBill({ name: billName.trim(), amountCents: cents, due: billDue || null }));
              });
              setBillName("");
              setBillAmount("");
              setBillDue("");
            }}
          >
            <Field label="Nome">
              <TextInput value={billName} onChange={(event) => setBillName(event.target.value)} />
            </Field>
            <Field label="Valor">
              <TextInput inputMode="decimal" value={billAmount} onChange={(event) => setBillAmount(event.target.value)} placeholder="0,00" />
            </Field>
            <Field label="Vencimento">
              <TextInput type="date" value={billDue} onChange={(event) => setBillDue(event.target.value)} />
            </Field>
            <div className="flex items-end">
              <Button variant="primary" type="submit">Adicionar</Button>
            </div>
          </form>
          {billError ? <p className="mt-2 text-sm text-loss">{billError}</p> : null}
          <div className="mt-4 grid gap-2">
            {data.bills.length === 0 ? <p className="text-sm text-muted">Nenhuma conta lançada.</p> : null}
            {data.bills.map((bill) => (
              <div key={bill.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-line px-3 py-2">
                <div>
                  <p className={bill.paid ? "text-muted line-through" : ""}>{bill.name}</p>
                  <p className="text-sm text-muted">{formatCents(bill.amountCents)}{bill.due ? ` · vence ${formatDate(bill.due)}` : ""}</p>
                </div>
                <div className="flex gap-2">
                  <Button onClick={() => commit(bill.paid ? "Reabrir conta" : "Pagar conta", (draft) => {
                    const found = draft.bills.find((item) => item.id === bill.id);
                    if (found) found.paid = !found.paid;
                  })}>{bill.paid ? "Reabrir" : "Paga"}</Button>
                  <Button variant="danger" onClick={() => {
                    if (window.confirm(`Apagar a conta “${bill.name}”?`)) commit("Apagar conta", (draft) => {
                      draft.bills = draft.bills.filter((item) => item.id !== bill.id);
                    });
                  }}>Apagar</Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ) : null}
      <Card>
        <h2 className="mb-3 font-display text-xl">Movimentos</h2>
        <MovementList rows={rows} />
      </Card>
    </div>
  );
}

export function MovementList({ rows }: { rows: import("@/lib/finance/types").Movement[] }) {
  if (!rows.length) return <p className="text-sm text-muted">Nenhum lançamento além do que já está no saldo.</p>;
  return (
    <div className="grid gap-2">
      {rows.slice(0, 12).map((movement) => (
        <div key={movement.id} className="flex items-center justify-between gap-3 text-sm">
          <span className={movement.voided ? "text-faint line-through" : ""}>
            <span className="block text-muted">{formatDate(movement.date)} · {KIND_LABEL[movement.kind]}</span>
            <span className="block">{movement.description}</span>
          </span>
          <span>{formatCents(movement.amountCents)}</span>
        </div>
      ))}
    </div>
  );
}
