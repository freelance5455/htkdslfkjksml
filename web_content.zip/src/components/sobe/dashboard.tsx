import { AllocationChart, CashChart, FlowChart } from "@/components/sobe/charts";
import { Badge, Button, Card, Stat } from "@/components/sobe/bits";
import type { MoveRequest } from "@/components/sobe/dialogs";
import { cryptoPosition, cashSeries, monthFlows, sumKind, wealthReport, type WealthPart } from "@/lib/finance/engine";
import { formatCents, formatRangeCents, monthKey, monthLabel, todayISO } from "@/lib/finance/money";
import { useFinance } from "@/lib/finance/store";
import type { View } from "@/components/sobe/shell";

export function Dashboard({
  onMove,
  onView,
  goalOpen,
}: {
  onMove: (request: MoveRequest) => void;
  onView: (view: View) => void;
  goalOpen: () => void;
}) {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const today = todayISO();
  const report = wealthReport(data);
  const flows = monthFlows(data.movements, monthKey(today));
  const yields = sumKind(data.movements, "yield");
  const pnl = cryptoPosition(data.assets).pnlCents;
  const confirmed = report.confirmedCents;
  const estimate =
    report.estimatedMinCents == null || report.estimatedMaxCents == null
      ? null
      : formatRangeCents(report.estimatedMinCents, report.estimatedMaxCents);

  return (
    <div className="sobe-rise grid gap-4">
      {!data.setupDismissed ? (
        <Card className="border-emerald">
          <p className="text-sm text-lime">Configuração inicial</p>
          <h2 className="mt-1 font-display text-2xl">Estes números são aproximados</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Reserva, conta e cripto vieram do que você lembra, não de um extrato. O Meu Padrinho veio das anotações e
            ainda espera a contagem física. Confirme ou corrija quando quiser. Nada disso foi tratado como renda.
          </p>
          <div className="mt-4 grid gap-2">
            <SetupRow
              label="Reserva"
              value={formatCents(report.reservaCents)}
              onConfirm={() => commit("Confirmar reserva", (draft) => void (draft.accounts.reserva.certainty = "confirmed"))}
              onFix={() => onMove({ preset: "set-balance", bucket: "reserva" })}
            />
            <SetupRow
              label="Conta corrente"
              value={formatCents(report.correnteCents)}
              onConfirm={() => commit("Confirmar conta", (draft) => void (draft.accounts.corrente.certainty = "confirmed"))}
              onFix={() => onMove({ preset: "set-balance", bucket: "corrente" })}
            />
            <SetupRow label="Criptomoedas" value="R$ 550,00 a R$ 600,00" onFix={() => onView("cripto")} fixLabel="Cadastrar ativos" />
            <SetupRow label="Meu Padrinho" value="R$ 1.030,00 a R$ 1.050,00" onFix={() => onView("padrinho")} fixLabel="Abrir contagem" />
          </div>
          <Button className="mt-4" variant="quiet" onClick={() => commit("Adiar conferência", (draft) => void (draft.setupDismissed = true))}>
            Deixar para depois
          </Button>
        </Card>
      ) : null}

      <Card className="bg-surface-2" >
        <p className="text-sm tracking-widest text-muted">{confirmed == null ? "PATRIMÔNIO ESTIMADO" : "PATRIMÔNIO CONFIRMADO"}</p>
        <div id="patrimonio" className="mt-2">
          {confirmed == null ? (
            <p className="font-display text-4xl leading-tight sm:text-6xl">{estimate}</p>
          ) : (
            <p className="font-display text-4xl leading-tight sm:text-6xl">{formatCents(confirmed)}</p>
          )}
        </div>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
          {confirmed == null
            ? "Nenhum valor foi confirmado ainda. A faixa junta as aproximações e as anotações do cofrinho. Não é um saldo exato."
            : `Fora desta conta confirmada, a leitura estimada é ${estimate}. Estimativa não substitui conferência.`}
        </p>
        <div className="mt-5 grid gap-3">
          {report.parts.map((part) => (
            <PartRow key={part.id} part={part} onOpen={() => onView(part.id === "corrente" ? "conta" : (part.id as View))} />
          ))}
        </div>
        {report.notes.length ? (
          <ul className="mt-4 grid gap-1 text-sm text-muted">
            {report.notes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        ) : null}
      </Card>

      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <Stat label={`Entradas em ${monthLabel(monthKey(today)).split(" de ")[0]}`} value={flows.incomeCents ? formatCents(flows.incomeCents) : "Nada lançado"} hint="Receitas e aportes vindos de fora. Transferência não entra." />
        </Card>
        <Card>
          <Stat label="Saídas do mês" value={flows.expenseCents ? formatCents(flows.expenseCents) : "Nada lançado"} hint="Só gastos. Levar da reserva para a conta não é gasto." />
        </Card>
        <Card>
          <Stat
            label="Rendimentos"
            value={yields ? formatCents(yields) : "Nada lançado"}
            hint={pnl == null ? "Sem rendimento em dinheiro registrado." : `Variação estimada da cripto: ${formatCents(pnl)}. Não é saldo na conta.`}
          />
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Button variant="primary" onClick={() => onMove({ preset: "aporte" })}>Aporte</Button>
        <Button onClick={() => onMove({ preset: "expense" })}>Gasto</Button>
        <Button onClick={() => onMove({ preset: "set-balance" })}>Atualizar saldo</Button>
        <Button onClick={goalOpen}>Nova meta</Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="mb-3 font-display text-xl">Caixa no tempo</h2>
          <CashChart points={cashSeries(data.movements)} />
        </Card>
        <Card>
          <h2 className="mb-3 font-display text-xl">Entradas e saídas</h2>
          <FlowChart movements={data.movements} />
        </Card>
        <Card className="lg:col-span-2">
          <h2 className="mb-3 font-display text-xl">Distribuição</h2>
          <AllocationChart report={report} />
        </Card>
      </div>
    </div>
  );
}

function PartRow({ part, onOpen }: { part: WealthPart; onOpen: () => void }) {
  const value = part.minCents == null || part.maxCents == null ? "Sem número" : formatRangeCents(part.minCents, part.maxCents);
  return (
    <button type="button" onClick={onOpen} className="flex min-h-11 items-center justify-between gap-3 rounded-2xl border border-line px-3 py-2 text-left">
      <span>
        <span className="block text-sm text-fg">{part.label}</span>
        <span className="block text-xs text-faint">{part.detail}</span>
      </span>
      <span className="text-right">
        <span className="block text-sm">{value}</span>
        <Badge state={part.state} />
      </span>
    </button>
  );
}

function SetupRow({
  label,
  value,
  onConfirm,
  onFix,
  fixLabel = "Corrigir",
}: {
  label: string;
  value: string;
  onConfirm?: () => void;
  onFix: () => void;
  fixLabel?: string;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-bg px-3 py-2">
      <div>
        <p className="text-sm text-muted">{label}</p>
        <p className="font-display text-xl">{value}</p>
      </div>
      <div className="flex gap-2">
        {onConfirm ? (
          <Button variant="primary" onClick={onConfirm}>
            Confirmar
          </Button>
        ) : null}
        <Button onClick={onFix}>{fixLabel}</Button>
      </div>
    </div>
  );
}
