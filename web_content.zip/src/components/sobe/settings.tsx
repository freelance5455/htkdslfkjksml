import { useState } from "react";
import { Button, Card, TextArea } from "@/components/sobe/bits";
import { downloadText } from "@/components/sobe/bits";
import { MoreMenu, type View } from "@/components/sobe/shell";
import { movementsToCsv, toBackup, validateBackup } from "@/lib/finance/backup";
import { wealthReport } from "@/lib/finance/engine";
import { formatRangeCents, todayISO } from "@/lib/finance/money";
import { createSeed } from "@/lib/finance/seed";
import { useFinance } from "@/lib/finance/store";

export function SettingsPage({ onView }: { onView: (view: View) => void }) {
  const data = useFinance((state) => state.data);
  const replaceAll = useFinance((state) => state.replaceAll);
  const [raw, setRaw] = useState("");
  const [preview, setPreview] = useState("");
  const [wipe, setWipe] = useState("");
  const [error, setError] = useState("");

  function exportJson() {
    const file = toBackup(data, new Date().toISOString());
    downloadText(`sobe-financeiro-${todayISO()}.json`, JSON.stringify(file, null, 2), "application/json");
  }

  function readBackup(text: string) {
    setError("");
    setPreview("");
    try {
      const parsed = JSON.parse(text) as unknown;
      const valid = validateBackup(parsed);
      if (!valid.ok) {
        setError(valid.error);
        return;
      }
      const report = wealthReport(valid.data);
      const estimate = report.estimatedMinCents == null || report.estimatedMaxCents == null ? "sem total" : formatRangeCents(report.estimatedMinCents, report.estimatedMaxCents);
      setPreview(`Backup válido. ${valid.data.movements.length} lançamentos, ${valid.data.assets.length} ativos, ${valid.data.padrinhoSnapshots.length} leituras do cofrinho. Patrimônio estimado nesse arquivo: ${estimate}.`);
      setRaw(text);
    } catch {
      setError("Este texto não é um JSON válido. Nada foi substituído.");
    }
  }

  return (
    <div className="sobe-rise grid gap-4">
      <MoreMenu onView={onView} />
      <Card>
        <h1 className="font-display text-4xl">Dados e backup</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          Os números ficam neste navegador. Nenhum saldo é enviado para servidor. Apagar os dados do navegador apaga o painel, por isso o backup JSON é a cópia que você guarda.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="primary" onClick={exportJson}>Exportar backup JSON</Button>
          <Button onClick={() => downloadText(`sobe-livro-${todayISO()}.csv`, movementsToCsv(data), "text/csv;charset=utf-8")}>Exportar CSV</Button>
        </div>
      </Card>
      <Card>
        <h2 className="font-display text-xl">Restaurar</h2>
        <p className="mt-2 text-sm text-muted">O arquivo é conferido antes de substituir o que está aqui. Baixe o backup atual antes, se este painel já tiver lançamentos.</p>
        <div className="mt-3">
          <TextArea value={raw} onChange={(event) => setRaw(event.target.value)} placeholder="Cole o JSON do backup" />
        </div>
        <input
          className="mt-3 block w-full text-sm text-muted"
          type="file"
          accept="application/json,.json"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => readBackup(String(reader.result ?? ""));
            reader.readAsText(file);
          }}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={() => readBackup(raw)}>Conferir arquivo</Button>
          <Button onClick={exportJson}>Baixar backup atual antes</Button>
          <Button
            variant="primary"
            onClick={() => {
              try {
                const valid = validateBackup(JSON.parse(raw) as unknown);
                if (!valid.ok) {
                  setError(valid.error);
                  return;
                }
                if (!window.confirm("Substituir os dados deste navegador pelo backup? Dá para desfazer em seguida, se nada der errado.")) return;
                replaceAll(valid.data, "Restaurar backup");
                setPreview("Backup restaurado.");
                setError("");
              } catch {
                setError("Não foi possível restaurar.");
              }
            }}
          >
            Restaurar
          </Button>
        </div>
        {preview ? <p className="mt-3 text-sm text-lime">{preview}</p> : null}
        {error ? <p className="mt-3 text-sm text-loss">{error}</p> : null}
      </Card>
      <Card>
        <h2 className="font-display text-xl">Como usar</h2>
        <div className="mt-3 grid gap-3 text-sm leading-relaxed text-muted">
          <p>No dia a dia, use o botão de mais para aporte, gasto ou saldo. Aporte vindo da conta para a reserva não aumenta o patrimônio. Gasto diminui. Rendimento é outro botão, separado do aporte.</p>
          <p>Para corrigir a reserva ou a conta, abra Atualizar saldo e informe o valor conferido. A diferença vira ajuste, não salário e não lucro. O saldo inicial aproximado continua no histórico.</p>
          <p>O Meu Padrinho só muda pela contagem das moedas e cédulas. Campo vazio não é zero. A faixa de R$ 180 a R$ 200 nas moedas de R$ 1 fica até você digitar a quantidade exata.</p>
          <p>Na cripto, cadastre cada ativo com a quantidade que você realmente tem. Atualizar cotação, quando houver internet, consulta só o código público da moeda. Sem rede, fica o último preço, com data e hora.</p>
          <p>Exporte o JSON de tempos em tempos e guarde o arquivo. Para trocar de celular, exporte aqui e restaure lá.</p>
        </div>
      </Card>
      <Card>
        <h2 className="font-display text-xl">Limitações</h2>
        <ul className="mt-3 grid list-disc gap-2 pl-5 text-sm leading-relaxed text-muted">
          <li>Os dados moram no armazenamento local deste navegador. Limpar histórico, cookies ou os dados do site apaga tudo o que não estiver num backup.</li>
          <li>Abrir em outro navegador ou no modo anônimo começa vazio até você restaurar o JSON.</li>
          <li>Não há login, nuvem nem sincronização. Isso é de propósito.</li>
          <li>Cotações dependem da CoinGecko quando você pede. O painel não promete preço, taxa nem rendimento futuro.</li>
          <li>Simulações do laboratório são hipotéticas e não são recomendação de compra.</li>
          <li>O total estimado inclui faixas. Ele não deve ser lido como saldo exato de banco.</li>
        </ul>
      </Card>
      <Card>
        <h2 className="font-display text-xl">Apagar neste navegador</h2>
        <p className="mt-2 text-sm text-muted">Digite APAGAR. Os valores aproximados iniciais voltam. Baixe um backup antes se quiser guardar o que está aqui.</p>
        <input className="mt-3 min-h-11 w-full rounded-xl border border-line bg-bg px-3" value={wipe} onChange={(event) => setWipe(event.target.value)} />
        <Button
          className="mt-3"
          variant="danger"
          onClick={() => {
            if (wipe !== "APAGAR") {
              setError("Digite APAGAR para confirmar.");
              return;
            }
            if (!window.confirm("Apagar os dados deste navegador e voltar aos valores iniciais aproximados?")) return;
            replaceAll(createSeed(todayISO()), "Recomeçar");
            setWipe("");
          }}
        >
          Apagar e recomeçar
        </Button>
      </Card>
    </div>
  );
}
