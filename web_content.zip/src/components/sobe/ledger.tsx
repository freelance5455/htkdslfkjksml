import { useMemo, useState } from "react";
import { Button, Card, Dialog, Field, SelectInput, TextInput } from "@/components/sobe/bits";
import { movementMatches, type FilterInput } from "@/lib/finance/engine";
import { endpointLabel, KIND_LABEL } from "@/lib/finance/labels";
import { fold, formatCents, formatDate, isIsoDate, parseBrlToCents, todayISO } from "@/lib/finance/money";
import { patchMovement, useFinance } from "@/lib/finance/store";
import type { Endpoint, Movement, MovementKind } from "@/lib/finance/types";

const KINDS = Object.keys(KIND_LABEL) as MovementKind[];

export function LedgerPage() {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [kind, setKind] = useState<MovementKind | "all">("all");
  const [category, setCategory] = useState("");
  const [endpoint, setEndpoint] = useState<Endpoint | "all">("all");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Movement | null>(null);

  const filter: FilterInput = useMemo(() => ({
    from,
    to,
    kind,
    category,
    endpoint,
    minCents: min.trim() ? parseBrlToCents(min) : null,
    maxCents: max.trim() ? parseBrlToCents(max) : null,
    query,
  }), [from, to, kind, category, endpoint, min, max, query]);

  const rows = data.movements.filter((movement) => movementMatches(movement, filter, fold)).slice().reverse();
  const categories = [...new Set(data.movements.map((movement) => movement.category).filter(Boolean))];

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <h1 className="font-display text-4xl">Livro-caixa</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          Tudo o que mexe no dinheiro fica aqui. Transferência muda onde o valor está, não o total. Gasto reduz. Rendimento e receita de fora podem aumentar. Correção de saldo não é lucro.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="De"><TextInput type="date" value={from} onChange={(event) => setFrom(event.target.value)} /></Field>
          <Field label="Até"><TextInput type="date" value={to} onChange={(event) => setTo(event.target.value)} /></Field>
          <Field label="Tipo">
            <SelectInput value={kind} onChange={(event) => setKind(event.target.value as MovementKind | "all")}>
              <option value="all">Todos</option>
              {KINDS.map((item) => <option key={item} value={item}>{KIND_LABEL[item]}</option>)}
            </SelectInput>
          </Field>
          <Field label="Categoria">
            <SelectInput value={category} onChange={(event) => setCategory(event.target.value)}>
              <option value="">Todas</option>
              {categories.map((item) => <option key={item} value={item}>{item}</option>)}
            </SelectInput>
          </Field>
          <Field label="Origem ou destino">
            <SelectInput value={endpoint} onChange={(event) => setEndpoint(event.target.value as Endpoint | "all")}>
              <option value="all">Todas</option>
              <option value="reserva">Reserva</option>
              <option value="corrente">Conta</option>
              <option value="padrinho">Meu Padrinho</option>
              <option value="externo">Fora</option>
            </SelectInput>
          </Field>
          <Field label="Palavra"><TextInput value={query} onChange={(event) => setQuery(event.target.value)} /></Field>
          <Field label="Valor mínimo"><TextInput inputMode="decimal" value={min} onChange={(event) => setMin(event.target.value)} /></Field>
          <Field label="Valor máximo"><TextInput inputMode="decimal" value={max} onChange={(event) => setMax(event.target.value)} /></Field>
        </div>
      </Card>
      <Card>
        <p className="mb-3 text-sm text-muted">{rows.length} lançamento{rows.length === 1 ? "" : "s"}</p>
        <div className="grid gap-2">
          {rows.map((movement) => (
            <button key={movement.id} type="button" onClick={() => setEditing(movement)} className="flex min-h-11 items-center justify-between gap-3 rounded-2xl border border-line px-3 py-2 text-left">
              <span className={movement.voided ? "text-faint line-through" : ""}>
                <span className="block text-xs text-muted">{formatDate(movement.date)} · {KIND_LABEL[movement.kind]} · {movement.category}</span>
                <span className="block">{movement.description}</span>
                <span className="block text-xs text-faint">{movement.from ? endpointLabel(movement.from) : "—"} → {movement.to ? endpointLabel(movement.to) : "—"}{movement.history.length ? " · corrigido" : ""}</span>
              </span>
              <span>{formatCents(movement.amountCents)}</span>
            </button>
          ))}
        </div>
      </Card>
      {editing ? (
        <EditDialog
          movement={editing}
          onClose={() => setEditing(null)}
          onSave={(next, reason) => {
            commit("Corrigir lançamento", (draft) => {
              patchMovement(draft, next.id, (current) => {
                current.date = next.date;
                current.amountCents = next.amountCents;
                current.category = next.category;
                current.description = next.description;
                current.note = next.note;
                current.from = next.from;
                current.to = next.to;
                if (current.kind === "opening" && (current.to === "reserva" || current.to === "corrente")) {
                  draft.accounts[current.to].certainty = "approximate";
                }
              }, reason);
            });
            setEditing(null);
          }}
          onVoid={() => {
            if (!window.confirm("Anular este lançamento? Ele sai dos saldos e continua visível, riscado.")) return;
            commit("Anular lançamento", (draft) => {
              const found = draft.movements.find((item) => item.id === editing.id);
              if (!found) return;
              found.voided = !found.voided;
              found.voidedAt = found.voided ? new Date().toISOString() : null;
            });
            setEditing(null);
          }}
          onDelete={() => {
            if (!window.confirm("Apagar de vez? Dá para desfazer pelo botão do topo, enquanto ele existir.")) return;
            commit("Apagar lançamento", (draft) => {
              draft.movements = draft.movements.filter((item) => item.id !== editing.id);
            });
            setEditing(null);
          }}
        />
      ) : null}
    </div>
  );
}

function EditDialog({
  movement,
  onClose,
  onSave,
  onVoid,
  onDelete,
}: {
  movement: Movement;
  onClose: () => void;
  onSave: (movement: Movement, reason: string) => void;
  onVoid: () => void;
  onDelete: () => void;
}) {
  const [date, setDate] = useState(movement.date);
  const [amount, setAmount] = useState((movement.amountCents / 100).toFixed(2).replace(".", ","));
  const [category, setCategory] = useState(movement.category);
  const [description, setDescription] = useState(movement.description);
  const [note, setNote] = useState(movement.note);
  const [reason, setReason] = useState("Correção");
  const [error, setError] = useState("");

  return (
    <Dialog title="Corrigir lançamento" subtitle="A versão anterior fica no histórico deste registro." onClose={onClose}>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = parseBrlToCents(amount);
          if (!isIsoDate(date) || cents == null || cents < 0) {
            setError("Data ou valor inválido.");
            return;
          }
          onSave({ ...movement, date, amountCents: cents, category, description, note }, reason || "Correção");
        }}
      >
        <Field label="Data"><TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} /></Field>
        <Field label="Valor"><TextInput inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} /></Field>
        <Field label="Categoria"><TextInput value={category} onChange={(event) => setCategory(event.target.value)} /></Field>
        <Field label="Descrição"><TextInput value={description} onChange={(event) => setDescription(event.target.value)} /></Field>
        <Field label="Observação"><TextInput value={note} onChange={(event) => setNote(event.target.value)} /></Field>
        <Field label="Motivo da correção"><TextInput value={reason} onChange={(event) => setReason(event.target.value)} /></Field>
        {movement.history.length ? <p className="text-sm text-muted">{movement.history.length} correção(ões) anterior(es). Última em {movement.history[movement.history.length - 1].at.slice(0, 10)}.</p> : null}
        {error ? <p className="text-sm text-loss">{error}</p> : null}
        <Button variant="primary" type="submit">Salvar correção</Button>
        <Button onClick={onVoid}>{movement.voided ? "Restaurar" : "Anular"}</Button>
        <Button variant="danger" onClick={onDelete}>Apagar de vez</Button>
      </form>
      <p className="mt-3 text-xs text-faint">Hoje é {formatDate(todayISO())}. Anular tira o efeito no saldo sem esquecer que o lançamento existiu.</p>
    </Dialog>
  );
}
