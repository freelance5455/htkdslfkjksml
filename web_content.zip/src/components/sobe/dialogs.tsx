import { useMemo, useState } from "react";
import { Button, Dialog, Field, SelectInput, TextArea, TextInput } from "@/components/sobe/bits";
import { bucketBalance } from "@/lib/finance/engine";
import { CATEGORIES } from "@/lib/finance/labels";
import { formatCents, isIsoDate, parseBrlToCents } from "@/lib/finance/money";
import { addCashMovement, setAbsoluteBalance, useFinance } from "@/lib/finance/store";
import type { BucketId, Endpoint, MovementKind } from "@/lib/finance/types";

export type MovePreset = "expense" | "income" | "aporte" | "yield" | "transfer" | "adjustment" | "set-balance";

export interface MoveRequest {
  preset: MovePreset;
  from?: string;
  to?: string;
  bucket?: BucketId;
}

const TITLES: Record<MovePreset, string> = {
  expense: "Registrar gasto",
  income: "Registrar entrada",
  aporte: "Adicionar aporte",
  yield: "Registrar rendimento",
  transfer: "Transferir",
  adjustment: "Ajuste de saldo",
  "set-balance": "Atualizar saldo",
};

export function MoveDialog({ request, onClose, onDone }: { request: MoveRequest; onClose: () => void; onDone: (message: string) => void }) {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const today = useMemo(() => new Date(), []);
  const iso = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(iso);
  const [from, setFrom] = useState(request.from ?? (request.preset === "expense" ? "corrente" : request.preset === "transfer" ? "reserva" : "externo"));
  const [to, setTo] = useState(request.to ?? (request.preset === "expense" ? "externo" : request.preset === "income" ? "corrente" : request.preset === "transfer" ? "corrente" : "reserva"));
  const [bucket, setBucket] = useState<BucketId>(request.bucket ?? (request.preset === "expense" ? "corrente" : "reserva"));
  const [direction, setDirection] = useState<"up" | "down">("up");
  const [category, setCategory] = useState(CATEGORIES[request.preset === "set-balance" ? "adjustment" : request.preset]?.[0] ?? "Outros");
  const [description, setDescription] = useState(TITLES[request.preset]);
  const [note, setNote] = useState("");
  const [workedDay, setWorkedDay] = useState(false);
  const [confirmAccount, setConfirmAccount] = useState(request.preset === "set-balance");
  const [error, setError] = useState("");

  const suggestions = CATEGORIES[request.preset === "set-balance" ? "adjustment" : request.preset] ?? [];
  const previewBalance = bucket === "reserva" || bucket === "corrente" ? bucketBalance(data.movements, bucket) : bucketBalance(data.movements, "corrente");

  function save() {
    if (!isIsoDate(date)) {
      setError("Informe uma data válida.");
      return;
    }
    commit(TITLES[request.preset], (draft) => {
      if (request.preset === "set-balance") {
        const next = parseBrlToCents(amount);
        if (next == null || next < 0) throw new Error("Informe o saldo conferido, com vírgula se houver centavos.");
        const changed = setAbsoluteBalance(draft, bucket, next, date, note);
        if (!changed) draft.accounts[bucket].certainty = "confirmed";
        return;
      }
      const cents = parseBrlToCents(amount);
      if (cents == null || cents <= 0) throw new Error("Informe um valor maior que zero. Exemplo: 10,50.");
      let kind: MovementKind = request.preset === "adjustment" ? "adjustment" : request.preset;
      let origin: Endpoint | null = from as Endpoint;
      let dest: Endpoint | null = to as Endpoint;
      if (request.preset === "adjustment") {
        origin = direction === "down" ? bucket : null;
        dest = direction === "up" ? bucket : null;
        kind = "adjustment";
      }
      if (request.preset === "yield") {
        origin = null;
        dest = to === "corrente" ? "corrente" : "reserva";
      }
      if (request.preset === "expense" && origin !== "reserva" && origin !== "corrente") {
        throw new Error("Escolha se o gasto saiu da conta ou da reserva.");
      }
      if (request.preset === "transfer" && (origin === dest || (origin !== "reserva" && origin !== "corrente") || (dest !== "reserva" && dest !== "corrente"))) {
        throw new Error("A transferência precisa sair de uma conta e entrar na outra.");
      }
      if (request.preset === "aporte" && origin === dest) throw new Error("Origem e destino do aporte não podem ser iguais.");
      if (request.preset === "aporte" && dest !== "reserva" && dest !== "corrente") {
        throw new Error("Aporte em dinheiro vai para a reserva ou a conta. O Meu Padrinho entra pela contagem das peças.");
      }
      addCashMovement(draft, {
        date,
        kind,
        amountCents: cents,
        from: origin,
        to: dest,
        category: category.trim() || "Outros",
        description: description.trim() || TITLES[request.preset],
        note: note.trim(),
        isAporte: request.preset === "aporte",
        workedDay: request.preset === "aporte" && workedDay,
      });
      if (confirmAccount && (request.preset === "adjustment" || request.preset === "set-balance")) {
        draft.accounts[bucket].certainty = "confirmed";
      }
    });
    try {
      onDone("Lançamento salvo neste aparelho.");
      onClose();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível salvar.");
    }
  }

  function guardedSave() {
    setError("");
    try {
      if (request.preset !== "set-balance") {
        const cents = parseBrlToCents(amount);
        if (cents == null || cents <= 0) {
          setError("Informe um valor maior que zero. Exemplo: 10,50.");
          return;
        }
      } else if (parseBrlToCents(amount) == null || (parseBrlToCents(amount) ?? -1) < 0) {
        setError("Informe o saldo conferido.");
        return;
      }
      save();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível salvar.");
    }
  }

  return (
    <Dialog title={TITLES[request.preset]} subtitle="Transferência interna não aumenta o patrimônio. Rendimento não é aporte." onClose={onClose}>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          guardedSave();
        }}
      >
        {request.preset === "set-balance" || request.preset === "adjustment" ? (
          <Field label="Conta">
            <SelectInput value={bucket} onChange={(event) => setBucket(event.target.value as BucketId)}>
              <option value="reserva">Reserva · agora {formatCents(bucketBalance(data.movements, "reserva"))}</option>
              <option value="corrente">Conta · agora {formatCents(bucketBalance(data.movements, "corrente"))}</option>
            </SelectInput>
          </Field>
        ) : null}
        {request.preset === "adjustment" ? (
          <Field label="O saldo real está">
            <SelectInput value={direction} onChange={(event) => setDirection(event.target.value as "up" | "down")}>
              <option value="up">Maior — somar a diferença</option>
              <option value="down">Menor — tirar a diferença</option>
            </SelectInput>
          </Field>
        ) : null}
        <Field label={request.preset === "set-balance" ? "Saldo conferido" : "Valor"} hint="Use vírgula nos centavos. Exemplo: 10,50">
          <TextInput inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0,00" autoFocus />
        </Field>
        <Field label="Data">
          <TextInput type="date" value={date} onChange={(event) => setDate(event.target.value)} />
        </Field>
        {request.preset === "expense" ? (
          <Field label="Saiu de">
            <SelectInput value={from} onChange={(event) => setFrom(event.target.value)}>
              <option value="corrente">Conta corrente</option>
              <option value="reserva">Reserva</option>
            </SelectInput>
          </Field>
        ) : null}
        {request.preset === "income" || request.preset === "yield" ? (
          <Field label="Entrou em">
            <SelectInput value={to} onChange={(event) => setTo(event.target.value)}>
              <option value="corrente">Conta corrente</option>
              <option value="reserva">Reserva</option>
            </SelectInput>
          </Field>
        ) : null}
        {request.preset === "aporte" ? (
          <>
            <Field label="Origem">
              <SelectInput value={from} onChange={(event) => setFrom(event.target.value)}>
                <option value="externo">Dinheiro novo, de fora</option>
                <option value="corrente">Conta corrente</option>
                <option value="reserva">Reserva</option>
              </SelectInput>
            </Field>
            <Field label="Destino">
              <SelectInput value={to} onChange={(event) => setTo(event.target.value)}>
                <option value="reserva">Reserva</option>
                <option value="corrente">Conta corrente</option>
              </SelectInput>
            </Field>
            <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
              <input type="checkbox" checked={workedDay} onChange={(event) => setWorkedDay(event.target.checked)} />
              Foi um dia de trabalho
            </label>
          </>
        ) : null}
        {request.preset === "transfer" ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="De">
              <SelectInput value={from} onChange={(event) => setFrom(event.target.value)}>
                <option value="reserva">Reserva</option>
                <option value="corrente">Conta corrente</option>
              </SelectInput>
            </Field>
            <Field label="Para">
              <SelectInput value={to} onChange={(event) => setTo(event.target.value)}>
                <option value="corrente">Conta corrente</option>
                <option value="reserva">Reserva</option>
              </SelectInput>
            </Field>
          </div>
        ) : null}
        <Field label="Categoria">
          <TextInput list="cats" value={category} onChange={(event) => setCategory(event.target.value)} />
          <datalist id="cats">
            {suggestions.map((item) => (
              <option key={item} value={item} />
            ))}
          </datalist>
        </Field>
        <Field label="Descrição">
          <TextInput value={description} onChange={(event) => setDescription(event.target.value)} />
        </Field>
        <Field label="Observação">
          <TextArea value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
        {request.preset === "adjustment" ? (
          <label className="flex min-h-11 items-center gap-2 text-sm text-muted">
            <input type="checkbox" checked={confirmAccount} onChange={(event) => setConfirmAccount(event.target.checked)} />
            Marcar esta conta como conferida
          </label>
        ) : null}
        {request.preset === "set-balance" ? (
          <p className="text-sm text-muted">Saldo no painel agora: {formatCents(previewBalance)}. A diferença entra como ajuste, não como renda.</p>
        ) : null}
        {request.preset === "yield" ? <p className="text-sm text-muted">Rendimento não se mistura com aporte. Nada aqui é previsão do futuro.</p> : null}
        {error ? <p className="text-sm text-loss">{error}</p> : null}
        <Button variant="primary" type="submit">
          Salvar
        </Button>
      </form>
    </Dialog>
  );
}

export function LaunchSheet({
  onClose,
  onMove,
  onGo,
  onExport,
}: {
  onClose: () => void;
  onMove: (request: MoveRequest) => void;
  onGo: (view: "cripto" | "padrinho" | "metas" | "inicio") => void;
  onExport: () => void;
}) {
  const items: { label: string; run: () => void }[] = [
    { label: "Adicionar aporte", run: () => onMove({ preset: "aporte" }) },
    { label: "Registrar gasto", run: () => onMove({ preset: "expense" }) },
    { label: "Registrar entrada", run: () => onMove({ preset: "income" }) },
    { label: "Transferir", run: () => onMove({ preset: "transfer" }) },
    { label: "Atualizar saldo", run: () => onMove({ preset: "set-balance" }) },
    { label: "Registrar rendimento", run: () => onMove({ preset: "yield" }) },
    { label: "Moedas e cédulas", run: () => onGo("padrinho") },
    { label: "Atualizar criptomoedas", run: () => onGo("cripto") },
    { label: "Criar uma meta", run: () => onGo("metas") },
    { label: "Ver patrimônio", run: () => onGo("inicio") },
    { label: "Exportar backup", run: onExport },
  ];
  return (
    <Dialog title="Lançar agora" subtitle="Atalhos do dia. O formulário é curto de propósito." onClose={onClose}>
      <div className="grid gap-2">
        {items.map((item) => (
          <Button key={item.label} onClick={item.run}>
            {item.label}
          </Button>
        ))}
      </div>
    </Dialog>
  );
}
