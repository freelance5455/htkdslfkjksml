import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { PartState } from "@/lib/finance/engine";

export function Mark({ className }: { className?: string }) {
  return (
    <svg className={cn("size-8", className)} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="10" fill="var(--color-emerald-deep)" />
      <path d="M8 22c2.2-7 4.4-10 8-10s5.8 3 8 10" fill="none" stroke="var(--color-lime)" strokeWidth="2" strokeLinecap="round" />
      <circle cx="16" cy="12" r="1.7" fill="var(--color-lime)" />
    </svg>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-3xl border border-line bg-surface p-5", className)}>{children}</section>;
}

type ButtonVariant = "primary" | "ghost" | "danger" | "quiet";

export function Button({
  variant = "ghost",
  className,
  type = "button",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-4 text-sm font-medium transition-opacity disabled:opacity-40",
        variant === "primary" && "bg-lime text-lime-ink",
        variant === "ghost" && "border border-line bg-surface-2 text-fg",
        variant === "danger" && "border border-line bg-surface text-loss",
        variant === "quiet" && "px-2 text-muted",
        className,
      )}
      {...props}
    />
  );
}

const STATE_LABEL: Record<PartState, string> = {
  confirmed: "Confirmado",
  approximate: "Aproximado",
  estimated: "Estimado",
  unknown: "Não conferido",
  partial: "Parcial",
};

export function Badge({ state }: { state: PartState }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-1 text-xs",
        state === "confirmed" && "border-emerald bg-emerald-deep text-fg",
        state === "approximate" && "border-line text-muted",
        state === "estimated" && "border-line text-lime",
        state === "unknown" && "border-line text-faint",
        state === "partial" && "border-line text-muted",
      )}
    >
      {STATE_LABEL[state]}
    </span>
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-bg px-3 text-base text-fg outline-none focus:border-emerald";

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm text-muted">{label}</span>
      {children}
      {hint ? <span className="mt-1 block text-sm text-faint">{hint}</span> : null}
    </label>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input className={fieldClass} {...props} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(fieldClass, "min-h-28 py-3")} {...props} />;
}

export function SelectInput(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={fieldClass} {...props} />;
}

export function Dialog({
  title,
  subtitle,
  onClose,
  children,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 sm:items-center sm:p-6" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-line bg-surface p-5 sm:max-w-lg sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl">{title}</h2>
            {subtitle ? <p className="mt-1 text-sm text-muted">{subtitle}</p> : null}
          </div>
          <Button variant="quiet" onClick={onClose} aria-label="Fechar">
            Fechar
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function NeedHistory({ children }: { children: ReactNode }) {
  return <p className="rounded-2xl border border-dashed border-line px-4 py-6 text-sm leading-relaxed text-muted">{children}</p>;
}

export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="min-w-0">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-display text-2xl leading-tight text-fg">{value}</p>
      {hint ? <p className="mt-1 text-sm text-muted">{hint}</p> : null}
    </div>
  );
}

export function downloadText(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function MoneyText({ cents }: { cents: number | null }) {
  if (cents == null) return <span className="text-muted">sem valor</span>;
  return <span>{formatSafe(cents)}</span>;
}

function formatSafe(cents: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
}
