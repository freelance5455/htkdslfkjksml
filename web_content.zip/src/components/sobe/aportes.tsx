import { useState } from "react";
import { Button, Card, Field, TextArea, TextInput } from "@/components/sobe/bits";
import { AporteChart } from "@/components/sobe/charts";
import type { MoveRequest } from "@/components/sobe/dialogs";
import { aporteMovements, aporteStats, monthAporteCents } from "@/lib/finance/engine";
import { endpointLabel } from "@/lib/finance/labels";
import { formatCents, formatDate, monthKey, monthLabel, parseBrlToCents, todayISO } from "@/lib/finance/money";
import { useFinance } from "@/lib/finance/store";

export function AportesPage({ onMove }: { onMove: (request: MoveRequest) => void }) {
  const data = useFinance((state) => state.data);
  const commit = useFinance((state) => state.commit);
  const today = todayISO();
  const stats = aporteStats(data.movements, today);
  const month = monthAporteCents(data.movements, monthKey(today));
  const [day, setDay] = useState(data.strategy.perDayCents != null ? (data.strategy.perDayCents / 100).toString().replace(".", ",") : "");
  const [week, setWeek] = useState(data.strategy.perWeekCents != null ? (data.strategy.perWeekCents / 100).toString().replace(".", ",") : "");
  const [monthRef, setMonthRef] = useState(data.strategy.perMonthCents != null ? (data.strategy.perMonthCents / 100).toString().replace(".", ",") : "");
  const [note, setNote] = useState(data.strategy.note);
  const [error, setError] = useState("");
  const rows = aporteMovements(data.movements).slice().reverse();

  return (
    <div className="sobe-rise grid gap-4">
      <Card>
        <p className="text-sm text-muted">Disciplina</p>
        <h1 className="font-display text-4xl">Aportes</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">{data.strategy.note}</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Block label="Total registrado" value={stats.count ? formatCents(stats.totalCents) : "Nenhum aporte"} />
          <Block label="Média nos dias com aporte" value={stats.avgPerActiveDayCents == null ? "—" : formatCents(stats.avgPerActiveDayCents)} />
          <Block label="Maior aporte" value={stats.largestCents == null ? "—" : formatCents(stats.largestCents)} />
          <Block label="Média nas semanas com aporte" value={stats.avgPerActiveWeekCents == null ? "—" : formatCents(stats.avgPerActiveWeekCents)} />
          <Block label="Média nos meses com aporte" value={stats.avgPerActiveMonthCents == null ? "—" : formatCents(stats.avgPerActiveMonthCents)} />
          <Block label={stats.streakActive ? "Sequência atual" : "Última sequência"} value={stats.streak ? `${stats.streak} dia${stats.streak > 1 ? "s" : ""}` : "Ainda não"} />
        </div>
        <p className="mt-3 text-sm text-muted">
          Dias com aporte: {stats.activeDays}. Dias de trabalho marcados: {stats.workedDays}. {stats.lastDate ? `Último em ${formatDate(stats.lastDate)}.` : ""} Dia sem registro não vira dívida.
        </p>
        <div className="mt-4">
          <Button variant="primary" onClick={() => onMove({ preset: "aporte" })}>Registrar aporte</Button>
        </div>
      </Card>
      <Card>
        <h2 className="font-display text-xl">Referência, sem obrigação</h2>
        <p className="mt-2 text-sm text-muted">
          Neste mês foram registrados {formatCents(month)}. Se você definir uma referência, a comparação é só informativa.
          {data.strategy.perMonthCents != null ? ` Referência mensal: ${formatCents(data.strategy.perMonthCents)}.` : ""}
          {data.strategy.perDayCents != null && stats.avgPerActiveDayCents != null ? ` A média dos dias com aporte está ${stats.avgPerActiveDayCents >= data.strategy.perDayCents ? "na referência ou acima" : "abaixo da referência por dia"}, sem cobrar os dias em branco.` : ""}
        </p>
        <form
          className="mt-3 grid gap-3 sm:grid-cols-3"
          onSubmit={(event) => {
            event.preventDefault();
            const perDay = day.trim() ? parseBrlToCents(day) : null;
            const perWeek = week.trim() ? parseBrlToCents(week) : null;
            const perMonth = monthRef.trim() ? parseBrlToCents(monthRef) : null;
            if ((day.trim() && perDay == null) || (week.trim() && perWeek == null) || (monthRef.trim() && perMonth == null)) {
              setError("Use valores como 5 ou 10,50, ou deixe em branco.");
              return;
            }
            setError("");
            commit("Referência de aportes", (draft) => {
              draft.strategy.perDayCents = perDay;
              draft.strategy.perWeekCents = perWeek;
              draft.strategy.perMonthCents = perMonth;
              draft.strategy.note = note;
            });
          }}
        >
          <Field label="Por dia, opcional"><TextInput inputMode="decimal" value={day} onChange={(event) => setDay(event.target.value)} placeholder="em branco" /></Field>
          <Field label="Por semana, opcional"><TextInput inputMode="decimal" value={week} onChange={(event) => setWeek(event.target.value)} placeholder="em branco" /></Field>
          <Field label="Por mês, opcional"><TextInput inputMode="decimal" value={monthRef} onChange={(event) => setMonthRef(event.target.value)} placeholder="em branco" /></Field>
          <div className="sm:col-span-3">
            <Field label="Nota da estratégia"><TextArea value={note} onChange={(event) => setNote(event.target.value)} /></Field>
          </div>
          {error ? <p className="text-sm text-loss sm:col-span-3">{error}</p> : null}
          <Button variant="primary" type="submit">Salvar referência</Button>
        </form>
      </Card>
      <Card>
        <h2 className="mb-3 font-display text-xl">Aportes por mês</h2>
        <AporteChart movements={data.movements} />
      </Card>
      <Card>
        <h2 className="mb-3 font-display text-xl">Registros</h2>
        <p className="mb-3 text-sm text-muted">{monthLabel(monthKey(today))} não presume aporte em dia vazio.</p>
        <div className="grid gap-2">
          {rows.length === 0 ? <p className="text-sm text-muted">Nenhum aporte lançado.</p> : null}
          {rows.map((row) => (
            <div key={row.id} className="flex items-center justify-between gap-3 text-sm">
              <span>
                <span className="block text-muted">{formatDate(row.date)} · {row.from ? endpointLabel(row.from) : "—"} → {row.to ? endpointLabel(row.to) : "—"}</span>
                <span className="block">{row.description}{row.workedDay ? " · dia de trabalho" : ""}</span>
              </span>
              <span>{formatCents(row.amountCents)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Block({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-sm text-muted">{label}</p>
      <p className="font-display text-2xl leading-tight">{value}</p>
    </div>
  );
}
