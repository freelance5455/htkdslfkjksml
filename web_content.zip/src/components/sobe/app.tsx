import { useEffect, useState } from "react";
import { Mark } from "@/components/sobe/bits";
import { AportesPage } from "@/components/sobe/aportes";
import { CashPage } from "@/components/sobe/cash";
import { CryptoPage } from "@/components/sobe/crypto";
import { Dashboard } from "@/components/sobe/dashboard";
import { LaunchSheet, MoveDialog, type MoveRequest } from "@/components/sobe/dialogs";
import { GoalsPage } from "@/components/sobe/goals";
import { LedgerPage } from "@/components/sobe/ledger";
import { PadrinhoPage } from "@/components/sobe/padrinho";
import { SettingsPage } from "@/components/sobe/settings";
import { Shell, type View } from "@/components/sobe/shell";
import { downloadText } from "@/components/sobe/bits";
import { toBackup } from "@/lib/finance/backup";
import { todayISO } from "@/lib/finance/money";
import { useFinance } from "@/lib/finance/store";

export function SobeApp() {
  const ready = useFinance((state) => state.ready);
  const boot = useFinance((state) => state.boot);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    boot();
    setMounted(true);
  }, [boot]);

  if (!mounted || !ready) {
    return (
      <main className="min-h-screen bg-bg px-6 py-16 text-fg">
        <Mark />
        <p className="mt-6 text-sm tracking-widest text-muted">SOBÉ</p>
        <h1 className="font-display text-5xl">Financeiro</h1>
        <p className="mt-3 max-w-md text-muted">Abrindo o painel guardado neste aparelho.</p>
      </main>
    );
  }

  return <ReadyApp />;
}

function ReadyApp() {
  const data = useFinance((state) => state.data);
  const undo = useFinance((state) => state.undo);
  const undoLast = useFinance((state) => state.undoLast);
  const warning = useFinance((state) => state.warning);
  const locked = useFinance((state) => state.locked);
  const downloadRaw = useFinance((state) => state.downloadRaw);
  const unlockWithSeed = useFinance((state) => state.unlockWithSeed);
  const [view, setView] = useState<View>("inicio");
  const [move, setMove] = useState<MoveRequest | null>(null);
  const [sheet, setSheet] = useState(false);
  const [goalOpen, setGoalOpen] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);

  function exportBackup() {
    downloadText(`sobe-financeiro-${todayISO()}.json`, JSON.stringify(toBackup(data, new Date().toISOString()), null, 2), "application/json");
    setFlash("Backup baixado. Guarde o arquivo.");
    setSheet(false);
  }

  if (locked) {
    return (
      <main className="min-h-screen bg-bg px-6 py-16 text-fg">
        <h1 className="font-display text-4xl">Os dados salvos precisam de atenção</h1>
        <p className="mt-3 max-w-xl text-muted">{warning}</p>
        <div className="mt-6 flex flex-wrap gap-2">
          <button type="button" className="min-h-11 rounded-full bg-lime px-4 text-lime-ink" onClick={downloadRaw}>
            Baixar cópia recuperada
          </button>
          <button type="button" className="min-h-11 rounded-full border border-line px-4" onClick={() => {
            if (window.confirm("Começar de novo com os valores aproximados? A cópia ilegível deixa de ser protegida.")) unlockWithSeed();
          }}>
            Recomeçar
          </button>
        </div>
      </main>
    );
  }

  return (
    <Shell
      view={view}
      onView={(next) => {
        setView(next);
        if (next !== "metas") setGoalOpen(false);
      }}
      onLaunch={() => setSheet(true)}
      undoLabel={undo[0]?.label ?? null}
      onUndo={() => {
        undoLast();
        setFlash("Última alteração desfeita.");
      }}
    >
      {flash ? <p className="mb-4 rounded-2xl border border-line bg-surface px-4 py-3 text-sm text-lime">{flash}</p> : null}
      {warning ? <p className="mb-4 text-sm text-loss">{warning}</p> : null}
      <div data-ready="true">
        {view === "inicio" ? <Dashboard onMove={setMove} onView={setView} goalOpen={() => { setView("metas"); setGoalOpen(true); }} /> : null}
        {view === "reserva" ? <CashPage bucket="reserva" onMove={setMove} /> : null}
        {view === "conta" ? <CashPage bucket="corrente" onMove={setMove} /> : null}
        {view === "padrinho" ? <PadrinhoPage /> : null}
        {view === "cripto" ? <CryptoPage /> : null}
        {view === "aportes" ? <AportesPage onMove={setMove} /> : null}
        {view === "livro" ? <LedgerPage /> : null}
        {view === "metas" ? <GoalsPage openForm={goalOpen} onFormClose={() => setGoalOpen(false)} /> : null}
        {view === "ajustes" ? <SettingsPage onView={setView} /> : null}
      </div>
      {sheet ? (
        <LaunchSheet
          onClose={() => setSheet(false)}
          onMove={(request) => {
            setSheet(false);
            setMove(request);
          }}
          onGo={(next) => {
            setSheet(false);
            setView(next);
            if (next === "metas") setGoalOpen(true);
          }}
          onExport={exportBackup}
        />
      ) : null}
      {move ? <MoveDialog request={move} onClose={() => setMove(null)} onDone={setFlash} /> : null}
    </Shell>
  );
}
