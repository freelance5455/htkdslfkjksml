import React, { useState } from 'react';
import { StudentProfile, EssayResult, SavedHistoryItem, ActiveTab } from '../types';
import {
  BookMarked,
  Sparkles,
  Sliders,
  Copy,
  Printer,
  Download,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  ListTree,
  Quote,
  Clock,
  Layers,
  FileCheck2,
  FileDown
} from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface EssayWriterProps {
  profile: StudentProfile;
  onSaveHistory: (item: Omit<SavedHistoryItem, 'id' | 'timestamp'>) => void;
  onUpdateStats: (key: keyof StudentProfile) => void;
  setActiveTab: (tab: ActiveTab) => void;
  onSendToGrammar: (text: string) => void;
}

export const EssayWriter: React.FC<EssayWriterProps> = ({
  profile,
  onSaveHistory,
  onUpdateStats,
  setActiveTab,
  onSendToGrammar,
}) => {
  const [topic, setTopic] = useState('');
  const [wordCount, setWordCount] = useState<number>(500);
  const [essayType, setEssayType] = useState('Argumentative');
  const [thesisGuidance, setThesisGuidance] = useState('');
  const [citationStyle, setCitationStyle] = useState('MLA');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EssayResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const essayPromptSuggestions = [
    'Should standardized testing be abolished in public schools?',
    'The causes and lasting impact of the Industrial Revolution',
    'How artificial intelligence is reshaping modern creative arts',
    'Analyze the theme of courage in Harper Lee’s To Kill a Mockingbird',
    'The ethics of space exploration versus addressing climate change on Earth',
    'Why media literacy should be a mandatory school subject',
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter an essay topic.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-essay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          essayType,
          wordCount,
          grade: profile.grade,
          thesisGuidance: thesisGuidance.trim() || undefined,
          citationStyle,
          studentName: profile.name,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate essay.');
      }

      setResult(data.data);
      onUpdateStats('writtenEssaysCount');
      fireCelebration();

      onSaveHistory({
        type: 'essay',
        title: data.data.title || topic.trim(),
        data: data.data,
        gradeWhenCreated: profile.grade,
      });
    } catch (err: any) {
      setError(err.message || 'Something went wrong while generating the essay.');
    } finally {
      setLoading(false);
    }
  };

  const copyText = () => {
    if (!result) return;
    const fullText = `${result.title}\n\nThesis Statement: ${result.thesisStatement}\n\n${result.essay}\n\nWorks Cited:\n${result.worksCited.join('\n')}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadText = () => {
    if (!result) return;
    const fullText = `${result.title}\n\nThesis: ${result.thesisStatement}\n\n${result.essay}\n\nWorks Cited (${citationStyle}):\n${result.worksCited.join('\n')}`;
    const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${result.title.replace(/[^a-zA-Z0-9]/g, '_')}_Essay.txt`;
    link.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <BookMarked className="w-3.5 h-3.5" />
            Essay Studio
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Grade-Calibrated Essay Generator
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Complete structured essays with thesis statements, body paragraphs, and citations calibrated for{' '}
            <span className="font-semibold text-emerald-600">{profile.grade}</span>.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-2xl flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Input Form */}
        <div className="lg:col-span-5 space-y-6">
          <form
            onSubmit={handleGenerate}
            className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5"
          >
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center justify-between">
              <span>Essay Specifications</span>
              <span className="text-[11px] text-emerald-700 font-bold px-2 py-0.5 bg-emerald-50 rounded-full">
                {profile.grade}
              </span>
            </h3>

            {/* Essay Topic */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Essay Topic / Prompt
              </label>
              <textarea
                rows={3}
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Discuss the social and economic consequences of the Industrial Revolution..."
                className="w-full px-4 py-3 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-800 text-xs sm:text-sm transition resize-none"
              />
            </div>

            {/* Prompt Suggestions */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                Popular Essay Prompts
              </span>
              <div className="flex flex-wrap gap-1.5">
                {essayPromptSuggestions.slice(0, 4).map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setTopic(sug)}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 border border-slate-200/60 transition cursor-pointer text-left truncate max-w-full"
                  >
                    {sug}
                  </button>
                ))}
              </div>
            </div>

            {/* Word Count Slider & Presets */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                  Target Essay Length
                </label>
                <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-lg">
                  {wordCount} words
                </span>
              </div>
              <input
                type="range"
                min="250"
                max="1200"
                step="50"
                value={wordCount}
                onChange={(e) => setWordCount(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
              <div className="flex justify-between items-center mt-2 gap-1">
                {[300, 500, 750, 1000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setWordCount(preset)}
                    className={`text-[10px] font-bold px-2 py-1 rounded-lg transition cursor-pointer ${
                      wordCount === preset
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {preset}w
                  </button>
                ))}
              </div>
            </div>

            {/* Essay Type */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Essay Type
                </label>
                <select
                  value={essayType}
                  onChange={(e) => setEssayType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/30 cursor-pointer"
                >
                  <option value="Argumentative">Argumentative</option>
                  <option value="Expository / Analytical">Expository / Analytical</option>
                  <option value="Narrative">Narrative Essay</option>
                  <option value="Compare & Contrast">Compare & Contrast</option>
                  <option value="DBQ / Historical Analysis">DBQ / Historical Analysis</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Citation Style
                </label>
                <select
                  value={citationStyle}
                  onChange={(e) => setCitationStyle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/30 cursor-pointer"
                >
                  <option value="MLA">MLA 9th Ed.</option>
                  <option value="APA">APA 7th Ed.</option>
                  <option value="Chicago">Chicago</option>
                  <option value="None">None</option>
                </select>
              </div>
            </div>

            {/* Optional Thesis / Stance guidance */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center justify-between">
                <span>Specific Stance or Thesis (Optional)</span>
                <span className="text-[10px] text-slate-400 font-normal">Auto-crafted if empty</span>
              </label>
              <input
                type="text"
                value={thesisGuidance}
                onChange={(e) => setThesisGuidance(e.target.value)}
                placeholder="e.g. Argue that renewable energy creates more jobs than fossil fuels"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/30 text-xs text-slate-800"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !topic.trim()}
              className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition cursor-pointer ${
                loading || !topic.trim()
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-500/25'
              }`}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Drafting complete essay for {profile.grade}...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Generate Full Grade-Tuned Essay</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Column: Generated Essay Output */}
        <div className="lg:col-span-7 space-y-6">
          {!result && !loading && (
            <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs">
              <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
                <BookOpen className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">
                Ready to compose your essay
              </h3>
              <p className="text-sm text-slate-500 max-w-md mt-1">
                Enter your essay prompt and length target on the left. The AI will write an engaging hook, thesis statement, evidence-backed body paragraphs, and bibliography calibrated to {profile.grade}.
              </p>
            </div>
          )}

          {loading && (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs space-y-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-emerald-100 border-t-emerald-600 animate-spin" />
                <Sparkles className="w-6 h-6 text-amber-500 absolute animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Constructing Arguments & Outlining
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Synthesizing hook, thesis, evidence paragraphs, counter-arguments, and citations for {profile.grade}...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Main Essay Card */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
                {/* Essay Header and Meta */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wide">
                      {essayType}
                    </span>
                    <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      ~{result.readingTimeMinutes} min read • {result.actualWordCount} words
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyText}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                    <button
                      onClick={downloadText}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download .txt
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="p-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition"
                      title="Print essay"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Title */}
                <div className="text-center py-2">
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-serif">
                    {result.title}
                  </h2>
                </div>

                {/* Thesis Statement Banner */}
                <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">
                    Central Thesis Statement
                  </span>
                  <p className="text-xs sm:text-sm font-semibold text-emerald-950 font-serif italic">
                    "{result.thesisStatement}"
                  </p>
                </div>

                {/* Outline Summary */}
                {result.outline && result.outline.length > 0 && (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <ListTree className="w-4 h-4 text-emerald-600" />
                      Structural Outline
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {result.outline.map((sec, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-white border border-slate-200/60">
                          <span className="font-bold text-emerald-800 block">{sec.section}</span>
                          <span className="text-slate-600 text-[11px] block mt-0.5">{sec.summary}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Essay Body Text */}
                <div className="space-y-4 pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                    Full Essay Text
                  </span>
                  <div className="prose prose-slate max-w-none text-slate-800 leading-relaxed font-serif text-sm sm:text-base space-y-4 bg-slate-50/30 p-6 rounded-2xl border border-slate-100">
                    {result.essay.split('\n\n').map((para, i) => (
                      <p key={i} className="indent-6 sm:indent-8 leading-7">
                        {para}
                      </p>
                    ))}
                  </div>
                </div>

                {/* Works Cited / References */}
                {result.worksCited && result.worksCited.length > 0 && (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Works Cited ({citationStyle})
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700 font-mono">
                      {result.worksCited.map((cite, idx) => (
                        <li key={idx} className="pl-4 -indent-4">
                          {cite}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Grade alignment */}
                <div className="bg-emerald-50/50 border border-emerald-100 rounded-2xl p-4 flex items-start gap-3">
                  <div className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg shrink-0 mt-0.5">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-950 block">
                      Tailored for {profile.grade}
                    </span>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {result.gradeLevelAlignment}
                    </p>
                  </div>
                </div>

                {/* Next steps: Check in Grammar Checker */}
                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-slate-500">Want to run real-time grammar & style feedback on this draft?</span>
                  <button
                    onClick={() => {
                      onSendToGrammar(result.essay);
                      setActiveTab('grammar');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold border border-amber-200 transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Open in Grammar Checker
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
