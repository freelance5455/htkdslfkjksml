import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownCodeViewProps {
  text: string;
  onCopyCode: (code: string, label?: string) => void;
}

export const MarkdownCodeView: React.FC<MarkdownCodeViewProps> = ({
  text,
  onCopyCode,
}) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const parts = text.split(/(```[\s\S]*?```)/g);

  const handleCopy = (code: string, lang: string, idx: number) => {
    onCopyCode(code, lang ? `${lang} snippet` : 'Code snippet');
    setCopiedIdx(idx);
    window.setTimeout(() => setCopiedIdx(null), 1800);
  };

  return (
    <div className="space-y-2.5 text-[14.5px] leading-relaxed break-words tracking-[0.005em]">
      {parts.map((part, idx) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          const inner = part.slice(3, -3);
          const firstNewline = inner.indexOf('\n');
          const lang = firstNewline !== -1 ? inner.slice(0, firstNewline).trim() : '';
          const code = firstNewline !== -1 ? inner.slice(firstNewline + 1).trimEnd() : inner.trim();

          return (
            <div
              key={idx}
              className="rounded-xl border border-zinc-800 bg-black text-zinc-100 overflow-hidden"
            >
              <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-900/90 border-b border-zinc-800 text-xs text-zinc-400 gap-2">
                <span className="font-mono text-cyan-300">{lang || 'code'}</span>
                <button
                  type="button"
                  onClick={() => handleCopy(code, lang, idx)}
                  className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedIdx === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3 overflow-x-auto text-xs leading-5 font-mono text-zinc-100 max-h-[520px]">
                <code>{code}</code>
              </pre>
              <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-900/90 border-t border-zinc-800 text-[11px] text-zinc-400">
                <span className="tabular-nums">{code.split('\n').length.toLocaleString()} lines</span>
                <button
                  type="button"
                  onClick={() => handleCopy(code, lang, idx)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100 transition-colors cursor-pointer"
                >
                  {copiedIdx === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        }

        const lines = part.split('\n');
        return (
          <div key={idx} className="space-y-1.5">
            {lines.map((line, lIdx) => {
              if (!line.trim()) return <div key={lIdx} className="h-1" />;
              const segments = line.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
              return (
                <p key={lIdx} className="whitespace-pre-wrap">
                  {segments.map((seg, sIdx) => {
                    if (seg.startsWith('`') && seg.endsWith('`')) {
                      return (
                        <code
                          key={sIdx}
                          className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-cyan-200 text-[13px] font-mono"
                        >
                          {seg.slice(1, -1)}
                        </code>
                      );
                    }
                    if (seg.startsWith('**') && seg.endsWith('**')) {
                      return (
                        <strong key={sIdx} className="font-semibold text-white">
                          {seg.slice(2, -2)}
                        </strong>
                      );
                    }
                    return <React.Fragment key={sIdx}>{seg}</React.Fragment>;
                  })}
                </p>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};
