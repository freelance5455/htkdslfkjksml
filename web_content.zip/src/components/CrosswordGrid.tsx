import React, { useState, useRef, useEffect } from 'react';
import { GridCell, GridPosition } from '../types/crossword';
import { convertToArabicNumerals } from '../data/sampleStages';
import { soundManager } from '../utils/audio';

interface CrosswordGridProps {
  grid: GridCell[][];
  selectedPos: GridPosition | null;
  selectedWordId: string | null;
  activeDirection: 'horizontal' | 'vertical';
  isZoomEnabled: boolean;
  onCellClick: (row: number, col: number) => void;
}

export const CrosswordGrid: React.FC<CrosswordGridProps> = ({
  grid,
  selectedPos,
  selectedWordId,
  activeDirection,
  isZoomEnabled,
  onCellClick,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number; posX: number; posY: number }>({
    x: 0,
    y: 0,
    posX: 0,
    posY: 0,
  });
  const touchStartDistRef = useRef<number | null>(null);
  const initialScaleRef = useRef<number>(1);
  const hasMovedRef = useRef<boolean>(false);

  // When zoom mode is disabled, reset scale and position back to natural 100% fit
  useEffect(() => {
    if (!isZoomEnabled) {
      setScale(1);
      setPosition({ x: 0, y: 0 });
    } else {
      // Default comfortable zoom when activated
      setScale(1.4);
    }
  }, [isZoomEnabled]);

  if (!grid || grid.length === 0) return null;

  const rows = grid.length;
  const cols = grid[0].length;

  // Touch handlers for multi-touch pinch-to-zoom and single-finger pan when zoom is unlocked
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isZoomEnabled) return;
    hasMovedRef.current = false;
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      touchStartDistRef.current = dist;
      initialScaleRef.current = scale;
    } else if (e.touches.length === 1) {
      setIsDragging(true);
      dragStartRef.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        posX: position.x,
        posY: position.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isZoomEnabled) return;
    if (e.touches.length === 2 && touchStartDistRef.current !== null) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / touchStartDistRef.current;
      const newScale = Math.min(Math.max(initialScaleRef.current * factor, 1), 2.5);
      setScale(newScale);
      hasMovedRef.current = true;
    } else if (e.touches.length === 1 && isDragging) {
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
        hasMovedRef.current = true;
      }
      setPosition({
        x: dragStartRef.current.posX + dx,
        y: dragStartRef.current.posY + dy,
      });
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchStartDistRef.current = null;
  };

  // Mouse pan handlers (when zoom mode is enabled)
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isZoomEnabled || e.button !== 0) return;
    hasMovedRef.current = false;
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isZoomEnabled || !isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
      hasMovedRef.current = true;
    }
    setPosition({
      x: dragStartRef.current.posX + dx,
      y: dragStartRef.current.posY + dy,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleCellClickWithDragGuard = (rIndex: number, cIndex: number) => {
    if (isZoomEnabled && hasMovedRef.current) {
      return;
    }
    soundManager.playSelectCell();
    onCellClick(rIndex, cIndex);
  };

  return (
    <div
      ref={containerRef}
      className={`w-full h-full flex items-center justify-center relative select-none overflow-hidden ${
        isZoomEnabled ? 'cursor-grab active:cursor-grabbing touch-none' : ''
      }`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Visual indicator when zoom mode is enabled */}
      {isZoomEnabled && (
        <div className="absolute top-1 right-2 z-30 bg-[#2c2c2c] text-[#fdfbf7] text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs pointer-events-none opacity-85">
          وضع التكبير نشط (اسحب للتحريك أو قرّب بالأصابع)
        </div>
      )}

      {/* Grid Wrapper Box that scales cleanly without breaking container aspect ratio or overflowing available height */}
      <div
        className="w-full max-w-[350px] sm:max-w-[430px] max-h-full aspect-square flex items-center justify-center p-0.5"
        style={{
          transform: isZoomEnabled ? `translate(${position.x}px, ${position.y}px) scale(${scale})` : 'none',
          transformOrigin: 'center center',
          transition: isDragging ? 'none' : 'transform 0.15s ease-out',
        }}
      >
        <div
          dir="rtl"
          className="grid gap-px bg-[#2c2c2c] p-[2px] newspaper-border-double shadow-md rounded-xs w-full h-full"
          style={{
            gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
            gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
          }}
        >
          {grid.map((rowArr, rIndex) =>
            rowArr.map((cell, cIndex) => {
              const isSelected =
                selectedPos?.row === rIndex && selectedPos?.col === cIndex;

              const isWordMember =
                selectedWordId &&
                ((activeDirection === 'horizontal' && cell.horizontalWordId === selectedWordId) ||
                  (activeDirection === 'vertical' && cell.verticalWordId === selectedWordId) ||
                  cell.horizontalWordId === selectedWordId ||
                  cell.verticalWordId === selectedWordId);

              // Black Cell (Blocked)
              if (cell.isBlocked) {
                return (
                  <div
                    key={`${rIndex}_${cIndex}`}
                    className="bg-[#1a1a1a] relative select-none w-full h-full min-w-0 min-h-0"
                    aria-hidden="true"
                  >
                    <div className="absolute inset-0 bg-[radial-gradient(#000000_1px,transparent_1px)] [background-size:4px_4px] opacity-30" />
                  </div>
                );
              }

              // White Playable Cell
              let cellBg = 'bg-[#fdfbf7] hover:bg-[#ede9e1]';
              let textColor = 'text-[#1a1a1a]';

              if (cell.status === 'correct') {
                cellBg = 'bg-[#dfebd9]';
                textColor = 'text-[#1c4d1f]';
              } else if (cell.status === 'incorrect') {
                cellBg = 'bg-[#fce8e8]';
                textColor = 'text-[#7a1c1c]';
              } else if (isSelected) {
                // The specifically focused cell gets strong amber-gold highlighting with dark ring
                cellBg = 'bg-[#d8b87d] ring-2 ring-inset ring-[#1a1a1a] z-10 shadow-xs';
              } else if (isWordMember) {
                // The rest of the word gets a distinctive, clear warm-parchment tint with high contrast against blank white cells
                cellBg = 'bg-[#eed9b3]';
              }

              // Font size and scale adapt cleanly to balance high ascenders (ألف، لام، كاف) with low descenders/dots (ياء، حاء)
              const letterFontSizeClass = cols > 18 
                ? 'text-[9.5px] sm:text-[12px]' 
                : 'text-[11px] sm:text-[14px]';

              return (
                <button
                  key={`${rIndex}_${cIndex}`}
                  type="button"
                  onClick={() => handleCellClickWithDragGuard(rIndex, cIndex)}
                  className={`relative flex items-center justify-center transition-colors duration-75 touch-manipulation focus:outline-none w-full h-full min-w-0 min-h-0 p-0 ${cellBg}`}
                >
                  {/* Clue Number (Fixed inside cell) */}
                  {cell.number && (
                    <span
                      dir="rtl"
                      className="absolute top-[0.5px] right-[1px] text-[5.5px] sm:text-[7px] font-bold text-[#423d38] leading-none pointer-events-none select-none z-10"
                    >
                      {convertToArabicNumerals(cell.number)}
                    </span>
                  )}

                  {/* Typed Arabic Character: Pure original newspaper font (Amiri), perfectly balanced between ascenders and descenders */}
                  <span
                    dir="rtl"
                    className={`newspaper-font font-bold select-none text-center flex items-center justify-center pointer-events-none leading-none -translate-y-[0.5px] ${letterFontSizeClass} ${textColor}`}
                    style={{ lineHeight: 1 }}
                  >
                    {cell.userChar}
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
