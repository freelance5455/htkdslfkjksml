import React, { useState } from 'react';
import { ChevronLeft, Bot, Clock, Swords, Zap } from 'lucide-react';
import { AiDifficulty } from '../../types/chess';
import { sound } from '../../services/sound';
import { TIME_CONTROL_PRESETS } from '../../services/storage';

interface AiDifficultyScreenProps {
  onBack: () => void;
  onStart: (difficulty: AiDifficulty, timeSeconds: number, incrementSeconds: number, playerColor: 'w' | 'b' | 'random') => void;
}

export const AiDifficultyScreen: React.FC<AiDifficultyScreenProps> = ({
  onBack,
  onStart,
}) => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<AiDifficulty>('medium');
  const [selectedTimeControlId, setSelectedTimeControlId] = useState<string>('rapid_10_0');
  const [selectedColor, setSelectedColor] = useState<'w' | 'b' | 'random'>('w');

  const difficulties: { id: AiDifficulty; title: string; subtitle: string; elo: number }[] = [
    { id: 'beginner', title: 'Beginner', subtitle: '(Novice)', elo: 800 },
    { id: 'easy', title: 'Easy', subtitle: '(Casual)', elo: 1000 },
    { id: 'medium', title: 'Medium', subtitle: '(Good Challenge)', elo: 1400 },
    { id: 'hard', title: 'Hard', subtitle: '(Strong AI)', elo: 1800 },
    { id: 'expert', title: 'Expert', subtitle: '(Grandmaster)', elo: 2400 },
  ];

  const currentPreset = TIME_CONTROL_PRESETS.find((p) => p.id === selectedTimeControlId) || TIME_CONTROL_PRESETS[4];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col justify-between px-5 pt-8 pb-20 select-none overflow-y-auto">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold tracking-wide text-slate-100">
            Play vs AI
          </h2>
          <div className="w-10" />
        </div>

        {/* Robot Centerpiece */}
        <div className="flex flex-col items-center my-2">
          <div className="relative">
            <div className="absolute inset-0 bg-sky-500/20 blur-xl rounded-full scale-125" />
            <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-[#1C2842] to-[#11192E] border border-sky-400/40 flex items-center justify-center shadow-lg shadow-sky-500/10">
              <Bot className="w-8 h-8 text-sky-400" />
            </div>
          </div>
          <h3 className="text-sm font-semibold text-slate-200 mt-1.5">
            Select Difficulty & Time
          </h3>
        </div>
      </div>

      {/* Difficulty Grid */}
      <div className="max-w-sm mx-auto w-full flex flex-col gap-3.5 my-auto py-2">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {difficulties.map((diff, idx) => {
            const isSelected = selectedDifficulty === diff.id;
            const isFullWidth = idx === difficulties.length - 1 && difficulties.length % 2 === 1;
            return (
              <button
                key={diff.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedDifficulty(diff.id);
                }}
                className={`p-3 rounded-2xl border transition-all duration-200 flex flex-col items-center justify-center ${
                  isFullWidth ? 'col-span-2 sm:col-span-1' : ''
                } ${
                  isSelected
                    ? 'bg-[#18263E] border-amber-400 shadow-md shadow-amber-400/15'
                    : 'bg-[#101726]/80 border-[#1E2B45] hover:border-slate-600'
                }`}
              >
                <span className={`font-bold text-sm ${isSelected ? 'text-amber-300' : 'text-slate-200'}`}>
                  {diff.title}
                </span>
                <span className="text-[10px] text-slate-400">
                  {diff.subtitle}
                </span>
                <span className="text-[10px] text-amber-200/60 font-mono mt-0.5">
                  ~{diff.elo} Elo
                </span>
              </button>
            );
          })}
        </div>

        {/* Side Selection */}
        <div className="bg-[#101726]/80 border border-[#1E2B45] rounded-2xl p-3 flex flex-col gap-1.5">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
            <Swords className="w-3.5 h-3.5 text-amber-400" /> Play As:
          </span>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'w', label: 'White', icon: '♔' },
              { id: 'random', label: 'Random', icon: '⚡' },
              { id: 'b', label: 'Black', icon: '♚' },
            ].map((side) => {
              const isSelected = selectedColor === side.id;
              return (
                <button
                  key={side.id}
                  onClick={() => {
                    sound.playClick();
                    setSelectedColor(side.id as 'w' | 'b' | 'random');
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-[#141C2E] border-[#22314E] text-slate-300'
                  }`}
                >
                  <span className="text-sm">{side.icon}</span>
                  {side.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Time Control Selection (Bullet, Blitz, Rapid, Untimed) */}
        <div className="bg-[#101726]/80 border border-[#1E2B45] rounded-2xl p-3 flex flex-col gap-2">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
            <Clock className="w-3.5 h-3.5 text-sky-400" /> Time Control:
          </span>
          <div className="grid grid-cols-4 gap-1.5">
            {TIME_CONTROL_PRESETS.map((opt) => {
              const isSelected = selectedTimeControlId === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => {
                    sound.playClick();
                    setSelectedTimeControlId(opt.id);
                  }}
                  className={`py-1.5 rounded-xl text-[11px] font-medium border text-center transition-all ${
                    isSelected
                      ? 'bg-sky-500/20 border-sky-400 text-sky-300 font-semibold'
                      : 'bg-[#141C2E] border-[#22314E] text-slate-300'
                  }`}
                >
                  <div className="font-mono">{opt.name}</div>
                  <div className="text-[9px] text-slate-400 capitalize">{opt.category}</div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Start Game CTA Button */}
      <div className="max-w-sm mx-auto w-full pt-1">
        <button
          onClick={() => {
            sound.playClick();
            onStart(
              selectedDifficulty,
              currentPreset.initialSeconds,
              currentPreset.incrementSeconds,
              selectedColor
            );
          }}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-700 text-white font-bold text-base tracking-wide shadow-lg shadow-emerald-600/30 active:scale-[0.98] transition-all duration-200 border border-emerald-400/50"
        >
          Start Game
        </button>
      </div>
    </div>
  );
};
