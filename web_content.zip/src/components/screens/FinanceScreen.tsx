"use client";

import { useState } from "react";
import { Button, Card, EmptyState, ErrorCard, Field, Pill, Skeleton, Stat, inputClass } from "@/components/ui";
import { useToast } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtDateTime, fmtIls, fmtPrice, fmtUsd, pnlColor, sideHe } from "@/lib/format";

type LedgerRow = {
  id: number;
  symbol: string;
  side: string;
  qty: number;
  entryPrice: number;
  exitPrice: number;
  realizedPnl: number;
  realizedPnlIls: number;
  closeReason: string;
  closedAt: string | null;
};

type UnrealizedRow = { id: number; symbol: string; side: string; entryPrice: number; markPrice: number; unrealizedPnl: number };

type Invoice = {
  id: number;
  invoiceNumber: string;
  clientName: string;
  clientTaxId: string;
  description: string;
  amountUsdt: number;
  usdIlsRate: number;
  amountIls: number;
  vatPct: number;
  totalIls: number;
  status: string;
  issuedAt: string;
};

type Resp = {
  ok?: boolean;
  usdIlsRate?: number;
  ledger?: LedgerRow[];
  unrealized?: UnrealizedRow[];
  invoices?: Invoice[];
  summary?: {
    realizedTotal: number;
    realizedTotalIls: number;
    realizedGains: number;
    realizedLosses: number;
    unrealizedTotal: number;
    unrealizedTotalIls: number;
    tradesCount: number;
    openCount: number;
    invoicedIls: number;
    vatCollected: number;
  };
  tax?: {
    capitalGainsPct: number;
    businessTaxPct: number;
    vatPct: number;
    taxableBaseIls: number;
    capitalGainsDueIls: number;
    businessIncomeDueIls: number;
    form909Required: boolean;
    notes: string[];
  };
  error?: string | null;
};

export default function FinanceScreen() {
  const { toast } = useToast();
  const { data, loading, error, refresh } = useApi<Resp>("/api/finance", { intervalMs: 60000 });
  const [form, setForm] = useState({ clientName: "", clientTaxId: "", description: "", amountUsdt: 500, vatPct: 18 });
  const [busy, setBusy] = useState(false);

  const ledger = arr<LedgerRow>(data?.ledger);
  const unrealized = arr<UnrealizedRow>(data?.unrealized);
  const invoices = arr<Invoice>(data?.invoices);
  const s = data?.summary;
  const tax = data?.tax;

  const createInvoice = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/finance", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(form),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "החשבונית הופקה") : (json.error ?? "שגיאה"), json.ok ? "success" : "error");
      if (json.ok) setForm({ ...form, clientName: "", clientTaxId: "", description: "" });
      await refresh();
    } catch {
      toast("שגיאה בהפקת חשבונית", "error");
    } finally {
      setBusy(false);
    }
  };

  if (loading && !s) {
    return (
      <Card title="פיננסים, מיסוי ודוחות">
        <Skeleton rows={6} />
      </Card>
    );
  }

  if (!s) return <ErrorCard detail={error ?? data?.error ?? null} onRetry={() => void refresh()} />;

  return (
    <div className="space-y-4">
      <Card title="מרכז פיננסי - רווח והפסד" subtitle={`שער דולר/שקל: ${(data?.usdIlsRate ?? 0).toFixed(3)} ₪`}>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-6">
          <Stat label="רווח ממומש" value={fmtUsd(s.realizedTotal)} tone={s.realizedTotal >= 0 ? "up" : "down"} hint={fmtIls(s.realizedTotalIls)} />
          <Stat label="רווח לא ממומש" value={fmtUsd(s.unrealizedTotal)} tone={s.unrealizedTotal >= 0 ? "up" : "down"} hint={fmtIls(s.unrealizedTotalIls)} />
          <Stat label="סך רווחים" value={fmtUsd(s.realizedGains)} tone="up" />
          <Stat label="סך הפסדים" value={fmtUsd(s.realizedLosses)} tone="down" />
          <Stat label="עסקאות סגורות" value={s.tradesCount} />
          <Stat label="פוזיציות פתוחות" value={s.openCount} />
        </div>
      </Card>

      <Card title="חבות מס - רשות המסים בישראל" subtitle="חישוב אינדיקטיבי בלבד, אינו מהווה ייעוץ מס">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <Stat label="בסיס חייב במס" value={fmtIls(tax?.taxableBaseIls)} />
          <Stat label={`מס רווחי הון (${tax?.capitalGainsPct ?? 25}%)`} value={fmtIls(tax?.capitalGainsDueIls)} tone="warn" />
          <Stat label={`חלופת הכנסה מעסק (${tax?.businessTaxPct ?? 47}%)`} value={fmtIls(tax?.businessIncomeDueIls)} tone="down" />
          <Stat label="מע\u0022מ שנגבה בחשבוניות" value={fmtIls(s.vatCollected)} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Pill tone={tax?.form909Required ? "amber" : "green"}>
            {tax?.form909Required ? "נדרש דיווח טופס 909 / נספח ג'" : "אין חבות דיווח כרגע"}
          </Pill>
          <Pill tone="sky">מע&quot;מ {tax?.vatPct ?? 18}%</Pill>
        </div>
        <ul className="mt-3 space-y-1 text-[11px] text-slate-400">
          {arr<string>(tax?.notes).map((note, i) => (
            <li key={i}>• {note}</li>
          ))}
        </ul>
      </Card>

      <Card title="Invoapp - הפקת חשבונית בקריפטו (USDT/ILS)">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <Field label="שם הלקוח">
            <input className={inputClass} value={form.clientName} onChange={(e) => setForm({ ...form, clientName: e.target.value })} />
          </Field>
          <Field label="ח.פ / ע.מ">
            <input className={inputClass} value={form.clientTaxId} onChange={(e) => setForm({ ...form, clientTaxId: e.target.value })} />
          </Field>
          <Field label="תיאור השירות">
            <input className={inputClass} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </Field>
          <Field label="סכום ב-USDT">
            <input
              type="number"
              className={inputClass}
              value={form.amountUsdt}
              onChange={(e) => setForm({ ...form, amountUsdt: Number(e.target.value) })}
            />
          </Field>
          <Field label="מע&quot;מ (%)">
            <input
              type="number"
              className={inputClass}
              value={form.vatPct}
              onChange={(e) => setForm({ ...form, vatPct: Number(e.target.value) })}
            />
          </Field>
        </div>
        <div className="mt-3">
          <Button onClick={createInvoice} disabled={busy || !form.clientName}>
            {busy ? "מפיק..." : "🧾 הפק חשבונית"}
          </Button>
        </div>

        <div className="mt-4">
          {invoices.length === 0 ? (
            <EmptyState text="לא הופקו חשבוניות עדיין" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-right text-[11px]">
                <thead className="text-slate-400">
                  <tr>
                    <th className="p-2">מספר</th>
                    <th className="p-2">לקוח</th>
                    <th className="p-2">תיאור</th>
                    <th className="p-2">USDT</th>
                    <th className="p-2">שער</th>
                    <th className="p-2">לפני מע&quot;מ</th>
                    <th className="p-2">סה&quot;כ כולל מע&quot;מ</th>
                    <th className="p-2">תאריך</th>
                  </tr>
                </thead>
                <tbody className="tabular-nums">
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="border-t border-slate-800">
                      <td className="p-2 font-bold text-slate-100">{inv.invoiceNumber}</td>
                      <td className="p-2">
                        {inv.clientName}
                        {inv.clientTaxId ? ` (${inv.clientTaxId})` : ""}
                      </td>
                      <td className="p-2 text-slate-400">{inv.description}</td>
                      <td className="p-2">{inv.amountUsdt.toFixed(2)}</td>
                      <td className="p-2">{inv.usdIlsRate.toFixed(3)}</td>
                      <td className="p-2">{fmtIls(inv.amountIls)}</td>
                      <td className="p-2 font-bold text-emerald-400">{fmtIls(inv.totalIls)}</td>
                      <td className="p-2 text-slate-500">{fmtDateTime(inv.issuedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </Card>

      <Card title="יומן עסקאות למס (Ledger)" subtitle="כל עסקה סגורה מתועדת בדולר ובשקל לצורכי דיווח">
        {ledger.length === 0 ? (
          <EmptyState text="אין עדיין עסקאות סגורות ביומן" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-right text-[11px]">
              <thead className="text-slate-400">
                <tr>
                  <th className="p-2">מטבע</th>
                  <th className="p-2">כיוון</th>
                  <th className="p-2">כמות</th>
                  <th className="p-2">כניסה</th>
                  <th className="p-2">יציאה</th>
                  <th className="p-2">רווח ($)</th>
                  <th className="p-2">רווח (₪)</th>
                  <th className="p-2">תאריך סגירה</th>
                </tr>
              </thead>
              <tbody className="tabular-nums">
                {ledger.map((r) => (
                  <tr key={r.id} className="border-t border-slate-800">
                    <td className="p-2 font-bold text-slate-100">{r.symbol}</td>
                    <td className="p-2">{sideHe(r.side)}</td>
                    <td className="p-2">{r.qty.toFixed(4)}</td>
                    <td className="p-2">{fmtPrice(r.entryPrice)}</td>
                    <td className="p-2">{fmtPrice(r.exitPrice)}</td>
                    <td className={`p-2 font-bold ${pnlColor(r.realizedPnl)}`}>{fmtUsd(r.realizedPnl)}</td>
                    <td className={`p-2 ${pnlColor(r.realizedPnlIls)}`}>{fmtIls(r.realizedPnlIls)}</td>
                    <td className="p-2 text-slate-500">{fmtDateTime(r.closedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {unrealized.length > 0 && (
          <p className="mt-2 text-[11px] text-slate-500">
            * בנוסף קיימות {unrealized.length} פוזיציות פתוחות עם רווח/הפסד לא ממומש שאינו חייב במס עד למימוש.
          </p>
        )}
      </Card>
    </div>
  );
}
