import React from 'react';
import { TournamentHubScreen } from './TournamentHubScreen';

interface TournamentsScreenProps {
  userProfile?: { id: string; name: string; rating: number; avatar?: string };
  onBack: () => void;
  onJoinTournament?: (tournamentName: string) => void;
  onLaunchTournamentMatch?: (params: {
    tournamentId: string;
    pairingId: string;
    opponentName: string;
    opponentRating: number;
    playerSide: 'w' | 'b';
    timeControlSeconds: number;
    incrementSeconds: number;
  }) => void;
}

export const TournamentsScreen: React.FC<TournamentsScreenProps> = ({
  userProfile = { id: 'u-user', name: 'You', rating: 1500, avatar: '👑' },
  onBack,
  onJoinTournament,
  onLaunchTournamentMatch = () => {},
}) => {
  return (
    <TournamentHubScreen
      userProfile={userProfile}
      onBack={onBack}
      onLaunchTournamentMatch={onLaunchTournamentMatch}
    />
  );
};
