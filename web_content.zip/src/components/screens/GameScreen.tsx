import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronLeft,
  RotateCcw,
  RotateCw,
  Lightbulb,
  Settings,
  Flag,
  Handshake,
  Crown,
  RefreshCw,
  ListOrdered,
  Box,
  Layers,
  Compass,
  Volume2,
  VolumeX,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chess, Square, Move } from 'chess.js';
import { ChessScene } from '../3d/ChessScene';
import { ChessBoard2D } from '../common/ChessBoard2D';
import { ChessRulesEngine } from '../../services/chessRules';
import { AnalysisModal } from './AnalysisModal';
import {
  GameMode,
  AiDifficulty,
  GameSettings,
  PlayerInfo,
  MoveRecord,
  MatchResult,
  PieceType,
  PieceColor,
} from '../../types/chess';
import { getAiMove, getBestMoveHint, HintAnalysis } from '../../services/aiEngine';
import { sound, triggerMoveAudio, playIllegalMoveSound, playPieceSelectSound } from '../../services/sound';
import { multiplayer } from '../../services/multiplayer';
import { saveGameInProgress, clearSavedGame } from '../../services/storage';

interface GameScreenProps {
  mode: GameMode;
  aiDifficulty?: AiDifficulty;
  timeControlSeconds: number;
  incrementSeconds?: number;
  playerSide: 'w' | 'b';
  settings: GameSettings;
  userRating: number;
  userName: string;
  opponentInfo?: { name: string; avatar: string; rating: number };
  roomId?: string;
  initialFen?: string;
  initialWhiteTime?: number;
  initialBlackTime?: number;
  onExit: () => void;
  onMatchComplete: (result: MatchResult) => void;
  onOpenSettings: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  mode,
  aiDifficulty = 'medium',
  timeControlSeconds,
  incrementSeconds = 0,
  playerSide,
  settings,
  userRating,
  userName,
  opponentInfo,
  roomId,
  initialFen,
  initialWhiteTime,
  initialBlackTime,
  onExit,
  onMatchComplete,
  onOpenSettings,
}) => {
  const [game, setGame] = useState(() => new Chess(initialFen || undefined));
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [legalMoves, setLegalMoves] = useState<string[]>([]);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [moveHistory, setMoveHistory] = useState<MoveRecord[]>([]);
  const [undoneHistory, setUndoneHistory] = useState<MoveRecord[]>([]);

  // Turn & Perspective & 2D / 3D Mode Switch
  const [boardPerspective, setBoardPerspective] = useState<'w' | 'b'>(playerSide);
  const [displayMode, setDisplayMode] = useState<'3d' | '2d'>('3d');
  const [viewMode, setViewMode] = useState<'3d' | 'top_down'>('3d');
  const [showCoordinates, setShowCoordinates] = useState(true);
  const [cameraResetTrigger, setCameraResetTrigger] = useState(0);
  const [soundActive, setSoundActive] = useState(settings.soundEnabled);
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Clocks
  const [whiteTime, setWhiteTime] = useState(initialWhiteTime ?? (timeControlSeconds || 600));
  const [blackTime, setBlackTime] = useState(initialBlackTime ?? (timeControlSeconds || 600));
  const [clockRunning, setClockRunning] = useState(false);

  // Hint & Analysis & Move History Drawer
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [hintAnalysis, setHintAnalysis] = useState<HintAnalysis | null>(null);
  const [showMoveHistory, setShowMoveHistory] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Promotion Dialog
  const [pendingPromotion, setPendingPromotion] = useState<{ from: Square; to: Square } | null>(null);

  // Game Result Modal
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [drawOffered, setDrawOffered] = useState(false);

  // Opponent details
  const opponent: PlayerInfo = {
    id: 'opp-1',
    name: opponentInfo?.name || (mode === 'ai' ? `AI (${aiDifficulty.charAt(0).toUpperCase() + aiDifficulty.slice(1)})` : 'Opponent'),
    avatar: opponentInfo?.avatar || (mode === 'ai' ? '🤖' : '👤'),
    rating: opponentInfo?.rating || (mode === 'ai' ? (aiDifficulty === 'easy' ? 800 : aiDifficulty === 'medium' ? 1100 : aiDifficulty === 'hard' ? 1800 : 2400) : 1250),
    color: playerSide === 'w' ? 'b' : 'w',
    isAi: mode === 'ai',
  };

  const isPlayerTurn = mode === 'local' || game.turn() === playerSide;

  // Format digital clock mm:ss
  const formatTime = (secs: number) => {
    if (timeControlSeconds === 0) return '∞';
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // 1. Clock Countdown Timer
  useEffect(() => {
    if (timeControlSeconds === 0 || !clockRunning || matchResult) return;

    const timer = setInterval(() => {
      if (game.turn() === 'w') {
        setWhiteTime((prev) => {
          if (prev <= 1) {
            handleGameOver('b', 'timeout');
            return 0;
          }
          return prev - 1;
        });
      } else {
        setBlackTime((prev) => {
          if (prev <= 1) {
            handleGameOver('w', 'timeout');
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [clockRunning, game, timeControlSeconds, matchResult]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3200);
  };

  // 2. Multiplayer Subscriptions
  useEffect(() => {
    if (mode !== 'online' || !roomId) return;

    multiplayer.joinRoom(roomId, userName, userName);

    const unsubscribe = multiplayer.subscribe((msg) => {
      if (msg.type === 'MOVE' && msg.payload) {
        const { from, to, promotion } = msg.payload;
        const validation = ChessRulesEngine.validateMove(
          game,
          from as Square,
          to as Square,
          promotion || 'q'
        );
        if (validation.isValid) {
          makeMove(from as Square, to as Square, promotion || 'q', false);
        } else {
          console.warn('Rejected illegal multiplayer move:', msg.payload);
        }
      } else if (msg.type === 'DRAW_OFFER') {
        setDrawOffered(true);
      } else if (msg.type === 'DRAW_ACCEPT') {
        handleGameOver('draw', 'draw_agreement');
      } else if (msg.type === 'DRAW_DECLINE') {
        showToast('Opponent declined your draw offer.');
      } else if (msg.type === 'RESIGN') {
        handleGameOver(playerSide, 'resignation');
      }
    });

    return () => {
      unsubscribe();
      multiplayer.leaveRoom();
    };
  }, [mode, roomId, userName, playerSide, game]);

  // 3. AI Opponent Automated Move
  useEffect(() => {
    if (mode !== 'ai' || game.isGameOver() || matchResult) return;

    if (game.turn() !== playerSide && !isAiThinking) {
      setIsAiThinking(true);
      getAiMove(game, aiDifficulty).then((aiMove) => {
        setIsAiThinking(false);
        if (aiMove) {
          const validation = ChessRulesEngine.validateMove(
            game,
            aiMove.from as Square,
            aiMove.to as Square,
            'q'
          );
          if (validation.isValid) {
            makeMove(aiMove.from as Square, aiMove.to as Square, 'q', false);
          } else {
            console.error('AI attempted illegal move:', aiMove);
          }
        }
      });
    }
  }, [game, mode, playerSide, aiDifficulty, isAiThinking, matchResult]);

  // 4. Calculate Legal Moves on Selection using ChessRulesEngine
  const updateLegalMovesForSquare = useCallback(
    (square: Square) => {
      const validDests = ChessRulesEngine.getLegalMoves(game, square);
      setLegalMoves(validDests);
    },
    [game]
  );

  // 5. Authoritative Move Attempt Handler (shared by 2D & 3D dragging and clicking)
  const handleMoveAttempt = useCallback(
    (from: Square, to: Square, promotion = 'q') => {
      if (matchResult || (mode === 'ai' && game.turn() !== playerSide) || isAiThinking) {
        return false;
      }

      // Strict rules validation
      const validation = ChessRulesEngine.validateMove(game, from, to, promotion);
      if (!validation.isValid) {
        playIllegalMoveSound();
        showToast(validation.reason || 'Illegal move');
        setSelectedSquare(null);
        setLegalMoves([]);
        return false;
      }

      // Check for pawn promotion
      const movingPiece = game.get(from);
      const isPromotion = movingPiece?.type === 'p' && (to[1] === '8' || to[1] === '1');

      if (isPromotion) {
        if (settings.autoQueen) {
          makeMove(from, to, 'q', true);
        } else {
          setPendingPromotion({ from, to });
          return true;
        }
      } else {
        makeMove(from, to, promotion, true);
      }

      setSelectedSquare(null);
      setLegalMoves([]);
      return true;
    },
    [game, matchResult, mode, playerSide, isAiThinking, settings.autoQueen]
  );

  // 6. Handle Square Click from 2D or 3D Board
  const handleSquareClick = useCallback(
    (square: Square) => {
      if (matchResult || (mode === 'ai' && game.turn() !== playerSide) || isAiThinking) {
        return;
      }

      const clickedPiece = game.get(square);

      // If already selected a square
      if (selectedSquare) {
        // If clicking the same square, deselect
        if (selectedSquare === square) {
          setSelectedSquare(null);
          setLegalMoves([]);
          return;
        }

        // If clicking another piece of our same color, switch selection
        if (clickedPiece && clickedPiece.color === game.turn()) {
          setSelectedSquare(square);
          updateLegalMovesForSquare(square);
          playPieceSelectSound();
          return;
        }

        // Attempt move from selectedSquare to square
        handleMoveAttempt(selectedSquare, square);
        return;
      }

      // Selecting a piece of own color
      if (clickedPiece && clickedPiece.color === game.turn()) {
        setSelectedSquare(square);
        updateLegalMovesForSquare(square);
        playPieceSelectSound();
      }
    },
    [game, selectedSquare, matchResult, mode, playerSide, isAiThinking, updateLegalMovesForSquare, handleMoveAttempt]
  );

  // 7. Make Move Execution Pipeline
  const makeMove = (from: Square, to: Square, promotion = 'q', isLocalAction = true) => {
    try {
      const validation = ChessRulesEngine.validateMove(game, from, to, promotion);
      if (!validation.isValid) {
        playIllegalMoveSound();
        showToast(validation.reason || 'Illegal move');
        return;
      }

      const moveResult = game.move({ from, to, promotion });

      if (moveResult) {
        // Trigger specific audio effect through the sound system utility
        // Handles piece movement, captures, checks, castling, promotion, checkmate
        triggerMoveAudio(moveResult, {
          inCheck: game.inCheck(),
          isCheckmate: game.isCheckmate(),
          isDraw: game.isDraw(),
        });

        if (game.isCheckmate()) {
          confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
        }

        // Apply clock increment to player who just moved
        if (incrementSeconds > 0) {
          if (moveResult.color === 'w') {
            setWhiteTime((t) => t + incrementSeconds);
          } else {
            setBlackTime((t) => t + incrementSeconds);
          }
        }

        // Start clock on first move
        if (!clockRunning) {
          setClockRunning(true);
        }

        setLastMove({ from, to });
        const newRecord: MoveRecord = {
          san: moveResult.san,
          from,
          to,
          piece: moveResult.piece as PieceType,
          color: moveResult.color as PieceColor,
          captured: moveResult.captured as PieceType | undefined,
          promotion: moveResult.promotion as PieceType | undefined,
          fen: game.fen(),
        };
        const newHistory = [...moveHistory, newRecord];
        setMoveHistory(newHistory);
        setUndoneHistory([]); // Clear redo stack on new branch

        // Autosave game in progress
        saveGameInProgress({
          fen: game.fen(),
          pgn: game.pgn(),
          gameMode: mode,
          difficulty: aiDifficulty,
          playerColor: playerSide,
          whiteTime,
          blackTime,
          timeControlSeconds,
          incrementSeconds,
          date: new Date().toISOString(),
        });

        // Broadcast if online
        if (mode === 'online' && roomId && isLocalAction) {
          multiplayer.sendMove(roomId, userName, userName, {
            from,
            to,
            promotion,
            san: moveResult.san,
            fen: game.fen(),
          });
        }

        // Check for Game Over conditions
        if (game.isCheckmate()) {
          const winnerColor = game.turn() === 'w' ? 'b' : 'w';
          handleGameOver(winnerColor, 'checkmate');
        } else if (game.isStalemate()) {
          handleGameOver('draw', 'stalemate');
        } else if (game.isThreefoldRepetition()) {
          handleGameOver('draw', 'repetition');
        } else if (game.isInsufficientMaterial()) {
          handleGameOver('draw', 'insufficient_material');
        }

        // Refresh state
        setGame(new Chess(game.fen()));
        setSelectedSquare(null);
        setLegalMoves([]);
        setHintAnalysis(null);
      }
    } catch (err) {
      console.warn('Illegal move attempt', err);
    }
  };

  // 7. Handle Match Termination
  const handleGameOver = (winner: PieceColor | 'draw', reason: MatchResult['reason']) => {
    setClockRunning(false);
    clearSavedGame(); // Clear unfinished game on match finish
    const isPlayerWin = winner === playerSide;
    const isDraw = winner === 'draw';

    const result: MatchResult = {
      winner,
      reason,
      scoreDeltaWhite: isPlayerWin ? 16 : isDraw ? 2 : -14,
      scoreDeltaBlack: isPlayerWin ? -14 : isDraw ? 2 : 16,
    };

    setMatchResult(result);
    onMatchComplete(result);
  };

  // 8. Undo Move (Local & Practice Mode)
  const handleUndo = () => {
    if (mode === 'online' || matchResult || moveHistory.length === 0) return;
    sound.playClick();

    if (mode === 'ai') {
      const undoneAi = game.undo();
      const undoneUser = game.undo();
      if (undoneAi && undoneUser) {
        setUndoneHistory((prev) => [...prev, moveHistory[moveHistory.length - 1], moveHistory[moveHistory.length - 2]]);
        setMoveHistory((prev) => prev.slice(0, -2));
      }
    } else {
      const undone = game.undo();
      if (undone) {
        setUndoneHistory((prev) => [...prev, moveHistory[moveHistory.length - 1]]);
        setMoveHistory((prev) => prev.slice(0, -1));
      }
    }

    setGame(new Chess(game.fen()));
    setSelectedSquare(null);
    setLegalMoves([]);
    setHintAnalysis(null);
  };

  // Redo Move (Local & Practice Mode)
  const handleRedo = () => {
    if (mode === 'online' || matchResult || undoneHistory.length === 0) return;
    sound.playClick();

    if (mode === 'ai') {
      const userMove = undoneHistory[undoneHistory.length - 1];
      const aiMove = undoneHistory[undoneHistory.length - 2];
      if (userMove) {
        game.move({ from: userMove.from, to: userMove.to, promotion: userMove.promotion });
        if (aiMove) {
          game.move({ from: aiMove.from, to: aiMove.to, promotion: aiMove.promotion });
          setMoveHistory((prev) => [...prev, userMove, aiMove]);
          setUndoneHistory((prev) => prev.slice(0, -2));
        } else {
          setMoveHistory((prev) => [...prev, userMove]);
          setUndoneHistory((prev) => prev.slice(0, -1));
        }
      }
    } else {
      const nextMove = undoneHistory[undoneHistory.length - 1];
      if (nextMove) {
        game.move({ from: nextMove.from, to: nextMove.to, promotion: nextMove.promotion });
        setMoveHistory((prev) => [...prev, nextMove]);
        setUndoneHistory((prev) => prev.slice(0, -1));
      }
    }

    setGame(new Chess(game.fen()));
    setSelectedSquare(null);
    setLegalMoves([]);
    setHintAnalysis(null);
  };

  // 9. Hint Trigger
  const handleRequestHint = () => {
    sound.playClick();
    const hint = getBestMoveHint(game);
    setHintAnalysis(hint);
    setShowAnalysis(true);
  };

  // 10. Resign / Offer Draw
  const handleResign = () => {
    sound.playClick();
    if (mode === 'online' && roomId) {
      multiplayer.sendResign(roomId, userName, userName);
    }
    const winner = playerSide === 'w' ? 'b' : 'w';
    handleGameOver(winner, 'resignation');
  };

  const handleOfferDraw = () => {
    sound.playClick();
    if (mode === 'online' && roomId) {
      multiplayer.sendDrawOffer(roomId, userName, userName);
      showToast('Draw offer sent to opponent...');
    } else if (mode === 'ai') {
      const hint = getBestMoveHint(game);
      if (hint && Math.abs(hint.evalCentipawns) < 120) {
        showToast('AI accepted the draw agreement!');
        setTimeout(() => handleGameOver('draw', 'draw_agreement'), 500);
      } else {
        showToast('AI declined your draw offer.');
      }
    } else {
      handleGameOver('draw', 'draw_agreement');
    }
  };

  const handleAcceptDrawOffer = () => {
    sound.playClick();
    if (mode === 'online' && roomId) {
      multiplayer.sendDrawAccept(roomId, userName, userName);
    }
    setDrawOffered(false);
    handleGameOver('draw', 'draw_agreement');
  };

  const handleDeclineDrawOffer = () => {
    sound.playClick();
    if (mode === 'online' && roomId) {
      multiplayer.sendDrawDecline(roomId, userName, userName);
    }
    setDrawOffered(false);
    showToast('Draw offer declined.');
  };

  // Captured pieces and material differential calculation
  const capturedPieces = {
    white: [] as string[],
    black: [] as string[],
  };
  moveHistory.forEach((m) => {
    if (m.captured) {
      const symbols: Record<string, string> = { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛' };
      if (m.color === 'w') {
        capturedPieces.white.push(symbols[m.captured] || '♟');
      } else {
        capturedPieces.black.push(symbols[m.captured] || '♟');
      }
    }
  });

  const pieceScores: Record<string, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  let whiteMaterial = 0;
  let blackMaterial = 0;
  const boardMatrix = game.board();
  for (let r = 0; r < 8; r++) {
    for (let f = 0; f < 8; f++) {
      const p = boardMatrix[r][f];
      if (p) {
        if (p.color === 'w') whiteMaterial += pieceScores[p.type] || 0;
        else blackMaterial += pieceScores[p.type] || 0;
      }
    }
  }
  const whiteAdvantage = whiteMaterial - blackMaterial;

  return (
    <div className="relative w-screen h-screen bg-[#070B13] overflow-hidden select-none">
      {/* Interactive Board (3D WebGL or 2D Vector) */}
      <div className="absolute inset-0 z-0 flex items-center justify-center">
        {displayMode === '3d' ? (
          <ChessScene
            game={game}
            boardStyle={settings.boardStyle}
            pieceStyle={settings.pieceStyle}
            playerPerspective={boardPerspective}
            viewMode={viewMode}
            selectedSquare={selectedSquare}
            legalMoves={settings.showLegalMoves ? legalMoves : []}
            lastMove={lastMove}
            hintMove={hintAnalysis ? { from: hintAnalysis.from, to: hintAnalysis.to } : null}
            showCoordinates={showCoordinates}
            onSquareClick={handleSquareClick}
            onMoveAttempt={handleMoveAttempt}
            cameraResetTrigger={cameraResetTrigger}
            interactive={!matchResult}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center pt-16 pb-28 px-4">
            <ChessBoard2D
              game={game}
              boardStyle={settings.boardStyle}
              pieceStyle={settings.pieceStyle}
              playerPerspective={boardPerspective}
              selectedSquare={selectedSquare}
              legalMoves={settings.showLegalMoves ? legalMoves : []}
              lastMove={lastMove}
              hintMove={hintAnalysis ? { from: hintAnalysis.from, to: hintAnalysis.to } : null}
              showCoordinates={showCoordinates}
              onSquareClick={handleSquareClick}
              onMoveAttempt={handleMoveAttempt}
              interactive={!matchResult}
            />
          </div>
        )}
      </div>

      {/* Top HUD: Opponent Header (matches Screen 4 from reference) */}
      <div className="absolute top-4 inset-x-4 z-20 flex items-center justify-between pointer-events-none max-w-lg mx-auto">
        {/* Opponent Info Chip */}
        <div className="flex items-center gap-3 p-2 pr-4 rounded-2xl bg-[#0D1524]/90 border border-[#1E2B45] shadow-xl backdrop-blur-md pointer-events-auto">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-[#172238] border border-sky-400/30 flex items-center justify-center text-xl">
              {opponent.avatar}
            </div>
            {isAiThinking && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full animate-ping" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-xs text-slate-100">{opponent.name}</h4>
              <span className="text-[11px] font-mono text-amber-400 font-semibold">{opponent.rating}</span>
              {((opponent.color === 'w' && whiteAdvantage > 0) || (opponent.color === 'b' && whiteAdvantage < 0)) && (
                <span className="text-[10px] font-bold font-mono text-emerald-400 bg-emerald-500/20 px-1.5 py-0.2 rounded border border-emerald-500/40">
                  +{Math.abs(whiteAdvantage)}
                </span>
              )}
            </div>
            {/* Captured Pieces by Opponent */}
            <div className="flex gap-0.5 text-xs text-slate-400 h-4 items-center">
              {capturedPieces.black.map((sym, idx) => (
                <span key={idx}>{sym}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Opponent Digital Clock (matches Screen 4) */}
        <div className="py-2 px-3.5 rounded-xl bg-[#0B101D] border border-emerald-500/40 text-emerald-400 font-mono font-bold text-base shadow-lg shadow-emerald-500/10 pointer-events-auto">
          {opponent.color === 'w' ? formatTime(whiteTime) : formatTime(blackTime)}
        </div>
      </div>

      {/* Center Floating Turn Banner (matches Screen 4) */}
      <div className="absolute top-20 inset-x-0 z-20 flex justify-center pointer-events-none">
        <div className="py-1.5 px-4 rounded-full bg-[#0D1524]/90 border border-amber-400/30 text-amber-300 text-xs font-bold flex items-center gap-2 shadow-xl backdrop-blur-md">
          <Crown className="w-4 h-4 fill-amber-400 text-amber-300" />
          <span>
            {matchResult
              ? 'Game Finished'
              : isAiThinking
              ? 'AI Thinking...'
              : isPlayerTurn
              ? 'Your move'
              : `${opponent.name}'s move`}
          </span>
        </div>
      </div>

      {/* Bottom HUD: Player Info & Clock */}
      <div className="absolute bottom-20 inset-x-4 z-20 flex items-center justify-between pointer-events-none max-w-lg mx-auto">
        {/* Player Info Chip */}
        <div className="flex items-center gap-3 p-2 pr-4 rounded-2xl bg-[#0D1524]/90 border border-[#1E2B45] shadow-xl backdrop-blur-md pointer-events-auto">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-sky-500/20 border border-amber-400/40 flex items-center justify-center text-xl">
            👑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-xs text-slate-100">{userName}</h4>
              <span className="text-[11px] font-mono text-amber-400 font-semibold">{userRating}</span>
              {((playerSide === 'w' && whiteAdvantage > 0) || (playerSide === 'b' && whiteAdvantage < 0)) && (
                <span className="text-[10px] font-bold font-mono text-emerald-400 bg-emerald-500/20 px-1.5 py-0.2 rounded border border-emerald-500/40">
                  +{Math.abs(whiteAdvantage)}
                </span>
              )}
            </div>
            {/* Captured Pieces by Player */}
            <div className="flex gap-0.5 text-xs text-slate-300 h-4 items-center">
              {capturedPieces.white.map((sym, idx) => (
                <span key={idx}>{sym}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Player Digital Clock (matches Screen 4) */}
        <div className="py-2 px-3.5 rounded-xl bg-[#0B101D] border border-emerald-500/40 text-emerald-400 font-mono font-bold text-base shadow-lg shadow-emerald-500/10 pointer-events-auto">
          {playerSide === 'w' ? formatTime(whiteTime) : formatTime(blackTime)}
        </div>
      </div>

      {/* Floating Bottom Action Dock (matches Screen 4 from reference) */}
      <div className="absolute bottom-4 inset-x-4 z-30 flex items-center justify-center pointer-events-none">
        <div className="flex items-center gap-2 p-2 rounded-2xl bg-[#0D1524]/95 border border-[#1E2E4E] shadow-2xl backdrop-blur-md pointer-events-auto overflow-x-auto max-w-full">
          {/* Back to Menu */}
          <button
            onClick={() => {
              sound.playClick();
              onExit();
            }}
            title="Exit to Menu"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] text-slate-300 hover:text-white flex items-center justify-center shrink-0 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* 2D / 3D Live Mode Switch */}
          <button
            onClick={() => {
              sound.playClick();
              setDisplayMode((prev) => (prev === '3d' ? '2d' : '3d'));
              showToast(displayMode === '3d' ? 'Switched to 2D Mode' : 'Switched to 3D Mode');
            }}
            title={displayMode === '3d' ? 'Switch to 2D Board' : 'Switch to 3D Board'}
            className={`px-3 h-9 sm:h-10 rounded-xl border flex items-center gap-1.5 font-bold text-xs shrink-0 transition-all ${
              displayMode === '2d'
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-[0_0_15px_rgba(0,210,255,0.35)]'
                : 'bg-[#141E33] border-slate-700 text-slate-300 hover:text-cyan-300'
            }`}
          >
            {displayMode === '3d' ? (
              <Box className="w-4 h-4 text-cyan-400" />
            ) : (
              <Layers className="w-4 h-4 text-cyan-300" />
            )}
            <span>{displayMode === '3d' ? '3D' : '2D'}</span>
          </button>

          {/* Reset Camera (in 3D mode) */}
          {displayMode === '3d' && (
            <button
              onClick={() => {
                sound.playClick();
                setCameraResetTrigger((c) => c + 1);
                showToast('Camera reset');
              }}
              title="Reset 3D Camera View"
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] text-slate-300 hover:text-cyan-300 flex items-center justify-center shrink-0 transition-colors"
            >
              <Compass className="w-4 h-4" />
            </button>
          )}

          {/* Flip Board View */}
          <button
            onClick={() => {
              sound.playClick();
              setBoardPerspective((prev) => (prev === 'w' ? 'b' : 'w'));
              showToast(boardPerspective === 'w' ? 'Flipped to Black view' : 'Flipped to White view');
            }}
            title="Flip Board View"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] text-slate-300 hover:text-sky-400 flex items-center justify-center shrink-0 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* Coordinates Toggle */}
          <button
            onClick={() => {
              sound.playClick();
              setShowCoordinates((prev) => !prev);
              showToast(showCoordinates ? 'Coordinates hidden' : 'Coordinates visible');
            }}
            title={showCoordinates ? 'Hide Coordinates' : 'Show Coordinates'}
            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl border flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
              showCoordinates
                ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                : 'bg-[#141E33] border-transparent text-slate-400 hover:text-sky-300'
            }`}
          >
            <span className="font-mono text-[11px]">A1</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              const next = !soundActive;
              setSoundActive(next);
              sound.setSoundEnabled(next);
              showToast(next ? 'Sound enabled' : 'Sound muted');
            }}
            title={soundActive ? 'Mute Sound' : 'Enable Sound'}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] text-slate-300 hover:text-white flex items-center justify-center shrink-0 transition-colors"
          >
            {soundActive ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* Undo Move */}
          <button
            onClick={handleUndo}
            disabled={mode === 'online' || moveHistory.length === 0 || !!matchResult}
            title="Undo move"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] disabled:opacity-40 text-slate-300 hover:text-amber-300 flex items-center justify-center shrink-0 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Redo Move */}
          <button
            onClick={handleRedo}
            disabled={mode === 'online' || undoneHistory.length === 0 || !!matchResult}
            title="Redo move"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] disabled:opacity-40 text-slate-300 hover:text-emerald-300 flex items-center justify-center shrink-0 transition-colors"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Move Hint */}
          <button
            onClick={handleRequestHint}
            disabled={!!matchResult}
            title="Show Move Hint & Analysis"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0 transition-colors shadow-md"
          >
            <Lightbulb className="w-4 h-4 fill-amber-400/30" />
          </button>

          {/* Settings Screen */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenSettings();
            }}
            title="Game Settings"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] text-slate-300 hover:text-white flex items-center justify-center shrink-0 transition-colors"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Notation Move History */}
          <button
            onClick={() => {
              sound.playClick();
              setShowMoveHistory((prev) => !prev);
            }}
            title="Move Notation History"
            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl border flex items-center justify-center shrink-0 transition-colors ${
              showMoveHistory
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-[#141E33] border-transparent text-slate-300 hover:text-amber-300'
            }`}
          >
            <ListOrdered className="w-4 h-4" />
          </button>

          {/* Offer Draw */}
          <button
            onClick={handleOfferDraw}
            disabled={!!matchResult}
            title="Offer / Agree Draw"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#141E33] hover:bg-[#1B2945] disabled:opacity-40 text-slate-300 hover:text-emerald-300 flex items-center justify-center shrink-0 transition-colors"
          >
            <Handshake className="w-4 h-4" />
          </button>

          {/* Resign */}
          <button
            onClick={handleResign}
            disabled={!!matchResult}
            title="Resign Match"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 flex items-center justify-center shrink-0 transition-colors"
          >
            <Flag className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* In-game Toast Notification */}
      {toastMessage && (
        <div className="fixed top-28 inset-x-0 z-50 flex justify-center pointer-events-none animate-in fade-in slide-in-from-top-2">
          <div className="py-2 px-4 rounded-xl bg-[#10192A]/95 border border-sky-400/40 text-sky-200 text-xs font-semibold shadow-2xl backdrop-blur-md">
            {toastMessage}
          </div>
        </div>
      )}

      {/* Move History Notation Drawer */}
      {showMoveHistory && (
        <div className="fixed inset-x-4 top-24 bottom-28 z-40 max-w-sm mx-auto bg-[#0E1524]/95 border border-[#202E4A] rounded-2xl p-4 shadow-2xl backdrop-blur-md flex flex-col animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E2B45] mb-2">
            <h4 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <ListOrdered className="w-4 h-4 text-amber-400" /> Move Notation
            </h4>
            <button
              onClick={() => setShowMoveHistory(false)}
              className="text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-[#172238] border border-[#233352]"
            >
              Close
            </button>
          </div>
          <div className="flex-1 overflow-y-auto pr-1">
            {moveHistory.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-8">No moves recorded yet.</p>
            ) : (
              <div className="flex flex-col gap-1.5 text-xs font-mono">
                {moveHistory.reduce<{ white?: MoveRecord; black?: MoveRecord }[]>((acc, move, idx) => {
                  const turnIdx = Math.floor(idx / 2);
                  if (!acc[turnIdx]) acc[turnIdx] = {};
                  if (move.color === 'w') acc[turnIdx].white = move;
                  else acc[turnIdx].black = move;
                  return acc;
                }, []).map((pair, turnIdx) => (
                  <div key={turnIdx} className="grid grid-cols-2 gap-2">
                    <div className="py-1 px-2.5 rounded-lg bg-[#131B2D] border border-[#1C283F] flex items-center justify-between text-slate-200">
                      <span className="text-slate-500 font-bold text-[11px]">{turnIdx + 1}.</span>
                      <span className="font-semibold text-amber-300">{pair.white?.san}</span>
                    </div>
                    <div className="py-1 px-2.5 rounded-lg bg-[#131B2D] border border-[#1C283F] flex items-center justify-between text-slate-200">
                      <span className="text-slate-500 font-bold text-[11px]">{turnIdx + 1}...</span>
                      <span className="font-semibold text-sky-300">{pair.black ? pair.black.san : '-'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Draw Offer Incoming Modal */}
      {drawOffered && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-[#101726] border border-[#233352] rounded-3xl p-6 max-w-xs w-full text-center flex flex-col gap-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 mx-auto flex items-center justify-center text-2xl">
              🤝
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100">Draw Offered</h3>
              <p className="text-xs text-slate-400 mt-1">Your opponent has offered a draw agreement.</p>
            </div>
            <div className="grid grid-cols-2 gap-3 mt-1">
              <button
                onClick={handleAcceptDrawOffer}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md active:scale-95 transition-all"
              >
                Accept Draw
              </button>
              <button
                onClick={handleDeclineDrawOffer}
                className="py-2.5 px-3 rounded-xl bg-[#182338] hover:bg-[#202E4A] border border-[#283957] text-slate-300 text-xs font-semibold active:scale-95 transition-all"
              >
                Decline
              </button>
            </div>
          </div>
        </div>
      )}



      {/* Pawn Promotion Dialog */}
      {pendingPromotion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="bg-[#101726] border border-[#233352] rounded-3xl p-6 max-w-xs w-full text-center flex flex-col gap-4 shadow-2xl">
            <h3 className="font-bold text-lg text-slate-100">Promote Pawn</h3>
            <p className="text-xs text-slate-400">Choose a piece for promotion</p>
            <div className="grid grid-cols-4 gap-2">
              {[
                { type: 'q', label: 'Queen', icon: '♕' },
                { type: 'r', label: 'Rook', icon: '♖' },
                { type: 'b', label: 'Bishop', icon: '♗' },
                { type: 'n', label: 'Knight', icon: '♘' },
              ].map((p) => (
                <button
                  key={p.type}
                  onClick={() => {
                    makeMove(pendingPromotion.from, pendingPromotion.to, p.type, true);
                    setPendingPromotion(null);
                  }}
                  className="p-3 rounded-2xl bg-[#172238] border border-[#2B3B59] hover:border-amber-400 text-3xl flex flex-col items-center transition-all active:scale-95"
                >
                  <span>{p.icon}</span>
                  <span className="text-[10px] text-slate-300 mt-1">{p.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tactical Hint & Analysis Modal */}
      {showAnalysis && (
        <AnalysisModal
          hint={hintAnalysis}
          moves={moveHistory}
          turn={game.turn()}
          onClose={() => setShowAnalysis(false)}
          onApplyHint={
            hintAnalysis && isPlayerTurn && !matchResult
              ? () => {
                  makeMove(hintAnalysis.from as Square, hintAnalysis.to as Square, 'q', true);
                  setShowAnalysis(false);
                }
              : undefined
          }
        />
      )}

      {/* Game Over Victory / Draw Modal */}
      {matchResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="bg-gradient-to-b from-[#141C2E] to-[#0D1322] border border-[#2A3C5E] rounded-3xl p-6 max-w-sm w-full text-center flex flex-col items-center gap-4 shadow-2xl">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-4xl shadow-lg">
              {matchResult.winner === playerSide ? '🏆' : matchResult.winner === 'draw' ? '🤝' : '💀'}
            </div>

            <div>
              <h2 className="text-2xl font-black tracking-wide text-slate-100">
                {matchResult.winner === playerSide
                  ? 'Victory!'
                  : matchResult.winner === 'draw'
                  ? 'Game Drawn'
                  : 'Defeat'}
              </h2>
              <p className="text-xs text-amber-300/80 font-medium uppercase tracking-wider mt-1">
                {matchResult.reason.replace('_', ' ')}
              </p>
            </div>

            {/* Rating Delta */}
            <div className="py-2 px-4 rounded-xl bg-[#182338] border border-[#263756] text-xs font-semibold flex items-center gap-2">
              <span className="text-slate-400">Rating Adjustment:</span>
              <span className={`font-mono font-bold ${matchResult.winner === playerSide ? 'text-emerald-400' : 'text-rose-400'}`}>
                {matchResult.winner === playerSide ? `+${matchResult.scoreDeltaWhite}` : `${matchResult.scoreDeltaWhite}`} Elo
              </span>
            </div>

            <div className="w-full grid grid-cols-2 gap-3 mt-2">
              <button
                onClick={() => {
                  sound.playClick();
                  setGame(new Chess());
                  setMatchResult(null);
                  setMoveHistory([]);
                  setLastMove(null);
                  setSelectedSquare(null);
                  setLegalMoves([]);
                  setWhiteTime(timeControlSeconds || 600);
                  setBlackTime(timeControlSeconds || 600);
                  setClockRunning(false);
                }}
                className="py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs tracking-wide shadow-md active:scale-95 transition-all"
              >
                Play Again
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  onExit();
                }}
                className="py-3 px-4 rounded-xl bg-[#182338] hover:bg-[#202E4A] border border-[#2B3B59] text-white font-bold text-xs tracking-wide transition-all"
              >
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
