import React, { useState } from 'react';
import {
  Crown,
  Play,
  Globe,
  Bot,
  Trophy,
  BookOpen,
  Bell,
  Flame,
  BarChart2,
  Award,
  ShieldCheck,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { loadSavedGame, clearSavedGame, SavedGame } from '../../services/storage';
import { notificationService } from '../../services/notificationService';

interface MainMenuScreenProps {
  onPlayNow: () => void;
  onResumeGame?: (saved: SavedGame) => void;
  onSelectMode: (
    mode:
      | 'online'
      | 'ai'
      | 'local'
      | 'tournaments'
      | 'learn'
      | 'daily_challenges'
      | 'leaderboard'
      | 'progression'
  ) => void;
  onOpenNotifications?: () => void;
  onOpenAdminConsole?: () => void;
}

export const MainMenuScreen: React.FC<MainMenuScreenProps> = ({
  onPlayNow,
  onResumeGame,
  onSelectMode,
  onOpenNotifications,
  onOpenAdminConsole,
}) => {
  const [savedGame, setSavedGame] = useState<SavedGame | null>(() => loadSavedGame());
  const unreadCount = notificationService.getUnreadCount();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col justify-between px-5 pt-7 pb-20 select-none">
      {/* Top Header Utilities */}
      <div className="flex items-center justify-between w-full max-w-sm mx-auto">
        <button
          onClick={() => {
            sound.playClick();
            onOpenAdminConsole?.();
          }}
          title="Staff Fair Play & Moderation Console"
          className="p-2 rounded-xl bg-[#121B2D] border border-slate-800 text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1.5 text-xs font-semibold"
        >
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Fair Play</span>
        </button>

        {/* Crown Brand Center */}
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/25 border border-amber-300/40">
            <Crown className="w-7 h-7 text-amber-100 fill-amber-200 drop-shadow" />
          </div>
        </div>

        {/* Notification Bell */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenNotifications?.();
          }}
          title="Notification Center"
          className="relative p-2.5 rounded-xl bg-[#121B2D] border border-slate-800 text-slate-300 hover:text-white transition-colors"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center animate-pulse">
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Brand Title */}
      <div className="text-center mt-2 mb-2">
        <h1 className="font-['Cinzel'] text-3xl font-black tracking-widest bg-gradient-to-b from-[#FFF0B5] via-[#E2AF46] to-[#996515] bg-clip-text text-transparent">
          3D CHESS
        </h1>
        <p className="text-[10px] uppercase tracking-[0.3em] text-amber-200/70 font-medium">
          Competitive Ecosystem
        </p>
      </div>

      {/* Main Action Menu Group */}
      <div className="w-full max-w-sm mx-auto flex flex-col gap-3 my-auto py-2">
        {/* Unfinished Saved Match Prompt */}
        {savedGame && (
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/70 via-[#162238] to-[#101726] border border-amber-400/40 shadow-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 text-lg">
                ⏳
              </div>
              <div>
                <h4 className="font-bold text-xs text-amber-300 uppercase tracking-wider">Unfinished Match</h4>
                <p className="text-[11px] text-slate-300">
                  {savedGame.gameMode.toUpperCase()} {savedGame.difficulty ? `(${savedGame.difficulty})` : ''} •{' '}
                  {savedGame.playerColor === 'w' ? 'White' : 'Black'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  sound.playClick();
                  onResumeGame?.(savedGame);
                }}
                className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow-md active:scale-95 transition-all"
              >
                Resume
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  clearSavedGame();
                  setSavedGame(null);
                }}
                title="Discard saved game"
                className="w-7 h-7 rounded-lg bg-slate-800/80 hover:bg-rose-500/30 text-slate-400 hover:text-rose-300 text-xs flex items-center justify-center transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Play Now Hero Button */}
        <button
          onClick={() => {
            sound.playClick();
            onPlayNow();
          }}
          className="relative group overflow-hidden w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#FFE277] via-[#F3BA46] to-[#D59828] text-[#161208] font-bold text-base flex items-center justify-center gap-3 shadow-xl shadow-amber-500/20 active:scale-[0.98] transition-all duration-200 border border-amber-200/60"
        >
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          <Play className="w-5 h-5 fill-current" />
          <span className="tracking-wide">Quick Play</span>
        </button>

        {/* Grid of Core Modes */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* Online Multiplayer */}
          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('online');
            }}
            className="p-3 rounded-2xl bg-[#111827]/90 hover:bg-[#162033] border border-[#1E2B45] hover:border-sky-500/40 text-slate-100 flex flex-col gap-2 transition-all shadow-md group active:scale-[0.99]"
          >
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Globe className="w-4 h-4" />
            </div>
            <div className="text-left">
              <h4 className="font-bold text-xs text-slate-100">Multiplayer</h4>
              <p className="text-[10px] text-slate-400">Ranked & Friends</p>
            </div>
          </button>

          {/* Tournaments */}
          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('tournaments');
            }}
            className="p-3 rounded-2xl bg-[#111827]/90 hover:bg-[#162033] border border-[#1E2B45] hover:border-purple-500/40 text-slate-100 flex flex-col gap-2 transition-all shadow-md group active:scale-[0.99]"
          >
            <div className="w-9 h-9 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Trophy className="w-4 h-4" />
            </div>
            <div className="text-left">
              <h4 className="font-bold text-xs text-slate-100">Tournaments</h4>
              <p className="text-[10px] text-slate-400">Swiss & Arena</p>
            </div>
          </button>

          {/* Play vs AI */}
          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('ai');
            }}
            className="p-3 rounded-2xl bg-[#111827]/90 hover:bg-[#162033] border border-[#1E2B45] hover:border-amber-500/40 text-slate-100 flex flex-col gap-2 transition-all shadow-md group active:scale-[0.99]"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bot className="w-4 h-4" />
            </div>
            <div className="text-left">
              <h4 className="font-bold text-xs text-slate-100">Play vs AI</h4>
              <p className="text-[10px] text-slate-400">Stockfish Engine</p>
            </div>
          </button>

          {/* Daily Missions */}
          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('daily_challenges');
            }}
            className="p-3 rounded-2xl bg-[#111827]/90 hover:bg-[#162033] border border-[#1E2B45] hover:border-orange-500/40 text-slate-100 flex flex-col gap-2 transition-all shadow-md group active:scale-[0.99]"
          >
            <div className="w-9 h-9 rounded-xl bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Flame className="w-4 h-4" />
            </div>
            <div className="text-left">
              <h4 className="font-bold text-xs text-slate-100">Daily Missions</h4>
              <p className="text-[10px] text-slate-400">Streak Puzzles</p>
            </div>
          </button>
        </div>

        {/* Second Row Quick Actions: Leaderboards & Learn */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('leaderboard');
            }}
            className="py-2.5 px-2 rounded-xl bg-[#0F1524] border border-slate-800 hover:border-amber-400/40 text-slate-200 flex flex-col items-center gap-1 text-[11px] font-semibold"
          >
            <BarChart2 className="w-4 h-4 text-amber-400" />
            <span>Leaderboard</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('progression');
            }}
            className="py-2.5 px-2 rounded-xl bg-[#0F1524] border border-slate-800 hover:border-amber-400/40 text-slate-200 flex flex-col items-center gap-1 text-[11px] font-semibold"
          >
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Mastery & XP</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onSelectMode('learn');
            }}
            className="py-2.5 px-2 rounded-xl bg-[#0F1524] border border-slate-800 hover:border-amber-400/40 text-slate-200 flex flex-col items-center gap-1 text-[11px] font-semibold"
          >
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span>Academy</span>
          </button>
        </div>
      </div>

      {/* Decorative Bottom Chess Lineup */}
      <div className="flex justify-center items-center gap-4 text-slate-600/40 text-xl pb-1 select-none">
        <span>♙</span>
        <span>♘</span>
        <span>♗</span>
        <span className="text-amber-400/60 text-2xl">♔</span>
        <span>♕</span>
        <span>♖</span>
        <span>♙</span>
      </div>
    </div>
  );
};
