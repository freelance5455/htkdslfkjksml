import React, { useState } from 'react';
import { ChevronLeft, Trophy, Lightbulb, CheckCircle2, RotateCcw, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chess, Square } from 'chess.js';
import { ChessScene } from '../3d/ChessScene';
import { ENDGAME_LESSONS } from '../../services/endgameData';
import { EndgameLesson, GameSettings } from '../../types/chess';
import { sound } from '../../services/sound';

interface EndgameTrainingScreenProps {
  settings: GameSettings;
  onBack: () => void;
}

export const EndgameTrainingScreen: React.FC<EndgameTrainingScreenProps> = ({
  settings,
  onBack,
}) => {
  const [activeLessonIdx, setActiveLessonIdx] = useState(0);
  const currentLesson: EndgameLesson = ENDGAME_LESSONS[activeLessonIdx] || ENDGAME_LESSONS[0];

  const [game, setGame] = useState(() => new Chess(currentLesson.initialFen));
  const [stepIdx, setStepIdx] = useState(0);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [legalMoves, setLegalMoves] = useState<string[]>([]);
  const [status, setStatus] = useState<'playing' | 'completed' | 'mistake'>('playing');
  const [showHint, setShowHint] = useState(false);

  const handleSelectLesson = (idx: number) => {
    sound.playClick();
    setActiveLessonIdx(idx);
    const l = ENDGAME_LESSONS[idx];
    setGame(new Chess(l.initialFen));
    setStepIdx(0);
    setSelectedSquare(null);
    setLegalMoves([]);
    setStatus('playing');
    setShowHint(false);
  };

  const handleReset = () => {
    sound.playClick();
    setGame(new Chess(currentLesson.initialFen));
    setStepIdx(0);
    setSelectedSquare(null);
    setLegalMoves([]);
    setStatus('playing');
    setShowHint(false);
  };

  const handleSquareClick = (square: Square) => {
    if (status === 'completed') return;

    if (!selectedSquare) {
      const piece = game.get(square);
      if (piece && piece.color === game.turn()) {
        setSelectedSquare(square);
        const moves = game.moves({ square, verbose: true });
        setLegalMoves(moves.map((m) => m.to));
        sound.playClick();
      }
      return;
    }

    // Try making move
    const from = selectedSquare;
    const to = square;
    const expectedUci = currentLesson.solutionMoves[stepIdx];
    const attemptUci = `${from}${to}`;

    try {
      const move = game.move({ from, to, promotion: 'q' });
      if (move) {
        if (attemptUci === expectedUci || game.isCheckmate()) {
          // Correct endgame move!
          sound.playMove();
          setSelectedSquare(null);
          setLegalMoves([]);
          const nextStep = stepIdx + 1;
          setStepIdx(nextStep);

          if (nextStep >= currentLesson.solutionMoves.length || game.isCheckmate()) {
            setStatus('completed');
            sound.playVictory();
            confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
          } else {
            // Opponent automated response if applicable
            setTimeout(() => {
              const oppUci = currentLesson.solutionMoves[nextStep];
              if (oppUci) {
                game.move({
                  from: oppUci.substring(0, 2) as Square,
                  to: oppUci.substring(2, 4) as Square,
                  promotion: 'q',
                });
                setGame(new Chess(game.fen()));
                setStepIdx(nextStep + 1);
                sound.playMove();
              }
            }, 600);
          }
        } else {
          // Inaccurate endgame move
          game.undo();
          sound.playDefeat();
          setStatus('mistake');
          setSelectedSquare(null);
          setLegalMoves([]);
        }
      } else {
        setSelectedSquare(null);
        setLegalMoves([]);
      }
    } catch {
      setSelectedSquare(null);
      setLegalMoves([]);
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#070B13] text-white flex flex-col overflow-hidden select-none">
      {/* Header */}
      <div className="z-20 flex items-center justify-between px-5 pt-4 pb-2 bg-[#0A0F1D]/90 border-b border-[#1A263D] backdrop-blur-md">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-9 h-9 rounded-xl bg-[#141E33] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h2 className="text-base font-bold tracking-wide text-slate-100 flex items-center gap-1.5 justify-center">
            <Trophy className="w-4 h-4 text-amber-400" /> Endgame Mastery
          </h2>
          <p className="text-[11px] text-slate-400">Opposition, Pawn Races & Technical Checkmates</p>
        </div>

        <button
          onClick={handleReset}
          className="w-9 h-9 rounded-xl bg-[#141E33] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
          title="Reset Lesson"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* 3D Board */}
        <div className="relative flex-1 min-h-[300px] lg:min-h-0 bg-[#060910]">
          <ChessScene
            game={game}
            boardStyle={settings.boardStyle}
            pieceStyle={settings.pieceStyle}
            playerPerspective="w"
            selectedSquare={selectedSquare}
            legalMoves={legalMoves}
            lastMove={null}
            hintMove={null}
            onSquareClick={handleSquareClick}
            interactive={status === 'playing'}
          />

          {/* Goal Chip */}
          <div className="absolute top-4 inset-x-4 z-10 flex justify-center pointer-events-none">
            <div className="py-2 px-4 rounded-2xl bg-[#0D1524]/90 border border-amber-400/40 text-amber-200 text-xs font-semibold shadow-xl backdrop-blur-md max-w-sm text-center">
              Goal: {currentLesson.targetGoal}
            </div>
          </div>
        </div>

        {/* Right Panel: Lessons List, Hint, Feedback */}
        <div className="w-full lg:w-96 bg-[#0B111F] border-t lg:border-t-0 lg:border-l border-[#1A263D] flex flex-col p-4 overflow-y-auto gap-4">
          {/* Lessons List */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Endgame Modules ({ENDGAME_LESSONS.length})
            </span>
            <div className="flex flex-col gap-2">
              {ENDGAME_LESSONS.map((lesson, idx) => (
                <button
                  key={lesson.id}
                  onClick={() => handleSelectLesson(idx)}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    activeLessonIdx === idx
                      ? 'bg-amber-500/15 border-amber-400 text-amber-200 shadow-md font-bold'
                      : 'bg-[#121A2B] border-[#1E2B45] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs">{lesson.title}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#182338] text-amber-300 font-mono">
                      {lesson.difficulty}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Status Alert */}
          {status === 'completed' ? (
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-emerald-200 text-xs flex flex-col gap-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" /> Lesson Mastered!
              </div>
              <p className="text-[11px] leading-relaxed">{currentLesson.explanation}</p>
            </div>
          ) : status === 'mistake' ? (
            <div className="p-4 rounded-2xl bg-rose-500/20 border border-rose-400 text-rose-200 text-xs flex flex-col gap-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-sm">
                <AlertCircle className="w-5 h-5 text-rose-400" /> Inaccurate Move!
              </div>
              <p className="text-[11px]">
                That move ceded opposition or allowed Black to escape. Click Try Again to retry.
              </p>
              <button
                onClick={handleReset}
                className="py-1.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs w-fit"
              >
                Try Again
              </button>
            </div>
          ) : null}

          {/* Hint Card */}
          <div className="p-3.5 rounded-2xl bg-[#121A2B] border border-[#1E2B45] flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-300 flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-amber-400" /> Endgame Clues
              </span>
              <button
                onClick={() => setShowHint(!showHint)}
                className="text-[11px] text-amber-300 hover:text-amber-200 font-bold"
              >
                {showHint ? 'Hide Hint' : 'Reveal Hint'}
              </button>
            </div>

            {showHint && (
              <ul className="flex flex-col gap-1.5 mt-1 text-[11px] text-slate-300 bg-[#0E1524] p-3 rounded-xl border border-[#1A263D]">
                {currentLesson.hints.map((h, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span>💡</span>
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
