import React, { useState } from 'react';
import { Trophy, ShoppingBag, Sparkles, User, ShieldCheck, Flame, Scissors, Clock, RotateCcw } from 'lucide-react';
import { BADGES, SHOP_ITEMS, LEVELS, getLevelInfo } from '../../data/rewards';
import { useGame } from '../../context/GameContext';
import { sound } from '../../utils/sound';

export const RewardsShopScreen: React.FC = () => {
  const { state, purchaseItem, updateAvatar, resetProgress } = useGame();
  const [tab, setTab] = useState<'badges' | 'shop' | 'avatar' | 'stats'>('badges');
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const { currentLevel, nextLevel, progressPercent } = getLevelInfo(state.xp);

  const expressions = [
    { id: 'happy', label: 'Happy', emoji: '😊' },
    { id: 'confident', label: 'Confident', emoji: '😎' },
    { id: 'focused', label: 'Focused', emoji: '🧐' },
    { id: 'starry', label: 'Starry', emoji: '🤩' },
  ];

  const headwearOptions = [
    { id: 'none', label: 'None', emoji: '✨' },
    { id: 'gear_chef_hat', label: 'Chef Hat', emoji: '👨‍🍳' },
    { id: 'gear_gamer_headset', label: 'Gaming Headset', emoji: '🎧' },
    { id: 'gear_sweatband', label: 'Headband', emoji: '🎽' },
    { id: 'gear_sunglasses', label: 'Cool Shades', emoji: '🕶️' },
  ];

  const outfits = [
    { id: 'hoodie', label: 'Cozy Hoodie', emoji: '🧥' },
    { id: 'athletic', label: 'Sport Jersey', emoji: '⚽' },
    { id: 'gear_cape', label: 'Hero Cape', emoji: '🦸' },
  ];

  const accuracyPercent =
    state.stats.totalQuestionsAnswered > 0
      ? Math.round((state.stats.correctAnswers / state.stats.totalQuestionsAnswered) * 100)
      : 0;

  return (
    <div className="space-y-4">
      {/* Rewards Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-amber-400">
            <Trophy className="w-3.5 h-3.5" />
            <span>Achievements & Locker</span>
          </div>
          <h2 className="text-xl font-black font-display text-white">Rewards & Avatar Hub</h2>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-purple-500/15 border border-purple-500/30 text-purple-300 text-sm font-bold">
          <span>{state.coins}</span>
          <span>💎</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 text-xs font-bold">
        <button
          onClick={() => {
            sound.playTap();
            setTab('badges');
          }}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'badges' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          🏆 Trophies ({state.badges.length}/{BADGES.length})
        </button>

        <button
          onClick={() => {
            sound.playTap();
            setTab('shop');
          }}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'shop' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          🛒 Shop
        </button>

        <button
          onClick={() => {
            sound.playTap();
            setTab('avatar');
          }}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'avatar' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          👤 Avatar
        </button>

        <button
          onClick={() => {
            sound.playTap();
            setTab('stats');
          }}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'stats' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          📊 Stats
        </button>
      </div>

      {/* Badges / Trophies Showcase */}
      {tab === 'badges' && (
        <div className="space-y-3">
          {/* Level Progress Banner */}
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">Current Title: {currentLevel.title}</span>
              <span className="text-slate-400 font-mono">
                {state.xp} {nextLevel ? `/ ${nextLevel.minXp} XP` : 'MAX LEVEL'}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden border border-slate-700/60">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            {nextLevel && (
              <div className="text-[10px] text-slate-400 text-right">
                Next: {nextLevel.title} (+{nextLevel.rewardCoins} bonus gems)
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {BADGES.map((badge) => {
              const isUnlocked = state.badges.includes(badge.id);

              return (
                <div
                  key={badge.id}
                  className={`p-3.5 rounded-2xl border transition flex items-start gap-3 ${
                    isUnlocked
                      ? 'bg-slate-900/90 border-amber-500/40 text-slate-100'
                      : 'bg-slate-950/60 border-slate-800 text-slate-500 opacity-60'
                  }`}
                >
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border ${
                      isUnlocked
                        ? 'bg-gradient-to-tr from-amber-500/20 to-yellow-500/30 border-amber-400/50 shadow-md'
                        : 'bg-slate-800 border-slate-700 grayscale'
                    }`}
                  >
                    {badge.icon}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white">{badge.title}</span>
                      <span
                        className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded-full ${
                          badge.rarity === 'legendary'
                            ? 'bg-amber-500/20 text-amber-300'
                            : badge.rarity === 'epic'
                            ? 'bg-purple-500/20 text-purple-300'
                            : badge.rarity === 'rare'
                            ? 'bg-cyan-500/20 text-cyan-300'
                            : 'bg-slate-700 text-slate-300'
                        }`}
                      >
                        {badge.rarity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">{badge.description}</p>
                    <div className="text-[10px] font-semibold text-emerald-400 pt-0.5">
                      {isUnlocked ? '✓ Unlocked' : '🔒 Locked'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Rewards Shop */}
      {tab === 'shop' && (
        <div className="space-y-3">
          <div className="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-xs text-purple-200 flex items-center justify-between">
            <span>Spend your earned Healthy Gems to stock up on lifelines and gear!</span>
            <span className="font-bold text-purple-300 font-mono text-sm">{state.coins} 💎</span>
          </div>

          <div className="grid gap-2.5">
            {SHOP_ITEMS.map((item) => {
              const ownedCount = state.inventory[item.id] || 0;
              const canAfford = state.coins >= item.price;

              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{item.name}</span>
                        {ownedCount > 0 && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-emerald-300 font-bold border border-emerald-500/30">
                            Owned: {ownedCount}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-tight mt-0.5">{item.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => purchaseItem(item.id)}
                    disabled={!canAfford}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                      canAfford
                        ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-900/30 active:scale-95'
                        : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <span>{item.price}</span>
                    <span>💎</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Avatar Customizer */}
      {tab === 'avatar' && (
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-4">
            {/* Visual Avatar Card */}
            <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-600 border-2 border-emerald-400/50 flex flex-col items-center justify-center shadow-xl shadow-emerald-950/40 shrink-0">
              <span className="text-5xl">
                {expressions.find((e) => e.id === state.avatar.expression)?.emoji || '😊'}
              </span>
              {state.avatar.headwear !== 'none' && (
                <span className="absolute -top-3 text-2xl">
                  {headwearOptions.find((h) => h.id === state.avatar.headwear)?.emoji}
                </span>
              )}
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white font-display">Teen Nutrition Champion</h3>
              <p className="text-xs text-slate-400">Customize your avatar’s look and mood!</p>
              <div className="text-[11px] text-emerald-400 font-semibold">
                Title: {currentLevel.title}
              </div>
            </div>
          </div>

          {/* Mood Expression */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Facial Mood:
            </label>
            <div className="grid grid-cols-4 gap-2">
              {expressions.map((exp) => (
                <button
                  key={exp.id}
                  onClick={() => updateAvatar({ expression: exp.id as any })}
                  className={`p-2 rounded-xl border text-center transition cursor-pointer ${
                    state.avatar.expression === exp.id
                      ? 'bg-emerald-600/30 border-emerald-500 text-white font-bold'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <span className="text-xl block">{exp.emoji}</span>
                  <span className="text-[10px] mt-0.5 block">{exp.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Headwear */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Headwear & Gear:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {headwearOptions.map((gear) => (
                <button
                  key={gear.id}
                  onClick={() => updateAvatar({ headwear: gear.id })}
                  className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                    state.avatar.headwear === gear.id
                      ? 'bg-amber-600/30 border-amber-500 text-white font-bold'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <span className="text-xl block">{gear.emoji}</span>
                  <span className="text-[10px] mt-0.5 block truncate">{gear.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Lifetime Stats */}
      {tab === 'stats' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Total Answered</div>
              <div className="text-2xl font-black text-white font-mono mt-1">
                {state.stats.totalQuestionsAnswered}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Accuracy Rate</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                {accuracyPercent}%
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Streak Record</div>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                {state.streak}🔥
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Plate Blitz High</div>
              <div className="text-2xl font-black text-cyan-400 font-mono mt-1">
                {state.stats.blitzHighScore}
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-2">
            <div className="font-bold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Progress Persistence
            </div>
            <p>
              Your game saves locally on this device. When installed as an Android APK via WebAPK, your achievements and unlocks persist offline.
            </p>

            <div className="pt-2">
              {showResetConfirm ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      resetProgress();
                      setShowResetConfirm(false);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
                  >
                    Confirm Reset Everything
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="text-xs text-rose-400 hover:underline cursor-pointer"
                >
                  Reset Game Data
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
