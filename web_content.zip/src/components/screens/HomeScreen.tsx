import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryList } from '../customer/CategoryList';
import { FoodDeliveryView } from '../customer/FoodDeliveryView';
import { GroceryDeliveryView } from '../customer/GroceryDeliveryView';
import { RideBookingView } from '../customer/RideBookingView';
import { HomeServiceBookingView } from '../customer/HomeServiceBookingView';
import { CourierServiceView } from '../customer/CourierServiceView';
import { CartView } from '../customer/CartView';
import { ActiveOrderTracker } from '../customer/ActiveOrderTracker';
import { OrderHistoryView } from '../customer/OrderHistoryView';
import { UserProfileView } from '../customer/UserProfileView';
import { ProviderDashboard } from '../provider/ProviderDashboard';
import { DeliveryDashboard } from '../delivery/DeliveryDashboard';
import { AdminDashboard } from '../admin/AdminDashboard';
import { ChatModal } from '../customer/ChatModal';
import { ServiceCategoryType, Order } from '../../types';

export const HomeScreen: React.FC = () => {
  const { role, activeTab, orders } = useApp();

  // Navigation states within Customer experience
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategoryType | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);
  const [activeChatSessionId, setActiveChatSessionId] = useState<string | null>(null);

  // If role is Provider, render Provider portal
  if (role === 'provider') {
    return (
      <>
        <ProviderDashboard onOpenChat={sessionId => setActiveChatSessionId(sessionId)} />
        {activeChatSessionId && (
          <ChatModal
            sessionId={activeChatSessionId}
            onClose={() => setActiveChatSessionId(null)}
          />
        )}
      </>
    );
  }

  // If role is Delivery, render Delivery Partner portal
  if (role === 'delivery') {
    return (
      <>
        <DeliveryDashboard onOpenChat={sessionId => setActiveChatSessionId(sessionId)} />
        {activeChatSessionId && (
          <ChatModal
            sessionId={activeChatSessionId}
            onClose={() => setActiveChatSessionId(null)}
          />
        )}
      </>
    );
  }

  // If role is Admin, render Super Admin portal
  if (role === 'admin') {
    return <AdminDashboard />;
  }

  // CUSTOMER EXPERIENCE
  // 1. If viewing Cart
  if (isCartOpen) {
    return (
      <CartView
        onBack={() => setIsCartOpen(false)}
        onOrderPlaced={orderId => {
          setIsCartOpen(false);
          const found = orders.find(o => o.id === orderId);
          if (found) setTrackedOrder(found);
        }}
      />
    );
  }

  // 2. If tracking an active order
  if (trackedOrder) {
    return (
      <>
        <ActiveOrderTracker
          order={trackedOrder}
          onBack={() => setTrackedOrder(null)}
          onOpenChat={sessionId => setActiveChatSessionId(sessionId)}
        />
        {activeChatSessionId && (
          <ChatModal
            sessionId={activeChatSessionId}
            onClose={() => setActiveChatSessionId(null)}
          />
        )}
      </>
    );
  }

  // 3. Tab switching from bottom navigation
  if (activeTab === 'bookings') {
    return (
      <OrderHistoryView
        onSelectOrder={order => setTrackedOrder(order)}
      />
    );
  }

  if (activeTab === 'profile') {
    return <UserProfileView />;
  }

  // 4. If a Category is selected
  if (selectedCategory) {
    if (selectedCategory === 'food') {
      return (
        <FoodDeliveryView
          onBack={() => setSelectedCategory(null)}
          onOpenCart={() => setIsCartOpen(true)}
        />
      );
    }

    if (selectedCategory === 'grocery') {
      return (
        <GroceryDeliveryView
          onBack={() => setSelectedCategory(null)}
          onOpenCart={() => setIsCartOpen(true)}
        />
      );
    }

    if (selectedCategory === 'ride') {
      return (
        <RideBookingView
          onBack={() => setSelectedCategory(null)}
          onRideConfirmed={orderId => {
            setSelectedCategory(null);
            const found = orders.find(o => o.id === orderId);
            if (found) setTrackedOrder(found);
          }}
        />
      );
    }

    if (selectedCategory === 'courier') {
      return (
        <CourierServiceView
          onBack={() => setSelectedCategory(null)}
          onBookingSuccess={orderId => {
            setSelectedCategory(null);
            const found = orders.find(o => o.id === orderId);
            if (found) setTrackedOrder(found);
          }}
        />
      );
    }

    // Home Services (Electrician, Plumber, Appliance, Cleaning, Salon, Massage, Artists, etc.)
    return (
      <HomeServiceBookingView
        category={selectedCategory}
        onBack={() => setSelectedCategory(null)}
        onBookingSuccess={orderId => {
          setSelectedCategory(null);
          const found = orders.find(o => o.id === orderId);
          if (found) setTrackedOrder(found);
        }}
      />
    );
  }

  // Default Home View (Category Explorer & Highlights)
  return (
    <div className="pb-24">
      <CategoryList onSelectCategory={cat => setSelectedCategory(cat)} />
      {activeChatSessionId && (
        <ChatModal
          sessionId={activeChatSessionId}
          onClose={() => setActiveChatSessionId(null)}
        />
      )}
    </div>
  );
};
