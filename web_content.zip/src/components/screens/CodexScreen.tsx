import React, { useState } from 'react';
import { BookOpen, Sparkles, CheckCircle2, ChevronRight, HelpCircle, ArrowRight } from 'lucide-react';
import { FoodGroupId } from '../../types/game';
import { FOOD_GROUPS, FOOD_GROUP_LIST } from '../../data/foodGroups';
import { sound } from '../../utils/sound';

interface CodexScreenProps {
  initialGroup?: string;
  onLaunchQuiz: (group: string) => void;
}

export const CodexScreen: React.FC<CodexScreenProps> = ({ initialGroup = 'vegetables', onLaunchQuiz }) => {
  const [selectedGroupId, setSelectedGroupId] = useState<FoodGroupId>(
    (initialGroup in FOOD_GROUPS ? initialGroup : 'vegetables') as FoodGroupId
  );

  const group = FOOD_GROUPS[selectedGroupId];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-cyan-400">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Nutrition Encyclopedia</span>
          </div>
          <h2 className="text-xl font-black font-display text-white">The 5 Food Groups Codex</h2>
        </div>
        <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-xl shrink-0">
          📖
        </div>
      </div>

      {/* 5 Group Selector Pills */}
      <div className="grid grid-cols-5 gap-1 text-[11px] font-bold">
        {FOOD_GROUP_LIST.map((item) => {
          const isSelected = selectedGroupId === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                sound.playTap();
                setSelectedGroupId(item.id);
              }}
              className={`py-2 px-1 rounded-2xl flex flex-col items-center justify-center gap-1 transition cursor-pointer border ${
                isSelected
                  ? 'bg-slate-800 text-white border-slate-600 shadow-md ring-1 ring-slate-500'
                  : 'bg-slate-900/60 text-slate-400 border-transparent hover:bg-slate-800'
              }`}
            >
              <span className="text-xl">{item.emoji}</span>
              <span className="text-[10px] truncate max-w-full">{item.shortName.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Group Detail Card */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 relative overflow-hidden">
        {/* Banner with Group Colors */}
        <div className={`p-4 rounded-2xl bg-gradient-to-r ${group.gradient} text-white shadow-lg space-y-1`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider opacity-90">Food Group Deep-Dive</span>
            <span className="text-2xl">{group.emoji}</span>
          </div>
          <h3 className="text-xl font-black font-display">{group.name}</h3>
          <p className="text-xs opacity-95 italic">{group.tagline}</p>
        </div>

        {/* Why Teens Need It */}
        <div className="space-y-1.5">
          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Why Teens Specifically Need It:</span>
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3.5 rounded-2xl border border-slate-800/80">
            {group.teenWhy}
          </p>
        </div>

        {/* Recommended Daily Servings (Boys vs Girls) */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="text-xs font-bold text-white flex items-center justify-between">
            <span>Recommended Daily Servings for Teens (12-18 yrs):</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Teen Girls</div>
              <div className="text-sm font-black text-rose-300 mt-0.5">{group.recommendedServings.girls}</div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Teen Boys</div>
              <div className="text-sm font-black text-cyan-300 mt-0.5">{group.recommendedServings.boys}</div>
            </div>
          </div>

          <div className="pt-1 text-[11px] text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300">What Counts as 1 Serving?</div>
            <ul className="list-disc list-inside space-y-0.5 pl-1 text-slate-300">
              {group.recommendedServings.servingExamples.map((ex, i) => (
                <li key={i}>{ex}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Top Nutrient Superpowers */}
        <div className="space-y-1.5">
          <div className="text-xs font-bold text-slate-300">Key Nutrients Supplied:</div>
          <div className="flex flex-wrap gap-1.5">
            {group.keyNutrients.map((nutrient, idx) => (
              <span
                key={idx}
                className="py-1 px-2.5 rounded-full bg-slate-800 text-[11px] font-semibold text-slate-200 border border-slate-700"
              >
                {nutrient}
              </span>
            ))}
          </div>
        </div>

        {/* Top Foods Showcase */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-300">Top Foods & Teen Perks:</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {group.topFoods.map((f, i) => (
              <div
                key={i}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-2.5 text-xs"
              >
                <span className="text-2xl shrink-0">{f.emoji}</span>
                <div>
                  <div className="font-bold text-white">{f.name}</div>
                  <div className="text-[11px] text-slate-400 leading-tight mt-0.5">{f.highlight}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Teen Pro-Tip Callout */}
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-2.5">
          <span className="text-xl shrink-0">💡</span>
          <div>
            <strong className="text-amber-400 font-bold block mb-0.5">Teen Pro-Tip:</strong>
            <span className="leading-relaxed">{group.teenProTip}</span>
          </div>
        </div>

        {/* Launch Quiz for this specific group */}
        <button
          onClick={() => {
            sound.playTap();
            onLaunchQuiz(group.id);
          }}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-900/30 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
        >
          <span>Test My Knowledge on {group.shortName}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
