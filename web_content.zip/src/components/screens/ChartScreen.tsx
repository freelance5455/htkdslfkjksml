"use client";

import { useMemo, useState } from "react";
import { Card, EmptyState, ErrorCard, Pill, Skeleton, Stat } from "@/components/ui";
import { useApi } from "@/lib/client/useApi";
import { useTradeTape } from "@/lib/client/tradeTapeService";
import { arr, fmtCompact, fmtPct, fmtPrice, fmtTime } from "@/lib/format";
import { SYMBOLS } from "@/lib/universe";

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
type KlineResp = {
  ok?: boolean;
  candles?: Candle[];
  source?: string;
  ticker?: { price: number; change24h: number; high24h: number; low24h: number; volume24h: number } | null;
  error?: string | null;
};

const INTERVALS = [
  { key: "15m", label: "15 דק'" },
  { key: "1h", label: "שעה" },
  { key: "4h", label: "4 שעות" },
  { key: "1d", label: "יומי" },
];

function CandleChart({ candles }: { candles: Candle[] }) {
  const data = candles.slice(-90);
  const { width, height, pad } = { width: 900, height: 320, pad: 8 };
  const stats = useMemo(() => {
    if (data.length === 0) return null;
    const highs = data.map((c) => c.high);
    const lows = data.map((c) => c.low);
    const max = Math.max(...highs);
    const min = Math.min(...lows);
    const range = max - min || 1;
    const maxVol = Math.max(...data.map((c) => c.volume), 1);
    return { max, min, range, maxVol };
  }, [data]);

  if (!stats || data.length === 0) return <EmptyState text="אין נתוני נרות להצגה" />;

  const slot = (width - pad * 2) / data.length;
  const bodyW = Math.max(1.5, slot * 0.62);
  const priceY = (p: number) => pad + ((stats.max - p) / stats.range) * (height - pad * 2 - 60);
  const gridLines = 5;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-72 w-full" preserveAspectRatio="none">
      {Array.from({ length: gridLines }).map((_, i) => {
        const y = pad + (i / (gridLines - 1)) * (height - pad * 2 - 60);
        const price = stats.max - (i / (gridLines - 1)) * stats.range;
        return (
          <g key={i}>
            <line x1={0} x2={width} y1={y} y2={y} stroke="#1e293b" strokeWidth={1} />
            <text x={4} y={y - 3} fill="#64748b" fontSize={10}>
              {fmtPrice(price)}
            </text>
          </g>
        );
      })}
      {data.map((c, i) => {
        const x = pad + i * slot + slot / 2;
        const up = c.close >= c.open;
        const color = up ? "#10b981" : "#f43f5e";
        const yHigh = priceY(c.high);
        const yLow = priceY(c.low);
        const yOpen = priceY(c.open);
        const yClose = priceY(c.close);
        const top = Math.min(yOpen, yClose);
        const bodyH = Math.max(1, Math.abs(yClose - yOpen));
        const volH = (c.volume / stats.maxVol) * 45;
        return (
          <g key={`${c.time}-${i}`}>
            <line x1={x} x2={x} y1={yHigh} y2={yLow} stroke={color} strokeWidth={1} />
            <rect x={x - bodyW / 2} y={top} width={bodyW} height={bodyH} fill={color} />
            <rect x={x - bodyW / 2} y={height - 10 - volH} width={bodyW} height={volH} fill={color} opacity={0.35} />
          </g>
        );
      })}
    </svg>
  );
}

export default function ChartScreen() {
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [interval, setIntervalKey] = useState("1h");
  const kline = useApi<KlineResp>(`/api/market/klines?symbol=${symbol}&interval=${interval}&limit=200`, {
    intervalMs: 30000,
  });
  const tape = useTradeTape(symbol);

  const candles = arr<Candle>(kline.data?.candles);
  const ticker = kline.data?.ticker ?? null;
  const price = tape.lastPrice > 0 ? tape.lastPrice : (ticker?.price ?? 0);

  const maxBid = Math.max(...tape.bids.map((b) => b.qty), 1);
  const maxAsk = Math.max(...tape.asks.map((a) => a.qty), 1);
  const bidSum = tape.bids.reduce((s, b) => s + b.qty, 0);
  const askSum = tape.asks.reduce((s, a) => s + a.qty, 0);
  const imbalance = bidSum + askSum > 0 ? (bidSum / (bidSum + askSum)) * 100 : 50;
  const spread = tape.asks[0] && tape.bids[0] ? tape.asks[0].price - tape.bids[0].price : 0;

  return (
    <div className="space-y-4">
      <Card
        title={`גרף נרות מסונכרן - ${symbol}`}
        subtitle={`מקור: ${kline.data?.source ?? "—"} · ערוץ בזמן אמת: ${
          tape.mode === "ws" ? "WebSocket Bybit" : tape.mode === "rest" ? "פולינג REST (גיבוי)" : "מנותק"
        }`}
        action={
          <div className="flex flex-wrap items-center gap-2">
            <select
              className="rounded-xl border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
            >
              {SYMBOLS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <div className="flex gap-1">
              {INTERVALS.map((i) => (
                <button
                  key={i.key}
                  onClick={() => setIntervalKey(i.key)}
                  className={`rounded-lg px-2 py-1 text-[11px] font-bold ${
                    interval === i.key ? "bg-sky-500 text-white" : "bg-slate-800 text-slate-300"
                  }`}
                >
                  {i.label}
                </button>
              ))}
            </div>
          </div>
        }
      >
        <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-5">
          <Stat label="מחיר אחרון" value={fmtPrice(price)} />
          <Stat label="שינוי 24ש" value={fmtPct(ticker?.change24h)} tone={(ticker?.change24h ?? 0) >= 0 ? "up" : "down"} />
          <Stat label="גבוה 24ש" value={fmtPrice(ticker?.high24h)} />
          <Stat label="נמוך 24ש" value={fmtPrice(ticker?.low24h)} />
          <Stat label="מחזור 24ש" value={`${fmtCompact(ticker?.volume24h)}$`} />
        </div>
        {kline.loading && candles.length === 0 ? (
          <Skeleton rows={4} />
        ) : candles.length === 0 ? (
          <ErrorCard detail={kline.error ?? kline.data?.error ?? null} onRetry={() => void kline.refresh()} />
        ) : (
          <CandleChart candles={candles} />
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card
          title="ספר פקודות (עומק שוק)"
          subtitle={`מרווח: ${spread ? fmtPrice(spread) : "—"} · לחץ קונים ${imbalance.toFixed(0)}%`}
          action={<Pill tone={tape.mode === "ws" ? "green" : tape.mode === "rest" ? "amber" : "red"}>
            {tape.mode === "ws" ? "זמן אמת" : tape.mode === "rest" ? "גיבוי REST" : "מנותק"}
          </Pill>}
        >
          {tape.loading && tape.bids.length === 0 ? (
            <Skeleton rows={4} />
          ) : tape.bids.length === 0 && tape.asks.length === 0 ? (
            <ErrorCard detail={tape.error} onRetry={() => void tape.refresh()} />
          ) : (
            <div className="grid grid-cols-2 gap-3 text-[11px] tabular-nums">
              <div>
                <div className="mb-1 flex justify-between text-slate-400">
                  <span>ביקושים (Bids)</span>
                  <span>כמות</span>
                </div>
                {tape.bids.map((b, i) => (
                  <div key={`${b.price}-${i}`} className="relative mb-0.5 flex justify-between rounded px-1 py-0.5">
                    <span
                      className="absolute inset-y-0 right-0 rounded bg-emerald-500/15"
                      style={{ width: `${(b.qty / maxBid) * 100}%` }}
                    />
                    <span className="relative text-emerald-400">{fmtPrice(b.price)}</span>
                    <span className="relative text-slate-300">{b.qty.toFixed(3)}</span>
                  </div>
                ))}
              </div>
              <div>
                <div className="mb-1 flex justify-between text-slate-400">
                  <span>היצעים (Asks)</span>
                  <span>כמות</span>
                </div>
                {tape.asks.map((a, i) => (
                  <div key={`${a.price}-${i}`} className="relative mb-0.5 flex justify-between rounded px-1 py-0.5">
                    <span
                      className="absolute inset-y-0 right-0 rounded bg-rose-500/15"
                      style={{ width: `${(a.qty / maxAsk) * 100}%` }}
                    />
                    <span className="relative text-rose-400">{fmtPrice(a.price)}</span>
                    <span className="relative text-slate-300">{a.qty.toFixed(3)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>

        <Card title="סרט עסקאות בזמן אמת" subtitle="עסקאות ביצוע בשוק - קניות ומכירות גדולות מודגשות">
          {tape.trades.length === 0 ? (
            tape.loading ? (
              <Skeleton rows={4} />
            ) : (
              <EmptyState text="ממתין לעסקאות..." />
            )
          ) : (
            <div className="max-h-80 overflow-y-auto text-[11px] tabular-nums">
              <div className="mb-1 flex justify-between text-slate-400">
                <span>שעה</span>
                <span>מחיר</span>
                <span>כמות</span>
              </div>
              {tape.trades.slice(0, 40).map((t, i) => {
                const big = t.qty * t.price > 50000;
                return (
                  <div
                    key={`${t.time}-${i}`}
                    className={`mb-0.5 flex justify-between rounded px-1 py-0.5 ${
                      t.side === "Buy" ? "bg-emerald-500/5" : "bg-rose-500/5"
                    } ${big ? "font-black ring-1 ring-amber-500/40" : ""}`}
                  >
                    <span className="text-slate-500">{fmtTime(new Date(t.time))}</span>
                    <span className={t.side === "Buy" ? "text-emerald-400" : "text-rose-400"}>{fmtPrice(t.price)}</span>
                    <span className="text-slate-300">{t.qty.toFixed(4)}</span>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
