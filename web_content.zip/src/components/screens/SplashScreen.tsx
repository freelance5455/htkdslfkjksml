import React, { useEffect, useState } from 'react';
import { Crown } from 'lucide-react';
import { sound } from '../../services/sound';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onFinish, 400);
          return 100;
        }
        return prev + Math.floor(Math.random() * 22) + 10;
      });
    }, 180);

    return () => clearInterval(interval);
  }, [onFinish]);

  return (
    <div
      onClick={() => {
        sound.playClick();
        onFinish();
      }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-radial from-[#121A2C] via-[#0A0E17] to-[#05070B] text-white p-8 cursor-pointer select-none"
    >
      {/* Top subtle status info */}
      <div className="w-full flex justify-between items-center text-xs text-slate-400 font-mono tracking-wider pt-2">
        <span>9:41</span>
        <div className="flex items-center gap-1.5">
          <span className="w-3.5 h-2 border border-slate-400 rounded-sm inline-block" />
          <span className="w-2 h-2 bg-slate-400 rounded-full inline-block" />
        </div>
      </div>

      {/* Main Center Emblem & Cinematic 3D Chess Pieces */}
      <div className="flex flex-col items-center justify-center my-auto w-full max-w-sm text-center">
        {/* Golden Crown Icon */}
        <div className="relative mb-4">
          <div className="absolute inset-0 bg-amber-500/20 blur-2xl rounded-full scale-150" />
          <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-700 flex items-center justify-center shadow-2xl shadow-amber-500/30 border border-amber-300/40">
            <Crown className="w-11 h-11 text-amber-100 fill-amber-200 drop-shadow-md" />
          </div>
        </div>

        {/* Title Lockup */}
        <h1 className="font-['Cinzel'] text-4xl sm:text-5xl font-extrabold tracking-wider bg-gradient-to-b from-[#FFF2B2] via-[#E5B54B] to-[#996515] bg-clip-text text-transparent drop-shadow-lg">
          3D CHESS
        </h1>
        <p className="text-xs uppercase tracking-[0.35em] text-amber-200/80 mt-2 font-medium">
          Think • Move • Win
        </p>

        {/* Decorative 3D Pieces Silhouette Art */}
        <div className="relative w-full h-48 my-8 flex items-end justify-center gap-3">
          <div className="text-4xl text-slate-500/40 translate-y-2">♜</div>
          <div className="text-5xl text-slate-400/50 -translate-y-1">♞</div>
          <div className="text-7xl text-amber-300/80 font-bold drop-shadow-[0_0_20px_rgba(245,158,11,0.4)]">♚</div>
          <div className="text-6xl text-amber-100/70 -translate-y-2">♛</div>
          <div className="text-5xl text-slate-400/50 -translate-y-1">♝</div>
          <div className="text-4xl text-slate-500/40 translate-y-2">♟</div>
        </div>
      </div>

      {/* Bottom Loading Progress Bar */}
      <div className="w-full max-w-xs mb-8 flex flex-col items-center gap-3">
        <div className="w-full bg-[#1A2234] h-1.5 rounded-full overflow-hidden border border-[#2D3748]">
          <div
            className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-200 rounded-full transition-all duration-200 shadow-[0_0_12px_rgba(251,191,36,0.8)]"
            style={{ width: `${Math.min(100, progress)}%` }}
          />
        </div>
        <p className="text-xs text-amber-200/60 font-mono tracking-widest animate-pulse">
          Loading 3D Engine & Pieces...
        </p>
      </div>
    </div>
  );
};
