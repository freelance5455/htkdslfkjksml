"use client";

import { useMemo, useState } from "react";
import { Card, ErrorCard, Skeleton, Stat } from "@/components/ui";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtCompact, fmtPct, fmtPrice } from "@/lib/format";

type Row = {
  symbol: string;
  base: string;
  hebrewName: string;
  sector: string;
  price: number;
  change24h: number;
  volume24h: number;
};

type Resp = {
  ok?: boolean;
  tickers?: Row[];
  fearGreed?: { value: number; hebrew: string; classification: string; updatedAt: number };
  global?: { totalMarketCap: number; totalVolume: number; btcDominance: number; marketCapChange24h: number };
  source?: string;
  error?: string | null;
};

const colorFor = (pct: number) => {
  const clamped = Math.max(-5, Math.min(5, pct));
  if (clamped >= 0) {
    const alpha = 0.18 + (clamped / 5) * 0.72;
    return `rgba(16,185,129,${alpha.toFixed(2)})`;
  }
  const alpha = 0.18 + (Math.abs(clamped) / 5) * 0.72;
  return `rgba(244,63,94,${alpha.toFixed(2)})`;
};

export default function HeatmapScreen() {
  const { data, loading, error, refresh } = useApi<Resp>("/api/market/overview", { intervalMs: 20000 });
  const [metric, setMetric] = useState<"volume" | "equal">("volume");
  const rows = arr<Row>(data?.tickers);

  const sectors = useMemo(() => {
    const map = new Map<string, Row[]>();
    for (const r of rows) {
      const key = r.sector || "אחר";
      map.set(key, [...(map.get(key) ?? []), r]);
    }
    return [...map.entries()]
      .map(([name, items]) => ({
        name,
        items: [...items].sort((a, b) => b.volume24h - a.volume24h),
        volume: items.reduce((s, i) => s + i.volume24h, 0),
        avgChange: items.reduce((s, i) => s + i.change24h, 0) / Math.max(1, items.length),
      }))
      .sort((a, b) => b.volume - a.volume);
  }, [rows]);

  const fng = data?.fearGreed;
  const gl = data?.global;

  if (loading && rows.length === 0) {
    return (
      <Card title="מפת שוק">
        <Skeleton rows={6} />
      </Card>
    );
  }

  if (rows.length === 0) {
    return <ErrorCard detail={error ?? data?.error ?? null} onRetry={() => void refresh()} />;
  }

  return (
    <div className="space-y-4">
      <Card title="סקירת שוק ומדד הפחד והחמדנות" subtitle={`מקור נתונים: ${data?.source ?? "—"}`}>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
          <Stat
            label="מדד פחד וחמדנות"
            value={`${fng?.value ?? "—"} · ${fng?.hebrew ?? ""}`}
            tone={(fng?.value ?? 50) >= 55 ? "up" : (fng?.value ?? 50) <= 44 ? "down" : "warn"}
            hint={fng?.classification}
          />
          <Stat label="שווי שוק כולל" value={`${fmtCompact(gl?.totalMarketCap)}$`} />
          <Stat label="מחזור יומי" value={`${fmtCompact(gl?.totalVolume)}$`} />
          <Stat label="דומיננטיות ביטקוין" value={`${(gl?.btcDominance ?? 0).toFixed(1)}%`} />
          <Stat
            label="שינוי שווי שוק 24ש"
            value={fmtPct(gl?.marketCapChange24h)}
            tone={(gl?.marketCapChange24h ?? 0) >= 0 ? "up" : "down"}
          />
        </div>
        <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-gradient-to-l from-emerald-500 via-amber-400 to-rose-500">
          <div className="relative h-full">
            <span
              className="absolute top-0 h-3 w-1 bg-white"
              style={{ right: `${Math.max(0, Math.min(100, fng?.value ?? 50))}%` }}
            />
          </div>
        </div>
        <div className="mt-1 flex justify-between text-[10px] text-slate-500">
          <span>חמדנות קיצונית (100)</span>
          <span>ניטרלי (50)</span>
          <span>פחד קיצוני (0)</span>
        </div>
      </Card>

      <Card
        title="מפת חום סקטוריאלית (Finviz Style)"
        subtitle="גודל התא לפי מחזור מסחר · צבע לפי שינוי 24 שעות (-5% עד +5%)"
        action={
          <select
            className="rounded-xl border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs"
            value={metric}
            onChange={(e) => setMetric(e.target.value as "volume" | "equal")}
          >
            <option value="volume">שקלול לפי מחזור</option>
            <option value="equal">משקל שווה</option>
          </select>
        }
      >
        <div className="space-y-4">
          {sectors.map((sector) => {
            const totalVol = sector.items.reduce((s, i) => s + i.volume24h, 0) || 1;
            return (
              <div key={sector.name}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{sector.name}</span>
                  <span className={sector.avgChange >= 0 ? "text-emerald-400" : "text-rose-400"}>
                    ממוצע סקטור {fmtPct(sector.avgChange)} · מחזור {fmtCompact(sector.volume)}$
                  </span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {sector.items.map((item) => {
                    const share = metric === "volume" ? (item.volume24h / totalVol) * 100 : 100 / sector.items.length;
                    const basis = Math.max(88, Math.min(340, share * 6));
                    return (
                      <div
                        key={item.symbol}
                        className="flex min-h-[74px] flex-col justify-between rounded-lg border border-slate-800 p-2 transition hover:brightness-125"
                        style={{ background: colorFor(item.change24h), flex: `1 1 ${basis}px` }}
                        title={`${item.hebrewName} · מחזור ${fmtCompact(item.volume24h)}$`}
                      >
                        <div className="flex items-baseline justify-between">
                          <span className="text-sm font-black text-white">{item.base}</span>
                          <span className="text-[10px] text-white/70">{fmtCompact(item.volume24h)}$</span>
                        </div>
                        <div className="text-[11px] text-white/90">{fmtPrice(item.price)}</div>
                        <div className="text-sm font-black text-white">{fmtPct(item.change24h)}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
