import React, { useState, useEffect } from 'react';
import { Play, RotateCcw, Zap, Flame, Trophy, Sparkles, Check, X } from 'lucide-react';
import { FoodItem, FoodGroupId } from '../../types/game';
import { FOOD_ITEMS } from '../../data/foods';
import { FOOD_GROUPS } from '../../data/foodGroups';
import { useGame } from '../../context/GameContext';
import { sound } from '../../utils/sound';

export const PlateBlitzScreen: React.FC<{ onBackToMap: () => void }> = ({ onBackToMap }) => {
  const { state, addCoins, addXp, updateBlitzScore } = useGame();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [correctCount, setCorrectCount] = useState(0);
  const [currentFoodIndex, setCurrentFoodIndex] = useState(0);
  const [shuffledFoods, setShuffledFoods] = useState<FoodItem[]>([]);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);

  // Shuffle foods when starting
  const startGame = () => {
    sound.playTap();
    const shuffled = [...FOOD_ITEMS].sort(() => Math.random() - 0.5);
    setShuffledFoods(shuffled);
    setCurrentFoodIndex(0);
    setScore(0);
    setCombo(1);
    setCorrectCount(0);
    setTimeLeft(60);
    setIsGameOver(false);
    setIsPlaying(true);
    setFeedback(null);
  };

  // Timer
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          finishGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isPlaying, score, correctCount]);

  const finishGame = () => {
    setIsPlaying(false);
    setIsGameOver(true);
    sound.playLevelUp();
    updateBlitzScore(score);
    // Reward player with coins and XP based on score
    const earnedCoins = Math.max(10, Math.floor(score / 15));
    const earnedXp = Math.floor(score / 5);
    addCoins(earnedCoins);
    addXp(earnedXp);
  };

  const handleGroupTap = (groupId: FoodGroupId) => {
    if (!isPlaying || isGameOver || shuffledFoods.length === 0) return;
    const currentFood = shuffledFoods[currentFoodIndex % shuffledFoods.length];
    const isCorrect = currentFood.groupId === groupId;

    if (isCorrect) {
      sound.playCorrect();
      const points = 10 * combo;
      setScore((s) => s + points);
      setCombo((c) => Math.min(5, c + 1));
      setCorrectCount((c) => c + 1);
      setFeedback({
        isCorrect: true,
        text: `+${points} pts! ${currentFood.name} is in ${FOOD_GROUPS[groupId].shortName}!`,
      });
    } else {
      sound.playWrong();
      setCombo(1);
      setFeedback({
        isCorrect: false,
        text: `Oops! ${currentFood.name} belongs to ${FOOD_GROUPS[currentFood.groupId].name}!`,
      });
    }

    // Advance to next food
    setCurrentFoodIndex((prev) => prev + 1);
  };

  const currentFood = shuffledFoods[currentFoodIndex % shuffledFoods.length] || FOOD_ITEMS[0];

  const groupButtons: { id: FoodGroupId; name: string; emoji: string; color: string; border: string }[] = [
    { id: 'vegetables', name: 'Vegetables', emoji: '🥦', color: 'bg-emerald-600 hover:bg-emerald-500', border: 'border-emerald-400/40' },
    { id: 'fruits', name: 'Fruits', emoji: '🍎', color: 'bg-rose-600 hover:bg-rose-500', border: 'border-rose-400/40' },
    { id: 'grains', name: 'Grains', emoji: '🌾', color: 'bg-amber-600 hover:bg-amber-500', border: 'border-amber-400/40' },
    { id: 'protein', name: 'Protein', emoji: '🍗', color: 'bg-purple-600 hover:bg-purple-500', border: 'border-purple-400/40' },
    { id: 'dairy', name: 'Dairy & Alt', emoji: '🥛', color: 'bg-sky-600 hover:bg-sky-500', border: 'border-sky-400/40' },
  ];

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-amber-400">
            <Zap className="w-3.5 h-3.5" />
            <span>Speed Arcade</span>
          </div>
          <h2 className="text-xl font-black font-display text-white">Plate Blitz: 60s Food Sort</h2>
        </div>

        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-slate-400">Personal Best</div>
          <div className="text-base font-black font-mono text-amber-300">
            {state.stats.blitzHighScore} pts
          </div>
        </div>
      </div>

      {!isPlaying && !isGameOver && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-emerald-500/30 text-center space-y-4">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-4xl shadow-xl shadow-amber-500/20">
            ⚡
          </div>

          <h3 className="text-xl font-bold font-display text-white">Ready for the 60s Challenge?</h3>
          <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
            Foods will appear on screen. Tap their correct food group out of the 5 main groups as fast as you can. Chain combos for massive multipliers!
          </p>

          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-slate-400 flex items-center justify-center gap-4">
            <div>⏱️ <strong>60 Seconds</strong></div>
            <div>🔥 <strong>Up to 5x Combos</strong></div>
            <div>🏆 <strong>500+ Unlocks Badge</strong></div>
          </div>

          <button
            onClick={startGame}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-white font-black text-base shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-white" />
            <span>Start Plate Blitz!</span>
          </button>
        </div>
      )}

      {isPlaying && (
        <div className="space-y-3">
          {/* Blitz HUD */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs font-mono font-bold">
            <div className="flex items-center gap-1.5 text-slate-200">
              <span className="text-slate-400 font-sans">Score:</span>
              <span className="text-emerald-400 text-base">{score}</span>
            </div>

            <div
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl border transition ${
                combo > 1 ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>{combo}x Combo</span>
            </div>

            <div
              className={`flex items-center gap-1 text-base ${
                timeLeft <= 10 ? 'text-rose-400 animate-pulse font-black' : 'text-slate-200'
              }`}
            >
              <span>{timeLeft}s</span>
            </div>
          </div>

          {/* Active Food Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-slate-800/90 to-slate-900 border-2 border-slate-700/80 shadow-2xl text-center space-y-2 relative overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="text-6xl animate-bounce leading-tight">{currentFood.emoji}</div>
            <h3 className="text-xl font-black font-display text-white">{currentFood.name}</h3>
            <p className="text-[11px] text-slate-400 italic">Serving: {currentFood.servingSize}</p>

            {/* Quick Feedback Toast */}
            {feedback && (
              <div
                className={`text-[11px] font-bold py-1 px-3 rounded-full mx-auto inline-block border ${
                  feedback.isCorrect
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                }`}
              >
                {feedback.text}
              </div>
            )}
          </div>

          {/* 5 Food Group Target Buttons */}
          <div className="space-y-2">
            <div className="text-center text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Tap the Correct Food Group:
            </div>

            <div className="grid grid-cols-2 gap-2">
              {groupButtons.slice(0, 4).map((btn) => (
                <button
                  key={btn.id}
                  onClick={() => handleGroupTap(btn.id)}
                  className={`py-3.5 px-3 rounded-2xl ${btn.color} text-white font-bold text-xs sm:text-sm shadow-md transition active:scale-95 flex items-center justify-center gap-2 border ${btn.border} cursor-pointer`}
                >
                  <span className="text-xl">{btn.emoji}</span>
                  <span>{btn.name}</span>
                </button>
              ))}
            </div>

            {/* Dairy Full Width */}
            <button
              onClick={() => handleGroupTap('dairy')}
              className={`w-full py-3.5 px-3 rounded-2xl ${groupButtons[4].color} text-white font-bold text-xs sm:text-sm shadow-md transition active:scale-95 flex items-center justify-center gap-2 border ${groupButtons[4].border} cursor-pointer`}
            >
              <span className="text-xl">{groupButtons[4].emoji}</span>
              <span>{groupButtons[4].name} (Calcium Bank)</span>
            </button>
          </div>
        </div>
      )}

      {isGameOver && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-amber-500/40 text-center space-y-4 animate-in zoom-in-95 duration-200">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-4xl shadow-xl shadow-amber-500/20">
            🏆
          </div>

          <h3 className="text-2xl font-black font-display text-white">Time's Up!</h3>
          <p className="text-xs text-slate-300">Fantastic blitz sorting round!</p>

          <div className="grid grid-cols-3 gap-2 py-2">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Final Score</div>
              <div className="text-xl font-black text-amber-300 font-mono">{score}</div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Correct</div>
              <div className="text-xl font-black text-emerald-400 font-mono">{correctCount}</div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Rewards</div>
              <div className="text-sm font-black text-purple-300 mt-1">
                +{Math.max(10, Math.floor(score / 15))} 💎
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={startGame}
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>
            <button
              onClick={() => {
                sound.playTap();
                onBackToMap();
              }}
              className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition cursor-pointer"
            >
              Quest Map
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
