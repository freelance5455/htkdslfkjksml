import React, { useState } from 'react';
import { ChefHat, CheckCircle2, AlertCircle, Plus, Trash2, Award, Sparkles, RefreshCw } from 'lucide-react';
import { FoodItem, FoodGroupId } from '../../types/game';
import { FOOD_ITEMS } from '../../data/foods';
import { FOOD_GROUPS } from '../../data/foodGroups';
import { MEAL_SCENARIOS, MealScenario } from '../../data/rewards';
import { useGame } from '../../context/GameContext';
import { sound } from '../../utils/sound';

export const FoodLabScreen: React.FC = () => {
  const { addCoins, addXp, unlockBadge } = useGame();
  const [selectedScenario, setSelectedScenario] = useState<MealScenario>(MEAL_SCENARIOS[0]);
  const [plateFoods, setPlateFoods] = useState<FoodItem[]>([]);
  const [activeTabGroup, setActiveTabGroup] = useState<FoodGroupId>('vegetables');
  const [evaluation, setEvaluation] = useState<{ grade: string; text: string; balanced: boolean } | null>(null);

  const availableFoods = FOOD_ITEMS.filter((f) => f.groupId === activeTabGroup);

  const handleAddFood = (food: FoodItem) => {
    if (plateFoods.length >= 6) {
      sound.playWrong();
      return;
    }
    sound.playTap();
    setPlateFoods((prev) => [...prev, food]);
    setEvaluation(null);
  };

  const handleRemoveFood = (index: number) => {
    sound.playTap();
    setPlateFoods((prev) => prev.filter((_, i) => i !== index));
    setEvaluation(null);
  };

  const handleClearPlate = () => {
    sound.playTap();
    setPlateFoods([]);
    setEvaluation(null);
  };

  // Check which groups are covered on the plate
  const coveredGroups = new Set(plateFoods.map((f) => f.groupId));
  const hasVeggies = coveredGroups.has('vegetables');
  const hasFruits = coveredGroups.has('fruits');
  const hasGrains = coveredGroups.has('grains');
  const hasProtein = coveredGroups.has('protein');
  const hasDairy = coveredGroups.has('dairy');

  const evaluatePlate = () => {
    if (plateFoods.length === 0) return;
    sound.playCorrect();

    const groupCount = coveredGroups.size;
    let grade = 'B';
    let text = '';
    let balanced = false;

    if (groupCount >= 4) {
      grade = groupCount === 5 ? 'A+' : 'A';
      balanced = true;
      text =
        groupCount === 5
          ? 'Perfection! You covered all 5 food groups: sustained whole grains, lean protein for muscle, antioxidants from fruits, minerals from veggies, and calcium for peak bone mass!'
          : 'Outstanding balance! You hit 4 of the 5 main food groups, giving your body diverse macro and micronutrients.';

      addCoins(40);
      addXp(75);
      unlockBadge('plate_architect');
    } else if (groupCount >= 3) {
      grade = 'B+';
      text = 'Solid meal! To reach champion tier, try adding a serving of leafy vegetables or a calcium-fortified drink.';
      addCoins(20);
      addXp(30);
    } else {
      grade = 'C';
      text = 'A bit one-sided. Teen bodies need variety from multiple food groups to prevent energy crashes and nutrient gaps.';
      addCoins(10);
      addXp(15);
    }

    setEvaluation({ grade, text, balanced });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-400">
            <ChefHat className="w-3.5 h-3.5" />
            <span>Interactive Nutritionist</span>
          </div>
          <h2 className="text-xl font-black font-display text-white">Teen Food Lab & Plate Builder</h2>
        </div>
        <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-xl shrink-0">
          🍽️
        </div>
      </div>

      {/* Scenario Selector */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
          Select Teen Challenge Scenario:
        </label>
        <div className="grid grid-cols-2 gap-2">
          {MEAL_SCENARIOS.map((scenario) => {
            const isSelected = selectedScenario.id === scenario.id;
            return (
              <button
                key={scenario.id}
                onClick={() => {
                  sound.playTap();
                  setSelectedScenario(scenario);
                  setEvaluation(null);
                }}
                className={`p-2.5 rounded-xl text-left border transition text-xs cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-200 font-bold'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold line-clamp-1">{scenario.title}</div>
                <div className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{scenario.subtitle}</div>
              </button>
            );
          })}
        </div>
        <p className="text-[11px] text-slate-300 pt-1 leading-relaxed italic">
          "{selectedScenario.description}"
        </p>
      </div>

      {/* Visual Divided Plate */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl text-center space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">Your Current Plate ({plateFoods.length}/6 foods)</span>
          {plateFoods.length > 0 && (
            <button
              onClick={handleClearPlate}
              className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-semibold cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              Reset Plate
            </button>
          )}
        </div>

        {/* 5-Group Plate Diagram */}
        <div className="relative mx-auto w-52 h-52 sm:w-60 sm:h-60 rounded-full border-4 border-slate-700 bg-slate-950 p-3 shadow-inner flex items-center justify-center">
          {/* Plate Grid Sectors */}
          <div className="w-full h-full rounded-full grid grid-cols-2 grid-rows-2 gap-1 overflow-hidden p-1 border border-slate-800">
            {/* Top-Left: Vegetables */}
            <div
              className={`rounded-tl-full flex flex-col items-center justify-center p-2 transition ${
                hasVeggies ? 'bg-emerald-500/30 text-emerald-300' : 'bg-slate-900/60 text-slate-600'
              }`}
            >
              <span className="text-lg">🥦</span>
              <span className="text-[9px] font-bold">Veggies</span>
            </div>

            {/* Top-Right: Fruits */}
            <div
              className={`rounded-tr-full flex flex-col items-center justify-center p-2 transition ${
                hasFruits ? 'bg-rose-500/30 text-rose-300' : 'bg-slate-900/60 text-slate-600'
              }`}
            >
              <span className="text-lg">🍎</span>
              <span className="text-[9px] font-bold">Fruits</span>
            </div>

            {/* Bottom-Left: Protein */}
            <div
              className={`rounded-bl-full flex flex-col items-center justify-center p-2 transition ${
                hasProtein ? 'bg-purple-500/30 text-purple-300' : 'bg-slate-900/60 text-slate-600'
              }`}
            >
              <span className="text-lg">🍗</span>
              <span className="text-[9px] font-bold">Protein</span>
            </div>

            {/* Bottom-Right: Grains */}
            <div
              className={`rounded-br-full flex flex-col items-center justify-center p-2 transition ${
                hasGrains ? 'bg-amber-500/30 text-amber-300' : 'bg-slate-900/60 text-slate-600'
              }`}
            >
              <span className="text-lg">🌾</span>
              <span className="text-[9px] font-bold">Grains</span>
            </div>
          </div>

          {/* Floating Dairy Cup Badge */}
          <div
            className={`absolute -top-2 -right-2 w-14 h-14 rounded-2xl border-2 shadow-lg flex flex-col items-center justify-center transition ${
              hasDairy
                ? 'bg-sky-600 text-white border-white'
                : 'bg-slate-900 text-slate-600 border-slate-700'
            }`}
          >
            <span className="text-lg">🥛</span>
            <span className="text-[8px] font-bold">Dairy</span>
          </div>
        </div>

        {/* Selected Foods Pill List */}
        <div className="min-h-12 flex flex-wrap gap-1.5 items-center justify-center">
          {plateFoods.length === 0 ? (
            <span className="text-xs text-slate-500 italic">Plate is empty. Pick foods below!</span>
          ) : (
            plateFoods.map((food, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <span>{food.emoji}</span>
                <span>{food.name}</span>
                <button
                  onClick={() => handleRemoveFood(idx)}
                  className="text-slate-400 hover:text-rose-400 cursor-pointer ml-0.5"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </span>
            ))
          )}
        </div>

        {/* Evaluate Button */}
        <button
          onClick={evaluatePlate}
          disabled={plateFoods.length === 0}
          className={`w-full py-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-md ${
            plateFoods.length > 0
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Evaluate My Teen Plate & Get Grade</span>
        </button>

        {/* Nutritionist Evaluation Card */}
        {evaluation && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 text-left space-y-2 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Nutritionist Assessment
              </span>
              <span className="text-xl font-black font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-lg border border-emerald-500/30">
                Grade: {evaluation.grade}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{evaluation.text}</p>
          </div>
        )}
      </div>

      {/* Food Picker by 5 Groups */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="text-xs font-bold text-slate-300">Choose Foods to Add:</div>

        {/* Food Group Category Tabs */}
        <div className="grid grid-cols-5 gap-1 text-[10px] font-bold">
          {(['vegetables', 'fruits', 'grains', 'protein', 'dairy'] as FoodGroupId[]).map((grp) => {
            const isTabActive = activeTabGroup === grp;
            const meta = FOOD_GROUPS[grp];
            return (
              <button
                key={grp}
                onClick={() => {
                  sound.playTap();
                  setActiveTabGroup(grp);
                }}
                className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-0.5 transition cursor-pointer border ${
                  isTabActive
                    ? 'bg-slate-750 text-white border-slate-500 shadow-sm'
                    : 'bg-slate-800/60 text-slate-400 border-transparent hover:bg-slate-800'
                }`}
              >
                <span className="text-sm">{meta.emoji}</span>
                <span className="truncate w-full text-center">{meta.shortName.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Foods Grid for Active Group */}
        <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
          {availableFoods.map((food) => (
            <button
              key={food.id}
              onClick={() => handleAddFood(food)}
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-left transition flex items-center justify-between text-xs cursor-pointer group"
            >
              <div className="flex items-center gap-2 truncate">
                <span className="text-lg">{food.emoji}</span>
                <span className="truncate text-slate-200 group-hover:text-white font-medium">{food.name}</span>
              </div>
              <Plus className="w-3.5 h-3.5 text-emerald-400 shrink-0 opacity-70 group-hover:opacity-100" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
