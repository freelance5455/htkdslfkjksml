import React, { useState } from 'react';
import {
  ChevronLeft,
  Flame,
  Lightbulb,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Sparkles,
  Trophy,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chess, Square } from 'chess.js';
import { sound } from '../../services/sound';
import { dailyChallengeService, VERIFIED_DAILY_CHALLENGES } from '../../services/dailyChallengeService';
import { achievementService } from '../../services/achievementService';
import { DailyChallenge } from '../../types/chess';

interface DailyChallengesScreenProps {
  onBack: () => void;
  onRewardClaimed?: (xp: number) => void;
}

export const DailyChallengesScreen: React.FC<DailyChallengesScreenProps> = ({
  onBack,
  onRewardClaimed,
}) => {
  const [selectedChallenge, setSelectedChallenge] = useState<DailyChallenge>(() =>
    dailyChallengeService.getTodayChallenge()
  );
  const [game, setGame] = useState(() => new Chess(selectedChallenge.fen));
  const [solutionMoveIdx, setSolutionMoveIdx] = useState(0);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [status, setStatus] = useState<'playing' | 'solved' | 'failed'>('playing');
  const [attemptsLeft, setAttemptsLeft] = useState(selectedChallenge.attemptsAllowed);
  const [showHint, setShowHint] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [startTime] = useState<number>(Date.now());

  const resetChallenge = (ch = selectedChallenge) => {
    setSelectedChallenge(ch);
    setGame(new Chess(ch.fen));
    setSolutionMoveIdx(0);
    setSelectedSquare(null);
    setStatus('playing');
    setAttemptsLeft(ch.attemptsAllowed);
    setShowHint(false);
    setShowExplanation(false);
  };

  const handleSquareClick = (square: Square) => {
    if (status !== 'playing') return;

    if (!selectedSquare) {
      const piece = game.get(square);
      if (piece && piece.color === game.turn()) {
        setSelectedSquare(square);
        sound.playClick();
      }
      return;
    }

    const expectedUci = selectedChallenge.solutionMoves[solutionMoveIdx];
    const attemptUci = `${selectedSquare}${square}`;

    try {
      const move = game.move({ from: selectedSquare, to: square, promotion: 'q' });
      if (move) {
        if (attemptUci === expectedUci) {
          // Correct move
          sound.playMove();
          const nextIdx = solutionMoveIdx + 1;
          setSolutionMoveIdx(nextIdx);
          setSelectedSquare(null);

          if (nextIdx >= selectedChallenge.solutionMoves.length) {
            // Completed puzzle!
            setStatus('solved');
            setShowExplanation(true);
            sound.playVictory();
            try {
              confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
            } catch {}

            const durationSecs = Math.round((Date.now() - startTime) / 1000);
            const { xpAwarded } = dailyChallengeService.recordCompletion(
              selectedChallenge.id,
              true,
              durationSecs
            );

            if (xpAwarded > 0) {
              achievementService.addXp(xpAwarded);
              achievementService.incrementProgress('puzzle_solver', 1);
              if (onRewardClaimed) onRewardClaimed(xpAwarded);
            }
          }
        } else {
          // Incorrect move!
          sound.playIllegal();
          game.undo();
          setSelectedSquare(null);
          const remaining = attemptsLeft - 1;
          setAttemptsLeft(remaining);

          if (remaining <= 0) {
            setStatus('failed');
            setShowExplanation(true);
            dailyChallengeService.recordCompletion(selectedChallenge.id, false, 0);
          }
        }
      } else {
        setSelectedSquare(null);
      }
    } catch {
      setSelectedSquare(null);
    }
  };

  const pieceSymbols: Record<string, string> = {
    p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚',
    P: '♙', N: '♘', B: '♗', R: '♖', Q: '♕', K: '♔',
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#070B13] via-[#0C1220] to-[#05080E] text-slate-100 flex flex-col font-['Outfit',sans-serif] select-none pb-24 overflow-y-auto">
      {/* Top Bar */}
      <div className="px-5 pt-8 pb-4 border-b border-slate-800/60 bg-[#090F1C]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#121B2F] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h1 className="text-lg font-bold tracking-wide text-slate-100">Daily Chess Missions</h1>
          <p className="text-[11px] text-amber-400 font-medium flex items-center justify-center gap-1">
            <Flame className="w-3.5 h-3.5 fill-current text-orange-400" /> 4-Day Daily Streak Active
          </p>
        </div>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full px-4 pt-4 flex-1 flex flex-col gap-4">
        {/* Mission Selection Pill Scroller */}
        <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
          {VERIFIED_DAILY_CHALLENGES.map((ch) => {
            const isSelected = ch.id === selectedChallenge.id;
            const completion = dailyChallengeService.getCompletion(ch.id);

            return (
              <button
                key={ch.id}
                onClick={() => {
                  sound.playClick();
                  resetChallenge(ch);
                }}
                className={`px-3.5 py-2 rounded-xl font-semibold flex items-center gap-1.5 whitespace-nowrap border transition-all ${
                  isSelected
                    ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-md'
                    : 'bg-[#101726] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>{ch.challengeDate}</span>
                {completion?.completed && <span className="text-emerald-400 font-bold">✓</span>}
              </button>
            );
          })}
        </div>

        {/* Current Challenge Header */}
        <div className="p-4 rounded-2xl bg-[#0F1728] border border-slate-800/80 flex flex-col gap-2">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/15 border border-amber-400/30 text-amber-300">
                {selectedChallenge.category.replace('_', ' ')} • {selectedChallenge.difficulty}
              </span>
              <h2 className="text-base font-bold text-slate-100 mt-1">{selectedChallenge.title}</h2>
            </div>
            <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-1 rounded-lg border border-amber-400/20 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 fill-current" /> +{selectedChallenge.rewardXp} XP
            </span>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/60">
            <span>
              Turn:{' '}
              <strong className="text-slate-200">
                {game.turn() === 'w' ? 'White to move' : 'Black to move'}
              </strong>
            </span>
            <span>
              Attempts Left: <strong className="text-amber-400">{attemptsLeft}</strong>
            </span>
          </div>
        </div>

        {/* 2D Interactive Board */}
        <div className="w-full aspect-square max-w-sm mx-auto bg-[#18120B] p-2.5 rounded-2xl border-4 border-[#2C1D11] shadow-2xl">
          <div className="grid grid-cols-8 grid-rows-8 w-full h-full border border-black/50">
            {Array.from({ length: 8 }).map((_, r) => {
              return Array.from({ length: 8 }).map((_, f) => {
                const sq = `${String.fromCharCode(97 + f)}${8 - r}` as Square;
                const piece = game.get(sq);
                const isLight = (r + f) % 2 === 0;
                const isSelected = selectedSquare === sq;
                const pChar = piece
                  ? piece.color === 'w'
                    ? piece.type.toUpperCase()
                    : piece.type
                  : '';

                return (
                  <button
                    key={sq}
                    onClick={() => handleSquareClick(sq)}
                    className={`relative flex items-center justify-center text-3xl font-bold transition-all ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300 z-10'
                        : isLight
                        ? 'bg-[#E5D2B3]'
                        : 'bg-[#8B5A2B]'
                    }`}
                  >
                    <span
                      className={
                        piece?.color === 'w'
                          ? 'text-amber-100 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]'
                          : 'text-slate-950'
                      }
                    >
                      {pieceSymbols[pChar] || ''}
                    </span>
                  </button>
                );
              });
            })}
          </div>
        </div>

        {/* Actions & Status */}
        <div className="p-3.5 rounded-2xl bg-[#0D1424] border border-slate-800 flex items-center justify-between">
          {status === 'playing' ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  sound.playClick();
                  setShowHint((prev) => !prev);
                }}
                className="py-1.5 px-3 rounded-xl bg-[#141E33] border border-slate-700 text-xs font-semibold text-amber-300 flex items-center gap-1.5 hover:bg-[#1A2640]"
              >
                <Lightbulb className="w-3.5 h-3.5" /> {showHint ? 'Hide Hint' : 'Get Hint'}
              </button>
            </div>
          ) : status === 'solved' ? (
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
              <CheckCircle2 className="w-4 h-4" /> Challenge Solved! (+{selectedChallenge.rewardXp} XP)
            </div>
          ) : (
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
              <AlertTriangle className="w-4 h-4" /> Out of attempts! Review solution below.
            </div>
          )}

          <button
            onClick={() => {
              sound.playClick();
              resetChallenge();
            }}
            className="py-1.5 px-3 rounded-xl bg-[#141E33] text-xs font-semibold flex items-center gap-1.5 text-slate-300 hover:text-white"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Restart
          </button>
        </div>

        {/* Hint Box */}
        {showHint && selectedChallenge.hints && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-400/30 text-xs text-amber-300 leading-relaxed animate-in fade-in">
            💡 <strong>Hint:</strong> {selectedChallenge.hints[0]}
          </div>
        )}

        {/* Solution Explanation Box */}
        {showExplanation && (
          <div className="p-4 rounded-2xl bg-[#0F1728] border border-slate-800 flex flex-col gap-2 animate-in fade-in">
            <h4 className="font-bold text-xs text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-amber-400" /> Tactical Breakdown & Solution
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedChallenge.explanation}</p>
            <div className="text-[11px] font-mono text-amber-400 pt-1">
              Sequence: {selectedChallenge.solutionMoves.join(' → ')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
