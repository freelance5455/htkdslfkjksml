import React from 'react';
import { X, Cpu, Gauge, Clock, Layers, Eye, Shield, Globe } from 'lucide-react';
import { EngineSettings } from '../../types/chess';
import { sound } from '../../services/sound';

interface EngineSettingsModalProps {
  settings: EngineSettings;
  onUpdate: (updated: EngineSettings) => void;
  onClose: () => void;
}

export const EngineSettingsModal: React.FC<EngineSettingsModalProps> = ({
  settings,
  onUpdate,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in select-none">
      <div className="bg-gradient-to-b from-[#141C2E] to-[#0D1322] border border-[#2B3C5E] rounded-3xl p-6 max-w-md w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E2B45] mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100">Stockfish Engine Settings</h3>
              <p className="text-[11px] text-sky-300/80">UCI Protocol • Background Worker</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-[#182338] hover:bg-[#202E4A] text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-4 text-xs">
          {/* Engine Info Badge */}
          <div className="p-3 rounded-2xl bg-[#101726] border border-[#1E2B45] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="font-bold text-slate-200">Active Engine</span>
                <p className="text-[11px] text-slate-400">{settings.engineVersion}</p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
              GPL v3
            </span>
          </div>

          {/* Search Depth */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-amber-400" /> Search Depth
              </span>
              <span className="font-mono font-bold text-amber-300 text-sm">{settings.searchDepth} plies</span>
            </div>
            <input
              type="range"
              min="6"
              max="20"
              value={settings.searchDepth}
              onChange={(e) => onUpdate({ ...settings, searchDepth: parseInt(e.target.value, 10) })}
              className="accent-amber-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>Fast (6)</span>
              <span>Balanced (12)</span>
              <span>Deep (20)</span>
            </div>
          </div>

          {/* Time Limit */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-sky-400" /> Calculation Time Limit
              </span>
              <span className="font-mono font-bold text-sky-300 text-sm">
                {(settings.timeLimitMs / 1000).toFixed(1)}s
              </span>
            </div>
            <input
              type="range"
              min="500"
              max="5000"
              step="250"
              value={settings.timeLimitMs}
              onChange={(e) => onUpdate({ ...settings, timeLimitMs: parseInt(e.target.value, 10) })}
              className="accent-sky-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>0.5s</span>
              <span>2.5s</span>
              <span>5.0s</span>
            </div>
          </div>

          {/* Multi-PV Candidate Lines */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-purple-400" /> Candidate Moves (Multi-PV)
              </span>
              <p className="text-[11px] text-slate-400">Lines evaluated in parallel</p>
            </div>
            <div className="flex gap-1">
              {[1, 2, 3, 5].map((pv) => (
                <button
                  key={pv}
                  onClick={() => {
                    sound.playClick();
                    onUpdate({ ...settings, multiPv: pv });
                  }}
                  className={`w-8 h-8 rounded-xl font-bold text-xs transition-colors ${
                    settings.multiPv === pv
                      ? 'bg-purple-600 text-white shadow-md'
                      : 'bg-[#182338] text-slate-400 hover:text-white'
                  }`}
                >
                  {pv}
                </button>
              ))}
            </div>
          </div>

          {/* Coach Language */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-emerald-400" /> Coach Language
              </span>
              <p className="text-[11px] text-slate-400">Natural language explanations</p>
            </div>
            <div className="flex gap-1.5">
              {[
                { code: 'en', label: 'English' },
                { code: 'mr', label: 'मराठी' },
                { code: 'hi', label: 'हिंदी' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    sound.playClick();
                    onUpdate({ ...settings, language: lang.code as any });
                  }}
                  className={`py-1.5 px-2.5 rounded-xl text-xs font-bold transition-all ${
                    settings.language === lang.code
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-[#182338] text-slate-400 hover:text-white'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* Visual Toggles */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-3">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300 font-semibold flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-slate-400" /> Evaluation Bar
              </span>
              <input
                type="checkbox"
                checked={settings.showEvalBar}
                onChange={(e) => onUpdate({ ...settings, showEvalBar: e.target.checked })}
                className="w-4 h-4 rounded accent-sky-400 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300 font-semibold flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-slate-400" /> 3D Best Move Arrow
              </span>
              <input
                type="checkbox"
                checked={settings.showBestMoveArrow}
                onChange={(e) => onUpdate({ ...settings, showBestMoveArrow: e.target.checked })}
                className="w-4 h-4 rounded accent-sky-400 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300 font-semibold flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-slate-400" /> Auto Review Completed Games
              </span>
              <input
                type="checkbox"
                checked={settings.autoGameReview}
                onChange={(e) => onUpdate({ ...settings, autoGameReview: e.target.checked })}
                className="w-4 h-4 rounded accent-sky-400 cursor-pointer"
              />
            </label>
          </div>

          {/* GPL v3 Notice */}
          <div className="p-3 rounded-xl bg-[#0B0F19] text-[10px] text-slate-500 leading-relaxed border border-[#18243A]">
            Stockfish is free software released under the GNU General Public License v3 (GPLv3).
            Engine development by T. Romstad, M. Costalba, J. Kiiski, G. Linscott and the Stockfish community.
          </div>
        </div>

        {/* Done Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="mt-4 w-full py-3 rounded-2xl bg-gradient-to-r from-sky-400 to-sky-500 text-slate-950 font-bold text-xs shadow-lg active:scale-95 transition-all"
        >
          Save & Close
        </button>
      </div>
    </div>
  );
};
