"use client";

import { useState } from "react";
import { Button, Card, EmptyState, ErrorCard, Pill, Skeleton, Stat } from "@/components/ui";
import { useToast } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtCompact, fmtPct, fmtPrice, fmtTime } from "@/lib/format";
import type { Analysis } from "@/lib/signals";
import EvaluatorPanel from "@/components/screens/EvaluatorPanel";

type SignalsResponse = {
  ok?: boolean;
  analyses?: Analysis[];
  source?: string;
  degraded?: boolean;
  scannedAt?: number;
  error?: string | null;
  rules?: { minConfluence: number; adxMin: number; volumeRatioMin: number };
};

const dirTone = (d: string) => (d === "LONG" ? "green" : d === "SHORT" ? "red" : "slate") as "green" | "red" | "slate";

export default function SignalsScreen() {
  const { toast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [openSymbol, setOpenSymbol] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "actionable">("actionable");
  const { data, loading, error, refresh, lastUpdated } = useApi<SignalsResponse>("/api/signals", {
    intervalMs: 300000, // רענון רקע כל 5 דקות
  });

  const analyses = arr<Analysis>(data?.analyses);
  const shown = filter === "actionable" ? analyses.filter((a) => a?.direction !== "WAIT") : analyses;

  const handleManualScan = async () => {
    setScanning(true);
    try {
      const res = await fetch("/api/signals", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ force: true }),
      });
      const json = (await res.json()) as SignalsResponse & { message?: string };
      toast(json?.message ?? "הסריקה הושלמה בהצלחה", json?.ok ? "success" : "error");
      await refresh();
    } catch {
      toast("שגיאה בסריקה - נסה שוב", "error");
    } finally {
      setScanning(false);
    }
  };

  const executeDemo = async (a: Analysis) => {
    try {
      const notional = Math.max(50, (10000 * a.positionPct) / 100) * a.leverage;
      const res = await fetch("/api/paper/order", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "OPEN",
          symbol: a.symbol,
          side: a.direction,
          orderType: "MARKET",
          notional,
          leverage: a.leverage,
          stopLoss: a.stopLoss,
          takeProfit: a.takeProfit1,
          source: "SIGNAL",
        }),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "העסקה בוצעה בחשבון הדמו") : (json.error ?? "שגיאה בביצוע"), json.ok ? "success" : "error");
    } catch {
      toast("שגיאה בביצוע עסקת דמו", "error");
    }
  };

  if (loading && analyses.length === 0) {
    return (
      <Card title="אותות ועצות מסחר">
        <Skeleton rows={5} />
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card
        title="אותות AI ועצות מסחר"
        subtitle={`סריקה אחרונה: ${lastUpdated ? fmtTime(new Date(lastUpdated)) : "—"} · מקור: ${data?.source ?? "—"} · רענון אוטומטי כל 5 דקות`}
        action={
          <div className="flex items-center gap-2">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as "all" | "actionable")}
              className="rounded-xl border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-200"
            >
              <option value="actionable">אותות פעילים בלבד</option>
              <option value="all">כל המטבעות שנסרקו</option>
            </select>
            <Button onClick={handleManualScan} disabled={scanning}>
              {scanning ? (
                <span className="flex items-center gap-2">
                  <span className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  סורק...
                </span>
              ) : (
                "🔄 סריקה ידנית"
              )}
            </Button>
          </div>
        }
      >
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <Stat label="מטבעות שנסרקו" value={analyses.length} />
          <Stat label="אותות פעילים" value={analyses.filter((a) => a.direction !== "WAIT").length} tone="up" />
          <Stat
            label="ביטחון ממוצע"
            value={`${(analyses.reduce((s, a) => s + (a?.confidence ?? 0), 0) / Math.max(1, analyses.length)).toFixed(1)}%`}
          />
          <Stat
            label="סף קונפלואנס נוכחי"
            value={`${data?.rules?.minConfluence ?? 58}%`}
            tone="warn"
            hint={'מתעדכן אוטומטית על ידי סוכן הבקרה'}
          />
        </div>
      </Card>

      {error || (data && data.ok === false && analyses.length === 0) ? (
        <ErrorCard detail={error ?? data?.error ?? null} onRetry={() => void refresh()} />
      ) : null}

      {shown.length === 0 ? (
        <EmptyState text="אין כרגע אותות שעומדים בסף הביטחון. לחץ על 'סריקה ידנית' או המתן לרענון האוטומטי." />
      ) : (
        <div className="space-y-3">
          {shown.map((a) => {
            const open = openSymbol === a.symbol;
            return (
              <div key={a.symbol} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-100">{a.symbol}</span>
                    <span className="text-[11px] text-slate-400">{a.hebrewName}</span>
                    <Pill tone={dirTone(a.direction)}>{a.directionHe}</Pill>
                    <Pill tone={a.confidence >= 80 ? "green" : a.confidence >= 65 ? "amber" : "slate"}>
                      ביטחון {a.confidence.toFixed(0)}%
                    </Pill>
                  </div>
                  <div className="flex items-center gap-3 text-xs tabular-nums">
                    <span className="text-slate-200">{fmtPrice(a.price)}$</span>
                    <span className={a.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}>{fmtPct(a.change24h)}</span>
                    <span className="text-slate-500">מחזור {fmtCompact(a.volume24h)}$</span>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-2 text-center md:grid-cols-6">
                  <Stat label="כניסה" value={fmtPrice(a.entry)} />
                  <Stat label="סטופ לוס" value={fmtPrice(a.stopLoss)} tone="down" />
                  <Stat label="יעד 1" value={fmtPrice(a.takeProfit1)} tone="up" />
                  <Stat label="יעד 2" value={fmtPrice(a.takeProfit2)} tone="up" />
                  <Stat label="מינוף מומלץ" value={`${a.leverage}x`} tone="warn" hint={`ATR ${a.atrPct}%`} />
                  <Stat
                    label="בכמה לסחור"
                    value={`${a.positionPct}%`}
                    hint={`קלי ${(a.kellyFraction * 100).toFixed(1)}%`}
                  />
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <Button variant="ghost" onClick={() => setOpenSymbol(open ? null : a.symbol)}>
                    {open ? "סגור ניתוח עומק" : "🔎 ניתוח עומק"}
                  </Button>
                  {a.direction !== "WAIT" && (
                    <Button variant="success" onClick={() => void executeDemo(a)}>
                      ⚡ בצע בעסקת דמו
                    </Button>
                  )}
                  <span className="text-[10px] text-slate-500">
                    יחס סיכון/סיכוי 1:{a.riskReward} · מקור נתונים: {a.source}
                  </span>
                </div>

                {open && (
                  <div className="mt-3 space-y-3 border-t border-slate-800 pt-3">
                    <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                      <Stat label="RSI (14)" value={a.indicators.rsi.toFixed(1)} tone={a.indicators.rsi > 70 ? "down" : a.indicators.rsi < 30 ? "up" : "default"} />
                      <Stat label="MACD היסט'" value={a.indicators.macdHist.toFixed(4)} tone={a.indicators.macdHist >= 0 ? "up" : "down"} />
                      <Stat label="ADX" value={a.indicators.adx.toFixed(1)} tone={a.indicators.adx >= 25 ? "up" : "warn"} />
                      <Stat label="ATR (14)" value={fmtPrice(a.indicators.atr)} />
                      <Stat label="יחס נפח" value={`${a.indicators.volumeRatio.toFixed(2)}x`} tone={a.indicators.volumeRatio >= 1.2 ? "up" : "warn"} />
                      <Stat label="EMA 20" value={fmtPrice(a.indicators.ema20)} />
                      <Stat label="EMA 50" value={fmtPrice(a.indicators.ema50)} />
                      <Stat label="EMA 200" value={fmtPrice(a.indicators.ema200)} />
                      <Stat label="POC (פרופיל נפח)" value={fmtPrice(a.indicators.poc)} />
                      <Stat
                        label="דיברגנס"
                        value={a.indicators.divergence === "bullish" ? "חיובי" : a.indicators.divergence === "bearish" ? "שלילי" : "אין"}
                        tone={a.indicators.divergence === "bullish" ? "up" : a.indicators.divergence === "bearish" ? "down" : "default"}
                      />
                    </div>
                    <div>
                      <h4 className="mb-1 text-xs font-bold text-emerald-300">נימוקי הקונפלואנס</h4>
                      <ul className="space-y-1 text-[11px] text-slate-300">
                        {arr<string>(a.reasons).map((r, i) => (
                          <li key={i}>✔️ {r}</li>
                        ))}
                        {arr<string>(a.reasons).length === 0 && <li className="text-slate-500">אין נימוקים חזקים</li>}
                      </ul>
                    </div>
                    {arr<string>(a.warnings).length > 0 && (
                      <div>
                        <h4 className="mb-1 text-xs font-bold text-amber-300">אזהרות סיכון</h4>
                        <ul className="space-y-1 text-[11px] text-amber-200/80">
                          {arr<string>(a.warnings).map((w, i) => (
                            <li key={i}>⚠️ {w}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <EvaluatorPanel />
    </div>
  );
}
