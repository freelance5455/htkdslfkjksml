"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { CATEGORY_ICON, Icon } from "@/components/ui/Icon";
import {
  Btn,
  Card,
  Chip,
  EmptyState,
  IconBtn,
  Progress,
  Screen,
  SectionTitle,
} from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import { dayLabel, googleCalendarUrl, monthLabel, relativeDay } from "@/lib/calendar";
import type { BillView, DataPayload } from "@/lib/types";

type Filter = "all" | "due" | "partial" | "paid" | "overdue";

const TEMPLATES: { name: string; category: string; amount: number; dueDay: number }[] = [
  { name: "Electricity", category: "Electricity", amount: 80, dueDay: 12 },
  { name: "Water", category: "Water", amount: 30, dueDay: 5 },
  { name: "Fuel", category: "Fuel", amount: 120, dueDay: 20 },
  { name: "Internet", category: "Internet", amount: 45, dueDay: 15 },
  { name: "Rent", category: "Rent", amount: 800, dueDay: 1 },
  { name: "Phone", category: "Phone", amount: 18, dueDay: 8 },
];

const STATUS_TONE: Record<string, "earn" | "spend" | "bill" | "neutral"> = {
  paid: "earn",
  partial: "bill",
  due: "spend",
  overdue: "spend",
  upcoming: "neutral",
};

export function BillsScreen() {
  const { data, setTab } = useApp();
  if (!data) return <div className="h-full" />;
  return <BillsBody data={data} onBack={() => setTab("home")} />;
}

function BillsBody({ data, onBack }: { data: DataPayload; onBack: () => void }) {
  const { money, openBillEditor, openPay, deletePayment, askConfirm } = useApp();
  const [filter, setFilter] = useState<Filter>("all");
  const [expanded, setExpanded] = useState<number | null>(null);

  const bills = data.bills;
  const summary = useMemo(() => {
    const due = bills.reduce((s, b) => s + b.current.due, 0);
    const paid = bills.reduce((s, b) => s + b.current.paid, 0);
    const remaining = bills.reduce((s, b) => s + b.current.remaining, 0);
    const carried = bills.reduce((s, b) => s + b.current.carry, 0);
    return { due, paid, remaining, carried };
  }, [bills]);

  const visible = bills.filter((b) => {
    if (filter === "all") return true;
    if (filter === "due") return b.current.status === "due" || b.current.status === "upcoming";
    if (filter === "partial") return b.current.status === "partial";
    if (filter === "paid") return b.current.status === "paid";
    return b.current.status === "overdue" || b.overdue;
  });

  const overdueTotal = bills
    .filter((b) => b.overdue)
    .reduce((s, b) => s + b.periods.filter((p) => p.status === "overdue" || p.status === "partial").reduce((x, p) => x + p.remaining, 0), 0);

  return (
    <Screen
      title="Bills"
      subtitle={`${bills.length} recurring · auto rollover`}
      onBack={onBack}
      right={<IconBtn name="plus" label="Add bill" onClick={() => openBillEditor()} />}
    >
      <div className="space-y-4 px-4 pb-8 pt-4">
        <Card className="overflow-hidden">
          <div
            className="px-4 pb-4 pt-4"
            style={{
              background:
                "radial-gradient(120% 140% at 100% 0%, color-mix(in oklab, var(--c-bill) 16%, transparent), transparent 60%)",
            }}
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink3">
              {monthLabel(data.stats.months[data.stats.months.length - 1]!.month)} · outstanding
            </p>
            <div className="mt-1 flex items-end gap-2">
              <p
                className="tnum font-display text-[36px] font-extrabold leading-none tracking-[-0.04em]"
                style={{ color: summary.remaining > 0 ? "var(--c-bill)" : "var(--c-earn)" }}
              >
                {money(summary.remaining)}
              </p>
              <p className="pb-1 text-[12px] text-ink2">of {money(summary.due)} due</p>
            </div>
            <div className="mt-3">
              <Progress
                value={summary.due > 0 ? (summary.paid / summary.due) * 100 : 0}
                tone={summary.remaining === 0 ? "earn" : "bill"}
              />
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <Chip tone="earn" icon="check">
                {money(summary.paid)} paid
              </Chip>
              {summary.carried > 0 ? (
                <Chip tone="bill" icon="refresh">
                  {money(summary.carried)} carried in
                </Chip>
              ) : null}
              {overdueTotal > 0 ? (
                <Chip tone="spend" icon="alert">
                  {money(overdueTotal)} overdue
                </Chip>
              ) : null}
            </div>
          </div>
        </Card>

        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
          {(
            [
              ["all", "All"],
              ["due", "Due"],
              ["partial", "Part-paid"],
              ["paid", "Paid"],
              ["overdue", "Overdue"],
            ] as [Filter, string][]
          ).map(([key, label]) => (
            <Chip key={key} tone="neutral" active={filter === key} onClick={() => setFilter(key)}>
              {label}
              <span className="ml-1 opacity-60">
                {key === "all"
                  ? bills.length
                  : bills.filter((b) =>
                      key === "due"
                        ? b.current.status === "due" || b.current.status === "upcoming"
                        : key === "partial"
                          ? b.current.status === "partial"
                          : key === "paid"
                            ? b.current.status === "paid"
                            : b.current.status === "overdue" || b.overdue,
                    ).length}
              </span>
            </Chip>
          ))}
        </div>

        {!bills.length ? (
          <EmptyState
            icon="bolt"
            title="No bill trackers yet"
            body="Add electricity, water, fuel or any custom bill. Part-payments automatically roll the remainder into next month."
            action={
              <div className="w-full">
                <Btn variant="brand" full icon="plus" onClick={() => openBillEditor()}>
                  Create a bill tracker
                </Btn>
                <p className="mt-4 mb-2 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink3">
                  or start from a template
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {TEMPLATES.map((t) => (
                    <Chip
                      key={t.name}
                      tone="bill"
                      icon={CATEGORY_ICON[t.category] ?? "bolt"}
                      onClick={() => openBillEditor(null, t)}
                    >
                      {t.name}
                    </Chip>
                  ))}
                </div>
              </div>
            }
          />
        ) : null}

        {bills.length && !visible.length ? (
          <EmptyState
            icon="check"
            title="Nothing in this view"
            body="No bills match this filter right now — that is usually good news."
          />
        ) : null}

        <div className="space-y-3">
          <AnimatePresence initial={false}>
            {visible.map((b, i) => (
              <BillCard
                key={b.id}
                bill={b}
                index={i}
                expanded={expanded === b.id}
                onToggle={() => setExpanded(expanded === b.id ? null : b.id)}
                onPay={(period) => openPay(b, period)}
                onEdit={() => openBillEditor(b)}
                onDeletePayment={(paymentId, amount, period) =>
                  askConfirm({
                    title: "Remove payment?",
                    body: `${money(amount)} paid towards ${monthLabel(period)} will be deleted and the balance recomputed.`,
                    confirmLabel: "Remove",
                    tone: "danger",
                    onConfirm: () => void deletePayment(paymentId, b.id),
                  })
                }
              />
            ))}
          </AnimatePresence>
        </div>

        {bills.length ? (
          <Card className="flex items-center gap-3 p-4">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl border border-line bg-surface2 text-brandtext">
              <Icon name="info" size={17} />
            </span>
            <p className="text-[12px] leading-relaxed text-ink2">
              Rollover is on: any unpaid remainder is added to next month&apos;s due amount, and the
              month-by-month history keeps a running tally per bill.
            </p>
          </Card>
        ) : null}
      </div>
    </Screen>
  );
}

function BillCard({
  bill,
  index,
  expanded,
  onToggle,
  onPay,
  onEdit,
  onDeletePayment,
}: {
  bill: BillView;
  index: number;
  expanded: boolean;
  onToggle: () => void;
  onPay: (period?: string) => void;
  onEdit: () => void;
  onDeletePayment: (paymentId: number, amount: number, period: string) => void;
}) {
  const { money } = useApp();
  const pct = bill.current.due > 0 ? (bill.current.paid / bill.current.due) * 100 : 0;
  const history = bill.periods.slice(0, 8);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ delay: Math.min(index * 0.04, 0.24), type: "spring", stiffness: 300, damping: 28 }}
    >
      <Card className="overflow-hidden">
        <div className="flex items-start gap-3 p-3.5">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border"
            style={{
              color: bill.current.status === "paid" ? "var(--c-earn)" : "var(--c-bill)",
              borderColor: `color-mix(in oklab, ${
                bill.current.status === "paid" ? "var(--c-earn)" : "var(--c-bill)"
              } 32%, transparent)`,
              background: `color-mix(in oklab, ${
                bill.current.status === "paid" ? "var(--c-earn)" : "var(--c-bill)"
              } 12%, transparent)`,
            }}
          >
            <Icon name={CATEGORY_ICON[bill.category] ?? "bolt"} size={19} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="min-w-0 flex-1 truncate font-display text-[15.5px] font-extrabold tracking-[-0.02em]">
                {bill.name}
              </p>
              <Chip tone={STATUS_TONE[bill.current.status] ?? "neutral"}>{bill.current.status}</Chip>
            </div>
            <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
              {bill.category} · due {relativeDay(bill.current.dueDay)} · day {bill.dueDay}
            </p>
            <div className="mt-2 flex items-end justify-between gap-2">
              <p className="tnum font-display text-[19px] font-extrabold leading-none tracking-[-0.03em]">
                {money(bill.current.remaining)}
                <span className="ml-1.5 text-[11px] font-semibold text-ink3">
                  left of {money(bill.current.due)}
                </span>
              </p>
              <span className="tnum font-mono text-[10.5px] text-ink2">{Math.round(pct)}%</span>
            </div>
            <div className="mt-1.5">
              <Progress
                value={pct}
                tone={bill.current.status === "paid" ? "earn" : bill.current.status === "overdue" ? "spend" : "bill"}
              />
            </div>
            {bill.current.carry > 0 ? (
              <div className="stripe mt-2 flex items-center gap-1.5 rounded-lg border border-bill/35 px-2 py-1">
                <Icon name="refresh" size={12} className="text-bill" />
                <span className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-bill">
                  {money(bill.current.carry)} rolled over from earlier
                </span>
              </div>
            ) : null}
          </div>
        </div>

        <div className="flex items-center gap-2 border-t border-line px-3 py-2.5">
          <Btn size="sm" variant={bill.current.remaining > 0 ? "brand" : "soft"} icon="wallet" onClick={() => onPay()}>
            {bill.current.remaining > 0 ? `Pay ${money(bill.current.remaining)}` : "Paid up"}
          </Btn>
          <a
            href={googleCalendarUrl({
              title: `Pay ${bill.name} — ${money(bill.current.due)}`,
              day: bill.current.dueDay,
              details: `Keep Tracked bill reminder · remaining ${money(bill.current.remaining)}`,
            })}
            target="_blank"
            rel="noopener noreferrer"
            className="press grid h-9 w-9 place-items-center rounded-xl border border-line bg-surface2 text-ink2"
            aria-label="Add reminder to Google Calendar"
          >
            <Icon name="google" size={15} />
          </a>
          <IconBtn name="edit" label="Edit bill" size={36} onClick={onEdit} />
          <button
            onClick={onToggle}
            className="press ml-auto flex items-center gap-1 rounded-xl px-2 py-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-ink3"
            aria-expanded={expanded}
          >
            {expanded ? "hide" : "history"}
            <motion.span animate={{ rotate: expanded ? 180 : 0 }}>
              <Icon name="chevron" size={14} />
            </motion.span>
          </button>
        </div>

        <AnimatePresence initial={false}>
          {expanded ? (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 30 }}
              className="overflow-hidden border-t border-line"
            >
              <div className="space-y-3 p-3.5">
                <div>
                  <SectionTitle>month to month</SectionTitle>
                  <div className="space-y-1.5">
                    {history.map((p) => (
                      <div
                        key={p.period}
                        className="flex items-center gap-2 rounded-xl border border-line bg-surface2/60 px-2.5 py-2"
                      >
                        <span className="w-[74px] shrink-0 font-mono text-[10px] uppercase tracking-[0.1em] text-ink2">
                          {monthLabel(p.period, "short")}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block font-mono text-[10.5px] text-ink2">
                            due {money(p.due)}
                            {p.carry > 0 ? <span className="text-bill"> (+{money(p.carry)})</span> : null}
                            {" · paid "}
                            <span className="text-earn">{money(p.paid)}</span>
                          </span>
                          <span className="mt-1 block">
                            <Progress
                              value={p.due > 0 ? (p.paid / p.due) * 100 : 0}
                              height={4}
                              tone={p.status === "paid" ? "earn" : p.status === "overdue" ? "spend" : "bill"}
                            />
                          </span>
                        </span>
                        <Chip tone={STATUS_TONE[p.status] ?? "neutral"}>{p.status}</Chip>
                        {p.remaining > 0 ? (
                          <button
                            onClick={() => onPay(p.period)}
                            className="press shrink-0 rounded-lg border border-line px-2 py-1 font-mono text-[9.5px] uppercase tracking-[0.1em] text-brandtext"
                          >
                            pay
                          </button>
                        ) : null}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <SectionTitle>payments logged</SectionTitle>
                  {bill.payments.length ? (
                    <div className="divide-y divide-line rounded-xl border border-line">
                      {bill.payments.slice(0, 6).map((p) => (
                        <div key={p.id} className="flex items-center gap-2 px-3 py-2">
                          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-earn/12 text-earn">
                            <Icon name="check" size={13} />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block font-mono text-[11px]">
                              {money(p.amount)} · {monthLabel(p.period, "short")}
                            </span>
                            <span className="block font-mono text-[9.5px] uppercase tracking-[0.1em] text-ink3">
                              {new Date(p.paidAt).toLocaleDateString("en-US", {
                                month: "short",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                              {p.note ? ` · ${p.note}` : ""}
                            </span>
                          </span>
                          <button
                            onClick={() => onDeletePayment(p.id, p.amount, p.period)}
                            className="press text-ink3 hover:text-spend"
                            aria-label="Remove payment"
                          >
                            <Icon name="trash" size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="rounded-xl border border-dashed border-line px-3 py-3 text-center font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
                      no payments yet · due {dayLabel(bill.current.dueDay)}
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
}
