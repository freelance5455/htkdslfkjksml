import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { sound } from '../../services/sound';
import { antiCheatService } from '../../services/antiCheatService';
import { ReportCategory } from '../../types/chess';

interface FairPlayModalProps {
  reportedUserId: string;
  reportedUserName: string;
  gameId?: string;
  currentUserId: string;
  currentUserName: string;
  onClose: () => void;
}

export const FairPlayModal: React.FC<FairPlayModalProps> = ({
  reportedUserId,
  reportedUserName,
  gameId,
  currentUserId,
  currentUserName,
  onClose,
}) => {
  const [category, setCategory] = useState<ReportCategory>('suspected_engine');
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playClick();

    antiCheatService.submitReport({
      reporterId: currentUserId,
      reporterName: currentUserName,
      reportedId: reportedUserId,
      reportedName: reportedUserName,
      gameId,
      category,
      notes,
    });

    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0C1220] border border-amber-500/30 rounded-2xl w-full max-w-md p-5 flex flex-col gap-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-100">Submit Fair Play Report</h3>
                <p className="text-xs text-slate-400">
                  Player: <strong className="text-slate-200">{reportedUserName}</strong>
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Violation Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ReportCategory)}
                  className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                >
                  <option value="suspected_engine">Suspected External Chess Engine Assistance</option>
                  <option value="stalling">Intentional Move Stalling / Griefing</option>
                  <option value="abandonment">Disconnect Abandonment</option>
                  <option value="harassment">Unsportsmanlike Conduct / Chat</option>
                  <option value="other">Other Fair Play Violation</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">Incident Notes & Evidence</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Describe move timing, unusual accuracy, or suspicious behaviors..."
                  required
                  className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400 placeholder:text-slate-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>
                  All reports are audited by fair play algorithms and human grandmaster review. False reports are subject to review.
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 rounded-xl bg-[#151F33] text-slate-300 font-semibold hover:bg-[#1A2640]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white font-bold hover:bg-rose-400"
                >
                  Submit Report
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="py-6 flex flex-col items-center text-center gap-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400" />
            <h3 className="font-bold text-base text-slate-100">Report Received</h3>
            <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
              Thank you for keeping competitive chess clean and enjoyable. Our fair-play team will review the match telemetry.
            </p>
            <button
              onClick={onClose}
              className="mt-2 px-5 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
