import React, { useState } from 'react';
import {
  ShieldAlert,
  Users,
  AlertTriangle,
  X,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { antiCheatService } from '../../services/antiCheatService';
import { tournamentService } from '../../services/tournamentService';
import { FairPlayAnalysis, UserReport, ModerationAction } from '../../types/chess';

interface AdminDashboardModalProps {
  currentUserName: string;
  onClose: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  currentUserName,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'flags' | 'reports' | 'mod_actions' | 'tournaments'>('flags');
  const [flags, setFlags] = useState<FairPlayAnalysis[]>(() => antiCheatService.getFlags());
  const [reports, setReports] = useState<UserReport[]>(() => antiCheatService.getReports());
  const [actions, setActions] = useState<ModerationAction[]>(() =>
    antiCheatService.getModerationActions()
  );

  // New Moderation Action Form
  const [targetName, setTargetName] = useState('');
  const [actionType, setActionType] = useState<'warning' | 'temporary_ban' | 'rating_adjustment'>('warning');
  const [reason, setReason] = useState('');

  const reloadData = () => {
    setFlags(antiCheatService.getFlags());
    setReports(antiCheatService.getReports());
    setActions(antiCheatService.getModerationActions());
  };

  const handleApplyAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetName.trim() || !reason.trim()) return;

    sound.playClick();
    antiCheatService.applyModerationAction({
      targetUserId: `u-mod-${Date.now()}`,
      targetUserName: targetName,
      actionType,
      reason,
      expiresInDays: actionType === 'temporary_ban' ? 7 : undefined,
      createdBy: currentUserName,
    });

    setTargetName('');
    setReason('');
    reloadData();
    setActiveTab('mod_actions');
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <div className="bg-[#0A101C] border border-amber-500/40 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-[#0E1627] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-slate-100">
                Staff Moderation & Fair-Play Console
              </h2>
              <p className="text-[11px] text-amber-400 font-medium">Authoritative Review & Integrity</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-[#0C1220] text-xs font-semibold">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('flags');
            }}
            className={`flex-1 py-3 border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'flags'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Fair Play Flags ({flags.length})
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('reports');
            }}
            className={`flex-1 py-3 border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'reports'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" /> Reports ({reports.length})
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('mod_actions');
            }}
            className={`flex-1 py-3 border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'mod_actions'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Lock className="w-3.5 h-3.5" /> Moderation Log ({actions.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 flex-1 overflow-y-auto flex flex-col gap-3">
          {/* TAB 1: FAIR PLAY FLAGS */}
          {activeTab === 'flags' && (
            <div className="flex flex-col gap-2.5">
              {flags.map((flag) => (
                <div
                  key={flag.id}
                  className="p-3.5 rounded-xl bg-[#0F1728] border border-slate-800 flex flex-col gap-2 text-xs"
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-100">{flag.userName}</span>
                      <span className="text-[10px] text-slate-500 font-mono">Game: {flag.gameId}</span>
                    </div>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        flag.riskLevel === 'critical'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {flag.riskLevel} risk
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 bg-[#131E33] p-2 rounded-lg text-center font-mono">
                    <div>
                      <span className="text-[10px] text-slate-400 block">ACPL</span>
                      <strong className="text-amber-300">{flag.acpl} cp</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Engine Match</span>
                      <strong className="text-amber-300">{flag.engineSimilarity}%</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Timing StdDev</span>
                      <strong className="text-amber-300">{flag.moveTimeVariance}s</strong>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1 text-[11px] text-slate-400">
                    {flag.flagReasons.map((r, i) => (
                      <div key={i} className="flex items-center gap-1.5">
                        <span className="text-amber-400 font-bold">•</span>
                        <span>{r}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: USER REPORTS */}
          {activeTab === 'reports' && (
            <div className="flex flex-col gap-2.5">
              {reports.map((rep) => (
                <div
                  key={rep.id}
                  className="p-3.5 rounded-xl bg-[#0F1728] border border-slate-800 flex flex-col gap-2 text-xs"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400">
                        Category: {rep.category.replace('_', ' ')}
                      </span>
                      <h4 className="font-bold text-slate-100">
                        {rep.reporterName} reported {rep.reportedName}
                      </h4>
                    </div>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        rep.status === 'pending'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-emerald-500/20 text-emerald-300'
                      }`}
                    >
                      {rep.status}
                    </span>
                  </div>
                  <p className="text-slate-300 bg-[#131E33] p-2 rounded-lg leading-relaxed">
                    "{rep.notes}"
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: MODERATION ACTIONS & ISSUE ACTION */}
          {activeTab === 'mod_actions' && (
            <div className="flex flex-col gap-4">
              {/* Form to issue a new moderation action */}
              <form
                onSubmit={handleApplyAction}
                className="p-3.5 rounded-xl bg-[#0F1728] border border-slate-800 flex flex-col gap-2.5 text-xs"
              >
                <h4 className="font-bold text-slate-100">Issue Formal Moderation Action</h4>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Target Username"
                    value={targetName}
                    onChange={(e) => setTargetName(e.target.value)}
                    required
                    className="px-3 py-2 rounded-lg bg-[#141F33] border border-slate-700 text-slate-100"
                  />
                  <select
                    value={actionType}
                    onChange={(e) => setActionType(e.target.value as any)}
                    className="px-3 py-2 rounded-lg bg-[#141F33] border border-slate-700 text-slate-100"
                  >
                    <option value="warning">Official Policy Warning</option>
                    <option value="temporary_ban">7-Day Matchmaking Suspension</option>
                    <option value="rating_adjustment">Rating Rollback / Adjustment</option>
                  </select>
                </div>
                <textarea
                  placeholder="Official finding and justification..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  rows={2}
                  required
                  className="px-3 py-2 rounded-lg bg-[#141F33] border border-slate-700 text-slate-100"
                />
                <button
                  type="submit"
                  className="py-2 rounded-lg bg-amber-400 text-slate-950 font-bold hover:bg-amber-300 self-end px-4"
                >
                  Apply Action
                </button>
              </form>

              {/* Action History Log */}
              <div className="flex flex-col gap-2">
                {actions.map((act) => (
                  <div
                    key={act.id}
                    className="p-3 rounded-xl bg-[#111A2D] border border-slate-800 flex flex-col gap-1 text-xs"
                  >
                    <div className="flex justify-between items-center font-semibold">
                      <span className="text-amber-300 capitalize">{act.actionType.replace('_', ' ')}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Target: {act.targetUserName}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px]">{act.reason}</p>
                    <span className="text-[10px] text-slate-500 font-mono">
                      Issued by {act.createdBy} on {new Date(act.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
