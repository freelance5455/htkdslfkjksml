import React, { useState } from 'react';
import {
  ChevronLeft,
  Trophy,
  Flame,
  Globe,
  Search,
  Zap,
  Clock,
  Sparkles,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { leaderboardService } from '../../services/leaderboardService';
import {
  LeaderboardCategory,
  LeaderboardScope,
  LeaderboardTimeframe,
  LeaderboardEntry,
} from '../../types/chess';

interface LeaderboardScreenProps {
  userProfile: { id: string; name: string; avatar: string; rating: number; country?: string };
  onBack: () => void;
}

export const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({
  userProfile,
  onBack,
}) => {
  const [category, setCategory] = useState<LeaderboardCategory>('blitz');
  const [scope, setScope] = useState<LeaderboardScope>('global');
  const [timeframe, setTimeframe] = useState<LeaderboardTimeframe>('all_time');
  const [search, setSearch] = useState('');

  const entries: LeaderboardEntry[] = leaderboardService.getLeaderboard(
    category,
    timeframe,
    scope,
    userProfile
  );

  const filtered = entries.filter((e) =>
    e.username.toLowerCase().includes(search.toLowerCase())
  );

  const userEntry = entries.find((e) => e.isUser);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#070B13] via-[#0C1220] to-[#05080E] text-slate-100 flex flex-col font-['Outfit',sans-serif] select-none pb-24 overflow-y-auto">
      {/* Top Header */}
      <div className="px-5 pt-8 pb-4 border-b border-slate-800/60 bg-[#090F1C]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#121B2F] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h1 className="text-lg font-bold tracking-wide text-slate-100">Global Leaderboards</h1>
          <p className="text-[11px] text-amber-400 font-medium">FIDE & ELO Competitive Rankings</p>
        </div>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full px-4 pt-4 flex-1 flex flex-col gap-4">
        {/* User Rank Card */}
        {userEntry && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#17243E] to-[#0E1729] border border-amber-500/40 flex items-center justify-between shadow-xl shadow-amber-500/5">
            <div className="flex items-center gap-3">
              <div className="relative">
                <span className="text-3xl">{userEntry.avatar}</span>
                <span className="absolute -bottom-1 -right-1 text-[9px] font-bold px-1 rounded bg-amber-400 text-slate-950">
                  #{userEntry.rank}
                </span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-sm text-slate-100">{userEntry.username}</h3>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    YOU
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-mono">
                  Rating: <strong className="text-amber-300">{userEntry.rating}</strong> • Win Rate: {userEntry.winRate}%
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 justify-end">
                <Flame className="w-3.5 h-3.5 fill-current text-orange-400" /> {userEntry.streak} Streak
              </span>
              <span className="text-[11px] text-slate-400">{userEntry.wins}W / {userEntry.losses}L</span>
            </div>
          </div>
        )}

        {/* Category Selector Tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
          {(
            [
              { id: 'bullet', label: 'Bullet', icon: Zap },
              { id: 'blitz', label: 'Blitz', icon: Flame },
              { id: 'rapid', label: 'Rapid', icon: Clock },
              { id: 'overall', label: 'Overall', icon: Trophy },
              { id: 'puzzle', label: 'Tactics', icon: Sparkles },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            const isSelected = category === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  sound.playClick();
                  setCategory(item.id);
                }}
                className={`flex-1 py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-md'
                    : 'bg-[#101726] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Scope and Search Bar */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search grandmaster..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#101726] border border-slate-800 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex rounded-xl bg-[#101726] border border-slate-800 p-0.5 text-xs font-semibold">
            <button
              onClick={() => {
                sound.playClick();
                setScope('global');
              }}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1 ${
                scope === 'global' ? 'bg-amber-400/20 text-amber-300' : 'text-slate-400'
              }`}
            >
              <Globe className="w-3 h-3" /> Global
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setScope('country');
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                scope === 'country' ? 'bg-amber-400/20 text-amber-300' : 'text-slate-400'
              }`}
            >
              National
            </button>
          </div>
        </div>

        {/* Leaderboard Table */}
        <div className="rounded-2xl bg-[#0D1424] border border-slate-800 overflow-hidden flex flex-col">
          <div className="grid grid-cols-12 py-2.5 px-3 bg-[#111A2D] text-slate-400 text-[11px] font-bold uppercase border-b border-slate-800">
            <span className="col-span-2">Rank</span>
            <span className="col-span-6">Grandmaster</span>
            <span className="col-span-2 text-right">Rating</span>
            <span className="col-span-2 text-right">Win%</span>
          </div>

          <div className="divide-y divide-slate-800/60">
            {filtered.map((player) => {
              const medal =
                player.rank === 1 ? '🥇' : player.rank === 2 ? '🥈' : player.rank === 3 ? '🥉' : null;

              return (
                <div
                  key={player.userId}
                  className={`grid grid-cols-12 items-center py-3 px-3 text-xs transition-colors hover:bg-[#131E33] ${
                    player.isUser ? 'bg-amber-400/10 font-bold border-l-2 border-amber-400' : ''
                  }`}
                >
                  <span className="col-span-2 font-mono font-bold flex items-center gap-1">
                    {medal ? <span className="text-base">{medal}</span> : `#${player.rank}`}
                  </span>

                  <div className="col-span-6 flex items-center gap-2">
                    <span className="text-base">{player.avatar}</span>
                    <div className="truncate">
                      <div className="flex items-center gap-1">
                        {player.title && (
                          <span className="text-[9px] font-bold px-1 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                            {player.title}
                          </span>
                        )}
                        <span className="text-slate-100 truncate">{player.username}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {player.country} • {player.totalGames} games
                      </span>
                    </div>
                  </div>

                  <span className="col-span-2 text-right font-mono font-bold text-amber-300">
                    {category === 'bullet'
                      ? player.ratingBullet
                      : category === 'blitz'
                      ? player.ratingBlitz
                      : category === 'rapid'
                      ? player.ratingRapid
                      : category === 'puzzle'
                      ? player.ratingPuzzle
                      : player.rating}
                  </span>

                  <span className="col-span-2 text-right font-mono text-slate-400 text-[11px]">
                    {player.winRate}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
