import React, { useState } from 'react';
import { Lightbulb, BarChart3, ListOrdered, X, CheckCircle, TrendingUp } from 'lucide-react';
import { HintAnalysis } from '../../services/aiEngine';
import { MoveRecord } from '../../types/chess';
import { sound } from '../../services/sound';

interface AnalysisModalProps {
  hint: HintAnalysis | null;
  moves: MoveRecord[];
  turn: 'w' | 'b';
  onClose: () => void;
  onApplyHint?: () => void;
}

export const AnalysisModal: React.FC<AnalysisModalProps> = ({
  hint,
  moves,
  turn,
  onClose,
  onApplyHint,
}) => {
  const [activeTab, setActiveTab] = useState<'hint' | 'analysis' | 'moves'>('hint');

  // Format move pairs for notation
  const movePairs: { num: number; white: string; black?: string }[] = [];
  for (let i = 0; i < moves.length; i += 2) {
    movePairs.push({
      num: Math.floor(i / 2) + 1,
      white: moves[i]?.san || '',
      black: moves[i + 1]?.san,
    });
  }

  const whiteWinProb = hint ? hint.winProbability : 50;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 p-4 max-w-md mx-auto animate-in slide-in-from-bottom duration-300">
      <div className="bg-[#0E1524]/95 border border-[#233554] rounded-3xl p-5 shadow-2xl backdrop-blur-xl text-white flex flex-col gap-4">
        {/* Top Header with Close */}
        <div className="flex items-center justify-between pb-1 border-b border-[#1E2B45]">
          {/* Tabs: Hint vs Analysis vs Moves (matches Screen 8) */}
          <div className="flex items-center gap-1.5 p-1 bg-[#131E33] rounded-xl border border-[#1E2E4E]">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('hint');
              }}
              className={`py-1 px-3 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                activeTab === 'hint'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5" /> Hint
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('analysis');
              }}
              className={`py-1 px-3 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                activeTab === 'analysis'
                  ? 'bg-sky-500 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" /> Analysis
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('moves');
              }}
              className={`py-1 px-3 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                activeTab === 'moves'
                  ? 'bg-purple-500 text-white font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5" /> Moves
            </button>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-[#182338] text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab 1: Tactical Move Hint (matches Screen 8 from reference) */}
        {activeTab === 'hint' && (
          <div className="flex flex-col gap-3">
            {hint ? (
              <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-[#142036] border border-amber-400/40 shadow-inner">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 flex-shrink-0">
                  <Lightbulb className="w-6 h-6 fill-amber-400/30" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] uppercase tracking-wider text-amber-300/80 font-bold">
                      Recommended Move
                    </span>
                    <span className="text-xs font-mono font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-400/30">
                      Eval: {hint.evalText}
                    </span>
                  </div>
                  <h3 className="text-xl font-black text-amber-300 font-mono mt-0.5">
                    Best move: {hint.san}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {hint.explanation}
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-4">
                No legal moves or position ended.
              </p>
            )}

            {onApplyHint && hint && (
              <button
                onClick={() => {
                  sound.playClick();
                  onApplyHint();
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow-md active:scale-98 transition-all flex items-center justify-center gap-1.5"
              >
                <CheckCircle className="w-4 h-4" /> Play Best Move ({hint.san})
              </button>
            )}
          </div>
        )}

        {/* Tab 2: Position Evaluation & Win Probability */}
        {activeTab === 'analysis' && (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-sky-400" /> Win Probability:
              </span>
              <span className="font-mono font-bold text-sky-300">
                White {whiteWinProb}% • Black {100 - whiteWinProb}%
              </span>
            </div>

            {/* Visual Advantage Bar */}
            <div className="w-full h-3 bg-[#1A263D] rounded-full overflow-hidden flex border border-[#253655]">
              <div
                className="h-full bg-gradient-to-r from-amber-100 to-amber-400 transition-all duration-300"
                style={{ width: `${whiteWinProb}%` }}
              />
              <div
                className="h-full bg-slate-900 transition-all duration-300"
                style={{ width: `${100 - whiteWinProb}%` }}
              />
            </div>

            <div className="p-3 rounded-xl bg-[#142036] border border-[#223352] text-xs text-slate-300 flex flex-col gap-1.5">
              <div className="flex justify-between">
                <span>Centipawn Advantage:</span>
                <span className="font-mono font-bold text-amber-300">
                  {hint ? hint.evalText : '0.0'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Active Turn:</span>
                <span className="font-semibold text-slate-200">
                  {turn === 'w' ? 'White to move' : 'Black to move'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Evaluation Depth:</span>
                <span className="font-mono text-sky-300">Stockfish-equivalent 16 ply</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Move History List */}
        {activeTab === 'moves' && (
          <div className="max-h-48 overflow-y-auto flex flex-col gap-1 pr-1 font-mono text-xs">
            {movePairs.length === 0 ? (
              <p className="text-slate-500 text-center py-4">No moves played yet.</p>
            ) : (
              movePairs.map((pair) => (
                <div
                  key={pair.num}
                  className="grid grid-cols-3 py-1 px-2 rounded-lg bg-[#142036]/60 border border-[#1E2B45]/40 text-slate-300"
                >
                  <span className="text-slate-500">{pair.num}.</span>
                  <span className="font-bold text-amber-300">{pair.white}</span>
                  <span className="font-bold text-sky-300">{pair.black || ''}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
