import React, { useState } from 'react';
import { X, Layers, Play, ChevronRight, RotateCcw } from 'lucide-react';
import { Chess, Square } from 'chess.js';
import { CandidateLine } from '../../types/chess';
import { sound } from '../../services/sound';

interface CandidateMovesModalProps {
  initialFen: string;
  candidateLines: CandidateLine[];
  onClose: () => void;
  onExploreLine?: (moves: string[]) => void;
}

export const CandidateMovesModal: React.FC<CandidateMovesModalProps> = ({
  initialFen,
  candidateLines,
  onClose,
  onExploreLine,
}) => {
  const [activePreviewIndex, setActivePreviewIndex] = useState(0);
  const activeLine = candidateLines[activePreviewIndex] || candidateLines[0];

  // Variation simulation board
  const [variationGame, setVariationGame] = useState(() => {
    const g = new Chess(initialFen);
    if (activeLine && activeLine.pvMoves.length > 0) {
      for (const m of activeLine.pvMoves.slice(0, 3)) {
        try {
          g.move({ from: m.substring(0, 2), to: m.substring(2, 4), promotion: m[4] });
        } catch {
          break;
        }
      }
    }
    return g;
  });

  const handleSelectLine = (idx: number) => {
    setActivePreviewIndex(idx);
    const line = candidateLines[idx];
    const g = new Chess(initialFen);
    if (line) {
      for (const m of line.pvMoves.slice(0, 3)) {
        try {
          g.move({ from: m.substring(0, 2), to: m.substring(2, 4), promotion: m[4] });
        } catch {
          break;
        }
      }
    }
    setVariationGame(g);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in select-none">
      <div className="bg-gradient-to-b from-[#141C2E] to-[#0D1322] border border-[#2B3C5E] rounded-3xl p-6 max-w-lg w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E2B45] mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100">Candidate Move Explorer</h3>
              <p className="text-[11px] text-purple-300/80">Multi-PV Analysis • Top Alternative Lines</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-[#182338] hover:bg-[#202E4A] text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Candidate List & Interactive Preview */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-3">
          <div className="flex flex-col gap-2">
            {candidateLines.map((line, idx) => {
              const isSelected = idx === activePreviewIndex;
              const isPositive = line.whiteScoreCp >= 0;

              return (
                <div
                  key={line.multipv}
                  onClick={() => {
                    sound.playClick();
                    handleSelectLine(idx);
                  }}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#18233A] border-purple-500/60 shadow-lg'
                      : 'bg-[#101726]/80 border-[#1E2B45] hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-[#111A2C] border border-[#223352] flex items-center justify-center text-[11px] font-mono font-bold text-slate-400">
                        #{line.multipv}
                      </span>
                      <span className="font-mono font-bold text-sm text-amber-300">
                        {line.bestMoveSan || line.bestMove}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`py-1 px-2.5 rounded-lg text-xs font-mono font-bold ${
                          isPositive
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {line.evalPawns}
                      </span>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>

                  {/* Principal Variation preview */}
                  <div className="mt-2 text-[11px] text-slate-400 font-mono truncate">
                    PV: {line.pvSan.slice(0, 6).join(' ')}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mini Board Representation of selected continuation */}
          {activeLine && (
            <div className="p-3.5 rounded-2xl bg-[#0E1524] border border-[#1E2B45] flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300">Continuation Preview</span>
                <span className="text-[11px] text-purple-300">
                  Depth {activeLine.depth} plies
                </span>
              </div>

              {/* 8x8 Mini Grid */}
              <div className="w-48 h-48 mx-auto grid grid-cols-8 border border-[#253655] rounded-lg overflow-hidden shadow-md">
                {variationGame.board().map((row, r) =>
                  row.map((piece, c) => {
                    const isDark = (r + c) % 2 === 1;
                    return (
                      <div
                        key={`${r}-${c}`}
                        className={`w-6 h-6 flex items-center justify-center text-xs ${
                          isDark ? 'bg-[#182338]' : 'bg-[#293B5B]'
                        }`}
                      >
                        {piece ? (
                          <span className={piece.color === 'w' ? 'text-amber-200' : 'text-sky-300'}>
                            {piece.type === 'p' ? '♟' : piece.type === 'n' ? '♞' : piece.type === 'b' ? '♝' : piece.type === 'r' ? '♜' : piece.type === 'q' ? '♛' : '♚'}
                          </span>
                        ) : null}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="mt-4 flex gap-2">
          {onExploreLine && activeLine && (
            <button
              onClick={() => {
                sound.playClick();
                onExploreLine(activeLine.pvMoves);
                onClose();
              }}
              className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" /> Explore Line on 3D Board
            </button>
          )}
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="py-3 px-5 rounded-2xl bg-[#182338] hover:bg-[#202E4A] border border-[#2B3B59] text-white font-bold text-xs transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
