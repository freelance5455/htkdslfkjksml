import React, { useState } from 'react';
import { ChevronLeft, BookOpen, Compass, RotateCcw, Play, CheckCircle2 } from 'lucide-react';
import { Chess } from 'chess.js';
import { ChessScene } from '../3d/ChessScene';
import { OPENING_BOOK, identifyOpeningFromMoves } from '../../services/openingBook';
import { OpeningEntry, GameSettings } from '../../types/chess';
import { sound } from '../../services/sound';

interface OpeningExplorerScreenProps {
  settings: GameSettings;
  onBack: () => void;
}

export const OpeningExplorerScreen: React.FC<OpeningExplorerScreenProps> = ({
  settings,
  onBack,
}) => {
  const [selectedOpening, setSelectedOpening] = useState<OpeningEntry>(OPENING_BOOK[0]);
  const [boardGame, setBoardGame] = useState(() => new Chess(OPENING_BOOK[0].fen));
  const [playedMoves, setPlayedMoves] = useState<string[]>(OPENING_BOOK[0].moves);

  const handleSelectOpening = (entry: OpeningEntry) => {
    sound.playClick();
    setSelectedOpening(entry);
    setPlayedMoves(entry.moves);
    setBoardGame(new Chess(entry.fen));
  };

  const handlePlayContinuation = (uci: string) => {
    sound.playMove();
    const sim = new Chess(boardGame.fen());
    try {
      const from = uci.substring(0, 2);
      const to = uci.substring(2, 4);
      const promo = uci.length > 4 ? uci[4] : undefined;
      sim.move({ from, to, promotion: promo });
      setBoardGame(sim);
      const newMoves = [...playedMoves, uci];
      setPlayedMoves(newMoves);

      const recognized = identifyOpeningFromMoves(newMoves);
      if (recognized) {
        setSelectedOpening(recognized);
      }
    } catch {
      // ignore
    }
  };

  const handleReset = () => {
    sound.playClick();
    setBoardGame(new Chess(selectedOpening.fen));
    setPlayedMoves(selectedOpening.moves);
  };

  return (
    <div className="relative w-screen h-screen bg-[#070B13] text-white flex flex-col overflow-hidden select-none">
      {/* Header */}
      <div className="z-20 flex items-center justify-between px-5 pt-4 pb-2 bg-[#0A0F1D]/90 border-b border-[#1A263D] backdrop-blur-md">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-9 h-9 rounded-xl bg-[#141E33] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h2 className="text-base font-bold tracking-wide text-slate-100 flex items-center gap-1.5 justify-center">
            <BookOpen className="w-4 h-4 text-emerald-400" /> Opening Explorer
          </h2>
          <p className="text-[11px] text-slate-400">Master Theory & Verified Repertoire Statistics</p>
        </div>

        <button
          onClick={handleReset}
          className="w-9 h-9 rounded-xl bg-[#141E33] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
          title="Reset Opening Position"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* 3D Board */}
        <div className="relative flex-1 min-h-[300px] lg:min-h-0 bg-[#060910]">
          <ChessScene
            game={boardGame}
            boardStyle={settings.boardStyle}
            pieceStyle={settings.pieceStyle}
            playerPerspective="w"
            selectedSquare={null}
            legalMoves={[]}
            lastMove={null}
            hintMove={null}
            onSquareClick={() => {}}
            interactive={false}
          />

          <div className="absolute top-4 left-4 z-10">
            <span className="px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-[#0D1524]/90 border border-emerald-400/40 text-emerald-300 shadow-lg backdrop-blur-md">
              ECO {selectedOpening.eco} • {selectedOpening.name}
            </span>
          </div>
        </div>

        {/* Right Panel: Repertoire Selector & Master Continuations */}
        <div className="w-full lg:w-96 bg-[#0B111F] border-t lg:border-t-0 lg:border-l border-[#1A263D] flex flex-col p-4 overflow-y-auto gap-4">
          {/* Opening Selector Carousel */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Famous Openings
            </span>
            <div className="grid grid-cols-2 gap-2">
              {OPENING_BOOK.map((op) => (
                <button
                  key={op.eco}
                  onClick={() => handleSelectOpening(op)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    selectedOpening.eco === op.eco
                      ? 'bg-emerald-500/15 border-emerald-400 text-emerald-200 shadow-md font-bold'
                      : 'bg-[#121A2B] border-[#1E2B45] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="text-[10px] font-mono text-emerald-400">{op.eco}</div>
                  <div className="text-xs truncate font-semibold">{op.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Description & Principles */}
          <div className="p-3.5 rounded-2xl bg-[#121A2B] border border-[#1E2B45] flex flex-col gap-2">
            <h4 className="font-bold text-xs text-slate-200 flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-emerald-400" /> Strategic Concepts
            </h4>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {selectedOpening.description}
            </p>
            <ul className="flex flex-col gap-1.5 mt-1">
              {selectedOpening.strategicGoals.map((g, i) => (
                <li key={i} className="flex items-start gap-1.5 text-[11px] text-slate-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{g}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Master Continuations with Win Rates */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Master Continuations & Win Rates
            </span>
            <div className="flex flex-col gap-2">
              {selectedOpening.continuations.map((c) => (
                <div
                  key={c.san}
                  className="p-3 rounded-2xl bg-[#121A2B] border border-[#1E2B45] flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-amber-300 text-sm">{c.san}</span>
                      <span className="text-[11px] text-slate-400 ml-2">{c.name}</span>
                    </div>
                    <button
                      onClick={() => handlePlayContinuation(c.uci)}
                      className="py-1 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow-sm active:scale-95 transition-all flex items-center gap-1"
                    >
                      <Play className="w-3 h-3 fill-current" /> Play
                    </button>
                  </div>

                  {/* Tri-color win rate bar (White Win / Draw / Black Win) */}
                  <div className="flex flex-col gap-1">
                    <div className="w-full h-3 rounded-full overflow-hidden flex text-[9px] font-bold text-center">
                      <div
                        className="bg-amber-400 text-slate-950 flex items-center justify-center"
                        style={{ width: `${c.whiteWinRate}%` }}
                        title={`White Wins: ${c.whiteWinRate}%`}
                      >
                        {c.whiteWinRate}%
                      </div>
                      <div
                        className="bg-slate-500 text-slate-200 flex items-center justify-center"
                        style={{ width: `${c.drawRate}%` }}
                        title={`Draws: ${c.drawRate}%`}
                      >
                        {c.drawRate}%
                      </div>
                      <div
                        className="bg-sky-500 text-slate-950 flex items-center justify-center"
                        style={{ width: `${c.blackWinRate}%` }}
                        title={`Black Wins: ${c.blackWinRate}%`}
                      >
                        {c.blackWinRate}%
                      </div>
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>White: {c.whiteWinRate}%</span>
                      <span>Draw: {c.drawRate}%</span>
                      <span>Black: {c.blackWinRate}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
