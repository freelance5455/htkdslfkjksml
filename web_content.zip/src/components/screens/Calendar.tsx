"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { CATEGORY_ICON, Icon } from "@/components/ui/Icon";
import { Btn, Card, Chip, IconBtn, Screen, SectionTitle } from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import {
  buildIcs,
  currentMonthKey,
  dayLabel,
  downloadText,
  formatCompact,
  googleCalendarUrl,
  monthGrid,
  monthLabel,
  orderedWeekdays,
  relativeDay,
  shiftMonth,
  todayKey,
} from "@/lib/calendar";
import type { DataPayload, SafeProfile } from "@/lib/types";

type Mode = "spend" | "earn" | "net";

export function CalendarScreen() {
  const { data, profile, setTab } = useApp();
  if (!data || !profile) return <div className="h-full" />;
  return <CalendarBody data={data} profile={profile} onBack={() => setTab("home")} />;
}

function CalendarBody({
  data,
  profile,
  onBack,
}: {
  data: DataPayload;
  profile: SafeProfile;
  onBack: () => void;
}) {
  const { money, short, openReceipt, openAdd } = useApp();
  const [month, setMonth] = useState(currentMonthKey());
  const [mode, setMode] = useState<Mode>("spend");
  const [selected, setSelected] = useState<string>(todayKey());

  const byDay = useMemo(() => {
    const map = new Map<string, { earn: number; spend: number; count: number }>();
    for (const c of data.stats.calendar) map.set(c.day, c);
    return map;
  }, [data.stats.calendar]);

  const cells = useMemo(() => monthGrid(month, profile.weekStart), [month, profile.weekStart]);

  const valueOf = (day: string) => {
    const c = byDay.get(day);
    if (!c) return 0;
    if (mode === "spend") return c.spend;
    if (mode === "earn") return c.earn;
    return Math.round((c.earn - c.spend) * 100) / 100;
  };

  const { max, min, maxDay, minDay, monthTotal, activeDays } = useMemo(() => {
    const inMonth = cells.filter((c) => c.inMonth);
    const vals = inMonth.map((c) => ({ day: c.day, v: valueOf(c.day) }));
    const positive = vals.filter((x) => (mode === "net" ? x.v !== 0 : x.v > 0));
    const sortedDesc = [...positive].sort((a, b) => Math.abs(b.v) - Math.abs(a.v));
    const sortedAsc = [...positive].sort((a, b) => Math.abs(a.v) - Math.abs(b.v));
    return {
      max: sortedDesc[0]?.v ?? 0,
      min: sortedAsc[0]?.v ?? 0,
      maxDay: sortedDesc[0]?.day ?? null,
      minDay: sortedAsc[0]?.day ?? null,
      monthTotal: Math.round(vals.reduce((s, x) => s + x.v, 0) * 100) / 100,
      activeDays: positive.length,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cells, mode, byDay]);

  const dayEntries = useMemo(
    () => data.transactions.filter((t) => t.day === selected).sort((a, b) => b.id - a.id),
    [data.transactions, selected],
  );
  const billsDue = useMemo(
    () => data.bills.filter((b) => b.current.dueDay === selected || b.periods.some((p) => p.dueDay === selected)),
    [data.bills, selected],
  );
  const dueInMonth = useMemo(
    () => data.bills.filter((b) => b.periods.some((p) => p.dueDay.startsWith(month))),
    [data.bills, month],
  );

  const accent = mode === "earn" ? "var(--c-earn)" : mode === "spend" ? "var(--c-spend)" : "var(--c-brand)";

  function cellStyle(day: string, inMonth: boolean) {
    const v = valueOf(day);
    const isNet = mode === "net";
    const magnitude = Math.abs(v);
    const scale = Math.abs(max) || 1;
    const intensity = magnitude > 0 ? 0.14 + Math.min(1, magnitude / scale) * 0.72 : 0;
    const color = isNet ? (v >= 0 ? "var(--c-earn)" : "var(--c-spend)") : accent;
    return {
      background:
        magnitude > 0
          ? `color-mix(in oklab, ${color} ${Math.round(intensity * 100)}%, var(--c-surface))`
          : inMonth
            ? "var(--c-surface)"
            : "transparent",
      borderColor:
        day === selected
          ? "var(--c-brand)"
          : day === maxDay
            ? color
            : magnitude > 0
              ? `color-mix(in oklab, ${color} 35%, transparent)`
              : "var(--c-line)",
      opacity: inMonth ? 1 : 0.32,
      color: intensity > 0.55 ? "var(--c-bg)" : undefined,
    };
  }

  return (
    <Screen
      title="Calendar"
      subtitle={`${data.stats.count} entries mapped`}
      onBack={onBack}
      right={
        <IconBtn
          name="google"
          label="Export month to Google Calendar"
          size={36}
          onClick={() => {
            const events = data.transactions
              .filter((t) => t.day.startsWith(month))
              .map((t) => ({
                title: `${t.kind === "earn" ? "Earned" : "Spent"} ${money(t.amount)} — ${t.title}`,
                day: t.day,
                description: `Keep Tracked · ${t.category}`,
              }));
            if (!events.length) return;
            downloadText(`keep-tracked-${month}.ics`, buildIcs(events), "text/calendar");
          }}
        />
      }
    >
      <div className="space-y-4 px-4 pb-8 pt-4">
        <div className="flex items-center gap-2">
          <IconBtn name="left" label="Previous month" size={36} onClick={() => setMonth((m) => shiftMonth(m, -1))} />
          <div className="flex-1 text-center">
            <AnimatePresence mode="wait">
              <motion.p
                key={month}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ type: "spring", stiffness: 340, damping: 30 }}
                className="font-display text-[19px] font-extrabold tracking-[-0.02em]"
              >
                {monthLabel(month)}
              </motion.p>
            </AnimatePresence>
          </div>
          <IconBtn name="right" label="Next month" size={36} onClick={() => setMonth((m) => shiftMonth(m, 1))} />
          {month !== currentMonthKey() ? (
            <Chip tone="brand" onClick={() => { setMonth(currentMonthKey()); setSelected(todayKey()); }}>
              Today
            </Chip>
          ) : null}
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex-1">
            <SegmentedMode value={mode} onChange={setMode} />
          </div>
        </div>

        <Card className="p-3">
          <div className="mb-2 grid grid-cols-7 gap-1.5">
            {orderedWeekdays(profile.weekStart).map((d) => (
              <span key={d} className="text-center font-mono text-[9.5px] uppercase tracking-[0.1em] text-ink3">
                {d.slice(0, 2)}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {cells.map((c) => {
              const v = valueOf(c.day);
              const isMax = c.day === maxDay;
              const isMin = c.day === minDay && minDay !== maxDay;
              const hasBill = dueInMonth.some((b) => b.periods.some((p) => p.dueDay === c.day));
              return (
                <motion.button
                  key={c.day}
                  layout="position"
                  whileTap={{ scale: 0.92 }}
                  onClick={() => setSelected(c.day)}
                  className="press relative flex aspect-square flex-col items-center justify-center rounded-xl border"
                  style={cellStyle(c.day, c.inMonth)}
                  aria-label={`${c.day}: ${money(v)}`}
                >
                  <span
                    className={`font-mono text-[11.5px] font-semibold leading-none ${
                      c.isToday ? "text-brandtext" : ""
                    }`}
                    style={cellStyle(c.day, c.inMonth).color ? { color: "inherit" } : undefined}
                  >
                    {c.dateNum}
                  </span>
                  {v !== 0 ? (
                    <span className="tnum mt-0.5 font-mono text-[8.5px] leading-none opacity-80">
                      {mode === "net" ? (v > 0 ? "+" : "−") : ""}
                      {formatCompact(Math.abs(v), profile.currency)}
                    </span>
                  ) : null}
                  {hasBill ? (
                    <span
                      className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full"
                      style={{ background: "var(--c-bill)" }}
                    />
                  ) : null}
                  {isMax ? (
                    <span className="absolute -top-1 left-1/2 -translate-x-1/2 text-brandtext">
                      <Icon name="spark" size={11} />
                    </span>
                  ) : null}
                  {isMin ? (
                    <span className="absolute inset-0 rounded-xl border border-dashed border-ink3/60" />
                  ) : null}
                  {c.isToday ? (
                    <span className="absolute inset-x-2 -bottom-[3px] h-[2px] rounded-full bg-brand" />
                  ) : null}
                </motion.button>
              );
            })}
          </div>

          <div className="mt-3 flex items-center gap-2">
            <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-ink3">least</span>
            <div
              className="h-2 flex-1 rounded-full"
              style={{
                background: `linear-gradient(90deg, color-mix(in oklab, ${accent} 12%, var(--c-surface)), ${accent})`,
              }}
            />
            <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-ink3">most</span>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-2">
          <HighlightCard
            icon="flame"
            label={`most ${mode === "net" ? "movement" : mode}`}
            day={maxDay}
            amount={max}
            tone={mode === "earn" ? "earn" : "spend"}
            money={money}
          />
          <HighlightCard
            icon="droplet"
            label={`least ${mode === "net" ? "movement" : mode}`}
            day={minDay}
            amount={min}
            tone="neutral"
            money={money}
          />
          <StatMini label="month total" value={money(monthTotal, { sign: mode === "net" })} icon="chart" />
          <StatMini
            label="avg / active day"
            value={money(activeDays ? monthTotal / activeDays : 0)}
            icon="target"
          />
        </div>

        <section>
          <SectionTitle
            action={
              <Btn size="sm" variant="soft" icon="plus" onClick={() => openAdd(mode === "earn" ? "earn" : "spend", { day: selected })}>
                Add
              </Btn>
            }
          >
            {relativeDay(selected)}
          </SectionTitle>
          <Card className="divide-y divide-line">
            {dayEntries.length === 0 && billsDue.length === 0 ? (
              <div className="px-4 py-7 text-center">
                <p className="font-display text-[14px] font-bold">Nothing logged on this day</p>
                <p className="mt-1 text-[12px] text-ink2">
                  Tap Add to record an earning or spending dated {dayLabel(selected)}.
                </p>
              </div>
            ) : null}
            {dayEntries.map((t) => (
              <button
                key={t.id}
                onClick={() => openReceipt(t)}
                className="press flex w-full items-center gap-3 px-3.5 py-3 text-left"
              >
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border"
                  style={{
                    color: `var(--c-${t.kind === "earn" ? "earn" : "spend"})`,
                    borderColor: `color-mix(in oklab, var(--c-${t.kind === "earn" ? "earn" : "spend"}) 30%, transparent)`,
                    background: `color-mix(in oklab, var(--c-${t.kind === "earn" ? "earn" : "spend"}) 10%, transparent)`,
                  }}
                >
                  <Icon name={CATEGORY_ICON[t.category] ?? "dots"} size={16} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-display text-[13.5px] font-bold">{t.title}</span>
                  <span className="block font-mono text-[9.5px] uppercase tracking-[0.12em] text-ink3">
                    {t.category}
                  </span>
                </span>
                <span
                  className="tnum font-mono text-[13px] font-semibold"
                  style={{ color: `var(--c-${t.kind === "earn" ? "earn" : "spend"})` }}
                >
                  {t.kind === "earn" ? "+" : "−"}
                  {short(t.amount)}
                </span>
              </button>
            ))}
            {billsDue.map((b) => (
              <div key={`bill-${b.id}`} className="flex items-center gap-3 px-3.5 py-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-bill/30 bg-bill/12 text-bill">
                  <Icon name={CATEGORY_ICON[b.category] ?? "bolt"} size={16} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-display text-[13.5px] font-bold">{b.name}</span>
                  <span className="block font-mono text-[9.5px] uppercase tracking-[0.12em] text-ink3">
                    bill due · {b.current.status}
                  </span>
                </span>
                <span className="tnum font-mono text-[13px] font-semibold text-bill">
                  {money(b.current.remaining)}
                </span>
              </div>
            ))}
          </Card>

          <div className="mt-2 flex gap-2">
            <a
              className="press flex flex-1 items-center justify-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2.5 text-[12.5px] font-semibold text-ink2"
              href={googleCalendarUrl({
                title: `Keep Tracked · ${dayLabel(selected)}`,
                day: selected,
                details: `${dayEntries.length} entries · net ${money(
                  dayEntries.reduce((s, t) => s + (t.kind === "earn" ? t.amount : -t.amount), 0),
                )}`,
              })}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icon name="google" size={15} />
              Open in Google Calendar
            </a>
            <Btn variant="outline" icon="ledger" onClick={() => openAdd("spend", { day: selected })}>
              Log entry
            </Btn>
          </div>
        </section>
      </div>
    </Screen>
  );
}

function SegmentedMode({ value, onChange }: { value: Mode; onChange: (m: Mode) => void }) {
  const opts: { v: Mode; label: string; icon: Parameters<typeof Icon>[0]["name"] }[] = [
    { v: "spend", label: "Spendings", icon: "down" },
    { v: "earn", label: "Earnings", icon: "up" },
    { v: "net", label: "Net flow", icon: "trend" },
  ];
  return (
    <div className="relative flex rounded-2xl border border-line bg-surface2 p-1">
      {opts.map((o) => {
        const active = o.v === value;
        return (
          <button
            key={o.v}
            onClick={() => onChange(o.v)}
            className={`press relative z-10 flex flex-1 items-center justify-center gap-1.5 rounded-xl px-2 py-2 text-[12px] font-bold transition-colors ${
              active ? "text-brandink" : "text-ink2"
            }`}
          >
            {active ? (
              <motion.span
                layoutId="cal-mode"
                transition={{ type: "spring", stiffness: 480, damping: 38 }}
                className="absolute inset-0 z-[-1] rounded-xl bg-brand"
              />
            ) : null}
            <Icon name={o.icon} size={13} />
            <span className="truncate">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function HighlightCard({
  icon,
  label,
  day,
  amount,
  tone,
  money,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  label: string;
  day: string | null;
  amount: number;
  tone: "earn" | "spend" | "neutral";
  money: (v: number) => string;
}) {
  const color =
    tone === "earn" ? "var(--c-earn)" : tone === "spend" ? "var(--c-spend)" : "var(--c-ink2)";
  return (
    <Card className="p-3">
      <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-ink3">
        <Icon name={icon} size={11} />
        {label}
      </span>
      <p className="tnum mt-1 font-display text-[19px] font-extrabold tracking-[-0.03em]" style={{ color }}>
        {day ? money(amount) : "—"}
      </p>
      <p className="mt-0.5 truncate text-[11.5px] text-ink2">{day ? dayLabel(day) : "no data yet"}</p>
    </Card>
  );
}

function StatMini({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: Parameters<typeof Icon>[0]["name"];
}) {
  return (
    <Card className="p-3">
      <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-ink3">
        <Icon name={icon} size={11} />
        {label}
      </span>
      <p className="tnum mt-1 truncate font-display text-[17px] font-extrabold tracking-[-0.03em]">
        {value}
      </p>
    </Card>
  );
}
