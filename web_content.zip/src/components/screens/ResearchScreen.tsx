"use client";

import { useState } from "react";
import { Card, ErrorCard, Pill, Skeleton, Stat } from "@/components/ui";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtCompact, fmtPct, fmtPrice, fmtUsd } from "@/lib/format";
import { COIN_UNIVERSE } from "@/lib/universe";
import type { Analysis } from "@/lib/signals";

type Fundamentals = {
  symbol: string;
  name: string;
  marketCap: number;
  fdv: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number;
  supplyInflation: number;
  onChainVolume: number;
  volumeToMcap: number;
  activeWallets: number;
  developerActivity: number;
  communityScore: number;
  sentimentUp: number;
  ath: number;
  athChangePct: number;
  categories: string[];
  description: string;
};

type Resp = {
  ok?: boolean;
  fundamentals?: Fundamentals | null;
  analysis?: Analysis | null;
  aiSummary?: string;
  meta?: { hebrewName: string; sector: string; base: string };
  source?: string;
  error?: string | null;
};

export default function ResearchScreen() {
  const [symbol, setSymbol] = useState("BTCUSDT");
  const { data, loading, error, refresh } = useApi<Resp>(`/api/research?symbol=${symbol}`, { intervalMs: 120000 });
  const f = data?.fundamentals ?? null;
  const a = data?.analysis ?? null;

  return (
    <div className="space-y-4">
      <Card
        title="מחקר עומק ויסודות (Messari Style)"
        subtitle="נתוני און-צ'יין, היצע, פעילות מפתחים וסיכום AI"
        action={
          <select
            className="rounded-xl border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
          >
            {COIN_UNIVERSE.map((c) => (
              <option key={c.symbol} value={c.symbol}>
                {c.base} · {c.hebrewName}
              </option>
            ))}
          </select>
        }
      >
        {loading && !f ? (
          <Skeleton rows={5} />
        ) : !f ? (
          <ErrorCard detail={error ?? data?.error ?? null} onRetry={() => void refresh()} />
        ) : (
          <div className="space-y-4">
            <div className="rounded-2xl border border-sky-500/30 bg-sky-950/20 p-3">
              <h3 className="mb-1 text-xs font-bold text-sky-300">סיכום פרוטוקול אוטומטי (AI)</h3>
              <p className="text-[12px] leading-relaxed text-slate-200">{data?.aiSummary}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
              <Stat label="שווי שוק" value={`${fmtCompact(f.marketCap)}$`} />
              <Stat label="שווי בדילול מלא (FDV)" value={`${fmtCompact(f.fdv)}$`} />
              <Stat label="מחזור און-צ'יין 24ש" value={`${fmtCompact(f.onChainVolume)}$`} />
              <Stat
                label="נזילות (מחזור/שווי שוק)"
                value={`${f.volumeToMcap.toFixed(2)}%`}
                tone={f.volumeToMcap > 5 ? "up" : "warn"}
              />
              <Stat label="היצע במחזור" value={fmtCompact(f.circulatingSupply)} />
              <Stat label="היצע מקסימלי" value={f.maxSupply ? fmtCompact(f.maxSupply) : "ללא הגבלה"} />
              <Stat
                label="אינפלציית היצע"
                value={`${f.supplyInflation.toFixed(2)}%`}
                tone={f.supplyInflation > 15 ? "down" : "up"}
                hint="חלק ההיצע שטרם שוחרר"
              />
              <Stat label="ארנקים/קהילה פעילה" value={fmtCompact(f.activeWallets)} />
              <Stat
                label="פעילות מפתחים (4 שבועות)"
                value={f.developerActivity.toLocaleString("he-IL")}
                tone={f.developerActivity > 100 ? "up" : "warn"}
              />
              <Stat label="סנטימנט חיובי" value={`${f.sentimentUp.toFixed(0)}%`} tone={f.sentimentUp >= 60 ? "up" : "warn"} />
              <Stat label="שיא כל הזמנים" value={fmtUsd(f.ath)} />
              <Stat label="מרחק מהשיא" value={fmtPct(f.athChangePct)} tone={f.athChangePct >= -30 ? "up" : "down"} />
            </div>

            <div className="flex flex-wrap gap-1">
              {arr<string>(f.categories).map((c) => (
                <Pill key={c} tone="violet">
                  {c}
                </Pill>
              ))}
            </div>

            {f.description && (
              <div>
                <h4 className="mb-1 text-xs font-bold text-slate-300">תיאור הפרוטוקול</h4>
                <p className="text-[11px] leading-relaxed text-slate-400">{f.description}</p>
              </div>
            )}
          </div>
        )}
      </Card>

      <Card title="קריאה טכנית משולבת" subtitle="ניתוח יומי מחושב דינמית מנתוני הבורסה">
        {!a ? (
          <Skeleton rows={2} label="מחשב אינדיקטורים..." />
        ) : (
          <div className="grid grid-cols-2 gap-2 md:grid-cols-6">
            <Stat label="המלצה" value={a.directionHe} tone={a.direction === "LONG" ? "up" : a.direction === "SHORT" ? "down" : "warn"} />
            <Stat label="ביטחון" value={`${a.confidence.toFixed(0)}%`} />
            <Stat label="מחיר" value={fmtPrice(a.price)} />
            <Stat label="RSI" value={a.indicators.rsi.toFixed(1)} />
            <Stat label="ADX" value={a.indicators.adx.toFixed(1)} />
            <Stat label="תנודתיות ATR" value={`${a.atrPct}%`} />
          </div>
        )}
      </Card>
    </div>
  );
}
