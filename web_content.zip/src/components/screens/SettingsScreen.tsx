import React from 'react';
import { ChevronLeft, Volume2, Music, Eye, Zap } from 'lucide-react';
import { BoardStyle, PieceStyle, AppTheme, GameSettings } from '../../types/chess';
import { sound } from '../../services/sound';

interface SettingsScreenProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onBack,
}) => {
  const update = (partial: Partial<GameSettings>) => {
    sound.playClick();
    const updated = { ...settings, ...partial };
    if ('soundEnabled' in partial) {
      sound.setSoundEnabled(!!partial.soundEnabled);
    }
    if ('musicEnabled' in partial) {
      sound.setMusicEnabled(!!partial.musicEnabled);
    }
    onUpdateSettings(updated);
  };

  const boardStyles: { id: BoardStyle; label: string; previewClass: string }[] = [
    { id: 'classic', label: 'Classic', previewClass: 'from-[#E8D5B5] to-[#302117]' },
    { id: 'wooden', label: 'Wooden', previewClass: 'from-[#C7A779] to-[#3D2516]' },
    { id: 'marble', label: 'Marble', previewClass: 'from-[#EAECEF] to-[#14171E]' },
    { id: 'glass', label: 'Glass', previewClass: 'from-[#7DD3FC] to-[#075985]' },
    { id: 'futuristic', label: 'Sci-Fi', previewClass: 'from-[#00F0FF] to-[#0A0E17]' },
  ];

  const pieceStyles: { id: PieceStyle; label: string; icon: string }[] = [
    { id: 'classic', label: 'Classic', icon: '♔' },
    { id: 'modern', label: 'Modern', icon: '♚' },
    { id: 'fantasy', label: 'Fantasy', icon: '⚜️' },
    { id: 'metal', label: 'Metal', icon: '🪙' },
  ];

  const themes: { id: AppTheme; label: string; color: string }[] = [
    { id: 'dark', label: 'Dark', color: '#090D17' },
    { id: 'light', label: 'Light', color: '#334155' },
    { id: 'blue', label: 'Blue', color: '#0284C7' },
    { id: 'green', label: 'Green', color: '#059669' },
  ];

  const aiSpeeds: { id: 'fast' | 'normal' | 'realistic'; label: string }[] = [
    { id: 'fast', label: 'Instant' },
    { id: 'normal', label: 'Normal' },
    { id: 'realistic', label: 'Ponder' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-24 select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100">
          Game Settings
        </h2>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex flex-col gap-6">
        {/* 1. Board Style */}
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3">
            Board Style
          </label>
          <div className="grid grid-cols-4 gap-2.5">
            {boardStyles.map((b) => {
              const isSelected = settings.boardStyle === b.id;
              return (
                <button
                  key={b.id}
                  onClick={() => update({ boardStyle: b.id })}
                  className={`flex flex-col items-center p-2 rounded-2xl border transition-all ${
                    isSelected
                      ? 'bg-[#18263E] border-amber-400 shadow-md shadow-amber-400/20'
                      : 'bg-[#101726] border-[#1E2B45] hover:border-slate-600'
                  }`}
                >
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${b.previewClass} shadow-inner mb-2 border border-white/20`}
                  />
                  <span className={`text-xs font-medium ${isSelected ? 'text-amber-300 font-bold' : 'text-slate-300'}`}>
                    {b.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Piece Style */}
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3">
            Piece Style
          </label>
          <div className="grid grid-cols-4 gap-2.5">
            {pieceStyles.map((p) => {
              const isSelected = settings.pieceStyle === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => update({ pieceStyle: p.id })}
                  className={`flex flex-col items-center p-2.5 rounded-2xl border transition-all ${
                    isSelected
                      ? 'bg-[#18263E] border-amber-400 shadow-md shadow-amber-400/20'
                      : 'bg-[#101726] border-[#1E2B45] hover:border-slate-600'
                  }`}
                >
                  <div className="w-11 h-11 rounded-xl bg-[#162035] border border-[#233352] flex items-center justify-center text-2xl mb-2">
                    {p.icon}
                  </div>
                  <span className={`text-xs font-medium ${isSelected ? 'text-amber-300 font-bold' : 'text-slate-300'}`}>
                    {p.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Theme */}
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3">
            Theme
          </label>
          <div className="grid grid-cols-4 gap-2.5">
            {themes.map((t) => {
              const isSelected = settings.theme === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => update({ theme: t.id })}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-[#101726] border-[#1E2B45] text-slate-300'
                  }`}
                >
                  {t.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* AI Calculation Speed */}
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3">
            AI Calculation Pace
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {aiSpeeds.map((s) => {
              const isSelected = settings.aiSpeed === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => update({ aiSpeed: s.id })}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                      : 'bg-[#101726] border-[#1E2B45] text-slate-300'
                  }`}
                >
                  {s.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Audio & Gameplay Toggles (matches Screen 5 from reference) */}
        <div className="bg-[#101726]/80 border border-[#1E2B45] rounded-2xl p-4 flex flex-col gap-4">
          {/* Sound Effects */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
                <Volume2 className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium text-slate-200">Sound Effects</span>
            </div>
            <button
              onClick={() => update({ soundEnabled: !settings.soundEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.soundEnabled ? 'bg-sky-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Background Music */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                <Music className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium text-slate-200">Background Music</span>
            </div>
            <button
              onClick={() => update({ musicEnabled: !settings.musicEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.musicEnabled ? 'bg-sky-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  settings.musicEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Show Legal Moves */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Eye className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium text-slate-200">Show Legal Moves</span>
            </div>
            <button
              onClick={() => update({ showLegalMoves: !settings.showLegalMoves })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.showLegalMoves ? 'bg-sky-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  settings.showLegalMoves ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Auto Queen Promotion */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Zap className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium text-slate-200">Auto-Queen on Promotion</span>
            </div>
            <button
              onClick={() => update({ autoQueen: !settings.autoQueen })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.autoQueen ? 'bg-sky-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  settings.autoQueen ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
