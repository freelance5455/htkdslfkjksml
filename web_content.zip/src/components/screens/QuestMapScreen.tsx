import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2, Lock, Flame, Shield, Award } from 'lucide-react';
import { useGame } from '../../context/GameContext';
import { FOOD_GROUPS } from '../../data/foodGroups';
import { sound } from '../../utils/sound';

interface QuestMapScreenProps {
  onStartQuiz: (group: string) => void;
  onOpenCodex: (group: string) => void;
  onOpenBlitz: () => void;
  onOpenLab: () => void;
}

export const QuestMapScreen: React.FC<QuestMapScreenProps> = ({
  onStartQuiz,
  onOpenCodex,
  onOpenBlitz,
  onOpenLab,
}) => {
  const { state, addCoins } = useGame();

  const stages = [
    {
      id: 'vegetables',
      name: 'Vegetable Realm',
      tagline: 'Gut Defense & Clear Skin',
      emoji: '🥦',
      color: 'from-emerald-600 to-teal-800',
      badgeId: 'veg_master',
      borderColor: 'border-emerald-500/40',
      textColor: 'text-emerald-400',
    },
    {
      id: 'fruits',
      name: 'Fruit Orchard',
      tagline: 'Antioxidants & Quick Fuel',
      emoji: '🍎',
      color: 'from-rose-600 to-red-800',
      badgeId: 'fruit_master',
      borderColor: 'border-rose-500/40',
      textColor: 'text-rose-400',
    },
    {
      id: 'grains',
      name: 'Golden Grain Plains',
      tagline: 'Sustained Brain & Sports Fuel',
      emoji: '🌾',
      color: 'from-amber-600 to-yellow-800',
      badgeId: 'grain_master',
      borderColor: 'border-amber-500/40',
      textColor: 'text-amber-400',
    },
    {
      id: 'protein',
      name: 'Protein Citadel',
      tagline: 'Growth Spurts & Muscle Repair',
      emoji: '🍗',
      color: 'from-purple-600 to-indigo-800',
      badgeId: 'protein_master',
      borderColor: 'border-purple-500/40',
      textColor: 'text-purple-400',
    },
    {
      id: 'dairy',
      name: 'Calcium Cavern',
      tagline: 'Peak Teen Bone Bank (Ages 12-19)',
      emoji: '🥛',
      color: 'from-sky-600 to-blue-800',
      badgeId: 'dairy_master',
      borderColor: 'border-sky-500/40',
      textColor: 'text-sky-400',
    },
    {
      id: 'all',
      name: 'Plate Master Summit',
      tagline: 'The Ultimate 5-Group Challenge',
      emoji: '🍽️',
      color: 'from-fuchsia-600 to-pink-800',
      badgeId: 'plate_architect',
      borderColor: 'border-fuchsia-500/40',
      textColor: 'text-fuchsia-400',
    },
  ];

  return (
    <div className="space-y-4">
      {/* Hero Teen Quest Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900/60 via-slate-900 to-teal-950 p-4 sm:p-5 border border-emerald-500/30 shadow-xl">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Teen Adventure Mode</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-display text-white">
              The 5 Food Groups Quest
            </h2>
            <p className="text-xs text-slate-300 max-w-xs leading-relaxed">
              Explore the five essential food groups, conquer teen nutrition questions, and earn trophies!
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-3xl shadow-lg shrink-0">
            🥗
          </div>
        </div>

        {/* Quick Launch Buttons */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              sound.playTap();
              onStartQuiz('all');
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-900/30 transition active:scale-95 cursor-pointer"
          >
            <span>Play All-Group Quiz</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              sound.playTap();
              onOpenBlitz();
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-amber-600/90 hover:bg-amber-500 text-white font-bold text-xs shadow-md shadow-amber-900/30 transition active:scale-95 cursor-pointer"
          >
            <span>⚡ 60s Plate Blitz</span>
          </button>
        </div>
      </div>

      {/* Daily Challenge Card */}
      <div className="p-3.5 rounded-2xl bg-slate-900 border border-amber-500/30 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl shrink-0">
            🔥
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white">Daily Teen Habit Challenge</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                +30 Gems
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              "Did you know? Half your plate should be Fruits & Veggies combined!"
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            sound.playTap();
            onOpenLab();
          }}
          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold border border-slate-700 shrink-0 transition cursor-pointer"
        >
          Build Plate
        </button>
      </div>

      {/* Quest Stages List (The 5 Food Group Realms) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold font-display text-slate-200">Food Group Realms</h3>
          <span className="text-[11px] text-slate-400">
            {state.badges.filter((b) => stages.some((s) => s.badgeId === b)).length} / 6 Mastered
          </span>
        </div>

        <div className="grid gap-2.5">
          {stages.map((stage, idx) => {
            const isCompleted = state.badges.includes(stage.badgeId);

            return (
              <div
                key={stage.id}
                className={`p-3.5 rounded-2xl bg-slate-900/90 border transition hover:bg-slate-850 ${stage.borderColor} relative overflow-hidden`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${stage.color} flex items-center justify-center text-2xl shadow-md shrink-0 border border-white/20`}
                    >
                      {stage.emoji}
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                          Stage {idx + 1}
                        </span>
                        {isCompleted && (
                          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded-full border border-emerald-500/20">
                            <CheckCircle2 className="w-3 h-3" /> Mastered
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-bold text-white font-display leading-snug">
                        {stage.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{stage.tagline}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {stage.id !== 'all' && (
                      <button
                        onClick={() => {
                          sound.playTap();
                          onOpenCodex(stage.id);
                        }}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer"
                        title="View Group Codex"
                      >
                        📖
                      </button>
                    )}

                    <button
                      onClick={() => {
                        sound.playTap();
                        onStartQuiz(stage.id);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer flex items-center gap-1 ${
                        isCompleted
                          ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
                      }`}
                    >
                      <span>{isCompleted ? 'Review' : 'Enter'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
