"use client";

import { useState } from "react";
import { Button, Card, EmptyState, ErrorCard, Pill, Skeleton, Stat } from "@/components/ui";
import { useToast } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtDateTime } from "@/lib/format";

type Log = {
  id: number;
  level: string;
  symbol: string | null;
  message: string;
  rootCause: string | null;
  action: string | null;
  winRateSnapshot: number | null;
  createdAt: string;
};

type Snapshot = {
  ok?: boolean;
  logs?: Log[];
  rules?: { minConfluence: number; adxMin: number; volumeRatioMin: number; maxLeverage: number };
  stats?: { totalSignals: number; closed: number; wins: number; losses: number; winRate: number };
  error?: string | null;
};

export default function EvaluatorPanel() {
  const { toast } = useToast();
  const [running, setRunning] = useState(false);
  const { data, loading, error, refresh } = useApi<Snapshot>("/api/evaluator", { intervalMs: 300000 });
  const logs = arr<Log>(data?.logs);
  const stats = data?.stats;

  const runAudit = async () => {
    setRunning(true);
    try {
      const res = await fetch("/api/evaluator", { method: "POST" });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "הסריקה העצמית הושלמה") : (json.error ?? "שגיאה"), json.ok ? "success" : "error");
      await refresh();
    } catch {
      toast("שגיאה בהרצת סוכן הבקרה", "error");
    } finally {
      setRunning(false);
    }
  };

  return (
    <Card
      title="יומן אבחונים וסריקה עצמית"
      subtitle="סוכן בקרה אוטומטי (Evaluator-Optimizer) הבודק כל אות מול מחירי היציאה בבורסה"
      action={
        <Button variant="ghost" onClick={runAudit} disabled={running}>
          {running ? "מריץ בדיקה..." : "🤖 הרץ בדיקה עצמית"}
        </Button>
      }
    >
      {loading && logs.length === 0 ? (
        <Skeleton rows={3} />
      ) : error ? (
        <ErrorCard detail={error} onRetry={() => void refresh()} />
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
            <Stat label="אותות (7 ימים)" value={stats?.totalSignals ?? 0} />
            <Stat label="נסגרו" value={stats?.closed ?? 0} />
            <Stat label="הצליחו" value={stats?.wins ?? 0} tone="up" />
            <Stat label="נכשלו" value={stats?.losses ?? 0} tone="down" />
            <Stat
              label="אחוז הצלחה מתגלגל"
              value={`${(stats?.winRate ?? 0).toFixed(1)}%`}
              tone={(stats?.winRate ?? 0) >= 75 ? "up" : "warn"}
              hint="יעד: 75% ומעלה"
            />
          </div>

          <div className="flex flex-wrap gap-2 text-[11px]">
            <Pill tone="sky">סף ביטחון: {data?.rules?.minConfluence ?? 58}%</Pill>
            <Pill tone="sky">ADX מינימלי: {data?.rules?.adxMin ?? 20}</Pill>
            <Pill tone="sky">נפח מינימלי: {data?.rules?.volumeRatioMin ?? 0.9}x</Pill>
            <Pill tone="violet">מינוף מרבי: {data?.rules?.maxLeverage ?? 5}x</Pill>
          </div>

          {logs.length === 0 ? (
            <EmptyState text="אין עדיין רשומות אבחון. הרץ בדיקה עצמית לאחר שייסגרו אותות." />
          ) : (
            <ul className="max-h-96 space-y-2 overflow-y-auto">
              {logs.map((log) => (
                <li
                  key={log.id}
                  className={`rounded-xl border p-2 text-[11px] ${
                    log.level === "error"
                      ? "border-rose-500/30 bg-rose-950/20"
                      : log.level === "fix"
                        ? "border-amber-500/30 bg-amber-950/20"
                        : "border-slate-800 bg-slate-900/60"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-100">
                      {log.level === "error" ? "❌" : log.level === "fix" ? "🛠️" : "✅"} {log.message}
                    </span>
                    <span className="text-[9px] text-slate-500">{fmtDateTime(log.createdAt)}</span>
                  </div>
                  {log.rootCause && <p className="mt-1 text-slate-400">סיבת שורש: {log.rootCause}</p>}
                  {log.action && <p className="text-slate-500">פעולה: {log.action}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Card>
  );
}
