"use client";

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Icon } from "@/components/ui/Icon";
import {
  Btn,
  Card,
  Chip,
  Field,
  IconBtn,
  Screen,
  SectionTitle,
  Toggle,
} from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import { pushToast } from "@/lib/toast";
import { CURRENCIES, downloadText } from "@/lib/calendar";
import type { DataPayload, SafeProfile } from "@/lib/types";

const CAP_COMMANDS = `npm i -D @capacitor/core @capacitor/cli @capacitor/android
export CAP_SERVER_URL=${"${"}your hosted url${"}"}
npm run build && npx cap add android && npx cap sync
cd android && ./gradlew assembleDebug
# apk → android/app/build/outputs/apk/debug/app-debug.apk`;

export function SettingsScreen() {
  const { data, profile, setTab } = useApp();
  if (!data || !profile) return <div className="h-full" />;
  return <SettingsBody data={data} profile={profile} onBack={() => setTab("home")} />;
}

function SettingsBody({
  data,
  profile,
  onBack,
}: {
  data: DataPayload;
  profile: SafeProfile;
  onBack: () => void;
}) {
  const {
    saveSettings,
    changePin,
    reset,
    lock,
    logout,
    askConfirm,
    money,
    autoLock,
    setAutoLock,
    restoreBackup,
  } = useApp();
  const fileRef = useRef<HTMLInputElement | null>(null);

  const [balance, setBalance] = useState(String(profile.startBalance ?? 0));
  const [appUrl, setAppUrl] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") setAppUrl(window.location.origin);
  }, []);

  async function copy(text: string) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      pushToast("Copied to clipboard");
    } catch {
      pushToast("Clipboard blocked by browser", "error");
    }
  }
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");

  useEffect(() => setBalance(String(profile.startBalance ?? 0)), [profile.startBalance]);

  function exportJson() {
    downloadText(
      `keep-tracked-backup-${new Date().toISOString().slice(0, 10)}.json`,
      JSON.stringify(
        {
          exportedAt: new Date().toISOString(),
          profile: { username: profile.username, currency: profile.currency },
          transactions: data.transactions,
          bills: data.bills.map((b) => ({
            name: b.name,
            category: b.category,
            amount: b.amount,
            dueDay: b.dueDay,
            startMonth: b.startMonth,
            periods: b.periods,
            payments: b.payments,
          })),
        },
        null,
        2,
      ),
      "application/json",
    );
  }

  function exportCsv() {
    const rows = [
      ["date", "type", "title", "category", "amount", "note"],
      ...data.transactions.map((t) => [
        t.day,
        t.kind === "earn" ? "earning" : "spending",
        t.title.replace(/"/g, '""'),
        t.category,
        t.amount.toFixed(2),
        (t.note ?? "").replace(/"/g, '""'),
      ]),
    ];
    downloadText(
      `keep-tracked-${profile.username}.csv`,
      rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n"),
      "text/csv",
    );
  }

  async function submitPin() {
    if (newPin !== confirmPin) return;
    const ok = await changePin(currentPin, newPin);
    if (ok) {
      setCurrentPin("");
      setNewPin("");
      setConfirmPin("");
    }
  }

  return (
    <Screen title="Settings" subtitle={profile.username} onBack={onBack}>
      <div className="space-y-5 px-4 pb-10 pt-4">
        {/* profile */}
        <Card className="flex items-center gap-3 p-4">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-brand font-display text-[19px] font-extrabold text-brandink">
            {profile.username.slice(0, 2).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-[17px] font-extrabold tracking-[-0.02em]">
              {profile.username}
            </p>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
              ledger #{profile.id} · since{" "}
              {new Date(profile.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              <Chip tone="neutral" icon="ledger">
                {data.transactions.length} entries
              </Chip>
              <Chip tone="bill" icon="bolt">
                {data.bills.length} bills
              </Chip>
            </div>
          </div>
        </Card>

        <div className="flex gap-2">
          <Btn variant="soft" icon="lock" full onClick={lock}>
            Lock now
          </Btn>
          <Btn
            variant="outline"
            icon="logout"
            full
            onClick={() =>
              askConfirm({
                title: "Log out of this profile?",
                body: "You will need your PIN to open the ledger again.",
                confirmLabel: "Log out",
                tone: "danger",
                onConfirm: () => void logout(),
              })
            }
          >
            Log out
          </Btn>
        </div>

        {/* appearance */}
        <section>
          <SectionTitle>appearance</SectionTitle>
          <Card className="space-y-3.5 p-4">
            <div>
              <p className="mb-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">mode</p>
              <div className="relative flex rounded-2xl border border-line bg-surface2 p-1">
                {(["dark", "light", "system"] as const).map((t) => {
                  const active = profile.theme === t;
                  return (
                    <button
                      key={t}
                      onClick={() => void saveSettings({ theme: t }, `${t} mode on`)}
                      className={`press relative z-10 flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-[12.5px] font-bold capitalize transition-colors ${
                        active ? "text-brandink" : "text-ink2"
                      }`}
                    >
                      {active ? (
                        <motion.span
                          layoutId="theme-pill"
                          transition={{ type: "spring", stiffness: 480, damping: 38 }}
                          className="absolute inset-0 z-[-1] rounded-xl bg-brand"
                        />
                      ) : null}
                      <Icon name={t === "dark" ? "moon" : t === "light" ? "sun" : "monitor"} size={14} />
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>

            <SettingRow
              icon="coins"
              title="Compact numbers"
              body="Show $1.2k instead of full amounts in dense lists."
              right={
                <Toggle
                  checked={profile.compactNumbers}
                  onChange={(v) => void saveSettings({ compactNumbers: v })}
                  label="Compact numbers"
                />
              }
            />
            <div className="perf" />
            <SettingRow
              icon="calendar"
              title="Week starts on"
              body="Applies to the calendar grid."
              right={
                <div className="flex gap-1.5">
                  {(["Sun", "Mon"] as const).map((d, i) => (
                    <Chip
                      key={d}
                      tone="neutral"
                      active={profile.weekStart === i}
                      onClick={() => void saveSettings({ weekStart: i })}
                    >
                      {d}
                    </Chip>
                  ))}
                </div>
              }
            />
          </Card>
        </section>

        {/* money */}
        <section>
          <SectionTitle>money</SectionTitle>
          <Card className="space-y-3.5 p-4">
            <Field label="Currency">
              <div className="relative">
                <select
                  className="field pr-10 font-semibold"
                  value={profile.currency}
                  onChange={(e) => void saveSettings({ currency: e.target.value }, "Currency updated")}
                >
                  {CURRENCIES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.symbol} · {c.code} — {c.label}
                    </option>
                  ))}
                </select>
                <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-ink3">
                  <Icon name="chevron" size={16} />
                </span>
              </div>
            </Field>
            <Field label="Opening balance" hint="Added on top of everything you log">
              <div className="flex gap-2">
                <input
                  className="field tnum font-mono"
                  inputMode="decimal"
                  value={balance}
                  onChange={(e) => setBalance(e.target.value.replace(/[^\d.-]/g, ""))}
                />
                <Btn
                  variant="brand"
                  onClick={() =>
                    void saveSettings({ startBalance: Number(balance) || 0 }, "Opening balance saved")
                  }
                >
                  Save
                </Btn>
              </div>
            </Field>
            <div className="flex items-center justify-between rounded-xl border border-line bg-surface2 px-3 py-2.5">
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
                current balance
              </span>
              <span className="tnum font-display text-[17px] font-extrabold">{money(data.stats.balance)}</span>
            </div>
          </Card>
        </section>

        {/* security */}
        <section>
          <SectionTitle>security</SectionTitle>
          <Card className="space-y-3 p-4">
            <SettingRow
              icon="lock"
              title="Require PIN on open"
              body="Ask for the PIN every time Keep Tracked launches."
              right={
                <Toggle
                  checked={profile.requirePin}
                  onChange={(v) => void saveSettings({ requirePin: v }, v ? "PIN gate on" : "PIN gate off")}
                  label="Require PIN"
                />
              }
            />
            <div className="perf" />
            <SettingRow
              icon="clock"
              title="Auto-lock when away"
              body="Re-lock if the app stays in the background for a minute."
              right={<Toggle checked={autoLock} onChange={setAutoLock} label="Auto lock" />}
            />
            <div className="perf" />
            <div>
              <p className="mb-2 font-display text-[13.5px] font-bold">Change PIN</p>
              <div className="grid grid-cols-3 gap-2">
                <input
                  className="field tnum text-center font-mono"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  placeholder="current"
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, ""))}
                />
                <input
                  className="field tnum text-center font-mono"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  placeholder="new"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ""))}
                />
                <input
                  className="field tnum text-center font-mono"
                  type="password"
                  inputMode="numeric"
                  maxLength={8}
                  placeholder="repeat"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ""))}
                />
              </div>
              <div className="mt-2 flex items-center gap-2">
                <Btn
                  variant="brand"
                  size="sm"
                  icon="key"
                  disabled={
                    currentPin.length < 4 || newPin.length < 4 || newPin !== confirmPin
                  }
                  onClick={submitPin}
                >
                  Update PIN
                </Btn>
                {newPin && confirmPin && newPin !== confirmPin ? (
                  <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-spend">
                    pins do not match
                  </span>
                ) : (
                  <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
                    4–8 digits
                  </span>
                )}
              </div>
            </div>
          </Card>
        </section>

        {/* data */}
        <section>
          <SectionTitle>data &amp; backup</SectionTitle>
          <Card className="space-y-2 p-4">
            <div className="flex items-start gap-3 rounded-2xl border border-line bg-surface2/60 p-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-brand/30 bg-brand/12 text-brandtext">
                <Icon name="shield" size={16} />
              </span>
              <p className="text-[11.5px] leading-relaxed text-ink2">
                Everything — profiles, PINs, entries, bills — lives <b>only on this device</b>. No
                internet is used, ever. Installing Keep Tracked on another phone starts completely
                fresh; carry your history over with a backup file.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Btn variant="soft" icon="download" onClick={exportJson}>
                Backup
              </Btn>
              <Btn variant="soft" icon="upload" onClick={() => fileRef.current?.click()}>
                Restore
              </Btn>
              <Btn variant="soft" icon="ledger" onClick={exportCsv}>
                CSV
              </Btn>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                const reader = new FileReader();
                reader.onload = () => {
                  const text = String(reader.result ?? "");
                  askConfirm({
                    title: "Restore this backup?",
                    body: "Current entries and bills on this device will be replaced by the contents of the backup file.",
                    confirmLabel: "Restore",
                    tone: "brand",
                    onConfirm: () => void restoreBackup(text),
                  });
                };
                reader.readAsText(file);
              }}
            />
            <div className="perf my-1" />
            <DangerRow
              icon="refresh"
              title="Reset everything"
              body="Delete all earnings, spendings, bills and payments for this profile."
              action={
                <Btn
                  size="sm"
                  variant="danger"
                  onClick={() =>
                    askConfirm({
                      title: "Reset all records?",
                      body: "Every entry, receipt and bill payment will be erased. Your username and PIN stay. This cannot be undone.",
                      confirmLabel: "Erase everything",
                      tone: "danger",
                      onConfirm: () => void reset("data", false),
                    })
                  }
                >
                  Reset
                </Btn>
              }
            />
            <DangerRow
              icon="spark"
              title="Reset & load demo data"
              body="Wipe the ledger then refill it with 5 months of sample activity."
              action={
                <Btn
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    askConfirm({
                      title: "Reset and load demo data?",
                      body: "Current records are erased and replaced with a sample ledger so you can explore the graphs.",
                      confirmLabel: "Load demo",
                      tone: "brand",
                      onConfirm: () => void reset("data", true),
                    })
                  }
                >
                  Reload
                </Btn>
              }
            />
            <DangerRow
              icon="trash"
              title="Delete profile"
              body="Removes your username, PIN and every record tied to it."
              action={
                <Btn
                  size="sm"
                  variant="danger"
                  onClick={() =>
                    askConfirm({
                      title: "Delete this profile?",
                      body: `${profile.username} and all linked data will be permanently deleted. You will return to first-time setup.`,
                      confirmLabel: "Delete profile",
                      tone: "danger",
                      onConfirm: () => void reset("account"),
                    })
                  }
                >
                  Delete
                </Btn>
              }
            />
          </Card>
        </section>

        {/* android app */}
        <section>
          <SectionTitle>get the .apk</SectionTitle>
          <Card className="space-y-3.5 p-4">
            <SettingRow
              icon="phone"
              title="Install from Chrome"
              body="Open Keep Tracked in Chrome on Android → menu ⋮ → Add to Home screen. Full-screen with its own icon, works offline — the ledger lives on the phone."
              right={
                <Btn size="sm" variant="soft" icon="download" onClick={() => void copy(appUrl)}>
                  Copy link
                </Btn>
              }
            />
            <div className="perf" />
            <div>
              <p className="font-display text-[13.5px] font-bold">Package a signed .apk online</p>
              <p className="mt-1 text-[11.5px] leading-snug text-ink2">
                This website cannot compile Android binaries itself, so PWABuilder compiles your
                APK in the cloud for free — it wraps this exact app (manifest + service worker).
                No Android Studio, no SDK, nothing to install on your computer.
              </p>
              <ol className="mt-2 space-y-1 text-[12px] leading-relaxed text-ink2">
                <li>1 · Open PWABuilder and paste your app URL.</li>
                <li>2 · Package for stores → Android → download the signed APK zip.</li>
                <li>3 · On the phone allow unknown apps, then tap the APK to install.</li>
                <li>4 · Open it once; after that it runs with no internet and a fresh device starts fresh.</li>
              </ol>
              <div className="mt-2.5 flex flex-wrap gap-2">
                <a
                  href={`https://www.pwabuilder.com/?url=${encodeURIComponent(appUrl || "https://")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="press inline-flex h-9 items-center gap-1.5 rounded-xl bg-brand px-3 text-[13px] font-semibold text-brandink"
                >
                  <Icon name="google" size={14} />
                  Open PWABuilder
                </a>
                <Btn size="sm" variant="outline" icon="download" onClick={() => void copy(appUrl)}>
                  Copy app URL
                </Btn>
              </div>
              <p className="mt-2 break-all font-mono text-[10px] text-ink3">{appUrl || "…"}</p>
            </div>
            <div className="perf" />
            <div>
              <p className="font-display text-[13.5px] font-bold">Single-file build (no PWA needed)</p>
              <p className="mt-1 text-[11.5px] leading-snug text-ink2">
                The project ships <span className="font-mono">standalone/index.html</span> — the
                entire app in one offline file. Point Capacitor&apos;s webDir at the{" "}
                <span className="font-mono">standalone</span> folder, or hand that one file to any
                HTML→APK wrapper (WebIntoApp, AppsGeyser, Median). The resulting APK needs no
                server and no internet.
              </p>
              <pre className="thin-scroll mt-2 overflow-x-auto rounded-xl border border-line bg-surface2 p-3 font-mono text-[10.5px] leading-relaxed text-ink2">
{`npx cap init "Keep Tracked" app.keeptracked.offline --web-dir standalone
npx cap add android && npx cap copy android
cd android && ./gradlew assembleDebug`}
              </pre>
              <Btn
                size="sm"
                variant="soft"
                icon="download"
                onClick={() =>
                  void copy(
                    'npx cap init "Keep Tracked" app.keeptracked.offline --web-dir standalone\nnpx cap add android && npx cap copy android\ncd android && ./gradlew assembleDebug',
                  )
                }
              >
                Copy commands
              </Btn>
            </div>
            <div className="perf" />
            <div>
              <p className="font-display text-[13.5px] font-bold">Build the APK from a terminal</p>
              <p className="mt-1 text-[11.5px] leading-snug text-ink2">
                Needs only JDK 17 + Android SDK command-line tools (no Android Studio). The repo
                ships <span className="font-mono">scripts/build-android-apk.sh</span> and a
                Capacitor config pointing the WebView at your server.
              </p>
              <pre className="thin-scroll mt-2 overflow-x-auto rounded-xl border border-line bg-surface2 p-3 font-mono text-[10.5px] leading-relaxed text-ink2">
{CAP_COMMANDS}
              </pre>
              <Btn size="sm" variant="soft" icon="download" onClick={() => void copy(CAP_COMMANDS)}>
                Copy commands
              </Btn>
            </div>
          </Card>
        </section>

        {/* about */}
        <section>
          <SectionTitle>about</SectionTitle>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand text-brandink">
                <Icon name="ledger" size={20} />
              </span>
              <div>
                <p className="font-display text-[15px] font-extrabold tracking-[-0.02em]">Keep Tracked</p>
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
                  version 1.0 · installable app
                </p>
              </div>
            </div>
            <p className="mt-3 text-[12.5px] leading-relaxed text-ink2">
              A pocket ledger for money in and money out: automatic most / least / average graphs for
              days and months, a heat calendar, printable receipts and bill trackers that roll unpaid
              balances forward month to month.
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              <Chip tone="neutral" icon="shield">
                PIN hashed on device
              </Chip>
              <Chip tone="neutral" icon="google">
                Google Calendar export
              </Chip>
              <Chip tone="neutral" icon="wallet">
                100% offline ledger
              </Chip>
            </div>
          </Card>
          <p className="pt-3 text-center font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink3">
            keep tracked · {new Date().getFullYear()}
          </p>
        </section>
      </div>
    </Screen>
  );
}

function SettingRow({
  icon,
  title,
  body,
  right,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  title: string;
  body: string;
  right: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-line bg-surface2 text-ink2">
        <Icon name={icon} size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-display text-[13.5px] font-bold">{title}</p>
        <p className="mt-0.5 text-[11.5px] leading-snug text-ink2">{body}</p>
      </div>
      <div className="shrink-0">{right}</div>
    </div>
  );
}

function DangerRow({
  icon,
  title,
  body,
  action,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  title: string;
  body: string;
  action: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-line bg-surface2/50 p-3">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-spend/30 bg-spend/10 text-spend">
        <Icon name={icon} size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-display text-[13.5px] font-bold">{title}</p>
        <p className="mt-0.5 text-[11.5px] leading-snug text-ink2">{body}</p>
      </div>
      <div className="shrink-0">{action}</div>
    </div>
  );
}
