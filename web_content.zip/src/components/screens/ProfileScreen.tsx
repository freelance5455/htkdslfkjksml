import React, { useState } from 'react';
import { ChevronLeft, Crown, Award, Edit3, Check, Trophy } from 'lucide-react';
import { UserProfile } from '../../types/chess';
import { sound } from '../../services/sound';

interface ProfileScreenProps {
  profile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  onBack: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  profile,
  onUpdateProfile,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'achievements'>('stats');
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);

  const handleSaveName = () => {
    sound.playClick();
    if (nameInput.trim()) {
      onUpdateProfile({ ...profile, name: nameInput.trim() });
    }
    setIsEditingName(false);
  };

  const winRate = profile.totalGames > 0
    ? Math.round((profile.wins / profile.totalGames) * 100)
    : 0;

  // Rating history chart calculation (matches Screen 9 green line)
  const history = profile.ratingHistory || [];
  const minRating = Math.min(...history.map((h) => h.rating), 950);
  const maxRating = Math.max(...history.map((h) => h.rating), 1350);
  const range = maxRating - minRating || 1;

  const points = history.map((item, idx) => {
    const x = 30 + (idx / Math.max(1, history.length - 1)) * 260;
    const y = 130 - ((item.rating - minRating) / range) * 90;
    return { x, y, rating: item.rating, date: item.date };
  });

  const pathD = points.length > 0
    ? `M ${points.map((p) => `${p.x},${p.y}`).join(' L ')}`
    : '';

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-24 select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100">
          Profile
        </h2>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex flex-col gap-5">
        {/* User Card (matches Screen 9) */}
        <div className="p-5 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] flex items-center gap-4 shadow-xl">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 via-sky-500/20 to-purple-500/20 border border-amber-400/40 flex items-center justify-center text-3xl shadow-inner">
              {profile.avatar}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-500 border-2 border-[#101726] flex items-center justify-center text-[10px] text-slate-950 font-bold">
              ✓
            </div>
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              {isEditingName ? (
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="bg-[#182338] border border-amber-400/60 rounded px-2 py-0.5 text-sm text-white focus:outline-none"
                    autoFocus
                  />
                  <button onClick={handleSaveName} className="p-1 text-emerald-400 hover:text-emerald-300">
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-lg text-slate-100">{profile.name}</h3>
                  <button
                    onClick={() => {
                      setIsEditingName(true);
                      setNameInput(profile.name);
                    }}
                    className="text-slate-400 hover:text-amber-300"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 mt-1">
              <span className="flex items-center gap-1 text-xs font-bold text-amber-400">
                <Crown className="w-3.5 h-3.5 fill-current" /> Rating: {profile.rating}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-sky-500/15 border border-sky-400/30 text-[10px] font-semibold text-sky-300">
                {profile.title}
              </span>
            </div>
          </div>
        </div>

        {/* Tabs: Stats vs Achievements */}
        <div className="grid grid-cols-2 p-1 bg-[#101726] border border-[#1E2B45] rounded-2xl">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('stats');
            }}
            className={`py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'stats'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Stats
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('achievements');
            }}
            className={`py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'achievements'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Achievements
          </button>
        </div>

        {activeTab === 'stats' ? (
          <div className="flex flex-col gap-4">
            {/* 5 Stats Numbers (matches Screen 9) */}
            <div className="bg-[#101726]/80 border border-[#1E2B45] rounded-2xl p-4 flex flex-col gap-2.5">
              <div className="flex justify-between items-center py-1 border-b border-[#1E2B45]/60">
                <span className="text-xs text-slate-300">Total Games</span>
                <span className="text-sm font-bold font-mono text-slate-100">{profile.totalGames}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#1E2B45]/60">
                <span className="text-xs text-slate-300">Wins</span>
                <span className="text-sm font-bold font-mono text-emerald-400">{profile.wins}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#1E2B45]/60">
                <span className="text-xs text-slate-300">Losses</span>
                <span className="text-sm font-bold font-mono text-rose-400">{profile.losses}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#1E2B45]/60">
                <span className="text-xs text-slate-300">Draws</span>
                <span className="text-sm font-bold font-mono text-slate-400">{profile.draws}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-xs text-slate-300">Win Rate</span>
                <span className="text-sm font-bold font-mono text-amber-400">{winRate}%</span>
              </div>
            </div>

            {/* Recent Performance Elo Rating Chart (matches Screen 9 green line) */}
            <div className="bg-[#101726]/80 border border-[#1E2B45] rounded-2xl p-4 flex flex-col gap-2">
              <span className="text-xs font-semibold text-slate-300">Recent Performance</span>
              <div className="w-full h-40 relative">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 320 150">
                  {/* Grid lines */}
                  {[30, 60, 90, 120].map((y) => (
                    <line key={y} x1="30" y1={y} x2="300" y2={y} stroke="#1E2B45" strokeDasharray="3 3" />
                  ))}

                  {/* Y-axis labels */}
                  <text x="5" y="35" fill="#64748B" fontSize="9" fontFamily="monospace">1300</text>
                  <text x="5" y="75" fill="#64748B" fontSize="9" fontFamily="monospace">1200</text>
                  <text x="5" y="115" fill="#64748B" fontSize="9" fontFamily="monospace">1100</text>
                  <text x="5" y="145" fill="#64748B" fontSize="9" fontFamily="monospace">1000</text>

                  {/* Rating Line */}
                  {points.length > 1 && (
                    <path
                      d={pathD}
                      fill="none"
                      stroke="#10B981"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  )}

                  {/* Points */}
                  {points.map((p, i) => (
                    <g key={i}>
                      <circle cx={p.x} cy={p.y} r="4" fill="#10B981" stroke="#064E3B" strokeWidth="2" />
                      <text x={p.x} y="148" fill="#64748B" fontSize="8" textAnchor="middle" fontFamily="monospace">
                        {p.date}
                      </text>
                    </g>
                  ))}
                </svg>
              </div>
            </div>
          </div>
        ) : (
          /* Achievements Tab */
          <div className="flex flex-col gap-2.5">
            {profile.achievements.map((ach) => (
              <div
                key={ach.id}
                className={`p-3.5 rounded-2xl border flex items-center gap-3 transition-all ${
                  ach.unlocked
                    ? 'bg-[#101E2E] border-amber-500/40'
                    : 'bg-[#101726]/60 border-[#1E2B45] opacity-70'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-[#162238] border border-[#233352] flex items-center justify-center text-2xl">
                  {ach.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-slate-100">{ach.title}</h4>
                    {ach.unlocked ? (
                      <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 border border-amber-400/30 px-2 py-0.5 rounded-full">
                        Unlocked
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-500 font-mono">Locked</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{ach.description}</p>
                  {ach.maxProgress && !ach.unlocked && (
                    <div className="w-full bg-[#182338] h-1.5 rounded-full mt-2 overflow-hidden border border-[#233352]">
                      <div
                        className="h-full bg-amber-400 rounded-full"
                        style={{ width: `${((ach.progress || 0) / ach.maxProgress) * 100}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
