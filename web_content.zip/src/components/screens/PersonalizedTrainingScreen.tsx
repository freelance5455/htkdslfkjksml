import React, { useState } from 'react';
import {
  ChevronLeft,
  Calendar,
  Clock,
  Target,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Award,
  Sparkles,
  BarChart2,
} from 'lucide-react';
import {
  calculateTrainingStats,
  loadTrainingPlan,
  saveTrainingPlan,
  generateAdaptiveWeeklyPlan,
  TrainingStats,
} from '../../services/trainingPlan';
import { PersonalizedTrainingPlan, TacticalTheme } from '../../types/chess';
import { sound } from '../../services/sound';

interface PersonalizedTrainingScreenProps {
  onBack: () => void;
  onOpenModule: (category: string) => void;
}

export const PersonalizedTrainingScreen: React.FC<PersonalizedTrainingScreenProps> = ({
  onBack,
  onOpenModule,
}) => {
  const [stats, setStats] = useState<TrainingStats>(() => calculateTrainingStats());
  const [plan, setPlan] = useState<PersonalizedTrainingPlan>(() => loadTrainingPlan());
  const [selectedDayIdx, setSelectedDayIdx] = useState(0);
  const [sessionMinutes, setSessionMinutes] = useState(30);

  const activeDay = plan.days[selectedDayIdx] || plan.days[0];

  const handleToggleModule = (modId: string) => {
    sound.playClick();
    const updated = { ...plan };
    const day = updated.days[selectedDayIdx];
    const mod = day.modules.find((m) => m.id === modId);
    if (mod) {
      mod.completed = !mod.completed;
      day.completed = day.modules.every((m) => m.completed);
    }
    setPlan(updated);
    saveTrainingPlan(updated);
  };

  const handleRegeneratePlan = (minutes: number) => {
    sound.playClick();
    setSessionMinutes(minutes);
    const newPlan = generateAdaptiveWeeklyPlan(1200, minutes);
    setPlan(newPlan);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-20 select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100 flex items-center gap-2">
          <Target className="w-5 h-5 text-amber-400" /> Personalized Training
        </h2>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex flex-col gap-4">
        {/* Insufficient Data Notice if applicable */}
        {!stats.hasSufficientData ? (
          <div className="p-4 rounded-2xl bg-[#182338]/90 border border-amber-400/40 flex items-start gap-3 shadow-lg">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-xs text-amber-200 uppercase tracking-wide">
                Calibrating Your Training Profile
              </h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                Complete at least 3 tactical puzzles or reviewed games so the training engine can accurately detect your recurring mistake patterns. Standard baseline assigned.
              </p>
            </div>
          </div>
        ) : (
          /* Demonstrated Weakness Radar */
          <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-3 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs text-slate-200 flex items-center gap-1.5 uppercase tracking-wide">
                <BarChart2 className="w-4 h-4 text-sky-400" /> Focus Weaknesses
              </h3>
              <span className="text-[11px] text-amber-400 font-bold font-mono">
                {stats.accuracyRate}% Overall Tactics Accuracy
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {plan.focusWeaknesses.map((w, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-1.5"
                >
                  <Flame className="w-3.5 h-3.5 fill-current" /> {w}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Configurable Session Duration */}
        <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex items-center justify-between shadow-xl">
          <div>
            <span className="font-bold text-xs text-slate-200 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-400" /> Daily Target
            </span>
            <p className="text-[11px] text-slate-400">Configure daily training commitment</p>
          </div>

          <div className="flex gap-1.5">
            {[15, 30, 45].map((mins) => (
              <button
                key={mins}
                onClick={() => handleRegeneratePlan(mins)}
                className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all ${
                  sessionMinutes === mins
                    ? 'bg-sky-500 text-slate-950 shadow-md'
                    : 'bg-[#182338] text-slate-300 hover:text-white'
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>
        </div>

        {/* 7-Day Calendar Tabs */}
        <div className="grid grid-cols-7 gap-1.5 p-1.5 bg-[#101726] border border-[#1E2B45] rounded-2xl text-center text-xs">
          {plan.days.map((day, idx) => {
            const isSelected = selectedDayIdx === idx;
            return (
              <button
                key={day.dayShort}
                onClick={() => {
                  sound.playClick();
                  setSelectedDayIdx(idx);
                }}
                className={`py-2 rounded-xl flex flex-col items-center gap-1 transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="text-[10px] uppercase font-semibold">{day.dayShort}</span>
                {day.completed ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                )}
              </button>
            );
          })}
        </div>

        {/* Active Day Modules Checklist */}
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between px-1">
            <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wide">
              {activeDay.dayName} Plan ({activeDay.modules.reduce((acc, m) => acc + m.durationMinutes, 0)} mins)
            </h4>
            <span className="text-[11px] text-emerald-400 font-bold">
              {activeDay.modules.filter((m) => m.completed).length} / {activeDay.modules.length} Completed
            </span>
          </div>

          {activeDay.modules.map((mod) => (
            <div
              key={mod.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-start gap-3 shadow-md ${
                mod.completed
                  ? 'bg-[#10192A]/60 border-emerald-500/40 opacity-80'
                  : 'bg-[#101726] border-[#1E2B45]'
              }`}
            >
              <button
                onClick={() => handleToggleModule(mod.id)}
                className={`w-6 h-6 rounded-lg mt-0.5 flex items-center justify-center border transition-all ${
                  mod.completed
                    ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                    : 'bg-[#182338] border-[#2A3C5E] text-transparent hover:border-slate-400'
                }`}
              >
                ✓
              </button>

              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4
                    className={`font-bold text-xs ${
                      mod.completed ? 'line-through text-slate-400' : 'text-slate-100'
                    }`}
                  >
                    {mod.title}
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">
                    {mod.durationMinutes} min
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  {mod.description}
                </p>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModule(mod.category);
                  }}
                  className="mt-2 py-1 px-3 rounded-lg bg-[#182338] hover:bg-[#202E4A] border border-[#283B59] text-[10px] font-bold text-sky-300 transition-colors"
                >
                  Start Module →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
