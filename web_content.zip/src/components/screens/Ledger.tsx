"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { CATEGORY_ICON, Icon } from "@/components/ui/Icon";
import { Btn, Card, Chip, EmptyState, IconBtn, SectionTitle } from "@/components/ui/primitives";
import { Screen } from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import {
  buildIcs,
  dayLabel,
  downloadText,
  monthLabel,
  monthShort,
  relativeDay,
} from "@/lib/calendar";
import type { DataPayload, SafeProfile, Tx } from "@/lib/types";

export function LedgerScreen() {
  const { data, profile, setTab } = useApp();
  if (!data || !profile) return <div className="h-full" />;
  return <LedgerBody data={data} profile={profile} onBack={() => setTab("home")} />;
}

function LedgerBody({
  data,
  profile,
  onBack,
}: {
  data: DataPayload;
  profile: SafeProfile;
  onBack: () => void;
}) {
  const { openReceipt, openAdd, money } = useApp();
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<"all" | "earn" | "spend">("all");
  const [month, setMonth] = useState<string>("all");

  const months = useMemo(() => {
    const set = new Set(data.transactions.map((t) => t.day.slice(0, 7)));
    return [...set].sort((a, b) => b.localeCompare(a));
  }, [data.transactions]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.transactions.filter((t) => {
      if (kind !== "all" && t.kind !== kind) return false;
      if (month !== "all" && !t.day.startsWith(month)) return false;
      if (q && !`${t.title} ${t.category} ${t.note ?? ""}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [data.transactions, query, kind, month]);

  const groups = useMemo(() => {
    const map = new Map<string, Tx[]>();
    for (const t of filtered) {
      const list = map.get(t.day) ?? [];
      list.push(t);
      map.set(t.day, list);
    }
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  const totals = filtered.reduce(
    (acc, t) => {
      if (t.kind === "earn") acc.earn += t.amount;
      else acc.spend += t.amount;
      return acc;
    },
    { earn: 0, spend: 0 },
  );

  function exportCsv() {
    const rows = [
      ["date", "type", "title", "category", "amount", "note"],
      ...filtered.map((t) => [
        t.day,
        t.kind === "earn" ? "earning" : "spending",
        t.title.replace(/"/g, '""'),
        t.category,
        t.amount.toFixed(2),
        (t.note ?? "").replace(/"/g, '""'),
      ]),
    ];
    downloadText(
      `keep-tracked-ledger-${new Date().toISOString().slice(0, 10)}.csv`,
      rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n"),
      "text/csv",
    );
  }

  function exportIcs() {
    downloadText(
      `keep-tracked-ledger.ics`,
      buildIcs(
        filtered.map((t) => ({
          title: `${t.kind === "earn" ? "Earned" : "Spent"} ${money(t.amount)} — ${t.title}`,
          day: t.day,
          description: `Keep Tracked · ${t.category}`,
        })),
      ),
      "text/calendar",
    );
  }

  return (
    <Screen
      title="Ledger"
      subtitle={`${filtered.length} receipt${filtered.length === 1 ? "" : "s"}`}
      onBack={onBack}
      right={
        <div className="flex gap-2">
          <IconBtn name="download" label="Export CSV" onClick={exportCsv} size={36} />
          <IconBtn name="calendarPlus" label="Export to Google Calendar (.ics)" onClick={exportIcs} size={36} />
        </div>
      }
    >
      <div className="space-y-4 px-4 pb-8 pt-4">
        <div className="relative">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink3">
            <Icon name="search" size={16} />
          </span>
          <input
            className="field pl-10"
            placeholder="Search title, category or note…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {query ? (
            <button
              onClick={() => setQuery("")}
              className="press absolute right-3 top-1/2 -translate-y-1/2 text-ink3 hover:text-ink"
              aria-label="Clear search"
            >
              <Icon name="close" size={15} />
            </button>
          ) : null}
        </div>

        <div className="flex gap-2">
          {(["all", "earn", "spend"] as const).map((k) => (
            <Chip
              key={k}
              tone={k === "earn" ? "earn" : k === "spend" ? "spend" : "neutral"}
              active={kind === k}
              onClick={() => setKind(k)}
              icon={k === "all" ? "ledger" : k === "earn" ? "up" : "down"}
            >
              {k === "all" ? "Everything" : k === "earn" ? "Earnings" : "Spendings"}
            </Chip>
          ))}
        </div>

        {months.length > 1 ? (
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
            <Chip tone="brand" active={month === "all"} onClick={() => setMonth("all")}>
              All time
            </Chip>
            {months.map((m) => (
              <Chip key={m} tone="neutral" active={month === m} onClick={() => setMonth(m)}>
                {monthShort(m)} {m.slice(2, 4)}
              </Chip>
            ))}
          </div>
        ) : null}

        <Card className="flex items-center justify-between gap-2 px-4 py-3">
          <div>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink3">filtered in</p>
            <p className="tnum font-display text-[16px] font-extrabold text-earn">{money(totals.earn)}</p>
          </div>
          <span className="h-8 w-px bg-line" />
          <div>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink3">filtered out</p>
            <p className="tnum font-display text-[16px] font-extrabold text-spend">{money(totals.spend)}</p>
          </div>
          <span className="h-8 w-px bg-line" />
          <div>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink3">net</p>
            <p
              className="tnum font-display text-[16px] font-extrabold"
              style={{ color: totals.earn - totals.spend >= 0 ? "var(--c-earn)" : "var(--c-spend)" }}
            >
              {money(totals.earn - totals.spend, { sign: true })}
            </p>
          </div>
        </Card>

        {groups.length === 0 ? (
          <EmptyState
            icon="ledger"
            title="No receipts match"
            body="Try a different filter, or log a new earning / spending and it will print here instantly."
            action={
              <Btn variant="brand" icon="plus" onClick={() => openAdd("spend")}>
                New entry
              </Btn>
            }
          />
        ) : null}

        <AnimatePresence initial={false}>
          {groups.map(([day, items]) => {
            const net = items.reduce((s, t) => s + (t.kind === "earn" ? t.amount : -t.amount), 0);
            return (
              <motion.section
                key={day}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              >
                <SectionTitle className="mt-1">
                  <span className="flex w-full items-center gap-2">
                    <span className="text-ink">{dayLabel(day)}</span>
                    <span className="h-px flex-1 bg-line" />
                    <span
                      className="font-mono text-[10px] normal-case tracking-[0.08em]"
                      style={{ color: net >= 0 ? "var(--c-earn)" : "var(--c-spend)" }}
                    >
                      {money(net, { sign: true })}
                    </span>
                  </span>
                </SectionTitle>
                <div className="space-y-2">
                  {items.map((t, i) => (
                    <ReceiptCard key={t.id} tx={t} index={i} onOpen={() => openReceipt(t)} />
                  ))}
                </div>
              </motion.section>
            );
          })}
        </AnimatePresence>

        {groups.length ? (
          <p className="pt-2 text-center font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink3">
            end of ledger · {month === "all" ? "all time" : monthLabel(month)} · {profile.username}
          </p>
        ) : null}
      </div>
    </Screen>
  );
}

function ReceiptCard({ tx, index, onOpen }: { tx: Tx; index: number; onOpen: () => void }) {
  const { money } = useApp();
  const isEarn = tx.kind === "earn";
  return (
    <motion.button
      layout
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.2), type: "spring", stiffness: 320, damping: 30 }}
      whileTap={{ scale: 0.985 }}
      onClick={onOpen}
      className="receipt press flex w-full items-center gap-3 px-3.5 py-3 text-left"
    >
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border"
        style={{
          color: `var(--c-${isEarn ? "earn" : "spend"})`,
          borderColor: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 30%, transparent)`,
          background: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 10%, transparent)`,
        }}
      >
        <Icon name={CATEGORY_ICON[tx.category] ?? (isEarn ? "up" : "down")} size={17} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-display text-[14px] font-bold">{tx.title}</span>
        <span className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
          {relativeDay(tx.day)} · {tx.category} · KT-{String(Math.abs(tx.id)).padStart(6, "0")}
        </span>
      </span>
      <span
        className="tnum shrink-0 font-mono text-[14px] font-semibold"
        style={{ color: `var(--c-${isEarn ? "earn" : "spend"})` }}
      >
        {isEarn ? "+" : "−"}
        {money(tx.amount)}
      </span>
    </motion.button>
  );
}
