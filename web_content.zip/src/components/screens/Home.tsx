"use client";

import { motion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import { Icon, CATEGORY_ICON } from "@/components/ui/Icon";
import { Btn, Card, Chip, IconBtn, SectionTitle } from "@/components/ui/primitives";
import { ExtremeRow, MirrorBars, MonthDial } from "@/components/ui/charts";
import { useApp } from "@/lib/store";
import {
  buildIcs,
  downloadText,
  monthLabel,
  relativeDay,
  todayKey,
} from "@/lib/calendar";
import type { DataPayload, SafeProfile, Tx } from "@/lib/types";

function useCountUp(value: number, duration = 700) {
  const [display, setDisplay] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    const start = performance.now();
    const initial = from.current;
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(initial + (value - initial) * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
      else from.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return display;
}

export function HomeScreen() {
  const { data, profile } = useApp();
  if (!data || !profile) return <div className="h-full" />;
  return <HomeBody data={data} profile={profile} />;
}

function HomeBody({ data, profile }: { data: DataPayload; profile: SafeProfile }) {
  const { setTab, openAdd, openPay, openReceipt, money, short } = useApp();
  const { stats, transactions, bills } = data;
  const balance = useCountUp(stats.balance);

  const monthName = monthLabel(todayKey().slice(0, 7));
  const recent = transactions.slice(0, 4);
  const dueBills = bills.filter(
    (b) => b.current.status === "due" || b.current.status === "partial" || b.current.status === "overdue",
  );
  const monthDueTotal = bills.reduce((s, b) => s + b.current.due, 0);
  const monthRemaining = bills.reduce((s, b) => s + b.current.remaining, 0);
  const overdueCount = bills.filter((b) => b.overdue).length;

  const monthEntries = useMemo(
    () => transactions.filter((t) => t.day.startsWith(todayKey().slice(0, 7))),
    [transactions],
  );

  return (
    <div className="thin-scroll h-full overflow-y-auto overscroll-contain pb-8">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line/70 bg-bg/80 px-4 pb-3 pt-4 backdrop-blur-xl">
        <div className="min-w-0 flex-1">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink3">
            {new Date().toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long" })}
          </p>
          <h1 className="truncate font-display text-[21px] font-extrabold leading-tight tracking-[-0.03em]">
            Hey {profile.username}
          </h1>
        </div>
        <IconBtn name="ledger" label="Open ledger" onClick={() => setTab("ledger")} />
        <IconBtn name="settings" label="Settings" onClick={() => setTab("settings")} />
      </header>

      <div className="space-y-5 px-4 pt-4">
        {/* ------------------------------ balance ------------------------------ */}
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 260, damping: 26 }}
          className="card relative overflow-hidden p-4"
        >
          <div
            className="pointer-events-none absolute inset-0 opacity-70"
            style={{
              background:
                "radial-gradient(90% 120% at 12% 0%, color-mix(in oklab, var(--c-brand) 16%, transparent), transparent 60%)",
            }}
          />
          <div className="relative flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink3">
                balance remaining
              </p>
              <p
                className="tnum mt-1 font-display text-[42px] font-extrabold leading-[0.95] tracking-[-0.045em]"
                style={{ color: balance < 0 ? "var(--c-spend)" : "var(--c-ink)" }}
              >
                {money(Math.round(balance * 100) / 100)}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <Chip tone={stats.monthNet >= 0 ? "earn" : "spend"} icon={stats.monthNet >= 0 ? "up" : "down"}>
                  {monthName} {money(stats.monthNet, { sign: true })}
                </Chip>
                <Chip tone="neutral" icon="target">
                  {stats.savingsRate}% saved
                </Chip>
              </div>
            </div>
            <MonthDial earn={stats.monthEarn} spend={stats.monthSpend} currency={profile.currency} size={108} />
          </div>

          <div className="perf relative my-4" />

          <div className="relative grid grid-cols-3 gap-2">
            <MiniStat label="all-time in" value={short(stats.totalEarn)} tone="earn" icon="up" />
            <MiniStat label="all-time out" value={short(stats.totalSpend)} tone="spend" icon="down" />
            <MiniStat label="entries" value={String(stats.count)} tone="neutral" icon="ledger" />
          </div>
        </motion.section>

        {/* --------------------------- quick actions --------------------------- */}
        <section className="grid grid-cols-4 gap-2">
          <QuickAction icon="up" label="Earn" tone="earn" onClick={() => openAdd("earn")} />
          <QuickAction icon="down" label="Spend" tone="spend" onClick={() => openAdd("spend")} />
          <QuickAction icon="bolt" label="Bills" tone="bill" onClick={() => setTab("bills")} />
          <QuickAction icon="calendar" label="Calendar" tone="brand" onClick={() => setTab("calendar")} />
        </section>

        {/* ------------------------------- today ------------------------------- */}
        <Card className="flex items-center gap-3 p-3.5">
          <span className="grid h-10 w-10 place-items-center rounded-2xl border border-line bg-surface2 text-brandtext">
            <Icon name="spark" size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink3">today so far</p>
            <p className="font-display text-[14.5px] font-bold">
              <span className="text-earn">+{short(stats.todayEarn)}</span>
              <span className="mx-1.5 text-ink3">/</span>
              <span className="text-spend">−{short(stats.todaySpend)}</span>
            </p>
          </div>
          <Btn size="sm" variant="outline" iconRight="right" onClick={() => setTab("insights")}>
            {stats.monthPace > 0 ? `${short(stats.monthPace)}/mo pace` : "Insights"}
          </Btn>
        </Card>

        {/* ------------------------------ 21 days ------------------------------ */}
        <section>
          <SectionTitle
            action={
              <button
                onClick={() => setTab("insights")}
                className="press font-mono text-[10px] uppercase tracking-[0.14em] text-brandtext"
              >
                all graphs →
              </button>
            }
          >
            flow · earn vs spend
          </SectionTitle>
          <Card className="p-4">
            <MirrorBars days={stats.days} currency={profile.currency} />
          </Card>
        </section>

        {/* -------------------------------- bills ------------------------------ */}
        <section>
          <SectionTitle
            action={
              <button
                onClick={() => setTab("bills")}
                className="press font-mono text-[10px] uppercase tracking-[0.14em] text-brandtext"
              >
                manage →
              </button>
            }
          >
            bills this month
          </SectionTitle>
          {overdueCount > 0 ? (
            <div className="stripe mb-2 flex items-center gap-2.5 rounded-2xl border border-spend/40 bg-spend/10 px-3.5 py-2.5">
              <Icon name="alert" size={16} className="text-spend" />
              <p className="text-[12.5px] font-semibold text-spend">
                {overdueCount} bill{overdueCount > 1 ? "s" : ""} unpaid from earlier months —
                remainder rolled forward.
              </p>
            </div>
          ) : null}
          <Card className="p-4">
            <div className="mb-3 flex items-end justify-between gap-3">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink3">
                  {bills.length} tracked · {monthName}
                </p>
                <p className="font-display text-[20px] font-extrabold tracking-[-0.03em]">
                  <span style={{ color: monthRemaining > 0 ? "var(--c-bill)" : "var(--c-earn)" }}>
                    {money(monthRemaining)}
                  </span>
                  <span className="ml-1.5 text-[12px] font-semibold text-ink3">
                    left of {money(monthDueTotal)}
                  </span>
                </p>
              </div>
              <Btn size="sm" variant="soft" icon="plus" onClick={() => setTab("bills")}>
                Add
              </Btn>
            </div>
            <div className="space-y-2">
              {dueBills.slice(0, 3).map((b) => (
                <div
                  key={b.id}
                  className="press flex items-center gap-3 rounded-2xl border border-line bg-surface2/70 p-2.5"
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-bill/30 bg-bill/12 text-bill">
                    <Icon name={CATEGORY_ICON[b.category] ?? "bolt"} size={16} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-[13.5px] font-bold">{b.name}</p>
                    <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
                      due {relativeDay(b.current.dueDay)} · {money(b.current.due)}
                      {b.current.carry > 0 ? ` · +${money(b.current.carry)} carried` : ""}
                    </p>
                  </div>
                  <Chip tone={b.current.status === "overdue" ? "spend" : "bill"}>{b.current.status}</Chip>
                  <Btn size="sm" variant="outline" onClick={() => openPay(b)}>
                    Pay
                  </Btn>
                </div>
              ))}
              {!bills.length ? (
                <div className="rounded-2xl border border-dashed border-line px-4 py-6 text-center">
                  <p className="font-display text-[14px] font-bold">No bill trackers yet</p>
                  <p className="mt-1 text-[12.5px] text-ink2">
                    Add electricity, water, fuel or any custom bill to see paid / part-paid / carried
                    balances.
                  </p>
                  <Btn className="mt-3" size="sm" variant="brand" icon="plus" onClick={() => setTab("bills")}>
                    Track a bill
                  </Btn>
                </div>
              ) : !dueBills.length ? (
                <p className="py-2 text-center font-mono text-[10.5px] uppercase tracking-[0.14em] text-earn">
                  ✓ everything paid for {monthName}
                </p>
              ) : null}
            </div>
          </Card>
        </section>

        {/* ------------------------------ insights ----------------------------- */}
        <section>
          <SectionTitle
            action={
              <button
                onClick={() => setTab("insights")}
                className="press font-mono text-[10px] uppercase tracking-[0.14em] text-brandtext"
              >
                open →
              </button>
            }
          >
            auto insights
          </SectionTitle>
          <div className="space-y-2">
            <ExtremeRow
              icon="flame"
              label="most spent day"
              value={stats.spend.maxDay ? `${money(stats.spend.maxDay.amount)} · ${stats.spend.maxDay.label}` : "—"}
              sub={stats.spend.maxDay?.sub}
              tone="spend"
            />
            <ExtremeRow
              icon="calendar"
              label="most spent month"
              value={stats.spend.maxMonth ? `${money(stats.spend.maxMonth.amount)} · ${stats.spend.maxMonth.label}` : "—"}
              sub={stats.spend.avgMonth ? `avg ${short(stats.spend.avgMonth)}` : undefined}
              tone="spend"
            />
            <ExtremeRow
              icon="spark"
              label="best earning day"
              value={stats.earn.maxDay ? `${money(stats.earn.maxDay.amount)} · ${stats.earn.maxDay.label}` : "—"}
              sub={stats.earn.maxDay?.sub}
              tone="earn"
            />
          </div>
        </section>

        {/* ------------------------------ receipts ----------------------------- */}
        <section>
          <SectionTitle
            action={
              <button
                onClick={() => setTab("ledger")}
                className="press font-mono text-[10px] uppercase tracking-[0.14em] text-brandtext"
              >
                all receipts →
              </button>
            }
          >
            latest receipts
          </SectionTitle>
          <div className="space-y-2">
            {recent.map((t, i) => (
              <ReceiptRow key={t.id} tx={t} index={i} onOpen={() => openReceipt(t)} money={short(t.amount)} />
            ))}
            {!recent.length ? (
              <Card className="px-4 py-7 text-center">
                <p className="font-display text-[15px] font-bold">Your ledger is empty</p>
                <p className="mx-auto mt-1 max-w-[36ch] text-[12.5px] text-ink2">
                  Tap ＋ to log your first earning or spending — receipts, graphs and the calendar
                  build themselves.
                </p>
                <Btn className="mt-3" variant="brand" icon="plus" onClick={() => openAdd("spend")}>
                  Log an entry
                </Btn>
              </Card>
            ) : null}
          </div>
        </section>

        {/* --------------------------- calendar sync --------------------------- */}
        <Card className="flex items-center gap-3 p-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-line bg-surface2 text-brandtext">
            <Icon name="google" size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-display text-[14px] font-bold">Sync {monthName} to Google Calendar</p>
            <p className="mt-0.5 text-[11.5px] leading-snug text-ink2">
              {monthEntries.length} entries as all-day events · import the .ics once
            </p>
          </div>
          <Btn
            size="sm"
            variant="soft"
            icon="download"
            onClick={() => {
              downloadText(
                `keep-tracked-${todayKey().slice(0, 7)}.ics`,
                buildIcs(
                  monthEntries.map((t) => ({
                    title: `${t.kind === "earn" ? "Earned" : "Spent"} ${money(t.amount)} — ${t.title}`,
                    day: t.day,
                    description: `Keep Tracked · ${t.category}`,
                  })),
                ),
                "text/calendar",
              );
            }}
          >
            Export
          </Btn>
        </Card>
      </div>
    </div>
  );
}

function MiniStat({
  label,
  value,
  tone,
  icon,
}: {
  label: string;
  value: string;
  tone: "earn" | "spend" | "neutral";
  icon: Parameters<typeof Icon>[0]["name"];
}) {
  const colors: Record<string, string> = {
    earn: "var(--c-earn)",
    spend: "var(--c-spend)",
    neutral: "var(--c-ink)",
  };
  return (
    <div className="rounded-2xl border border-line bg-surface2/60 px-2.5 py-2">
      <span className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-[0.12em] text-ink3">
        <Icon name={icon} size={11} />
        {label}
      </span>
      <p className="tnum mt-0.5 truncate font-display text-[15px] font-extrabold" style={{ color: colors[tone] }}>
        {value}
      </p>
    </div>
  );
}

function QuickAction({
  icon,
  label,
  tone,
  onClick,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  label: string;
  tone: "earn" | "spend" | "bill" | "brand";
  onClick: () => void;
}) {
  const map: Record<string, string> = {
    earn: "var(--c-earn)",
    spend: "var(--c-spend)",
    bill: "var(--c-bill)",
    brand: "var(--c-brand-text)",
  };
  return (
    <motion.button
      whileTap={{ scale: 0.93 }}
      onClick={onClick}
      className="press flex flex-col items-center gap-1.5 rounded-2xl border border-line bg-surface py-3"
    >
      <span
        className="grid h-9 w-9 place-items-center rounded-xl"
        style={{
          color: map[tone],
          background: `color-mix(in oklab, ${map[tone]} 14%, transparent)`,
          border: `1px solid color-mix(in oklab, ${map[tone]} 32%, transparent)`,
        }}
      >
        <Icon name={icon} size={17} />
      </span>
      <span className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-ink2">{label}</span>
    </motion.button>
  );
}

function ReceiptRow({
  tx,
  index,
  onOpen,
  money,
}: {
  tx: Tx;
  index: number;
  onOpen: () => void;
  money: string;
}) {
  const isEarn = tx.kind === "earn";
  return (
    <motion.button
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.045, type: "spring", stiffness: 300, damping: 28 }}
      whileTap={{ scale: 0.985 }}
      onClick={onOpen}
      className="receipt press flex w-full items-center gap-3 px-3.5 py-3 text-left"
    >
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border"
        style={{
          color: `var(--c-${isEarn ? "earn" : "spend"})`,
          borderColor: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 32%, transparent)`,
          background: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 10%, transparent)`,
        }}
      >
        <Icon name={CATEGORY_ICON[tx.category] ?? (isEarn ? "up" : "down")} size={17} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-display text-[14px] font-bold">{tx.title}</span>
        <span className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink3">
          {relativeDay(tx.day)} · {tx.category}
        </span>
      </span>
      <span
        className="tnum shrink-0 font-mono text-[14px] font-semibold"
        style={{ color: `var(--c-${isEarn ? "earn" : "spend"})` }}
      >
        {isEarn ? "+" : "−"}
        {money}
      </span>
      <Icon name="right" size={15} className="shrink-0 text-ink3" />
    </motion.button>
  );
}
