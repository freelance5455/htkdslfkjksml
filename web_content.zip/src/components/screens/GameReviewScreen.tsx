import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Play,
  Pause,
  Award,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Info,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Globe,
} from 'lucide-react';
import { Chess, Square } from 'chess.js';
import { ChessScene } from '../3d/ChessScene';
import {
  MoveRecord,
  GameReviewReport,
  ReviewedMove,
  MoveClassification,
  GameSettings,
} from '../../types/chess';
import { analyzeRecordedGame } from '../../services/gameReview';
import { sound } from '../../services/sound';

interface GameReviewScreenProps {
  moves: MoveRecord[];
  whitePlayerName?: string;
  blackPlayerName?: string;
  settings: GameSettings;
  language: 'en' | 'mr' | 'hi';
  onExit: () => void;
}

export const GameReviewScreen: React.FC<GameReviewScreenProps> = ({
  moves,
  whitePlayerName = 'White',
  blackPlayerName = 'Black',
  settings,
  language: initialLanguage,
  onExit,
}) => {
  const [report, setReport] = useState<GameReviewReport | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [analysisProgress, setAnalysisProgress] = useState({ current: 0, total: moves.length });
  const [activePly, setActivePly] = useState(0); // 0 = start position
  const [isPlaying, setIsPlaying] = useState(false);
  const [lang, setLang] = useState<'en' | 'mr' | 'hi'>(initialLanguage);

  // Active game instance for 3D board
  const [boardGame, setBoardGame] = useState(() => new Chess());

  // Run full game analysis on mount
  useEffect(() => {
    let cancelled = false;

    setIsAnalyzing(true);
    analyzeRecordedGame(
      moves,
      whitePlayerName,
      blackPlayerName,
      (current, total) => {
        if (!cancelled) setAnalysisProgress({ current, total });
      }
    ).then((res) => {
      if (!cancelled) {
        setReport(res);
        setIsAnalyzing(false);
        sound.playVictory();
      }
    });

    return () => {
      cancelled = true;
    };
  }, [moves, whitePlayerName, blackPlayerName]);

  // Update board position when active ply changes
  useEffect(() => {
    const sim = new Chess();
    for (let i = 0; i < activePly && i < moves.length; i++) {
      const m = moves[i];
      try {
        sim.move({ from: m.from, to: m.to, promotion: m.promotion });
      } catch {
        break;
      }
    }
    setBoardGame(sim);
  }, [activePly, moves]);

  // Auto-play replay timer
  useEffect(() => {
    if (!isPlaying) return;

    const timer = setInterval(() => {
      setActivePly((prev) => {
        if (prev >= moves.length) {
          setIsPlaying(false);
          return prev;
        }
        sound.playMove();
        return prev + 1;
      });
    }, 1400);

    return () => clearInterval(timer);
  }, [isPlaying, moves.length]);

  const activeMove: ReviewedMove | undefined =
    report && activePly > 0 ? report.moves[activePly - 1] : undefined;

  const getClassificationBadge = (c?: MoveClassification) => {
    switch (c) {
      case 'brilliant':
        return { label: 'Brilliant !!', bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40', icon: '💎' };
      case 'great':
        return { label: 'Great Move !', bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40', icon: '⚡' };
      case 'best':
        return { label: 'Best Move ★', bg: 'bg-amber-500/20 text-amber-300 border-amber-400/40', icon: '★' };
      case 'excellent':
        return { label: 'Excellent ✓', bg: 'bg-teal-500/20 text-teal-300 border-teal-400/40', icon: '✓' };
      case 'good':
        return { label: 'Good •', bg: 'bg-blue-500/20 text-blue-300 border-blue-400/40', icon: '•' };
      case 'book':
        return { label: 'Book Move', bg: 'bg-slate-500/20 text-slate-300 border-slate-400/40', icon: '📖' };
      case 'inaccuracy':
        return { label: 'Inaccuracy ?!', bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-400/40', icon: '?!' };
      case 'mistake':
        return { label: 'Mistake ?', bg: 'bg-orange-500/20 text-orange-300 border-orange-400/40', icon: '?' };
      case 'blunder':
        return { label: 'Blunder ??', bg: 'bg-rose-500/20 text-rose-300 border-rose-400/40', icon: '??' };
      case 'missed_win':
        return { label: 'Missed Win', bg: 'bg-pink-500/20 text-pink-300 border-pink-400/40', icon: '✗' };
      default:
        return { label: 'Start Position', bg: 'bg-slate-500/20 text-slate-300 border-slate-400/40', icon: '♟' };
    }
  };

  const badge = getClassificationBadge(activeMove?.classification);

  // Compute evaluation line path across moves
  const points = report
    ? report.moves.map((m, idx) => {
        const x = 30 + (idx / Math.max(1, report.moves.length - 1)) * 280;
        // Clamp centipawns between -600 and +600 for chart
        const clamped = Math.max(-600, Math.min(600, m.evalAfter));
        const y = 60 - (clamped / 600) * 45;
        return { x, y, evalAfter: m.evalAfter, ply: m.ply, classification: m.classification };
      })
    : [];

  const pathD = points.length > 0 ? `M ${points.map((p) => `${p.x},${p.y}`).join(' L ')}` : '';

  return (
    <div className="relative w-screen h-screen bg-[#070B13] text-white flex flex-col overflow-hidden select-none">
      {/* Top Header */}
      <div className="z-20 flex items-center justify-between px-5 pt-4 pb-2 bg-[#0A0F1D]/90 border-b border-[#1A263D] backdrop-blur-md">
        <button
          onClick={() => {
            sound.playClick();
            onExit();
          }}
          className="w-9 h-9 rounded-xl bg-[#141E33] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h2 className="text-base font-bold tracking-wide text-slate-100 flex items-center gap-1.5 justify-center">
            <Sparkles className="w-4 h-4 text-amber-400" /> Game Review
          </h2>
          <p className="text-[11px] text-slate-400">Stockfish Depth 10 Analysis</p>
        </div>

        {/* Language switch */}
        <div className="flex bg-[#121A2B] border border-[#1E2B45] rounded-xl p-0.5 text-[10px]">
          {(['en', 'mr', 'hi'] as const).map((l) => (
            <button
              key={l}
              onClick={() => {
                sound.playClick();
                setLang(l);
              }}
              className={`px-2 py-0.5 rounded-lg font-bold transition-all ${
                lang === l ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {l === 'en' ? 'EN' : l === 'mr' ? 'मरा' : 'हिं'}
            </button>
          ))}
        </div>
      </div>

      {/* Analysis Loading Screen */}
      {isAnalyzing ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-4 p-6">
          <div className="relative w-20 h-20 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-2 border-amber-400/20 animate-ping" />
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-2xl shadow-lg">
              🔍
            </div>
          </div>
          <div className="text-center">
            <h3 className="font-bold text-lg text-slate-100">Reviewing Your Game...</h3>
            <p className="text-xs text-slate-400 mt-1">
              Analyzing positions with Stockfish engine ({analysisProgress.current} / {analysisProgress.total} plies)
            </p>
          </div>
          <div className="w-64 bg-[#141E33] rounded-full h-2 overflow-hidden border border-[#202D47]">
            <div
              className="bg-gradient-to-r from-amber-400 to-sky-400 h-full transition-all duration-300"
              style={{
                width: `${analysisProgress.total > 0 ? (analysisProgress.current / analysisProgress.total) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Left/Top: 3D Board Display */}
          <div className="relative flex-1 min-h-[300px] lg:min-h-0 bg-[#060910]">
            <ChessScene
              game={boardGame}
              boardStyle={settings.boardStyle}
              pieceStyle={settings.pieceStyle}
              playerPerspective="w"
              selectedSquare={null}
              legalMoves={[]}
              lastMove={
                activeMove
                  ? {
                      from: activeMove.uci.substring(0, 2),
                      to: activeMove.uci.substring(2, 4),
                    }
                  : null
              }
              hintMove={
                activeMove
                  ? {
                      from: activeMove.bestMove.substring(0, 2),
                      to: activeMove.bestMove.substring(2, 4),
                    }
                  : null
              }
              onSquareClick={() => {}}
              interactive={false}
            />

            {/* Move Classification Overlay on 3D Board */}
            {activeMove && (
              <div className="absolute top-4 left-4 z-10 animate-in fade-in">
                <span
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border shadow-lg flex items-center gap-1.5 backdrop-blur-md ${badge.bg}`}
                >
                  <span>{badge.icon}</span>
                  <span>{badge.label}</span>
                </span>
              </div>
            )}
          </div>

          {/* Right/Bottom: Review Timeline, Accuracy, and Insights */}
          <div className="w-full lg:w-96 bg-[#0B111F] border-t lg:border-t-0 lg:border-l border-[#1A263D] flex flex-col p-4 overflow-y-auto">
            {/* Accuracy Badges */}
            {report && (
              <div className="p-3.5 rounded-2xl bg-[#121A2B] border border-[#1E2B45] flex items-center justify-between mb-3 shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center font-mono font-bold text-amber-300 text-sm">
                    {report.whiteAccuracy}%
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-100">{whitePlayerName}</h4>
                    <span className="text-[10px] text-slate-400">White Accuracy</span>
                  </div>
                </div>

                <div className="text-slate-500 text-xs font-bold">vs</div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <h4 className="font-bold text-xs text-slate-100">{blackPlayerName}</h4>
                    <span className="text-[10px] text-slate-400">Black Accuracy</span>
                  </div>
                  <div className="w-11 h-11 rounded-2xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center font-mono font-bold text-sky-300 text-sm">
                    {report.blackAccuracy}%
                  </div>
                </div>
              </div>
            )}

            {/* Evaluation Graph SVG */}
            {points.length > 0 && (
              <div className="p-3 rounded-2xl bg-[#121A2B] border border-[#1E2B45] mb-3 flex flex-col gap-1.5 shadow-md">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold px-1">
                  <span>Advantage Flow</span>
                  <span className="font-mono text-amber-400">
                    {activeMove ? `${(activeMove.evalAfter / 100).toFixed(1)} pawns` : 'Equal (0.0)'}
                  </span>
                </div>
                <div className="relative w-full h-24 bg-[#0A0F1A] rounded-xl overflow-hidden border border-[#182338]">
                  {/* Zero centerline */}
                  <div className="absolute inset-x-0 top-1/2 border-b border-slate-700/60" />
                  <svg className="w-full h-full" viewBox="0 0 340 120">
                    <path d={pathD} fill="none" stroke="#38BDF8" strokeWidth="2.5" />
                    {points.map((p, idx) => {
                      const isCurrent = idx + 1 === activePly;
                      const isBlunder = p.classification === 'blunder';
                      const isBrilliant = p.classification === 'brilliant';

                      return (
                        <circle
                          key={idx}
                          cx={p.x}
                          cy={p.y}
                          r={isCurrent ? 5 : isBlunder || isBrilliant ? 4 : 2}
                          fill={isCurrent ? '#F59E0B' : isBlunder ? '#EF4444' : isBrilliant ? '#06B6D4' : '#38BDF8'}
                          className="cursor-pointer"
                          onClick={() => {
                            sound.playClick();
                            setActivePly(idx + 1);
                          }}
                        />
                      );
                    })}
                  </svg>
                </div>
              </div>
            )}

            {/* Active Move Comparison Card */}
            {activeMove ? (
              <div className="p-3.5 rounded-2xl bg-[#121A2B] border border-[#1E2B45] mb-3 flex flex-col gap-2.5 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-400 text-xs">
                      {activeMove.moveNumber}.{activeMove.color === 'b' ? '..' : ''}
                    </span>
                    <span className="font-mono font-black text-base text-white">
                      {activeMove.san}
                    </span>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-lg text-xs font-bold border ${badge.bg}`}>
                    {badge.label}
                  </span>
                </div>

                {/* Best Alternative */}
                {activeMove.bestMoveSan && activeMove.bestMoveSan !== activeMove.san && (
                  <div className="p-2 rounded-xl bg-[#0E1524] border border-amber-400/30 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Best Alternative:</span>
                      <span className="font-mono font-bold text-amber-300">{activeMove.bestMoveSan}</span>
                    </div>
                    <span className="font-mono text-rose-400 text-[11px]">
                      -{Math.round(activeMove.evalDiff)} cp
                    </span>
                  </div>
                )}

                {/* Tactical Explanation */}
                <p className="text-[11px] text-slate-300 leading-relaxed bg-[#0E1524]/60 p-2.5 rounded-xl border border-[#192438]">
                  {lang === 'mr'
                    ? activeMove.explanationMarathi || activeMove.explanation
                    : lang === 'hi'
                    ? activeMove.explanationHindi || activeMove.explanation
                    : activeMove.explanation}
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-[#121A2B] border border-[#1E2B45] mb-3 text-center text-slate-400 text-xs">
                Initial board state. Use the controls below to step through moves.
              </div>
            )}

            {/* Replay Controls Dock */}
            <div className="mt-auto pt-2 flex items-center justify-between gap-1 bg-[#121A2B] p-2 rounded-2xl border border-[#1E2B45]">
              <button
                onClick={() => {
                  sound.playClick();
                  setActivePly(0);
                }}
                title="Jump to Start"
                className="w-9 h-9 rounded-xl bg-[#182338] hover:bg-[#202E4A] flex items-center justify-center text-slate-300 hover:text-white"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  setActivePly((prev) => Math.max(0, prev - 1));
                }}
                disabled={activePly <= 0}
                title="Previous Move"
                className="w-9 h-9 rounded-xl bg-[#182338] hover:bg-[#202E4A] disabled:opacity-40 flex items-center justify-center text-slate-300 hover:text-white"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  setIsPlaying((p) => !p);
                }}
                title={isPlaying ? 'Pause' : 'Auto Play Replay'}
                className="py-2 px-4 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>{isPlaying ? 'Pause' : 'Replay'}</span>
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  setActivePly((prev) => Math.min(moves.length, prev + 1));
                }}
                disabled={activePly >= moves.length}
                title="Next Move"
                className="w-9 h-9 rounded-xl bg-[#182338] hover:bg-[#202E4A] disabled:opacity-40 flex items-center justify-center text-slate-300 hover:text-white"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  setActivePly(moves.length);
                }}
                title="Jump to End"
                className="w-9 h-9 rounded-xl bg-[#182338] hover:bg-[#202E4A] flex items-center justify-center text-slate-300 hover:text-white font-mono text-xs font-bold"
              >
                End
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
