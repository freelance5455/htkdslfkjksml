import React from 'react';
import { ChevronLeft, Bot, Globe, Users, Trophy } from 'lucide-react';
import { sound } from '../../services/sound';

interface ModeSelectScreenProps {
  onBack: () => void;
  onSelectAi: () => void;
  onSelectOnline: () => void;
  onSelectLocal: () => void;
  onSelectTournaments: () => void;
}

export const ModeSelectScreen: React.FC<ModeSelectScreenProps> = ({
  onBack,
  onSelectAi,
  onSelectOnline,
  onSelectLocal,
  onSelectTournaments,
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-20 select-none">
      {/* Navigation Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100">
          Choose Game Mode
        </h2>
        <div className="w-10" />
      </div>

      {/* 2x2 Game Mode Cards Grid */}
      <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto w-full my-auto">
        {/* 1. Play vs AI */}
        <button
          onClick={() => {
            sound.playClick();
            onSelectAi();
          }}
          className="aspect-square p-5 rounded-2xl bg-gradient-to-b from-[#131B2C] to-[#0E1524] border border-[#23324E] hover:border-amber-400/50 flex flex-col items-center justify-center text-center group active:scale-95 transition-all duration-200 shadow-lg shadow-black/40"
        >
          <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform mb-3">
            <Bot className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm tracking-wide text-slate-100 mb-1">
            Play vs AI
          </h3>
          <p className="text-[11px] text-amber-200/70 font-medium">
            Easy • Medium
          </p>
          <p className="text-[11px] text-amber-200/70 font-medium">
            Hard • Expert
          </p>
        </button>

        {/* 2. Online Multiplayer */}
        <button
          onClick={() => {
            sound.playClick();
            onSelectOnline();
          }}
          className="aspect-square p-5 rounded-2xl bg-gradient-to-b from-[#131B2C] to-[#0E1524] border border-[#23324E] hover:border-sky-400/50 flex flex-col items-center justify-center text-center group active:scale-95 transition-all duration-200 shadow-lg shadow-black/40"
        >
          <div className="w-12 h-12 rounded-2xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400 group-hover:scale-110 transition-transform mb-3">
            <Globe className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm tracking-wide text-slate-100 mb-1">
            Online Multiplayer
          </h3>
          <p className="text-[11px] text-slate-400 leading-tight">
            Play with real players around this world
          </p>
        </button>

        {/* 3. Local Multiplayer */}
        <button
          onClick={() => {
            sound.playClick();
            onSelectLocal();
          }}
          className="aspect-square p-5 rounded-2xl bg-gradient-to-b from-[#131B2C] to-[#0E1524] border border-[#23324E] hover:border-emerald-400/50 flex flex-col items-center justify-center text-center group active:scale-95 transition-all duration-200 shadow-lg shadow-black/40"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform mb-3">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm tracking-wide text-slate-100 mb-1">
            Local Multiplayer
          </h3>
          <p className="text-[11px] text-slate-400 leading-tight">
            Play on same device with friend
          </p>
        </button>

        {/* 4. Tournaments */}
        <button
          onClick={() => {
            sound.playClick();
            onSelectTournaments();
          }}
          className="aspect-square p-5 rounded-2xl bg-gradient-to-b from-[#131B2C] to-[#0E1524] border border-[#23324E] hover:border-purple-400/50 flex flex-col items-center justify-center text-center group active:scale-95 transition-all duration-200 shadow-lg shadow-black/40"
        >
          <div className="w-12 h-12 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform mb-3">
            <Trophy className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm tracking-wide text-slate-100 mb-1">
            Tournaments
          </h3>
          <p className="text-[11px] text-purple-300 leading-tight">
            Join & win rewards (Active Arena)
          </p>
        </button>
      </div>
    </div>
  );
};
