"use client";

import { useState } from "react";
import { Button, Card, EmptyState, ErrorCard, Field, Pill, Skeleton, Stat, inputClass } from "@/components/ui";
import { useToast } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtDateTime, fmtPrice, fmtUsd, pnlColor, sideHe } from "@/lib/format";

type Trader = {
  id: number;
  name: string;
  handle: string;
  strategy: string;
  winRate: number;
  roi7d: number;
  roi30d: number;
  maxDrawdown: number;
  profitFactor: number;
  riskScore: number;
  followers: number;
  avgLeverage: number;
  markets: string[] | null;
  bio: string;
};

type Follow = {
  id: number;
  masterTraderId: number;
  budget: number;
  copyStopLossPct: number;
  maxOpenPositions: number;
  maxLeverage: number;
  active: boolean;
  copiedPnl: number;
};

type CopyPosition = {
  id: number;
  symbol: string;
  side: string;
  qty: number;
  entryPrice: number;
  markPrice: number;
  leverage: number;
  status: string;
  pnl: number;
  masterTraderId: number | null;
  openedAt: string;
};

type Resp = { ok?: boolean; traders?: Trader[]; follows?: Follow[]; positions?: CopyPosition[]; error?: string | null };

export default function CopyTradingScreen() {
  const { toast } = useToast();
  const { data, loading, error, refresh } = useApi<Resp>("/api/copy", { intervalMs: 30000 });
  const [form, setForm] = useState({ budget: 1000, copyStopLossPct: 15, maxOpenPositions: 3, maxLeverage: 5 });
  const [selected, setSelected] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  const traders = arr<Trader>(data?.traders);
  const follows = arr<Follow>(data?.follows);
  const positions = arr<CopyPosition>(data?.positions);

  const post = async (payload: Record<string, unknown>) => {
    setBusy(true);
    try {
      const res = await fetch("/api/copy", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "בוצע") : (json.error ?? "שגיאה"), json.ok ? "success" : "error");
      await refresh();
    } catch {
      toast("שגיאת תקשורת - נסה שוב", "error");
    } finally {
      setBusy(false);
    }
  };

  if (loading && traders.length === 0) {
    return (
      <Card title="חיקוי עסקאות סוחרים">
        <Skeleton rows={5} />
      </Card>
    );
  }

  if (error && traders.length === 0) {
    return <ErrorCard detail={error} onRetry={() => void refresh()} />;
  }

  const totalCopied = follows.reduce((s, f) => s + f.copiedPnl, 0);
  const openPnl = positions.filter((p) => p.status === "OPEN").reduce((s, p) => s + p.pnl, 0);

  return (
    <div className="space-y-4">
      <Card
        title="לוח מובילים - סוחרי על ואסטרטגיות AI"
        subtitle="כל החיקוי מתבצע בחשבון הדמו ללא סיכון כספי אמיתי"
        action={
          <Button variant="ghost" onClick={() => void post({ action: "SYNC" })} disabled={busy}>
            🔁 סנכרן עסקאות
          </Button>
        }
      >
        <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4">
          <Stat label="סוחרים במעקב" value={follows.length} />
          <Stat label="עסקאות משוכפלות" value={positions.length} />
          <Stat label="רווח פתוח" value={fmtUsd(openPnl)} tone={openPnl >= 0 ? "up" : "down"} />
          <Stat label="רווח מצטבר מחיקוי" value={fmtUsd(totalCopied)} tone={totalCopied >= 0 ? "up" : "down"} />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {traders.map((t) => {
            const follow = follows.find((f) => f.masterTraderId === t.id);
            const isOpen = selected === t.id;
            return (
              <div key={t.id} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-slate-100">{t.name}</span>
                      <span className="text-[10px] text-slate-500">{t.handle}</span>
                      {follow ? <Pill tone="green">במעקב</Pill> : null}
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-400">{t.strategy}</p>
                  </div>
                  <Pill tone={t.riskScore >= 7 ? "red" : t.riskScore >= 4 ? "amber" : "green"}>
                    סיכון {t.riskScore}/10
                  </Pill>
                </div>

                <div className="mt-2 grid grid-cols-3 gap-2 text-center md:grid-cols-6">
                  <Stat label="Win Rate" value={`${t.winRate.toFixed(1)}%`} tone="up" />
                  <Stat label="ROI 7 ימים" value={`${t.roi7d.toFixed(1)}%`} tone={t.roi7d >= 0 ? "up" : "down"} />
                  <Stat label="ROI 30 יום" value={`${t.roi30d.toFixed(1)}%`} tone={t.roi30d >= 0 ? "up" : "down"} />
                  <Stat label="ירידה מקסימלית" value={`${t.maxDrawdown.toFixed(1)}%`} tone="down" />
                  <Stat label="Profit Factor" value={t.profitFactor.toFixed(2)} />
                  <Stat label="עוקבים" value={t.followers.toLocaleString("he-IL")} />
                </div>

                <p className="mt-2 text-[11px] text-slate-400">{t.bio}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {arr<string>(t.markets).map((m) => (
                    <Pill key={m} tone="slate">
                      {m.replace("USDT", "")}
                    </Pill>
                  ))}
                  <Pill tone="violet">מינוף ממוצע {t.avgLeverage}x</Pill>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {follow ? (
                    <>
                      <Button variant="danger" onClick={() => void post({ action: "UNFOLLOW", followId: follow.id })} disabled={busy}>
                        הפסק חיקוי
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() =>
                          void post({
                            action: "UPDATE",
                            followId: follow.id,
                            ...form,
                            active: !follow.active,
                          })
                        }
                        disabled={busy}
                      >
                        {follow.active ? "השהה" : "הפעל מחדש"}
                      </Button>
                      <span className="self-center text-[11px] text-slate-400">
                        תקציב {fmtUsd(follow.budget)} · סטופ חיקוי {follow.copyStopLossPct}% · עד {follow.maxOpenPositions} פוזיציות
                      </span>
                    </>
                  ) : (
                    <>
                      <Button onClick={() => setSelected(isOpen ? null : t.id)} variant="ghost">
                        ⚙️ הגדרות סיכון
                      </Button>
                      <Button
                        variant="success"
                        disabled={busy}
                        onClick={() => void post({ action: "FOLLOW", masterTraderId: t.id, ...form })}
                      >
                        עקוב ושכפל
                      </Button>
                    </>
                  )}
                </div>

                {isOpen && !follow && (
                  <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-800 pt-3 md:grid-cols-4">
                    <Field label="תקציב הקצאה ($)">
                      <input
                        type="number"
                        className={inputClass}
                        value={form.budget}
                        onChange={(e) => setForm({ ...form, budget: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="סטופ לוס לחיקוי (%)">
                      <input
                        type="number"
                        className={inputClass}
                        value={form.copyStopLossPct}
                        onChange={(e) => setForm({ ...form, copyStopLossPct: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="מקסימום פוזיציות">
                      <input
                        type="number"
                        className={inputClass}
                        value={form.maxOpenPositions}
                        onChange={(e) => setForm({ ...form, maxOpenPositions: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="תקרת מינוף">
                      <input
                        type="number"
                        className={inputClass}
                        value={form.maxLeverage}
                        onChange={(e) => setForm({ ...form, maxLeverage: Number(e.target.value) })}
                      />
                    </Field>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      <Card title="עסקאות משוכפלות" subtitle="מבוצעות אוטומטית בחשבון הדמו לפי תקציב ההקצאה">
        {positions.length === 0 ? (
          <EmptyState text="עדיין לא שוכפלו עסקאות. לחץ 'עקוב ושכפל' אצל אחד הסוחרים." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-right text-[11px]">
              <thead className="text-slate-400">
                <tr>
                  <th className="p-2">מטבע</th>
                  <th className="p-2">כיוון</th>
                  <th className="p-2">כניסה</th>
                  <th className="p-2">מחיר נוכחי</th>
                  <th className="p-2">מינוף</th>
                  <th className="p-2">רווח/הפסד</th>
                  <th className="p-2">סטטוס</th>
                  <th className="p-2">נפתח</th>
                </tr>
              </thead>
              <tbody className="tabular-nums">
                {positions.map((p) => (
                  <tr key={p.id} className="border-t border-slate-800">
                    <td className="p-2 font-bold text-slate-100">{p.symbol}</td>
                    <td className={`p-2 ${p.side === "LONG" ? "text-emerald-400" : "text-rose-400"}`}>{sideHe(p.side)}</td>
                    <td className="p-2">{fmtPrice(p.entryPrice)}</td>
                    <td className="p-2">{fmtPrice(p.markPrice)}</td>
                    <td className="p-2">{p.leverage}x</td>
                    <td className={`p-2 font-bold ${pnlColor(p.pnl)}`}>{fmtUsd(p.pnl)}</td>
                    <td className="p-2">{p.status === "OPEN" ? "פתוחה" : "סגורה"}</td>
                    <td className="p-2 text-slate-500">{fmtDateTime(p.openedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
