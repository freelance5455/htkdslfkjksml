import React, { useState } from 'react';
import { X, Sparkles, Shield, Swords, Compass, Globe, CheckCircle2, AlertTriangle } from 'lucide-react';
import { StockfishAnalysisResult } from '../../types/chess';
import { generateCoachExplanation, LocalizedCoachAdvice } from '../../services/chessCoach';
import { sound } from '../../services/sound';

interface ChessCoachModalProps {
  analysis: StockfishAnalysisResult | null;
  fen: string;
  language: 'en' | 'mr' | 'hi';
  onClose: () => void;
  onApplyMove?: (bestMove: string) => void;
}

export const ChessCoachModal: React.FC<ChessCoachModalProps> = ({
  analysis,
  fen,
  language: initialLanguage,
  onClose,
  onApplyMove,
}) => {
  const [lang, setLang] = useState<'en' | 'mr' | 'hi'>(initialLanguage);

  if (!analysis) return null;

  const advice: LocalizedCoachAdvice = generateCoachExplanation(analysis, fen);
  const current = advice[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in select-none">
      <div className="bg-gradient-to-b from-[#141C2E] to-[#0D1322] border border-[#2B3C5E] rounded-3xl p-6 max-w-md w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E2B45] mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/20 to-sky-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100">Chess Coach</h3>
              <p className="text-[11px] text-slate-400">Tactical & Positional Insights</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Selector */}
            <div className="flex bg-[#101726] border border-[#1E2B45] rounded-xl p-0.5 text-[10px]">
              {(['en', 'mr', 'hi'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => {
                    sound.playClick();
                    setLang(l);
                  }}
                  className={`px-2 py-1 rounded-lg font-bold transition-all ${
                    lang === l ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {l === 'en' ? 'EN' : l === 'mr' ? 'मरा' : 'हिं'}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="w-8 h-8 rounded-lg bg-[#182338] hover:bg-[#202E4A] text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-3.5 text-xs">
          {/* Main Headline */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#162238] to-[#101726] border border-amber-400/30">
            <h4 className="font-bold text-sm text-amber-300">{current.headline}</h4>
            <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
              {current.recommendedMoveText}
            </p>
          </div>

          {/* Tactical Motif Badge if detected */}
          {current.tacticalMotif && (
            <div className="p-3 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center gap-2.5 text-purple-200">
              <Swords className="w-4 h-4 text-purple-400" />
              <div>
                <span className="font-bold text-[11px] text-purple-300 uppercase tracking-wider">Tactical Motif</span>
                <p className="font-semibold text-xs">{current.tacticalMotif}</p>
              </div>
            </div>
          )}

          {/* Threats & Attacks */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-2">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Swords className="w-4 h-4 text-rose-400" /> Threats & Opportunities
            </span>
            <ul className="flex flex-col gap-1.5 pl-1">
              {current.threatsCreated.map((th, i) => (
                <li key={i} className="flex items-start gap-2 text-slate-300 text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{th}</span>
                </li>
              ))}
            </ul>

            {current.piecesAttacked.length > 0 && (
              <div className="mt-1 pt-2 border-t border-[#1C273C] flex items-center gap-1.5 text-[11px] text-amber-300/90">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Puts pressure on: {current.piecesAttacked.join(', ')}</span>
              </div>
            )}
          </div>

          {/* Positional Dynamics */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-1.5">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-sky-400" /> Positional Strategy
            </span>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {current.positionalSummary}
            </p>
          </div>

          {/* King Safety */}
          <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-1.5">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-emerald-400" /> King Safety
            </span>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {current.kingSafety}
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-4 flex gap-2">
          {onApplyMove && (
            <button
              onClick={() => {
                sound.playClick();
                onApplyMove(analysis.bestMove);
                onClose();
              }}
              className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow-md active:scale-95 transition-all"
            >
              Play Recommended Move ({analysis.bestMoveSan})
            </button>
          )}
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="py-3 px-5 rounded-2xl bg-[#182338] hover:bg-[#202E4A] border border-[#2B3B59] text-white font-bold text-xs transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
