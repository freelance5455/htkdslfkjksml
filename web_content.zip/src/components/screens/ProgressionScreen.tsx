import React, { useState } from 'react';
import {
  ChevronLeft,
  Trophy,
  Award,
  Sparkles,
  Flame,
  CheckCircle2,
  Lock,
  Layers,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { achievementService, COSMETIC_REWARDS } from '../../services/achievementService';
import { AchievementItem, PlayerProgression, AchievementCategory } from '../../types/chess';

interface ProgressionScreenProps {
  onBack: () => void;
  onSelectTheme?: (themeId: string) => void;
}

export const ProgressionScreen: React.FC<ProgressionScreenProps> = ({
  onBack,
  onSelectTheme,
}) => {
  const [activeTab, setActiveTab] = useState<'achievements' | 'cosmetics'>('achievements');
  const [categoryFilter, setCategoryFilter] = useState<AchievementCategory | 'all'>('all');
  const [progression, setProgression] = useState<PlayerProgression>(() =>
    achievementService.getProgression()
  );
  const [achievements, setAchievements] = useState<AchievementItem[]>(() =>
    achievementService.getAchievements()
  );

  const handleClaimAchievement = (ach: AchievementItem) => {
    sound.playVictory();
    achievementService.unlockAchievement(ach.id);
    setAchievements(achievementService.getAchievements());
    setProgression(achievementService.getProgression());
  };

  const filteredAchievements = achievements.filter(
    (a) => categoryFilter === 'all' || a.category === categoryFilter
  );

  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#070B13] via-[#0C1220] to-[#05080E] text-slate-100 flex flex-col font-['Outfit',sans-serif] select-none pb-24 overflow-y-auto">
      {/* Top Header */}
      <div className="px-5 pt-8 pb-4 border-b border-slate-800/60 bg-[#090F1C]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#121B2F] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h1 className="text-lg font-bold tracking-wide text-slate-100">Player Progression</h1>
          <p className="text-[11px] text-amber-400 font-medium">XP Level & Mastery Showcase</p>
        </div>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full px-4 pt-4 flex-1 flex flex-col gap-4">
        {/* Level Progression Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#17243F] to-[#0E1627] border border-amber-500/40 flex flex-col gap-3 shadow-xl">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 font-bold text-lg font-mono">
                L{progression.level}
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400">Current Rank Tier</span>
                <h2 className="text-base font-bold text-slate-100">{progression.levelTitle}</h2>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-amber-300">
                {progression.xp} / {progression.xpToNextLevel} XP
              </span>
              <p className="text-[11px] text-slate-400">
                {progression.currentLevelProgressPercent}% to Level {progression.level + 1}
              </p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2.5 rounded-full bg-slate-900 overflow-hidden border border-slate-700/60">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-500 rounded-full"
              style={{ width: `${progression.currentLevelProgressPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-1 text-slate-400">
            <span className="flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-current text-orange-400" /> {progression.streakDays} Day Streak
            </span>
            <span className="flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-amber-400" /> {unlockedCount} / {achievements.length} Achievements
            </span>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex rounded-xl bg-[#0D1424] border border-slate-800 p-1 text-xs font-semibold">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('achievements');
            }}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'achievements'
                ? 'bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" /> Achievements ({unlockedCount})
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('cosmetics');
            }}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'cosmetics'
                ? 'bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" /> Unlocks & Rewards
          </button>
        </div>

        {/* TAB 1: ACHIEVEMENTS */}
        {activeTab === 'achievements' && (
          <div className="flex flex-col gap-3">
            {/* Category Filter Chips */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
              {(['all', 'combat', 'tactics', 'tournaments', 'progression', 'mastery'] as const).map(
                (cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      sound.playClick();
                      setCategoryFilter(cat);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-semibold capitalize whitespace-nowrap border transition-all ${
                      categoryFilter === cat
                        ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                        : 'bg-[#101726] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                )
              )}
            </div>

            {/* Achievement Cards */}
            <div className="flex flex-col gap-2.5">
              {filteredAchievements.map((ach) => {
                const canClaim = !ach.isUnlocked && ach.progress >= ach.targetCount;

                return (
                  <div
                    key={ach.id}
                    className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                      ach.isUnlocked
                        ? 'bg-[#0E1627] border-slate-800/80'
                        : canClaim
                        ? 'bg-amber-500/10 border-amber-400/60 shadow-lg'
                        : 'bg-[#0B101D] border-slate-900 opacity-80'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-2xl">
                        {ach.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-sm text-slate-100">{ach.name}</h4>
                          {ach.isUnlocked && (
                            <span className="text-emerald-400 text-xs">✓</span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 line-clamp-1 leading-relaxed">
                          {ach.description}
                        </p>
                        {/* Target Progress Bar */}
                        <div className="flex items-center gap-2 mt-1">
                          <div className="w-24 h-1.5 rounded-full bg-slate-900 overflow-hidden">
                            <div
                              className="h-full bg-amber-400 rounded-full"
                              style={{
                                width: `${Math.min(
                                  100,
                                  (ach.progress / ach.targetCount) * 100
                                )}%`,
                              }}
                            />
                          </div>
                          <span className="text-[10px] font-mono text-slate-500">
                            {ach.progress}/{ach.targetCount}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      {ach.isUnlocked ? (
                        <div className="text-right">
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Claimed
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">
                            +{ach.rewardXp} XP
                          </span>
                        </div>
                      ) : canClaim ? (
                        <button
                          onClick={() => handleClaimAchievement(ach)}
                          className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 animate-pulse"
                        >
                          Claim +{ach.rewardXp} XP
                        </button>
                      ) : (
                        <span className="text-xs font-bold text-slate-500 font-mono flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5 text-amber-500/40" /> +{ach.rewardXp} XP
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: COSMETIC UNLOCKS */}
        {activeTab === 'cosmetics' && (
          <div className="flex flex-col gap-3">
            <p className="text-xs text-slate-400 px-1">
              Level up to unlock handcrafted 3D chessboard materials and Staunton piece finishes.
            </p>

            <div className="grid grid-cols-2 gap-3">
              {COSMETIC_REWARDS.map((c) => {
                const isUnlocked = progression.level >= c.levelReq;

                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      if (isUnlocked && onSelectTheme) {
                        sound.playClick();
                        onSelectTheme(c.id);
                      }
                    }}
                    className={`p-3.5 rounded-2xl border flex flex-col gap-2 transition-all ${
                      isUnlocked
                        ? 'bg-[#0E1627] border-slate-800 hover:border-amber-400/50 cursor-pointer'
                        : 'bg-[#090D18] border-slate-900 opacity-60'
                    }`}
                  >
                    <div
                      className="w-full h-16 rounded-xl border border-white/10 flex items-center justify-center relative overflow-hidden"
                      style={{ backgroundColor: c.previewColor }}
                    >
                      {!isUnlocked && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <Lock className="w-5 h-5 text-slate-400" />
                        </div>
                      )}
                    </div>

                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-xs text-slate-100">{c.name}</h4>
                        <span className="text-[10px] text-slate-500 capitalize">
                          {c.type === 'board' ? '3D Board Texture' : 'Chess Piece Set'}
                        </span>
                      </div>
                      {isUnlocked ? (
                        <span className="text-[10px] font-bold text-emerald-400">UNLOCKED</span>
                      ) : (
                        <span className="text-[10px] font-mono text-amber-400">Lvl {c.levelReq}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
