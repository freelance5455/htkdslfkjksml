import React, { useState } from 'react';
import {
  Bell,
  X,
  CheckCircle2,
  Trophy,
  Swords,
  Flame,
  Settings,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { notificationService } from '../../services/notificationService';
import { NotificationItem, NotificationSettings } from '../../types/chess';

interface NotificationDrawerProps {
  onClose: () => void;
  onNavigate?: (screen: string) => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  onClose,
  onNavigate,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    notificationService.getNotifications()
  );
  const [settings, setSettings] = useState<NotificationSettings>(() =>
    notificationService.getSettings()
  );
  const [showSettings, setShowSettings] = useState(false);
  const [filterUnreadOnly, setFilterUnreadOnly] = useState(false);

  const reload = () => {
    setNotifications(notificationService.getNotifications());
    setSettings(notificationService.getSettings());
  };

  const handleMarkAsRead = (id: string) => {
    sound.playClick();
    notificationService.markAsRead(id);
    reload();
  };

  const handleMarkAllRead = () => {
    sound.playClick();
    notificationService.markAllAsRead();
    reload();
  };

  const handleToggleSetting = (key: keyof NotificationSettings) => {
    sound.playClick();
    const updated = { ...settings, [key]: !settings[key] };
    notificationService.updateSettings(updated);
    setSettings(updated);
  };

  const filtered = filterUnreadOnly
    ? notifications.filter((n) => !n.isRead)
    : notifications;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-end select-none">
      <div className="bg-[#0A101C] border-l border-amber-500/30 w-full max-w-sm h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-[#0E1627] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <h2 className="font-bold text-sm text-slate-100">Notification Center</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playClick();
                setShowSettings((p) => !p);
              }}
              title="Notification Settings"
              className={`p-1.5 rounded-lg border transition-colors ${
                showSettings
                  ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                  : 'bg-[#141F33] border-slate-800 text-slate-400'
              }`}
            >
              <Settings className="w-4 h-4" />
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings ? (
          <div className="p-4 flex-1 flex flex-col gap-3 text-xs bg-[#0C1220]">
            <h3 className="font-bold text-slate-200 uppercase text-[11px] tracking-wider mb-1">
              Notification Preferences
            </h3>
            {(
              [
                { key: 'tournamentAlerts', label: 'Tournament Round & Match Alerts' },
                { key: 'matchInvites', label: 'Direct Friend Match Invitations' },
                { key: 'dailyReminder', label: 'Daily Tactical Mission Reminders' },
                { key: 'achievementSounds', label: 'Achievement Sound Effects' },
                { key: 'systemNotices', label: 'Fair Play & Policy Notices' },
              ] as const
            ).map((item) => (
              <label
                key={item.key}
                className="flex items-center justify-between p-2.5 rounded-xl bg-[#111A2D] border border-slate-800 cursor-pointer"
              >
                <span className="text-slate-200 font-medium">{item.label}</span>
                <input
                  type="checkbox"
                  checked={settings[item.key]}
                  onChange={() => handleToggleSetting(item.key)}
                  className="rounded text-amber-500 focus:ring-0 w-4 h-4"
                />
              </label>
            ))}
          </div>
        ) : (
          /* Notifications List */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Filter Sub-header */}
            <div className="px-4 py-2 border-b border-slate-800/80 bg-[#0C1322] flex items-center justify-between text-[11px]">
              <button
                onClick={() => setFilterUnreadOnly((p) => !p)}
                className={`font-semibold px-2 py-0.5 rounded ${
                  filterUnreadOnly ? 'bg-amber-400/20 text-amber-300' : 'text-slate-400'
                }`}
              >
                {filterUnreadOnly ? 'Showing Unread' : 'Showing All'}
              </button>
              <button
                onClick={handleMarkAllRead}
                className="text-amber-400 font-semibold hover:underline"
              >
                Mark all read
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
              {filtered.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs">
                  <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <span>No notifications right now.</span>
                </div>
              ) : (
                filtered.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => {
                      handleMarkAsRead(n.id);
                      if (n.type === 'tournament_start' && onNavigate) onNavigate('tournaments');
                      else if (n.type === 'daily_challenge' && onNavigate) onNavigate('daily_challenges');
                      else if (n.type === 'achievement_unlocked' && onNavigate) onNavigate('progression');
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-1 text-xs ${
                      !n.isRead
                        ? 'bg-[#121D33] border-amber-500/40'
                        : 'bg-[#0E1627] border-slate-800/70 opacity-75'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-1.5 font-bold text-slate-100">
                        {n.type === 'tournament_start' ? (
                          <Trophy className="w-3.5 h-3.5 text-amber-400" />
                        ) : n.type === 'daily_challenge' ? (
                          <Flame className="w-3.5 h-3.5 text-orange-400" />
                        ) : n.type === 'achievement_unlocked' ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Swords className="w-3.5 h-3.5 text-sky-400" />
                        )}
                        <span>{n.title}</span>
                      </div>
                      {!n.isRead && (
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                      )}
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">{n.message}</p>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">
                      {new Date(n.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
