"use client";

import { useEffect, useState } from "react";
import { Button, Card, EmptyState, ErrorCard, Field, Pill, Skeleton, Stat, inputClass } from "@/components/ui";
import { useToast } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { arr, fmtDateTime, fmtPrice, fmtUsd, pnlColor, sideHe, toNum } from "@/lib/format";
import { SYMBOLS } from "@/lib/universe";

type Account = {
  balance: number;
  realizedPnl: number;
  usedMargin: number;
  unrealizedPnl: number;
  equity: number;
  marginUsagePct: number;
};

type Position = {
  id: number;
  symbol: string;
  side: string;
  qty: number;
  entryPrice: number;
  markPrice: number;
  leverage: number;
  margin: number;
  liquidationPrice: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  unrealizedPnl: number;
  unrealizedPnlPct: number;
  source: string;
  openedAt: string;
};

type Order = {
  id: number;
  symbol: string;
  side: string;
  orderType: string;
  status: string;
  qty: number;
  limitPrice: number | null;
  filledPrice: number | null;
  leverage: number;
  createdAt: string;
};

type History = {
  id: number;
  symbol: string;
  side: string;
  entryPrice: number;
  exitPrice: number | null;
  realizedPnl: number | null;
  closeReason: string | null;
  closedAt: string | null;
};

type Resp = {
  ok?: boolean;
  account?: Account;
  positions?: Position[];
  orders?: Order[];
  history?: History[];
  source?: string;
  error?: string | null;
};

const reasonHe: Record<string, string> = {
  STOP_LOSS: "סטופ לוס",
  TAKE_PROFIT: "יעד רווח",
  LIQUIDATION: "לִיקווידציה",
  MANUAL: "סגירה ידנית",
};

export default function PaperTradingScreen() {
  const { toast } = useToast();
  const { data, loading, error, refresh } = useApi<Resp>("/api/paper", { intervalMs: 10000 });
  const [busy, setBusy] = useState(false);
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [side, setSide] = useState<"LONG" | "SHORT">("LONG");
  const [orderType, setOrderType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [notional, setNotional] = useState(500);
  const [leverage, setLeverage] = useState(3);
  const [limitPrice, setLimitPrice] = useState<number | "">("");
  const [stopLoss, setStopLoss] = useState<number | "">("");
  const [takeProfit, setTakeProfit] = useState<number | "">("");
  const [marketPrice, setMarketPrice] = useState(0);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await fetch(`/api/market/depth?symbol=${symbol}`, { cache: "no-store" });
        const json = (await res.json()) as { ticker?: { price?: number } | null };
        if (alive) setMarketPrice(toNum(json?.ticker?.price));
      } catch {
        if (alive) setMarketPrice(0);
      }
    };
    void load();
    const id = setInterval(load, 8000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [symbol]);

  const account = data?.account;
  const positions = arr<Position>(data?.positions);
  const orders = arr<Order>(data?.orders);
  const history = arr<History>(data?.history);
  const pending = orders.filter((o) => o.status === "PENDING");

  const submit = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/paper/order", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "OPEN",
          symbol,
          side,
          orderType,
          notional,
          leverage,
          limitPrice: orderType === "LIMIT" ? Number(limitPrice || marketPrice) : null,
          stopLoss: stopLoss === "" ? null : Number(stopLoss),
          takeProfit: takeProfit === "" ? null : Number(takeProfit),
        }),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "בוצע") : (json.error ?? "שגיאה בביצוע"), json.ok ? "success" : "error");
      await refresh();
    } catch {
      toast("שגיאת תקשורת - נסה שוב", "error");
    } finally {
      setBusy(false);
    }
  };

  const act = async (payload: Record<string, unknown>) => {
    try {
      const res = await fetch("/api/paper/order", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      toast(json.ok ? (json.message ?? "בוצע") : (json.error ?? "שגיאה"), json.ok ? "success" : "error");
      await refresh();
    } catch {
      toast("שגיאת תקשורת", "error");
    }
  };

  if (loading && !account) {
    return (
      <Card title="מסחר דמו / ניסיון">
        <Skeleton rows={5} />
      </Card>
    );
  }

  if (error && !account) return <ErrorCard detail={error} onRetry={() => void refresh()} />;

  return (
    <div className="space-y-4">
      <Card title="חשבון דמו - 10,000$ וירטואלי" subtitle={`ביצוע במחירי שוק אמיתיים · מקור: ${data?.source ?? "—"}`}>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-6">
          <Stat label="יתרה פנויה" value={fmtUsd(account?.balance)} />
          <Stat label="שווי כולל (Equity)" value={fmtUsd(account?.equity)} tone={(account?.equity ?? 0) >= 10000 ? "up" : "down"} />
          <Stat label="מרג'ין בשימוש" value={fmtUsd(account?.usedMargin)} tone="warn" />
          <Stat label="ניצול מרג'ין" value={`${(account?.marginUsagePct ?? 0).toFixed(1)}%`} tone="warn" />
          <Stat label="רווח לא ממומש" value={fmtUsd(account?.unrealizedPnl)} tone={(account?.unrealizedPnl ?? 0) >= 0 ? "up" : "down"} />
          <Stat label="רווח ממומש" value={fmtUsd(account?.realizedPnl)} tone={(account?.realizedPnl ?? 0) >= 0 ? "up" : "down"} />
        </div>
      </Card>

      <Card title="פתיחת פוזיציה חדשה" subtitle={`מחיר שוק נוכחי: ${marketPrice > 0 ? fmtPrice(marketPrice) : "טוען..."}`}>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field label="מטבע">
            <select className={inputClass} value={symbol} onChange={(e) => setSymbol(e.target.value)}>
              {SYMBOLS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </Field>
          <Field label="כיוון">
            <div className="flex gap-2">
              <button
                onClick={() => setSide("LONG")}
                className={`flex-1 rounded-xl px-3 py-2 text-sm font-bold ${side === "LONG" ? "bg-emerald-500 text-slate-950" : "bg-slate-800 text-slate-300"}`}
              >
                לונג
              </button>
              <button
                onClick={() => setSide("SHORT")}
                className={`flex-1 rounded-xl px-3 py-2 text-sm font-bold ${side === "SHORT" ? "bg-rose-500 text-white" : "bg-slate-800 text-slate-300"}`}
              >
                שורט
              </button>
            </div>
          </Field>
          <Field label="סוג פקודה">
            <select className={inputClass} value={orderType} onChange={(e) => setOrderType(e.target.value as "MARKET" | "LIMIT")}>
              <option value="MARKET">מרקט (מיידי)</option>
              <option value="LIMIT">לימיט (ממתינה)</option>
            </select>
          </Field>
          <Field label="שווי פוזיציה ($)">
            <input type="number" className={inputClass} value={notional} onChange={(e) => setNotional(Number(e.target.value))} />
          </Field>
          <Field label={`מינוף: ${leverage}x`}>
            <input
              type="range"
              min={1}
              max={20}
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="w-full accent-sky-500"
            />
          </Field>
          {orderType === "LIMIT" && (
            <Field label="מחיר לימיט">
              <input
                type="number"
                className={inputClass}
                value={limitPrice}
                placeholder={marketPrice ? String(marketPrice) : ""}
                onChange={(e) => setLimitPrice(e.target.value === "" ? "" : Number(e.target.value))}
              />
            </Field>
          )}
          <Field label="סטופ לוס (לא חובה)">
            <input
              type="number"
              className={inputClass}
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value === "" ? "" : Number(e.target.value))}
            />
          </Field>
          <Field label="יעד רווח (לא חובה)">
            <input
              type="number"
              className={inputClass}
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value === "" ? "" : Number(e.target.value))}
            />
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Button onClick={submit} disabled={busy} variant={side === "LONG" ? "success" : "danger"}>
            {busy ? "שולח..." : `פתח ${sideHe(side)} ${orderType === "LIMIT" ? "לימיט" : "מרקט"}`}
          </Button>
          <span className="text-[11px] text-slate-400">
            מרג'ין נדרש: {fmtUsd(notional / Math.max(1, leverage))} · מחיר חיסול משוער:{" "}
            {marketPrice > 0
              ? fmtPrice(side === "LONG" ? marketPrice * (1 - 0.95 / leverage) : marketPrice * (1 + 0.95 / leverage))
              : "—"}
          </span>
        </div>
      </Card>

      <Card title="פוזיציות פתוחות">
        {positions.length === 0 ? (
          <EmptyState text="אין פוזיציות פתוחות כרגע" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-right text-[11px]">
              <thead className="text-slate-400">
                <tr>
                  <th className="p-2">מטבע</th>
                  <th className="p-2">כיוון</th>
                  <th className="p-2">כמות</th>
                  <th className="p-2">כניסה</th>
                  <th className="p-2">מחיר נוכחי</th>
                  <th className="p-2">מינוף</th>
                  <th className="p-2">מרג'ין</th>
                  <th className="p-2">חיסול</th>
                  <th className="p-2">SL / TP</th>
                  <th className="p-2">רווח/הפסד</th>
                  <th className="p-2">מקור</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody className="tabular-nums">
                {positions.map((p) => (
                  <tr key={p.id} className="border-t border-slate-800">
                    <td className="p-2 font-bold text-slate-100">{p.symbol}</td>
                    <td className={`p-2 ${p.side === "LONG" ? "text-emerald-400" : "text-rose-400"}`}>{sideHe(p.side)}</td>
                    <td className="p-2">{p.qty.toFixed(4)}</td>
                    <td className="p-2">{fmtPrice(p.entryPrice)}</td>
                    <td className="p-2">{fmtPrice(p.markPrice)}</td>
                    <td className="p-2">{p.leverage}x</td>
                    <td className="p-2">{fmtUsd(p.margin)}</td>
                    <td className="p-2 text-amber-400">{p.liquidationPrice ? fmtPrice(p.liquidationPrice) : "—"}</td>
                    <td className="p-2 text-slate-400">
                      {p.stopLoss ? fmtPrice(p.stopLoss) : "—"} / {p.takeProfit ? fmtPrice(p.takeProfit) : "—"}
                    </td>
                    <td className={`p-2 font-bold ${pnlColor(p.unrealizedPnl)}`}>
                      {fmtUsd(p.unrealizedPnl)} ({p.unrealizedPnlPct.toFixed(1)}%)
                    </td>
                    <td className="p-2">
                      <Pill tone={p.source === "COPY" ? "violet" : p.source === "SIGNAL" ? "sky" : "slate"}>
                        {p.source === "COPY" ? "חיקוי" : p.source === "SIGNAL" ? "אות AI" : "ידני"}
                      </Pill>
                    </td>
                    <td className="p-2">
                      <button
                        onClick={() => void act({ action: "CLOSE", positionId: p.id })}
                        className="rounded-lg bg-slate-800 px-2 py-1 text-[10px] text-slate-200 hover:bg-slate-700"
                      >
                        סגור
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card title="פקודות ממתינות (לימיט)">
        {pending.length === 0 ? (
          <EmptyState text="אין פקודות ממתינות" />
        ) : (
          <ul className="space-y-2">
            {pending.map((o) => (
              <li key={o.id} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/60 p-2 text-[11px]">
                <span className="font-bold text-slate-100">
                  {o.symbol} · {sideHe(o.side)} · לימיט {fmtPrice(o.limitPrice)} · {o.leverage}x
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">{fmtDateTime(o.createdAt)}</span>
                  <button
                    onClick={() => void act({ action: "CANCEL", orderId: o.id })}
                    className="rounded-lg bg-rose-500/20 px-2 py-1 text-rose-300 hover:bg-rose-500/30"
                  >
                    בטל
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="היסטוריית עסקאות">
        {history.length === 0 ? (
          <EmptyState text="עדיין לא נסגרו עסקאות" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-right text-[11px]">
              <thead className="text-slate-400">
                <tr>
                  <th className="p-2">מטבע</th>
                  <th className="p-2">כיוון</th>
                  <th className="p-2">כניסה</th>
                  <th className="p-2">יציאה</th>
                  <th className="p-2">תוצאה</th>
                  <th className="p-2">סיבת סגירה</th>
                  <th className="p-2">נסגר</th>
                </tr>
              </thead>
              <tbody className="tabular-nums">
                {history.map((h) => (
                  <tr key={h.id} className="border-t border-slate-800">
                    <td className="p-2 font-bold text-slate-100">{h.symbol}</td>
                    <td className="p-2">{sideHe(h.side)}</td>
                    <td className="p-2">{fmtPrice(h.entryPrice)}</td>
                    <td className="p-2">{fmtPrice(h.exitPrice)}</td>
                    <td className={`p-2 font-bold ${pnlColor(h.realizedPnl)}`}>{fmtUsd(h.realizedPnl)}</td>
                    <td className="p-2 text-slate-400">{reasonHe[String(h.closeReason)] ?? "—"}</td>
                    <td className="p-2 text-slate-500">{fmtDateTime(h.closedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
