import React, { useState } from 'react';
import {
  ShieldCheck,
  Building,
  Users,
  CheckCircle,
  XCircle,
  ArrowLeft,
  Settings,
  Plus,
  Edit,
  Eye,
  Calendar,
  X,
  AlertCircle,
  Clock,
  RefreshCw,
  QrCode,
} from 'lucide-react';
import { Store, ScreenType, SomaliCurrency, StoreTier } from '../../types';
import { formatPrice } from '../../data/mockData';

interface SuperAdminScreenProps {
  stores: Store[];
  currency: SomaliCurrency;
  onCreateStore: (newStore: Store) => void;
  onUpdateStore: (updatedStore: Store) => void;
  onApproveStore: (storeId: string, operatingDays: number, customCode?: string) => void;
  onToggleStoreVerification: (storeId: string) => void;
  onPreviewStore: (store: Store) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const SuperAdminScreen: React.FC<SuperAdminScreenProps> = ({
  stores,
  currency,
  onCreateStore,
  onUpdateStore,
  onApproveStore,
  onToggleStoreVerification,
  onPreviewStore,
  onNavigate,
}) => {
  const [commissionRate, setCommissionRate] = useState(2.5);

  // Create store modal
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createStoreCode, setCreateStoreCode] = useState('DUK-301');
  const [createName, setCreateName] = useState('');
  const [createAdmin, setCreateAdmin] = useState('');
  const [createPhone, setCreatePhone] = useState('+252 ');
  const [createCity, setCreateCity] = useState('Muqdisho');
  const [createCategory, setCreateCategory] = useState('Elektaroonig');
  const [createType, setCreateType] = useState<StoreTier>('large');
  const [createDays, setCreateDays] = useState(90);

  // Edit store modal
  const [editingStore, setEditingStore] = useState<Store | null>(null);

  // Approve store modal
  const [approvingStore, setApprovingStore] = useState<Store | null>(null);
  const [approveStoreCode, setApproveStoreCode] = useState('');
  const [approveDays, setApproveDays] = useState(60);

  const generateRandomStoreCode = () => `DUK-${Math.floor(200 + Math.random() * 799)}`;

  const totalGmv = 124800;
  const platformRevenue = totalGmv * (commissionRate / 100);

  const pendingStores = stores.filter((s) => s.isPendingApproval);
  const activeStores = stores.filter((s) => !s.isPendingApproval);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createName || !createAdmin) return;

    const assignedCode = createStoreCode.trim().toUpperCase() || generateRandomStoreCode();

    const newStore: Store = {
      id: `store-${Date.now()}`,
      storeCode: assignedCode,
      name: createName,
      adminName: createAdmin,
      phone: createPhone,
      password: 'default123',
      city: createCity,
      category: createCategory,
      storeType: createType,
      operatingDays: createDays,
      rating: 5.0,
      salesCount: 0,
      followersCount: 0,
      isVerified: true,
      isPendingApproval: false,
      avatar: createName.substring(0, 2).toUpperCase(),
      description: `Dukaanka ${createName} oo uu maamulo ${createAdmin}.`,
      employees: [],
    };

    onCreateStore(newStore);
    setIsCreateOpen(false);
    setCreateName('');
    setCreateAdmin('');
    setCreateStoreCode(generateRandomStoreCode());
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStore) return;
    onUpdateStore({
      ...editingStore,
      storeCode: editingStore.storeCode.trim().toUpperCase(),
    });
    setEditingStore(null);
  };

  const handleApproveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!approvingStore) return;
    const finalCode = approveStoreCode.trim().toUpperCase() || approvingStore.storeCode;
    onApproveStore(approvingStore.id, approveDays, finalCode);
    setApprovingStore(null);
  };

  return (
    <div className="min-h-full pb-20 bg-slate-900 text-slate-100 select-none">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('welcome')}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <span className="font-bold text-sm text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              Maamulka Sare (Super Admin)
            </span>
            <span className="text-[11px] text-slate-400">
              Xafiiska Maamulka & Dukaamada
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCreateOpen(true)}
            className="py-1.5 px-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Abuuro Dukaan Cusub</span>
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-4xl mx-auto">
        {/* KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80">
            <span className="text-[11px] text-slate-400">Dakhliga Guud (GMV)</span>
            <div className="text-base sm:text-lg font-bold text-white mt-1 tabular-nums">
              {formatPrice(totalGmv, currency)}
            </div>
            <span className="text-[10px] text-emerald-400">Suuqa oo dhan</span>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80">
            <span className="text-[11px] text-slate-400">Komishanka ({commissionRate}%)</span>
            <div className="text-base sm:text-lg font-bold text-teal-300 mt-1 tabular-nums">
              {formatPrice(platformRevenue, currency)}
            </div>
            <span className="text-[10px] text-teal-400">Dakhliga shirkadda</span>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80">
            <span className="text-[11px] text-slate-400">Dukaamada Firfircoon</span>
            <div className="text-base sm:text-lg font-bold text-white mt-1 tabular-nums">
              {activeStores.length} Dukaan
            </div>
            <span className="text-[10px] text-slate-400">
              {pendingStores.length > 0 ? `${pendingStores.length} ayaa sugaya` : 'Dhammaan waa xaqiijisan'}
            </span>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80">
            <span className="text-[11px] text-slate-400">Macaamiisha</span>
            <div className="text-base sm:text-lg font-bold text-white mt-1 tabular-nums">
              3,892
            </div>
            <span className="text-[10px] text-emerald-400">EVC / Zaad</span>
          </div>
        </div>

        {/* 1. DUKAAMADA SUGAYA OGGOLAANSHAHA (Pending Approval & Operating Days Allocation) */}
        {pendingStores.length > 0 && (
          <div className="bg-amber-950/40 border border-amber-600/40 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs sm:text-sm font-bold text-amber-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-400" />
                Dukaamada Cusub ee Soo Dalbaday ({pendingStores.length})
              </h3>
              <span className="text-[11px] text-amber-400/80">
                Oggolow oo u qoondee maalmaha uu shaqaynayo
              </span>
            </div>

            <div className="space-y-2">
              {pendingStores.map((st) => (
                <div
                  key={st.id}
                  className="bg-slate-800/90 p-3 rounded-xl border border-amber-500/30 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">
                        {st.name}
                      </span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-medium">
                        Codsade Cusub
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {st.storeType === 'large' ? 'Dukaan Weyn' : 'Dukaan Yar'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Adminka: <b>{st.adminName}</b> · Tel: {st.phone} · Magaalada: {st.city}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onPreviewStore(st)}
                      className="px-2.5 py-1 rounded-lg text-xs bg-slate-700 hover:bg-slate-600 text-teal-300 flex items-center gap-1 cursor-pointer"
                      title="Kormeer dukaankan khalad ma ku jiro"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview</span>
                    </button>
                    <button
                      onClick={() => {
                        setApprovingStore(st);
                        setApproveDays(st.operatingDays || 60);
                        setApproveStoreCode(st.storeCode || generateRandomStoreCode());
                      }}
                      className="px-3 py-1 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow cursor-pointer"
                    >
                      Aqbal & Maalmo U Dar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2. ACTIVE STORES LIST (Edit, Preview, Operating Days, Verification) */}
        <div className="bg-slate-800/60 rounded-2xl p-4 border border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
              <Building className="w-4 h-4 text-teal-400" />
              Dhammaan Dukaamada Diiwaangashan ({activeStores.length})
            </h3>
            <span className="text-[11px] text-slate-400">
              Guji <b>Preview</b> si aad u kormeerto ama <b>Edit</b> si aad wax uga beddesho
            </span>
          </div>

          <div className="space-y-2">
            {activeStores.map((st) => (
              <div
                key={st.id}
                className="bg-slate-800 p-3 rounded-xl border border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">
                      {st.name}
                    </span>
                    {st.storeType === 'large' ? (
                      <span className="text-[10px] bg-teal-500/20 text-teal-300 px-1.5 py-0.2 rounded border border-teal-500/30">
                        Dukaan Weyn ({st.employees?.length || 0} Shaqaale)
                      </span>
                    ) : (
                      <span className="text-[10px] bg-slate-700 text-slate-300 px-1.5 py-0.2 rounded">
                        Dukaan Yar
                      </span>
                    )}
                    <span className="text-[10px] bg-slate-700/80 text-teal-300 px-1.5 py-0.2 rounded font-mono">
                      {st.operatingDays} Maalmood
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Adminka: <b>{st.adminName}</b> · Tel: {st.phone} · {st.city} · {st.followersCount} Macmiil
                  </span>
                </div>

                <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                  {/* PREVIEW BUTTON (Kormeer Dukaan si khalad loogu baaro) */}
                  <button
                    onClick={() => onPreviewStore(st)}
                    className="px-2.5 py-1 text-xs rounded-lg bg-teal-950 text-teal-300 border border-teal-700/60 hover:bg-teal-900 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Kormeer dukaankan sida macmiilku u arko"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Preview</span>
                  </button>

                  {/* EDIT BUTTON (Edit ku sameyn karo) */}
                  <button
                    onClick={() => setEditingStore({ ...st })}
                    className="px-2.5 py-1 text-xs rounded-lg bg-slate-700 text-slate-200 hover:bg-slate-600 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Wax ka beddel dukaankan"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>

                  {/* STATUS TOGGLE */}
                  <button
                    onClick={() => onToggleStoreVerification(st.id)}
                    className={`px-2.5 py-1 text-xs rounded-lg font-semibold transition-colors cursor-pointer ${
                      st.isVerified
                        ? 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {st.isVerified ? 'Haki' : 'Oggolow'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. PLATFORM SETTINGS */}
        <div className="bg-slate-800/60 rounded-2xl p-4 border border-slate-700 space-y-3">
          <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
            <Settings className="w-4 h-4 text-teal-400" />
            Dejinta Komishanka Suuqa (Commission Rate)
          </h3>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0.5"
              max="5.0"
              step="0.1"
              value={commissionRate}
              onChange={(e) => setCommissionRate(parseFloat(e.target.value))}
              className="flex-1 accent-teal-400 cursor-pointer"
            />
            <span className="text-sm font-bold text-teal-300 font-mono w-14">
              {commissionRate.toFixed(1)}%
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Boqolkiiba {commissionRate}% ayaa laga jarayaa dalab kasta oo lagu bixiyo EVC Plus / Zaad.
          </p>
        </div>
      </div>

      {/* Modal: Create New Store (Abuuro Dukaan Cusub) */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-5 shadow-2xl text-slate-100">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-teal-400" />
                Abuuro Dukaan Cusub
              </h3>
              <button
                onClick={() => setIsCreateOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3 mt-3 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-semibold">
                    Aqoonsiga Dukaanka (Store Code / ID)
                  </label>
                  <button
                    type="button"
                    onClick={() => setCreateStoreCode(generateRandomStoreCode())}
                    className="text-[11px] text-teal-400 hover:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Abuur ID Cusub</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={createStoreCode}
                  onChange={(e) => setCreateStoreCode(e.target.value.toUpperCase())}
                  placeholder="Tusaale: DUK-301 ama DUK-999"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono uppercase focus:outline-none focus:border-teal-400"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Super Adminku wuxuu qori karaa aqoonsi kasta oo uu rabo ama guji "Abuur ID Cusub".
                </span>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Magaca Dukaanka
                </label>
                <input
                  type="text"
                  required
                  value={createName}
                  onChange={(e) => setCreateName(e.target.value)}
                  placeholder="Tusaale: Somaliland Tech Mart"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Magaca Adminka
                  </label>
                  <input
                    type="text"
                    required
                    value={createAdmin}
                    onChange={(e) => setCreateAdmin(e.target.value)}
                    placeholder="Magaca maamulaha"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Telefoonka (ID)
                  </label>
                  <input
                    type="text"
                    required
                    value={createPhone}
                    onChange={(e) => setCreatePhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Nooca Dukaanka
                  </label>
                  <select
                    value={createType}
                    onChange={(e) => setCreateType(e.target.value as StoreTier)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  >
                    <option value="large">Dukaan Weyn (Shaqaale leh)</option>
                    <option value="small">Dukaan Yar (Kaliya Admin)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Maalmaha Shaqada
                  </label>
                  <input
                    type="number"
                    value={createDays}
                    onChange={(e) => setCreateDays(parseInt(e.target.value) || 30)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Magaalada
                  </label>
                  <select
                    value={createCity}
                    onChange={(e) => setCreateCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  >
                    <option value="Muqdisho">Muqdisho</option>
                    <option value="Hargeysa">Hargeysa</option>
                    <option value="Garoowe">Garoowe</option>
                    <option value="Boosaaso">Boosaaso</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Qaybta
                  </label>
                  <select
                    value={createCategory}
                    onChange={(e) => setCreateCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  >
                    <option value="Elektaroonig">Elektaroonig</option>
                    <option value="Dharka & Moodada">Dharka & Moodada</option>
                    <option value="Raashinka & Uunsiga">Raashinka & Uunsiga</option>
                    <option value="Qalabka Guriga">Qalabka Guriga</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 font-bold text-white transition-colors cursor-pointer mt-2"
              >
                Dhis & Diiwaangeli Dukaanka
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Existing Store (Edit ku sameyn karo) */}
      {editingStore && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-5 shadow-2xl text-slate-100">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                <Edit className="w-4 h-4 text-teal-400" />
                Wax ka Beddel Dukaanka (Edit Store)
              </h3>
              <button
                onClick={() => setEditingStore(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3 mt-3 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-semibold">
                    Aqoonsiga Dukaanka (Store Code / ID)
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingStore({
                        ...editingStore,
                        storeCode: generateRandomStoreCode(),
                      })
                    }
                    className="text-[11px] text-teal-400 hover:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Beddel ID Cusub</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={editingStore.storeCode}
                  onChange={(e) =>
                    setEditingStore({
                      ...editingStore,
                      storeCode: e.target.value.toUpperCase(),
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono uppercase focus:outline-none focus:border-teal-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Magaca Dukaanka
                </label>
                <input
                  type="text"
                  required
                  value={editingStore.name}
                  onChange={(e) =>
                    setEditingStore({ ...editingStore, name: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Magaca Adminka
                  </label>
                  <input
                    type="text"
                    required
                    value={editingStore.adminName}
                    onChange={(e) =>
                      setEditingStore({ ...editingStore, adminName: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Telefoonka (ID)
                  </label>
                  <input
                    type="text"
                    required
                    value={editingStore.phone}
                    onChange={(e) =>
                      setEditingStore({ ...editingStore, phone: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Nooca Dukaanka
                  </label>
                  <select
                    value={editingStore.storeType}
                    onChange={(e) =>
                      setEditingStore({
                        ...editingStore,
                        storeType: e.target.value as StoreTier,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400"
                  >
                    <option value="large">Dukaan Weyn (Shaqaale leh)</option>
                    <option value="small">Dukaan Yar (Kaliya Admin)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Maalmaha Shaqada (Days)
                  </label>
                  <input
                    type="number"
                    value={editingStore.operatingDays}
                    onChange={(e) =>
                      setEditingStore({
                        ...editingStore,
                        operatingDays: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-teal-400 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 font-bold text-white transition-colors cursor-pointer mt-2"
              >
                Cusboonaysii Dukaanka (Save Changes)
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Approve Store & Allocate Operating Days */}
      {approvingStore && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-2xl p-5 shadow-2xl text-slate-100">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-emerald-400 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" />
                Aqbal Dukaanka: {approvingStore.name}
              </h3>
              <button
                onClick={() => setApprovingStore(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleApproveSubmit} className="space-y-3 mt-3 text-xs">
              <p className="text-slate-300">
                U qoondee aqoonsiga iyo inta maalmood ee uu dukaankan shaqeynayo:
              </p>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-semibold">
                    Aqoonsiga Dukaanka (Store Code)
                  </label>
                  <button
                    type="button"
                    onClick={() => setApproveStoreCode(generateRandomStoreCode())}
                    className="text-[11px] text-teal-400 hover:text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Abuur Cusub</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={approveStoreCode}
                  onChange={(e) => setApproveStoreCode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono uppercase focus:outline-none focus:border-teal-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Maalmaha Shaqada (Operating Days)
                </label>
                <select
                  value={approveDays}
                  onChange={(e) => setApproveDays(parseInt(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono text-sm"
                >
                  <option value={30}>30 Maalmood (1 Bil)</option>
                  <option value={60}>60 Maalmood (2 Bilood)</option>
                  <option value={90}>90 Maalmood (3 Bilood)</option>
                  <option value={180}>180 Maalmood (6 Bilood)</option>
                  <option value={365}>365 Maalmood (1 Sano)</option>
                </select>
              </div>

              <div className="p-2.5 bg-slate-800 rounded-lg text-[11px] text-slate-400">
                Marka aad gujiso "Xaqiiji & Fur Dukaanka", dukaanku wuxuu toos ugu biirayaa suuqa macmiilka.
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-white transition-colors cursor-pointer"
              >
                Xaqiiji & Fur Dukaanka
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
