"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { Icon } from "@/components/ui/Icon";
import { Btn, Card, Chip, Screen, SectionTitle } from "@/components/ui/primitives";
import { Donut, ExtremeRow, MonthBars } from "@/components/ui/charts";
import { useApp } from "@/lib/store";
import { monthLabel, monthShort } from "@/lib/calendar";
import type { DataPayload } from "@/lib/types";

type Focus = "spend" | "earn";

export function InsightsScreen() {
  const { data, setTab } = useApp();
  if (!data) return <div className="h-full" />;
  return <InsightsBody data={data} onBack={() => setTab("home")} />;
}

function InsightsBody({ data, onBack }: { data: DataPayload; onBack: () => void }) {
  const { money, short, profile } = useApp();
  const [focus, setFocus] = useState<Focus>("spend");
  const { stats } = data;
  const kind = focus === "spend" ? stats.spend : stats.earn;
  const lastMonth = stats.months[stats.months.length - 2];
  const thisMonth = stats.months[stats.months.length - 1];
  const delta =
    lastMonth && lastMonth.spend > 0
      ? Math.round(((thisMonth!.spend - lastMonth.spend) / lastMonth.spend) * 100)
      : 0;

  async function copySummary() {
    const lines = [
      `Keep Tracked summary — ${profile?.username ?? ""}`,
      `Balance: ${money(stats.balance)}`,
      `All-time earnings: ${money(stats.totalEarn)} · spendings: ${money(stats.totalSpend)}`,
      `Most spent day: ${stats.spend.maxDay ? `${stats.spend.maxDay.label} (${money(stats.spend.maxDay.amount)})` : "—"}`,
      `Least spent day: ${stats.spend.minDay ? `${stats.spend.minDay.label} (${money(stats.spend.minDay.amount)})` : "—"}`,
      `Most spent month: ${stats.spend.maxMonth ? `${stats.spend.maxMonth.label} (${money(stats.spend.maxMonth.amount)})` : "—"}`,
      `Average daily spend: ${money(stats.spend.avgDay)} · average monthly spend: ${money(stats.spend.avgMonth)}`,
      `Best earning day: ${stats.earn.maxDay ? `${stats.earn.maxDay.label} (${money(stats.earn.maxDay.amount)})` : "—"}`,
      `Best earning month: ${stats.earn.maxMonth ? `${stats.earn.maxMonth.label} (${money(stats.earn.maxMonth.amount)})` : "—"}`,
      `Average daily earning: ${money(stats.earn.avgDay)} · average monthly earning: ${money(stats.earn.avgMonth)}`,
    ];
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      const { pushToast } = await import("@/lib/toast");
      pushToast("Summary copied to clipboard");
    } catch {
      const { pushToast } = await import("@/lib/toast");
      pushToast("Clipboard blocked by browser", "error");
    }
  }

  return (
    <Screen
      title="Insights"
      subtitle={`${stats.spanDays} tracked days · ${stats.count} entries`}
      onBack={onBack}
      right={<Btn size="sm" variant="soft" icon="download" onClick={copySummary}>Copy</Btn>}
    >
      <div className="space-y-5 px-4 pb-8 pt-4">
        <div className="relative flex rounded-2xl border border-line bg-surface2 p-1">
          {(
            [
              ["spend", "Spendings", "down"],
              ["earn", "Earnings", "up"],
            ] as [Focus, string, "down" | "up"][]
          ).map(([v, label, icon]) => {
            const active = focus === v;
            return (
              <button
                key={v}
                onClick={() => setFocus(v)}
                className={`press relative z-10 flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-[13px] font-bold transition-colors ${
                  active ? "text-brandink" : "text-ink2"
                }`}
              >
                {active ? (
                  <motion.span
                    layoutId="insights-focus"
                    transition={{ type: "spring", stiffness: 480, damping: 38 }}
                    className="absolute inset-0 z-[-1] rounded-xl bg-brand"
                  />
                ) : null}
                <Icon name={icon} size={15} />
                {label}
              </button>
            );
          })}
        </div>

        <Card className="flex items-center gap-4 p-4">
          <span
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border"
            style={{
              color: focus === "earn" ? "var(--c-earn)" : "var(--c-spend)",
              borderColor: `color-mix(in oklab, ${focus === "earn" ? "var(--c-earn)" : "var(--c-spend)"} 32%, transparent)`,
              background: `color-mix(in oklab, ${focus === "earn" ? "var(--c-earn)" : "var(--c-spend)"} 12%, transparent)`,
            }}
          >
            <Icon name={focus === "earn" ? "up" : "down"} size={22} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink3">
              total {focus === "earn" ? "earned" : "spent"} · all time
            </p>
            <p className="tnum font-display text-[28px] font-extrabold leading-none tracking-[-0.04em]">
              {money(kind.total)}
            </p>
            <p className="mt-1 text-[11.5px] text-ink2">
              across {kind.activeDays} day{kind.activeDays === 1 ? "" : "s"} and {kind.activeMonths} month
              {kind.activeMonths === 1 ? "" : "s"}
            </p>
          </div>
        </Card>

        <section>
          <SectionTitle>the extremes · {focus === "earn" ? "earnings" : "spendings"}</SectionTitle>
          <div className="grid grid-cols-1 gap-2">
            <ExtremeRow
              icon="flame"
              label={`most ${focus === "earn" ? "earned" : "spent"} day`}
              value={kind.maxDay ? `${money(kind.maxDay.amount)}` : "—"}
              sub={kind.maxDay?.label}
              tone={focus}
            />
            <ExtremeRow
              icon="droplet"
              label={`least ${focus === "earn" ? "earned" : "spent"} day`}
              value={kind.minDay ? `${money(kind.minDay.amount)}` : "—"}
              sub={kind.minDay?.label}
              tone="neutral"
            />
            <ExtremeRow
              icon="target"
              label="average per day"
              value={money(kind.avgDay)}
              sub={`over ${stats.spanDays}d`}
              tone="bill"
            />
            <ExtremeRow
              icon="clock"
              label="average per active day"
              value={money(kind.avgActiveDay)}
              sub={`${kind.activeDays}d`}
              tone="neutral"
            />
            <ExtremeRow
              icon="chart"
              label={`biggest ${focus === "earn" ? "earning" : "spending"} month`}
              value={kind.maxMonth ? money(kind.maxMonth.amount) : "—"}
              sub={kind.maxMonth ? monthLabel(kind.maxMonth.key, "short") : undefined}
              tone={focus}
            />
            <ExtremeRow
              icon="chart"
              label={`smallest ${focus === "earn" ? "earning" : "spending"} month`}
              value={kind.minMonth ? money(kind.minMonth.amount) : "—"}
              sub={kind.minMonth ? monthLabel(kind.minMonth.key, "short") : undefined}
              tone="neutral"
            />
            <ExtremeRow
              icon="coins"
              label="average per month"
              value={money(kind.avgMonth)}
              sub={`${kind.activeMonths} mo`}
              tone="bill"
            />
          </div>
        </section>

        <section>
          <SectionTitle
            action={
              <span className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-ink3">
                6 months
              </span>
            }
          >
            month by month
          </SectionTitle>
          <Card className="p-4">
            <MonthBars months={stats.months} currency={data.profile.currency} />
          </Card>
        </section>

        <section>
          <SectionTitle>where it goes · categories</SectionTitle>
          <Card className="p-4">
            <Donut
              slices={kind.byCategory}
              currency={data.profile.currency}
              centerLabel={focus === "earn" ? "earned" : "spent"}
              centerValue={short(kind.total)}
            />
          </Card>
        </section>

        <section>
          <SectionTitle>this month vs last</SectionTitle>
          <Card className="p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
                  {thisMonth ? monthLabel(thisMonth.month) : ""} spend
                </p>
                <p className="tnum font-display text-[24px] font-extrabold tracking-[-0.03em] text-spend">
                  {money(stats.monthSpend)}
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
                  projected at 30 days
                </p>
                <p className="tnum font-display text-[20px] font-extrabold tracking-[-0.03em]">
                  {money(stats.monthPace)}
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Chip tone={delta <= 0 ? "earn" : "spend"} icon={delta <= 0 ? "down" : "up"}>
                {delta > 0 ? "+" : ""}
                {delta}% vs {lastMonth ? monthShort(lastMonth.month) : "last month"}
              </Chip>
              <Chip tone="neutral" icon="wallet">
                {money(stats.monthEarn)} earned this month
              </Chip>
            </div>
          </Card>
        </section>

        <section>
          <SectionTitle>net flow highlights</SectionTitle>
          <div className="grid grid-cols-2 gap-2">
            <Card className="p-3">
              <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink3">best day</p>
              <p className="tnum mt-1 font-display text-[19px] font-extrabold tracking-[-0.03em] text-earn">
                {stats.bestDay ? money(stats.bestDay.amount, { sign: true }) : "—"}
              </p>
              <p className="mt-0.5 truncate text-[11px] text-ink2">{stats.bestDay?.label ?? "no data"}</p>
            </Card>
            <Card className="p-3">
              <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink3">toughest day</p>
              <p className="tnum mt-1 font-display text-[19px] font-extrabold tracking-[-0.03em] text-spend">
                {stats.worstDay ? money(stats.worstDay.amount, { sign: true }) : "—"}
              </p>
              <p className="mt-0.5 truncate text-[11px] text-ink2">{stats.worstDay?.label ?? "no data"}</p>
            </Card>
          </div>
        </section>

        <section>
          <SectionTitle>auto notes</SectionTitle>
          <div className="space-y-2">
            {stats.insights.map((ins, i) => (
              <motion.div
                key={ins.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ delay: Math.min(i * 0.04, 0.3), type: "spring", stiffness: 300, damping: 28 }}
                className="card flex items-start gap-3 p-3.5"
              >
                <span
                  className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl border"
                  style={{
                    color:
                      ins.tone === "earn"
                        ? "var(--c-earn)"
                        : ins.tone === "spend"
                          ? "var(--c-spend)"
                          : "var(--c-brand-text)",
                    borderColor: `color-mix(in oklab, ${
                      ins.tone === "earn"
                        ? "var(--c-earn)"
                        : ins.tone === "spend"
                          ? "var(--c-spend)"
                          : "var(--c-brand)"
                    } 30%, transparent)`,
                    background: `color-mix(in oklab, ${
                      ins.tone === "earn"
                        ? "var(--c-earn)"
                        : ins.tone === "spend"
                          ? "var(--c-spend)"
                          : "var(--c-brand)"
                    } 10%, transparent)`,
                  }}
                >
                  <Icon
                    name={ins.tone === "earn" ? "up" : ins.tone === "spend" ? "down" : "spark"}
                    size={15}
                  />
                </span>
                <div className="min-w-0">
                  <p className="font-display text-[13.5px] font-bold">{ins.title}</p>
                  <p className="mt-0.5 text-[12px] leading-relaxed text-ink2">{ins.body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </Screen>
  );
}
