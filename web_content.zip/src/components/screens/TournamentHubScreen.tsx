import React, { useState } from 'react';
import {
  ChevronLeft,
  Trophy,
  Users,
  Clock,
  Swords,
  Plus,
  ShieldCheck,
  CheckCircle2,
  Play,
  RotateCcw,
  Sparkles,
  Search,
  Filter,
} from 'lucide-react';
import { sound } from '../../services/sound';
import { tournamentService } from '../../services/tournamentService';
import {
  TournamentItem,
  TournamentFormat,
  TournamentPairingResult,
} from '../../types/chess';

interface TournamentHubScreenProps {
  userProfile: { id: string; name: string; rating: number; avatar?: string };
  onBack: () => void;
  onLaunchTournamentMatch: (params: {
    tournamentId: string;
    pairingId: string;
    opponentName: string;
    opponentRating: number;
    playerSide: 'w' | 'b';
    timeControlSeconds: number;
    incrementSeconds: number;
  }) => void;
}

export const TournamentHubScreen: React.FC<TournamentHubScreenProps> = ({
  userProfile,
  onBack,
  onLaunchTournamentMatch,
}) => {
  const [tournaments, setTournaments] = useState<TournamentItem[]>(() =>
    tournamentService.getAllTournaments()
  );
  const [filterFormat, setFilterFormat] = useState<TournamentFormat | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTournament, setSelectedTournament] = useState<TournamentItem | null>(null);
  const [activeTab, setActiveTab] = useState<'standings' | 'pairings' | 'roster' | 'bracket'>('standings');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Tournament Form State
  const [newTitle, setNewTitle] = useState('');
  const [newFormat, setNewFormat] = useState<TournamentFormat>('swiss');
  const [newTimeControl, setNewTimeControl] = useState<'bullet' | 'blitz' | 'rapid'>('blitz');
  const [newRounds, setNewRounds] = useState(5);
  const [newMaxPlayers, setNewMaxPlayers] = useState(16);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage((curr) => (curr === msg ? null : curr)), 3200);
  };

  const reloadData = () => {
    const list = tournamentService.getAllTournaments();
    setTournaments(list);
    if (selectedTournament) {
      const updated = tournamentService.getTournamentById(selectedTournament.id);
      if (updated) setSelectedTournament({ ...updated });
    }
  };

  const handleRegister = (t: TournamentItem) => {
    sound.playClick();
    const res = tournamentService.registerPlayer(t.id, userProfile);
    showToast(res.message);
    if (res.success) reloadData();
  };

  const handleWithdraw = (t: TournamentItem) => {
    sound.playClick();
    const res = tournamentService.withdrawPlayer(t.id, userProfile.id);
    showToast(res.message);
    if (res.success) reloadData();
  };

  const handleStartTournament = (t: TournamentItem) => {
    sound.playClick();
    const res = tournamentService.startTournament(t.id);
    showToast(res.message);
    if (res.success) {
      reloadData();
      setActiveTab('pairings');
    }
  };

  const handleAdvanceRound = (t: TournamentItem) => {
    sound.playClick();
    const res = tournamentService.advanceNextRound(t.id);
    showToast(res.message);
    if (res.success) reloadData();
  };

  const handleSimulateResult = (pairingId: string, result: TournamentPairingResult) => {
    if (!selectedTournament) return;
    sound.playMove();
    tournamentService.submitPairingResult(selectedTournament.id, pairingId, result);
    reloadData();
  };

  const handleCreateTournament = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    sound.playClick();
    const initialSecs = newTimeControl === 'bullet' ? 120 : newTimeControl === 'blitz' ? 300 : 600;
    const increment = newTimeControl === 'bullet' ? 1 : 0;

    const created = tournamentService.createTournament({
      title: newTitle,
      description: `${newFormat.toUpperCase()} tournament organized by ${userProfile.name}.`,
      format: newFormat,
      organizerId: userProfile.id,
      organizerName: userProfile.name,
      timeControlType: newTimeControl,
      initialSeconds: initialSecs,
      incrementSeconds: increment,
      maxParticipants: newMaxPlayers,
      totalRounds: newRounds,
      isRated: true,
      isPrivate: false,
    });

    setShowCreateModal(false);
    setNewTitle('');
    reloadData();
    setSelectedTournament(created);
    showToast('Tournament created successfully!');
  };

  const filteredTournaments = tournaments.filter((t) => {
    const matchesFormat = filterFormat === 'all' || t.format === filterFormat;
    const matchesQuery = t.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFormat && matchesQuery;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#070B13] via-[#0C1220] to-[#05080E] text-slate-100 flex flex-col font-['Outfit',sans-serif] select-none pb-24">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-2xl bg-amber-500 text-slate-950 font-bold text-sm shadow-2xl flex items-center gap-2 border border-amber-300 animate-in fade-in slide-in-from-top-4">
          <Sparkles className="w-4 h-4 fill-current" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="px-5 pt-8 pb-4 border-b border-slate-800/60 bg-[#090F1C]/80 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              sound.playClick();
              if (selectedTournament) setSelectedTournament(null);
              else onBack();
            }}
            className="w-10 h-10 rounded-xl bg-[#121B2F] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h1 className="text-lg font-bold tracking-wide text-slate-100">
              {selectedTournament ? selectedTournament.title : 'Competitive Tournaments'}
            </h1>
            <p className="text-[11px] text-amber-400 font-medium">
              {selectedTournament
                ? `${selectedTournament.format.toUpperCase()} • Round ${selectedTournament.currentRound} of ${selectedTournament.totalRounds}`
                : 'FIDE Swiss • Lightning Arena • Knockouts'}
            </p>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              setShowCreateModal(true);
            }}
            title="Create Custom Tournament"
            className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 hover:bg-amber-500/30"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-2xl mx-auto w-full px-4 pt-4 flex-1 flex flex-col gap-4">
        {!selectedTournament ? (
          /* 1. TOURNAMENT DISCOVERY LIST */
          <>
            {/* Search and Filters */}
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search tournaments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#101726] border border-slate-800 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-400/60"
                />
              </div>
            </div>

            {/* Format Filter Chips */}
            <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
              {(['all', 'swiss', 'arena', 'single_elimination'] as const).map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => {
                    sound.playClick();
                    setFilterFormat(fmt);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl font-semibold capitalize whitespace-nowrap border transition-all ${
                    filterFormat === fmt
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                      : 'bg-[#101726] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {fmt === 'single_elimination' ? 'Knockout' : fmt}
                </button>
              ))}
            </div>

            {/* Tournament Cards */}
            <div className="flex flex-col gap-3">
              {filteredTournaments.map((t) => {
                const isRegistered = t.participants.some((p) => p.playerId === userProfile.id);
                const isLive = t.status === 'live';

                return (
                  <div
                    key={t.id}
                    onClick={() => {
                      sound.playClick();
                      setSelectedTournament(t);
                    }}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col gap-3 group ${
                      isLive
                        ? 'bg-gradient-to-br from-[#121E36] to-[#0A111E] border-amber-500/40 shadow-lg shadow-amber-500/5'
                        : 'bg-[#0E1524] border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                              isLive
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 animate-pulse'
                                : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            {t.status}
                          </span>
                          <span className="text-[11px] font-mono font-semibold text-slate-400 uppercase">
                            {t.format} • {t.timeControlType}
                          </span>
                        </div>
                        <h3 className="font-bold text-base text-slate-100 group-hover:text-amber-300 transition-colors">
                          {t.title}
                        </h3>
                      </div>
                      <span className="text-xs font-mono font-bold bg-[#141F33] px-2.5 py-1 rounded-lg border border-slate-700/60 text-slate-300">
                        {t.initialSeconds / 60}+{t.incrementSeconds}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {t.description}
                    </p>

                    <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/60 text-slate-400">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-slate-500" />
                          <span>
                            {t.participants.length} / {t.maxParticipants} Players
                          </span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
                          <span>{t.totalRounds} Rounds</span>
                        </span>
                      </div>
                      {isRegistered && (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Registered
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          /* 2. TOURNAMENT DETAIL & LIVE LOBBY */
          <div className="flex flex-col gap-4">
            {/* Header Status Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#142038] to-[#0E1626] border border-amber-500/30 flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    {selectedTournament.status}
                  </span>
                  <h2 className="text-lg font-bold text-slate-100 mt-1">
                    {selectedTournament.title}
                  </h2>
                  <p className="text-xs text-slate-400">
                    Organizer: <span className="text-slate-200 font-medium">{selectedTournament.organizerName}</span>
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-amber-400">
                    {selectedTournament.timeControlType.toUpperCase()}{' '}
                    {selectedTournament.initialSeconds / 60}+{selectedTournament.incrementSeconds}
                  </span>
                  <p className="text-[11px] text-slate-400">
                    {selectedTournament.participants.length} Contenders
                  </p>
                </div>
              </div>

              {/* Tournament Controls for User & Organizer */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
                {(() => {
                  const isRegistered = selectedTournament.participants.some(
                    (p) => p.playerId === userProfile.id
                  );
                  const isOrganizer = selectedTournament.organizerId === userProfile.id;

                  return (
                    <>
                      {!isRegistered && selectedTournament.status === 'registration' && (
                        <button
                          onClick={() => handleRegister(selectedTournament)}
                          className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 flex items-center gap-1.5"
                        >
                          <Trophy className="w-3.5 h-3.5" /> Register Now
                        </button>
                      )}

                      {isRegistered && selectedTournament.status === 'registration' && (
                        <button
                          onClick={() => handleWithdraw(selectedTournament)}
                          className="px-3.5 py-2 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 font-semibold text-xs hover:bg-rose-500/25"
                        >
                          Withdraw
                        </button>
                      )}

                      {/* Organizer controls */}
                      {isOrganizer && selectedTournament.status === 'registration' && (
                        <button
                          onClick={() => handleStartTournament(selectedTournament)}
                          className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 flex items-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" /> Start Tournament (Round 1)
                        </button>
                      )}

                      {isOrganizer &&
                        selectedTournament.status === 'live' &&
                        selectedTournament.currentRound < selectedTournament.totalRounds && (
                          <button
                            onClick={() => handleAdvanceRound(selectedTournament)}
                            className="px-3.5 py-2 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-300 font-bold text-xs hover:bg-sky-500/30 flex items-center gap-1.5"
                          >
                            <RotateCcw className="w-3.5 h-3.5" /> Advance to Next Round
                          </button>
                        )}
                    </>
                  );
                })()}
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-slate-800 text-xs font-semibold">
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('standings');
                }}
                className={`flex-1 py-2.5 text-center border-b-2 transition-all ${
                  activeTab === 'standings'
                    ? 'border-amber-400 text-amber-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Standings
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('pairings');
                }}
                className={`flex-1 py-2.5 text-center border-b-2 transition-all ${
                  activeTab === 'pairings'
                    ? 'border-amber-400 text-amber-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Pairings & Matches
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveTab('roster');
                }}
                className={`flex-1 py-2.5 text-center border-b-2 transition-all ${
                  activeTab === 'roster'
                    ? 'border-amber-400 text-amber-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Participants ({selectedTournament.participants.length})
              </button>
            </div>

            {/* TAB 1: STANDINGS */}
            {activeTab === 'standings' && (
              <div className="flex flex-col gap-2">
                <div className="rounded-xl bg-[#0D1422] border border-slate-800 overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-[#121B2D] text-slate-400 text-[11px] uppercase border-b border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3">#</th>
                        <th className="py-2.5 px-3">Player</th>
                        <th className="py-2.5 px-3 text-center">Pts</th>
                        <th className="py-2.5 px-3 text-center">Buchholz</th>
                        <th className="py-2.5 px-3 text-center">W/D/L</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {[...selectedTournament.participants]
                        .sort((a, b) => {
                          if (b.score !== a.score) return b.score - a.score;
                          return b.tieBreakBuchholz - a.tieBreakBuchholz;
                        })
                        .map((p, idx) => (
                          <tr
                            key={p.id}
                            className={`hover:bg-[#141F33] transition-colors ${
                              p.playerId === userProfile.id ? 'bg-amber-400/5 font-semibold' : ''
                            }`}
                          >
                            <td className="py-2.5 px-3 font-mono font-bold text-slate-400">
                              {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : idx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <div className="flex items-center gap-1.5">
                                <span>{p.avatar || '👤'}</span>
                                <span className="text-slate-100">{p.playerName}</span>
                                <span className="text-[10px] text-slate-500 font-mono">
                                  ({p.playerRating})
                                </span>
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-center font-bold text-amber-300 font-mono">
                              {p.score.toFixed(1)}
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                              {p.tieBreakBuchholz.toFixed(1)}
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono text-[11px] text-slate-400">
                              {p.wins}/{p.draws}/{p.losses}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 2: PAIRINGS & ROUNDS */}
            {activeTab === 'pairings' && (
              <div className="flex flex-col gap-3">
                {selectedTournament.rounds.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-[#0D1422] border border-slate-800 text-center">
                    <Clock className="w-8 h-8 text-amber-400 mx-auto mb-2 opacity-80" />
                    <h4 className="font-bold text-sm text-slate-200">No Rounds Generated Yet</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                      Pairings will be generated automatically once the tournament officially commences.
                    </p>
                  </div>
                ) : (
                  selectedTournament.rounds.map((round) => (
                    <div
                      key={round.id}
                      className="p-3.5 rounded-2xl bg-[#0D1422] border border-slate-800 flex flex-col gap-2.5"
                    >
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-amber-300">Round {round.roundNumber}</span>
                        <span className="text-[11px] text-slate-400 capitalize">{round.status}</span>
                      </div>

                      <div className="flex flex-col gap-2">
                        {round.pairings.map((pair) => {
                          const isUserInPair =
                            pair.whiteId === userProfile.id || pair.blackId === userProfile.id;
                          const userIsWhite = pair.whiteId === userProfile.id;

                          return (
                            <div
                              key={pair.id}
                              className={`p-3 rounded-xl border flex flex-col gap-2 ${
                                isUserInPair
                                  ? 'bg-[#142035] border-amber-400/40'
                                  : 'bg-[#11192A] border-slate-800/80'
                              }`}
                            >
                              <div className="flex items-center justify-between text-xs font-semibold">
                                {/* White */}
                                <div className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full bg-slate-100 border border-slate-400 inline-block" />
                                  <span className="text-slate-100">{pair.whiteName}</span>
                                  <span className="text-[10px] text-slate-500 font-mono">
                                    ({pair.whiteRating})
                                  </span>
                                </div>

                                {/* Score / Result */}
                                <div className="font-mono font-bold text-amber-300 px-2 py-0.5 rounded bg-black/40 border border-white/5">
                                  {pair.result === 'pending'
                                    ? 'VS'
                                    : pair.result === '1-0'
                                    ? '1 - 0'
                                    : pair.result === '0-1'
                                    ? '0 - 1'
                                    : pair.result === '1/2-1/2'
                                    ? '½ - ½'
                                    : 'BYE'}
                                </div>

                                {/* Black */}
                                <div className="flex items-center gap-1.5 justify-end">
                                  <span className="text-slate-100">
                                    {pair.isBye ? 'BYE (1.0 Pt)' : pair.blackName}
                                  </span>
                                  {pair.blackRating && (
                                    <span className="text-[10px] text-slate-500 font-mono">
                                      ({pair.blackRating})
                                    </span>
                                  )}
                                  <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-600 inline-block" />
                                </div>
                              </div>

                              {/* Play Match Button for Active User */}
                              {isUserInPair && pair.result === 'pending' && !pair.isBye && (
                                <button
                                  onClick={() => {
                                    sound.playClick();
                                    onLaunchTournamentMatch({
                                      tournamentId: selectedTournament.id,
                                      pairingId: pair.id,
                                      opponentName: userIsWhite
                                        ? pair.blackName || 'Opponent'
                                        : pair.whiteName,
                                      opponentRating: userIsWhite
                                        ? pair.blackRating || 1500
                                        : pair.whiteRating,
                                      playerSide: userIsWhite ? 'w' : 'b',
                                      timeControlSeconds: selectedTournament.initialSeconds,
                                      incrementSeconds: selectedTournament.incrementSeconds,
                                    });
                                  }}
                                  className="w-full py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 flex items-center justify-center gap-1.5 shadow-md"
                                >
                                  <Swords className="w-3.5 h-3.5" /> Play Official Round Match
                                </button>
                              )}

                              {/* Quick result reporting for testing/tournament staff */}
                              {pair.result === 'pending' && !pair.isBye && (
                                <div className="flex gap-1 justify-end pt-1 border-t border-slate-800 text-[10px]">
                                  <button
                                    onClick={() => handleSimulateResult(pair.id, '1-0')}
                                    className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                                  >
                                    1-0
                                  </button>
                                  <button
                                    onClick={() => handleSimulateResult(pair.id, '1/2-1/2')}
                                    className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                                  >
                                    ½-½
                                  </button>
                                  <button
                                    onClick={() => handleSimulateResult(pair.id, '0-1')}
                                    className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                                  >
                                    0-1
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 3: ROSTER */}
            {activeTab === 'roster' && (
              <div className="flex flex-col gap-2">
                {selectedTournament.participants.map((p, idx) => (
                  <div
                    key={p.id}
                    className="p-3 rounded-xl bg-[#0D1422] border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-slate-500 font-bold w-5">{idx + 1}</span>
                      <span className="text-base">{p.avatar || '👤'}</span>
                      <div>
                        <h4 className="font-bold text-slate-100">{p.playerName}</h4>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Rating {p.playerRating}
                        </span>
                      </div>
                    </div>
                    <div>
                      {p.checkedIn ? (
                        <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Checked In
                        </span>
                      ) : (
                        <span className="text-slate-500 font-medium text-[11px]">Pending Check-In</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* CREATE TOURNAMENT MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D1424] border border-amber-500/30 rounded-2xl w-full max-w-md p-5 flex flex-col gap-4 shadow-2xl">
            <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" /> Create Custom Tournament
            </h3>

            <form onSubmit={handleCreateTournament} className="flex flex-col gap-3 text-xs">
              <div>
                <label className="text-slate-400 font-semibold mb-1 block">Tournament Title</label>
                <input
                  type="text"
                  placeholder="e.g. Midnight Blitz Championship"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-semibold mb-1 block">Format</label>
                  <select
                    value={newFormat}
                    onChange={(e) => setNewFormat(e.target.value as TournamentFormat)}
                    className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none"
                  >
                    <option value="swiss">FIDE Swiss</option>
                    <option value="arena">Lightning Arena</option>
                    <option value="single_elimination">Single Knockout</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 font-semibold mb-1 block">Time Control</label>
                  <select
                    value={newTimeControl}
                    onChange={(e) =>
                      setNewTimeControl(e.target.value as 'bullet' | 'blitz' | 'rapid')
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none"
                  >
                    <option value="bullet">Bullet (2+1)</option>
                    <option value="blitz">Blitz (5+0)</option>
                    <option value="rapid">Rapid (10+0)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-semibold mb-1 block">Total Rounds</label>
                  <input
                    type="number"
                    min={1}
                    max={15}
                    value={newRounds}
                    onChange={(e) => setNewRounds(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-semibold mb-1 block">Max Players</label>
                  <input
                    type="number"
                    min={2}
                    max={64}
                    value={newMaxPlayers}
                    onChange={(e) => setNewMaxPlayers(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#141E33] border border-slate-700 text-slate-100 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-[#151F33] text-slate-300 font-semibold hover:bg-[#1A2640]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold hover:bg-amber-300"
                >
                  Publish Tournament
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
