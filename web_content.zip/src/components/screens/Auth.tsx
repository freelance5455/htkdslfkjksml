"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "@/components/ui/Icon";
import { Btn, Chip, Field, pushToast, Segmented, Toggle } from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import { CURRENCIES } from "@/lib/calendar";

/* ------------------------------ PIN pad -------------------------------- */

function PinPad({
  onDigit,
  onDelete,
  disabled,
  footer,
}: {
  onDigit: (d: string) => void;
  onDelete: () => void;
  disabled?: boolean;
  footer?: React.ReactNode;
}) {
  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
  return (
    <div className="grid grid-cols-3 gap-2.5">
      {keys.map((k, i) => (
        <motion.button
          key={k}
          type="button"
          disabled={disabled}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 + i * 0.022, type: "spring", stiffness: 380, damping: 28 }}
          whileTap={{ scale: 0.92 }}
          onClick={() => onDigit(k)}
          className="press grid h-[62px] place-items-center rounded-2xl border border-line bg-surface2 font-display text-[24px] font-bold text-ink hover:border-brand/50 hover:text-brandtext disabled:opacity-40"
        >
          {k}
        </motion.button>
      ))}
      <div className="grid h-[62px] place-items-center">{footer}</div>
      <motion.button
        type="button"
        disabled={disabled}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.28, type: "spring", stiffness: 380, damping: 28 }}
        whileTap={{ scale: 0.92 }}
        onClick={() => onDigit("0")}
        className="press grid h-[62px] place-items-center rounded-2xl border border-line bg-surface2 font-display text-[24px] font-bold hover:border-brand/50 hover:text-brandtext disabled:opacity-40"
      >
        0
      </motion.button>
      <motion.button
        type="button"
        disabled={disabled}
        aria-label="Delete"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, type: "spring", stiffness: 380, damping: 28 }}
        whileTap={{ scale: 0.92 }}
        onClick={onDelete}
        className="press grid h-[62px] place-items-center rounded-2xl border border-line bg-surface text-ink2 hover:text-spend disabled:opacity-40"
      >
        <Icon name="backspace" size={22} />
      </motion.button>
    </div>
  );
}

function PinDots({ value, max = 6, shake }: { value: string; max?: number; shake: boolean }) {
  return (
    <motion.div
      animate={shake ? { x: [0, -10, 9, -6, 4, 0] } : { x: 0 }}
      transition={{ duration: 0.42 }}
      className="flex items-center justify-center gap-2.5"
    >
      {Array.from({ length: max }).map((_, i) => (
        <span
          key={i}
          className={`grid h-3.5 w-3.5 place-items-center rounded-full border transition-all duration-200 ${
            i < value.length
              ? "scale-110 border-brand bg-brand shadow-[0_0_12px_var(--c-brand)]"
              : "border-ink3/60 bg-transparent"
          }`}
        />
      ))}
    </motion.div>
  );
}

/* ------------------------------ lock ---------------------------------- */

export function LockScreen() {
  const { profiles, activeProfileId, setActiveProfileId, unlock, boot, startNewProfile } = useApp();
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [busy, setBusy] = useState(false);
  const current = useMemo(
    () => profiles.find((p) => p.id === activeProfileId) ?? profiles[0] ?? null,
    [profiles, activeProfileId],
  );

  useEffect(() => {
    if (!activeProfileId && profiles[0]) setActiveProfileId(profiles[0].id);
  }, [activeProfileId, profiles, setActiveProfileId]);

  const pinRef = useRef(pin);
  pinRef.current = pin;
  const submitRef = useRef<((v: string) => Promise<void>) | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (busy || !current) return;
      if (/^\d$/.test(e.key)) {
        if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate?.(8);
        const next = (pinRef.current + e.key).slice(0, 8);
        setPin(next);
        if (next.length === 8) void submitRef.current?.(next);
      } else if (e.key === "Backspace") {
        setPin((p) => p.slice(0, -1));
      } else if (e.key === "Enter" && pinRef.current.length >= 4) {
        void submitRef.current?.(pinRef.current);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [busy, current]);

  async function submit(value: string) {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const ok = await unlock(value);
      if (!ok) throw new Error("Incorrect PIN.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Incorrect PIN.");
      setShake(true);
      setTimeout(() => setShake(false), 450);
      setPin("");
    } finally {
      setBusy(false);
    }
  }

  submitRef.current = submit;

  function onDigit(d: string) {
    if (busy) return;
    if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate?.(6);
    setError(null);
    setPin((p) => {
      const next = (p + d).slice(0, 8);
      if (next.length === 8) void submit(next);
      return next;
    });
  }

  const initials = (current?.username ?? "k").slice(0, 2).toUpperCase();

  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-brandink">
            <Icon name="ledger" size={18} />
          </span>
          <span className="font-display text-[15px] font-extrabold tracking-[-0.02em]">
            Keep Tracked
          </span>
        </div>
        <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink3">locked</span>
      </div>

      <div className="mt-10 flex flex-col items-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 280, damping: 20 }}
          className="relative grid h-20 w-20 place-items-center rounded-[26px] border border-line bg-surface2"
        >
          <span className="font-display text-[26px] font-extrabold tracking-[-0.03em] text-brandtext">
            {initials}
          </span>
          <span className="absolute -bottom-2 -right-2 grid h-8 w-8 place-items-center rounded-full border border-line bg-bg text-ink2">
            <Icon name="lock" size={14} />
          </span>
        </motion.div>

        {profiles.length > 1 ? (
          <div className="no-scrollbar mt-5 flex max-w-full gap-2 overflow-x-auto">
            {profiles.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setActiveProfileId(p.id);
                  setPin("");
                  setError(null);
                }}
                className="press shrink-0"
              >
                <Chip tone={p.id === current?.id ? "brand" : "neutral"} active={p.id === current?.id}>
                  {p.username}
                </Chip>
              </button>
            ))}
          </div>
        ) : null}

        <h1 className="mt-5 text-center font-display text-[26px] font-extrabold leading-tight tracking-[-0.03em]">
          {current ? `Hey ${current.username}` : "No profile yet"}
        </h1>
        <p className="mt-1 text-center text-[13px] text-ink2">
          {current ? "Enter your PIN to open the ledger" : "Create a profile to start tracking"}
        </p>

        <div className="mt-6 h-6 w-full">
          <AnimatePresence mode="wait">
            {error ? (
              <motion.p
                key="err"
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="text-center font-mono text-[11.5px] uppercase tracking-[0.12em] text-spend"
              >
                {error}
              </motion.p>
            ) : busy ? (
              <motion.p
                key="busy"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center font-mono text-[11.5px] uppercase tracking-[0.12em] text-ink3"
              >
                verifying…
              </motion.p>
            ) : (
              <motion.p
                key="hint"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center font-mono text-[11.5px] uppercase tracking-[0.12em] text-ink3"
              >
                {pin.length}/8 digits
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="mt-4">
        <PinDots value={pin} shake={shake} />
      </div>

      <div className="mt-auto">
        {current ? (
          <PinPad
            onDigit={onDigit}
            onDelete={() => setPin((p) => p.slice(0, -1))}
            disabled={busy || !current}
            footer={
              <button
                type="button"
                aria-label="Unlock"
                onClick={() => pin.length >= 4 && submit(pin)}
                disabled={pin.length < 4 || busy}
                className={`press grid h-[52px] w-[52px] place-items-center rounded-full disabled:opacity-25 ${
                  pin.length >= 4 ? "bg-brand text-brandink" : "bg-surface2 text-ink3"
                }`}
              >
                <Icon name="right" size={22} strokeWidth={2.2} />
              </button>
            }
          />
        ) : null}
        <div className="mt-4 flex items-center justify-center gap-3">
          <Btn
            variant="ghost"
            size="sm"
            icon="plus"
            onClick={() => {
              pushToast("Setting up a new profile");
              startNewProfile();
            }}
          >
            New profile
          </Btn>
          {boot === "lock" ? null : null}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ setup --------------------------------- */

export function SetupScreen() {
  const { createProfile } = useApp();
  const [step, setStep] = useState(0);
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [phase, setPhase] = useState<"set" | "confirm">("set");
  const [currency, setCurrency] = useState("USD");
  const [startBalance, setStartBalance] = useState("0");
  const [sample, setSample] = useState(true);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  const steps = ["Identity", "Security", "Preferences"];

  async function finish() {
    setBusy(true);
    setError(null);
    try {
      await createProfile({
        username: username.trim(),
        pin,
        currency,
        startBalance: Number(startBalance) || 0,
        sampleData: sample,
        theme,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create profile.");
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-8">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-brandink">
          <Icon name="ledger" size={18} />
        </span>
        <div>
          <p className="font-display text-[15px] font-extrabold leading-none tracking-[-0.02em]">
            Keep Tracked
          </p>
          <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-ink3">first time setup</p>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2">
        {steps.map((s, i) => (
          <div key={s} className="flex-1">
            <div className="h-1 overflow-hidden rounded-full bg-surface2">
              <motion.div
                className="h-full rounded-full bg-brand"
                animate={{ width: i <= step ? "100%" : "0%" }}
                transition={{ type: "spring", stiffness: 240, damping: 30 }}
              />
            </div>
            <p
              className={`mt-1.5 font-mono text-[9px] uppercase tracking-[0.14em] ${
                i === step ? "text-brandtext" : "text-ink3"
              }`}
            >
              {s}
            </p>
          </div>
        ))}
      </div>

      <div className="min-h-0 flex-1">
        <AnimatePresence mode="wait">
          {step === 0 ? (
            <motion.div
              key="s0"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="pt-7"
            >
              <h1 className="font-display text-[30px] font-extrabold leading-[1.05] tracking-[-0.035em]">
                Let&apos;s open
                <br />
                your ledger.
              </h1>
              <p className="mt-2.5 max-w-[34ch] text-[13.5px] leading-relaxed text-ink2">
                Pick the name that shows up on your receipts and at the lock screen. Everything you
                log stays tied to it.
              </p>
              <div className="mt-7">
                <Field label="Username" hint="2–24 characters · letters, numbers, spaces">
                  <div className="relative">
                    <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink3">
                      <Icon name="user" size={17} />
                    </span>
                    <input
                      className="field pl-11 font-semibold"
                      value={username}
                      autoFocus
                      maxLength={24}
                      placeholder="e.g. nimali"
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                </Field>
              </div>
              <div className="mt-4 flex items-center gap-3 rounded-2xl border border-line bg-surface p-3">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand font-display text-[16px] font-extrabold text-brandink">
                  {(username.trim() || "kt").slice(0, 2).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <p className="truncate font-display text-[15px] font-bold">
                    {username.trim() || "your name"}
                  </p>
                  <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
                    ledger owner
                  </p>
                </div>
              </div>
            </motion.div>
          ) : step === 1 ? (
            <motion.div
              key="s1"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="pt-7"
            >
              <h1 className="font-display text-[28px] font-extrabold leading-[1.05] tracking-[-0.035em]">
                {phase === "confirm" ? "Type it once more" : "Set a secret PIN"}
              </h1>
              <p className="mt-2 text-[13px] leading-relaxed text-ink2">
                4 to 8 digits. Keep Tracked asks for it every single time the app opens.
              </p>
              <div className="mt-6">
                <PinDots value={phase === "confirm" ? confirmPin : pin} shake={false} />
              </div>
              {error ? (
                <p className="mt-3 text-center font-mono text-[11px] uppercase tracking-[0.12em] text-spend">
                  {error}
                </p>
              ) : null}
              <div className="mt-5">
                <PinPad
                  onDigit={(d) => {
                    setError(null);
                    if (phase === "set") {
                      setPin((p) => (p.length >= 8 ? p : p + d));
                    } else {
                      const next = confirmPin.length >= 8 ? confirmPin : confirmPin + d;
                      setConfirmPin(next);
                      if (next === pin && next.length >= 4) setStep(2);
                      else if (next.length >= pin.length && next.length >= 4) {
                        setError("PINs do not match. Set it again.");
                        setConfirmPin("");
                        setPin("");
                        setPhase("set");
                      }
                    }
                  }}
                  onDelete={() => {
                    if (phase === "confirm") setConfirmPin((p) => p.slice(0, -1));
                    else setPin((p) => p.slice(0, -1));
                  }}
                  footer={
                    <button
                      type="button"
                      aria-label="Next"
                      onClick={() => {
                        if (phase === "set" && pin.length >= 4) {
                          setPhase("confirm");
                          setConfirmPin("");
                        } else if (phase === "confirm" && confirmPin === pin && confirmPin.length >= 4) {
                          setStep(2);
                        }
                      }}
                      disabled={
                        phase === "set" ? pin.length < 4 : confirmPin.length < 4 || confirmPin !== pin
                      }
                      className="press grid h-[52px] w-[52px] place-items-center rounded-full bg-brand text-brandink disabled:opacity-25"
                    >
                      <Icon name="check" size={22} strokeWidth={2.2} />
                    </button>
                  }
                />
              </div>
              <div className="mt-4 flex justify-center gap-2">
                <Chip tone="neutral" icon="shield">
                  hashed + salted
                </Chip>
                {phase === "set" && pin.length >= 4 ? (
                  <Chip tone="brand" icon="key">
                    {pin.length} digits set
                  </Chip>
                ) : null}
                {phase === "confirm" ? (
                  <Chip tone="bill" icon="lock">
                    confirming
                  </Chip>
                ) : null}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="s2"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="space-y-4 pt-6"
            >
              <h1 className="font-display text-[28px] font-extrabold leading-[1.05] tracking-[-0.035em]">
                Make it yours.
              </h1>
              <Field label="Currency">
                <div className="relative">
                  <select
                    className="field pr-10 font-semibold"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                  >
                    {CURRENCIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.symbol} · {c.code} — {c.label}
                      </option>
                    ))}
                  </select>
                  <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-ink3">
                    <Icon name="chevron" size={16} />
                  </span>
                </div>
              </Field>
              <Field label="Opening balance" hint="Cash you already have before logging anything">
                <div className="relative">
                  <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-[13px] text-ink3">
                    {CURRENCIES.find((c) => c.code === currency)?.symbol}
                  </span>
                  <input
                    className="field pl-9 font-mono"
                    inputMode="decimal"
                    value={startBalance}
                    onChange={(e) => setStartBalance(e.target.value.replace(/[^\d.-]/g, ""))}
                  />
                </div>
              </Field>
              <Field label="Appearance">
                <Segmented
                  id="setup-theme"
                  value={theme}
                  onChange={(v) => setTheme(v)}
                  options={[
                    { value: "dark", label: "Dark", icon: "moon" },
                    { value: "light", label: "Light", icon: "sun" },
                  ]}
                />
              </Field>
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-3.5">
                <div className="min-w-0">
                  <p className="font-display text-[14px] font-bold">Load 5 months of demo data</p>
                  <p className="mt-0.5 text-[12px] leading-snug text-ink2">
                    Sample earnings, spendings and bills so the graphs, calendar and receipts light
                    up instantly.
                  </p>
                </div>
                <Toggle checked={sample} onChange={setSample} label="Load demo data" />
              </div>
              {error ? (
                <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-spend">{error}</p>
              ) : null}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-5 flex items-center gap-2">
        {step > 0 ? (
          <Btn
            variant="outline"
            icon="left"
            onClick={() => {
              if (step === 1 && phase === "confirm") {
                setPhase("set");
                setConfirmPin("");
                setError(null);
              } else {
                setStep((s) => s - 1);
              }
            }}
          >
            Back
          </Btn>
        ) : null}
        {step < 2 ? (
          <Btn
            variant="brand"
            full
            iconRight={step === 1 ? "check" : "right"}
            disabled={
              step === 0
                ? username.trim().length < 2
                : phase === "set"
                  ? pin.length < 4
                  : confirmPin.length < 4 || confirmPin !== pin
            }
            onClick={() => {
              setError(null);
              if (step === 0) {
                if (username.trim().length < 2) {
                  setError("Username is too short.");
                  return;
                }
                setStep(1);
              } else if (phase === "set" && pin.length >= 4) {
                setPhase("confirm");
                setConfirmPin("");
              } else if (phase === "confirm" && confirmPin === pin && confirmPin.length >= 4) {
                setStep(2);
              }
            }}
          >
            {step === 0 ? "Continue" : phase === "set" ? "Set PIN" : "Confirm PIN"}
          </Btn>
        ) : (
          <Btn variant="brand" full iconRight="spark" disabled={busy} onClick={finish}>
            {busy ? "Building your ledger…" : "Create my ledger"}
          </Btn>
        )}
      </div>
    </div>
  );
}
