import React, { useState } from 'react';
import { ChevronLeft, Zap, Users, Copy, Check, ArrowRight } from 'lucide-react';
import { ONLINE_LOBBY_PLAYERS } from '../../services/storage';
import { OnlineLobbyPlayer } from '../../types/chess';
import { sound } from '../../services/sound';

interface MultiplayerScreenProps {
  onBack: () => void;
  onStartMatch: (opponent: OnlineLobbyPlayer, isPrivateRoom?: boolean, roomId?: string) => void;
}

export const MultiplayerScreen: React.FC<MultiplayerScreenProps> = ({
  onBack,
  onStartMatch,
}) => {
  const [activeTab, setActiveTab] = useState<'quick' | 'friends'>('quick');
  const [roomCodeInput, setRoomCodeInput] = useState('');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Matchmaking queue state
  const [isSearching, setIsSearching] = useState(false);
  const [searchTime, setSearchTime] = useState(0);
  const [matchedPlayer, setMatchedPlayer] = useState<OnlineLobbyPlayer | null>(null);

  // Matchmaking search timer
  React.useEffect(() => {
    let timer: any;
    let matchTimeout: any;

    if (isSearching) {
      setSearchTime(0);
      setMatchedPlayer(null);

      timer = setInterval(() => {
        setSearchTime((t) => t + 1);
      }, 1000);

      // Find suitable opponent after ~2.5s
      matchTimeout = setTimeout(() => {
        const randomOpp =
          ONLINE_LOBBY_PLAYERS[Math.floor(Math.random() * ONLINE_LOBBY_PLAYERS.length)];
        setMatchedPlayer(randomOpp);
        sound.playVictory();

        // Launch after short opponent found celebration
        setTimeout(() => {
          setIsSearching(false);
          onStartMatch(randomOpp);
        }, 1200);
      }, 2500);
    }

    return () => {
      clearInterval(timer);
      clearTimeout(matchTimeout);
    };
  }, [isSearching]);

  const handleStartSearch = () => {
    sound.playClick();
    setIsSearching(true);
  };

  const handleCancelSearch = () => {
    sound.playClick();
    setIsSearching(false);
    setMatchedPlayer(null);
  };

  const handleCreateRoom = () => {
    sound.playClick();
    const code = `CHESS-${Math.floor(1000 + Math.random() * 9000)}`;
    setGeneratedCode(code);
  };

  const handleCopyCode = () => {
    if (!generatedCode) return;
    navigator.clipboard?.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleJoinByCode = () => {
    if (!roomCodeInput.trim()) return;
    sound.playClick();
    onStartMatch(
      {
        id: `friend-${roomCodeInput}`,
        name: `Friend (${roomCodeInput.toUpperCase()})`,
        avatar: '🤝',
        rating: 1250,
        status: 'online',
      },
      true,
      roomCodeInput.trim().toUpperCase()
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-20 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100">
          Online Multiplayer
        </h2>
        <div className="w-10" />
      </div>

      {/* Tabs (Quick Match vs Friends) */}
      <div className="max-w-md mx-auto w-full mb-5">
        <div className="grid grid-cols-2 p-1 bg-[#101726] border border-[#1E2B45] rounded-2xl">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('quick');
            }}
            className={`py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'quick'
                ? 'bg-sky-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Quick Match
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('friends');
            }}
            className={`py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'friends'
                ? 'bg-sky-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Friends & Rooms
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col overflow-y-auto">
        {activeTab === 'quick' ? (
          <div className="flex flex-col gap-3">
            {/* Quick Match Instant Finder Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-sky-900/40 via-blue-900/30 to-[#101726] border border-sky-500/30 flex items-center justify-between shadow-lg mb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-400">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Auto Matchmaking</h4>
                  <p className="text-[11px] text-sky-200/70">Finds an opponent in ~3 seconds</p>
                </div>
              </div>
              <button
                onClick={handleStartSearch}
                className="py-2 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              >
                Find Now
              </button>
            </div>

            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              Active Lobby Players ({ONLINE_LOBBY_PLAYERS.length})
            </h3>

            {/* Online Players List (matches Screen 6 from reference) */}
            <div className="flex flex-col gap-2.5">
              {ONLINE_LOBBY_PLAYERS.map((player) => (
                <div
                  key={player.id}
                  className="p-3.5 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-slate-600 flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-11 h-11 rounded-xl bg-[#18243A] border border-[#2B3B59] flex items-center justify-center text-xl">
                        {player.avatar}
                      </div>
                      <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-[#101726] rounded-full" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-slate-100">
                        {player.name}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span className="text-amber-400/90 font-mono font-medium">{player.rating}</span>
                        <span>•</span>
                        <span className="text-emerald-400 font-medium">Online</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      sound.playClick();
                      onStartMatch(player);
                    }}
                    className="py-1.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs tracking-wide shadow-md active:scale-95 transition-all"
                  >
                    Play
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Friends & Private Rooms */
          <div className="flex flex-col gap-4">
            {/* Create Room Card */}
            <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Create Private Room</h4>
                  <p className="text-[11px] text-slate-400">Share code with a friend to play together</p>
                </div>
              </div>

              {generatedCode ? (
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#18243A] border border-amber-400/40">
                  <span className="flex-1 font-mono font-bold text-amber-300 text-base text-center tracking-wider">
                    {generatedCode}
                  </span>
                  <button
                    onClick={handleCopyCode}
                    className="p-2 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-xs flex items-center gap-1 font-semibold"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                  <button
                    onClick={() => {
                      onStartMatch(
                        { id: 'friend-host', name: 'Friend Room', avatar: '👑', rating: 1200, status: 'online' },
                        true,
                        generatedCode
                      );
                    }}
                    className="py-2 px-3 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                  >
                    Enter Room
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleCreateRoom}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all"
                >
                  Generate Room Code
                </button>
              )}
            </div>

            {/* Join Room by Code */}
            <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-3">
              <div>
                <h4 className="font-bold text-sm text-slate-100">Join with Room Code</h4>
                <p className="text-[11px] text-slate-400">Enter your friend's room code to connect</p>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. CHESS-8492"
                  value={roomCodeInput}
                  onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
                  className="flex-1 bg-[#162033] border border-[#253655] rounded-xl px-3 py-2 text-sm text-slate-100 uppercase tracking-wider font-mono placeholder:text-slate-500 focus:outline-none focus:border-sky-400"
                />
                <button
                  onClick={handleJoinByCode}
                  disabled={!roomCodeInput.trim()}
                  className="py-2 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1 shadow-md transition-all"
                >
                  Join <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 text-center px-4 leading-relaxed">
              Real-time cross-tab synchronization supported. You can open a second browser window to test playing both sides in real time!
            </p>
          </div>
        )}
      </div>

      {/* Real-time Matchmaking Search Overlay */}
      {isSearching && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="bg-gradient-to-b from-[#141C2E] to-[#0D1322] border border-[#2B3C5E] rounded-3xl p-6 max-w-xs w-full text-center flex flex-col items-center gap-4 shadow-2xl">
            {/* Animated Radar Radar Rings */}
            <div className="relative w-24 h-24 flex items-center justify-center my-2">
              <div className="absolute inset-0 rounded-full border-2 border-sky-400/20 animate-ping" />
              <div className="absolute inset-2 rounded-full border border-sky-400/40 animate-pulse" />
              <div className="w-14 h-14 rounded-2xl bg-sky-500/20 border border-sky-400/50 flex items-center justify-center text-sky-400 text-2xl shadow-lg">
                {matchedPlayer ? matchedPlayer.avatar : '⚡'}
              </div>
            </div>

            <div>
              <h3 className="font-bold text-lg text-slate-100">
                {matchedPlayer ? 'Opponent Found!' : 'Searching for Match'}
              </h3>
              <p className="text-xs text-sky-300/80 mt-1">
                {matchedPlayer
                  ? `${matchedPlayer.name} (${matchedPlayer.rating} Elo)`
                  : 'Rating pool: 1100 - 1350 Elo • Live clocks'}
              </p>
            </div>

            <div className="py-1 px-3 rounded-lg bg-[#182338] border border-[#263756] text-xs font-mono text-slate-400">
              {matchedPlayer ? 'Launching board...' : `Wait time: 00:0${searchTime}`}
            </div>

            {!matchedPlayer && (
              <button
                onClick={handleCancelSearch}
                className="w-full mt-2 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
              >
                Cancel Search
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
