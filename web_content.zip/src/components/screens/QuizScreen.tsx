import React, { useState, useEffect, useMemo } from 'react';
import { Flame, Clock, Scissors, Sparkles, CheckCircle, XCircle, ArrowRight, RotateCcw, Lightbulb } from 'lucide-react';
import { Question, FoodGroupId } from '../../types/game';
import { QUESTIONS } from '../../data/questions';
import { FOOD_GROUPS } from '../../data/foodGroups';
import { useGame } from '../../context/GameContext';
import { sound } from '../../utils/sound';

interface QuizScreenProps {
  initialGroup?: string;
  onBackToMap: () => void;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({ initialGroup = 'all', onBackToMap }) => {
  const { state, recordAnswer, unlockBadge, usePowerup, addCoins } = useGame();
  const [selectedGroup, setSelectedGroup] = useState<string>(initialGroup);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([]);
  const [isDoubleXpActive, setIsDoubleXpActive] = useState(false);
  const [roundStats, setRoundStats] = useState({ correct: 0, total: 0, xpGained: 0, coinsGained: 0 });
  const [timeLeft, setTimeLeft] = useState(25);
  const [timerRunning, setTimerRunning] = useState(true);

  // Filter questions for the selected group
  const questionsList = useMemo(() => {
    let pool = QUESTIONS;
    if (selectedGroup !== 'all') {
      pool = QUESTIONS.filter((q) => q.foodGroup === selectedGroup || q.foodGroup === 'all');
    }
    return pool.length > 0 ? pool : QUESTIONS;
  }, [selectedGroup]);

  const currentQ = questionsList[currentIndex % questionsList.length];

  // Timer countdown
  useEffect(() => {
    if (!timerRunning || isAnswered) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [timerRunning, isAnswered, currentIndex]);

  const handleTimeOut = () => {
    if (isAnswered) return;
    setIsAnswered(true);
    recordAnswer(false);
    setRoundStats((prev) => ({ ...prev, total: prev.total + 1 }));
  };

  const handleSelectOption = (index: number) => {
    if (isAnswered || eliminatedOptions.includes(index)) return;
    sound.playTap();
    setSelectedOption(index);
    setIsAnswered(true);
    setTimerRunning(false);

    const isCorrect = index === currentQ.correctIndex;
    const mult = isDoubleXpActive ? 2 : 1;
    const { xpEarned, coinsEarned } = recordAnswer(isCorrect, mult);

    setRoundStats((prev) => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1,
      xpGained: prev.xpGained + xpEarned,
      coinsGained: prev.coinsGained + coinsEarned,
    }));

    // Check food group mastery badge
    if (isCorrect && currentQ.foodGroup !== 'all') {
      const badgeKey = `${currentQ.foodGroup}_master`;
      if (roundStats.correct + 1 >= 2) {
        unlockBadge(badgeKey);
      }
    }
  };

  const handleNext = () => {
    sound.playTap();
    setSelectedOption(null);
    setIsAnswered(false);
    setEliminatedOptions([]);
    setIsDoubleXpActive(false);
    setTimeLeft(25);
    setTimerRunning(true);
    setCurrentIndex((prev) => prev + 1);
  };

  const handleUse5050 = () => {
    if (isAnswered || eliminatedOptions.length > 0) return;
    if (state.inventory.powerup_5050 > 0) {
      usePowerup('powerup_5050');
      // Eliminate 2 wrong answers
      const wrongIndices = currentQ.options
        .map((_, i) => i)
        .filter((i) => i !== currentQ.correctIndex);
      // shuffle and take 2
      const toEliminate = wrongIndices.sort(() => Math.random() - 0.5).slice(0, 2);
      setEliminatedOptions(toEliminate);
    }
  };

  const handleUseFreeze = () => {
    if (isAnswered) return;
    if (state.inventory.powerup_freeze > 0) {
      usePowerup('powerup_freeze');
      setTimeLeft((prev) => prev + 15);
    }
  };

  const handleUseDoubleXp = () => {
    if (isAnswered || isDoubleXpActive) return;
    if (state.inventory.powerup_double_xp > 0) {
      usePowerup('powerup_double_xp');
      setIsDoubleXpActive(true);
    }
  };

  const currentGroupMeta = currentQ.foodGroup !== 'all' ? FOOD_GROUPS[currentQ.foodGroup] : null;

  return (
    <div className="space-y-4">
      {/* Food Group Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        <button
          onClick={() => {
            sound.playTap();
            setSelectedGroup('all');
            setCurrentIndex(0);
            setIsAnswered(false);
          }}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition cursor-pointer ${
            selectedGroup === 'all'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          🍽️ All Groups
        </button>
        {Object.values(FOOD_GROUPS).map((group) => (
          <button
            key={group.id}
            onClick={() => {
              sound.playTap();
              setSelectedGroup(group.id);
              setCurrentIndex(0);
              setIsAnswered(false);
            }}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition cursor-pointer flex items-center gap-1 ${
              selectedGroup === group.id
                ? 'bg-slate-700 text-white border border-slate-500 shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>{group.emoji}</span>
            <span>{group.shortName}</span>
          </button>
        ))}
      </div>

      {/* Quiz Card Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
        {/* Top Indicators */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 text-xs font-semibold">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono text-[11px] border border-slate-700">
              Q {(currentIndex % questionsList.length) + 1}/{questionsList.length}
            </span>
            {currentGroupMeta && (
              <span
                className="px-2 py-0.5 rounded-full text-[11px] font-bold border"
                style={{
                  backgroundColor: `${currentGroupMeta.color}20`,
                  color: currentGroupMeta.color,
                  borderColor: `${currentGroupMeta.color}40`,
                }}
              >
                {currentGroupMeta.emoji} {currentGroupMeta.shortName}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Timer */}
            <div
              className={`flex items-center gap-1 font-mono font-bold text-xs ${
                timeLeft <= 5 ? 'text-rose-400 animate-pulse' : 'text-slate-300'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{timeLeft}s</span>
            </div>

            {/* Streak */}
            {state.streak > 0 && (
              <div className="flex items-center gap-1 text-amber-400 font-bold text-xs animate-bounce">
                <Flame className="w-3.5 h-3.5 fill-amber-400" />
                <span>{state.streak}x Streak!</span>
              </div>
            )}
          </div>
        </div>

        {/* Lifelines Bar */}
        <div className="flex items-center justify-between py-2.5 px-1 text-xs">
          <span className="text-[11px] font-bold text-slate-400">Lifelines:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleUse5050}
              disabled={isAnswered || (state.inventory.powerup_5050 || 0) <= 0 || eliminatedOptions.length > 0}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold border transition ${
                (state.inventory.powerup_5050 || 0) > 0 && !isAnswered && eliminatedOptions.length === 0
                  ? 'bg-slate-800 hover:bg-slate-700 text-amber-300 border-amber-500/30 cursor-pointer'
                  : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
              }`}
              title="50/50: Removes 2 wrong answers"
            >
              <Scissors className="w-3 h-3" />
              <span>50/50</span>
              <span className="ml-0.5 px-1 rounded-full bg-slate-700 text-[9px] text-white">
                {state.inventory.powerup_5050 || 0}
              </span>
            </button>

            <button
              onClick={handleUseFreeze}
              disabled={isAnswered || (state.inventory.powerup_freeze || 0) <= 0}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold border transition ${
                (state.inventory.powerup_freeze || 0) > 0 && !isAnswered
                  ? 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-cyan-500/30 cursor-pointer'
                  : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
              }`}
              title="Freeze: Adds +15 seconds"
            >
              <Clock className="w-3 h-3" />
              <span>+15s</span>
              <span className="ml-0.5 px-1 rounded-full bg-slate-700 text-[9px] text-white">
                {state.inventory.powerup_freeze || 0}
              </span>
            </button>

            <button
              onClick={handleUseDoubleXp}
              disabled={isAnswered || (state.inventory.powerup_double_xp || 0) <= 0 || isDoubleXpActive}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold border transition ${
                (state.inventory.powerup_double_xp || 0) > 0 && !isAnswered && !isDoubleXpActive
                  ? 'bg-slate-800 hover:bg-slate-700 text-purple-300 border-purple-500/30 cursor-pointer'
                  : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
              }`}
              title="2x XP Boost for this question"
            >
              <Sparkles className="w-3 h-3" />
              <span>2x XP</span>
              <span className="ml-0.5 px-1 rounded-full bg-slate-700 text-[9px] text-white">
                {state.inventory.powerup_double_xp || 0}
              </span>
            </button>
          </div>
        </div>

        {/* Question Text */}
        <div className="py-2">
          <h3 className="text-base sm:text-lg font-bold text-white font-display leading-snug">
            {currentQ.question}
          </h3>
        </div>

        {/* Answer Options */}
        <div className="mt-3 space-y-2.5">
          {currentQ.options.map((opt, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === currentQ.correctIndex;
            const isEliminated = eliminatedOptions.includes(idx);

            let btnStyle = 'bg-slate-800/80 border-slate-700/80 hover:bg-slate-750 text-slate-200';

            if (isAnswered) {
              if (isCorrect) {
                btnStyle = 'bg-emerald-600/30 border-emerald-500 text-emerald-200 font-bold';
              } else if (isSelected) {
                btnStyle = 'bg-rose-600/30 border-rose-500 text-rose-200 font-bold';
              } else {
                btnStyle = 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-60';
              }
            } else if (isEliminated) {
              btnStyle = 'bg-slate-900/40 border-slate-800/40 text-slate-600 line-through opacity-30 cursor-not-allowed';
            }

            return (
              <button
                key={idx}
                disabled={isAnswered || isEliminated}
                onClick={() => handleSelectOption(idx)}
                className={`w-full p-3.5 rounded-2xl border text-left text-xs sm:text-sm transition flex items-start gap-3 cursor-pointer ${btnStyle}`}
              >
                <span className="w-6 h-6 rounded-lg bg-slate-900/60 border border-slate-700 flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="flex-1 leading-relaxed">{opt}</span>
                {isAnswered && isCorrect && <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />}
                {isAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />}
              </button>
            );
          })}
        </div>

        {/* Explanation & Teen Pro-Tip Box (Revealed after answering) */}
        {isAnswered && (
          <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5 animate-in fade-in duration-200">
            <div className="flex items-center gap-2">
              <span
                className={`text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  selectedOption === currentQ.correctIndex
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {selectedOption === currentQ.correctIndex ? '✓ Correct! +XP' : '✗ Need Review'}
              </span>
              <span className="text-xs text-slate-400 font-semibold">Educational Breakdown</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{currentQ.explanation}</p>

            <div className="pt-2 border-t border-slate-800/80 flex items-start gap-2 text-xs text-amber-300">
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-400">Teen Pro-Tip:</strong> {currentQ.teenTip}
              </div>
            </div>

            <button
              onClick={handleNext}
              className="mt-3 w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-900/30 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
            >
              <span>Next Question</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Round Score Banner */}
      <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs text-slate-300">
        <div>
          <span>This Session: </span>
          <strong className="text-white">
            {roundStats.correct} / {roundStats.total} Correct
          </strong>
        </div>
        <button
          onClick={() => {
            sound.playTap();
            onBackToMap();
          }}
          className="text-emerald-400 font-bold hover:underline cursor-pointer"
        >
          ← Return to Quest Map
        </button>
      </div>
    </div>
  );
};
