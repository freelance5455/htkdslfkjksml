import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, BookOpen, Users, Trophy, Sparkles, Play, CheckCircle2, RotateCcw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chess, Square } from 'chess.js';
import { CHESS_PUZZLES, OPENING_LESSONS, CHESS_BASICS_LESSONS } from '../../services/puzzleData';
import { Puzzle, OpeningLesson } from '../../types/chess';
import { sound } from '../../services/sound';

interface LearnScreenProps {
  onBack: () => void;
  onOpenPlayablePuzzle?: (puzzle: Puzzle) => void;
}

export const LearnScreen: React.FC<LearnScreenProps> = ({ onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState<'menu' | 'basics' | 'openings' | 'endgames' | 'puzzles' | 'videos'>('menu');
  const [activePuzzleIndex, setActivePuzzleIndex] = useState(0);
  const [activeOpeningIndex, setActiveOpeningIndex] = useState(0);

  // Puzzle interactive state
  const currentPuzzle = CHESS_PUZZLES[activePuzzleIndex];
  const [puzzleGame, setPuzzleGame] = useState(() => new Chess(currentPuzzle.fen));
  const [puzzleMoveIdx, setPuzzleMoveIdx] = useState(0);
  const [puzzleStatus, setPuzzleStatus] = useState<'playing' | 'solved' | 'failed'>('playing');
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);

  const resetPuzzle = (index = activePuzzleIndex) => {
    setActivePuzzleIndex(index);
    const puz = CHESS_PUZZLES[index];
    setPuzzleGame(new Chess(puz.fen));
    setPuzzleMoveIdx(0);
    setPuzzleStatus('playing');
    setSelectedSquare(null);
  };

  const handleSquareClick = (square: Square) => {
    if (puzzleStatus !== 'playing') return;

    if (!selectedSquare) {
      const piece = puzzleGame.get(square);
      if (piece && piece.color === puzzleGame.turn()) {
        setSelectedSquare(square);
        sound.playClick();
      }
      return;
    }

    // Try making move
    const expectedMove = currentPuzzle.moves[puzzleMoveIdx];
    const attemptUci = `${selectedSquare}${square}`;

    try {
      const move = puzzleGame.move({ from: selectedSquare, to: square, promotion: 'q' });
      if (move) {
        if (attemptUci === expectedMove) {
          // Correct move!
          sound.playMove();
          const nextIdx = puzzleMoveIdx + 1;
          setPuzzleMoveIdx(nextIdx);
          setSelectedSquare(null);

          if (nextIdx >= currentPuzzle.moves.length) {
            // Puzzle Solved!
            setPuzzleStatus('solved');
            sound.playVictory();
            confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
          } else {
            // Opponent response
            setTimeout(() => {
              const oppUci = currentPuzzle.moves[nextIdx];
              const fromSq = oppUci.substring(0, 2) as Square;
              const toSq = oppUci.substring(2, 4) as Square;
              puzzleGame.move({ from: fromSq, to: toSq, promotion: 'q' });
              setPuzzleGame(new Chess(puzzleGame.fen()));
              setPuzzleMoveIdx(nextIdx + 1);
              sound.playCapture();
            }, 500);
          }
        } else {
          // Wrong tactical move
          puzzleGame.undo();
          sound.playDefeat();
          setPuzzleStatus('failed');
          setSelectedSquare(null);
        }
      } else {
        setSelectedSquare(null);
      }
    } catch {
      setSelectedSquare(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#090D17] via-[#0D1322] to-[#070A11] text-white flex flex-col px-5 pt-8 pb-24 select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <button
          onClick={() => {
            sound.playClick();
            if (selectedCategory !== 'menu') {
              setSelectedCategory('menu');
            } else {
              onBack();
            }
          }}
          className="w-10 h-10 rounded-xl bg-[#131B2C] border border-[#202D47] flex items-center justify-center text-slate-300 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold tracking-wide text-slate-100">
          {selectedCategory === 'menu' ? 'Learn & Practice' : selectedCategory.toUpperCase()}
        </h2>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex-1 flex flex-col">
        {selectedCategory === 'menu' && (
          /* Main 5 Categories matching Screen 10 */
          <div className="flex flex-col gap-3 my-auto">
            {/* 1. Chess Basics */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedCategory('basics');
              }}
              className="p-4 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-emerald-500/50 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-sm text-slate-100">Chess Basics</h3>
                  <p className="text-xs text-slate-400">Learn the rules</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            </button>

            {/* 2. Opening Strategies */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedCategory('openings');
              }}
              className="p-4 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-rose-500/50 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 group-hover:scale-105 transition-transform">
                  <Users className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-sm text-slate-100">Opening Strategies</h3>
                  <p className="text-xs text-slate-400">Popular openings</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            </button>

            {/* 3. Endgame Tips */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedCategory('endgames');
              }}
              className="p-4 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-amber-500/50 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                  <Trophy className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-sm text-slate-100">Endgame Tips</h3>
                  <p className="text-xs text-slate-400">Win with less pieces</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            </button>

            {/* 4. Tactics & Puzzles */}
            <button
              onClick={() => {
                sound.playClick();
                resetPuzzle(0);
                setSelectedCategory('puzzles');
              }}
              className="p-4 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-purple-500/50 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-105 transition-transform">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-sm text-slate-100">Tactics & Puzzles</h3>
                  <p className="text-xs text-slate-400">Improve your skills</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            </button>

            {/* 5. Video Lessons */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedCategory('videos');
              }}
              className="p-4 rounded-2xl bg-[#101726]/90 border border-[#1E2B45] hover:border-red-500/50 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 group-hover:scale-105 transition-transform">
                  <Play className="w-6 h-6 fill-current" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-sm text-slate-100">Video Lessons</h3>
                  <p className="text-xs text-slate-400">Watch & learn</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            </button>
          </div>
        )}

        {/* Category: Interactive Tactics & Puzzles */}
        {selectedCategory === 'puzzles' && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between bg-[#101726] p-3 rounded-2xl border border-[#1E2B45]">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400">
                  Puzzle #{activePuzzleIndex + 1} of {CHESS_PUZZLES.length}
                </span>
                <h3 className="font-bold text-base text-slate-100">{currentPuzzle.title}</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => resetPuzzle((activePuzzleIndex - 1 + CHESS_PUZZLES.length) % CHESS_PUZZLES.length)}
                  className="p-2 rounded-lg bg-[#182338] text-slate-300 hover:text-white"
                >
                  ◀
                </button>
                <button
                  onClick={() => resetPuzzle((activePuzzleIndex + 1) % CHESS_PUZZLES.length)}
                  className="p-2 rounded-lg bg-[#182338] text-slate-300 hover:text-white"
                >
                  ▶
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-300 px-1">{currentPuzzle.description}</p>

            {/* Interactive 2D Chessboard for Tactics */}
            <div className="w-full aspect-square max-w-sm mx-auto bg-[#1A120B] p-2.5 rounded-2xl border-4 border-[#2A1D12] shadow-2xl">
              <div className="grid grid-cols-8 grid-rows-8 w-full h-full border border-black/40">
                {Array.from({ length: 8 }).map((_, rankIdx) => {
                  const r = rankIdx;
                  return Array.from({ length: 8 }).map((_, fileIdx) => {
                    const f = fileIdx;
                    const sq = `${String.fromCharCode(97 + f)}${8 - r}` as Square;
                    const piece = puzzleGame.get(sq);
                    const isLight = (r + f) % 2 === 0;
                    const isSelected = selectedSquare === sq;

                    const pieceSymbols: Record<string, string> = {
                      p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚',
                      P: '♙', N: '♘', B: '♗', R: '♖', Q: '♕', K: '♔',
                    };
                    const pChar = piece ? (piece.color === 'w' ? piece.type.toUpperCase() : piece.type) : '';

                    return (
                      <button
                        key={sq}
                        onClick={() => handleSquareClick(sq)}
                        className={`relative flex items-center justify-center text-3xl font-bold transition-colors ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300 z-10'
                            : isLight
                            ? 'bg-[#E5D2B3]'
                            : 'bg-[#8B5A2B]'
                        }`}
                      >
                        <span className={piece?.color === 'w' ? 'text-amber-100 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]' : 'text-slate-950'}>
                          {pieceSymbols[pChar] || ''}
                        </span>
                      </button>
                    );
                  });
                })}
              </div>
            </div>

            {/* Status / Hint Panel */}
            <div className="p-3.5 rounded-2xl bg-[#101726] border border-[#1E2B45] flex items-center justify-between">
              {puzzleStatus === 'playing' ? (
                <span className="text-xs text-amber-300/90 font-medium">
                  Hint: {currentPuzzle.hint}
                </span>
              ) : puzzleStatus === 'solved' ? (
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5" /> Puzzle Solved! (+15 Rating)
                </div>
              ) : (
                <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                  Incorrect move. Try again!
                </div>
              )}

              <button
                onClick={() => resetPuzzle()}
                className="py-1 px-3 rounded-xl bg-[#182338] text-xs font-semibold flex items-center gap-1.5 text-slate-200"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Reset
              </button>
            </div>
          </div>
        )}

        {/* Category: Opening Lessons */}
        {selectedCategory === 'openings' && (
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 overflow-x-auto pb-1">
              {OPENING_LESSONS.map((op, i) => (
                <button
                  key={op.id}
                  onClick={() => {
                    sound.playClick();
                    setActiveOpeningIndex(i);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all ${
                    activeOpeningIndex === i
                      ? 'bg-rose-500/20 border-rose-400 text-rose-300'
                      : 'bg-[#101726] border-[#1E2B45] text-slate-400'
                  }`}
                >
                  {op.name}
                </button>
              ))}
            </div>

            {/* Active opening details */}
            {(() => {
              const op = OPENING_LESSONS[activeOpeningIndex];
              return (
                <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-base text-slate-100">{op.name}</h3>
                    <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-400/30">
                      {op.eco}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-mono bg-[#162035] p-2 rounded-lg">
                    {op.movesText}
                  </p>
                  <p className="text-xs text-slate-400 leading-relaxed">{op.description}</p>
                  <div className="flex flex-col gap-1.5 mt-1">
                    <span className="text-xs font-bold text-amber-300">Key Strategic Ideas:</span>
                    {op.keyIdeas.map((idea, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{idea}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* Category: Chess Basics */}
        {selectedCategory === 'basics' && (
          <div className="flex flex-col gap-3">
            {CHESS_BASICS_LESSONS.map((b) => (
              <div key={b.id} className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-2">
                <h4 className="font-bold text-sm text-amber-300">{b.title}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{b.summary}</p>
                <div className="flex flex-col gap-1 mt-1">
                  {b.tips.map((tip, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="text-sky-400">✔</span> {tip}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Category: Endgame Tips & Videos */}
        {(selectedCategory === 'endgames' || selectedCategory === 'videos') && (
          <div className="flex flex-col gap-3">
            <div className="p-4 rounded-2xl bg-[#101726] border border-[#1E2B45] flex flex-col gap-2">
              <h4 className="font-bold text-sm text-slate-100">
                {selectedCategory === 'endgames' ? 'Essential Endgame Principles' : 'Grandmaster Video Masterclasses'}
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                {selectedCategory === 'endgames'
                  ? 'Master King & Pawn endgames, opposition, the rule of the square, and Lucena & Philidor rook positions.'
                  : 'Interactive AI coaching modules: Tactical fork patterns, pin exploitation, smothered mate sequences, and positional mastery.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
