import React, { useState } from 'react';
import { ClassInfo, GenderSection, Language } from '../types';
import { translations } from '../utils/translations';
import {
  Clock,
  BookOpen,
  Mic,
  Headphones,
  Calendar,
  Sparkles,
  Camera,
  GraduationCap,
  Users,
  ShieldCheck,
  CheckCircle
} from 'lucide-react';

interface ClassScheduleViewProps {
  classes: ClassInfo[];
  lang: Language;
  onUpdateClassPhoto: (classId: string, newUrl: string) => void;
  onNavigateToSyllabus: (levelId: string) => void;
}

export const ClassScheduleView: React.FC<ClassScheduleViewProps> = ({
  classes,
  lang,
  onUpdateClassPhoto,
  onNavigateToSyllabus,
}) => {
  const t = translations[lang];
  const [selectedGender, setSelectedGender] = useState<GenderSection | 'all'>('all');
  const [editingPhotoClassId, setEditingPhotoClassId] = useState<string | null>(null);
  const [newPhotoInput, setNewPhotoInput] = useState<string>('');

  const filteredClasses = classes.filter((c) => {
    if (selectedGender === 'all') return true;
    return c.gender === selectedGender;
  });

  const handleSavePhoto = (classId: string) => {
    if (newPhotoInput.trim()) {
      onUpdateClassPhoto(classId, newPhotoInput.trim());
    }
    setEditingPhotoClassId(null);
    setNewPhotoInput('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, classId: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          onUpdateClassPhoto(classId, reader.result);
          setEditingPhotoClassId(null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-1 rounded-full text-xs font-bold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>2-Month Progression & 4-Month Advanced Diploma</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            {t.navClasses} - Rahbar English Center
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed mb-4">
            {lang === 'ps'
              ? 'په رهبر انګلیسي مرکز کې هر ټولګی تر ۲ میاشتو وروسته بدلیږي، او پرمختللی (Advanced) ټولګی ټول ۴ میاشتې دی: ۲ میاشتې جونیئر اډوانس او ۲ میاشتې سینئر اډوانس. هر ټولګی ټاکلی د پیل او پای وخت لري.'
              : lang === 'ur'
              ? 'رہبر انگلش سینٹر میں ہر کلاس ۲ ماہ بعد پروموٹ ہوتی ہے، جبکہ ایڈوانسڈ کلاس کل ۴ ماہ پر مشتمل ہے: ۲ ماہ جونیئر ایڈوانسڈ اور ۲ ماہ سینئر ایڈوانسڈ۔ ہر کلاس کا آغاز اور اختتام کا مقررہ وقت طے ہے۔'
              : 'At Rahbar English Center, each class changes every 2 months. The Advanced Diploma is 4 months total (2 months Junior Advanced followed by 2 months Senior Advanced). All classes operate on fixed start and end schedules.'}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <div className="flex items-center gap-2 bg-emerald-800/40 px-3 py-1.5 rounded-xl border border-emerald-700/50 text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{t.femaleSectionNotice}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Gender Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {lang === 'ps' ? 'څانګه وټاکئ:' : lang === 'ur' ? 'شعبہ منتخب کریں:' : 'Select Wing:'}
          </span>
          <div className="inline-flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setSelectedGender('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedGender === 'all'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.allGenders}
            </button>
            <button
              onClick={() => setSelectedGender('male')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedGender === 'male'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              {t.maleSection}
            </button>
            <button
              onClick={() => setSelectedGender('female')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedGender === 'female'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              {t.femaleSection}
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          {filteredClasses.length} {lang === 'ps' ? 'ټولګي شتون لري' : lang === 'ur' ? 'کلاسز دستیاب ہیں' : 'Classes Available'}
        </div>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.map((cls) => {
          const isAdvanced = cls.levelId === 'junior_advanced' || cls.levelId === 'senior_advanced';
          const name = lang === 'ps' ? cls.namePs : lang === 'ur' ? cls.nameUr : cls.nameEn;
          const desc = lang === 'ps' ? cls.descriptionPs : lang === 'ur' ? cls.descriptionUr : cls.descriptionEn;
          const duration = lang === 'ps' ? cls.durationLabelPs : lang === 'ur' ? cls.durationLabelUr : cls.durationLabelEn;

          return (
            <div
              key={cls.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden group"
            >
              {/* Picture Header */}
              <div className="relative h-48 w-full bg-slate-900 overflow-hidden">
                <img
                  src={cls.imageUrl}
                  alt={cls.nameEn}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />

                {/* Duration Badge */}
                <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold shadow-md flex items-center gap-1 ${
                    isAdvanced
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-emerald-600 text-white'
                  }`}>
                    <Calendar className="w-3 h-3" />
                    {duration}
                  </span>

                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold shadow-md ${
                    cls.gender === 'female'
                      ? 'bg-rose-600 text-white'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {cls.gender === 'female' ? t.femaleSection : t.maleSection}
                  </span>
                </div>

                {/* Change Class Photo Button */}
                <button
                  onClick={() => {
                    setEditingPhotoClassId(cls.id);
                    setNewPhotoInput(cls.imageUrl);
                  }}
                  className="absolute top-3 right-3 bg-slate-900/80 hover:bg-slate-900 text-white p-2 rounded-xl text-xs backdrop-blur-sm shadow border border-white/20 transition flex items-center gap-1"
                  title={t.changeClassPhoto}
                >
                  <Camera className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden group-hover:inline text-[11px] font-medium">{t.changeClassPhoto}</span>
                </button>

                {/* Fixed Time Bar */}
                <div className="absolute bottom-3 left-3 right-3 bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 flex items-center justify-between text-white text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-amber-300">
                    <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>{cls.startTime} - {cls.endTime}</span>
                  </div>
                  <span className="text-slate-300 text-[11px]">{cls.roomNumber}</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-black text-slate-900 mb-1.5 leading-snug group-hover:text-emerald-700 transition-colors">
                    {name}
                  </h3>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {desc}
                  </p>
                </div>

                {/* Hours Breakdown: Grammar, Speaking, Vocab */}
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span className="text-slate-500 uppercase tracking-wider text-[10px]">
                      {lang === 'ps' ? 'د درسونو ساعتونه (اونیزه):' : lang === 'ur' ? 'ہفتہ وار درسی گھنٹے:' : 'Weekly Teaching Hours:'}
                    </span>
                    <span className="text-emerald-700">
                      {cls.grammarHoursWeekly + cls.speakingHoursWeekly + cls.vocabListeningHoursWeekly} {t.weeklyHours}
                    </span>
                  </div>

                  {/* Grammar */}
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                        <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                        {t.grammarHours}
                      </span>
                      <span className="font-extrabold text-blue-700">{cls.grammarHoursWeekly}h</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-blue-600 h-full rounded-full"
                        style={{ width: `${(cls.grammarHoursWeekly / 12) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Speaking */}
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                        <Mic className="w-3.5 h-3.5 text-emerald-600" />
                        {t.speakingHours}
                      </span>
                      <span className="font-extrabold text-emerald-700">{cls.speakingHoursWeekly}h</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full"
                        style={{ width: `${(cls.speakingHoursWeekly / 12) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Vocab & Listening */}
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-slate-700 font-medium">
                        <Headphones className="w-3.5 h-3.5 text-purple-600" />
                        {t.vocabHours}
                      </span>
                      <span className="font-extrabold text-purple-700">{cls.vocabListeningHoursWeekly}h</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-purple-600 h-full rounded-full"
                        style={{ width: `${(cls.vocabListeningHoursWeekly / 12) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Footer Fee & Syllabus Link */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div>
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">
                      {t.monthlyFee}
                    </span>
                    <span className="text-base font-black text-slate-900">
                      PKR {cls.monthlyFeePkr.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => onNavigateToSyllabus(cls.levelId)}
                    className="inline-flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.viewSyllabus}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Change Class Photo Modal */}
      {editingPhotoClassId && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-600" />
                {t.changeClassPhoto}
              </h3>
              <button
                onClick={() => setEditingPhotoClassId(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ps' ? 'د نوي عکس انټرنیټ لینک (URL):' : lang === 'ur' ? 'تصویر کا نیا یو آر ایل درج کریں:' : 'Image URL:'}
                </label>
                <input
                  type="text"
                  value={newPhotoInput}
                  onChange={(e) => setNewPhotoInput(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full text-xs px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="text-center text-xs font-semibold text-slate-400">
                {lang === 'ps' ? 'یا هم د کمپیوټر / موبایل څخه فایل وټاکئ:' : lang === 'ur' ? 'یا کمپیوٹر / موبائل سے تصویر منتخب کریں:' : 'Or upload image file:'}
              </div>

              <div>
                <label className="cursor-pointer flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-4 bg-slate-50 transition">
                  <Camera className="w-6 h-6 text-slate-400 mb-1" />
                  <span className="text-xs font-bold text-slate-700">{t.uploadPhoto}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, editingPhotoClassId)}
                    className="hidden"
                  />
                </label>
              </div>

              {newPhotoInput && (
                <div className="relative h-32 rounded-xl overflow-hidden border">
                  <img src={newPhotoInput} alt="Preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setEditingPhotoClassId(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => handleSavePhoto(editingPhotoClassId)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow flex items-center gap-1.5"
              >
                <CheckCircle className="w-4 h-4" />
                {t.saveChanges}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
