import { Button } from "@/components/ui/button";
import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = { children: ReactNode; fallbackTitle?: string };
type State = { error: Error | null };

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.warn(error.message, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="rounded-2xl border border-border bg-card px-5 py-8 text-center">
        <p className="font-display text-base font-semibold">
          {this.props.fallbackTitle ?? "Something went wrong"}
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          This section recovered. You can keep browsing.
        </p>
        <Button className="mt-4" variant="outline" onClick={() => this.setState({ error: null })}>
          Try again
        </Button>
      </div>
    );
  }
}
