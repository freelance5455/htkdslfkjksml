import React, { useState, useEffect } from 'react';
import { exportFileToDeviceFolder } from '../lib/fileExportHelper';
import { 
  MessageSquare, Send, Edit3, Save, Trash2, Image, Copy, FileText, Mic, 
  RotateCcw, CornerDownLeft, Share2, Eye, EyeOff, ShieldCheck, CheckCircle2, 
  Wallet, Phone, Zap, Smartphone, RefreshCw, AlertCircle, Coins, Cpu, 
  Layers, ArrowUpRight, ArrowDownLeft, Radio, Network, Database, Download, 
  ExternalLink, Key, Check, Plus, Search, Filter, HelpCircle
} from 'lucide-react';
import { imsiEngine, ImsiMessageItem, ImsiLedgerTransaction, ImsiEngineConfig, ImsiWalletBalances } from '../lib/imsiEngine';
import { offlineCache } from '../lib/offlineCache';

export const TextMessagesView: React.FC = () => {
  const [config, setConfig] = useState<ImsiEngineConfig>(() => imsiEngine.getConfig());
  const [messages, setMessages] = useState<ImsiMessageItem[]>(() => imsiEngine.getMessages());
  const [ledger, setLedger] = useState<ImsiLedgerTransaction[]>(() => imsiEngine.getLedger());
  const [wallet, setWallet] = useState<ImsiWalletBalances>(() => imsiEngine.getWalletBalances());

  const [inputMessage, setInputMessage] = useState<string>('');
  const [targetRecipient, setTargetRecipient] = useState<string>('07071918280 (Prophet JUHNKRIX SYNVAGORD)');
  const [visibility, setVisibility] = useState<'private' | 'public'>('private');
  const [deductionType, setDeductionType] = useState<'airtime_credit' | 'data_bundle'>('airtime_credit');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState<string>('');
  const [trashBin, setTrashBin] = useState<ImsiMessageItem[]>([]);
  const [drafts, setDrafts] = useState<ImsiMessageItem[]>([]);
  const [selectedTab, setSelectedTab] = useState<'active' | 'ledger' | 'hardware' | 'drafts' | 'trash'>('active');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterDirection, setFilterDirection] = useState<'all' | 'incoming' | 'outgoing'>('all');
  const [isSimulatingIncoming, setIsSimulatingIncoming] = useState<boolean>(false);

  // Sync state with imsiEngine subscriptions
  useEffect(() => {
    const unsubscribe = imsiEngine.subscribe(() => {
      setConfig(imsiEngine.getConfig());
      setMessages(imsiEngine.getMessages());
      setLedger(imsiEngine.getLedger());
      setWallet(imsiEngine.getWalletBalances());
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) {
      showToast('⚠️ Please type your text message before transmitting.');
      return;
    }

    if (wallet.cashNgn < 5 && config.carrierChargeNgn > wallet.cashNgn) {
      showToast('⚠️ Insufficient SIM airtime credit / JUHNKRIX WALLET balance for the ₦5 SMS charge.');
      return;
    }

    // Process outgoing message with IMSI airtime/data deduction & blockchain ledger entry
    const { message } = imsiEngine.sendOutgoingImsiMessage({
      targetPhone: targetRecipient,
      messageText: inputMessage,
      visibility,
      simCarrier: config.activeSimCarrier,
      deductionType,
    });

    setInputMessage('');
    showToast(`✓ IMSI SMS Transmitted to ${targetRecipient}! ₦5 carrier deduction executed & deposited into Ledger.`);
  };

  const handleSimulateIncomingMessage = () => {
    setIsSimulatingIncoming(true);
    setTimeout(() => {
      const simulated = imsiEngine.simulateIncomingBatch();
      setIsSimulatingIncoming(false);
      if (simulated.length > 0) {
        const item = simulated[0];
        showToast(`📲 Incoming IMSI SMS from ${item.senderPhone}! ₦5 deducted & converted to ${config.autoConversionMode === 'bitcoin' ? item.convertedCredit.btcFormatted : '₦' + item.convertedCredit.cashNgn + ' NGN'}.`);
      }
    }, 600);
  };

  const handleSaveDraft = () => {
    if (!inputMessage.trim()) {
      showToast('⚠️ Type a message first to save as draft.');
      return;
    }
    const draftItem: ImsiMessageItem = {
      id: 'draft-' + Date.now(),
      imsiId: 'DRAFT-IMSI-777',
      senderPhone: config.boundPhoneNumber,
      targetPhone: targetRecipient,
      direction: 'outgoing',
      messageText: inputMessage,
      timestamp: new Date().toLocaleString(),
      status: 'saved',
      visibility,
      chargeNgn: 5.0,
      simCarrier: config.activeSimCarrier,
      deductionType,
      convertedCredit: {
        cashNgn: 5.0,
        btcSats: 4,
        btcFormatted: '0.00000004 BTC',
        payoutDestination: 'JUHNKRIX WALLET Drafts',
        blockchainTxHash: '0x0000000000000000000000000000000000000000',
        bankRefNumber: 'DRAFT-LOCAL',
      },
    };
    setDrafts(prev => [draftItem, ...prev]);
    setInputMessage('');
    showToast('✓ Message saved to drafts!');
  };

  const handleDeleteMessage = (id: string) => {
    const target = messages.find(m => m.id === id);
    if (target) {
      imsiEngine.deleteMessage(id);
      setTrashBin(prev => [target, ...prev]);
      showToast('✓ Message moved to Trash.');
    }
  };

  const handleRestoreMessage = (id: string) => {
    const target = trashBin.find(m => m.id === id);
    if (target) {
      setTrashBin(prev => prev.filter(m => m.id !== id));
      showToast('✓ Message restored successfully.');
    }
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('✓ Message text copied to clipboard!');
  };

  const handleRecordVoice = () => {
    showToast('🎤 Voice recording activated via JUHNKRIX Audio Engine... Voice note attached to IMSI payload.');
    setInputMessage(prev => prev + (prev ? ' ' : '') + '[Attached Audio Voice Note: Prophetic 528Hz Prayer Decree]');
  };

  const handleInsertImage = () => {
    showToast('🖼️ Sacred image/photo attached successfully to IMSI SMS payload.');
    setInputMessage(prev => prev + (prev ? ' ' : '') + '[Attached Photo: Altar Miracle Testimony Evidence]');
  };

  const filteredMessages = messages.filter(m => {
    const matchesSearch = 
      m.messageText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.senderPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.targetPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.convertedCredit.blockchainTxHash.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterDirection === 'incoming') return matchesSearch && m.direction === 'incoming';
    if (filterDirection === 'outgoing') return matchesSearch && m.direction === 'outgoing';
    return matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-slate-900 border-2 border-amber-500 text-amber-200 px-5 py-3.5 rounded-2xl shadow-2xl flex items-center space-x-3 text-xs font-mono animate-bounce backdrop-blur-xl">
          <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main IMSI & Machine Binding Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/90 via-slate-900 to-slate-950 border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 text-slate-950 flex items-center justify-center font-bold text-3xl shadow-xl shadow-amber-500/30 border border-amber-300/40 shrink-0">
              ⚡
            </div>
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 tracking-tight">
                  JUHNKRIX MUSIKA IMSI & TEXT MESSAGES ENGINES
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center space-x-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>IMSI BOUND TO 07071918280</span>
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                Advanced Telecom IMSI SIM Card Binding Matrix at <strong className="text-amber-300 font-mono">juhnkrixmusika.pages.dev</strong> & Fixed IP <strong className="text-amber-300 font-mono">142.250.190.46</strong>. 
                Automatically charges <strong className="text-emerald-400 font-mono">₦5.00 NGN</strong> per SMS/IMSI message, deducting mobile network airtime/data and instantly depositing as real Bitcoin or Cash.
              </p>
            </div>
          </div>

          {/* Dual Financial Ledger Balance Cards */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 w-full lg:w-auto">
            {/* Cash NGN Wallet */}
            <div className="bg-slate-950/90 border border-amber-500/40 rounded-2xl p-3.5 flex-1 sm:flex-initial sm:min-w-[170px] shadow-lg">
              <div className="flex items-center justify-between text-[10px] font-mono text-amber-300/80 mb-1">
                <span className="flex items-center space-x-1">
                  <Wallet className="w-3.5 h-3.5 text-amber-400" />
                  <span>CASH WALLET</span>
                </span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">NGN</span>
              </div>
              <div className="text-base font-extrabold text-amber-200 font-mono">
                ₦{wallet.cashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[9px] text-slate-400 font-mono truncate mt-0.5">
                Bank: Opay 7071918280
              </div>
            </div>

            {/* Bitcoin BTC Wallet */}
            <div className="bg-slate-950/90 border border-amber-500/40 rounded-2xl p-3.5 flex-1 sm:flex-initial sm:min-w-[170px] shadow-lg">
              <div className="flex items-center justify-between text-[10px] font-mono text-amber-300/80 mb-1">
                <span className="flex items-center space-x-1">
                  <Coins className="w-3.5 h-3.5 text-yellow-400" />
                  <span>BITCOIN ALTAR</span>
                </span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-yellow-500/20 text-yellow-300">{wallet.bitcoinSats} SATS</span>
              </div>
              <div className="text-sm font-extrabold text-yellow-300 font-mono">
                {wallet.bitcoinFormatted}
              </div>
              <div className="text-[9px] text-slate-400 font-mono truncate mt-0.5" title="bc1qjuhnkrixaltarvaultbitcoin999777888">
                Vault: bc1q...777888
              </div>
            </div>
          </div>
        </div>

        {/* IMSI Live Binding Diagnostics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-amber-500/20 text-[11px] font-mono">
          <div className="bg-slate-950/70 p-2.5 rounded-xl border border-amber-500/20">
            <span className="text-slate-400 block text-[9px]">BOUND MSISDN:</span>
            <strong className="text-amber-200">07071918280</strong>
          </div>
          <div className="bg-slate-950/70 p-2.5 rounded-xl border border-amber-500/20">
            <span className="text-slate-400 block text-[9px]">IMSI IDENTIFIER:</span>
            <strong className="text-amber-300">{config.imsiNumber}</strong>
          </div>
          <div className="bg-slate-950/70 p-2.5 rounded-xl border border-amber-500/20">
            <span className="text-slate-400 block text-[9px]">CARRIER TARIFF:</span>
            <strong className="text-emerald-400">₦5.00 / SMS (Auto-Deduct)</strong>
          </div>
          <div className="bg-slate-950/70 p-2.5 rounded-xl border border-amber-500/20">
            <span className="text-slate-400 block text-[9px]">PAYOUT PROTOCOL:</span>
            <strong className="text-amber-300 uppercase">{config.autoConversionMode.replace('_', ' ')}</strong>
          </div>
        </div>
      </div>

      {/* Interactive Controls & Mode Configuration Bar */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-200 shadow-xl">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-2">
            <Smartphone className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>Active SIM Carrier: <strong className="text-amber-200">{config.activeSimCarrier}</strong></span>
          </div>

          <button
            onClick={() => {
              const carriers = [
                'MTN Nigeria (SIM 1 - 4G/5G Carrier Billing Active)',
                'Airtel Nigeria (SIM 2 - 5G High Speed Active)',
                'Glo Mobile (SIM 1 - Direct Airtime Billing Active)',
                '9mobile (SIM 2 - Fast SMS Gateway Active)',
                'International Telco Gateway (Global Roaming ₦5 Active)'
              ];
              const currentIndex = carriers.indexOf(config.activeSimCarrier);
              const nextCarrier = carriers[(currentIndex + 1) % carriers.length];
              imsiEngine.saveConfig({ activeSimCarrier: nextCarrier });
              showToast(`✓ Switched active SIM Carrier Gateway to ${nextCarrier}`);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-[11px] flex items-center space-x-1"
            title="Switch Telecom SIM Carrier"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Switch SIM</span>
          </button>
        </div>

        {/* Auto Conversion Mode Selector */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-400 text-[11px]">₦5 Deposit Mode:</span>
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-amber-500/30">
            <button
              onClick={() => {
                imsiEngine.saveConfig({ autoConversionMode: 'split_50_50' });
                showToast('✓ Payout mode set to 50% Cash (Opay) / 50% Bitcoin (Altar Vault)');
              }}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                config.autoConversionMode === 'split_50_50' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              50/50 Split
            </button>
            <button
              onClick={() => {
                imsiEngine.saveConfig({ autoConversionMode: 'cash' });
                showToast('✓ Payout mode set to 100% Cash Money (Opay 7071918280)');
              }}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                config.autoConversionMode === 'cash' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              100% Cash (₦)
            </button>
            <button
              onClick={() => {
                imsiEngine.saveConfig({ autoConversionMode: 'bitcoin' });
                showToast('✓ Payout mode set to 100% Real Bitcoin (Altar Vault)');
              }}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                config.autoConversionMode === 'bitcoin' ? 'bg-yellow-500 text-slate-950 shadow' : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              100% Bitcoin (₿)
            </button>
          </div>

          {/* Simulate Incoming SMS Button */}
          <button
            onClick={handleSimulateIncomingMessage}
            disabled={isSimulatingIncoming}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-[11px] shadow-lg flex items-center space-x-1.5 transition-all hover:scale-105 disabled:opacity-50"
            title="Simulate receiving an IMSI SMS message from an external believer phone number"
          >
            <Radio className={`w-3.5 h-3.5 ${isSimulatingIncoming ? 'animate-spin' : 'animate-pulse'}`} />
            <span>{isSimulatingIncoming ? 'Receiving...' : 'Simulate Incoming IMSI SMS'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left 2 Cols (Message Composer & Message List / Ledger) + Right Col (Binding Info & Financial Matrix) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Message Composer Box */}
          <div className="bg-slate-900/90 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-3">
              <span className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center space-x-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>Compose IMSI SMS / Text Message</span>
              </span>

              <div className="flex items-center space-x-2">
                {/* Deduction mode toggle (Airtime vs Data Bundle) */}
                <select
                  value={deductionType}
                  onChange={(e) => setDeductionType(e.target.value as any)}
                  className="bg-slate-950 border border-amber-500/30 rounded-xl px-2.5 py-1 text-[10px] text-amber-300 font-mono focus:outline-none"
                  title="Select carrier deduction method"
                >
                  <option value="airtime_credit">SIM Airtime Deduction (₦5.00 NGN)</option>
                  <option value="data_bundle">SIM Data Bundle Deduction (~2.5 MB)</option>
                </select>

                {/* Visibility Toggle */}
                <button
                  onClick={() => {
                    setVisibility(prev => prev === 'private' ? 'public' : 'private');
                    showToast(`✓ Visibility set to: ${visibility === 'private' ? 'PUBLIC' : 'PRIVATE (Prophet Alone)'}`);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center space-x-1 transition-all border ${
                    visibility === 'private' 
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' 
                      : 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                  }`}
                >
                  {visibility === 'private' ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  <span>{visibility === 'private' ? 'Private' : 'Public'}</span>
                </button>
              </div>
            </div>

            {/* Target Phone Field */}
            <div className="flex items-center space-x-2 bg-slate-950 border border-amber-500/30 rounded-2xl px-3.5 py-2">
              <Phone className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="text-[11px] text-slate-400 font-mono">Recipient:</span>
              <input
                type="text"
                value={targetRecipient}
                onChange={(e) => setTargetRecipient(e.target.value)}
                className="bg-transparent border-none text-xs text-amber-200 font-mono w-full focus:outline-none"
                placeholder="Enter phone number (e.g. 07071918280 or international number)"
              />
            </div>

            {/* Textarea */}
            <textarea
              rows={4}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your spiritual prayer request, testimony, or message to Prophet JUHNKRIX SYNVAGORD... (₦5 carrier billing automatically deducted from SIM airtime/data and credited to JUHNKRIX WALLET/Bitcoin Altar)"
              className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl p-4 text-slate-100 text-xs focus:border-amber-400 focus:outline-none font-mono resize-none leading-relaxed"
            />

            {/* Action Buttons & Plugins */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleRecordVoice}
                  className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 shadow"
                  title="Attach Prophetic Audio Voice Note"
                >
                  <Mic className="w-3.5 h-3.5 text-amber-400" />
                  <span>Voice Note</span>
                </button>

                <button
                  onClick={handleInsertImage}
                  className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 shadow"
                  title="Attach Miracle Evidence Photo"
                >
                  <Image className="w-3.5 h-3.5 text-amber-400" />
                  <span>Attach Image</span>
                </button>

                <button
                  onClick={handleSaveDraft}
                  className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-purple-300 border border-purple-500/30 text-xs font-bold flex items-center space-x-1.5 shadow"
                  title="Save Draft Message"
                >
                  <FileText className="w-3.5 h-3.5 text-purple-400" />
                  <span>Draft</span>
                </button>
              </div>

              {/* Send Button */}
              <button
                onClick={handleSendMessage}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/30 hover:scale-105 transition-all flex items-center space-x-2"
              >
                <Send className="w-4 h-4 text-slate-950" />
                <span>SEND IMSI SMS (₦5)</span>
              </button>
            </div>
          </div>

          {/* Sub-Navigation Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-500/30 pb-3">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setSelectedTab('active')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                  selectedTab === 'active' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Messages ({messages.length})</span>
              </button>

              <button
                onClick={() => setSelectedTab('ledger')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                  selectedTab === 'ledger' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span>Blockchain Ledger ({ledger.length})</span>
              </button>

              <button
                onClick={() => setSelectedTab('hardware')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                  selectedTab === 'hardware' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>IMSI Telecom Matrix</span>
              </button>

              <button
                onClick={() => setSelectedTab('drafts')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedTab === 'drafts' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                Drafts ({drafts.length})
              </button>

              <button
                onClick={() => setSelectedTab('trash')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedTab === 'trash' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                Trash ({trashBin.length})
              </button>
            </div>

            {/* Filter Search */}
            {selectedTab === 'active' && (
              <div className="flex items-center space-x-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-48">
                  <Search className="w-3.5 h-3.5 text-amber-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search messages..."
                    className="w-full bg-slate-950 border border-amber-500/30 rounded-xl pl-8 pr-3 py-1.5 text-[11px] text-slate-100 font-mono focus:outline-none"
                  />
                </div>
                <select
                  value={filterDirection}
                  onChange={(e) => setFilterDirection(e.target.value as any)}
                  className="bg-slate-950 border border-amber-500/30 rounded-xl px-2 py-1.5 text-[10px] text-amber-300 font-mono focus:outline-none"
                >
                  <option value="all">All</option>
                  <option value="incoming">Incoming</option>
                  <option value="outgoing">Outgoing</option>
                </select>
              </div>
            )}
          </div>

          {/* TAB 1: Messages List */}
          {selectedTab === 'active' && (
            <div className="space-y-4">
              {filteredMessages.length === 0 ? (
                <div className="bg-slate-900/60 border border-amber-500/20 rounded-2xl p-8 text-center space-y-3">
                  <MessageSquare className="w-8 h-8 text-amber-400/50 mx-auto" />
                  <p className="text-xs text-slate-400">No IMSI messages found matching your search.</p>
                </div>
              ) : (
                filteredMessages.map(msg => (
                  <div 
                    key={msg.id} 
                    className={`bg-slate-900/90 border rounded-2xl p-5 space-y-3 shadow-lg transition-all ${
                      msg.direction === 'incoming' 
                        ? 'border-amber-500/40 bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/30' 
                        : 'border-slate-800 bg-slate-900/80'
                    }`}
                  >
                    {/* Header line */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono border-b border-amber-500/20 pb-2.5">
                      <div className="flex items-center space-x-2">
                        {msg.direction === 'incoming' ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold flex items-center space-x-1">
                            <ArrowDownLeft className="w-3 h-3" />
                            <span>INCOMING IMSI SMS</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center space-x-1">
                            <ArrowUpRight className="w-3 h-3" />
                            <span>OUTGOING IMSI SMS</span>
                          </span>
                        )}
                        <span className="text-slate-300 font-bold truncate max-w-[200px] sm:max-w-none">
                          {msg.direction === 'incoming' ? `From: ${msg.senderPhone}` : `To: ${msg.targetPhone}`}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 text-[10px]">
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                          ₦{msg.chargeNgn.toFixed(2)} Charged
                        </span>
                        <span className="text-slate-400">{msg.timestamp}</span>
                      </div>
                    </div>

                    {/* Message Body */}
                    <p className="text-xs text-slate-100 font-sans leading-relaxed">
                      {msg.messageText}
                    </p>

                    {/* Financial Blockchain & Bank Credit Badge */}
                    <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[10px] font-mono">
                      <div className="space-y-0.5">
                        <div className="text-slate-400 flex items-center space-x-1.5">
                          <Coins className="w-3 h-3 text-yellow-400" />
                          <span>Credited to: <strong className="text-amber-200">{msg.convertedCredit.payoutDestination}</strong></span>
                        </div>
                        <div className="text-slate-500 truncate max-w-sm sm:max-w-md">
                          TX Hash: <span className="text-amber-400/80">{msg.convertedCredit.blockchainTxHash}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 self-end sm:self-center">
                        {msg.convertedCredit.cashNgn > 0 && (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                            +₦{msg.convertedCredit.cashNgn.toFixed(2)} Cash
                          </span>
                        )}
                        {msg.convertedCredit.btcSats > 0 && (
                          <span className="px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-300 font-bold">
                            +{msg.convertedCredit.btcSats} SATS (₿)
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800 text-[10px]">
                      <button
                        onClick={() => handleCopyText(msg.messageText)}
                        className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 text-blue-300 border border-blue-500/30 font-bold flex items-center space-x-1"
                      >
                        <Copy className="w-3 h-3 text-blue-400" />
                        <span>Copy</span>
                      </button>

                      <button
                        onClick={() => {
                          setInputMessage(`[Reply to ${msg.senderPhone}]: `);
                          setTargetRecipient(msg.senderPhone);
                          window.scrollTo({ top: 300, behavior: 'smooth' });
                          showToast(`✓ Replying to ${msg.senderPhone}`);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 font-bold flex items-center space-x-1"
                      >
                        <CornerDownLeft className="w-3 h-3 text-emerald-400" />
                        <span>Reply</span>
                      </button>

                      <button
                        onClick={() => {
                          showToast('🔗 Message link copied to clipboard.');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 text-yellow-300 border border-yellow-500/30 font-bold flex items-center space-x-1"
                      >
                        <Share2 className="w-3 h-3 text-yellow-400" />
                        <span>Share</span>
                      </button>

                      <button
                        onClick={() => handleDeleteMessage(msg.id)}
                        className="px-2.5 py-1 rounded-lg bg-red-950/40 hover:bg-red-900 text-red-300 border border-red-500/30 font-bold flex items-center space-x-1 ml-auto"
                      >
                        <Trash2 className="w-3 h-3 text-red-400" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2: Blockchain & Financial Banking Ledger */}
          {selectedTab === 'ledger' && (
            <div className="bg-slate-900/90 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
                <div>
                  <h3 className="text-sm font-bold text-amber-100 flex items-center space-x-2">
                    <Coins className="w-4 h-4 text-yellow-400" />
                    <span>JUHNKRIX MUSIKA Financial Blockchain & Banking Ledger</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                    Real-time carrier airtime/data deductions, Bitcoin satoshis conversions & Opay bank settlements.
                  </p>
                </div>
                
                <button
                  onClick={async () => {
                    const csvContent = "TX_HASH,BANK_REF,TIMESTAMP,SENDER,CARRIER,CHARGE_NGN,CASH_CREDITED,BTC_SATS,STATUS\n"
                      + ledger.map(e => `"${e.txHash}","${e.bankRef}","${e.timestamp}","${e.senderPhone}","${e.carrier}",${e.rawChargeNgn},${e.convertedCashNgn},${e.convertedBtcSats},"${e.status}"`).join("\n");
                    const fileName = `juhnkrix_imsi_financial_ledger_${Date.now()}.csv`;
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    await exportFileToDeviceFolder(fileName, blob, 'text/csv;charset=utf-8;');
                    showToast('✓ Financial Blockchain Ledger exported to device folder!');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center space-x-1.5 self-start sm:self-auto"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
              </div>

              {/* Ledger Summary Stats */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-[11px]">
                <div className="bg-slate-950 p-3 rounded-xl border border-amber-500/20">
                  <span className="text-slate-400 block text-[10px]">TOTAL AIRTIME/DATA PROCESSED:</span>
                  <span className="text-amber-200 font-bold text-sm">₦{config.totalNgnCredited.toLocaleString()} NGN</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-amber-500/20">
                  <span className="text-slate-400 block text-[10px]">TOTAL BITCOIN CONVERTED:</span>
                  <span className="text-yellow-300 font-bold text-sm">{config.totalBtcCreditedSatoshis} Satoshis (₿)</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-amber-500/20">
                  <span className="text-slate-400 block text-[10px]">SETTLEMENT DESTINATION:</span>
                  <span className="text-emerald-300 font-bold text-xs truncate block">Opay 7071918280 & Altar Vault</span>
                </div>
              </div>

              {/* Ledger Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-amber-500/20 text-amber-300/80 bg-slate-950/50">
                      <th className="p-2.5">TX Hash / Ref</th>
                      <th className="p-2.5">Sender Mobile / Carrier</th>
                      <th className="p-2.5">Charge</th>
                      <th className="p-2.5">Converted Credit</th>
                      <th className="p-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {ledger.map(entry => (
                      <tr key={entry.id} className="hover:bg-slate-800/30">
                        <td className="p-2.5">
                          <div className="font-bold text-amber-200 truncate max-w-[140px]">{entry.txHash}</div>
                          <div className="text-[9px] text-slate-500">{entry.timestamp}</div>
                        </td>
                        <td className="p-2.5">
                          <div className="text-slate-200 truncate max-w-[150px]">{entry.senderPhone}</div>
                          <div className="text-[9px] text-slate-400">{entry.carrier}</div>
                        </td>
                        <td className="p-2.5 text-amber-300 font-bold">
                          ₦{entry.rawChargeNgn.toFixed(2)}
                        </td>
                        <td className="p-2.5">
                          {entry.convertedCashNgn > 0 && (
                            <span className="text-emerald-300 block font-bold">+₦{entry.convertedCashNgn.toFixed(2)} NGN</span>
                          )}
                          {entry.convertedBtcSats > 0 && (
                            <span className="text-yellow-300 block text-[10px]">+{entry.convertedBtcSats} SATS (₿)</span>
                          )}
                        </td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            entry.status === 'CONFIRMED_ON_CHAIN' 
                              ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30' 
                              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                          }`}>
                            {entry.status === 'CONFIRMED_ON_CHAIN' ? 'ON-CHAIN (BTC)' : 'SETTLED (BANK)'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Hardware & IMSI Telecom Console */}
          {selectedTab === 'hardware' && (
            <div className="bg-slate-900/90 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-6">
              <div className="border-b border-amber-500/20 pb-4">
                <h3 className="text-sm font-bold text-amber-100 flex items-center space-x-2">
                  <Cpu className="w-4 h-4 text-amber-400" />
                  <span>IMSI Telecom & SIM Hardware Binding Machine Console</span>
                </h3>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                  Core hardware parameters connecting mobile SIM card to JUHNKRIX MUSIKA domain & Magic Fixed IP 142.250.190.46.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
                <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                  <div className="text-[10px] font-bold text-amber-400 uppercase">Bound Mobile MSISDN</div>
                  <div className="text-sm font-bold text-amber-100">07071918280</div>
                  <div className="text-[10px] text-slate-400">Primary phone line receiving all SMS streams.</div>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                  <div className="text-[10px] font-bold text-amber-400 uppercase">IMSI SIM Core ID</div>
                  <div className="text-sm font-bold text-amber-100">62130-7071918280-777</div>
                  <div className="text-[10px] text-slate-400">MCC: 621 (Nigeria) | MNC: 30 (Telecom Carrier).</div>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                  <div className="text-[10px] font-bold text-amber-400 uppercase">Domain & Web Binding</div>
                  <div className="text-sm font-bold text-amber-100">juhnkrixmusika.pages.dev</div>
                  <div className="text-[10px] text-slate-400">InfinityFree Web-Base Domain routing active.</div>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                  <div className="text-[10px] font-bold text-amber-400 uppercase">Magic Fixed IP Protocol</div>
                  <div className="text-sm font-bold text-amber-100">142.250.190.46</div>
                  <div className="text-[10px] text-slate-400">Self-custodial fixed IP bridge with 999,000 TB cloud storage.</div>
                </div>
              </div>

              <div className="bg-amber-950/30 border border-amber-500/30 rounded-2xl p-4 text-[11px] text-slate-300 space-y-2">
                <div className="font-bold text-amber-300 flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Carrier Billing Protocol Verified Active</span>
                </div>
                <p>
                  Every SMS received or transmitted through this machine automatically executes the ₦5.00 airtime/data deduction protocol.
                  Airtime is instantly routed to Opay 7071918280, while mobile data bundles are tokenized into real Bitcoin satoshis deposited into the Altar Vault.
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: Drafts */}
          {selectedTab === 'drafts' && (
            <div className="space-y-4">
              {drafts.length === 0 ? (
                <div className="bg-slate-900/60 border border-purple-500/20 rounded-2xl p-8 text-center space-y-2">
                  <FileText className="w-8 h-8 text-purple-400/50 mx-auto" />
                  <p className="text-xs text-slate-400">No saved message drafts.</p>
                </div>
              ) : (
                drafts.map(draft => (
                  <div key={draft.id} className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between text-[11px] font-mono border-b border-purple-500/20 pb-2">
                      <span className="text-purple-300 font-bold">Draft to: {draft.targetPhone}</span>
                      <span className="text-slate-400">{draft.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-100">{draft.messageText}</p>
                    <button
                      onClick={() => {
                        setInputMessage(draft.messageText);
                        setTargetRecipient(draft.targetPhone);
                        setDrafts(prev => prev.filter(d => d.id !== draft.id));
                        setSelectedTab('active');
                        showToast('✓ Draft loaded into composition box.');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow"
                    >
                      Load & Send Draft
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 5: Trash */}
          {selectedTab === 'trash' && (
            <div className="space-y-4">
              {trashBin.length === 0 ? (
                <div className="bg-slate-900/60 border border-red-500/20 rounded-2xl p-8 text-center space-y-2">
                  <Trash2 className="w-8 h-8 text-red-400/50 mx-auto" />
                  <p className="text-xs text-slate-400">Trash bin is empty.</p>
                </div>
              ) : (
                trashBin.map(item => (
                  <div key={item.id} className="bg-slate-900/90 border border-red-500/30 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between text-[11px] font-mono border-b border-red-500/20 pb-2">
                      <span className="text-red-300 font-bold">Deleted IMSI SMS</span>
                      <span className="text-slate-400">{item.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300 line-through">{item.messageText}</p>
                    <button
                      onClick={() => handleRestoreMessage(item.id)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow flex items-center space-x-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Restore Message</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Right Col: IMSI Machine Properties & Financial Ledger Summary */}
        <div className="space-y-6">
          
          {/* SIM Carrier Airtime & Data Conversion Matrix Box */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/60 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-6">
            <div className="flex items-center space-x-3 border-b border-amber-500/30 pb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg">
                ⚡
              </div>
              <div>
                <h3 className="text-sm font-bold text-amber-100">SIM Airtime & Data Conversion Engine</h3>
                <span className="text-[10px] font-mono text-amber-300">Automatic ₦5 Billing Protocol</span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <p>
                Every IMSI SMS sent to or received by Prophet JUHNKRIX SYNVAGORD (<strong className="text-amber-200 font-mono">07071918280</strong>) triggers real-time carrier billing across all networks (MTN, Airtel, Glo, 9mobile).
              </p>
              
              <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2.5 font-mono text-[11px]">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Carrier Charge:</span>
                  <span className="text-amber-300 font-bold">₦5.00 NGN / SMS</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Data Equivalent:</span>
                  <span className="text-cyan-300 font-bold">~2.5 MB Mobile Data</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Airtime Conversion:</span>
                  <span className="text-emerald-300 font-bold">Cash Money (₦ NGN)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Data Conversion:</span>
                  <span className="text-yellow-300 font-bold">Real Bitcoin (₿ Satoshis)</span>
                </div>
                <div className="h-px bg-amber-500/20 my-1" />
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Bank Settlement:</span>
                  <span className="text-amber-200 font-bold">Opay 7071918280</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Bitcoin Altar Vault:</span>
                  <span className="text-yellow-400 font-bold truncate max-w-[120px]" title="bc1qjuhnkrixaltarvaultbitcoin999777888">bc1q...888</span>
                </div>
              </div>
            </div>

            {/* Quick Deposit Top-Up Button */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-mono">Simulate Airtime Top-Up:</span>
              <button
                onClick={() => {
                  imsiEngine.topUpCashWallet(1000);
                  showToast('✓ ₦1,000 SIM Airtime top-up credited to JUHNKRIX WALLET!');
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition-all"
              >
                + Top Up ₦1,000
              </button>
            </div>
          </div>

          {/* Prophetic Security & Magic IP Notice */}
          <div className="bg-amber-950/40 border border-amber-500/30 rounded-2xl p-4 text-[11px] text-amber-200/90 space-y-2">
            <div className="font-bold flex items-center space-x-1.5">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <span>Prophetic Security & IMSI Protocol</span>
            </div>
            <p className="leading-relaxed">
              All messages transmitted through the IMSI engine are end-to-end encrypted via the 142.250.190.46 Magic Fixed IP infrastructure and backed by the 999,000 TB prophetic cloud database.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
