import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Eye,
  EyeOff,
  Flame,
  Heart,
  Keyboard,
  MessageCircle,
  Mic,
  RotateCcw,
  Sparkles,
  Square,
  Star,
  Timer,
  Trophy,
  Volume2,
  Zap,
} from 'lucide-react';
import type { PersistedSettings, SentenceEntry, SentenceGameModeId } from '../types';
import { translateSentencesBatch } from '../utils/aiApi';
import { getBlitzMultiplier, shuffleWithRng, createSeededRng } from '../utils/arcadeGamesLogic';
import {
  evaluateSpokenMatch,
  parseSentencesTSV,
  SENTENCE_SECTIONS,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import {
  buildChatReplyRound,
  buildClozeQuestion,
  buildFirstLetterHint,
  buildSentenceBlitzQuestion,
  buildVanishStage,
  CURATED_PRACTICE_SENTENCES,
  filterSentencesBySection,
} from '../utils/sentenceProGamesLogic';
import {
  idbGetDataset,
  idbGetSentenceTranslations,
  idbSetDataset,
  idbSetSentenceTranslations,
} from '../utils/storage';

type ProSentenceMode = Extract<
  SentenceGameModeId,
  | 'sentence_vanish'
  | 'sentence_cloze'
  | 'sentence_chat_reply'
  | 'sentence_speak'
  | 'sentence_blitz'
>;

interface SentenceGamesProArenaProps {
  mode: ProSentenceMode;
  settings: PersistedSettings;
  onSpeak: (text: string) => void;
  onSpeakSlow: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xpDelta: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onToggleFavoriteSentence: (num: number) => void;
  onUpdateSettings: (patch: Partial<PersistedSettings>) => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onExit: () => void;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: {
    resultIndex: number;
    results: { length: number; [i: number]: { 0: { transcript: string } } };
  }) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

function getSpeechRecCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

const FEATURED_SECTION_IDS = [
  'all',
  'daily_chat',
  'travel',
  'shopping',
  'short_qa',
  'apology',
  'opinions',
  'basics',
  'modals',
  'plans',
];

function useSentenceCorpus(sectionId: string) {
  const [sentences, setSentences] = useState<SentenceEntry[]>(() => {
    const starter = parseSentencesTSV(STARTER_SENTENCES_TSV);
    const curated = CURATED_PRACTICE_SENTENCES.map((c, idx) => ({
      id: 10000 + idx,
      num: c.num,
      en: c.en,
    }));
    return [...curated, ...starter];
  });

  const [arMap, setArMap] = useState<Record<string, string>>(() => ({
    ...STARTER_AR_TRANSLATIONS,
    ...Object.fromEntries(CURATED_PRACTICE_SENTENCES.map((c) => [c.en, c.ar])),
  }));

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const cached = await idbGetDataset('sentences-21k');
        if (active && cached && cached.length > 1000) {
          const parsed = parseSentencesTSV(cached);
          if (active && parsed.length > 50) setSentences(parsed);
        }
      } catch {
        // Ignore IDB miss
      }

      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const txt = await res.text();
          const parsed = parseSentencesTSV(txt);
          if (active && parsed.length > 50) {
            setSentences(parsed);
            void idbSetDataset('sentences-21k', txt);
          }
        }
      } catch {
        // Offline fallback ready
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const raw = filterSentencesBySection(sentences, sectionId);
    const good = raw.filter((s) => {
      const words = s.en.trim().split(/\s+/);
      return words.length >= 4 && words.length <= 14;
    });
    return good.length >= 8
      ? good
      : CURATED_PRACTICE_SENTENCES.map((c, i) => ({ id: i, num: c.num, en: c.en }));
  }, [sentences, sectionId]);

  const prefetchTranslations = useCallback(async (items: SentenceEntry[]) => {
    const enList = items.map((s) => s.en).filter(Boolean);
    if (!enList.length) return;

    // 1) Hydrate from IndexedDB instantly
    try {
      const cached = await idbGetSentenceTranslations(enList);
      if (Object.keys(cached).length > 0) {
        setArMap((prev) => ({ ...prev, ...cached }));
      }
      const missing = enList.filter(
        (en) => !cached[en] && !STARTER_AR_TRANSLATIONS[en] && !CURATED_PRACTICE_SENTENCES.some((c) => c.en === en)
      );
      if (missing.length > 0) {
        const fresh = await translateSentencesBatch(missing.slice(0, 12), undefined, 'ar');
        if (Object.keys(fresh).length > 0) {
          setArMap((prev) => ({ ...prev, ...fresh }));
          void idbSetSentenceTranslations(fresh);
        }
      }
    } catch {
      // Offline resilient
    }
  }, []);

  return { filtered, arMap, prefetchTranslations };
}

function SectionPicker({
  sectionId,
  onChange,
}: {
  sectionId: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {FEATURED_SECTION_IDS.map((id) => {
        const label =
          id === 'all' ? 'الكل' : SENTENCE_SECTIONS.find((s) => s.id === id)?.label || id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={`rounded-lg px-2.5 py-1 text-xs font-bold transition-colors ${
              sectionId === id
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
            }`}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}

/* ============================================================================
 * 1) VANISHING SENTENCE ("الجملة المتلاشية — حفظ سريع")
 * ============================================================================ */
function VanishingSentenceGame({
  roundItems,
  arMap,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkPracticedSentence,
  onHudChange,
  onRoundComplete,
  onReplay,
  onExit,
}: {
  roundItems: SentenceEntry[];
  arMap: Record<string, string>;
  onSpeak: (t: string) => void;
  onSfx: (t: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xp: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onHudChange: (h: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onReplay: () => void;
  onExit: () => void;
}) {
  const [idx, setIdx] = useState(0);
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [readyPct, setReadyPct] = useState(0);
  const [filledMap, setFilledMap] = useState<Record<number, string>>({});
  const [usedChipIds, setUsedChipIds] = useState<string[]>([]);
  const [typingMode, setTypingMode] = useState(false);
  const [typedInput, setTypedInput] = useState('');
  const [wrongFlash, setWrongFlash] = useState(false);
  const [completedCount, setCompletedCount] = useState(0);
  const [finished, setFinished] = useState(false);

  const current = roundItems[idx];
  const stageData = useMemo(
    () => (current ? buildVanishStage(current.en, stage, current.num + idx * 17) : null),
    [current, stage, idx]
  );

  useEffect(() => {
    onHudChange({
      current: Math.min(roundItems.length, idx + 1),
      total: roundItems.length,
      correct: completedCount,
      wrong: 0,
    });
  }, [idx, roundItems.length, completedCount, onHudChange]);

  // Stage 1: auto-speak + smooth 3-second readiness bar
  useEffect(() => {
    if (!current || stage !== 1 || finished) return;
    setReadyPct(0);
    onSpeak(current.en);
    const start = Date.now();
    const timer = window.setInterval(() => {
      const pct = Math.min(100, Math.round(((Date.now() - start) / 3000) * 100));
      setReadyPct(pct);
      if (pct >= 100) window.clearInterval(timer);
    }, 60);
    return () => window.clearInterval(timer);
  }, [current?.en, stage, finished, onSpeak]);

  const advanceStageOrSentence = useCallback(() => {
    if (!current) return;
    if (stage < 3) {
      setStage((s) => (s + 1) as 2 | 3);
      setFilledMap({});
      setUsedChipIds([]);
      setTypedInput('');
      onSfx('ok');
    } else {
      onSfx('win');
      onEarnXp(25);
      onMarkPracticedSentence(current.num);
      setCompletedCount((c) => c + 1);
      if (idx + 1 >= roundItems.length) {
        setFinished(true);
        onRoundComplete?.();
      } else {
        setIdx((i) => i + 1);
        setStage(1);
        setFilledMap({});
        setUsedChipIds([]);
        setTypedInput('');
      }
    }
  }, [current, stage, idx, roundItems.length, onSfx, onEarnXp, onMarkPracticedSentence, onRoundComplete]);

  const handleChipClick = (chip: { id: string; word: string }) => {
    if (!stageData || usedChipIds.includes(chip.id)) return;
    const nextBlankIdx = stageData.blankIndices.find((bIdx) => !filledMap[bIdx]);
    if (nextBlankIdx === undefined) return;
    const expected = stageData.tokens[nextBlankIdx].cleanWord.toLowerCase();
    if (chip.word.toLowerCase() === expected) {
      const nextFilled = { ...filledMap, [nextBlankIdx]: stageData.tokens[nextBlankIdx].cleanWord };
      setFilledMap(nextFilled);
      setUsedChipIds((prev) => [...prev, chip.id]);
      onSfx('ok');
      if (Object.keys(nextFilled).length >= stageData.blankIndices.length) {
        window.setTimeout(() => advanceStageOrSentence(), 450);
      }
    } else {
      onSfx('err');
      setWrongFlash(true);
      window.setTimeout(() => setWrongFlash(false), 300);
    }
  };

  const handleTypingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!current) return;
    const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9\s']/g, '').replace(/\s+/g, ' ').trim();
    if (norm(typedInput) === norm(current.en)) {
      advanceStageOrSentence();
    } else {
      onSfx('err');
      setWrongFlash(true);
      window.setTimeout(() => setWrongFlash(false), 300);
    }
  };

  if (finished || !current || !stageData) {
    return (
      <div className="tmn-card mx-auto max-w-xl rounded-3xl p-7 text-center">
        <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
        <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
          أتممت جولة الجملة المتلاشية!
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          رسّخت {completedCount} جمل إنجليزية كاملة عبر 3 مراحل استرجاع نشط.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={onReplay}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>جولة جديدة</span>
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>خروج</span>
          </button>
        </div>
      </div>
    );
  }

  const stageLabel =
    stage === 1
      ? 'المرحلة 1/3: احفظ الجملة واستمع للنطق'
      : stage === 2
        ? 'المرحلة 2/3: أعد بناء 35% من الكلمات المخفية'
        : 'المرحلة 3/3: استرجع 70% من الجملة من ذاكرتك';

  return (
    <div data-testid="sentence-vanish-arena" className="mx-auto max-w-2xl space-y-5">
      {/* 3-Stage Stepper */}
      <div className="tmn-card rounded-2xl p-4">
        <div className="mb-2 flex items-center justify-between text-xs font-bold">
          <span className="text-indigo-600 dark:text-indigo-400">{stageLabel}</span>
          <span className="font-code text-slate-400 tabular-nums">
            {idx + 1} / {roundItems.length}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full transition-colors ${
                s <= stage ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Sentence Display Card */}
      <div
        className={`tmn-card rounded-3xl p-6 sm:p-7 ${wrongFlash ? 'animate-match-shake border-rose-500/60' : ''}`}
      >
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-400">
            {arMap[current.en] || 'استمع للجملة واحفظ تركيبها'}
          </span>
          <button
            type="button"
            onClick={() => onSpeak(current.en)}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:text-slate-200"
          >
            <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
            <span>استمع</span>
          </button>
        </div>

        <div
          dir="ltr"
          className="mt-5 flex flex-wrap items-center gap-x-2 gap-y-2.5 font-en text-xl font-extrabold leading-relaxed text-slate-900 dark:text-white sm:text-2xl"
        >
          {stageData.tokens.map((tok) => {
            if (!tok.isBlank) {
              return <span key={tok.index}>{tok.raw}</span>;
            }
            const filled = filledMap[tok.index];
            return (
              <span key={tok.index} className="inline-flex items-center">
                {tok.leadingPunct}
                <span
                  className={`inline-flex min-w-[68px] items-center justify-center rounded-xl border-2 px-2.5 py-0.5 text-lg transition-colors ${
                    filled
                      ? 'border-emerald-500 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                      : 'border-dashed border-indigo-400/70 bg-indigo-500/10 text-transparent'
                  }`}
                >
                  {filled || tok.cleanWord}
                </span>
                {tok.trailingPunct}
              </span>
            );
          })}
        </div>

        {stage === 1 ? (
          <div className="mt-6 space-y-3">
            <div className="tmn-progress-track h-2 w-full">
              <div className="tmn-progress-fill h-full" style={{ width: `${readyPct}%` }} />
            </div>
            <button
              type="button"
              data-testid="vanish-ready-btn"
              onClick={() => advanceStageOrSentence()}
              className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 text-sm font-extrabold text-white hover:bg-indigo-700"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <span>جاهز للمرحلة التالية</span>
            </button>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {stage === 3 && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setTypingMode((m) => !m)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400"
                >
                  <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{typingMode ? 'العودة لبطاقات الكلمات' : 'وضع الكتابة الكاملة'}</span>
                </button>
              </div>
            )}

            {stage === 3 && typingMode ? (
              <form onSubmit={handleTypingSubmit} className="flex flex-col gap-2 sm:flex-row">
                <input
                  type="text"
                  dir="ltr"
                  value={typedInput}
                  onChange={(e) => setTypedInput(e.target.value)}
                  placeholder="Type the complete sentence from memory..."
                  className="h-11 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 font-en text-sm font-semibold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#0d1424] dark:text-white"
                />
                <button
                  type="submit"
                  className="h-11 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
                >
                  تحقق
                </button>
              </form>
            ) : (
              <div dir="ltr" className="flex flex-wrap gap-2">
                {stageData.chips.map((chip) => {
                  const used = usedChipIds.includes(chip.id);
                  return (
                    <button
                      key={chip.id}
                      type="button"
                      disabled={used}
                      onClick={() => handleChipClick(chip)}
                      className={`rounded-xl border px-3.5 py-2 font-en text-sm font-bold transition-colors ${
                        used
                          ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-40 dark:border-slate-800 dark:bg-slate-900'
                          : 'border-indigo-300 bg-white text-slate-900 hover:border-indigo-500 hover:bg-indigo-50 dark:border-indigo-500/40 dark:bg-[#162036] dark:text-white dark:hover:bg-indigo-500/20'
                      }`}
                    >
                      {chip.word}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * 2) SMART SENTENCE CLOZE ("أكمل الفراغ الذكي")
 * ============================================================================ */
function SmartClozeGame({
  roundItems,
  allPool,
  arMap,
  onSpeak,
  onSfx,
  onEarnXp,
  onMarkPracticedSentence,
  onHudChange,
  onRoundComplete,
  onReplay,
  onExit,
}: {
  roundItems: SentenceEntry[];
  allPool: SentenceEntry[];
  arMap: Record<string, string>;
  onSpeak: (t: string) => void;
  onSfx: (t: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xp: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onHudChange: (h: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onReplay: () => void;
  onExit: () => void;
}) {
  const questions = useMemo(
    () =>
      roundItems
        .map((s, i) => buildClozeQuestion(s, allPool, arMap, s.num + i * 31))
        .filter((q): q is NonNullable<typeof q> => q !== null),
    [roundItems, allPool, arMap]
  );

  const [idx, setIdx] = useState(0);
  const [inputMode, setInputMode] = useState<'choice' | 'type'>('choice');
  const [typedWord, setTypedWord] = useState('');
  const [answered, setAnswered] = useState(false);
  const [isRight, setIsRight] = useState(false);
  const [pickedWord, setPickedWord] = useState('');
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [finished, setFinished] = useState(false);

  const cur = questions[idx];

  useEffect(() => {
    onHudChange({
      current: Math.min(questions.length, idx + 1),
      total: Math.max(1, questions.length),
      correct: correctCount,
      wrong: wrongCount,
    });
  }, [idx, questions.length, correctCount, wrongCount, onHudChange]);

  const submitAnswer = (guess: string) => {
    if (!cur || answered) return;
    const ok = guess.trim().toLowerCase() === cur.targetWord.trim().toLowerCase();
    setPickedWord(guess);
    setAnswered(true);
    setIsRight(ok);
    if (ok) {
      setCorrectCount((c) => c + 1);
      onSfx('ok');
      onEarnXp(15);
      onMarkPracticedSentence(cur.sentence.num);
    } else {
      setWrongCount((w) => w + 1);
      onSfx('err');
    }
    onSpeak(cur.sentence.en);
  };

  const handleNext = () => {
    if (idx + 1 >= questions.length) {
      setFinished(true);
      onSfx('win');
      onRoundComplete?.();
    } else {
      setIdx((i) => i + 1);
      setAnswered(false);
      setIsRight(false);
      setPickedWord('');
      setTypedWord('');
    }
  };

  if (finished || !cur) {
    return (
      <div className="tmn-card mx-auto max-w-xl rounded-3xl p-7 text-center">
        <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
        <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
          أنهيت جولة أكمل الفراغ الذكي!
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          إجابات صحيحة: {correctCount} من {questions.length}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={onReplay}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>جولة جديدة</span>
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>خروج</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div data-testid="sentence-cloze-arena" className="mx-auto max-w-2xl space-y-5">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-2 rounded-2xl p-4">
        <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-900/70">
          <button
            type="button"
            onClick={() => setInputMode('choice')}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold ${
              inputMode === 'choice'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            اختيار سريع
          </button>
          <button
            type="button"
            onClick={() => setInputMode('type')}
            className={`rounded-lg px-3 py-1.5 text-xs font-extrabold ${
              inputMode === 'type'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            كتابة يدوية
          </button>
        </div>

        <button
          type="button"
          onClick={() => onSpeak(cur.sentence.en)}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
        >
          <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
          <span>استمع للجملة</span>
        </button>
      </div>

      <div className="tmn-card rounded-3xl p-6 sm:p-8">
        <div className="text-sm font-bold text-indigo-600 dark:text-indigo-300">
          {cur.ar || arMap[cur.sentence.en] || 'اختر الكلمة المناسبة لإكمال الجملة'}
        </div>

        <div
          dir="ltr"
          className="mt-4 font-en text-2xl font-extrabold leading-relaxed text-slate-900 dark:text-white"
        >
          {cur.beforeBlank}
          <span
            className={`mx-1 inline-block rounded-xl border-2 px-3 py-0.5 ${
              answered
                ? 'border-emerald-500 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                : 'border-dashed border-indigo-400 bg-indigo-500/10 text-indigo-500'
            }`}
          >
            {answered ? cur.targetWord : '______'}
          </span>
          {cur.afterBlank}
        </div>

        {inputMode === 'choice' ? (
          <div dir="ltr" className="mt-6 grid grid-cols-2 gap-3">
            {cur.options.map((opt) => {
              const isTarget = opt.toLowerCase() === cur.targetWord.toLowerCase();
              const isPicked = opt.toLowerCase() === pickedWord.toLowerCase();
              return (
                <button
                  key={opt}
                  type="button"
                  disabled={answered}
                  onClick={() => submitAnswer(opt)}
                  className={`min-h-[52px] rounded-2xl border px-4 py-2.5 font-en text-base font-bold transition-colors ${
                    answered && isTarget
                      ? 'border-emerald-500 bg-emerald-600 text-white'
                      : answered && isPicked && !isTarget
                        ? 'border-rose-500 bg-rose-600 text-white'
                        : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-indigo-500 hover:bg-indigo-50 dark:border-slate-700 dark:bg-[#0d1424] dark:text-white dark:hover:border-indigo-400'
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (typedWord.trim()) submitAnswer(typedWord);
            }}
            className="mt-6 flex gap-2"
          >
            <input
              type="text"
              dir="ltr"
              disabled={answered}
              value={typedWord}
              onChange={(e) => setTypedWord(e.target.value)}
              placeholder="اكتب الكلمة الناقصة بالإنجليزية..."
              className="h-12 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 font-en text-base font-bold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#0d1424] dark:text-white"
            />
            <button
              type="submit"
              disabled={answered || !typedWord.trim()}
              className="h-12 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              تحقق
            </button>
          </form>
        )}

        {answered && (
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4 dark:border-slate-800">
            <span
              className={`text-sm font-extrabold ${
                isRight ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {isRight ? 'إجابة صحيحة! (+15 XP)' : `الإجابة الصحيحة هي: ${cur.targetWord}`}
            </span>
            <button
              type="button"
              data-testid="cloze-next-btn"
              onClick={handleNext}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
            >
              <span>الجملة التالية</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * 3) QUICK CHAT REPLY ("الرد السريع في المحادثة")
 * ============================================================================ */
function QuickChatReplyGame({
  sectionId,
  seed,
  onSpeak,
  onSfx,
  onEarnXp,
  onHudChange,
  onRoundComplete,
  onReplay,
  onExit,
}: {
  sectionId: string;
  seed: number;
  onSpeak: (t: string) => void;
  onSfx: (t: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xp: number) => void;
  onHudChange: (h: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onReplay: () => void;
  onExit: () => void;
}) {
  const round = useMemo(() => buildChatReplyRound(sectionId, 10, seed), [sectionId, seed]);
  const [idx, setIdx] = useState(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [streak, setStreak] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [finished, setFinished] = useState(false);

  const cur = round[idx];

  useEffect(() => {
    setIdx(0);
    setSelectedIdx(null);
    setFinished(false);
  }, [sectionId, seed]);

  useEffect(() => {
    onHudChange({
      current: Math.min(round.length, idx + 1),
      total: round.length,
      correct: correctCount,
      wrong: wrongCount,
    });
  }, [idx, round.length, correctCount, wrongCount, onHudChange]);

  useEffect(() => {
    if (cur && selectedIdx === null && !finished) {
      onSpeak(cur.dialogue.incomingEn);
    }
  }, [cur?.dialogue.id, selectedIdx, finished, onSpeak]);

  if (finished || !cur) {
    return (
      <div className="tmn-card mx-auto max-w-xl rounded-3xl p-7 text-center">
        <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
        <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
          محادثة رائعة!
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          ردود طبيعية صحيحة: {correctCount} من {round.length}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={onReplay}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>محادثات جديدة</span>
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>خروج</span>
          </button>
        </div>
      </div>
    );
  }

  const handleChoose = (optIdx: number) => {
    if (selectedIdx !== null) return;
    setSelectedIdx(optIdx);
    const chosen = cur.options[optIdx];
    if (chosen.isCorrect) {
      setCorrectCount((c) => c + 1);
      setStreak((s) => s + 1);
      onSfx('ok');
      onEarnXp(15);
      onSpeak(chosen.text);
    } else {
      setWrongCount((w) => w + 1);
      setStreak(0);
      onSfx('err');
      onSpeak(cur.dialogue.replyEn);
    }
  };

  const chosenOpt = selectedIdx !== null ? cur.options[selectedIdx] : null;

  return (
    <div data-testid="sentence-chat-reply-arena" className="mx-auto max-w-2xl space-y-5">
      <div className="tmn-card flex items-center justify-between rounded-2xl px-4 py-3 text-xs font-bold">
        <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
          <Flame className="h-4 w-4" aria-hidden="true" />
          سلسلة المحادثة: {streak}
        </span>
        <span className="font-code text-slate-400 tabular-nums">
          {idx + 1} / {round.length}
        </span>
      </div>

      {/* Chat Thread Window */}
      <div className="tmn-card space-y-4 rounded-3xl p-5 sm:p-6">
        {/* Incoming Bubble */}
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-indigo-600 font-en text-sm font-extrabold text-white">
            {cur.dialogue.speakerName.slice(0, 1)}
          </div>
          <div className="max-w-[85%] rounded-2xl rounded-tr-sm border border-slate-200 bg-slate-50 p-4 dark:border-slate-700/80 dark:bg-[#0d1424]">
            <div className="mb-1 flex items-center justify-between gap-3">
              <span className="font-en text-xs font-bold text-indigo-600 dark:text-indigo-400">
                {cur.dialogue.speakerName}
              </span>
              <button
                type="button"
                onClick={() => onSpeak(cur.dialogue.incomingEn)}
                aria-label="استمع للرسالة"
                className="text-slate-400 hover:text-indigo-500"
              >
                <Volume2 className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
            <p dir="ltr" className="font-en text-base font-bold text-slate-900 dark:text-white sm:text-lg">
              {cur.dialogue.incomingEn}
            </p>
            {selectedIdx !== null && (
              <p className="mt-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                {cur.dialogue.incomingAr}
              </p>
            )}
          </div>
        </div>

        {/* Outgoing User Bubble (animated when answered) */}
        {chosenOpt && (
          <div className="flex justify-end animate-tile-pop">
            <div
              className={`max-w-[85%] rounded-2xl rounded-tl-sm p-4 text-white ${
                chosenOpt.isCorrect ? 'bg-emerald-600' : 'bg-rose-600'
              }`}
            >
              <p dir="ltr" className="font-en text-base font-bold">
                {chosenOpt.text}
              </p>
              <p className="mt-1 text-xs opacity-90">{chosenOpt.ar}</p>
            </div>
          </div>
        )}

        {chosenOpt && !chosenOpt.isCorrect && (
          <div className="rounded-2xl border border-emerald-500/35 bg-emerald-500/10 p-3.5 text-sm">
            <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
              الرد الطبيعي الأنسب:
            </div>
            <div dir="ltr" className="mt-1 font-en font-bold text-slate-900 dark:text-white">
              {cur.dialogue.replyEn}
            </div>
            <div className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
              {cur.dialogue.replyAr}
            </div>
          </div>
        )}

        {/* 4 Reply Options */}
        <div className="space-y-2.5 pt-2">
          <div className="text-xs font-bold text-slate-400">اختر الرد الطبيعي المناسب:</div>
          {cur.options.map((opt, oIdx) => {
            const picked = selectedIdx === oIdx;
            return (
              <button
                key={oIdx}
                type="button"
                data-testid={`chat-reply-opt-${opt.isCorrect ? 'correct' : oIdx}`}
                disabled={selectedIdx !== null}
                onClick={() => handleChoose(oIdx)}
                dir="ltr"
                className={`w-full rounded-2xl border px-4 py-3 text-left font-en text-sm font-bold transition-colors sm:text-base ${
                  selectedIdx !== null && opt.isCorrect
                    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                    : picked && !opt.isCorrect
                      ? 'border-rose-500 bg-rose-500/15 text-rose-700 dark:text-rose-300'
                      : 'border-slate-200 bg-white text-slate-800 hover:border-indigo-500 hover:bg-indigo-50 dark:border-slate-700/80 dark:bg-[#151f35] dark:text-slate-100 dark:hover:border-indigo-400'
                }`}
              >
                {opt.text}
              </button>
            );
          })}
        </div>

        {selectedIdx !== null && (
          <div className="flex justify-end pt-2">
            <button
              type="button"
              data-testid="chat-reply-next-btn"
              onClick={() => {
                if (idx + 1 >= round.length) {
                  setFinished(true);
                  onSfx('win');
                  onRoundComplete?.();
                } else {
                  setIdx((i) => i + 1);
                  setSelectedIdx(null);
                }
              }}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
            >
              <span>الجملة التالية</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * 4) SPEAK TO UNLOCK ("تحدي النطق المباشر")
 * ============================================================================ */
function SpeakToUnlockGame({
  roundItems,
  arMap,
  onSpeak,
  onSpeakSlow,
  onSfx,
  onEarnXp,
  onMarkPracticedSentence,
  onHudChange,
  onRoundComplete,
  onReplay,
  onExit,
}: {
  roundItems: SentenceEntry[];
  arMap: Record<string, string>;
  onSpeak: (t: string) => void;
  onSpeakSlow: (t: string) => void;
  onSfx: (t: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xp: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onHudChange: (h: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onReplay: () => void;
  onExit: () => void;
}) {
  const [idx, setIdx] = useState(0);
  const [memoryMask, setMemoryMask] = useState(false);
  const [listening, setListening] = useState(false);
  const [liveText, setLiveText] = useState('');
  const [evalRes, setEvalRes] = useState<ReturnType<typeof evaluateSpokenMatch> | null>(null);
  const [unlockedCount, setUnlockedCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [manualText, setManualText] = useState('');
  const recRef = useRef<SpeechRecognitionLike | null>(null);

  const cur = roundItems[idx];
  const hasSpeechRec = useMemo(() => Boolean(getSpeechRecCtor()), []);

  useEffect(() => {
    onHudChange({
      current: Math.min(roundItems.length, idx + 1),
      total: roundItems.length,
      correct: unlockedCount,
      wrong: 0,
    });
  }, [idx, roundItems.length, unlockedCount, onHudChange]);

  useEffect(() => {
    return () => {
      try {
        recRef.current?.stop();
      } catch {
        // Ignore
      }
    };
  }, []);

  const gradeSpoken = useCallback(
    (transcript: string) => {
      if (!cur || !transcript.trim()) return;
      const result = evaluateSpokenMatch(cur.en, transcript);
      setEvalRes(result);
      if (result.score >= 80) {
        onSfx('win');
        onEarnXp(20);
        onMarkPracticedSentence(cur.num);
        setUnlockedCount((c) => c + 1);
      } else {
        onSfx('err');
      }
    },
    [cur, onSfx, onEarnXp, onMarkPracticedSentence]
  );

  const toggleMic = () => {
    if (listening) {
      try {
        recRef.current?.stop();
      } catch {
        // Ignore
      }
      setListening(false);
      if (liveText.trim()) gradeSpoken(liveText);
      return;
    }

    const Ctor = getSpeechRecCtor();
    if (!Ctor) return;
    setEvalRes(null);
    setLiveText('');
    const rec = new Ctor();
    rec.lang = 'en-US';
    rec.continuous = false;
    rec.interimResults = true;
    let finalTxt = '';
    rec.onresult = (e) => {
      let combined = '';
      for (let i = 0; i < e.results.length; i++) {
        combined += e.results[i][0].transcript + ' ';
      }
      finalTxt = combined.trim();
      setLiveText(finalTxt);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => {
      setListening(false);
      if (finalTxt.trim()) gradeSpoken(finalTxt);
    };
    recRef.current = rec;
    setListening(true);
    try {
      rec.start();
    } catch {
      setListening(false);
    }
  };

  const handleNext = () => {
    if (idx + 1 >= roundItems.length) {
      setFinished(true);
      onRoundComplete?.();
    } else {
      setIdx((i) => i + 1);
      setEvalRes(null);
      setLiveText('');
      setManualText('');
    }
  };

  if (finished || !cur) {
    return (
      <div className="tmn-card mx-auto max-w-xl rounded-3xl p-7 text-center">
        <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
        <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
          تحدي النطق مكتمل!
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          نجحت في نطق وفتح {unlockedCount} من {roundItems.length} جملة بدقة عالية.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={onReplay}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>جولة جديدة</span>
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>خروج</span>
          </button>
        </div>
      </div>
    );
  }

  const passed = Boolean(evalRes && evalRes.score >= 80);

  return (
    <div data-testid="sentence-speak-arena" className="mx-auto max-w-2xl space-y-5">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-2 rounded-2xl p-4">
        <button
          type="button"
          data-testid="speak-memory-toggle"
          onClick={() => setMemoryMask((m) => !m)}
          className={`inline-flex h-9 items-center gap-1.5 rounded-xl border px-3 text-xs font-bold transition-colors ${
            memoryMask
              ? 'border-indigo-500 bg-indigo-500/15 text-indigo-700 dark:text-indigo-300'
              : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
          }`}
        >
          {memoryMask ? <Eye className="h-4 w-4" aria-hidden="true" /> : <EyeOff className="h-4 w-4" aria-hidden="true" />}
          <span>{memoryMask ? 'إظهار النص الكامل' : 'وضع الذاكرة — إخفاء النص'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onSpeak(cur.en)}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
            <span>استمع</span>
          </button>
          <button
            type="button"
            onClick={() => onSpeakSlow(cur.en)}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <span>ببطء 0.7x</span>
          </button>
        </div>
      </div>

      <div className="tmn-card rounded-3xl p-6 text-center sm:p-8">
        <div className="text-sm font-bold text-indigo-600 dark:text-indigo-300">
          {arMap[cur.en] || 'انطق الجملة بوضوح لفتح الجملة التالية'}
        </div>

        {/* Target Sentence or Word-by-word Highlight */}
        <div dir="ltr" className="mt-4 font-en text-2xl font-extrabold leading-relaxed text-slate-900 dark:text-white">
          {evalRes?.tokens && evalRes.tokens.length > 0 ? (
            <div className="flex flex-wrap justify-center gap-1.5">
              {evalRes.tokens.map((tk, i) => (
                <span
                  key={i}
                  className={`rounded-lg px-2 py-0.5 ${
                    tk.matched
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                      : 'bg-rose-500/15 text-rose-600 dark:text-rose-300'
                  }`}
                >
                  {tk.word}
                </span>
              ))}
            </div>
          ) : memoryMask ? (
            <span className="tracking-wide text-slate-700 dark:text-slate-200">
              {buildFirstLetterHint(cur.en)}
            </span>
          ) : (
            cur.en
          )}
        </div>

        {/* Big Tactile Mic Button */}
        <div className="mt-7 flex flex-col items-center">
          <button
            type="button"
            data-testid="speak-mic-btn"
            disabled={!hasSpeechRec}
            onClick={toggleMic}
            aria-label={listening ? 'إيقاف التسجيل' : 'ابدأ التحدث'}
            className={`flex h-20 w-20 items-center justify-center rounded-full shadow-lg transition-transform active:scale-95 disabled:opacity-45 ${
              listening
                ? 'bg-rose-600 text-white ring-8 ring-rose-500/25'
                : 'bg-indigo-600 text-white hover:bg-indigo-700 ring-8 ring-indigo-500/15'
            }`}
          >
            {listening ? <Square className="h-7 w-7" aria-hidden="true" /> : <Mic className="h-8 w-8" aria-hidden="true" />}
          </button>
          <span className="mt-3 text-xs font-bold text-slate-500 dark:text-slate-400">
            {!hasSpeechRec
              ? 'متصفحك لا يدعم التعرف التلقائي على الصوت — يمكنك التدرب بالكتابة أدناه'
              : listening
                ? 'جاري الاستماع... تكلّم الآن'
                : 'اضغط الميكروفون وانطق الجملة (تحتاج 80% فأكثر لفتح التالية)'}
          </span>
        </div>

        {liveText && (
          <p dir="ltr" className="mt-3 font-en text-sm font-semibold text-slate-500 dark:text-slate-400">
            “{liveText}”
          </p>
        )}

        {/* Accuracy Result */}
        {evalRes && (
          <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/70">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className={passed ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}>
                {passed ? 'أحسنت! نطق واضح (+20 XP)' : 'قريب جداً — استمع ببطء وحاول مجدداً'}
              </span>
              <span className="font-code text-base tabular-nums">{evalRes.score}%</span>
            </div>
            <div className="tmn-progress-track mt-2 h-2 w-full">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all"
                style={{ width: `${evalRes.score}%` }}
              />
            </div>
          </div>
        )}

        {/* Quiet fallback input for browsers without SpeechRecognition */}
        {!hasSpeechRec && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (manualText.trim()) gradeSpoken(manualText);
            }}
            className="mt-4 flex gap-2"
          >
            <input
              type="text"
              dir="ltr"
              value={manualText}
              onChange={(e) => setManualText(e.target.value)}
              placeholder="Type the sentence to test..."
              className="h-11 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 font-en text-sm dark:border-slate-700 dark:bg-[#0d1424] dark:text-white"
            />
            <button
              type="submit"
              className="h-11 rounded-xl bg-indigo-600 px-4 text-xs font-extrabold text-white"
            >
              تقييم
            </button>
          </form>
        )}

        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={handleNext}
            className={`inline-flex h-11 items-center gap-2 rounded-xl px-5 text-xs font-extrabold ${
              passed
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800'
            }`}
          >
            <span>{passed ? 'الجملة التالية' : 'تخطي الجملة'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
 * 5) 60-SECOND SENTENCE SPEED BLITZ ("سباق الجمل — 60 ثانية")
 * ============================================================================ */
function SentenceSpeedBlitzGame({
  allPool,
  arMap,
  settings,
  onSpeak,
  onSfx,
  onEarnXp,
  onToggleFavoriteSentence,
  onUpdateSettings,
  onHudChange,
  onRoundComplete,
  onExit,
}: {
  allPool: SentenceEntry[];
  arMap: Record<string, string>;
  settings: PersistedSettings;
  onSpeak: (t: string) => void;
  onSfx: (t: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xp: number) => void;
  onToggleFavoriteSentence: (num: number) => void;
  onUpdateSettings: (patch: Partial<PersistedSettings>) => void;
  onHudChange: (h: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onExit: () => void;
}) {
  const translatedPool = useMemo(() => {
    const pairs: Array<{ sentence: SentenceEntry; ar: string }> = [];
    const seen = new Set<string>();
    for (const s of allPool) {
      const ar = arMap[s.en];
      if (ar && ar.trim() && !seen.has(s.en)) {
        seen.add(s.en);
        pairs.push({ sentence: s, ar });
      }
      if (pairs.length >= 60) break;
    }
    if (pairs.length < 8) {
      for (const c of CURATED_PRACTICE_SENTENCES) {
        if (!seen.has(c.en)) {
          seen.add(c.en);
          pairs.push({ sentence: { id: c.num, num: c.num, en: c.en }, ar: c.ar });
        }
      }
    }
    return pairs;
  }, [allPool, arMap]);

  const [phase, setPhase] = useState<'playing' | 'over'>('playing');
  const [timeLeft, setTimeLeft] = useState(60);
  const [hearts, setHearts] = useState(3);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [roundIdx, setRoundIdx] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [missed, setMissed] = useState<Array<{ num: number; en: string; ar: string }>>([]);
  const recentRef = useRef<Set<number>>(new Set());
  const [question, setQuestion] = useState(() =>
    buildSentenceBlitzQuestion(translatedPool, 0, Date.now(), new Set())
  );

  const bestScore = Math.max(settings.bestSentenceBlitzScore || 0, score);
  const multiplier = getBlitzMultiplier(streak);

  const finishGame = useCallback(
    (finalScore: number) => {
      setPhase('over');
      onSfx('win');
      onEarnXp(Math.max(15, Math.min(80, Math.round(finalScore / 12))));
      onRoundComplete?.();
      if (finalScore > (settings.bestSentenceBlitzScore || 0)) {
        onUpdateSettings({ bestSentenceBlitzScore: finalScore });
      }
    },
    [onSfx, onEarnXp, onRoundComplete, settings.bestSentenceBlitzScore, onUpdateSettings]
  );

  const resetGame = () => {
    recentRef.current.clear();
    setPhase('playing');
    setTimeLeft(60);
    setHearts(3);
    setScore(0);
    setStreak(0);
    setRoundIdx(0);
    setCorrectCount(0);
    setWrongCount(0);
    setMissed([]);
    setQuestion(buildSentenceBlitzQuestion(translatedPool, 0, Date.now(), new Set()));
  };

  useEffect(() => {
    onHudChange({
      current: roundIdx + 1,
      total: Math.max(15, roundIdx + 1),
      correct: correctCount,
      wrong: wrongCount,
    });
  }, [roundIdx, correctCount, wrongCount, onHudChange]);

  useEffect(() => {
    if (phase !== 'playing') return;
    const id = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0.5) {
          window.clearInterval(id);
          return 0;
        }
        return Math.max(0, Number((prev - 0.5).toFixed(1)));
      });
    }, 500);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'playing' && timeLeft === 0) {
      finishGame(score);
    }
  }, [phase, timeLeft, score, finishGame]);

  const handlePick = (isCorrect: boolean) => {
    if (phase !== 'playing' || !question) return;
    if (isCorrect) {
      const nextStreak = streak + 1;
      const mult = getBlitzMultiplier(nextStreak);
      setStreak(nextStreak);
      setScore((s) => s + 10 * mult);
      setCorrectCount((c) => c + 1);
      if (nextStreak % 5 === 0) {
        setTimeLeft((t) => Math.min(60, Number((t + 1.5).toFixed(1))));
        onSfx('win');
      } else {
        onSfx('ok');
      }
      const nextIdx = roundIdx + 1;
      setRoundIdx(nextIdx);
      recentRef.current.add(question.sentence.num);
      setQuestion(buildSentenceBlitzQuestion(translatedPool, nextIdx, Date.now(), recentRef.current));
    } else {
      const nextHearts = hearts - 1;
      setHearts(nextHearts);
      setStreak(0);
      setWrongCount((w) => w + 1);
      setMissed((prev) =>
        prev.some((m) => m.num === question.sentence.num)
          ? prev
          : [...prev, { num: question.sentence.num, en: question.sentence.en, ar: question.ar }]
      );
      onSfx('err');
      if (nextHearts <= 0) {
        finishGame(score);
      } else {
        const nextIdx = roundIdx + 1;
        setRoundIdx(nextIdx);
        setQuestion(buildSentenceBlitzQuestion(translatedPool, nextIdx, Date.now(), recentRef.current));
      }
    }
  };

  if (phase === 'over') {
    const isNewRecord = score > 0 && score >= bestScore;
    return (
      <div className="tmn-card mx-auto max-w-2xl rounded-3xl p-6 text-center sm:p-8">
        <Trophy className="mx-auto h-10 w-10 text-amber-500" aria-hidden="true" />
        <h2 className="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">
          انتهى سباق الجمل! {isNewRecord ? '· رقم قياسي جديد' : ''}
        </h2>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
            <div className="text-xs font-bold text-slate-400">النقاط</div>
            <div className="mt-1 font-code text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
              {score}
            </div>
          </div>
          <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
            <div className="text-xs font-bold text-slate-400">أعلى رقم</div>
            <div className="mt-1 font-code text-2xl font-extrabold text-emerald-500">{bestScore}</div>
          </div>
          <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900/70">
            <div className="text-xs font-bold text-slate-400">الدقة</div>
            <div className="mt-1 font-code text-2xl font-extrabold text-slate-900 dark:text-white">
              {Math.round((correctCount / Math.max(1, correctCount + wrongCount)) * 100)}%
            </div>
          </div>
        </div>

        {missed.length > 0 && (
          <div className="mt-6 space-y-2 text-start">
            <div className="text-xs font-bold text-slate-400">جمل تحتاج مراجعة:</div>
            {missed.map((m) => {
              const isFav = (settings.favoriteSentences || []).includes(m.num);
              return (
                <div
                  key={m.num}
                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs dark:border-slate-800"
                >
                  <div className="min-w-0">
                    <div dir="ltr" className="truncate font-en font-bold text-slate-900 dark:text-white">
                      {m.en}
                    </div>
                    <div className="truncate text-slate-500 dark:text-slate-400">{m.ar}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleFavoriteSentence(m.num)}
                    className={`inline-flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1 font-bold ${
                      isFav
                        ? 'border-amber-400 bg-amber-500/15 text-amber-600 dark:text-amber-300'
                        : 'border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Star className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>{isFav ? 'بالمفضلة' : 'حفظ'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            onClick={resetGame}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-extrabold text-white hover:bg-indigo-700"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>العب مجدداً</span>
          </button>
          <button
            type="button"
            onClick={onExit}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700 dark:border-slate-700 dark:text-slate-200"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>خروج</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div data-testid="sentence-blitz-arena" className="mx-auto max-w-2xl space-y-5">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 font-code text-lg font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
            <Timer className="h-5 w-5" aria-hidden="true" />
            <span>{Math.ceil(timeLeft)}s</span>
          </div>
          <div className="flex items-center gap-1">
            {[0, 1, 2].map((i) => (
              <Heart
                key={i}
                className={`h-5 w-5 ${
                  i < hearts ? 'fill-rose-500 text-rose-500' : 'text-slate-300 dark:text-slate-700'
                }`}
                aria-hidden="true"
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-extrabold tabular-nums">
          <span className="rounded-lg bg-amber-500/15 px-2.5 py-1 font-code text-amber-600 dark:text-amber-300">
            x{multiplier}
          </span>
          <span className="font-code text-base text-slate-900 dark:text-white">{score}</span>
          <span className="text-slate-400">
            الأعلى: <strong className="font-code text-emerald-500">{bestScore}</strong>
          </span>
        </div>
      </div>

      {question && (
        <div className="tmn-card rounded-3xl p-6 text-center sm:p-8">
          <div className="text-xs font-bold text-slate-400">
            {question.direction === 'en2ar'
              ? 'اختر الترجمة العربية الصحيحة'
              : 'اختر الجملة الإنجليزية المطابقة'}{' '}
            · +1.5s كل 5 إجابات
          </div>
          <div
            dir={question.direction === 'en2ar' ? 'ltr' : 'rtl'}
            className={`mt-3 text-xl font-extrabold text-slate-900 dark:text-white sm:text-2xl ${
              question.direction === 'en2ar' ? 'font-en' : ''
            }`}
          >
            {question.prompt}
          </div>
          <button
            type="button"
            onClick={() => onSpeak(question.sentence.en)}
            className="mt-3 inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 dark:border-slate-700 dark:text-slate-300"
          >
            <Volume2 className="h-3.5 w-3.5 text-indigo-500" aria-hidden="true" />
            <span>استمع للجملة</span>
          </button>

          <div className="mt-6 space-y-2.5">
            {question.options.map((opt, idx) => (
              <button
                key={`${question.sentence.num}-${opt.id}-${idx}`}
                type="button"
                dir={question.direction === 'ar2en' ? 'ltr' : 'rtl'}
                onClick={() => handlePick(opt.isCorrect)}
                className={`w-full rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3.5 text-start text-sm font-bold text-slate-900 transition-colors hover:border-indigo-500 hover:bg-indigo-50 dark:border-slate-700/80 dark:bg-[#0d1424] dark:text-slate-100 dark:hover:border-indigo-400 dark:hover:bg-indigo-500/15 sm:text-base ${
                  question.direction === 'ar2en' ? 'font-en' : ''
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================================================================
 * MAIN EXPORTED PRO SENTENCE ARENA
 * ============================================================================ */
export function SentenceGamesProArena(props: SentenceGamesProArenaProps) {
  const { mode, onExit } = props;
  const [sectionId, setSectionId] = useState<string>('all');
  const [seed, setSeed] = useState(() => Date.now());
  const { filtered, arMap, prefetchTranslations } = useSentenceCorpus(sectionId);

  const roundItems = useMemo(() => {
    const rng = createSeededRng(seed);
    return shuffleWithRng(filtered, rng).slice(0, 8);
  }, [filtered, seed]);

  // Background prefetch translations for the current round's 10 sentences (0ms wait)
  useEffect(() => {
    void prefetchTranslations(roundItems);
  }, [roundItems, prefetchTranslations]);

  const meta: Record<ProSentenceMode, { title: string; subtitle: string; icon: React.ReactNode }> = {
    sentence_vanish: {
      title: 'الجملة المتلاشية — حفظ سريع',
      subtitle: 'تدرّج ذكي من 3 مراحل لحفظ الجمل الإنجليزية في الذاكرة طويلة المدى',
      icon: <Sparkles className="h-5 w-5" aria-hidden="true" />,
    },
    sentence_cloze: {
      title: 'أكمل الفراغ الذكي',
      subtitle: 'اختر أو اكتب الكلمة المحذوفة لإتقان السياق والقواعد معاً',
      icon: <CheckCircle2 className="h-5 w-5" aria-hidden="true" />,
    },
    sentence_chat_reply: {
      title: 'الرد السريع في المحادثة',
      subtitle: 'اختر الرد الإنجليزي الطبيعي في مواقف المحادثة الواقعية',
      icon: <MessageCircle className="h-5 w-5" aria-hidden="true" />,
    },
    sentence_speak: {
      title: 'تحدي النطق المباشر',
      subtitle: 'انطق الجملة بوضوح أو فعّل وضع الذاكرة لفتح الجملة التالية',
      icon: <Mic className="h-5 w-5" aria-hidden="true" />,
    },
    sentence_blitz: {
      title: 'سباق الجمل — 60 ثانية',
      subtitle: 'طابق الجمل ومعانيها بأقصى سرعة مع مضاعف السلسلة x5',
      icon: <Zap className="h-5 w-5" aria-hidden="true" />,
    },
  };

  const info = meta[mode];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xs">
            {info.icon}
          </div>
          <div>
            <h1 className="text-lg font-extrabold text-slate-900 dark:text-white sm:text-xl">
              {info.title}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">{info.subtitle}</p>
          </div>
        </div>

        <button
          type="button"
          data-testid="sentence-pro-exit-btn"
          onClick={onExit}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-[#11192b] dark:text-slate-200"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>خروج</span>
        </button>
      </div>

      {/* Category Section Picker */}
      <div className="tmn-card rounded-2xl p-3.5">
        <div className="mb-2 text-[11px] font-bold text-slate-400">اختر موضوع الجمل:</div>
        <SectionPicker
          sectionId={sectionId}
          onChange={(id) => {
            setSectionId(id);
            setSeed(Date.now());
          }}
        />
      </div>

      {mode === 'sentence_vanish' && (
        <VanishingSentenceGame
          key={`${sectionId}-${seed}`}
          roundItems={roundItems}
          arMap={arMap}
          onSpeak={props.onSpeak}
          onSfx={props.onSfx}
          onEarnXp={props.onEarnXp}
          onMarkPracticedSentence={props.onMarkPracticedSentence}
          onHudChange={props.onHudChange}
          onRoundComplete={props.onRoundComplete}
          onReplay={() => setSeed(Date.now())}
          onExit={onExit}
        />
      )}

      {mode === 'sentence_cloze' && (
        <SmartClozeGame
          key={`${sectionId}-${seed}`}
          roundItems={roundItems}
          allPool={filtered}
          arMap={arMap}
          onSpeak={props.onSpeak}
          onSfx={props.onSfx}
          onEarnXp={props.onEarnXp}
          onMarkPracticedSentence={props.onMarkPracticedSentence}
          onHudChange={props.onHudChange}
          onRoundComplete={props.onRoundComplete}
          onReplay={() => setSeed(Date.now())}
          onExit={onExit}
        />
      )}

      {mode === 'sentence_chat_reply' && (
        <QuickChatReplyGame
          sectionId={sectionId}
          seed={seed}
          onSpeak={props.onSpeak}
          onSfx={props.onSfx}
          onEarnXp={props.onEarnXp}
          onHudChange={props.onHudChange}
          onRoundComplete={props.onRoundComplete}
          onReplay={() => setSeed(Date.now())}
          onExit={onExit}
        />
      )}

      {mode === 'sentence_speak' && (
        <SpeakToUnlockGame
          key={`${sectionId}-${seed}`}
          roundItems={roundItems}
          arMap={arMap}
          onSpeak={props.onSpeak}
          onSpeakSlow={props.onSpeakSlow}
          onSfx={props.onSfx}
          onEarnXp={props.onEarnXp}
          onMarkPracticedSentence={props.onMarkPracticedSentence}
          onHudChange={props.onHudChange}
          onRoundComplete={props.onRoundComplete}
          onReplay={() => setSeed(Date.now())}
          onExit={onExit}
        />
      )}

      {mode === 'sentence_blitz' && (
        <SentenceSpeedBlitzGame
          key={`${sectionId}-${seed}`}
          allPool={filtered}
          arMap={arMap}
          settings={props.settings}
          onSpeak={props.onSpeak}
          onSfx={props.onSfx}
          onEarnXp={props.onEarnXp}
          onToggleFavoriteSentence={props.onToggleFavoriteSentence}
          onUpdateSettings={props.onUpdateSettings}
          onHudChange={props.onHudChange}
          onRoundComplete={props.onRoundComplete}
          onExit={onExit}
        />
      )}
    </div>
  );
}
