import React, { useState, useEffect } from 'react';
import {
  Check,
  RotateCcw,
  Folder,
  ChevronDown,
  X,
  AlertTriangle,
  Plus,
} from 'lucide-react';
import { Carpeta } from '../types';
import {
  listarCarpetas,
  guardarFoto,
  crearCarpeta,
  generarNombreFoto,
} from '../db/storage';
import { ConfirmarDialog, NombreDialog } from './Dialogos';

interface PreviaViewProps {
  tempFoto: {
    dataUrl: string;
    tamanoBytes: number;
    ancho: number;
    alto: number;
  };
  carpetaInicialId: string;
  onRepetir: () => void;
  onGuardado: (destinoCarpetaId: string) => void;
  onSalirSinGuardar: () => void;
}

export const PreviaView: React.FC<PreviaViewProps> = ({
  tempFoto,
  carpetaInicialId,
  onRepetir,
  onGuardado,
  onSalirSinGuardar,
}) => {
  const [carpetas, setCarpetas] = useState<Carpeta[]>([]);
  const [carpetaDestinoId, setCarpetaDestinoId] = useState(carpetaInicialId);
  const [mostrarSelectorCarpeta, setMostrarSelectorCarpeta] = useState(false);
  const [mostrarConfirmarDescarte, setMostrarConfirmarDescarte] = useState(false);
  const [modalNuevaCarpeta, setModalNuevaCarpeta] = useState(false);
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    listarCarpetas().then(setCarpetas);
  }, []);

  const carpetaActual = carpetas.find((c) => c.id === carpetaDestinoId);

  // Guardar foto con nombre estándar IMG_YYYYMMDD_HHMMSS.jpg Requerimiento 19 & 22
  const handleGuardar = async () => {
    if (guardando) return;
    setGuardando(true);
    try {
      const nombre = generarNombreFoto();
      await guardarFoto(carpetaDestinoId, {
        nombre,
        dataUrl: tempFoto.dataUrl,
        tamanoBytes: tempFoto.tamanoBytes,
        ancho: tempFoto.ancho,
        alto: tempFoto.alto,
      });
      onGuardado(carpetaDestinoId);
    } catch (err) {
      console.error('Error al guardar foto:', err);
      setGuardando(false);
    }
  };

  const handleCrearNuevaCarpeta = async (nombre: string) => {
    try {
      const nueva = await crearCarpeta(nombre);
      const actualizadas = await listarCarpetas();
      setCarpetas(actualizadas);
      setCarpetaDestinoId(nueva.id);
      setModalNuevaCarpeta(false);
    } catch (err) {
      console.error('Error al crear carpeta rápida:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between overflow-hidden select-none">
      {/* Botón flotante superior para cerrar con confirmación */}
      <div className="absolute top-4 left-4 z-30">
        <button
          onClick={() => setMostrarConfirmarDescarte(true)}
          className="p-2.5 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-95"
          aria-label="Cerrar y descartar foto"
        >
          <X size={22} />
        </button>
      </div>

      {/* Contenedor de la Imagen Tomada Requerimiento 18 */}
      <div className="relative flex-1 flex items-center justify-center bg-black p-2 overflow-hidden">
        <img
          src={tempFoto.dataUrl}
          alt="Previsualización de foto tomada"
          className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl"
        />
      </div>

      {/* Panel Inferior de Configuración y Guardado Requerimiento 19, 20, 21 */}
      <div className="w-full bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 p-4 md:p-6 space-y-4">
        {/* Selector de Carpeta Destino Requerimiento 21 */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
            Guardar en carpeta de vehículo:
          </label>
          <div className="relative">
            <button
              onClick={() => setMostrarSelectorCarpeta(!mostrarSelectorCarpeta)}
              className="w-full px-4 py-3 rounded-2xl bg-slate-800/80 border border-slate-700 hover:border-amber-500/70 text-left flex items-center justify-between text-sm font-semibold transition"
            >
              <div className="flex items-center gap-2.5 truncate">
                <Folder className="text-amber-500 shrink-0" size={18} />
                <span className="truncate">{carpetaActual?.nombre || 'Seleccionar carpeta…'}</span>
              </div>
              <ChevronDown size={18} className="text-slate-400 shrink-0" />
            </button>

            {/* Menú Desplegable de Selección de Carpeta */}
            {mostrarSelectorCarpeta && (
              <div className="absolute bottom-full mb-2 inset-x-0 bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl max-h-60 overflow-y-auto p-1.5 z-40 animate-fadeIn space-y-1">
                <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Carpetas disponibles:
                </div>
                {carpetas.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setCarpetaDestinoId(c.id);
                      setMostrarSelectorCarpeta(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition ${
                      c.id === carpetaDestinoId
                        ? 'bg-amber-600 text-white'
                        : 'text-slate-300 hover:bg-slate-700/60'
                    }`}
                  >
                    <span className="truncate">{c.nombre}</span>
                    {c.id === carpetaDestinoId && <Check size={14} />}
                  </button>
                ))}

                <button
                  onClick={() => {
                    setMostrarSelectorCarpeta(false);
                    setModalNuevaCarpeta(true);
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold text-amber-400 hover:bg-amber-500/10 flex items-center gap-2 border-t border-slate-700/50 mt-1"
                >
                  <Plus size={14} />
                  + Crear nueva carpeta aquí
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Botones Repetir y Guardar Requerimiento 19 & 20 */}
        <div className="flex items-center gap-3 pt-1">
          <button
            onClick={onRepetir}
            disabled={guardando}
            className="flex-1 py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-sm transition active:scale-98 flex items-center justify-center gap-2"
          >
            <RotateCcw size={18} />
            Repetir foto
          </button>

          <button
            onClick={handleGuardar}
            disabled={guardando}
            className="flex-1 py-3.5 px-4 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 transition active:scale-98 flex items-center justify-center gap-2"
          >
            <Check size={18} />
            {guardando ? 'Guardando…' : 'Guardar en Carpeta'}
          </button>
        </div>
      </div>

      {/* Modal Confirmación de Descarte Requerimiento 34 */}
      {mostrarConfirmarDescarte && (
        <ConfirmarDialog
          titulo="Descartar foto"
          mensaje="La foto capturada no se ha guardado todavía. ¿Deseas salir y descartarla?"
          textoOk="Sí, descartar"
          textoCancelar="Seguir aquí"
          esPeligroso={true}
          onOk={onSalirSinGuardar}
          onCancelar={() => setMostrarConfirmarDescarte(false)}
        />
      )}

      {/* Modal Rápido para Nueva Carpeta */}
      {modalNuevaCarpeta && (
        <NombreDialog
          titulo="Nueva Carpeta Destino"
          existentes={carpetas.map((c) => c.nombre)}
          placeholder="Ej. Placa XYZ-987"
          onAceptar={handleCrearNuevaCarpeta}
          onCancelar={() => setModalNuevaCarpeta(false)}
        />
      )}
    </div>
  );
};
