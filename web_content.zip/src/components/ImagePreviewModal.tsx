import React, { useState } from "react";
import {
  X,
  Download,
  Copy,
  Check,
  Heart,
  Wand2,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Info,
  Share2,
  Calendar,
  Layers,
  Square,
} from "lucide-react";
import { GeneratedImage } from "../types";
import { SmartImage } from "./SmartImage";
import { downloadImage as triggerDownload } from "../utils/downloadImage";

interface ImagePreviewModalProps {
  image: GeneratedImage | null;
  onClose: () => void;
  onSendToEditor: (image: GeneratedImage) => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({
  image,
  onClose,
  onSendToEditor,
  isFavorite,
  onToggleFavorite,
}) => {
  if (!image) return null;

  const [zoom, setZoom] = useState(1);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState<"png" | "jpg" | "webp">("png");

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(image.prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "AI Generated Image",
          text: `Check out this AI artwork created with prompt: "${image.prompt}"`,
          url: window.location.href,
        });
      } catch (err) {
        console.error("Error sharing:", err);
      }
    } else {
      handleCopyPrompt();
    }
  };

  const downloadImage = () => {
    triggerDownload(image.url, `scientific_ai_creation_${image.id}.${downloadFormat}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Navigation Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800/80 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-xs font-bold text-slate-200">HD Creation Viewer</span>
            <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] text-purple-300 font-mono">
              {image.aspectRatio}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleFavorite(image.id)}
              className={`p-2 rounded-xl transition ${
                isFavorite
                  ? "bg-red-500/20 text-red-400 border border-red-500/30"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
              title={isFavorite ? "Remove from Favorites" : "Add to Favorites"}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-400" : ""}`} />
            </button>

            <button
              onClick={() => setShowInfo(!showInfo)}
              className={`p-2 rounded-xl border transition ${
                showInfo ? "bg-purple-600/20 border-purple-500 text-purple-300" : "bg-slate-800 border-transparent text-slate-400 hover:text-white"
              }`}
              title="Toggle Details Inspector"
            >
              <Info className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: Image Viewport + Optional Inspector */}
        <div className="relative flex-1 overflow-hidden flex flex-col md:flex-row bg-slate-950">
          {/* Main Image Container */}
          <div className="relative flex-1 flex items-center justify-center p-4 min-h-[360px] max-h-[65vh] md:max-h-full overflow-auto scrollbar-thin scrollbar-thumb-slate-800">
            <div className="relative transition-transform duration-200" style={{ transform: `scale(${zoom})` }}>
              <SmartImage
                src={image.url}
                alt={image.prompt}
                prompt={image.prompt}
                referrerPolicy="no-referrer"
                className="max-h-[68vh] w-auto max-w-full object-contain rounded-xl shadow-2xl border border-slate-800/60"
              />
            </div>

            {/* Floating Zoom Controls */}
            <div className="absolute bottom-4 left-4 flex items-center gap-1 bg-slate-900/90 border border-slate-800 rounded-xl p-1 shadow-lg backdrop-blur-md">
              <button
                onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 text-[11px] font-mono font-bold text-slate-300">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              {zoom !== 1 && (
                <button
                  onClick={() => setZoom(1)}
                  className="px-2 py-1 text-[10px] bg-slate-800 rounded text-slate-300 hover:text-white"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          {/* Right Inspector Drawer */}
          {showInfo && (
            <div className="w-full md:w-80 bg-slate-900 border-t md:border-t-0 md:border-l border-slate-800/80 p-5 space-y-4 overflow-y-auto text-xs">
              <h4 className="font-bold text-slate-200 flex items-center gap-2">
                <Info className="w-4 h-4 text-purple-400" />
                <span>Creation Metadata</span>
              </h4>

              <div className="space-y-3">
                <div className="space-y-1">
                  <span className="text-slate-400 font-medium flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Prompt</span>
                  </span>
                  <p className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 leading-relaxed">
                    {image.prompt}
                  </p>
                </div>

                {image.compiledPrompt && (
                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium">Enhanced Full Prompt</span>
                    <p className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 font-mono text-[11px] leading-relaxed">
                      {image.compiledPrompt}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                      <Layers className="w-3 h-3 text-purple-400" />
                      Style Preset
                    </span>
                    <p className="font-semibold text-slate-200 truncate">{image.style}</p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                      <Square className="w-3 h-3 text-indigo-400" />
                      Ratio
                    </span>
                    <p className="font-semibold text-slate-200">{image.aspectRatio}</p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5 col-span-2">
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-teal-400" />
                      Created On
                    </span>
                    <p className="font-mono text-slate-300">
                      {new Date(image.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Action Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyPrompt}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              {copiedPrompt ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedPrompt ? "Copied!" : "Copy Prompt"}</span>
            </button>

            <button
              onClick={handleShare}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
              title="Share Creation"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                onClose();
                onSendToEditor(image);
              }}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600/20 to-pink-600/20 hover:from-purple-600/30 hover:to-pink-600/30 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition"
            >
              <Wand2 className="w-4 h-4 text-pink-400" />
              <span>Edit Image with AI</span>
            </button>

            {/* Download selector & button */}
            <div className="flex items-center rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 p-0.5 shadow-lg">
              <select
                value={downloadFormat}
                onChange={(e: any) => setDownloadFormat(e.target.value)}
                className="bg-slate-950 text-slate-200 text-xs font-semibold px-2 py-1.5 rounded-l-lg focus:outline-none border-r border-indigo-500/30"
              >
                <option value="png">PNG</option>
                <option value="jpg">JPG</option>
                <option value="webp">WEBP</option>
              </select>

              <button
                onClick={downloadImage}
                className="px-4 py-2 text-white text-xs font-bold flex items-center gap-1.5 hover:opacity-90 transition"
              >
                <Download className="w-4 h-4" />
                <span>Save HD</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
