import React, { useState } from 'react';
import {
  Briefcase,
  Building2,
  Car,
  CheckCircle2,
  CloudRain,
  Compass,
  Home,
  Landmark,
  MapPin,
  Save,
  Settings,
  Shirt,
  Sun,
  Target,
  Trash2,
  X,
  Youtube,
} from 'lucide-react';
import {
  CarControlMode,
  CharacterCustomization,
  CharacterId,
  ClothingStyle,
  FacialHairStyle,
  HudSnapshot,
  MissionDef,
  RecordedClipDraft,
  SaveData,
  VehicleType,
  WeatherType,
  YouTubeChannel,
  YouTubeVideo,
} from '../types/game';
import { YouTubeApp } from './YouTubeApp';
import { BankApp } from './BankApp';
import {
  CHARACTER_PROFILES,
  KARACHI_DISTRICTS,
  KARACHI_MISSIONS,
  KARACHI_PLACES,
  PHONE_MODELS,
  VEHICLE_SPECS,
} from '../data/karachiWorldData';

export type PhoneTab = 'youtube' | 'bank' | 'missions' | 'map' | 'garage' | 'life' | 'style' | 'settings';

interface SmartphoneModalProps {
  save: SaveData;
  hud: HudSnapshot;
  initialTab?: PhoneTab;
  pendingDraft: RecordedClipDraft | null;
  onClose: () => void;
  onStartMission: (m: MissionDef) => void;
  onAbortMission: () => void;
  onSetWaypoint: (x: number, z: number, label: string) => void;
  onClearWaypoint: () => void;
  onBuyOrSummonVehicle: (type: VehicleType) => void;
  onBuyProperty: (placeId: string) => void;
  onRunQuickJob: (jobTitle: string, reward: number) => void;
  onSwitchCharacter: (id: CharacterId) => void;
  onUpdateCustomization: (custom: CharacterCustomization) => void;
  onSetTime: (hour: number, auto: boolean) => void;
  onSetWeather: (w: WeatherType) => void;
  onSaveGame: () => void;
  onResetSave: () => void;
  onUpdateYouTubeChannel: (patch: Partial<YouTubeChannel>) => void;
  onCaptureProfilePhoto: () => string;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onPublishVideo: (title: string, category: YouTubeVideo['category'], draft: RecordedClipDraft) => void;
  onDiscardDraft: () => void;
  onClaimYouTubeRevenue: () => void;
  onChangeCarControlMode: (mode: CarControlMode) => void;
  onGoHome: () => void;
  onBankDeposit: (amount: number) => void;
  onBankWithdraw: (amount: number) => void;
  onBankTakeLoan: (amount: number) => void;
  onBankRepayLoan: () => void;
}

const VEHICLE_LIST: VehicleType[] = [
  'mehran',
  'alto',
  'corolla',
  'civic',
  'land_cruiser',
  'rickshaw',
  'motorcycle',
  'bus',
  'truck',
  'boat',
];

const CLOTHING_STYLES: { id: ClothingStyle; label: string }[] = [
  { id: 'shalwar_kameez', label: 'Shalwar Kameez' },
  { id: 'kurta_waistcoat', label: 'Kurta & Waistcoat' },
  { id: 'ajrak_street', label: 'Sindhi Ajrak Street' },
  { id: 'modern_casual', label: 'Modern Jacket' },
];

const COLOR_SWATCHES = ['#f8fafc', '#0f172a', '#16a34a', '#dc2626', '#0284c7', '#eab308', '#7c3aed'];

export const SmartphoneModal: React.FC<SmartphoneModalProps> = ({
  save,
  hud,
  initialTab = 'youtube',
  pendingDraft,
  onClose,
  onStartMission,
  onAbortMission,
  onSetWaypoint,
  onClearWaypoint,
  onBuyOrSummonVehicle,
  onBuyProperty,
  onRunQuickJob,
  onSwitchCharacter,
  onUpdateCustomization,
  onSetTime,
  onSetWeather,
  onSaveGame,
  onResetSave,
  onUpdateYouTubeChannel,
  onCaptureProfilePhoto,
  onStartRecording,
  onStopRecording,
  onPublishVideo,
  onDiscardDraft,
  onClaimYouTubeRevenue,
  onChangeCarControlMode,
  onGoHome,
  onBankDeposit,
  onBankWithdraw,
  onBankTakeLoan,
  onBankRepayLoan,
}) => {
  const [tab, setTab] = useState<PhoneTab>(initialTab);
  const activeCustom = save.customizations[save.activeCharacter];
  const properties = KARACHI_PLACES.filter((p) => p.type === 'property');
  const activePhone = PHONE_MODELS[save.phoneModel] || PHONE_MODELS.lite;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center sm:justify-end sm:p-6 bg-black/55">
      <div
        style={{ borderColor: save.phoneThemeColor }}
        className="w-full h-full sm:w-[390px] sm:h-[640px] sm:max-h-[90vh] bg-slate-950 border-[5px] sm:rounded-[30px] shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Phone Top Notch / Status Bar */}
        <div
          style={{ backgroundColor: save.phoneThemeColor }}
          className="flex items-center justify-between px-5 py-3 border-b border-white/15"
        >
          <div>
            <div className="text-[10px] font-black tracking-[0.15em] text-emerald-300 uppercase flex items-center gap-1.5">
              <span>{activePhone.name}</span>
              <span className="px-1.5 py-0.5 rounded bg-black/40 text-amber-300">
                {activePhone.ytMultiplier}x YT
              </span>
            </div>
            <div className="text-sm font-black text-white tabular-nums">
              Rs. {save.cash.toLocaleString()}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full bg-black/35 hover:bg-black/55 text-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* App Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {tab === 'youtube' && (
            <YouTubeApp
              channel={save.youtube}
              isRecording={hud.isRecordingVideo}
              recordingSeconds={hud.recordingSeconds}
              pendingDraft={pendingDraft}
              onUpdateChannel={onUpdateYouTubeChannel}
              onCaptureProfilePhoto={onCaptureProfilePhoto}
              onStartRecording={onStartRecording}
              onStopRecording={onStopRecording}
              onPublishVideo={onPublishVideo}
              onDiscardDraft={onDiscardDraft}
              onClaimRevenue={onClaimYouTubeRevenue}
            />
          )}

          {tab === 'bank' && (
            <BankApp
              save={save}
              onDeposit={onBankDeposit}
              onWithdraw={onBankWithdraw}
              onTakeLoan={onBankTakeLoan}
              onRepayLoan={onBankRepayLoan}
            />
          )}

          {tab === 'missions' && (
            <>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black uppercase tracking-wider text-amber-400">
                  Karachi Contracts & Missions
                </h3>
                {hud.activeMission && (
                  <button
                    type="button"
                    onClick={onAbortMission}
                    className="text-xs font-bold text-rose-400 hover:underline cursor-pointer"
                  >
                    Abort Active
                  </button>
                )}
              </div>
              {KARACHI_MISSIONS.map((m) => {
                const completed = save.completedMissions.includes(m.id);
                const isActive = hud.activeMission?.id === m.id;
                return (
                  <div
                    key={m.id}
                    className={`p-3 rounded-xl border ${
                      isActive
                        ? 'bg-amber-950/40 border-amber-400'
                        : 'bg-slate-900 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-slate-800 text-sky-300">
                          {m.category}
                        </span>
                        <h4 className="text-sm font-bold text-white mt-1">{m.title}</h4>
                      </div>
                      <span className="text-xs font-black text-emerald-400 tabular-nums shrink-0">
                        +Rs. {m.rewardCash.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{m.description}</p>
                    <div className="mt-2.5 flex items-center justify-between">
                      {completed ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-500">
                          {m.requiredVehicle ? `Includes ${VEHICLE_SPECS[m.requiredVehicle].name}` : 'Any Vehicle'}
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          onStartMission(m);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs cursor-pointer"
                      >
                        {isActive ? 'Restart' : 'Start Mission'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {tab === 'map' && (
            <>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black uppercase tracking-wider text-sky-400">
                  Karachi GPS & 12 Districts
                </h3>
                {hud.waypoint && (
                  <button
                    type="button"
                    onClick={onClearWaypoint}
                    className="text-xs font-bold text-rose-400 cursor-pointer"
                  >
                    Clear GPS
                  </button>
                )}
              </div>

              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { label: 'Home', x: 26, z: -70, color: 'text-amber-300 border-amber-500/40' },
                  { label: 'K-Bank', x: -44, z: -32, color: 'text-emerald-300 border-emerald-500/40' },
                  { label: 'Phones', x: -50, z: 36, color: 'text-purple-300 border-purple-500/40' },
                  { label: 'Cars', x: 45, z: -42, color: 'text-sky-300 border-sky-500/40' },
                ].map((spot) => (
                  <button
                    key={spot.label}
                    type="button"
                    onClick={() => {
                      onSetWaypoint(spot.x, spot.z, spot.label);
                      onClose();
                    }}
                    className={`py-1.5 px-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border ${spot.color} text-[10px] font-black cursor-pointer`}
                  >
                    {spot.label}
                  </button>
                ))}
              </div>

              {/* Interactive SVG / Grid Map */}
              <div className="relative w-full h-52 rounded-xl bg-slate-900 border border-slate-700 overflow-hidden">
                <div
                  className="absolute inset-x-0 bottom-0 h-11 bg-sky-900/75 border-t border-sky-500/40"
                  title="Arabian Sea"
                />
                {KARACHI_DISTRICTS.map((d) => {
                  const leftPct = ((d.x + 700) / 1400) * 100;
                  const topPct = ((d.z + 620) / 1080) * 100;
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => {
                        onSetWaypoint(d.x, d.z, d.name);
                        onClose();
                      }}
                      style={{ left: `${leftPct}%`, top: `${topPct}%` }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded bg-slate-950/90 border border-slate-600 hover:border-amber-400 text-[9px] font-bold text-white cursor-pointer whitespace-nowrap"
                    >
                      {d.name}
                    </button>
                  );
                })}
                {/* Player live marker */}
                <div
                  style={{
                    left: `${((hud.playerX + 700) / 1400) * 100}%`,
                    top: `${((hud.playerZ + 620) / 1080) * 100}%`,
                  }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-amber-400 border-2 border-white shadow"
                />
              </div>

              <div className="space-y-1.5">
                {KARACHI_DISTRICTS.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      onSetWaypoint(d.x, d.z, d.name);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-bold text-white">{d.name}</div>
                      <div className="text-[11px] text-slate-400">{d.tagline}</div>
                    </div>
                    <MapPin className="w-4 h-4 text-sky-400 shrink-0" />
                  </button>
                ))}
              </div>
            </>
          )}

          {tab === 'garage' && (
            <>
              <h3 className="text-sm font-black uppercase tracking-wider text-emerald-400">
                Vehicles & Dealership (10 Models)
              </h3>
              {VEHICLE_LIST.map((vType) => {
                const spec = VEHICLE_SPECS[vType];
                const owned = save.ownedVehicles.includes(vType);
                const canAfford = save.cash >= spec.price;
                return (
                  <div
                    key={vType}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                  >
                    <div>
                      <div className="text-sm font-bold text-white">{spec.name}</div>
                      <div className="text-[11px] text-slate-400">
                        Top Speed {Math.round(spec.topSpeed * 3.6)} km/h · {spec.category.toUpperCase()}
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={!owned && !canAfford}
                      onClick={() => {
                        onBuyOrSummonVehicle(vType);
                        onClose();
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black cursor-pointer shrink-0 ${
                        owned
                          ? 'bg-sky-500 hover:bg-sky-400 text-white'
                          : canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {owned ? 'Summon' : `Buy Rs.${(spec.price / 1000).toFixed(0)}K`}
                    </button>
                  </div>
                );
              })}
            </>
          )}

          {tab === 'life' && (
            <>
              <div className="p-3 rounded-xl bg-slate-900 border border-amber-400/50 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <Home className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <div className="text-xs font-black text-white">Your Karachi Home</div>
                    <div className="text-[10px] text-slate-400">Gulshan House · Rest, Wardrobe & Garage</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onSetWaypoint(26, -70, 'Your Karachi Home');
                      onClose();
                    }}
                    className="px-2 py-1.5 rounded-lg bg-slate-800 text-sky-300 text-[10px] font-bold cursor-pointer"
                  >
                    GPS
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onGoHome();
                      onClose();
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-[10px] font-black cursor-pointer"
                  >
                    Go Home
                  </button>
                </div>
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-amber-400 pt-1">
                Quick Jobs & Hustles
              </h3>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { title: 'Ride-Share Shift (Clifton – Saddar)', pay: 6500 },
                  { title: 'Burns Road Express Delivery', pay: 4800 },
                  { title: 'Karachi Port Security Shift', pay: 9200 },
                ].map((job) => (
                  <button
                    key={job.title}
                    type="button"
                    onClick={() => onRunQuickJob(job.title, job.pay)}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between text-left cursor-pointer"
                  >
                    <span className="text-xs font-bold text-white">{job.title}</span>
                    <span className="text-xs font-black text-emerald-400 tabular-nums">
                      +Rs.{job.pay.toLocaleString()}
                    </span>
                  </button>
                ))}
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-emerald-400 pt-2">
                Houses & Businesses
              </h3>
              {properties.map((p) => {
                const owned = save.ownedProperties.includes(p.id);
                const price = p.price ?? 100000;
                const canAfford = save.cash >= price;
                return (
                  <div key={p.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-bold text-white">{p.name}</div>
                        <div className="text-[11px] text-emerald-400 font-semibold">
                          Income: +Rs.{(p.incomePerMin ?? 2000).toLocaleString()} / min
                        </div>
                      </div>
                      {owned ? (
                        <button
                          type="button"
                          onClick={() => {
                            onSetWaypoint(p.x, p.z, p.name);
                            onClose();
                          }}
                          className="px-2.5 py-1 rounded bg-slate-800 text-sky-300 text-xs font-bold cursor-pointer"
                        >
                          GPS
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={!canAfford}
                          onClick={() => onBuyProperty(p.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black cursor-pointer ${
                            canAfford
                              ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          Buy Rs.{(price / 1000).toFixed(0)}K
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{p.description}</p>
                  </div>
                );
              })}
            </>
          )}

          {tab === 'style' && (
            <>
              <h3 className="text-sm font-black uppercase tracking-wider text-pink-400">
                Switch Karachi Character
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {(['zain', 'ayesha', 'bilal', 'tariq', 'sana'] as CharacterId[]).map((cid) => {
                  const prof = CHARACTER_PROFILES[cid];
                  const active = save.activeCharacter === cid;
                  return (
                    <button
                      key={cid}
                      type="button"
                      onClick={() => onSwitchCharacter(cid)}
                      className={`p-2 rounded-xl border text-center cursor-pointer ${
                        active
                          ? 'bg-amber-400 text-slate-950 border-amber-300'
                          : 'bg-slate-900 text-white border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs font-black">{prof.name.split(' ')[0]}</div>
                      <div className="text-[10px] opacity-80 truncate">{prof.role.split('·')[1]}</div>
                    </button>
                  );
                })}
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-amber-400 pt-2">
                Pakistani Clothing & Accessories
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {CLOTHING_STYLES.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => onUpdateCustomization({ ...activeCustom, style: st.id })}
                    className={`p-2 rounded-lg border text-xs font-bold cursor-pointer ${
                      activeCustom.style === st.id
                        ? 'bg-sky-500 text-white border-sky-300'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              <div className="space-y-2 pt-1">
                <div className="text-xs font-bold text-slate-300">Primary Outfit Color</div>
                <div className="flex gap-2">
                  {COLOR_SWATCHES.map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => onUpdateCustomization({ ...activeCustom, primaryColor: col })}
                      style={{ backgroundColor: col }}
                      className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                        activeCustom.primaryColor === col ? 'border-amber-400 scale-110' : 'border-slate-600'
                      }`}
                    />
                  ))}
                </div>

                <div className="text-xs font-bold text-slate-300 pt-1">Waistcoat / Scarf Accent</div>
                <div className="flex gap-2">
                  {COLOR_SWATCHES.map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => onUpdateCustomization({ ...activeCustom, secondaryColor: col })}
                      style={{ backgroundColor: col }}
                      className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                        activeCustom.secondaryColor === col ? 'border-amber-400 scale-110' : 'border-slate-600'
                      }`}
                    />
                  ))}
                </div>

                <div className="text-xs font-bold text-slate-300 pt-1">Headwear & Shades</div>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['none', 'sunglasses', 'cap', 'sindhi_cap'] as const).map((acc) => (
                    <button
                      key={acc}
                      type="button"
                      onClick={() => onUpdateCustomization({ ...activeCustom, accessory: acc })}
                      className={`py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer ${
                        activeCustom.accessory === acc
                          ? 'bg-amber-400 text-slate-950 border-amber-300'
                          : 'bg-slate-900 text-slate-300 border-slate-800'
                      }`}
                    >
                      {acc === 'sindhi_cap' ? 'Topi' : acc === 'sunglasses' ? 'Shades' : acc}
                    </button>
                  ))}
                </div>

                {!CHARACTER_PROFILES[save.activeCharacter].isFemale && (
                  <>
                    <div className="text-xs font-bold text-slate-300 pt-1">Beard & Facial Hair</div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['none', 'stubble', 'beard'] as FacialHairStyle[]).map((fh) => (
                        <button
                          key={fh}
                          type="button"
                          onClick={() => onUpdateCustomization({ ...activeCustom, facialHair: fh })}
                          className={`py-1.5 rounded-lg border text-[11px] font-bold capitalize cursor-pointer ${
                            (activeCustom.facialHair ?? 'none') === fh
                              ? 'bg-emerald-400 text-slate-950 border-emerald-300'
                              : 'bg-slate-900 text-slate-300 border-slate-800'
                          }`}
                        >
                          {fh === 'none' ? 'Clean' : fh}
                        </button>
                      ))}
                    </div>
                  </>
                )}

                <div className="text-xs font-bold text-slate-300 pt-1">Skin Tone</div>
                <div className="flex gap-2">
                  {['#e0ac80', '#d8a072', '#c68b59', '#b57b4e', '#a66e43'].map((skin) => (
                    <button
                      key={skin}
                      type="button"
                      onClick={() => onUpdateCustomization({ ...activeCustom, skinTone: skin })}
                      style={{ backgroundColor: skin }}
                      className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                        (activeCustom.skinTone || CHARACTER_PROFILES[save.activeCharacter].defaultSkin) === skin
                          ? 'border-amber-400 scale-110'
                          : 'border-slate-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </>
          )}

          {tab === 'settings' && (
            <>
              <h3 className="text-sm font-black uppercase tracking-wider text-sky-400">
                Karachi Time & Weather
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onSetTime(10, true)}
                  className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
                >
                  <Sun className="w-4 h-4 text-amber-300" /> Morning (Auto)
                </button>
                <button
                  type="button"
                  onClick={() => onSetTime(17.3, false)}
                  className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
                >
                  <Sun className="w-4 h-4 text-orange-400" /> Sunset Lock
                </button>
                <button
                  type="button"
                  onClick={() => onSetTime(22.5, false)}
                  className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-indigo-300" /> Night Neon
                </button>
                <button
                  type="button"
                  onClick={() => onSetTime(hud.timeOfDay, true)}
                  className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-white cursor-pointer"
                >
                  Resume Cycle
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                {(['clear', 'golden', 'overcast', 'rain'] as WeatherType[]).map((w) => (
                  <button
                    key={w}
                    type="button"
                    onClick={() => onSetWeather(w)}
                    className={`p-2.5 rounded-lg border text-xs font-bold capitalize flex items-center gap-2 cursor-pointer ${
                      hud.weather === w
                        ? 'bg-sky-500 text-white border-sky-300'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    <CloudRain className="w-4 h-4" /> {w}
                  </button>
                ))}
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-amber-400 pt-2">
                Car Steering Controls
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { id: 'buttons', label: 'Arrows' },
                    { id: 'wheel', label: 'Wheel' },
                    { id: 'joystick', label: 'Joystick' },
                  ] as { id: CarControlMode; label: string }[]
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onChangeCarControlMode(m.id)}
                    className={`p-2 rounded-lg border text-xs font-black cursor-pointer ${
                      save.carControlMode === m.id
                        ? 'bg-amber-400 text-slate-950 border-amber-300'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-emerald-400 pt-2">
                Save & Career Stats
              </h3>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
                <div>Missions Completed: {save.completedMissions.length} / {KARACHI_MISSIONS.length}</div>
                <div>Owned Properties: {save.ownedProperties.length}</div>
                <div>Owned Vehicles: {save.ownedVehicles.length} / 10</div>
                <div>Active Phone: {activePhone.name}</div>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onSaveGame}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Save Progress
                </button>
                <button
                  type="button"
                  onClick={onResetSave}
                  className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" /> Reset
                </button>
              </div>
            </>
          )}
        </div>

        {/* Bottom Dock App Switcher */}
        <div className="grid grid-cols-8 bg-slate-900 border-t border-slate-800 p-1">
          {(
            [
              { id: 'youtube', label: 'YT', Icon: Youtube },
              { id: 'bank', label: 'Bank', Icon: Landmark },
              { id: 'missions', label: 'Jobs', Icon: Target },
              { id: 'map', label: 'Map', Icon: MapPin },
              { id: 'garage', label: 'Cars', Icon: Car },
              { id: 'life', label: 'Life', Icon: Building2 },
              { id: 'style', label: 'Style', Icon: Shirt },
              { id: 'settings', label: 'World', Icon: Settings },
            ] as const
          ).map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`flex flex-col items-center justify-center py-1.5 rounded-lg text-[9px] font-bold cursor-pointer ${
                tab === id ? 'bg-slate-800 text-amber-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4 mb-0.5" />
              <span>{label}</span>
            </button>
          ))}
        </div>
        <span className="sr-only">
          <Briefcase />
        </span>
      </div>
    </div>
  );
};
