import { useState } from "react";
import {
  formatDec,
  gateDecision,
  LANGUAGE_WEIGHT,
  parseBlock,
  priorityScore,
  SCORE_LIMIT,
  shr2,
} from "@/lib/rax";
import { Eyebrow, Panel } from "@/components/desk";

const SAMPLES = [
  { label: "javascript", text: '[javascript] ack("user1")' },
  { label: "python", text: '[python] print("queued")' },
  { label: "bash", text: '[bash] echo "Test"' },
];

type Ticket = {
  keyword: string;
  content: string;
  executionId: number;
  weight: number | null;
  score: number | null;
  decision: "granted" | "denied" | "unknown";
  response: "[" | "." | null;
};

export function DispatchView({ now }: { now: number | null }) {
  const [draft, setDraft] = useState(SAMPLES[2].text);
  const [error, setError] = useState<string | null>(null);
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [log, setLog] = useState<string[]>([]);

  const liveBase = now === null ? null : shr2(now);

  function stage() {
    const parsed = parseBlock(draft);
    if (!parsed) {
      setError("Code must start with [keyword].");
      setTicket(null);
      return;
    }
    if (now === null || liveBase === null) {
      setError("Clock is not ready.");
      return;
    }
    const weight = LANGUAGE_WEIGHT[parsed.keyword] ?? null;
    const score = priorityScore(liveBase, parsed.keyword);
    setError(weight === null ? `Unknown keyword: ${parsed.keyword}` : null);
    setTicket({
      keyword: parsed.keyword,
      content: parsed.content,
      executionId: liveBase,
      weight,
      score,
      decision: gateDecision(score),
      response: null,
    });
  }

  function respond(response: "[" | ".") {
    if (!ticket || ticket.response) return;
    if (response === "[" && ticket.decision !== "granted") return;
    const next = { ...ticket, response };
    setTicket(next);
    const line =
      response === "."
        ? `Denied ${next.executionId}.`
        : `Filed dispatch ${next.executionId}. ${next.keyword} staged — the desk does not run it.`;
    setLog((prev) => [line, ...prev].slice(0, 6));
  }

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="flex flex-col gap-6 lg:col-span-3">
        <Panel>
          <Eyebrow>Code block</Eyebrow>
          <p className="mt-2 text-sm text-muted">
            Start with a bracketed keyword. End the old CLI ritual with EOF if you want — it is
            stripped.
          </p>
          <textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value.slice(0, 600))}
            rows={6}
            spellCheck={false}
            className="mt-4 w-full border border-line bg-bg px-3 py-3 font-mono text-sm text-fg"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {SAMPLES.map((sample) => (
              <button
                key={sample.label}
                type="button"
                onClick={() => {
                  setDraft(sample.text);
                  setError(null);
                }}
                className="min-h-11 border border-line px-3 font-mono text-sm text-muted"
              >
                {sample.label}
              </button>
            ))}
          </div>
          {error ? <p className="mt-3 text-sm text-brass">{error}</p> : null}
          <button
            type="button"
            onClick={stage}
            className="mt-4 inline-flex min-h-11 items-center bg-brass px-4 font-medium text-bg"
          >
            Assign execution id
          </button>
        </Panel>

        <Panel>
          <Eyebrow>Recipient response</Eyebrow>
          {ticket === null ? (
            <p className="mt-3 text-sm text-muted">No ticket yet. Assign an id first.</p>
          ) : (
            <div className="mt-3">
              <dl className="grid gap-3 sm:grid-cols-2">
                <div>
                  <dt className="text-sm text-muted">Keyword</dt>
                  <dd className="font-mono text-fg">{ticket.keyword}</dd>
                </div>
                <div>
                  <dt className="text-sm text-muted">Execution id</dt>
                  <dd className="font-mono text-fg tabular-nums">{formatDec(ticket.executionId)}</dd>
                </div>
                <div className="sm:col-span-2">
                  <dt className="text-sm text-muted">Content</dt>
                  <dd className="font-mono text-sm text-fg whitespace-pre-wrap">
                    {ticket.content || "—"}
                  </dd>
                </div>
              </dl>

              <p className="mt-4 text-sm text-muted">
                Respond with [ to deploy or . to deny.
                {ticket.decision === "denied"
                  ? " The gate already refused this language."
                  : ticket.decision === "unknown"
                    ? " Unknown keywords are not deployed."
                    : ""}
              </p>

              <div className="mt-4 flex gap-3">
                <button
                  type="button"
                  disabled={ticket.response !== null || ticket.decision !== "granted"}
                  onClick={() => respond("[")}
                  className="flex h-16 w-16 items-center justify-center bg-brass font-mono text-2xl text-bg disabled:opacity-40"
                  aria-label="Deploy"
                >
                  [
                </button>
                <button
                  type="button"
                  disabled={ticket.response !== null}
                  onClick={() => respond(".")}
                  className="flex h-16 w-16 items-center justify-center border border-line bg-bg font-mono text-2xl text-fg disabled:opacity-40"
                  aria-label="Deny"
                >
                  .
                </button>
              </div>

              {ticket.response === "[" ? (
                <p className="mt-4 text-sm text-fg">
                  Deploying code with id {formatDec(ticket.executionId)}. Ticket filed. The block
                  stays on the desk — it is not executed.
                </p>
              ) : null}
              {ticket.response === "." ? (
                <p className="mt-4 text-sm text-fg">Code deployment denied.</p>
              ) : null}
            </div>
          )}

          {log.length > 0 ? (
            <ul className="mt-5 border-t border-line pt-4">
              {log.map((line, index) => (
                <li key={`${line}-${index}`} className="py-1 font-mono text-xs text-muted">
                  {line}
                </li>
              ))}
            </ul>
          ) : null}
        </Panel>
      </div>

      <Panel className="lg:col-span-2">
        <Eyebrow>Priority gate</Eyebrow>
        <p className="mt-2 text-sm text-muted">
          Score is the compact id times the language weight. At or under{" "}
          {formatDec(SCORE_LIMIT)} is granted.
        </p>
        <p className="mt-3 font-mono text-sm text-fg tabular-nums">
          Live id {liveBase === null ? "—" : formatDec(liveBase)}
        </p>
        <ul className="mt-4 flex flex-col gap-4">
          {Object.entries(LANGUAGE_WEIGHT).map(([language, weight]) => {
            const score = liveBase === null ? null : liveBase * weight;
            const decision = gateDecision(score);
            const pct = score === null ? 0 : Math.min(100, (score / SCORE_LIMIT) * 100);
            return (
              <li key={language}>
                <div className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-sm text-fg">
                    {language} × {weight}
                  </span>
                  <span className="text-sm text-brass">{decision === "granted" ? "Granted" : "Denied"}</span>
                </div>
                <div className="mt-2 h-2 border border-line bg-bg">
                  <div className="h-full bg-brass" style={{ width: `${pct}%` }} />
                </div>
                <p className="mt-1 font-mono text-xs text-muted tabular-nums">
                  {score === null ? "—" : formatDec(score)}
                </p>
              </li>
            );
          })}
        </ul>
        <p className="mt-4 text-sm text-muted">
          Bash is weight 3, so it steps over the gate on today’s clock. JavaScript and Python still
          clear it. The id itself is only the shifted time — the weight is what ranks the language.
        </p>
      </Panel>
    </div>
  );
}
