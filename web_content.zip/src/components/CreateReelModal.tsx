import React, { useState, useRef } from 'react';
import { X, Video, Music, Loader2, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { processGalleryUpload, ProcessedMedia } from '../utils/media';
import { SafeVideo } from './SafeVideo';

interface CreateReelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateReelModal: React.FC<CreateReelModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { createReel } = useSocial();

  const [caption, setCaption] = useState('');
  const [soundTitle, setSoundTitle] = useState('Original Audio - ' + (user?.displayName || 'Creator'));
  const [media, setMedia] = useState<ProcessedMedia | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleVideoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    try {
      const processed = await processGalleryUpload(file);
      setMedia(processed);
    } catch (err) {
      console.error('Failed to process reel video:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!media?.mediaUrl) return;

    setIsSubmitting(true);
    try {
      await createReel(
        caption.trim() || 'Check out my new reel! 🔥 #FaceLook #Shorts',
        media.mediaUrl,
        soundTitle.trim() || 'Original Sound'
      );
      setCaption('');
      setMedia(null);
      onClose();
    } catch (err) {
      console.error('Failed to create reel:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="relative px-4 py-3.5 border-b border-slate-200 flex items-center justify-center bg-slate-50">
          <div className="flex items-center gap-1.5 font-bold text-slate-900 text-base">
            <Video className="w-5 h-5 text-rose-500" />
            <span>Create New Reel</span>
          </div>
          <button
            onClick={onClose}
            className="absolute right-3.5 top-3 w-8 h-8 rounded-full bg-slate-200/80 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
          
          {/* Gallery Video Selector Area */}
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={handleVideoChange}
          />

          {!media ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-9/12 max-h-64 border-2 border-dashed border-rose-300 hover:border-rose-500 rounded-2xl bg-rose-50/40 flex flex-col items-center justify-center p-6 text-center cursor-pointer transition-colors group"
            >
              {isProcessing ? (
                <div className="flex flex-col items-center gap-2">
                  <Loader2 className="w-8 h-8 animate-spin text-rose-500" />
                  <p className="text-xs font-semibold text-rose-700">Loading video from gallery...</p>
                </div>
              ) : (
                <>
                  <div className="w-14 h-14 rounded-full bg-rose-100 group-hover:bg-rose-200 flex items-center justify-center text-rose-600 mb-3 transition-colors">
                    <Video className="w-7 h-7" />
                  </div>
                  <p className="font-bold text-sm text-slate-800 mb-1">
                    Select video from Android gallery
                  </p>
                  <p className="text-xs text-slate-500 max-w-xs">
                    MP4, WebM or MOV format. Vertical (9:16) clips work best!
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="relative aspect-9/12 max-h-64 rounded-2xl overflow-hidden bg-black flex items-center justify-center">
              <SafeVideo
                src={media.mediaUrl}
                controls
                playsInline
                className="w-full h-full object-contain"
              />
              <button
                type="button"
                onClick={() => setMedia(null)}
                className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[10px] font-mono px-2 py-0.5 rounded-md flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>Ready {media.duration ? `(${media.duration}s)` : ''}</span>
              </div>
            </div>
          )}

          {/* Caption */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Reel Caption & Hashtags
            </label>
            <textarea
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Write a catchy caption... #FaceLook #Shorts #Viral"
              rows={2}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-[#1877F2]"
            />
          </div>

          {/* Sound / Music Track */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Audio / Sound Track
            </label>
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 bg-slate-50">
              <Music className="w-4 h-4 text-purple-600 shrink-0" />
              <input
                type="text"
                value={soundTitle}
                onChange={(e) => setSoundTitle(e.target.value)}
                placeholder="Audio title..."
                className="w-full text-xs font-medium text-slate-800 bg-transparent focus:outline-hidden"
              />
            </div>
          </div>

          {/* Publish Button */}
          <button
            type="submit"
            disabled={!media || isSubmitting || isProcessing}
            className="w-full py-2.5 rounded-xl bg-linear-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 disabled:opacity-50 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Publishing Reel...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Share Reel</span>
              </>
            )}
          </button>

        </form>

      </div>
    </div>
  );
};
