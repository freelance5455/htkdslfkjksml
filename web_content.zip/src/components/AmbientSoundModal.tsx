import React, { useState } from 'react';
import { 
  X, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  Clock, 
  Sparkles, 
  CloudRain, 
  Feather, 
  Wind, 
  Droplets, 
  Moon,
  Headphones,
  Check
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AMBIENT_TRACKS } from '../utils/ambientSoundService';
import { AmbientSoundType } from '../types';

export const AmbientSoundModal: React.FC = () => {
  const {
    showAmbientModal,
    setShowAmbientModal,
    ambientType,
    ambientPlaying,
    ambientVolume,
    setAmbientType,
    toggleAmbientPlay,
    setAmbientVolume,
    setAmbientTimer,
    showToast
  } = useApp();

  const [selectedTimerMin, setSelectedTimerMin] = useState<number>(0);

  if (!showAmbientModal) return null;

  const timerOptions = [
    { label: 'مستمر', minutes: 0 },
    { label: '١٠ دقائق', minutes: 10 },
    { label: '٢٠ دقيقة', minutes: 20 },
    { label: '٣٠ دقيقة', minutes: 30 },
  ];

  const handleSelectTrack = (type: AmbientSoundType) => {
    setAmbientType(type);
    if (type !== 'none') {
      showToast('جاري تشغيل الصوت الهادئ لتعزيز الخشوع 🌿');
    } else {
      showToast('تم إيقاف الصوت الهادئ');
    }
  };

  const handleTimerChange = (min: number) => {
    setSelectedTimerMin(min);
    setAmbientTimer(min);
    if (min > 0) {
      showToast(`تم ضبط مؤقت الإيقاف التلقائي بعد ${min} دقيقة ⏰`);
    } else {
      showToast('تشغيل مستمر دون إيقاف');
    }
  };

  const getTrackIcon = (id: AmbientSoundType) => {
    switch (id) {
      case 'rain': return CloudRain;
      case 'birds': return Feather;
      case 'nature': return Wind;
      case 'water': return Droplets;
      case 'night': return Moon;
      default: return Headphones;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150 select-none text-right"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md max-h-[90vh] bg-[#032017] border-2 border-emerald-600/50 dark:border-amber-500/40 rounded-3xl p-5 shadow-2xl flex flex-col space-y-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-emerald-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 border border-emerald-500/40 flex items-center justify-center text-amber-300 shadow-xs">
              <Headphones className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-extrabold text-[#e8f5ee] font-cairo">
                  أصوات السكينة والخشوع
                </h2>
                {ambientPlaying && (
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#84b8a0] font-tajawal">
                أصوات طبيعية هادئة لتعزيز التركيز والطمأنينة أثناء الذكر
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAmbientModal(false)}
            className="p-1.5 rounded-full text-[#84b8a0] hover:text-white hover:bg-emerald-900/60 transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tracks List */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-2 max-h-[46vh]">
          {AMBIENT_TRACKS.map((track) => {
            const Icon = getTrackIcon(track.id);
            const isSelected = ambientType === track.id && ambientPlaying;

            return (
              <button
                key={track.id}
                onClick={() => handleSelectTrack(track.id)}
                className={`w-full p-3 rounded-2xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#063826] to-[#04281b] border-amber-400/60 shadow-md ring-1 ring-amber-400/30'
                    : 'bg-[#042017] border-emerald-800/80 hover:bg-[#062c20] hover:border-emerald-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 border-amber-400/50'
                      : 'bg-[#062c20] text-emerald-400 border-emerald-800'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>

                  <div>
                    <h3 className={`text-xs font-bold font-cairo ${
                      isSelected ? 'text-amber-200' : 'text-[#e8f5ee]'
                    }`}>
                      {track.title}
                    </h3>
                    <p className="text-[10px] text-[#84b8a0] font-tajawal mt-0.5">
                      {track.description}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 mr-2">
                  {isSelected ? (
                    <div className="flex items-center gap-1">
                      {/* Equalizer animation */}
                      <span className="w-1 h-3.5 bg-amber-400 rounded-full animate-bounce"></span>
                      <span className="w-1 h-5 bg-amber-300 rounded-full animate-bounce [animation-delay:0.15s]"></span>
                      <span className="w-1 h-3 bg-amber-400 rounded-full animate-bounce [animation-delay:0.3s]"></span>
                    </div>
                  ) : (
                    <Play className="w-4 h-4 text-emerald-600 dark:text-emerald-500 opacity-60" />
                  )}
                </div>
              </button>
            );
          })}

          {/* Stop Option Button */}
          <button
            onClick={() => handleSelectTrack('none')}
            className={`w-full p-2.5 rounded-xl border text-center font-bold font-cairo text-xs transition-colors cursor-pointer ${
              ambientType === 'none' || !ambientPlaying
                ? 'bg-[#062c20] border-emerald-700 text-[#84b8a0]'
                : 'bg-red-950/30 border-red-800/50 text-red-300 hover:bg-red-900/40'
            }`}
          >
            إيقاف الصوت الهادئ ✕
          </button>
        </div>

        {/* Volume & Controls Card */}
        <div className="p-3.5 rounded-2xl bg-[#062c20] border border-emerald-800/80 space-y-3">
          {/* Volume Slider */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold font-cairo">
              <span className="flex items-center gap-1.5 text-[#e8f5ee]">
                <Volume2 className="w-4 h-4 text-amber-300" />
                <span>مستوى الصوت:</span>
              </span>
              <span className="text-amber-300 font-mono text-[11px]">
                {Math.round(ambientVolume * 100)}%
              </span>
            </div>

            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ambientVolume}
              onChange={(e) => setAmbientVolume(parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-[#032017] rounded-lg"
            />
          </div>

          {/* Sleep / Reading Timer */}
          <div className="space-y-1.5 pt-1 border-t border-emerald-800/60">
            <div className="flex items-center justify-between text-xs font-bold font-cairo">
              <span className="flex items-center gap-1.5 text-[#e8f5ee]">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                <span>مؤقت الإيقاف التلقائي:</span>
              </span>
              <span className="text-[10px] text-[#84b8a0] font-tajawal">
                {selectedTimerMin > 0 ? `بعد ${selectedTimerMin} دقيقة` : 'بدون مؤقت'}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {timerOptions.map((opt) => (
                <button
                  key={opt.minutes}
                  onClick={() => handleTimerChange(opt.minutes)}
                  className={`py-1 px-1 rounded-lg text-[10px] font-tajawal font-bold border transition-colors cursor-pointer ${
                    selectedTimerMin === opt.minutes
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-[#042017] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Confirmation */}
        <button
          onClick={() => setShowAmbientModal(false)}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs font-cairo transition-transform active:scale-98 shadow-md cursor-pointer"
        >
          تم، متابعة القراءة
        </button>
      </div>
    </div>
  );
};
