import React from 'react';
import { useData } from '../context/DataContext.tsx';
import { ArrowLeft, Github, Mail, MessageSquare, Twitter, Linkedin, Users } from 'lucide-react';

interface FoundersPageProps {
  onBack: () => void;
  onOpenAdmin?: () => void;
}

export const FoundersPage: React.FC<FoundersPageProps> = ({ onBack }) => {
  const { data } = useData();

  // Filter published founders and sort by displayOrder
  const foundersList = (data.founders || [])
    .filter((f) => f.published !== false)
    .sort((a, b) => (a.displayOrder || 99) - (b.displayOrder || 99));

  return (
    <div className="max-w-[1120px] mx-auto px-4 sm:px-6 py-10 sm:py-14 animate-fadeIn">
      {/* Top Navigation */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <span className="text-xs font-mono text-cyan-400/80 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-500/20">
          Studio Leadership
        </span>
      </div>

      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-16">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          THE PEOPLE BEHIND CUBIX
        </span>
        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight mt-4 mb-4 font-['Plus_Jakarta_Sans']">
          Meet the <span className="text-cyan-400">Founders.</span>
        </h1>
        <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
          Meet the people shaping Cubix Studio, guiding projects, managing technical architectures, and turning ideas into finished digital work.
        </p>
      </div>

      {/* Founders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {foundersList.map((founder, idx) => {
          const skillsList = founder.skills ? founder.skills.split(',').map((s) => s.trim()).filter(Boolean) : [];

          return (
            <article
              key={founder.id || idx}
              className="p-8 sm:p-9 rounded-3xl bg-gradient-to-b from-[#08172c] to-[#040c17] border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-200 shadow-[0_15px_40px_rgba(0,0,0,0.4)] flex flex-col justify-between"
            >
              <div>
                {/* Header row: Avatar & Role */}
                <div className="flex items-start justify-between mb-6">
                  <div className="relative">
                    <img
                      src={founder.avatar || '/cubix-logo.jpg'}
                      alt={founder.name}
                      className="w-20 h-20 rounded-2xl object-cover bg-black p-1 border border-cyan-400/40 shadow-[0_0_20px_rgba(0,210,255,0.2)]"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/cubix-logo.jpg';
                      }}
                    />
                    <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#08172c]" />
                  </div>
                  <span className="text-[11px] font-mono font-bold tracking-wider px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    {founder.role || 'LEADERSHIP'}
                  </span>
                </div>

                {/* Name */}
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">
                  {founder.name}
                </h2>

                {/* Bio */}
                <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
                  {founder.bio}
                </p>
              </div>

              <div>
                {/* Skills Chips */}
                {skillsList.length > 0 && (
                  <div className="pt-4 border-t border-white/10 mb-4">
                    <div className="text-[11px] font-mono uppercase text-slate-400 mb-2">Areas of Expertise</div>
                    <div className="flex flex-wrap gap-2">
                      {skillsList.map((skill, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-3 py-1 rounded-full text-xs font-semibold bg-white/[0.04] text-cyan-200 border border-cyan-500/20"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Optional Social / Contact Links */}
                {founder.socialLinks && Object.values(founder.socialLinks).some(Boolean) && (
                  <div className="flex items-center gap-2 pt-2">
                    {founder.socialLinks.github && (
                      <a
                        href={founder.socialLinks.github}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
                        title="GitHub"
                      >
                        <Github className="w-4 h-4" />
                      </a>
                    )}
                    {founder.socialLinks.discord && (
                      <a
                        href={founder.socialLinks.discord}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
                        title="Discord"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </a>
                    )}
                    {founder.socialLinks.twitter && (
                      <a
                        href={founder.socialLinks.twitter}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
                        title="Twitter / X"
                      >
                        <Twitter className="w-4 h-4" />
                      </a>
                    )}
                    {founder.socialLinks.linkedin && (
                      <a
                        href={founder.socialLinks.linkedin}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
                        title="LinkedIn"
                      >
                        <Linkedin className="w-4 h-4" />
                      </a>
                    )}
                    {founder.socialLinks.email && (
                      <a
                        href={`mailto:${founder.socialLinks.email}`}
                        className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
                        title="Email"
                      >
                        <Mail className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {foundersList.length === 0 && (
        <div className="text-center py-16 p-8 rounded-3xl bg-white/[0.02] border border-dashed border-white/15">
          <Users className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">Founders Directory Updating</h3>
          <p className="text-slate-400 text-sm">Founder profiles will appear once published by the studio administrator.</p>
        </div>
      )}
    </div>
  );
};
