"use client";

import { useState } from "react";
import { RotateCcw } from "lucide-react";
import type { DhikrItem } from "@/data/adhkar";
import { useLocalState } from "@/lib/use-local-state";
import { toArabicDigits } from "@/lib/site";

const RING_LENGTH = 289.02652413026095; // 2 * π * 46

type Props = {
  items: DhikrItem[];
  /** Counts are saved in localStorage under this key (shared between pages). */
  storageKey: string;
  /** "full" shows the Arabic text and its source; "compact" shows only the list and counter. */
  variant?: "full" | "compact";
};

export function DhikrCounter({ items, storageKey, variant = "full" }: Props) {
  const [counts, setCounts] = useLocalState<Record<string, number>>(`lia:dhikr:${storageKey}`, {});
  const [activeId, setActiveId] = useState(items[0]?.id ?? "");

  const active = items.find((i) => i.id === activeId) ?? items[0];
  if (!active) return null;

  const count = counts[active.id] ?? 0;
  const progress = Math.min(count / active.target, 1);
  const finished = count >= active.target;
  const total = items.reduce((sum, i) => sum + (counts[i.id] ?? 0), 0);
  const allDone = items.every((i) => (counts[i.id] ?? 0) >= i.target);
  const activeIndex = items.findIndex((i) => i.id === active.id);

  const tap = () => setCounts((prev) => ({ ...prev, [active.id]: (prev[active.id] ?? 0) + 1 }));
  const reset = () => setCounts((prev) => ({ ...prev, [active.id]: 0 }));

  const gridCols =
    variant === "full" ? "lg:grid-cols-[1fr_1.1fr_1fr]" : "lg:grid-cols-[1fr_1.3fr]";

  return (
    <div className={`grid items-center gap-10 ${gridCols}`}>
      {/* List of dhikr */}
      <div className="order-2 lg:order-1">
        <p className="mb-4 text-sm text-ivory/60">اختر الذكر</p>
        <ul className="flex flex-wrap gap-2 lg:flex-col" role="radiogroup" aria-label="الأذكار">
          {items.map((item) => {
            const selected = item.id === active.id;
            const c = counts[item.id] ?? 0;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setActiveId(item.id)}
                  className={`flex w-full items-center justify-between gap-4 rounded-2xl border px-5 py-3.5 text-start transition-all duration-300 ${
                    selected
                      ? "border-gold bg-gold/15 text-ivory shadow-[0_0_30px_-10px_rgba(182,154,105,0.8)]"
                      : "border-white/10 bg-white/[0.03] text-ivory/70 hover:border-gold/40 hover:text-ivory"
                  }`}
                >
                  <span className="font-serif text-xl">{item.title}</span>
                  <span className="shrink-0 text-xs text-gold-light tabular-nums">
                    {toArabicDigits(c)} / {toArabicDigits(item.target)}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Counter */}
      <div className="order-1 flex flex-col items-center gap-6 text-center lg:order-2">
        <button
          type="button"
          onClick={tap}
          aria-label={`سبّح: ${active.title}`}
          className="group relative mx-auto grid aspect-square w-full max-w-[22rem] cursor-pointer place-items-center rounded-full outline-none focus-visible:ring-2 focus-visible:ring-gold"
        >
          <span className="absolute inset-[8%] rounded-full border border-gold/20 bg-[radial-gradient(circle,rgba(49,75,117,0.55),transparent_70%)]" aria-hidden="true" />
          <span className="animate-spin-slower absolute inset-[2%] rounded-full border border-dashed border-gold/20" aria-hidden="true" />
          <svg viewBox="0 0 100 100" className="absolute inset-0 size-full -rotate-90" aria-hidden="true">
            <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(248,247,244,0.1)" strokeWidth="3" />
            <circle
              cx="50"
              cy="50"
              r="46"
              fill="none"
              stroke="#B69A69"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={RING_LENGTH}
              strokeDashoffset={RING_LENGTH * (1 - progress)}
              className="transition-[stroke-dashoffset] duration-500"
            />
          </svg>
          <span className="relative flex flex-col items-center" aria-live="polite">
            <span className="font-serif text-6xl font-bold text-ivory tabular-nums sm:text-7xl">
              {toArabicDigits(count)}
            </span>
            <span className="text-sm text-ivory/50">من {toArabicDigits(active.target)}</span>
          </span>
          <span className="pointer-events-none absolute inset-x-0 bottom-[4%] text-center text-xs text-ivory/50 transition-colors group-hover:text-gold-light">
            اضغط على المسبحة للتسبيح
          </span>
        </button>

        <p className={`min-h-6 text-gold-light transition-opacity duration-500 ${finished ? "opacity-100" : "opacity-0"}`}>
          {allDone ? "تقبّل الله منك — أتممت الورد" : "بارك الله فيك — أتممت هذا الذكر"}
        </p>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={tap}
            className="rounded-full bg-gradient-to-b from-gold-light to-gold px-8 py-3 font-medium text-navy shadow-[0_10px_30px_-10px_rgba(182,154,105,0.9)] transition-transform active:scale-95"
          >
            سبّح
          </button>
          <button
            type="button"
            onClick={reset}
            className="grid size-12 place-items-center rounded-full border border-white/15 text-ivory/70 transition-colors hover:border-gold hover:text-gold-light"
            aria-label="إعادة العدّاد"
          >
            <RotateCcw className="size-4" aria-hidden="true" />
          </button>
        </div>

        <p className="text-xs text-ivory/45">
          مجموع التسبيحات: {toArabicDigits(total)}
          {variant === "full" && activeIndex >= 0 && (
            <span className="ms-3">
              · الذكر {toArabicDigits(activeIndex + 1)} من {toArabicDigits(items.length)}
            </span>
          )}
        </p>
      </div>

      {variant === "full" && (
        <div className="order-3 rounded-3xl border border-white/10 bg-white/[0.03] p-6 sm:p-8">
          <p className="text-sm text-gold-light">{active.source}</p>
          <p
            className="mt-5 font-serif text-2xl leading-[2.1] text-ivory sm:text-3xl"
            lang="ar"
          >
            {active.text}
          </p>
          <p className="mt-6 text-sm text-ivory/55">
            يُقال: {toArabicDigits(active.target)} {active.target === 1 ? "مرة" : "مرات"}
          </p>
        </div>
      )}
    </div>
  );
}
