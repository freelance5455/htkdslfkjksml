import React, { useEffect, useState } from 'react';
import { Crown, Skull, Swords } from 'lucide-react';
import { BossTargetInfo } from '../types/game';

interface BossHealthBarProps {
  boss: BossTargetInfo | null;
}

export const BossHealthBar: React.FC<BossHealthBarProps> = ({ boss }) => {
  const [ghostHpPct, setGhostHpPct] = useState(100);
  const [prevHp, setPrevHp] = useState<number | null>(null);

  const healthPct = boss
    ? Math.max(0, Math.min(100, (boss.health / boss.maxHealth) * 100))
    : 0;

  // Delayed ghost recoil bar animation
  useEffect(() => {
    if (!boss) return;

    if (prevHp !== null && boss.health < prevHp) {
      // Took damage! Keep ghost high for a short moment then lerp down
      const timer = setTimeout(() => {
        setGhostHpPct(healthPct);
      }, 350);
      return () => clearTimeout(timer);
    } else {
      setGhostHpPct(healthPct);
    }
    setPrevHp(boss.health);
  }, [boss?.health, healthPct, prevHp]);

  if (!boss) return null;

  const isDead = boss.health <= 0;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-30 w-[94vw] max-w-lg pointer-events-none select-none font-sans animate-slide-down">
      {/* Boss Health Bar Container Frame */}
      <div className="bg-slate-950/95 border-2 border-red-700/80 rounded-2xl p-2.5 md:p-3 shadow-2xl backdrop-blur-md relative overflow-hidden">
        {/* Subtle fiery glow backdrop */}
        <div className="absolute inset-0 bg-gradient-to-r from-red-950/40 via-amber-950/20 to-red-950/40 pointer-events-none" />

        {/* Top Header Row: Boss Name, Crown, Level & Island */}
        <div className="relative flex items-center justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-lg bg-red-950 border border-red-600/60 flex items-center justify-center shrink-0 text-amber-400 shadow-md">
              {boss.isBoss ? <Crown className="w-3.5 h-3.5" /> : <Skull className="w-3.5 h-3.5" />}
            </div>
            <div className="truncate">
              <span className="font-black text-xs md:text-sm text-white tracking-wide uppercase truncate block">
                {boss.name}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] md:text-xs font-mono font-bold text-amber-400 bg-amber-950/80 border border-amber-600/60 px-2 py-0.5 rounded-md">
              Lv. {boss.level} {boss.isBoss ? 'BOSS' : ''}
            </span>
            {boss.islandName && (
              <span className="hidden sm:inline-block text-[10px] text-slate-400 font-medium">
                · {boss.islandName}
              </span>
            )}
          </div>
        </div>

        {/* Health Bar Track with Ghost Recoil */}
        <div className="relative w-full h-4 md:h-5 bg-slate-900 rounded-lg overflow-hidden border border-red-900/60 shadow-inner">
          {/* Background notches at 25%, 50%, 75% */}
          <div className="absolute inset-0 flex justify-between px-1 pointer-events-none z-20 opacity-30">
            <div className="w-px h-full bg-white ml-[25%]" />
            <div className="w-px h-full bg-white ml-[50%]" />
            <div className="w-px h-full bg-white ml-[75%]" />
          </div>

          {/* Ghost recoil bar (yellow/orange lag) */}
          <div
            className="absolute top-0 bottom-0 left-0 bg-amber-400/80 transition-all duration-500 ease-out z-0"
            style={{ width: `${ghostHpPct}%` }}
          />

          {/* Main active health bar fill */}
          <div
            className={`absolute top-0 bottom-0 left-0 h-full rounded-l-lg transition-all duration-150 z-10 ${
              isDead
                ? 'bg-slate-700'
                : 'bg-gradient-to-r from-red-700 via-rose-600 to-red-500 shadow-lg'
            }`}
            style={{ width: `${healthPct}%` }}
          />

          {/* Health Percentage & HP Text Overlay */}
          <div className="absolute inset-0 flex items-center justify-between px-2.5 text-[10px] md:text-[11px] font-mono font-extrabold text-white z-20 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            <span>{isDead ? 'DEFEATED' : `${Math.round(healthPct)}%`}</span>
            <span>
              {boss.health.toLocaleString()} / {boss.maxHealth.toLocaleString()} HP
            </span>
          </div>
        </div>

        {/* Combat Status Footer */}
        <div className="relative mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400">
          <div className="flex items-center gap-1 text-red-400">
            <Swords className="w-3 h-3" />
            <span className="font-semibold uppercase tracking-wider">Target Engaged</span>
          </div>
          <span>Distance: {Math.round(boss.distance)}m</span>
        </div>
      </div>
    </div>
  );
};
