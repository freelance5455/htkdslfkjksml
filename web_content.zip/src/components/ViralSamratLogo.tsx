import React from 'react';

interface ViralSamratLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const ViralSamratLogo: React.FC<ViralSamratLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeMap = {
    sm: { box: 'w-8 h-8', svg: 32, text: 'text-xs', sub: 'text-[8px]' },
    md: { box: 'w-11 h-11', svg: 44, text: 'text-sm', sub: 'text-[10px]' },
    lg: { box: 'w-16 h-16', svg: 64, text: 'text-lg', sub: 'text-xs' },
    xl: { box: 'w-24 h-24', svg: 96, text: 'text-2xl', sub: 'text-sm' },
  };

  const dim = sizeMap[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Logo Icon Badge */}
      <div className={`relative ${dim.box} rounded-2xl p-[1.5px] rgb-gradient-border shadow-[0_0_20px_rgba(0,255,255,0.35)] shrink-0 transition-transform hover:scale-105 duration-300`}>
        <div className="w-full h-full rounded-[14px] bg-zinc-950 flex items-center justify-center overflow-hidden relative">
          {/* Subtle interior glow */}
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 via-pink-500/20 to-amber-500/30" />
          
          <svg
            width="85%"
            height="85%"
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="relative z-10 drop-shadow-[0_2px_8px_rgba(255,215,0,0.6)]"
          >
            <defs>
              {/* Crown Gold Gradient */}
              <linearGradient id="crownGold" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFF275" />
                <stop offset="50%" stopColor="#FFB800" />
                <stop offset="100%" stopColor="#FF7700" />
              </linearGradient>

              {/* Play Neon Gradient */}
              <linearGradient id="playNeon" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#00F0FF" />
                <stop offset="50%" stopColor="#7000FF" />
                <stop offset="100%" stopColor="#FF007A" />
              </linearGradient>

              {/* Ring Cyan Gradient */}
              <linearGradient id="ringCyan" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#00FFFF" />
                <stop offset="100%" stopColor="#FF00AA" />
              </linearGradient>
            </defs>

            {/* Cyber Ring Orbit */}
            <circle
              cx="50"
              cy="55"
              r="40"
              stroke="url(#ringCyan)"
              strokeWidth="2.5"
              strokeDasharray="6 4"
              className="animate-spin-slow opacity-70 origin-center"
            />

            {/* Glowing Play Triangle */}
            <path
              d="M40 38L68 55L40 72Z"
              fill="url(#playNeon)"
              filter="drop-shadow(0 0 6px #00F0FF)"
            />

            {/* Inner Play Highlight */}
            <path
              d="M44 44L61 55L44 65Z"
              fill="#FFFFFF"
              opacity="0.25"
            />

            {/* Imperial Crown on Top */}
            <path
              d="M26 36L32 18L50 28L68 18L74 36C70 38 30 38 26 36Z"
              fill="url(#crownGold)"
              stroke="#FFF"
              strokeWidth="1"
              filter="drop-shadow(0 0 5px rgba(255,184,0,0.8))"
            />

            {/* Crown Jewels (Ruby & Diamond specks) */}
            <circle cx="32" cy="18" r="2.5" fill="#00FFFF" />
            <circle cx="50" cy="28" r="3" fill="#FF0055" />
            <circle cx="68" cy="18" r="2.5" fill="#00FFFF" />

            {/* Crown Base Band */}
            <rect
              x="28"
              y="33"
              width="44"
              height="4"
              rx="2"
              fill="#FFF275"
              stroke="#FF8800"
              strokeWidth="0.5"
            />
          </svg>
        </div>
      </div>

      {/* Brand Name Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-black tracking-tight text-white ${dim.text} flex items-center gap-1`}>
              <span className="rgb-text font-black">ViralSamrat</span>
              <span className="text-amber-400 font-extrabold tracking-widest text-[10px] sm:text-xs px-1.5 py-0.2 bg-amber-500/10 border border-amber-500/30 rounded-md">
                AI 👑
              </span>
            </span>
          </div>
          <span className={`text-zinc-400 font-mono tracking-wider ${dim.sub}`}>
            वायरल सम्राट • The YouTube Trend King
          </span>
        </div>
      )}
    </div>
  );
};
