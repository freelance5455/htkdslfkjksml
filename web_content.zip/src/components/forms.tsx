import { useMemo, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Field, NativeSelect } from "@/components/field";
import { cn } from "@/lib/utils";
import {
  addDays,
  BREEDS,
  compareSheep,
  HEALTH_KIND_LABEL,
  HEALTH_PRESETS,
  PENS,
  suggestTags,
  todayIso,
} from "@/lib/flock/logic";
import { useFlock } from "@/lib/flock/store";
import type { HealthKind, HerdStatus, Sex, SheepDraft } from "@/lib/flock/types";

function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 rounded-full px-3 text-sm",
        active
          ? "bg-primary text-primary-foreground"
          : "border border-border text-muted-foreground",
      )}
    >
      {children}
    </button>
  );
}

export function SheepForm({
  sheepId,
  onSaved,
}: {
  sheepId?: string;
  onSaved?: (id: string) => void;
}) {
  const sheep = useFlock((s) => s.sheep);
  const saveSheep = useFlock((s) => s.saveSheep);
  const current = sheep.find((s) => s.id === sheepId);
  const [tag, setTag] = useState(current?.tag ?? "");
  const [name, setName] = useState(current?.name ?? "");
  const [sex, setSex] = useState<Sex>(current?.sex ?? "ewe");
  const [birthDate, setBirthDate] = useState(current?.birthDate ?? "");
  const [breed, setBreed] = useState(current?.breed ?? "أولاد جلال");
  const [weight, setWeight] = useState(
    current?.weightKg != null ? String(current.weightKg) : "",
  );
  const [status, setStatus] = useState<HerdStatus>(current?.status ?? "active");
  const [pen, setPen] = useState(current?.pen ?? "حظيرة 1");
  const [notes, setNotes] = useState(current?.notes ?? "");
  const [damId, setDamId] = useState(current?.damId ?? "");
  const [sireId, setSireId] = useState(current?.sireId ?? "");
  const [error, setError] = useState<string | null>(null);

  const dams = sheep
    .filter((s) => s.sex === "ewe" && s.id !== sheepId)
    .slice()
    .sort(compareSheep);
  const sires = sheep
    .filter((s) => s.sex === "ram" && s.id !== sheepId)
    .slice()
    .sort(compareSheep);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const weightKg =
      weight.trim() === ""
        ? (current?.weightKg ?? null)
        : Number(weight.replace(",", "."));
    const draft: SheepDraft = {
      tag,
      name,
      sex,
      birthDate,
      breed,
      weightKg: weightKg != null && Number.isFinite(weightKg) ? weightKg : null,
      status,
      pen,
      notes,
      damId: damId || null,
      sireId: sireId || null,
    };
    if (weight.trim() !== "" && (weightKg == null || !Number.isFinite(weightKg))) {
      setError("الوزن غير مفهوم");
      return;
    }
    const result = saveSheep(draft, sheepId);
    if ("error" in result) {
      setError(result.error);
      return;
    }
    onSaved?.(result.id);
  }

  return (
    <form id="sheep-form" onSubmit={onSubmit} className="flex flex-col gap-4">
      <Field label="رقم الحلقة" htmlFor="tag">
        <Input
          id="tag"
          value={tag}
          onChange={(e) => setTag(e.target.value)}
          placeholder="مثلاً 21"
          autoComplete="off"
          required
        />
      </Field>
      <Field label="الاسم" htmlFor="name" hint="اختياري">
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="اسم تعرفه به"
        />
      </Field>
      <Field label="الجنس">
        <div className="grid grid-cols-2 gap-2">
          <Chip active={sex === "ewe"} onClick={() => setSex("ewe")}>
            نعجة
          </Chip>
          <Chip active={sex === "ram"} onClick={() => setSex("ram")}>
            كبش
          </Chip>
        </div>
      </Field>
      <Field label="تاريخ الميلاد" htmlFor="birth">
        <Input
          id="birth"
          type="date"
          value={birthDate}
          max={todayIso()}
          onChange={(e) => setBirthDate(e.target.value)}
        />
      </Field>
      <Field label="السلالة" htmlFor="breed">
        <Input
          id="breed"
          value={breed}
          onChange={(e) => setBreed(e.target.value)}
          list="breeds"
        />
        <div className="flex flex-wrap gap-2">
          {BREEDS.map((item) => (
            <Chip key={item} active={breed === item} onClick={() => setBreed(item)}>
              {item}
            </Chip>
          ))}
        </div>
      </Field>
      <datalist id="breeds">
        {BREEDS.map((item) => (
          <option key={item} value={item} />
        ))}
      </datalist>
      <Field label="الوزن الحالي" htmlFor="weight" hint="بالكيلوغرام، ويُضاف لسجل الأوزان">
        <Input
          id="weight"
          inputMode="decimal"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          placeholder="48"
        />
      </Field>
      <Field label="الحالة">
        <NativeSelect
          value={status}
          onChange={(v) => setStatus(v as HerdStatus)}
        >
          <option value="active">سليم</option>
          <option value="sick">مريض</option>
          <option value="sold">مبيع</option>
          <option value="dead">نافق</option>
        </NativeSelect>
      </Field>
      <Field label="الحظيرة" htmlFor="pen">
        <Input
          id="pen"
          value={pen}
          onChange={(e) => setPen(e.target.value)}
          list="pens"
        />
        <datalist id="pens">
          {PENS.map((item) => (
            <option key={item} value={item} />
          ))}
        </datalist>
      </Field>
      <Field label="الأم">
        <NativeSelect value={damId} onChange={setDamId}>
          <option value="">غير محددة</option>
          {dams.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name ? `${s.tag} · ${s.name}` : s.tag}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="الأب">
        <NativeSelect value={sireId} onChange={setSireId}>
          <option value="">غير محدد</option>
          {sires.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name ? `${s.tag} · ${s.name}` : s.tag}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="ملاحظات" htmlFor="notes">
        <Textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
        />
      </Field>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Button type="submit" className="w-full">
        حفظ
      </Button>
    </form>
  );
}

export function HealthForm({
  defaultSheepId = null,
  onDone,
}: {
  defaultSheepId?: string | null;
  onDone?: () => void;
}) {
  const sheep = useFlock((s) => s.sheep);
  const addHealth = useFlock((s) => s.addHealth);
  const [date, setDate] = useState(todayIso());
  const [kind, setKind] = useState<HealthKind>("treatment");
  const [sheepId, setSheepId] = useState(defaultSheepId ?? "");
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [markSick, setMarkSick] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const options = useMemo(
    () => sheep.filter((s) => s.status === "active" || s.status === "sick").slice().sort(compareSheep),
    [sheep],
  );

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const result = addHealth({
      sheepId: sheepId || null,
      date,
      kind,
      title,
      notes,
      markSick: markSick && Boolean(sheepId),
    });
    if ("error" in result) {
      setError(result.error);
      return;
    }
    setTitle("");
    setNotes("");
    setMarkSick(false);
    setError(null);
    onDone?.();
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <Field label="النوع">
        <div className="flex flex-wrap gap-2">
          {(Object.keys(HEALTH_KIND_LABEL) as HealthKind[]).map((key) => (
            <Chip key={key} active={kind === key} onClick={() => setKind(key)}>
              {HEALTH_KIND_LABEL[key]}
            </Chip>
          ))}
        </div>
      </Field>
      <Field label="ماذا تم" htmlFor="health-title" error={error ?? undefined}>
        <Input
          id="health-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="مثلاً طارد ديدان"
        />
        <div className="flex flex-wrap gap-2">
          {HEALTH_PRESETS.map((item) => (
            <Chip key={item} active={title === item} onClick={() => setTitle(item)}>
              {item}
            </Chip>
          ))}
        </div>
      </Field>
      <Field label="الرأس">
        <NativeSelect value={sheepId} onChange={setSheepId}>
          <option value="">القطيع كله</option>
          {options.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name ? `${s.tag} · ${s.name}` : s.tag}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="التاريخ" htmlFor="health-date">
        <Input
          id="health-date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
      </Field>
      {sheepId ? (
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={markSick}
            onChange={(e) => setMarkSick(e.target.checked)}
            className="size-4 accent-[var(--foreground)]"
          />
          تعليم هذا الرأس مريضاً
        </label>
      ) : null}
      <Field label="تفصيل" htmlFor="health-notes">
        <Textarea
          id="health-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
        />
      </Field>
      <Button type="submit">حفظ السجل</Button>
    </form>
  );
}

export function BreedingForm({
  defaultEweId,
  onDone,
}: {
  defaultEweId?: string;
  onDone?: () => void;
}) {
  const sheep = useFlock((s) => s.sheep);
  const gestationDays = useFlock((s) => s.gestationDays);
  const addBreeding = useFlock((s) => s.addBreeding);
  const ewes = sheep
    .filter((s) => s.sex === "ewe" && (s.status === "active" || s.status === "sick"))
    .slice()
    .sort(compareSheep);
  const rams = sheep
    .filter((s) => s.sex === "ram" && (s.status === "active" || s.status === "sick"))
    .slice()
    .sort(compareSheep);
  const [eweId, setEweId] = useState(defaultEweId ?? ewes[0]?.id ?? "");
  const [ramId, setRamId] = useState("");
  const [matingDate, setMatingDate] = useState(todayIso());
  const [expectedDate, setExpectedDate] = useState(addDays(todayIso(), gestationDays));
  const [touched, setTouched] = useState(false);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);

  function changeMating(value: string) {
    setMatingDate(value);
    if (!touched && value) setExpectedDate(addDays(value, gestationDays));
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const result = addBreeding({
      eweId,
      ramId: ramId || null,
      matingDate,
      expectedDate,
      notes,
    });
    if ("error" in result) {
      setError(result.error);
      return;
    }
    setNotes("");
    setError(null);
    onDone?.();
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <Field label="النعجة" error={error ?? undefined}>
        <NativeSelect value={eweId} onChange={setEweId}>
          {ewes.length === 0 ? <option value="">لا نعاج في القطيع</option> : null}
          {ewes.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name ? `${s.tag} · ${s.name}` : s.tag}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="الكبش">
        <NativeSelect value={ramId} onChange={setRamId}>
          <option value="">غير محدد</option>
          {rams.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name ? `${s.tag} · ${s.name}` : s.tag}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="تاريخ التلقيح" htmlFor="mate-date">
        <Input
          id="mate-date"
          type="date"
          value={matingDate}
          onChange={(e) => changeMating(e.target.value)}
          required
        />
      </Field>
      <Field
        label="الولادة المتوقعة"
        htmlFor="due-date"
        hint={`حساب افتراضي ${gestationDays} يوماً، ويمكن تعديله`}
      >
        <Input
          id="due-date"
          type="date"
          value={expectedDate}
          onChange={(e) => {
            setTouched(true);
            setExpectedDate(e.target.value);
          }}
          required
        />
      </Field>
      <Field label="ملاحظة" htmlFor="breed-notes">
        <Textarea
          id="breed-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
        />
      </Field>
      <Button type="submit" disabled={!eweId}>
        حفظ التلقيح
      </Button>
    </form>
  );
}

export function LambingForm({
  breedingId,
  onDone,
}: {
  breedingId: string;
  onDone?: () => void;
}) {
  const sheep = useFlock((s) => s.sheep);
  const recordLambing = useFlock((s) => s.recordLambing);
  const [date, setDate] = useState(todayIso());
  const [count, setCount] = useState(1);
  const [rows, setRows] = useState(() =>
    suggestTags(sheep, 1).map((tag) => ({ tag, sex: "ewe" as Sex })),
  );
  const [error, setError] = useState<string | null>(null);

  function resize(next: number) {
    const n = Math.min(4, Math.max(1, next));
    setCount(n);
    setRows((prev) => {
      if (prev.length === n) return prev;
      if (prev.length > n) return prev.slice(0, n);
      const extra = suggestTags(sheep, n).slice(prev.length);
      return [
        ...prev,
        ...extra.map((tag) => ({ tag, sex: "ewe" as Sex })),
      ];
    });
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const result = recordLambing(breedingId, date, rows.slice(0, count));
    if ("error" in result) {
      setError(result.error);
      return;
    }
    onDone?.();
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <Field label="تاريخ الولادة" htmlFor="lamb-date" error={error ?? undefined}>
        <Input
          id="lamb-date"
          type="date"
          value={date}
          max={todayIso()}
          onChange={(e) => setDate(e.target.value)}
          required
        />
      </Field>
      <Field label="عدد المواليد">
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" size="icon" onClick={() => resize(count - 1)} aria-label="أنقص">
            −
          </Button>
          <span className="w-8 text-center text-lg font-semibold tabular-nums">{count}</span>
          <Button type="button" variant="outline" size="icon" onClick={() => resize(count + 1)} aria-label="زد">
            +
          </Button>
        </div>
      </Field>
      {rows.slice(0, count).map((row, index) => (
        <div key={index} className="grid grid-cols-[1fr_8rem] gap-2">
          <Field label={`حلقة المولود ${index + 1}`}>
            <Input
              value={row.tag}
              onChange={(e) =>
                setRows((prev) =>
                  prev.map((item, i) =>
                    i === index ? { ...item, tag: e.target.value } : item,
                  ),
                )
              }
            />
          </Field>
          <Field label="الجنس">
            <NativeSelect
              value={row.sex}
              onChange={(v) =>
                setRows((prev) =>
                  prev.map((item, i) =>
                    i === index ? { ...item, sex: v as Sex } : item,
                  ),
                )
              }
            >
              <option value="ewe">أنثى</option>
              <option value="ram">ذكر</option>
            </NativeSelect>
          </Field>
        </div>
      ))}
      <Button type="submit">تسجيل الولادة وإضافة المواليد</Button>
    </form>
  );
}
