import React, { useState } from 'react';
import {
  TrendingUp,
  DollarSign,
  AlertTriangle,
  Clock,
  Package,
  ShoppingBag,
  ShoppingCart,
  Receipt,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  AlertCircle,
  ChevronLeft,
  Sparkles,
} from 'lucide-react';
import type { AppDatabase, MedicineStock } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic, calculateProfitReport, calculateDebts } from '../utils/calculations.ts';

interface HomeTabProps {
  db: AppDatabase;
  stocks: Record<string, MedicineStock>;
  onNavigateTab: (tabId: string) => void;
  onOpenSaleModal: () => void;
  onOpenPurchaseModal: () => void;
  onOpenExpenseModal: () => void;
  onSelectMedicineDetails: (barcode: string) => void;
  onOpenTeamModal?: () => void;
  onOpenCatalogModal?: () => void;
  isCloudConnected?: boolean;
  actorName?: string;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  db,
  stocks,
  onNavigateTab,
  onOpenSaleModal,
  onOpenPurchaseModal,
  onOpenExpenseModal,
  onSelectMedicineDetails,
  onOpenTeamModal,
  onOpenCatalogModal,
  isCloudConnected,
  actorName,
}) => {
  const [periodMode, setPeriodMode] = useState<'thisMonth' | 'last7Days'>('thisMonth');

  // Compute date intervals
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  let startDate = '';
  let periodTitle = '';

  if (periodMode === 'thisMonth') {
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    startDate = startOfMonth.toISOString().split('T')[0];
    periodTitle = 'ملخص الشهر الحالي';
  } else {
    const past7 = new Date(today);
    past7.setDate(past7.getDate() - 7);
    startDate = past7.toISOString().split('T')[0];
    periodTitle = 'ملخص آخر 7 أيام';
  }

  const profitReport = calculateProfitReport(db.purchases, db.sales, db.expenses, startDate, todayStr, periodTitle);
  const debts = calculateDebts(db.purchases, db.sales, db.payments);

  // Near expiry medicines (within 90 days or expired)
  const stockList = Object.values(stocks);
  const nearExpiryList = stockList
    .filter((s) => s.remaining > 0 && s.daysToExpiry !== null && s.daysToExpiry <= 90)
    .sort((a, b) => (a.daysToExpiry ?? 999) - (b.daysToExpiry ?? 999));

  // Low stock medicines (remaining <= minStockAlert)
  const lowStockList = stockList
    .filter((s) => s.remaining <= s.minStockAlert)
    .sort((a, b) => a.remaining - b.remaining);

  // Combined recent activities (latest 6) with employee attribution
  const recentActivities = [
    ...db.sales.map((s) => ({
      id: s.id,
      type: 'sale' as const,
      title: `بيع: ${s.medicineName}`,
      party: s.buyer,
      date: s.date,
      amount: s.totalAmount,
      qty: s.qty,
      addedByName: s.addedByName || 'فريق المبيعات',
      createdAt: s.createdAt,
    })),
    ...db.purchases.map((p) => ({
      id: p.id,
      type: 'purchase' as const,
      title: `شراء: ${p.medicineName}`,
      party: p.supplier,
      date: p.date,
      amount: p.totalAmount,
      qty: p.qty,
      addedByName: p.addedByName || 'مسؤول المخزن',
      createdAt: p.createdAt,
    })),
    ...db.expenses.map((e) => ({
      id: e.id,
      type: 'expense' as const,
      title: `مصروف: ${e.type}`,
      party: e.note || e.type,
      date: e.date,
      amount: e.amount,
      qty: 0,
      addedByName: e.addedByName || 'الإدارة',
      createdAt: e.createdAt,
    })),
  ]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 6);

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Welcome & Quick Period Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-l from-teal-800 to-teal-900 p-4 rounded-2xl text-white shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-black tracking-tight">لوحة القيادة والمؤشرات</h1>
            <span className="rounded-full bg-teal-700/60 px-2 py-0.5 text-[11px] font-semibold text-teal-200">
              مذخر / صيدلية
            </span>
          </div>
          <p className="text-xs text-teal-100/80 mt-0.5">
            إدارة فورية لجرد المخزون، المبيعات والمشتريات، وحساب الأرباح بدقة بالدينار العراقي
          </p>
        </div>

        {/* Period Segmented Toggle */}
        <div className="flex rounded-xl bg-teal-950/50 p-1 border border-teal-700/50 self-start sm:self-auto">
          <button
            onClick={() => setPeriodMode('thisMonth')}
            className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              periodMode === 'thisMonth'
                ? 'bg-teal-500 text-white shadow-xs'
                : 'text-teal-200 hover:text-white'
            }`}
          >
            الشهر الحالي
          </button>
          <button
            onClick={() => setPeriodMode('last7Days')}
            className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              periodMode === 'last7Days'
                ? 'bg-teal-500 text-white shadow-xs'
                : 'text-teal-200 hover:text-white'
            }`}
          >
            آخر 7 أيام
          </button>
        </div>
      </div>

      {/* Quick Action Buttons Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={onOpenSaleModal}
          className="flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-indigo-600 p-3 text-white shadow-sm hover:bg-indigo-700 active:scale-98 transition"
        >
          <div className="rounded-full bg-indigo-500/50 p-2">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <span className="text-xs font-black">فاتورة بيع (عدة مواد)</span>
        </button>

        <button
          onClick={onOpenPurchaseModal}
          className="flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-teal-700 p-3 text-white shadow-sm hover:bg-teal-800 active:scale-98 transition"
        >
          <div className="rounded-full bg-teal-600/50 p-2">
            <ShoppingCart className="h-5 w-5" />
          </div>
          <span className="text-xs font-black">فاتورة شراء (عدة مواد)</span>
        </button>

        {onOpenCatalogModal && (
          <button
            onClick={onOpenCatalogModal}
            className="flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-emerald-700 p-3 text-white shadow-sm hover:bg-emerald-800 active:scale-98 transition"
          >
            <div className="rounded-full bg-emerald-600/50 p-2">
              <Package className="h-5 w-5" />
            </div>
            <span className="text-xs font-black">تعريف مواد بالباركود</span>
          </button>
        )}

        <button
          onClick={onOpenExpenseModal}
          className="flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-amber-600 p-3 text-white shadow-sm hover:bg-amber-700 active:scale-98 transition"
        >
          <div className="rounded-full bg-amber-500/50 p-2">
            <Receipt className="h-5 w-5" />
          </div>
          <span className="text-xs font-black">إضافة مصاريف</span>
        </button>
      </div>

      {/* Main Financial KPI Grid for Selected Period */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Net Profit */}
        <div className="col-span-2 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 p-4 text-white shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-100 flex items-center gap-1">
              <TrendingUp className="h-4 w-4" />
              صافي الربح ({periodMode === 'thisMonth' ? 'هذا الشهر' : '7 أيام'})
            </span>
            <span className="text-[11px] font-bold bg-white/20 px-2 py-0.5 rounded-full">
              هامش {profitReport.profitMarginPercent.toFixed(1)}%
            </span>
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-black tracking-tight">
            {formatIQD(profitReport.netProfit)}
          </div>
          <div className="mt-2 pt-2 border-t border-white/15 flex items-center justify-between text-xs text-emerald-100">
            <span>إجمالي الربح: {formatIQD(profitReport.grossProfit)}</span>
            <span>المصاريف: {formatIQD(profitReport.totalExpenses)}</span>
          </div>
        </div>

        {/* Sales */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">إجمالي المبيعات</span>
            <div className="rounded-full bg-indigo-50 p-2 text-indigo-600">
              <ArrowUpRight className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-lg font-black text-slate-900">
            {formatIQD(profitReport.totalSales)}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">إيراد المبيعات الإجمالي</p>
        </div>

        {/* Cost of Goods Sold */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">كلفة البضاعة المباعة</span>
            <div className="rounded-full bg-slate-100 p-2 text-slate-600">
              <Package className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-lg font-black text-slate-900">
            {formatIQD(profitReport.cogs)}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">محسوب بمتوسط التكلفة</p>
        </div>
      </div>

      {/* Debts Summary Overview */}
      <div className="grid grid-cols-2 gap-3">
        {/* Money owed to us */}
        <div
          onClick={() => onNavigateTab('debts')}
          className="cursor-pointer rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-teal-300 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600">ديون لنا على الصيدليات</span>
            <span className="text-[10px] text-teal-600 font-bold bg-teal-50 px-1.5 py-0.5 rounded">
              {debts.buyersDebts.length} عميل
            </span>
          </div>
          <div className="mt-2 text-lg font-black text-teal-700">
            {formatIQD(debts.totalOwedToUs)}
          </div>
          <p className="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
            <span>مستحقات واجبة القبض</span>
            <ChevronLeft className="h-3.5 w-3.5" />
          </p>
        </div>

        {/* Money we owe to suppliers */}
        <div
          onClick={() => onNavigateTab('debts')}
          className="cursor-pointer rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-amber-300 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600">ديون علينا للمذاخر</span>
            <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded">
              {debts.suppliersDebts.length} مورد
            </span>
          </div>
          <div className="mt-2 text-lg font-black text-amber-700">
            {formatIQD(debts.totalWeOwe)}
          </div>
          <p className="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
            <span>مطلوبات للموردين</span>
            <ChevronLeft className="h-3.5 w-3.5" />
          </p>
        </div>
      </div>

      {/* Urgent Alerts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Near Expiry Alert (Within 90 days or expired) */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-rose-100 p-1.5 text-rose-600">
                <Clock className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                تنبيهات الصلاحية (خلال 90 يوماً)
              </h3>
            </div>
            <span className="rounded-full bg-rose-50 px-2 py-0.5 text-xs font-bold text-rose-700">
              {nearExpiryList.length} مادة
            </span>
          </div>

          {nearExpiryList.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-400">
              ممتاز! لا توجد وجبات قريبة الانتهاء خلال الأشهر الثلاثة القادمة.
            </div>
          ) : (
            <div className="space-y-2">
              {nearExpiryList.slice(0, 4).map((item) => (
                <div
                  key={item.barcode}
                  onClick={() => onSelectMedicineDetails(item.barcode)}
                  className="cursor-pointer flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-100 transition"
                >
                  <div className="space-y-0.5">
                    <div className="text-xs font-bold text-slate-900">{item.name}</div>
                    <div className="text-[11px] text-slate-500">
                      متبقي في المخزن: <strong className="text-slate-800">{item.remaining}</strong>
                    </div>
                  </div>

                  <div className="text-left">
                    {item.daysToExpiry !== null && item.daysToExpiry <= 0 ? (
                      <span className="inline-block text-[11px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">
                        منتهي!
                      </span>
                    ) : (
                      <span className="inline-block text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                        {item.daysToExpiry} يوم
                      </span>
                    )}
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {formatDateArabic(item.nearestExpiry || '')}
                    </div>
                  </div>
                </div>
              ))}

              {nearExpiryList.length > 4 && (
                <button
                  onClick={() => onNavigateTab('inventory')}
                  className="w-full text-center text-xs font-bold text-teal-700 hover:underline pt-1"
                >
                  عرض جميع المواد القريبة الانتهاء ({nearExpiryList.length}) ←
                </button>
              )}
            </div>
          )}
        </div>

        {/* Low Stock Alert */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-amber-100 p-1.5 text-amber-600">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                تنبيهات انخفاض المخزون (تحت الحد الأدنى)
              </h3>
            </div>
            <span className="rounded-full bg-amber-50 px-2 py-0.5 text-xs font-bold text-amber-700">
              {lowStockList.length} مادة
            </span>
          </div>

          {lowStockList.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-400">
              المخزون متوفر بكميات كافية أعلى من الحد الأدنى للطلب.
            </div>
          ) : (
            <div className="space-y-2">
              {lowStockList.slice(0, 4).map((item) => (
                <div
                  key={item.barcode}
                  onClick={() => onSelectMedicineDetails(item.barcode)}
                  className="cursor-pointer flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-100 transition"
                >
                  <div className="space-y-0.5">
                    <div className="text-xs font-bold text-slate-900">{item.name}</div>
                    <div className="text-[11px] text-slate-500">
                      الحد الأدنى: {item.minStockAlert}
                    </div>
                  </div>

                  <div className="text-left">
                    <span
                      className={`inline-block text-[11px] font-black px-2 py-0.5 rounded-md ${
                        item.remaining === 0
                          ? 'bg-rose-100 text-rose-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}
                    >
                      {item.remaining === 0 ? 'نفذ (0)' : `متبقي ${item.remaining}`}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      كلفة: {formatIQD(item.averageCost)}
                    </div>
                  </div>
                </div>
              ))}

              {lowStockList.length > 4 && (
                <button
                  onClick={() => onNavigateTab('inventory')}
                  className="w-full text-center text-xs font-bold text-teal-700 hover:underline pt-1"
                >
                  عرض جميع المواد المنخفضة ({lowStockList.length}) ←
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Team Activity & Recent Additions Log */}
      <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-slate-900">
                سجل إضافات الفريق (من أضاف القوائم مؤخراً)
              </h3>
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  isCloudConnected
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    isCloudConnected ? 'bg-emerald-600 animate-pulse' : 'bg-amber-500'
                  }`}
                />
                {isCloudConnected ? 'مزامنة سحابية مباشرة' : 'وضع محلي (اضغط لتفعيل السحابة)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              الموظف الحالي المسجل: <strong className="text-teal-800">{actorName || 'المدير'}</strong> — يظهر اسم كل شخص يضيف قائمة بيع أو شراء أو مصروف
            </p>
          </div>

          {onOpenTeamModal && (
            <button
              onClick={onOpenTeamModal}
              className="inline-flex items-center gap-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 px-3 py-1.5 text-xs font-black transition active:scale-95"
            >
              <span>سجل الفريق والسحابة</span>
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="divide-y divide-slate-100">
          {recentActivities.map((act) => (
            <div key={act.id} className="py-2.5 flex items-center justify-between gap-2 first:pt-0 last:pb-0">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                    act.type === 'sale'
                      ? 'bg-indigo-100 text-indigo-700'
                      : act.type === 'purchase'
                      ? 'bg-teal-100 text-teal-700'
                      : 'bg-amber-100 text-amber-700'
                  }`}
                >
                  {act.type === 'sale' ? (
                    <ArrowUpRight className="h-4 w-4" />
                  ) : act.type === 'purchase' ? (
                    <ArrowDownLeft className="h-4 w-4" />
                  ) : (
                    <Receipt className="h-4 w-4" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-900 truncate">{act.title}</span>
                    <span className="inline-flex items-center rounded-md bg-slate-900 text-amber-300 px-1.5 py-0.5 text-[10px] font-bold">
                      بواسطة: {act.addedByName}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {act.party} | {formatDateArabic(act.date)}
                  </div>
                </div>
              </div>

              <div className="text-left font-black text-xs text-slate-900 shrink-0">
                {formatIQD(act.amount)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
