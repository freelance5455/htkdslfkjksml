import React, { useState } from 'react';
import {
  Download,
  Shuffle,
  Volume2,
  ArrowRight,
  HelpCircle,
  Boxes,
  AlertOctagon,
  Bookmark,
  Sparkles,
  Zap,
  Trophy,
  CheckCircle2,
  Gift,
  Flame,
  Brain,
  Clock,
  RotateCcw,
  TrendingUp,
  AlertTriangle,
  Play,
  BarChart3,
  Smartphone,
  Target
} from 'lucide-react';
import { WordData, UserProfile, UserProgressData, SrsRating } from '../types';
import { speakWord, sound } from '../services/sound';
import { SrsEngine, EBBINGHAUS_STAGES } from '../services/srs';

interface HomeTabProps {
  profile: UserProfile;
  progress: UserProgressData;
  wordOfTheDay: WordData;
  words: WordData[];
  onShuffleWod: () => void;
  onOpenWordDetail: (word: WordData) => void;
  onNavigateToTab: (tab: 'wordbook' | 'detective' | 'flashcards' | 'quiz' | 'profile') => void;
  onFilterWordbook: (filter: 'mastered' | 'revise' | 'learn' | 'saved') => void;
  onOpenGame: () => void;
  onOpenChat: () => void;
  onOpenBlitz: () => void;
  onClaimQuest: (questId: string) => void;
  onOpenSrsDrill: () => void;
  onRateSrsWord: (word: string, rating: SrsRating) => void;
  onOpenAnalytics: () => void;
  onOpenApkModal: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  profile,
  progress,
  wordOfTheDay,
  words,
  onShuffleWod,
  onOpenWordDetail,
  onNavigateToTab,
  onFilterWordbook,
  onOpenGame,
  onOpenChat,
  onOpenBlitz,
  onClaimQuest,
  onOpenSrsDrill,
  onRateSrsWord,
  onOpenAnalytics,
  onOpenApkModal,
}) => {
  const [showCurveExplanation, setShowCurveExplanation] = useState(false);
  const goalMax = profile.dailyGoal || 15;
  const goalProgress = progress.todayLearned.length;
  const goalPercent = Math.min(100, Math.round((goalProgress / goalMax) * 100));

  // Compute live Ebbinghaus schedule
  const srsSchedule = SrsEngine.getSrsSchedule(
    words,
    progress.srsRecords || {},
    progress.mastered,
    progress.revise,
    progress.learn
  );

  // Vocabulary Pipeline Numbers
  const totalWords = words.length;
  const masteredCount = progress.mastered.length;
  const reviseCount = progress.revise.length;
  const learnCount = progress.learn.length;
  const remainingCount = Math.max(0, totalWords - masteredCount);
  const masteredPercent = Math.min(100, Math.round((masteredCount / totalWords) * 100));
  const remainingPercent = Math.round((remainingCount / totalWords) * 100);

  // Words needing review more
  const urgentReviewList: { word: WordData; reason: string; badge: string; color: string }[] = [];

  // Overdue & critical decay words first
  srsSchedule.dueWords.slice(0, 2).forEach(item => {
    const wObj = words.find(w => w.word.toLowerCase() === item.word.toLowerCase());
    if (wObj) {
      urgentReviewList.push({
        word: wObj,
        reason: `${item.srs.retentionScore}% Retention • Overdue`,
        badge: 'Spaced Due',
        color: 'rose',
      });
    }
  });

  // Mistakes vault weak words
  progress.mistakesVault.slice(0, 2).forEach(m => {
    if (!urgentReviewList.some(u => u.word.word.toLowerCase() === m.word.toLowerCase())) {
      const wObj = words.find(w => w.word.toLowerCase() === m.word.toLowerCase());
      if (wObj) {
        urgentReviewList.push({
          word: wObj,
          reason: `Missed in Diagnostic (${m.category})`,
          badge: 'Vault Weakness',
          color: 'purple',
        });
      }
    }
  });

  // Group B words fallback
  progress.revise.slice(0, 2).forEach(r => {
    if (!urgentReviewList.some(u => u.word.word.toLowerCase() === r.toLowerCase()) && urgentReviewList.length < 3) {
      const wObj = words.find(w => w.word.toLowerCase() === r.toLowerCase());
      if (wObj) {
        urgentReviewList.push({
          word: wObj,
          reason: 'Group B (Revise Queue)',
          badge: 'Revise',
          color: 'amber',
        });
      }
    }
  });

  // Determine Cadre rank based on XP
  let cadreRank = "Novice Aspirant";
  if (profile.xp >= 1800) cadreRank = "Lexicon Cadre Master 🌟";
  else if (profile.xp >= 800) cadreRank = "Senior Scholar";
  else if (profile.xp >= 300) cadreRank = "Competitive Contender";

  const quests = progress.dailyQuests || [];
  const completedUnclaimedCount = quests.filter(q => q.completed && !q.claimed).length;

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-4 pb-28 max-w-md mx-auto w-full">
      
      {/* PWA / Android APK Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-700 text-white rounded-2xl p-3.5 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Smartphone className="w-5 h-5 text-amber-300 shrink-0" />
          <div>
            <div className="text-xs font-bold leading-tight">Android App & APK Center</div>
            <div className="text-[10px] text-blue-100 leading-tight">Install WebAPK or download standalone package</div>
          </div>
        </div>
        <button
          onClick={onOpenApkModal}
          className="px-3 py-1.5 bg-white text-blue-900 font-extrabold text-xs rounded-xl shadow-sm hover:bg-blue-50 active:scale-95 shrink-0 flex items-center gap-1.5 transition-all"
        >
          <Download className="w-3.5 h-3.5 text-blue-600" />
          <span>Get APK</span>
        </button>
      </div>

      {/* Daily Sprint Card */}
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-3xl p-5 shadow-[0_4px_0_0_#059669] relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider text-emerald-100">
            <span>Welcome, {profile.name}!</span>
            <span className="bg-white/20 px-2.5 py-0.5 rounded-full font-mono text-[10px]">
              {profile.targetExam.split('(')[0].trim()}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-black">Daily Vocab Sprint</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-400 text-slate-900 inline-block mt-0.5">
                Rank: {cadreRank}
              </span>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-black text-2xl">
              🎯
            </div>
          </div>

          <p className="text-xs text-emerald-100 font-bengali">
            অতিরিক্ত মানসিক চাপ ছাড়া প্রতিদিনের লক্ষ্য পূরণ করুন ও দীর্ঘমেয়াদী স্মৃতিতে ধারণ করুন।
          </p>

          <div className="pt-2">
            <div className="flex justify-between text-xs font-bold mb-1">
              <span>Today: {goalProgress}/{goalMax} Words</span>
              <span>{goalPercent}%</span>
            </div>
            <div className="w-full bg-black/20 h-2.5 rounded-full overflow-hidden p-0.5">
              <div
                className="bg-amber-300 h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${goalPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* PROPER ANALYTICS CARD: Total Mastered Words, Remaining Words & Words to Review More */}
      <div className="bg-white dark:bg-[#111827] border-2 border-indigo-200 dark:border-indigo-950/80 rounded-3xl p-4 shadow-sm space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white">
              Mastery & Review Analytics
            </h3>
          </div>
          <button
            onClick={onOpenAnalytics}
            className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 flex items-center gap-0.5"
          >
            <span>Full Analytics</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* 3 Metric Pills */}
        <div className="grid grid-cols-3 gap-2 text-center">
          
          {/* Mastered */}
          <div
            onClick={onOpenAnalytics}
            className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 p-2.5 rounded-2xl cursor-pointer hover:border-emerald-400 transition-all"
          >
            <div className="text-[10px] font-black uppercase text-emerald-800 dark:text-emerald-300">
              Mastered
            </div>
            <div className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {masteredCount}
            </div>
            <div className="text-[9px] font-bold text-emerald-700 dark:text-emerald-400 font-mono">
              {masteredPercent}%
            </div>
          </div>

          {/* Remaining */}
          <div
            onClick={onOpenAnalytics}
            className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 p-2.5 rounded-2xl cursor-pointer hover:border-blue-400 transition-all"
          >
            <div className="text-[10px] font-black uppercase text-blue-800 dark:text-blue-300">
              Remaining
            </div>
            <div className="text-xl sm:text-2xl font-black text-blue-600 dark:text-blue-400">
              {remainingCount}
            </div>
            <div className="text-[9px] font-bold text-blue-700 dark:text-blue-400 font-mono">
              {remainingPercent}%
            </div>
          </div>

          {/* Review More */}
          <div
            onClick={onOpenAnalytics}
            className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 p-2.5 rounded-2xl cursor-pointer hover:border-amber-400 transition-all"
          >
            <div className="text-[10px] font-black uppercase text-amber-800 dark:text-amber-300">
              Review More
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-600 dark:text-amber-400">
              {srsSchedule.dueWords.length + progress.mistakesVault.length + reviseCount}
            </div>
            <div className="text-[9px] font-bold text-amber-700 dark:text-amber-400 font-mono">
              Needs Focus
            </div>
          </div>

        </div>

        {/* Multi-Segmented Visual Bar */}
        <div className="space-y-1">
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
            <div
              style={{ width: `${(masteredCount / totalWords) * 100}%` }}
              className="bg-emerald-500 h-full"
              title={`Mastered: ${masteredCount}`}
            />
            <div
              style={{ width: `${(reviseCount / totalWords) * 100}%` }}
              className="bg-amber-500 h-full"
              title={`Revise: ${reviseCount}`}
            />
            <div
              style={{ width: `${(learnCount / totalWords) * 100}%` }}
              className="bg-rose-500 h-full"
              title={`Learn: ${learnCount}`}
            />
          </div>
          <div className="flex justify-between text-[10px] font-bold text-slate-400 dark:text-slate-500 px-0.5">
            <span>{masteredCount} Mastered</span>
            <span>{remainingCount} Remaining of {totalWords}</span>
          </div>
        </div>

        {/* Priority: Words to Review More Preview */}
        {urgentReviewList.length > 0 && (
          <div className="pt-1 space-y-1.5">
            <div className="text-[10px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-500" />
                Urgent Words to Review:
              </span>
              <button
                onClick={onOpenAnalytics}
                className="text-indigo-600 dark:text-indigo-400 text-[10px] font-bold hover:underline"
              >
                View all ({urgentReviewList.length})
              </button>
            </div>

            <div className="space-y-1.5">
              {urgentReviewList.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => onOpenWordDetail(item.word)}
                  className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 flex items-center justify-between cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                      {item.word.word}
                    </span>
                    <span className="text-[9px] text-slate-400 font-bengali truncate max-w-[120px]">
                      {item.word.bengali}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-md ${
                      item.color === 'rose'
                        ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                        : item.color === 'purple'
                        ? 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300'
                        : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                    }`}>
                      {item.badge}
                    </span>
                    <ArrowRight className="w-3 h-3 text-slate-400" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={onOpenAnalytics}
          className="w-full py-2 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Open Complete Analytics & Lexicon Breakdown</span>
        </button>
      </div>

      {/* Interactive 3D Game & Rapid Match & Gemini AI Mentor Cards */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={onOpenGame}
          className="bg-gradient-to-br from-purple-700 via-indigo-800 to-purple-950 text-white rounded-2xl p-3 shadow-md flex flex-col justify-between text-left active:scale-95 transition-all group border border-purple-500/30"
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-black text-base">
              🎮
            </div>
            <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-900 uppercase">
              3D
            </span>
          </div>
          <div>
            <div className="font-black text-xs text-white group-hover:text-amber-300 transition-colors leading-tight">
              Cadre Runner
            </div>
            <div className="text-[9px] text-purple-200 mt-0.5 font-bengali truncate">
              ৩ডি রানার গেম
            </div>
          </div>
        </button>

        <button
          onClick={onOpenBlitz}
          className="bg-gradient-to-br from-amber-600 via-orange-600 to-red-700 text-white rounded-2xl p-3 shadow-md flex flex-col justify-between text-left active:scale-95 transition-all group border border-amber-400/30"
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-black text-base text-yellow-200">
              ⚡
            </div>
            <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full bg-yellow-300 text-slate-900 uppercase">
              30s
            </span>
          </div>
          <div>
            <div className="font-black text-xs text-white group-hover:text-yellow-200 transition-colors leading-tight">
              Word Blitz
            </div>
            <div className="text-[9px] text-amber-100 mt-0.5 font-bengali truncate">
              দ্রুত অর্থ ম্যাচ
            </div>
          </div>
        </button>

        <button
          onClick={onOpenChat}
          className="bg-gradient-to-br from-blue-700 via-indigo-900 to-slate-950 text-white rounded-2xl p-3 shadow-md flex flex-col justify-between text-left active:scale-95 transition-all group border border-blue-500/30"
        >
          <div className="flex items-center justify-between mb-1.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-black text-base text-amber-300">
              ✨
            </div>
            <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full bg-blue-400 text-slate-950 uppercase">
              AI
            </span>
          </div>
          <div>
            <div className="font-black text-xs text-white group-hover:text-amber-300 transition-colors leading-tight">
              Prof. Cadre
            </div>
            <div className="text-[9px] text-blue-200 mt-0.5 font-bengali truncate">
              সার্চ গ্রাউন্ডিং
            </div>
          </div>
        </button>
      </div>

      {/* Ebbinghaus Forgetting Curve Spaced Repetition Schedule */}
      <div className="bg-white dark:bg-[#111827] border-2 border-indigo-200 dark:border-indigo-950/80 rounded-3xl p-4 shadow-sm space-y-3.5 relative overflow-hidden">
        
        {/* Header & Theoretical Badge */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center shadow-sm">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-slate-900 dark:text-white leading-tight">
                  Ebbinghaus Memory Schedule
                </h3>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  R = e^-t/S
                </span>
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-bengali">
                বৈজ্ঞানিক স্পেসড রিপিটেশন শিডিউল (ভুলে যাওয়ার আগে পুনরাবৃত্তি)
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowCurveExplanation(prev => !prev)}
            className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5"
          >
            {showCurveExplanation ? 'Hide Curve' : 'View Curve'}
          </button>
        </div>

        {/* Ebbinghaus Scientific Explanation Visualizer */}
        {showCurveExplanation && (
          <div className="bg-indigo-50/70 dark:bg-indigo-950/30 p-3.5 rounded-2xl border border-indigo-100 dark:border-indigo-900/40 text-xs space-y-2 animate-fadeIn">
            <div className="flex items-center justify-between font-bold text-indigo-900 dark:text-indigo-200 text-[11px]">
              <span>Hermann Ebbinghaus Forgetting Curve Principle:</span>
              <span className="text-[9px] font-mono bg-indigo-200/60 dark:bg-indigo-900 px-1.5 py-0.5 rounded">
                Decay Halved Each Review
              </span>
            </div>

            {/* SVG Visualizing the Spaced Repetition Curve */}
            <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
              <svg viewBox="0 0 300 90" className="w-full h-20 text-slate-400">
                {/* Axes */}
                <line x1="25" y1="10" x2="25" y2="75" stroke="currentColor" strokeWidth="1" />
                <line x1="25" y1="75" x2="290" y2="75" stroke="currentColor" strokeWidth="1" />
                
                {/* Axis Labels */}
                <text x="5" y="16" fontSize="7" fill="currentColor">100%</text>
                <text x="10" y="75" fontSize="7" fill="currentColor">0%</text>
                <text x="25" y="85" fontSize="7" fill="currentColor">Day 0</text>
                <text x="80" y="85" fontSize="7" fill="currentColor">Day 1</text>
                <text x="145" y="85" fontSize="7" fill="currentColor">Day 3</text>
                <text x="210" y="85" fontSize="7" fill="currentColor">Day 7</text>
                <text x="270" y="85" fontSize="7" fill="currentColor">Day 16+</text>

                {/* Decay without review (dashed red curve) */}
                <path
                  d="M 25 15 Q 40 60, 100 70 T 290 73"
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="1.5"
                  strokeDasharray="3 3"
                />

                {/* Spaced repetition curve (solid green curve with resets) */}
                <path
                  d="M 25 15 Q 50 50, 80 50 L 80 15 Q 110 38, 145 38 L 145 15 Q 180 28, 210 28 L 210 15 Q 250 20, 290 20"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2"
                />

                {/* 80% threshold line */}
                <line x1="25" y1="30" x2="290" y2="30" stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 2" opacity="0.6" />
                <text x="255" y="28" fontSize="6.5" fill="#f59e0b" fontWeight="bold">80% Review Line</text>
              </svg>
            </div>

            <p className="text-[11px] text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
              মানুষের মস্তিষ্ক ২৪ ঘণ্টায় শেখা শব্দের ৫০-৭০% ভুলে যায়। কিন্তু <strong>১ম দিন, ৩য় দিন, ৭ম দিন ও ১৬তম দিনে</strong> রিভিশন দিলে স্মৃতিরেখা সমতল হয়ে দীর্ঘস্থায়ী মেমরিতে স্থায়ী হয়।
            </p>
          </div>
        )}

        {/* Retention Health Metrics Bar */}
        <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Overall Memory Retention
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <span className={
                  srsSchedule.stats.averageRetention >= 80
                    ? 'text-emerald-500'
                    : srsSchedule.stats.averageRetention >= 50
                    ? 'text-amber-500'
                    : 'text-rose-500'
                }>
                  {srsSchedule.stats.averageRetention}%
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {srsSchedule.stats.averageRetention >= 80 ? 'Consolidated' : 'Decaying Traces'}
                </span>
              </div>
            </div>

            {/* Words Due Badge */}
            <div className="text-right">
              <span className={`text-[11px] font-black px-2.5 py-1 rounded-xl inline-flex items-center gap-1 shadow-sm ${
                srsSchedule.dueWords.length > 0
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
              }`}>
                <Clock className="w-3.5 h-3.5" />
                {srsSchedule.dueWords.length > 0
                  ? `${srsSchedule.dueWords.length} Words Due Now`
                  : 'All Up to Date!'}
              </span>
            </div>
          </div>

          {/* Retention Distribution Mini-Pills */}
          <div className="grid grid-cols-3 gap-1.5 pt-1 text-center text-[10px] font-bold">
            <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 p-1.5 rounded-xl text-rose-700 dark:text-rose-300">
              <div className="font-mono text-xs font-black">{srsSchedule.stats.retentionDistribution.critical}</div>
              <div className="text-[9px] font-bengali truncate">ঝুঁকিতে (&lt;৫০%)</div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 p-1.5 rounded-xl text-amber-700 dark:text-amber-300">
              <div className="font-mono text-xs font-black">{srsSchedule.stats.retentionDistribution.fading}</div>
              <div className="text-[9px] font-bengali truncate">ফেইডিং (৫০-৭৯%)</div>
            </div>

            <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 p-1.5 rounded-xl text-emerald-700 dark:text-emerald-300">
              <div className="font-mono text-xs font-black">{srsSchedule.stats.retentionDistribution.stable}</div>
              <div className="text-[9px] font-bengali truncate">স্থায়ী (&gt;৮০%)</div>
            </div>
          </div>
        </div>

        {/* Due Words List for Today */}
        {srsSchedule.dueWords.length > 0 ? (
          <div className="space-y-2">
            <div className="text-xs font-black text-slate-900 dark:text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                Words Due for Revision Today (আজকের রিভিশন)
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {srsSchedule.dueWords.length} due
              </span>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {srsSchedule.dueWords.slice(0, 4).map((item) => {
                const srs = item.srs;
                const stageInfo = EBBINGHAUS_STAGES[srs.stage] || EBBINGHAUS_STAGES[0];
                const retention = srs.retentionScore;
                
                let retBg = 'bg-rose-500';
                let retTextColor = 'text-rose-600 dark:text-rose-400';
                if (retention >= 80) {
                  retBg = 'bg-emerald-500';
                  retTextColor = 'text-emerald-600 dark:text-emerald-400';
                } else if (retention >= 50) {
                  retBg = 'bg-amber-500';
                  retTextColor = 'text-amber-600 dark:text-amber-400';
                }

                return (
                  <div
                    key={item.word}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 flex flex-col gap-2 hover:border-indigo-300 dark:hover:border-indigo-800 transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => onOpenWordDetail(item)}
                            className="font-black text-sm text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 text-left transition-colors"
                          >
                            {item.word}
                          </button>
                          <span className="text-[9px] font-bold capitalize text-slate-400">
                            {item.pos}
                          </span>
                        </div>
                        <div className="text-xs font-bengali text-slate-600 dark:text-slate-300 mt-0.5 line-clamp-1">
                          {item.bengali}
                        </div>
                      </div>

                      {/* Retention score badge */}
                      <div className="text-right">
                        <span className={`text-xs font-black font-mono ${retTextColor}`}>
                          {retention}%
                        </span>
                        <div className="text-[9px] text-slate-400 font-mono">
                          {stageInfo.label.split('(')[0].trim()}
                        </div>
                      </div>
                    </div>

                    {/* Mini Retention Progress Bar */}
                    <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${retBg}`}
                        style={{ width: `${retention}%` }}
                      />
                    </div>

                    {/* Quick 1-Tap Inline SRS Rating Buttons */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-slate-800/60">
                      <span className="text-[9px] font-bold text-slate-400 font-bengali">
                        ১-ট্যাপ রেটিং:
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            onRateSrsWord(item.word, 'again');
                            sound.wrong();
                          }}
                          className="px-2 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-[9px] font-extrabold hover:bg-rose-200 active:scale-95 transition-all"
                          title="Forgot / Reset"
                        >
                          Again
                        </button>

                        <button
                          onClick={() => {
                            onRateSrsWord(item.word, 'good');
                            sound.correct();
                          }}
                          className="px-2 py-0.5 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[9px] font-extrabold hover:bg-blue-200 active:scale-95 transition-all"
                          title="Recalled properly"
                        >
                          Good
                        </button>

                        <button
                          onClick={() => {
                            onRateSrsWord(item.word, 'easy');
                            sound.triggerFloatingXp(20);
                          }}
                          className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[9px] font-extrabold hover:bg-emerald-200 active:scale-95 transition-all"
                          title="Instant effortless recall"
                        >
                          Easy
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Start SRS Drill Button */}
            <button
              onClick={onOpenSrsDrill}
              className="w-full py-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-[0_4px_0_0_#4338ca] flex items-center justify-center gap-2 active:translate-y-0.5 transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Ebbinghaus Daily Drill ({srsSchedule.dueWords.length} Words)</span>
            </button>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/40 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
            <div>
              <div className="text-xs font-black text-slate-900 dark:text-white">
                All Memory Traces 100% Consolidated!
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-bengali mt-0.5">
                আপনার কোনো শব্দই বর্তমানে ভুলে যাওয়ার ঝুঁকিতে নেই। পরবর্তী রিভিশন শিডিউল প্রস্তুত রয়েছে।
              </div>
            </div>

            {srsSchedule.upcomingWords.length > 0 && (
              <button
                onClick={onOpenSrsDrill}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-sm inline-flex items-center gap-1 active:scale-95 transition-all"
              >
                Practice Upcoming Words Early ({srsSchedule.upcomingWords.length})
              </button>
            )}
          </div>
        )}

      </div>

      {/* Duolingo-Style Daily Quests */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-500 fill-amber-500" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white">
              Daily Quests (প্রতিদিনের মিশন)
            </h3>
          </div>
          {completedUnclaimedCount > 0 && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500 text-white animate-pulse">
              {completedUnclaimedCount} ready to claim!
            </span>
          )}
        </div>

        <div className="space-y-2.5">
          {quests.map((q) => {
            const pct = Math.min(100, Math.round((q.current / q.target) * 100));

            return (
              <div
                key={q.id}
                className={`p-3 rounded-2xl border transition-all ${
                  q.completed && !q.claimed
                    ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700/60'
                    : q.claimed
                    ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40'
                    : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      {q.title}
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                      {q.description}
                    </div>
                  </div>

                  {q.claimed ? (
                    <span className="flex items-center gap-1 text-[10px] font-black text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/80 px-2.5 py-1 rounded-xl">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Claimed
                    </span>
                  ) : q.completed ? (
                    <button
                      onClick={() => {
                        onClaimQuest(q.id);
                        sound.triggerCelebration();
                      }}
                      className="flex items-center gap-1 text-xs font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 px-3 py-1.5 rounded-xl shadow-[0_2px_0_0_#d97706] active:translate-y-0.5 transition-all animate-bounce"
                    >
                      <Gift className="w-3.5 h-3.5" /> +{q.xpReward} XP
                    </button>
                  ) : (
                    <span className="text-[10px] font-mono font-bold text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded-lg">
                      {q.current}/{q.target}
                    </span>
                  )}
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      q.completed ? 'bg-amber-400' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3-Tier Cognitive Mastery Counters */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <button
          onClick={() => {
            onFilterWordbook('mastered');
            onNavigateToTab('wordbook');
          }}
          className="bg-white dark:bg-[#111827] border-2 border-emerald-200 dark:border-emerald-950 p-2.5 rounded-2xl shadow-sm hover:border-emerald-400 active:scale-95 transition-all text-left"
        >
          <div className="text-lg font-black text-emerald-600 dark:text-emerald-400">
            {progress.mastered.length}
          </div>
          <div className="text-[10px] font-bold text-slate-500 font-bengali truncate">গ্রুপ A (আয়ত্ত করা)</div>
          <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-mono font-bold">✓ Known</span>
        </button>

        <button
          onClick={() => {
            onFilterWordbook('revise');
            onNavigateToTab('wordbook');
          }}
          className="bg-white dark:bg-[#111827] border-2 border-amber-200 dark:border-amber-950 p-2.5 rounded-2xl shadow-sm hover:border-amber-400 active:scale-95 transition-all text-left"
        >
          <div className="text-lg font-black text-amber-500">
            {progress.revise.length}
          </div>
          <div className="text-[10px] font-bold text-slate-500 font-bengali truncate">গ্রুপ B (রিভাইজ)</div>
          <span className="text-[9px] text-amber-500 font-mono font-bold">⚡ Revise</span>
        </button>

        <button
          onClick={() => {
            onFilterWordbook('learn');
            onNavigateToTab('wordbook');
          }}
          className="bg-white dark:bg-[#111827] border-2 border-rose-200 dark:border-rose-950 p-2.5 rounded-2xl shadow-sm hover:border-rose-400 active:scale-95 transition-all text-left"
        >
          <div className="text-lg font-black text-rose-500">
            {progress.learn.length}
          </div>
          <div className="text-[10px] font-bold text-slate-500 font-bengali truncate">গ্রুপ C (নতুন শব্দ)</div>
          <span className="text-[9px] text-rose-500 font-mono font-bold">🎯 Learn</span>
        </button>
      </div>

      {/* Word of the Day Showcase */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-amber-500 flex items-center gap-1 uppercase tracking-wide">
            <Sparkles className="w-3.5 h-3.5 fill-current" /> Word of the Day (আজকের শব্দ)
          </span>
          <button
            onClick={onShuffleWod}
            className="px-2.5 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-extrabold text-[10px] flex items-center gap-1 hover:scale-105 active:scale-95 transition-all"
            title="Random Active Recall Shuffle"
          >
            <Shuffle className="w-3 h-3" /> Random Recall
          </button>
        </div>

        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {wordOfTheDay.word}
            </h3>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 capitalize">
                {wordOfTheDay.pos}
              </span>
              <span className="text-xs text-slate-400 font-mono">{wordOfTheDay.ipa}</span>
              <span className="text-xs font-bengali text-slate-500">{wordOfTheDay.bengaliPron}</span>
            </div>
          </div>
          <button
            onClick={() => speakWord(wordOfTheDay.word, profile.voiceLang || 'en-US')}
            className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:text-emerald-500 active:scale-95 transition-all"
            title="Listen to pronunciation"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-emerald-50/80 dark:bg-emerald-950/40 p-3 rounded-2xl border border-emerald-100 dark:border-emerald-900/60 font-bengali">
          <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider block">
            বাংলা অর্থ:
          </span>
          <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
            {wordOfTheDay.bengali}
          </p>
        </div>

        <div className="p-2.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 font-bengali text-xs">
          <strong className="text-amber-800 dark:text-amber-300 block font-bold">
            স্মৃতি সহায়ক টেকনিক (Mnemonic):
          </strong>
          <span className="text-slate-700 dark:text-slate-300">
            {wordOfTheDay.mnemonicBengali}
          </span>
        </div>

        <button
          onClick={() => onOpenWordDetail(wordOfTheDay)}
          className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-[0_4px_0_0_#059669] flex items-center justify-center gap-1.5 active:translate-y-1 transition-all"
        >
          <span>Read Full 17-Section Master Dossier</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Action Navigation Grid */}
      <div className="grid grid-cols-4 gap-2">
        <button
          onClick={() => onNavigateToTab('detective')}
          className="bg-white dark:bg-[#111827] border-2 border-purple-200 dark:border-purple-950 rounded-2xl p-2.5 shadow-sm flex flex-col justify-between items-center active:scale-95 transition-all text-center"
        >
          <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-600 flex items-center justify-center mb-1">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <div className="font-extrabold text-xs text-slate-900 dark:text-white">Clues</div>
            <div className="text-[9px] text-purple-500 font-bengali">ডিটেক্টিভ</div>
          </div>
        </button>

        <button
          onClick={() => {
            onFilterWordbook('saved');
            onNavigateToTab('wordbook');
          }}
          className="bg-white dark:bg-[#111827] border-2 border-amber-200 dark:border-amber-950 rounded-2xl p-2.5 shadow-sm flex flex-col justify-between items-center active:scale-95 transition-all text-center"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 flex items-center justify-center mb-1 relative">
            <Bookmark className="w-4 h-4 fill-current" />
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-600 text-white text-[8px] font-black flex items-center justify-center">
              {progress.saved.length}
            </span>
          </div>
          <div>
            <div className="font-extrabold text-xs text-slate-900 dark:text-white">Saved</div>
            <div className="text-[9px] text-amber-600 font-bengali">বুকমার্ক</div>
          </div>
        </button>

        <button
          onClick={() => onNavigateToTab('flashcards')}
          className="bg-white dark:bg-[#111827] border-2 border-blue-200 dark:border-blue-950 rounded-2xl p-2.5 shadow-sm flex flex-col justify-between items-center active:scale-95 transition-all text-center"
        >
          <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 flex items-center justify-center mb-1">
            <Boxes className="w-4 h-4" />
          </div>
          <div>
            <div className="font-extrabold text-xs text-slate-900 dark:text-white">Cards</div>
            <div className="text-[9px] text-blue-600 font-bengali">ফ্ল্যাশকার্ড</div>
          </div>
        </button>

        <button
          onClick={() => onNavigateToTab('quiz')}
          className="bg-white dark:bg-[#111827] border-2 border-rose-200 dark:border-rose-950 rounded-2xl p-2.5 shadow-sm flex flex-col justify-between items-center active:scale-95 transition-all text-center"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 flex items-center justify-center mb-1 relative">
            <AlertOctagon className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[8px] font-black flex items-center justify-center">
              {progress.mistakesVault.length}
            </span>
          </div>
          <div>
            <div className="font-extrabold text-xs text-slate-900 dark:text-white">Mistakes</div>
            <div className="text-[9px] text-rose-500 font-bengali">দুর্বল শব্দ</div>
          </div>
        </button>
      </div>

    </div>
  );
};
