import React, { useState } from 'react';
import {
  TrendingUp,
  AlertTriangle,
  Clock,
  Package,
  ShoppingBag,
  ShoppingCart,
  Receipt,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronLeft,
  Printer,
  Cloud,
  BarChart3,
  Database,
  PackagePlus,
} from 'lucide-react';
import type { AppDatabase, MedicineStock } from '../types/pharmacy.ts';
import {
  formatIQD,
  formatDateArabic,
  calculateProfitReport,
  calculateDebts,
} from '../utils/calculations.ts';

interface HomeTabProps {
  db: AppDatabase;
  stocks: Record<string, MedicineStock>;
  onNavigateTab: (tabId: string) => void;
  onOpenSaleModal: () => void;
  onOpenPurchaseModal: () => void;
  onOpenExpenseModal: () => void;
  onSelectMedicineDetails: (barcode: string) => void;
  onOpenTeamModal?: () => void;
  onOpenCatalogModal?: () => void;
  onOpenPrintModal?: () => void;
  isCloudConnected?: boolean;
  actorName?: string;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  db,
  stocks,
  onNavigateTab,
  onOpenSaleModal,
  onOpenPurchaseModal,
  onOpenExpenseModal,
  onSelectMedicineDetails,
  onOpenTeamModal,
  onOpenCatalogModal,
  onOpenPrintModal,
  isCloudConnected,
  actorName,
}) => {
  const [periodMode, setPeriodMode] = useState<'thisMonth' | 'last7Days'>('thisMonth');

  // Compute date intervals
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  let startDate = '';
  let periodTitle = '';

  if (periodMode === 'thisMonth') {
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    startDate = startOfMonth.toISOString().split('T')[0];
    periodTitle = 'ملخص الشهر الحالي';
  } else {
    const past7 = new Date(today);
    past7.setDate(past7.getDate() - 7);
    startDate = past7.toISOString().split('T')[0];
    periodTitle = 'ملخص آخر 7 أيام';
  }

  const profitReport = calculateProfitReport(
    db.purchases,
    db.sales,
    db.expenses,
    startDate,
    todayStr,
    periodTitle
  );
  const debts = calculateDebts(db.purchases, db.sales, db.payments);

  // Near expiry medicines (within 90 days or expired)
  const stockList = Object.values(stocks);
  const nearExpiryList = stockList
    .filter((s) => s.remaining > 0 && s.daysToExpiry !== null && s.daysToExpiry <= 90)
    .sort((a, b) => (a.daysToExpiry ?? 999) - (b.daysToExpiry ?? 999));

  // Low stock medicines (remaining <= minStockAlert)
  const lowStockList = stockList
    .filter((s) => s.remaining <= s.minStockAlert)
    .sort((a, b) => a.remaining - b.remaining);

  // Combined recent activities (latest 5)
  const recentActivities = [
    ...db.sales.map((s) => ({
      id: s.id,
      type: 'sale' as const,
      title: `بيع: ${s.medicineName}`,
      party: s.buyer,
      date: s.date,
      amount: s.totalAmount,
      addedByName: s.addedByName || 'فريق المبيعات',
      createdAt: s.createdAt,
    })),
    ...db.purchases.map((p) => ({
      id: p.id,
      type: 'purchase' as const,
      title: `شراء: ${p.medicineName}`,
      party: p.supplier,
      date: p.date,
      amount: p.totalAmount,
      addedByName: p.addedByName || 'مسؤول المخزن',
      createdAt: p.createdAt,
    })),
    ...db.expenses.map((e) => ({
      id: e.id,
      type: 'expense' as const,
      title: `مصروف: ${e.type}`,
      party: e.note || e.type,
      date: e.date,
      amount: e.amount,
      addedByName: e.addedByName || 'الإدارة',
      createdAt: e.createdAt,
    })),
  ]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 5);

  return (
    <div className="space-y-3.5 pb-20 animate-fadeIn">
      {/* Primary 4 Quick Actions Grid (Mobile-First Ergonomic Layout) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={onOpenSaleModal}
          className="flex items-center gap-2.5 rounded-2xl bg-indigo-700 hover:bg-indigo-800 p-3 text-white shadow-xs active:scale-98 transition text-right"
        >
          <div className="rounded-xl bg-white/15 p-2 shrink-0">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-black truncate">فاتورة بيع</div>
            <div className="text-[10px] text-indigo-200 truncate">لصيدلية أو عميل</div>
          </div>
        </button>

        <button
          onClick={onOpenPurchaseModal}
          className="flex items-center gap-2.5 rounded-2xl bg-teal-700 hover:bg-teal-800 p-3 text-white shadow-xs active:scale-98 transition text-right"
        >
          <div className="rounded-xl bg-white/15 p-2 shrink-0">
            <ShoppingCart className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-black truncate">فاتورة شراء</div>
            <div className="text-[10px] text-teal-200 truncate">من مذخر أو مورد</div>
          </div>
        </button>

        {onOpenPrintModal && (
          <button
            onClick={onOpenPrintModal}
            className="flex items-center gap-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 p-3 text-white shadow-xs active:scale-98 transition text-right"
          >
            <div className="rounded-xl bg-amber-400/20 text-amber-300 p-2 shrink-0">
              <Printer className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black text-amber-300 truncate">طباعة فاتورة</div>
              <div className="text-[10px] text-slate-300 truncate">ترتيب وتحديد الاسم</div>
            </div>
          </button>
        )}

        {onOpenTeamModal && (
          <button
            onClick={onOpenTeamModal}
            className="flex items-center gap-2.5 rounded-2xl bg-emerald-800 hover:bg-emerald-900 p-3 text-white shadow-xs active:scale-98 transition text-right"
          >
            <div className="rounded-xl bg-white/15 p-2 shrink-0">
              <Cloud className="h-5 w-5 text-emerald-300" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black truncate">التحكم بالسحابة</div>
              <div className="text-[10px] text-emerald-200 truncate">مزامنة ومسح شامل</div>
            </div>
          </button>
        )}
      </div>

      {/* Secondary Quick Tools Strip (Expenses, Reports, Catalog, Backup) */}
      <div className="grid grid-cols-4 gap-1.5">
        {onOpenCatalogModal && (
          <button
            onClick={onOpenCatalogModal}
            className="flex flex-col sm:flex-row items-center justify-center gap-1 rounded-xl bg-white border border-slate-200/90 py-2 px-2 text-slate-700 hover:bg-slate-50 transition"
          >
            <PackagePlus className="h-4 w-4 text-teal-700 shrink-0" />
            <span className="text-[11px] font-bold truncate">تعريف المواد</span>
          </button>
        )}
        <button
          onClick={onOpenExpenseModal}
          className="flex flex-col sm:flex-row items-center justify-center gap-1 rounded-xl bg-white border border-slate-200/90 py-2 px-2 text-slate-700 hover:bg-slate-50 transition"
        >
          <Receipt className="h-4 w-4 text-amber-600 shrink-0" />
          <span className="text-[11px] font-bold truncate">المصاريف</span>
        </button>
        <button
          onClick={() => onNavigateTab('report')}
          className="flex flex-col sm:flex-row items-center justify-center gap-1 rounded-xl bg-white border border-slate-200/90 py-2 px-2 text-slate-700 hover:bg-slate-50 transition"
        >
          <BarChart3 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span className="text-[11px] font-bold truncate">تقرير الأرباح</span>
        </button>
        <button
          onClick={() => onNavigateTab('backup')}
          className="flex flex-col sm:flex-row items-center justify-center gap-1 rounded-xl bg-white border border-slate-200/90 py-2 px-2 text-slate-700 hover:bg-slate-50 transition"
        >
          <Database className="h-4 w-4 text-indigo-700 shrink-0" />
          <span className="text-[11px] font-bold truncate">نسخ احتياطي</span>
        </button>
      </div>

      {/* Main Financial Hero Card + Period Switcher */}
      <div className="rounded-2xl bg-gradient-to-l from-teal-900 via-teal-800 to-emerald-900 p-4 text-white shadow-sm space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <span className="text-xs font-bold text-teal-200 flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4 text-amber-300" />
              صافي الربح ({periodMode === 'thisMonth' ? 'الشهر الحالي' : 'آخر 7 أيام'})
            </span>
            <div className="mt-1 text-2xl sm:text-3xl font-black font-mono tracking-tight">
              {formatIQD(profitReport.netProfit)}
            </div>
          </div>

          <div className="flex rounded-xl bg-teal-950/60 p-1 border border-teal-700/50 shrink-0">
            <button
              onClick={() => setPeriodMode('thisMonth')}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition ${
                periodMode === 'thisMonth'
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              هذا الشهر
            </button>
            <button
              onClick={() => setPeriodMode('last7Days')}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition ${
                periodMode === 'last7Days'
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              7 أيام
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-2.5 border-t border-white/15 text-xs">
          <div>
            <div className="text-[10px] text-teal-200/80">المبيعات</div>
            <div className="font-mono font-black text-white mt-0.5 truncate">
              {formatIQD(profitReport.totalSales)}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-teal-200/80">كلفة البضاعة</div>
            <div className="font-mono font-black text-white mt-0.5 truncate">
              {formatIQD(profitReport.cogs)}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-teal-200/80">المصاريف</div>
            <div className="font-mono font-black text-amber-300 mt-0.5 truncate">
              {formatIQD(profitReport.totalExpenses)}
            </div>
          </div>
        </div>
      </div>

      {/* Debts Summary Overview */}
      <div className="grid grid-cols-2 gap-2.5">
        <div
          onClick={() => onNavigateTab('debts')}
          className="cursor-pointer rounded-2xl bg-white p-3.5 border border-slate-200/90 shadow-xs hover:border-teal-400 transition"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-bold">ديون لنا (الصيدليات)</span>
            <span className="font-mono text-[11px] text-teal-700 font-bold">
              {debts.buyersDebts.length} عميل
            </span>
          </div>
          <div className="mt-1.5 text-base sm:text-lg font-black font-mono text-teal-800">
            {formatIQD(debts.totalOwedToUs)}
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('debts')}
          className="cursor-pointer rounded-2xl bg-white p-3.5 border border-slate-200/90 shadow-xs hover:border-amber-400 transition"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-bold">ديون علينا (المذاخر)</span>
            <span className="font-mono text-[11px] text-amber-700 font-bold">
              {debts.suppliersDebts.length} مورد
            </span>
          </div>
          <div className="mt-1.5 text-base sm:text-lg font-black font-mono text-amber-700">
            {formatIQD(debts.totalWeOwe)}
          </div>
        </div>
      </div>

      {/* Urgent Alerts Section (Compact & Clean) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Near Expiry Alert */}
        <div className="rounded-2xl bg-white p-3.5 border border-slate-200/90 shadow-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-rose-600" />
              <h3 className="text-xs sm:text-sm font-black text-slate-900">
                تنبيهات الصلاحية القريبة
              </h3>
            </div>
            <span className="text-xs font-bold text-rose-700">{nearExpiryList.length} مادة</span>
          </div>

          {nearExpiryList.length === 0 ? (
            <div className="text-center py-4 text-xs text-slate-400">
              لا توجد وجبات قريبة الانتهاء حالياً.
            </div>
          ) : (
            <div className="space-y-1.5">
              {nearExpiryList.slice(0, 3).map((item) => (
                <div
                  key={item.barcode}
                  onClick={() => onSelectMedicineDetails(item.barcode)}
                  className="cursor-pointer flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-100 transition text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 truncate">{item.name}</div>
                    <div className="text-[11px] text-slate-500">
                      المتبقي: <strong className="text-slate-800">{item.remaining}</strong> ·{' '}
                      {formatDateArabic(item.nearestExpiry || '')}
                    </div>
                  </div>
                  <span className="text-[11px] font-black text-rose-700 shrink-0">
                    {item.daysToExpiry !== null && item.daysToExpiry <= 0
                      ? 'منتهي!'
                      : `${item.daysToExpiry} يوم`}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Low Stock Alert */}
        <div className="rounded-2xl bg-white p-3.5 border border-slate-200/90 shadow-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <h3 className="text-xs sm:text-sm font-black text-slate-900">
                تنبيهات انخفاض المخزون
              </h3>
            </div>
            <span className="text-xs font-bold text-amber-700">{lowStockList.length} مادة</span>
          </div>

          {lowStockList.length === 0 ? (
            <div className="text-center py-4 text-xs text-slate-400">
              المخزون متوفر بكميات كافية.
            </div>
          ) : (
            <div className="space-y-1.5">
              {lowStockList.slice(0, 3).map((item) => (
                <div
                  key={item.barcode}
                  onClick={() => onSelectMedicineDetails(item.barcode)}
                  className="cursor-pointer flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-100 transition text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 truncate">{item.name}</div>
                    <div className="text-[11px] text-slate-500">
                      الحد الأدنى: {item.minStockAlert} · كلفة: {formatIQD(item.averageCost)}
                    </div>
                  </div>
                  <span
                    className={`text-[11px] font-black shrink-0 ${
                      item.remaining === 0 ? 'text-rose-700' : 'text-amber-700'
                    }`}
                  >
                    {item.remaining === 0 ? 'نفذ (0)' : `متبقي ${item.remaining}`}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Team Activity & Recent Additions Log */}
      <div className="rounded-2xl bg-white p-3.5 border border-slate-200/90 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
          <div>
            <h3 className="text-xs sm:text-sm font-black text-slate-900">
              آخر الحركات السحابية ({actorName || 'المدير'})
            </h3>
            <p className="text-[11px] text-slate-500">
              {isCloudConnected
                ? 'مزامنة سحابية مباشرة لجميع الأجهزة'
                : 'وضع محلي — اضغط للتحكم بالسحابة'}
            </p>
          </div>

          {onOpenTeamModal && (
            <button
              onClick={onOpenTeamModal}
              className="inline-flex items-center gap-1 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 px-2.5 py-1.5 text-[11px] font-black transition shrink-0"
            >
              <span>إدارة السحابة</span>
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        {recentActivities.length === 0 ? (
          <div className="py-5 text-center text-xs text-slate-400">
            لا توجد حركات مسجلة حالياً.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentActivities.map((act) => (
              <div
                key={act.id}
                className="py-2 flex items-center justify-between gap-2 first:pt-0 last:pb-0 text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl ${
                      act.type === 'sale'
                        ? 'bg-indigo-50 text-indigo-700'
                        : act.type === 'purchase'
                        ? 'bg-teal-50 text-teal-700'
                        : 'bg-amber-50 text-amber-700'
                    }`}
                  >
                    {act.type === 'sale' ? (
                      <ArrowUpRight className="h-4 w-4" />
                    ) : act.type === 'purchase' ? (
                      <ArrowDownLeft className="h-4 w-4" />
                    ) : (
                      <Receipt className="h-4 w-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 truncate">{act.title}</div>
                    <div className="text-[11px] text-slate-500 truncate">
                      {act.party} · {act.addedByName} · {formatDateArabic(act.date)}
                    </div>
                  </div>
                </div>

                <div className="text-left font-mono font-black text-slate-900 shrink-0">
                  {formatIQD(act.amount)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
