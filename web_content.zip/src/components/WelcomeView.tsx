import React from 'react';
import { Code2, Compass, Lightbulb, Smile } from 'lucide-react';

interface WelcomeViewProps {
  onSelectPrompt: (prompt: string) => void;
}

const STARTER_PROMPTS = [
  {
    icon: Lightbulb,
    title: 'Creative project ideas',
    prompt: 'Give me 5 creative weekend project ideas I can build and actually finish.',
  },
  {
    icon: Compass,
    title: 'Explain AI simply',
    prompt: 'Explain how modern AI language models work simply, with a fun everyday analogy.',
  },
  {
    icon: Smile,
    title: 'Make me laugh',
    prompt: 'Tell me a clean, genuinely funny programmer or everyday-life joke.',
  },
  {
    icon: Code2,
    title: 'Hinglish productivity tip',
    prompt: 'Hinglish mein ek mast aur practical productivity tip do jo aaj hi try kar sakein.',
  },
];

export function WelcomeView({ onSelectPrompt }: WelcomeViewProps) {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-[760px] flex-col items-center justify-center px-4 py-10 text-center">
      <div className="grid h-16 w-16 place-items-center rounded-[22px] bg-gradient-to-br from-[#6678ff] to-[#42d8c6] font-display text-2xl font-extrabold tracking-tight text-white shadow-xl shadow-[#6478ff]/25">
        CB
      </div>

      <h1
        className="mt-5 font-display text-3xl font-bold tracking-tight text-slate-950 dark:text-[#edf2ff] sm:text-4xl"
        style={{ textWrap: 'balance' }}
      >
        Hey! I&apos;m CB AI
      </h1>

      <p className="mt-2.5 max-w-md text-[15px] leading-relaxed text-slate-600 dark:text-[#9aa8c0]">
        Your friendly AI buddy by Code Bracker. Ask a question, upload an image for analysis, or chat naturally in English or Hinglish.
      </p>

      <div className="mt-8 grid w-full grid-cols-1 gap-3 text-left sm:grid-cols-2">
        {STARTER_PROMPTS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.title}
              type="button"
              onClick={() => onSelectPrompt(item.prompt)}
              className="group flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-left transition-all duration-150 hover:border-[#6478ff]/50 hover:bg-slate-50 dark:border-[#293449] dark:bg-[#141a27] dark:hover:border-[#6478ff]/60 dark:hover:bg-[#182030]"
            >
              <div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-slate-100 text-[#5367dd] transition-colors group-hover:bg-[#6478ff]/15 dark:bg-[#1b2333] dark:text-[#8ea0ff]">
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <div className="font-display text-sm font-semibold text-slate-900 dark:text-[#edf2ff]">
                  {item.title}
                </div>
                <div className="mt-0.5 line-clamp-2 text-[13px] leading-snug text-slate-500 dark:text-[#9aa8c0]">
                  {item.prompt}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
