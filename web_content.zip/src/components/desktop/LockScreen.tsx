import React, { useState, useEffect } from 'react';
import { Lock, ArrowRight } from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

export const LockScreen: React.FC = () => {
  const { isLockScreenOpen, setLockScreenOpen, customIcon } = useDesktop();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [pin, setPin] = useState('');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isLockScreenOpen) return null;

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    setLockScreenOpen(false);
    setPin('');
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-3xl flex flex-col items-center justify-between p-12 text-white select-none animate-in fade-in duration-200">
      {/* Time & Date */}
      <div className="text-center space-y-1 mt-8">
        <div className="text-6xl font-light tracking-tight">
          {currentTime.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
        </div>
        <div className="text-base text-slate-300 font-medium">
          {currentTime.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}
        </div>
      </div>

      {/* User Login Card */}
      <div className="flex flex-col items-center gap-4 max-w-xs w-full">
        <div className="w-24 h-24 rounded-full bg-slate-800 border-2 border-white/20 overflow-hidden flex items-center justify-center shadow-2xl">
          {customIcon?.dataUrl ? (
            <img src={customIcon.dataUrl} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            <span className="text-3xl font-bold text-sky-400">BP</span>
          )}
        </div>

        <div className="text-center">
          <h2 className="text-lg font-bold text-white">Bird Base / User</h2>
          <span className="text-xs text-sky-400 font-mono">com.birdbase.app</span>
        </div>

        <form onSubmit={handleUnlock} className="w-full flex items-center gap-2">
          <input
            type="password"
            placeholder="Enter PIN (Press Enter)"
            value={pin}
            onChange={e => setPin(e.target.value)}
            className="flex-1 bg-slate-900/90 border border-white/20 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-sky-400 text-center"
            autoFocus
          />
          <button
            type="submit"
            className="p-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl transition-all font-bold"
          >
            <ArrowRight size={16} />
          </button>
        </form>
      </div>

      <div className="text-xs text-slate-500 flex items-center gap-1.5">
        <Lock size={13} /> Secured Bird PC Android Environment
      </div>
    </div>
  );
};
