import React, { useState } from 'react';
import {
  Search,
  ChevronRight,
  Power,
  RotateCw,
  Moon,
  Lock,
  ArrowLeft
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { DESKTOP_APPS } from '../../data/appsList';
import { AppIconDisplay } from './AppIconDisplay';

export const StartMenu: React.FC = () => {
  const {
    isStartMenuOpen,
    closeStartMenu,
    openApp,
    customIcon,
    setLockScreenOpen
  } = useDesktop();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewAllApps, setViewAllApps] = useState(false);
  const [showPowerMenu, setShowPowerMenu] = useState(false);

  if (!isStartMenuOpen) return null;

  // Filter apps by search
  const filteredApps = DESKTOP_APPS.filter(app =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pinned items for the default view
  const pinnedApps = DESKTOP_APPS.filter(a => a.pinnedToStart !== false);

  // Recommended recent items
  const recommendedItems = [
    { id: 'project-exporter', title: 'com.birdbase.app Gradle Project', desc: 'Ready for export' },
    { id: 'app-icon-studio', title: 'Custom Launcher Mipmaps', desc: '48px to 192px adaptive' },
    { id: 'bird-ai', title: 'Bird AI Studio Copilot', desc: 'Gemini reasoning enabled' },
    { id: 'feature-checklist', title: '100+ Features Audit Suite', desc: 'Checked & verified' }
  ];

  return (
    <>
      {/* Backdrop to dismiss on outside click */}
      <div
        className="fixed inset-0 z-40"
        onClick={closeStartMenu}
      />

      {/* Start Menu Floating Panel */}
      <div
        className="fixed bottom-14 left-1/2 -translate-x-1/2 w-[92vw] max-w-[620px] max-h-[82vh] bg-slate-900/90 backdrop-blur-3xl border border-white/15 rounded-2xl shadow-2xl z-50 text-white flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Bar */}
        <div className="p-5 pb-3">
          <div className="relative flex items-center bg-slate-800/80 rounded-full border border-white/10 px-4 py-2.5 focus-within:border-sky-500/80 focus-within:ring-2 focus-within:ring-sky-500/20 transition-all">
            <Search size={18} className="text-slate-400 mr-3 shrink-0" />
            <input
              type="text"
              placeholder="Search apps, settings, and documents..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full text-slate-100 placeholder:text-slate-400"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-white px-1"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto px-6 py-2 custom-scrollbar">
          {searchQuery ? (
            /* Search Results */
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                Search Results ({filteredApps.length})
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {filteredApps.map(app => (
                  <button
                    key={app.id}
                    onClick={() => {
                      openApp(app.id);
                      closeStartMenu();
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/10 transition-colors text-left group"
                  >
                    <div className="p-2 rounded-lg bg-slate-800 text-sky-400 group-hover:scale-105 transition-transform">
                      <AppIconDisplay appId={app.id} iconName={app.icon} size={22} />
                    </div>
                    <div className="overflow-hidden">
                      <div className="text-sm font-medium text-slate-100 truncate">{app.name}</div>
                      <div className="text-xs text-slate-400 truncate">{app.description}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : viewAllApps ? (
            /* All Apps Alphabetical List */
            <div>
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={() => setViewAllApps(false)}
                  className="flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-medium"
                >
                  <ArrowLeft size={14} /> Back to Pinned
                </button>
                <span className="text-xs text-slate-400">{DESKTOP_APPS.length} Apps</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[...DESKTOP_APPS]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map(app => (
                    <button
                      key={app.id}
                      onClick={() => {
                        openApp(app.id);
                        closeStartMenu();
                      }}
                      className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/10 transition-colors text-left"
                    >
                      <div className="p-2 rounded-lg bg-slate-800 text-sky-400">
                        <AppIconDisplay appId={app.id} iconName={app.icon} size={20} />
                      </div>
                      <div className="overflow-hidden">
                        <div className="text-sm font-medium text-slate-100 truncate">{app.name}</div>
                        <div className="text-xs text-slate-400 truncate">{app.category}</div>
                      </div>
                    </button>
                  ))}
              </div>
            </div>
          ) : (
            /* Standard Windows 11 Pinned & Recommended */
            <div className="space-y-6">
              {/* Pinned Header */}
              <div>
                <div className="flex items-center justify-between mb-3 px-1">
                  <span className="text-sm font-semibold text-slate-200">Pinned</span>
                  <button
                    onClick={() => setViewAllApps(true)}
                    className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 px-2 py-1 rounded hover:bg-white/5 transition-colors font-medium"
                  >
                    All apps <ChevronRight size={14} />
                  </button>
                </div>

                {/* Pinned 6-column Grid */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 text-center">
                  {pinnedApps.slice(0, 18).map(app => (
                    <button
                      key={app.id}
                      onClick={() => {
                        openApp(app.id);
                        closeStartMenu();
                      }}
                      className="flex flex-col items-center p-2 rounded-xl hover:bg-white/10 active:scale-95 transition-all group"
                      title={app.description}
                    >
                      <div className="w-12 h-12 rounded-xl bg-slate-800/80 flex items-center justify-center text-sky-400 mb-1.5 shadow-sm group-hover:scale-105 transition-transform">
                        <AppIconDisplay appId={app.id} iconName={app.icon} size={24} />
                      </div>
                      <span className="text-[12px] font-medium text-slate-200 truncate w-full group-hover:text-white">
                        {app.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Recommended Section */}
              <div className="border-t border-white/10 pt-4">
                <span className="text-sm font-semibold text-slate-200 mb-3 block px-1">
                  Recommended
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {recommendedItems.map(item => {
                    const app = DESKTOP_APPS.find(a => a.id === item.id);
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          openApp(item.id);
                          closeStartMenu();
                        }}
                        className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/10 transition-colors text-left"
                      >
                        <div className="p-2 rounded-lg bg-slate-800 text-sky-400">
                          <AppIconDisplay appId={item.id} iconName={app?.icon || 'FileText'} size={18} />
                        </div>
                        <div className="overflow-hidden">
                          <div className="text-xs font-medium text-slate-100 truncate">{item.title}</div>
                          <div className="text-[11px] text-slate-400 truncate">{item.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer User Profile & Power Controls */}
        <div className="bg-slate-950/60 border-t border-white/10 px-6 py-3.5 flex items-center justify-between relative">
          {/* User Account */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center overflow-hidden">
              {customIcon?.dataUrl ? (
                <img
                  src={customIcon.dataUrl}
                  alt="Bird Avatar"
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-sm font-bold text-sky-400">BP</span>
              )}
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-100">Bird Base / User</div>
              <div className="text-[11px] text-slate-400">com.birdbase.app</div>
            </div>
          </div>

          {/* Power Button */}
          <div className="relative">
            <button
              onClick={() => setShowPowerMenu(!showPowerMenu)}
              className="p-2 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title="Power Options"
            >
              <Power size={18} />
            </button>

            {/* Power Menu Popover */}
            {showPowerMenu && (
              <div className="absolute right-0 bottom-full mb-2 w-44 bg-slate-800/95 backdrop-blur-xl border border-white/15 rounded-xl shadow-2xl py-1 z-50 text-xs">
                <button
                  onClick={() => {
                    setLockScreenOpen(true);
                    closeStartMenu();
                    setShowPowerMenu(false);
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2 hover:bg-white/10 text-slate-200 text-left"
                >
                  <Lock size={14} /> Lock Bird PC
                </button>
                <button
                  onClick={() => {
                    closeStartMenu();
                    setShowPowerMenu(false);
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2 hover:bg-white/10 text-slate-200 text-left"
                >
                  <Moon size={14} /> Sleep
                </button>
                <button
                  onClick={() => {
                    window.location.reload();
                  }}
                  className="w-full px-3 py-2 flex items-center gap-2 hover:bg-white/10 text-slate-200 text-left"
                >
                  <RotateCw size={14} /> Restart Desktop
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
