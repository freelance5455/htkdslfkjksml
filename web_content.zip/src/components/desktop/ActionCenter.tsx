import React from 'react';
import {
  Wifi,
  Bluetooth,
  Plane,
  Moon,
  BatteryCharging,
  Sun,
  Volume2,
  VolumeX,
  Sliders,
  Trash2,
  X
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

export const ActionCenter: React.FC = () => {
  const {
    isActionCenterOpen,
    closeActionCenter,
    notifications,
    removeNotification,
    clearNotifications,
    volume,
    setVolume,
    brightness,
    setBrightness,
    quickSettings,
    toggleQuickSetting
  } = useDesktop();

  if (!isActionCenterOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40" onClick={closeActionCenter} />

      {/* Action Center Flyout */}
      <div
        className="fixed bottom-14 right-3 w-[92vw] max-w-[380px] bg-slate-900/90 backdrop-blur-3xl border border-white/15 rounded-2xl shadow-2xl z-50 text-white p-5 flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-5 duration-150 select-none"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <span className="text-sm font-semibold text-slate-200">Quick Settings & Notifications</span>
          <button
            onClick={closeActionCenter}
            className="p-1 rounded-md hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X size={16} />
          </button>
        </div>

        {/* Quick Settings Grid (6 Tiles) */}
        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={() => toggleQuickSetting('wifi')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.wifi
                ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Wifi size={18} />
            <span className="text-[11px] font-medium">Wi-Fi</span>
          </button>

          <button
            onClick={() => toggleQuickSetting('bluetooth')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.bluetooth
                ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Bluetooth size={18} />
            <span className="text-[11px] font-medium">Bluetooth</span>
          </button>

          <button
            onClick={() => toggleQuickSetting('airplaneMode')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.airplaneMode
                ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Plane size={18} />
            <span className="text-[11px] font-medium">Airplane</span>
          </button>

          <button
            onClick={() => toggleQuickSetting('batterySaver')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.batterySaver
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <BatteryCharging size={18} />
            <span className="text-[11px] font-medium">Saver</span>
          </button>

          <button
            onClick={() => toggleQuickSetting('nightLight')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.nightLight
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Moon size={18} />
            <span className="text-[11px] font-medium">Night light</span>
          </button>

          <button
            onClick={() => toggleQuickSetting('focusMode')}
            className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all ${
              quickSettings.focusMode
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Sliders size={18} />
            <span className="text-[11px] font-medium">Focus</span>
          </button>
        </div>

        {/* Sliders: Brightness and Volume */}
        <div className="space-y-3 bg-slate-800/40 p-3 rounded-xl border border-white/5">
          {/* Brightness */}
          <div className="flex items-center gap-3">
            <Sun size={16} className="text-amber-400 shrink-0" />
            <input
              type="range"
              min={10}
              max={100}
              value={brightness}
              onChange={e => setBrightness(Number(e.target.value))}
              className="w-full accent-sky-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
            />
            <span className="text-xs text-slate-400 w-8 text-right">{brightness}%</span>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3">
            {volume === 0 ? (
              <VolumeX size={16} className="text-rose-400 shrink-0" />
            ) : (
              <Volume2 size={16} className="text-sky-400 shrink-0" />
            )}
            <input
              type="range"
              min={0}
              max={100}
              value={volume}
              onChange={e => setVolume(Number(e.target.value))}
              className="w-full accent-sky-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
            />
            <span className="text-xs text-slate-400 w-8 text-right">{volume}%</span>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="pt-2 border-t border-white/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Notifications ({notifications.length})
            </span>
            {notifications.length > 0 && (
              <button
                onClick={clearNotifications}
                className="text-[11px] text-sky-400 hover:text-sky-300 flex items-center gap-1"
              >
                <Trash2 size={12} /> Clear all
              </button>
            )}
          </div>

          <div className="max-h-40 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            {notifications.length === 0 ? (
              <div className="text-center py-4 text-xs text-slate-400">
                No new notifications
              </div>
            ) : (
              notifications.map(notif => (
                <div
                  key={notif.id}
                  className="p-2.5 rounded-xl bg-slate-800/80 border border-white/5 flex items-start justify-between gap-2"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-200">{notif.title}</div>
                    <div className="text-[11px] text-slate-400 leading-snug">{notif.message}</div>
                    <span className="text-[9px] text-slate-500 mt-0.5 block">{notif.time}</span>
                  </div>
                  <button
                    onClick={() => removeNotification(notif.id)}
                    className="text-slate-500 hover:text-white p-0.5"
                  >
                    <X size={13} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  );
};
