import React, { useState, useEffect } from 'react';
import {
  Search,
  Wifi,
  Volume2,
  VolumeX,
  Battery,
  BatteryCharging,
  Bell,
  ChevronUp,
  LayoutGrid
} from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';
import { DESKTOP_APPS } from '../../data/appsList';
import { AppIconDisplay } from './AppIconDisplay';

export const Taskbar: React.FC = () => {
  const {
    openWindows,
    activeWindowId,
    openApp,
    bringToFront,
    minimizeWindow,
    restoreWindow,
    isStartMenuOpen,
    toggleStartMenu,
    isActionCenterOpen,
    toggleActionCenter,
    minimizeAll,
    taskbarAlignment,
    volume,
    quickSettings,
    notifications,
    customIcon
  } = useDesktop();

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: 'numeric' });
  };

  // Pinned apps to show in taskbar
  const pinnedAppIds = [
    'project-exporter',
    'app-icon-studio',
    'file-explorer',
    'bird-browser',
    'bird-ai',
    'terminal',
    'app-store',
    'settings'
  ];

  // Open windows apps that are not pinned
  const unpinnedOpenAppIds = Array.from(
    new Set(
      openWindows
        .map(w => w.appId)
        .filter(appId => !pinnedAppIds.includes(appId))
    )
  );

  const displayAppIds = [...pinnedAppIds, ...unpinnedOpenAppIds];

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="fixed bottom-0 left-0 right-0 h-12 bg-slate-900/80 backdrop-blur-2xl border-t border-white/10 z-50 flex items-center justify-between px-3 select-none text-white transition-all duration-200">
      
      {/* Left side (Widgets / Weather or empty when centered) */}
      <div className="flex items-center min-w-[140px]">
        {taskbarAlignment === 'left' ? null : (
          <button
            onClick={() => openApp('weather')}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-white/10 transition-colors text-xs text-slate-300"
            title="Weather & Widgets"
          >
            <span className="text-base">⛅</span>
            <div className="hidden sm:flex flex-col text-left text-[11px] leading-tight">
              <span className="font-medium text-slate-200">72°F Sunny</span>
              <span className="text-slate-400">Bird Base</span>
            </div>
          </button>
        )}
      </div>

      {/* Centered or Left-aligned App Launchers */}
      <div
        className={`flex items-center gap-1.5 h-full ${
          taskbarAlignment === 'center' ? 'absolute left-1/2 -translate-x-1/2' : ''
        }`}
      >
        {/* Windows 11 Start Button */}
        <button
          onClick={toggleStartMenu}
          className={`relative p-2 rounded-md transition-all duration-150 flex items-center justify-center ${
            isStartMenuOpen
              ? 'bg-sky-500/20 shadow-inner'
              : 'hover:bg-white/10 active:scale-95'
          }`}
          title="Start"
        >
          {customIcon?.dataUrl ? (
            <img
              src={customIcon.dataUrl}
              alt="Start"
              className="w-6 h-6 object-contain rounded"
            />
          ) : (
            <svg
              className="w-6 h-6 text-sky-400"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z" />
            </svg>
          )}
        </button>

        {/* Quick Search Button */}
        <button
          onClick={() => openApp('bird-ai')}
          className="p-2 rounded-md hover:bg-white/10 active:scale-95 transition-all text-slate-300 hover:text-white"
          title="Search or Ask Bird AI"
        >
          <Search size={18} />
        </button>

        {/* Task View / Feature Checklist Button */}
        <button
          onClick={() => openApp('feature-checklist')}
          className="p-2 rounded-md hover:bg-white/10 active:scale-95 transition-all text-slate-300 hover:text-white hidden sm:flex"
          title="Task View & 100+ Features Audit"
        >
          <LayoutGrid size={18} />
        </button>

        {/* App Icons List */}
        {displayAppIds.map(appId => {
          const appDef = DESKTOP_APPS.find(a => a.id === appId);
          if (!appDef) return null;

          const openInstance = openWindows.find(w => w.appId === appId);
          const isOpen = !!openInstance;
          const isActive = openInstance && openInstance.id === activeWindowId && openInstance.state !== 'minimized';

          const handleClick = () => {
            if (!openInstance) {
              openApp(appId);
            } else if (isActive) {
              minimizeWindow(openInstance.id);
            } else if (openInstance.state === 'minimized') {
              restoreWindow(openInstance.id);
            } else {
              bringToFront(openInstance.id);
            }
          };

          return (
            <button
              key={appId}
              onClick={handleClick}
              className={`relative px-2.5 py-1.5 h-10 rounded-md transition-all duration-150 flex items-center justify-center group ${
                isActive
                  ? 'bg-white/15'
                  : isOpen
                  ? 'bg-white/5 hover:bg-white/10'
                  : 'hover:bg-white/10'
              } active:scale-95`}
              title={appDef.name}
            >
              <div className="w-6 h-6 flex items-center justify-center transition-transform group-hover:-translate-y-0.5">
                <AppIconDisplay
                  appId={appDef.id}
                  iconName={appDef.icon}
                  size={20}
                  className={
                    appDef.id === 'project-exporter'
                      ? 'text-emerald-400'
                      : appDef.id === 'app-icon-studio'
                      ? 'text-amber-400'
                      : appDef.id === 'file-explorer'
                      ? 'text-yellow-400'
                      : appDef.id === 'bird-browser'
                      ? 'text-sky-400'
                      : appDef.id === 'bird-ai'
                      ? 'text-indigo-400'
                      : 'text-slate-200'
                  }
                />
              </div>

              {/* Running / Active indicator underline */}
              {isOpen && (
                <span
                  className={`absolute bottom-0.5 left-1/2 -translate-x-1/2 h-[3px] rounded-full transition-all duration-200 ${
                    isActive
                      ? 'w-4 bg-sky-400 shadow-sm shadow-sky-400/50'
                      : 'w-1.5 bg-slate-400'
                  }`}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Right side System Tray & Notification Center */}
      <div className="flex items-center gap-1 text-slate-300">
        <button
          onClick={() => openApp('device-info')}
          className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white hidden sm:block"
          title="Hardware & Sensors"
        >
          <ChevronUp size={14} />
        </button>

        {/* Quick Settings Group (Wi-Fi, Volume, Battery) */}
        <button
          onClick={toggleActionCenter}
          className={`flex items-center gap-2 px-2 py-1 rounded-md transition-colors ${
            isActionCenterOpen ? 'bg-white/15 text-white' : 'hover:bg-white/10'
          }`}
          title="Network, Sound, Battery & Action Center"
        >
          <Wifi size={15} className={quickSettings.wifi ? 'text-sky-400' : 'text-slate-500'} />
          {volume === 0 ? <VolumeX size={15} className="text-rose-400" /> : <Volume2 size={15} />}
          <div className="flex items-center gap-1">
            {quickSettings.batterySaver ? (
              <BatteryCharging size={15} className="text-emerald-400" />
            ) : (
              <Battery size={15} className="text-slate-200" />
            )}
          </div>
        </button>

        {/* Date and Time */}
        <button
          onClick={() => openApp('calendar-clock')}
          className="flex flex-col items-end px-2 py-0.5 rounded-md hover:bg-white/10 transition-colors text-right"
          title="Calendar & Time"
        >
          <span className="text-[12px] font-medium leading-tight text-slate-100">
            {formatTime(currentTime)}
          </span>
          <span className="text-[11px] leading-tight text-slate-400">
            {formatDate(currentTime)}
          </span>
        </button>

        {/* Notifications Icon */}
        <button
          onClick={toggleActionCenter}
          className="relative p-2 rounded-md hover:bg-white/10 transition-colors text-slate-300 hover:text-white"
          title="Notifications"
        >
          <Bell size={16} />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-sky-400 ring-2 ring-slate-900" />
          )}
        </button>

        {/* Show Desktop Peek Strip */}
        <button
          onClick={minimizeAll}
          className="w-1.5 h-8 ml-1 rounded-sm hover:bg-sky-400/40 transition-colors border-l border-white/10"
          title="Show Desktop (Minimize All)"
        />
      </div>
    </div>
  );
};
