import React from 'react';
import * as Icons from 'lucide-react';
import { useDesktop } from '../../context/DesktopContext';

interface AppIconDisplayProps {
  appId?: string;
  iconName: string;
  className?: string;
  size?: number;
}

export const AppIconDisplay: React.FC<AppIconDisplayProps> = ({
  appId,
  iconName,
  className = '',
  size = 24
}) => {
  const { customIcon } = useDesktop();

  // If this is the App Icon Studio or Bird PC system icon, show custom mascot icon
  if ((appId === 'app-icon-studio' || appId === 'system-bird') && customIcon?.dataUrl) {
    return (
      <img
        src={customIcon.dataUrl}
        alt="Bird PC Icon"
        className={`object-contain rounded-lg ${className}`}
        style={{ width: size, height: size }}
      />
    );
  }

  // Fallback to Lucide icon
  const IconComponent = (Icons as Record<string, any>)[iconName] || Icons.AppWindow;
  return <IconComponent size={size} className={className} />;
};
