import React, { useState, useRef, useEffect } from 'react';
import {
  Minus,
  Square,
  Copy,
  X
} from 'lucide-react';
import { AppWindow, WindowPosition, WindowSize } from '../../types/desktop';
import { useDesktop } from '../../context/DesktopContext';
import { AppIconDisplay } from './AppIconDisplay';
import { WindowContentRouter } from './WindowContentRouter';

interface WindowFrameProps {
  window: AppWindow;
}

export const WindowFrame: React.FC<WindowFrameProps> = ({ window: win }) => {
  const {
    activeWindowId,
    bringToFront,
    closeWindow,
    minimizeWindow,
    maximizeWindow,
    restoreWindow,
    updateWindowPosition,
    updateWindowSize
  } = useDesktop();

  const isActive = activeWindowId === win.id;
  const isMaximized = win.state === 'maximized';

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [initialPos, setInitialPos] = useState<WindowPosition>({ x: 0, y: 0 });

  const [isResizing, setIsResizing] = useState(false);
  const [resizeStart, setResizeStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [initialSize, setInitialSize] = useState<WindowSize>({ width: 0, height: 0 });

  // Handle Dragging
  const handleMouseDownHeader = (e: React.MouseEvent) => {
    if (isMaximized) return;
    bringToFront(win.id);
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
    setInitialPos({ ...win.position });
  };

  const handleTouchStartHeader = (e: React.TouchEvent) => {
    if (isMaximized) return;
    bringToFront(win.id);
    const touch = e.touches[0];
    setIsDragging(true);
    setDragStart({ x: touch.clientX, y: touch.clientY });
    setInitialPos({ ...win.position });
  };

  // Handle Resizing
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.stopPropagation();
    bringToFront(win.id);
    setIsResizing(true);
    setResizeStart({ x: e.clientX, y: e.clientY });
    setInitialSize({ ...win.size });
  };

  const handleTouchStartResize = (e: React.TouchEvent) => {
    e.stopPropagation();
    bringToFront(win.id);
    const touch = e.touches[0];
    setIsResizing(true);
    setResizeStart({ x: touch.clientX, y: touch.clientY });
    setInitialSize({ ...win.size });
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const dx = e.clientX - dragStart.x;
        const dy = e.clientY - dragStart.y;
        updateWindowPosition(win.id, {
          x: Math.max(0, Math.min(window.innerWidth - 100, initialPos.x + dx)),
          y: Math.max(0, Math.min(window.innerHeight - 80, initialPos.y + dy))
        });
      }

      if (isResizing) {
        const dx = e.clientX - resizeStart.x;
        const dy = e.clientY - resizeStart.y;
        updateWindowSize(win.id, {
          width: Math.max(win.minWidth || 380, initialSize.width + dx),
          height: Math.max(win.minHeight || 280, initialSize.height + dy)
        });
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      const touch = e.touches[0];
      if (isDragging) {
        const dx = touch.clientX - dragStart.x;
        const dy = touch.clientY - dragStart.y;
        updateWindowPosition(win.id, {
          x: Math.max(0, Math.min(window.innerWidth - 100, initialPos.x + dx)),
          y: Math.max(0, Math.min(window.innerHeight - 80, initialPos.y + dy))
        });
      }

      if (isResizing) {
        const dx = touch.clientX - resizeStart.x;
        const dy = touch.clientY - resizeStart.y;
        updateWindowSize(win.id, {
          width: Math.max(win.minWidth || 380, initialSize.width + dx),
          height: Math.max(win.minHeight || 280, initialSize.height + dy)
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDragging, isResizing, dragStart, initialPos, resizeStart, initialSize, win.id]);

  if (win.state === 'minimized') {
    return null;
  }

  const windowStyle: React.CSSProperties = isMaximized
    ? {
        top: 0,
        left: 0,
        width: '100vw',
        height: 'calc(100vh - 48px)',
        zIndex: win.zIndex
      }
    : {
        top: `${win.position.y}px`,
        left: `${win.position.x}px`,
        width: `${win.size.width}px`,
        height: `${win.size.height}px`,
        zIndex: win.zIndex
      };

  return (
    <div
      style={windowStyle}
      onClick={() => bringToFront(win.id)}
      className={`fixed rounded-xl overflow-hidden flex flex-col backdrop-blur-2xl transition-shadow duration-150 border select-none ${
        isActive
          ? 'shadow-2xl shadow-black/80 border-sky-500/40 ring-1 ring-sky-500/20'
          : 'shadow-xl shadow-black/50 border-white/10 opacity-95'
      } ${isMaximized ? 'rounded-none' : ''}`}
    >
      {/* Title Bar */}
      <div
        onMouseDown={handleMouseDownHeader}
        onTouchStart={handleTouchStartHeader}
        onDoubleClick={() => (isMaximized ? restoreWindow(win.id) : maximizeWindow(win.id))}
        className={`h-9 px-3 flex items-center justify-between text-xs cursor-default select-none border-b transition-colors ${
          isActive
            ? 'bg-slate-900/95 border-white/10 text-slate-100'
            : 'bg-slate-950/90 border-white/5 text-slate-400'
        }`}
      >
        {/* App Icon & Title */}
        <div className="flex items-center gap-2 truncate pointer-events-none">
          <AppIconDisplay appId={win.appId} iconName={win.icon} size={15} />
          <span className="font-semibold truncate">{win.title}</span>
        </div>

        {/* Window Controls (Minimize, Maximize, Close) */}
        <div className="flex items-center">
          <button
            onClick={e => {
              e.stopPropagation();
              minimizeWindow(win.id);
            }}
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Minimize"
          >
            <Minus size={13} />
          </button>

          <button
            onClick={e => {
              e.stopPropagation();
              if (isMaximized) {
                restoreWindow(win.id);
              } else {
                maximizeWindow(win.id);
              }
            }}
            className="w-10 h-9 hover:bg-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title={isMaximized ? 'Restore' : 'Maximize'}
          >
            {isMaximized ? <Copy size={11} /> : <Square size={11} />}
          </button>

          <button
            onClick={e => {
              e.stopPropagation();
              closeWindow(win.id);
            }}
            className="w-10 h-9 hover:bg-rose-600 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Close"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Window Body Router */}
      <div className="flex-1 bg-slate-900 overflow-hidden relative">
        <WindowContentRouter appId={win.appId} />
      </div>

      {/* Resize Handle (Bottom-Right) */}
      {!isMaximized && (
        <div
          onMouseDown={handleMouseDownResize}
          onTouchStart={handleTouchStartResize}
          className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize z-50 flex items-center justify-center opacity-40 hover:opacity-100"
        >
          <div className="w-1.5 h-1.5 bg-white/60 rounded-br-sm" />
        </div>
      )}
    </div>
  );
};
