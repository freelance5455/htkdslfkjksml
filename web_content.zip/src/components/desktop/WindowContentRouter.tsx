import React from 'react';
import { AppIconStudio } from '../apps/AppIconStudio';
import { ProjectExporter } from '../apps/ProjectExporter';
import { FileExplorer } from '../apps/FileExplorer';
import { BirdBrowser } from '../apps/BirdBrowser';
import { BirdAIAssistant } from '../apps/BirdAIAssistant';
import { ImageVideoStudio } from '../apps/ImageVideoStudio';
import { TaskManager } from '../apps/TaskManager';
import { SystemSettings } from '../apps/SystemSettings';
import { Notepad } from '../apps/Notepad';
import { Terminal } from '../apps/Terminal';
import { FeatureChecklist } from '../apps/FeatureChecklist';
import { ApkVsZipExplainer } from '../apps/ApkVsZipExplainer';
import {
  BirdAppStore,
  Calculator,
  CalendarClock,
  PaintApp,
  GameCenter,
  DeviceInformation,
  VirtualMachineManager,
  GitHubActionsCiApp
} from '../apps/UtilitiesPack';

interface WindowContentRouterProps {
  appId: string;
}

export const WindowContentRouter: React.FC<WindowContentRouterProps> = ({ appId }) => {
  switch (appId) {
    case 'app-icon-studio':
      return <AppIconStudio />;
    case 'project-exporter':
      return <ProjectExporter />;
    case 'file-explorer':
      return <FileExplorer />;
    case 'bird-browser':
      return <BirdBrowser />;
    case 'bird-ai':
      return <BirdAIAssistant />;
    case 'image-studio':
      return <ImageVideoStudio />;
    case 'terminal':
      return <Terminal />;
    case 'task-manager':
      return <TaskManager />;
    case 'settings':
      return <SystemSettings />;
    case 'notepad':
      return <Notepad />;
    case 'app-store':
      return <BirdAppStore />;
    case 'calculator':
      return <Calculator />;
    case 'calendar-clock':
      return <CalendarClock />;
    case 'feature-checklist':
      return <FeatureChecklist />;
    case 'apk-vs-zip':
      return <ApkVsZipExplainer />;
    case 'paint-canvas':
      return <PaintApp />;
    case 'game-center':
      return <GameCenter />;
    case 'device-info':
    case 'battery-monitor':
    case 'network-monitor':
      return <DeviceInformation />;
    case 'vm-manager':
      return <VirtualMachineManager />;
    case 'github-ci-helper':
      return <GitHubActionsCiApp />;
    case 'weather':
    case 'downloads-mgr':
    case 'archive-mgr':
    case 'snipping-tool':
    case 'clipboard-mgr':
    case 'sticky-notes':
    case 'security-center':
    case 'sound-recorder':
    case 'media-viewer':
    case 'music-player':
    default:
      // Fallback clean view
      return <FeatureChecklist />;
  }
};
