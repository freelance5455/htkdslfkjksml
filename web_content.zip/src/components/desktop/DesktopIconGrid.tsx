import React, { useState } from 'react';
import { useDesktop } from '../../context/DesktopContext';
import { DESKTOP_APPS } from '../../data/appsList';
import { AppIconDisplay } from './AppIconDisplay';
import {
  RotateCw,
  FolderPlus,
  FilePlus,
  Palette,
  Info,
  Maximize2
} from 'lucide-react';

export const DesktopIconGrid: React.FC = () => {
  const { openApp, addNotification } = useDesktop();
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null);

  // Desktop primary shortcuts
  const desktopShortcutIds = [
    'project-exporter',
    'app-icon-studio',
    'file-explorer',
    'bird-browser',
    'bird-ai',
    'image-studio',
    'terminal',
    'task-manager',
    'settings',
    'notepad',
    'app-store',
    'feature-checklist',
    'apk-vs-zip'
  ];

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({
      x: Math.min(e.clientX, window.innerWidth - 200),
      y: Math.min(e.clientY, window.innerHeight - 240)
    });
  };

  const closeContextMenu = () => setContextMenu(null);

  return (
    <div
      className="absolute inset-0 p-4 pb-14 z-0 overflow-hidden"
      onClick={() => {
        setSelectedAppId(null);
        closeContextMenu();
      }}
      onContextMenu={handleContextMenu}
    >
      {/* Desktop Icons Grid (Vertical flow like Windows) */}
      <div className="flex flex-col flex-wrap gap-2 h-full max-w-fit items-start content-start">
        {desktopShortcutIds.map(appId => {
          const appDef = DESKTOP_APPS.find(a => a.id === appId);
          if (!appDef) return null;

          const isSelected = selectedAppId === appId;

          return (
            <button
              key={appId}
              onClick={e => {
                e.stopPropagation();
                setSelectedAppId(appId);
              }}
              onDoubleClick={() => openApp(appId)}
              className={`w-20 p-2 rounded-xl flex flex-col items-center text-center gap-1.5 transition-all select-none border ${
                isSelected
                  ? 'bg-sky-500/25 border-sky-400/50 shadow-md ring-1 ring-sky-400/40'
                  : 'border-transparent hover:bg-white/10 hover:border-white/10'
              }`}
              title={appDef.description}
            >
              <div className="w-12 h-12 rounded-xl bg-slate-900/60 backdrop-blur-md flex items-center justify-center shadow-lg border border-white/10 transition-transform group-hover:scale-105">
                <AppIconDisplay
                  appId={appDef.id}
                  iconName={appDef.icon}
                  size={26}
                  className={
                    appDef.id === 'project-exporter'
                      ? 'text-emerald-400'
                      : appDef.id === 'app-icon-studio'
                      ? 'text-amber-400'
                      : appDef.id === 'bird-ai'
                      ? 'text-indigo-400'
                      : appDef.id === 'file-explorer'
                      ? 'text-yellow-400'
                      : 'text-sky-400'
                  }
                />
              </div>

              <span className="text-[11px] font-medium text-slate-100 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] leading-tight line-clamp-2 px-1">
                {appDef.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Windows 11 Desktop Context Menu */}
      {contextMenu && (
        <div
          style={{ top: contextMenu.y, left: contextMenu.x }}
          className="fixed w-52 bg-slate-900/95 backdrop-blur-2xl border border-white/15 rounded-xl shadow-2xl py-1.5 z-50 text-xs text-slate-200 select-none animate-in fade-in duration-100"
          onClick={e => e.stopPropagation()}
        >
          <button
            onClick={() => {
              addNotification({ title: 'Desktop Refreshed', message: 'Desktop state refreshed.', type: 'info' });
              closeContextMenu();
            }}
            className="w-full px-3.5 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors"
          >
            <RotateCw size={14} /> Refresh
          </button>

          <div className="my-1 border-t border-white/10" />

          <button
            onClick={() => {
              openApp('file-explorer');
              closeContextMenu();
            }}
            className="w-full px-3.5 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors"
          >
            <FolderPlus size={14} /> New Folder
          </button>

          <button
            onClick={() => {
              openApp('notepad');
              closeContextMenu();
            }}
            className="w-full px-3.5 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors"
          >
            <FilePlus size={14} /> New Text Document
          </button>

          <div className="my-1 border-t border-white/10" />

          <button
            onClick={() => {
              openApp('settings');
              closeContextMenu();
            }}
            className="w-full px-3.5 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors"
          >
            <Palette size={14} /> Personalize & Wallpaper
          </button>

          <button
            onClick={() => {
              openApp('feature-checklist');
              closeContextMenu();
            }}
            className="w-full px-3.5 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors"
          >
            <Info size={14} /> 100+ Features Audit
          </button>
        </div>
      )}
    </div>
  );
};
