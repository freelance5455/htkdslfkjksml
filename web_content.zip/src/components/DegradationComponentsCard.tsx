import React, { useState } from 'react';
import {
  AlertOctagon,
  BatteryWarning,
  Smartphone,
  HardDrive,
  Zap,
  Camera,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  Flame,
  CheckCircle2,
} from 'lucide-react';
import { ComponentThermalStatus } from '../utils/thermal';

interface DegradationComponentsCardProps {
  components: ComponentThermalStatus[];
  batteryTemp: number;
}

export const DegradationComponentsCard: React.FC<
  DegradationComponentsCardProps
> = ({ components, batteryTemp }) => {
  const [expandedId, setExpandedId] = useState<string | null>(
    batteryTemp >= 37 ? 'battery_chemistry' : null
  );

  const getIcon = (id: string) => {
    switch (id) {
      case 'battery_chemistry':
        return <BatteryWarning className="w-5 h-5 text-amber-400" />;
      case 'amoled_display':
        return <Smartphone className="w-5 h-5 text-indigo-400" />;
      case 'ufs_storage':
        return <HardDrive className="w-5 h-5 text-teal-400" />;
      case 'pmic_charging':
        return <Zap className="w-5 h-5 text-yellow-400" />;
      case 'camera_sensor':
        return <Camera className="w-5 h-5 text-rose-400" />;
      default:
        return <ShieldAlert className="w-5 h-5 text-neutral-400" />;
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="rounded-2xl bg-neutral-950 border border-neutral-800 p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/80 pb-3">
        <div>
          <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-amber-500" />
            Componenti a Rischio Degrado Termico
          </h2>
          <p className="text-xs text-neutral-400">
            Cosa si rovina irrimediabilmente quando il telefono scalda oltre i 37°C - 39°C
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400">
            5 componenti monitorati
          </span>
        </div>
      </div>

      <div className="space-y-2.5">
        {components.map((comp) => {
          const isExpanded = expandedId === comp.id;
          const isDanger = comp.status === 'critical';
          const isWarm = comp.status === 'warm';

          return (
            <div
              key={comp.id}
              className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                isDanger
                  ? 'bg-red-950/20 border-red-800/80'
                  : isWarm
                  ? 'bg-amber-950/15 border-amber-800/60'
                  : 'bg-neutral-900/40 border-neutral-800/70'
              }`}
            >
              {/* Riga Intestazione Componente */}
              <button
                type="button"
                onClick={() => toggleExpand(comp.id)}
                className="w-full px-3.5 py-3 flex items-start sm:items-center justify-between gap-2.5 text-left cursor-pointer hover:bg-neutral-900/60 transition"
              >
                <div className="flex items-start sm:items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 shrink-0 mt-0.5 sm:mt-0">
                    {getIcon(comp.id)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-xs sm:text-sm font-semibold text-neutral-200">
                        {comp.name}
                      </span>
                      {isDanger ? (
                        <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-red-900 text-red-200 flex items-center gap-1 shrink-0">
                          <Flame className="w-2.5 h-2.5" /> Degrado
                        </span>
                      ) : isWarm ? (
                        <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-900/80 text-amber-200 shrink-0">
                          Rischio
                        </span>
                      ) : (
                        <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-emerald-400 flex items-center gap-0.5 shrink-0">
                          <CheckCircle2 className="w-2.5 h-2.5" /> OK
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5 line-clamp-1">
                      {comp.riskDescription}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3 shrink-0 pt-0.5 sm:pt-0">
                  <div className="text-right">
                    <div className="text-sm sm:text-base font-mono font-bold text-neutral-100">
                      {comp.temp.toFixed(1)}°C
                    </div>
                    <span className="text-[9px] text-neutral-500 font-mono block">
                      Max {comp.safeMax}°C
                    </span>
                  </div>
                  <div className="text-neutral-500">
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </div>
                </div>
              </button>

              {/* Dettagli Espansi sul Degrado Fisico/Elettrochimico */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-neutral-800/60 bg-neutral-950/70 text-xs space-y-2">
                  <p className="font-medium text-neutral-300">
                    Come e perché si usura con le alte temperature:
                  </p>
                  <ul className="space-y-1.5 list-disc list-inside text-neutral-400 pl-1">
                    {comp.degradationEffects.map((effect, idx) => (
                      <li key={idx} className="leading-relaxed">
                        {effect}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-2.5 p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-between text-[11px]">
                    <span className="text-neutral-400">
                      Soglia critica di danneggiamento continuo:
                    </span>
                    <span className="font-mono font-bold text-red-400">
                      ≥ {comp.dangerThreshold}°C
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
