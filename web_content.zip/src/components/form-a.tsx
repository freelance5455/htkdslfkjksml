"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { GOVERNORATES, REQUEST_TYPES, ROLES, validateFormA, type FormAErrors, type FormAInput } from "@/lib/form-a";

const EMPTY: FormAInput = {
  fullName: "",
  phone: "",
  email: "",
  governorate: "",
  mosqueName: "",
  role: "",
  requestType: "",
  details: "",
};

const inputClass =
  "w-full rounded-2xl border bg-ivory px-4 py-3 text-navy placeholder:text-navy/40 focus:border-gold focus:ring-2 focus:ring-gold/30 focus:outline-none";

export function FormA() {
  const [values, setValues] = useState<FormAInput>(EMPTY);
  const [errors, setErrors] = useState<FormAErrors>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "done" | "error">("idle");
  const [serverError, setServerError] = useState<string | null>(null);
  const [submissionId, setSubmissionId] = useState<number | null>(null);

  const update = (field: keyof FormAInput) => (e: { target: { value: string } }) => {
    setValues((v) => ({ ...v, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setServerError(null);

    const found = validateFormA(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setStatus("submitting");
    try {
      const res = await fetch("/api/form-a", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const json = (await res.json()) as { ok: boolean; id?: number; error?: string; errors?: FormAErrors };
      if (!res.ok || !json.ok) {
        if (json.errors) setErrors(json.errors);
        setServerError(json.error ?? "تعذّر إرسال النموذج. حاول مرة أخرى.");
        setStatus("error");
        return;
      }
      setSubmissionId(json.id ?? null);
      setStatus("done");
      setValues(EMPTY);
    } catch {
      setServerError("تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم حاول مرة أخرى.");
      setStatus("error");
    }
  };

  if (status === "done") {
    return (
      <div className="rounded-[2rem] border border-gold/40 bg-card p-10 text-center shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)]" role="status">
        <CheckCircle2 className="mx-auto size-14 text-gold" aria-hidden="true" />
        <h2 className="mt-6 font-serif text-3xl font-bold text-navy">تم استلام النموذج</h2>
        <p className="mt-3 leading-8 text-navy/65">
          شكراً لك، تم حفظ طلبك{submissionId ? ` برقم ${submissionId}` : ""}. سيتم التواصل معك على الرقم الذي أدخلته.
        </p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="mt-8 rounded-full bg-navy px-6 py-3 text-sm font-medium text-ivory transition-all hover:bg-royal"
        >
          تقديم نموذج آخر
        </button>
      </div>
    );
  }

  const fieldError = (name: keyof FormAInput) =>
    errors[name] ? (
      <p className="mt-1.5 text-sm text-destructive" role="alert">
        {errors[name]}
      </p>
    ) : null;

  const borderFor = (name: keyof FormAInput) => (errors[name] ? "border-destructive/60" : "border-border");

  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="space-y-6 rounded-[2rem] border border-border bg-card p-6 shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)] sm:p-10"
    >
      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="fullName" className="mb-2 block text-sm font-medium text-navy">
            الاسم الكامل <span className="text-destructive">*</span>
          </label>
          <input id="fullName" name="fullName" autoComplete="name" value={values.fullName} onChange={update("fullName")} className={`${inputClass} ${borderFor("fullName")}`} />
          {fieldError("fullName")}
        </div>
        <div>
          <label htmlFor="phone" className="mb-2 block text-sm font-medium text-navy">
            رقم الهاتف <span className="text-destructive">*</span>
          </label>
          <input id="phone" name="phone" type="tel" inputMode="tel" dir="ltr" autoComplete="tel" value={values.phone} onChange={update("phone")} className={`${inputClass} ${borderFor("phone")} text-start`} />
          {fieldError("phone")}
        </div>
        <div>
          <label htmlFor="email" className="mb-2 block text-sm font-medium text-navy">
            البريد الإلكتروني <span className="text-navy/50">(اختياري)</span>
          </label>
          <input id="email" name="email" type="email" dir="ltr" autoComplete="email" value={values.email} onChange={update("email")} className={`${inputClass} ${borderFor("email")} text-start`} />
          {fieldError("email")}
        </div>
        <div>
          <label htmlFor="governorate" className="mb-2 block text-sm font-medium text-navy">
            المحافظة <span className="text-destructive">*</span>
          </label>
          <select id="governorate" name="governorate" value={values.governorate} onChange={update("governorate")} className={`${inputClass} ${borderFor("governorate")}`}>
            <option value="">اختر المحافظة…</option>
            {GOVERNORATES.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
          {fieldError("governorate")}
        </div>
        <div>
          <label htmlFor="role" className="mb-2 block text-sm font-medium text-navy">
            الصفة <span className="text-destructive">*</span>
          </label>
          <select id="role" name="role" value={values.role} onChange={update("role")} className={`${inputClass} ${borderFor("role")}`}>
            <option value="">اختر الصفة…</option>
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          {fieldError("role")}
        </div>
        <div>
          <label htmlFor="mosqueName" className="mb-2 block text-sm font-medium text-navy">
            اسم الجامع أو المسجد <span className="text-navy/50">(اختياري)</span>
          </label>
          <input id="mosqueName" name="mosqueName" value={values.mosqueName} onChange={update("mosqueName")} className={`${inputClass} ${borderFor("mosqueName")}`} />
          {fieldError("mosqueName")}
        </div>
      </div>

      <fieldset>
        <legend className="mb-3 text-sm font-medium text-navy">
          نوع الطلب <span className="text-destructive">*</span>
        </legend>
        <div className="grid gap-3 sm:grid-cols-2">
          {REQUEST_TYPES.map((t) => {
            const selected = values.requestType === t;
            return (
              <label
                key={t}
                className={`flex cursor-pointer items-center gap-3 rounded-2xl border px-5 py-4 transition-colors ${
                  selected ? "border-gold bg-gold/10 text-navy" : "border-border bg-ivory text-navy/80 hover:border-gold/60"
                }`}
              >
                <input type="radio" name="requestType" value={t} checked={selected} onChange={update("requestType")} className="accent-gold" />
                {t}
              </label>
            );
          })}
        </div>
        {fieldError("requestType")}
      </fieldset>

      <div>
        <label htmlFor="details" className="mb-2 block text-sm font-medium text-navy">
          التفاصيل <span className="text-destructive">*</span>
        </label>
        <textarea id="details" name="details" rows={6} value={values.details} onChange={update("details")} className={`${inputClass} ${borderFor("details")} resize-y leading-7`} placeholder="اكتب تفاصيل طلبك بوضوح…" />
        <div className="mt-1.5 flex items-start justify-between gap-4">
          {fieldError("details") ?? <span />}
          <span className="shrink-0 text-xs text-navy/50 tabular-nums">{values.details.length} / 2000</span>
        </div>
      </div>

      {serverError && (
        <p className="rounded-2xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive" role="alert">
          {serverError}
        </p>
      )}

      <div className="flex flex-wrap items-center justify-between gap-4 border-t border-border pt-6">
        <p className="text-xs text-navy/50">الحقول التي تحمل * إلزامية.</p>
        <button
          type="submit"
          disabled={status === "submitting"}
          className="inline-flex items-center gap-3 rounded-full bg-navy px-8 py-3.5 font-semibold text-ivory shadow-[0_20px_40px_-20px_rgba(23,36,58,0.9)] transition-all hover:-translate-y-0.5 hover:bg-royal disabled:opacity-60"
        >
          {status === "submitting" ? <Loader2 className="size-5 animate-spin" aria-hidden="true" /> : <Send className="size-5 -scale-x-100" aria-hidden="true" />}
          {status === "submitting" ? "جارٍ الإرسال…" : "إرسال النموذج"}
        </button>
      </div>
    </form>
  );
}
