import React, { useState } from "react";
import {
  Lightbulb,
  Sparkles,
  Shield,
  BookOpen,
  Download,
  Palette,
  Layout,
  Type,
  Frame,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Search
} from "lucide-react";

interface TipItem {
  id: string;
  category: string;
  icon: any;
  title: string;
  description: string;
  steps?: string[];
  shortcut?: string;
  badge?: string;
}

interface TipsViewProps {
  onOpenNewNote?: () => void;
  onOpenVault?: () => void;
  onOpenStudy?: () => void;
  onOpenSettings?: () => void;
  onOpenGallery?: () => void;
}

export const TipsView: React.FC<TipsViewProps> = ({
  onOpenNewNote,
  onOpenVault,
  onOpenStudy,
  onOpenSettings,
  onOpenGallery,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("Tümü");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [expandedTip, setExpandedTip] = useState<string | null>("tip-box-photo");

  const categories = [
    "Tümü",
    "Yazı & Biçim",
    "Fotoğraf & Kare",
    "Yapay Zeka",
    "Kasa & Güvenlik",
    "Çalışma Kartları",
    "Yedekleme & Belge",
    "Görünüm & Tema",
  ];

  const tips: TipItem[] = [
    {
      id: "tip-box-photo",
      category: "Fotoğraf & Kare",
      icon: Frame,
      title: "Yazıyı Kare İçerisine Alma & Fotoğraf Olarak Kaydetme",
      badge: "Yeni Özellik",
      description:
        "Önemli metinlerinizi veya alıntılarınızı şık bir çerçeve içerisine alabilir ve bunu tek dokunuşla PNG fotoğrafına dönüştürerek yan galeride saklayabilirsiniz.",
      steps: [
        "Not yazma penceresinde kare içine almak istediğiniz metni seçin (veya boş bir yere imleci koyun).",
        "Biçimlendirme araç çubuğundaki 'Kutu / Kare Ekle' (🔲) butonuna dokunun.",
        "Açılan menüden 'Enstantane Çek & Fotoğraf Olarak Galeriye Kaydet' seçeneğini seçin.",
        "Oluşan görsel anında sağ taraftaki 'Görsel Galerisi'ne kaydedilir ve istediğiniz zaman başka notlara eklenebilir!",
      ],
    },
    {
      id: "tip-word-fonts",
      category: "Yazı & Biçim",
      icon: Type,
      title: "Word Benzeri Yazı Tipleri ve Başlık Boyutları",
      badge: "Zengin Metin",
      description:
        "Notlarınızı klasik sıkıcı metinler yerine kitap fontları, kod fontları veya el yazısı fontlarıyla özelleştirin.",
      steps: [
        "Not düzenleyicide üst araç çubuğunda 'Yazı Tipi' menüsünden Sans (Modern), Serif (Kitap), Monospace (Kod) veya Caveat (El Yazısı) seçin.",
        "H1, H2, H3 butonlarıyla başlık boyutlarını anında ayarlayın.",
        "Metin hizalaması (Sol, Orta, Sağ) ve madde işaretleri ile belgenizi Word gibi biçimlendirin.",
      ],
      shortcut: "Ctrl+B (Kalın), Ctrl+I (İtalik), Ctrl+U (Altı Çizili)",
    },
    {
      id: "tip-color-highlight",
      category: "Yazı & Biçim",
      icon: Palette,
      title: "İstenilen Renkte Yazma ve Fosforlu Boyama",
      badge: "Vurgulama",
      description:
        "Önemli cümleleri göz alıcı renklerle boyayarak çalışma ve gözden geçirme hızınızı ikiye katlayın.",
      steps: [
        "Renk Paleti butonuna (🎨) dokunarak metin rengini Kırmızı, Mavi, Yeşil, Turuncu veya Mor yapın.",
        "Fosforlu Kalem (Vurgu) butonuna dokunarak seçili metnin üzerini sarı, yeşil veya pembe fosforla boyayın.",
      ],
    },
    {
      id: "tip-side-gallery",
      category: "Fotoğraf & Kare",
      icon: Frame,
      title: "Yan Galeri ve Görsel Ekleme",
      badge: "Çoklu Ortam",
      description:
        "Uygulamanın sağ tarafında yer alan Görsel Galerisi ile cihazınızdan yüklediğiniz fotoğrafları veya çektiğiniz metin karelerini kolayca yönetin.",
      steps: [
        "Sağ üstteki Galeri ikonuna dokunarak Görsel Çekmecesini açın.",
        "'Cihazdan Fotoğraf Yükle' butonu ile galerinizdeki herhangi bir resmi içeri alın.",
        "İstediğiniz görselin altındaki 'Metne Ekle (➕)' butonuna basarak anında notun içerisine ekleyin.",
      ],
    },
    {
      id: "tip-ai-features",
      category: "Yapay Zeka",
      icon: Sparkles,
      title: "Google Gemini 3.8 Flash ile Akıllı Not Alma",
      badge: "Yapay Zeka",
      description:
        "Yapay zeka asistanı notlarınızı anlar, uzun metinleri özetler, aksiyon maddelerini çıkarır ve soru sorabileceğiniz bir çalışma arkadaşı olur.",
      steps: [
        "Not modalındaki '✨ AI Özetle' butonuyla uzun notları 3 maddelik özete dönüştürün.",
        "'✨ Görev Çıkar' butonuyla yapılacak işleri otomatik tespit edin.",
        "Sağ alttaki 'Akıllı Asistan' butonuyla notlarınız hakkında sohbet edin ve fikir danışın.",
      ],
    },
    {
      id: "tip-vault-security",
      category: "Kasa & Güvenlik",
      icon: Shield,
      title: "PBKDF2 & AES-256 PBKDF2 Şifreli Kasa",
      badge: "Maksimum Güvenlik",
      description:
        "Özel şifreleriniz, kişisel günlükleriniz ve hassas belgeleriniz tarayıcı düzeyinde askeri şifreleme ile korunur.",
      steps: [
        "Kasa sekmesinden 4-8 basamaklı bir PIN kodu belirleyin.",
        "Kasa kilitlendiğinde şifre çözme anahtarı bellekten tamamen silinir.",
        "Not kaydederken 'Gizli Kasaya Kaydet' seçeneğini işaretleyerek notu otomatik olarak şifreleyin.",
      ],
    },
    {
      id: "tip-study-flashcards",
      category: "Çalışma Kartları",
      icon: BookOpen,
      title: "3D Dokunmatik Çalışma Kartları & Aralıklı Tekrar",
      badge: "Öğrenme",
      description:
        "Ezberlemek istediğiniz konular için çalışma kartları oluşturun veya yapay zekanın notlarınızdan otomatik kart üretmesini sağlayın.",
      steps: [
        "'Öğren' sekmesine geçin ve kartın üzerine dokunarak arka yüzündeki cevabı görün.",
        "'Öğrendim' veya 'Tekrar Et' butonlarıyla ilerlemenizi takip edin.",
        "İlerleme çubuğunda öğrenilen kart yüzdesini anlık olarak izleyin.",
      ],
    },
    {
      id: "tip-export-multi",
      category: "Yedekleme & Belge",
      icon: Download,
      title: "JSON, Markdown, HTML, TXT ve CSV Belge İndirme",
      badge: "Her Belge Destekli",
      description:
        "Notlarınızı istediğiniz formata dönüştürün, tek dosya HTML web belgesi veya Excel uyumlu CSV tablosu olarak indirin.",
      steps: [
        "Ayarlar sekmesine gidin.",
        "İstediğiniz formatı seçin: JSON (Tam sistem yedeği), HTML (Tek dosya taşınabilir web belgesi), Markdown (.md), TXT (Düz metin) veya CSV (E-Tablo).",
        "'Yedeği İçe Aktar' kısmından da istediğiniz metin veya yedek dosyasını geri yükleyebilirsiniz.",
      ],
    },
    {
      id: "tip-theme-colors",
      category: "Görünüm & Tema",
      icon: Palette,
      title: "6 Farklı Tema Rengi & Gece/Gündüz Modu",
      badge: "Kişiselleştirme",
      description:
        "Gözlerinizi yormayan Gece (Dark) ve Gündüz (Light) modlarının yanı sıra 6 farklı canlı renk teması arasından seçim yapabilirsiniz.",
      steps: [
        "Üst bardaki Güneş/Ay ikonuna dokunarak anında Gece ve Gündüz modları arasında geçiş yapın.",
        "Ayarlar sekmesinden Zümrüt Yeşili, Okyanus Mavisi, Ametist Moru, Günbatımı Turuncusu veya Gül Kurusu temalarını etkinleştirin.",
      ],
    },
    {
      id: "tip-view-layouts",
      category: "Görünüm & Tema",
      icon: Layout,
      title: "Izgara, Liste ve Kompakt Listeleme Biçimleri",
      badge: "Esnek Düzen",
      description:
        "Notlarınızı ister geniş kartlar halinde, ister okunabilir liste formatında, isterseniz de yoğun kompakt tablo biçiminde listeleyin.",
      steps: [
        "Üst arama çubuğunun hemen sağındaki Görünüm Değiştirici ikonlara dokunun.",
        "Geniş ekranlarda Izgara, çok sayıda not incelerken Kompakt Liste modunu tercih edebilirsiniz.",
      ],
    },
  ];

  const filteredTips = tips.filter((tip) => {
    if (selectedCategory !== "Tümü" && tip.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tip.title.toLowerCase().includes(q) ||
        tip.description.toLowerCase().includes(q) ||
        tip.steps?.some((s) => s.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-lg shadow-teal-700/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              <Lightbulb className="w-5 h-5 text-amber-300" />
            </div>
            <h2 className="text-xl font-extrabold tracking-tight">Uygulama İpuçları & Rehber</h2>
          </div>
          <p className="text-xs sm:text-sm text-teal-100 max-w-xl">
            NoteFlow'un Word tarzı yazı editörü, kareye alıp fotoğraf çekme sistemi, şifreli kasa ve yapay zeka özelliklerinden maksimum verim alın.
          </p>
        </div>

        <div className="w-full sm:w-auto">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/60" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="İpucu ara..."
              className="w-full sm:w-56 pl-9 pr-3 py-2 bg-white/15 border border-white/25 rounded-2xl text-xs text-white placeholder:text-white/60 focus:outline-none focus:bg-white/25"
            />
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              selectedCategory === cat
                ? "bg-teal-600 text-white shadow-sm"
                : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Tips Accordion Cards */}
      <div className="space-y-3">
        {filteredTips.length === 0 ? (
          <div className="text-center py-16 bg-white dark:bg-slate-800/50 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700">
            <Lightbulb className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-500">Aradığınız kriterde ipucu bulunamadı.</p>
          </div>
        ) : (
          filteredTips.map((tip) => {
            const isExpanded = expandedTip === tip.id;
            const Icon = tip.icon;

            return (
              <div
                key={tip.id}
                className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700/80 overflow-hidden shadow-xs hover:shadow-md transition-all"
              >
                <button
                  type="button"
                  onClick={() => setExpandedTip(isExpanded ? null : tip.id)}
                  className="w-full p-4 flex items-center justify-between gap-3 text-left focus:outline-none"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          {tip.title}
                        </span>
                        {tip.badge && (
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 rounded-full">
                            {tip.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                        {tip.description}
                      </p>
                    </div>
                  </div>

                  <div className="text-slate-400 shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 border-t border-slate-100 dark:border-slate-700/60 space-y-3 animate-in fade-in">
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {tip.description}
                    </p>

                    {tip.steps && (
                      <div className="p-3.5 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200/60 dark:border-slate-800 space-y-2">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-1">
                          Adım Adım Nasıl Yapılır:
                        </span>
                        {tip.steps.map((step, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400">
                            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {tip.shortcut && (
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
                        <span className="font-bold">Kısayol:</span>
                        <code className="px-2 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-slate-800 dark:text-slate-200">
                          {tip.shortcut}
                        </code>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
