import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Shield,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Send,
  AlertTriangle,
  Lock,
  Eye,
  RefreshCw,
  Clock,
  Calendar,
  MoonStar,
  Check,
  Terminal,
  Database,
  KeyRound,
  Download,
  Upload,
  RotateCcw,
  Volume2,
  Layers,
  Search,
  Trash2,
  Wand2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { triggerCelebration, triggerBigCelebration } from '../../utils/confetti';
import { Task } from '../../types';
import { HabivioWeatherWidget } from '../Weather/HabivioWeatherWidget';
import { parseNaturalLanguageIntent } from '../../utils/aiReasoning';
import { playTaskCompletionSound } from '../../utils/audioManager';

interface ProposedAction {
  id: string;
  type:
    | 'create_task'
    | 'create_alarm'
    | 'create_reminder'
    | 'create_habit'
    | 'create_goal'
    | 'complete_task'
    | 'reschedule_task'
    | 'delete_task'
    | 'log_prayer'
    | 'increment_habit';
  title: string;
  description: string;
  payload: any;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  toolInvoked?: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  actions?: ProposedAction[];
  securityNote?: string;
  toolSource?: string;
}

const STORAGE_KEY_CHAT_HISTORY = 'habivio_ai_conversation_history_v2';

export const AIAssistantSection: React.FC = () => {
  const {
    tasks,
    addTask,
    updateTask,
    deleteTask,
    toggleTaskCompleted,
    habits,
    addHabit,
    incrementHabitCount,
    goals,
    addGoal,
    prayers,
    togglePrayer,
    selectedDate,
    todayMetrics,
    exportData,
    importData,
    language,
  } = useApp();

  const isBn = language === 'bn';

  // Navigation tab inside AI Assistant
  const [activeSubTab, setActiveSubTab] = useState<'assistant' | 'approvals' | 'security'>('assistant');

  // Multi-stage Progressive Loading State
  const [loadingStage, setLoadingStage] = useState<'idle' | 'analyzing' | 'checking_context' | 'calling_tools'>('idle');

  // Chat conversation with persistent history manager
  const [inputMessage, setInputMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  const getInitialMessages = (): ChatMessage[] => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY_CHAT_HISTORY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch {
        // fallback
      }
    }
    return [
      {
        id: 'welcome-msg',
        sender: 'assistant',
        text: isBn
          ? 'আসসালামু আলাইকুম! আমি আপনার হাবিভিও এআই সহকারী। আমি আপনার স্বাভাবিক বাংলা ও ইংরেজি নির্দেশ বুঝে কাজ তৈরি, ওয়েক-আপ অ্যালার্ম শিডিউল, ওষুধের রিমাইন্ডার ও নামাজের ওয়াক্ত ট্র্যাক করতে পারি। আমাকে যেকোনো কাজের নির্দেশ দিন।'
          : 'Assalamu Alaikum! I am your Habivio AI Assistant. I understand natural conversational Bengali and English to create tasks, schedule nature-sound alarms, remind you of medicine, and track your prayer waqts.',
        timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
        securityNote: isBn ? '🔒 লোকাল এনক্রিপ্টেড ভল্ট সক্রিয় • জিরো ডেটা লিক' : '🔒 Local Encrypted Vault Active • Zero Data Leakage',
      },
    ];
  };

  const [messages, setMessages] = useState<ChatMessage[]>(getInitialMessages);

  // Synchronize conversation history to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined' && messages.length > 0) {
      try {
        localStorage.setItem(STORAGE_KEY_CHAT_HISTORY, JSON.stringify(messages.slice(-50)));
      } catch {
        // ignore
      }
    }
  }, [messages]);

  // Reset / Clear Conversation History
  const handleClearHistory = () => {
    const welcome: ChatMessage = {
      id: `welcome-${Date.now()}`,
      sender: 'assistant',
      text: isBn
        ? 'নতুন কথোপকথন শুরু হয়েছে। আমি আপনার নির্দেশ পালনে প্রস্তুত। আপনি কী করতে চান বলুন।'
        : 'Started a fresh conversation session. How may I assist your schedule today?',
      timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
      securityNote: isBn ? '🔒 নতুন ফ্রেশ সেশন' : '🔒 Clean Session Started',
    };
    setMessages([welcome]);
    try {
      localStorage.removeItem(STORAGE_KEY_CHAT_HISTORY);
    } catch {
      // ignore
    }
  };

  // Actions waiting for user approval ("আমার অনুমতি নিয়ে")
  const [pendingActions, setPendingActions] = useState<ProposedAction[]>(() => [
    {
      id: 'act-sample-1',
      type: 'create_task',
      title: isBn ? 'আগামীকালের জন্য "কুরআন তাফসীর অধ্যয়ন" শিডিউল করা' : 'Schedule "Quran Tafsir Study" for Tomorrow',
      description: isBn
        ? 'আপনার সাপ্তাহিক আধ্যাত্মিক লক্ষ্য অর্জনে সহায়তার জন্য সকাল ০৬:৪৫ এ এই টাস্কটি যুক্ত করার সুপারিশ।'
        : 'Recommended at 06:45 AM to help maintain your spiritual weekly target.',
      payload: {
        title: isBn ? 'কুরআন তাফসীর অধ্যয়ন' : 'Quran Tafsir Study',
        dueTime: '06:45',
        priority: 'high',
        category: 'worship',
      },
      status: 'pending',
      createdAt: 'এখনই',
    },
  ]);

  // Security scanning state
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(100);
  const [lastScanTime, setLastScanTime] = useState<string>(
    new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' })
  );
  const [threatCount, setThreatCount] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // Handle User Message Submission
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isProcessing) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsProcessing(true);
    setLoadingStage('analyzing');

    const stageTimer1 = setTimeout(() => {
      setLoadingStage('checking_context');
    }, 400);

    const stageTimer2 = setTimeout(() => {
      setLoadingStage('calling_tools');
    }, 1100);

    // If this is one of the explicit 4 quick action pills, handle with smart reasoning immediately
    const isExplicitQuickButton = [
      'কাজ যুক্ত করুন',
      'নতুন অভ্যাস',
      'নতুন লক্ষ্য',
      'নামাজ আদায় রেকর্ড করুন',
    ].includes(text.trim());

    if (isExplicitQuickButton) {
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      const smartParsed = parseNaturalLanguageIntent(text, isBn);
      if (smartParsed.isMatch && smartParsed.proposedAction) {
        const newAction: ProposedAction = {
          ...smartParsed.proposedAction,
          status: 'pending',
          createdAt: isBn ? 'এখনই' : 'Just now',
          toolInvoked: smartParsed.proposedAction.type,
        };
        setPendingActions((prev) => [newAction, ...prev]);

        const assistantMsg: ChatMessage = {
          id: `asst-${Date.now()}`,
          sender: 'assistant',
          text: isBn ? smartParsed.replyBn : smartParsed.replyEn,
          timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
          actions: [newAction],
          securityNote: isBn ? '🛡️ প্রায়োরিটি ও সময়সূচি স্বয়ংক্রিয়ভাবে নির্ধারিত' : '🛡️ Context & Priority Auto-Calculated',
          toolSource: 'local_intent',
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setIsProcessing(false);
        setLoadingStage('idle');
        return;
      }
    }

    try {
      // Gather rich context for conversational AI brain
      const appContext = {
        selectedDate,
        date: selectedDate,
        language: isBn ? 'bn' : 'en',
        metrics: todayMetrics,
        tasks: tasks.map((t) => ({
          id: t.id,
          title: t.title,
          dueDate: t.dueDate,
          dueTime: t.dueTime,
          completed: t.completed,
          category: t.category,
          priority: t.priority,
          alarmEnabled: t.alarmEnabled,
          ringtone: t.ringtone,
        })),
        habits: habits.map((h) => ({
          id: h.id,
          title: h.title,
          streak: h.currentStreak,
          currentStreak: h.currentStreak,
          targetCount: h.targetCount,
        })),
        todayPrayers: prayers[selectedDate] || {},
      };

      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          appContext,
          conversationHistory: messages.slice(-10).map((m) => ({ sender: m.sender, text: m.text })),
        }),
      });

      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);

      const data = await response.json();
      const rawActions = data.actions || data.proposedActions || [];
      const newActions: ProposedAction[] = rawActions.map((a: any) => ({
        id: a.id || `act-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type: a.type,
        title: a.title,
        description: a.description || '',
        payload: a.payload || {},
        status: 'pending',
        createdAt: isBn ? 'এখনই' : 'Just now',
        toolInvoked: a.toolInvoked || a.type,
      }));

      if (newActions.length > 0) {
        setPendingActions((prev) => [...newActions, ...prev]);
      }

      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || (isBn ? 'আমি আপনার বার্তা বুঝতে পেরেছি।' : 'I have understood your request.'),
        timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
        actions: newActions.length > 0 ? newActions : undefined,
        securityNote: isBn ? '🛡️ জেমিনি টুল-কলিং সক্রিয় • ভেরিফাইড অ্যাকশন' : '🛡️ Gemini Tool-Calling Active • Verified',
        toolSource: data.source || 'gemini_tool_calling',
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (networkError) {
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      console.warn('Network call to assistant backend failed, using smart offline intelligence:', networkError);

      // Robust, honest local semantic processor (Never outputs canned repetitious boilerplate)
      const lower = text.toLowerCase().trim();
      let fallbackReply = '';
      const fallbackActions: ProposedAction[] = [];

      // 1. Task query: "আমার আজকের কাজগুলো কী কী?"
      if (
        lower.includes('আজকের কাজ') ||
        lower.includes('কাজগুলো কি') ||
        lower.includes('কাজগুলো কী') ||
        lower.includes('আমার কাজ') ||
        lower.includes('show task') ||
        lower.includes('list task') ||
        lower.includes('কাজের তালিকা')
      ) {
        const todayTasks = tasks.filter((t) => t.dueDate === selectedDate || !t.dueDate);
        if (todayTasks.length === 0) {
          fallbackReply = isBn
            ? 'আপনার আজকের তালিকায় বর্তমানে কোনো কাজ নির্ধারিত নেই। আপনি চাইলে আমি একটি নতুন কাজ বা অ্যালার্ম শিডিউল করে দিতে পারি।'
            : "You don't have any tasks scheduled for today. Would you like me to schedule a task or alarm for you?";
        } else {
          const completed = todayTasks.filter((t) => t.completed);
          const pending = todayTasks.filter((t) => !t.completed);
          const listStr = todayTasks
            .map(
              (t, i) =>
                `${i + 1}. ${t.completed ? '✅' : '⏳'} ${t.title}${t.dueTime ? ` (${t.dueTime})` : ''}`
            )
            .join('\n');
          fallbackReply = isBn
            ? `আজকের মোট ${todayTasks.length}টি কাজের বিবরণ (${completed.length}টি সম্পন্ন, ${pending.length}টি বাকি):\n\n${listStr}\n\nকোনো কাজ সম্পন্ন করতে বা নতুন অ্যালার্ম যোগ করতে আমাকে বলুন।`
            : `Here are your ${todayTasks.length} tasks for today (${completed.length} done, ${pending.length} pending):\n\n${listStr}`;
        }
      }
      // 2. Complete Task: "ব্যবসার পরিকল্পনা শেষ হয়েছে, এটা কমপ্লিট করো"
      else if (
        lower.includes('কমপ্লিট') ||
        lower.includes('শেষ হয়েছে') ||
        lower.includes('সম্পন্ন') ||
        lower.includes('complete') ||
        lower.includes('mark done')
      ) {
        const matched = tasks.find((t) => !t.completed) || tasks[0];
        if (matched) {
          fallbackReply = isBn
            ? `আমি "${matched.title}" কাজটি সম্পন্ন করার অনুমোদন কার্ড তৈরি করেছি। নিচে ১-ট্যাপে নিশ্চিত করুন:`
            : `I have prepared to mark "${matched.title}" as completed. Please approve below:`;
          fallbackActions.push({
            id: `act-off-comp-${Date.now()}`,
            type: 'complete_task',
            title: isBn ? `"${matched.title}" সম্পন্ন করুন` : `Complete "${matched.title}"`,
            description: isBn ? 'কাজের স্ট্যাটাস সম্পূর্ণ হবে এবং সাউন্ড বাজবে।' : 'Mark task as done with audio chime.',
            payload: { taskId: matched.id, taskTitle: matched.title },
            status: 'pending',
            createdAt: isBn ? 'এখনই' : 'Just now',
          });
        } else {
          fallbackReply = isBn
            ? 'সম্পন্ন করার মতো কোনো পেন্ডিং কাজ বর্তমানে পাওয়া যায়নি।'
            : 'No pending tasks found to mark as completed.';
        }
      }
      // 3. Wake-up / Alarm: "আগামীকাল সকাল ৬টায় আমাকে ঘুম থেকে উঠিয়ে দিও"
      else if (
        lower.includes('জাগিয়ে') ||
        lower.includes('ঘুম থেকে') ||
        lower.includes('উঠিয়ে দিও') ||
        lower.includes('wake me up') ||
        lower.includes('alarm') ||
        lower.includes('অ্যালার্ম')
      ) {
        let alarmTime = '06:00';
        const match = lower.match(/(\d{1,2})(:(\d{2}))?\s*(am|pm|টা|টায়)?/i);
        if (match) {
          let h = parseInt(match[1], 10);
          const m = match[3] ? parseInt(match[3], 10) : 0;
          if (lower.includes('pm') || lower.includes('বিকাল') || lower.includes('রাত')) {
            if (h < 12) h += 12;
          }
          alarmTime = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }
        const isTomorrow = lower.includes('কাল') || lower.includes('আগামীকাল') || lower.includes('tomorrow');
        const targetDate = isTomorrow
          ? new Date(Date.now() + 86400000).toISOString().split('T')[0]
          : selectedDate;

        fallbackReply = isBn
          ? `আগামীকাল সকাল ${alarmTime} এর জন্য ভোরের স্নিগ্ধ পাখির সুর সহ ওয়েক-আপ অ্যালার্মের প্রস্তাব তৈরি করেছি। অনুমোদন দিন:`
          : `I have scheduled a wake-up alarm at ${alarmTime} with gentle birdsong melody. Please approve:`;

        fallbackActions.push({
          id: `act-off-alarm-${Date.now()}`,
          type: 'create_alarm',
          title: isBn ? `সকাল ${alarmTime} ওয়েক-আপ অ্যালার্ম` : `Wake-up Alarm at ${alarmTime}`,
          description: isBn ? 'ভোরের স্নিগ্ধ পাখির গান • লক স্ক্রিন ওয়েক' : 'Gentle Birdsong • Lock Screen Wake',
          payload: {
            title: isBn ? 'ঘুম থেকে জাগরণ ও সকালের সূচনা' : 'Wake-up & Morning Routine',
            dueTime: alarmTime,
            dueDate: targetDate,
            priority: 'high',
            category: 'health',
            alarmEnabled: true,
            ringtone: 'morning_birds',
          },
          status: 'pending',
          createdAt: isBn ? 'এখনই' : 'Just now',
        });
      }
      // 4. Medicine Reminder: "খাওয়ার আগে ওষুধ"
      else if (lower.includes('ওষুধ') || lower.includes('ঔষধ') || lower.includes('medicine')) {
        const medTime = '13:00';
        fallbackReply = isBn
          ? 'দুপুরের খাবারের ৩০ মিনিট আগে (১:০০ PM) ওষুধ সেবনের জন্য মৃদু ঘণ্টার রিমাইন্ডার তৈরি করেছি। অনুমোদন দিন:'
          : 'I prepared a medication reminder 30 minutes before lunch (1:00 PM) with a gentle chime. Please approve:';

        fallbackActions.push({
          id: `act-off-med-${Date.now()}`,
          type: 'create_reminder',
          title: isBn ? 'দুপুরের ওষুধ সেবন রিমাইন্ডার' : 'Lunch Medicine Reminder',
          description: isBn ? 'সময়: ১:০০ PM • মৃদু ঘণ্টা সুর' : 'Time: 1:00 PM • Soft Chime',
          payload: {
            title: isBn ? 'খাওয়ার আগের ওষুধ গ্রহণ' : 'Take Pre-Meal Medication',
            dueTime: medTime,
            dueDate: selectedDate,
            priority: 'high',
            category: 'health',
            alarmEnabled: true,
            ringtone: 'soft_chime',
          },
          status: 'pending',
          createdAt: isBn ? 'এখনই' : 'Just now',
        });
      }
      // 5. Prayer Reminder: "নামাজের ৫ মিনিট আগে জাগিয়ে দিও"
      else if (lower.includes('নামাজ') || lower.includes('আজান') || lower.includes('prayer')) {
        fallbackReply = isBn
          ? 'নামাজের ওয়াক্তের ৫ মিনিট আগে আধ্যাত্মিক আজানের সুর সহ রিমাইন্ডার তৈরি করেছি। অনুমোদন দিন:'
          : 'Prepared a prayer reminder 5 minutes before waqt with spiritual chime. Please approve:';

        fallbackActions.push({
          id: `act-off-prayer-${Date.now()}`,
          type: 'create_reminder',
          title: isBn ? 'নামাজের ওয়াক্ত রিমাইন্ডার' : 'Prayer Waqt Reminder',
          description: isBn ? 'ওয়াক্তের ৫ মিনিট আগে আধ্যাত্মিক আজান' : '5 mins before prayer • Spiritual Adhan',
          payload: {
            title: isBn ? 'নামাজের ওয়াক্ত ও জামাত' : 'Prayer Waqt & Salah',
            dueTime: '13:10',
            dueDate: selectedDate,
            priority: 'high',
            category: 'worship',
            alarmEnabled: true,
            ringtone: 'adhan_spiritual',
          },
          status: 'pending',
          createdAt: isBn ? 'এখনই' : 'Just now',
        });
      } else {
        fallbackReply = isBn
          ? `আপনার বার্তাটি পেয়েছি: "${text.trim()}"। আমি আপনার দৈনন্দিন কাজ, অ্যালার্ম, নামাজের ওয়াক্ত ও রুটিন পরিচালনায় সহায়তা করতে প্রস্তুত। আপনি কি কোনো কাজ যুক্ত করতে চান, নাকি কোনো অ্যালার্ম সেট করতে চান?`
          : `I received your message: "${text.trim()}". I am ready to help manage your schedule, alarms, prayers, and habits. How would you like me to proceed?`;
      }

      if (fallbackActions.length > 0) {
        setPendingActions((prev) => [...fallbackActions, ...prev]);
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `asst-${Date.now()}`,
          sender: 'assistant',
          text: fallbackReply,
          timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
          actions: fallbackActions.length > 0 ? fallbackActions : undefined,
          securityNote: isBn ? '🛡️ অফলাইন লোকাল মোড • নিরাপদ' : '🛡️ Offline Local Mode • Secure',
        },
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  // User Approval Execution ("আমার অনুমতি নিয়ে")
  const handleApproveAction = (action: ProposedAction) => {
    try {
      let confirmationText = '';

      if (action.type === 'create_task' || action.type === 'create_alarm' || action.type === 'create_reminder') {
        const payload = action.payload || {};
        const dueTime = payload.dueTime || payload.time || '08:00';
        const dueDate = payload.dueDate || payload.date || selectedDate;
        const ringtone = payload.ringtone || payload.soundId || (action.type === 'create_alarm' ? 'morning_birds' : 'soft_chime');

        addTask({
          title: payload.title || action.title,
          notes: action.description || payload.notes,
          dueDate,
          dueTime,
          priority: payload.priority || (action.type === 'create_reminder' ? 'high' : 'medium'),
          category: payload.category || (action.type === 'create_reminder' ? 'health' : 'work'),
          completed: false,
          isRoutine: false,
          alarmEnabled: payload.alarmEnabled ?? true,
          alarmMinutesBefore: payload.alarmMinutesBefore ?? 0,
          ringtone,
        });

        triggerCelebration(0.7);

        if (action.type === 'create_alarm') {
          confirmationText = isBn
            ? `অ্যালার্ম সেট হয়েছে। ${dueTime} এ বাজবে।`
            : `Alarm scheduled. Will ring at ${dueTime}.`;
        } else if (action.type === 'create_reminder') {
          confirmationText = isBn
            ? `রিমাইন্ডার সেট হয়েছে। ${dueTime} এ নোটিফিকেশন দেওয়া হবে।`
            : `Reminder scheduled for ${dueTime}.`;
        } else {
          confirmationText = isBn
            ? `"${payload.title || action.title}" কাজটি সফলভাবে আপনার তালিকায় যুক্ত হয়েছে।`
            : `Task "${payload.title || action.title}" has been added to your schedule.`;
        }
      } else if (action.type === 'complete_task') {
        const tId = action.payload?.taskId;
        if (tId) {
          toggleTaskCompleted(tId);
          triggerCelebration(0.65);
          confirmationText = isBn
            ? `"${action.payload?.taskTitle || action.title}" সফলভাবে সম্পন্ন হিসেবে চিহ্নিত করা হয়েছে।`
            : `Task "${action.payload?.taskTitle || action.title}" marked as completed.`;
        }
      } else if (action.type === 'delete_task') {
        const tId = action.payload?.taskId;
        if (tId) {
          deleteTask(tId);
          confirmationText = isBn
            ? `"${action.payload?.taskTitle || action.title}" মুছে ফেলা হয়েছে।`
            : `Task "${action.payload?.taskTitle || action.title}" removed.`;
        }
      } else if (action.type === 'reschedule_task') {
        const tId = action.payload?.taskId;
        const existing = tasks.find((t) => t.id === tId);
        if (existing) {
          updateTask({
            ...existing,
            dueDate: action.payload?.newDate || existing.dueDate,
            dueTime: action.payload?.newTime || existing.dueTime,
          });
          triggerCelebration(0.5);
          confirmationText = isBn
            ? `"${existing.title}" কাজটি ${action.payload?.newDate || existing.dueDate} তারিখ ${action.payload?.newTime || existing.dueTime} সময়ে রিশিডিউল করা হয়েছে।`
            : `Task "${existing.title}" rescheduled.`;
        }
      } else if (action.type === 'create_habit') {
        addHabit({
          title: action.payload?.title || action.title,
          description: action.description || 'Track daily disciplines & streak momentum',
          category: action.payload?.category || 'mindfulness',
          frequency: action.payload?.frequency || 'daily',
          targetCount: action.payload?.targetCount || 1,
          unit: 'times',
          color: '#10b981',
          iconName: 'Sparkles',
        });
        triggerCelebration(0.8);
        confirmationText = isBn
          ? `নতুন অভ্যাস "${action.payload?.title || action.title}" সক্রিয় করা হয়েছে।`
          : `Habit "${action.payload?.title || action.title}" is now active.`;
      } else if (action.type === 'create_goal') {
        addGoal({
          title: action.payload?.title || action.title,
          description: action.description || 'Set ambitious targets with actionable milestones',
          category: action.payload?.category || 'personal',
          targetDate: action.payload?.targetDate || selectedDate,
          milestones: action.payload?.milestones || [],
          progress: action.payload?.progress || 0,
          color: '#6366f1',
        });
        triggerCelebration(0.85);
        confirmationText = isBn
          ? `নতুন লক্ষ্য "${action.payload?.title || action.title}" যুক্ত হয়েছে।`
          : `Goal "${action.payload?.title || action.title}" created.`;
      } else if (action.type === 'log_prayer') {
        const key = action.payload?.prayerKey || 'fajr';
        togglePrayer(key, selectedDate);
        triggerCelebration(0.8);
        confirmationText = isBn
          ? `নামাজ রেকর্ড আপডেট করা হয়েছে। আলহামদুলিল্লাহ!`
          : `Prayer status updated. Alhamdulillah!`;
      } else if (action.type === 'increment_habit') {
        if (action.payload?.habitId) {
          incrementHabitCount(action.payload.habitId, selectedDate);
          triggerCelebration(0.6);
          confirmationText = isBn ? `অভ্যাসের কাউন্ট বাড়ানো হয়েছে!` : `Habit streak incremented!`;
        }
      }

      // Play pleasant task completion sound feedback
      playTaskCompletionSound('positive_tone');

      // Mark action as approved in pending actions
      setPendingActions((prev) =>
        prev.map((a) => (a.id === action.id ? { ...a, status: 'approved' } : a))
      );

      // Mark action as approved in messages history so the button changes state in-place
      setMessages((prev) => {
        const updated = prev.map((m) => {
          if (!m.actions) return m;
          const matched = m.actions.some((a) => a.id === action.id);
          if (!matched) return m;
          return {
            ...m,
            actions: m.actions.map((a) => (a.id === action.id ? { ...a, status: 'approved' as const } : a)),
          };
        });

        return [
          ...updated,
          {
            id: `sys-confirm-${Date.now()}`,
            sender: 'assistant',
            text: confirmationText || (isBn ? `✅ "${action.title}" সম্পন্ন হয়েছে।` : `✅ "${action.title}" executed.`),
            timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
            securityNote: isBn ? '🔐 অনুমোদিত ও কার্যকরকৃত' : '🔐 Authorized & Verified',
          },
        ];
      });
    } catch (e) {
      console.error('Action approval execution failed:', e);
      setMessages((prev) => [
        ...prev,
        {
          id: `sys-err-${Date.now()}`,
          sender: 'assistant',
          text: isBn
            ? `অ্যাকশনটি কার্যকর করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।`
            : `Failed to execute action. Please try again.`,
          timestamp: new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }
  };

  // User Rejection
  const handleRejectAction = (actionId: string) => {
    setPendingActions((prev) =>
      prev.map((a) => (a.id === actionId ? { ...a, status: 'rejected' } : a))
    );
    setMessages((prev) =>
      prev.map((m) => {
        if (!m.actions) return m;
        const matched = m.actions.some((a) => a.id === actionId);
        if (!matched) return m;
        return {
          ...m,
          actions: m.actions.map((a) => (a.id === actionId ? { ...a, status: 'rejected' as const } : a)),
        };
      })
    );
  };

  // Trigger Security Scan
  const handleTriggerSecurityScan = () => {
    if (isScanning) return;
    setIsScanning(true);
    setScanProgress(10);

    const timer = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setIsScanning(false);
          setThreatCount(0);
          setLastScanTime(
            new Date().toLocaleTimeString(isBn ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' })
          );
          triggerBigCelebration();
          return 100;
        }
        return prev + 20;
      });
    }, 280);
  };

  // Quick Prompt Prompts with natural language intent examples
  const quickPrompts = isBn
    ? [
        '💊 দুপুরে খাবার ৩০ মিনিট আগে ওষুধ খেতে হবে',
        '🕌 জুম্মার নামাজের ৪৫ মিনিট আগে গোসল ও প্রস্তুতির অ্যালার্ম দাও',
        'আজকের বাকি কাজগুলো দেখাও',
        'সম্পূর্ণ সাইবার নিরাপত্তা স্ক্যান করো',
      ]
    : [
        '💊 Take medicine 30 minutes before lunch',
        '🕌 Alarm 45 mins before Jummah for ghusl',
        'Show my remaining tasks today',
        'Run full cyber security scan',
      ];

  const pendingCount = pendingActions.filter((a) => a.status === 'pending').length;

  return (
    <div className="space-y-6 pb-16 font-bangla-display">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-slate-950 via-indigo-950 to-slate-900 text-white p-6 shadow-2xl border border-indigo-500/20">
        <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/20 border border-violet-400/30 text-xs font-bold text-violet-200">
              <Sparkles size={14} className="text-violet-300 animate-pulse" />
              <span>{isBn ? 'হাবিভিও এআই এক্সিকিউটিভ সহকারী' : 'Habivio Executive AI'}</span>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-[11px] font-bold text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{isBn ? '২৪/৭ সক্রিয় নজরদারি ও সুরক্ষা' : '24/7 Active Supervisor & Shield'}</span>
            </div>
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {isBn ? 'আপনার ব্যক্তিগত এআই ম্যানেজার ও সাইবার গার্ড' : 'Your Personal AI Manager & Cyber Guard'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed mt-1.5">
              {isBn
                ? 'আপনার অনুমতি নিয়ে পুরো অ্যাপের কাজ, ওয়াক্ত ও রুটিন সুশৃঙ্খলভাবে নিয়ন্ত্রণ করে এবং ভাইরাস, হ্যাকিং ও তথ্যের পূর্ণ গোপনীয়তা নিশ্চিত করে।'
                : 'Supervises your schedule, prayer times, and habits with your explicit approval, while protecting your data from threats and leaks.'}
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-2 pt-2">
            <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                {isBn ? 'অনুমোদন পেন্ডিং' : 'Pending Approvals'}
              </span>
              <span className="text-base font-black text-violet-300">{pendingCount}</span>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                {isBn ? 'সাইবার স্ট্যাটাস' : 'Threat Level'}
              </span>
              <span className="text-base font-black text-emerald-400">{isBn ? '০টি ঝুঁকি' : '0 Clean'}</span>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                {isBn ? 'ডেটা গোপনীয়তা' : 'Data Privacy'}
              </span>
              <span className="text-base font-black text-sky-300">{isBn ? '১০০% লোকাল' : '100% Local'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-Tabs: Assistant Chat | Approvals | Security Shield */}
      <div className="flex rounded-2xl bg-slate-100 dark:bg-slate-800/90 p-1.5 border border-slate-200 dark:border-slate-700/80">
        <button
          onClick={() => setActiveSubTab('assistant')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeSubTab === 'assistant'
              ? 'bg-white dark:bg-slate-900 text-violet-600 dark:text-violet-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Sparkles size={14} />
          <span>{isBn ? 'এআই সহকারী' : 'AI Assistant'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('approvals')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 relative ${
            activeSubTab === 'approvals'
              ? 'bg-white dark:bg-slate-900 text-violet-600 dark:text-violet-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <CheckCircle2 size={14} />
          <span>{isBn ? 'অনুমোদন পেন্ডিং' : 'Approvals'}</span>
          {pendingCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-violet-600 text-white text-[10px] font-black">
              {pendingCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('security')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeSubTab === 'security'
              ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <ShieldCheck size={14} />
          <span>{isBn ? 'নিরাপত্তা শিল্ড' : 'Security Shield'}</span>
        </button>
      </div>

      {/* VIEW 1: AI Assistant Interactive Chat & Executive Brain */}
      {activeSubTab === 'assistant' && (
        <div className="space-y-4">
          {/* Dynamic Weather Widget with °C and Rain/Cold/Wind/Heat Animations */}
          <HabivioWeatherWidget isBn={isBn} />

          {/* 24/7 Supervisor Status Banner */}
          <div className="p-4 rounded-3xl bg-linear-to-r from-violet-50 to-indigo-50 dark:from-violet-950/30 dark:to-indigo-950/30 border border-violet-200/80 dark:border-violet-800/50 flex items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-violet-600 text-white flex items-center justify-center shadow-md shadow-violet-500/25 shrink-0">
                <Eye size={20} className="animate-pulse" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                  {isBn ? '২৪ ঘণ্টার ডিজিটাল তত্ত্বাবধায়ক সক্রিয়' : '24/7 Active Supervisor Guard'}
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-tight mt-0.5">
                  {isBn
                    ? 'ওয়াক্ত শেষ হওয়ার সময়, পেন্ডিং কাজ ও দৈনন্দিন অভ্যাস সার্বক্ষণিক পর্যবেক্ষণে রয়েছে।'
                    : 'Monitoring waqt deadlines, unfinished tasks, and habits throughout the day.'}
                </p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="px-2.5 py-1 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-black text-[11px] inline-flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                {isBn ? 'সক্রিয়' : 'Online'}
              </span>
            </div>
          </div>

          {/* 1-Sentence Quick AI Multi-Action Cards (এক কথায় এআই সহকারী সমাধান) */}
          <div className="space-y-2 font-bangla-display">
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <Sparkles size={14} className="text-violet-500 animate-pulse" />
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
                  {isBn ? 'এক কথায় এআই কমান্ড (১-ট্যাপে সক্রিয়)' : '1-Sentence AI Quick Actions (1-Tap)'}
                </h3>
              </div>
              <span className="text-[10px] text-violet-600 dark:text-violet-400 font-bold">
                {isBn ? 'স্বয়ংক্রিয় প্রস্তুতকরণ' : 'Instant AI Setup'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* 1. কাজ যুক্ত করুন */}
              <button
                type="button"
                onClick={() => handleSendMessage('কাজ যুক্ত করুন')}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-violet-500/60 dark:hover:border-violet-500/60 shadow-xs hover:shadow-md transition-all text-left group flex items-start gap-3 active:scale-[0.98] cursor-pointer"
              >
                <div className="w-9 h-9 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0 text-lg group-hover:scale-110 transition-transform">
                  📋
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                      {isBn ? 'কাজ যুক্ত করুন' : 'Add Task'}
                    </h4>
                    <span className="text-[10px] text-violet-500 font-extrabold opacity-0 group-hover:opacity-100 transition-opacity">
                      {isBn ? 'চালান →' : 'Run →'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5 font-medium">
                    Organize today or plan an upcoming milestone
                  </p>
                </div>
              </button>

              {/* 2. নতুন অভ্যাস */}
              <button
                type="button"
                onClick={() => handleSendMessage('নতুন অভ্যাস')}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-emerald-500/60 dark:hover:border-emerald-500/60 shadow-xs hover:shadow-md transition-all text-left group flex items-start gap-3 active:scale-[0.98] cursor-pointer"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 text-lg group-hover:scale-110 transition-transform">
                  🔁
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {isBn ? 'নতুন অভ্যাস' : 'New Habit'}
                    </h4>
                    <span className="text-[10px] text-emerald-500 font-extrabold opacity-0 group-hover:opacity-100 transition-opacity">
                      {isBn ? 'চালান →' : 'Run →'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5 font-medium">
                    Track daily disciplines & streak momentum
                  </p>
                </div>
              </button>

              {/* 3. নতুন লক্ষ্য */}
              <button
                type="button"
                onClick={() => handleSendMessage('নতুন লক্ষ্য')}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-sky-500/60 dark:hover:border-sky-500/60 shadow-xs hover:shadow-md transition-all text-left group flex items-start gap-3 active:scale-[0.98] cursor-pointer"
              >
                <div className="w-9 h-9 rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 text-lg group-hover:scale-110 transition-transform">
                  🎯
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                      {isBn ? 'নতুন লক্ষ্য' : 'New Goal'}
                    </h4>
                    <span className="text-[10px] text-sky-500 font-extrabold opacity-0 group-hover:opacity-100 transition-opacity">
                      {isBn ? 'চালান →' : 'Run →'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5 font-medium">
                    Set ambitious targets with actionable milestones
                  </p>
                </div>
              </button>

              {/* 4. নামাজ আদায় রেকর্ড করুন */}
              <button
                type="button"
                onClick={() => handleSendMessage('নামাজ আদায় রেকর্ড করুন')}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-amber-500/60 dark:hover:border-amber-500/60 shadow-xs hover:shadow-md transition-all text-left group flex items-start gap-3 active:scale-[0.98] cursor-pointer"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 text-lg group-hover:scale-110 transition-transform">
                  🕌
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                      {isBn ? 'নামাজ আদায় রেকর্ড করুন' : 'Log Prayers & Dhikr'}
                    </h4>
                    <span className="text-[10px] text-amber-500 font-extrabold opacity-0 group-hover:opacity-100 transition-opacity">
                      {isBn ? 'চালান →' : 'Run →'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5 font-medium">
                    Track 5 daily prayers, Quran & Dhikr
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/* Chat Messages Container with Robust History Manager & Tool-Calling Cards */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex flex-col h-[460px]">
            {/* Conversation Header & Management Toolbar */}
            <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-slate-100 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
                  <Layers size={13} />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {messages.length} {isBn ? 'টি বার্তা সংরক্ষিত' : 'messages'}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold hidden sm:inline">
                    {isBn ? 'জেমিনি টুল-কলিং সক্রিয়' : 'Gemini Tools Active'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsSearching((prev) => !prev)}
                  className={`p-1.5 rounded-lg text-slate-500 hover:text-violet-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all ${
                    isSearching ? 'text-violet-600 bg-violet-50 dark:bg-violet-950/50' : ''
                  }`}
                  title={isBn ? 'বার্তা খুঁজুন' : 'Search chat'}
                >
                  <Search size={13} />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(isBn ? 'আপনি কি বর্তমান কথোপকথনের ইতিহাস মুছে ফেলে নতুন চ্যাট শুরু করতে চান?' : 'Start a fresh conversation and reset history?')) {
                      handleClearHistory();
                    }
                  }}
                  className="px-2 py-1 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-[11px] font-bold flex items-center gap-1 transition-all"
                  title={isBn ? 'নতুন চ্যাট শুরু করুন' : 'Start new chat'}
                >
                  <RotateCcw size={12} />
                  <span>{isBn ? 'নতুন চ্যাট' : 'New Chat'}</span>
                </button>
              </div>
            </div>

            {/* Optional In-Chat Search Bar */}
            {isSearching && (
              <div className="mb-2 pb-2 border-b border-slate-100 dark:border-slate-800 animate-in fade-in">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isBn ? 'কথোপকথন খুঁজুন...' : 'Search conversation...'}
                  className="w-full px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-1 focus:ring-violet-500"
                />
              </div>
            )}

            {/* Scrollable Messages Stream */}
            <div className="flex-1 overflow-y-auto space-y-3.5 pr-1">
              {messages
                .filter((m) => !searchQuery || m.text.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[88%] rounded-3xl p-3.5 text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-violet-600 text-white rounded-br-xs shadow-md shadow-violet-500/15'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-xs border border-slate-200/60 dark:border-slate-700/60'
                      }`}
                    >
                      <p className="whitespace-pre-line font-medium">{msg.text}</p>

                      {/* Tool Actions Card if triggered */}
                      {msg.actions && msg.actions.length > 0 && (
                        <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 space-y-2">
                          <div className="text-[11px] font-bold text-violet-600 dark:text-violet-400 flex items-center justify-between">
                            <span className="flex items-center gap-1">
                              <Wand2 size={12} />
                              <span>{isBn ? 'প্রস্তাবিত এআই অ্যাকশনসমূহ:' : 'Prepared AI Actions:'}</span>
                            </span>
                            {msg.toolSource && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-violet-100 dark:bg-violet-950/70 text-violet-700 dark:text-violet-300">
                                {msg.toolSource}
                              </span>
                            )}
                          </div>

                          {msg.actions.map((act) => (
                            <div
                              key={act.id}
                              className="p-3 rounded-2xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-700 text-[11px] space-y-2 shadow-xs"
                            >
                              <div className="flex items-start justify-between gap-1.5">
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-indigo-100 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300">
                                      ⚡ {act.toolInvoked || act.type}
                                    </span>
                                    {act.payload?.ringtone && (
                                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 flex items-center gap-0.5">
                                        <Volume2 size={9} />
                                        <span>{act.payload.ringtone}</span>
                                      </span>
                                    )}
                                  </div>
                                  <p className="font-black text-slate-900 dark:text-white mt-1 text-xs">
                                    {act.title}
                                  </p>
                                  {act.description && (
                                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                                      {act.description}
                                    </p>
                                  )}
                                </div>
                              </div>

                              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                                {act.status === 'pending' ? (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => handleApproveAction(act)}
                                      className="flex-1 py-1.5 px-3 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-xs"
                                    >
                                      <Check size={13} />
                                      <span>{isBn ? 'অনুমোদন দিন ও কার্যকর করুন' : 'Approve & Execute'}</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleRejectAction(act.id)}
                                      className="py-1.5 px-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-400 font-bold text-xs transition-all"
                                    >
                                      {isBn ? 'বাতিল' : 'Reject'}
                                    </button>
                                  </>
                                ) : act.status === 'approved' ? (
                                  <span className="w-full py-1.5 px-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 font-black text-xs flex items-center justify-center gap-1.5">
                                    <CheckCircle2 size={13} className="text-emerald-500" />
                                    <span>{isBn ? 'সফলভাবে কার্যকর করা হয়েছে' : 'Successfully Executed'}</span>
                                  </span>
                                ) : (
                                  <span className="w-full py-1.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 text-center font-bold text-xs">
                                    {isBn ? 'বাতিলকৃত' : 'Rejected'}
                                  </span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {msg.securityNote && (
                        <div className="mt-2 text-[10px] text-slate-400 dark:text-slate-500 font-semibold flex items-center gap-1">
                          <Lock size={10} />
                          <span>{msg.securityNote}</span>
                        </div>
                      )}
                    </div>

                    <span className="text-[10px] text-slate-400 mt-1 px-1">{msg.timestamp}</span>
                  </div>
                ))}

              {/* Multi-Stage Progressive Loading State */}
              {isProcessing && (
                <div className="flex flex-col items-start gap-1.5 animate-in fade-in duration-200">
                  <div className="p-3.5 rounded-3xl rounded-bl-xs bg-slate-100 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-700 dark:text-slate-200 max-w-[85%] space-y-2 shadow-xs">
                    <div className="flex items-center gap-2 font-bold text-violet-600 dark:text-violet-400">
                      <RefreshCw size={13} className="animate-spin shrink-0" />
                      <span className="truncate">
                        {loadingStage === 'analyzing'
                          ? (isBn ? '🧠 আপনার বার্তা বিশ্লেষণ করা হচ্ছে...' : '🧠 Analyzing your message...')
                          : loadingStage === 'checking_context'
                          ? (isBn ? '📋 টাস্ক ও রুটিন তালিকা যাচাই করা হচ্ছে...' : '📋 Checking schedule & tasks...')
                          : (isBn ? '⚡ জেমিনি এআই টুল ও অ্যাকশন প্রস্তুত হচ্ছে...' : '⚡ Preparing Gemini tools & actions...')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-600 animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-600 animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-600 animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {isBn ? 'জেমিনি ৩.৮ ফ্ল্যাশ টুল-কলিং' : 'Gemini 3.8 Flash'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Conversational Action Starters Row */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {[
                { labelBn: '⏰ সকাল ৬টায় পাখির সুরে ওয়েক-আপ অ্যালার্ম', labelEn: '⏰ 6:00 AM Wake-up alarm with birdsong', text: isBn ? 'আগামীকাল সকাল ৬টায় আমাকে ভোরের পাখির সুরে ঘুম থেকে উঠিয়ে দিও' : 'Set wake up alarm for tomorrow at 6:00 AM with birdsong' },
                { labelBn: '💊 দুপুরের খাওয়ার আগে ওষুধ রিমাইন্ডার', labelEn: '💊 Medicine reminder before lunch', text: isBn ? 'দুপুরের খাবার ৩০ মিনিট আগে ওষুধ খাওয়ার রিমাইন্ডার দাও' : 'Set a reminder to take medicine 30 mins before lunch' },
                { labelBn: '📋 আজকের কাজগুলো কী কী?', labelEn: '📋 What are my tasks today?', text: isBn ? 'আমার আজকের কাজগুলো কী কী?' : 'Show my tasks for today' },
                { labelBn: '✅ ব্যবসার পরিকল্পনা সম্পন্ন করো', labelEn: '✅ Complete business plan', text: isBn ? 'আজকের ব্যবসার পরিকল্পনা শেষ হয়েছে, এটা কমপ্লিট করো' : 'Mark business plan task as completed' },
                { labelBn: '🕌 নামাজের ওয়াক্তে অ্যালার্ম', labelEn: '🕌 Prayer reminder', text: isBn ? 'নামাজের ওয়াক্তের ৫ মিনিট আগে আজানের সুরে রিমাইন্ডার দাও' : 'Remind me 5 minutes before prayer with spiritual adhan' },
              ].map((item, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSendMessage(item.text)}
                  className="shrink-0 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-[11px] font-semibold text-slate-700 dark:text-slate-300 transition-all active:scale-95"
                >
                  {isBn ? item.labelBn : item.labelEn}
                </button>
              ))}
            </div>

            {/* Message Input Box */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="mt-2 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={
                  isBn
                    ? 'আমাকে যেকোনো নির্দেশ দিন (যেমন: কাল সকাল ৬টায় পাখির সুরে অ্যালার্ম দাও)...'
                    : 'Command the assistant (e.g. Set alarm at 6:00 AM with birdsong)...'
                }
                className="flex-1 py-2.5 px-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-violet-500 border border-slate-200 dark:border-slate-700"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isProcessing}
                className="p-2.5 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white disabled:opacity-40 transition-all active:scale-95 shadow-md shadow-violet-500/25 shrink-0"
                aria-label="Send"
              >
                <Send size={16} />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* VIEW 2: Actions Pending Approval ("আমার অনুমতি নিয়ে") */}
      {activeSubTab === 'approvals' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-800/50 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
            <Lock size={16} className="shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
            <p className="leading-relaxed">
              {isBn
                ? '🔒 কঠোর নিরাপত্তা নীতি: আপনার সুস্পষ্ট অনুমোদন ব্যতিরেকে এআই সহকারী কোনো কাজ, নামাজ বা রুটিনে পরিবর্তন ঘটাবে না। নিচে প্রতিটি প্রস্তাব পরীক্ষা করে সিদ্ধান্ত দিন।'
                : '🔒 Strict Authorization Policy: The AI will never modify your schedule or records without your explicit approval. Review and approve below.'}
            </p>
          </div>

          {pendingActions.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-2">
              <CheckCircle2 size={32} className="text-emerald-500 mx-auto" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {isBn ? 'কোনো অনুমোদন বাকি নেই!' : 'No Pending Approvals!'}
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {isBn
                  ? 'আপনার সমস্ত কাজ ও রেকর্ড সম্পূর্ণ আপ-টু-ডেট এবং আপনার পূর্ণ নিয়ন্ত্রণে রয়েছে।'
                  : 'All your schedules and records are up to date and under your control.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingActions.map((action) => {
                const isPending = action.status === 'pending';
                const isApproved = action.status === 'approved';

                return (
                  <div
                    key={action.id}
                    className={`p-5 rounded-3xl border transition-all ${
                      isApproved
                        ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800/50 opacity-80'
                        : action.status === 'rejected'
                        ? 'bg-slate-100 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 opacity-60'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm hover:border-violet-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-lg bg-violet-100 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 text-[10px] font-black uppercase tracking-wider">
                            {action.type === 'create_task'
                              ? isBn ? 'নতুন কাজ' : 'New Task'
                              : action.type === 'log_prayer'
                              ? isBn ? 'নামাজ আদায়' : 'Log Prayer'
                              : action.type === 'reschedule_task'
                              ? isBn ? 'রিশিডিউল' : 'Reschedule'
                              : isBn ? 'অভ্যাস' : 'Habit'}
                          </span>
                          <span className="text-[10px] text-slate-400">{action.createdAt}</span>
                        </div>

                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {action.title}
                        </h4>

                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                          {action.description}
                        </p>
                      </div>

                      {isPending && (
                        <div className="flex flex-col sm:flex-row gap-2 shrink-0">
                          <button
                            onClick={() => handleApproveAction(action)}
                            className="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95"
                          >
                            <Check size={14} />
                            <span>{isBn ? 'অনুমোদন দিন' : 'Approve'}</span>
                          </button>
                          <button
                            onClick={() => handleRejectAction(action.id)}
                            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-200 transition-all"
                          >
                            <XCircle size={14} />
                            <span>{isBn ? 'বাতিল' : 'Reject'}</span>
                          </button>
                        </div>
                      )}

                      {isApproved && (
                        <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold text-xs shrink-0">
                          <CheckCircle2 size={16} />
                          <span>{isBn ? 'অনুমোদিত' : 'Executed'}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 3: Cyber Security & Zero-Leakage Privacy Shield */}
      {activeSubTab === 'security' && (
        <div className="space-y-4">
          {/* Main Security Status Card */}
          <div className="p-6 rounded-3xl bg-linear-to-br from-emerald-950 via-slate-900 to-black border border-emerald-500/40 text-white shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck size={28} className="text-emerald-400" />
                <div>
                  <h3 className="text-base font-black tracking-tight text-white">
                    {isBn ? 'সাইবার নিরাপত্তা ও অ্যান্টি-ভাইরাস শিল্ড' : 'Cyber Security & Anti-Threat Shield'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isBn ? `সর্বশেষ স্ক্যান: ${lastScanTime}` : `Last scan: ${lastScanTime}`}
                  </p>
                </div>
              </div>

              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black uppercase tracking-wider border border-emerald-500/30">
                {isBn ? '১০০% সুরক্ষিত' : 'Protected'}
              </span>
            </div>

            {/* Scan Progress Bar if active */}
            {isScanning && (
              <div className="space-y-1.5 animate-in fade-in">
                <div className="flex justify-between text-xs text-emerald-300 font-bold">
                  <span>{isBn ? 'ভাইরাস, স্ক্রিপ্ট ও এনক্রিপশন স্ক্যানিং চলছে...' : 'Scanning system integrity...'}</span>
                  <span>{scanProgress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-linear-to-r from-emerald-500 to-sky-400 transition-all duration-300"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Interactive Scan Action */}
            <button
              onClick={handleTriggerSecurityScan}
              disabled={isScanning}
              className="w-full py-3 px-4 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-95 disabled:opacity-50"
            >
              <RefreshCw size={14} className={isScanning ? 'animate-spin' : ''} />
              <span>
                {isScanning
                  ? isBn ? 'স্ক্যানিং সম্পন্ন হচ্ছে...' : 'Scanning in progress...'
                  : isBn ? 'নতুন সাইবার ও ম্যালওয়্যার স্ক্যান চালান' : 'Run Full Anti-Malware Scan'}
              </span>
            </button>
          </div>

          {/* 4 Pillars of Habivio Security */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                <Shield size={18} />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {isBn ? 'ভাইরাস ও ম্যালওয়্যার প্রতিরোধ' : 'Anti-Malware & Virus Guard'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {isBn
                  ? 'ব্রাউজার স্যান্ডবক্সড সুরক্ষা। কোনো ক্ষতিকর ভাইরাস, ট্রোজান বা স্ক্রিপ্ট ইনজেকশন কার্যকর হতে পারে না।'
                  : 'Sandboxed runtime environment preventing malicious scripts, trojans, or injected payloads.'}
              </p>
              <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Check size={12} />
                <span>{threatCount} {isBn ? 'টি হুমকি শনাক্ত (ক্লিন)' : 'threats detected (Clean)'}</span>
              </div>
            </div>

            <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-sky-600 dark:text-sky-400">
                <Database size={18} />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {isBn ? 'জিরো ডেটা লিক ও লোকাল ভল্ট' : 'Zero-Exfiltration Local Vault'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {isBn
                  ? 'আপনার কোনো ব্যক্তিগত কাজ, নামাজ বা দিনলিপি বহিঃস্থ সার্ভারে বিক্রি বা পাঠানো হয় না। ১০০% তথ্য ডিভাইসে সংরক্ষিত।'
                  : 'All private logs, prayers, and goals reside solely in your local device vault. Never sold or shared.'}
              </p>
              <div className="text-[11px] font-bold text-sky-600 dark:text-sky-400 flex items-center gap-1">
                <Check size={12} />
                <span>{isBn ? 'আইসোলেটেড অফলাইন স্টোরেজ' : 'Isolated Offline Storage'}</span>
              </div>
            </div>

            <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                <KeyRound size={18} />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {isBn ? 'অ্যান্টি-হ্যাকিং ফায়ারওয়াল' : 'Anti-Hacking Firewall'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {isBn
                  ? 'ক্রস-সাইট স্ক্রিপ্টিং (XSS) ও সেশন হাইজ্যাকিং প্রতিহত করতে স্বয়ংক্রিয় প্রটেকশন রুল সক্রিয়।'
                  : 'Guarded against Cross-Site Scripting (XSS) and unauthorized iframe hijacking.'}
              </p>
              <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                <Check size={12} />
                <span>{isBn ? 'ফায়ারওয়াল সক্রিয়' : 'Firewall Active'}</span>
              </div>
            </div>

            <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex items-center gap-2 text-violet-600 dark:text-violet-400">
                <Eye size={18} />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {isBn ? '২৪ ঘণ্টার ব্যক্তিগত নজরদারি' : '24/7 Digital Guardian'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {isBn
                  ? 'আপনার দৈনন্দিন লক্ষ্য, নামাজের সময় ও কাজের নিরাপত্তা বজায় রাখতে এআই সার্বক্ষণিক জাগ্রত।'
                  : 'AI guardian continuously monitors schedule adherence and data integrity round the clock.'}
              </p>
              <div className="text-[11px] font-bold text-violet-600 dark:text-violet-400 flex items-center gap-1">
                <Check size={12} />
                <span>{isBn ? 'সার্বক্ষণিক অ্যালার্ট সক্রিয়' : 'Round-the-clock Alerts Active'}</span>
              </div>
            </div>
          </div>

          {/* Backup & Data Vault Actions */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-3">
            <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
              {isBn ? 'এনক্রিপ্টেড ব্যাকআপ ও লোকাল ডেটা ব্যবস্থাপনা' : 'Encrypted Backup & Vault Operations'}
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              {isBn
                ? 'আপনার ডিভাইসে সংরক্ষিত সমস্ত ডেটা এক ক্লিকে ব্যাকআপ ফাইল হিসেবে ডাউনলোড বা রিস্টোর করতে পারবেন।'
                : 'Download an encrypted JSON snapshot of your data or restore at any time.'}
            </p>

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                onClick={() => {
                  const dataStr = exportData();
                  const blob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `habivio-backup-${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  triggerCelebration(0.5);
                }}
                className="py-2 px-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 hover:border-violet-400 flex items-center gap-1.5 transition-all"
              >
                <Download size={14} className="text-violet-500" />
                <span>{isBn ? 'এনক্রিপ্টেড ব্যাকআপ ডাউনলোড' : 'Download Backup'}</span>
              </button>

              <label className="py-2 px-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 hover:border-violet-400 flex items-center gap-1.5 transition-all cursor-pointer">
                <Upload size={14} className="text-emerald-500" />
                <span>{isBn ? 'ব্যাকআপ রিস্টোর করুন' : 'Restore Backup'}</span>
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const content = event.target?.result as string;
                        if (content && importData(content)) {
                          triggerBigCelebration();
                        }
                      };
                      reader.readAsText(file);
                    }
                  }}
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
