import { useMemo } from "react";

const HEARTS = ["💗", "💖", "💕", "✨", "🌸", "💞"];
const CONFETTI = ["💗", "✨", "🎉", "💖", "🌸", "🎊", "⭐"];

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

/** Soft translucent emojis drifting upward behind everything. */
export function FloatingHearts({ count = 14 }: { count?: number }) {
  const items = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        char: HEARTS[i % HEARTS.length],
        left: rand(2, 96),
        size: rand(14, 30),
        duration: rand(11, 22),
        delay: -rand(0, 20),
      })),
    [count],
  );

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* ambient glows */}
      <div className="absolute -top-32 -left-24 h-96 w-96 rounded-full bg-[#FF3EA5]/15 blur-[110px]" />
      <div className="absolute -right-24 -bottom-32 h-96 w-96 rounded-full bg-[#8A2BE2]/20 blur-[110px]" />

      {items.map((h) => (
        <span
          key={h.id}
          className="absolute -bottom-10 animate-float-up select-none"
          style={{
            left: `${h.left}%`,
            fontSize: h.size,
            animationDuration: `${h.duration}s`,
            animationDelay: `${h.delay}s`,
          }}
        >
          {h.char}
        </span>
      ))}
    </div>
  );
}

/** Celebratory emoji confetti for the final screen. */
export function Confetti({ count = 26 }: { count?: number }) {
  const items = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        char: CONFETTI[i % CONFETTI.length],
        left: rand(0, 98),
        size: rand(16, 28),
        duration: rand(4, 8),
        delay: -rand(0, 8),
      })),
    [count],
  );

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-20 overflow-hidden">
      {items.map((c) => (
        <span
          key={c.id}
          className="absolute top-0 animate-confetti select-none"
          style={{
            left: `${c.left}%`,
            fontSize: c.size,
            animationDuration: `${c.duration}s`,
            animationDelay: `${c.delay}s`,
          }}
        >
          {c.char}
        </span>
      ))}
    </div>
  );
}
