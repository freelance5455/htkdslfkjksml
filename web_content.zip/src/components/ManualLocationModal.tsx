import React, { useState, useEffect } from 'react';
import {
  X,
  MapPin,
  Globe,
  Compass,
  Check,
  Navigation,
  HelpCircle,
} from 'lucide-react';
import { LocationPreset } from '../types';

interface ManualLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation: LocationPreset;
  onSaveLocation: (newLocation: LocationPreset) => void;
}

const COMMON_TIMEZONES = [
  { value: 'Asia/Jerusalem', label: 'Asia/Jerusalem (Israel Standard Time)' },
  { value: 'America/New_York', label: 'America/New_York (Eastern Time: NY, Lakewood, Miami)' },
  { value: 'America/Chicago', label: 'America/Chicago (Central Time: Chicago, Dallas)' },
  { value: 'America/Denver', label: 'America/Denver (Mountain Time: Denver, Phoenix)' },
  { value: 'America/Los_Angeles', label: 'America/Los_Angeles (Pacific Time: LA, SF)' },
  { value: 'America/Toronto', label: 'America/Toronto (Canada Eastern)' },
  { value: 'Europe/London', label: 'Europe/London (GMT/BST: London, Manchester)' },
  { value: 'Europe/Paris', label: 'Europe/Paris (CET: Paris, Antwerp, Strasbourg)' },
  { value: 'Europe/Zurich', label: 'Europe/Zurich (CET: Zurich, Basel)' },
  { value: 'Europe/Rome', label: 'Europe/Rome (CET: Rome, Milan)' },
  { value: 'Europe/Amsterdam', label: 'Europe/Amsterdam (CET: Amsterdam)' },
  { value: 'Europe/Moscow', label: 'Europe/Moscow (MSK: Moscow)' },
  { value: 'Asia/Dubai', label: 'Asia/Dubai (GST: Dubai)' },
  { value: 'Australia/Sydney', label: 'Australia/Sydney (AEST: Sydney, Melbourne)' },
  { value: 'America/Sao_Paulo', label: 'America/Sao_Paulo (BRT: Sao Paulo)' },
  { value: 'America/Buenos_Aires', label: 'America/Buenos_Aires (ART: Buenos Aires)' },
  { value: 'Africa/Johannesburg', label: 'Africa/Johannesburg (SAST: Johannesburg)' },
];

export const ManualLocationModal: React.FC<ManualLocationModalProps> = ({
  isOpen,
  onClose,
  currentLocation,
  onSaveLocation,
}) => {
  const [name, setName] = useState(currentLocation.name || '');
  const [nameHe, setNameHe] = useState(currentLocation.nameHe || '');
  const [country, setCountry] = useState(currentLocation.country || '');
  const [lat, setLat] = useState<string>(currentLocation.lat ? String(currentLocation.lat) : '31.7683');
  const [long, setLong] = useState<string>(currentLocation.long ? String(currentLocation.long) : '35.2137');
  const [elevation, setElevation] = useState<string>(
    currentLocation.elevation !== undefined ? String(currentLocation.elevation) : '0'
  );
  const [timezone, setTimezone] = useState<string>(currentLocation.timezone || 'Asia/Jerusalem');
  const [isIsrael, setIsIsrael] = useState<boolean>(currentLocation.isIsrael ?? true);
  const [candleLightingOffset, setCandleLightingOffset] = useState<number>(
    currentLocation.candleLightingOffset || 18
  );
  const [isCustomTz, setIsCustomTz] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setName(currentLocation.name || '');
      setNameHe(currentLocation.nameHe || '');
      setCountry(currentLocation.country || '');
      setLat(String(currentLocation.lat ?? 31.7683));
      setLong(String(currentLocation.long ?? 35.2137));
      setElevation(String(currentLocation.elevation ?? 0));
      setTimezone(currentLocation.timezone || 'Asia/Jerusalem');
      setIsIsrael(currentLocation.isIsrael ?? false);
      setCandleLightingOffset(currentLocation.candleLightingOffset || 18);
      setValidationError(null);
    }
  }, [isOpen, currentLocation]);

  if (!isOpen) return null;

  const handleFetchGPS = async () => {
    setGpsLoading(true);
    setValidationError(null);

    const tryIPFallback = async (reason: string) => {
      console.log(`Manual modal GPS failed (${reason}). Trying secure IP fallback...`);
      try {
        const res = await fetch('https://freeipapi.com/api/json');
        if (!res.ok) throw new Error('freeipapi failed');
        const data = await res.json();
        
        const detectedLat = Number(data.latitude || 31.7683);
        const detectedLong = Number(data.longitude || 35.2137);
        const inIsrael = detectedLat > 29 && detectedLat < 33.5 && detectedLong > 34 && detectedLong < 36;
        const systemTz = data.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem';

        setLat(String(detectedLat));
        setLong(String(detectedLong));
        setElevation('0');
        setTimezone(systemTz);
        setIsIsrael(inIsrael);
        
        const placeName = data.cityName ? data.cityName : 'My Location (IP)';
        setName(placeName);
        setNameHe(inIsrael ? 'מיקום נוכחי (IP)' : 'מיקום נוכחי');
        setCountry(data.countryName || (inIsrael ? 'Israel' : 'Local'));
        
        setGpsLoading(false);
      } catch (err1) {
        console.warn('FreeIPAPI failed in modal, trying secondary fallback...', err1);
        try {
          const res = await fetch('https://ipapi.co/json/');
          if (!res.ok) throw new Error('ipapi failed');
          const data = await res.json();
          
          const detectedLat = Number(data.latitude || 31.7683);
          const detectedLong = Number(data.longitude || 35.2137);
          const inIsrael = detectedLat > 29 && detectedLat < 33.5 && detectedLong > 34 && detectedLong < 36;
          const systemTz = data.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem';

          setLat(String(detectedLat));
          setLong(String(detectedLong));
          setElevation('0');
          setTimezone(systemTz);
          setIsIsrael(inIsrael);
          
          const placeName = data.city ? data.city : 'My Location (IP)';
          setName(placeName);
          setNameHe(inIsrael ? 'מיקום נוכחי (IP)' : 'מיקום נוכחי');
          setCountry(data.country_name || (inIsrael ? 'Israel' : 'Local'));
          
          setGpsLoading(false);
        } catch (err2) {
          console.error('All modal location fallbacks failed:', err2);
          setGpsLoading(false);
          setValidationError('Could not retrieve coordinates automatically. Please enter coordinates manually.');
        }
      }
    };

    if (!navigator.geolocation) {
      await tryIPFallback('Geolocation API not supported');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const detectedLat = Number(pos.coords.latitude.toFixed(4));
        const detectedLong = Number(pos.coords.longitude.toFixed(4));
        const detectedElev = pos.coords.altitude ? Math.round(pos.coords.altitude) : 0;
        const systemTz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem';
        const inIsrael =
          detectedLat > 29 &&
          detectedLat < 33.5 &&
          detectedLong > 34 &&
          detectedLong < 36;

        setLat(String(detectedLat));
        setLong(String(detectedLong));
        setElevation(String(detectedElev));
        setTimezone(systemTz);
        setIsIsrael(inIsrael);
        if (inIsrael && !name) {
          setName('My Location (Israel)');
          setNameHe('מיקום נוכחי (ישראל)');
          setCountry('Israel');
        } else if (!name) {
          setName(`Location (${detectedLat}°, ${detectedLong}°)`);
          setNameHe('מיקום מותאם אישית');
          setCountry('Local');
        }
        setGpsLoading(false);
      },
      async (err) => {
        console.warn('Native GPS failed in modal, triggering IP fallback', err);
        await tryIPFallback(err.message || 'Permission denied/timeout');
      },
      { timeout: 6000, enableHighAccuracy: true }
    );
  };

  const handleAutoFillIsrael = (e: boolean) => {
    setIsIsrael(e);
    if (e && (candleLightingOffset === 18 || !candleLightingOffset)) {
      setCandleLightingOffset(20);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parsedLat = parseFloat(lat);
    const parsedLong = parseFloat(long);
    const parsedElev = parseFloat(elevation) || 0;

    if (isNaN(parsedLat) || parsedLat < -90 || parsedLat > 90) {
      setValidationError('Please enter a valid Latitude between -90 and 90 degrees.');
      return;
    }

    if (isNaN(parsedLong) || parsedLong < -180 || parsedLong > 180) {
      setValidationError('Please enter a valid Longitude between -180 and 180 degrees.');
      return;
    }

    if (!name.trim()) {
      setValidationError('Please provide a name for this location.');
      return;
    }

    if (!timezone.trim()) {
      setValidationError('Please select or specify a valid IANA timezone (e.g. Asia/Jerusalem).');
      return;
    }

    const manualLoc: LocationPreset = {
      id: `custom-loc-${Date.now()}`,
      name: name.trim(),
      nameHe: nameHe.trim() || name.trim(),
      country: country.trim() || (isIsrael ? 'Israel' : 'Custom'),
      lat: parsedLat,
      long: parsedLong,
      elevation: parsedElev,
      timezone: timezone.trim(),
      isIsrael,
      candleLightingOffset,
    };

    onSaveLocation(manualLoc);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-lg w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#252525] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg shadow-xs">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#EAEAEA]">
                Set Custom / Manual Location
              </h3>
              <p className="text-xs text-[#888888]">
                Define custom coordinates, timezone, and Halachic parameters
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          {validationError && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300">
              {validationError}
            </div>
          )}

          {/* Quick GPS Auto-detect button */}
          <div className="p-3.5 rounded-xl bg-[#181818] border border-[#2A2A2A] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#C5A267]" />
              <span className="text-xs font-medium text-[#D1D1D1]">
                Auto-fill with device GPS
              </span>
            </div>
            <button
              type="button"
              onClick={handleFetchGPS}
              disabled={gpsLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#252525] hover:bg-[#303030] text-[#C5A267] border border-[#3A3A3A] text-xs font-semibold transition-colors disabled:opacity-50"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>{gpsLoading ? 'Detecting...' : 'Detect GPS'}</span>
            </button>
          </div>

          {/* City / Place Name English & Hebrew */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1">
                Location Name (English) *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Bet Shemesh, Monsey, Zurich"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1 text-right" dir="rtl">
                שם המיקום בעברית
              </label>
              <input
                type="text"
                placeholder="לדוגמה: בית שמש, מונסי, ציריך"
                dir="rtl"
                value={nameHe}
                onChange={(e) => setNameHe(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-hebrew text-right placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>
          </div>

          {/* Country */}
          <div>
            <label className="block text-xs font-semibold text-[#888888] mb-1">
              Country / Region
            </label>
            <input
              type="text"
              placeholder="e.g. Israel, USA, UK, Switzerland, France"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
            />
          </div>

          {/* Latitude & Longitude */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1">
                Latitude (°N / °S) *
              </label>
              <input
                type="number"
                step="any"
                required
                placeholder="e.g. 31.7683"
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#888888] mb-1">
                Longitude (°E / °W) *
              </label>
              <input
                type="number"
                step="any"
                required
                placeholder="e.g. 35.2137"
                value={long}
                onChange={(e) => setLong(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>
          </div>

          {/* Elevation */}
          <div>
            <label className="block text-xs font-semibold text-[#888888] mb-1">
              Elevation (Meters above sea level)
            </label>
            <input
              type="number"
              step="1"
              placeholder="e.g. 800 for Jerusalem, 0 for coastal"
              value={elevation}
              onChange={(e) => setElevation(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
            />
            <p className="text-[10px] text-[#666666] mt-1">
              Used for precise astronomical horizon correction (Netz / Shkiya).
            </p>
          </div>

          {/* Timezone Selection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-[#888888]">
                IANA Timezone *
              </label>
              <button
                type="button"
                onClick={() => setIsCustomTz(!isCustomTz)}
                className="text-[11px] text-[#C5A267] hover:underline"
              >
                {isCustomTz ? 'Select from list' : 'Type custom timezone'}
              </button>
            </div>

            {isCustomTz ? (
              <input
                type="text"
                placeholder="e.g. Asia/Jerusalem, America/New_York"
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono placeholder-[#666666] focus:border-[#C5A267] focus:outline-hidden"
              />
            ) : (
              <select
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              >
                {COMMON_TIMEZONES.map((tz) => (
                  <option key={tz.value} value={tz.value}>
                    {tz.label}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Halachic Israel & Candle Lighting Settings */}
          <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-3">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isIsrael}
                onChange={(e) => handleAutoFillIsrael(e.target.checked)}
                className="w-4 h-4 rounded border-[#3A3A3A] bg-[#1A1A1A] text-[#C5A267] focus:ring-0"
              />
              <span className="text-xs font-semibold text-[#EAEAEA]">
                Location is within Eretz Yisrael (Israel)
              </span>
            </label>
            <p className="text-[11px] text-[#888888] pl-6">
              Affects Halachic observance: 1 day Yom Tov (Israel) vs 2 days (Chutz La’Aretz), and Purim vs Shushan Purim rules.
            </p>

            <div className="pt-2 border-t border-[#2A2A2A]">
              <label className="block text-xs font-semibold text-[#888888] mb-1">
                Candle Lighting Offset (minutes before sunset)
              </label>
              <select
                value={candleLightingOffset}
                onChange={(e) => setCandleLightingOffset(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              >
                <option value={18}>18 minutes (Standard Diaspora / Tel Aviv)</option>
                <option value={20}>20 minutes (Tel Aviv / Haifa custom)</option>
                <option value={24}>24 minutes</option>
                <option value={30}>30 minutes (Safed / Tiberias custom)</option>
                <option value={40}>40 minutes (Jerusalem & Petach Tikva custom)</option>
              </select>
            </div>
          </div>

          {/* Footer Submit Buttons */}
          <div className="pt-3 border-t border-[#2A2A2A] flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#888888] hover:text-[#EAEAEA] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold shadow-sm transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>Apply Location</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
