import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Eye, 
  Heart, 
  Bookmark, 
  Share2, 
  AlertTriangle, 
  CheckCircle2, 
  FileCheck2, 
  Sparkles, 
  ZoomIn, 
  ZoomOut, 
  ChevronLeft, 
  ChevronRight, 
  Printer, 
  School, 
  MapPin, 
  Calendar, 
  ShieldCheck, 
  FileText
} from 'lucide-react';
import { Paper, Language, User } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface PaperDetailModalProps {
  paper: Paper | null;
  onClose: () => void;
  language: Language;
  onDownload: (paper: Paper) => void;
  onLikeToggle: (paperId: string) => void;
  isLiked: boolean;
  onBookmarkToggle: (paperId: string) => void;
  isBookmarked: boolean;
  onAskAi: (paper: Paper) => void;
  currentUser: User;
}

export const PaperDetailModal: React.FC<PaperDetailModalProps> = ({
  paper,
  onClose,
  language,
  onDownload,
  onLikeToggle,
  isLiked,
  onBookmarkToggle,
  isBookmarked,
  onAskAi,
  currentUser
}) => {
  if (!paper) return null;

  const t = TRANSLATIONS[language];
  const [currentPage, setCurrentPage] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [showMarkingSchemeView, setShowMarkingSchemeView] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [reportSubmitted, setReportSubmitted] = useState(false);

  const previewPages = paper.previewPagesText || [
    `EXAMINATION PAPER: ${paper.title}\nSubject: ${paper.subject} | Grade: ${paper.grade}\nMedium: ${paper.medium} | Year: ${paper.year}\nSchool: ${paper.school}\n\n[PART A] MULTIPLE CHOICE QUESTIONS\n1. Select the correct answer according to Sri Lankan curriculum guidelines.\n2. Verify all step-by-step solutions provided in the marking scheme.\n\n[PART B] ESSAY SECTION\n3. Derive equations and elaborate with real-world examples.`
  ];

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReportSubmitted(true);
    setTimeout(() => {
      setShowReportModal(false);
      setReportSubmitted(false);
      setReportReason('');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Top Header Bar */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-xs font-black rounded-lg bg-amber-500 text-slate-950 uppercase tracking-wider">
              {paper.grade}
            </span>
            <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-800 text-amber-300 border border-slate-700">
              {paper.subject}
            </span>
            <span className="text-xs font-semibold text-slate-400 hidden sm:inline">
              {paper.year} • {paper.medium} Medium
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onAskAi(paper)}
              className="px-3 py-1.5 text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-xl flex items-center gap-1.5 shadow-md shadow-amber-500/10 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Exam Breakdown</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body Grid (PDF Preview + Sidebar Metadata) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 overflow-y-auto divide-y lg:divide-y-0 lg:divide-x divide-slate-800 flex-1">
          
          {/* Main Interactive PDF Preview Canvas (2 columns on desktop) */}
          <div className="lg:col-span-2 p-5 bg-slate-950 flex flex-col justify-between space-y-4">
            
            {/* PDF Toolbar */}
            <div className="flex items-center justify-between bg-slate-900 px-4 py-2 rounded-2xl border border-slate-800 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <button
                  disabled={currentPage === 0}
                  onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                  className="p-1 text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="font-bold text-amber-400">
                  Page {currentPage + 1} / {previewPages.length}
                </span>
                <button
                  disabled={currentPage === previewPages.length - 1}
                  onClick={() => setCurrentPage((p) => Math.min(previewPages.length - 1, p + 1))}
                  className="p-1 text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-xl">
                  <button
                    onClick={() => setZoomLevel((z) => Math.max(75, z - 25))}
                    className="p-0.5 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[11px] font-bold text-slate-200">{zoomLevel}%</span>
                  <button
                    onClick={() => setZoomLevel((z) => Math.min(175, z + 25))}
                    className="p-0.5 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>

                {paper.hasMarkingScheme && (
                  <button
                    onClick={() => setShowMarkingSchemeView(!showMarkingSchemeView)}
                    className={`px-2.5 py-1 text-[11px] font-bold rounded-xl border transition-all cursor-pointer ${
                      showMarkingSchemeView
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                        : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {showMarkingSchemeView ? 'View Paper' : 'View Marking Scheme'}
                  </button>
                )}
              </div>
            </div>

            {/* Document Render Sheet */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner min-h-[380px] flex flex-col justify-between relative overflow-hidden">
              
              <div
                className="prose prose-invert max-w-none text-slate-200 font-mono text-xs leading-relaxed whitespace-pre-wrap transition-transform origin-top"
                style={{ transform: `scale(${zoomLevel / 100})` }}
              >
                {showMarkingSchemeView ? (
                  <div className="space-y-3">
                    <div className="text-emerald-400 font-bold border-b border-emerald-500/30 pb-2">
                      OFFICIAL MARKING SCHEME & ANSWER KEY
                    </div>
                    <p>Q1. Option (C) - Derivation of orbital velocity v = √(GM/R)</p>
                    <p>Q2. Part (A) Pure Mathematics: 10 marks awarded for induction proof base step + inductive hypothesis step.</p>
                    <p>Q3. Part (B) Applied Mathematics: Step 1 (3 marks), Step 2 (4 marks), Final Numerical Value (3 marks).</p>
                  </div>
                ) : (
                  previewPages[currentPage]
                )}
              </div>

              {/* Watermark */}
              <div className="absolute bottom-4 right-4 text-[10px] font-bold text-slate-700 uppercase tracking-widest pointer-events-none">
                LankaPaperHub Verified Document
              </div>
            </div>

            {/* Download Banner */}
            <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <div>
                <p className="text-xs font-bold text-white">{paper.fileFormat} File Format ({paper.fileSize})</p>
                <p className="text-[11px] text-slate-400">Contains complete question paper + marking guide</p>
              </div>

              <button
                onClick={() => onDownload(paper)}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer transition-all"
              >
                <Download className="w-4 h-4" />
                <span>{t.downloadBtn} ({paper.downloadCount})</span>
              </button>
            </div>

          </div>

          {/* Sidebar Metadata & Uploader Info */}
          <div className="p-6 bg-slate-900 space-y-6">
            
            {/* Paper Title */}
            <div>
              <h2 className="text-lg font-extrabold text-white leading-snug mb-2">
                {paper.title}
              </h2>
              <p className="text-xs text-slate-400">{paper.description}</p>
            </div>

            {/* Metadata Table */}
            <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.subject}:</span>
                <span className="font-bold text-amber-300">{paper.subject}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.grade}:</span>
                <span className="font-bold text-slate-200">{paper.grade}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.medium}:</span>
                <span className="font-bold text-slate-200">{paper.medium}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.year}:</span>
                <span className="font-bold text-slate-200">{paper.year}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.province}:</span>
                <span className="font-bold text-slate-200">{paper.province} Province</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">{t.school}:</span>
                <span className="font-bold text-slate-200 line-clamp-1">{paper.school}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">{t.hasAnswers}:</span>
                <span className={`font-bold ${paper.hasAnswers ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {paper.hasAnswers ? 'Yes' : 'No'}
                </span>
              </div>
            </div>

            {/* Tags */}
            <div className="space-y-1.5">
              <p className="text-xs font-bold text-slate-400">Tags & Topics:</p>
              <div className="flex flex-wrap gap-1.5">
                {paper.tags.map((tag, i) => (
                  <span key={i} className="px-2 py-1 text-[10px] font-semibold bg-slate-800 text-slate-300 rounded-lg border border-slate-700">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Uploader Card */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center gap-3">
              <img
                src={paper.uploaderAvatar}
                alt={paper.uploaderName}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/40"
              />
              <div>
                <p className="text-xs font-bold text-white flex items-center gap-1">
                  <span>{paper.uploaderName}</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                </p>
                <p className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">
                  {paper.uploaderRole} • Uploaded {paper.uploadedDate}
                </p>
              </div>
            </div>

            {/* Social Actions (Like, Bookmark, Report) */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => onLikeToggle(paper.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  isLiked
                    ? 'bg-rose-500 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                <span>{paper.likesCount} Likes</span>
              </button>

              <button
                onClick={() => onBookmarkToggle(paper.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  isBookmarked
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Bookmark className="w-4 h-4" />
                <span>{isBookmarked ? 'Saved' : 'Save'}</span>
              </button>

              <button
                onClick={() => setShowReportModal(true)}
                className="p-2 text-slate-400 hover:text-red-400 bg-slate-800 rounded-xl transition-all cursor-pointer"
                title="Report File"
              >
                <AlertTriangle className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl p-5 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span>Report Examination File</span>
            </h3>
            {reportSubmitted ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 text-center font-bold">
                Thank you. Your report has been submitted to platform moderators.
              </div>
            ) : (
              <form onSubmit={handleReportSubmit} className="space-y-3">
                <p className="text-xs text-slate-300">Why are you reporting this paper?</p>
                <textarea
                  required
                  rows={3}
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  placeholder="e.g. Incorrect subject details, poor scan quality, or wrong marking scheme..."
                  className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-500 text-white font-bold text-xs rounded-xl"
                  >
                    Submit Report
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
