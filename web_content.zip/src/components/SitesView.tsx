import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Site, Labour } from '../types';
import { formatCurrency, formatNumber, formatDateBengali, getRoleTypeBadge } from '../utils/formatters';
import { 
  Building2, 
  Plus, 
  Calendar, 
  Coins, 
  Users, 
  CheckCircle2, 
  Trash2, 
  CreditCard, 
  Wallet, 
  Phone, 
  MapPin, 
  FileText,
  Search,
  ArrowDownLeft,
  X
} from 'lucide-react';

export const SitesView: React.FC = () => {
  const { 
    sites, 
    labours, 
    attendance, 
    advances, 
    engineerPayments, 
    selectedSiteId, 
    setSelectedSiteId,
    addSite,
    updateSite,
    deleteSite,
    addAttendanceRecord,
    deleteAttendanceRecord,
    addLabourAdvance,
    deleteLabourAdvance,
    addEngineerPayment,
    deleteEngineerPayment
  } = useApp();

  // Modals
  const [showAddSiteModal, setShowAddSiteModal] = useState(false);
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [showEngineerPaymentModal, setShowEngineerPaymentModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Preselected labour for advance payment modal
  const [selectedLabourForAdvance, setSelectedLabourForAdvance] = useState<Labour | null>(null);

  // New Site Form State
  const [newSite, setNewSite] = useState<Omit<Site, 'id'>>({
    name: '',
    address: '',
    engineerName: '',
    engineerPhone: '',
    flatCommission: 50000,
    status: 'active',
    startDate: new Date().toISOString().slice(0, 10),
    targetEndDate: '',
    notes: ''
  });

  // Attendance Form State
  const [attForm, setAttForm] = useState({
    labourId: '',
    date: new Date().toISOString().slice(0, 10),
    daysWorked: 1,
    wageRate: 600,
    note: ''
  });

  // Advance Form State
  const [advForm, setAdvForm] = useState({
    labourId: '',
    date: new Date().toISOString().slice(0, 10),
    amount: 2000,
    paymentMethod: 'cash' as const,
    note: ''
  });

  // Engineer Payment Form State
  const [engForm, setEngForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    amount: 30000,
    paymentMethod: 'bank' as const,
    receiptNo: '',
    note: ''
  });

  // Selected site data
  const currentSite = sites.find(s => s.id === selectedSiteId) || sites[0];

  if (!currentSite) {
    return (
      <div className="bg-white p-8 rounded-xl border border-slate-200 text-center">
        <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-800">কোনো সাইট পাওয়া যায়নি</h3>
        <p className="text-sm text-slate-500 mb-4">অনুগ্রহ করে একটি নতুন সাইট তৈরি করুন।</p>
        <button
          onClick={() => setShowAddSiteModal(true)}
          className="px-4 py-2 bg-amber-600 text-white rounded-lg text-sm font-medium"
        >
          + নতুন সাইট যোগ করুন
        </button>
      </div>
    );
  }

  // Attendance and payments for current site
  const siteAttendance = attendance.filter(a => a.siteId === currentSite.id);
  const siteAdvances = advances.filter(a => a.siteId === currentSite.id);
  const siteEngPayments = engineerPayments.filter(p => p.siteId === currentSite.id);

  // Aggregate by labour on this site
  // Get all unique labours who either have attendance or are assigned to this site
  const siteLabourIds = Array.from(new Set([
    ...siteAttendance.map(a => a.labourId),
    ...labours.filter(l => l.assignedSiteId === currentSite.id).map(l => l.id)
  ]));

  const siteLaboursData = siteLabourIds.map(labId => {
    const labour = labours.find(l => l.id === labId);
    if (!labour) return null;

    const labourAtt = siteAttendance.filter(a => a.labourId === labId);
    const totalDaysWorked = labourAtt.reduce((sum, a) => sum + a.daysWorked, 0);
    const totalWagesEarned = labourAtt.reduce((sum, a) => sum + (a.daysWorked * a.wageRate), 0);

    const labourAdvances = siteAdvances.filter(a => a.labourId === labId);
    const totalAdvancePaid = labourAdvances.reduce((sum, a) => sum + a.amount, 0);
    const balanceDue = totalWagesEarned - totalAdvancePaid;

    return {
      labour,
      totalDaysWorked,
      totalWagesEarned,
      totalAdvancePaid,
      balanceDue,
      attendanceRecords: labourAtt,
      advanceRecords: labourAdvances
    };
  }).filter(Boolean) as {
    labour: Labour;
    totalDaysWorked: number;
    totalWagesEarned: number;
    totalAdvancePaid: number;
    balanceDue: number;
    attendanceRecords: typeof siteAttendance;
    advanceRecords: typeof siteAdvances;
  }[];

  // Totals for this site
  const totalSiteWages = siteLaboursData.reduce((sum, l) => sum + l.totalWagesEarned, 0);
  const totalSiteAdvances = siteLaboursData.reduce((sum, l) => sum + l.totalAdvancePaid, 0);
  const totalSiteLabourBalanceDue = totalSiteWages - totalSiteAdvances;
  const totalReceivedFromEngineer = siteEngPayments.reduce((sum, p) => sum + p.amount, 0);

  // Total Billed to Engineer = Site Wages + Flat Commission
  const totalSiteBill = totalSiteWages + currentSite.flatCommission;
  const pendingFromEngineer = Math.max(0, totalSiteBill - totalReceivedFromEngineer);

  // Filtered labour list by search
  const filteredSiteLabours = siteLaboursData.filter(item => 
    item.labour.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.labour.trade.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.labour.phone.includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      
      {/* সাইট সিলেকশন বার ও নতুন সাইট যোগ বাটন */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        {/* সাইট ট্যাবস */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
          {sites.map(s => {
            const isSelected = s.id === currentSite.id;
            return (
              <button
                key={s.id}
                onClick={() => setSelectedSiteId(s.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${
                  isSelected 
                    ? 'bg-amber-600 text-white shadow-xs font-semibold' 
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>{s.name}</span>
              </button>
            );
          })}
        </div>

        <button
          onClick={() => setShowAddSiteModal(true)}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন সাইট যোগ</span>
        </button>
      </div>

      {/* সাইটের বিস্তারিত হেডবোর্ড ও কমিশন তথ্য */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">{currentSite.name}</h2>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                currentSite.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'
              }`}>
                {currentSite.status === 'active' ? 'চলতি সাইট' : 'সম্পন্ন'}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {currentSite.address}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                ইঞ্জিনিয়ার: <strong className="text-slate-700 font-medium">{currentSite.engineerName}</strong> ({currentSite.engineerPhone})
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                শুরু: {formatDateBengali(currentSite.startDate)}
              </span>
            </div>
          </div>

          {/* নির্দিষ্ট ফ্ল্যাট কমিশন অ্যামাউন্ট */}
          <div className="flex items-center gap-3 bg-amber-50/80 border border-amber-200 p-3 rounded-lg">
            <Coins className="w-5 h-5 text-amber-700 shrink-0" />
            <div>
              <span className="block text-[11px] text-amber-800 font-medium">নির্দিষ্ট সাইট কমিশন (ফ্ল্যাট টাকা, কোনো % নয়)</span>
              <span className="text-lg font-bold font-mono tabular-nums text-amber-950">
                {formatCurrency(currentSite.flatCommission)}
              </span>
            </div>
          </div>
        </div>

        {/* সাইটের আর্থিক মেট্রিক্স বার */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
            <span className="block text-[11px] text-slate-500">মোট লেবার মজুরি অর্জিত</span>
            <span className="text-base font-bold font-mono tabular-nums text-slate-900">
              {formatCurrency(totalSiteWages)}
            </span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
            <span className="block text-[11px] text-slate-500">লেবারদের প্রদত্ত অগ্রিম/পার্ট</span>
            <span className="text-base font-bold font-mono tabular-nums text-emerald-700">
              {formatCurrency(totalSiteAdvances)}
            </span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
            <span className="block text-[11px] text-slate-500">লেবার মজুরি বকেয়া</span>
            <span className="text-base font-bold font-mono tabular-nums text-rose-700">
              {formatCurrency(totalSiteLabourBalanceDue)}
            </span>
          </div>

          <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-200/70">
            <span className="block text-[11px] text-blue-700 font-medium">ইঞ্জিনিয়ার থেকে পাওনা</span>
            <span className="text-base font-bold font-mono tabular-nums text-blue-900">
              {formatCurrency(pendingFromEngineer)}
            </span>
            <span className="block text-[10px] text-blue-600 mt-0.5 font-mono">
              প্রাপ্ত: {formatCurrency(totalReceivedFromEngineer)} / {formatCurrency(totalSiteBill)}
            </span>
          </div>
        </div>
      </div>

      {/* দুটি প্রধান সেকশন: লেবার হাজিরা ও মজুরি টেবিল + ইঞ্জিনিয়ার পেমেন্ট হিসেব */}
      <div className="space-y-6">

        {/* সেকশন ১: লেবার ও হাজিরা হিসাব */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-600" />
                <span>সাইটের লেবার তালিকা, দৈনিক হাজিরা ও মজুরি হিসাব</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                প্রতিটি লেবারের কাজের দিন (Days Worked), দৈনিক মজুরি রেট (₹) এবং বকেয়া টাকার হিসাব
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="লেবার বা কাজ খুঁজুন..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <button
                onClick={() => {
                  setAttForm({
                    labourId: labours[0]?.id || '',
                    date: new Date().toISOString().slice(0, 10),
                    daysWorked: 1,
                    wageRate: labours[0]?.dailyWageRate || 600,
                    note: ''
                  });
                  setShowAttendanceModal(true);
                }}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1 whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>হাজিরা যোগ</span>
              </button>
            </div>
          </div>

          {/* লেবার মজুরি ও হাজিরার টেবিল */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold tracking-wider">
                <tr>
                  <th className="py-3 px-4">লেবারের নাম ও কাজের ধরন</th>
                  <th className="py-3 px-3">ট্রেড/পদবি</th>
                  <th className="py-3 px-3 text-right">কাজের দিন (Days Worked)</th>
                  <th className="py-3 px-3 text-right">দৈনিক রেট (Per Day ₹)</th>
                  <th className="py-3 px-3 text-right">মোট মজুরি (₹)</th>
                  <th className="py-3 px-3 text-right">প্রদত্ত অগ্রিম (₹)</th>
                  <th className="py-3 px-3 text-right">নিট বকেয়া (₹)</th>
                  <th className="py-3 px-4 text-center">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSiteLabours.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      এই সাইটে এখনো কোনো লেবারের হাজিরা নথিভুক্ত করা হয়নি।
                    </td>
                  </tr>
                ) : (
                  filteredSiteLabours.map(({ labour, totalDaysWorked, totalWagesEarned, totalAdvancePaid, balanceDue }) => {
                    const roleBadge = getRoleTypeBadge(labour.roleType);
                    return (
                      <tr key={labour.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{labour.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono">{labour.phone}</div>
                          <span className={`inline-block mt-0.5 text-[10px] px-1.5 py-0.2 rounded border ${roleBadge.badgeClass}`}>
                            {roleBadge.label}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-700 font-medium">
                          {labour.trade}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                          {formatNumber(totalDaysWorked)} দিন
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                          {formatCurrency(labour.dailyWageRate)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                          {formatCurrency(totalWagesEarned)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 font-semibold">
                          {formatCurrency(totalAdvancePaid)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums">
                          <span className={`font-bold ${balanceDue > 0 ? 'text-rose-600' : 'text-slate-600'}`}>
                            {formatCurrency(balanceDue)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedLabourForAdvance(labour);
                                setAdvForm({
                                  labourId: labour.id,
                                  date: new Date().toISOString().slice(0, 10),
                                  amount: 1500,
                                  paymentMethod: 'cash',
                                  note: 'সাইট থেকে পার্ট পেমেন্ট'
                                });
                                setShowAdvanceModal(true);
                              }}
                              className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-medium rounded transition-colors whitespace-nowrap"
                            >
                              + অগ্রিম / পার্ট
                            </button>
                            <button
                              onClick={() => {
                                setAttForm({
                                  labourId: labour.id,
                                  date: new Date().toISOString().slice(0, 10),
                                  daysWorked: 1,
                                  wageRate: labour.dailyWageRate,
                                  note: ''
                                });
                                setShowAttendanceModal(true);
                              }}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded transition-colors"
                              title="হাজিরা দিন যোগ করুন"
                            >
                              + হাজিরা
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* সেকশন ২: ইঞ্জিনিয়ার থেকে পার্ট পেমেন্ট তোলার হিসাব ও লেবার অগ্রিম হিস্ট্রি */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* বক্স ১: ইঞ্জিনিয়ার থেকে পার্ট পেমেন্ট তোলা */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <ArrowDownLeft className="w-4 h-4 text-blue-600" />
                  <span>ইঞ্জিনিয়ার থেকে পার্ট পেমেন্ট উত্তোলনের হিসাব</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  ইঞ্জিনিয়ার {currentSite.engineerName} এর থেকে কিস্তিতে গৃহীত টাকা
                </p>
              </div>

              <button
                onClick={() => {
                  setEngForm({
                    date: new Date().toISOString().slice(0, 10),
                    amount: 25000,
                    paymentMethod: 'bank',
                    receiptNo: '',
                    note: ''
                  });
                  setShowEngineerPaymentModal(true);
                }}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>পেমেন্ট এন্ট্রি</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 mt-2 max-h-72 overflow-y-auto">
              {siteEngPayments.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  ইঞ্জিনিয়ার থেকে এখনো কোনো পেমেন্ট এন্ট্রি নেই।
                </div>
              ) : (
                siteEngPayments.map(p => (
                  <div key={p.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-slate-800">
                        {p.note || 'পার্ট পেমেন্ট প্রাপ্তি'}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span>তারিখ: {formatDateBengali(p.date)}</span>
                        <span>· মাধ্যম: {p.paymentMethod.toUpperCase()}</span>
                        {p.receiptNo && <span>· রসিদ: {p.receiptNo}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold font-mono tabular-nums text-blue-700 text-sm">
                        {formatCurrency(p.amount)}
                      </span>
                      <button
                        onClick={() => deleteEngineerPayment(p.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded"
                        title="মুছুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded-lg">
              <span className="text-slate-600 font-medium">মোট প্রাপ্ত টাকা:</span>
              <span className="text-sm font-bold font-mono tabular-nums text-blue-700">
                {formatCurrency(totalReceivedFromEngineer)}
              </span>
            </div>
          </div>

          {/* বক্স ২: লেবারদের প্রদত্ত অগ্রিম ও পার্ট পেমেন্ট লগ */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Wallet className="w-4 h-4 text-emerald-600" />
                  <span>লেবারদের পার্ট পেমেন্ট / অগ্রিম প্রদানের ইতিহাস</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  সাইটের চলতি লেবারদের দেওয়া ক্যাশ বা অনলাইন অগ্রিম
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedLabourForAdvance(null);
                  setAdvForm({
                    labourId: labours[0]?.id || '',
                    date: new Date().toISOString().slice(0, 10),
                    amount: 2000,
                    paymentMethod: 'cash',
                    note: ''
                  });
                  setShowAdvanceModal(true);
                }}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>অগ্রিম দিন</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 mt-2 max-h-72 overflow-y-auto">
              {siteAdvances.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  এই সাইটের কোনো লেবারকে এখনো অগ্রিম দেওয়া হয়নি।
                </div>
              ) : (
                siteAdvances.map(adv => {
                  const labour = labours.find(l => l.id === adv.labourId);
                  return (
                    <div key={adv.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-800">
                          {labour?.name || 'লেবার'} - <span className="font-normal text-slate-600">{adv.note || 'অগ্রিম প্রদান'}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>{formatDateBengali(adv.date)}</span>
                          <span>· মাধ্যম: {adv.paymentMethod === 'cash' ? 'নগদ' : adv.paymentMethod.toUpperCase()}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold font-mono tabular-nums text-emerald-700 text-sm">
                          {formatCurrency(adv.amount)}
                        </span>
                        <button
                          onClick={() => deleteLabourAdvance(adv.id)}
                          className="text-slate-400 hover:text-rose-600 p-1 rounded"
                          title="মুছুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded-lg">
              <span className="text-slate-600 font-medium">মোট প্রদত্ত অগ্রিম:</span>
              <span className="text-sm font-bold font-mono tabular-nums text-emerald-700">
                {formatCurrency(totalSiteAdvances)}
              </span>
            </div>
          </div>

        </div>

      </div>

      {/* মডাল ১: নতুন সাইট যোগ করার ফরম */}
      {showAddSiteModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">নতুন নির্মাণ সাইট যোগ করুন</h3>
              <button onClick={() => setShowAddSiteModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!newSite.name.trim()) return;
                addSite(newSite);
                setShowAddSiteModal(false);
                setNewSite({
                  name: '',
                  address: '',
                  engineerName: '',
                  engineerPhone: '',
                  flatCommission: 50000,
                  status: 'active',
                  startDate: new Date().toISOString().slice(0, 10),
                  targetEndDate: '',
                  notes: ''
                });
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">সাইটের নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: রাজারহাট রেসিডেন্সিয়াল ফ্ল্যাটস"
                  value={newSite.name}
                  onChange={e => setNewSite({ ...newSite, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">সাইটের ঠিকানা *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: প্লট ২২, রাজারহাট মেইন রোড, কলকাতা"
                  value={newSite.address}
                  onChange={e => setNewSite({ ...newSite, address: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ইঞ্জিনিয়ারের নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="ইঞ্জি. নাম"
                    value={newSite.engineerName}
                    onChange={e => setNewSite({ ...newSite, engineerName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ফোন নম্বর</label>
                  <input
                    type="text"
                    placeholder="৯৮৩০০০০০০০"
                    value={newSite.engineerPhone}
                    onChange={e => setNewSite({ ...newSite, engineerPhone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* নির্দিষ্ট ফ্ল্যাট কমিশন */}
              <div className="bg-amber-50/70 p-3 rounded-lg border border-amber-200">
                <label className="block font-bold text-amber-900 mb-1">
                  নির্দিষ্ট কমিশন অ্যামাউন্ট (টাকা/₹, কোনো % নয়) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="500"
                  placeholder="যেমন: 60000"
                  value={newSite.flatCommission}
                  onChange={e => setNewSite({ ...newSite, flatCommission: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-amber-300 rounded-lg focus:ring-1 focus:ring-amber-500 font-mono text-base font-bold bg-white"
                />
                <span className="block text-[11px] text-amber-700 mt-1">
                  সাইটের জন্য কন্ট্রাক্টরের নির্দিষ্ট মোট লাভ বা ফি (ফ্ল্যাট অ্যামাউন্ট)।
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">কাজের শুরুর তারিখ</label>
                  <input
                    type="date"
                    value={newSite.startDate}
                    onChange={e => setNewSite({ ...newSite, startDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">স্ট্যাটাস</label>
                  <select
                    value={newSite.status}
                    onChange={e => setNewSite({ ...newSite, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="active">চলতি (Active)</option>
                    <option value="completed">সম্পন্ন (Completed)</option>
                    <option value="on_hold">স্থগিত (On Hold)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddSiteModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  সাইট সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ২: হাজিরা ও দৈনিক কাজের হিসাব এন্ট্রি */}
      {showAttendanceModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">লেবার হাজিরা ও কাজের দিন এন্ট্রি</h3>
              <button onClick={() => setShowAttendanceModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!attForm.labourId) return;
                addAttendanceRecord({
                  siteId: currentSite.id,
                  labourId: attForm.labourId,
                  date: attForm.date,
                  daysWorked: Number(attForm.daysWorked),
                  wageRate: Number(attForm.wageRate),
                  note: attForm.note
                });
                setShowAttendanceModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">লেবার নির্বাচন করুন *</label>
                <select
                  required
                  value={attForm.labourId}
                  onChange={e => {
                    const selId = e.target.value;
                    const labour = labours.find(l => l.id === selId);
                    setAttForm({
                      ...attForm,
                      labourId: selId,
                      wageRate: labour?.dailyWageRate || attForm.wageRate
                    });
                  }}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="">-- লেবার বাছুন --</option>
                  {labours.map(l => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.trade}) - রেট: ₹{l.dailyWageRate}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">হাজিরা/কাজের দিন (Days)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="31"
                    required
                    value={attForm.daysWorked}
                    onChange={e => setAttForm({ ...attForm, daysWorked: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-400">১ = পূর্ণ দিন, ০.৫ = হাফ দিন</span>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">দৈনিক রেট (₹/দিন)</label>
                  <input
                    type="number"
                    required
                    min="100"
                    step="10"
                    value={attForm.wageRate}
                    onChange={e => setAttForm({ ...attForm, wageRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200 flex items-center justify-between">
                <span className="text-xs text-amber-800">মোট মজুরি হিসাব:</span>
                <span className="font-bold font-mono text-base text-amber-950">
                  {formatCurrency(attForm.daysWorked * attForm.wageRate)}
                </span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                <input
                  type="date"
                  value={attForm.date}
                  onChange={e => setAttForm({ ...attForm, date: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">নোট / মন্তব্য</label>
                <input
                  type="text"
                  placeholder="যেমন: ১ম তলা ছাদ ঢালাই হাজিরা"
                  value={attForm.note}
                  onChange={e => setAttForm({ ...attForm, note: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAttendanceModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  হাজিরা যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ৩: লেবারকে অগ্রিম / পার্ট পেমেন্ট দেওয়ার ফরম */}
      {showAdvanceModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">লেবারকে পার্ট পেমেন্ট / অগ্রিম প্রদান</h3>
              <button onClick={() => setShowAdvanceModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!advForm.labourId || !advForm.amount) return;
                addLabourAdvance({
                  siteId: currentSite.id,
                  labourId: advForm.labourId,
                  date: advForm.date,
                  amount: Number(advForm.amount),
                  paymentMethod: advForm.paymentMethod,
                  note: advForm.note
                });
                setShowAdvanceModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">লেবার নির্বাচন *</label>
                <select
                  required
                  value={advForm.labourId}
                  onChange={e => setAdvForm({ ...advForm, labourId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="">-- লেবার নির্বাচন করুন --</option>
                  {labours.map(l => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.trade})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">অগ্রিম টাকার পরিমাণ (₹) *</label>
                <input
                  type="number"
                  required
                  min="50"
                  step="50"
                  value={advForm.amount}
                  onChange={e => setAdvForm({ ...advForm, amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-base text-emerald-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={advForm.paymentMethod}
                    onChange={e => setAdvForm({ ...advForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="cash">নগদ (Cash)</option>
                    <option value="upi">UPI / অনলাইন</option>
                    <option value="bank">ব্যাংক ট্রান্সফার</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={advForm.date}
                    onChange={e => setAdvForm({ ...advForm, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">নোট / কারণ</label>
                <input
                  type="text"
                  placeholder="যেমন: বাড়ি যাওয়ার খরচ বা উৎসবের অগ্রিম"
                  value={advForm.note}
                  onChange={e => setAdvForm({ ...advForm, note: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAdvanceModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium"
                >
                  অগ্রিম নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* মডাল ৪: ইঞ্জিনিয়ার থেকে পার্ট পেমেন্ট তোলার এন্ট্রি */}
      {showEngineerPaymentModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">ইঞ্জিনিয়ার থেকে পেমেন্ট গ্রহণ</h3>
              <button onClick={() => setShowEngineerPaymentModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!engForm.amount) return;
                addEngineerPayment({
                  siteId: currentSite.id,
                  date: engForm.date,
                  amount: Number(engForm.amount),
                  paymentMethod: engForm.paymentMethod,
                  receiptNo: engForm.receiptNo,
                  note: engForm.note
                });
                setShowEngineerPaymentModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div>
                <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                <input
                  type="number"
                  required
                  min="500"
                  step="500"
                  value={engForm.amount}
                  onChange={e => setEngForm({ ...engForm, amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg font-mono font-bold text-base text-blue-900 bg-blue-50/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={engForm.paymentMethod}
                    onChange={e => setEngForm({ ...engForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="bank">ব্যাংক ট্রান্সফার (NEFT/RTGS)</option>
                    <option value="cheque">চেক (Cheque)</option>
                    <option value="upi">UPI</option>
                    <option value="cash">নগদ (Cash)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={engForm.date}
                    onChange={e => setEngForm({ ...engForm, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">রসিদ বা চেক/ট্রানজ্যাকশন নং</label>
                <input
                  type="text"
                  placeholder="যেমন: CHQ-88902 বা TXN-4412"
                  value={engForm.receiptNo}
                  onChange={e => setEngForm({ ...engForm, receiptNo: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">নোট / কিস্তির বিবরণ</label>
                <input
                  type="text"
                  placeholder="যেমন: ২য় কিস্তি লেবার বিল ক্লিয়ারেন্স"
                  value={engForm.note}
                  onChange={e => setEngForm({ ...engForm, note: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowEngineerPaymentModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium"
                >
                  পেমেন্ট জমা করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
