/**
 * GODEX Phase 1 - Task Tree View
 * Expandable hierarchical DAG task visualization displaying:
 * - Real decomposed milestones (Inspect -> Diagnose -> Implement -> Test -> Verify)
 * - Agent role assignments (ARCHITECT, RESEARCHER, CODER, DEBUGGER, TESTER, VERIFIER)
 * - Exact dependency mapping and truthful progress percentages
 */

import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  AlertCircle, 
  Clock, 
  ChevronRight, 
  ChevronDown, 
  FileCode, 
  Layers, 
  Play,
  RotateCcw,
  Sparkles,
  Zap
} from 'lucide-react';
import { OperationTaskItem, OperationStatus } from '../godex/operationState';

interface GodexTaskTreeViewProps {
  tasks: OperationTaskItem[];
  operationId?: string;
  operationStatus?: OperationStatus;
  onSelectFile?: (path: string) => void;
}

export const GodexTaskTreeView: React.FC<GodexTaskTreeViewProps> = ({
  tasks,
  operationId,
  operationStatus = 'IDLE',
  onSelectFile
}) => {
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({
    'task-1-arch': true,
    'task-2-ctx': true,
    'task-3-code': true
  });

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getStatusBadge = (status: OperationTaskItem['status']) => {
    switch (status) {
      case 'COMPLETED':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">COMPLETED</span>;
      case 'RUNNING':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 animate-pulse">RUNNING</span>;
      case 'READY':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800">READY</span>;
      case 'FAILED':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-rose-950 text-rose-400 border border-rose-800">FAILED</span>;
      case 'BLOCKED':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800">BLOCKED</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-[#121824] text-neutral-500 border border-[#1E273A]">QUEUED</span>;
    }
  };

  const completedCount = tasks.filter(t => t.status === 'COMPLETED').length;

  return (
    <div className="flex-1 h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#08090D] select-text">
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-[#182030]">
        <div>
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Autonomous Task Execution Tree</span>
          </h3>
          <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
            {operationId ? `Operation: ${operationId} (${operationStatus})` : 'Acyclic DAG Execution Pipeline'}
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-[11px]">
          <span className="px-2.5 py-1 rounded bg-[#101624] text-cyan-300 border border-cyan-800/60 font-bold">
            {tasks.length > 0 ? `${completedCount}/${tasks.length} Verified` : 'IDLE'}
          </span>
        </div>
      </div>

      {tasks.length === 0 ? (
        <div className="p-8 text-center space-y-3 rounded-xl border border-dashed border-[#1A2234] bg-[#0A0D15]">
          <Layers className="w-8 h-8 text-neutral-600 mx-auto" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-neutral-300">No Active Tasks</h4>
            <p className="text-[11px] text-neutral-500 max-w-sm mx-auto">
              Execute a feature request in the Composer to automatically synthesize a DAG task execution graph.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {tasks.map((task, idx) => {
            const isExpanded = expandedIds[task.id] ?? false;
            const isDone = task.status === 'COMPLETED';
            const isRunning = task.status === 'RUNNING';
            const isFailed = task.status === 'FAILED';

            return (
              <div
                key={task.id}
                className={`rounded-xl border transition-all overflow-hidden ${
                  isRunning 
                    ? 'bg-[#0E1524] border-cyan-500/70 shadow-lg ring-1 ring-cyan-500/30' 
                    : isDone
                    ? 'bg-[#0B0E16] border-[#182232]'
                    : isFailed
                    ? 'bg-rose-950/20 border-rose-800/60'
                    : 'bg-[#0A0D14] border-[#161D2B]'
                }`}
              >
                {/* Task Node Header */}
                <div
                  onClick={() => toggleExpand(task.id)}
                  className="p-3.5 flex items-start gap-3 cursor-pointer hover:bg-[#121927]/60 transition-colors"
                >
                  <div className="mt-0.5 shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : isRunning ? (
                      <span className="w-3.5 h-3.5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin inline-block" />
                    ) : isFailed ? (
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                    ) : (
                      <Circle className="w-3.5 h-3.5 text-neutral-500" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 truncate">
                        <span className="font-mono text-[10px] text-neutral-500">#{idx + 1}</span>
                        <h4 className={`text-xs font-bold truncate ${isDone ? 'text-neutral-300' : isRunning ? 'text-cyan-300' : 'text-white'}`}>
                          {task.title}
                        </h4>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-1.5 py-0.2 rounded bg-[#101420] text-cyan-300 border border-[#1E2638] text-[9px] font-mono">
                          {task.agentRole}
                        </span>
                        {getStatusBadge(task.status)}
                        {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-neutral-500" /> : <ChevronRight className="w-3.5 h-3.5 text-neutral-500" />}
                      </div>
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-relaxed font-sans line-clamp-2">
                      {task.description}
                    </p>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-3 pt-0 border-t border-[#161F2E] bg-[#07090F] space-y-2.5 text-[11px] font-mono">
                    {/* Target Files */}
                    {task.files && task.files.length > 0 && (
                      <div className="space-y-1 pt-2">
                        <span className="text-[10px] text-neutral-500 uppercase font-bold">Target Files ({task.files.length}):</span>
                        <div className="flex flex-wrap gap-1.5">
                          {task.files.map((file, fi) => (
                            <button
                              key={fi}
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectFile?.(file);
                              }}
                              className="px-2 py-0.5 rounded bg-[#0D121D] hover:bg-[#141C2B] text-cyan-300 border border-[#1A2538] text-[10px] flex items-center gap-1 transition-colors"
                            >
                              <FileCode className="w-3 h-3 text-cyan-400" />
                              <span>{file}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Dependencies */}
                    {task.dependencies && task.dependencies.length > 0 && (
                      <div className="text-[10px] text-neutral-400">
                        <span className="text-neutral-500 uppercase font-bold">Dependencies: </span>
                        <span>{task.dependencies.join(', ')}</span>
                      </div>
                    )}

                    {/* Progress Info */}
                    <div className="flex items-center justify-between text-[10px] text-neutral-500 pt-1 border-t border-[#121824]">
                      <span>Created: {new Date(task.createdAt).toLocaleTimeString()}</span>
                      <span>Progress: <strong className="text-cyan-300">{task.progressPercent > 0 ? `${task.progressPercent}%` : 'UNKNOWN'}</strong></span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
