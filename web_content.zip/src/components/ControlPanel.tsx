import React, { useRef, useState } from 'react';
import {
  Upload,
  Layers,
  Sparkles,
  Sliders,
  Ratio,
  Maximize,
  RefreshCw,
  Clock,
  Palette,
  ChevronDown,
  ChevronUp,
  Sun,
  Flame,
  Square,
  Crop,
  Move,
  ZoomIn,
  Check,
} from 'lucide-react';
import { SlideshowSettings, MaskStyle, AspectRatio, MotionPattern, SlideItem } from '../types';

interface ControlPanelProps {
  settings: SlideshowSettings;
  slides: SlideItem[];
  currentIndex: number;
  isPlaying: boolean;
  onUpdateSettings: (patch: Partial<SlideshowSettings>) => void;
  onUpdateSlide?: (index: number, patch: Partial<SlideItem>) => void;
  onFilesSelected: (files: FileList) => void;
  onLoadSamplePhotos: () => void;
  onResetSettings: () => void;
  onClearProject: () => void;
  onStartShow: () => void;
  onStopShow: () => void;
  onExportVideo: () => void;
  onSelectSlide: (index: number) => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  settings,
  slides,
  currentIndex,
  isPlaying,
  onUpdateSettings,
  onUpdateSlide,
  onFilesSelected,
  onLoadSamplePhotos,
  onResetSettings,
  onClearProject,
  onStartShow,
  onStopShow,
  onExportVideo,
  onSelectSlide,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesSelected(e.dataTransfer.files);
    }
  };

  const maskOptions: { labelBn: string; labelEn: string; value: MaskStyle }[] = [
    { labelBn: 'শার্প স্কয়ার বর্ডার (০ পিক্সেল)', labelEn: 'Sharp Square (0px)', value: 'box' },
    { labelBn: 'গোল সার্কেল', labelEn: 'Circle Mask (50%)', value: 'circle' },
    { labelBn: 'রাউন্ডেড কর্নার', labelEn: 'Rounded (20px)', value: 'rounded' },
    { labelBn: 'বর্ডার ছাড়া ফুল', labelEn: 'Full Box (0px)', value: 'full' },
    { labelBn: 'পোলায়ারয়েড ফ্রেম', labelEn: 'Polaroid Frame', value: 'polaroid' },
  ];

  const aspectRatios: { label: string; sub: string; value: AspectRatio }[] = [
    { label: '16:9', sub: 'ইউটিউব / ল্যান্ডস্কেপ', value: '16:9' },
    { label: '9:16', sub: 'ইনশট রিল / শর্টস', value: '9:16' },
    { label: '1:1', sub: 'স্কয়ার / ইন্সটাগ্রাম', value: '1:1' },
    { label: '4:5', sub: 'পোর্ট্রেট ফিড', value: '4:5' },
  ];

  const motionOptions: { labelBn: string; labelEn: string; value: MotionPattern }[] = [
    { labelBn: '৪টি সুনির্দিষ্ট লিনিয়ার মোশন (Zoom In/Out, R-L, L-R)', labelEn: '4 Linear Preset', value: '4-linear' },
    { labelBn: 'ইনশট ক্লাসিক (বিপরীত স্লাইড)', labelEn: 'InShot Classic Opposing', value: 'inshot-classic' },
    { labelBn: 'জুম অ্যান্ড ড্রিফ্ট', labelEn: 'Zoom & Drift', value: 'zoom-drift' },
    { labelBn: 'ডায়াগোনাল ড্রিফ্ট', labelEn: 'Diagonal Drift', value: 'diagonal-drift' },
    { labelBn: 'কেন বার্নস সিনেমাটিক প্যান', labelEn: 'Cinematic Ken Burns', value: 'ken-burns' },
  ];

  return (
    <div className="w-full bg-[#1e1e1e] border border-neutral-800 rounded-xl p-3.5 sm:p-4 shadow-[0_4px_15px_rgba(0,0,0,0.8)] flex flex-col gap-3.5 text-neutral-200">
      {/* 1. Direct InShot Controls as specified by user */}
      <div className="controls flex flex-col gap-2.5">
        {/* File Selection */}
        <div className="control-group flex flex-col gap-1">
          <label className="text-xs text-[#bbb] font-medium flex items-center justify-between">
            <span>নতুন ছবি আপলোড করুন:</span>
            <span className="text-[10px] text-neutral-500">একাধিক ছবি সাপোর্ট করে</span>
          </label>
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className="flex items-center gap-2"
          >
            <input
              ref={fileInputRef}
              id="imageInput"
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  onFilesSelected(e.target.files);
                }
              }}
              className="w-full p-1.5 bg-[#2c2c2c] border border-[#444] text-white rounded-md text-xs cursor-pointer file:mr-2 file:py-1 file:px-2.5 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-[#00e676] file:text-[#121212] hover:file:bg-[#00c853]"
            />
          </div>
        </div>

        {/* Primary Action Button Row 1: Clear, Start, Stop */}
        <div className="btn-row flex gap-2 w-full">
          <button
            type="button"
            id="btn-clear"
            onClick={onClearProject}
            className="btn-clear flex-1 py-2 px-2 bg-[#ffa726] hover:bg-[#ff9800] text-[#121212] font-bold text-xs rounded transition-colors text-center shadow-md active:scale-95"
            title="সব ছবি মুছে ফেলে নতুন প্রজেক্ট শুরু করুন"
          >
            সব মুছুন (Clear)
          </button>

          <button
            type="button"
            id="btn-start"
            onClick={onStartShow}
            className="flex-1 py-2 px-2 bg-[#00e676] hover:bg-[#00c853] text-[#121212] font-bold text-xs rounded transition-colors text-center shadow-md active:scale-95"
            title="স্লাইডশো চালু করুন"
          >
            স্টার্ট শো
          </button>

          <button
            type="button"
            id="btn-stop"
            onClick={onStopShow}
            className="btn-stop flex-1 py-2 px-2 bg-[#ff5252] hover:bg-[#f44336] text-white font-bold text-xs rounded transition-colors text-center shadow-md active:scale-95"
            title="স্লাইডশো থামান"
          >
            থামুন
          </button>
        </div>

        {/* Primary Action Button Row 2: Export / Download */}
        <div className="btn-row flex w-full">
          <button
            type="button"
            id="btn-export"
            onClick={onExportVideo}
            className="btn-export w-full py-2.5 px-3 bg-[#29b6f6] hover:bg-[#039be5] text-[#121212] font-bold text-xs rounded transition-colors text-center shadow-md active:scale-98"
            title="ভিডিও বা ফটো ডাউনলোড করুন"
          >
            এক্সপোর্ট / ডাউনলোড
          </button>
        </div>

        {/* Time Control: Minimum 5s duration with both Input field and Slider */}
        <div className="bg-[#242424] border border-neutral-700/80 rounded-lg p-2.5 flex flex-col gap-1.5 shadow-inner">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#00e676]" />
              <span>প্রতিটি স্লাইডের সময় (ডিউরেশন):</span>
            </label>
            <div className="flex items-center gap-1">
              <input
                type="number"
                id="slideDurationInput"
                min="5"
                max="60"
                step="0.5"
                value={settings.interval}
                onChange={(e) => {
                  const val = Math.max(5, parseFloat(e.target.value) || 5);
                  onUpdateSettings({ interval: val, transitionDuration: val });
                }}
                className="w-16 py-0.5 px-1 bg-[#151515] border border-[#00e676]/60 text-white font-mono font-bold text-xs rounded text-center focus:outline-none focus:ring-1 focus:ring-[#00e676]"
                title="স্লাইড ডিউরেশন (মিনিমাম ৫ সেকেন্ড)"
              />
              <span className="text-xs font-bold text-[#00e676]">সেকেন্ড</span>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-0.5">
            <span className="text-[10px] text-neutral-400 font-mono">5s</span>
            <input
              id="slideDurationSlider"
              type="range"
              min="5"
              max="25"
              step="0.5"
              value={settings.interval}
              onChange={(e) => {
                const val = Math.max(5, Number(e.target.value));
                onUpdateSettings({ interval: val, transitionDuration: val });
              }}
              className="w-full h-1.5 bg-neutral-700 rounded appearance-none cursor-pointer accent-[#00e676]"
            />
            <span className="text-[10px] text-neutral-400 font-mono">25s</span>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 pt-0.5">
            <span className="text-[10px] text-neutral-400">প্রিসেট:</span>
            {[5, 6, 8, 10, 15].map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => onUpdateSettings({ interval: sec, transitionDuration: sec })}
                className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
                  settings.interval === sec
                    ? 'bg-[#00e676] text-[#121212]'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {sec}s
              </button>
            ))}
            <span className="text-[10px] text-emerald-400 ml-auto font-medium">* মিনিমাম ৫ সেকেন্ড</span>
          </div>
        </div>

        {/* Dedicated Border Size & Style Control (বর্ডারের সাইজ কমানো/বাড়ানোর কন্ট্রোল) */}
        <div className="bg-[#242424] border border-neutral-700/80 rounded-lg p-2.5 flex flex-col gap-2 shadow-inner">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
              <Square className="w-3.5 h-3.5 text-[#00e676]" />
              <span>বর্ডার সাইজ ও বর্ডার কন্ট্রোল:</span>
            </label>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1 text-[11px] text-neutral-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.showBorder}
                  onChange={(e) => onUpdateSettings({ showBorder: e.target.checked })}
                  className="rounded text-[#00e676] focus:ring-0 w-3.5 h-3.5 bg-neutral-800 border-neutral-600"
                />
                <span>বর্ডার চালু</span>
              </label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  max="30"
                  step="1"
                  disabled={!settings.showBorder}
                  value={settings.borderWidth}
                  onChange={(e) => {
                    const val = Math.max(0, Math.min(30, parseInt(e.target.value) || 0));
                    onUpdateSettings({ borderWidth: val });
                  }}
                  className="w-14 py-0.5 px-1 bg-[#151515] border border-[#00e676]/60 text-white font-mono font-bold text-xs rounded text-center focus:outline-none focus:ring-1 focus:ring-[#00e676] disabled:opacity-40"
                  title="বর্ডারের পুরুত্ব (পিক্সেল)"
                />
                <span className="text-xs font-bold text-[#00e676]">px</span>
              </div>
            </div>
          </div>

          {/* Border Width Slider */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-neutral-400 font-mono">0px</span>
            <input
              type="range"
              min="0"
              max="24"
              step="1"
              disabled={!settings.showBorder}
              value={settings.borderWidth}
              onChange={(e) => onUpdateSettings({ borderWidth: Number(e.target.value) })}
              className="w-full h-1.5 bg-neutral-700 rounded appearance-none cursor-pointer accent-[#00e676] disabled:opacity-40"
            />
            <span className="text-[10px] text-neutral-400 font-mono">24px</span>
          </div>

          {/* Border Width Quick Presets & Color */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 pt-0.5 border-t border-neutral-700/50">
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-neutral-400">সাইজ:</span>
              {[
                { label: 'পাতলা', size: 2 },
                { label: 'ডিফল্ট', size: 4 },
                { label: 'মাঝারি', size: 8 },
                { label: 'মোটা', size: 12 },
                { label: 'বড় ফ্রেম', size: 16 },
              ].map((p) => (
                <button
                  key={p.size}
                  type="button"
                  disabled={!settings.showBorder}
                  onClick={() => onUpdateSettings({ borderWidth: p.size, showBorder: true })}
                  className={`px-1.5 py-0.5 text-[10px] font-bold rounded transition-colors disabled:opacity-40 ${
                    settings.showBorder && settings.borderWidth === p.size
                      ? 'bg-[#00e676] text-[#121212]'
                      : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                  }`}
                >
                  {p.label} ({p.size}px)
                </button>
              ))}
            </div>

            {/* Border Color Picker */}
            <div className="flex items-center gap-1.5">
              <Palette className="w-3 h-3 text-neutral-400" />
              <div className="flex items-center gap-1">
                {['#ffffff', '#000000', '#00e676', '#ffd600', '#ff1744'].map((col) => (
                  <button
                    key={col}
                    type="button"
                    title={`রং: ${col}`}
                    onClick={() => onUpdateSettings({ borderColor: col, showBorder: true })}
                    className={`w-4 h-4 rounded-full border transition-transform ${
                      settings.borderColor.toLowerCase() === col.toLowerCase()
                        ? 'scale-125 border-emerald-400 ring-1 ring-white'
                        : 'border-neutral-600 hover:scale-110'
                    }`}
                    style={{ backgroundColor: col }}
                  />
                ))}
                <input
                  type="color"
                  value={settings.borderColor}
                  onChange={(e) => onUpdateSettings({ borderColor: e.target.value })}
                  title="কাস্টম বর্ডার রং পছন্দ করুন"
                  className="w-5 h-5 rounded cursor-pointer border border-neutral-700 bg-transparent"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Photo Crop, Zoom & Frame Position Control (ছবি কতটুকু অংশ দেখাবে তা অ্যাডজাস্ট করার কন্ট্রোল) */}
        {slides.length > 0 && slides[currentIndex] && (
          <div className="bg-[#1e1e1e] border border-cyan-500/40 rounded-lg p-2.5 flex flex-col gap-2 shadow-inner">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                <Crop className="w-3.5 h-3.5 text-cyan-400" />
                <span>ছবির দৃশ্যমান অংশ ও ক্রপ (# {currentIndex + 1}):</span>
              </label>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => {
                    const current = slides[currentIndex];
                    const newFit = current.fitMode === 'contain' ? 'cover' : 'contain';
                    if (onUpdateSlide) onUpdateSlide(currentIndex, { fitMode: newFit });
                  }}
                  className={`text-[10px] px-2 py-0.5 rounded font-medium border transition-colors ${
                    slides[currentIndex].fitMode === 'contain'
                      ? 'bg-cyan-500 text-neutral-950 font-bold border-cyan-400'
                      : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:bg-neutral-700'
                  }`}
                  title="পুরো ছবি দেখান অথবা ফ্রেম ভর্তি ক্রপ"
                >
                  {slides[currentIndex].fitMode === 'contain' ? '✓ সম্পূর্ণ ছবি ফিট' : 'ফ্রেম ভর্তি (Cover)'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (onUpdateSlide) {
                      onUpdateSlide(currentIndex, {
                        zoom: 1.0,
                        offsetX: 0,
                        offsetY: 0,
                        fitMode: 'cover',
                      });
                    }
                  }}
                  className="text-[10px] text-neutral-400 hover:text-white px-1.5 py-0.5 rounded bg-neutral-800"
                  title="রিসেট করুন"
                >
                  রিসেট
                </button>
              </div>
            </div>

            {/* Zoom Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-neutral-300 flex items-center gap-1">
                  <ZoomIn className="w-3 h-3 text-cyan-400" />
                  <span>জুম ইন / আউট (Zoom):</span>
                </span>
                <span className="text-cyan-400 font-mono font-bold">
                  {Math.round((slides[currentIndex].zoom ?? 1.0) * 100)}%
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-neutral-500 font-mono">100%</span>
                <input
                  type="range"
                  min="0.8"
                  max="2.5"
                  step="0.05"
                  value={slides[currentIndex].zoom ?? 1.0}
                  onChange={(e) => {
                    if (onUpdateSlide) {
                      onUpdateSlide(currentIndex, { zoom: parseFloat(e.target.value) });
                    }
                  }}
                  className="w-full h-1.5 bg-neutral-700 rounded appearance-none cursor-pointer accent-cyan-400"
                />
                <span className="text-[10px] text-neutral-500 font-mono">250%</span>
              </div>
            </div>

            {/* Position / Pan Sliders (ডান-বাম এবং উপর-নিচ পজিশনিং) */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-neutral-800/80">
              {/* Horizontal Position */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-neutral-400 flex items-center gap-1">
                    <Move className="w-2.5 h-2.5 text-cyan-400" />
                    <span>ডান - বাম সরান:</span>
                  </span>
                  <span className="text-cyan-400 font-mono text-[10px]">
                    {slides[currentIndex].offsetX ?? 0}%
                  </span>
                </div>
                <input
                  type="range"
                  min="-45"
                  max="45"
                  step="1"
                  value={slides[currentIndex].offsetX ?? 0}
                  onChange={(e) => {
                    if (onUpdateSlide) {
                      onUpdateSlide(currentIndex, { offsetX: parseInt(e.target.value) });
                    }
                  }}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-cyan-400"
                />
              </div>

              {/* Vertical Position */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-neutral-400 flex items-center gap-1">
                    <Move className="w-2.5 h-2.5 text-cyan-400 rotate-90" />
                    <span>উপর - নিচ সরান:</span>
                  </span>
                  <span className="text-cyan-400 font-mono text-[10px]">
                    {slides[currentIndex].offsetY ?? 0}%
                  </span>
                </div>
                <input
                  type="range"
                  min="-45"
                  max="45"
                  step="1"
                  value={slides[currentIndex].offsetY ?? 0}
                  onChange={(e) => {
                    if (onUpdateSlide) {
                      onUpdateSlide(currentIndex, { offsetY: parseInt(e.target.value) });
                    }
                  }}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>
            <div className="text-[10px] text-neutral-400 flex items-center justify-between">
              <span>* মুখের অংশ কেটে গেলে স্লাইডার দিয়ে ছবি উপরে/নিচে অ্যাডজাস্ট করে নিন।</span>
            </div>
          </div>
        )}

        {/* Thumbnail strip container directly matching user's spec (.thumb: 45x30px) */}
        {slides.length > 0 && (
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400">
              <span>স্লাইড থাম্বনেইল ({slides.length} টি ছবি):</span>
              <span className="text-[10px] text-neutral-500">ক্লিক করে স্লাইড দেখুন</span>
            </div>
            <div
              id="thumbContainer"
              className="thumbnail-container flex gap-1.5 overflow-x-auto py-1.5 scrollbar-thin scrollbar-thumb-neutral-700"
            >
              {slides.map((slide, idx) => {
                const isActive = idx === currentIndex;
                return (
                  <div
                    key={slide.id || idx}
                    onClick={() => onSelectSlide(idx)}
                    className={`thumb w-[45px] h-[30px] rounded-[3px] bg-cover bg-center flex-shrink-0 cursor-pointer transition-all ${
                      isActive
                        ? 'border-2 border-[#00e676] shadow-md scale-105 opacity-100'
                        : 'border border-[#555] opacity-60 hover:opacity-100'
                    }`}
                    style={{ backgroundImage: `url('${slide.url}')` }}
                    title={`Slide #${idx + 1}: ${slide.name}`}
                  />
                );
              })}
            </div>
          </div>
        )}

        {/* Info text directly matching user's HTML */}
        <div className="info text-[11px] text-[#888] text-center mt-1 leading-relaxed border-t border-neutral-800/80 pt-2">
          * শার্প স্কয়ার বর্ডার (০ পিক্সেল), ডিউরেশন মিনিমাম ৫ সেকেন্ড বা তার বেশি এবং ডান-বামে স্লাইড একদম প্রান্ত থেকে প্রান্ত পর্যন্ত সোজা (Linear)।
        </div>
      </div>

      {/* Advanced Customization Toggle */}
      <div className="border-t border-neutral-800 pt-2">
        <button
          type="button"
          onClick={() => setShowAdvanced((prev) => !prev)}
          className="w-full py-1.5 px-2.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold text-neutral-300 flex items-center justify-between transition-colors"
        >
          <span className="flex items-center gap-1.5 text-emerald-400">
            <Sliders className="w-3.5 h-3.5" />
            <span>উন্নত কাস্টমাইজেশন ও সেটিংস (Advanced Settings)</span>
          </span>
          {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showAdvanced && (
          <div className="mt-3 flex flex-col gap-3.5 text-xs">
            {/* Aspect Ratio */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1">
                <Ratio className="w-3 h-3 text-emerald-400" /> ক্যানভাস অনুপাত (Aspect Ratio):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {aspectRatios.map((item) => {
                  const isSelected = settings.aspectRatio === item.value;
                  return (
                    <button
                      key={item.value}
                      type="button"
                      onClick={() => onUpdateSettings({ aspectRatio: item.value })}
                      className={`py-1.5 px-2 rounded border text-left flex flex-col transition-all ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-500/15 text-white ring-1 ring-emerald-500/40'
                          : 'border-neutral-800 bg-[#2c2c2c] hover:bg-neutral-700 text-neutral-300'
                      }`}
                    >
                      <span className="text-xs font-bold">{item.label}</span>
                      <span className="text-[9px] text-neutral-400 truncate">{item.sub}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Mask / Frame Style */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1">
                <Layers className="w-3 h-3 text-emerald-400" /> ফ্রেম বা মাস্ক স্টাইল:
              </label>
              <select
                id="maskSelect"
                value={settings.maskStyle}
                onChange={(e) => onUpdateSettings({ maskStyle: e.target.value as MaskStyle })}
                className="w-full p-1.5 bg-[#2c2c2c] border border-[#444] text-white rounded text-xs"
              >
                {maskOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.labelBn} — {opt.labelEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Motion Selection */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" /> মোশন ও অ্যানিমেশন টাইপ:
              </label>
              <select
                id="motionSelect"
                value={settings.motionPattern}
                onChange={(e) => onUpdateSettings({ motionPattern: e.target.value as MotionPattern })}
                className="w-full p-1.5 bg-[#2c2c2c] border border-[#444] text-white rounded text-xs"
              >
                {motionOptions.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.labelBn}
                  </option>
                ))}
              </select>
            </div>

            {/* White Vibe & Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-neutral-800/80">
              {/* Blur Range */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-300">ব্লার মাত্রা (White Vibe Blur):</span>
                  <span className="text-emerald-400 font-mono font-bold">{settings.blur}px</span>
                </div>
                <input
                  id="blurRange"
                  type="range"
                  min="0"
                  max="35"
                  value={settings.blur}
                  onChange={(e) => onUpdateSettings({ blur: Number(e.target.value) })}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              {/* White Vibe Brightness */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-300 flex items-center gap-1">
                    <Sun className="w-2.5 h-2.5 text-amber-400" />
                    <span>হোয়াইট ভাইব আলো (Brightness):</span>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">{settings.brightness}x</span>
                </div>
                <input
                  id="brightnessRange"
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.05"
                  value={settings.brightness}
                  onChange={(e) => onUpdateSettings({ brightness: Number(e.target.value) })}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              {/* Saturation */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-300 flex items-center gap-1">
                    <Flame className="w-2.5 h-2.5 text-rose-400" />
                    <span>স্যাচুরেশন (Vibrance):</span>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">{settings.saturate}x</span>
                </div>
                <input
                  id="saturateRange"
                  type="range"
                  min="0.8"
                  max="1.8"
                  step="0.05"
                  value={settings.saturate}
                  onChange={(e) => onUpdateSettings({ saturate: Number(e.target.value) })}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              {/* Slide Duration */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-300 flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5 text-emerald-400" />
                    <span>স্লাইড পরিবর্তনের গতি (ডিউরেশন):</span>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">{settings.interval}s (মিনিমাম ৫ সে.)</span>
                </div>
                <input
                  id="intervalRange"
                  type="range"
                  min="5.0"
                  max="30.0"
                  step="0.5"
                  value={settings.interval}
                  onChange={(e) => {
                    const val = Math.max(5, Number(e.target.value));
                    onUpdateSettings({
                      interval: val,
                      transitionDuration: val,
                    });
                  }}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              {/* Foreground Card Scale / Photo Size */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-300 flex items-center gap-1">
                    <Maximize className="w-2.5 h-2.5 text-cyan-400" />
                    <span>মূল ছবির সাইজ (Card Zoom/Scale):</span>
                  </span>
                  <span className="text-cyan-400 font-mono font-bold">{settings.foregroundScale}%</span>
                </div>
                <input
                  id="foregroundScaleRange"
                  type="range"
                  min="40"
                  max="95"
                  step="1"
                  value={settings.foregroundScale}
                  onChange={(e) => onUpdateSettings({ foregroundScale: Number(e.target.value) })}
                  className="w-full h-1 bg-neutral-700 rounded appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>

            {/* Quick Demo & Reset Buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <button
                type="button"
                id="btn-load-sample-photos"
                onClick={onLoadSamplePhotos}
                className="text-xs px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-emerald-400 border border-emerald-500/20 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-3 h-3" />
                <span>নমুনা ডেমো ছবি লোড করুন</span>
              </button>
              <button
                type="button"
                onClick={onResetSettings}
                className="text-[11px] text-neutral-400 hover:text-white"
              >
                ডিফল্ট সেটিংস
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
