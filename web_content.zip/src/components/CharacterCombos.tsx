import React, { useState } from 'react';
import { 
  Layers, 
  Zap, 
  Shield, 
  Sparkles, 
  CheckCircle, 
  Flame, 
  Activity, 
  Crosshair,
  UserCheck
} from 'lucide-react';
import { CHARACTER_COMBOS } from '../data/freeFireData';
import { CharacterCombo } from '../types';
import { sounds } from '../utils/soundEffects';

interface ActiveChar {
  id: string;
  name: string;
  skill: string;
  desc: string;
  cd: string;
  role: string;
}

interface PassiveChar {
  id: string;
  name: string;
  skill: string;
  desc: string;
  type: string;
}

const ACTIVE_CHARACTERS: ActiveChar[] = [
  { id: 'tatsuya', name: 'Tatsuya', skill: 'Rebel Rush', desc: 'Dashes forward at rapid speed (3 charges). Rapid repositioning and Gloo Wall break.', cd: '45s', role: 'Rusher' },
  { id: 'alok', name: 'Alok (Awakened)', skill: 'Drop the Beat', desc: 'Creates 5m aura restoring 3 HP/s and boosting movement speed by 15% for 10s.', cd: '45s', role: 'Rusher/IGL' },
  { id: 'k', name: 'K (Captain Booyah)', skill: 'Master of All', desc: 'Max EP 250. Converts 3 EP to HP per sec (Jiujitsu) or restores 3 EP every 2s.', cd: '3s switch', role: 'Sustain Tank' },
  { id: 'chrono', name: 'Chrono', skill: 'Time Turner', desc: 'Force field blocks 800 damage. Safe peek shooting zone.', cd: '75s', role: 'Sniper' },
  { id: 'dimitri', name: 'Dimitri', skill: 'Healing Heartbeat', desc: 'Creates 3.5m healing zone where downed teammates self-recover.', cd: '60s', role: 'Support' },
  { id: 'homer', name: 'Homer', skill: 'Senses Shockwave', desc: 'Releases drone slowing enemy movement by 60% and firing rate by 35%.', cd: '60s', role: 'Intel/IGL' },
  { id: 'wukong', name: 'Wukong', skill: 'Camouflage', desc: 'Transforms into a bush. Resets cooldown whenever an enemy is downed.', cd: 'Reset on knock', role: '1v4 Rusher' },
  { id: 'orion', name: 'Orion', skill: 'Crimson Crush', desc: 'Consumes 150 EP to become invulnerable while absorbing 15 HP from enemies.', cd: '3s', role: 'Close Combat' },
];

const PASSIVE_CHARACTERS: PassiveChar[] = [
  { id: 'hayato', name: 'Hayato (Awakened)', skill: 'Art of Blades', desc: '+10% Armor penetration per 10% lost HP + frontal damage reduction.', type: 'Offense' },
  { id: 'kelly', name: 'Kelly (Awakened)', skill: 'Deadly Velocity', desc: '+6% sprint speed + 106% damage on first shot after sprint.', type: 'Mobility' },
  { id: 'jota', name: 'Jota', skill: 'Sustained Raids', desc: 'Gun hits restore HP; knockdowns instantly recover 20% max HP.', type: 'Sustain' },
  { id: 'moco', name: 'Moco (Awakened)', skill: 'Hacker\'s Eye', desc: 'Tags hit enemies for up to 6.5s, visible through walls for the squad.', type: 'Intel' },
  { id: 'rafael', name: 'Rafael', skill: 'Dead Silent', desc: 'Silences all snipers & marksman rifles. Downed enemies bleed 85% faster.', type: 'Sniper' },
  { id: 'maro', name: 'Maro', skill: 'Falcon Fervor', desc: 'Damage increases with distance up to +25%. Marked enemies take +3.5%.', type: 'Offense' },
  { id: 'laura', name: 'Laura', skill: 'Sharp Shooter', desc: 'Increases accuracy by 50% while scoped in.', type: 'Accuracy' },
  { id: 'luqueta', name: 'Luqueta', skill: 'Hat Trick', desc: 'Every kill permanently boosts max HP up to +50 HP (Total 250 HP).', type: 'Defense' },
  { id: 'nairi', name: 'Nairi', skill: 'Ice Iron', desc: 'Gloo walls self-repair 50 durability/s; +35% damage to enemy Gloo walls.', type: 'Defense' },
  { id: 'miguel', name: 'Miguel', skill: 'Crazy Slayer', desc: 'Gain 200 EP on each enemy knock down.', type: 'Sustain' },
  { id: 'shirou', name: 'Shirou', skill: 'Damage Delivered', desc: 'Attacker marked for 6s. First counter shot has +100% armor pen.', type: 'Offense' },
  { id: 'alvaro', name: 'Alvaro (Awakened)', skill: 'Art of Demolition', desc: 'Explosive damage increased by 20% + grenades split into 3 extra blastlets.', type: 'Grenadier' },
];

export const CharacterCombos: React.FC = () => {
  const [combos] = useState<CharacterCombo[]>(CHARACTER_COMBOS);
  const [selectedActive, setSelectedActive] = useState<ActiveChar>(ACTIVE_CHARACTERS[0]);
  const [selectedPassives, setSelectedPassives] = useState<PassiveChar[]>([
    PASSIVE_CHARACTERS[0],
    PASSIVE_CHARACTERS[1],
    PASSIVE_CHARACTERS[2]
  ]);

  const togglePassive = (passive: PassiveChar) => {
    sounds.playClick();
    const exists = selectedPassives.some(p => p.id === passive.id);
    if (exists) {
      if (selectedPassives.length > 1) {
        setSelectedPassives(selectedPassives.filter(p => p.id !== passive.id));
      }
    } else {
      if (selectedPassives.length < 3) {
        setSelectedPassives([...selectedPassives, passive]);
      } else {
        // replace the oldest selected
        setSelectedPassives([...selectedPassives.slice(1), passive]);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 font-rajdhani">
            CHARACTER COMBAT SYNERGIES
          </span>
          <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
            <Zap className="w-3.5 h-3.5" /> 1 Active + 3 Passive Meta Deck
          </span>
        </div>
        <h2 className="text-2xl font-bold font-heading text-white">
          Pro Skill Synergy & Ability Builder
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
          Tournament-validated character skill decks for rushers, marksmen, zone anchors, and clutch revivalists. Combine active abilities with complementary passive amplifiers.
        </p>
      </div>

      {/* Preset Meta Decks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {combos.map((combo) => (
          <div
            key={combo.id}
            className="bg-[#101423] border border-slate-800 hover:border-orange-500/50 rounded-2xl p-5 space-y-4 shadow-xl transition-all"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-orange-400 px-2 py-0.5 bg-orange-500/10 rounded border border-orange-500/20">
                  {combo.role}
                </span>
                <h3 className="font-heading font-bold text-white text-base mt-1">
                  {combo.name}
                </h3>
              </div>
            </div>

            {/* Active Skill */}
            <div className="bg-[#1a1728] border border-purple-500/30 rounded-xl p-3 flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-md">
                <Zap className="w-5 h-5 text-yellow-300" />
              </div>
              <div className="text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">ACTIVE SKILL</span>
                  <span className="font-bold text-white">{combo.activeSkill.character} • {combo.activeSkill.skillName}</span>
                </div>
                <p className="text-slate-300 text-[11px] mt-0.5">{combo.activeSkill.description}</p>
              </div>
            </div>

            {/* Passive Skills */}
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                PASSIVE AMPLIFIERS (3 SLOTS)
              </span>
              <div className="grid grid-cols-1 gap-2">
                {combo.passiveSkills.map((p, idx) => (
                  <div key={idx} className="bg-[#090b14] border border-slate-800 rounded-lg p-2.5 text-xs flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px] flex items-center justify-center shrink-0">
                      #{idx + 1}
                    </span>
                    <div>
                      <span className="font-bold text-amber-300">{p.character}: </span>
                      <span className="font-semibold text-white">{p.skillName}</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">{p.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Synergy Note */}
            <div className="bg-[#14192b] border border-orange-500/20 rounded-xl p-3 text-[11px] text-slate-300">
              <strong className="text-orange-400">Tactical Advantage: </strong>
              {combo.comboSynergy}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Custom Ability Deck Builder */}
      <div className="bg-[#101423] border border-orange-500/30 rounded-2xl p-5 space-y-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-heading font-bold text-lg text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-orange-400" />
              Build Your Custom Synergy Deck
            </h3>
            <p className="text-xs text-slate-400">
              Select 1 Active Character + 3 Passives to calculate custom squad synergy
            </p>
          </div>
          <div className="text-xs font-mono bg-[#14192b] px-3 py-1.5 rounded-lg border border-slate-700">
            Selected: <strong className="text-orange-400">1 Active</strong> + <strong className="text-amber-300">{selectedPassives.length}/3 Passives</strong>
          </div>
        </div>

        {/* 1. Pick Active Character */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-purple-400" />
            Step 1: Choose Active Skill Character
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {ACTIVE_CHARACTERS.map((char) => {
              const isSelected = selectedActive.id === char.id;
              return (
                <div
                  key={char.id}
                  onClick={() => { setSelectedActive(char); sounds.playClick(); }}
                  className={`p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-purple-950/40 border-purple-500 shadow-md shadow-purple-500/20'
                      : 'bg-[#090b14] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white text-sm">{char.name}</span>
                    <span className="text-[10px] text-purple-400 font-mono">{char.cd}</span>
                  </div>
                  <div className="text-amber-300 font-semibold text-[11px]">{char.skill}</div>
                  <p className="text-slate-400 text-[10px] mt-1 line-clamp-2">{char.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* 2. Pick 3 Passives */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-amber-400" />
            Step 2: Choose 3 Passive Amplifiers ({selectedPassives.length}/3 selected)
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {PASSIVE_CHARACTERS.map((passive) => {
              const isSelected = selectedPassives.some(p => p.id === passive.id);
              return (
                <div
                  key={passive.id}
                  onClick={() => togglePassive(passive)}
                  className={`p-3 rounded-xl border text-xs transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-amber-950/30 border-amber-500 shadow-md shadow-amber-500/20'
                      : 'bg-[#090b14] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white text-xs">{passive.name}</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                      {passive.type}
                    </span>
                  </div>
                  <div className="text-orange-400 font-semibold text-[11px]">{passive.skill}</div>
                  <p className="text-slate-400 text-[10px] mt-1 line-clamp-2">{passive.desc}</p>
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-400"></div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Deck Preview Banner */}
        <div className="bg-[#090b14] border border-orange-500/30 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">YOUR CUSTOM METAGAME DECK</span>
            <div className="font-heading font-bold text-base text-white">
              {selectedActive.name} + {selectedPassives.map(p => p.name.split(' ')[0]).join(' + ')}
            </div>
            <p className="text-xs text-slate-300">
              Role: <strong className="text-orange-400">{selectedActive.role}</strong> • Balanced for high rank push and competitive 4v4 clash squad.
            </p>
          </div>

          <button
            onClick={() => {
              const summary = `🔥 MY FREE FIRE SKILL DECK:\nActive: ${selectedActive.name} (${selectedActive.skill})\nPassives: ${selectedPassives.map(p => `${p.name} - ${p.skill}`).join(' | ')}`;
              navigator.clipboard.writeText(summary);
              sounds.playClick();
              alert('Custom combo deck copied!');
            }}
            className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold rounded-xl shadow-lg cursor-pointer whitespace-nowrap"
          >
            Copy Custom Deck
          </button>
        </div>
      </div>
    </div>
  );
};
