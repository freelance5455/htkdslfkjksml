import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Upload,
  Smartphone,
  Users,
  User,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  ArrowRight,
  Mail,
} from 'lucide-react';
import { EventCategory, CustomGroupTier, EventTicketTier } from '../types';
import { triggerHaptic } from '../utils/haptics';

interface CreateEventModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateEventModal: React.FC<CreateEventModalProps> = ({ isOpen, onClose }) => {
  const { addEvent, showToast, setCurrentPage } = useApp();

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState<EventCategory>('concerts');
  const [city, setCity] = useState('Nairobi');
  const [venue, setVenue] = useState('');
  const [address, setAddress] = useState('');
  const [date, setDate] = useState('Saturday, Dec 12, 2026');
  const [time, setTime] = useState('6:00 PM');

  // Admission Ticket Tiers with Passes to Sell Customization to Any Amount
  const [admissionTiers, setAdmissionTiers] = useState<EventTicketTier[]>([
    {
      id: 'tier_early',
      name: 'Early Bird Pass',
      price: 2000,
      capacity: 200,
      description: 'Exclusive early admission discount with expedited entry',
      perks: 'Fast-track gate pass',
    },
    {
      id: 'tier_regular',
      name: 'Regular Admission',
      price: 3000,
      capacity: 800,
      description: 'Standard festival entry to all main grounds & stages',
      perks: 'General admission, all stages',
    },
    {
      id: 'tier_vip',
      name: 'VIP Raised Lounge',
      price: 6500,
      capacity: 150,
      description: 'Elevated balcony deck, private bar, express turnstile',
      perks: 'VIP Lounge, private bar',
    },
  ]);

  // Ticket types
  const [personalPrice, setPersonalPrice] = useState('2500');
  const [customGroupTiers, setCustomGroupTiers] = useState<CustomGroupTier[]>([
    {
      id: 'tier_mod_1',
      name: 'Squad Group Pass (4 Guests)',
      size: 4,
      price: 8500,
      perks: '4 wristbands, 15% discount, priority line',
    },
  ]);

  // Event owner direct M-Pesa payout & email settings
  const [hostMpesa, setHostMpesa] = useState('0712 345 678');
  const [hostName, setHostName] = useState('Sub-Zero Audio Arts');
  const [hostEmail, setHostEmail] = useState('host@eventra.live');
  const [autoSendBuyerEmail, setAutoSendBuyerEmail] = useState(true);
  const [ageRestriction, setAgeRestriction] = useState('All Ages');
  const [dressCode, setDressCode] = useState('Smart Casual');

  const [description, setDescription] = useState('');
  const [posterImage, setPosterImage] = useState('/src/assets/images/event_hero_festival_1793028386968.jpg');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPosterImage(reader.result);
          showToast('Custom poster uploaded successfully!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddTier = () => {
    const newTier: CustomGroupTier = {
      id: `tier_${Date.now()}`,
      name: 'VIP Table for 6',
      size: 6,
      price: 18000,
      perks: 'Complimentary drinks, reserved booth',
    };
    setCustomGroupTiers((prev) => [...prev, newTier]);
  };

  const handleUpdateTier = (index: number, updates: Partial<CustomGroupTier>) => {
    setCustomGroupTiers((prev) =>
      prev.map((tier, i) => (i === index ? { ...tier, ...updates } : tier))
    );
  };

  const handleRemoveTier = (index: number) => {
    setCustomGroupTiers((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !venue.trim()) {
      triggerHaptic('warning');
      showToast('Please provide an event title and venue');
      return;
    }

    triggerHaptic('medium');
    const pPrice = admissionTiers.length > 0 ? admissionTiers[0].price : (parseInt(personalPrice, 10) || 2000);
    const defaultGroupPrice = customGroupTiers.length > 0 ? customGroupTiers[0].price : pPrice * 4 * 0.85;
    const defaultGroupSize = customGroupTiers.length > 0 ? customGroupTiers[0].size : 4;
    const totalCapacity = admissionTiers.reduce((acc, t) => acc + (t.capacity || 0), 0) || 1000;

    addEvent({
      title,
      subtitle: subtitle || 'Curated Live Experience in Kenya',
      category,
      categoryLabel:
        category === 'concerts'
          ? 'Festival & Live'
          : category === 'classical'
          ? 'Symphony & Hall'
          : category === 'electronic'
          ? 'Electronic & Club'
          : category === 'sports'
          ? 'Stadium & Match'
          : 'Theatre & Stage',
      city,
      venue,
      address: address || `${venue}, ${city}, Kenya`,
      mapsUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${venue} ${city}`)}`,
      date,
      time,
      doorTime: '1 hour prior',
      isoDate: new Date().toISOString(),
      image: posterImage,
      price: pPrice,
      personalPrice: pPrice,
      groupPrice: defaultGroupPrice,
      groupSize: defaultGroupSize,
      tiers: admissionTiers,
      groupTiers: customGroupTiers,
      capacity: totalCapacity,
      hostMpesa: hostMpesa || '0712 345 678',
      hostName: hostName || 'Verified Host',
      organizer: hostName || 'Verified Host',
      description: description || 'Extraordinary live experience with direct contactless entry and spatial acoustics.',
      highlights: [
        'Personal & Custom Group tiers supported',
        `Automatic M-Pesa payout to host (${hostMpesa})`,
        'Turnstile verified pass with distinct code',
        'Instant automated email pass delivery',
      ],
      hostEmail,
      autoSendBuyerEmail,
      ageRestriction,
      dressCode,
      isUserCreated: true,
      isTrending: true,
    });

    onClose();
    setCurrentPage('dashboard');
    showToast(`"${title}" published! Live on organizer dashboard.`);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg my-8 bg-[#111317] rounded-[32px] shadow-2xl border border-[#1f2229] p-6 sm:p-8 text-[#f4f4f6]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#1f2229]">
          <div>
            <h2 className="text-lg font-bold text-white">
              Create New Live Experience
            </h2>
            <p className="text-xs text-[#9496a1]">
              Personal & custom group tickets with direct host M-Pesa payout
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-[#1f2229] flex items-center justify-center text-[#9496a1] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4 max-h-[75vh] overflow-y-auto pr-1">
          {/* Poster Upload */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#b8b9c2]">
              Event Artwork Poster
            </label>
            <div className="flex items-center gap-3">
              <img
                src={posterImage}
                alt="Event Poster Preview"
                className="w-16 h-16 rounded-xl object-cover border border-[#262934] shrink-0"
              />
              <div className="flex-1">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-11 px-3 rounded-xl border border-[#262934] bg-[#16181f] hover:bg-[#1a1d26] text-xs font-semibold text-[#f4f4f6] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Upload Poster from Device</span>
                </button>
              </div>
            </div>
          </div>

          {/* Title & Category */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#b8b9c2]">
              Event Title
            </label>
            <input
              type="text"
              placeholder="e.g. Solstice Sunset Acoustic Garden"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-sm font-medium text-white placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2]">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as EventCategory)}
                className="w-full h-12 px-3 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-medium text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="concerts" className="bg-[#16181f]">Festival & Live</option>
                <option value="classical" className="bg-[#16181f]">Symphony Hall</option>
                <option value="electronic" className="bg-[#16181f]">Club & DJ</option>
                <option value="sports" className="bg-[#16181f]">Stadium Match</option>
                <option value="theatre" className="bg-[#16181f]">Theatre & Opera</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2]">
                City
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-medium text-white placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Venue & Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#b8b9c2]">
              Venue & Location
            </label>
            <input
              type="text"
              placeholder="e.g. Nairobi Arboretum Grounds"
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
              className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-medium text-white placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2]">
                Event Date
              </label>
              <input
                type="text"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-medium text-white focus:border-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2]">
                Time
              </label>
              <input
                type="text"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-medium text-white focus:border-emerald-500 focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Automated Email Ticket Delivery */}
          <div className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-xs font-bold text-white block">
                  Automated Email Pass Delivery
                </span>
                <span className="text-[10px] text-[#9496a1]">
                  Dispatches pass voucher directly to buyer's email
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAutoSendBuyerEmail(!autoSendBuyerEmail)}
              className={`w-10 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                autoSendBuyerEmail ? 'bg-emerald-500' : 'bg-[#262934]'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                  autoSendBuyerEmail ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Pricing */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#b8b9c2]">
              Individual Ticket Price (KES)
            </label>
            <input
              type="number"
              value={personalPrice}
              onChange={(e) => setPersonalPrice(e.target.value)}
              className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-sm font-mono font-bold text-white focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Host M-Pesa Payout */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#b8b9c2]">
              Host Safaricom M-Pesa Number (B2C Cashout)
            </label>
            <input
              type="text"
              value={hostMpesa}
              onChange={(e) => setHostMpesa(e.target.value)}
              placeholder="0712 345 678"
              className="w-full h-12 px-4 rounded-xl border border-[#262934] bg-[#16181f] text-xs font-mono font-bold text-white focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full h-12 mt-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98"
          >
            <span>Publish Live Experience</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </form>
      </div>
    </div>
  );
};
