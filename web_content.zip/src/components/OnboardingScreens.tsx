import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Check, Lock } from 'lucide-react';
import { ClassLevel, LanguageCode } from '../types/edutoon';
import { Logo } from './Logo';

interface LanguageSelectionProps {
  studentName: string;
  initialLanguage: LanguageCode | '';
  onSelectLanguage: (lang: LanguageCode) => Promise<void>;
}

export const LanguageSelectionScreen: React.FC<LanguageSelectionProps> = ({
  studentName,
  initialLanguage,
  onSelectLanguage,
}) => {
  const [selected, setSelected] = useState<LanguageCode>(initialLanguage || 'en');
  const [saving, setSaving] = useState(false);

  const handleConfirm = async () => {
    setSaving(true);
    try {
      await onSelectLanguage(selected);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F6F8FC] flex flex-col items-center justify-center px-5 py-10">
      <div className="w-full max-w-2xl">
        <div className="flex flex-col items-center text-center mb-8">
          <Logo size="lg" />
          <h1 className="mt-4 font-display text-2xl sm:text-3xl font-bold text-slate-900">
            Choose Your Learning Language
          </h1>
          <p className="mt-1.5 text-sm sm:text-base text-slate-600">
            Welcome, <span className="font-semibold text-slate-900">{studentName}</span>. Select
            your preferred medium — you can also explore both Hindi and English sections anytime.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <motion.button
            type="button"
            whileTap={{ scale: 0.985 }}
            onClick={() => setSelected('hi')}
            className={`text-left p-6 rounded-2xl border-2 transition-all cursor-pointer ${
              selected === 'hi'
                ? 'border-sky-500 bg-white shadow-[0_0_24px_rgba(56,189,248,0.28)]'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <span className="font-display text-3xl font-bold text-slate-900">हिंदी</span>
              <span
                className={`h-6 w-6 rounded-full flex items-center justify-center border ${
                  selected === 'hi'
                    ? 'bg-sky-600 border-sky-600 text-white'
                    : 'border-slate-300 bg-slate-50'
                }`}
              >
                {selected === 'hi' && <Check className="h-4 w-4" />}
              </span>
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-800">हिंदी माध्यम (Hindi Medium)</p>
            <p className="mt-1 text-xs sm:text-sm text-slate-500 leading-relaxed">
              सरल हिंदी भाषा में एनिमेटेड वीडियो, अध्याय नोट्स और डाउनलोड करने योग्य PDF अध्ययन सामग्री।
            </p>
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.985 }}
            onClick={() => setSelected('en')}
            className={`text-left p-6 rounded-2xl border-2 transition-all cursor-pointer ${
              selected === 'en'
                ? 'border-sky-500 bg-white shadow-[0_0_24px_rgba(56,189,248,0.28)]'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <span className="font-display text-3xl font-bold text-slate-900">English</span>
              <span
                className={`h-6 w-6 rounded-full flex items-center justify-center border ${
                  selected === 'en'
                    ? 'bg-sky-600 border-sky-600 text-white'
                    : 'border-slate-300 bg-slate-50'
                }`}
              >
                {selected === 'en' && <Check className="h-4 w-4" />}
              </span>
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-800">English Medium</p>
            <p className="mt-1 text-xs sm:text-sm text-slate-500 leading-relaxed">
              Interactive animated concept lessons, structured chapter notes, and downloadable PDF guides in English.
            </p>
          </motion.button>
        </div>

        <div className="mt-8 flex justify-center">
          <button
            type="button"
            disabled={saving}
            onClick={handleConfirm}
            className="w-full sm:w-auto min-w-[240px] min-h-[48px] px-8 py-3 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <span>{saving ? 'Saving Medium...' : 'Continue to Class Selection'}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

interface ClassSelectionProps {
  language: LanguageCode;
  onLockClass: (classLevel: ClassLevel) => Promise<void>;
}

const CLASS_LEVELS: ClassLevel[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

export const ClassSelectionScreen: React.FC<ClassSelectionProps> = ({
  language,
  onLockClass,
}) => {
  const [selectedClass, setSelectedClass] = useState<ClassLevel | null>(null);
  const [confirmStep, setConfirmStep] = useState(false);
  const [saving, setSaving] = useState(false);
  const isHi = language === 'hi';

  const handleLock = async () => {
    if (!selectedClass) return;
    setSaving(true);
    try {
      await onLockClass(selectedClass);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070E24] text-white px-5 py-8 sm:py-12 flex flex-col items-center justify-center">
      <div className="w-full max-w-4xl">
        <div className="flex flex-col items-center text-center mb-8">
          <Logo size="lg" glow />
          <h1 className="mt-4 font-display text-2xl sm:text-3xl font-bold text-white">
            {isHi ? 'अपनी कक्षा चुनें (कक्षा 1 से 10)' : 'Select Your Class (Classes 1–10)'}
          </h1>
          <p className="mt-2 text-sm text-slate-300 max-w-xl">
            {isHi
              ? 'शैक्षणिक सत्र 2026–2027 के लिए आपकी चुनी हुई कक्षा लॉक हो जाएगी। बाद में बदलाव के लिए क्लास चेंज रिपोर्ट भेजनी होगी।'
              : 'Your selected class locks for the 2026–2027 academic session. Later changes require submitting a Class Change Report for admin approval.'}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {CLASS_LEVELS.map((num, idx) => {
            const isSelected = selectedClass === num;
            return (
              <motion.button
                key={num}
                type="button"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03, duration: 0.28 }}
                onClick={() => {
                  setSelectedClass(num);
                  setConfirmStep(false);
                }}
                className={`class-card-3d rounded-2xl p-5 flex flex-col items-center justify-center text-center border-2 cursor-pointer min-h-[120px] ${
                  isSelected
                    ? 'class-card-3d-selected bg-gradient-to-b from-sky-500 to-blue-700 border-sky-300 text-white'
                    : 'bg-slate-900/90 border-slate-700/80 text-slate-100 hover:border-sky-400/70'
                }`}
              >
                <span className="text-xs font-medium tracking-wide text-sky-200">
                  {isHi ? 'कक्षा' : 'Class'}
                </span>
                <span className="mt-1 font-display text-3xl sm:text-4xl font-extrabold font-mono-num">
                  {num}
                </span>
                <span className="mt-1.5 text-[11px] text-slate-300">
                  {num <= 5
                    ? isHi
                      ? 'प्राथमिक स्तर'
                      : 'Primary'
                    : num <= 8
                      ? isHi
                        ? 'माध्यमिक स्तर'
                        : 'Middle'
                      : isHi
                        ? 'हाई स्कूल'
                        : 'Secondary'}
                </span>
              </motion.button>
            );
          })}
        </div>

        <div className="mt-8 bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-start gap-3 text-left">
            <Lock className="h-5 w-5 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-white">
                {selectedClass
                  ? isHi
                    ? `कक्षा ${selectedClass} चुनी गई — सत्र 2026–2027 के लिए लॉक होगी`
                    : `Class ${selectedClass} selected — Locks for Academic Session 2026–2027`
                  : isHi
                    ? 'कृपया आगे बढ़ने के लिए ऊपर से कोई एक कक्षा चुनें'
                    : 'Tap any 3D class card above to continue'}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {isHi
                  ? 'सत्र के दौरान छात्र सीधे कक्षा नहीं बदल सकते।'
                  : 'Students cannot switch classes directly once locked.'}
              </p>
            </div>
          </div>

          {!confirmStep ? (
            <button
              type="button"
              disabled={!selectedClass}
              onClick={() => setConfirmStep(true)}
              className="w-full sm:w-auto min-h-[46px] px-6 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0"
            >
              <span>{isHi ? 'कक्षा कन्फर्म करें' : 'Confirm Class'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setConfirmStep(false)}
                className="min-h-[46px] px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:text-white text-sm font-medium cursor-pointer"
              >
                {isHi ? 'बदलें' : 'Change'}
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleLock}
                className="flex-1 sm:flex-initial min-h-[46px] px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-bold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Lock className="h-4 w-4" />
                <span>
                  {saving
                    ? isHi
                      ? 'लॉक हो रहा है...'
                      : 'Locking...'
                    : isHi
                      ? `कक्षा ${selectedClass} लॉक करें`
                      : `Lock Class ${selectedClass}`}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
