import React, { useState } from 'react';
import {
  BarChart2,
  BookOpen,
  DollarSign,
  FolderKanban,
  Hexagon,
  Home,
  KeyRound,
  Lock,
  Megaphone,
  Menu,
  MessageSquare,
  Plus,
  ShoppingBag,
  Sparkles,
  Speaker,
  X,
} from 'lucide-react';
import { AvatarConfig, CatalogItem, StudioPart } from '../types/game';
import { MiniAvatarIcon } from './GameThumbnail';

interface CreatorHubPageProps {
  username: string;
  avatar: AvatarConfig;
  projectTitle: string;
  projectDescription: string;
  studioParts: StudioPart[];
  published: boolean;
  ugcItems: CatalogItem[];
  onOpenStudio: (title: string) => void;
  onOpenUgcStudio: () => void;
  onOpenCreateModal: () => void;
  onBackToSlapbox: () => void;
}

type CreatorTab = 'beranda' | 'kreasi' | 'pelajari' | 'toko' | 'analitik';

export const CreatorHubPage: React.FC<CreatorHubPageProps> = ({
  username,
  avatar,
  projectTitle,
  projectDescription,
  studioParts,
  published,
  ugcItems,
  onOpenStudio,
  onOpenUgcStudio,
  onOpenCreateModal,
  onBackToSlapbox,
}) => {
  const [tab, setTab] = useState<CreatorTab>('beranda');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [creationTab, setCreationTab] = useState<'experiences' | 'ugc'>('experiences');

  const navItems: { id: CreatorTab; label: string; icon: React.ReactNode }[] = [
    { id: 'beranda', label: 'Beranda', icon: <Home className="w-4 h-4" /> },
    { id: 'kreasi', label: 'Kreasi', icon: <FolderKanban className="w-4 h-4" /> },
    { id: 'pelajari', label: 'Pelajari', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'toko', label: 'Toko', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'analitik', label: 'Analitik', icon: <BarChart2 className="w-4 h-4" /> },
  ];

  return (
    <div className="h-screen w-screen flex bg-[#09090b] text-zinc-100 overflow-hidden">
      {/* Desktop Sidebar / Mobile Drawer */}
      <aside
        className={`${
          drawerOpen ? 'fixed inset-y-0 left-0 z-40 flex' : 'hidden md:flex'
        } flex-col w-64 bg-[#111113] border-r border-zinc-800 p-4 justify-between shrink-0`}
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-display text-lg font-black tracking-tight">
              <Hexagon className="w-5 h-5 text-white" />
              KREATOR
            </div>
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              className="md:hidden text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2.5 px-2 py-2 rounded-xl bg-zinc-900/90 border border-zinc-800">
            <MiniAvatarIcon avatar={avatar} size={32} />
            <span className="text-sm font-semibold">{username}</span>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium cursor-pointer ${
                  tab === item.id ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}

            <div className="pt-2 border-t border-zinc-800/80 space-y-1 text-zinc-500 text-sm">
              <div className="flex items-center gap-3 px-3 py-2">
                <MessageSquare className="w-4 h-4" /> Forum
              </div>
              <div className="flex items-center gap-3 px-3 py-2">
                <Speaker className="w-4 h-4" /> Update
              </div>
              <div className="flex items-center gap-3 px-3 py-2">
                <KeyRound className="w-4 h-4" /> Kunci API
              </div>
              <div className="flex items-center gap-3 px-3 py-2">
                <DollarSign className="w-4 h-4" /> Keuangan
              </div>
              <div className="flex items-center gap-3 px-3 py-2">
                <Megaphone className="w-4 h-4" /> Iklan
              </div>
            </div>
          </nav>
        </div>

        <button
          type="button"
          onClick={onBackToSlapbox}
          className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-sm font-semibold text-white cursor-pointer"
        >
          <Hexagon className="w-4 h-4 text-rose-400" />
          Kembali ke Slapbox
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        <header className="flex items-center justify-between px-5 h-14 border-b border-zinc-800 shrink-0">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              className="md:hidden text-zinc-300 hover:text-white cursor-pointer"
              aria-label="Menu Kreator"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display text-lg font-bold capitalize">
              {tab === 'beranda' ? 'Beranda Kreator' : tab === 'kreasi' ? 'Kreasi Game & UGC (Terpisah)' : tab}
            </h1>
          </div>
          <MiniAvatarIcon avatar={avatar} size={32} />
        </header>

        <main className="flex-1 min-h-0 overflow-y-auto p-5 md:p-7 space-y-7 max-w-5xl">
          {tab === 'beranda' && (
            <>
              <section>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-display text-lg font-bold">Pilih Studio Pembuatan</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Card 1: Bikin Game / Map */}
                  <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-5 space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-lime-300 to-cyan-300 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-sky-400">
                          Game Studio (Map 3D)
                        </div>
                        <div className="font-display font-bold text-base text-white truncate">
                          {projectTitle || 'Baseplate Kosong'}
                        </div>
                        <div className="inline-flex items-center gap-1.5 text-xs text-zinc-400 mt-0.5">
                          <Lock className="w-3.5 h-3.5" />
                          {published ? 'Publik' : 'Draft'} · {studioParts.length + 1} Objek
                        </div>
                      </div>
                    </div>

                    {projectDescription && (
                      <p className="text-xs text-zinc-400 line-clamp-2">{projectDescription}</p>
                    )}

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => onOpenStudio(projectTitle || 'Baseplate Kosong')}
                        className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white cursor-pointer"
                      >
                        Edit Map di Game Studio
                      </button>
                      <button
                        type="button"
                        onClick={onOpenCreateModal}
                        className="px-3.5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white cursor-pointer"
                      >
                        + Map Baru
                      </button>
                    </div>
                  </div>

                  {/* Card 2: Bikin UGC Item Sendiri (Terpisah) */}
                  <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-5 space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-xl bg-white text-black flex items-center justify-center shrink-0">
                        <Sparkles className="w-6 h-6" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                          UGC Studio (Jual Aksesori Avatar)
                        </div>
                        <div className="font-display font-bold text-base text-white">
                          Buat & Jual UGC Sendiri
                        </div>
                        <div className="text-xs text-zinc-400 mt-0.5">
                          {ugcItems.length} item UGC dipublish · Harga & Kreator tampil di Toko
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-400">
                      Desain aksesoris kepala, sayap belakang, atau pegangan tangan, beri nama dan harga Slapbux untuk dijual!
                    </p>

                    <button
                      type="button"
                      onClick={onOpenUgcStudio}
                      className="w-full py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
                    >
                      Buka UGC Studio (Terpisah)
                    </button>
                  </div>
                </div>
              </section>

              <section>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-display text-lg font-bold">Item UGC Kamu ({ugcItems.length})</h2>
                  <button
                    type="button"
                    onClick={() => {
                      setTab('kreasi');
                      setCreationTab('ugc');
                    }}
                    className="text-xs font-semibold text-sky-400 hover:text-sky-300 cursor-pointer"
                  >
                    Lihat semua UGC
                  </button>
                </div>

                {ugcItems.length === 0 ? (
                  <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-5 text-xs text-zinc-400">
                    Belum ada UGC yang kamu publish. Klik &ldquo;Buka UGC Studio&rdquo; di atas untuk membuat dan menjual item UGC pertamamu!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {ugcItems.map((u) => (
                      <div key={u.id} className="rounded-2xl bg-zinc-900 border border-zinc-800 p-3 space-y-1.5">
                        <div
                          style={{ backgroundColor: `${u.accentColor}22` }}
                          className="h-20 rounded-xl flex items-center justify-center font-display text-xl font-black text-white"
                        >
                          {u.letter}
                        </div>
                        <div className="text-xs font-bold text-white truncate">{u.name}</div>
                        <div className="text-[11px] text-zinc-400 truncate">Kreator: {u.creator}</div>
                        <div className="text-xs font-bold text-emerald-400 font-mono-num">
                          {u.price.toLocaleString('id-ID')} Slapbux
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section>
                <h2 className="font-display text-lg font-bold mb-3">Pelajari</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-4">
                    <div className="font-bold text-sm text-white">Game Studio vs UGC Studio</div>
                    <p className="text-xs text-zinc-400 mt-1">
                      Pembuatan Game/Map dan pembuatan item UGC dipisah agar fokus membangun dunia dan item avatar lebih rapi.
                    </p>
                  </div>
                  <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-4">
                    <div className="font-bold text-sm text-white">Cara jual UGC sendiri</div>
                    <p className="text-xs text-zinc-400 mt-1">
                      Buka UGC Studio, susun bentuk 3D, klik Publish & Jual UGC lalu tentukan nama dan harga Slapbux.
                    </p>
                  </div>
                </div>
              </section>
            </>
          )}

          {tab === 'kreasi' && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCreationTab('experiences')}
                  className={`px-4 py-2 rounded-full text-xs font-bold cursor-pointer ${
                    creationTab === 'experiences' ? 'bg-white text-zinc-950' : 'bg-zinc-900 text-zinc-300'
                  }`}
                >
                  Game / Map Saya
                </button>
                <button
                  type="button"
                  onClick={() => setCreationTab('ugc')}
                  className={`px-4 py-2 rounded-full text-xs font-bold cursor-pointer ${
                    creationTab === 'ugc' ? 'bg-white text-zinc-950' : 'bg-zinc-900 text-zinc-300'
                  }`}
                >
                  UGC Saya ({ugcItems.length})
                </button>
              </div>

              {creationTab === 'experiences' ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  <button
                    type="button"
                    onClick={onOpenCreateModal}
                    className="h-44 rounded-2xl border-2 border-dashed border-zinc-700 hover:border-zinc-500 bg-zinc-900/50 flex flex-col items-center justify-center gap-2 text-xs font-semibold text-zinc-300 cursor-pointer"
                  >
                    <Plus className="w-6 h-6" />
                    Buat Game / Map Baru
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenStudio(projectTitle || 'Baseplate Kosong')}
                    className="text-left space-y-2 cursor-pointer group"
                  >
                    <div className="h-44 rounded-2xl bg-gradient-to-br from-lime-300 via-emerald-300 to-cyan-300 group-hover:opacity-90 transition-opacity" />
                    <div className="text-xs text-zinc-400 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> {published ? 'Publik' : 'Draft'}
                    </div>
                    <div className="text-sm font-bold text-white truncate">{projectTitle || 'Baseplate Kosong'}</div>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  <button
                    type="button"
                    onClick={onOpenUgcStudio}
                    className="h-44 rounded-2xl border-2 border-dashed border-zinc-700 hover:border-white bg-zinc-900/50 flex flex-col items-center justify-center gap-2 text-xs font-semibold text-white cursor-pointer p-3 text-center"
                  >
                    <Sparkles className="w-6 h-6" />
                    Buat & Jual UGC Baru
                  </button>

                  {ugcItems.map((u) => (
                    <div
                      key={u.id}
                      className="rounded-2xl bg-zinc-900 border border-zinc-800 p-3 flex flex-col justify-between h-44"
                    >
                      <div
                        style={{ backgroundColor: `${u.accentColor}22` }}
                        className="h-24 rounded-xl flex items-center justify-center font-display text-2xl font-black text-white"
                      >
                        {u.letter}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white truncate">{u.name}</div>
                        <div className="text-[11px] text-zinc-400 truncate">Kreator: {u.creator}</div>
                        <div className="text-xs font-bold text-emerald-400 font-mono-num">
                          {u.price.toLocaleString('id-ID')} Slapbux
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {(tab === 'pelajari' || tab === 'toko' || tab === 'analitik') && (
            <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-6 space-y-4">
              <h2 className="font-display text-lg font-bold text-white capitalize">{tab}</h2>
              <p className="text-sm text-zinc-400">
                {tab === 'analitik'
                  ? `Game "${projectTitle || 'Baseplate Kosong'}": ${studioParts.length + 1} objek (${published ? 'Publik' : 'Draft'}) · Total UGC dijual: ${ugcItems.length}`
                  : 'Pilih Game Studio untuk membangun map 3D, atau UGC Studio untuk mendesain & menjual aksesoris avatar.'}
              </p>
              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={() => onOpenStudio(projectTitle || 'Baseplate Kosong')}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white cursor-pointer"
                >
                  Buka Game Studio 3D
                </button>
                <button
                  type="button"
                  onClick={onOpenUgcStudio}
                  className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
                >
                  Buka UGC Studio 3D
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
