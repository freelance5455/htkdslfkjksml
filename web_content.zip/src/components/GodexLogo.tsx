import React from 'react';
import { Godex3DGlyph } from './Godex3DGlyph';

export interface GodexLogoProps {
  size?: 16 | 20 | 24 | 28 | 32 | 40 | 48 | 64;
  showText?: boolean;
  showTagline?: boolean;
  textClassName?: string;
  className?: string;
  variant?: 'mark' | 'full' | 'compact' | 'hero';
  pulse?: boolean;
}

/**
 * GODEX Official Engineering Brand Mark
 * 3D Geometric identity with faceted isometric G core and futuristic typography.
 */
export const GodexLogo: React.FC<GodexLogoProps> = ({
  size = 28,
  showText = false,
  showTagline = false,
  textClassName = '',
  className = '',
  variant = 'mark',
  pulse = false
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* 3D Faceted G Glyph */}
      <div
        className={`relative flex items-center justify-center shrink-0 rounded-lg transition-transform duration-200 ${
          pulse ? 'animate-pulse' : ''
        }`}
        style={{
          width: size,
          height: size
        }}
      >
        <Godex3DGlyph 
          size={size} 
          withOrbitalRing={size >= 40} 
          withGlow={size >= 24}
        />
      </div>

      {/* Brand Text */}
      {(showText || variant === 'full' || variant === 'hero') && (
        <div className="flex flex-col leading-none">
          <div className="flex items-center gap-1.5">
            <span className={`font-black tracking-[0.14em] text-white font-sans ${textClassName || 'text-sm'}`}>
              GODEX
            </span>
            {variant === 'hero' && (
              <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40">
                PRO
              </span>
            )}
          </div>
          {(showTagline || variant === 'hero' || variant === 'full') && (
            <span className="text-[9px] font-mono text-neutral-400 tracking-wider mt-0.5">
              Design. Build. Evolve. Perfect.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
