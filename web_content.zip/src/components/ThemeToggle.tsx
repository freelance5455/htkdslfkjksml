import React, { useState, useRef, useEffect } from 'react';
import { useApp, ThemeMode } from '../context/AppContext';
import { Sparkles, Moon, Sun, Check, ChevronDown } from 'lucide-react';

interface ThemeToggleProps {
  variant?: 'dropdown' | 'buttons' | 'compact';
  className?: string;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ variant = 'dropdown', className = '' }) => {
  const { themeMode, setThemeMode } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const THEMES: { id: ThemeMode; label: string; sublabel: string; icon: React.ReactNode }[] = [
    {
      id: 'default',
      label: 'Default Mode',
      sublabel: 'Cyber Obsidian & Neon',
      icon: <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
    },
    {
      id: 'dark',
      label: 'Dark Mode',
      sublabel: 'Pure OLED Dark',
      icon: <Moon className="w-3.5 h-3.5 text-indigo-400" />
    },
    {
      id: 'light',
      label: 'Light Mode',
      sublabel: 'Clean Campus White',
      icon: <Sun className="w-3.5 h-3.5 text-amber-400" />
    }
  ];

  const currentTheme = THEMES.find(t => t.id === themeMode) || THEMES[0];

  // 1. Button Segmented Control (great for Profile or Onboarding)
  if (variant === 'buttons') {
    return (
      <div className={`grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-slate-950/80 border border-slate-800 ${className}`}>
        {THEMES.map(theme => {
          const isActive = themeMode === theme.id;
          return (
            <button
              key={theme.id}
              type="button"
              onClick={() => setThemeMode(theme.id)}
              className={`py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                isActive
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm shadow-cyan-500/10 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              {theme.icon}
              <span className="truncate">{theme.label.replace(' Mode', '')}</span>
            </button>
          );
        })}
      </div>
    );
  }

  // 2. Compact Toggle: Cycles through themes on click
  if (variant === 'compact') {
    const cycleNext = () => {
      if (themeMode === 'default') setThemeMode('dark');
      else if (themeMode === 'dark') setThemeMode('light');
      else setThemeMode('default');
    };

    return (
      <button
        type="button"
        onClick={cycleNext}
        className={`p-1.5 sm:p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-slate-300 transition-all flex items-center gap-1 text-xs font-medium active:scale-95 shadow-sm ${className}`}
        title={`Current Theme: ${currentTheme.label} (Click to switch)`}
      >
        {currentTheme.icon}
        <span className="hidden sm:inline text-[11px] font-medium text-slate-300">
          {currentTheme.label.replace(' Mode', '')}
        </span>
      </button>
    );
  }

  // 3. Dropdown Menu (Default for Header)
  return (
    <div className={`relative inline-block ${className}`} ref={containerRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1 px-1.5 sm:px-2 py-1 sm:py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-slate-300 text-[10px] sm:text-[11px] font-semibold transition-all shadow-sm active:scale-95"
        title="Change App Theme Mode (Default / Dark / Light)"
      >
        {currentTheme.icon}
        <span className="hidden sm:inline font-mono uppercase text-[10px] text-cyan-300">
          {currentTheme.label.replace(' Mode', '')}
        </span>
        <ChevronDown className="w-3 h-3 text-slate-400" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-52 p-1.5 rounded-2xl bg-[#0e111d] border border-cyan-500/30 shadow-2xl shadow-black/80 z-50 animate-in fade-in duration-150 backdrop-blur-xl">
          <div className="px-2.5 py-1.5 mb-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800/80 flex items-center justify-between">
            <span>Theme Mode</span>
            <span className="text-cyan-400 text-[9px] font-mono">3 Options</span>
          </div>

          <div className="space-y-1">
            {THEMES.map(theme => {
              const isActive = themeMode === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => {
                    setThemeMode(theme.id);
                    setIsOpen(false);
                  }}
                  className={`w-full p-2 rounded-xl text-left transition-all flex items-center justify-between ${
                    isActive
                      ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-200'
                      : 'hover:bg-slate-900 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded-lg bg-slate-950 border border-slate-800">
                      {theme.icon}
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-tight flex items-center gap-1.5">
                        <span>{theme.label}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 leading-tight">
                        {theme.sublabel}
                      </div>
                    </div>
                  </div>
                  {isActive && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
