import React, { useState, useRef, useEffect } from 'react';
import { useTheme, ThemeMode } from '../context/ThemeContext';
import { Sun, Moon, Clock, Check, ChevronDown, Sparkles } from 'lucide-react';

export const ThemeToggle: React.FC = () => {
  const { mode, resolvedTheme, isAuto, isDaytime, deviceTimeStr, setMode } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        id="theme-toggle-btn"
        onClick={() => setIsOpen(!isOpen)}
        title="التبديل بين الوضع المضيء والمظلم أو التلقائي حسب توقيت جهازك"
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all border cursor-pointer ${
          resolvedTheme === 'dark'
            ? 'bg-[#141a29] text-slate-200 border-slate-700/70 hover:border-rose-500/50 hover:bg-slate-800'
            : 'bg-white text-slate-700 border-slate-200 hover:border-rose-400 hover:bg-slate-50 shadow-sm'
        }`}
      >
        {isAuto ? (
          <div className="flex items-center gap-1.5">
            <span className="relative flex items-center justify-center text-amber-500">
              {isDaytime ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4 text-indigo-400" />}
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </span>
            <span className="hidden sm:inline font-bold text-[11px]">
              تلقائي <span className="font-normal opacity-75">({isDaytime ? 'نهاري' : 'ليلي'})</span>
            </span>
          </div>
        ) : mode === 'light' ? (
          <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
            <Sun className="w-4 h-4" />
            <span className="hidden sm:inline font-bold text-[11px]">مضيء</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-indigo-500 dark:text-indigo-400">
            <Moon className="w-4 h-4" />
            <span className="hidden sm:inline font-bold text-[11px]">مظلم</span>
          </div>
        )}

        <ChevronDown className={`w-3.5 h-3.5 opacity-60 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Popover Menu */}
      {isOpen && (
        <div
          id="theme-dropdown-menu"
          className={`absolute left-0 sm:left-auto sm:right-0 mt-2 w-72 rounded-2xl p-2 shadow-2xl border z-50 animate-in fade-in slide-in-from-top-2 duration-150 ${
            resolvedTheme === 'dark'
              ? 'bg-[#0f1422] border-slate-700/80 text-slate-100 shadow-black/80'
              : 'bg-white border-slate-200 text-slate-800 shadow-slate-300/60'
          }`}
        >
          <div className="px-3 py-2 border-b mb-1.5 flex items-center justify-between text-xs font-bold ${resolvedTheme === 'dark' ? 'border-slate-800 text-slate-300' : 'border-slate-100 text-slate-700'}">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-rose-500" />
              <span>مظهر التطبيق</span>
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500 font-semibold">
              توقيت جهازك: {deviceTimeStr}
            </span>
          </div>

          <div className="space-y-1">
            {/* Auto (Device Time) Option */}
            <button
              id="theme-option-auto"
              onClick={() => {
                setMode('auto');
                setIsOpen(false);
              }}
              className={`w-full flex items-start gap-3 p-2.5 rounded-xl text-right text-xs transition-colors cursor-pointer ${
                mode === 'auto'
                  ? resolvedTheme === 'dark'
                    ? 'bg-rose-950/40 text-rose-300 border border-rose-500/40 font-bold'
                    : 'bg-rose-50 text-rose-700 border border-rose-300 font-bold'
                  : resolvedTheme === 'dark'
                  ? 'hover:bg-slate-800/80 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <div className="mt-0.5 p-1.5 rounded-lg bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold">تلقائي حسب توقيت الجهاز</span>
                  {mode === 'auto' && <Check className="w-4 h-4 text-rose-500" />}
                </div>
                <p className="text-[11px] opacity-75 mt-0.5 leading-snug">
                  نهاري (6:00 ص - 6:00 م) • ليلي (6:00 م - 6:00 ص)
                </p>
                <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-500 font-semibold">
                  <span>الحالة الآن:</span>
                  <span>{isDaytime ? '☀️ نهاري مضيء' : '🌙 ليلي مظلم'}</span>
                </div>
              </div>
            </button>

            {/* Light Mode Option */}
            <button
              id="theme-option-light"
              onClick={() => {
                setMode('light');
                setIsOpen(false);
              }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-right text-xs transition-colors cursor-pointer ${
                mode === 'light'
                  ? resolvedTheme === 'dark'
                    ? 'bg-rose-950/40 text-rose-300 border border-rose-500/40 font-bold'
                    : 'bg-rose-50 text-rose-700 border border-rose-300 font-bold'
                  : resolvedTheme === 'dark'
                  ? 'hover:bg-slate-800/80 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                <Sun className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold">الوضع المضيء (نهاري)</span>
                  {mode === 'light' && <Check className="w-4 h-4 text-rose-500" />}
                </div>
                <p className="text-[11px] opacity-75 mt-0.5">مظهر نهاري فاتح دائم</p>
              </div>
            </button>

            {/* Dark Mode Option */}
            <button
              id="theme-option-dark"
              onClick={() => {
                setMode('dark');
                setIsOpen(false);
              }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-right text-xs transition-colors cursor-pointer ${
                mode === 'dark'
                  ? resolvedTheme === 'dark'
                    ? 'bg-rose-950/40 text-rose-300 border border-rose-500/40 font-bold'
                    : 'bg-rose-50 text-rose-700 border border-rose-300 font-bold'
                  : resolvedTheme === 'dark'
                  ? 'hover:bg-slate-800/80 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                <Moon className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold">الوضع المظلم (ليلي)</span>
                  {mode === 'dark' && <Check className="w-4 h-4 text-rose-500" />}
                </div>
                <p className="text-[11px] opacity-75 mt-0.5">مظهر ليلي مريح للعين أثناء المباريات</p>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
