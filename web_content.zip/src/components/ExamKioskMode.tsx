import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  KeyRound,
  Lock,
  Maximize2,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { ExambroConfig, ViolationEvent, ViolationType } from '../types/exambro';

interface ExamKioskModeProps {
  config: ExambroConfig;
  onExit: () => void;
}

function playAlarmBeep() {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(660, ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.18, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.45);
  } catch {
    // Ignore audio context errors if browser blocked autoplay before gesture
  }
}

function formatTime(totalSeconds: number): string {
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;
  return [hrs, mins, secs].map((v) => String(v).padStart(2, '0')).join(':');
}

export const ExamKioskMode: React.FC<ExamKioskModeProps> = ({
  config,
  onExit,
}) => {
  const isOnline = useOnlineStatus();
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const initialScreenWidthRef = useRef<number>(
    typeof window !== 'undefined' ? window.innerWidth : 1280,
  );

  const [tokenVerified, setTokenVerified] = useState(
    !config.security.requireToken,
  );
  const [tokenInput, setTokenInput] = useState('');
  const [tokenError, setTokenError] = useState('');

  const [secondsLeft, setSecondsLeft] = useState(config.durationMinutes * 60);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [violations, setViolations] = useState<ViolationEvent[]>([]);
  const [lockReason, setLockReason] = useState<string | null>(null);
  const [iframeKey, setIframeKey] = useState(0);
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const [showPinModal, setShowPinModal] = useState(false);
  const [pinMode, setPinMode] = useState<'EXIT' | 'UNLOCK'>('EXIT');
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const isLockedOut =
    violations.length >= config.maxViolationsBeforeLock ||
    lockReason !== null;

  const requestFullscreenSafe = useCallback(async () => {
    try {
      const target = containerRef.current || document.documentElement;
      if (!document.fullscreenElement && target.requestFullscreen) {
        await target.requestFullscreen();
      }
      setIsFullscreen(true);
    } catch {
      // Browser may reject fullscreen if not directly triggered by user gesture
    }
  }, []);

  const recordViolation = useCallback(
    (type: ViolationType, detail: string) => {
      if (!tokenVerified) return;
      const event: ViolationEvent = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
        type,
        detail,
      };
      setViolations((prev) => [event, ...prev]);
      setLockReason(detail);
      if (config.security.kioskSoundAlarm) {
        playAlarmBeep();
      }
    },
    [config.security.kioskSoundAlarm, tokenVerified],
  );

  // Enter fullscreen on mount
  useEffect(() => {
    if (tokenVerified) {
      void requestFullscreenSafe();
      initialScreenWidthRef.current = window.innerWidth;
    }
  }, [tokenVerified, requestFullscreenSafe]);

  // Countdown timer
  useEffect(() => {
    if (!tokenVerified) return;
    const interval = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(interval);
          setLockReason(
            'Waktu asesmen telah habis. Hubungi pengawas untuk mengakhiri sesi.',
          );
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [tokenVerified]);

  // Security listeners: tab switch, window blur, fullscreen exit, split-screen resize, keyboard shortcuts
  useEffect(() => {
    if (!tokenVerified) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        recordViolation(
          'TAB_SWITCH',
          'Siswa berpindah tab atau meminimalkan jendela Exambrowser.',
        );
      }
    };

    const handleWindowBlur = () => {
      // Distinguish genuine app/window blur from clicking inside the embedded exam iframe
      window.setTimeout(() => {
        const active = document.activeElement;
        if (document.hidden) return;
        if (active && active.tagName === 'IFRAME') {
          return;
        }
        if (config.security.detectFloatingApps) {
          recordViolation(
            'FOCUS_LOST',
            'Fokus keluar dari jendela ujian (indikasi membuka aplikasi lain atau jendela mengambang).',
          );
        }
      }, 120);
    };

    const handleFullscreenChange = () => {
      const active = Boolean(document.fullscreenElement);
      setIsFullscreen(active);
      if (!active && !showPinModal) {
        recordViolation(
          'FULLSCREEN_EXIT',
          'Mode layar penuh (Fullscreen) ditutup oleh pengguna.',
        );
      }
    };

    const handleResize = () => {
      if (!config.security.blockSplitScreen) return;
      const ratio = window.innerWidth / Math.max(window.screen.width, 1);
      if (window.screen.width >= 600 && ratio < 0.65) {
        recordViolation(
          'SPLIT_SCREEN',
          'Ukuran layar mengecil drastis (terindikasi mode Split-Screen / Multi-Window).',
        );
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      recordViolation(
        'CONTEXT_MENU',
        'Percobaan membuka menu klik kanan / inspect diblokir.',
      );
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      const ctrlOrMeta = e.ctrlKey || e.metaKey;

      const blockedCombo =
        e.key === 'F12' ||
        e.key === 'PrintScreen' ||
        (ctrlOrMeta && ['c', 'v', 'x', 'u', 's', 'p', 'a'].includes(key)) ||
        (ctrlOrMeta && e.shiftKey && ['i', 'j', 'c'].includes(key));

      if (blockedCombo) {
        e.preventDefault();
        e.stopPropagation();
        recordViolation(
          'SHORTCUT_BLOCKED',
          `Pintasan keyboard terlarang (${e.key}) diblokir.`,
        );
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    window.addEventListener('resize', handleResize);
    document.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown, true);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [
    tokenVerified,
    config.security.detectFloatingApps,
    config.security.blockSplitScreen,
    showPinModal,
    recordViolation,
  ]);

  const handleVerifyToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      tokenInput.trim().toUpperCase() ===
      config.security.examToken.trim().toUpperCase()
    ) {
      setTokenError('');
      setTokenVerified(true);
      void requestFullscreenSafe();
    } else {
      setTokenError('Token ujian tidak sesuai. Periksa kembali dengan pengawas.');
    }
  };

  const handleOpenPinModal = (mode: 'EXIT' | 'UNLOCK') => {
    setPinMode(mode);
    setPinInput('');
    setPinError('');
    setShowPinModal(true);
  };

  const handleSubmitPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() !== config.exitPin.trim()) {
      setPinError('PIN Pengawas salah.');
      return;
    }

    if (pinMode === 'EXIT') {
      if (document.fullscreenElement) {
        try {
          await document.exitFullscreen();
        } catch {
          // Ignore exit fullscreen error
        }
      }
      setShowPinModal(false);
      onExit();
    } else {
      setViolations([]);
      setLockReason(null);
      setShowPinModal(false);
      void requestFullscreenSafe();
    }
  };

  const handleResumeAfterWarning = () => {
    if (violations.length >= config.maxViolationsBeforeLock) {
      handleOpenPinModal('UNLOCK');
      return;
    }
    setLockReason(null);
    void requestFullscreenSafe();
  };

  if (!tokenVerified) {
    return (
      <div
        ref={containerRef}
        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950 p-4 exam-locked-surface"
      >
        <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-6 text-slate-100 shadow-2xl">
          <div className="flex items-center gap-3">
            <img
              src="/src/assets/images/exambro_shield_emblem_1794998133936.jpg"
              alt="Logo Exambro MTs Inayatul Marzuki"
              referrerPolicy="no-referrer"
              className="h-12 w-12 rounded-lg object-cover border border-slate-700"
            />
            <div>
              <h2 className="text-lg font-semibold text-white">
                {config.schoolName}
              </h2>
              <p className="text-xs text-slate-400">{config.examTitle}</p>
            </div>
          </div>

          <form onSubmit={handleVerifyToken} className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="exam-token-input"
                className="block text-sm font-medium text-slate-200"
              >
                Token Masuk Asesmen
              </label>
              <input
                id="exam-token-input"
                type="text"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="Masukkan token dari pengawas"
                autoFocus
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 font-mono text-sm uppercase tracking-wider text-white placeholder:normal-case placeholder:tracking-normal placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
              />
              {tokenError && (
                <p className="mt-1.5 text-xs text-red-400">{tokenError}</p>
              )}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-emerald-500 transition-colors"
              >
                Masuk Layar Penuh
              </button>
              <button
                type="button"
                onClick={onExit}
                className="rounded-lg border border-slate-700 px-4 py-2.5 text-sm font-medium text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Batal
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-white exam-locked-surface"
    >
      {/* Exam Kiosk Header Bar */}
      <header className="flex items-center justify-between gap-4 border-b border-emerald-900/60 bg-emerald-950 px-4 py-2.5 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <ShieldCheck
            className="h-5 w-5 text-emerald-400 shrink-0"
            aria-hidden="true"
          />
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold text-white">
              {config.schoolName} · {config.examTitle}
            </div>
            <div className="flex items-center gap-3 text-xs text-emerald-200/90">
              <span className="font-mono tabular-nums">
                Sisa Waktu: {formatTime(secondsLeft)}
              </span>
              <span aria-hidden="true">·</span>
              <span
                className={`font-mono tabular-nums ${
                  violations.length > 0 ? 'text-amber-300 font-semibold' : ''
                }`}
              >
                Pelanggaran: {violations.length}/{config.maxViolationsBeforeLock}
              </span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                {isOnline ? (
                  <>
                    <Wifi className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Terhubung</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3.5 w-3.5 text-red-400" />
                    <span className="text-red-300">Terputus</span>
                  </>
                )}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!isFullscreen && (
            <button
              type="button"
              onClick={() => void requestFullscreenSafe()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-700 bg-emerald-900/60 px-3 py-1.5 text-xs font-medium text-emerald-100 hover:bg-emerald-800 whitespace-nowrap"
            >
              <Maximize2 className="h-3.5 w-3.5" />
              Layar Penuh
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setIframeLoaded(false);
              setIframeKey((k) => k + 1);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-700 bg-emerald-900/50 px-3 py-1.5 text-xs font-medium text-emerald-100 hover:bg-emerald-800 whitespace-nowrap"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Muat Ulang
          </button>
          <button
            type="button"
            onClick={() => handleOpenPinModal('EXIT')}
            className="inline-flex items-center gap-1.5 rounded-lg bg-red-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-600 whitespace-nowrap"
          >
            <Lock className="h-3.5 w-3.5" />
            Keluar (PIN)
          </button>
        </div>
      </header>

      {/* Main Embedded Assessment Frame */}
      <main className="relative flex-1 bg-white">
        {!iframeLoaded && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-50 text-slate-700 p-6 text-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-emerald-700" />
            <p className="mt-3 text-sm font-medium text-slate-800">
              Memuat halaman asesmen MTs Inayatul Marzuki...
            </p>
            <p className="mt-1 max-w-md truncate font-mono text-xs text-slate-500">
              {config.examUrl}
            </p>
          </div>
        )}

        <iframe
          key={iframeKey}
          ref={iframeRef}
          src={config.examUrl}
          title={config.examTitle}
          onLoad={() => setIframeLoaded(true)}
          referrerPolicy="no-referrer-when-downgrade"
          allow="fullscreen"
          className="h-full w-full border-0"
        />

        {/* Security Violation Lockout Overlay */}
        {isLockedOut && (
          <div
            className="absolute inset-0 z-30 flex items-center justify-center bg-red-950/95 p-6 backdrop-blur-sm"
            role="alertdialog"
            aria-modal="true"
          >
            <div className="w-full max-w-lg rounded-xl border border-red-800 bg-slate-950 p-6 text-white shadow-2xl">
              <div className="flex items-start gap-3">
                <ShieldAlert className="h-7 w-7 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-lg font-semibold text-white">
                    {violations.length >= config.maxViolationsBeforeLock
                      ? 'Perangkat Terkunci Permanen — Hubungi Pengawas'
                      : 'Peringatan Keamanan Exambrowser'}
                  </h2>
                  <p className="mt-1.5 text-sm text-red-200">
                    {lockReason ||
                      'Batas pelanggaran perpindahan aplikasi telah tercapai.'}
                  </p>
                </div>
              </div>

              <div className="mt-4 rounded-lg border border-slate-800 bg-slate-900 p-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Log Pelanggaran Sesi Ini</span>
                  <span className="font-mono tabular-nums text-amber-300">
                    {violations.length} / {config.maxViolationsBeforeLock}
                  </span>
                </div>
                <ul className="mt-2 max-h-32 space-y-1.5 overflow-y-auto text-xs text-slate-300">
                  {violations.slice(0, 5).map((v) => (
                    <li key={v.id} className="flex items-start gap-2">
                      <span className="font-mono tabular-nums text-slate-500 shrink-0">
                        {v.timestamp}
                      </span>
                      <span>{v.detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-5 flex flex-col sm:flex-row gap-3">
                {violations.length < config.maxViolationsBeforeLock &&
                  secondsLeft > 0 && (
                    <button
                      type="button"
                      onClick={handleResumeAfterWarning}
                      className="flex-1 rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-red-950 hover:bg-slate-100 transition-colors"
                    >
                      Kembali ke Layar Penuh & Lanjutkan
                    </button>
                  )}
                <button
                  type="button"
                  onClick={() => handleOpenPinModal('UNLOCK')}
                  className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg border border-red-700 bg-red-900/60 px-4 py-2.5 text-sm font-medium text-white hover:bg-red-800 transition-colors"
                >
                  <KeyRound className="h-4 w-4" />
                  Buka Kunci (PIN Pengawas)
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Proctor PIN Verification Modal */}
      {showPinModal && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/80 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-6 text-white shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <AlertTriangle className="h-5 w-5 text-amber-400" />
                <h3 className="text-base font-semibold">
                  {pinMode === 'EXIT'
                    ? 'PIN Pengawas untuk Keluar Ujian'
                    : 'PIN Pengawas untuk Buka Kunci'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPinModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
                aria-label="Tutup dialog"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-2 text-xs text-slate-400">
              {pinMode === 'EXIT'
                ? 'Pastikan siswa sudah menekan tombol Kirim / Submit pada soal asesmen sebelum keluar.'
                : 'Memasukkan PIN akan mereset penghitung pelanggaran dan mengizinkan siswa melanjutkan.'}
            </p>

            {violations.length > 0 && (
              <div className="mt-3 rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-amber-300 font-mono tabular-nums">
                Tercatat {violations.length} percobaan keluar / pelanggaran.
              </div>
            )}

            <form onSubmit={handleSubmitPin} className="mt-4 space-y-4">
              <div>
                <label
                  htmlFor="proctor-pin-input"
                  className="block text-xs font-medium text-slate-300"
                >
                  PIN Pengawas
                </label>
                <input
                  id="proctor-pin-input"
                  type="password"
                  inputMode="numeric"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Masukkan PIN pengawas"
                  autoFocus
                  className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 font-mono text-sm text-white focus:border-emerald-500 focus:outline-none"
                />
                {pinError && (
                  <p className="mt-1.5 text-xs text-red-400">{pinError}</p>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="submit"
                  className="flex-1 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-emerald-500"
                >
                  {pinMode === 'EXIT' ? 'Akhiri Sesi Ujian' : 'Buka Kunci'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className="rounded-lg border border-slate-700 px-4 py-2.5 text-sm font-medium text-slate-300 hover:bg-slate-800"
                >
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
