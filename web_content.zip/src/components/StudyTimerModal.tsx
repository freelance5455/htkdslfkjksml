import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, X, Clock, Coffee, Sparkles } from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface StudyTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StudyTimerModal: React.FC<StudyTimerModalProps> = ({ isOpen, onClose }) => {
  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timer: any;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      fireCelebration();
      if (mode === 'study') {
        alert('🎉 Great focus session! Time for a 5-minute brain break.');
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        alert('⚡ Break over! Ready to get back into flow?');
        setMode('study');
        setTimeLeft(25 * 60);
      }
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft, mode]);

  if (!isOpen) return null;

  const toggleTimer = () => setIsRunning(!isRunning);

  const resetTimer = (newMode?: 'study' | 'break') => {
    setIsRunning(false);
    const m = newMode || mode;
    setMode(m);
    setTimeLeft(m === 'study' ? 25 * 60 : 5 * 60);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progressPercent = mode === 'study'
    ? ((25 * 60 - timeLeft) / (25 * 60)) * 100
    : ((5 * 60 - timeLeft) / (5 * 60)) * 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-semibold mb-2">
            <Clock className="w-3.5 h-3.5" />
            Pomodoro Focus Zone
          </div>
          <h3 className="text-xl font-bold text-slate-800">
            {mode === 'study' ? 'Deep Study Session' : 'Rest & Recharge'}
          </h3>
          <p className="text-xs text-slate-500">
            {mode === 'study' ? '25 minutes of laser-focused learning' : '5-minute stretch & hydrate'}
          </p>
        </div>

        {/* Mode switch */}
        <div className="flex bg-slate-100 p-1 rounded-xl mb-6">
          <button
            onClick={() => resetTimer('study')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
              mode === 'study' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Study (25m)
          </button>
          <button
            onClick={() => resetTimer('break')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
              mode === 'break' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Coffee className="w-3.5 h-3.5" /> Break (5m)
          </button>
        </div>

        {/* Circular Progress & Clock */}
        <div className="flex flex-col items-center justify-center my-4">
          <div className="relative w-48 h-48 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="84"
                className="stroke-slate-100"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="96"
                cy="96"
                r="84"
                className={`transition-all duration-500 ${
                  mode === 'study' ? 'stroke-blue-600' : 'stroke-emerald-500'
                }`}
                strokeWidth="10"
                strokeDasharray={527}
                strokeDashoffset={527 - (527 * progressPercent) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="font-mono text-4xl font-extrabold tracking-tight text-slate-800">
                {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
              </span>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mt-1">
                {isRunning ? 'Timer Active' : 'Paused'}
              </span>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-3 mt-4">
          <button
            onClick={() => resetTimer()}
            className="p-3 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
            title="Reset timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          <button
            onClick={toggleTimer}
            className={`px-8 py-3 rounded-2xl font-bold text-white shadow-lg flex items-center gap-2 transition ${
              mode === 'study'
                ? 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/25'
                : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/25'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5" /> Pause
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" /> Start
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
