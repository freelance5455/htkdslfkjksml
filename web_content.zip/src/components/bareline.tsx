import { useEffect, useMemo, useRef, useState } from "react";
import { Menu, Plus, Send, Trash2, X } from "lucide-react";
import { sendChat, type ChatTurn } from "@/lib/chat.functions";

type Thread = {
  id: string;
  title: string;
  messages: ChatTurn[];
  updated: number;
};

const STORE = "bareline.threads.v1";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function starter(): Thread {
  return { id: "start", title: "New chat", messages: [], updated: 0 };
}

function loadThreads(): Thread[] {
  try {
    const raw = localStorage.getItem(STORE);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Thread[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function titleFrom(text: string) {
  const line = text.replace(/\s+/g, " ").trim();
  return line.length > 42 ? `${line.slice(0, 42)}…` : line || "New chat";
}

export function Bareline() {
  const [threads, setThreads] = useState<Thread[]>(() => [starter()]);
  const [activeId, setActiveId] = useState("start");
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [rail, setRail] = useState(false);
  const [ready, setReady] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const box = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const existing = loadThreads();
    if (existing.length) {
      setThreads(existing);
      setActiveId(existing[0].id);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORE, JSON.stringify(threads));
  }, [threads, ready]);

  const active = useMemo(
    () => threads.find((t) => t.id === activeId) ?? threads[0],
    [threads, activeId],
  );

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
  }, [active?.messages.length, busy]);

  function newChat() {
    const t: Thread = { id: uid(), title: "New chat", messages: [], updated: Date.now() };
    setThreads((prev) => [t, ...prev]);
    setActiveId(t.id);
    setError("");
    setRail(false);
    box.current?.focus();
  }

  function removeThread(id: string) {
    setThreads((prev) => {
      const next = prev.filter((t) => t.id !== id);
      if (!next.length) {
        const t: Thread = { id: uid(), title: "New chat", messages: [], updated: Date.now() };
        setActiveId(t.id);
        return [t];
      }
      if (id === activeId) setActiveId(next[0].id);
      return next;
    });
  }

  async function submit() {
    const text = draft.trim();
    if (!text || busy || !active) return;
    setDraft("");
    setError("");
    const userTurn: ChatTurn = { role: "user", content: text };
    const history = [...active.messages, userTurn];
    setThreads((prev) =>
      prev.map((t) =>
        t.id === active.id
          ? {
              ...t,
              title: t.messages.length === 0 ? titleFrom(text) : t.title,
              messages: history,
              updated: Date.now(),
            }
          : t,
      ),
    );
    setBusy(true);
    try {
      const result = await sendChat({ data: { messages: history } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setThreads((prev) =>
        prev.map((t) =>
          t.id === active.id
            ? {
                ...t,
                messages: [...history, { role: "assistant", content: result.text }],
                updated: Date.now(),
              }
            : t,
        ),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something broke.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-dvh bg-bg text-fg">
      {rail && (
        <button
          type="button"
          aria-label="Close threads"
          className="fixed inset-0 z-20 bg-black/50 md:hidden"
          onClick={() => setRail(false)}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex w-72 flex-col border-r border-line bg-surface transition-transform md:static md:translate-x-0 ${
          rail ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between gap-2 px-4 py-4">
          <div>
            <p className="font-display text-2xl leading-none tracking-tight">Bareline</p>
            <p className="mt-1 text-xs text-muted">Direct answers. Nothing extra.</p>
          </div>
          <button
            type="button"
            className="grid size-10 place-items-center rounded-full text-muted md:hidden"
            aria-label="Close menu"
            onClick={() => setRail(false)}
          >
            <X size={18} />
          </button>
        </div>
        <div className="px-3">
          <button
            type="button"
            onClick={newChat}
            className="flex h-11 w-full items-center justify-center gap-2 rounded-full bg-accent font-medium text-accent-ink"
          >
            <Plus size={16} />
            New chat
          </button>
        </div>
        <div className="mt-4 flex-1 overflow-y-auto px-2 pb-4">
          {threads.map((t) => (
            <div
              key={t.id}
              className={`group mb-1 flex items-center rounded-xl ${
                t.id === active?.id ? "bg-surface-2" : "hover:bg-surface-2"
              }`}
            >
              <button
                type="button"
                onClick={() => {
                  setActiveId(t.id);
                  setRail(false);
                }}
                className="min-h-11 flex-1 truncate px-3 text-left text-sm"
              >
                {t.title}
              </button>
              <button
                type="button"
                aria-label="Delete chat"
                onClick={() => removeThread(t.id)}
                className="mr-1 grid size-9 place-items-center rounded-lg text-muted opacity-100 md:opacity-0 md:group-hover:opacity-100"
              >
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      </aside>

      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 items-center gap-2 border-b border-line px-3 md:px-5">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full md:hidden"
            aria-label="Open threads"
            onClick={() => setRail(true)}
          >
            <Menu size={18} />
          </button>
          <p className="truncate font-medium">{active?.title ?? "Bareline"}</p>
        </header>

        <div ref={scroller} className="flex-1 overflow-y-auto px-4 py-6 md:px-8">
          <div className="mx-auto flex max-w-2xl flex-col gap-5">
            {active && active.messages.length === 0 && !busy && (
              <div className="pt-10">
                <h1 className="font-display text-4xl leading-tight md:text-5xl">Say it straight.</h1>
                <p className="mt-3 max-w-md text-muted">
                  Ask for a plan, a rewrite, a diagnosis, or working code. Bareline answers the question and stops.
                </p>
                <div className="mt-8 flex flex-wrap gap-2">
                  {[
                    "Rewrite this email so it is shorter and clearer.",
                    "Explain why my React list re-renders on every keystroke.",
                    "Draft a week of dinners from what's already in a fridge.",
                  ].map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => {
                        setDraft(prompt);
                        box.current?.focus();
                      }}
                      className="rounded-full border border-line bg-surface px-4 py-2 text-left text-sm text-muted hover:text-fg"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {active?.messages.map((m, i) => (
              <article key={`${active.id}-${i}`} className={m.role === "user" ? "ml-8" : ""}>
                <p className="mb-1 text-xs uppercase tracking-wide text-muted">
                  {m.role === "user" ? "You" : "Bareline"}
                </p>
                <div
                  className={`whitespace-pre-wrap rounded-2xl px-4 py-3 text-[15px] ${
                    m.role === "user" ? "bg-surface-2" : "bg-surface"
                  }`}
                >
                  {m.content}
                </div>
              </article>
            ))}
            {busy && <p className="text-sm text-muted">Writing…</p>}
            {error && <p className="text-sm text-accent">{error}</p>}
          </div>
        </div>

        <form
          className="border-t border-line px-3 py-3 md:px-8"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <div className="mx-auto flex max-w-2xl items-end gap-2 rounded-2xl border border-line bg-surface p-2">
            <textarea
              ref={box}
              value={draft}
              rows={1}
              placeholder="Ask anything"
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void submit();
                }
              }}
              className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2 text-[15px] outline-none placeholder:text-muted"
            />
            <button
              type="submit"
              disabled={busy || !draft.trim()}
              aria-label="Send"
              className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent text-accent-ink disabled:opacity-40"
            >
              <Send size={16} />
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
