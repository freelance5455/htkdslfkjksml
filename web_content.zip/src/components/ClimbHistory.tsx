import React, { useState, useMemo } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  ClimbEntry,
  ClimbingStyle,
  ClimbOutcome,
  WallAngle,
  BOULDERING_GRADES,
  ROPED_GRADES
} from '../types/climbing';
import {
  Search,
  SlidersHorizontal,
  Edit2,
  Trash2,
  MapPin,
  Calendar,
  ArrowUpDown,
  X,
  Plus
} from 'lucide-react';

interface ClimbHistoryProps {
  onNavigateToLog?: () => void;
}

export const ClimbHistory: React.FC<ClimbHistoryProps> = ({ onNavigateToLog }) => {
  const { climbs, clubs, deleteClimb, updateClimb, getClubById } = useClimbing();

  // Real-time search & filters
  const [searchTerm, setSearchTerm] = useState('');
  const [styleFilter, setStyleFilter] = useState<string>('All');
  const [outcomeFilter, setOutcomeFilter] = useState<string>('All');
  const [clubFilter, setClubFilter] = useState<string>('All');
  const [angleFilter, setAngleFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'grade'>('date-desc');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Edit modal state
  const [editingClimb, setEditingClimb] = useState<ClimbEntry | null>(null);

  // Filtered climbs matching route name, location, or notes in real-time
  const filteredClimbs = useMemo(() => {
    return climbs
      .filter(climb => {
        if (searchTerm.trim()) {
          const term = searchTerm.toLowerCase().trim();
          const matchesRoute = climb.routeName.toLowerCase().includes(term);
          const matchesNotes = (climb.notes || '').toLowerCase().includes(term);
          const club = getClubById(climb.clubId);
          const matchesClubName = club ? club.name.toLowerCase().includes(term) : false;
          const matchesClubLocation = club ? club.location.toLowerCase().includes(term) : false;

          if (!matchesRoute && !matchesNotes && !matchesClubName && !matchesClubLocation) {
            return false;
          }
        }

        if (styleFilter !== 'All' && climb.style !== styleFilter) return false;
        if (outcomeFilter !== 'All' && climb.outcome !== outcomeFilter) return false;
        if (clubFilter !== 'All' && climb.clubId !== clubFilter) return false;
        if (angleFilter !== 'All' && climb.wallAngle !== angleFilter) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date-desc') {
          return b.date.localeCompare(a.date) || b.createdAt - a.createdAt;
        }
        if (sortBy === 'date-asc') {
          return a.date.localeCompare(b.date) || a.createdAt - b.createdAt;
        }
        if (sortBy === 'grade') {
          return a.grade.localeCompare(b.grade);
        }
        return 0;
      });
  }, [climbs, searchTerm, styleFilter, outcomeFilter, clubFilter, angleFilter, sortBy, getClubById]);

  const handleDelete = (climb: ClimbEntry) => {
    if (confirm(`Delete logged climb "${climb.routeName}" from your logbook?`)) {
      deleteClimb(climb.id);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClimb) return;
    updateClimb(editingClimb.id, {
      date: editingClimb.date,
      routeName: editingClimb.routeName,
      style: editingClimb.style,
      grade: editingClimb.grade,
      wallAngle: editingClimb.wallAngle,
      outcome: editingClimb.outcome,
      clubId: editingClimb.clubId,
      notes: editingClimb.notes,
      attemptsCount: editingClimb.attemptsCount
    });
    setEditingClimb(null);
  };

  return (
    <div className="space-y-4 w-full max-w-full overflow-hidden">
      {/* Real-time Search & Filter Strip */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Real-time Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by route name, location/centre, or notes in real-time..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Log & View Mode toggle */}
          <div className="flex items-center gap-2 justify-between sm:justify-end">
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  viewMode === 'cards' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Cards
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  viewMode === 'table' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Table
              </button>
            </div>

            {onNavigateToLog && (
              <button
                type="button"
                onClick={onNavigateToLog}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Climb</span>
              </button>
            )}
          </div>
        </div>

        {/* Filters Row */}
        <div className="flex items-center gap-1.5 flex-wrap text-xs pt-1">
          <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 font-semibold mr-1">
            <SlidersHorizontal className="w-3 h-3 text-orange-600" />
            <span>Filter:</span>
          </div>

          <select
            aria-label="Filter by Style"
            value={styleFilter}
            onChange={e => setStyleFilter(e.target.value)}
            className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-medium text-slate-700 dark:text-slate-200 text-xs"
          >
            <option value="All">All Styles</option>
            <option value="Top Rope">Top Rope</option>
            <option value="Lead">Lead</option>
            <option value="Bouldering">Bouldering</option>
            <option value="Auto-Belay">Auto-Belay</option>
          </select>

          <select
            aria-label="Filter by Outcome"
            value={outcomeFilter}
            onChange={e => setOutcomeFilter(e.target.value)}
            className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-medium text-slate-700 dark:text-slate-200 text-xs"
          >
            <option value="All">All Outcomes</option>
            <option value="Onsite">Onsite</option>
            <option value="Flash">Flash</option>
            <option value="Redpoint">Redpoint</option>
            <option value="Attempt">Attempt</option>
          </select>

          <select
            aria-label="Filter by Centre"
            value={clubFilter}
            onChange={e => setClubFilter(e.target.value)}
            className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-medium text-slate-700 dark:text-slate-200 text-xs max-w-[140px] truncate"
          >
            <option value="All">All Centres</option>
            {clubs.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>

          <select
            aria-label="Filter by Angle"
            value={angleFilter}
            onChange={e => setAngleFilter(e.target.value)}
            className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-medium text-slate-700 dark:text-slate-200 text-xs"
          >
            <option value="All">All Angles</option>
            <option value="Slab">Slab</option>
            <option value="Vertical">Vertical</option>
            <option value="Overhang">Overhang</option>
            <option value="Roof">Roof</option>
          </select>

          {/* Sort By */}
          <div className="ml-auto flex items-center gap-1 text-slate-500 dark:text-slate-400">
            <ArrowUpDown className="w-3 h-3" />
            <select
              aria-label="Sort Climbs"
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-medium text-slate-700 dark:text-slate-200 text-xs"
            >
              <option value="date-desc">Newest</option>
              <option value="date-asc">Oldest</option>
              <option value="grade">Grade</option>
            </select>
          </div>
        </div>

        {/* Count Indicator */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800">
          <div>
            Showing <span className="font-mono font-bold text-slate-800 dark:text-white">{filteredClimbs.length}</span> of <span className="font-mono text-slate-600 dark:text-slate-300">{climbs.length}</span> ascents
            {searchTerm && <span> matching "<span className="text-orange-600 dark:text-orange-400 font-semibold">{searchTerm}</span>"</span>}
          </div>
          {(styleFilter !== 'All' || outcomeFilter !== 'All' || clubFilter !== 'All' || angleFilter !== 'All' || searchTerm) && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setStyleFilter('All');
                setOutcomeFilter('All');
                setClubFilter('All');
                setAngleFilter('All');
              }}
              className="text-orange-600 dark:text-orange-400 hover:underline font-semibold"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Climbs List / Table */}
      {filteredClimbs.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 text-center text-slate-500 dark:text-slate-400 space-y-3">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            {climbs.length === 0 ? 'Your logbook has no recorded climbs yet.' : 'No ascents match your search criteria.'}
          </p>
          <p className="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">
            {climbs.length === 0
              ? 'Log individual top rope, lead, bouldering, or auto-belay climbs to build your candidate ascent record.'
              : 'Try clearing the search query or adjusting your filters.'}
          </p>
          {onNavigateToLog && (
            <button
              type="button"
              onClick={onNavigateToLog}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Log Climb</span>
            </button>
          )}
        </div>
      ) : viewMode === 'table' ? (
        /* Table View */
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs w-full">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs min-w-[620px]">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 font-bold text-slate-600 dark:text-slate-300">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Route / Problem</th>
                  <th className="py-2.5 px-2">Style</th>
                  <th className="py-2.5 px-2 text-center">Grade</th>
                  <th className="py-2.5 px-2">Angle</th>
                  <th className="py-2.5 px-2">Outcome</th>
                  <th className="py-2.5 px-3">Location / Centre</th>
                  <th className="py-2.5 px-3">Notes</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-normal text-slate-700 dark:text-slate-300">
                {filteredClimbs.map(climb => {
                  const club = getClubById(climb.clubId);
                  return (
                    <tr key={climb.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500 whitespace-nowrap">
                        {climb.date}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                        {climb.routeName}
                      </td>
                      <td className="py-2.5 px-2 whitespace-nowrap">
                        {climb.style}
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <span className="inline-block px-1.5 py-0.5 rounded font-mono font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800">
                          {climb.grade}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-slate-500">
                        {climb.wallAngle}
                      </td>
                      <td className="py-2.5 px-2 whitespace-nowrap">
                        <span
                          className={`font-semibold ${
                            climb.outcome === 'Onsite'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : climb.outcome === 'Flash'
                              ? 'text-orange-700 dark:text-orange-400'
                              : climb.outcome === 'Redpoint'
                              ? 'text-amber-700 dark:text-amber-400'
                              : 'text-slate-500'
                          }`}
                        >
                          {climb.outcome}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 truncate max-w-[140px]" title={club ? `${club.name} (${club.location})` : climb.clubId}>
                        {club ? club.name : 'Unknown Centre'}
                      </td>
                      <td className="py-2.5 px-3 truncate max-w-[160px] text-slate-500 italic" title={climb.notes}>
                        {climb.notes || '—'}
                      </td>
                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => setEditingClimb(climb)}
                            title="Edit entry"
                            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(climb)}
                            title="Delete entry"
                            className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Cards View */
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredClimbs.map(climb => {
            const club = getClubById(climb.clubId);
            return (
              <div
                key={climb.id}
                className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-4 shadow-xs space-y-2.5 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-mono font-bold text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white px-1.5 py-0.5 rounded">
                        {climb.grade}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">{climb.routeName}</h4>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 pt-0.5">
                      <span>{climb.style}</span>
                      <span>·</span>
                      <span
                        className={`font-semibold ${
                          climb.outcome === 'Onsite'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : climb.outcome === 'Flash'
                            ? 'text-orange-700 dark:text-orange-400'
                            : climb.outcome === 'Redpoint'
                            ? 'text-amber-700 dark:text-amber-400'
                            : 'text-slate-600'
                        }`}
                      >
                        {climb.outcome}
                      </span>
                      <span>·</span>
                      <span>{climb.wallAngle}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => setEditingClimb(climb)}
                      className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(climb)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {climb.notes && (
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 italic bg-slate-50 dark:bg-slate-800/60 p-2 rounded border border-slate-100 dark:border-slate-800">
                    "{climb.notes}"
                  </p>
                )}

                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1.5 border-t border-slate-100 dark:border-slate-800 font-mono">
                  <div className="flex items-center gap-1 truncate max-w-[180px]">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{club ? club.name : climb.clubId}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0 tabular-nums">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>{climb.date}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Climb Modal */}
      {editingClimb && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-lg border border-slate-200 dark:border-slate-800 overflow-hidden text-slate-900 dark:text-slate-100">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
              <h3 className="text-sm font-bold">Edit Logged Climb</h3>
              <button
                type="button"
                onClick={() => setEditingClimb(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-4 sm:p-5 space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Date *</label>
                  <input
                    type="date"
                    required
                    value={editingClimb.date}
                    onChange={e => setEditingClimb({ ...editingClimb, date: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Route Name *</label>
                  <input
                    type="text"
                    required
                    value={editingClimb.routeName}
                    onChange={e => setEditingClimb({ ...editingClimb, routeName: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Style</label>
                  <select
                    value={editingClimb.style}
                    onChange={e => {
                      const newStyle = e.target.value as ClimbingStyle;
                      const newGrade = newStyle === 'Bouldering' ? 'V3' : '6a';
                      setEditingClimb({ ...editingClimb, style: newStyle, grade: newGrade });
                    }}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {(['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'] as ClimbingStyle[]).map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Grade</label>
                  <select
                    value={editingClimb.grade}
                    onChange={e => setEditingClimb({ ...editingClimb, grade: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono font-bold"
                  >
                    {editingClimb.style === 'Bouldering'
                      ? BOULDERING_GRADES.map(g => <option key={g} value={g}>{g}</option>)
                      : ROPED_GRADES.map(g => <option key={g} value={g}>{g}</option>)
                    }
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Wall Angle</label>
                  <select
                    value={editingClimb.wallAngle}
                    onChange={e => setEditingClimb({ ...editingClimb, wallAngle: e.target.value as WallAngle })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {(['Slab', 'Vertical', 'Overhang', 'Roof'] as WallAngle[]).map(a => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Outcome</label>
                  <select
                    value={editingClimb.outcome}
                    onChange={e => setEditingClimb({ ...editingClimb, outcome: e.target.value as ClimbOutcome })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {(['Onsite', 'Flash', 'Redpoint', 'Attempt'] as ClimbOutcome[]).map(o => (
                      <option key={o} value={o}>{o}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Centre</label>
                <select
                  value={editingClimb.clubId}
                  onChange={e => setEditingClimb({ ...editingClimb, clubId: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  {clubs.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Notes</label>
                <textarea
                  rows={2}
                  value={editingClimb.notes}
                  onChange={e => setEditingClimb({ ...editingClimb, notes: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingClimb(null)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
