import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator, Zap, TrendingUp, DollarSign, ShieldCheck, Cpu, RefreshCw, CheckCircle2 } from 'lucide-react';
import { currencyConverter, DisplayCurrency } from '../lib/currencyConverter';

interface MiningRoiCalculatorProps {
  displayCurrency: DisplayCurrency;
  onShowToast?: (msg: string) => void;
}

export const MiningRoiCalculator: React.FC<MiningRoiCalculatorProps> = ({ displayCurrency, onShowToast }) => {
  const [hashrate, setHashrate] = useState<string>('110'); // TH/s
  const [powerWatts, setPowerWatts] = useState<string>('3250'); // Watts
  const [electricityCost, setElectricityCost] = useState<string>('0.08'); // $ per kWh
  const [poolFeePercent, setPoolFeePercent] = useState<string>('1.0'); // %
  const [btcPriceUsd, setBtcPriceUsd] = useState<number>(92500); // Current estimated BTC price in USD

  // Calculations
  const hashrateTh = parseFloat(hashrate) || 0;
  const powerW = parseFloat(powerWatts) || 0;
  const kwhRate = parseFloat(electricityCost) || 0;
  const poolFee = parseFloat(poolFeePercent) || 0;

  // Approx network difficulty reward model (approx 0.00000082 BTC per TH/s per day at current diff)
  const btcPerThPerDay = 0.00000084;
  const grossBtcPerDay = hashrateTh * btcPerThPerDay;
  const grossBtcPerWeek = grossBtcPerDay * 7;
  const grossBtcPerMonth = grossBtcPerDay * 30.44;

  const kwhPerDay = (powerW * 24) / 1000;
  const dailyPowerCostUsd = kwhPerDay * kwhRate;
  const monthlyPowerCostUsd = dailyPowerCostUsd * 30.44;

  const grossUsdPerDay = grossBtcPerDay * btcPriceUsd;
  const netUsdPerDay = grossUsdPerDay - dailyPowerCostUsd;
  const netUsdPerMonth = (grossUsdPerDay * 30.44) - monthlyPowerCostUsd;

  const netBtcPerMonth = grossBtcPerMonth * (1 - poolFee / 100);

  const formatCurrency = (amountUsd: number) => {
    const converted = currencyConverter.convertUsd(amountUsd, displayCurrency);
    return currencyConverter.formatValue(converted, displayCurrency);
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-lg">
            <Calculator className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/30">
                ASIC & RIG ESTIMATOR
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 mt-1">
              Mining ROI Calculator
            </h3>
            <p className="text-xs text-slate-400">
              Calculate daily, weekly, and monthly Bitcoin mining earnings based on network difficulty and internal rates.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950/80 px-4 py-2 rounded-2xl border border-amber-500/30">
          <Cpu className="w-4 h-4 text-amber-400 animate-pulse" />
          <span className="text-xs font-mono text-amber-200">BTC Benchmark: ${btcPriceUsd.toLocaleString()} USD</span>
        </div>
      </div>

      {/* Calculator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Inputs (6 cols) */}
        <div className="lg:col-span-6 space-y-5 bg-slate-950/70 p-5 sm:p-6 rounded-2xl border border-amber-500/20">
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Hardware & Energy Specifications</span>
          </h4>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1.5 flex items-center justify-between">
                <span>Hashrate (TH/s)</span>
                <span className="text-amber-400 font-mono">{hashrateTh} TH/s</span>
              </label>
              <input
                type="number"
                value={hashrate}
                onChange={(e) => setHashrate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                placeholder="110"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">e.g., Antminer S19 Pro (110 TH/s) or WhatsMiner M30S</span>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1.5 flex items-center justify-between">
                <span>Power Consumption (Watts)</span>
                <span className="text-amber-400 font-mono">{powerW} W</span>
              </label>
              <input
                type="number"
                value={powerWatts}
                onChange={(e) => setPowerWatts(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                placeholder="3250"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1.5 flex items-center justify-between">
                <span>Electricity Cost ($ / kWh)</span>
                <span className="text-amber-400 font-mono">${kwhRate} / kWh</span>
              </label>
              <input
                type="number"
                step="0.01"
                value={electricityCost}
                onChange={(e) => setElectricityCost(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                placeholder="0.08"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1.5 flex items-center justify-between">
                <span>Mining Pool Fee (%)</span>
                <span className="text-amber-400 font-mono">{poolFee}%</span>
              </label>
              <input
                type="number"
                step="0.1"
                value={poolFeePercent}
                onChange={(e) => setPoolFeePercent(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                placeholder="1.0"
              />
            </div>
          </div>
        </div>

        {/* Right Output Results (6 cols) */}
        <div className="lg:col-span-6 space-y-5">
          <div className="bg-gradient-to-br from-slate-950 to-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">Estimated Earnings & ROI</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                Profitable Mining
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Daily Net</span>
                <span className="text-sm sm:text-base font-bold text-amber-200 font-mono mt-1 block">
                  {formatCurrency(netUsdPerDay)}
                </span>
                <span className="text-[9px] text-slate-400 font-mono">
                  {(grossBtcPerDay * (1 - poolFee/100)).toFixed(6)} BTC
                </span>
              </div>

              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Weekly Net</span>
                <span className="text-sm sm:text-base font-bold text-amber-200 font-mono mt-1 block">
                  {formatCurrency(netUsdPerDay * 7)}
                </span>
                <span className="text-[9px] text-slate-400 font-mono">
                  {(grossBtcPerWeek * (1 - poolFee/100)).toFixed(5)} BTC
                </span>
              </div>

              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Monthly Net</span>
                <span className="text-sm sm:text-base font-bold text-amber-200 font-mono mt-1 block">
                  {formatCurrency(netUsdPerMonth)}
                </span>
                <span className="text-[9px] text-slate-400 font-mono">
                  {netBtcPerMonth.toFixed(4)} BTC
                </span>
              </div>
            </div>

            <div className="space-y-2.5 text-xs bg-slate-900/50 p-4 rounded-xl border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">Monthly Electricity Cost:</span>
                <span className="text-rose-300 font-mono">-${monthlyPowerCostUsd.toFixed(2)} USD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Gross Monthly Revenue:</span>
                <span className="text-emerald-300 font-mono">{formatCurrency(grossBtcPerMonth * btcPriceUsd)}</span>
              </div>
              <div className="flex justify-between font-bold pt-2 border-t border-slate-800">
                <span className="text-amber-300">Estimated Annual ROI:</span>
                <span className="text-amber-200 font-mono">
                  {(((netUsdPerMonth * 12) / 3500) * 100).toFixed(1)}% (Based on Rig Spec)
                </span>
              </div>
            </div>

            <button
              onClick={() => onShowToast?.('✓ Mining ROI configuration saved successfully to active rig profile!')}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>Save Rig ROI Profile to Wallet</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
