import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  BellPlus, 
  Volume2, 
  Play, 
  ShieldCheck, 
  Activity, 
  BarChart2, 
  CandlestickChart, 
  Loader2, 
  Check,
  Zap
} from 'lucide-react';
import { AssetData, GeminiAssetAnalysis, AudioSettings, SoundEffectType } from '../types/market';
import { fetchGeminiAssetAnalysis } from '../services/marketApi';
import { executeVoiceAlert, playChimeSound } from '../services/audioEngine';

interface AssetDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  asset: AssetData | null;
  audioSettings: AudioSettings;
  onOpenAlertModalForAsset: (asset: AssetData) => void;
  onApplyRecommendedAlert: (alertData: {
    targetPrice: number;
    condition: 'above' | 'below';
    voiceScript: string;
    soundChime: SoundEffectType;
  }) => void;
  language: 'fr' | 'en';
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  isOpen,
  onClose,
  asset,
  audioSettings,
  onOpenAlertModalForAsset,
  onApplyRecommendedAlert,
  language,
}) => {
  const [chartType, setChartType] = useState<'line' | 'candle'>('line');
  const [timeframe, setTimeframe] = useState<'1H' | '24H' | '7D' | '30D' | '1Y'>('24H');
  const [geminiAnalysis, setGeminiAnalysis] = useState<GeminiAssetAnalysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState<boolean>(false);
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number; price: number; time: string } | null>(null);

  // Auto-fetch or refresh Gemini analysis when opened
  useEffect(() => {
    if (!isOpen || !asset) return;
    let isMounted = true;
    async function loadAnalysis() {
      setIsLoadingAnalysis(true);
      try {
        const analysis = await fetchGeminiAssetAnalysis(asset!.id, language);
        if (isMounted) {
          setGeminiAnalysis(analysis);
        }
      } catch (e) {
        console.warn('Analysis fetch error', e);
      } finally {
        if (isMounted) setIsLoadingAnalysis(false);
      }
    }
    loadAnalysis();
    return () => {
      isMounted = false;
    };
  }, [isOpen, asset?.id, language]);

  if (!isOpen || !asset) return null;

  const isPositive = asset.change24h >= 0;

  // Generate synthetic multi-timeframe candle/line points grounded in real asset baseline
  const generateChartData = () => {
    const count = timeframe === '1H' ? 24 : timeframe === '24H' ? 36 : timeframe === '7D' ? 42 : 50;
    const base = asset.price;
    const volatility = asset.category === 'crypto' ? 0.025 : 0.008;
    const points: Array<{ open: number; close: number; high: number; low: number; time: string }> = [];

    let current = base * (1 - (isPositive ? 0.03 : -0.03));
    for (let i = 0; i < count; i++) {
      const delta = (Math.sin(i * 0.4) + (Math.random() - 0.48)) * (base * volatility);
      const open = current;
      const close = i === count - 1 ? base : current + delta;
      const high = Math.max(open, close) + Math.random() * (base * volatility * 0.6);
      const low = Math.min(open, close) - Math.random() * (base * volatility * 0.6);
      current = close;

      points.push({
        open,
        close,
        high,
        low,
        time: `${i * 2}:00`,
      });
    }
    return points;
  };

  const chartData = generateChartData();
  const allPrices = chartData.flatMap((d) => [d.low, d.high]);
  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  const priceRange = maxPrice - minPrice || 1;

  const chartWidth = 600;
  const chartHeight = 220;

  const linePointsString = chartData
    .map((d, idx) => {
      const x = (idx / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.close - minPrice) / priceRange) * (chartHeight - 30) - 15;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const handleTestVoiceScript = async (script: string, chime: SoundEffectType) => {
    await executeVoiceAlert(chime, script, audioSettings, language);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center font-bold text-white text-sm font-mono shadow-inner">
              {asset.symbol.slice(0, 4)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg text-white font-['Chakra_Petch']">
                  {asset.name}
                </h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
                  {asset.symbol}
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300">
                  {asset.category}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Dernière actualisation: {new Date(asset.lastUpdated).toLocaleTimeString()} &bull; Flux direct
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenAlertModalForAsset(asset)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all cursor-pointer shadow-sm"
            >
              <BellPlus className="w-4 h-4 text-amber-400" />
              <span>Créer Alerte Vocale</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Price Header & Metric Badges */}
          <div className="flex flex-wrap items-baseline justify-between gap-4 p-4 rounded-2xl bg-slate-900/50 border border-slate-800">
            <div>
              <div className="text-xs font-mono uppercase text-slate-400 mb-1">PRIX EN DIRECT</div>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono tracking-tight">
                  ${asset.price.toLocaleString(undefined, {
                    minimumFractionDigits: asset.price < 1 ? 4 : 2,
                    maximumFractionDigits: asset.price < 1 ? 4 : 2,
                  })}
                </span>
                <span className={`flex items-center gap-1 text-sm font-mono font-bold px-2.5 py-1 rounded-xl border ${
                  isPositive
                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                    : 'bg-rose-500/15 border-rose-500/30 text-rose-400'
                }`}>
                  {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  <span>{isPositive ? '+' : ''}{asset.change24h}%</span>
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">PLUS HAUT 24H</span>
                <span className="font-bold text-slate-200">${asset.high24h.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">PLUS BAS 24H</span>
                <span className="font-bold text-slate-200">${asset.low24h.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">VOLUME 24H</span>
                <span className="font-bold text-slate-200">{asset.volume24h}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-slate-500 block text-[10px]">CAPITALISATION</span>
                <span className="font-bold text-slate-200">{asset.marketCap || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Interactive Chart Container */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setChartType('line')}
                  className={`p-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                    chartType === 'line'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <BarChart2 className="w-3.5 h-3.5" />
                  <span>Courbe</span>
                </button>
                <button
                  onClick={() => setChartType('candle')}
                  className={`p-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                    chartType === 'candle'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <CandlestickChart className="w-3.5 h-3.5" />
                  <span>Chandelier</span>
                </button>
              </div>

              {/* Timeframes */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 font-mono text-xs">
                {(['1H', '24H', '7D', '30D', '1Y'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      timeframe === tf
                        ? 'bg-amber-500 text-slate-950 shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* SVG Chart */}
            <div className="relative w-full h-[220px] bg-slate-950/70 rounded-xl border border-slate-800/80 p-2 overflow-hidden flex items-center justify-center">
              <svg 
                className="w-full h-full overflow-visible" 
                viewBox={`0 0 ${chartWidth} ${chartHeight}`} 
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient id={`detail-grad-${asset.id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.35" />
                    <stop offset="100%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Horizontal reference grid lines */}
                {[0.2, 0.5, 0.8].map((ratio) => {
                  const y = chartHeight * ratio;
                  const priceLabel = maxPrice - priceRange * ratio;
                  return (
                    <g key={ratio}>
                      <line
                        x1="0"
                        y1={y}
                        x2={chartWidth}
                        y2={y}
                        stroke="#334155"
                        strokeDasharray="4 4"
                        strokeWidth="1"
                        opacity="0.4"
                      />
                      <text x="6" y={y - 4} fill="#64748b" fontSize="10" fontFamily="monospace">
                        ${priceLabel.toFixed(priceLabel < 1 ? 4 : 2)}
                      </text>
                    </g>
                  );
                })}

                {/* Mode 1: Line Chart */}
                {chartType === 'line' && (
                  <g>
                    <polygon
                      points={`0,${chartHeight} ${linePointsString} ${chartWidth},${chartHeight}`}
                      fill={`url(#detail-grad-${asset.id})`}
                    />
                    <polyline
                      fill="none"
                      stroke={isPositive ? '#10b981' : '#f43f5e'}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points={linePointsString}
                    />
                  </g>
                )}

                {/* Mode 2: Candlestick Chart */}
                {chartType === 'candle' &&
                  chartData.map((d, i) => {
                    const x = (i / (chartData.length - 1)) * chartWidth;
                    const candleWidth = Math.max(3, chartWidth / chartData.length - 2);
                    const isGreen = d.close >= d.open;
                    const highY = chartHeight - ((d.high - minPrice) / priceRange) * (chartHeight - 30) - 15;
                    const lowY = chartHeight - ((d.low - minPrice) / priceRange) * (chartHeight - 30) - 15;
                    const openY = chartHeight - ((d.open - minPrice) / priceRange) * (chartHeight - 30) - 15;
                    const closeY = chartHeight - ((d.close - minPrice) / priceRange) * (chartHeight - 30) - 15;
                    const bodyTop = Math.min(openY, closeY);
                    const bodyHeight = Math.max(2, Math.abs(openY - closeY));

                    return (
                      <g key={i}>
                        {/* Wick */}
                        <line
                          x1={x}
                          y1={highY}
                          x2={x}
                          y2={lowY}
                          stroke={isGreen ? '#10b981' : '#f43f5e'}
                          strokeWidth="1.2"
                        />
                        {/* Real Body */}
                        <rect
                          x={x - candleWidth / 2}
                          y={bodyTop}
                          width={candleWidth}
                          height={bodyHeight}
                          fill={isGreen ? '#10b981' : '#f43f5e'}
                          rx="1"
                        />
                      </g>
                    );
                  })}
              </svg>
            </div>
          </div>

          {/* Gemini AI Intelligence & Recommended Voice Alerts Section */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-950/40 via-slate-900 to-slate-950 border border-purple-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white font-['Chakra_Petch'] flex items-center gap-2">
                    ANALYSE TECHNIQUE & ALERTES IA GEMINI
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/40 text-purple-200">
                      gemini-3.8-flash
                    </span>
                  </h4>
                  <p className="text-xs text-purple-200/70">
                    Détection de niveaux de support/résistance et propositions d'alertes vocales
                  </p>
                </div>
              </div>

              {isLoadingAnalysis && (
                <div className="flex items-center gap-2 text-xs font-mono text-purple-300">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Analyse en cours...</span>
                </div>
              )}
            </div>

            {geminiAnalysis ? (
              <div className="space-y-4">
                {/* Sentiment & Levels Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-400 block">SENTIMENT MARCHÉ</span>
                    <span className={`font-bold text-sm ${
                      geminiAnalysis.sentiment === 'Bullish'
                        ? 'text-emerald-400'
                        : geminiAnalysis.sentiment === 'Bearish'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}>
                      {geminiAnalysis.sentiment}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-400 block">SUPPORT MAJEUR</span>
                    <span className="font-bold text-sm font-mono text-emerald-300">
                      ${geminiAnalysis.supportLevel?.toLocaleString() || (asset.low24h * 0.98).toFixed(2)}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-400 block">RÉSISTANCE CLÉ</span>
                    <span className="font-bold text-sm font-mono text-purple-300">
                      ${geminiAnalysis.resistanceLevel?.toLocaleString() || (asset.high24h * 1.02).toFixed(2)}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-[10px] font-mono text-slate-400 block">SCORE VOLATILITÉ</span>
                    <span className="font-bold text-sm text-amber-300">
                      {geminiAnalysis.volatilityScore}
                    </span>
                  </div>
                </div>

                {/* Gemini Summary */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-purple-500/20 text-xs text-slate-300 leading-relaxed font-mono">
                  {geminiAnalysis.summary}
                </div>

                {/* Recommended Alerts */}
                {geminiAnalysis.recommendedAlerts && geminiAnalysis.recommendedAlerts.length > 0 && (
                  <div className="space-y-2 pt-1">
                    <span className="text-xs font-mono font-bold text-purple-200 uppercase tracking-wide flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-purple-400" />
                      Alertes vocales recommandées par l'IA (1-clic pour armer)
                    </span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {geminiAnalysis.recommendedAlerts.map((rec, i) => (
                        <div
                          key={i}
                          className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-purple-500/50 transition-all flex flex-col justify-between space-y-2"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-bold text-xs text-white">{rec.label}</span>
                              <span className="font-mono text-xs font-bold text-amber-400">
                                {rec.type === 'above' ? '≥' : '≤'} ${rec.targetPrice.toLocaleString()}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 italic">"{rec.voiceScript}"</p>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                            <button
                              type="button"
                              onClick={() => handleTestVoiceScript(rec.voiceScript, rec.soundChime)}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 cursor-pointer"
                            >
                              <Play className="w-3 h-3 fill-slate-200" />
                              <span>Tester</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                onApplyRecommendedAlert({
                                  targetPrice: rec.targetPrice,
                                  condition: rec.type,
                                  voiceScript: rec.voiceScript,
                                  soundChime: rec.soundChime,
                                });
                                onClose();
                              }}
                              className="px-3 py-1 rounded-lg bg-purple-500 hover:bg-purple-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Armer l'Alerte</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-center text-xs text-slate-400">
                Chargement de la modélisation technique par Gemini...
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
