import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  Trash2,
  Globe,
  Mic,
  Image as ImageIcon,
  Loader2,
  Info
} from 'lucide-react';
import { Character, ChatMessage, ModelSettings } from '../types';

interface ChatRoomModalProps {
  character: Character;
  messages: ChatMessage[];
  onSendMessage: (text: string, isAudio?: boolean) => Promise<void>;
  onClose: () => void;
  onClearChat: () => void;
  modelSettings: ModelSettings;
  freeMessages: number;
}

export const ChatRoomModal: React.FC<ChatRoomModalProps> = ({
  character,
  messages,
  onSendMessage,
  onClose,
  onClearChat,
  modelSettings,
  freeMessages,
}) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceMuted, setIsVoiceMuted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;
    const textToSend = inputText;
    setInputText('');
    setIsLoading(true);

    try {
      await onSendMessage(textToSend);
    } catch (err) {
      console.error('Send message error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeechInput = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      alert('التعرف على الصوت غير مدعوم مباشرة في متصفحك.');
      return;
    }

    try {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA';
      recognition.interimResults = false;

      recognition.onstart = () => setIsRecording(true);
      recognition.onend = () => setIsRecording(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.start();
    } catch (e) {
      console.error(e);
      setIsRecording(false);
    }
  };

  // Text-To-Speech for character message
  const speakText = (text: string) => {
    if (isVoiceMuted) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      // Remove parentheses action text for cleaner audio reading
      const cleanText = text.replace(/\([^)]*\)/g, '').trim() || text;
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Helper function to format roleplay narrative in brackets
  const renderMessageContent = (content: string) => {
    const parts = content.split(/(\([^)]+\))/g);
    return parts.map((part, index) => {
      if (part.startsWith('(') && part.endsWith(')')) {
        return (
          <span
            key={index}
            className="text-pink-300 italic font-medium bg-pink-500/10 px-1 py-0.5 rounded text-xs block my-1"
          >
            {part}
          </span>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col h-full dir-rtl">
      {/* Top Bar Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between text-white shadow-md">
        <div className="flex items-center space-x-3 space-x-reverse">
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="relative">
            <img
              src={character.avatar}
              alt={character.name}
              className="w-10 h-10 rounded-full object-cover border border-pink-500/40"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border border-slate-900" />
          </div>

          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
              <span>{character.nameAr || character.name}</span>
              <span className="text-[10px] bg-pink-500/20 text-pink-300 px-2 py-0.2 rounded-full border border-pink-500/30">
                {modelSettings.chatModel}
              </span>
            </h3>
            <span className="text-[10px] text-green-400 font-medium">متصل الآن</span>
          </div>
        </div>

        {/* Right side controls */}
        <div className="flex items-center space-x-1.5 space-x-reverse">
          <button
            onClick={() => setIsVoiceMuted(!isVoiceMuted)}
            className={`p-2 rounded-xl border transition-colors ${
              isVoiceMuted
                ? 'bg-slate-800 border-slate-700 text-slate-400'
                : 'bg-pink-500/20 border-pink-500/40 text-pink-300'
            }`}
            title={isVoiceMuted ? 'تفعيل الصوت' : 'كتم الصوت'}
          >
            {isVoiceMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setShowInfo(!showInfo)}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title="معلومات الشخصية"
          >
            <Info className="w-4 h-4" />
          </button>

          <button
            onClick={onClearChat}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-400 hover:text-red-400 transition-colors"
            title="مسح الدردشة"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Info drawer toggle */}
      {showInfo && (
        <div className="bg-slate-900/95 border-b border-pink-500/20 p-3 text-xs text-slate-300 flex items-start space-x-3 space-x-reverse animate-fadeIn">
          <img
            src={character.avatar}
            alt=""
            className="w-12 h-12 rounded-xl object-cover border border-pink-500/30"
          />
          <div className="flex-1">
            <p className="font-bold text-white mb-1">{character.nameAr || character.name}</p>
            <p className="text-slate-300 leading-relaxed mb-1">{character.description}</p>
            <p className="text-[10px] text-pink-400 font-semibold">
              بواسطة: {character.creatorName || 'PinkVerse'}
            </p>
          </div>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
        {messages.length === 0 ? (
          <div className="text-center py-10 px-4">
            <div className="w-16 h-16 rounded-full bg-pink-500/10 border border-pink-500/30 mx-auto flex items-center justify-center mb-3">
              <Sparkles className="w-8 h-8 text-pink-400" />
            </div>
            <h4 className="font-bold text-white text-base mb-1">
              ابدأ الدردشة مع {character.nameAr || character.name}
            </h4>
            <p className="text-slate-400 text-xs max-w-xs mx-auto mb-4">
              {character.description}
            </p>

            {/* Default greeting bubble */}
            <div className="bg-slate-800/90 border border-slate-700 p-3.5 rounded-2xl max-w-sm mx-auto text-right text-xs text-slate-200 shadow-md">
              {renderMessageContent(character.greeting)}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex ${isUser ? 'justify-start' : 'justify-end'} items-end space-x-2 space-x-reverse`}
              >
                {!isUser && (
                  <img
                    src={character.avatar}
                    alt=""
                    className="w-7 h-7 rounded-full object-cover mb-1 border border-pink-500/30"
                  />
                )}

                <div
                  className={`max-w-[82%] p-3.5 rounded-2xl text-xs leading-relaxed shadow-md relative ${
                    isUser
                      ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-br-none'
                      : 'bg-slate-800 border border-slate-700/80 text-slate-100 rounded-bl-none'
                  }`}
                >
                  <div>{renderMessageContent(msg.text)}</div>

                  {/* Audio Speaker trigger for character replies */}
                  {!isUser && (
                    <button
                      onClick={() => speakText(msg.text)}
                      className="mt-2 text-[10px] text-pink-300 hover:text-white flex items-center gap-1 bg-pink-500/10 px-2 py-0.5 rounded-full border border-pink-500/20"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>استماع</span>
                    </button>
                  )}

                  <span className="text-[9px] opacity-60 block text-left mt-1">
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })
        )}

        {/* Loading spinner during response */}
        {isLoading && (
          <div className="flex justify-end items-center space-x-2 space-x-reverse">
            <div className="bg-slate-800 border border-slate-700 p-3 rounded-2xl text-xs text-pink-300 flex items-center gap-2 shadow-md">
              <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
              <span>{character.nameAr || character.name} يكتب الآن...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar */}
      <div className="bg-slate-900 border-t border-slate-800 p-3">
        {/* Remaining Messages Alert if low */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2 px-1">
          <span>الرسائل المتبقية: <strong className="text-pink-400">{freeMessages}</strong></span>
          <span className="text-[10px] text-purple-300">النموذج: {modelSettings.chatModel}</span>
        </div>

        <div className="flex items-center space-x-2 space-x-reverse bg-slate-800 border border-slate-700/80 rounded-2xl px-3 py-1.5 focus-within:border-pink-500 transition-colors">
          {/* Voice input button */}
          <button
            onClick={handleSpeechInput}
            className={`p-2 rounded-xl transition-colors ${
              isRecording ? 'bg-red-500/20 text-red-400 animate-pulse' : 'text-slate-400 hover:text-pink-400'
            }`}
            title="تحدث بدلاً من الكتابة"
          >
            <Mic className="w-4 h-4" />
          </button>

          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="اكتب رسالتك هنا..."
            rows={1}
            className="flex-1 bg-transparent text-white text-xs placeholder-slate-400 focus:outline-none resize-none py-1.5 dir-rtl"
          />

          <button
            onClick={handleSend}
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 text-white transition-all shadow-md shadow-pink-500/20"
          >
            <Send className="w-4 h-4 rotate-180" />
          </button>
        </div>
      </div>
    </div>
  );
};
