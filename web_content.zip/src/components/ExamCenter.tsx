import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  AlertCircle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Check, 
  TrendingUp,
  FileText,
  Zap,
  Bookmark,
  RotateCcw,
  Target,
  Clock,
  ChevronRight,
  Filter,
  CheckSquare,
  Award as Trophy,
  Languages,
  Search,
  Flag,
  ListOrdered,
  ArrowLeft,
  Brain,
  BarChart3,
  Flame,
  ShieldCheck,
  Eye,
  Trash2,
  Calendar,
  History
} from 'lucide-react';
import { ExamType, UserProfile, MCQQuestion } from '../types';
import { 
  ExamSession, 
  ExamHistoryItem, 
  getExamTranslation, 
  saveExamResult, 
  getExamHistory, 
  getFullExamSession,
  deleteExamHistoryItem,
  clearAllExamHistory,
  getSavedWeakTopics 
} from '../lib/examEngine';
import { saveMistake } from '../lib/dailyQuestionEngine';
import { SUPPORTED_INDIAN_LANGUAGES } from '../lib/languageUtils';
import { COMPETITIVE_EXAM_SUBJECTS as COMPETITIVE_SUBJECTS } from '../data/competitiveSubjects';

interface ExamCenterProps {
  language: string;
  examPrep: ExamType;
  setExamPrep: (exam: ExamType) => void;
  onIncrementQuiz: (score: number) => void;
  userProfile?: UserProfile;
}

// Major Indian Competitive Exam Categories
const EXAM_CATEGORIES = [
  { id: 'RRB NTPC', label: 'Railway RRB NTPC' },
  { id: 'Railway Group D', label: 'Railway Group D' },
  { id: 'SSC CGL', label: 'SSC CGL' },
  { id: 'SSC CHSL', label: 'SSC CHSL' },
  { id: 'Banking IBPS', label: 'Banking (IBPS PO / Clerk)' },
  { id: 'WBCS', label: 'WBCS & WBPSC Services' },
  { id: 'State Police', label: 'Police Constable & SI' },
  { id: 'Group C / D', label: 'Group C & Group D Exams' }
];

// Supported Exam Languages
const EXAM_LANGUAGES = SUPPORTED_INDIAN_LANGUAGES;

export default function ExamCenter({ 
  language, 
  examPrep, 
  setExamPrep, 
  onIncrementQuiz,
  userProfile
}: ExamCenterProps) {

  // Exam Workflow State
  const [step, setStep] = useState<'select' | 'instructions' | 'active_exam' | 'result' | 'solutions'>('select');
  
  // Selection States
  const [selectedSubject, setSelectedSubject] = useState<string>('History');
  const [selectedExamCategory, setSelectedExamCategory] = useState<string>(userProfile?.targetExam || examPrep || 'RRB NTPC');
  const [examLanguage, setExamLanguage] = useState<string>(language || 'bn');
  const [subjectSearch, setSubjectSearch] = useState<string>('');

  // Active Exam Session States
  const [loading, setLoading] = useState<boolean>(false);
  const [questions, setQuestions] = useState<MCQQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [markedForReview, setMarkedForReview] = useState<number[]>([]);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(90 * 60); // 90 minutes
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [showQuestionPalette, setShowQuestionPalette] = useState<boolean>(false);

  // Result & Analytics States
  const [examResult, setExamResult] = useState<ExamSession | null>(null);
  const [solutionFilter, setSolutionFilter] = useState<'all' | 'correct' | 'wrong' | 'unattempted'>('all');
  const [pastHistory, setPastHistory] = useState<ExamHistoryItem[]>([]);
  const [historySearch, setHistorySearch] = useState<string>('');

  // Helper translation getter
  const t = (key: string) => getExamTranslation(examLanguage, key);

  // Load Past Exam History
  useEffect(() => {
    setPastHistory(getExamHistory());
  }, [step]);

  // Open past exam session to review results and solutions
  const handleOpenPastExam = (sessionId: string) => {
    const fullSession = getFullExamSession(sessionId);
    if (fullSession) {
      setExamResult(fullSession);
      if (fullSession.language) setExamLanguage(fullSession.language);
      if (fullSession.subject) setSelectedSubject(fullSession.subject);
      if (fullSession.targetExam) setSelectedExamCategory(fullSession.targetExam);
      setStep('result');
    }
  };

  // Delete past exam entry
  const handleDeletePastExam = (e: React.MouseEvent, sessionId: string) => {
    e.stopPropagation();
    const confirmMsg = examLanguage === 'bn' 
      ? 'আপনি কি নিশ্চিত যে এই পরীক্ষার রেকর্ডটি মুছে ফেলতে চান?' 
      : examLanguage === 'hi'
      ? 'क्या आप इस परीक्षा रिकॉर्ड को हटाना चाहते हैं?'
      : 'Are you sure you want to delete this exam record?';
    if (window.confirm(confirmMsg)) {
      const updated = deleteExamHistoryItem(sessionId);
      setPastHistory(updated);
    }
  };

  // Clear all exam history
  const handleClearAllHistory = () => {
    const confirmMsg = examLanguage === 'bn'
      ? 'আপনি কি সমস্ত পূর্ববর্তী পরীক্ষার হিস্ট্রি মুছে ফেলতে চান?'
      : examLanguage === 'hi'
      ? 'क्या आप सभी पिछली परीक्षाओं का इतिहास हटाना चाहते हैं?'
      : 'Are you sure you want to clear all exam history?';
    if (window.confirm(confirmMsg)) {
      clearAllExamHistory();
      setPastHistory([]);
    }
  };

  // Timer Effect during Active Examination
  useEffect(() => {
    if (step !== 'active_exam' || secondsRemaining <= 0) return;

    const timer = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [step, secondsRemaining]);

  // Step 1: Start 100 Question Exam Generation
  const handleStartExamGeneration = async () => {
    setLoading(true);
    setStep('instructions');
    try {
      const res = await fetch('/api/gemini/exam-100', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userProfile?.id || userProfile?.phone || userProfile?.email || 'default_user',
          subject: selectedSubject,
          targetExam: selectedExamCategory,
          language: examLanguage,
          count: 100,
          weakTopics: getSavedWeakTopics()
        })
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
        setQuestions(data.questions);
      } else {
        throw new Error('Empty questions array returned');
      }
    } catch (err) {
      console.warn('Exam Generation fallback engaged:', err);
      const isBn = examLanguage === 'bn';
      
      const subjectTopics: Record<string, string[]> = {
        History: isBn ? ['সিন্ধু সভ্যতা', 'মৌর্য সাম্রাজ্য', 'মুঘল সাম্রাজ্য', 'ভারতের স্বাধীনতা সংগ্রাম', 'জাতীয় কংগ্রেস'] : ['Indus Valley', 'Maurya Empire', 'Mughal Empire', 'Freedom Movement', 'National Congress'],
        Geography: isBn ? ['ভারতের নদ-নদী', 'জলবায়ু ও মৃত্তিকা', 'খনিজ সম্পদ', 'পশ্চিমবঙ্গের ভূগোল', 'সৌরজগৎ'] : ['Rivers of India', 'Climate & Soil', 'Mineral Resources', 'West Bengal Geography', 'Solar System'],
        Polity: isBn ? ['মৌলিক অধিকার', 'রাষ্ট্রপতি ও সংসদ', 'সুপ্রিম কোর্ট', 'পঞ্চায়েতি রাজ', 'সংবিধান সংশোধন'] : ['Fundamental Rights', 'President & Parliament', 'Supreme Court', 'Panchayati Raj', 'Amendments'],
        Science: isBn ? ['গতি ও শক্তি', 'পর্যায় সারণি', 'মানব শরীরবিদ্যা', 'ভিটামিন ও রোগ', 'বাস্তুতন্ত্র'] : ['Motion & Energy', 'Periodic Table', 'Human Physiology', 'Vitamins & Diseases', 'Ecology'],
        Mathematics: isBn ? ['শতকরা ও লাভ-ক্ষতি', 'অনুপাত ও সমানুপাত', 'সময় ও দূরত্ব', 'পরিমিতি ও ক্ষেত্রফল', 'সরল সুদ ও চক্রবৃদ্ধি সুদ'] : ['Percentage & Profit', 'Ratio & Proportion', 'Time & Distance', 'Mensuration', 'Simple & Compound Interest'],
        Reasoning: isBn ? ['কোডিং ও ডিকোডিং', 'রক্তের সম্পর্ক', 'দিকনির্ণয়', 'সিরিজ ও লুপ্ত পদ', 'সিটিং বিন্যাস'] : ['Coding-Decoding', 'Blood Relations', 'Direction Test', 'Series Completion', 'Seating Layout']
      };

      const topics = subjectTopics[selectedSubject] || (isBn ? ['মূল ধারণা', 'ব্যবহারিক প্রশ্নাবলি', 'সিলেবাস ভিত্তিক প্রশ্নোত্তর'] : ['Core Concepts', 'Applied Questions', 'Syllabus Focus']);

      // Construct structured 100 question fallback set matching syllabus
      const fallbackList: MCQQuestion[] = Array.from({ length: 100 }).map((_, i) => {
        const topic = topics[i % topics.length];
        const diff = (i % 3 === 0 ? 'Easy' : i % 3 === 1 ? 'Medium' : 'Hard') as 'Easy' | 'Medium' | 'Hard';
        
        return {
          id: `exam-fallback-${i + 1}`,
          subject: selectedSubject,
          question: isBn 
            ? `[${selectedSubject} প্রশ্ন ${i + 1}] ${topic} সম্পর্কিত ${selectedExamCategory} পরীক্ষার জন্য গুরুত্বপূর্ণ প্রশ্ন:`
            : `[${selectedSubject} Q${i + 1}] Practice MCQ on ${topic} tailored for ${selectedExamCategory}:`,
          options: [
            isBn ? `A. ${topic} - বিকল্প ১` : `A. ${topic} Concept Option 1`,
            isBn ? `B. ${topic} - বিকল্প ২` : `B. ${topic} Concept Option 2`,
            isBn ? `C. ${topic} - বিকল্প ৩` : `C. ${topic} Concept Option 3`,
            isBn ? `D. ${topic} - বিকল্প ৪` : `D. ${topic} Concept Option 4`
          ],
          correctOptionIndex: (i % 4),
          explanation: isBn
            ? `${selectedSubject}-এর "${topic}" বিষয়ের বিস্তারিত ব্যাখ্যা এবং ${selectedExamCategory} পরীক্ষার গুরুত্বপূর্ণ সূত্র।`
            : `Comprehensive explanation for ${selectedSubject} (${topic}) aligned with ${selectedExamCategory} examination pattern.`,
          topic: topic,
          difficulty: diff
        };
      });
      setQuestions(fallbackList);
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Begin Countdown Timer
  const handleBeginExam = () => {
    setCurrentIndex(0);
    setUserAnswers({});
    setMarkedForReview([]);
    setSecondsRemaining(90 * 60);
    setStep('active_exam');
  };

  // Answer selection handler
  const handleSelectOption = (optIdx: number) => {
    setUserAnswers(prev => ({ ...prev, [currentIndex]: optIdx }));
  };

  // Toggle mark for review
  const handleToggleMarkReview = (idx: number) => {
    setMarkedForReview(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  // Final Auto/Manual Submit Calculation
  const handleAutoSubmit = () => handleFinalSubmission();

  const handleFinalSubmission = () => {
    setShowSubmitModal(false);

    let correctCount = 0;
    let wrongCount = 0;
    let unattemptedCount = 0;
    const identifiedWeakTopics: string[] = [];

    questions.forEach((q, idx) => {
      const uAns = userAnswers[idx];
      if (uAns === undefined) {
        unattemptedCount++;
      } else if (uAns === q.correctOptionIndex) {
        correctCount++;
      } else {
        wrongCount++;
        saveMistake(q, uAns);
        if (q.topic) identifiedWeakTopics.push(q.topic);
      }
    });

    const totalQ = questions.length || 100;
    const attemptedCount = totalQ - unattemptedCount;
    const scoreVal = correctCount;
    const percentageVal = Math.round((correctCount / totalQ) * 100);
    const accuracyVal = attemptedCount > 0 ? Math.round((correctCount / attemptedCount) * 100) : 0;
    const timeTakenSec = (90 * 60) - secondsRemaining;

    let perfLevel: 'Excellent' | 'Very Good' | 'Good' | 'Needs Improvement' = 'Needs Improvement';
    if (percentageVal >= 80) perfLevel = 'Excellent';
    else if (percentageVal >= 65) perfLevel = 'Very Good';
    else if (percentageVal >= 50) perfLevel = 'Good';

    const uniqueWeak = Array.from(new Set(identifiedWeakTopics)).slice(0, 5);

    const sessionData: ExamSession = {
      id: `exam-session-${Date.now()}`,
      subject: selectedSubject,
      targetExam: selectedExamCategory,
      language: examLanguage,
      date: new Date().toISOString().split('T')[0],
      totalQuestions: totalQ,
      timeLimitMinutes: 90,
      timeTakenSeconds: timeTakenSec,
      questions,
      userAnswers,
      markedForReview,
      score: scoreVal,
      accuracy: accuracyVal,
      percentage: percentageVal,
      performanceLevel: perfLevel,
      weakTopics: uniqueWeak,
      submittedAt: new Date().toLocaleTimeString()
    };

    setExamResult(sessionData);
    saveExamResult(sessionData);
    onIncrementQuiz(scoreVal);
    setStep('result');
  };

  // Format time (MM:SS or HH:MM:SS)
  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Filtered Subjects list
  const filteredSubjects = COMPETITIVE_SUBJECTS.filter(s => {
    const q = subjectSearch.toLowerCase();
    return s.id.toLowerCase().includes(q) || s.nameBn.includes(q) || s.nameHi.includes(q) || s.nameEn.toLowerCase().includes(q);
  });

  const currentQ = questions[currentIndex];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-900 text-slate-100 p-4 md:p-8 space-y-6">

      {/* STEP 1: SUBJECT & LANGUAGE SELECTION DASHBOARD */}
      {step === 'select' && (
        <div className="space-y-6">
          
          {/* HEADER BANNER */}
          <div className="bg-gradient-to-r from-slate-800 via-indigo-950 to-slate-800 border border-slate-700/80 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-extrabold text-xs rounded-xl flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5" />
                    {selectedExamCategory}
                  </span>
                  <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-xs rounded-xl">
                    100 MCQs Timed Test
                  </span>
                </div>
                <h1 className="text-2xl md:text-4xl font-black text-white font-display">
                  {t('examCenterTitle')}
                </h1>
                <p className="text-xs md:text-sm text-slate-300 max-w-2xl font-medium">
                  {t('examCenterDesc')}
                </p>
              </div>

              {/* TARGET EXAM & LANGUAGE SELECTORS */}
              <div className="bg-slate-900/90 border border-slate-700/80 p-4 rounded-2xl space-y-3 shrink-0 min-w-[280px]">
                <div>
                  <label className="block text-xs font-extrabold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-indigo-400" />
                    {t('selectExamHeader')}
                  </label>
                  <select
                    value={selectedExamCategory}
                    onChange={(e) => {
                      setSelectedExamCategory(e.target.value);
                      setExamPrep(e.target.value as ExamType);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 text-white font-bold rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    {EXAM_CATEGORIES.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Languages className="w-3.5 h-3.5 text-emerald-400" />
                    {t('selectLanguageHeader')}
                  </label>
                  <select
                    value={examLanguage}
                    onChange={(e) => setExamLanguage(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 text-emerald-300 font-bold rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    {EXAM_LANGUAGES.map(lang => (
                      <option key={lang.code} value={lang.code}>{lang.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* SUBJECT SELECTION GRID */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg md:text-xl font-black text-white font-display flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-400" />
                  {t('selectSubjectHeader')}
                </h2>
                <p className="text-xs text-slate-400">
                  {examLanguage === 'bn' 
                    ? 'যেকোনো ১টি বিষয় নির্বাচন করুন। সম্পূর্ণ ১০০টি প্রশ্ন কেবল সেই নির্দিষ্ট বিষয় থেকেই থাকবে।'
                    : 'Select exactly 1 subject for a dedicated 100-question examination.'}
                </p>
              </div>

              {/* Subject Search input */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={examLanguage === 'bn' ? 'বিষয় খুঁজুন...' : 'Search subjects...'}
                  value={subjectSearch}
                  onChange={(e) => setSubjectSearch(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* SUBJECT CARDS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredSubjects.map(sub => {
                const isSelected = selectedSubject === sub.id;
                const displayName = examLanguage === 'bn' ? sub.nameBn : examLanguage === 'hi' ? sub.nameHi : sub.nameEn;

                return (
                  <div
                    key={sub.id}
                    onClick={() => setSelectedSubject(sub.id)}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer relative group flex flex-col justify-between ${
                      isSelected
                        ? 'bg-gradient-to-br from-indigo-900/90 to-slate-800 border-indigo-500 shadow-xl shadow-indigo-600/20 ring-2 ring-indigo-500/50 scale-[1.02]'
                        : 'bg-slate-800/80 border-slate-700/80 hover:bg-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl p-2.5 bg-slate-900/80 rounded-xl border border-slate-700 shadow-inner">
                          {sub.icon}
                        </span>
                        <div>
                          <h3 className="font-black text-sm text-white font-display">
                            {displayName}
                          </h3>
                          <span className="text-[10px] font-bold text-slate-400 block mt-0.5">
                            {sub.nameEn}
                          </span>
                        </div>
                      </div>

                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-indigo-600 border-indigo-400 text-white' : 'border-slate-600 bg-slate-900/50'
                      }`}>
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-700/60 text-xs">
                      <span className="font-extrabold text-indigo-300">
                        100 MCQs
                      </span>
                      <span className="text-[11px] font-bold text-slate-400">
                        90 Mins
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* ACTION FOOTER */}
            <div className="bg-slate-800/90 border border-slate-700 p-5 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-300 flex items-center justify-center font-black text-lg">
                  100
                </span>
                <div>
                  <div className="text-xs text-slate-400 font-bold">
                    {examLanguage === 'bn' ? 'নির্বাচিত বিষয় ও ভাষা:' : 'Selected Subject & Language:'}
                  </div>
                  <div className="text-sm font-black text-white flex items-center gap-2">
                    <span>{selectedSubject}</span>
                    <span className="text-indigo-400">•</span>
                    <span className="text-emerald-300">
                      {EXAM_LANGUAGES.find(l => l.code === examLanguage)?.label}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleStartExamGeneration}
                className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-sm rounded-2xl cursor-pointer shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all hover:scale-105"
              >
                <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
                {t('start100ExamBtn')}
              </button>
            </div>
          </div>

          {/* PAST EXAMINATION HISTORY CONTAINER */}
          {pastHistory.length > 0 && (
            <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 space-y-3 shadow-xl backdrop-blur-md">
              {/* HISTORY HEADER WITH STATS & CONTROLS */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-700/60 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 bg-indigo-600/20 border border-indigo-500/30 rounded-lg text-indigo-400">
                    <History className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-black text-white font-display">
                        {t('pastExamsTitle')}
                      </h3>
                      <span className="px-2 py-0.5 bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[11px] font-black rounded-md">
                        {pastHistory.length} {examLanguage === 'bn' ? 'টি' : ''}
                      </span>
                    </div>
                  </div>
                </div>

                {/* SUMMARY STATS PILLS & CLEAR */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <div className="px-2.5 py-1 bg-slate-900/90 border border-slate-700/80 rounded-lg text-[11px] flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase">{t('avgScoreLabel')}:</span>
                    <span className="font-black text-indigo-300">
                      {Math.round(pastHistory.reduce((acc, h) => acc + h.percentage, 0) / pastHistory.length)}%
                    </span>
                  </div>

                  <div className="px-2.5 py-1 bg-slate-900/90 border border-slate-700/80 rounded-lg text-[11px] flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase">
                      {examLanguage === 'bn' ? 'সর্বোচ্চ' : 'Best'}:
                    </span>
                    <span className="font-black text-emerald-300">
                      {Math.max(...pastHistory.map(h => h.score), 0)}/100
                    </span>
                  </div>

                  {pastHistory.length > 1 && (
                    <button
                      onClick={handleClearAllHistory}
                      className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-[10px] font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1"
                      title={t('clearAllHistory')}
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>{examLanguage === 'bn' ? 'ক্লিয়ার' : 'Clear'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* SEARCH FILTER (If > 3 items) */}
              {pastHistory.length > 3 && (
                <div className="relative">
                  <Search className="w-3 h-3 text-slate-400 absolute left-2.5 top-2" />
                  <input
                    type="text"
                    placeholder={examLanguage === 'bn' ? 'পরীক্ষা খুঁজুন...' : 'Search past exams...'}
                    value={historySearch}
                    onChange={(e) => setHistorySearch(e.target.value)}
                    className="w-full bg-slate-900/80 border border-slate-700/80 rounded-lg pl-7 pr-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              )}

              {/* SCROLLABLE HISTORY LIST (Compact, well proportioned items) */}
              <div className="max-h-[300px] overflow-y-auto pr-1 space-y-2">
                {pastHistory
                  .filter(item => {
                    if (!historySearch.trim()) return true;
                    const q = historySearch.toLowerCase();
                    return item.subject.toLowerCase().includes(q) || 
                           item.targetExam.toLowerCase().includes(q) || 
                           item.date.includes(q);
                  })
                  .map((item) => {
                    const matchedSub = COMPETITIVE_SUBJECTS.find(s => s.id === item.subject);
                    const subDisplayName = matchedSub 
                      ? (examLanguage === 'bn' ? matchedSub.nameBn : examLanguage === 'hi' ? matchedSub.nameHi : matchedSub.nameEn)
                      : item.subject;
                    const subIcon = matchedSub?.icon || '📝';

                    return (
                      <div 
                        key={item.id} 
                        className="p-2.5 sm:p-3 bg-slate-900/80 hover:bg-slate-900 border border-slate-700/70 hover:border-indigo-500/50 rounded-xl transition-all shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 group"
                      >
                        {/* LEFT: ICON + SUBJECT + METADATA */}
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="w-8 h-8 flex items-center justify-center text-base bg-slate-800 rounded-lg border border-slate-700/80 shrink-0 shadow-inner">
                            {subIcon}
                          </span>
                          <div className="min-w-0 space-y-0.5">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="text-xs font-black text-white group-hover:text-indigo-300 transition-colors truncate">
                                {subDisplayName}
                              </h4>
                              <span className="px-1.5 py-0.2 bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 font-bold text-[9px] rounded">
                                {item.targetExam}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 text-[10px] text-slate-400">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-2.5 h-2.5 text-slate-500" />
                                {item.date}
                              </span>
                              {item.submittedAt && (
                                <span className="flex items-center gap-0.5 text-slate-500">
                                  <Clock className="w-2.5 h-2.5" />
                                  {item.submittedAt}
                                </span>
                              )}
                              <span className="text-slate-500">• 100 MCQs</span>
                            </div>
                          </div>
                        </div>

                        {/* RIGHT: SCORE + VIEW BUTTON + DELETE */}
                        <div className="flex items-center justify-between sm:justify-end gap-2.5 shrink-0 pt-1.5 sm:pt-0 border-t sm:border-t-0 border-slate-800/60">
                          <div className="flex items-center gap-2">
                            <div className="text-left sm:text-right">
                              <div className="flex items-baseline gap-1 sm:justify-end">
                                <span className="text-sm font-black text-white font-mono leading-none">
                                  {item.score}
                                </span>
                                <span className="text-[10px] text-slate-400 font-bold leading-none">
                                  /100
                                </span>
                              </div>
                            </div>
                            <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                              item.percentage >= 80 ? 'bg-emerald-500/20 border border-emerald-500/30 text-emerald-300' :
                              item.percentage >= 65 ? 'bg-indigo-500/20 border border-indigo-500/30 text-indigo-300' :
                              item.percentage >= 50 ? 'bg-amber-500/20 border border-amber-500/30 text-amber-300' : 
                              'bg-rose-500/20 border border-rose-500/30 text-rose-300'
                            }`}>
                              {item.percentage}%
                            </span>
                          </div>

                          {/* VIEW EXAM BUTTON */}
                          <button
                            onClick={() => handleOpenPastExam(item.id)}
                            className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-extrabold text-[11px] rounded-lg cursor-pointer shadow-sm flex items-center gap-1 transition-all shrink-0"
                          >
                            <Eye className="w-3 h-3" />
                            <span>{examLanguage === 'bn' ? 'উত্তর ও রেজাল্ট' : examLanguage === 'hi' ? 'उत्तर देखें' : 'View Exam'}</span>
                          </button>

                          {/* DELETE BUTTON */}
                          <button
                            onClick={(e) => handleDeletePastExam(e, item.id)}
                            className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/20 rounded-md transition-all cursor-pointer"
                            title={examLanguage === 'bn' ? 'মুছুন' : 'Delete'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

        </div>
      )}

      {/* STEP 2: PRE-EXAM INSTRUCTIONS SCREEN */}
      {step === 'instructions' && (
        <div className="max-w-3xl mx-auto space-y-6 py-4">
          <button
            onClick={() => setStep('select')}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            {examLanguage === 'bn' ? 'বিষয় নির্বাচনে ফিরে যান' : 'Back to Subject Selection'}
          </button>

          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-700">
              <span className="p-3 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 rounded-2xl text-2xl">
                📝
              </span>
              <div>
                <h2 className="text-xl md:text-2xl font-black text-white font-display">
                  {selectedSubject} — {t('instructionTitle')}
                </h2>
                <div className="flex items-center gap-3 mt-1 text-xs font-bold text-indigo-300">
                  <span>{selectedExamCategory}</span>
                  <span>•</span>
                  <span>{EXAM_LANGUAGES.find(l => l.code === examLanguage)?.label}</span>
                </div>
              </div>
            </div>

            {loading ? (
              <div className="p-12 text-center space-y-4">
                <RefreshCw className="w-10 h-10 text-indigo-400 animate-spin mx-auto" />
                <div className="space-y-1">
                  <p className="text-base font-extrabold text-white">
                    {t('loadingExam')}
                  </p>
                  <p className="text-xs text-slate-400">
                    {examLanguage === 'bn' 
                      ? 'এআই নির্দিষ্ট বিষয়, সিলেবাস ও ভাষা অনুযায়ী ১০০টি স্বতন্ত্র MCQ তৈরি করছে...'
                      : 'Constructing 100 subject-specific questions with AI backend...'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="p-4 bg-indigo-950/40 border border-indigo-800/50 rounded-2xl flex items-center justify-between text-xs font-bold text-indigo-200">
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-300" />
                    {t('timeLimitLabel')}
                  </span>
                  <span className="px-3 py-1 bg-indigo-600/30 text-indigo-300 rounded-lg">
                    100 MCQs
                  </span>
                </div>

                <div className="space-y-3 text-xs text-slate-300 font-medium">
                  <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-700/80 flex items-start gap-3">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{t('rule1')}</span>
                  </div>
                  <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-700/80 flex items-start gap-3">
                    <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{t('rule2')}</span>
                  </div>
                  <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-700/80 flex items-start gap-3">
                    <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{t('rule3')}</span>
                  </div>
                </div>

                <button
                  onClick={handleBeginExam}
                  className="w-full py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-base rounded-2xl cursor-pointer shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
                >
                  <Trophy className="w-5 h-5 text-amber-300" />
                  {t('startExamNow')}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 3: ACTIVE EXAMINATION INTERFACE */}
      {step === 'active_exam' && currentQ && (
        <div className="space-y-4">
          
          {/* ACTIVE EXAM TOP TIMER & STATUS BAR */}
          <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-4 sticky top-0 z-30 backdrop-blur-md">
            
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-extrabold text-xs rounded-xl">
                {selectedSubject}
              </span>
              <span className="text-xs font-bold text-slate-300 hidden sm:inline">
                {selectedExamCategory}
              </span>
            </div>

            {/* COUNTDOWN TIMER */}
            <div className={`px-4 py-2 rounded-xl border flex items-center gap-2 font-mono font-black text-sm md:text-base ${
              secondsRemaining < 600 
                ? 'bg-rose-600/20 border-rose-500 text-rose-300 animate-pulse' 
                : 'bg-slate-900 border-slate-700 text-amber-300'
            }`}>
              <Clock className="w-4 h-4 text-amber-400" />
              <span>{formatTime(secondsRemaining)}</span>
            </div>

            {/* QUESTION PALETTE TOGGLE BUTTON */}
            <button
              onClick={() => setShowQuestionPalette(!showQuestionPalette)}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ListOrdered className="w-4 h-4 text-indigo-400" />
              <span>1-100 {examLanguage === 'bn' ? 'গ্রিড' : 'Grid'}</span>
            </button>
          </div>

          {/* PALETTE STATS COUNTER */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-extrabold">
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 flex items-center justify-between">
              <span>{t('answeredLabel')}</span>
              <span className="font-mono text-sm">{Object.keys(userAnswers).length}</span>
            </div>
            <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 flex items-center justify-between">
              <span>{t('unansweredLabel')}</span>
              <span className="font-mono text-sm">{questions.length - Object.keys(userAnswers).length}</span>
            </div>
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 flex items-center justify-between">
              <span>{t('reviewLabel')}</span>
              <span className="font-mono text-sm">{markedForReview.length}</span>
            </div>
            <div className="p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-slate-300 flex items-center justify-between">
              <span>{t('totalQuestions')}</span>
              <span className="font-mono text-sm">{questions.length}</span>
            </div>
          </div>

          {/* 1 TO 100 QUESTION PALETTE GRID DRAWER */}
          {showQuestionPalette && (
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 shadow-2xl space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-300 pb-2 border-b border-slate-700">
                <span>{examLanguage === 'bn' ? '১ থেকে ১০০ প্রশ্ন নেভিগেশন গ্রিড (সরাসরি প্রশ্নে যান):' : 'Question Navigation Palette (Jump to Q 1-100):'}</span>
                <button 
                  onClick={() => setShowQuestionPalette(false)}
                  className="text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-5 sm:grid-cols-10 md:grid-cols-20 gap-1.5 max-h-60 overflow-y-auto p-1">
                {questions.map((_, idx) => {
                  const isAnswered = userAnswers[idx] !== undefined;
                  const isMarked = markedForReview.includes(idx);
                  const isCurrent = idx === currentIndex;

                  let btnBg = 'bg-slate-900 text-slate-400 border-slate-700';
                  if (isMarked) btnBg = 'bg-amber-500 text-slate-950 border-amber-400 font-black';
                  else if (isAnswered) btnBg = 'bg-emerald-600 text-white border-emerald-400 font-black';

                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        setCurrentIndex(idx);
                        setShowQuestionPalette(false);
                      }}
                      className={`h-8 rounded-lg border text-xs font-mono transition-all cursor-pointer flex items-center justify-center ${btnBg} ${
                        isCurrent ? 'ring-2 ring-white scale-110 z-10 shadow-lg' : ''
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* MAIN QUESTION CARD */}
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 shadow-2xl space-y-6">
            
            {/* QUESTION NUMBER & MARK REVIEW BAR */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-700">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-black rounded-lg">
                  {t('questionCountLabel')} {currentIndex + 1} / {questions.length}
                </span>
                {currentQ.topic && (
                  <span className="px-2.5 py-1 bg-slate-900 border border-slate-700 text-slate-300 text-xs font-bold rounded-lg hidden sm:inline">
                    {currentQ.topic}
                  </span>
                )}
              </div>

              <button
                onClick={() => handleToggleMarkReview(currentIndex)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  markedForReview.includes(currentIndex)
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                    : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <Flag className="w-3.5 h-3.5" />
                <span>
                  {markedForReview.includes(currentIndex) ? t('unmarkReviewBtn') : t('markReviewBtn')}
                </span>
              </button>
            </div>

            {/* QUESTION TEXT */}
            <h2 className="text-base md:text-lg font-black text-white leading-relaxed font-display">
              {currentQ.question}
            </h2>

            {/* OPTIONS LIST */}
            <div className="grid grid-cols-1 gap-3">
              {currentQ.options.map((opt, oIdx) => {
                const isSelected = userAnswers[currentIndex] === oIdx;

                return (
                  <button
                    key={oIdx}
                    onClick={() => handleSelectOption(oIdx)}
                    className={`p-4 rounded-2xl border text-left text-xs md:text-sm font-semibold transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-black ring-2 ring-indigo-500/40 shadow-lg'
                        : 'bg-slate-900/80 border-slate-700/80 text-slate-200 hover:bg-slate-700/80'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                        isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span>{opt}</span>
                    </div>

                    {isSelected && <CheckCircle2 className="w-5 h-5 text-indigo-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* BOTTOM NAVIGATION CONTROLS */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-700">
              <button
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                disabled={currentIndex === 0}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                {t('prevBtn')}
              </button>

              <button
                onClick={() => setShowSubmitModal(true)}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-xs cursor-pointer shadow-lg shadow-emerald-600/20"
              >
                {t('submitExamBtn')}
              </button>

              <button
                onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
                disabled={currentIndex === questions.length - 1}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer"
              >
                <span>{t('nextBtn')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>

          {/* SUBMIT CONFIRMATION MODAL */}
          {showSubmitModal && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 md:p-8 max-w-md w-full space-y-6 shadow-2xl animate-scaleIn">
                <div className="space-y-2 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center mx-auto text-xl">
                    ⚠️
                  </div>
                  <h3 className="text-lg font-black text-white font-display">
                    {t('submitConfirmTitle')}
                  </h3>
                </div>

                <div className="space-y-2 text-xs font-bold bg-slate-900 p-4 rounded-2xl border border-slate-700">
                  <div className="flex justify-between text-emerald-300">
                    <span>{t('answeredLabel')}:</span>
                    <span className="font-mono">{Object.keys(userAnswers).length} / {questions.length}</span>
                  </div>
                  <div className="flex justify-between text-rose-300">
                    <span>{t('unansweredLabel')}:</span>
                    <span className="font-mono">{questions.length - Object.keys(userAnswers).length}</span>
                  </div>
                  <div className="flex justify-between text-amber-300">
                    <span>{t('reviewLabel')}:</span>
                    <span className="font-mono">{markedForReview.length}</span>
                  </div>
                  <div className="flex justify-between text-slate-300 pt-2 border-t border-slate-800">
                    <span>{t('timeRemaining')}:</span>
                    <span className="font-mono">{formatTime(secondsRemaining)}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowSubmitModal(false)}
                    className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-xl text-xs cursor-pointer"
                  >
                    {t('continueExamNo')}
                  </button>
                  <button
                    onClick={handleFinalSubmission}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-xs cursor-pointer shadow-lg shadow-emerald-600/30"
                  >
                    {t('confirmSubmitYes')}
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      )}

      {/* STEP 4: RESULT & PERFORMANCE REPORT */}
      {step === 'result' && examResult && (
        <div className="max-w-4xl mx-auto space-y-6 py-2">
          
          {/* TOP NAVIGATION BACK BUTTON */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setStep('select')}
              className="flex items-center gap-2 text-xs font-extrabold text-slate-300 hover:text-white bg-slate-800/90 hover:bg-slate-800 border border-slate-700 px-4 py-2 rounded-xl transition-all cursor-pointer shadow-md"
            >
              <ArrowLeft className="w-4 h-4 text-indigo-400" />
              <span>{examLanguage === 'bn' ? 'পরীক্ষা কেন্দ্র ও হিস্ট্রিতে ফিরে যান' : 'Back to History & Exam Center'}</span>
            </button>

            <span className="text-xs text-slate-400 font-medium">
              {examResult.date} {examResult.submittedAt ? `• ${examResult.submittedAt}` : ''}
            </span>
          </div>

          {/* RESULT HEADER SCORECARD */}
          <div className="bg-gradient-to-br from-slate-800 via-indigo-950 to-slate-800 border border-slate-700/80 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-700/80 pb-4">
              <div>
                <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-extrabold text-xs rounded-xl">
                  {examResult.subject} • {examResult.targetExam}
                </span>
                <h1 className="text-2xl md:text-3xl font-black text-white mt-1 font-display">
                  {t('resultTitle')}
                </h1>
              </div>

              <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-black text-sm rounded-2xl flex items-center gap-2 self-start sm:self-auto">
                <Award className="w-5 h-5 text-amber-300" />
                <span>{examResult.performanceLevel}</span>
              </div>
            </div>

            {/* METRICS STATS GRID */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-1">
                <span className="text-[11px] font-extrabold text-slate-400 block">{t('scoreLabel')}</span>
                <div className="text-2xl font-black text-white font-mono">
                  {examResult.score} <span className="text-xs text-slate-400">/ 100</span>
                </div>
              </div>

              <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-1">
                <span className="text-[11px] font-extrabold text-slate-400 block">{t('percentageLabel')}</span>
                <div className="text-2xl font-black text-indigo-300 font-mono">
                  {examResult.percentage}%
                </div>
              </div>

              <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-1">
                <span className="text-[11px] font-extrabold text-slate-400 block">{t('accuracyLabel')}</span>
                <div className="text-2xl font-black text-emerald-300 font-mono">
                  {examResult.accuracy}%
                </div>
              </div>

              <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-1">
                <span className="text-[11px] font-extrabold text-slate-400 block">{t('timeTakenLabel')}</span>
                <div className="text-2xl font-black text-amber-300 font-mono">
                  {formatTime(examResult.timeTakenSeconds)}
                </div>
              </div>
            </div>

            {/* AI WEAK TOPICS IDENTIFIED */}
            {examResult.weakTopics.length > 0 && (
              <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl space-y-2 text-xs">
                <span className="font-extrabold text-rose-300 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-400" />
                  {t('weakTopicsTitle')}
                </span>
                <div className="flex flex-wrap gap-2">
                  {examResult.weakTopics.map((topic, i) => (
                    <span key={i} className="px-2.5 py-1 bg-rose-950/60 border border-rose-500/40 text-rose-200 font-bold rounded-lg">
                      • {topic}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* ACTION BUTTONS */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => setStep('solutions')}
                className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl cursor-pointer shadow-lg flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                {t('viewSolutionsBtn')}
              </button>

              <button
                onClick={() => {
                  setSolutionFilter('wrong');
                  setStep('solutions');
                }}
                className="px-5 py-3 bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs rounded-xl cursor-pointer shadow-lg flex items-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                {t('viewWrongBtn')}
              </button>

              <button
                onClick={handleStartExamGeneration}
                className="px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl cursor-pointer shadow-lg flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                {t('retakeExamBtn')}
              </button>

              <button
                onClick={() => setStep('select')}
                className="px-5 py-3 bg-slate-700 hover:bg-slate-600 text-white font-extrabold text-xs rounded-xl cursor-pointer flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                {t('practiceSubjectBtn')}
              </button>
            </div>
          </div>

        </div>
      )}

      {/* STEP 5: DETAILED SOLUTIONS VIEW */}
      {step === 'solutions' && examResult && (
        <div className="space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800 border border-slate-700 p-5 rounded-3xl">
            <div>
              <div className="flex items-center gap-3 mb-1.5">
                <button
                  onClick={() => setStep('result')}
                  className="text-xs font-extrabold text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {examLanguage === 'bn' ? 'ফলাফলে ফিরে যান' : 'Back to Results'}
                </button>
                <span className="text-slate-600">•</span>
                <button
                  onClick={() => setStep('select')}
                  className="text-xs font-extrabold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                >
                  <History className="w-3.5 h-3.5" />
                  {t('backToHistoryBtn')}
                </button>
              </div>
              <h2 className="text-lg md:text-xl font-black text-white font-display">
                {t('solutionsTitle')}
              </h2>
            </div>

            {/* FILTER CHIPS */}
            <div className="flex flex-wrap gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-700">
              <button
                onClick={() => setSolutionFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                  solutionFilter === 'all' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {t('filterAll')}
              </button>
              <button
                onClick={() => setSolutionFilter('wrong')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                  solutionFilter === 'wrong' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {t('filterWrong')}
              </button>
              <button
                onClick={() => setSolutionFilter('correct')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                  solutionFilter === 'correct' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {t('filterCorrect')}
              </button>
            </div>
          </div>

          {/* QUESTION SOLUTIONS LIST */}
          <div className="space-y-4">
            {examResult.questions.map((q, idx) => {
              const uAns = examResult.userAnswers[idx];
              const isCorrect = uAns === q.correctOptionIndex;
              const isUnattempted = uAns === undefined;

              if (solutionFilter === 'correct' && !isCorrect) return null;
              if (solutionFilter === 'wrong' && (isCorrect || isUnattempted)) return null;
              if (solutionFilter === 'unattempted' && !isUnattempted) return null;

              return (
                <div 
                  key={idx}
                  className={`bg-slate-800 border rounded-3xl p-6 space-y-4 shadow-xl ${
                    isCorrect ? 'border-emerald-500/40' : isUnattempted ? 'border-slate-700' : 'border-rose-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                    <span className="px-3 py-1 bg-slate-900 border border-slate-700 text-xs font-black text-slate-300 rounded-lg">
                      Q{idx + 1}
                    </span>

                    <span className={`px-3 py-1 text-xs font-black rounded-lg ${
                      isCorrect ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300' :
                      isUnattempted ? 'bg-slate-700 text-slate-300' : 'bg-rose-500/20 border border-rose-500/40 text-rose-300'
                    }`}>
                      {isCorrect ? '✓ Correct' : isUnattempted ? '— Unattempted' : '✗ Wrong'}
                    </span>
                  </div>

                  <h3 className="text-sm md:text-base font-extrabold text-white leading-relaxed">
                    {q.question}
                  </h3>

                  <div className="grid grid-cols-1 gap-2">
                    {q.options.map((opt, oIdx) => {
                      const isCorrectOpt = q.correctOptionIndex === oIdx;
                      const isUserOpt = uAns === oIdx;

                      let style = 'bg-slate-900 border-slate-700 text-slate-300';
                      if (isCorrectOpt) style = 'bg-emerald-600/20 border-emerald-500 text-emerald-200 font-bold';
                      else if (isUserOpt && !isCorrectOpt) style = 'bg-rose-600/20 border-rose-500 text-rose-200 font-bold';

                      return (
                        <div key={oIdx} className={`p-3 rounded-xl border text-xs flex items-center justify-between ${style}`}>
                          <span>{opt}</span>
                          {isCorrectOpt && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                          {isUserOpt && !isCorrectOpt && <XCircle className="w-4 h-4 text-rose-400" />}
                        </div>
                      );
                    })}
                  </div>

                  <div className="p-4 bg-indigo-950/40 border border-indigo-800/50 rounded-2xl space-y-2 text-xs text-indigo-100">
                    <span className="font-extrabold text-white block">
                      {t('explanationHeader')}
                    </span>
                    <p className="leading-relaxed text-slate-200">
                      {q.explanation}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

    </div>
  );
}
