import React, { useState, useMemo } from 'react';
import { Search as SearchIcon, X, BookOpen, ChevronLeft } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ALL_ADHKAR } from '../data/adhkarData';

// Helper to normalize Arabic text for resilient search (removes diacritics / tashkeel, standardizes alefs)
function normalizeArabic(text: string): string {
  return text
    // Remove Arabic tashkeel / harakat
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // Standardize Alef variations
    .replace(/[أإآ]/g, 'ا')
    // Standardize Taa Marbuta
    .replace(/ة/g, 'ه')
    // Standardize Yaa
    .replace(/ى/g, 'ي')
    .toLowerCase()
    .trim();
}

export const SearchScreen: React.FC = () => {
  const [query, setQuery] = useState('');
  const { openDhikr, getProgressFor } = useApp();

  const quickKeywords = ['الصباح', 'المساء', 'الاستغفار', 'الكرسي', 'العافية', 'سورة الإخلاص', 'التسبيح', 'النبي'];

  const filteredResults = useMemo(() => {
    const trimmed = query.trim();
    if (!trimmed) return [];

    const normQuery = normalizeArabic(trimmed);

    return ALL_ADHKAR.filter((dhikr) => {
      const normTitle = normalizeArabic(dhikr.title);
      const normText = normalizeArabic(dhikr.text);
      const normCategory = normalizeArabic(dhikr.categoryArabic);

      return (
        normTitle.includes(normQuery) ||
        normText.includes(normQuery) ||
        normCategory.includes(normQuery)
      );
    });
  }, [query]);

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="pt-2">
        <h2 className="text-2xl font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
          البحث في الأذكار
        </h2>
        <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
          ابحث في جميع النصوص والأدعية والأسماء بسرعة وبدون إنترنت
        </p>
      </div>

      {/* Search Input Box */}
      <div className="relative flex items-center">
        <div className="absolute right-4 text-emerald-700 dark:text-emerald-400 pointer-events-none">
          <SearchIcon className="w-5 h-5" />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث بالاسم أو بكلمة من نص الذكر..."
          className="w-full h-13 pr-12 pl-10 bg-[#ffffff] dark:bg-[#042017] border border-emerald-300/60 dark:border-emerald-800 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition-all shadow-xs text-[#0c2e20] dark:text-[#e8f5ee] placeholder:text-[#62927c] dark:placeholder:text-[#5e967e] font-tajawal"
          dir="rtl"
          autoFocus
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute left-3 p-1.5 rounded-full text-[#62927c] hover:text-[#0c2e20] dark:hover:text-[#e8f5ee] cursor-pointer"
            aria-label="مسح البحث"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Quick Keywords Chips */}
      {!query && (
        <div className="space-y-2 pt-1">
          <p className="text-xs font-bold text-[#1a4432] dark:text-[#a7d7c0] font-cairo">
            كلمات بحث مقترحة:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {quickKeywords.map((word) => (
              <button
                key={word}
                onClick={() => setQuery(word)}
                className="px-3 py-1.5 rounded-xl bg-[#eaf5ef] dark:bg-[#062c20] text-xs font-medium text-[#1a4432] dark:text-[#a7d7c0] hover:bg-[#d6ecde] dark:hover:bg-[#0a3829] hover:text-emerald-800 transition-colors cursor-pointer font-tajawal border border-emerald-300/40 dark:border-emerald-800/60"
              >
                {word}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results Section */}
      {query && (
        <div className="space-y-2.5 pt-1">
          <div className="flex items-center justify-between text-xs text-[#4d7d67] dark:text-[#84b8a0] px-1 font-tajawal">
            <span>نتائج البحث:</span>
            <span>{filteredResults.length} نتيجة</span>
          </div>

          {filteredResults.length === 0 ? (
            <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-3xl p-8 text-center space-y-2">
              <p className="text-sm font-bold text-[#1a4432] dark:text-[#a7d7c0] font-cairo">
                لم يتم العثور على أذكار تطابق &quot;{query}&quot;
              </p>
              <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
                تأكد من كتابة الكلمة بشكل صحيح، أو ابحث بكلمة رئيسية مثل &quot;الصباح&quot; أو &quot;الاستغفار&quot;.
              </p>
            </div>
          ) : (
            filteredResults.map((dhikr) => {
              const currentCount = getProgressFor(dhikr.id);
              const isDone = currentCount >= dhikr.count;

              const repetitionText = 
                dhikr.count === 1 ? 'مرة واحدة' :
                dhikr.count === 3 ? '٣ مرات' :
                dhikr.count === 4 ? '٤ مرات' :
                dhikr.count === 7 ? '٧ مرات' :
                dhikr.count === 10 ? '١٠ مرات' :
                dhikr.count === 100 ? '١٠٠ مرة' : `${dhikr.count} مرات`;

              return (
                <div
                  key={dhikr.id}
                  onClick={() => openDhikr(dhikr)}
                  className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/60 rounded-2xl p-4 shadow-xs hover:border-emerald-500 dark:hover:border-emerald-600 hover:shadow-md transition-all cursor-pointer flex items-start justify-between gap-3 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-amber-300 border border-emerald-600/40 flex items-center justify-center font-bold text-xs shrink-0 font-cairo shadow-2xs">
                    <BookOpen className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0 text-right">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] truncate font-cairo group-hover:text-emerald-800 dark:group-hover:text-emerald-300">
                        {dhikr.title}
                      </h3>
                      <span className="shrink-0 px-2.5 py-0.5 rounded-full bg-emerald-700/15 border border-emerald-600/40 text-[#123828] dark:text-emerald-300 text-[10px] font-bold font-cairo shadow-2xs">
                        {repetitionText}
                      </span>
                    </div>

                    <p className="text-xs text-[#2b5945] dark:text-[#84b8a0] font-tajawal line-clamp-2 leading-relaxed">
                      {dhikr.text}
                    </p>

                    <div className="flex items-center gap-3 mt-2 text-[11px] text-[#4d7d67] dark:text-[#7ba993]">
                      <span className="text-emerald-800 dark:text-emerald-300 font-medium">
                        · {dhikr.categoryArabic}
                      </span>
                      {currentCount > 0 && (
                        <span className={isDone ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-amber-600 dark:text-amber-400 font-medium'}>
                          · المنجز: {currentCount} / {dhikr.count}
                        </span>
                      )}
                    </div>
                  </div>

                  <ChevronLeft className="w-4 h-4 text-[#7ca994] dark:text-[#5e967e] group-hover:text-emerald-600 shrink-0 mt-2 transition-colors" />
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
