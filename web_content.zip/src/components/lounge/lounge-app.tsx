import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import {
  BookOpen,
  Clock,
  Coffee,
  Copy,
  Gamepad2,
  House,
  Lock,
  MessagesSquare,
  Mic,
  Moon,
  Music,
  Plus,
  Radio,
  Users,
  type LucideIcon,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/cn";
import { micErrorMessage, primeAudioOutput, requestMic } from "@/lib/voice/audio";
import {
  ROOM_CAP,
  ROOMS,
  cleanName,
  fetchPresence,
  findRoom,
  initials,
  isPrivateId,
  makePrivateId,
  normalizeCode,
  privateCode,
  type RoomDef,
  type RoomIcon,
  type RoomPresence,
} from "@/lib/voice/rooms";
import { RoomView } from "@/components/lounge/room-view";

const ICONS: Record<RoomIcon, LucideIcon> = {
  home: House,
  coffee: Coffee,
  book: BookOpen,
  game: Gamepad2,
  music: Music,
  talk: MessagesSquare,
  dz: Radio,
  moon: Moon,
};

const POINTS: { title: string; body: string }[] = [
  { title: "مباشر بينكم", body: "الصوت يسافر من جهاز إلى جهاز. لا نحفظ المكالمات." },
  { title: "حتى ٨ أشخاص", body: "غرفة صغيرة تبقى مفهومة. إذا امتلأت اختر غيرها." },
  { title: "حساب جيميل", body: "اسمك مربوط بحسابك، وتخرج من زر الحساب متى شئت." },
];

interface Session {
  room: RoomDef;
  stream: MediaStream | null;
  note: string | null;
}

function useAlgiersClock(): string {
  const [label, setLabel] = useState("");
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("ar-DZ", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Africa/Algiers",
    });
    const tick = () => setLabel(fmt.format(new Date()));
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, []);
  return label;
}

async function copyRoomLink(roomId: string) {
  const url = `${window.location.origin}/?r=${roomId}`;
  try {
    await navigator.clipboard.writeText(url);
    toast("تم نسخ رابط الغرفة");
  } catch {
    toast(url);
  }
}

export function LoungeApp({ entryRoom, accountName }: { entryRoom?: string; accountName: string }) {
  const [name, setName] = useState(accountName);
  const [nameHint, setNameHint] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState(() => findRoom(entryRoom).id);
  const [presence, setPresence] = useState<Record<string, RoomPresence> | null>(null);
  const [code, setCode] = useState("");
  const [codeHint, setCodeHint] = useState<string | null>(null);
  const [entering, setEntering] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const clock = useAlgiersClock();

  useEffect(() => {
    const saved = localStorage.getItem("ousimdz-name");
    setName(saved || accountName);
  }, [accountName]);

  useEffect(() => {
    if (session) return;
    let stop = false;
    const ids = ROOMS.map((room) => room.id);
    if (isPrivateId(selectedId)) ids.push(selectedId);
    const tick = async () => {
      const next = await fetchPresence(ids);
      if (!stop) setPresence(next);
    };
    void tick();
    const timer = setInterval(() => {
      if (document.visibilityState === "hidden") return;
      void tick();
    }, 4000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [session, selectedId]);

  const active = useMemo(() => findRoom(selectedId), [selectedId]);
  const activeCount = presence?.[active.id]?.count;
  const full = (activeCount ?? 0) >= ROOM_CAP;

  async function enter(room: RoomDef) {
    primeAudioOutput();
    const cleaned = cleanName(name);
    if (!cleaned) {
      setNameHint("اكتب اسمك أولاً حتى يعرفك من في الغرفة.");
      nameRef.current?.focus();
      return;
    }
    if ((presence?.[room.id]?.count ?? 0) >= ROOM_CAP) return;
    setEntering(true);
    setNameHint(null);
    localStorage.setItem("ousimdz-name", cleaned);
    setName(cleaned);
    let stream: MediaStream | null = null;
    let note: string | null = null;
    try {
      stream = await requestMic();
    } catch (error) {
      note = micErrorMessage(error);
    }
    setSession({ room, stream, note });
    setEntering(false);
  }

  if (session) {
    return (
      <>
        <Toaster
          position="top-center"
          dir="rtl"
          theme="dark"
          toastOptions={{
            style: {
              background: "var(--color-surface)",
              color: "var(--color-fg)",
              border: "1px solid var(--color-border)",
              fontFamily: "inherit",
            },
          }}
        />
        <RoomView
          room={session.room}
          name={cleanName(name)}
          initialStream={session.stream}
          initialNote={session.note}
          onLeave={() => setSession(null)}
        />
      </>
    );
  }

  const names = presence?.[active.id]?.names ?? [];

  return (
    <div className="mx-auto flex h-dvh w-full max-w-6xl flex-col px-4">
      <Toaster
        position="top-center"
        dir="rtl"
        theme="dark"
        toastOptions={{
          style: {
            background: "var(--color-surface)",
            color: "var(--color-fg)",
            border: "1px solid var(--color-border)",
            fontFamily: "inherit",
          },
        }}
      />
      <div className="h-1 shrink-0 bg-primary" />
      <header className="flex shrink-0 flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-primary font-display text-lg font-semibold text-primary-fg">
            DZ
          </span>
          <div>
            <p className="font-display text-2xl leading-none tracking-wide">OUSIMDZ</p>
            <p className="mt-1 text-sm text-muted">دردشة صوتية عربية مجانية</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <p className="hidden items-center gap-2 text-sm text-muted sm:flex">
            <Clock className="size-4" aria-hidden="true" />
            <span>الجزائر</span>
            <span className="tabular-nums text-fg" dir="ltr">
              {clock || "—"}
            </span>
          </p>
          <AccountChip />
          <label className="min-w-0 flex-1 sm:w-56 sm:flex-none">
            <span className="sr-only">اسمك في الغرفة</span>
            <input
              ref={nameRef}
              value={name}
              maxLength={24}
              placeholder="اسمك في الغرفة"
              autoComplete="nickname"
              onChange={(event) => {
                setName(event.target.value);
                if (nameHint) setNameHint(null);
              }}
              className="h-12 w-full rounded-2xl border border-border bg-surface px-4 text-base text-fg outline-none placeholder:text-muted"
            />
          </label>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-2 lg:pb-4">
        <section className="min-h-0 overflow-y-auto lg:pe-1" aria-label="الغرف">
          <div className="mb-3 flex items-center justify-between">
            <h1 className="font-display text-lg">الغرف</h1>
            <p className="text-xs text-muted">حدّ الغرفة {ROOM_CAP}</p>
          </div>
          <ul className="flex flex-col gap-2">
            {isPrivateId(active.id) ? (
              <li>
                <RoomButton
                  room={active}
                  selected
                  count={activeCount}
                  onSelect={() => setSelectedId(active.id)}
                />
              </li>
            ) : null}
            {ROOMS.map((room, index) => (
              <li key={room.id} className="rise" style={{ animationDelay: `${index * 40}ms` }}>
                <RoomButton
                  room={room}
                  selected={room.id === active.id}
                  count={presence?.[room.id]?.count}
                  onSelect={() => setSelectedId(room.id)}
                />
              </li>
            ))}
          </ul>

          <form
            className="mt-4 rounded-card border border-border bg-surface p-3"
            onSubmit={(event) => {
              event.preventDefault();
              const id = normalizeCode(code);
              if (!id) {
                setCodeHint("الرمز أربعة أحرف، مثل K7MQ.");
                return;
              }
              setCodeHint(null);
              setSelectedId(id);
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <p className="flex items-center gap-2 text-sm font-medium">
                <Lock className="size-4 text-primary" aria-hidden="true" />
                غرفة بالرمز
              </p>
              <button
                type="button"
                onClick={() => {
                  const id = makePrivateId();
                  setSelectedId(id);
                  setCode(privateCode(id));
                  setCodeHint(null);
                }}
                className="inline-flex h-11 items-center gap-1 rounded-xl px-3 text-sm text-primary transition-transform duration-150 active:scale-[0.96]"
              >
                <Plus className="size-4" aria-hidden="true" />
                جديدة
              </button>
            </div>
            <div className="mt-2 flex gap-2">
              <input
                value={code}
                onChange={(event) => setCode(event.target.value.toUpperCase())}
                placeholder="K7MQ"
                maxLength={8}
                dir="ltr"
                className="h-12 min-w-0 flex-1 rounded-xl border border-border bg-bg px-3 text-center font-display text-lg tracking-widest text-fg uppercase outline-none placeholder:text-muted"
                aria-label="رمز الغرفة الخاصة"
              />
              <button
                type="submit"
                className="h-12 shrink-0 rounded-xl bg-surface-2 px-4 text-sm font-medium transition-transform duration-150 active:scale-[0.96]"
              >
                افتح
              </button>
            </div>
            {codeHint ? <p className="mt-2 text-sm text-primary">{codeHint}</p> : null}
          </form>
        </section>

        <section className="hidden min-h-0 flex-col justify-between overflow-y-auto rounded-card border border-border bg-surface p-6 shadow-card lg:flex">
          <div>
            <p className="text-sm text-primary">{active.topic}</p>
            <h2 className="mt-2 font-display text-4xl leading-tight">{active.title}</h2>
            <p className="mt-3 max-w-md text-muted">{active.blurb}</p>
            {isPrivateId(active.id) ? (
              <p className="mt-4 font-display text-3xl tracking-widest text-primary" dir="ltr">
                {privateCode(active.id)}
              </p>
            ) : null}
            <p className="mt-5 text-sm text-muted">
              {presence === null
                ? "نتحقّق من الحضور…"
                : names.length
                  ? `في الداخل: ${names.join("، ")}`
                  : "لا أحد في الداخل بعد. كن أول الصوت."}
            </p>
            <p className="mt-1 text-sm tabular-nums text-fg" dir="ltr">
              {activeCount ?? "–"} / {ROOM_CAP}
            </p>
          </div>
          <div>
            <ul className="mb-5 grid gap-3">
              {POINTS.map((point) => (
                <li key={point.title} className="flex gap-3 text-sm">
                  <span className="mt-0.5 size-1.5 shrink-0 rounded-full bg-primary" />
                  <span>
                    <span className="font-medium">{point.title}. </span>
                    <span className="text-muted">{point.body}</span>
                  </span>
                </li>
              ))}
            </ul>
            {nameHint ? <p className="mb-3 text-sm text-primary">{nameHint}</p> : null}
            <div className="flex gap-2">
              <button
                type="button"
                disabled={entering || full}
                onClick={() => void enter(active)}
                className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary px-5 font-semibold text-primary-fg transition-transform duration-150 disabled:opacity-50 active:scale-[0.96]"
              >
                <Mic className="size-5" aria-hidden="true" />
                {entering ? "جارٍ فتح الميكروفون…" : full ? "الغرفة ممتلئة" : "ادخل وتحدّث"}
              </button>
              <button
                type="button"
                onClick={() => void copyRoomLink(active.id)}
                className="grid size-12 place-items-center rounded-2xl border border-border text-fg transition-transform duration-150 active:scale-[0.96]"
                aria-label="نسخ رابط الغرفة"
              >
                <Copy className="size-5" />
              </button>
            </div>
          </div>
        </section>
      </div>

      <footer className="shrink-0 border-t border-border py-3 lg:hidden">
        {nameHint ? <p className="mb-2 text-sm text-primary">{nameHint}</p> : null}
        <div className="flex gap-2">
          <button
            type="button"
            disabled={entering || full}
            onClick={() => void enter(active)}
            className="inline-flex h-12 min-w-0 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary px-4 font-semibold text-primary-fg transition-transform duration-150 disabled:opacity-50 active:scale-[0.96]"
          >
            <Users className="size-5 shrink-0" aria-hidden="true" />
            <span className="truncate">
              {entering ? "لحظة…" : full ? "ممتلئة" : `ادخل ${active.title}`}
            </span>
          </button>
          <button
            type="button"
            onClick={() => void copyRoomLink(active.id)}
            className="grid size-12 shrink-0 place-items-center rounded-2xl border border-border"
            aria-label="نسخ رابط الغرفة"
          >
            <Copy className="size-5" />
          </button>
        </div>
      </footer>
    </div>
  );
}

function AccountChip() {
  const user = useCurrentUser();
  const [signingOut, setSigningOut] = useState(false);
  const gateSession = useSyncExternalStore(subscribeNothing, hasGateSessionMarker, () => false);
  if (!user) return null;
  const label = user.displayName ?? user.primaryEmail ?? "حساب";
  return (
    <div className="flex shrink-0 items-center gap-2">
      {user.profileImageUrl ? (
        <img src={user.profileImageUrl} alt="" className="size-9 rounded-full object-cover" />
      ) : (
        <span className="grid size-9 place-items-center rounded-full bg-surface-2 text-sm font-medium">
          {initials(label)}
        </span>
      )}
      {authEnabled && !gateSession ? (
        <button
          type="button"
          disabled={signingOut}
          onClick={() => {
            setSigningOut(true);
            void signOut().catch(() => setSigningOut(false));
          }}
          className="text-sm text-muted disabled:opacity-60"
        >
          {signingOut ? "جارٍ الخروج…" : "خروج"}
        </button>
      ) : null}
    </div>
  );
}

const subscribeNothing = () => () => {};

function RoomButton({
  room,
  selected,
  count,
  onSelect,
}: {
  room: RoomDef;
  selected: boolean;
  count: number | undefined;
  onSelect: () => void;
}) {
  const Icon = isPrivateId(room.id) ? Lock : ICONS[room.icon];
  const full = (count ?? 0) >= ROOM_CAP;
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      className={cn(
        "flex w-full items-center gap-3 rounded-2xl border px-3 py-2.5 text-start transition-colors duration-200",
        "active:scale-[0.96]",
        selected ? "border-primary bg-surface-2" : "border-transparent bg-surface",
      )}
    >
      <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-bg text-primary">
        <Icon className="size-5" aria-hidden="true" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate font-medium">{room.title}</span>
          <span className={cn("shrink-0 text-xs tabular-nums", full ? "text-primary" : "text-muted")} dir="ltr">
            {count === undefined ? "–" : count}/{ROOM_CAP}
          </span>
        </span>
        <span className="mt-0.5 block truncate text-sm text-muted">
          {selected ? room.blurb : room.topic}
        </span>
      </span>
    </button>
  );
}
