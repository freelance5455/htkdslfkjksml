import { signIn } from "@/lib/auth/client";

export function BootScreen() {
  return (
    <main className="mx-auto flex h-dvh w-full max-w-md flex-col px-4">
      <div className="h-1 shrink-0 bg-primary" />
      <div className="flex flex-1 flex-col justify-center gap-4">
        <div className="size-14 animate-pulse rounded-2xl bg-surface-2" />
        <div className="h-8 w-40 animate-pulse rounded-xl bg-surface-2" />
        <div className="h-4 w-64 animate-pulse rounded-xl bg-surface" />
      </div>
    </main>
  );
}

export function GmailSignIn() {
  return (
    <main className="mx-auto flex h-dvh w-full max-w-md flex-col px-4">
      <div className="h-1 shrink-0 bg-primary" />
      <div className="flex flex-1 flex-col justify-center">
        <span className="grid size-14 place-items-center rounded-2xl bg-primary font-display text-xl font-semibold text-primary-fg">
          DZ
        </span>
        <h1 className="mt-6 font-display text-4xl tracking-wide">OUSIMDZ</h1>
        <p className="mt-3 max-w-sm text-muted">ادخل بحساب جيميل ليظهر اسمك داخل الغرف.</p>
        <button
          type="button"
          onClick={() => void signIn("grok-google", { callbackURL: "/" })}
          className="mt-8 inline-flex h-16 items-center justify-center gap-3 rounded-2xl bg-primary px-4 font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]"
        >
          <GmailIcon />
          المتابعة عبر جيميل
        </button>
      </div>
    </main>
  );
}

function GmailIcon() {
  return (
    <svg viewBox="0 0 48 48" className="size-14 shrink-0" aria-hidden="true">
      <path fill="#4caf50" d="M45 16.2 40 18.95 35 23.7V40h7a3 3 0 0 0 3-3V16.2z" />
      <path fill="#1e88e5" d="M3 16.2 6.6 17.9 13 23.7V40H6a3 3 0 0 1-3-3V16.2z" />
      <path fill="#e53935" d="m35 11.2-11 8.25-11-8.25-1 5.8 1 6.7 11 8.25 11-8.25 1-6.7z" />
      <path
        fill="#c62828"
        d="M3 12.3v3.9l10 7.5V11.2L9.9 8.86A4.3 4.3 0 0 0 7.3 8C4.9 8 3 9.9 3 12.3z"
      />
      <path
        fill="#fbc02d"
        d="M45 12.3v3.9l-10 7.5V11.2l3.1-2.34A4.3 4.3 0 0 1 40.7 8C43.1 8 45 9.9 45 12.3z"
      />
    </svg>
  );
}
