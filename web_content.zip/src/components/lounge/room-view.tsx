import { useEffect, useRef, useState, type ReactNode } from "react";
import * as Slider from "@radix-ui/react-slider";
import {
  Copy,
  Hand,
  HeadphoneOff,
  Headphones,
  MessageCircle,
  Mic,
  MicOff,
  PhoneOff,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/cn";
import { micErrorMessage, playChime, primeAudioOutput, requestMic, useAudioLevel } from "@/lib/voice/audio";
import { ROOM_CAP, initials, isPrivateId, privateCode, type RoomDef } from "@/lib/voice/rooms";
import { useVoiceSession, type ChatLine } from "@/lib/voice/use-voice-session";
import type { PeerInfo } from "@/lib/multiplayer";

const timeFmt = new Intl.DateTimeFormat("ar-DZ", { hour: "2-digit", minute: "2-digit" });

export function RoomView({
  room,
  name,
  initialStream,
  initialNote,
  onLeave,
}: {
  room: RoomDef;
  name: string;
  initialStream: MediaStream | null;
  initialNote: string | null;
  onLeave: () => void;
}) {
  const [stream, setStream] = useState<MediaStream | null>(initialStream);
  const [note, setNote] = useState<string | null>(initialNote);
  const [muted, setMuted] = useState(false);
  const [ptt, setPtt] = useState(false);
  const [held, setHeld] = useState(false);
  const [deaf, setDeaf] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [volumes, setVolumes] = useState<Record<string, number>>({});
  const [openVolume, setOpenVolume] = useState<string | null>(null);
  const [soundLocked, setSoundLocked] = useState(false);
  const [seen, setSeen] = useState(0);
  const streamRef = useRef<MediaStream | null>(initialStream);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const lastChat = useRef(0);
  streamRef.current = stream;

  const micHot = Boolean(stream) && !muted && (!ptt || held);
  const session = useVoiceSession({ roomId: room.id, name, localStream: stream, micHot });

  useEffect(() => {
    const ctx = primeAudioOutput();
    if (!ctx) {
      setSoundLocked(true);
      return;
    }
    const sync = () => setSoundLocked(ctx.state !== "running");
    void ctx.resume().finally(sync);
  }, []);

  useEffect(() => {
    const current = stream?.getAudioTracks()[0];
    if (current) current.enabled = micHot;
  }, [stream, micHot]);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        Boolean(target?.isContentEditable);
      if (event.code === "KeyM" && event.type === "keydown" && !event.repeat && !typing && !ptt) {
        event.preventDefault();
        setMuted((value) => !value);
      }
      if (ptt && event.code === "Space" && !typing) {
        event.preventDefault();
        setHeld(event.type === "keydown");
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKey);
    };
  }, [ptt]);

  const seenPeers = useRef<Set<string> | null>(null);
  useEffect(() => {
    const ids = new Set(
      session.peers.filter((peer) => peer.connectionState === "connected").map((peer) => peer.id),
    );
    if (seenPeers.current === null) {
      seenPeers.current = ids;
      return;
    }
    let joined = false;
    let left = false;
    for (const id of ids) if (!seenPeers.current.has(id)) joined = true;
    for (const id of seenPeers.current) if (!ids.has(id)) left = true;
    seenPeers.current = ids;
    if (joined) playChime("join");
    else if (left) playChime("leave");
  }, [session.peers]);

  useEffect(() => {
    const wide = window.matchMedia("(min-width: 1024px)");
    const mark = () => {
      if (wide.matches || chatOpen) setSeen(session.lines.length);
    };
    mark();
    wide.addEventListener("change", mark);
    return () => wide.removeEventListener("change", mark);
  }, [chatOpen, session.lines.length]);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [session.lines, chatOpen]);

  const count = session.peers.length + 1;
  const unread = Math.max(0, session.lines.length - seen);
  const failed = session.peers.some(
    (peer) => peer.connectionState === "failed" || peer.connectionState === "disconnected",
  );

  async function enableMic() {
    primeAudioOutput();
    try {
      const next = await requestMic();
      setStream((prev) => {
        prev?.getTracks().forEach((track) => track.stop());
        return next;
      });
      setNote(null);
      setMuted(false);
    } catch (error) {
      setNote(micErrorMessage(error));
    }
  }

  function submitChat() {
    const now = Date.now();
    if (now - lastChat.current < 400) return;
    if (!session.sendChat(draft)) return;
    lastChat.current = now;
    setDraft("");
  }

  async function copyLink() {
    const url = `${window.location.origin}/?r=${room.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast("تم نسخ رابط الغرفة");
    } catch {
      toast(url);
    }
  }

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <div className="h-1 shrink-0 bg-primary" />
      <header className="flex shrink-0 items-center gap-2 border-b border-border px-3 py-3 sm:gap-3 sm:px-4">
        <button
          type="button"
          onClick={onLeave}
          className="inline-flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border px-3 text-sm transition-transform duration-150 active:scale-[0.96]"
        >
          <PhoneOff className="size-4" aria-hidden="true" />
          الغرف
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-display text-xl leading-tight">{room.title}</h1>
          <p className="truncate text-sm text-muted">
            <span className="tabular-nums" dir="ltr">
              {count}/{ROOM_CAP}
            </span>
            <span> · {session.joined ? "متصل بالصالة" : "جارٍ الدخول…"}</span>
            {isPrivateId(room.id) ? (
              <span dir="ltr" className="ms-1 text-primary">
                {privateCode(room.id)}
              </span>
            ) : null}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void copyLink()}
          className="grid size-11 shrink-0 place-items-center rounded-xl border border-border transition-transform duration-150 active:scale-[0.96]"
          aria-label="نسخ رابط الغرفة"
        >
          <Copy className="size-4" />
        </button>
      </header>

      <div className="flex min-h-0 flex-1">
        <section
          className={cn("flex min-h-0 min-w-0 flex-1 flex-col", chatOpen && "hidden lg:flex")}
          aria-label="الحاضرون"
        >
          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6">
            {session.peers.length === 0 ? (
              <p className="mx-auto mb-8 max-w-sm text-center text-sm text-muted">
                أنت أول الحاضرين. انسخ الرابط وافتحه من جهاز آخر ليبدأ الصوت.
              </p>
            ) : null}
            <ul className="mx-auto grid w-full max-w-lg grid-cols-2 gap-4 sm:grid-cols-3">
              <PersonOrb
                id={session.selfId}
                name={name}
                you
                stream={stream}
                analyse={micHot}
                hand={session.handUp}
                muted={!micHot}
                subtitle={stream ? (micHot ? "تتحدث" : "مكتوم") : "مستمع"}
              />
              {session.peers.map((peer) => (
                <PersonOrb
                  key={peer.id}
                  id={peer.id}
                  name={peer.name || "ضيف"}
                  stream={session.streams[peer.id] ?? null}
                  analyse={Boolean(session.streams[peer.id])}
                  hand={session.hands[peer.id]}
                  muted={session.mutes[peer.id]}
                  subtitle={peerSubtitle(peer)}
                  volume={deaf ? 0 : (volumes[peer.id] ?? 1)}
                  expanded={openVolume === peer.id}
                  onToggle={() => setOpenVolume((current) => (current === peer.id ? null : peer.id))}
                  onVolume={(value) => setVolumes((prev) => ({ ...prev, [peer.id]: value }))}
                />
              ))}
            </ul>
            {failed ? (
              <p className="mx-auto mt-8 max-w-sm text-center text-sm text-muted">
                بعض الأجهزة لم تصل مباشرة. غالباً الشبكة تمنع المسار الصوتي بينها.
              </p>
            ) : null}
          </div>

          <div className="flex shrink-0 justify-center gap-2 px-4 pb-3">
            <div className="inline-flex rounded-full bg-surface p-1">
              <button
                type="button"
                aria-pressed={!ptt}
                onClick={() => {
                  setPtt(false);
                  setHeld(false);
                }}
                className={cn(
                  "h-10 rounded-full px-4 text-sm transition-colors",
                  !ptt ? "bg-surface-2 text-fg" : "text-muted",
                )}
              >
                مفتوح
              </button>
              <button
                type="button"
                aria-pressed={ptt}
                onClick={() => {
                  setPtt(true);
                  setHeld(false);
                  setMuted(false);
                }}
                className={cn(
                  "h-10 rounded-full px-4 text-sm transition-colors",
                  ptt ? "bg-surface-2 text-fg" : "text-muted",
                )}
              >
                اضغط للتحدث
              </button>
            </div>
          </div>
        </section>

        <aside
          className={cn(
            "min-h-0 min-w-0 flex-col border-border bg-surface",
            chatOpen ? "flex flex-1 lg:w-80 lg:flex-none lg:border-s" : "hidden lg:flex lg:w-80 lg:shrink-0 lg:border-s",
          )}
          aria-label="دردشة الغرفة"
        >
          <div className="border-b border-border px-4 py-3">
            <h2 className="font-display text-lg">الدردشة</h2>
            <p className="text-xs text-muted">تختفي الرسائل بمغادرة الغرفة</p>
          </div>
          <div ref={scrollerRef} className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-4">
            {session.lines.length === 0 ? (
              <p className="text-sm text-muted">كن أول من يسلّم. الصوت يبقى الأساس.</p>
            ) : (
              session.lines.map((line) => (
                <ChatBubble key={line.id} line={line} mine={line.from === session.selfId} />
              ))
            )}
          </div>
          <form
            className="flex gap-2 border-t border-border p-3"
            onSubmit={(event) => {
              event.preventDefault();
              submitChat();
            }}
          >
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              maxLength={400}
              placeholder="اكتب رسالة"
              className="h-12 min-w-0 flex-1 rounded-2xl border border-border bg-bg px-4 text-base text-fg outline-none placeholder:text-muted"
            />
            <button
              type="submit"
              className="h-12 shrink-0 rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]"
            >
              إرسال
            </button>
          </form>
        </aside>
      </div>

      {(note || soundLocked) && (
        <div className="shrink-0 border-t border-border bg-surface px-4 py-2 text-center text-sm text-muted">
          {soundLocked ? (
            <button
              type="button"
              className="text-primary"
              onClick={() => {
                const ctx = primeAudioOutput();
                void ctx?.resume().finally(() => setSoundLocked(ctx?.state !== "running"));
              }}
            >
              اضغط لتشغيل صوت الغرفة
            </button>
          ) : null}
          {note ? <span className={soundLocked ? "ms-3" : undefined}>{note}</span> : null}
          {note && !stream ? (
            <button type="button" className="ms-2 text-primary" onClick={() => void enableMic()}>
              إعادة المحاولة
            </button>
          ) : null}
        </div>
      )}

      <footer className="shrink-0 border-t border-border px-3 py-3">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-pressed={micHot}
              aria-label={ptt ? "اضغط مع الاستمرار للتحدث" : micHot ? "كتم الميكروفون" : "فتح الميكروفون"}
              onPointerDown={(event) => {
                if (!ptt) return;
                event.currentTarget.setPointerCapture(event.pointerId);
                setHeld(true);
              }}
              onPointerUp={() => ptt && setHeld(false)}
              onPointerCancel={() => setHeld(false)}
              onContextMenu={(event) => ptt && event.preventDefault()}
              onClick={() => {
                if (ptt) return;
                if (!stream) {
                  void enableMic();
                  return;
                }
                setMuted((value) => !value);
              }}
              className={cn(
                "grid size-14 touch-none place-items-center rounded-full transition-transform duration-150 active:scale-[0.96]",
                micHot ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg",
              )}
            >
              {micHot ? <Mic className="size-6" /> : <MicOff className="size-6" />}
            </button>
            <DockButton
              label={deaf ? "السماعات متوقفة" : "إيقاف السماعات"}
              pressed={deaf}
              onClick={() => setDeaf((value) => !value)}
            >
              {deaf ? <HeadphoneOff className="size-5" /> : <Headphones className="size-5" />}
            </DockButton>
            <DockButton
              label={session.handUp ? "اخفض يدك" : "ارفع يدك"}
              pressed={session.handUp}
              onClick={() => session.setHandUp(!session.handUp)}
            >
              <Hand className="size-5" />
            </DockButton>
            <DockButton
              label="الدردشة"
              pressed={chatOpen}
              className="relative lg:hidden"
              onClick={() => setChatOpen((value) => !value)}
            >
              <MessageCircle className="size-5" />
              {unread > 0 ? (
                <span className="absolute top-2 left-2 size-2 rounded-full bg-primary" />
              ) : null}
            </DockButton>
          </div>
          <button
            type="button"
            onClick={onLeave}
            className="inline-flex h-12 items-center gap-2 rounded-2xl border border-border px-4 text-sm transition-transform duration-150 active:scale-[0.96]"
          >
            مغادرة
          </button>
        </div>
        <p className="mt-2 text-center text-xs text-muted">
          السماعات تمنع الصدى.
          <span className="hidden md:inline"> M للكتم{ptt ? "، والمسافة للتحدث" : ""}.</span>
        </p>
      </footer>
    </div>
  );
}

function peerSubtitle(peer: PeerInfo): string {
  if (peer.connectionState === "connected") {
    return peer.rttMs != null ? `${peer.rttMs} ms` : "متصل";
  }
  if (peer.connectionState === "failed") return "تعذّر المسار";
  if (peer.connectionState === "disconnected") return "انقطع";
  return "يتم الاتصال";
}

function PersonOrb({
  id,
  name,
  you,
  stream,
  analyse,
  hand,
  muted,
  subtitle,
  volume,
  expanded,
  onToggle,
  onVolume,
}: {
  id: string;
  name: string;
  you?: boolean;
  stream: MediaStream | null;
  analyse: boolean;
  hand?: boolean;
  muted?: boolean;
  subtitle: string;
  volume?: number;
  expanded?: boolean;
  onToggle?: () => void;
  onVolume?: (value: number) => void;
}) {
  const { level, speaking } = useAudioLevel(stream, you ? analyse : Boolean(stream), !you, volume ?? 1);
  const body = (
    <>
      <span
        className={cn(
          "relative grid size-20 place-items-center rounded-full border-2 bg-surface font-display text-2xl",
          speaking ? "speaking-ring border-live" : "border-border",
        )}
      >
        {initials(name)}
        {muted ? (
          <span className="absolute -bottom-1 -left-1 grid size-7 place-items-center rounded-full bg-surface-2 text-fg">
            <MicOff className="size-3.5" aria-hidden="true" />
          </span>
        ) : null}
        {hand ? (
          <span className="absolute -top-1 -right-1 grid size-7 place-items-center rounded-full bg-primary text-primary-fg">
            <Hand className="size-3.5" aria-hidden="true" />
          </span>
        ) : null}
      </span>
      <span className="mt-3 max-w-full truncate text-sm font-medium">{name}</span>
      <span className="text-xs text-muted" dir={subtitle.endsWith("ms") ? "ltr" : undefined}>
        {you ? "أنت" : subtitle}
        {you ? ` · ${subtitle}` : ""}
      </span>
      {you ? (
        <span className="mt-2 h-1 w-16 overflow-hidden rounded-full bg-border">
          <span className="block h-full bg-live" style={{ width: `${Math.round(level * 100)}%` }} />
        </span>
      ) : null}
    </>
  );

  return (
    <li className="flex flex-col items-center text-center" data-peer={id} data-hearing={!you && stream ? "yes" : undefined}>
      {onToggle ? (
        <button type="button" onClick={onToggle} className="flex flex-col items-center" aria-expanded={expanded}>
          {body}
        </button>
      ) : (
        <div className="flex flex-col items-center">{body}</div>
      )}
      {expanded && onVolume ? (
        <div className="mt-3 w-full px-1">
          <Slider.Root
            dir="ltr"
            min={0}
            max={1}
            step={0.05}
            value={[volume ?? 1]}
            onValueChange={(value) => onVolume(value[0] ?? 0)}
            className="relative flex h-6 touch-none items-center"
            aria-label={`صوت ${name}`}
          >
            <Slider.Track className="relative h-1 grow rounded-full bg-border">
              <Slider.Range className="absolute h-full rounded-full bg-primary" />
            </Slider.Track>
            <Slider.Thumb className="block size-4 rounded-full bg-primary" />
          </Slider.Root>
        </div>
      ) : null}
    </li>
  );
}

function ChatBubble({ line, mine }: { line: ChatLine; mine: boolean }) {
  return (
    <article className={cn("max-w-xs rounded-2xl px-3 py-2", mine ? "self-start bg-primary text-primary-fg" : "self-end bg-bg text-fg")}>
      <p className="text-xs opacity-80">
        {mine ? "أنت" : line.name}
        <span className="ms-2 tabular-nums" dir="ltr">
          {timeFmt.format(line.at)}
        </span>
      </p>
      <p dir="auto" className="text-sm leading-6">
        {line.text}
      </p>
    </article>
  );
}

function DockButton({
  children,
  label,
  pressed,
  onClick,
  className,
}: {
  children: ReactNode;
  label: string;
  pressed?: boolean;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      aria-label={label}
      onClick={onClick}
      className={cn(
        "grid size-12 place-items-center rounded-2xl border border-border transition-transform duration-150 active:scale-[0.96]",
        pressed ? "bg-surface-2 text-primary" : "text-fg",
        className,
      )}
    >
      {children}
    </button>
  );
}
