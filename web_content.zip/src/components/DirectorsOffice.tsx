import React from 'react';
import {
  Briefcase,
  Bot,
  UserCheck,
  UserX,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  AlertCircle,
  Film,
} from 'lucide-react';
import { StationDirector } from '../types/game';
import { soundFx } from '../utils/audio';

interface DirectorsOfficeProps {
  directors: StationDirector[];
  cash: number;
  onHireDirector: (directorId: string) => void;
  onFireDirector: (directorId: string) => void;
  onToggleDirectorAuto: (directorId: string) => void;
  onRequestProposal?: () => void;
}

export const DirectorsOffice: React.FC<DirectorsOfficeProps> = ({
  directors,
  cash,
  onHireDirector,
  onFireDirector,
  onToggleDirectorAuto,
  onRequestProposal,
}) => {
  const totalPayroll = directors
    .filter((d) => d.isHired)
    .reduce((sum, d) => sum + d.salary, 0);

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Header Banner - Compact */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-amber-400" />
            Gabinete da Diretoria Executiva & Automação
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Nomeie diretores para gerenciar a emissora no piloto automático. Você não precisa ficar clicando em botões o tempo todo, mas pode intervir quando quiser!
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-400 block uppercase">
            CUSTO DIÁRIO DA DIRETORIA
          </span>
          <span className="text-xs font-mono font-bold text-amber-400">
            R$ {totalPayroll.toLocaleString('pt-BR')} / dia
          </span>
        </div>
      </div>

      {/* Directors Cards Grid - Compact */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {directors.map((director) => (
          <div
            key={director.id}
            className={`rounded-xl border p-4 flex flex-col justify-between transition-all shadow-md ${
              director.isHired
                ? 'bg-slate-900/95 border-amber-500/40 shadow-amber-950/20'
                : 'bg-slate-900/70 border-slate-800'
            }`}
          >
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl shrink-0">
                    {director.avatarEmoji}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      {director.name}
                      {director.isHired && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-500 text-emerald-400 font-mono font-bold">
                          NOMEADO
                        </span>
                      )}
                    </h3>
                    <div className="text-xs text-amber-400 font-semibold">{director.role}</div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-400 block">SALÁRIO DIÁRIO</span>
                  <span className="text-xs font-mono font-bold text-slate-200">
                    R$ {director.salary.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>

              {/* Description & Function */}
              <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                {director.description}
              </p>

              {/* Automation Toggle State */}
              {director.isHired && (
                <div className="mt-3 p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bot className={`w-4 h-4 ${director.isAutoActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <div>
                      <span className="text-xs font-bold text-white block">
                        {director.isAutoActive ? 'Automação Ativa (Piloto Automático)' : 'Modo Manual (Aguardando Você)'}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {director.isAutoActive
                          ? 'O diretor toma decisões sozinho para você não se preocupar.'
                          : 'O diretor não age automaticamente; controle tudo você mesmo.'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundFx.playClick();
                      onToggleDirectorAuto(director.id);
                    }}
                    className="p-1 text-slate-300 hover:text-white cursor-pointer"
                    title={director.isAutoActive ? 'Pausar automação deste diretor' : 'Ativar automação deste diretor'}
                  >
                    {director.isAutoActive ? (
                      <ToggleRight className="w-7 h-7 text-emerald-400" />
                    ) : (
                      <ToggleLeft className="w-7 h-7 text-slate-600" />
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between">
              {director.isHired ? (
                <div className="flex items-center gap-2 w-full justify-between">
                  {director.id === 'dir-teledramaturgia' && onRequestProposal ? (
                    <button
                      onClick={() => {
                        soundFx.playClick();
                        onRequestProposal();
                      }}
                      className="min-h-[44px] px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                    >
                      <Film className="w-4 h-4 text-amber-400" />
                      <span>Pedir Projeto Agora</span>
                    </button>
                  ) : (
                    <div />
                  )}

                  <button
                    onClick={() => {
                      soundFx.playClick();
                      onFireDirector(director.id);
                    }}
                    className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-red-950/50 border border-slate-800 hover:border-red-800 text-xs text-red-400 font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <UserX className="w-4 h-4" />
                    <span>Destituir</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    if (cash >= director.salary * 3) {
                      soundFx.playVictory();
                      onHireDirector(director.id);
                    }
                  }}
                  disabled={cash < director.salary * 3}
                  className={`w-full min-h-[46px] py-2 px-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer ${
                    cash >= director.salary * 3
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-950/40'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-70'
                  }`}
                >
                  <UserCheck className="w-4 h-4" />
                  <span>
                    {cash >= director.salary * 3
                      ? 'Nomear para a Diretoria'
                      : `Caixa Insuficiente (Necessário R$ ${(director.salary * 3).toLocaleString('pt-BR')})`}
                  </span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
