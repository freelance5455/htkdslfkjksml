import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  ChevronDown,
  Copy,
  Eye,
  EyeOff,
  LockKeyhole,
  Plus,
  Search,
  ShieldCheck,
} from "lucide-react";
import { twMerge } from "tailwind-merge";
import {
  MAX_ENTRIES,
  ITERATIONS,
  b64ToBytes,
  bytesToB64,
  clearVaultFile,
  decryptJson,
  deriveKey,
  encryptJson,
  isVaultFile,
  loadVault,
  sanitizeEntries,
  saveVaultFile,
  type VaultEntry,
  type VaultFile,
} from "@/lib/vault";

const AUTO_LOCK_MS = 180_000;
const EMAIL_OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Phase = "boot" | "setup" | "locked" | "open" | "corrupt";

type DialogState =
  | { kind: "none" }
  | { kind: "entry"; entry: VaultEntry | null }
  | { kind: "delete"; entry: VaultEntry }
  | { kind: "pass" }
  | { kind: "wipe" }
  | { kind: "import"; file: VaultFile };

type Toast = { id: number; text: string };

function cn(...parts: Array<string | false | undefined>) {
  return twMerge(parts.filter(Boolean).join(" "));
}

const controlClass =
  "w-full rounded-xl border border-line bg-bg px-4 text-base text-fg outline-none placeholder:text-muted focus-visible:border-brass";

export function VaultApp() {
  const [phase, setPhase] = useState<Phase>("boot");
  const [entries, setEntries] = useState<VaultEntry[]>([]);
  const [hint, setHint] = useState("");
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const [toast, setToast] = useState<Toast | null>(null);
  const [query, setQuery] = useState("");
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [copied, setCopied] = useState<{ id: string; field: "email" | "code" } | null>(null);
  const fileRef = useRef<VaultFile | null>(null);
  const keyRef = useRef<CryptoKey | null>(null);

  const notify = useCallback((text: string) => {
    setToast({ id: Date.now(), text });
  }, []);

  const closeDialog = useCallback(() => setDialog({ kind: "none" }), []);

  const lock = useCallback(() => {
    keyRef.current = null;
    setEntries([]);
    setRevealed({});
    setQuery("");
    setCopied(null);
    setDialog({ kind: "none" });
    setPhase(fileRef.current ? "locked" : "setup");
  }, []);

  useEffect(() => {
    const loaded = loadVault();
    if (loaded.status === "empty") {
      fileRef.current = null;
      setPhase("setup");
      return;
    }
    if (loaded.status === "corrupt") {
      fileRef.current = null;
      setPhase("corrupt");
      return;
    }
    fileRef.current = loaded.file;
    setHint(loaded.file.hint);
    setPhase("locked");
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (phase !== "open") return;
    let timer = window.setTimeout(() => lock(), AUTO_LOCK_MS);
    const bump = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => lock(), AUTO_LOCK_MS);
    };
    window.addEventListener("pointerdown", bump);
    window.addEventListener("keydown", bump);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("pointerdown", bump);
      window.removeEventListener("keydown", bump);
    };
  }, [phase, lock]);

  useEffect(() => {
    if (phase !== "open") return;
    const onHide = () => {
      if (document.visibilityState === "hidden") setRevealed({});
    };
    document.addEventListener("visibilitychange", onHide);
    return () => document.removeEventListener("visibilitychange", onHide);
  }, [phase]);

  async function createVault(passphrase: string, nextHint: string) {
    if (!crypto.subtle) throw new Error("Is browser mein encryption nahi chalti.");
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const key = await deriveKey(passphrase, salt, ITERATIONS);
    const sealed = await encryptJson(key, { entries: [] });
    const file: VaultFile = {
      v: 1,
      kdf: "PBKDF2-SHA256",
      iterations: ITERATIONS,
      salt: bytesToB64(salt),
      iv: sealed.iv,
      data: sealed.data,
      hint: nextHint.trim(),
      createdAt: Date.now(),
    };
    saveVaultFile(file);
    fileRef.current = file;
    keyRef.current = key;
    setHint(file.hint);
    setEntries([]);
    setPhase("open");
    notify("Tijori ban gayi. Ab entries add karo.");
  }

  async function unlock(passphrase: string) {
    const file = fileRef.current;
    if (!file) throw new Error("Vault nahi mili.");
    const key = await deriveKey(passphrase, b64ToBytes(file.salt), file.iterations);
    let payload: unknown;
    try {
      payload = await decryptJson(key, file.iv, file.data);
    } catch {
      throw new Error("Yeh passphrase nahi hai.");
    }
    keyRef.current = key;
    setEntries(sanitizeEntries(payload));
    setPhase("open");
  }

  async function writeEntries(next: VaultEntry[]) {
    const key = keyRef.current;
    const file = fileRef.current;
    if (!key || !file) throw new Error("Pehle tijori kholo.");
    const sealed = await encryptJson(key, { entries: next });
    const updated: VaultFile = { ...file, iv: sealed.iv, data: sealed.data };
    saveVaultFile(updated);
    fileRef.current = updated;
    setEntries(next);
  }

  async function saveEntry(next: VaultEntry) {
    const exists = entries.some((entry) => entry.id === next.id);
    if (!exists && entries.length >= MAX_ENTRIES) {
      throw new Error("50 entries full hain. Pehle koi purani hatao.");
    }
    const rest = entries.filter((entry) => entry.id !== next.id);
    await writeEntries([next, ...rest]);
    closeDialog();
    notify("Save ho gaya. Is device par encrypted hai.");
  }

  async function removeEntry(id: string) {
    await writeEntries(entries.filter((entry) => entry.id !== id));
    setRevealed((current) => {
      const next = { ...current };
      delete next[id];
      return next;
    });
    closeDialog();
    notify("Entry hat gayi.");
  }

  async function changePass(oldPass: string, newPass: string) {
    const file = fileRef.current;
    if (!file) throw new Error("Vault nahi mili.");
    const oldKey = await deriveKey(oldPass, b64ToBytes(file.salt), file.iterations);
    let payload: unknown;
    try {
      payload = await decryptJson(oldKey, file.iv, file.data);
    } catch {
      throw new Error("Purani passphrase galat hai.");
    }
    const nextEntries = sanitizeEntries(payload);
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const newKey = await deriveKey(newPass, salt, ITERATIONS);
    const sealed = await encryptJson(newKey, { entries: nextEntries });
    const updated: VaultFile = {
      ...file,
      iterations: ITERATIONS,
      salt: bytesToB64(salt),
      iv: sealed.iv,
      data: sealed.data,
    };
    saveVaultFile(updated);
    fileRef.current = updated;
    keyRef.current = newKey;
    setEntries(nextEntries);
    closeDialog();
    notify("Passphrase badal gayi.");
  }

  function commitImport(file: VaultFile) {
    saveVaultFile(file);
    fileRef.current = file;
    keyRef.current = null;
    setEntries([]);
    setHint(file.hint);
    setRevealed({});
    setDialog({ kind: "none" });
    setPhase("locked");
    notify("Backup lag gayi. Us file wali passphrase se kholo.");
  }

  async function stageImport(raw: File) {
    if (raw.size > 1_000_000) {
      notify("File bahut badi hai.");
      return;
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(await raw.text());
    } catch {
      notify("Yeh tijori backup nahi lagti.");
      return;
    }
    if (!isVaultFile(parsed)) {
      notify("Yeh tijori backup nahi lagti.");
      return;
    }
    if (phase === "setup" || phase === "corrupt") {
      commitImport(parsed);
      return;
    }
    setDialog({ kind: "import", file: parsed });
  }

  function exportBackup() {
    const file = fileRef.current;
    if (!file) return;
    const blob = new Blob([JSON.stringify(file)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "tijori-backup.json";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    notify("Backup download ho gayi. File encrypted hai.");
  }

  function wipe() {
    clearVaultFile();
    fileRef.current = null;
    keyRef.current = null;
    setEntries([]);
    setHint("");
    setRevealed({});
    setDialog({ kind: "none" });
    setPhase("setup");
    notify("Tijori is device se mit gayi.");
  }

  async function copyText(entry: VaultEntry, field: "email" | "code") {
    const text = field === "email" ? entry.email : entry.code;
    try {
      await navigator.clipboard.writeText(text);
      setCopied({ id: entry.id, field });
      window.setTimeout(() => {
        setCopied((current) =>
          current && current.id === entry.id && current.field === field ? null : current,
        );
      }, 1600);
    } catch {
      notify("Copy nahi hua. Code dikhao, phir khud select karo.");
    }
  }

  const needle = query.trim().toLowerCase();
  const visible = entries.filter((entry) => {
    if (!needle) return true;
    return [entry.name, entry.email, entry.note, entry.code].some((part) =>
      part.toLowerCase().includes(needle),
    );
  });

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <div className="h-1 bg-brass" />
      {toast ? (
        <div className="pointer-events-none fixed inset-x-0 top-4 z-40 flex justify-center px-4">
          <p
            role="status"
            className="max-w-md rounded-xl border border-line bg-surface px-4 py-3 text-center text-sm text-fg"
          >
            {toast.text}
          </p>
        </div>
      ) : null}

      {phase === "boot" ? <BootScreen /> : null}
      {phase === "setup" ? <SetupScreen onCreate={createVault} onImport={stageImport} /> : null}
      {phase === "locked" ? (
        <LockScreen hint={hint} onUnlock={unlock} onImport={stageImport} onWipe={() => setDialog({ kind: "wipe" })} />
      ) : null}
      {phase === "corrupt" ? (
        <CorruptScreen onImport={stageImport} onWipe={() => setDialog({ kind: "wipe" })} />
      ) : null}
      {phase === "open" ? (
        <OpenScreen
          entries={entries}
          visible={visible}
          query={query}
          revealed={revealed}
          copied={copied}
          onQuery={setQuery}
          onToggle={(id) => setRevealed((current) => ({ ...current, [id]: !current[id] }))}
          onCopy={copyText}
          onAdd={() => setDialog({ kind: "entry", entry: null })}
          onEdit={(entry) => setDialog({ kind: "entry", entry })}
          onDelete={(entry) => setDialog({ kind: "delete", entry })}
          onLock={lock}
          onExport={exportBackup}
          onImport={stageImport}
          onPass={() => setDialog({ kind: "pass" })}
          onWipe={() => setDialog({ kind: "wipe" })}
        />
      ) : null}

      {dialog.kind === "entry" ? (
        <EntryDialog
          entry={dialog.entry}
          onClose={closeDialog}
          onSave={saveEntry}
        />
      ) : null}
      {dialog.kind === "delete" ? (
        <ConfirmDialog
          title="Entry hatao?"
          body={`${dialog.entry.email} aur uska security code is device se mit jayega.`}
          confirmLabel="Hatao"
          danger
          onClose={closeDialog}
          onConfirm={() => removeEntry(dialog.entry.id)}
        />
      ) : null}
      {dialog.kind === "pass" ? (
        <PassDialog onClose={closeDialog} onSubmit={changePass} />
      ) : null}
      {dialog.kind === "wipe" ? (
        <WipeDialog onClose={closeDialog} onConfirm={wipe} />
      ) : null}
      {dialog.kind === "import" ? (
        <ConfirmDialog
          title="Backup se badlo?"
          body="Purani entries is device se hat jayengi. Nayi file ki passphrase se tijori khulegi."
          confirmLabel="Badal do"
          danger
          onClose={closeDialog}
          onConfirm={() => commitImport(dialog.file)}
        />
      ) : null}
    </div>
  );
}

function BootScreen() {
  return (
    <Gate
      title="Tijori"
      lede="Email aur security code, sirf is device par."
    />
  );
}

function SetupScreen({
  onCreate,
  onImport,
}: {
  onCreate: (passphrase: string, hint: string) => Promise<void>;
  onImport: (file: File) => Promise<void>;
}) {
  const [passphrase, setPassphrase] = useState("");
  const [again, setAgain] = useState("");
  const [hint, setHint] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (passphrase.length < 6) {
      setError("Kam se kam 6 akshar. Lamba rakho to safer.");
      return;
    }
    if (passphrase !== again) {
      setError("Dono passphrase same nahi hain.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await onCreate(passphrase, hint);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Tijori nahi bani.");
      setBusy(false);
    }
  }

  return (
    <Gate
      title="Apna lock lagao"
      lede="50 email aur 50 security code. Sab kuch is browser ke andar encrypt hota hai — server par nahi jaata."
    >
      <form className="flex flex-col gap-4" onSubmit={submit} autoComplete="off">
        <SecretField
          id="setup-pass"
          label="Master passphrase"
          value={passphrase}
          onChange={setPassphrase}
          autoComplete="new-password"
          autoFocus
        />
        <p className="text-sm text-muted">{strengthLine(passphrase)}</p>
        <SecretField
          id="setup-pass2"
          label="Phir se likho"
          value={again}
          onChange={setAgain}
          autoComplete="new-password"
        />
        <Field label="Hint (zaruri nahi)" hint="Lock screen par dikhega. Asli passphrase mat likhna.">
          <input
            id="setup-hint"
            className={cn(controlClass, "h-12")}
            value={hint}
            maxLength={80}
            onChange={(event) => setHint(event.target.value)}
            placeholder="jaise: purana ghar"
            autoComplete="off"
          />
        </Field>
        {error ? (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        ) : null}
        <BrassButton type="submit" disabled={busy}>
          {busy ? "Bana rahe hain…" : "Tijori banao"}
        </BrassButton>
      </form>
      <ul className="mt-6 flex flex-col gap-2 text-sm leading-relaxed text-muted">
        <li>Passphrase hum save nahi karte. Bhool gaye to entries nahi khulengi.</li>
        <li>Browser data clear karoge to tijori bhi mit jayegi. Backup rakhna.</li>
      </ul>
      <ImportLabel className="mt-4" onFile={onImport} label="Purani backup lao" />
    </Gate>
  );
}

function LockScreen({
  hint,
  onUnlock,
  onImport,
  onWipe,
}: {
  hint: string;
  onUnlock: (passphrase: string) => Promise<void>;
  onImport: (file: File) => Promise<void>;
  onWipe: () => void;
}) {
  const [passphrase, setPassphrase] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await onUnlock(passphrase);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nahi khuli.");
      setBusy(false);
    }
  }

  return (
    <Gate title="Tijori band hai" lede="Master passphrase se kholo. Codes tab tak chhupe rehte hain.">
      <form className="flex flex-col gap-4" onSubmit={submit} autoComplete="off">
        <SecretField
          id="unlock-pass"
          label="Master passphrase"
          value={passphrase}
          onChange={setPassphrase}
          autoComplete="current-password"
          autoFocus
        />
        {hint ? <p className="text-sm text-muted">Hint: {hint}</p> : null}
        {error ? (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        ) : null}
        <BrassButton type="submit" disabled={busy || passphrase.length === 0}>
          {busy ? "Khol rahe hain…" : "Kholo"}
        </BrassButton>
      </form>
      <div className="mt-6 flex flex-col gap-2">
        <ImportLabel onFile={onImport} label="Backup file lao" />
        <button type="button" onClick={onWipe} className="h-11 text-sm text-muted">
          Is device se tijori mitao
        </button>
      </div>
    </Gate>
  );
}

function CorruptScreen({
  onImport,
  onWipe,
}: {
  onImport: (file: File) => Promise<void>;
  onWipe: () => void;
}) {
  return (
    <Gate
      title="Vault padh nahi paayi"
      lede="File kharab lag rahi hai. Backup hai to lao, warna nayi tijori banao. Purani entries bina passphrase ke nahi khulengi."
    >
      <div className="flex flex-col gap-3">
        <ImportLabel onFile={onImport} label="Backup file lao" primary />
        <GhostButton type="button" onClick={onWipe}>
          Nayi tijori ke liye purani mitao
        </GhostButton>
      </div>
    </Gate>
  );
}

function OpenScreen({
  entries,
  visible,
  query,
  revealed,
  copied,
  onQuery,
  onToggle,
  onCopy,
  onAdd,
  onEdit,
  onDelete,
  onLock,
  onExport,
  onImport,
  onPass,
  onWipe,
}: {
  entries: VaultEntry[];
  visible: VaultEntry[];
  query: string;
  revealed: Record<string, boolean>;
  copied: { id: string; field: "email" | "code" } | null;
  onQuery: (value: string) => void;
  onToggle: (id: string) => void;
  onCopy: (entry: VaultEntry, field: "email" | "code") => void;
  onAdd: () => void;
  onEdit: (entry: VaultEntry) => void;
  onDelete: (entry: VaultEntry) => void;
  onLock: () => void;
  onExport: () => void;
  onImport: (file: File) => Promise<void>;
  onPass: () => void;
  onWipe: () => void;
}) {
  const full = entries.length >= MAX_ENTRIES;

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col md:flex-row">
      <aside className="flex flex-col gap-5 border-b border-line px-5 py-5 md:sticky md:top-0 md:h-dvh md:w-80 md:shrink-0 md:overflow-y-auto md:border-r md:border-b-0 md:px-6 md:py-8">
        <div className="flex items-center justify-between gap-3">
          <Brand />
          <button
            type="button"
            onClick={onLock}
            aria-label="Band karo"
            className="grid size-12 place-items-center rounded-full border border-line text-fg md:hidden"
          >
            <LockKeyhole className="size-5" strokeWidth={1.75} />
          </button>
        </div>
        <Slots used={entries.length} />
        <p className="text-sm leading-relaxed text-muted">
          Sirf is browser mein. 3 minute chup rehne par khud band ho jayegi.
        </p>
        <SettingsBlock
          onExport={onExport}
          onImport={onImport}
          onPass={onPass}
          onWipe={onWipe}
        />
        <div className="mt-auto hidden pt-4 md:block">
          <BrassButton type="button" onClick={onLock}>
            <LockKeyhole className="size-4" />
            Band karo
          </BrassButton>
        </div>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col px-5 pt-5 pb-28 md:px-8 md:pt-8 md:pb-10">
        <div className="flex items-center gap-3">
          <div className="relative min-w-0 flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted"
              aria-hidden="true"
            />
            <input
              type="search"
              value={query}
              onChange={(event) => onQuery(event.target.value)}
              placeholder="Email ya naam dhoondo"
              aria-label="Email ya naam dhoondo"
              className={cn(controlClass, "h-12 rounded-full pr-4 pl-11")}
            />
          </div>
          <BrassButton
            type="button"
            onClick={onAdd}
            disabled={full}
            className="hidden w-auto shrink-0 px-5 md:flex"
          >
            <Plus className="size-4" />
            Naya code
          </BrassButton>
        </div>

        {entries.length === 0 ? (
          <div className="flex flex-col items-center px-4 py-16 text-center">
            <span className="grid size-14 place-items-center rounded-2xl border border-line text-brass">
              <ShieldCheck className="size-7" strokeWidth={1.75} />
            </span>
            <h2 className="mt-4 font-display text-3xl text-fg">Abhi khali hai</h2>
            <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted">
              Pehla email aur uska security code add karo. 50 jagah hain — har jagah ek email, ek code.
            </p>
          </div>
        ) : visible.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted">Is search se kuch nahi mila.</p>
        ) : (
          <ul className="mt-5 flex flex-col gap-3">
            {visible.map((entry) => (
              <li key={entry.id}>
                <EntryCard
                  entry={entry}
                  shown={Boolean(revealed[entry.id])}
                  copied={copied}
                  onToggle={() => onToggle(entry.id)}
                  onCopy={(field) => onCopy(entry, field)}
                  onEdit={() => onEdit(entry)}
                  onDelete={() => onDelete(entry)}
                />
              </li>
            ))}
          </ul>
        )}
      </main>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg p-4 md:hidden">
        <BrassButton type="button" onClick={onAdd} disabled={full}>
          <Plus className="size-4" />
          {full ? "50 full hain" : "Naya code"}
        </BrassButton>
      </div>
    </div>
  );
}

function EntryCard({
  entry,
  shown,
  copied,
  onToggle,
  onCopy,
  onEdit,
  onDelete,
}: {
  entry: VaultEntry;
  shown: boolean;
  copied: { id: string; field: "email" | "code" } | null;
  onToggle: () => void;
  onCopy: (field: "email" | "code") => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const emailCopied = copied?.id === entry.id && copied.field === "email";
  const codeCopied = copied?.id === entry.id && copied.field === "code";
  const when = new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short" }).format(entry.updatedAt);

  return (
    <article className="rounded-card border border-line bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-base font-medium text-fg">{entry.name || "Bina naam"}</h3>
          <p className="truncate text-sm text-muted" title={entry.email}>
            {entry.email}
          </p>
        </div>
        <p className="shrink-0 text-xs text-muted">{when}</p>
      </div>
      <div className="mt-3 flex items-start gap-2 rounded-xl bg-bg px-3 py-3">
        <p className="min-w-0 flex-1 font-mono text-sm leading-relaxed break-all whitespace-pre-wrap text-fg">
          {shown ? entry.code : "••••  ••••  ••••"}
        </p>
        <button
          type="button"
          onClick={onToggle}
          aria-pressed={shown}
          aria-label={shown ? "Code chhupao" : "Code dikhao"}
          className="grid size-11 shrink-0 place-items-center rounded-full text-muted"
        >
          {shown ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
        </button>
      </div>
      {entry.note ? <p className="mt-3 line-clamp-2 text-sm text-muted">{entry.note}</p> : null}
      <div className="mt-4 grid grid-cols-2 gap-2">
        <GhostButton type="button" onClick={() => onCopy("email")} className="h-11 text-sm">
          <Copy className="size-4" />
          {emailCopied ? "Ho gaya" : "Email"}
        </GhostButton>
        <GhostButton type="button" onClick={() => onCopy("code")} className="h-11 text-sm">
          <Copy className="size-4" />
          {codeCopied ? "Ho gaya" : "Code"}
        </GhostButton>
      </div>
      <div className="mt-1 flex justify-end gap-1">
        <button type="button" onClick={onEdit} className="h-11 px-3 text-sm text-muted">
          Badlo
        </button>
        <button type="button" onClick={onDelete} className="h-11 px-3 text-sm text-danger">
          Hatao
        </button>
      </div>
    </article>
  );
}

function SettingsBlock({
  onExport,
  onImport,
  onPass,
  onWipe,
}: {
  onExport: () => void;
  onImport: (file: File) => Promise<void>;
  onPass: () => void;
  onWipe: () => void;
}) {
  const buttons = (
    <div className="flex flex-col gap-2">
      <GhostButton type="button" onClick={onExport} className="h-11">
        Backup nikalo
      </GhostButton>
      <ImportLabel onFile={onImport} label="Backup lao" />
      <GhostButton type="button" onClick={onPass} className="h-11">
        Passphrase badlo
      </GhostButton>
      <button type="button" onClick={onWipe} className="h-11 text-sm text-danger">
        Poori tijori mitao
      </button>
    </div>
  );

  return (
    <>
      <details className="group md:hidden">
        <summary className="flex h-12 list-none items-center justify-between text-sm text-fg">
          Backup aur settings
          <ChevronDown className="size-4 text-muted transition-transform duration-200 group-open:rotate-180" />
        </summary>
        <div className="pb-2">{buttons}</div>
      </details>
      <div className="hidden md:block">{buttons}</div>
    </>
  );
}

function EntryDialog({
  entry,
  onClose,
  onSave,
}: {
  entry: VaultEntry | null;
  onClose: () => void;
  onSave: (entry: VaultEntry) => Promise<void>;
}) {
  const [name, setName] = useState(entry?.name ?? "");
  const [email, setEmail] = useState(entry?.email ?? "");
  const [code, setCode] = useState(entry?.code ?? "");
  const [note, setNote] = useState(entry?.note ?? "");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    const cleanEmail = email.trim();
    const cleanCode = code.trim();
    if (!EMAIL_OK.test(cleanEmail)) {
      setError("Email poora likho — jaise naam@email.com");
      return;
    }
    if (!cleanCode) {
      setError("Security code likho.");
      return;
    }
    if (name.trim().length > 60 || cleanCode.length > 2000 || note.trim().length > 500) {
      setError("Bahut lamba hai. Thoda chhota karo.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await onSave({
        id: entry?.id ?? crypto.randomUUID(),
        name: name.trim(),
        email: cleanEmail,
        code: cleanCode,
        note: note.trim(),
        updatedAt: Date.now(),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save nahi hua.");
      setBusy(false);
    }
  }

  return (
    <Sheet title={entry ? "Entry badlo" : "Nayi entry"} onClose={onClose}>
      <form className="flex flex-col gap-4" onSubmit={submit} autoComplete="off">
        <Field label="Naam" hint="Jaise Gmail, bank, Instagram">
          <input
            id="entry-name"
            className={cn(controlClass, "h-12")}
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Gmail"
            autoComplete="off"
            autoFocus
          />
        </Field>
        <Field label="Email">
          <input
            id="entry-email"
            type="email"
            inputMode="email"
            className={cn(controlClass, "h-12")}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="naam@email.com"
            autoComplete="off"
            spellCheck={false}
          />
        </Field>
        <Field label="Security code" hint="Ek se zyada ho to nayi line par likho.">
          <textarea
            id="entry-code"
            className={cn(controlClass, "min-h-28 resize-y py-3 font-mono text-sm")}
            value={code}
            onChange={(event) => setCode(event.target.value)}
            placeholder="security code"
            autoComplete="off"
            spellCheck={false}
            rows={4}
          />
        </Field>
        <Field label="Note">
          <input
            id="entry-note"
            className={cn(controlClass, "h-12")}
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="optional"
            autoComplete="off"
          />
        </Field>
        {error ? (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        ) : null}
        <div className="grid grid-cols-2 gap-2">
          <GhostButton type="button" onClick={onClose}>
            Rehne do
          </GhostButton>
          <BrassButton type="submit" disabled={busy}>
            {busy ? "Save…" : "Save karo"}
          </BrassButton>
        </div>
      </form>
    </Sheet>
  );
}

function PassDialog({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (oldPass: string, newPass: string) => Promise<void>;
}) {
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [again, setAgain] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (newPass.length < 6) {
      setError("Nayi passphrase kam se kam 6 akshar.");
      return;
    }
    if (newPass !== again) {
      setError("Nayi passphrase match nahi kar rahi.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await onSubmit(oldPass, newPass);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nahi badli.");
      setBusy(false);
    }
  }

  return (
    <Sheet title="Passphrase badlo" onClose={onClose}>
      <form className="flex flex-col gap-4" onSubmit={submit} autoComplete="off">
        <SecretField
          id="old-pass"
          label="Purani passphrase"
          value={oldPass}
          onChange={setOldPass}
          autoComplete="current-password"
          autoFocus
        />
        <SecretField
          id="new-pass"
          label="Nayi passphrase"
          value={newPass}
          onChange={setNewPass}
          autoComplete="new-password"
        />
        <SecretField
          id="new-pass2"
          label="Nayi phir se"
          value={again}
          onChange={setAgain}
          autoComplete="new-password"
        />
        {error ? (
          <p role="alert" className="text-sm text-danger">
            {error}
          </p>
        ) : null}
        <div className="grid grid-cols-2 gap-2">
          <GhostButton type="button" onClick={onClose}>
            Rehne do
          </GhostButton>
          <BrassButton type="submit" disabled={busy}>
            {busy ? "Badal rahe…" : "Badlo"}
          </BrassButton>
        </div>
      </form>
    </Sheet>
  );
}

function WipeDialog({ onClose, onConfirm }: { onClose: () => void; onConfirm: () => void }) {
  const [phrase, setPhrase] = useState("");
  const ready = phrase.trim() === "MITAO";

  return (
    <Sheet title="Poori tijori mitao?" onClose={onClose}>
      <p className="text-sm leading-relaxed text-muted">
        Saari entries is device se khatam. Jo backup pehle download ki hai, woh file nahi mitegi. Wapas nahi aayega.
      </p>
      <form
        className="mt-4 flex flex-col gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          if (ready) onConfirm();
        }}
      >
        <Field label="MITAO likho">
          <input
            className={cn(controlClass, "h-12")}
            value={phrase}
            onChange={(event) => setPhrase(event.target.value)}
            placeholder="MITAO"
            autoComplete="off"
            autoFocus
            aria-label="MITAO likho"
          />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <GhostButton type="button" onClick={onClose}>
            Rehne do
          </GhostButton>
          <button
            type="submit"
            disabled={!ready}
            className="flex h-12 items-center justify-center rounded-full bg-danger px-4 text-sm font-medium text-brass-ink disabled:opacity-50"
          >
            Mitao
          </button>
        </div>
      </form>
    </Sheet>
  );
}

function ConfirmDialog({
  title,
  body,
  confirmLabel,
  danger,
  onClose,
  onConfirm,
}: {
  title: string;
  body: string;
  confirmLabel: string;
  danger?: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <Sheet title={title} onClose={onClose}>
      <p className="text-sm leading-relaxed text-muted">{body}</p>
      <div className="mt-5 grid grid-cols-2 gap-2">
        <GhostButton type="button" onClick={onClose}>
          Rehne do
        </GhostButton>
        <button
          type="button"
          onClick={onConfirm}
          className={cn(
            "flex h-12 items-center justify-center rounded-full px-4 text-sm font-medium",
            danger ? "bg-danger text-brass-ink" : "bg-brass text-brass-ink",
          )}
        >
          {confirmLabel}
        </button>
      </div>
    </Sheet>
  );
}

function Gate({ title, lede, children }: { title: string; lede: string; children?: ReactNode }) {
  return (
    <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 py-10">
      <Brand />
      <h1 className="mt-8 font-display text-4xl leading-tight text-fg">{title}</h1>
      <p className="mt-3 text-base leading-relaxed text-muted">{lede}</p>
      {children ? <div className="mt-8">{children}</div> : null}
    </div>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-3">
      <span className="grid size-12 shrink-0 place-items-center rounded-2xl border border-line bg-surface text-brass">
        <LockKeyhole className="size-6" strokeWidth={1.75} />
      </span>
      <div>
        <p className="text-xs font-medium tracking-widest text-brass uppercase">Tijori</p>
        <p className="text-sm text-muted">Private email locker</p>
      </div>
    </div>
  );
}

function Slots({ used }: { used: number }) {
  return (
    <div>
      <p className="text-sm text-muted">
        <span className="font-display text-3xl text-fg">{used}</span>
        <span> / {MAX_ENTRIES} bhare</span>
      </p>
      <div className="mt-3 grid grid-cols-10 gap-1" aria-hidden="true">
        {Array.from({ length: MAX_ENTRIES }, (_, index) => (
          <span
            key={index}
            className={cn("h-1.5 rounded-full", index < used ? "bg-brass" : "bg-line")}
          />
        ))}
      </div>
    </div>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const titleId = useId();

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="relative z-10 max-h-dvh w-full max-w-md overflow-y-auto rounded-t-card border border-line bg-surface p-5 pb-8 sm:rounded-card sm:pb-5"
      >
        <h2 id={titleId} className="font-display text-3xl leading-tight text-fg">
          {title}
        </h2>
        <div className="mt-5">{children}</div>
      </div>
      <button type="button" className="absolute inset-0 bg-bg/80" aria-label="Band karo" onClick={onClose} />
    </div>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="flex flex-col gap-2 text-sm text-muted">
      <span className="font-medium text-fg">{label}</span>
      {children}
      {hint ? <span>{hint}</span> : null}
    </label>
  );
}

function SecretField({
  id,
  label,
  value,
  onChange,
  autoComplete,
  autoFocus,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  autoComplete: string;
  autoFocus?: boolean;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-sm font-medium text-fg">
        {label}
      </label>
      <div className="relative">
        <input
          id={id}
          type={show ? "text" : "password"}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          autoComplete={autoComplete}
          autoFocus={autoFocus}
          spellCheck={false}
          className={cn(controlClass, "h-12 pr-14")}
        />
        <button
          type="button"
          onClick={() => setShow((current) => !current)}
          aria-label={show ? "Chhupao" : "Dikhao"}
          className="absolute top-1 right-1 grid size-10 place-items-center rounded-full text-muted"
        >
          {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
        </button>
      </div>
    </div>
  );
}

function ImportLabel({
  onFile,
  label,
  className,
  primary,
}: {
  onFile: (file: File) => Promise<void>;
  label: string;
  className?: string;
  primary?: boolean;
}) {
  return (
    <label
      className={cn(
        "flex h-12 cursor-pointer items-center justify-center rounded-full px-4 text-sm font-medium",
        primary ? "bg-brass text-brass-ink" : "border border-line text-fg",
        className,
      )}
    >
      {label}
      <input
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) void onFile(file);
        }}
      />
    </label>
  );
}

function BrassButton({
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={cn(
        "flex h-12 w-full items-center justify-center gap-2 rounded-full bg-brass px-5 text-base font-medium text-brass-ink transition-opacity duration-200 hover:opacity-90 disabled:opacity-50",
        className,
      )}
    >
      {children}
    </button>
  );
}

function GhostButton({
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={cn(
        "flex h-12 w-full items-center justify-center gap-2 rounded-full border border-line bg-transparent px-4 text-sm font-medium text-fg transition-colors duration-200 hover:bg-surface-2 disabled:opacity-50",
        className,
      )}
    >
      {children}
    </button>
  );
}

function strengthLine(passphrase: string): string {
  if (!passphrase) return "Yahi passphrase baad mein tijori kholegi.";
  if (passphrase.length < 6) return "Kam se kam 6 akshar.";
  if (passphrase.length < 10) return "Chhota hai — lamba rakho to safer.";
  return "Mazboot lag raha hai.";
}
