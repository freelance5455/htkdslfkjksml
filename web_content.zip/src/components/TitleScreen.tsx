import React from 'react';
import { Play, Users, ShoppingBag, Map, Trophy, Settings, Wifi } from 'lucide-react';
import { CharacterItem, HoverboardItem } from '../types/game';

interface TitleScreenProps {
  onStartGame: () => void;
  onOpenCharacters: () => void;
  onOpenShop: () => void;
  onOpenLevels: () => void;
  onOpenMissions: () => void;
  onOpenLeaderboard: () => void;
  onOpenMultiplayer: () => void;
  onOpenSettings: () => void;
  coins: number;
  gems: number;
  highScore: number;
  selectedCharacter: CharacterItem;
  selectedBoard: HoverboardItem;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  onOpenCharacters,
  onOpenShop,
  onOpenLevels,
  onOpenMissions,
  onOpenLeaderboard,
  onOpenMultiplayer,
  onOpenSettings,
  coins,
  gems,
  highScore,
  selectedCharacter,
  selectedBoard
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 md:p-6 z-10 bg-gradient-to-t from-slate-950/90 via-transparent to-slate-950/70">
      {/* Top Header Bar: Currencies & High Score */}
      <div className="pointer-events-auto flex items-center justify-between gap-3">
        {/* Currencies cluster */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-slate-900/85 border border-amber-500/40 rounded-full px-3 py-1 shadow-md">
            <span className="text-amber-400 text-base">🪙</span>
            <span className="text-amber-300 font-bold tabular-nums text-sm md:text-base">
              {coins.toLocaleString('ar-EG')}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-900/85 border border-cyan-500/40 rounded-full px-3 py-1 shadow-md">
            <span className="text-cyan-400 text-base">💎</span>
            <span className="text-cyan-300 font-bold tabular-nums text-sm md:text-base">
              {gems.toLocaleString('ar-EG')}
            </span>
          </div>
        </div>

        {/* High Score & Settings */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-900/85 border border-yellow-500/30 rounded-xl px-3 py-1 text-center">
            <div className="text-[10px] text-yellow-400 font-bold">أعلى رقم قياسي 🏆</div>
            <div className="text-sm md:text-base font-extrabold text-white tabular-nums">
              {highScore.toLocaleString('ar-EG')}
            </div>
          </div>

          <button
            onClick={onOpenSettings}
            className="p-2.5 rounded-xl bg-slate-800/85 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95 transition-all shadow-md"
            title="الإعدادات وأذرع التحكم"
          >
            <Settings className="w-5 h-5 text-amber-400" />
          </button>
        </div>
      </div>

      {/* Middle Centerpiece: Title Lockup & Character Summary */}
      <div className="flex flex-col items-center justify-center text-center my-auto pointer-events-auto">
        {/* Bespoke Logo Lockup */}
        <div className="relative mb-3">
          <div className="inline-block bg-gradient-to-r from-red-600 via-amber-500 to-rose-600 text-transparent bg-clip-text text-4xl md:text-6xl font-black tracking-tight drop-shadow-lg">
            هربان من ماما 3D
          </div>
          <div className="text-amber-300 text-xs md:text-sm font-bold tracking-wide mt-1 flex items-center justify-center gap-1.5">
            <span>👟 أسرع لعبة ركض في شوارع المدينة</span>
            <span className="bg-red-600 text-white text-[10px] px-2 py-0.5 rounded-full font-black animate-bounce">
              احذر الشبشب!
            </span>
          </div>
        </div>

        {/* Selected Character & Gear Badge */}
        <div className="bg-slate-900/80 border border-slate-700/80 rounded-2xl px-4 py-2 mt-2 flex items-center gap-3 shadow-xl backdrop-blur-xs">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-lg shadow-inner">
            {selectedCharacter.gender === 'girl' ? '👧' : selectedCharacter.gender === 'special' ? '⚡' : '👦'}
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">الشخصية المختارة:</div>
            <div className="text-sm font-extrabold text-white">{selectedCharacter.arabicName}</div>
          </div>
          <div className="h-6 w-px bg-slate-700 mx-1" />
          <div className="text-right">
            <div className="text-xs text-slate-400">المركبة:</div>
            <div className="text-sm font-bold text-amber-400">{selectedBoard.name}</div>
          </div>
        </div>
      </div>

      {/* Bottom Dock: Big Start CTA & Navigation Pill Buttons */}
      <div className="pointer-events-auto flex flex-col items-center gap-3 max-w-xl mx-auto w-full">
        {/* Big Start Button */}
        <button
          onClick={onStartGame}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-400 hover:to-red-400 text-slate-950 font-black text-xl md:text-2xl shadow-2xl shadow-orange-500/40 border-2 border-yellow-300 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer"
        >
          <Play className="w-7 h-7 fill-slate-950" />
          <span>ابدأ الهروب السريع!</span>
        </button>

        {/* Action Pills Bar */}
        <div className="grid grid-cols-5 gap-2 w-full">
          <button
            onClick={onOpenCharacters}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-200 active:scale-95 transition-all"
          >
            <Users className="w-5 h-5 text-cyan-400 mb-0.5" />
            <span className="text-[11px] font-bold">54 بطلاً ووحشاً</span>
          </button>

          <button
            onClick={onOpenShop}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-200 active:scale-95 transition-all"
          >
            <ShoppingBag className="w-5 h-5 text-amber-400 mb-0.5" />
            <span className="text-[11px] font-bold">المتجر</span>
          </button>

          <button
            onClick={onOpenLevels}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-200 active:scale-95 transition-all"
          >
            <Map className="w-5 h-5 text-emerald-400 mb-0.5" />
            <span className="text-[11px] font-bold">المراحل</span>
          </button>

          <button
            onClick={onOpenMultiplayer}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-200 active:scale-95 transition-all"
          >
            <Wifi className="w-5 h-5 text-indigo-400 mb-0.5" />
            <span className="text-[11px] font-bold">سباق ثنائي</span>
          </button>

          <button
            onClick={onOpenLeaderboard}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-200 active:scale-95 transition-all"
          >
            <Trophy className="w-5 h-5 text-yellow-400 mb-0.5" />
            <span className="text-[11px] font-bold">الصدارة</span>
          </button>
        </div>

        {/* Single flat control hint line */}
        <div className="text-[11px] text-slate-400 font-medium text-center">
          سحب للتوجيه والقفز والزحلقة · نقر مزدوج للزلاجة · يدعم أجهزة التحكم (Gamepad)
        </div>
      </div>
    </div>
  );
};
