import React, { useState } from 'react';
import { HelpCircle, Users, Volume2, VolumeX, Bot, ArrowRight, Download } from 'lucide-react';
import type { AvatarId } from '../shared/unoTypes';
import { AVATAR_OPTIONS, PlayerAvatar } from './PlayerAvatar';

interface TitleScreenProps {
  initialRoomCode: string;
  initialName: string;
  initialAvatar: AvatarId;
  muted: boolean;
  connected: boolean;
  isStandaloneFile: boolean;
  errorMessage: string | null;
  onToggleMute: () => void;
  onOpenRules: () => void;
  onCreateRoom: (name: string, avatar: AvatarId) => void;
  onJoinRoom: (code: string, name: string, avatar: AvatarId) => void;
  onStartOfflineMabar: (name: string, avatar: AvatarId) => void;
  onPlaySolo: (name: string, avatar: AvatarId) => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  initialRoomCode,
  initialName,
  initialAvatar,
  muted,
  connected,
  isStandaloneFile,
  errorMessage,
  onToggleMute,
  onOpenRules,
  onCreateRoom,
  onJoinRoom,
  onStartOfflineMabar,
  onPlaySolo,
}) => {
  const [name, setName] = useState(initialName);
  const [avatar, setAvatar] = useState<AvatarId>(initialAvatar);
  const [roomCode, setRoomCode] = useState(initialRoomCode);

  const validName = name.trim() || 'Pemain';

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = roomCode.toUpperCase().trim();
    if (!cleaned) return;
    onJoinRoom(cleaned, validName, avatar);
  };

  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-stone-950 flex flex-col justify-between">
      {/* Key-Art Atmospheric Backdrop */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src="/src/assets/images/title_backdrop_cards_1795173543186.jpg"
          alt="Meja kartu Ari Uno"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-75"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-950/88 to-stone-950/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-transparent to-stone-950/50" />
      </div>

      {/* Top Utility Cluster */}
      <div className="relative z-10 flex items-center justify-between px-6 sm:px-10 pt-6">
        <div className="flex items-center gap-3">
          {/* Bespoke inline SVG double-card lockup */}
          <svg width="36" height="36" viewBox="0 0 36 36" aria-hidden="true">
            <rect
              x="4"
              y="6"
              width="18"
              height="24"
              rx="4"
              transform="rotate(-10 13 18)"
              fill="#DC2626"
              stroke="#FFFFFF"
              strokeWidth="1.5"
            />
            <rect
              x="14"
              y="6"
              width="18"
              height="24"
              rx="4"
              transform="rotate(8 23 18)"
              fill="#0F766E"
              stroke="#F5D0FE"
              strokeWidth="1.5"
            />
            <path
              d="M19 14.5a4.5 4.5 0 0 1 7.6-1.8M27.5 19.5a4.5 4.5 0 0 1-7.6 1.8"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
          <span className="font-display text-xl font-extrabold tracking-tight text-white">
            Ari Uno
          </span>
        </div>

        <div className="flex items-center gap-2">
          {!isStandaloneFile && (
            <a
              href="/api/download-html"
              download="ari-uno.html"
              className="h-10 px-3.5 rounded-lg bg-stone-900/75 hover:bg-stone-800 border border-white/15 text-stone-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-emerald-300" />
              <span className="hidden sm:inline">Unduh HTML</span>
            </a>
          )}
          <button
            type="button"
            onClick={onOpenRules}
            className="h-10 px-3.5 rounded-lg bg-stone-900/75 hover:bg-stone-800 border border-white/15 text-stone-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-amber-300" />
            <span>Cara Main</span>
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            className="w-10 h-10 rounded-lg bg-stone-900/75 hover:bg-stone-800 border border-white/15 text-stone-200 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={muted ? 'Nyalakan suara' : 'Bisukan suara'}
            title={muted ? 'Nyalakan suara' : 'Bisukan suara'}
          >
            {muted ? <VolumeX className="w-4 h-4 text-stone-400" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
          </button>
        </div>
      </div>

      {/* Main Left-Aligned Setup Panel over calm negative space */}
      <main className="relative z-10 flex-1 flex items-center px-6 sm:px-10 py-6">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-2">
            <p className="text-xs font-medium text-amber-300/90 tracking-wide">
              Edisi UNO Flip Dua Sisi · Mabar Online &amp; Offline
            </p>
            <h1 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white leading-[1.08] text-balance">
              Ari Uno
            </h1>
            <p className="text-sm sm:text-base text-stone-300 leading-relaxed max-w-sm">
              Balik meja dari Sisi Terang ke Sisi Gelap dengan kartu +5 dan Skip Semua. Bisa mabar online atau offline 1 perangkat!
            </p>
          </div>

          <div className="rounded-2xl bg-stone-900/90 border border-white/15 p-5 sm:p-6 shadow-2xl space-y-5">
            {errorMessage && (
              <div
                role="alert"
                className="rounded-lg bg-rose-950/90 border border-rose-500/40 px-3.5 py-2.5 text-xs sm:text-sm text-rose-200"
              >
                {errorMessage}
              </div>
            )}

            {/* Player Name + Avatar */}
            <div className="space-y-3">
              <label htmlFor="player-name" className="block text-xs font-semibold text-stone-300">
                Nama Pemain
              </label>
              <input
                id="player-name"
                type="text"
                maxLength={18}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Masukkan namamu..."
                className="w-full h-11 px-3.5 rounded-xl bg-stone-950 border border-white/15 text-white placeholder:text-stone-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
              />

              <div className="flex items-center justify-between gap-2 pt-1">
                {AVATAR_OPTIONS.map((opt) => {
                  const active = avatar === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setAvatar(opt.id)}
                      title={opt.label}
                      aria-label={`Pilih ikon ${opt.label}`}
                      className={`p-1 rounded-xl transition-transform duration-150 ${
                        active
                          ? 'ring-2 ring-amber-400 scale-105 bg-amber-400/10'
                          : 'opacity-65 hover:opacity-100'
                      }`}
                    >
                      <PlayerAvatar avatar={opt.id} size="sm" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Primary Actions */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                disabled={!connected}
                onClick={() => onCreateRoom(validName, avatar)}
                className="w-full h-11 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-stone-950 font-display font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-colors shadow-lg shadow-amber-500/10 cursor-pointer"
              >
                <Users className="w-5 h-5" />
                <span>Buat Room Mabar Online</span>
              </button>

              <form onSubmit={handleJoinSubmit} className="flex items-center gap-2">
                <input
                  type="text"
                  maxLength={6}
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  placeholder="KODE ROOM"
                  aria-label="Kode Room Mabar"
                  className="flex-1 h-11 px-3.5 rounded-xl bg-stone-950 border border-white/15 text-white font-mono-tabular uppercase tracking-widest text-sm placeholder:text-stone-500 placeholder:tracking-normal focus:outline-none focus:ring-2 focus:ring-emerald-400"
                />
                <button
                  type="submit"
                  disabled={!connected || roomCode.trim().length < 4}
                  className="h-11 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white font-semibold text-sm flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>Gabung</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              <div className="pt-2 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onStartOfflineMabar(validName, avatar)}
                  className="h-11 px-3.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-white/10 text-amber-200 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Users className="w-4 h-4 text-amber-300" />
                  <span>Mabar Offline</span>
                </button>
                <button
                  type="button"
                  onClick={() => onPlaySolo(validName, avatar)}
                  className="h-11 px-3.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-white/10 text-stone-100 font-medium text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Bot className="w-4 h-4 text-sky-300" />
                  <span>Solo vs Bot AI</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Single flat control-hint line */}
      <footer className="relative z-10 px-6 sm:px-10 pb-5">
        <p className="text-xs text-stone-400">
          Klik kartu untuk bermain · Tekan Space untuk ambil kartu · Tekan U untuk teriak UNO
        </p>
      </footer>
    </div>
  );
};
