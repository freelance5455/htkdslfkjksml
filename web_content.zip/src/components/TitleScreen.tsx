import React, { useEffect } from 'react';
import { GameMode, SaveData } from '../types/game';
import {
  Play,
  Clock,
  Infinity as InfinityIcon,
  Calendar,
  Grid,
  ShoppingBag,
  Award,
  Settings,
  HelpCircle,
  Coins,
  Star,
  Flame
} from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface TitleScreenProps {
  saveData: SaveData;
  onStartGame: (mode: GameMode, levelId?: number | string) => void;
  onOpenLevelSelect: () => void;
  onOpenShop: () => void;
  onOpenAchievements: () => void;
  onOpenDailyCalendar: () => void;
  onOpenHowToPlay: () => void;
  onOpenSettings: () => void;
  onOpenDownloadApk: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  saveData,
  onStartGame,
  onOpenLevelSelect,
  onOpenShop,
  onOpenAchievements,
  onOpenDailyCalendar,
  onOpenHowToPlay,
  onOpenSettings,
  onOpenDownloadApk
}) => {
  // Global Keyboard shortcuts: Space / Enter to play immediately
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        soundEngine.playNodeSelect(2);
        onStartGame('classic');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStartGame]);

  const todayStr = new Date().toISOString().split('T')[0];
  const isDailyCompletedToday = Boolean(saveData.dailyCompletions[todayStr]?.completed);

  return (
    <div className="relative w-full h-full flex flex-col justify-between items-center p-4 sm:p-8 overflow-hidden select-none">
      {/* Background Animated Neon Grid & Light Streams */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 50% 50%, rgba(56, 189, 248, 0.15) 1px, transparent 1px),
                              linear-gradient(to right, rgba(255, 45, 85, 0.05) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(0, 122, 255, 0.05) 1px, transparent 1px)`,
            backgroundSize: '40px 40px, 80px 80px, 80px 80px'
          }}
        />
      </div>

      {/* Top Bar: Player Stats (Coins, Stars, Daily Streak) & Quick Nav */}
      <div className="w-full max-w-4xl flex items-center justify-between z-10 gap-3">
        {/* Currencies & Badges */}
        <div className="flex items-center gap-2 sm:gap-3 bg-slate-900/80 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-slate-800 shadow-xl">
          {/* Coins */}
          <div className="flex items-center gap-1.5 text-amber-400 font-mono font-bold text-xs sm:text-sm">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="tabular-nums">{saveData.stats.totalCoins}</span>
          </div>

          <div className="w-px h-4 bg-slate-700/60" />

          {/* Stars */}
          <div className="flex items-center gap-1.5 text-yellow-300 font-mono font-bold text-xs sm:text-sm">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="tabular-nums">{saveData.stats.starsCollected}</span>
          </div>

          {/* Daily Streak */}
          {saveData.stats.dailyStreak > 0 && (
            <>
              <div className="w-px h-4 bg-slate-700/60" />
              <div className="flex items-center gap-1 text-orange-400 font-mono font-bold text-xs">
                <Flame className="w-3.5 h-3.5 fill-orange-500 text-orange-500" />
                <span className="tabular-nums">{saveData.stats.dailyStreak}d</span>
              </div>
            </>
          )}
        </div>

        {/* Action Icon Cluster */}
        <div className="flex items-center gap-2">
          {/* APK & ZIP Button */}
          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onOpenDownloadApk();
            }}
            title="Download ZIP & Android APK"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 transition-colors shadow-lg text-xs font-bold"
          >
            <span className="text-sm">📦</span>
            <span className="hidden sm:inline">APK &amp; ZIP</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onOpenShop();
            }}
            title="Themes & Skins Shop"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 transition-colors shadow-lg text-xs font-semibold"
          >
            <ShoppingBag className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Shop</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(1);
              onOpenAchievements();
            }}
            title="Achievements"
            className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-amber-300 border border-slate-800 transition-colors shadow-lg"
          >
            <Award className="w-4 h-4 text-amber-400" />
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onOpenHowToPlay();
            }}
            title="How To Play"
            className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-purple-300 border border-slate-800 transition-colors shadow-lg"
          >
            <HelpCircle className="w-4 h-4 text-purple-400" />
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(3);
              onOpenSettings();
            }}
            title="Settings"
            className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors shadow-lg"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Centerpiece: Bespoke Hero Title Lockup & Subtitle */}
      <div className="flex flex-col items-center text-center z-10 max-w-xl my-auto">
        {/* Bespoke Inline SVG Logo Lockup */}
        <div className="relative mb-3 group cursor-pointer" onClick={() => soundEngine.playNodeSelect(4)}>
          <svg
            className="w-64 sm:w-84 md:w-96 h-auto drop-shadow-[0_0_24px_rgba(6,182,212,0.6)]"
            viewBox="0 0 400 90"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="chromaGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ff2d55" />
                <stop offset="25%" stopColor="#ff9f0a" />
                <stop offset="50%" stopColor="#ffd60a" />
                <stop offset="75%" stopColor="#30d158" />
                <stop offset="100%" stopColor="#64d2ff" />
              </linearGradient>
              <linearGradient id="rushGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="50%" stopColor="#c084fc" />
                <stop offset="100%" stopColor="#bf5af2" />
              </linearGradient>
            </defs>

            {/* Glowing Accent Circuit Line */}
            <path
              d="M 20 75 H 140 L 160 55 H 240 L 260 75 H 380"
              stroke="url(#chromaGrad)"
              strokeWidth="3"
              strokeLinecap="round"
              opacity="0.8"
            />

            {/* Neon Title Text */}
            <text
              x="200"
              y="48"
              textAnchor="middle"
              className="font-extrabold tracking-tight font-sans"
              style={{
                fontFamily: 'Outfit, sans-serif',
                fontSize: '44px',
                fontWeight: 900,
                letterSpacing: '0.08em',
                fill: 'url(#chromaGrad)'
              }}
            >
              CHROMA
            </text>
            <text
              x="200"
              y="80"
              textAnchor="middle"
              className="font-black tracking-widest"
              style={{
                fontFamily: 'Outfit, sans-serif',
                fontSize: '24px',
                fontWeight: 900,
                letterSpacing: '0.35em',
                fill: 'url(#rushGrad)'
              }}
            >
              RUSH
            </text>
          </svg>
        </div>

        <p className="text-slate-400 text-xs sm:text-sm font-medium tracking-wide mb-6">
          Connect Colors · Create Combos · Beat Every Challenge
        </p>

        {/* Primary Start CTA Button */}
        <button
          onClick={() => {
            soundEngine.playNodeSelect(2);
            onStartGame('classic');
          }}
          className="group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 sm:px-10 sm:py-4 rounded-2xl bg-gradient-to-r from-rose-500 via-purple-600 to-cyan-500 text-white font-extrabold text-base sm:text-lg tracking-wide shadow-[0_0_30px_rgba(168,85,247,0.5)] hover:shadow-[0_0_40px_rgba(244,63,94,0.7)] hover:scale-105 active:scale-95 transition-all duration-200"
        >
          <Play className="w-5 h-5 fill-white" />
          <span>PLAY NOW</span>
        </button>

        {/* Control hint line */}
        <div className="mt-3 text-[11px] text-slate-500 font-mono">
          Press <span className="text-slate-300 font-bold">Space</span> or <span className="text-slate-300 font-bold">Enter</span> to Start
        </div>
      </div>

      {/* Game Modes Grid */}
      <div className="w-full max-w-4xl grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5 z-10 mt-4 mb-2">
        {/* Mode 1: Classic Levels */}
        <button
          onClick={() => {
            soundEngine.playNodeSelect(0);
            onOpenLevelSelect();
          }}
          className="flex flex-col items-start p-3 sm:p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-cyan-500/50 transition-all text-left group shadow-lg"
        >
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-2 group-hover:scale-110 transition-transform">
            <Grid className="w-4 h-4" />
          </div>
          <div className="text-xs sm:text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
            Classic Levels
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            5 Worlds · 100 Levels
          </div>
        </button>

        {/* Mode 2: Time Challenge */}
        <button
          onClick={() => {
            soundEngine.playNodeSelect(1);
            onStartGame('time_challenge');
          }}
          className="flex flex-col items-start p-3 sm:p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-rose-500/50 transition-all text-left group shadow-lg"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-2 group-hover:scale-110 transition-transform">
            <Clock className="w-4 h-4" />
          </div>
          <div className="text-xs sm:text-sm font-bold text-white group-hover:text-rose-300 transition-colors">
            Time Challenge
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Best: <span className="font-mono text-slate-300">{saveData.stats.timeChallengeHighScore}</span>
          </div>
        </button>

        {/* Mode 3: Endless Mode */}
        <button
          onClick={() => {
            soundEngine.playNodeSelect(2);
            onStartGame('endless');
          }}
          className="flex flex-col items-start p-3 sm:p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-purple-500/50 transition-all text-left group shadow-lg"
        >
          <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-2 group-hover:scale-110 transition-transform">
            <InfinityIcon className="w-4 h-4" />
          </div>
          <div className="text-xs sm:text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
            Endless Mode
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Best: <span className="font-mono text-slate-300">{saveData.stats.endlessHighScore} pts</span>
          </div>
        </button>

        {/* Mode 4: Daily Challenge */}
        <button
          onClick={() => {
            soundEngine.playNodeSelect(3);
            onOpenDailyCalendar();
          }}
          className="flex flex-col items-start p-3 sm:p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-500/50 transition-all text-left group shadow-lg relative overflow-hidden"
        >
          {isDailyCompletedToday && (
            <span className="absolute top-2 right-2 px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[9px] font-bold">
              DONE
            </span>
          )}
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-2 group-hover:scale-110 transition-transform">
            <Calendar className="w-4 h-4" />
          </div>
          <div className="text-xs sm:text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
            Daily Challenge
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Fresh Puzzle Daily
          </div>
        </button>
      </div>

      {/* Flat Control Hint Line */}
      <div className="z-10 text-[11px] text-slate-500 tracking-wider">
        Drag to Connect · Backtrack to Erase · Esc Pause
      </div>
    </div>
  );
};
