/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { soundManager } from '../audio/SoundManager';
import {
  Play,
  Flame,
  Volume2,
  VolumeX,
  HelpCircle,
  Sparkles,
  Gamepad2,
  X,
  Check,
} from 'lucide-react';

interface TitleScreenProps {
  onStartCampaign: () => void;
  onStartEndless: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartCampaign,
  onStartEndless,
}) => {
  const [showHelp, setShowHelp] = useState(false);
  const [muted, setMuted] = useState(soundManager.getMuted());

  const toggleSound = () => {
    const next = !muted;
    setMuted(next);
    soundManager.setMuted(next);
    if (!next) {
      soundManager.playPickup('WEAPON');
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-between p-6 sm:p-10 select-none bg-gradient-to-t from-black/85 via-black/30 to-black/70 pointer-events-auto">
      {/* Top Bar with Creator Badge and Audio Toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="px-4 py-1.5 rounded-full bg-red-950/70 border border-red-500/50 text-xs font-bold uppercase tracking-widest text-red-300 flex items-center gap-2 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
            <span>MADE BY REHANX</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowHelp(true)}
            className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 transition-colors"
            title="How to Play"
          >
            <HelpCircle className="w-5 h-5" />
          </button>
          <button
            onClick={toggleSound}
            className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-500 transition-colors"
            title="Toggle Audio"
          >
            {muted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* Center 30-40% Negative Space with Bespoke Inline SVG Title Lockup */}
      <div className="my-auto max-w-2xl">
        <div className="mb-2 text-xs sm:text-sm tracking-[0.3em] font-mono text-red-500 font-bold uppercase flex items-center gap-2">
          <span className="w-8 h-[2px] bg-red-500" />
          TACTICAL 3D SURVIVAL SHOOTER
        </div>

        {/* Bespoke Inline SVG Title Lockup */}
        <div className="w-full max-w-lg mb-4">
          <svg viewBox="0 0 540 100" className="w-full drop-shadow-[0_0_25px_rgba(239,68,68,0.6)]">
            <defs>
              <linearGradient id="titleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="55%" stopColor="#f87171" />
                <stop offset="100%" stopColor="#b91c1c" />
              </linearGradient>
            </defs>
            <text
              x="0"
              y="58"
              fontFamily="Impact, system-ui, sans-serif"
              fontSize="64"
              fontWeight="900"
              letterSpacing="2"
              fill="url(#titleGrad)"
            >
              DEADZONE
            </text>
            <text
              x="330"
              y="58"
              fontFamily="monospace"
              fontSize="48"
              fontWeight="900"
              letterSpacing="4"
              fill="#ef4444"
            >
              OUTBREAK
            </text>
            <line x1="0" y1="74" x2="520" y2="74" stroke="#ef4444" strokeWidth="3" strokeDasharray="18 6" />
          </svg>
        </div>

        <p className="text-sm sm:text-base text-slate-300 max-w-lg mb-8 leading-relaxed font-sans">
          The urban quarantine has failed. Navigate destroyed city blocks, fend off mutated infected swarms, collect the biochemical vaccine data, and reach the extraction helipad.
        </p>

        {/* Primary CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
          <button
            onClick={() => {
              soundManager.unlockAudio();
              onStartCampaign();
            }}
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-black text-base sm:text-lg tracking-wider uppercase shadow-[0_0_25px_rgba(239,68,68,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-white" />
            <span>MISSION: ESCAPE THE CITY</span>
          </button>

          <button
            onClick={() => {
              soundManager.unlockAudio();
              onStartEndless();
            }}
            className="px-6 py-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-amber-500/50 text-amber-300 font-bold text-sm sm:text-base tracking-wider uppercase active:scale-95 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
          >
            <Flame className="w-5 h-5 text-amber-400" />
            <span>ENDLESS HORDE MODE</span>
          </button>
        </div>
      </div>

      {/* Flat Single Control-Hint Line & Attribution */}
      <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 font-mono border-t border-slate-800/80 pt-4 gap-2">
        <div className="flex items-center gap-2 text-slate-300">
          <Gamepad2 className="w-4 h-4 text-cyan-400" />
          <span>WASD Move · Click Shoot · Right-Click Aim · Space Roll · R Reload · Esc Pause</span>
        </div>
        <div className="text-slate-400">
          DESIGNED & PROGRAMMED BY <span className="text-yellow-400 font-bold">REHANX</span>
        </div>
      </div>

      {/* Help / Controls Modal */}
      {showHelp && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 text-slate-200 font-sans shadow-2xl relative">
            <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-red-500" />
                SURVIVOR TACTICAL CONTROLS
              </h3>
              <button onClick={() => setShowHelp(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Movement / Strafe</span>
                <span className="font-mono text-cyan-400 font-semibold">WASD / Left Touch Joystick</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Aim & Look</span>
                <span className="font-mono text-cyan-400 font-semibold">Mouse Drag / Right Screen Drag</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Fire Weapon</span>
                <span className="font-mono text-cyan-400 font-semibold">Left Click / On-screen Shoot</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Tactical Roll (Invincible)</span>
                <span className="font-mono text-cyan-400 font-semibold">Spacebar / Roll Button</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Reload Chamber</span>
                <span className="font-mono text-cyan-400 font-semibold">Key [R] / Reload Button</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Switch Arsenal</span>
                <span className="font-mono text-cyan-400 font-semibold">[1, 2, 3] or [Q] / Swap Icon</span>
              </div>
            </div>

            <button
              onClick={() => setShowHelp(false)}
              className="mt-6 w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 font-bold text-white text-center flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>UNDERSTOOD</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
