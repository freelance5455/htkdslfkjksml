import React from 'react';
import { Flame, Shield, Zap, Sparkles, Crosshair, Volume2, VolumeX } from 'lucide-react';

interface TitleScreenProps {
  onStart: () => void;
  selectedPerk: 'speed' | 'ep' | 'gloo';
  onSelectPerk: (perk: 'speed' | 'ep' | 'gloo') => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  selectedPerk,
  onSelectPerk,
  isMuted,
  onToggleMute,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-between p-8 bg-slate-950/85 backdrop-blur-none text-white select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flame className="w-6 h-6 text-amber-500 fill-amber-500" />
          <span className="text-xs font-mono tracking-widest text-amber-400 font-bold uppercase">
            BERMUDA BATTLEGROUNDS • MINI BR
          </span>
        </div>
        <button
          onClick={onToggleMute}
          className="p-2 bg-slate-900 hover:bg-slate-800 text-amber-400 rounded-lg border border-amber-500/40 cursor-pointer transition-colors flex items-center gap-2 text-xs font-bold"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          <span>{isMuted ? 'UNMUTE' : 'SOUND ON'}</span>
        </button>
      </div>

      {/* Hero Centerpiece & Title Lockup */}
      <div className="flex flex-col items-center text-center my-auto max-w-2xl mx-auto">
        {/* Bespoke Inline SVG Title Lockup */}
        <div className="relative mb-4">
          <svg
            className="w-full max-w-[500px] h-24 filter drop-shadow-[0_10px_20px_rgba(245,158,11,0.5)]"
            viewBox="0 0 500 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="fireGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#f59e0b" />
                <stop offset="50%" stopColor="#ef4444" />
                <stop offset="100%" stopColor="#e11d48" />
              </linearGradient>
            </defs>
            <text
              x="50%"
              y="55%"
              dominantBaseline="middle"
              textAnchor="middle"
              fill="url(#fireGrad)"
              fontFamily="Impact, sans-serif"
              fontSize="68"
              fontWeight="900"
              letterSpacing="4"
              stroke="#0f172a"
              strokeWidth="4"
            >
              FREE FIRE MINI
            </text>
            <text
              x="50%"
              y="90%"
              dominantBaseline="middle"
              textAnchor="middle"
              fill="#fbbf24"
              fontFamily="sans-serif"
              fontSize="16"
              fontWeight="800"
              letterSpacing="8"
            >
              SURVIVAL BATTLE ROYALE
            </text>
          </svg>
        </div>

        {/* Urdu / Hindi / English Friendly Subtitle */}
        <p className="text-amber-200/90 text-sm md:text-base font-medium max-w-lg mb-8 leading-relaxed">
          Bhai Ready Ho? Island par drop karo, weapons loot karo, safe zone mein raho, Gloo Wall lagao aur <span className="text-amber-400 font-black">BOOYAH</span> jeeto!
        </p>

        {/* Character Perk Selector */}
        <div className="w-full mb-8">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">
            Select Battle Character Skill
          </div>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => onSelectPerk('speed')}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedPerk === 'speed'
                  ? 'bg-amber-950/80 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-sm mb-1">
                <Zap className="w-4 h-4" /> Kelly Speed
              </div>
              <div className="text-[11px] text-slate-300">
                +20% Sprint speed to outrun the blue zone
              </div>
            </button>

            <button
              onClick={() => onSelectPerk('ep')}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedPerk === 'ep'
                  ? 'bg-amber-950/80 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-sm mb-1">
                <Sparkles className="w-4 h-4" /> Alok Aura
              </div>
              <div className="text-[11px] text-slate-300">
                Continuous EP regeneration & auto-healing
              </div>
            </button>

            <button
              onClick={() => onSelectPerk('gloo')}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedPerk === 'gloo'
                  ? 'bg-amber-950/80 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-sm mb-1">
                <Shield className="w-4 h-4" /> Gloo Master
              </div>
              <div className="text-[11px] text-slate-300">
                Start with 5 Gloo Walls for instant cover
              </div>
            </button>
          </div>
        </div>

        {/* Primary Start CTA */}
        <button
          onClick={onStart}
          className="group relative px-10 py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-xl rounded-2xl tracking-wider uppercase shadow-[0_0_30px_rgba(245,158,11,0.6)] cursor-pointer transition-all transform hover:scale-105 active:scale-95"
        >
          <div className="flex items-center gap-3">
            <Crosshair className="w-6 h-6 animate-spin-slow" />
            <span>START BATTLE</span>
            <span className="text-xs bg-slate-950/30 text-white font-mono px-2 py-0.5 rounded">
              ENTER / CLICK
            </span>
          </div>
        </button>
      </div>

      {/* Flat Control Hints Footer */}
      <div className="flex items-center justify-center text-xs text-slate-400 font-mono tracking-wider border-t border-slate-800/80 pt-4">
        <span>WASD Move · Click Shoot · Right-Click Aim · Space Jump · G Gloo Wall · 1/2/3 Weapons · H Medkit</span>
      </div>
    </div>
  );
};
