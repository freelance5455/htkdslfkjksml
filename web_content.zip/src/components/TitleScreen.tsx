import React, { useEffect } from 'react';
import { GameSaveData } from '../game/types';
import { sound } from '../game/audio';
import { usePWAInstall } from '../game/usePWAInstall';

interface TitleScreenProps {
  saveData: GameSaveData;
  onStartGame: () => void;
  onResetSave: () => void;
  onOpenSettings: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  saveData,
  onStartGame,
  onResetSave,
  onOpenSettings,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        sound.play('ui_click');
        onStartGame();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStartGame]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between p-6 sm:p-12 select-none bg-stone-950 text-stone-100 overflow-hidden">
      {/* Ambient background styling */}
      <div className="absolute inset-0 bg-radial from-stone-900/60 via-stone-950/95 to-black pointer-events-none" />

      {/* Subtle background world grid pattern */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, rgba(245, 158, 11, 0.15) 0%, transparent 65%)',
        }}
      />

      {/* Top Bar / Guild Dispatch Banner */}
      <header className="relative z-10 flex items-center justify-between border-b border-stone-800 pb-4">
        <div className="flex items-center gap-3">
          <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
          <span className="text-xs tracking-widest uppercase text-stone-400 font-mono">
            OAKHAVEN GUILD DISPATCH · OPEN WORLD SIMULATION
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-stone-400">
          <span>RANK: HR {saveData.hunterRank}</span>
          <span>ZENNY: {saveData.zenny.toLocaleString()}z</span>
          <button
            onClick={() => {
              sound.play('ui_click');
              onOpenSettings();
            }}
            className="hover:text-amber-400 transition-colors cursor-pointer px-2 py-1 rounded border border-stone-800 hover:border-amber-500/40"
          >
            SETTINGS
          </button>
        </div>
      </header>

      {/* Hero Centerpiece / Bespoke Inline SVG Crest Lockup */}
      <main className="relative z-10 my-auto flex flex-col items-center text-center max-w-3xl mx-auto">
        {/* Dragon / Behemoth Crest Icon */}
        <div className="mb-4">
          <svg
            className="w-20 h-20 sm:w-28 sm:h-28 text-amber-500 drop-shadow-[0_0_25px_rgba(245,158,11,0.35)]"
            viewBox="0 0 100 100"
            fill="none"
            stroke="currentColor"
          >
            {/* Outer Dragon Crest Silhouette */}
            <path
              d="M50 6 L88 28 L88 72 L50 94 L12 72 L12 28 Z"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />
            {/* Inner Horns & Eye */}
            <path
              d="M30 42 C38 24 50 16 68 22 C60 30 52 42 50 56 C46 48 38 44 30 42 Z"
              fill="currentColor"
              fillOpacity="0.85"
            />
            <path
              d="M70 42 C62 24 50 16 32 22 C40 30 48 42 50 56 C54 48 62 44 70 42 Z"
              fill="currentColor"
              fillOpacity="0.85"
            />
            {/* Central Behemoth Core Star */}
            <circle cx="50" cy="56" r="5" fill="#ef4444" />
            <path
              d="M32 72 L50 84 L68 72"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Title Lockup */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-wider uppercase text-amber-500 drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)] font-serif">
          PROJECT BEHEMOTH
        </h1>
        <p className="mt-2 text-stone-400 text-sm sm:text-base tracking-widest uppercase font-mono max-w-xl">
          Open-World Monster Hunting Action RPG · 6 Weapon Classes · 12 Behemoth Species · Part-Breaking Combat
        </p>

          {/* Main CTA Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row items-center gap-3">
            <button
              data-start="true"
              onClick={() => {
                sound.play('ui_click');
                onStartGame();
              }}
              className="w-64 sm:w-72 py-3.5 px-8 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-base tracking-wider uppercase rounded shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer font-mono"
            >
              ENTER THE WILDERNESS [SPACE]
            </button>

            {isInstallable && !isInstalled && (
              <button
                onClick={install}
                className="py-3 px-5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/80 text-emerald-300 font-bold text-xs uppercase tracking-wider rounded cursor-pointer transition-colors"
              >
                📥 INSTALL TO ANDROID (APK / APP)
              </button>
            )}

            {saveData.completedQuestIds.length > 0 && (
              <button
                onClick={() => {
                  if (window.confirm('Reset all hunting progress and start a new game?')) {
                    onResetSave();
                  }
                }}
                className="py-3 px-4 text-xs text-stone-500 hover:text-red-400 font-mono tracking-wider uppercase transition-colors cursor-pointer"
              >
                Reset Data
              </button>
            )}
          </div>
      </main>

      {/* Flat Control Hints in Safe Footer Margin */}
      <footer className="relative z-10 border-t border-stone-800 pt-4 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 font-mono gap-2 text-center">
        <div>
          <span className="text-amber-500">PC:</span> WASD Move · Shift Run · Space Roll · J Attack · K Special · L Guard/Pouch · E Interact · Q Lock-On · Esc Pause
        </div>
        <div>
          <span className="text-amber-500">MOBILE:</span> Virtual Joystick + Multi-Touch Combat Buttons
        </div>
      </footer>
    </div>
  );
};
