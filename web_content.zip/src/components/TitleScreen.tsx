import React from 'react';
import { Language } from '../types/game';
import { MISSIONS_DATA } from '../data/missionsData';

interface TitleScreenProps {
  onStartGame: () => void;
  onSelectLevel: (level: number) => void;
  unlockedLevel: number;
  language: Language;
  onToggleLanguage: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  onSelectLevel,
  unlockedLevel,
  language,
  onToggleLanguage,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex flex-col justify-between p-6 bg-gradient-to-b from-slate-950/80 via-slate-900/60 to-slate-950/90 text-white select-none pointer-events-auto">
      {/* Top Header & Language */}
      <div className="flex items-center justify-between max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-amber-400 uppercase bg-black/40 px-3 py-1.5 rounded-full border border-amber-500/30">
          <span>🌟</span> 3D Indian Family Comedy Game
        </div>

        <button
          onClick={onToggleLanguage}
          className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400 text-amber-300 font-bold text-xs shadow-md transition-all active:scale-95"
        >
          {language === 'hinglish' ? '🇮🇳 Hinglish' : '🇬🇧 English'}
        </button>
      </div>

      {/* Main Title Centerpiece */}
      <div className="max-w-2xl mx-auto w-full text-center my-auto flex flex-col items-center">
        {/* Custom SVG Logo Title Lockup */}
        <div className="relative mb-2">
          <svg className="w-72 md:w-96 h-28 mx-auto" viewBox="0 0 400 120" fill="none">
            {/* Glow / Drop shadow behind */}
            <text
              x="200"
              y="55"
              textAnchor="middle"
              className="text-4xl md:text-5xl font-black fill-amber-950/60 stroke-amber-950 stroke-[8]"
              style={{ fontFamily: "'Baloo 2', cursive" }}
            >
              AYUSH
            </text>
            <text
              x="200"
              y="55"
              textAnchor="middle"
              className="text-4xl md:text-5xl font-black fill-amber-400"
              style={{ fontFamily: "'Baloo 2', cursive" }}
            >
              AYUSH
            </text>

            <text
              x="200"
              y="102"
              textAnchor="middle"
              className="text-2xl md:text-3xl font-extrabold fill-orange-950/80 stroke-orange-950 stroke-[6]"
              style={{ fontFamily: "'Baloo 2', cursive" }}
            >
              FAMILY ADVENTURE
            </text>
            <text
              x="200"
              y="102"
              textAnchor="middle"
              className="text-2xl md:text-3xl font-extrabold fill-orange-300"
              style={{ fontFamily: "'Baloo 2', cursive" }}
            >
              FAMILY ADVENTURE
            </text>
          </svg>
        </div>

        {/* Tagline */}
        <p className="text-sm md:text-base text-amber-100 max-w-lg mx-auto font-medium mb-6">
          {language === 'hinglish'
            ? 'Arav aur Akshhara ke funny jhagde suljhao, ghar ke secret items dhoondho aur parivar mein khushiyan laao!'
            : 'Settle hilarious sibling arguments, find hidden household items, and bring the family together!'}
        </p>

        {/* Primary Start CTA Button */}
        <button
          onClick={onStartGame}
          className="px-10 py-4 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-95 text-slate-950 font-black text-lg md:text-xl shadow-2xl border-2 border-white ring-4 ring-amber-400/40 transition-transform flex items-center gap-3 animate-pulse"
        >
          <span>🚀</span>
          <span>{language === 'hinglish' ? 'Khel Shuru Karein!' : 'Play Adventure!'}</span>
        </button>

        {/* Flat Control Hints */}
        <div className="mt-4 text-xs font-semibold text-slate-400 font-mono tracking-wider">
          WASD / Arrow Keys Move · Space Jump · E Interact · Shift Run
        </div>

        {/* Family Member Characters Preview Pills */}
        <div className="flex flex-wrap justify-center gap-2 mt-6">
          {[
            { name: 'Ayush', role: 'Hero', color: 'bg-sky-500/20 border-sky-400 text-sky-200' },
            { name: 'Arav', role: 'Brother', color: 'bg-orange-500/20 border-orange-400 text-orange-200' },
            { name: 'Akshhara', role: 'Sister', color: 'bg-pink-500/20 border-pink-400 text-pink-200' },
            { name: 'Mr. Ripin', role: 'Papa', color: 'bg-blue-500/20 border-blue-400 text-blue-200' },
            { name: 'Mrs. Anjeeta', role: 'Mummy', color: 'bg-amber-500/20 border-amber-400 text-amber-200' },
          ].map((c) => (
            <div
              key={c.name}
              className={`px-3 py-1 rounded-xl border text-[11px] font-bold ${c.color}`}
            >
              {c.name} <span className="opacity-70">({c.role})</span>
            </div>
          ))}
        </div>
      </div>

      {/* Level Selection Bar */}
      <div className="max-w-3xl mx-auto w-full bg-slate-950/80 border border-amber-500/30 rounded-2xl p-4 shadow-xl">
        <div className="text-xs font-bold text-amber-400 mb-2 uppercase tracking-wide flex items-center justify-between">
          <span>{language === 'hinglish' ? 'Mission Chuno:' : 'Select Mission:'}</span>
          <span className="text-[10px] text-slate-400">
            {unlockedLevel} / 5 {language === 'hinglish' ? 'Unlocked' : 'Unlocked'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {MISSIONS_DATA.map((m) => {
            const isUnlocked = m.id <= unlockedLevel;
            return (
              <button
                key={m.id}
                disabled={!isUnlocked}
                onClick={() => onSelectLevel(m.id)}
                className={`p-2 rounded-xl text-left border transition-all text-xs flex flex-col justify-between h-18 ${
                  isUnlocked
                    ? 'bg-amber-500/15 hover:bg-amber-500/30 border-amber-400/60 text-amber-100 active:scale-95'
                    : 'bg-slate-900/40 border-slate-800 text-slate-500 cursor-not-allowed opacity-50'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>Lvl {m.id}</span>
                  <span>{isUnlocked ? '🔓' : '🔒'}</span>
                </div>
                <div className="text-[10px] truncate leading-tight mt-1 opacity-90">
                  {m.title[language].split(':')[1] || m.title[language]}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
