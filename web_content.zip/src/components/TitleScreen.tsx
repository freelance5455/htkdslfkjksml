import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Play, Sparkles, Tv, Radio, ArrowRight } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface TitleScreenProps {
  onStartGame: (stationName: string, logoStyle: number, difficulty: 'normal' | 'desafiador') => void;
  savedGameAvailable: boolean;
  onContinueGame: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  savedGameAvailable,
  onContinueGame,
}) => {
  const [stationName, setStationName] = useState('Rede Brasilis');
  const [logoStyle, setLogoStyle] = useState(1);
  const [difficulty, setDifficulty] = useState<'normal' | 'desafiador'>('normal');
  const [isMuted, setIsMuted] = useState(soundFx.getMuted());
  const [showConfig, setShowConfig] = useState(false);

  const handleToggleSound = () => {
    const muted = soundFx.toggleMute();
    setIsMuted(muted);
    if (!muted) soundFx.playClick();
  };

  const handleStart = () => {
    soundFx.playVictory();
    onStartGame(stationName.trim() || 'Rede Brasilis', logoStyle, difficulty);
  };

  const logos = [
    { id: 1, label: 'Dourada', color: 'from-amber-400 via-yellow-500 to-amber-600' },
    { id: 2, label: 'Azul', color: 'from-blue-400 via-indigo-500 to-sky-600' },
    { id: 3, label: 'Rubi', color: 'from-rose-500 via-red-600 to-pink-600' },
    { id: 4, label: 'Esmeralda', color: 'from-emerald-400 via-teal-500 to-green-600' },
  ];

  return (
    <div className="relative w-full h-full min-h-screen overflow-y-auto bg-slate-950 flex flex-col justify-between p-4 pb-8 select-none">
      {/* Background with measured contrast */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <img
          src="/src/assets/images/tv_studio_control_room_1794275027661.jpg"
          alt="TV Master Control Room"
          className="w-full h-full object-cover opacity-25 filter brightness-70"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/85 to-slate-950/60" />
      </div>

      {/* Top Mobile Bar */}
      <div className="relative z-10 flex items-center justify-between w-full pt-1">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-red-600/30 border border-red-500/50 flex items-center justify-center text-red-400 animate-pulse">
            <Radio className="w-3.5 h-3.5" />
          </div>
          <span className="text-[11px] font-mono font-bold text-red-400 tracking-wider">
            SINAL AO VIVO
          </span>
        </div>

        <button
          onClick={handleToggleSound}
          className="min-h-[40px] px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-700/60 text-slate-300 active:scale-95 transition-all text-xs font-medium flex items-center gap-1.5"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          <span className="text-[10px] font-mono">{isMuted ? 'MUDO' : 'SOM'}</span>
        </button>
      </div>

      {/* Center Hero Lockup (Mobile Ergonomics) */}
      <div className="relative z-10 w-full max-w-sm mx-auto text-center flex flex-col items-center my-auto py-4">
        {/* TV Icon */}
        <div className="relative mb-3">
          <svg className="w-20 h-20 mx-auto drop-shadow-[0_0_20px_rgba(245,158,11,0.35)]" viewBox="0 0 100 100" fill="none">
            <rect x="8" y="14" width="84" height="68" rx="14" fill="#090d16" stroke="#f59e0b" strokeWidth="3" />
            <rect x="14" y="20" width="72" height="56" rx="8" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
            <path d="M 50 14 L 30 2 M 50 14 L 70 2" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="30" cy="2" r="2.5" fill="#f59e0b" />
            <circle cx="70" cy="2" r="2.5" fill="#f59e0b" />
            <rect x="18" y="24" width="9" height="34" fill="#e11d48" />
            <rect x="27" y="24" width="9" height="34" fill="#2563eb" />
            <rect x="36" y="24" width="9" height="34" fill="#10b981" />
            <rect x="45" y="24" width="9" height="34" fill="#f59e0b" />
            <rect x="54" y="24" width="9" height="34" fill="#06b6d4" />
            <rect x="63" y="24" width="9" height="34" fill="#ec4899" />
            <rect x="72" y="24" width="10" height="34" fill="#ffffff" />
            <rect x="18" y="58" width="64" height="14" fill="#020617" />
            <path d="M 22 65 Q 32 59 42 65 T 62 65 T 78 65" stroke="#38bdf8" strokeWidth="2" fill="none" />
          </svg>
          <div className="absolute -top-1 -right-2 px-1.5 py-0.2 rounded bg-red-600 text-white font-mono text-[9px] font-bold tracking-widest uppercase shadow animate-pulse">
            NO AR
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-white uppercase font-display">
          Rede Brasilis
        </h1>
        <p className="text-xs font-bold tracking-widest text-amber-400 uppercase mt-0.5">
          Magnata da Emissora de TV
        </p>

        <p className="text-slate-300 text-xs mt-3 leading-relaxed px-2">
          Comande sua própria rede de televisão pelo celular. Produza novelas, dispute o IBOPE ao vivo e monte a grade ideal!
        </p>

        {/* Buttons (Natural Reach Thumb Zone) */}
        {!showConfig ? (
          <div className="w-full flex flex-col gap-2.5 mt-6 px-2">
            {savedGameAvailable && (
              <button
                onClick={() => {
                  soundFx.playClick();
                  onContinueGame();
                }}
                className="w-full h-12 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-950/50 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
              >
                <Tv className="w-4 h-4" />
                <span>Continuar Minha Emissora</span>
              </button>
            )}

            <button
              onClick={() => {
                soundFx.playClick();
                setShowConfig(true);
              }}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-950/50 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>{savedGameAvailable ? 'Fundar Nova Emissora' : 'Iniciar Transmissão'}</span>
            </button>
          </div>
        ) : (
          <div className="w-full mt-4 p-4 rounded-2xl bg-slate-900/95 border border-slate-700 shadow-2xl text-left">
            <h2 className="text-xs font-bold text-white mb-3 flex items-center gap-1.5 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Configurar Sua Rede
            </h2>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Nome da Emissora
                </label>
                <input
                  type="text"
                  value={stationName}
                  onChange={(e) => setStationName(e.target.value)}
                  maxLength={24}
                  className="w-full h-10 px-3 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Cor da Marca
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {logos.map((l) => (
                    <button
                      key={l.id}
                      type="button"
                      onClick={() => {
                        soundFx.playClick();
                        setLogoStyle(l.id);
                      }}
                      className={`h-9 rounded-lg border flex items-center justify-center transition-all ${
                        logoStyle === l.id
                          ? 'border-amber-400 bg-amber-500/20'
                          : 'border-slate-800 bg-slate-950'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-gradient-to-tr ${l.color}`} />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Dificuldade
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      soundFx.playClick();
                      setDifficulty('normal');
                    }}
                    className={`p-2 rounded-lg border text-left transition-all ${
                      difficulty === 'normal'
                        ? 'border-amber-400 bg-amber-500/15 text-white'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-bold text-white">Normal</div>
                    <div className="text-[10px] text-slate-400">R$ 50.000 caixa</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      soundFx.playClick();
                      setDifficulty('desafiador');
                    }}
                    className={`p-2 rounded-lg border text-left transition-all ${
                      difficulty === 'desafiador'
                        ? 'border-amber-400 bg-amber-500/15 text-white'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-bold text-white">Desafiador</div>
                    <div className="text-[10px] text-slate-400">R$ 25.000 caixa</div>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowConfig(false)}
                className="h-10 px-3 text-xs text-slate-400 active:text-white"
              >
                Voltar
              </button>
              <button
                type="button"
                onClick={handleStart}
                className="h-10 px-4 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-1 active:scale-95"
              >
                <span>Entrar no Ar</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Mobile Marker */}
      <div className="relative z-10 text-center text-[10px] font-mono text-slate-500">
        Simulador de TV Mobile · Versão Toque
      </div>
    </div>
  );
};
