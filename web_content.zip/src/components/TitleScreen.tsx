import React, { useState, useEffect } from 'react';
import { Plane, Compass, Globe2, ArrowRight, Dices, Check, UserCheck, LogOut } from 'lucide-react';
import { sound } from '../game/sound';

interface TitleScreenProps {
  airlineName: string;
  onSetAirlineName: (name: string) => void;
  userId: string | null;
  userEmail: string | null;
  userAvatar: string | null;
  onGoogleSignIn: () => void;
  onGoogleSignOut: () => void;
  onStart: () => void;
}

const SAMPLE_AIRLINE_NAMES = [
  'Pacific Horizon Airways',
  'AeroVanguard Global',
  'Starlight Intercontinental',
  'Zephyr World Lines',
  'Atlas Transoceanic',
  'Silver Wing Express',
  'Apex International Air',
  'Oceanic Skyways',
  'Polaris Continental'
];

export const TitleScreen: React.FC<TitleScreenProps> = ({
  airlineName,
  onSetAirlineName,
  userId,
  userEmail,
  userAvatar,
  onGoogleSignIn,
  onGoogleSignOut,
  onStart
}) => {
  const [nameInput, setNameInput] = useState(airlineName || 'Pacific Horizon Airways');

  useEffect(() => {
    if (airlineName) {
      setNameInput(airlineName);
    }
  }, [airlineName]);

  const handleRandomize = () => {
    const random = SAMPLE_AIRLINE_NAMES[Math.floor(Math.random() * SAMPLE_AIRLINE_NAMES.length)];
    setNameInput(random);
    onSetAirlineName(random);
    sound.playClick();
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNameInput(e.target.value);
    onSetAirlineName(e.target.value);
  };

  const handleLaunch = () => {
    const finalName = nameInput.trim() || 'Pacific Horizon Airways';
    onSetAirlineName(finalName);
    sound.playUnlockCity();
    onStart();
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't auto-launch if typing into the input
      if (document.activeElement?.tagName === 'INPUT') return;

      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleLaunch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nameInput, onStart]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#07080b] text-white p-6 select-none overflow-y-auto"
      data-testid="title-screen"
    >
      {/* Subtle Radar Screen Grid Lines */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50%" cy="50%" r="200" fill="none" stroke="#ffffff" strokeWidth="1" strokeDasharray="4 6" />
          <circle cx="50%" cy="50%" r="350" fill="none" stroke="#ffffff" strokeWidth="1" strokeDasharray="6 8" />
          <circle cx="50%" cy="50%" r="500" fill="none" stroke="#ffffff" strokeWidth="1" strokeDasharray="8 12" />
          <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#ffffff" strokeWidth="0.8" strokeDasharray="5 5" />
          <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#ffffff" strokeWidth="0.8" strokeDasharray="5 5" />
        </svg>
      </div>

      <div className="relative z-10 max-w-xl w-full flex flex-col items-center text-center my-auto py-8">
        {/* Aviation Insignia */}
        <div className="w-16 h-16 rounded-2xl bg-white text-black flex items-center justify-center shadow-2xl mb-4">
          <svg
            className="w-10 h-10"
            viewBox="0 0 24 24"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
          </svg>
        </div>

        {/* Title Lockup (AEROIDLE completely removed per user request) */}
        <h1 className="text-3xl sm:text-4xl font-mono font-bold tracking-tight text-white mb-2 uppercase">
          GLOBAL FLIGHT TYCOON
        </h1>
        <div className="text-xs font-mono tracking-widest text-[#a1a1aa] uppercase mb-6">
          Real-Time World Map & Fleet Operations
        </div>

        {/* Airline Name Customizer & Google Auth Setup Card */}
        <div className="bg-[#101117] border border-[#27272a] rounded-xl p-5 mb-6 text-left space-y-4 w-full">
          <div>
            <label className="block text-xs font-mono text-[#a1a1aa] uppercase font-semibold mb-1.5">
              Set Your Airline Name
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={nameInput}
                onChange={handleNameChange}
                maxLength={36}
                placeholder="Enter your airline name..."
                className="flex-1 bg-[#161722] border border-[#3f3f46] focus:border-white rounded-lg px-3.5 py-2 text-sm font-mono text-white placeholder-[#71717a] focus:outline-none transition-colors"
              />
              <button
                type="button"
                onClick={handleRandomize}
                title="Generate Random Name"
                className="px-3 py-2 bg-[#20212f] hover:bg-[#2b2d3f] border border-[#3f3f46] text-white rounded-lg transition-colors flex items-center gap-1.5 text-xs font-mono cursor-pointer"
              >
                <Dices size={15} />
                <span className="hidden sm:inline">Random</span>
              </button>
            </div>
          </div>

          {/* Google Sign-in Auth Bar */}
          <div className="pt-2 border-t border-[#23242e] flex items-center justify-between">
            {userId ? (
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2.5">
                  {userAvatar ? (
                    <img
                      src={userAvatar}
                      alt="Avatar"
                      className="w-7 h-7 rounded-full border border-white/20"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-white text-black font-bold flex items-center justify-center text-xs">
                      {(userEmail || 'P')[0].toUpperCase()}
                    </div>
                  )}
                  <div className="text-left font-mono">
                    <span className="text-xs font-bold text-white block">
                      {userEmail || 'Google Pilot'}
                    </span>
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <Check size={10} /> Cloud Sync Active
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onGoogleSignOut}
                  className="text-xs font-mono text-[#a1a1aa] hover:text-white flex items-center gap-1 py-1 px-2.5 rounded bg-[#181924] border border-[#27272a] hover:bg-[#222434] cursor-pointer"
                >
                  <LogOut size={12} />
                  <span>Sign out</span>
                </button>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between w-full gap-2 font-mono">
                <div>
                  <span className="text-xs text-white font-semibold block">
                    Save Progress Across Devices
                  </span>
                  <span className="text-[11px] text-[#71717a]">
                    Optional Google Authentication
                  </span>
                </div>
                <button
                  type="button"
                  onClick={onGoogleSignIn}
                  className="px-3.5 py-1.5 bg-white text-black hover:bg-[#e4e4e7] rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Login with Google</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Tactical Mission Briefing */}
        <div className="bg-[#101117] border border-[#27272a] rounded-xl p-5 mb-8 text-left space-y-3 w-full">
          <div className="flex items-center gap-2 text-xs font-mono text-white font-semibold pb-2 border-b border-[#27272a]">
            <Compass size={14} className="text-white" />
            <span>OPERATIONAL BRIEFING</span>
          </div>

          <p className="text-xs text-[#d4d4d8] leading-relaxed">
            Take command of <strong className="text-white">{nameInput || 'your airline'}</strong> starting in the <strong className="text-white">United States</strong> with your first two unlocked hub airports: <strong className="text-white">San Francisco (SFO)</strong> and <strong className="text-white">Los Angeles (LAX)</strong>.
          </p>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-[#a1a1aa] pt-1">
            <div className="p-2 bg-[#161720] rounded border border-[#23242e]">
              <span className="text-white block font-semibold mb-0.5">1. Set Routes</span>
              Planes cruise between unlocked cities on straight flight corridors.
            </div>
            <div className="p-2 bg-[#161720] rounded border border-[#23242e]">
              <span className="text-white block font-semibold mb-0.5">2. Earn Revenue</span>
              Collect fares upon arrival minus real aviation fuel burn costs.
            </div>
            <div className="p-2 bg-[#161720] rounded border border-[#23242e]">
              <span className="text-white block font-semibold mb-0.5">3. Upgrades & Fleet</span>
              Boost Speed, Money Maker yields, and commission +1 Planes.
            </div>
            <div className="p-2 bg-[#161720] rounded border border-[#23242e]">
              <span className="text-white block font-semibold mb-0.5">4. Unlock Global Map</span>
              Expand city-by-city across 56 airports spanning all 7 continents.
            </div>
          </div>
        </div>

        {/* Primary Start CTA Button */}
        <button
          onClick={handleLaunch}
          data-start="true"
          className="w-full sm:w-auto px-8 py-3.5 bg-white text-black hover:bg-[#e4e4e7] font-mono font-bold text-sm rounded-xl shadow-xl transition-all flex items-center justify-center gap-3 cursor-pointer group"
        >
          <span>START FLIGHT OPERATIONS</span>
          <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Control Hints */}
        <div className="mt-6 text-[11px] font-mono text-[#71717a]">
          <span>Drag Map to Pan</span>
          <span className="mx-2">·</span>
          <span>Scroll to Zoom</span>
          <span className="mx-2">·</span>
          <span>Click Cities to Open Hubs</span>
        </div>
      </div>
    </div>
  );
};
