import React, { useEffect } from 'react';
import { Play, RotateCcw } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface TitleScreenProps {
  hasSavedProgress: boolean;
  onStart: (continueSave: boolean) => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({ hasSavedProgress, onStart }) => {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        onStart(true);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onStart]);

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-between p-6 md:p-12 pointer-events-none bg-gradient-to-r from-black/80 via-black/35 to-transparent">
      {/* Top Studio Mark */}
      <div className="flex items-center justify-between">
        <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded bg-slate-950/90 border border-amber-400/40">
          <span className="text-xs font-black tracking-[0.26em] text-amber-400 uppercase">
            AQ GAMES
          </span>
          <span className="text-xs text-slate-400">|</span>
          <span className="text-xs font-semibold tracking-wider text-slate-200">
            OPEN WORLD KARACHI EDITION
          </span>
        </div>
      </div>

      {/* Left-aligned GTA 6-inspired Title Lockup with generous calm negative space over live 3D city */}
      <div className="max-w-xl my-auto pointer-events-auto">
        <svg
          viewBox="0 0 540 165"
          className="w-full max-w-[460px] h-auto drop-shadow-[0_8px_24px_rgba(0,0,0,0.9)] mb-4"
          aria-label="GKC 1 Grand Karachi City 1"
        >
          <defs>
            <linearGradient id="gkcGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fde047" />
              <stop offset="48%" stopColor="#fb7185" />
              <stop offset="100%" stopColor="#38bdf8" />
            </linearGradient>
          </defs>
          <text
            x="2"
            y="84"
            fill="url(#gkcGrad)"
            fontFamily="system-ui, -apple-system, sans-serif"
            fontWeight="900"
            fontSize="86"
            letterSpacing="-3"
          >
            GKC 1
          </text>
          <rect x="4" y="100" width="490" height="4" rx="2" fill="#f59e0b" />
          <text
            x="4"
            y="140"
            fill="#f8fafc"
            fontFamily="system-ui, -apple-system, sans-serif"
            fontWeight="800"
            fontSize="30"
            letterSpacing="4.5"
          >
            GRAND KARACHI CITY 1
          </text>
        </svg>

        <p className="text-sm md:text-base text-slate-200/95 max-w-md mb-7 leading-relaxed">
          Explore 12 connected Karachi districts from Clifton Sea View and Mazar-e-Quaid to
          Shahrah-e-Faisal, Burns Road, Saddar, and Karachi Port.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => onStart(true)}
            className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-lg bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black text-base tracking-wide shadow-lg cursor-pointer transition-transform"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            {hasSavedProgress ? 'CONTINUE KARACHI' : 'ENTER KARACHI'}
          </button>

          {hasSavedProgress && (
            <button
              type="button"
              onClick={() => onStart(false)}
              className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-100 font-bold text-sm tracking-wide cursor-pointer transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              NEW GAME
            </button>
          )}

          <PWAInstallButton />
        </div>
      </div>

      {/* Single flat control hint line */}
      <div className="text-xs font-medium tracking-wider text-slate-300/90 uppercase">
        WASD / Joystick Move · Space Jump · F Enter/Exit Vehicle · E Shop/Interact · P Phone · C Camera · Esc Pause
      </div>
    </div>
  );
};
