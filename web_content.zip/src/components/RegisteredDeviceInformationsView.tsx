import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Search,
  Filter,
  Download,
  Copy,
  Check,
  RefreshCw,
  Cpu,
  HardDrive,
  Activity,
  Terminal,
  Lock,
  X,
  ExternalLink,
  Laptop,
  CheckCircle2,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { deviceRegistryEngine, RegisteredDeviceRecord } from '../lib/deviceRegistryEngine';
import { DeviceScanAnimation } from './DeviceScanAnimation';
import { DeviceHardwareHealthDashboard } from './DeviceHardwareHealthDashboard';

export const RegisteredDeviceInformationsView: React.FC = () => {
  const [devices, setDevices] = useState<RegisteredDeviceRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterManufacturer, setFilterManufacturer] = useState<string>('ALL');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<RegisteredDeviceRecord | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showLiveScanner, setShowLiveScanner] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'ledger' | 'health_dashboard'>('ledger');

  const handleRemoteSecureWipe = (device: RegisteredDeviceRecord) => {
    const confirmWipe = window.confirm(
      `⚠️ CRITICAL SECURITY COMMAND:\n\nAre you sure you want to trigger a Remote Secure Wipe (factory-reset level data purge) for device ${device.deviceName} (${device.serialNumber}) via the decentralized network heartbeat protocol?\n\nThis will purge all local data, wallet keys, and mined JMC on that specific device immediately.`
    );
    if (!confirmWipe) return;

    deviceRegistryEngine.revokeDeviceApproval(device.deviceId, 'Remote Secure Wipe Triggered via Heartbeat Protocol');
    setNotice(`🔥 Remote Secure Wipe command broadcasted to node ${device.deviceName} (${device.imei}). Device data purged & access revoked.`);
    setTimeout(() => setNotice(null), 6000);
  };

  const loadDevices = () => {
    setDevices(deviceRegistryEngine.getAllRegisteredDevices());
  };

  useEffect(() => {
    loadDevices();
    const unsubscribe = deviceRegistryEngine.subscribe(() => {
      loadDevices();
    });
    return () => unsubscribe();
  }, []);

  const handleCopy = (text: string, fieldId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleToggleRevoke = (device: RegisteredDeviceRecord) => {
    if (device.approvalStatus === 'APPROVED') {
      deviceRegistryEngine.revokeDeviceApproval(device.deviceId, 'Revoked by Prophet JUHNKRIX SYNVAGORD');
      setNotice(`⚠️ Device ${device.deviceName} (${device.serialNumber}) approval REVOKED.`);
    } else {
      deviceRegistryEngine.approveDevice(device.deviceId);
      setNotice(`✓ Device ${device.deviceName} (${device.serialNumber}) RE-APPROVED.`);
    }
    setTimeout(() => setNotice(null), 4000);
  };

  const exportRegistry = (format: 'json' | 'csv') => {
    if (format === 'json') {
      const blob = new Blob([JSON.stringify(devices, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JUHNKRIX_REGISTERED_DEVICES_50M_NETWORK_${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      const headers = 'DeviceID,DeviceName,Manufacturer,Model,SerialNumber,ProductKey,IMEI,OSVersion,FullName,Email,Phone,ScreenResolution,RAM,CPU,ApprovalStatus,ApprovalDate,NodeIP\n';
      const rows = devices.map(d =>
        `"${d.deviceId}","${d.deviceName}","${d.manufacturer}","${d.model}","${d.serialNumber}","${d.productKey}","${d.imei}","${d.osVersion}","${d.registeredUser.fullName}","${d.registeredUser.email}","${d.registeredUser.phoneNumber || ''}","${d.screenResolution}","${d.deviceMemoryGb} GB","${d.hardwareConcurrency} Cores","${d.approvalStatus}","${d.approvalTimestamp}","${d.decentralizedNodeIp}"`
      ).join('\n');
      const blob = new Blob([headers + rows], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JUHNKRIX_REGISTERED_DEVICES_50M_NETWORK_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
    setNotice(`✓ Registered Device Registry exported (${format.toUpperCase()}).`);
    setTimeout(() => setNotice(null), 3000);
  };

  const filteredDevices = devices.filter(d => {
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !query ||
      d.deviceName.toLowerCase().includes(query) ||
      d.serialNumber.toLowerCase().includes(query) ||
      d.productKey.toLowerCase().includes(query) ||
      d.imei.toLowerCase().includes(query) ||
      d.model.toLowerCase().includes(query) ||
      d.manufacturer.toLowerCase().includes(query) ||
      d.registeredUser.fullName.toLowerCase().includes(query) ||
      d.registeredUser.email.toLowerCase().includes(query);

    const matchesStatus = filterStatus === 'ALL' || d.approvalStatus === filterStatus;
    const matchesMfg = filterManufacturer === 'ALL' || d.manufacturer.toLowerCase().includes(filterManufacturer.toLowerCase());

    return matchesQuery && matchesStatus && matchesMfg;
  });

  const approvedCount = devices.filter(d => d.approvalStatus === 'APPROVED').length;
  const revokedCount = devices.filter(d => d.approvalStatus === 'REVOKED').length;

  return (
    <div className="space-y-6 text-slate-100 font-sans">
      {/* Top Banner: Sovereign Confidential Security Notice */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950 via-slate-950 to-amber-950 border-2 border-amber-500/50 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400 shadow-xl shadow-amber-500/20">
              <Smartphone className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  PROPHET SOVEREIGN RESTRICTED ACCESS
                </span>
                <span className="text-xs text-emerald-400 font-mono font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  50,000,000 Decentralized Devices Mesh
                </span>
              </div>
              <h2 className="text-xl font-black text-white tracking-tight mt-0.5">
                REGISTERED DEVICE INFORMATIONS
              </h2>
              <p className="text-xs text-slate-300 font-mono">
                Tightly hidden from ordinary users • Accessible exclusively to Prophet JUHNKRIX SYNVAGORD (juhnkrix.musika@gmail.com)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => exportRegistry('csv')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold cursor-pointer transition-all shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => exportRegistry('json')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold cursor-pointer transition-all shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={() => setShowLiveScanner(!showLiveScanner)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-mono font-bold cursor-pointer transition-all shadow-md ${
                showLiveScanner
                  ? 'bg-emerald-500 text-slate-950 border border-emerald-300 shadow-emerald-500/20'
                  : 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>{showLiveScanner ? 'Hide Scan Visualizer' : 'Device Scan Animation'}</span>
            </button>
            <button
              onClick={() => setViewMode(viewMode === 'ledger' ? 'health_dashboard' : 'ledger')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-mono font-bold cursor-pointer transition-all shadow-md ${
                viewMode === 'health_dashboard'
                  ? 'bg-amber-500 text-slate-950 border border-amber-300 shadow-amber-500/20'
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>{viewMode === 'ledger' ? 'Hardware Health Dashboard' : 'Registered Devices Ledger'}</span>
            </button>
            <button
              onClick={loadDevices}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer border border-slate-700"
              title="Refresh Device Registry"
            >
              <RefreshCw className="w-4 h-4 text-amber-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Device Scan Animation Visualizer for Registered Device Information inspection process */}
      {showLiveScanner && (
        <div className="animate-fadeIn">
          <DeviceScanAnimation
            title="Registered Device Information - Real-Time Inspection Visualizer"
            subtitle="Prophet JUHNKRIX SYNVAGORD Sovereign Hardware Telemetry & Merkle Check"
          />
        </div>
      )}

      {notice && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 rounded-2xl bg-amber-950/80 border border-amber-500/40 text-xs font-mono text-amber-200 flex items-center justify-between gap-3 shadow-md"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{notice}</span>
          </div>
          <button onClick={() => setNotice(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Total Registered Devices</span>
            <Smartphone className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono">{devices.length}</div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Decentralized Self-Custodial Nodes
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Approved Devices</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">{approvedCount}</div>
          <div className="text-[11px] text-emerald-300 font-mono mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Active Mesh Authorized
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Network Capacity</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-cyan-300 font-mono">50,000,000</div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Zero Web Hosting / P2P Swarm
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-rose-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Revoked / Blocked</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 font-mono">{revokedCount}</div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Fraud / Tamper Guard Active
          </div>
        </div>
      </div>

      {viewMode === 'health_dashboard' ? (
        <DeviceHardwareHealthDashboard />
      ) : (
        /* Main Devices Table & Search Toolbar */
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        {/* Controls Toolbar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              Decentralized Hardware Technical Specifications Log
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Serial Numbers, Product Keys, Manufacturers, IMEIs, Models, and OS Versions
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Serial, IMEI, Model, User..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none"
              />
            </div>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="APPROVED">Approved</option>
              <option value="REVOKED">Revoked</option>
            </select>

            <select
              value={filterManufacturer}
              onChange={(e) => setFilterManufacturer(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
            >
              <option value="ALL">All Manufacturers</option>
              <option value="Samsung">Samsung</option>
              <option value="Apple">Apple</option>
              <option value="Google">Google</option>
              <option value="Microsoft">Microsoft / PC</option>
              <option value="Prophet">Prophet Sovereign</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/40">
                <th className="py-3 px-3">Approval</th>
                <th className="py-3 px-3">Device Name & Manufacturer</th>
                <th className="py-3 px-3">Model & OS</th>
                <th className="py-3 px-3">Serial Number</th>
                <th className="py-3 px-3">Product Key</th>
                <th className="py-3 px-3">IMEI Identifier</th>
                <th className="py-3 px-3">Registered User</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredDevices.length > 0 ? (
                filteredDevices.map((device) => (
                  <tr key={device.deviceId} className="hover:bg-slate-800/40 transition-colors">
                    {/* Status */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                          device.approvalStatus === 'APPROVED'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        }`}
                      >
                        {device.approvalStatus === 'APPROVED' ? <Check className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                        {device.approvalStatus}
                      </span>
                    </td>

                    {/* Device Name & Manufacturer */}
                    <td className="py-3 px-3">
                      <div className="text-white font-bold">{device.deviceName}</div>
                      <span className="text-[10px] text-amber-300/90">{device.manufacturer}</span>
                    </td>

                    {/* Model & OS */}
                    <td className="py-3 px-3">
                      <div className="text-slate-200">{device.model}</div>
                      <span className="text-[10px] text-slate-500">{device.osVersion}</span>
                    </td>

                    {/* Serial Number with Copy */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-cyan-300 select-all font-bold">{device.serialNumber}</span>
                        <button
                          onClick={() => handleCopy(device.serialNumber, `sn-${device.deviceId}`)}
                          className="text-slate-500 hover:text-cyan-400 cursor-pointer"
                          title="Copy Serial Number"
                        >
                          {copiedField === `sn-${device.deviceId}` ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Product Key */}
                    <td className="py-3 px-3">
                      <span className="text-slate-300 select-all">{device.productKey}</span>
                    </td>

                    {/* IMEI */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="text-emerald-300 font-bold select-all">{device.imei}</span>
                    </td>

                    {/* Registered User */}
                    <td className="py-3 px-3">
                      <div className="text-white font-medium">{device.registeredUser.fullName}</div>
                      <span className="text-[10px] text-amber-300 select-all">{device.registeredUser.email}</span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedDevice(device)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 border border-slate-700 text-[11px] font-bold cursor-pointer transition-all"
                        >
                          Inspect Specs
                        </button>
                        <button
                          onClick={() => handleToggleRevoke(device)}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-all border ${
                            device.approvalStatus === 'APPROVED'
                              ? 'bg-rose-950/60 hover:bg-rose-900 border-rose-500/40 text-rose-300'
                              : 'bg-emerald-950/60 hover:bg-emerald-900 border-emerald-500/40 text-emerald-300'
                          }`}
                        >
                          {device.approvalStatus === 'APPROVED' ? 'Revoke' : 'Re-Approve'}
                        </button>
                        <button
                          onClick={() => handleRemoteSecureWipe(device)}
                          className="px-2 py-1 rounded-lg bg-rose-900/80 hover:bg-rose-800 text-rose-100 border border-rose-600 text-[10px] font-bold cursor-pointer transition-all flex items-center gap-1 shadow"
                          title="Trigger factory-reset level data purge via heartbeat protocol"
                        >
                          <Trash2 className="w-3 h-3 text-rose-300" />
                          <span>Wipe</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-mono text-xs">
                    No registered devices found matching search query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      )}

      {/* Technical Device Specifications Inspection Modal */}
      <AnimatePresence>
        {selectedDevice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-6 shadow-2xl text-slate-100 font-sans"
            >
              {/* Modal Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400 shadow-md">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      Registered Device Technical Dossier
                    </h2>
                    <p className="text-xs text-amber-300 font-mono">
                      Device ID: {selectedDevice.deviceId} • Approval: {selectedDevice.approvalStatus}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedDevice(null)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Technical Specifications Grid */}
              <div className="space-y-3.5 my-4 text-xs font-mono">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Device Serial Number:</span>
                    <span className="text-cyan-300 font-bold select-all">{selectedDevice.serialNumber}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Cryptographic Product Key:</span>
                    <span className="text-amber-300 font-bold select-all">{selectedDevice.productKey}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Manufacturer:</span>
                    <span className="text-white font-bold">{selectedDevice.manufacturer}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">15-Digit Hardware IMEI:</span>
                    <span className="text-emerald-400 font-bold select-all">{selectedDevice.imei}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Hardware Model:</span>
                    <span className="text-white">{selectedDevice.model}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">OS & Firmware Version:</span>
                    <span className="text-slate-300">{selectedDevice.osVersion}</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                  <span className="text-slate-400 block font-bold">Deep Hardware Telemetry:</span>
                  <div className="text-slate-300">Screen Resolution: {selectedDevice.screenResolution}</div>
                  <div className="text-slate-300">CPU Concurrency: {selectedDevice.hardwareConcurrency} Cores</div>
                  <div className="text-slate-300">Device RAM: {selectedDevice.deviceMemoryGb} GB</div>
                  <div className="text-slate-300">GPU Graphics: {selectedDevice.gpuRenderer}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-slate-400 block font-bold">Approved User Binding:</span>
                  <div className="text-white font-bold">{selectedDevice.registeredUser.fullName}</div>
                  <div className="text-amber-300">{selectedDevice.registeredUser.email}</div>
                  <div className="text-slate-400 text-[11px]">Approved At: {new Date(selectedDevice.approvalTimestamp).toLocaleString()}</div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">
                  Decentralized 50M Peer Registry • Prophet Verified
                </span>
                <button
                  onClick={() => setSelectedDevice(null)}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer transition-all"
                >
                  Close Dossier
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
