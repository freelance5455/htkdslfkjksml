import { logos } from "../data/content";

export function SocialProof() {
  const row = [...logos, ...logos];

  return (
    <section
      className="relative border-y border-white/5 bg-ink-950/50 py-12 sm:py-16"
      aria-label="Trusted by leading teams"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <p className="reveal text-center text-sm font-medium tracking-wide text-ink-500 uppercase">
          Trusted by forward-thinking ops teams at
        </p>
      </div>

      <div className="relative mt-8 overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-20 bg-gradient-to-r from-ink-950 to-transparent sm:w-32" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-ink-950 to-transparent sm:w-32" />

        <div className="animate-marquee flex w-max gap-12 sm:gap-16">
          {row.map((name, i) => (
            <div
              key={`${name}-${i}`}
              className="flex shrink-0 items-center gap-2.5 opacity-40 transition-opacity duration-300 hover:opacity-70"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5">
                <span className="text-xs font-bold text-white">
                  {name.charAt(0)}
                </span>
              </div>
              <span className="text-lg font-semibold tracking-tight text-white whitespace-nowrap">
                {name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
