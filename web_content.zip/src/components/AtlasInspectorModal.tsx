import React, {useEffect, useRef} from 'react';
import {X} from 'lucide-react';
import type {AtlasTileMeta} from '../game/textureAtlas';
import type {AtlasMetrics, QualityTier} from '../game/types';

interface AtlasInspectorModalProps {
  open: boolean;
  metrics: AtlasMetrics;
  atlasCanvas: HTMLCanvasElement | null;
  tiles: AtlasTileMeta[];
  mobile30FpsCap: boolean;
  onToggleMobile30Fps: () => void;
  onChangeTier: (tier: QualityTier) => void;
  onClose: () => void;
}

export const AtlasInspectorModal: React.FC<AtlasInspectorModalProps> = ({
  open,
  metrics,
  atlasCanvas,
  tiles,
  mobile30FpsCap,
  onToggleMobile30Fps,
  onChangeTier,
  onClose,
}) => {
  const previewRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!open || !atlasCanvas || !previewRef.current) return;
    const dst = previewRef.current;
    dst.width = 512;
    dst.height = 512;
    const ctx = dst.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(atlasCanvas, 0, 0, 512, 512);

    // Draw subtle UV grid lines and tile labels
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 1;
    const cell = 512 / 4;
    for (let i = 1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cell, 0);
      ctx.lineTo(i * cell, 512);
      ctx.moveTo(0, i * cell);
      ctx.lineTo(512, i * cell);
      ctx.stroke();
    }
    ctx.font = 'bold 10px "JetBrains Mono", monospace';
    tiles.forEach((t) => {
      const x = t.col * cell + 6;
      const y = t.row * cell + 16;
      ctx.fillStyle = 'rgba(11,15,20,0.78)';
      ctx.fillRect(x - 3, y - 11, cell - 10, 15);
      ctx.fillStyle = '#f8fafc';
      ctx.fillText(t.label, x, y);
    });
  }, [open, atlasCanvas, tiles, metrics.atlasResolution]);

  if (!open) return null;

  const tiers: {id: QualityTier; label: string; desc: string}[] = [
    {id: 'pc-high', label: 'PC High', desc: '2048px Atlas · 2x DPR · Soft Shadows'},
    {id: 'mobile-balanced', label: 'Mobile Balanced', desc: '1024px Atlas · 1.5x DPR · 30fps Cap'},
    {id: 'mobile-eco', label: 'Mobile Eco', desc: '512px Atlas · 1.0x DPR · Contact Shadows'},
  ];

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
      <div className="flex max-h-[88vh] w-full max-w-3xl flex-col rounded-xl border border-white/15 bg-[#0f151e] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div>
            <h2 className="font-display text-xl font-bold text-white">
              Texture Atlas & Cross-Platform Performance
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              16 world materials packed into 1 GPU Texture Atlas sheet with bleed gutters & merged geometry
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white"
            aria-label="Close Atlas Inspector"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6 overflow-y-auto p-6 md:grid-cols-2">
          <div>
            <div className="text-xs font-semibold text-slate-300 mb-2">
              Live Procedural Atlas Sheet ({metrics.atlasResolution}×{metrics.atlasResolution}px)
            </div>
            <canvas
              ref={previewRef}
              className="w-full aspect-square rounded-lg border border-white/15 bg-slate-950"
            />
          </div>

          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3 rounded-xl border border-white/10 bg-slate-900/70 p-4">
              <div>
                <div className="text-xs text-slate-400">Draw Calls</div>
                <div className="font-mono-num text-xl font-bold text-emerald-400">
                  {metrics.drawCalls}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Frame Rate</div>
                <div className="font-mono-num text-xl font-bold text-white">
                  {metrics.fps} FPS
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Triangles</div>
                <div className="font-mono-num text-base font-semibold text-slate-200">
                  {metrics.triangles.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Pixel Ratio / Gutter</div>
                <div className="font-mono-num text-base font-semibold text-slate-200">
                  {metrics.pixelRatio.toFixed(1)}x / {metrics.gutterPx}px
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-slate-300 mb-2">
                Platform Quality Preset
              </div>
              <div className="space-y-2">
                {tiers.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => onChangeTier(t.id)}
                    className={`flex w-full items-center justify-between rounded-lg border px-3.5 py-2.5 text-left transition ${
                      metrics.qualityTier === t.id
                        ? 'border-emerald-400 bg-emerald-500/15 text-white'
                        : 'border-white/10 bg-slate-900/60 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold">{t.label}</div>
                      <div className="text-xs text-slate-400">{t.desc}</div>
                    </div>
                    {metrics.qualityTier === t.id && (
                      <span className="text-xs font-semibold text-emerald-400">Active</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-white/10 bg-slate-900/60 px-3.5 py-3">
              <div>
                <div className="text-xs font-bold text-white">Mobile 30 FPS Frame Cap</div>
                <div className="text-xs text-slate-400">
                  Locks mobile cadence to 33.3ms to prevent thermal throttling
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleMobile30Fps}
                className={`min-h-[36px] rounded-lg px-3 text-xs font-bold ${
                  mobile30FpsCap
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-800 text-slate-200'
                }`}
              >
                {mobile30FpsCap ? '30 FPS On' : '60 FPS'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
