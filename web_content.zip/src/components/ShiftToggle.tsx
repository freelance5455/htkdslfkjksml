import { Moon, Sun } from 'lucide-react';
import type { ShiftType } from '../types/attendance';

interface ShiftToggleProps {
  selectedShift: ShiftType;
  onChangeShift: (shift: ShiftType) => void;
}

export function ShiftToggle({ selectedShift, onChangeShift }: ShiftToggleProps) {
  return (
    <div
      role="group"
      aria-label="Select Shift"
      className="inline-flex items-center p-1 bg-slate-100 border border-slate-200/80 rounded-xl shrink-0"
    >
      <button
        type="button"
        onClick={() => onChangeShift('day')}
        aria-pressed={selectedShift === 'day'}
        className={`min-h-[36px] px-3 py-1.5 inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
          selectedShift === 'day'
            ? 'bg-white text-slate-900 shadow-xs'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <Sun
          className={`w-3.5 h-3.5 ${selectedShift === 'day' ? 'text-amber-500' : 'text-slate-400'}`}
          aria-hidden="true"
        />
        <span>Day Shift</span>
      </button>

      <button
        type="button"
        onClick={() => onChangeShift('night')}
        aria-pressed={selectedShift === 'night'}
        className={`min-h-[36px] px-3 py-1.5 inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
          selectedShift === 'night'
            ? 'bg-slate-900 text-white shadow-xs'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <Moon
          className={`w-3.5 h-3.5 ${selectedShift === 'night' ? 'text-blue-300' : 'text-slate-400'}`}
          aria-hidden="true"
        />
        <span>Night Shift</span>
      </button>
    </div>
  );
}
