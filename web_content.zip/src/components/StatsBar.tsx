import React, { useRef } from 'react';
import { SFXEvent } from '../types';
import { 
  TrendingUp, 
  CalendarCheck, 
  Clock, 
  IndianRupee, 
  Download, 
  Upload, 
  FileSpreadsheet 
} from 'lucide-react';
import { saveEventsToStorage } from '../services/storage';

interface StatsBarProps {
  events: SFXEvent[];
  onRefresh: () => void;
}

export const StatsBar: React.FC<StatsBarProps> = ({ events, onRefresh }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalAmount = events.reduce((sum, ev) => {
    const val = parseFloat(ev.amount) || 0;
    return sum + val;
  }, 0);

  const confirmedCount = events.filter(e => e.status === 'Confirmed').length;
  const advancePendingCount = events.filter(e => e.status === 'Advance Pending').length;

  const handleExportCSV = () => {
    const headers = ['ID', 'Customer', 'Type', 'Date', 'Venue', 'Phone', 'Amount_INR', 'Status', 'Notes'];
    const rows = events.map(e => [
      e.id,
      `"${(e.customer || '').replace(/"/g, '""')}"`,
      `"${(e.type || '').replace(/"/g, '""')}"`,
      e.event_date,
      `"${(e.venue || '').replace(/"/g, '""')}"`,
      `"${(e.phone || '').replace(/"/g, '""')}"`,
      e.amount || '0',
      e.status,
      `"${(e.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HiTechSFX_Events_Backup_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    const jsonStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(events, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', jsonStr);
    link.setAttribute('download', `HiTechSFX_Events_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          saveEventsToStorage(parsed);
          onRefresh();
          alert('Database restored successfully from JSON backup!');
        }
      } catch (err) {
        alert('Invalid JSON file');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
      {/* 4 Quick Stat Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1">
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <div className="flex items-center gap-1.5 text-slate-500 text-xs font-semibold">
            <CalendarCheck className="w-3.5 h-3.5 text-[#0f4c81]" />
            <span>Total Events</span>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-1">
            {events.length}
          </div>
        </div>

        <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-100">
          <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-semibold">
            <IndianRupee className="w-3.5 h-3.5 text-emerald-600" />
            <span>Total Value</span>
          </div>
          <div className="text-xl font-extrabold text-emerald-900 mt-1">
            ₹{totalAmount.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-100">
          <div className="flex items-center gap-1.5 text-blue-800 text-xs font-semibold">
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
            <span>Confirmed</span>
          </div>
          <div className="text-xl font-extrabold text-blue-900 mt-1">
            {confirmedCount}
          </div>
        </div>

        <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-100">
          <div className="flex items-center gap-1.5 text-amber-800 text-xs font-semibold">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Adv. Pending</span>
          </div>
          <div className="text-xl font-extrabold text-amber-900 mt-1">
            {advancePendingCount}
          </div>
        </div>
      </div>

      {/* Backup & CSV Buttons */}
      <div className="flex items-center gap-2 border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-4">
        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
          title="Export events as CSV spreadsheet"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
          <span>Export CSV</span>
        </button>

        <button
          onClick={handleExportJSON}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
          title="Export complete database backup as JSON"
        >
          <Download className="w-3.5 h-3.5 text-blue-600" />
          <span>Backup</span>
        </button>

        <label className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer">
          <Upload className="w-3.5 h-3.5 text-slate-600" />
          <span>Restore</span>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleImportJSON}
            className="hidden"
          />
        </label>
      </div>
    </div>
  );
};
