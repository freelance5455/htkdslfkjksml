import React from 'react';
import { Heart, Utensils, Zap, Smile, Dumbbell, Sparkles } from 'lucide-react';
import { calculateMaxEnergy, getMoodProductivityMultiplier, getXpRequiredForNextLevel } from '../game/engine';

interface StatsBarProps {
  health: number;
  hunger: number;
  energy: number;
  fitnessLevel: number;
  fitnessXP: number;
  mood: number;
  skill: number;
  rep: number;
}

export const StatsBar: React.FC<StatsBarProps> = ({
  health,
  hunger,
  energy,
  fitnessLevel,
  fitnessXP,
  mood,
  skill,
  rep
}) => {
  const maxEnergy = calculateMaxEnergy(fitnessLevel);
  const nextLevelXP = getXpRequiredForNextLevel(fitnessLevel);
  const energyPercent = Math.min(100, Math.max(0, (energy / maxEnergy) * 100));
  const xpPercent = Math.min(100, Math.max(0, (fitnessXP / nextLevelXP) * 100));

  const moodInfo = getMoodProductivityMultiplier(mood);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 mb-3 shadow-lg">
      {/* 4 Primary Bars */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Health */}
        <div className="bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-semibold">
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/20" />
              <span>الصحة</span>
            </span>
            <span className="font-bold text-slate-200">{Math.round(health)}%</span>
          </div>
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-rose-500 to-rose-400 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(100, Math.max(0, health))}%` }}
            />
          </div>
        </div>

        {/* Hunger */}
        <div className="bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-semibold">
              <Utensils className="w-3.5 h-3.5 text-amber-500" />
              <span>الشبع</span>
            </span>
            <span className="font-bold text-slate-200">{Math.round(hunger)}%</span>
          </div>
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(100, Math.max(0, hunger))}%` }}
            />
          </div>
        </div>

        {/* Energy with Progressive Level Bar */}
        <div className="bg-slate-950/80 p-2.5 rounded-2xl border border-cyan-900/40 relative">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="flex items-center gap-1 text-cyan-300 font-semibold">
              <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400/20" />
              <span>الطاقة</span>
            </span>
            <div className="flex items-center gap-1">
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/60 font-bold">
                Lvl {fitnessLevel}
              </span>
              <span className="font-bold text-slate-200">
                {Math.round(energy)}/{maxEnergy}
              </span>
            </div>
          </div>
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-teal-400 rounded-full transition-all duration-300"
              style={{ width: `${energyPercent}%` }}
            />
          </div>
          {/* Fitness XP bar */}
          <div className="flex items-center justify-between text-[9px] text-slate-400 mt-1">
            <span className="flex items-center gap-0.5">
              <Dumbbell className="w-2.5 h-2.5 text-cyan-400" />
              خبرة الجيم
            </span>
            <span>{Math.round(fitnessXP)}/{nextLevelXP} XP</span>
          </div>
        </div>

        {/* Mood with Productivity impact */}
        <div className="bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800/80">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="flex items-center gap-1 text-purple-300 font-semibold">
              <Smile className="w-3.5 h-3.5 text-purple-400" />
              <span>المزاج</span>
            </span>
            <span className="font-bold text-slate-200">{Math.round(mood)}%</span>
          </div>
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-fuchsia-400 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(100, Math.max(0, mood))}%` }}
            />
          </div>
          <div className={`text-[9px] mt-1 text-center font-medium ${
            moodInfo.tone === 'positive' ? 'text-emerald-400' : moodInfo.tone === 'negative' ? 'text-rose-400' : 'text-slate-400'
          }`}>
            {moodInfo.label}
          </div>
        </div>
      </div>

      {/* Sub stats info */}
      <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-800/80 text-[11px] text-slate-400">
        <div className="flex items-center gap-3">
          <span>🧠 المهارة: <b className="text-slate-200">{Math.round(skill)}</b></span>
          <span>⭐ السمعة: <b className="text-slate-200">{Math.round(rep)}</b></span>
        </div>
        <div className="flex items-center gap-1 text-amber-400/90">
          <Sparkles className="w-3 h-3" />
          <span>سعة الطاقة القصوى الحالية: {maxEnergy}⚡</span>
        </div>
      </div>
    </div>
  );
};
