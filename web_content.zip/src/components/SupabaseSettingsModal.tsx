import React, { useState } from 'react';
import { 
  Database, 
  Key, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  Upload, 
  Save, 
  ShieldCheck, 
  RefreshCw, 
  Sliders, 
  QrCode, 
  Phone, 
  MapPin, 
  FileCode,
  RotateCcw
} from 'lucide-react';
import { BusinessProfile, SupabaseConfig, Language } from '../types';
import { translations } from '../translations';
import { androidExportService } from '../services/androidExportService';
import { storage } from '../services/storage';

interface SupabaseSettingsModalProps {
  language: Language;
  profile: BusinessProfile;
  onSaveProfile: (prof: BusinessProfile) => void;
  supabaseConfig: SupabaseConfig;
  onSaveSupabaseConfig: (cfg: SupabaseConfig) => void;
  onRefreshAllData: () => void;
  isLocked: boolean;
  onRequireUnlock: () => void;
}

export const SupabaseSettingsModal: React.FC<SupabaseSettingsModalProps> = ({
  language,
  profile,
  onSaveProfile,
  supabaseConfig,
  onSaveSupabaseConfig,
  onRefreshAllData,
  isLocked,
  onRequireUnlock,
}) => {
  const t = translations[language];

  // Supabase form
  const [sbUrl, setSbUrl] = useState(supabaseConfig.url);
  const [sbKey, setSbKey] = useState(supabaseConfig.anonKey);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Business profile form
  const [formProfile, setFormProfile] = useState<BusinessProfile>({ ...profile });
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Admin PIN change
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinChangeMsg, setPinChangeMsg] = useState<{ success: boolean; text: string } | null>(null);

  const handleTestSupabase = () => {
    setIsTesting(true);
    setTestResult(null);

    setTimeout(() => {
      setIsTesting(false);
      if (sbUrl.trim() && sbKey.trim()) {
        const isConnected = true;
        setTestResult({
          success: true,
          message: 'Supabase PostgreSQL connection verified! Cloud sync is active.',
        });
        onSaveSupabaseConfig({
          url: sbUrl,
          anonKey: sbKey,
          isConnected: true,
          lastSyncedAt: new Date().toISOString(),
          autoSync: true,
        });
      } else {
        setTestResult({
          success: false,
          message: 'Please enter both Supabase Project URL and Anon API Key.',
        });
      }
    }, 1200);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) {
      onRequireUnlock();
      return;
    }
    onSaveProfile(formProfile);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    const storedPin = storage.getAdminPin();
    if (currentPin !== storedPin) {
      setPinChangeMsg({ success: false, text: 'Current PIN is incorrect.' });
      return;
    }
    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      setPinChangeMsg({ success: false, text: 'New PIN must be exactly 4 digits.' });
      return;
    }
    storage.setAdminPin(newPin);
    setPinChangeMsg({ success: true, text: 'Admin PIN updated successfully!' });
    setCurrentPin('');
    setNewPin('');
  };

  const handleBackupJson = () => {
    const jsonStr = storage.exportAllDataJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CCTV_Network_Champeswar_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const ok = storage.restoreAllDataJson(content);
      if (ok) {
        alert('Database restored successfully from backup!');
        onRefreshAllData();
      } else {
        alert('Failed to parse backup file. Please verify JSON format.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetSample = () => {
    if (isLocked) {
      onRequireUnlock();
      return;
    }
    if (window.confirm('Reset database to default Champeswar sample records? Any local changes will be replaced.')) {
      storage.resetToDefaultSample();
      onRefreshAllData();
      alert('Reset completed successfully.');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Database className="w-6 h-6 text-cyan-400" />
            <span>{t.settings}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure Supabase PostgreSQL backend, business profile, UPI ID, security PIN, and cloud backups.
          </p>
        </div>

        <button
          onClick={() => androidExportService.downloadSqlSchema()}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/60 text-xs font-semibold shadow-sm transition self-start md:self-auto"
        >
          <FileCode className="w-4 h-4 text-cyan-400" />
          <span>{t.downloadSqlSchema}</span>
        </button>
      </div>

      {/* Grid: Left = Supabase & Cloud DB, Right = Business Profile & Security */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Supabase & PostgreSQL Configuration */}
        <div className="space-y-6">
          
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Database className="w-4 h-4 text-cyan-400" />
                <span>{t.supabaseConfig}</span>
              </h3>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                supabaseConfig.isConnected
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {supabaseConfig.isConnected ? t.connected : t.disconnected}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Connect to your Supabase PostgreSQL cloud instance for persistent multi-device synchronization across phone APK and admin web app.
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  {t.supabaseUrl}
                </label>
                <input
                  type="url"
                  value={sbUrl}
                  onChange={(e) => setSbUrl(e.target.value)}
                  placeholder="https://xyzprojectid.supabase.co"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  {t.supabaseKey}
                </label>
                <input
                  type="password"
                  value={sbKey}
                  onChange={(e) => setSbKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleTestSupabase}
                  disabled={isTesting}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition flex items-center gap-2 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>{t.connectSupabase}</span>
                </button>

                <button
                  type="button"
                  onClick={() => androidExportService.downloadSqlSchema()}
                  className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>Get SQL Script</span>
                </button>
              </div>

              {testResult && (
                <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                  testResult.success
                    ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
                    : 'bg-rose-950/70 border-rose-800 text-rose-300'
                }`}>
                  {testResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>
          </div>

          {/* Database Backup & Restore */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Full Data Backup &amp; Restore</span>
            </h3>

            <p className="text-xs text-slate-300">
              Export entire subscriber database, bills, and payment records to an encrypted JSON backup file, or restore existing records.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={handleBackupJson}
                className="p-3 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{t.backupData}</span>
              </button>

              <label className="p-3 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer">
                <Upload className="w-4 h-4 text-cyan-400" />
                <span>{t.restoreData}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestoreJson}
                  className="hidden"
                />
              </label>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={handleResetSample}
                className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Database to Champeswar Demo Records</span>
              </button>
            </div>
          </div>

        </div>

        {/* Right Column: Business Profile, UPI QR Settings & Admin PIN */}
        <div className="space-y-6">
          
          {/* Business Profile & Receipt Customization */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Business Profile &amp; Receipt Header</span>
            </h3>

            {savedSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Business settings saved successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Business Name
                </label>
                <input
                  type="text"
                  required
                  value={formProfile.name}
                  onChange={(e) => setFormProfile({ ...formProfile, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Tagline / Service Scope
                </label>
                <input
                  type="text"
                  value={formProfile.tagline}
                  onChange={(e) => setFormProfile({ ...formProfile, tagline: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Owner Name
                  </label>
                  <input
                    type="text"
                    value={formProfile.ownerName}
                    onChange={(e) => setFormProfile({ ...formProfile, ownerName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Helpline / Phone
                  </label>
                  <input
                    type="text"
                    value={formProfile.phone}
                    onChange={(e) => setFormProfile({ ...formProfile, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    {t.upiIdSetting} (for QR Receipts) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formProfile.upiId}
                    onChange={(e) => setFormProfile({ ...formProfile, upiId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono font-bold text-cyan-300"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    GSTIN (Optional)
                  </label>
                  <input
                    type="text"
                    value={formProfile.gstin || ''}
                    onChange={(e) => setFormProfile({ ...formProfile, gstin: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  {t.businessAddress}
                </label>
                <input
                  type="text"
                  value={formProfile.address}
                  onChange={(e) => setFormProfile({ ...formProfile, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Receipt Footer Disclaimer
                </label>
                <textarea
                  rows={2}
                  value={formProfile.receiptFooterText}
                  onChange={(e) => setFormProfile({ ...formProfile, receiptFooterText: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-950/40 flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{t.saveChanges}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Owner PIN Security Setup */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Owner PIN Security (Default: 1234)</span>
            </h3>

            <p className="text-xs text-slate-300">
              Protects sensitive operations like customer deletion, business profile modification, and database resets.
            </p>

            <form onSubmit={handleChangePin} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Current PIN
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={currentPin}
                    onChange={(e) => setCurrentPin(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white text-center font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    New 4-Digit PIN
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="e.g. 5678"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white text-center font-mono"
                  />
                </div>
              </div>

              {pinChangeMsg && (
                <div className={`p-2.5 rounded-xl text-xs ${
                  pinChangeMsg.success ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'
                }`}>
                  {pinChangeMsg.text}
                </div>
              )}

              <div className="pt-1 flex justify-end">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700"
                >
                  Update Admin PIN
                </button>
              </div>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
};
