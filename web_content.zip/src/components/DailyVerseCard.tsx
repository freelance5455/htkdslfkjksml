import React, { useState } from 'react';
import {
  BookOpen,
  Volume2,
  Copy,
  Check,
  Sparkles,
  Shuffle,
} from 'lucide-react';
import { DailyVerse } from '../types';
import {
  getDailyVerseForDate,
  getRandomVerse,
} from '../services/dailyVerseService';

interface DailyVerseCardProps {
  date?: Date;
  onBookmark?: (verse: DailyVerse) => void;
}

export const DailyVerseCard: React.FC<DailyVerseCardProps> = ({
  date = new Date(),
}) => {
  const [currentVerse, setCurrentVerse] = useState<DailyVerse>(() =>
    getDailyVerseForDate(date)
  );
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const handleCopy = () => {
    const text = `"${currentVerse.english}"\n${currentVerse.hebrew}\n(${currentVerse.source} • ${currentVerse.sourceHe})`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShuffle = () => {
    setCurrentVerse(getRandomVerse());
  };

  const handlePlayAudio = () => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in this browser.');
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentVerse.hebrew);
    utterance.lang = 'he-IL';
    utterance.rate = 0.85;

    setIsPlayingAudio(true);
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="bg-[#1A1A1A] p-6 rounded-2xl border border-[#2A2A2A] shadow-xl relative overflow-hidden">
      {/* Top row: Label & Controls */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs font-bold text-[#C5A267] uppercase tracking-[0.2em]">
          Daily Verse
        </span>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleShuffle}
            className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#161616] text-[#888888] hover:text-[#EAEAEA] hover:bg-[#202020] transition-colors"
            title="Read Another Daily Verse"
          >
            <Shuffle className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#161616] text-[#888888] hover:text-[#EAEAEA] hover:bg-[#202020] transition-colors"
            title="Copy Verse Text"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>
          <button
            onClick={handlePlayAudio}
            className={`p-1.5 rounded-lg border transition-colors ${
              isPlayingAudio
                ? 'bg-[#C5A267] text-[#0F0F0F] border-[#C5A267] animate-pulse'
                : 'border-[#2A2A2A] bg-[#161616] text-[#888888] hover:text-[#C5A267] hover:bg-[#202020]'
            }`}
            title="Listen to Hebrew Audio"
          >
            <Volume2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Hebrew Verse */}
      <p
        className="text-2xl sm:text-3xl font-serif text-[#EAEAEA] leading-relaxed text-right tracking-wide my-3"
        dir="rtl"
      >
        ״{currentVerse.hebrew}״
      </p>

      {/* Source Citation */}
      <p className="text-xs text-[#888888] italic text-right font-hebrew">
        {currentVerse.sourceHe} • {currentVerse.source}
      </p>

      {/* English Translation */}
      <p className="text-sm text-[#D1D1D1] mt-4 border-t border-[#2A2A2A] pt-4 leading-relaxed font-normal">
        "{currentVerse.english}"
      </p>

      {/* Reflection Note */}
      {currentVerse.practicalTakeaway && (
        <div className="mt-3 pt-3 border-t border-[#2A2A2A]/60 flex items-start gap-2 text-xs text-[#888888]">
          <Sparkles className="w-3.5 h-3.5 text-[#C5A267] shrink-0 mt-0.5" />
          <span>
            <strong className="text-[#C5A267] font-semibold">
              {currentVerse.theme}:
            </strong>{' '}
            {currentVerse.practicalTakeaway}
          </span>
        </div>
      )}
    </div>
  );
};
