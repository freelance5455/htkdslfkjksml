import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Workout, RecoveryCheckIn, ChatMessage } from '../types';
import { StorageService } from '../services/storage';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  ShieldAlert,
  Loader2,
  Flame,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

interface CoachChatProps {
  profile: UserProfile;
  recentWorkouts: Workout[];
  latestRecovery?: RecoveryCheckIn;
  onClose?: () => void;
  onNavigateToWorkout?: () => void;
}

export const CoachChat: React.FC<CoachChatProps> = ({
  profile,
  recentWorkouts,
  latestRecovery,
  onClose,
  onNavigateToWorkout,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const history = StorageService.getChatHistory();
    if (history.length > 0) return history;
    return [
      {
        id: 'msg-init',
        role: 'model',
        text: `Ram Ram ${profile.name || 'Runner'}! Main hoon Coach Jaat.\n\nTarget clear hai: 1600m in 4:50 (400m splits @ 1:12.5). Baseline ~5:30 abhi unverified hai. Aaj training shuru karne se pehle batao: sleep kaisi thi, muscle soreness kitni hai, aur aaj ka workout plan samjhna hai?`,
        timestamp: Date.now(),
      },
    ];
  });

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [preferredLang, setPreferredLang] = useState<'Hinglish' | 'Hindi' | 'English'>(
    profile.preferredLanguage || 'Hinglish'
  );

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    StorageService.saveChatHistory(messages);
  }, [messages]);

  // Setup Web Speech Recognition for speech-to-text
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = preferredLang === 'Hindi' ? 'hi-IN' : preferredLang === 'Hinglish' ? 'hi-IN' : 'en-US';

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
          setIsListening(false);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, [preferredLang]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser. Please type your message.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      try {
        recognitionRef.current.start();
      } catch (err) {
        setIsListening(false);
      }
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      text: text.trim(),
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/coach/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, text: m.text })),
          profile,
          recentWorkouts: recentWorkouts.slice(0, 3),
          recoveryState: latestRecovery,
          language: preferredLang,
        }),
      });

      const data = await response.json();
      const modelMsg: ChatMessage = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        text: data.reply || 'Train with discipline. Keep your recovery consistent.',
        timestamp: Date.now(),
      };
      setMessages([...newMessages, modelMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: ChatMessage = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        text: 'Discipline over motivation. Make sure you complete a 10 min dynamic warm-up before any hard repetitions. Check your recovery score first.',
        timestamp: Date.now(),
      };
      setMessages([...newMessages, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Text to Speech playback
  const playAudioForMessage = async (msg: ChatMessage) => {
    // If already playing this message, stop it
    if (playingAudioId === msg.id && currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
      setPlayingAudioId(null);
      return;
    }

    setPlayingAudioId(msg.id);

    try {
      // First attempt server Gemini TTS
      const res = await fetch('/api/coach/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: msg.text }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audio}`);
          currentAudioRef.current = audio;
          audio.onended = () => setPlayingAudioId(null);
          audio.onerror = () => fallbackBrowserSpeech(msg.text);
          audio.play();
          return;
        }
      }
      fallbackBrowserSpeech(msg.text);
    } catch (e) {
      fallbackBrowserSpeech(msg.text);
    }
  };

  const fallbackBrowserSpeech = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/[*#_`]/g, ''));
      utterance.rate = 1.0;
      utterance.onend = () => setPlayingAudioId(null);
      utterance.onerror = () => setPlayingAudioId(null);
      window.speechSynthesis.speak(utterance);
    } else {
      setPlayingAudioId(null);
    }
  };

  const quickChips = [
    { label: '🏃 Aaj ka Workout Samjhao', prompt: 'Aaj ka running workout detail mein samjhao - warm-up, intervals, aur pace kitni rakhni hai?' },
    { label: '⏱️ Target 4:50 Pace Strategy', prompt: '1600m target 4:50 achieve karne ke liye har 400m lap ka pace aur split strategy kya honi chahiye?' },
    { label: '🫁 Breathing & Form Guide', prompt: '1600m run karte waqt breathing pattern (2:2 vs 3:3) aur hip extension running posture kaise maintain karein?' },
    { label: '🦵 Shin Splints & Soreness Check', prompt: 'Mujhe calf aur shin mein halki soreness hai, kya mujhe hard intervals run karne chahiye ya recovery lena chahiye?' },
    { label: '📊 Review Last Workout', prompt: 'Mere last completed workout ke pace aur splits review karo aur honest improvement feedback do.' },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-md mx-auto bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
      {/* Coach Header */}
      <div className="bg-zinc-900/90 border-b border-zinc-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-black border-2 border-[#00FF66] flex items-center justify-center glow-neon-sm">
            <Flame className="w-5 h-5 text-[#00FF66] fill-[#00FF66]/20" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-athletic text-base font-extrabold uppercase text-white tracking-wide">
                Coach Jaat
              </h2>
              <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse" />
            </div>
            <p className="text-[11px] text-zinc-400 font-medium">
              1600m Elite Sports Scientist & Coach
            </p>
          </div>
        </div>

        {/* Language selector toggle */}
        <div className="flex items-center bg-black border border-zinc-800 rounded-lg p-0.5 text-[11px]">
          {(['Hinglish', 'Hindi', 'English'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => setPreferredLang(lang)}
              className={`px-2 py-1 rounded-md font-semibold transition ${
                preferredLang === lang
                  ? 'bg-[#00FF66] text-black'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Safety Notice Warning */}
      <div className="bg-zinc-900/40 border-b border-zinc-800/80 px-3 py-1.5 flex items-center gap-2 text-[11px] text-zinc-400">
        <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
        <span className="truncate">
          Safety First: Hard sessions are adjusted if fatigue or sharp pain is reported.
        </span>
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          const isPlaying = playingAudioId === msg.id;

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-md whitespace-pre-line leading-relaxed ${
                  isUser
                    ? 'bg-[#00FF66] text-black font-medium rounded-br-none'
                    : 'bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-bl-none'
                }`}
              >
                {msg.text}

                {/* Audio voice playback button for coach replies */}
                {!isUser && (
                  <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between">
                    <button
                      onClick={() => playAudioForMessage(msg)}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-semibold transition ${
                        isPlaying
                          ? 'bg-[#00FF66] text-black animate-pulse'
                          : 'bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700'
                      }`}
                    >
                      {isPlaying ? (
                        <>
                          <VolumeX className="w-3 h-3" />
                          <span>Speaking...</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3 h-3 text-[#00FF66]" />
                          <span>Listen (Coach Voice)</span>
                        </>
                      )}
                    </button>
                    <span className="text-[10px] text-zinc-500 font-mono-numbers">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-zinc-400 text-xs py-2">
            <Loader2 className="w-4 h-4 animate-spin text-[#00FF66]" />
            <span>Coach Jaat is analyzing your request...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompt Chips */}
      <div className="p-2 bg-zinc-900/60 border-t border-zinc-800/80 overflow-x-auto whitespace-nowrap flex gap-1.5 no-scrollbar">
        {quickChips.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(chip.prompt)}
            className="px-2.5 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 hover:text-white text-xs font-medium transition shrink-0 active:scale-95"
          >
            {chip.label}
          </button>
        ))}
      </div>

      {/* Message Input Box */}
      <div className="p-3 bg-zinc-900 border-t border-zinc-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          {/* Speech-to-text mic button */}
          <button
            type="button"
            onClick={toggleListening}
            className={`p-2.5 rounded-xl border transition ${
              isListening
                ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-white'
            }`}
            title="Speech to Text"
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              preferredLang === 'Hinglish'
                ? 'Coach se poochho: pace, recovery, workout...'
                : preferredLang === 'Hindi'
                ? 'कोच से पूछें...'
                : 'Ask Coach Jaat...'
            }
            className="flex-1 bg-black border border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#00FF66]"
          />

          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 rounded-xl bg-[#00FF66] text-black font-bold disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#10B981] transition"
          >
            <Send className="w-4 h-4 fill-current" />
          </button>
        </form>
      </div>
    </div>
  );
};
