import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Zap, Flame, Sparkles, TrendingUp, ShieldCheck, Download } from 'lucide-react';
import { soundEngine, triggerHaptic } from '../utils/audio';
import { LivePayoutItem } from '../types';

interface FloatingNumber {
  id: number;
  x: number;
  y: number;
  amount: number;
  isCrit: boolean;
}

interface TapViewProps {
  coins: number;
  energy: number;
  maxEnergy: number;
  tapPower: number;
  passiveRate: number;
  critChance: number;
  level: number;
  onTap: (pointsEarned: number, energyCost: number) => void;
  onFullEnergyRefill: () => void;
  canRefillEnergy: boolean;
  refillCooldownRemaining: number;
  livePayouts: LivePayoutItem[];
  onOpenWithdraw: () => void;
  onWatchAd: () => void;
  onOpenInstallModal: () => void;
}

export const TapView: React.FC<TapViewProps> = ({
  coins,
  energy,
  maxEnergy,
  tapPower,
  passiveRate,
  critChance,
  level,
  onTap,
  onFullEnergyRefill,
  canRefillEnergy,
  refillCooldownRemaining,
  livePayouts,
  onOpenWithdraw,
  onWatchAd,
  onOpenInstallModal,
}) => {
  const [floatingNumbers, setFloatingNumbers] = useState<FloatingNumber[]>([]);
  const [coinPressed, setCoinPressed] = useState(false);
  const [comboCount, setComboCount] = useState(0);
  const [isFeverMode, setIsFeverMode] = useState(false);
  const [feverTimeLeft, setFeverTimeLeft] = useState(0);
  const [activePayoutIndex, setActivePayoutIndex] = useState(0);

  const comboTimerRef = useRef<number | null>(null);
  const coinContainerRef = useRef<HTMLDivElement | null>(null);

  // Rotate live payout proof ticker every 4 seconds
  useEffect(() => {
    if (livePayouts.length === 0) return;
    const interval = setInterval(() => {
      setActivePayoutIndex((prev) => (prev + 1) % livePayouts.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [livePayouts.length]);

  // Fever Mode countdown
  useEffect(() => {
    if (!isFeverMode) return;
    const interval = setInterval(() => {
      setFeverTimeLeft((prev) => {
        if (prev <= 1) {
          setIsFeverMode(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isFeverMode]);

  // Handle single tap calculation
  const processTapAtCoordinate = useCallback((clientX: number, clientY: number) => {
    if (energy <= 0) {
      triggerHaptic('heavy');
      return;
    }

    // Check critical strike
    const isCrit = Math.random() < critChance;
    const feverMultiplier = isFeverMode ? 2 : 1;
    const critMultiplier = isCrit ? 5 : 1;
    const totalGained = tapPower * feverMultiplier * critMultiplier;

    // Trigger haptic and sound
    if (isCrit) {
      triggerHaptic('heavy');
      soundEngine.playCrit();
    } else {
      triggerHaptic('light');
      soundEngine.playTap(Math.min(comboCount + 1, 10));
    }

    // Update combo
    setComboCount((prev) => {
      const next = prev + 1;
      if (next >= 12 && !isFeverMode) {
        setIsFeverMode(true);
        setFeverTimeLeft(10);
        soundEngine.playCrit();
        triggerHaptic('success');
      }
      return next;
    });

    if (comboTimerRef.current) {
      window.clearTimeout(comboTimerRef.current);
    }
    comboTimerRef.current = window.setTimeout(() => {
      setComboCount(0);
    }, 1200);

    // Call parent handler
    onTap(totalGained, 1);

    // Add floating particle
    const coinRect = coinContainerRef.current?.getBoundingClientRect();
    const relX = coinRect ? clientX - coinRect.left : 140;
    const relY = coinRect ? clientY - coinRect.top : 140;

    const newId = Date.now() + Math.random();
    setFloatingNumbers((prev) => [
      ...prev.slice(-15),
      {
        id: newId,
        x: relX + (Math.random() * 20 - 10),
        y: relY + (Math.random() * 20 - 10),
        amount: totalGained,
        isCrit,
      },
    ]);

    setTimeout(() => {
      setFloatingNumbers((prev) => prev.filter((item) => item.id !== newId));
    }, 800);
  }, [energy, critChance, isFeverMode, tapPower, comboCount, onTap]);

  // Touch event supporting multi-finger tapping
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    setCoinPressed(true);
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      processTapAtCoordinate(touch.clientX, touch.clientY);
    }
  };

  const handleTouchEnd = () => {
    setCoinPressed(false);
  };

  // Mouse event for desktop
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    setCoinPressed(true);
    processTapAtCoordinate(e.clientX, e.clientY);
  };

  const handleMouseUp = () => {
    setCoinPressed(false);
  };

  const currentPayout = livePayouts[activePayoutIndex] || livePayouts[0];
  const energyPercentage = Math.min(100, Math.max(0, (energy / maxEnergy) * 100));

  const getRankName = (lvl: number) => {
    if (lvl >= 10) return 'Diamond Sultan';
    if (lvl >= 7) return 'Gold Tycoon';
    if (lvl >= 5) return 'Silver Miner';
    if (lvl >= 3) return 'Bronze Earner';
    return 'Apprentice';
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[calc(100vh-120px)] max-w-md mx-auto px-4 py-2 select-none">
      {/* Live Social Proof / Withdrawal Ticker */}
      {currentPayout && (
        <div
          onClick={onOpenWithdraw}
          className="w-full cursor-pointer bg-slate-900/80 hover:bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 flex items-center justify-between text-xs transition-colors shadow-sm mb-2"
        >
          <div className="flex items-center gap-2 truncate">
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${
                currentPayout.method === 'easypaisa' ? 'bg-emerald-500' : 'bg-rose-500'
              }`}
            />
            <span className="text-slate-300 truncate">
              <strong className="text-white font-medium">{currentPayout.userName}</strong> ({currentPayout.city}) withdrew{' '}
              <strong className="text-emerald-400 font-mono-num">Rs. {currentPayout.amountPKR}</strong> via{' '}
              <span className="capitalize font-semibold text-slate-200">{currentPayout.method}</span>
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0 text-[11px] text-slate-500 font-medium pl-2">
            <span>{currentPayout.timeAgo}</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      )}

      {/* Download & Install App Banner (Prominent for Users) */}
      <div
        onClick={onOpenInstallModal}
        className="w-full cursor-pointer bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-900 border border-emerald-500/40 hover:border-emerald-500 rounded-xl px-3 py-2 flex items-center justify-between text-xs transition-colors shadow-sm mb-2"
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Download className="w-4 h-4" />
          </div>
          <div>
            <span className="font-extrabold text-white block text-xs leading-tight">
              Download Game (.ZIP & Mobile App)
            </span>
            <span className="text-[10px] text-emerald-400">
              Apne mobile par save karein aur offline khelelin
            </span>
          </div>
        </div>
        <span className="px-2.5 py-1 bg-emerald-500 text-slate-950 font-black text-[11px] rounded-lg shadow-sm">
          Download
        </span>
      </div>

      {/* Level & Rank Badge */}
      <div className="w-full flex items-center justify-between px-1 mb-2">
        <div className="flex items-center gap-2">
          <div className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-bold text-amber-400 font-display">
            LVL {level}
          </div>
          <span className="text-xs font-semibold text-slate-300">
            {getRankName(level)}
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="flex items-center gap-1 font-mono-num">
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
            <span>+{passiveRate}/s passive</span>
          </span>
        </div>
      </div>

      {/* Main Big Coin Display */}
      <div className="my-auto relative flex flex-col items-center">
        {/* Fever / Turbo banner if active */}
        {isFeverMode ? (
          <div className="mb-3 px-3 py-1 rounded-full bg-gradient-to-r from-amber-600 via-orange-500 to-red-600 text-white font-black text-xs tracking-wider flex items-center gap-1.5 shadow-lg shadow-orange-500/30 animate-pulse">
            <Flame className="w-3.5 h-3.5 fill-current" />
            <span>FEVER MODE 2X ACTIVE ({feverTimeLeft}s)</span>
          </div>
        ) : comboCount > 4 ? (
          <div className="mb-3 px-3 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-amber-400 text-xs font-bold tracking-tight flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            <span>{comboCount} Combo Streak!</span>
          </div>
        ) : (
          <div className="h-6 mb-3" />
        )}

        {/* The 3D Tap Coin */}
        <div
          ref={coinContainerRef}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className={`relative w-64 h-64 sm:w-72 sm:h-72 cursor-pointer select-none touch-manipulation transition-transform duration-75 active:scale-95 ${
            coinPressed ? 'scale-95' : 'scale-100'
          }`}
          style={{ WebkitTapHighlightColor: 'transparent' }}
        >
          {/* Subtle Outer Energy Aura */}
          <div
            className={`absolute inset-0 rounded-full blur-2xl transition-opacity duration-300 ${
              isFeverMode
                ? 'bg-orange-500/40 opacity-100 animate-pulse'
                : 'bg-amber-500/20 opacity-70'
            }`}
          />

          {/* Golden Coin Graphic */}
          <div className="relative w-full h-full rounded-full p-2 bg-gradient-to-b from-amber-400 via-yellow-500 to-amber-700 shadow-2xl shadow-amber-500/20 border-4 border-yellow-300/60 overflow-hidden flex items-center justify-center">
            <img
              src="/src/assets/images/tap_coin_gold_1791924591380.jpg"
              alt="Tap Gold Coin"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-full pointer-events-none drop-shadow-md"
            />
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />
          </div>

          {/* Floating Numbers Spawner */}
          {floatingNumbers.map((num) => (
            <div
              key={num.id}
              className={`absolute pointer-events-none font-extrabold float-up-fade font-mono-num ${
                num.isCrit
                  ? 'text-yellow-300 text-2xl drop-shadow-[0_2px_8px_rgba(234,179,8,0.8)] z-30'
                  : 'text-amber-200 text-xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] z-20'
              }`}
              style={{
                left: `${num.x}px`,
                top: `${num.y}px`,
              }}
            >
              +{num.amount} {num.isCrit && '🔥'}
            </div>
          ))}
        </div>

        <p className="mt-3 text-xs text-slate-400 font-medium">
          Tap fast with multiple fingers to fill Fever Bar!
        </p>
      </div>

      {/* Energy & Stamina Bar Section */}
      <div className="w-full mt-auto pt-2 space-y-2">
        <div className="flex items-center justify-between text-xs px-1">
          <div className="flex items-center gap-1.5 font-semibold text-slate-200">
            <Zap className={`w-4 h-4 ${energy < 20 ? 'text-rose-400 animate-pulse' : 'text-amber-400'}`} />
            <span className="font-mono-num">
              {energy} / {maxEnergy}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                triggerHaptic('medium');
                onWatchAd();
              }}
              className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 active:scale-95 transition-transform bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/30"
            >
              <span>+250 Coins</span>
              <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-1 rounded">AD</span>
            </button>

            {canRefillEnergy ? (
              <button
                onClick={() => {
                  triggerHaptic('success');
                  soundEngine.playCoin();
                  onFullEnergyRefill();
                }}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 active:scale-95 transition-transform"
              >
                <span>Refill</span>
                <span className="text-[10px] bg-emerald-500/20 px-1 py-0.5 rounded text-emerald-300">FREE</span>
              </button>
            ) : (
              <span className="text-[10px] text-slate-500 font-mono-num">
                {refillCooldownRemaining}s
              </span>
            )}
          </div>
        </div>

        {/* Progress bar container */}
        <div className="w-full h-3.5 bg-slate-900 border border-slate-800 rounded-full p-0.5 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-200 ${
              energy < 50
                ? 'bg-rose-500'
                : 'bg-gradient-to-r from-amber-500 to-yellow-400'
            }`}
            style={{ width: `${energyPercentage}%` }}
          />
        </div>

        {/* Quick Cashout Teaser Bar */}
        <div className="flex items-center justify-between bg-slate-900/60 border border-slate-800/80 rounded-xl px-3 py-2 mt-2">
          <div className="flex items-center gap-2">
            <span className="text-sm">🇵🇰</span>
            <span className="text-xs text-slate-300 font-medium">
              Ready to cash out to Easypaisa or JazzCash?
            </span>
          </div>
          <button
            onClick={() => {
              triggerHaptic('medium');
              soundEngine.playCashRegister();
              onOpenWithdraw();
            }}
            className="text-xs font-bold text-emerald-400 hover:text-emerald-300 underline underline-offset-2 shrink-0 ml-2"
          >
            Withdraw Now
          </button>
        </div>
      </div>
    </div>
  );
};
