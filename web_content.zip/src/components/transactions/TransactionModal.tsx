import React, { useState, useEffect } from 'react';
import { useKhata } from '../../context/KhataContext';
import { TransactionType, PaymentMode } from '../../types';
import { CategoryIcon } from '../common/CategoryIcon';
import { formatRupee } from '../../i18n/translations';
import { X, AlertTriangle, Plus, Check } from 'lucide-react';

export const TransactionModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    editingTransaction,
    setEditingTransaction,
    categories,
    familyMembers,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    checkDuplicate,
    language,
    t
  } = useKhata();

  const isExpenseModal = activeModal === 'add-expense' || (editingTransaction && editingTransaction.type === 'expense');
  const isIncomeModal = activeModal === 'add-income' || (editingTransaction && editingTransaction.type === 'income');
  const isOpen = isExpenseModal || isIncomeModal;

  const defaultType: TransactionType = isIncomeModal ? 'income' : 'expense';

  const [type, setType] = useState<TransactionType>(defaultType);
  const [amount, setAmount] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [familyMemberId, setFamilyMemberId] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('upi');
  const [duplicateAlert, setDuplicateAlert] = useState<boolean>(false);
  const [bypassDuplicate, setBypassDuplicate] = useState<boolean>(false);

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmount(String(editingTransaction.amount));
      setCategoryId(editingTransaction.categoryId);
      setDate(editingTransaction.date);
      setDescription(editingTransaction.description);
      setFamilyMemberId(editingTransaction.familyMemberId || '');
      setPaymentMode(editingTransaction.paymentMode || 'upi');
      setDuplicateAlert(false);
      setBypassDuplicate(false);
    } else if (isOpen) {
      const now = new Date();
      const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      setType(defaultType);
      setAmount('');
      setDate(todayStr);
      setDescription('');
      setFamilyMemberId(familyMembers[0]?.id || '');
      setPaymentMode('upi');
      setDuplicateAlert(false);
      setBypassDuplicate(false);

      const filtered = categories.filter(c => c.type === defaultType);
      if (filtered.length > 0) {
        setCategoryId(filtered[0].id);
      }
    }
  }, [isOpen, editingTransaction, defaultType, familyMembers, categories]);

  if (!isOpen) return null;

  const filteredCategories = categories.filter(c => c.type === type);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) return;
    if (!categoryId) return;

    // Check duplicate if not editing and not bypassed
    if (!editingTransaction && !bypassDuplicate) {
      const dup = checkDuplicate(numAmount, categoryId, date);
      if (dup) {
        setDuplicateAlert(true);
        return;
      }
    }

    if (editingTransaction) {
      updateTransaction(editingTransaction.id, {
        type,
        amount: numAmount,
        categoryId,
        date,
        description: description.trim() || (type === 'income' ? 'आय' : 'घरेलू खर्च'),
        familyMemberId: familyMemberId || undefined,
        paymentMode
      });
    } else {
      addTransaction({
        type,
        amount: numAmount,
        categoryId,
        date,
        description: description.trim() || (type === 'income' ? 'आय' : 'घरेलू खर्च'),
        familyMemberId: familyMemberId || undefined,
        paymentMode
      });
    }

    handleClose();
  };

  const handleClose = () => {
    setActiveModal(null);
    setEditingTransaction(null);
    setDuplicateAlert(false);
    setBypassDuplicate(false);
  };

  const handleDelete = () => {
    if (editingTransaction && window.confirm(t.confirmDelete)) {
      deleteTransaction(editingTransaction.id);
      handleClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-2">
            <div
              className={`w-3 h-3 rounded-full ${
                type === 'income' ? 'bg-emerald-600' : 'bg-rose-500'
              }`}
            />
            <h3 className="text-base font-bold text-slate-900">
              {editingTransaction
                ? t.editTransactionTitle
                : type === 'income'
                ? t.addIncomeTitle
                : t.addExpenseTitle}
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Duplicate Warning Alert */}
          {duplicateAlert && (
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">
                  {t.duplicateWarning.replace('{amount}', amount)}
                </p>
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setBypassDuplicate(true);
                      setDuplicateAlert(false);
                    }}
                    className="px-2.5 py-1 bg-amber-600 text-white rounded-md text-xs font-semibold"
                  >
                    हाँ, फिर भी जोड़ें (Proceed)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDuplicateAlert(false)}
                    className="px-2.5 py-1 bg-white border border-amber-300 text-amber-800 rounded-md text-xs"
                  >
                    रद्द करें
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Type Toggle (Income / Expense) */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setType('expense');
                const firstExp = categories.find(c => c.type === 'expense');
                if (firstExp) setCategoryId(firstExp.id);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition ${
                type === 'expense'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              - {t.expenses} (Expense)
            </button>
            <button
              type="button"
              onClick={() => {
                setType('income');
                const firstInc = categories.find(c => c.type === 'income');
                if (firstInc) setCategoryId(firstInc.id);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition ${
                type === 'income'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + {t.income} (Income)
            </button>
          </div>

          {/* Amount Field (Big and Clear) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {t.amount} *
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-2xl font-bold text-slate-400">
                ₹
              </span>
              <input
                type="number"
                step="any"
                inputMode="decimal"
                required
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0"
                className="w-full pl-9 pr-4 py-3 text-2xl font-bold text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                autoFocus
              />
            </div>
          </div>

          {/* Category Picker Grid */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700">
                {t.category} *
              </label>
              <button
                type="button"
                onClick={() => setActiveModal('add-category')}
                className="text-[11px] font-semibold text-emerald-700 hover:underline flex items-center gap-0.5"
              >
                <Plus className="w-3 h-3" />
                {t.addCustomCategory}
              </button>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-44 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200">
              {filteredCategories.map(cat => {
                const isSelected = categoryId === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategoryId(cat.id)}
                    className={`flex flex-col items-center p-2 rounded-xl border text-center transition ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/80 ring-1 ring-emerald-600'
                        : 'border-slate-200 bg-white hover:bg-slate-100'
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center mb-1 shrink-0"
                      style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                    >
                      <CategoryIcon name={cat.icon} className="w-4 h-4" />
                    </div>
                    <span className="text-[11px] font-medium leading-tight text-slate-800 line-clamp-2">
                      {language === 'hi' ? cat.nameHi : cat.nameEn}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Description & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.description}
              </label>
              <input
                type="text"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={t.descriptionPlaceholder}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.date} *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Family Member & Payment Mode */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.familyMember}
              </label>
              <select
                value={familyMemberId}
                onChange={e => setFamilyMemberId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {familyMembers.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({language === 'hi' ? m.relationHi : m.relationEn})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.paymentMode}
              </label>
              <select
                value={paymentMode}
                onChange={e => setPaymentMode(e.target.value as PaymentMode)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="upi">{t.upi}</option>
                <option value="cash">{t.cash}</option>
                <option value="card">{t.card}</option>
                <option value="bank_transfer">{t.bank_transfer}</option>
                <option value="other">{t.other}</option>
              </select>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-3">
            {editingTransaction && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-4 py-2.5 rounded-xl border border-rose-300 text-rose-600 hover:bg-rose-50 text-xs font-semibold transition"
              >
                {t.delete}
              </button>
            )}
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-xl text-white text-sm font-bold shadow-md transition flex items-center justify-center gap-2 ${
                type === 'income'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>
                {t.save}{' '}
                {amount && !isNaN(parseFloat(amount))
                  ? `(${formatRupee(parseFloat(amount))})`
                  : ''}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
