import React, { useState, useMemo } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import { CategoryIcon } from '../common/CategoryIcon';
import { Transaction } from '../../types';
import {
  Search,
  Filter,
  Plus,
  Trash2,
  Calendar,
  Layers,
  Users,
  CreditCard,
  X
} from 'lucide-react';

export const DailyKhataView: React.FC = () => {
  const {
    transactions,
    categories,
    familyMembers,
    language,
    t,
    setActiveModal,
    setEditingTransaction,
    deleteTransaction
  } = useKhata();

  const [typeFilter, setTypeFilter] = useState<'all' | 'expense' | 'income'>('all');
  const [timeFilter, setTimeFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMember, setSelectedMember] = useState<string>('all');
  const [selectedPayment, setSelectedPayment] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);

  // Today & this week/month thresholds
  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }, []);

  const currentMonthPrefix = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }, []);

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      // Type
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;

      // Time Filter
      if (timeFilter === 'daily' && tx.date !== todayStr) return false;
      if (timeFilter === 'monthly' && !tx.date.startsWith(currentMonthPrefix)) return false;
      if (timeFilter === 'weekly') {
        const txDate = new Date(tx.date).getTime();
        const weekAgo = Date.now() - 7 * 86400000;
        if (txDate < weekAgo) return false;
      }

      // Category
      if (selectedCategory !== 'all' && tx.categoryId !== selectedCategory) return false;

      // Member
      if (selectedMember !== 'all' && tx.familyMemberId !== selectedMember) return false;

      // Payment mode
      if (selectedPayment !== 'all' && tx.paymentMode !== selectedPayment) return false;

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const cat = categories.find(c => c.id === tx.categoryId);
        const catNameHi = cat?.nameHi?.toLowerCase() || '';
        const catNameEn = cat?.nameEn?.toLowerCase() || '';
        const desc = tx.description.toLowerCase();
        const amt = String(tx.amount);
        const match =
          desc.includes(q) ||
          catNameHi.includes(q) ||
          catNameEn.includes(q) ||
          amt.includes(q) ||
          tx.date.includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [
    transactions,
    typeFilter,
    timeFilter,
    todayStr,
    currentMonthPrefix,
    selectedCategory,
    selectedMember,
    selectedPayment,
    searchQuery,
    categories
  ]);

  // Group by date
  const groupedByDate = useMemo(() => {
    const groups: Record<string, Transaction[]> = {};
    filteredTransactions.forEach(tx => {
      if (!groups[tx.date]) {
        groups[tx.date] = [];
      }
      groups[tx.date].push(tx);
    });

    // Sort dates descending
    return Object.keys(groups)
      .sort((a, b) => b.localeCompare(a))
      .map(date => ({
        date,
        transactions: groups[date],
        totalExpense: groups[date]
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0),
        totalIncome: groups[date]
          .filter(t => t.type === 'income')
          .reduce((sum, t) => sum + t.amount, 0)
      }));
  }, [filteredTransactions]);

  // Total summary of current filtered view
  const totalSummary = useMemo(() => {
    let inc = 0;
    let exp = 0;
    filteredTransactions.forEach(t => {
      if (t.type === 'income') inc += t.amount;
      else exp += t.amount;
    });
    return { income: inc, expense: exp, balance: inc - exp };
  }, [filteredTransactions]);

  const clearAllFilters = () => {
    setTypeFilter('all');
    setTimeFilter('all');
    setSelectedCategory('all');
    setSelectedMember('all');
    setSelectedPayment('all');
    setSearchQuery('');
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    selectedMember !== 'all' ||
    selectedPayment !== 'all' ||
    timeFilter !== 'all' ||
    searchQuery.trim().length > 0;

  return (
    <div className="space-y-4 pb-8">
      {/* Search & Filter Header */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-9 pr-8 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 bg-slate-50"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-xl border transition flex items-center gap-1 text-xs font-semibold ${
              showFilters || hasActiveFilters
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Filter className="w-4 h-4" />
            <span className="hidden sm:inline">{language === 'hi' ? 'फ़िल्टर' : 'Filter'}</span>
          </button>
        </div>

        {/* Type Segmented Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setTypeFilter('all')}
            className={`py-1.5 text-xs font-bold rounded-lg transition ${
              typeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            {t.all} ({filteredTransactions.length})
          </button>
          <button
            onClick={() => setTypeFilter('expense')}
            className={`py-1.5 text-xs font-bold rounded-lg transition ${
              typeFilter === 'expense' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
            }`}
          >
            - {t.expenses}
          </button>
          <button
            onClick={() => setTypeFilter('income')}
            className={`py-1.5 text-xs font-bold rounded-lg transition ${
              typeFilter === 'income' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
            }`}
          >
            + {t.income}
          </button>
        </div>

        {/* Time Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] font-semibold text-slate-400 mr-1 shrink-0">
            {language === 'hi' ? 'समय:' : 'Period:'}
          </span>
          {[
            { id: 'all', label: t.all },
            { id: 'daily', label: t.daily },
            { id: 'weekly', label: t.weekly },
            { id: 'monthly', label: t.monthly }
          ].map(tf => (
            <button
              key={tf.id}
              onClick={() => setTimeFilter(tf.id as typeof timeFilter)}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition ${
                timeFilter === tf.id
                  ? 'bg-emerald-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tf.label}
            </button>
          ))}
        </div>

        {/* Advanced Filters Expandable Drawer */}
        {showFilters && (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {t.filterByCategory}
              </label>
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="all">{t.all} {t.category}</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>
                    {language === 'hi' ? c.nameHi : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {t.filterByMember}
              </label>
              <select
                value={selectedMember}
                onChange={e => setSelectedMember(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="all">{t.all} {language === 'hi' ? 'सदस्य' : 'Members'}</option>
                {familyMembers.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {t.filterByPayment}
              </label>
              <select
                value={selectedPayment}
                onChange={e => setSelectedPayment(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="all">{t.all} {language === 'hi' ? 'माध्यम' : 'Modes'}</option>
                <option value="upi">UPI</option>
                <option value="cash">{t.cash}</option>
                <option value="card">{t.card}</option>
                <option value="bank_transfer">{t.bank_transfer}</option>
                <option value="other">{t.other}</option>
              </select>
            </div>

            {hasActiveFilters && (
              <div className="sm:col-span-3 pt-1 flex justify-end">
                <button
                  onClick={clearAllFilters}
                  className="text-xs font-semibold text-rose-600 hover:underline"
                >
                  {t.clearFilters}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Filtered View Summary Strip */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between text-xs">
        <div>
          <span className="text-slate-400">{t.totalEntries}: </span>
          <span className="font-bold text-slate-800">{filteredTransactions.length}</span>
        </div>
        <div className="flex items-center gap-3 tabular-nums">
          <span className="text-emerald-700 font-bold">+ {formatRupee(totalSummary.income)}</span>
          <span className="text-rose-700 font-bold">- {formatRupee(totalSummary.expense)}</span>
        </div>
      </div>

      {/* Grouped Transaction Records by Date */}
      {groupedByDate.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Layers className="w-6 h-6" />
          </div>
          <p className="text-xs text-slate-500">{t.noTransactionsYet}</p>
          <button
            onClick={() => setActiveModal('add-expense')}
            className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition"
          >
            + {t.quickAddExpense}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {groupedByDate.map(group => {
            const isToday = group.date === todayStr;
            const displayDate = isToday
              ? `${t.today} (${formatIndianDate(group.date, language)})`
              : formatIndianDate(group.date, language);

            return (
              <div
                key={group.date}
                className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden"
              >
                {/* Date Header Strip */}
                <div className="bg-slate-50 px-4 py-2 border-b border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{displayDate}</span>
                  </div>
                  <div className="flex items-center gap-2 tabular-nums text-[11px] font-semibold">
                    {group.totalIncome > 0 && (
                      <span className="text-emerald-700">+ {formatRupee(group.totalIncome)}</span>
                    )}
                    {group.totalExpense > 0 && (
                      <span className="text-rose-700">- {formatRupee(group.totalExpense)}</span>
                    )}
                  </div>
                </div>

                {/* Transactions in Date */}
                <div className="divide-y divide-slate-100">
                  {group.transactions.map(tx => {
                    const cat = categories.find(c => c.id === tx.categoryId);
                    const member = familyMembers.find(m => m.id === tx.familyMemberId);
                    const isIncome = tx.type === 'income';

                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 flex items-center justify-between hover:bg-slate-50 transition"
                      >
                        <div
                          onClick={() => {
                            setEditingTransaction(tx);
                            setActiveModal(isIncome ? 'add-income' : 'add-expense');
                          }}
                          className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                        >
                          <div
                            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                            style={{
                              backgroundColor: cat ? `${cat.color}15` : '#e2e8f0',
                              color: cat ? cat.color : '#475569'
                            }}
                          >
                            <CategoryIcon name={cat ? cat.icon : 'Receipt'} className="w-5 h-5" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs sm:text-sm font-bold text-slate-800 truncate">
                              {tx.description}
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                              <span>{language === 'hi' ? cat?.nameHi : cat?.nameEn}</span>
                              {member && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="text-emerald-700 font-medium">{member.name}</span>
                                </>
                              )}
                              <span aria-hidden="true">·</span>
                              <span className="uppercase text-[10px] bg-slate-100 px-1.5 py-0.2 rounded font-mono">
                                {tx.paymentMode}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Amount & Quick Delete */}
                        <div className="flex items-center gap-2 shrink-0 ml-3">
                          <div
                            onClick={() => {
                              setEditingTransaction(tx);
                              setActiveModal(isIncome ? 'add-income' : 'add-expense');
                            }}
                            className="text-right cursor-pointer"
                          >
                            <div
                              className={`text-sm sm:text-base font-extrabold tabular-nums ${
                                isIncome ? 'text-emerald-700' : 'text-slate-900'
                              }`}
                            >
                              {isIncome ? '+' : '-'} {formatRupee(tx.amount)}
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              if (window.confirm(t.confirmDelete)) {
                                deleteTransaction(tx.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Add Expense Quick Button on Mobile */}
      <div className="fixed bottom-20 right-4 sm:hidden z-30 flex flex-col gap-2">
        <button
          onClick={() => setActiveModal('add-income')}
          className="w-11 h-11 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg active:scale-95 transition"
          title={t.quickAddIncome}
        >
          <span className="text-lg font-bold">+</span>
        </button>
        <button
          onClick={() => setActiveModal('add-expense')}
          className="w-13 h-13 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-xl active:scale-95 transition"
          title={t.quickAddExpense}
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
