import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryType } from '../types';
import { filterProfanity } from '../utils/security';
import { 
  X, 
  Dices, 
  ShieldCheck, 
  AlertTriangle, 
  Send, 
  Lock, 
  Globe 
} from 'lucide-react';

const CATEGORIES: { id: CategoryType; label: string; icon: string }[] = [
  { id: 'secret', label: 'Secret', icon: '🤫' },
  { id: 'love', label: 'Love & Crush', icon: '❤️' },
  { id: 'funny', label: 'Humor & Fun', icon: '😂' },
  { id: 'stress', label: 'Study Stress', icon: '📚' },
  { id: 'hottake', label: 'Hot Take', icon: '🔥' },
  { id: 'campus', label: 'Campus Life', icon: '🏛️' },
];

export const CreateConfessionModal: React.FC = () => {
  const { 
    isCreateOpen, 
    setIsCreateOpen, 
    addConfession, 
    user, 
    rerollPersona 
  } = useApp();

  const [content, setContent] = useState('');
  const [category, setCategory] = useState<CategoryType>('secret');
  const [isCampusOnly, setIsCampusOnly] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCreateOpen) return null;

  // Real-time moderation safety check
  const safetyCheck = filterProfanity(content);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      setErrorMsg('Please write something to confess!');
      return;
    }
    if (content.length < 10) {
      setErrorMsg('Confession is too short. Share at least a sentence.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');
    const res = addConfession(content, category, isCampusOnly);
    setIsSubmitting(false);

    if (res.success) {
      setContent('');
      setIsCreateOpen(false);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-lg bg-[#0e111d] border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-cyan-900/30 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">🤫</span>
            <div>
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-100">
                Drop Campus Gossip
              </h3>
              <p className="text-[11px] text-slate-400">
                Zero identity leakage. 100% anonymous.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCreateOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Persona Bar: Reroll Avatar */}
        <div className="flex items-center justify-between p-3 my-3 bg-slate-900/80 border border-slate-800 rounded-2xl">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-cyan-950/50 border border-cyan-500/40 flex items-center justify-center text-lg">
              {user.avatarEmoji}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-cyan-300">
                  {user.avatarName}
                </span>
                <span className="text-[10px] font-mono text-slate-500">
                  {user.secretHashId}
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Your randomized disguise for this session
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={rerollPersona}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 transition-all active:scale-95"
          >
            <Dices className="w-3.5 h-3.5 text-cyan-400" />
            <span>Reroll</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Confession Textarea */}
          <div className="space-y-1">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's your deepest secret, campus crush, or hilarious fail? Let it out..."
              rows={4}
              maxLength={600}
              className="w-full bg-slate-950/90 border border-slate-800 rounded-2xl p-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/60 focus:ring-1 focus:ring-cyan-500/30 transition-all resize-none font-sans"
            />
            
            {/* Character count & Safety Status */}
            <div className="flex items-center justify-between text-[11px] px-1">
              <div className="flex items-center gap-1">
                {safetyCheck.isClean ? (
                  <span className="flex items-center gap-1 text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Safe & Censor-Clean</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-amber-400">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Offensive words will be auto-masked (***)</span>
                  </span>
                )}
              </div>
              <span className="text-slate-500 font-mono">
                {content.length}/600
              </span>
            </div>
          </div>

          {/* Category Selector Tabs */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Select Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {CATEGORIES.map(cat => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`flex items-center gap-1.5 p-2 rounded-xl border text-xs font-medium transition-all ${
                    category === cat.id 
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 shadow-sm shadow-cyan-500/20' 
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <span>{cat.icon}</span>
                  <span className="truncate">{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Audience Scope: Campus Only vs Global */}
          <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-xl ${isCampusOnly ? 'bg-indigo-500/20 text-indigo-400' : 'bg-cyan-500/20 text-cyan-400'}`}>
                {isCampusOnly ? <Lock className="w-4 h-4" /> : <Globe className="w-4 h-4" />}
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-200">
                  {isCampusOnly ? `Campus Only (${user.collegeName ? user.collegeName.split(' ')[0] : 'Campus'})` : 'Global Explore Feed'}
                </p>
                <p className="text-[10px] text-slate-400">
                  {isCampusOnly ? 'Only students from your verified college can see this' : 'Visible to all verified students across universities'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsCampusOnly(!isCampusOnly)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${isCampusOnly ? 'bg-cyan-500 justify-end' : 'bg-slate-700 justify-start'}`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md transition-transform" />
            </button>
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setIsCreateOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !content.trim()}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-cyan-500/25 disabled:opacity-50 flex items-center gap-1.5 active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post Anonymously</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
