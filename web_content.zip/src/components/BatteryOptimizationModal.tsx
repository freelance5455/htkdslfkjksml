import React, { useState } from 'react';
import { X, BatteryCharging, Smartphone, CheckCircle2 } from 'lucide-react';

interface BatteryOptimizationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BatteryOptimizationModal: React.FC<BatteryOptimizationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedBrand, setSelectedBrand] = useState<'samsung' | 'xiaomi' | 'pixel' | 'oneplus'>('samsung');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-3xl border border-emerald-900/60 bg-slate-900 shadow-2xl text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <BatteryCharging className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Android Background & Alarm Reliability
              </h2>
              <p className="text-xs text-slate-400">Prevent system killers from delaying Adhan alerts</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-800 bg-slate-950 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Brand Selector */}
        <div className="p-6 border-b border-slate-800/80 bg-slate-950/30">
          <div className="text-xs font-semibold text-slate-300 mb-2">Select your phone brand:</div>
          <div className="grid grid-cols-4 gap-2">
            {[
              { id: 'samsung', label: 'Samsung' },
              { id: 'xiaomi', label: 'Xiaomi / Redmi' },
              { id: 'oneplus', label: 'OnePlus / Oppo' },
              { id: 'pixel', label: 'Google Pixel' },
            ].map(brand => (
              <button
                key={brand.id}
                type="button"
                onClick={() => setSelectedBrand(brand.id as 'samsung' | 'xiaomi' | 'pixel' | 'oneplus')}
                className={`rounded-xl py-2 px-2 text-center text-xs font-semibold transition cursor-pointer border ${
                  selectedBrand === brand.id
                    ? 'border-emerald-500 bg-emerald-950 text-emerald-300'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700'
                }`}
              >
                {brand.label}
              </button>
            ))}
          </div>
        </div>

        {/* Instructions Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {selectedBrand === 'samsung' && (
            <div className="space-y-3 text-xs text-slate-300">
              <h3 className="font-bold text-sm text-white">Samsung One UI Setup:</h3>
              <ol className="list-decimal list-inside space-y-2.5 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <li>Open <strong>Settings → Apps → Salat Sathi</strong> (or your browser app).</li>
                <li>Tap <strong>Battery</strong> and select <span className="text-emerald-400 font-semibold">Unrestricted</span> (allows alarms to trigger when screen is locked).</li>
                <li>Go to <strong>Settings → Battery → Background usage limits</strong>. Ensure Salat Sathi is NOT in "Sleeping apps" or "Deep sleeping apps".</li>
                <li>Add Salat Sathi to <strong>Never sleeping apps</strong> list.</li>
              </ol>
            </div>
          )}

          {selectedBrand === 'xiaomi' && (
            <div className="space-y-3 text-xs text-slate-300">
              <h3 className="font-bold text-sm text-white">Xiaomi MIUI / HyperOS Setup:</h3>
              <ol className="list-decimal list-inside space-y-2.5 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <li>Long-press the Salat Sathi icon on home screen and tap <strong>App Info</strong>.</li>
                <li>Enable <span className="text-emerald-400 font-semibold">Autostart</span> (crucial for automatic rescheduling after phone restart).</li>
                <li>Under <strong>Battery Saver</strong>, select <span className="text-emerald-400 font-semibold">No restrictions</span>.</li>
                <li>In App permissions, ensure <strong>Notifications</strong> and <strong>Display pop-up windows while running in the background</strong> are Allowed.</li>
              </ol>
            </div>
          )}

          {selectedBrand === 'oneplus' && (
            <div className="space-y-3 text-xs text-slate-300">
              <h3 className="font-bold text-sm text-white">OnePlus OxygenOS / Oppo ColorOS Setup:</h3>
              <ol className="list-decimal list-inside space-y-2.5 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <li>Open <strong>Settings → Apps → App Management → Salat Sathi</strong>.</li>
                <li>Tap <strong>Battery usage</strong> and enable <span className="text-emerald-400 font-semibold">Allow background activity</span> and <strong>Allow auto-launch</strong>.</li>
                <li>Go to <strong>Settings → Battery → Advanced settings → Optimize battery use</strong> and set Salat Sathi to <strong>Don't optimize</strong>.</li>
              </ol>
            </div>
          )}

          {selectedBrand === 'pixel' && (
            <div className="space-y-3 text-xs text-slate-300">
              <h3 className="font-bold text-sm text-white">Google Pixel / Stock Android Setup:</h3>
              <ol className="list-decimal list-inside space-y-2.5 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <li>Open <strong>Settings → Apps → Salat Sathi</strong>.</li>
                <li>Tap <strong>App battery usage</strong> and select <span className="text-emerald-400 font-semibold">Unrestricted</span>.</li>
                <li>Ensure <strong>Alarms & reminders</strong> permission is toggled to <strong>Allowed</strong>.</li>
              </ol>
            </div>
          )}

          <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-4 text-xs text-emerald-300 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong>Reboot Auto-Rescheduling:</strong> Salat Sathi stores your preferences locally in persistent storage. As soon as your device boots and the service worker initializes, the daily alarm schedule automatically activates without manual intervention.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-950/80 px-6 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
