import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  Coffee,
  BookOpen,
} from 'lucide-react';
import { playNotificationChime, showBrowserNotification } from '../../utils/notifications';

export const FocusTimer: React.FC = () => {
  const { subjects, addScheduleItem } = useApp();

  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [durationMinutes, setDurationMinutes] = useState<number>(45);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(45 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.id || '');

  // Keep track of finished notification
  const [completedMessage, setCompletedMessage] = useState<string | null>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            playNotificationChime(mode === 'study' ? 'success' : 'timer');

            const title = mode === 'study' ? 'أحسنت! انتهت جلسة المذاكرة' : 'انتهت فترة الراحة، حان وقت العودة';
            const body = mode === 'study' ? 'خذ استراحة قصيرة واشرب كوب ماء' : 'استعد للتركيز في الجلسة التالية';
            showBrowserNotification(title, { body });

            if (mode === 'study') {
              const sub = subjects.find((s) => s.id === selectedSubjectId);
              setCompletedMessage(`رائع! أنجزت ${durationMinutes} دقيقة مذاكرة في مادة ${sub?.name || 'العامة'}.`);
            }

            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, mode, durationMinutes, selectedSubjectId, subjects]);

  const handleSetDuration = (mins: number, newMode: 'study' | 'break' = 'study') => {
    setIsRunning(false);
    setMode(newMode);
    setDurationMinutes(mins);
    setSecondsRemaining(mins * 60);
    setCompletedMessage(null);
  };

  const handleReset = () => {
    setIsRunning(false);
    setSecondsRemaining(durationMinutes * 60);
    setCompletedMessage(null);
  };

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const progressPercent = Math.round(
    ((durationMinutes * 60 - secondsRemaining) / (durationMinutes * 60)) * 100
  );

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Title */}
      <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div className="flex items-center gap-2">
          <Timer className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          <h2 className="text-xl font-bold text-slate-900 dark:text-rose-50">
            مؤقت التركيز الذكي (Smart Focus & Pomodoro)
          </h2>
        </div>
        <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-1">
          جلسات تركيز عميقة مخصصة مع فترات راحة منتظمة وتنبيهات صوتية هادئة
        </p>
      </div>

      {/* Timer Main Stage */}
      <div className="bg-white dark:bg-[#180d15] rounded-3xl border border-rose-100 dark:border-rose-950/60 p-8 text-center transition-colors shadow-xs space-y-6">
        {/* Preset Modes Buttons */}
        <div className="flex items-center justify-center flex-wrap gap-2">
          <button
            onClick={() => handleSetDuration(25, 'study')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
              mode === 'study' && durationMinutes === 25
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 border border-rose-100/60 dark:border-rose-900/30'
            }`}
          >
            25 دقيقة (بومودورو)
          </button>

          <button
            onClick={() => handleSetDuration(45, 'study')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
              mode === 'study' && durationMinutes === 45
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 border border-rose-100/60 dark:border-rose-900/30'
            }`}
          >
            45 دقيقة (تركيز عميق)
          </button>

          <button
            onClick={() => handleSetDuration(60, 'study')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
              mode === 'study' && durationMinutes === 60
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 border border-rose-100/60 dark:border-rose-900/30'
            }`}
          >
            60 دقيقة (جلسة متكاملة)
          </button>

          <button
            onClick={() => handleSetDuration(5, 'break')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
              mode === 'break' && durationMinutes === 5
                ? 'bg-pink-600 text-white shadow-xs'
                : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 border border-rose-100/60 dark:border-rose-900/30'
            }`}
          >
            5 دقائق راحة
          </button>

          <button
            onClick={() => handleSetDuration(15, 'break')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
              mode === 'break' && durationMinutes === 15
                ? 'bg-pink-600 text-white shadow-xs'
                : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 border border-rose-100/60 dark:border-rose-900/30'
            }`}
          >
            15 دقيقة راحة طويلة
          </button>
        </div>

        {/* Subject Assignment */}
        {mode === 'study' && (
          <div className="max-w-xs mx-auto">
            <label className="block text-xs font-semibold text-slate-500 dark:text-rose-200/70 mb-1">
              المادة قيد الاستذكار:
            </label>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/30 dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Digital Clock Display */}
        <div className="py-6">
          <div className="font-mono text-6xl sm:text-7xl font-extrabold tabular-nums tracking-wider text-rose-950 dark:text-rose-100">
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </div>
          <div className="text-xs font-semibold text-rose-500 dark:text-rose-300 mt-2">
            {mode === 'study' ? 'جلسة مذاكرة واستيعاب وردية' : 'وقت الراحة واستعادة النشاط'}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="max-w-md mx-auto w-full bg-rose-100/60 dark:bg-rose-950/60 h-3 rounded-full overflow-hidden p-0.5">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              mode === 'study'
                ? 'bg-gradient-to-r from-rose-500 to-pink-500'
                : 'bg-gradient-to-r from-pink-400 to-rose-300'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Controls: Play, Pause, Reset */}
        <div className="flex items-center justify-center gap-4 pt-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-8 py-3.5 rounded-2xl font-bold text-sm text-white shadow-lg transition-all flex items-center gap-2 ${
              isRunning
                ? 'bg-pink-700 hover:bg-pink-800 shadow-pink-700/25'
                : 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/30'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5" />
                <span>إيقاف مؤقت</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" />
                <span>بدء التركيز</span>
              </>
            )}
          </button>

          <button
            onClick={handleReset}
            className="p-3.5 rounded-2xl border border-rose-200 dark:border-rose-900/60 text-slate-600 dark:text-rose-200 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
            title="إعادة التعيين"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Completed Announcement */}
        {completedMessage && (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-semibold flex items-center justify-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-rose-600" />
            <span>{completedMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};
