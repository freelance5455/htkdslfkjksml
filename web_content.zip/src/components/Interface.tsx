import { useEffect, useId, useRef } from 'react';
import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

export function LeafMark({ size = 28 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 36 36" fill="none" aria-hidden="true"><path d="M18.4 29.8C6.8 29.1 4.2 19.7 7.1 8.2c9.8.5 17.2 5.6 14.1 14.7" fill="currentColor" opacity=".9" /><path d="M18.2 29.8c-1.9-10.9 3.9-18.4 14.4-20-1.3 10.6-4 18.1-14.4 20Z" fill="currentColor" opacity=".65" /><path d="m12.1 15.5 6.1 14.3L27 17.5" stroke="var(--paper, #f8f8f1)" strokeWidth="1.1" strokeLinecap="round" /></svg>;
}

export function Brand({ light = false }: { light?: boolean }) {
  return <span className={`brand ${light ? 'brand-light' : ''}`}><LeafMark size={32} /><span>rimba<span className="brand-dot">.</span><small>VIRTUAL NATURE</small></span></span>;
}

export function LandscapeDrawing() {
  return <svg className="landscape-drawing" viewBox="0 0 220 105" fill="none" aria-hidden="true"><path d="m0 77 37-21 22 11L105 8l43 58 27-24 45 35M61 66l24-13 20-45 13 42 30 16M86 53l19-12 13 9M7 84c27-10 40-2 62-1s45-10 72-7 45 9 71 4M27 96c25-7 42-1 64-3s40-5 62-2 35 5 52 1" stroke="currentColor" strokeWidth=".8" /><path d="M19 76V53m-9 12 9-12 9 12m-16 4 7-10 7 10M182 76V55m-8 11 8-11 8 11m-14 5 6-10 6 10M198 78V47m-10 15 10-15 10 15m-18 7 8-14 8 14" stroke="currentColor" strokeWidth="1" /><circle cx="155" cy="22" r="8" stroke="currentColor" strokeWidth=".8" /></svg>;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  return <button type="button" className={`toggle ${checked ? 'is-on' : ''}`} role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)}><span /></button>;
}

export function Slider({ label, value, min = 0, max = 100, step = 1, suffix = '%', onChange }: { label: string; value: number; min?: number; max?: number; step?: number; suffix?: string; onChange: (value: number) => void }) {
  const id = useId();
  return <div className="slider-field"><div className="slider-label"><label htmlFor={id}>{label}</label><output htmlFor={id}>{Number.isInteger(value) ? value : value.toFixed(1)}{suffix}</output></div><input id={id} aria-label={label} type="range" min={min} max={max} step={step} value={value} onChange={event => onChange(Number(event.target.value))} style={{ '--range-progress': `${(value - min) / (max - min) * 100}%` } as React.CSSProperties} /></div>;
}

export function Waveform({ playing = false, small = false }: { playing?: boolean; small?: boolean }) {
  return <span className={`waveform ${playing ? 'is-playing' : ''} ${small ? 'small' : ''}`} aria-hidden="true">{Array.from({ length: small ? 15 : 35 }, (_, i) => <span key={i} style={{ height: `${18 + Math.sin(i * 1.7) ** 2 * 72}%`, animationDelay: `${i * -0.13}s` }} />)}</span>;
}

export function Dialog({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = ref.current;
    dialog?.showModal();
    return () => dialog?.close();
  }, []);
  return <dialog ref={ref} className={`dialog ${wide ? 'dialog-wide' : ''}`} aria-labelledby={titleId} onCancel={event => { event.preventDefault(); onClose(); }} onClick={event => { if (event.target === ref.current) onClose(); }}><motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className="dialog-inner"><div className="dialog-header"><span id={titleId}>{title}</span><button className="icon-button" aria-label="Close dialog" onClick={onClose}><X size={20} /></button></div>{children}</motion.div></dialog>;
}