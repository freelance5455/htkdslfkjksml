import { useState } from "react";
import { Plus } from "lucide-react";
import { FAQS } from "../lib/data";

export default function Faq() {
  const [open, setOpen] = useState<number>(0);
  return (
    <section id="faq" className="scroll-mt-28 border-t border-white/5 bg-[#070c26]/60 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <p className="eyebrow">Preguntas frecuentes</p>
          <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">Todo claro,<br /><span className="grad-text">antes de descargar.</span></h2>
        </div>
        <div className="mt-10 grid gap-3 lg:grid-cols-2">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={i} className={`overflow-hidden rounded-2xl border transition-colors duration-300 ${isOpen ? "border-cyanx/30 bg-panel2" : "border-white/8 bg-white/[0.02]"}`}>
                <button
                  id={`faq-btn-${i}`}
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${i}`}
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="text-sm font-bold text-slate-100 sm:text-[15px]">{item.q}</span>
                  <Plus size={18} strokeWidth={2.5} className={`shrink-0 text-cyanx transition-transform duration-300 ${isOpen ? "rotate-45" : ""}`} aria-hidden="true" />
                </button>
                <div id={`faq-panel-${i}`} role="region" aria-labelledby={`faq-btn-${i}`} hidden={!isOpen}>
                  <p className="border-t border-white/5 px-5 pb-5 pt-3 text-sm leading-relaxed text-slate-400">{item.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
