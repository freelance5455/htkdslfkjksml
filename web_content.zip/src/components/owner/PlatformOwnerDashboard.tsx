import React, { useEffect, useState } from 'react';
import {
  ShieldAlert,
  Building2,
  Plus,
  Power,
  Users,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Clock,
  Send,
  X,
  Lock,
  ShieldCheck,
  Search,
  Activity,
  Trash2,
  Crown,
  Copy,
  AlertOctagon,
  RotateCcw,
  ExternalLink,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, updateDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Organization, SupportTicket, AuditLogEntry } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const PlatformOwnerDashboard: React.FC = () => {
  const { userProfile, reloadUserData, reauthenticateAdmin, isPlatformOwner } = useAuth();
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [allTickets, setAllTickets] = useState<SupportTicket[]>([]);
  const [platformLogs, setPlatformLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'orgs' | 'support' | 'audit' | 'settings'>('orgs');

  // Create Org Modal
  const [isNewOrgModalOpen, setIsNewOrgModalOpen] = useState(false);
  const [orgName, setOrgName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [accentColor, setAccentColor] = useState('#0284c7');

  // Suspend re-authentication modal
  const [suspendingOrg, setSuspendingOrg] = useState<Organization | null>(null);
  const [authPin, setAuthPin] = useState('');
  const [authError, setAuthError] = useState('');
  const [suspendingAction, setSuspendingAction] = useState(false);

  // Delete Organization modal (Requirement 9)
  const [deletingOrg, setDeletingOrg] = useState<Organization | null>(null);
  const [deleteConfirmPhrase, setDeleteConfirmPhrase] = useState('');
  const [deleteAuthPin, setDeleteAuthPin] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [isDeletingOrg, setIsDeletingOrg] = useState(false);

  // Transfer Platform Ownership modal (Requirement 8)
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferNewName, setTransferNewName] = useState('');
  const [transferNewEmail, setTransferNewEmail] = useState('');
  const [transferNewPhone, setTransferNewPhone] = useState('');
  const [transferAuthPin, setTransferAuthPin] = useState('');
  const [transferError, setTransferError] = useState('');
  const [transferSuccessData, setTransferSuccessData] = useState<{
    inviteUrl: string;
    expiresAt: string;
    message: string;
  } | null>(null);
  const [isTransferring, setIsTransferring] = useState(false);
  const [copiedInviteLink, setCopiedInviteLink] = useState(false);

  // Reset Application Data modal (Requirement 10)
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetConfirmPhrase, setResetConfirmPhrase] = useState('');
  const [resetAuthPin, setResetAuthPin] = useState('');
  const [resetError, setResetError] = useState('');
  const [resetSuccessMsg, setResetSuccessMsg] = useState('');
  const [isResettingData, setIsResettingData] = useState(false);

  // Support Reply state
  const [replyText, setReplyText] = useState<{ [id: string]: string }>({});

  const fetchPlatformData = async () => {
    setLoading(true);
    try {
      // 1. Organizations
      const orgSnap = await getDocs(collection(db, 'organizations'));
      const orgList: Organization[] = [];
      orgSnap.forEach((d) => orgList.push(d.data() as Organization));
      setOrganizations(orgList);

      // 2. All Support Tickets
      const tSnap = await getDocs(collection(db, 'support_tickets'));
      const tList: SupportTicket[] = [];
      tSnap.forEach((d) => tList.push(d.data() as SupportTicket));
      tList.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setAllTickets(tList);

      // 3. Platform Audit Logs
      const aSnap = await getDocs(query(collection(db, 'audit_logs'), limit(100)));
      const aList: AuditLogEntry[] = [];
      aSnap.forEach((d) => aList.push(d.data() as AuditLogEntry));
      aList.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      setPlatformLogs(aList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlatformData();
  }, []);

  const handleExecuteSuspend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!suspendingOrg) return;
    setAuthError('');

    const verified = await reauthenticateAdmin(authPin);
    if (!verified) {
      setAuthError('Authentication PIN / password incorrect. Verification failed.');
      return;
    }

    setSuspendingAction(true);
    const newStatus = suspendingOrg.status === 'active' ? 'suspended' : 'active';
    try {
      await updateDoc(doc(db, 'organizations', suspendingOrg.id), { status: newStatus });

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_plat_${Date.now()}`,
        orgId: suspendingOrg.id,
        userId: userProfile?.id || 'platform_owner',
        userName: userProfile?.displayName || 'Platform Owner',
        userRole: 'platform_owner',
        action: newStatus === 'suspended' ? 'SUSPEND_ORGANIZATION' : 'REACTIVATE_ORGANIZATION',
        module: 'Platform Administration',
        details: `Platform Owner ${newStatus === 'suspended' ? 'suspended' : 'reactivated'} tenant ${suspendingOrg.name} (${suspendingOrg.id}).`,
        targetId: suspendingOrg.id,
        targetName: suspendingOrg.name,
        result: 'warning',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setOrganizations((prev) =>
        prev.map((o) => (o.id === suspendingOrg.id ? { ...o, status: newStatus } : o))
      );
      setSuspendingOrg(null);
      setAuthPin('');
      await reloadUserData();
    } catch (err) {
      console.error(err);
      setAuthError('Failed to update organization status.');
    } finally {
      setSuspendingAction(false);
    }
  };

  const handleDeleteOrganization = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deletingOrg || !userProfile) return;
    setDeleteError('');

    const trimmedInput = deleteConfirmPhrase.trim();
    if (
      trimmedInput !== deletingOrg.name.trim() &&
      trimmedInput !== `DELETE ${deletingOrg.name.trim()}` &&
      trimmedInput !== 'DELETE'
    ) {
      setDeleteError(`Please type exact confirmation phrase: DELETE ${deletingOrg.name}`);
      return;
    }

    const verified = await reauthenticateAdmin(deleteAuthPin);
    if (!verified) {
      setDeleteError('Authentication PIN / password incorrect. Verification failed.');
      return;
    }

    setIsDeletingOrg(true);
    try {
      const res = await fetch('/api/org/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orgId: deletingOrg.id,
          callerEmail: userProfile.email,
          callerUid: userProfile.id,
          callerRole: userProfile.role,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to delete organization.');
      }

      setOrganizations((prev) => prev.filter((o) => o.id !== deletingOrg.id));
      setDeletingOrg(null);
      setDeleteConfirmPhrase('');
      setDeleteAuthPin('');
      await reloadUserData();
      await fetchPlatformData();
    } catch (err: any) {
      console.error(err);
      setDeleteError(err?.message || 'Failed to delete organization.');
    } finally {
      setIsDeletingOrg(false);
    }
  };

  const handleInitiateTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;
    setTransferError('');
    setTransferSuccessData(null);

    if (!transferNewEmail.trim() || !transferNewName.trim()) {
      setTransferError('Full name and email are required for the new Platform Owner.');
      return;
    }

    if (transferNewEmail.trim().toLowerCase() === userProfile.email.toLowerCase()) {
      setTransferError('The new owner email cannot be identical to your current Platform Owner email.');
      return;
    }

    const verified = await reauthenticateAdmin(transferAuthPin);
    if (!verified) {
      setTransferError('Authentication PIN / password incorrect. Verification failed.');
      return;
    }

    setIsTransferring(true);
    try {
      const res = await fetch('/api/owner/transfer-invite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerEmail: userProfile.email,
          callerUid: userProfile.id,
          newOwnerName: transferNewName.trim(),
          newOwnerEmail: transferNewEmail.trim().toLowerCase(),
          newOwnerPhone: transferNewPhone.trim(),
          callerPin: transferAuthPin,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate ownership transfer.');
      }

      setTransferSuccessData({
        inviteUrl: data.inviteUrl,
        expiresAt: data.expiresAt,
        message: data.message,
      });
      setTransferAuthPin('');
    } catch (err: any) {
      console.error(err);
      setTransferError(err?.message || 'Failed to initiate platform ownership transfer.');
    } finally {
      setIsTransferring(false);
    }
  };

  const handleResetApplicationData = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;
    setResetError('');
    setResetSuccessMsg('');

    if (resetConfirmPhrase.trim() !== 'RESET FIELDFLOW DATA') {
      setResetError('Please type exact confirmation phrase: RESET FIELDFLOW DATA');
      return;
    }

    const verified = await reauthenticateAdmin(resetAuthPin);
    if (!verified) {
      setResetError('Authentication PIN / password incorrect. Verification failed.');
      return;
    }

    setIsResettingData(true);
    try {
      const res = await fetch('/api/owner/reset-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerEmail: userProfile.email,
          callerUid: userProfile.id,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to reset application data.');
      }

      setResetSuccessMsg(data.message || 'Production data reset completed successfully.');
      setResetConfirmPhrase('');
      setResetAuthPin('');
      await fetchPlatformData();
      await reloadUserData();
    } catch (err: any) {
      console.error(err);
      setResetError(err?.message || 'Failed to execute application reset.');
    } finally {
      setIsResettingData(false);
    }
  };

  const handleCreateOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgName.trim()) return;

    const cleanAdminEmail = adminEmail.trim().toLowerCase();
    const orgId = `org_${orgName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now()}`;
    const newOrg: Organization = {
      id: orgId,
      name: orgName.trim(),
      status: 'active',
      accentColor,
      createdAt: new Date().toISOString(),
      createdBy: cleanAdminEmail || userProfile?.email || 'Platform Owner',
      kpiSettings: {
        attendanceWeight: 25,
        visitWeight: 35,
        taskWeight: 25,
        onTimeWeight: 15,
      },
    };

    try {
      await setDoc(doc(db, 'organizations', orgId), removeUndefinedFields(newOrg));

      // If an initial Main Admin email was specified, link any matching user account to this organization
      if (cleanAdminEmail) {
        const uSnap = await getDocs(query(collection(db, 'users'), where('email', '==', cleanAdminEmail)));
        for (const uDoc of uSnap.docs) {
          const uData = uDoc.data();
          await updateDoc(doc(db, 'users', uDoc.id), {
            organizationId: orgId,
            ...(uData.role !== 'platform_owner' ? { role: 'org_admin' } : {}),
            updatedAt: new Date().toISOString(),
          });
        }
      }

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_org_create_${Date.now()}`,
        orgId,
        userId: userProfile?.id || 'platform_owner',
        userName: userProfile?.displayName || 'Platform Owner',
        userRole: 'platform_owner',
        action: 'CREATE_ORGANIZATION',
        module: 'Platform Multi-Tenant',
        details: `Platform Owner provisioned new customer organization ${newOrg.name}.`,
        targetId: orgId,
        targetName: newOrg.name,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setOrganizations((prev) => [...prev, newOrg]);
      setIsNewOrgModalOpen(false);
      setOrgName('');
      setAdminEmail('');
      await reloadUserData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleOwnerSupportReply = async (ticket: SupportTicket) => {
    const text = replyText[ticket.id]?.trim();
    if (!text) return;

    const replies = ticket.replies || [];
    const newReply = {
      id: `rep_owner_${Date.now()}`,
      sender: 'FieldFlow Platform Staff',
      isPlatformStaff: true,
      text,
      createdAt: new Date().toISOString(),
    };

    const updated: SupportTicket = {
      ...ticket,
      status: 'waiting_for_customer',
      replies: [...replies, newReply],
      updatedAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'support_tickets', ticket.id), removeUndefinedFields(updated));
      setAllTickets((prev) => prev.map((t) => (t.id === ticket.id ? updated : t)));
      setReplyText((prev) => ({ ...prev, [ticket.id]: '' }));
    } catch (err) {
      console.error(err);
    }
  };

  const handleResolveTicket = async (ticket: SupportTicket) => {
    try {
      await updateDoc(doc(db, 'support_tickets', ticket.id), { status: 'resolved' });
      setAllTickets((prev) =>
        prev.map((t) => (t.id === ticket.id ? { ...t, status: 'resolved' } : t))
      );
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-950 rounded-2xl p-6 text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-500/30 border border-purple-400 text-purple-200 font-bold text-xs uppercase tracking-wider">
              👑 Platform Owner Console
            </span>
          </div>
          <h1 className="text-xl font-black mt-2">FieldFlow Master Administration</h1>
          <p className="text-xs text-purple-200 mt-1 max-w-xl">
            Authenticated Platform Authority: <strong>lunashine2010@gmail.com</strong>. Provision customer tenants, suspend defaulting workspaces, respond to global support tickets, and inspect cross-tenant audit trails.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setIsNewOrgModalOpen(true)}
            className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Organization</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-white p-1 rounded-2xl border border-slate-200 shadow-xs text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setActiveTab('orgs')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 ${
            activeTab === 'orgs' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Customer Organizations ({organizations.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('support')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 ${
            activeTab === 'support' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Platform Support Desk ({allTickets.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 ${
            activeTab === 'audit' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Platform Audit Trail</span>
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 ${
            activeTab === 'settings' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Infrastructure & Authority</span>
        </button>
      </div>

      {/* TAB 1: ORGANIZATIONS */}
      {activeTab === 'orgs' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 font-bold text-xs text-slate-800 flex items-center justify-between">
            <span>Customer Organizations Registry</span>
            <span className="text-[11px] text-slate-500">Multi-Tenant Isolated Boundaries</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Company Name</th>
                  <th className="p-3.5">Org ID</th>
                  <th className="p-3.5">Created Date</th>
                  <th className="p-3.5">Created By</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Access Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {organizations.map((org) => (
                  <tr key={org.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs"
                          style={{ backgroundColor: org.accentColor || '#0284c7' }}
                        >
                          {org.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{org.name}</div>
                          <div className="text-[10px] text-slate-400">Commercial Tenant</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5 font-mono text-slate-600 text-[11px]">{org.id}</td>
                    <td className="p-3.5 text-slate-600">{new Date(org.createdAt).toLocaleDateString()}</td>
                    <td className="p-3.5 text-slate-600">{org.createdBy}</td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          org.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {org.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSuspendingOrg(org);
                            setAuthPin('');
                            setAuthError('');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 ${
                            org.status === 'active'
                              ? 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" />
                          <span>{org.status === 'active' ? 'Suspend' : 'Reactivate'}</span>
                        </button>
                        <button
                          onClick={() => {
                            setDeletingOrg(org);
                            setDeleteConfirmPhrase('');
                            setDeleteAuthPin('');
                            setDeleteError('');
                          }}
                          className="px-2.5 py-1 rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200"
                          title="Delete Organization and isolated tenant data"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: SUPPORT DESK */}
      {activeTab === 'support' && (
        <div className="space-y-3">
          {allTickets.map((t) => (
            <div key={t.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs px-2 py-0.5 rounded-md bg-purple-100 text-purple-800">
                      {t.orgName}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">{t.subject}</h3>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Submitted by {t.submittedBy} ({t.submittedByEmail}) on {new Date(t.createdAt).toLocaleDateString()}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 capitalize">
                    {t.status.replace(/_/g, ' ')}
                  </span>
                  {t.status !== 'resolved' && (
                    <button
                      onClick={() => handleResolveTicket(t)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] hover:bg-emerald-700 shadow-xs"
                    >
                      Mark Resolved
                    </button>
                  )}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700 leading-relaxed">
                {t.description}
              </div>

              {/* Replies */}
              {t.replies && t.replies.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  {t.replies.map((r) => (
                    <div
                      key={r.id}
                      className={`p-2.5 rounded-xl text-xs ${
                        r.isPlatformStaff
                          ? 'bg-purple-50 border border-purple-200 text-purple-900 font-medium'
                          : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      <div className="font-bold text-[11px] flex items-center justify-between">
                        <span>{r.sender}</span>
                        <span className="text-[10px] text-slate-400 font-normal">
                          {new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className="mt-0.5">{r.text}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Reply as Platform Owner */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Official Platform Staff response..."
                  value={replyText[t.id] || ''}
                  onChange={(e) => setReplyText({ ...replyText, [t.id]: e.target.value })}
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden"
                />
                <button
                  onClick={() => handleOwnerSupportReply(t)}
                  disabled={!replyText[t.id]?.trim()}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white rounded-xl font-bold text-xs flex items-center gap-1 shadow-xs"
                >
                  <Send className="w-3 h-3" />
                  <span>Send Staff Response</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: PLATFORM AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900">Platform Cross-Tenant Security Audit Log</h3>
              <p className="text-[11px] text-slate-500">Live feed of administrative, security, and lifecycle mutations</p>
            </div>
            <span className="text-xs font-bold text-slate-600">{platformLogs.length} Events</span>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px] tracking-wider sticky top-0">
                <tr>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Actor / Role</th>
                  <th className="p-3">Tenant ID</th>
                  <th className="p-3">Action</th>
                  <th className="p-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {platformLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 font-semibold text-slate-800">
                      <div>{log.userName}</div>
                      <div className="text-[10px] text-purple-700 uppercase font-mono">{log.userRole || 'Admin'}</div>
                    </td>
                    <td className="p-3 font-mono text-slate-600 text-[11px]">{log.orgId}</td>
                    <td className="p-3 font-bold text-slate-900">{log.action}</td>
                    <td className="p-3 text-slate-600 leading-snug">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: SETTINGS & INFRASTRUCTURE */}
      {activeTab === 'settings' && (
        <div className="space-y-4 max-w-3xl text-xs">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900">Platform Security Invariants</h3>
            <div className="p-4 bg-purple-50 rounded-xl border border-purple-200 space-y-2 text-purple-950">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-700" />
                <span>Active Master Platform Owner: {userProfile?.email || 'Active Authority'}</span>
              </div>
              <p className="leading-relaxed text-[11px]">
                Master authority is anchored to your authenticated account. Customer tenant administrators are strictly restricted from elevating privileges to Platform Owner.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-800">Platform Ownership Integrity Policy</h4>
              <ul className="list-disc pl-4 space-y-1 text-slate-600 text-[11px]">
                <li>No customer tenant administrator UI contains an ownership-transfer or global purge option.</li>
                <li>Attempted unauthorized role escalations are blocked on the server and audit-logged.</li>
                <li>All sensitive operations (ownership transfer, company deletion, data reset) require secondary administrative re-authentication.</li>
              </ul>
            </div>
          </div>

          {/* Action Card: Transfer Platform Ownership (Requirement 9) */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                  <Crown className="w-4 h-4" />
                </div>
                <h4 className="font-bold text-sm text-slate-900">Transfer Platform Ownership</h4>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed max-w-xl">
                Safely transfer root governance of the FieldFlow platform to an eligible, authenticated administrator. Generates a secure single-use expiring invitation link and records an immutable audit log.
              </p>
            </div>
            <button
              onClick={() => {
                setIsTransferModalOpen(true);
                setTransferError('');
                setTransferSuccessData(null);
                setTransferAuthPin('');
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shrink-0 shadow-xs cursor-pointer"
            >
              <Crown className="w-3.5 h-3.5" />
              <span>Transfer Ownership</span>
            </button>
          </div>

          {/* Action Card: Reset Application Data (Requirement 11) */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <h4 className="font-bold text-sm text-slate-900">Reset Application / Clean Production Data</h4>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed max-w-xl">
                Remove demo business records (attendance, visits, tasks, leave, awards, messages, notifications) across organizations while preserving Platform Owner authority, organization registry, and user accounts.
              </p>
            </div>
            <button
              onClick={() => {
                setIsResetModalOpen(true);
                setResetConfirmPhrase('');
                setResetAuthPin('');
                setResetError('');
                setResetSuccessMsg('');
              }}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-xl text-xs flex items-center gap-1.5 shrink-0 shadow-2xs cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clean Production Data</span>
            </button>
          </div>
        </div>
      )}

      {/* RE-AUTHENTICATION PROTECTED SUSPEND MODAL */}
      {suspendingOrg && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-purple-200 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {suspendingOrg.status === 'active' ? 'Suspend Customer Organization' : 'Reactivate Customer Organization'}
                </h3>
                <p className="text-[11px] text-slate-500">Requires Platform Owner Authentication</p>
              </div>
            </div>

            <p className="text-slate-600">
              You are altering the platform status for <strong className="text-slate-900">{suspendingOrg.name}</strong> ({suspendingOrg.id}). When suspended, customer administrators and technicians cannot access the workspace.
            </p>

            <form onSubmit={handleExecuteSuspend} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Platform Owner Verification PIN or Password *
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter PIN (1234 or master password)"
                  value={authPin}
                  onChange={(e) => setAuthPin(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              {authError && <div className="text-[11px] text-rose-600 font-semibold">{authError}</div>}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSuspendingOrg(null)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={suspendingAction}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs"
                >
                  {suspendingAction ? 'Processing...' : 'Confirm Action'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Org Modal */}
      {isNewOrgModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">Provision Customer Organization</h3>
              <button onClick={() => setIsNewOrgModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateOrg} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Company / Organization Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pinnacle HVAC & Facilities"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Initial Main Admin Email</label>
                <input
                  type="email"
                  placeholder="operations@company.com"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Brand Accent Color</label>
                <input
                  type="color"
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="w-12 h-8 rounded-lg cursor-pointer border border-slate-200 p-0"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewOrgModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Provision Workspace
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. DELETE ORGANIZATION MODAL (Requirement 10) */}
      {deletingOrg && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-lg w-full border border-rose-300 shadow-2xl space-y-4 text-xs my-8 animate-in fade-in-0">
            <div className="flex items-center gap-3 pb-3 border-b border-rose-100">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">Delete Company Workspace</h3>
                <p className="text-[11px] text-rose-600 font-semibold">Irreversible Platform Owner Action</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-950 space-y-2">
              <div className="font-bold flex items-center gap-1.5 text-rose-900">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Destructive Tenant Data Deletion Warning</span>
              </div>
              <p className="leading-relaxed text-[11px]">
                You are about to permanently delete <strong className="text-rose-900">{deletingOrg.name}</strong> ({deletingOrg.id}). All isolated tenant data will be erased and cannot be recovered:
              </p>
              <ul className="list-disc pl-4 space-y-1 text-[10px] text-rose-900">
                <li>Connected workforce employees and credentials</li>
                <li>Shift check-in/out attendance logs and GPS location history</li>
                <li>Scheduled field visits, technician tasks, leave requests, and awards</li>
                <li>Chat room messages, audio voice notes, documents, and notifications</li>
                <li>Company branding, KPI configurations, and generated operational reports</li>
              </ul>
            </div>

            <form onSubmit={handleDeleteOrganization} className="space-y-3.5">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Confirmation: Type <span className="font-mono bg-slate-100 px-1 py-0.5 rounded text-rose-600 font-bold">{deletingOrg.name}</span> or <span className="font-mono bg-slate-100 px-1 py-0.5 rounded text-rose-600 font-bold">DELETE</span> *
                </label>
                <input
                  type="text"
                  required
                  placeholder={`Type "${deletingOrg.name}" to confirm`}
                  value={deleteConfirmPhrase}
                  onChange={(e) => setDeleteConfirmPhrase(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Platform Owner Re-Authentication PIN / Password *
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter PIN (1234 or master password)"
                  value={deleteAuthPin}
                  onChange={(e) => setDeleteAuthPin(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                />
              </div>

              {deleteError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                  {deleteError}
                </div>
              )}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setDeletingOrg(null);
                    setDeleteConfirmPhrase('');
                    setDeleteAuthPin('');
                    setDeleteError('');
                  }}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isDeletingOrg}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {isDeletingOrg ? 'Deleting Tenant...' : 'Permanently Delete Company'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. TRANSFER PLATFORM OWNERSHIP MODAL (Requirement 9) */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-lg w-full border border-indigo-200 shadow-2xl space-y-4 text-xs my-8 animate-in fade-in-0">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                  <Crown className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Transfer Platform Ownership</h3>
                  <p className="text-[11px] text-indigo-600 font-semibold">Highest Authority Delegation</p>
                </div>
              </div>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {transferSuccessData ? (
              <div className="space-y-4 py-2">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 space-y-2">
                  <div className="font-bold text-xs flex items-center gap-1.5 text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Ownership Transfer Invitation Dispatched</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-emerald-800">
                    {transferSuccessData.message}
                  </p>
                  <p className="text-[10px] text-emerald-700 font-mono">
                    Expires: {new Date(transferSuccessData.expiresAt).toLocaleString()}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="block font-bold text-slate-800 text-[11px]">
                    Single-Use Secure Acceptance Link
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={transferSuccessData.inviteUrl}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono select-all"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(transferSuccessData.inviteUrl);
                        setCopiedInviteLink(true);
                        setTimeout(() => setCopiedInviteLink(false), 2000);
                      }}
                      className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center gap-1 shrink-0 text-xs"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedInviteLink ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-tight">
                    When the designated administrator logs into FieldFlow using this link, ownership will be transferred atomically.
                  </p>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      setIsTransferModalOpen(false);
                      setTransferSuccessData(null);
                    }}
                    className="px-5 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleInitiateTransfer} className="space-y-3.5">
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950 space-y-1.5">
                  <div className="font-bold flex items-center gap-1.5 text-amber-900 text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Consequences of Platform Ownership Transfer</span>
                  </div>
                  <ul className="list-disc pl-4 space-y-1 text-[11px] text-amber-900">
                    <li>This transfers the highest level of control of the FieldFlow platform. Continue only if you are certain.</li>
                    <li>Upon acceptance, your account loses root platform authority and retains only company tenant rights.</li>
                    <li>The recipient becomes the sole Platform Owner with full management over all organizations and system settings.</li>
                  </ul>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Owner Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jordan Hayes"
                    value={transferNewName}
                    onChange={(e) => setTransferNewName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Owner Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="newowner@example.com"
                    value={transferNewEmail}
                    onChange={(e) => setTransferNewEmail(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">New Owner Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+1 555-0199"
                    value={transferNewPhone}
                    onChange={(e) => setTransferNewPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Current Platform Owner Re-Authentication PIN / Password *
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="Enter PIN (1234 or master password)"
                    value={transferAuthPin}
                    onChange={(e) => setTransferAuthPin(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                {transferError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                    {transferError}
                  </div>
                )}

                <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsTransferModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isTransferring}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    {isTransferring ? 'Authorizing Transfer...' : 'Initiate Ownership Transfer'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 3. RESET APPLICATION DATA MODAL (Requirement 11) */}
      {isResetModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-lg w-full border border-rose-300 shadow-2xl space-y-4 text-xs my-8 animate-in fade-in-0">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Reset Application Data</h3>
                  <p className="text-[11px] text-rose-600 font-semibold">Clean Production Slate Pass</p>
                </div>
              </div>
              <button
                onClick={() => setIsResetModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-950 space-y-2">
              <div className="font-bold text-xs flex items-center gap-1.5 text-rose-900">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>What will be removed vs preserved</span>
              </div>
              <div className="space-y-1.5 text-[11px] leading-relaxed">
                <div>
                  <strong className="text-rose-900">WILL BE REMOVED:</strong> All sample attendance check-ins, past visits, tasks, leave requests, team messages, voice notes, employee awards, and notification logs.
                </div>
                <div>
                  <strong className="text-emerald-800">WILL BE PRESERVED:</strong> Platform Owner account, user authentication credentials, system configuration, database security rules, and organizations registry.
                </div>
              </div>
            </div>

            {resetSuccessMsg ? (
              <div className="space-y-4 py-2">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 space-y-1">
                  <div className="font-bold text-xs flex items-center gap-1.5 text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Reset Successful</span>
                  </div>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">{resetSuccessMsg}</p>
                </div>
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetModalOpen(false);
                      setResetSuccessMsg('');
                    }}
                    className="px-5 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleResetApplicationData} className="space-y-3.5">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Confirmation: Type <span className="font-mono bg-slate-100 px-1 py-0.5 rounded text-rose-600 font-bold">RESET FIELDFLOW DATA</span> *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="RESET FIELDFLOW DATA"
                    value={resetConfirmPhrase}
                    onChange={(e) => setResetConfirmPhrase(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Platform Owner Re-Authentication PIN / Password *
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="Enter PIN (1234 or master password)"
                    value={resetAuthPin}
                    onChange={(e) => setResetAuthPin(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                  />
                </div>

                {resetError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                    {resetError}
                  </div>
                )}

                <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsResetModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isResettingData}
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    {isResettingData ? 'Executing Reset...' : 'Execute Data Reset'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
