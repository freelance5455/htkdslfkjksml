import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Plus,
  Pencil,
  Trash2,
  Search,
  NotebookPen,
  X,
  Check,
  FileText,
  Film,
  Music,
  Image as ImageIcon,
  FileType2,
  Presentation,
  FileSpreadsheet,
  Eye,
  Download,
  Loader2,
  MessageSquareText,
  WifiOff,
  CheckCircle2,
  Paperclip,
  AlertCircle,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  ExternalLink,
} from 'lucide-react';
import type { NoteItem, ColorTheme, WhatsNewItem, WhatsNewMediaType } from '../types';
import {
  deleteFileBlob,
  formatFileSize,
  getFileBlobRecord,
  inferMimeFromFilename,
  readFileAsBlobWithProgress,
  uploadFileToIndexedDb,
  validateAdminFile,
} from '../lib/fileDb';
import { useResolvedFileUrl } from '../hooks/useResolvedFileUrl';
import { InteractiveCard, TactileButton } from './InteractiveButton';
import { PdfViewer } from './PdfViewer';

interface NotesTabProps {
  notes: NoteItem[];
  onAddNote: (note: Omit<NoteItem, 'id' | 'updatedAt'>) => void;
  onUpdateNote: (id: string, patch: Partial<NoteItem>) => void;
  onDeleteNote: (id: string) => void;
  isOnline: boolean;
  items: WhatsNewItem[];
  loadingItems: boolean;
  readContentIds: string[];
  onMarkContentRead: (itemId: string) => void;
}

type NotesSubTab = 'my-notes' | 'files' | 'texts';

type PreviewPayload =
  | { type: 'word'; paragraphs: string[] }
  | { type: 'powerpoint'; slides: Array<{ slideNumber: number; lines: string[] }> }
  | { type: 'excel'; rows: string[][] }
  | { type: 'legacy'; message: string };

const NOTE_THEMES: Record<
  ColorTheme,
  { label: string; bg: string; border: string; accent: string; btn: string }
> = {
  purple: {
    label: 'بنفسجي',
    bg: 'bg-violet-50/80 dark:bg-violet-950/35',
    border: 'border-violet-200/80 dark:border-violet-800/70',
    accent: 'text-violet-700 dark:text-violet-300',
    btn: 'bg-violet-600',
  },
  blue: {
    label: 'أزرق',
    bg: 'bg-blue-50/80 dark:bg-blue-950/35',
    border: 'border-blue-200/80 dark:border-blue-800/70',
    accent: 'text-blue-700 dark:text-blue-300',
    btn: 'bg-blue-600',
  },
  orange: {
    label: 'برتقالي',
    bg: 'bg-orange-50/80 dark:bg-orange-950/35',
    border: 'border-orange-200/80 dark:border-orange-800/70',
    accent: 'text-orange-700 dark:text-orange-300',
    btn: 'bg-orange-500',
  },
  emerald: {
    label: 'أخضر',
    bg: 'bg-emerald-50/80 dark:bg-emerald-950/35',
    border: 'border-emerald-200/80 dark:border-emerald-800/70',
    accent: 'text-emerald-700 dark:text-emerald-300',
    btn: 'bg-emerald-600',
  },
  rose: {
    label: 'وردي',
    bg: 'bg-rose-50/80 dark:bg-rose-950/35',
    border: 'border-rose-200/80 dark:border-rose-800/70',
    accent: 'text-rose-700 dark:text-rose-300',
    btn: 'bg-rose-500',
  },
};

const COLOR_KEYS: ColorTheme[] = ['purple', 'blue', 'orange', 'emerald', 'rose'];

export function NotesTab({
  notes,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
  isOnline,
  items,
  loadingItems,
  readContentIds,
  onMarkContentRead,
}: NotesTabProps) {
  const [subTab, setSubTab] = useState<NotesSubTab>('my-notes');

  // Student personal notes state
  const [query, setQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);
  const [title, setTitle] = useState('');
  const [subjectTag, setSubjectTag] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState<ColorTheme>('purple');

  // Student personal note 90MB IndexedDB file attachment state
  const noteFilePickerRef = useRef<HTMLInputElement | null>(null);
  const [attachFile, setAttachFile] = useState<File | null>(null);
  const [attachBlob, setAttachBlob] = useState<Blob | null>(null);
  const [attachMediaType, setAttachMediaType] =
    useState<Exclude<WhatsNewMediaType, 'none'> | undefined>(undefined);
  const [attachProgress, setAttachProgress] = useState(0);
  const [attachUploading, setAttachUploading] = useState(false);
  const [attachDone, setAttachDone] = useState(false);
  const [attachError, setAttachError] = useState<string | null>(null);
  const [existingAttach, setExistingAttach] = useState<{
    url: string;
    name: string;
    size: number;
    mediaType: Exclude<WhatsNewMediaType, 'none'>;
  } | null>(null);

  // In-app file/summary viewer state
  const [viewerItem, setViewerItem] = useState<WhatsNewItem | null>(null);
  const {
    resolvedUrl: viewerResolvedUrl,
    blob: viewerBlob,
    loading: viewerUrlLoading,
    error: viewerUrlError,
  } = useResolvedFileUrl(viewerItem?.fileUrl || '', viewerItem?.mediaType);
  const [imageZoom, setImageZoom] = useState(1);
  const [officePreview, setOfficePreview] = useState<PreviewPayload | null>(null);
  const [officePreviewLoading, setOfficePreviewLoading] = useState(false);
  const [officePreviewError, setOfficePreviewError] = useState<string | null>(null);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  // Progressive viewport rendering for files & texts (load visible batch first)
  const [visibleFilesCount, setVisibleFilesCount] = useState(6);
  const [visibleTextsCount, setVisibleTextsCount] = useState(6);
  const filesSentinelRef = useRef<HTMLDivElement | null>(null);
  const textsSentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (subTab !== 'files') return;
    const node = filesSentinelRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleFilesCount((c) => c + 6);
        }
      },
      { rootMargin: '160px' }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [subTab, items.length, visibleFilesCount]);

  useEffect(() => {
    if (subTab !== 'texts') return;
    const node = textsSentinelRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleTextsCount((c) => c + 6);
        }
      },
      { rootMargin: '160px' }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [subTab, items.length, visibleTextsCount]);

  useEffect(() => {
    setImageZoom(1);
    if (!viewerItem) {
      setOfficePreview(null);
      setOfficePreviewError(null);
      return;
    }

    const needsOfficeParser =
      viewerItem.mediaType === 'word' ||
      viewerItem.mediaType === 'powerpoint' ||
      viewerItem.mediaType === 'excel';

    if (!needsOfficeParser || !viewerItem.fileUrl) return;

    let cancelled = false;
    setOfficePreviewLoading(true);
    setOfficePreviewError(null);

    if (viewerItem.fileUrl.startsWith('idb://')) {
      getFileBlobRecord(viewerItem.fileUrl)
        .then(async (record) => {
          if (!record) {
            throw new Error('الملف غير موجود في ذاكرة المتصفح (IndexedDB).');
          }
          const fileName = viewerItem.fileName || record.fileName || 'document';
          // Client-side fast fallback for CSV if offline
          if (fileName.toLowerCase().endsWith('.csv') && !navigator.onLine) {
            const raw = await record.blob.text();
            const rows = raw
              .split(/\r?\n/)
              .slice(0, 120)
              .map((line) => line.split(',').map((c) => c.trim()))
              .filter((r) => r.some(Boolean));
            if (!cancelled) setOfficePreview({ type: 'excel', rows });
            return;
          }

          const fd = new FormData();
          fd.append('file', record.blob, fileName);
          const res = await fetch('/api/preview-blob', {
            method: 'POST',
            body: fd,
          });
          const data = (await res.json()) as PreviewPayload & { error?: string };
          if (!res.ok) throw new Error(data.error || 'تعذر فتح الملف.');
          if (!cancelled) setOfficePreview(data);
        })
        .catch((err) => {
          if (!cancelled) {
            setOfficePreviewError(
              err instanceof Error ? err.message : 'تعذر عرض معاينة المستند.'
            );
          }
        })
        .finally(() => {
          if (!cancelled) setOfficePreviewLoading(false);
        });

      return () => {
        cancelled = true;
      };
    }

    const storedName = viewerItem.fileUrl.split('/').pop() || '';
    if (!storedName) {
      setOfficePreviewLoading(false);
      return;
    }

    fetch(`/api/preview/${encodeURIComponent(storedName)}`)
      .then(async (res) => {
        const data = (await res.json()) as PreviewPayload & { error?: string };
        if (!res.ok) throw new Error(data.error || 'تعذر فتح الملف.');
        if (!cancelled) setOfficePreview(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setOfficePreviewError(
            err instanceof Error ? err.message : 'تعذر عرض معاينة المستند.'
          );
        }
      })
      .finally(() => {
        if (!cancelled) setOfficePreviewLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [viewerItem]);

  const handleDownloadItem = async (item: WhatsNewItem) => {
    setDownloadNotice(null);
    if (!item.fileUrl) return;

    if (item.fileUrl.startsWith('idb://')) {
      try {
        const record = await getFileBlobRecord(item.fileUrl);
        if (!record) {
          setDownloadNotice('تعذر العثور على الملف في ذاكرة المتصفح.');
          return;
        }
        const isPdf =
          item.mediaType === 'pdf' ||
          (item.fileName || record.fileName || '').toLowerCase().endsWith('.pdf');
        const targetMime = isPdf
          ? 'application/pdf'
          : inferMimeFromFilename(
              item.fileName || record.fileName || '',
              record.mimeType || record.blob.type
            );
        const typedBlob =
          record.blob.type === targetMime
            ? record.blob
            : new Blob([record.blob], { type: targetMime });
        const objUrl = URL.createObjectURL(typedBlob);
        const a = document.createElement('a');
        a.href = objUrl;
        a.download = item.fileName || record.fileName || 'file';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.setTimeout(() => URL.revokeObjectURL(objUrl), 30000);
      } catch {
        setDownloadNotice('حصل خطأ أثناء تجهيز الملف للتحميل.');
      }
      return;
    }

    const storedName = getStoredFilename(item.fileUrl);
    const a = document.createElement('a');
    a.href = `/api/download/${encodeURIComponent(
      storedName
    )}?name=${encodeURIComponent(item.fileName || storedName)}`;
    a.download = item.fileName || storedName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const fileItems = items.filter(
    (i) => i.category === 'file' || i.category === 'summary'
  );
  const textItems = items.filter((i) => i.category === 'text');

  const filteredNotes = notes.filter((n) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      n.title.toLowerCase().includes(q) ||
      n.content.toLowerCase().includes(q) ||
      n.subjectTag.toLowerCase().includes(q)
    );
  });

  const resetAttachmentModalState = () => {
    setAttachFile(null);
    setAttachBlob(null);
    setAttachMediaType(undefined);
    setAttachProgress(0);
    setAttachUploading(false);
    setAttachDone(false);
    setAttachError(null);
    if (noteFilePickerRef.current) noteFilePickerRef.current.value = '';
  };

  const openCreateModal = () => {
    setEditingNote(null);
    setTitle('');
    setSubjectTag('');
    setContent('');
    setColor('purple');
    setExistingAttach(null);
    resetAttachmentModalState();
    setModalOpen(true);
  };

  const openEditModal = (note: NoteItem) => {
    setEditingNote(note);
    setTitle(note.title);
    setSubjectTag(note.subjectTag);
    setContent(note.content);
    setColor(note.color);
    setExistingAttach(
      note.attachmentUrl && note.attachmentName
        ? {
            url: note.attachmentUrl,
            name: note.attachmentName,
            size: note.attachmentSize || 0,
            mediaType: note.attachmentMediaType || 'pdf',
          }
        : null
    );
    resetAttachmentModalState();
    setModalOpen(true);
  };

  const handleSelectNoteAttachment = async (selected: File | null) => {
    setAttachError(null);
    setAttachDone(false);
    setAttachProgress(0);
    setAttachBlob(null);

    if (!selected) {
      setAttachFile(null);
      setAttachMediaType(undefined);
      return;
    }

    const validation = validateAdminFile(selected);
    if (!validation.valid) {
      setAttachFile(null);
      setAttachMediaType(undefined);
      if (noteFilePickerRef.current) noteFilePickerRef.current.value = '';
      setAttachError(validation.error);
      return;
    }

    setAttachFile(selected);
    setAttachMediaType(validation.mediaType);
    setAttachUploading(true);
    try {
      const blob = await readFileAsBlobWithProgress(selected, setAttachProgress);
      setAttachBlob(blob);
      setAttachProgress(100);
      setAttachDone(true);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'تعذر قراءة الملف';
      setAttachFile(null);
      setAttachBlob(null);
      setAttachMediaType(undefined);
      setAttachError(`حصل خطأ أثناء الرفع: ${reason}`);
    } finally {
      setAttachUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!title.trim() && !content.trim() && !attachFile && !existingAttach) || attachUploading) {
      return;
    }

    let finalAttachUrl = existingAttach?.url;
    let finalAttachName = existingAttach?.name;
    let finalAttachSize = existingAttach?.size;
    let finalAttachMediaType = existingAttach?.mediaType;

    if (attachFile && attachMediaType) {
      setAttachUploading(true);
      setAttachError(null);
      try {
        const blobId = `note_file_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        const uploaded = await uploadFileToIndexedDb(
          attachFile,
          blobId,
          setAttachProgress,
          attachBlob
        );
        if (editingNote?.attachmentUrl?.startsWith('idb://')) {
          await deleteFileBlob(editingNote.attachmentUrl).catch(() => {});
        }
        finalAttachUrl = uploaded.fileUrl;
        finalAttachName = uploaded.fileName;
        finalAttachSize = uploaded.size;
        finalAttachMediaType = attachMediaType;
      } catch (err) {
        const reason = err instanceof Error ? err.message : 'خطأ غير معروف';
        setAttachError(`حصل خطأ أثناء الرفع: ${reason}`);
        setAttachUploading(false);
        return;
      } finally {
        setAttachUploading(false);
      }
    } else if (!existingAttach && editingNote?.attachmentUrl?.startsWith('idb://')) {
      await deleteFileBlob(editingNote.attachmentUrl).catch(() => {});
    }

    if (editingNote) {
      onUpdateNote(editingNote.id, {
        title: title.trim() || 'ملاحظة بدون عنوان',
        subjectTag: subjectTag.trim() || 'عام',
        content: content.trim(),
        color,
        attachmentUrl: finalAttachUrl,
        attachmentName: finalAttachName,
        attachmentSize: finalAttachSize,
        attachmentMediaType: finalAttachMediaType,
      });
    } else {
      onAddNote({
        title: title.trim() || 'ملاحظة بدون عنوان',
        subjectTag: subjectTag.trim() || 'عام',
        content: content.trim(),
        color,
        attachmentUrl: finalAttachUrl,
        attachmentName: finalAttachName,
        attachmentSize: finalAttachSize,
        attachmentMediaType: finalAttachMediaType,
      });
    }
    setModalOpen(false);
  };

  const buildViewerItemFromNote = (note: NoteItem): WhatsNewItem => ({
    id: `note_view_${note.id}`,
    title: note.title,
    description: note.content,
    category: 'file',
    textKind: 'none',
    subjectName: note.subjectTag || 'عام',
    mediaType: note.attachmentMediaType || 'pdf',
    fileUrl: note.attachmentUrl || '',
    fileName: note.attachmentName || note.title,
    fileSize: note.attachmentSize || 0,
    newsDate: '',
    quizQuestion: '',
    quizOptions: [],
    quizCorrectIndex: -1,
    authorUid: '',
    createdAtMs: note.updatedAt,
  });

  const formatDate = (ts: number) =>
    new Intl.DateTimeFormat('ar-EG', {
      day: 'numeric',
      month: 'short',
    }).format(new Date(ts));

  const formatBytes = (bytes: number) => {
    if (!bytes) return '';
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getStoredFilename = (fileUrl: string) => {
    const parts = fileUrl.split('/');
    return parts[parts.length - 1] || '';
  };

  const getFileVisualMeta = (mediaType: WhatsNewMediaType) => {
    switch (mediaType) {
      case 'pdf':
        return {
          label: 'PDF',
          icon: FileText,
          badgeBg: 'bg-rose-50 dark:bg-rose-950/60',
          iconColor: 'text-rose-600 dark:text-rose-400',
          borderAccent: 'hover:border-rose-300 dark:hover:border-rose-700',
        };
      case 'video':
        return {
          label: 'فيديو',
          icon: Film,
          badgeBg: 'bg-blue-50 dark:bg-blue-950/60',
          iconColor: 'text-blue-600 dark:text-blue-400',
          borderAccent: 'hover:border-blue-300 dark:hover:border-blue-700',
        };
      case 'audio':
        return {
          label: 'ملف صوتي',
          icon: Music,
          badgeBg: 'bg-violet-50 dark:bg-violet-950/60',
          iconColor: 'text-violet-600 dark:text-violet-400',
          borderAccent: 'hover:border-violet-300 dark:hover:border-violet-700',
        };
      case 'image':
        return {
          label: 'صورة',
          icon: ImageIcon,
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60',
          iconColor: 'text-emerald-600 dark:text-emerald-400',
          borderAccent: 'hover:border-emerald-300 dark:hover:border-emerald-700',
        };
      case 'word':
        return {
          label: 'Word',
          icon: FileType2,
          badgeBg: 'bg-sky-50 dark:bg-sky-950/60',
          iconColor: 'text-sky-600 dark:text-sky-400',
          borderAccent: 'hover:border-sky-300 dark:hover:border-sky-700',
        };
      case 'powerpoint':
        return {
          label: 'PowerPoint',
          icon: Presentation,
          badgeBg: 'bg-orange-50 dark:bg-orange-950/60',
          iconColor: 'text-orange-600 dark:text-orange-400',
          borderAccent: 'hover:border-orange-300 dark:hover:border-orange-700',
        };
      case 'excel':
        return {
          label: 'Excel',
          icon: FileSpreadsheet,
          badgeBg: 'bg-teal-50 dark:bg-teal-950/60',
          iconColor: 'text-teal-600 dark:text-teal-400',
          borderAccent: 'hover:border-teal-300 dark:hover:border-teal-700',
        };
      default:
        return {
          label: 'ملف',
          icon: FileText,
          badgeBg: 'bg-slate-100 dark:bg-slate-800',
          iconColor: 'text-slate-600 dark:text-slate-300',
          borderAccent: 'hover:border-slate-300 dark:hover:border-slate-600',
        };
    }
  };

  return (
    <section className="space-y-5">
      {/* Compact Header + 3 Section Switcher Buttons */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              دفتر الملاحظات
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-0.5">
              ملاحظاتك الشخصية وملفات التلخيصات والنصوص والشروحات في مكان واحد.
            </p>
          </div>

          {subTab === 'my-notes' && (
            <TactileButton
              type="button"
              onClick={openCreateModal}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs sm:text-sm min-h-[40px] whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>ملاحظة جديدة</span>
            </TactileButton>
          )}
        </div>

        {/* 3 Top Section Buttons: [ملاحظاتي] [ملفات وتلخيصات] [نصوص وشروحات] */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
          {[
            { id: 'my-notes' as const, label: 'ملاحظاتي' },
            { id: 'files' as const, label: 'ملفات وتلخيصات' },
            { id: 'texts' as const, label: 'نصوص وشروحات' },
          ].map((btn) => {
            const active = subTab === btn.id;
            return (
              <TactileButton
                key={btn.id}
                type="button"
                onClick={() => setSubTab(btn.id)}
                className={`py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-sm font-bold whitespace-nowrap min-h-[40px] flex items-center justify-center ${
                  active
                    ? 'bg-violet-600 text-white'
                    : 'bg-transparent shadow-none text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {btn.label}
              </TactileButton>
            );
          })}
        </div>

        {subTab === 'my-notes' && (
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث في ملاحظاتك..."
              className="w-full pr-10 pl-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-violet-500 outline-none text-sm min-h-[40px]"
            />
          </div>
        )}
      </div>

      {/* Sub-Section 1: ملاحظاتي (100% Offline) */}
      {subTab === 'my-notes' && (
        <>
          {filteredNotes.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center">
              <div className="w-11 h-11 mx-auto mb-2.5 rounded-2xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                <NotebookPen className="w-5 h-5" />
              </div>
              <h2 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-1">
                {query ? 'لا توجد ملاحظات مطابقة للبحث' : 'دفتر الملاحظات فارغ'}
              </h2>
              <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm mb-3.5">
                {query
                  ? 'جرّب كلمة بحث أخرى أو أضف ملاحظة جديدة.'
                  : 'سجّل أهم القواعد أو أرفق ملفاتك الدراسية (حتى 90 ميجا) بدون إنترنت.'}
              </p>
              {!query && (
                <TactileButton
                  type="button"
                  onClick={openCreateModal}
                  className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm min-h-[40px]"
                >
                  <Plus className="w-4 h-4" />
                  <span>اكتب أول ملاحظة</span>
                </TactileButton>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
              <AnimatePresence>
                {filteredNotes.map((note) => {
                  const theme = NOTE_THEMES[note.color] || NOTE_THEMES.purple;
                  return (
                    <InteractiveCard
                      key={note.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={`rounded-2xl border ${theme.border} ${theme.bg} p-4 sm:p-5 flex flex-col justify-between gap-3 shadow-xs`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">
                              <span className={`font-bold ${theme.accent}`}>
                                {note.subjectTag || 'عام'}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>{formatDate(note.updatedAt)}</span>
                            </div>
                            <h3 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white break-words">
                              {note.title}
                            </h3>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <TactileButton
                              type="button"
                              onClick={() => openEditModal(note)}
                              aria-label={`تعديل ${note.title}`}
                              className="w-8 h-8 rounded-lg flex items-center justify-center bg-white/75 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </TactileButton>
                            <TactileButton
                              type="button"
                              onClick={() => onDeleteNote(note.id)}
                              aria-label={`حذف ${note.title}`}
                              className="w-8 h-8 rounded-lg flex items-center justify-center bg-white/75 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </TactileButton>
                          </div>
                        </div>

                        {note.content && (
                          <p className="text-slate-700 dark:text-slate-200 text-xs sm:text-sm leading-relaxed whitespace-pre-line break-words">
                            {note.content}
                          </p>
                        )}
                      </div>

                      {note.attachmentUrl && note.attachmentName && (
                        <div className="pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 space-y-2">
                          <div className="flex items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300">
                            <span className="inline-flex items-center gap-1 font-bold truncate">
                              <Paperclip className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{note.attachmentName}</span>
                            </span>
                            {note.attachmentSize ? (
                              <span className="font-mono-num shrink-0">
                                {formatFileSize(note.attachmentSize)}
                              </span>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <TactileButton
                              type="button"
                              onClick={() => setViewerItem(buildViewerItemFromNote(note))}
                              className="flex-1 py-1.5 px-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs flex items-center justify-center gap-1 min-h-[34px]"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>فتح</span>
                            </TactileButton>
                            <TactileButton
                              type="button"
                              flashSuccess
                              onClick={() => handleDownloadItem(buildViewerItemFromNote(note))}
                              className="py-1.5 px-2.5 rounded-xl bg-white/85 dark:bg-slate-800 hover:bg-white text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center justify-center gap-1 min-h-[34px]"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>تحميل</span>
                            </TactileButton>
                          </div>
                        </div>
                      )}
                    </InteractiveCard>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </>
      )}

      {/* Sub-Section 2: ملفات وتلخيصات */}
      {subTab === 'files' && (
        <div className="space-y-4">
          {downloadNotice && (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs sm:text-sm font-bold">
              {downloadNotice}
            </div>
          )}

          {!isOnline && fileItems.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center">
              <div className="w-11 h-11 mx-auto mb-2.5 rounded-2xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                <WifiOff className="w-5 h-5" />
              </div>
              <p className="text-slate-700 dark:text-slate-200 text-sm font-bold">
                افتح الإنترنت لعرض وتحميل الملفات والتلخيصات
              </p>
            </div>
          ) : loadingItems && fileItems.length === 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((n) => (
                <div
                  key={n}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 h-36 animate-pulse"
                />
              ))}
            </div>
          ) : fileItems.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center text-slate-500 dark:text-slate-400 text-sm">
              لم يرفع المشرف أي ملفات أو تلخيصات بعد.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
                {fileItems.slice(0, visibleFilesCount).map((item) => {
                  const meta = getFileVisualMeta(item.mediaType);
                  const Icon = meta.icon;
                  const isRead = readContentIds.includes(item.id);

                  return (
                    <InteractiveCard
                      key={item.id}
                      className={`bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 ${meta.borderAccent} p-4 sm:p-5 flex flex-col justify-between gap-4 shadow-xs transition-colors`}
                    >
                      <div className="space-y-2.5">
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-10 h-10 rounded-xl ${meta.badgeBg} ${meta.iconColor} flex items-center justify-center shrink-0`}
                          >
                            <Icon className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                              <span className={`font-bold ${meta.iconColor}`}>{meta.label}</span>
                              {item.subjectName && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="truncate font-semibold text-slate-700 dark:text-slate-300">
                                    {item.subjectName}
                                  </span>
                                </>
                              )}
                            </div>
                            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white mt-0.5 break-words">
                              {item.title}
                            </h3>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                          {item.fileSize > 0 && (
                            <span className="tabular-nums">{formatBytes(item.fileSize)}</span>
                          )}
                          {item.fileSize > 0 && <span aria-hidden="true">·</span>}
                          <span>{formatDate(item.createdAtMs)}</span>
                        </div>

                        {item.description && (
                          <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm line-clamp-2">
                            {item.description}
                          </p>
                        )}
                      </div>

                      <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                        {item.fileUrl && (
                          <div className="flex items-center gap-2">
                            <TactileButton
                              type="button"
                              onClick={() => setViewerItem(item)}
                              className="flex-1 py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 min-h-[40px]"
                            >
                              <Eye className="w-4 h-4" />
                              <span>فتح داخل التطبيق</span>
                            </TactileButton>

                            <TactileButton
                              type="button"
                              flashSuccess
                              onClick={() => handleDownloadItem(item)}
                              className="py-2 px-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 min-h-[40px]"
                            >
                              <Download className="w-4 h-4" />
                              <span>تحميل</span>
                            </TactileButton>
                          </div>
                        )}

                        <TactileButton
                          type="button"
                          flashSuccess={!isRead}
                          disabled={isRead}
                          onClick={() => onMarkContentRead(item.id)}
                          className={`w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 min-h-[38px] ${
                            isRead
                              ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-none cursor-default'
                              : 'bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>{isRead ? 'تمت المذاكرة' : 'أنهيت المذاكرة'}</span>
                        </TactileButton>
                      </div>
                    </InteractiveCard>
                  );
                })}
              </div>
              {fileItems.length > visibleFilesCount && (
                <div ref={filesSentinelRef} className="h-8 flex items-center justify-center">
                  <span className="text-xs font-bold text-slate-400">جاري تحميل المزيد...</span>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Sub-Section 3: نصوص وشروحات */}
      {subTab === 'texts' && (
        <div className="space-y-4">
          {!isOnline ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center">
              <div className="w-11 h-11 mx-auto mb-2.5 rounded-2xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
                <WifiOff className="w-5 h-5" />
              </div>
              <p className="text-slate-700 dark:text-slate-200 text-sm font-bold">
                افتح الإنترنت لعرض النصوص والشروحات المنشورة
              </p>
            </div>
          ) : loadingItems ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 h-32 animate-pulse"
                />
              ))}
            </div>
          ) : textItems.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 text-center text-slate-500 dark:text-slate-400 text-sm">
              لا توجد نصوص أو شروحات مكتوبة حالياً.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-5">
                {textItems.slice(0, visibleTextsCount).map((item) => {
                  const kindLabel = item.textKind !== 'none' ? item.textKind : 'شرح';
                  const kindColor =
                    kindLabel === 'تنبيه'
                      ? 'text-orange-600 dark:text-orange-400'
                      : kindLabel === 'ملخص'
                        ? 'text-violet-700 dark:text-violet-400'
                        : 'text-blue-600 dark:text-blue-400';
                  const isRead = readContentIds.includes(item.id);

                  return (
                    <InteractiveCard
                      key={item.id}
                      className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 flex flex-col justify-between gap-3.5 shadow-xs"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                          <MessageSquareText className={`w-3.5 h-3.5 ${kindColor}`} />
                          <span className={`font-bold ${kindColor}`}>{kindLabel}</span>
                          {item.subjectName && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{item.subjectName}</span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>{formatDate(item.createdAtMs)}</span>
                        </div>

                        <h3 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                          {item.title}
                        </h3>

                        <p className="text-slate-700 dark:text-slate-300 text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                          {item.description}
                        </p>
                      </div>

                      <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800">
                        <TactileButton
                          type="button"
                          flashSuccess={!isRead}
                          disabled={isRead}
                          onClick={() => onMarkContentRead(item.id)}
                          className={`w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 min-h-[38px] ${
                            isRead
                              ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-none cursor-default'
                              : 'bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>{isRead ? 'تمت قراءة الشرح' : 'أنهيت الشرح'}</span>
                        </TactileButton>
                      </div>
                    </InteractiveCard>
                  );
                })}
              </div>
              {textItems.length > visibleTextsCount && (
                <div ref={textsSentinelRef} className="h-8 flex items-center justify-center">
                  <span className="text-xs font-bold text-slate-400">جاري تحميل المزيد...</span>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Note Create / Edit Modal */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                  {editingNote ? 'تعديل الملاحظة' : 'ملاحظة جديدة'}
                </h2>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setModalOpen(false)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              <form onSubmit={handleSave} className="space-y-3.5">
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
                    عنوان الملاحظة
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="مثال: ملخص قوانين نيوتن"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-orange-500 outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
                    المادة / التصنيف
                  </label>
                  <input
                    type="text"
                    value={subjectTag}
                    onChange={(e) => setSubjectTag(e.target.value)}
                    placeholder="مثال: الفيزياء"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-orange-500 outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1">
                    المحتوى
                  </label>
                  <textarea
                    rows={3}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="اكتب ملاحظاتك هنا أو أرفق ملفاً..."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-orange-500 outline-none resize-y text-sm"
                  />
                </div>

                {/* 90MB IndexedDB File Attachment */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200">
                    إرفاق ملف (اختياري · حتى 90 ميجا)
                  </label>
                  <input
                    ref={noteFilePickerRef}
                    type="file"
                    accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.csv,image/*,video/*,audio/*"
                    onChange={(e) => handleSelectNoteAttachment(e.target.files?.[0] || null)}
                    className="w-full px-3 py-2 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-200 cursor-pointer"
                  />

                  {existingAttach && !attachFile && (
                    <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs">
                      <span className="inline-flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-200 truncate">
                        <Paperclip className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{existingAttach.name}</span>
                        {existingAttach.size > 0 && (
                          <span className="font-mono-num text-slate-500">
                            ({formatFileSize(existingAttach.size)})
                          </span>
                        )}
                      </span>
                      <button
                        type="button"
                        onClick={() => setExistingAttach(null)}
                        className="text-rose-600 dark:text-rose-400 font-bold shrink-0 cursor-pointer"
                      >
                        حذف
                      </button>
                    </div>
                  )}

                  {(attachFile || attachUploading || attachDone) && (
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1.5 text-xs">
                      {attachFile && (
                        <div className="flex items-center justify-between gap-2 font-bold">
                          <span className="truncate text-slate-800 dark:text-slate-100">
                            {attachFile.name}
                          </span>
                          <span className="font-mono-num text-slate-500 shrink-0">
                            {formatFileSize(attachFile.size)}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center justify-between font-bold">
                        <span className="flex items-center gap-1">
                          {attachDone ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                              <span className="text-emerald-600 dark:text-emerald-400">
                                تم رفع الملف بنجاح
                              </span>
                            </>
                          ) : (
                            <span className="text-violet-600 dark:text-violet-400">
                              جاري تجهيز الملف...
                            </span>
                          )}
                        </span>
                        <span className="font-mono-num text-violet-700 dark:text-violet-400">
                          {attachProgress}%
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-200 ${
                            attachDone ? 'bg-emerald-500' : 'bg-violet-600'
                          }`}
                          style={{ width: `${attachProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {attachError && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-bold space-y-2">
                      <div className="flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{attachError}</span>
                      </div>
                      <TactileButton
                        type="button"
                        onClick={() => {
                          setAttachError(null);
                          noteFilePickerRef.current?.click();
                        }}
                        className="w-full py-1.5 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 min-h-[34px]"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>اختار ملف تاني</span>
                      </TactileButton>
                    </div>
                  )}
                </div>

                <div>
                  <span className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    لون البطاقة
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {COLOR_KEYS.map((c) => {
                      const th = NOTE_THEMES[c];
                      const selected = color === c;
                      return (
                        <TactileButton
                          key={c}
                          type="button"
                          onClick={() => setColor(c)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold min-h-[34px] flex items-center gap-1.5 ${
                            selected
                              ? `${th.btn} text-white`
                              : `${th.bg} ${th.accent} border ${th.border}`
                          }`}
                        >
                          {selected && <Check className="w-3.5 h-3.5" />}
                          <span>{th.label}</span>
                        </TactileButton>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <TactileButton
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-bold min-h-[40px]"
                  >
                    إلغاء
                  </TactileButton>
                  <TactileButton
                    type="submit"
                    disabled={attachUploading}
                    className="px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:opacity-60 text-white text-sm font-bold min-h-[40px] flex items-center gap-1.5"
                  >
                    {attachUploading && <Loader2 className="w-4 h-4 animate-spin" />}
                    <span>حفظ الملاحظة</span>
                  </TactileButton>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* In-App Media & Document Viewer Modal */}
      <AnimatePresence>
        {viewerItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 12 }}
              className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="px-4 sm:px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="font-display text-base sm:text-xl font-bold text-slate-900 dark:text-white truncate">
                    {viewerItem.title}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {viewerItem.fileName}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <TactileButton
                    type="button"
                    flashSuccess={!readContentIds.includes(viewerItem.id)}
                    disabled={readContentIds.includes(viewerItem.id)}
                    onClick={() => onMarkContentRead(viewerItem.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold min-h-[38px] ${
                      readContentIds.includes(viewerItem.id)
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-none'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {readContentIds.includes(viewerItem.id) ? 'تمت القراءة' : 'أنهيت القراءة'}
                    </span>
                  </TactileButton>

                  <TactileButton
                    type="button"
                    flashSuccess
                    onClick={() => handleDownloadItem(viewerItem)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs sm:text-sm font-bold min-h-[38px]"
                  >
                    <Download className="w-4 h-4" />
                    <span className="hidden sm:inline">تحميل</span>
                  </TactileButton>

                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setViewerItem(null)}
                    aria-label="إغلاق العارض"
                    className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
                  >
                    <X className="w-5 h-5" />
                  </motion.button>
                </div>
              </div>

              <div className="p-4 sm:p-6 overflow-auto bg-slate-50 dark:bg-slate-950 flex-1 flex flex-col items-center justify-center">
                {(viewerItem.mediaType === 'pdf' ||
                  viewerItem.mediaType === 'video' ||
                  viewerItem.mediaType === 'audio' ||
                  viewerItem.mediaType === 'image') &&
                viewerUrlLoading ? (
                  <div className="py-12 w-full max-w-md space-y-3 text-center">
                    <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200">
                      <span>جاري فتح الملف...</span>
                      <Loader2 className="w-4 h-4 animate-spin text-violet-600" />
                    </div>
                    <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full w-2/3 bg-gradient-to-l from-violet-600 to-blue-500 animate-pulse rounded-full" />
                    </div>
                  </div>
                ) : (viewerItem.mediaType === 'pdf' ||
                    viewerItem.mediaType === 'video' ||
                    viewerItem.mediaType === 'audio' ||
                    viewerItem.mediaType === 'image') &&
                  viewerUrlError ? (
                  <div className="w-full max-w-md mx-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-center space-y-4">
                    <div className="w-12 h-12 mx-auto rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                      <AlertCircle className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <p className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                        مش قادرين نعرض الملف هنا
                      </p>
                      <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                        {viewerUrlError}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2.5">
                      <TactileButton
                        type="button"
                        onClick={() => handleDownloadItem(viewerItem)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs sm:text-sm min-h-[40px]"
                      >
                        <Download className="w-4 h-4" />
                        <span>تحميل الملف</span>
                      </TactileButton>
                      {viewerResolvedUrl && (
                        <a
                          href={viewerResolvedUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold text-xs sm:text-sm min-h-[40px]"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>فتح في تبويب جديد</span>
                        </a>
                      )}
                    </div>
                  </div>
                ) : (
                  <>
                    {viewerItem.mediaType === 'pdf' && viewerResolvedUrl && (
                      <PdfViewer
                        fileUrl={viewerResolvedUrl}
                        blob={viewerBlob}
                        fileName={viewerItem.fileName}
                        onDownload={() => handleDownloadItem(viewerItem)}
                      />
                    )}

                    {viewerItem.mediaType === 'video' && viewerResolvedUrl && (
                      <video
                        src={viewerResolvedUrl}
                        controls
                        playsInline
                        className="w-full max-h-[68vh] rounded-2xl bg-black"
                      />
                    )}

                    {viewerItem.mediaType === 'audio' && viewerResolvedUrl && (
                      <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-5 shadow-xs">
                        <div className="w-20 h-20 mx-auto rounded-3xl bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 flex items-center justify-center">
                          <Music className="w-10 h-10" />
                        </div>
                        <div>
                          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                            {viewerItem.title}
                          </h3>
                          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                            {viewerItem.fileName}
                          </p>
                        </div>
                        <audio src={viewerResolvedUrl} controls className="w-full" />
                      </div>
                    )}

                    {viewerItem.mediaType === 'image' && viewerResolvedUrl && (
                      <div className="w-full flex flex-col items-center gap-3">
                        <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl px-3 py-1.5 shadow-xs">
                          <TactileButton
                            type="button"
                            disabled={imageZoom <= 0.6}
                            onClick={() =>
                              setImageZoom((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))
                            }
                            aria-label="تصغير الصورة"
                            className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-45 text-slate-700 dark:text-slate-200 flex items-center justify-center"
                          >
                            <ZoomOut className="w-4 h-4" />
                          </TactileButton>

                          <span className="min-w-[48px] text-center font-mono-num text-xs font-bold text-slate-700 dark:text-slate-200">
                            {Math.round(imageZoom * 100)}%
                          </span>

                          <TactileButton
                            type="button"
                            disabled={imageZoom >= 3}
                            onClick={() =>
                              setImageZoom((z) => Math.min(3, Number((z + 0.25).toFixed(2))))
                            }
                            aria-label="تكبير الصورة"
                            className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-45 text-slate-700 dark:text-slate-200 flex items-center justify-center"
                          >
                            <ZoomIn className="w-4 h-4" />
                          </TactileButton>

                          {imageZoom !== 1 && (
                            <TactileButton
                              type="button"
                              onClick={() => setImageZoom(1)}
                              aria-label="إعادة ضبط التكبير"
                              className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </TactileButton>
                          )}
                        </div>

                        <div className="w-full max-h-[60vh] overflow-auto flex items-center justify-center p-2 rounded-2xl bg-slate-200/50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                          <img
                            src={viewerResolvedUrl}
                            alt={viewerItem.title}
                            referrerPolicy="no-referrer"
                            style={{
                              transform: `scale(${imageZoom})`,
                              transformOrigin: 'center center',
                            }}
                            className="max-w-full max-h-[56vh] rounded-xl object-contain shadow-sm transition-transform duration-150"
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}

                {(viewerItem.mediaType === 'word' ||
                  viewerItem.mediaType === 'powerpoint' ||
                  viewerItem.mediaType === 'excel') && (
                  <div className="w-full space-y-3">
                    <div className="flex flex-wrap items-center justify-end gap-2">
                      <TactileButton
                        type="button"
                        onClick={() => handleDownloadItem(viewerItem)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs min-h-[36px]"
                      >
                        <Download className="w-4 h-4" />
                        <span>تحميل</span>
                      </TactileButton>
                      {viewerResolvedUrl && (
                        <a
                          href={viewerResolvedUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold text-xs min-h-[36px]"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>فتح في تبويب جديد</span>
                        </a>
                      )}
                    </div>

                    <div className="w-full max-h-[60vh] overflow-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
                      {officePreviewLoading ? (
                        <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-600 dark:text-slate-300">
                          <Loader2 className="w-8 h-8 animate-spin text-violet-600" />
                          <span className="font-bold text-sm">جاري تجهيز معاينة المستند...</span>
                        </div>
                      ) : officePreviewError ? (
                        <div className="py-10 text-center space-y-3">
                          <p className="text-base font-bold text-slate-900 dark:text-white">
                            مش قادرين نعرض الملف هنا
                          </p>
                          <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                            {officePreviewError}
                          </p>
                        </div>
                      ) : officePreview?.type === 'word' ? (
                        <div className="space-y-3 text-slate-800 dark:text-slate-100 leading-relaxed">
                          {officePreview.paragraphs.length === 0 ? (
                            <p className="text-slate-500">المستند فارغ.</p>
                          ) : (
                            officePreview.paragraphs.map((p, idx) => (
                              <p key={idx} className="text-sm sm:text-base">
                                {p}
                              </p>
                            ))
                          )}
                        </div>
                      ) : officePreview?.type === 'powerpoint' ? (
                        <div className="space-y-4">
                          {officePreview.slides.map((slide) => (
                            <div
                              key={slide.slideNumber}
                              className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 space-y-2"
                            >
                              <span className="text-xs font-bold text-orange-600 dark:text-orange-400">
                                شريحة {slide.slideNumber}
                              </span>
                              {slide.lines.map((line, i) => (
                                <p
                                  key={i}
                                  className="text-slate-900 dark:text-slate-100 text-sm sm:text-base font-medium"
                                >
                                  {line}
                                </p>
                              ))}
                            </div>
                          ))}
                        </div>
                      ) : officePreview?.type === 'excel' ? (
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse text-sm text-right">
                            <tbody>
                              {officePreview.rows.map((row, rIdx) => (
                                <tr
                                  key={rIdx}
                                  className={
                                    rIdx === 0
                                      ? 'bg-slate-100 dark:bg-slate-800 font-bold'
                                      : 'border-t border-slate-200 dark:border-slate-800'
                                  }
                                >
                                  {row.map((cell, cIdx) => (
                                    <td
                                      key={cIdx}
                                      className="px-3 py-2 border-l border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200"
                                    >
                                      {cell}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : officePreview?.type === 'legacy' ? (
                        <p className="text-center text-slate-600 dark:text-slate-300 py-8">
                          {officePreview.message}
                        </p>
                      ) : null}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
