import React, { useState } from 'react';
import { Search, BookOpen, PenTool, CheckCircle, ChevronRight, Bookmark, Sparkles, Filter } from 'lucide-react';
import { BIOLOGY_CHAPTERS, ALL_19_CHAPTER_TITLES, ChapterData } from '../data/biologyData';

interface NotesTabProps {
  selectedClass: '11' | '12';
  onSelectChapter: (chapter: ChapterData, initialTab?: 'premium' | 'handwritten' | 'ncert' | 'solutions' | 'mcq' | 'important' | 'mindmap') => void;
  bookmarkedChapterIds: number[];
  onToggleBookmark: (id: number) => void;
}

export const NotesTab: React.FC<NotesTabProps> = ({
  selectedClass,
  onSelectChapter,
  bookmarkedChapterIds,
  onToggleBookmark,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUnit, setSelectedUnit] = useState<string>('all');
  const [activeNoteType, setActiveNoteType] = useState<'all' | 'premium' | 'handwritten'>('all');

  const units = [
    { id: 'all', label: 'सभी अध्याय' },
    { id: 'इकाई 1', label: 'इकाई 1: विविधता' },
    { id: 'इकाई 2', label: 'इकाई 2: शारीरिकी' },
    { id: 'इकाई 3', label: 'इकाई 3: कोशिका' },
    { id: 'इकाई 4', label: 'इकाई 4: पादप' },
    { id: 'इकाई 5', label: 'इकाई 5: मानव' },
  ];

  // Filter 19 chapters
  const filteredChapters = ALL_19_CHAPTER_TITLES.filter((ch) => {
    const matchesUnit = selectedUnit === 'all' || ch.unit.includes(selectedUnit);
    const matchesQuery =
      ch.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ch.eng.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ch.no.toString().includes(searchQuery);
    return matchesUnit && matchesQuery;
  });

  return (
    <div className="w-full max-w-md mx-auto px-4 pt-3 pb-24 space-y-4">
      {/* Title & Stats */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800 font-devanagari">
            कक्षा {selectedClass} जीव विज्ञान अध्याय
          </h2>
          <p className="text-xs text-slate-500">
            कुल 19 अध्याय · NCERT नवीनतम पाठ्यक्रम 2026-27
          </p>
        </div>

        <div className="flex items-center gap-1 bg-teal-50 border border-teal-200 text-teal-800 px-2.5 py-1 rounded-lg text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5 text-teal-600" />
          <span>100% सिलेबस</span>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="अध्याय या टॉपिक खोजें (उदा. कोशिका, प्रकाश संश्लेषण)..."
          className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00838f] text-slate-800 shadow-sm"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
          >
            साफ करें
          </button>
        )}
      </div>

      {/* Unit Selector Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {units.map((u) => (
          <button
            key={u.id}
            onClick={() => setSelectedUnit(u.id)}
            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              selectedUnit === u.id
                ? 'bg-[#00838f] text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {u.label}
          </button>
        ))}
      </div>

      {/* Note type filter pill bar */}
      <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
        <button
          onClick={() => setActiveNoteType('all')}
          className={`py-1.5 rounded-lg transition-colors ${
            activeNoteType === 'all'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          सभी सामग्री
        </button>
        <button
          onClick={() => setActiveNoteType('premium')}
          className={`py-1.5 rounded-lg flex items-center justify-center gap-1 transition-colors ${
            activeNoteType === 'premium'
              ? 'bg-white text-sky-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-3 h-3 text-sky-600" />
          प्रीमियम
        </button>
        <button
          onClick={() => setActiveNoteType('handwritten')}
          className={`py-1.5 rounded-lg flex items-center justify-center gap-1 transition-colors ${
            activeNoteType === 'handwritten'
              ? 'bg-white text-teal-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PenTool className="w-3 h-3 text-teal-600" />
          हस्तलिखित
        </button>
      </div>

      {/* Chapters List */}
      <div className="space-y-2.5">
        {filteredChapters.map((ch) => {
          // Check if we have rich mock chapter data or fallback
          const richChapter =
            BIOLOGY_CHAPTERS.find((c) => c.chapterNumber === ch.no) || {
              ...BIOLOGY_CHAPTERS[0],
              id: ch.no,
              chapterNumber: ch.no,
              title: ch.title,
              englishTitle: ch.eng,
              unit: ch.unit,
            };

          const isBookmarked = bookmarkedChapterIds.includes(ch.no);

          return (
            <div
              key={ch.no}
              className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm hover:shadow transition-all group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  {/* Chapter badge */}
                  <span className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 text-[#00838f] font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                    {ch.no}
                  </span>

                  <div>
                    <h3 className="text-sm font-bold text-slate-900 font-devanagari group-hover:text-[#00838f] transition-colors leading-snug">
                      अध्याय {ch.no}: {ch.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 font-medium">
                      {ch.eng} · {ch.unit} · <span className="text-amber-700 font-semibold">{ch.imp}</span>
                    </p>
                  </div>
                </div>

                {/* Bookmark action */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleBookmark(ch.no);
                  }}
                  className="p-1 rounded-md text-slate-400 hover:text-amber-500 transition-colors"
                  title={isBookmarked ? 'बुकमार्क हटाया गया' : 'बुकमार्क करें'}
                >
                  <Bookmark
                    className={`w-4 h-4 ${
                      isBookmarked
                        ? 'fill-amber-500 text-amber-500'
                        : 'text-slate-400'
                    }`}
                  />
                </button>
              </div>

              {/* Action buttons on card */}
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-1.5 text-xs">
                <button
                  onClick={() => onSelectChapter(richChapter, 'premium')}
                  className="flex-1 py-1 px-2 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  <BookOpen className="w-3 h-3" />
                  प्रीमियम नोट्स
                </button>

                <button
                  onClick={() => onSelectChapter(richChapter, 'handwritten')}
                  className="flex-1 py-1 px-2 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100 font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  <PenTool className="w-3 h-3" />
                  हस्तलिखित
                </button>

                <button
                  onClick={() => onSelectChapter(richChapter, 'solutions')}
                  className="py-1 px-2 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  समाधान
                </button>
              </div>
            </div>
          );
        })}

        {filteredChapters.length === 0 && (
          <div className="text-center py-8 text-slate-500 text-xs">
            कोई अध्याय नहीं मिला। कृपया दूसरा शब्द खोजें।
          </div>
        )}
      </div>
    </div>
  );
};
