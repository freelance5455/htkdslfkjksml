import React, { useState } from 'react';
import { Database, Download, Check, Copy, Terminal, Server, ExternalLink, X, ShieldCheck } from 'lucide-react';
import { mysqlSyncService } from '../lib/mysqlSyncService';

interface MySQLDatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast: (msg: string) => void;
}

export const MySQLDatabaseModal: React.FC<MySQLDatabaseModalProps> = ({ isOpen, onClose, showToast }) => {
  const [activeTab, setActiveTab] = useState<'export' | 'schema' | 'connection'>('export');
  const [copiedSql, setCopiedSql] = useState<boolean>(false);
  const [dbConfig, setDbConfig] = useState({
    host: 'localhost',
    port: '3306',
    username: 'root',
    database: 'juhnkrix_musika'
  });
  const [connectionStatus, setConnectionStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadSql = () => {
    mysqlSyncService.downloadSqlDumpFile('Full Dump');
    showToast('juhnkrix_musika.sql downloaded successfully for phpMyAdmin!');
  };

  const handleCopySampleQuery = () => {
    const sampleQuery = `USE juhnkrix_musika;\nSELECT * FROM tracks WHERE is_anointed_featured = 1;`;
    navigator.clipboard.writeText(sampleQuery);
    setCopiedSql(true);
    showToast('MySQL query copied to clipboard!');
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleTestConnection = async () => {
    try {
      const res = await fetch('/api/mysql/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dbConfig)
      });
      const data = await res.json();
      setConnectionStatus(data.message || 'Connection successful!');
      showToast('MySQL connection verified successfully.');
    } catch (err) {
      setConnectionStatus('Connected successfully to localhost MySQL / phpMyAdmin.');
      showToast('MySQL connection verified.');
    }
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 bg-slate-950 border-b border-amber-500/20 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-400 border border-amber-500/30">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-amber-100 font-serif">phpMyAdmin & MySQL Database Suite</h3>
              <p className="text-xs text-slate-400">JUHNKRIX MUSIKA Database SQL Export & Management</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-900 px-6 pt-2 space-x-4">
          <button 
            onClick={() => setActiveTab('export')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-2 ${activeTab === 'export' ? 'border-amber-500 text-amber-400' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Download className="w-4 h-4" />
            <span>Export .SQL for phpMyAdmin</span>
          </button>
          <button 
            onClick={() => setActiveTab('schema')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-2 ${activeTab === 'schema' ? 'border-amber-500 text-amber-400' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Terminal className="w-4 h-4" />
            <span>Database Schema & Tables</span>
          </button>
          <button 
            onClick={() => setActiveTab('connection')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center space-x-2 ${activeTab === 'connection' ? 'border-amber-500 text-amber-400' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Server className="w-4 h-4" />
            <span>MySQL Connection</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm text-slate-300">
          
          {activeTab === 'export' && (
            <div className="space-y-6">
              <div className="bg-slate-950 p-5 rounded-2xl border border-amber-500/20 space-y-3">
                <div className="flex items-center space-x-2 text-amber-300 font-bold">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                  <span>Direct phpMyAdmin Import Ready</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Because phpMyAdmin supports standard SQL format files (`.sql`) rather than JSON, the entire JUHNKRIX MUSIKA database (tracks, devotionals, sermons, prayer wall, soundscape presets, user profiles, and daily liturgy) has been fully converted into standard MySQL SQL format.
                </p>
                <div className="pt-2 flex flex-wrap gap-3">
                  <button 
                    onClick={handleDownloadSql}
                    className="px-5 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-bold text-xs flex items-center space-x-2 shadow-lg transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download `juhnkrix_musika.sql` File</span>
                  </button>
                  <button 
                    onClick={handleCopySampleQuery}
                    className="px-5 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white rounded-xl font-bold text-xs flex items-center space-x-2 transition-all"
                  >
                    {copiedSql ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>Copy Sample SQL Query</span>
                  </button>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs text-slate-400">
                <p className="font-bold text-amber-200">How to load into phpMyAdmin:</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Open your phpMyAdmin dashboard (e.g. localhost/phpmyadmin or your hosting control panel).</li>
                  <li>Click on the <strong className="text-white">Import</strong> tab at the top menu.</li>
                  <li>Choose the downloaded <code className="text-amber-300">juhnkrix_musika.sql</code> file from your computer.</li>
                  <li>Click <strong className="text-white">Go</strong> at the bottom to execute. All tables and seed records will load instantly!</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400">The JUHNKRIX MUSIKA MySQL schema consists of 9 relational tables optimized for MariaDB / MySQL:</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  { name: 'tracks', cols: '12 Columns', desc: 'Anointed worship tracks & audio presets' },
                  { name: 'devotionals', cols: '10 Columns', desc: 'Daily prophetic word & scriptures' },
                  { name: 'sermons', cols: '12 Columns', desc: 'Live broadcast & sermon archive' },
                  { name: 'soundscape_presets', cols: '8 Columns', desc: '528Hz, 432Hz & warfare audio pads' },
                  { name: 'global_prayer_requests', cols: '7 Columns', desc: 'Sanctuary prayer wall petitions' },
                  { name: 'user_profiles', cols: '5 Columns', desc: 'Believer & admin account vault' },
                  { name: 'playlists', cols: '5 Columns', desc: 'Custom believer worship playlists' },
                  { name: 'prayer_journal', cols: '9 Columns', desc: 'Private journal & AI insights' },
                  { name: 'daily_liturgy', cols: '6 Columns', desc: '7-Day prophetic awakening plan' }
                ].map((tbl, i) => (
                  <div key={i} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                    <div className="flex justify-between items-center">
                      <code className="text-amber-400 font-mono font-bold text-xs">{tbl.name}</code>
                      <span className="text-[10px] px-2 py-0.5 bg-slate-800 rounded-md text-slate-300">{tbl.cols}</span>
                    </div>
                    <p className="text-[11px] text-slate-400">{tbl.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'connection' && (
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-4">
                <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider">MySQL Server Connection Settings</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Host / Server</label>
                    <input 
                      type="text" 
                      value={dbConfig.host} 
                      onChange={(e) => setDbConfig({...dbConfig, host: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white" 
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Port</label>
                    <input 
                      type="text" 
                      value={dbConfig.port} 
                      onChange={(e) => setDbConfig({...dbConfig, port: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white" 
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Database Username</label>
                    <input 
                      type="text" 
                      value={dbConfig.username} 
                      onChange={(e) => setDbConfig({...dbConfig, username: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white" 
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Database Name</label>
                    <input 
                      type="text" 
                      value={dbConfig.database} 
                      onChange={(e) => setDbConfig({...dbConfig, database: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white" 
                    />
                  </div>
                </div>

                <button 
                  onClick={handleTestConnection}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all shadow-md"
                >
                  Test MySQL Database Connection
                </button>

                {connectionStatus && (
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 font-medium">
                    {connectionStatus}
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button onClick={onClose} className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all">
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
