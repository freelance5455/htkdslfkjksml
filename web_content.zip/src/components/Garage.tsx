import type { Car } from "../data/game";
import { CARS } from "../data/game";
import { ArrowRight, Check, Play } from "./Icons";
import { Pill, Reveal, SectionIntro } from "./ui";
import { cn } from "../utils/cn";

function CarArt({ car }: { car: Car }) {
  const id = car.id.replace(/[^a-z0-9]/gi, "");
  return (
    <svg viewBox="0 0 280 190" className="h-full w-full" aria-hidden="true">
      <defs>
        <linearGradient id={`paint-${id}`} x1="0" y1="0" x2="1" y2="0.2">
          <stop offset="0" stopColor={car.bodyDark} />
          <stop offset="0.28" stopColor={car.bodyLight} />
          <stop offset="0.55" stopColor={car.body} />
          <stop offset="0.8" stopColor={car.bodyLight} />
          <stop offset="1" stopColor={car.bodyDark} />
        </linearGradient>
        <linearGradient id={`glass-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#233437" />
          <stop offset="1" stopColor="#080f11" />
        </linearGradient>
        <radialGradient id={`floor-${id}`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor={car.accent} stopOpacity="0.18" />
          <stop offset="1" stopColor={car.accent} stopOpacity="0" />
        </radialGradient>
      </defs>

      <ellipse cx="140" cy="138" rx="96" ry="42" fill={`url(#floor-${id})`} />
      <path d="M52 142h176" stroke="white" strokeOpacity="0.08" strokeDasharray="2 8" />
      <ellipse cx="140" cy="140" rx="58" ry="10" fill="#000" fillOpacity="0.45" />

      <g transform="translate(140 96) rotate(-6)">
        {/* wheels */}
        {[
          [-39, -36],
          [39, -36],
          [-40, 26],
          [40, 26],
        ].map(([x, y], index) => (
          <rect key={index} x={x - 5} y={y - 11} width="10" height="22" rx="4" fill="#080a08" />
        ))}

        {/* body */}
        <path
          d="M-26 -72C-14 -78 14 -78 26 -72C36 -67 38 -52 38 -30L36 38C36 56 30 64 20 66C8 69 -8 69 -20 66C-30 64 -36 56 -36 38L-38 -30C-38 -52 -36 -67 -26 -72Z"
          fill={`url(#paint-${id})`}
          stroke="white"
          strokeOpacity="0.14"
        />
        {/* spine */}
        <rect x="-4" y="-66" width="8" height="70" rx="3" fill="white" fillOpacity="0.1" />
        <rect x="-2" y="-66" width="4" height="34" rx="2" fill={car.accent} fillOpacity="0.95" />

        {/* glass */}
        <path
          d="M-22 -44C-10 -52 10 -52 22 -44L24 2C12 10 -12 10 -24 2Z"
          fill={`url(#glass-${id})`}
          stroke="white"
          strokeOpacity="0.16"
        />
        <rect x="-16" y="10" width="32" height="12" rx="4" fill="white" fillOpacity="0.07" />

        {/* mirrors */}
        <rect x="-46" y="-26" width="12" height="5" rx="2" fill={car.body} />
        <rect x="34" y="-26" width="12" height="5" rx="2" fill={car.body} />

        {/* lights */}
        <rect x="-27" y="-70" width="17" height="4" rx="2" fill="#f2ffe0" fillOpacity="0.85" />
        <rect x="10" y="-70" width="17" height="4" rx="2" fill="#f2ffe0" fillOpacity="0.85" />
        <rect x="-28" y="62" width="21" height="4" rx="2" fill={car.accent} />
        <rect x="7" y="62" width="21" height="4" rx="2" fill={car.accent} />
        <rect x="-13" y="58" width="26" height="8" rx="3" fill="#050706" />
      </g>

      <g fill="white" fillOpacity="0.16" fontFamily="JetBrains Mono, monospace" fontSize="6">
        <text x="14" y="24">VANTA // {car.trim}</text>
        <text x="14" y="34" fillOpacity="0.08">BAY 0{car.id === "night-spec" ? "1" : car.id === "phantom-rs" ? "2" : "3"}</text>
      </g>
      <path d="M14 44v-10h10" stroke={car.accent} strokeOpacity="0.45" fill="none" />
      <path d="M266 166v10h-10" stroke={car.accent} strokeOpacity="0.45" fill="none" />
    </svg>
  );
}

export function Garage({
  equippedId,
  onEquip,
  onDrive,
}: {
  equippedId: string;
  onEquip: (id: string) => void;
  onDrive: (id: string) => void;
}) {
  return (
    <section id="garage" className="relative scroll-mt-24 border-t border-white/8 py-20 sm:py-28">
      <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
        <SectionIntro
          label="The garage"
          title={
            <>
              Choose your
              <br />
              <span className="font-serif font-normal italic text-volt">weapon.</span>
            </>
          }
          copy="Three machines, one speed ceiling. The difference shows up in the gaps: how late you can turn, how hard the nitro bites, how quickly the car answers."
          aside={
            <div className="flex flex-wrap items-center gap-2">
              <Pill tone="ghost">
                <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> 3 machines available
              </Pill>
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                Selection saves to this device
              </span>
            </div>
          }
        />

        <div className="mt-10 grid gap-4 sm:mt-12 md:grid-cols-2 xl:grid-cols-3">
          {CARS.map((car, index) => {
            const equipped = car.id === equippedId;
            return (
              <Reveal key={car.id} delay={index * 90}>
                <article
                  className={cn(
                    "group relative flex h-full flex-col overflow-hidden rounded-2xl border bg-ink-900/70 transition-all duration-300",
                    equipped
                      ? "border-volt/40 shadow-[0_0_0_1px_rgba(201,250,60,0.12),0_28px_70px_-40px_rgba(201,250,60,0.35)]"
                      : "border-white/10 hover:-translate-y-1 hover:border-white/20",
                  )}
                >
                  <div className="relative h-[196px] overflow-hidden border-b border-white/8 bg-[#0a0d0a]">
                    <div
                      className="absolute inset-0 opacity-25"
                      style={{
                        backgroundImage:
                          "linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.08) 1px, transparent 1px)",
                        backgroundSize: "28px 28px",
                        maskImage: "radial-gradient(70% 70% at 50% 50%, black, transparent)",
                        WebkitMaskImage: "radial-gradient(70% 70% at 50% 50%, black, transparent)",
                      }}
                    />
                    <div
                      className="absolute inset-x-0 top-0 h-[120%] opacity-30 transition-transform duration-700 group-hover:translate-y-1"
                      style={{ background: `radial-gradient(60% 50% at 50% 70%, ${car.accent}22, transparent 70%)` }}
                    />
                    <div className="absolute left-3 top-3 flex items-center gap-2">
                      <span className="rounded-full border border-white/12 bg-white/5 px-2 py-1 font-mono text-[8px] uppercase tracking-[0.14em] text-moss-300">
                        {car.klass}
                      </span>
                      {equipped && (
                        <span className="rounded-full bg-volt px-2 py-1 font-mono text-[8px] font-semibold uppercase tracking-[0.14em] text-ink-950">
                          Equipped
                        </span>
                      )}
                    </div>
                    <span className="absolute right-3 top-3 font-mono text-[9px] tracking-[0.16em] text-moss-500">
                      0{index + 1}
                    </span>
                    <div className="absolute inset-x-0 bottom-0 top-5">
                      <CarArt car={car} />
                    </div>
                  </div>

                  <div className="flex flex-1 flex-col p-4 sm:p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-mono text-[8px] uppercase tracking-[0.18em] text-moss-500">{car.trim} series</p>
                        <h3 className="mt-1 text-[23px] font-semibold leading-none tracking-tight text-bone">
                          {car.name}
                        </h3>
                      </div>
                      <span
                        className="mt-1 h-2.5 w-2.5 rotate-45 rounded-[2px]"
                        style={{ backgroundColor: car.accent, boxShadow: `0 0 14px ${car.accent}66` }}
                      />
                    </div>
                    <p className="mt-2.5 min-h-[54px] text-[12.5px] leading-relaxed text-moss-300">{car.blurb}</p>

                    <div className="mt-1 space-y-2">
                      {[
                        { label: "Handling", value: car.handling },
                        { label: "Nitro", value: car.nitro },
                        { label: "Acceleration", value: car.accel },
                      ].map((stat) => (
                        <div key={stat.label} className="flex items-center gap-3">
                          <span className="w-[76px] font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">
                            {stat.label}
                          </span>
                          <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/8">
                            <span
                              className="block h-full rounded-full transition-all duration-500"
                              style={{ width: `${stat.value}%`, backgroundColor: car.accent, opacity: 0.9 }}
                            />
                          </span>
                          <span className="w-6 text-right font-mono text-[9px] tabular-nums text-moss-300">{stat.value}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-white/8 pt-3 font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">
                      <span>Top speed</span>
                      <span className="text-[11px] font-medium normal-case tracking-normal text-bone">200 km/h</span>
                    </div>

                    <div className="mt-3.5 flex gap-2">
                      <button
                        type="button"
                        onClick={() => onEquip(car.id)}
                        className={cn(
                          "inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-[11px] font-semibold uppercase tracking-[0.1em] transition",
                          equipped
                            ? "border border-volt/30 bg-volt/10 text-volt hover:bg-volt/15"
                            : "bg-bone text-ink-950 hover:bg-volt",
                        )}
                      >
                        {equipped ? (
                          <>
                            <Check className="h-3.5 w-3.5" /> Selected
                          </>
                        ) : (
                          <>Equip car</>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDrive(car.id)}
                        className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-white/12 bg-white/4 px-3 py-2.5 text-[11px] font-medium text-bone transition hover:border-volt/40 hover:text-volt"
                        aria-label={`Drive the ${car.name}`}
                      >
                        <Play className="h-2.5 w-2.5" />
                        Drive
                        <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal>
          <div className="mt-5 flex flex-col justify-between gap-3 rounded-xl border border-white/8 bg-white/3 px-4 py-3 sm:flex-row sm:items-center">
            <p className="font-mono text-[9px] uppercase leading-relaxed tracking-[0.12em] text-moss-500">
              All machines are electronically limited to 200 km/h · paint and setup are cosmetic
            </p>
            <p className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.12em] text-moss-400">
              <span className="h-1 w-1 rounded-full bg-volt" /> Every setup is competitive
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
