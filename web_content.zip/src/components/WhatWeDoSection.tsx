import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import {
  ArrowLeft,
  Ticket,
  ExternalLink,
  AlertCircle,
  MapPin,
  Headphones,
  Bot,
  Globe,
  Terminal,
  MessageSquare,
  Palette,
  Box,
  Layers,
  FileCode,
  Search,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import type { ServiceProductItem } from '../types/index.ts';

interface WhatWeDoSectionProps {
  onBack?: () => void;
  isStandalonePage?: boolean;
}

export const WhatWeDoSection: React.FC<WhatWeDoSectionProps> = ({ onBack, isStandalonePage = false }) => {
  const { data } = useData();

  // Selected category filter for services & products
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [noUrlWarning, setNoUrlWarning] = useState(false);

  // Derive managed services & products from database / context
  const servicesAndProducts: ServiceProductItem[] = (data.serviceProducts || []).sort(
    (a, b) => (a.displayOrder || 0) - (b.displayOrder || 0)
  );

  // Available categories
  const categories = [
    'all',
    'Discord Bot',
    'Bot Files',
    'Web Development',
    'Discord Services',
    'Coding',
    'Graphic Design',
    'Digital Products',
    'Custom Solutions'
  ];

  const filteredItems = servicesAndProducts.filter((item) => {
    const matchesCat =
      selectedCategory === 'all' || item.category?.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch =
      !searchQuery.trim() ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const getServiceIcon = (iconName?: string) => {
    switch (iconName?.toLowerCase()) {
      case 'bot':
        return <Bot className="w-5 h-5 text-cyan-400" />;
      case 'filecode':
        return <FileCode className="w-5 h-5 text-blue-400" />;
      case 'globe':
        return <Globe className="w-5 h-5 text-emerald-400" />;
      case 'messagesquare':
        return <MessageSquare className="w-5 h-5 text-indigo-400" />;
      case 'terminal':
        return <Terminal className="w-5 h-5 text-cyan-300" />;
      case 'palette':
        return <Palette className="w-5 h-5 text-purple-400" />;
      case 'layers':
        return <Layers className="w-5 h-5 text-amber-400" />;
      default:
        return <Box className="w-5 h-5 text-cyan-400" />;
    }
  };

  const handleOpenTicket = () => {
    // Retrieve latest saved link from settings
    const configuredUrl = data?.settings?.ticketDiscordUrl || data?.settings?.discordUrl || '';
    const trimmed = configuredUrl.trim();

    if (!trimmed || (!trimmed.startsWith('http://') && !trimmed.startsWith('https://'))) {
      setNoUrlWarning(true);
      return;
    }

    setNoUrlWarning(false);
    window.open(trimmed, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="what-we-do" className="relative scroll-mt-24">
      {/* Hidden anchor element to ensure legacy #services links also scroll here smoothly */}
      <div id="services" className="absolute -top-24 left-0 pointer-events-none" />

      <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-12 sm:py-16 animate-fadeIn">
        {/* Optional Standalone Top Navigation */}
        {isStandalonePage && onBack && (
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer group"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              <span>Back to Home</span>
            </button>
            <span className="text-xs font-mono text-cyan-400/80 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-500/20">
              Cubix Studio • Capabilities
            </span>
          </div>
        )}

        {/* Section Header & Introduction */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 border border-cyan-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>WHAT WE DO</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-['Plus_Jakarta_Sans']">
            Engineering Digital Power &amp; Custom Experiences.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Cubix Studio provides Discord services, web development, coding, Discord bot development, bot files, digital products, graphic design, and custom solutions. Built with technical precision, clean architecture, and dedicated client support.
          </p>
        </div>

        {/* Category Selection Filter & Search */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search services or products..."
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 font-sans transition-colors"
              />
            </div>

            <div className="text-xs text-slate-400 font-mono">
              Showing <span className="text-cyan-400 font-bold">{filteredItems.length}</span> available items
            </div>
          </div>

          {/* Categories Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory.toLowerCase() === cat.toLowerCase()
                    ? 'bg-cyan-400 text-slate-950 font-bold shadow-[0_0_15px_rgba(0,210,255,0.3)]'
                    : 'bg-white/[0.04] text-slate-300 hover:bg-white/[0.08] hover:text-white border border-white/10'
                }`}
              >
                {cat === 'all' ? 'All Offerings' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Services and Products Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-12">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group relative p-6 rounded-2xl bg-gradient-to-b from-[#071526]/80 to-[#040e1b]/80 border border-white/10 hover:border-cyan-500/40 transition-all duration-300 flex flex-col justify-between shadow-lg hover:shadow-[0_10px_30px_rgba(0,210,255,0.1)]"
            >
              <div>
                {/* Card Header: Icon, Category & Availability */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getServiceIcon(item.iconName)}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300">
                      {item.category}
                    </span>
                    {item.available !== false ? (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        Available
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        Unavailable
                      </span>
                    )}
                  </div>
                </div>

                {/* Name & Badge */}
                <div className="space-y-1 mb-2">
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {item.name}
                  </h3>
                  {item.badge && (
                    <span className="inline-block text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-500/20">
                      {item.badge}
                    </span>
                  )}
                </div>

                {/* Description */}
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {item.description}
                </p>

                {/* Bullet Points */}
                {item.points && item.points.length > 0 && (
                  <ul className="space-y-2 mb-4 border-t border-white/5 pt-3">
                    {item.points.map((pt, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-[11px] text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Card Footer: Price & Type */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono text-[11px]">
                  {item.type === 'product' ? 'Digital Product' : 'Engineered Service'}
                </span>
                {item.price ? (
                  <span className="font-mono font-bold text-cyan-300 bg-cyan-950/40 px-2.5 py-1 rounded border border-cyan-500/20">
                    {item.price}
                  </span>
                ) : (
                  <span className="text-slate-400 text-[11px] font-mono">Custom Scope</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12 px-4 rounded-2xl bg-[#06111f] border border-white/10 mb-12">
            <p className="text-slate-400 text-sm">No services or products found matching your filter.</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-3 text-xs text-cyan-400 hover:text-cyan-300 font-semibold underline cursor-pointer"
            >
              Clear Filters
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 1. WIDE, SHORT MAP OF GURGAON, HARYANA, INDIA (EXACT DESIGN & POSITION) */}
        {/* ========================================================================= */}
        <div className="mb-8 rounded-2xl overflow-hidden border border-cyan-500/25 shadow-[0_10px_30px_rgba(0,0,0,0.5)] bg-[#071322]">
          <div className="flex items-center justify-between px-4 py-2.5 bg-[#050e1a] border-b border-white/10 text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span>Studio Location: Gurgaon, Haryana, India</span>
            </div>
            <span className="text-[11px] font-mono text-cyan-400/80">Global Client Engagements</span>
          </div>
          {/* Horizontally wide, short map */}
          <div className="w-full h-44 sm:h-52 relative">
            <iframe
              title="Cubix Studio Location - Gurgaon, Haryana, India"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d112318.57242139634!2d76.953179!3d28.4594965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d19d582e38859%3A0x2cf5fe8e5c64b1e!2sGurugram%2C%20Haryana!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) contrast(110%) opacity(0.85)' }}
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full h-full"
            />
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. SMALL, CLEAN SUPPORT TICKET SECTION DIRECTLY BELOW THE MAP */}
        {/* No forms, no email/username/Discord ID inputs; opens configured voice URL */}
        {/* ========================================================================= */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#071527] to-[#040e1b] border border-cyan-500/30 shadow-[0_10px_35px_rgba(0,0,0,0.5)] text-center max-w-2xl mx-auto space-y-4">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(0,210,255,0.2)]">
            <Headphones className="w-6 h-6" />
          </div>

          <div className="space-y-1.5">
            <span className="text-[11px] font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3 py-0.5 rounded-full border border-cyan-500/30">
              LIVE VOICE &amp; SUPPORT DESK
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Ready to Talk? Open a Ticket.
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm max-w-lg mx-auto leading-relaxed">
              Connect directly with the Cubix Studio team through our Discord voice channel or ticket desk for live inquiries, scope planning, and custom technical assistance.
            </p>
          </div>

          {/* Notice if no URL is configured */}
          {noUrlWarning && (
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-center gap-2 max-w-md mx-auto animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
              <span>
                No ticket channel link is currently configured. Please contact the administrator or reach out at{' '}
                <span className="font-mono text-white underline">{data?.settings?.contactEmail || 'real1cubix@gmail.com'}</span>.
              </span>
            </div>
          )}

          <div className="pt-2">
            <button
              onClick={handleOpenTicket}
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-sm tracking-wide shadow-[0_0_25px_rgba(0,210,255,0.3)] hover:shadow-[0_0_35px_rgba(0,210,255,0.5)] transition-all cursor-pointer transform hover:-translate-y-0.5"
            >
              <Ticket className="w-4 h-4" />
              <span>Open a Ticket</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
