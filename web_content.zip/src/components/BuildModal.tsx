import React, { useState } from 'react';
import { GeneratedApkResult } from '../types/apk';
import {
  CheckCircle2,
  Download,
  FolderArchive,
  Smartphone,
  Copy,
  Check,
  Shield,
  FileCode,
  Terminal,
  ExternalLink,
  X,
} from 'lucide-react';

interface BuildModalProps {
  isOpen: boolean;
  onClose: () => void;
  isBuilding: boolean;
  progressStep: string;
  progressPercent: number;
  result: GeneratedApkResult | null;
  onOpenInstallGuide: () => void;
}

export const BuildModal: React.FC<BuildModalProps> = ({
  isOpen,
  onClose,
  isBuilding,
  progressStep,
  progressPercent,
  result,
  onOpenInstallGuide,
}) => {
  const [copiedSha, setCopiedSha] = useState(false);
  const [copiedAdb, setCopiedAdb] = useState(false);

  if (!isOpen) return null;

  const handleDownloadApk = () => {
    if (!result) return;
    const url = URL.createObjectURL(result.apkBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = result.apkFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  const handleDownloadProject = () => {
    if (!result) return;
    const url = URL.createObjectURL(result.projectZipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = result.projectFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  const copySha256 = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.sha256Fingerprint);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const adbCommand = result ? `adb install -r ${result.apkFileName}` : 'adb install -r app.apk';

  const copyAdb = () => {
    navigator.clipboard.writeText(adbCommand);
    setCopiedAdb(true);
    setTimeout(() => setCopiedAdb(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-base">
              {isBuilding ? 'Building Android APK Package' : 'Android Build Complete'}
            </h3>
          </div>
          {!isBuilding && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Active Compiling Progress State */}
          {isBuilding && (
            <div className="py-8 space-y-5 text-center">
              <div className="relative w-20 h-20 mx-auto">
                <div className="w-20 h-20 rounded-full border-4 border-slate-800 border-t-emerald-400 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Smartphone className="w-8 h-8 text-emerald-400 animate-pulse" />
                </div>
              </div>

              <div>
                <h4 className="text-base font-bold text-white mb-1">{progressStep}</h4>
                <p className="text-xs text-slate-400">Packaging Dalvik bytecode, manifest, and assets into APK</p>
              </div>

              {/* Progress Bar */}
              <div className="max-w-md mx-auto space-y-1.5">
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 transition-all duration-300 ease-out"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] font-mono text-slate-500">
                  <span>compiling assets</span>
                  <span>{progressPercent}%</span>
                </div>
              </div>
            </div>
          )}

          {/* Finished Build Result State */}
          {!isBuilding && result && (
            <div className="space-y-6">
              {/* Success Badge & App Card */}
              <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-center gap-4">
                <img
                  src={result.iconDataUrl}
                  alt={result.appName}
                  className="w-16 h-16 rounded-2xl shadow-md border border-slate-800/80 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-bold text-white truncate">{result.appName}</h4>
                    <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30 font-semibold shrink-0">
                      v{result.versionName}
                    </span>
                  </div>
                  <p className="font-mono text-xs text-slate-400 truncate mt-0.5">
                    {result.packageName}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <span className="font-semibold text-emerald-400">
                      {result.apkSize >= 1024 * 1024
                        ? `${(result.apkSize / (1024 * 1024)).toFixed(2)} MB`
                        : `${(result.apkSize / 1024).toFixed(1)} KB`}
                    </span>
                    <span>·</span>
                    <span>{result.filesCount} web files bundled</span>
                    <span>·</span>
                    <span>Verified v1/v2/v3 Signatures</span>
                  </div>
                </div>
              </div>

              {/* Primary Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={handleDownloadApk}
                  className="flex items-center justify-center gap-2.5 px-4 py-3 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-emerald-500/20 transition-all cursor-pointer text-sm"
                >
                  <Download className="w-5 h-5" />
                  <span>Download .APK File</span>
                </button>

                <button
                  onClick={handleDownloadProject}
                  className="flex items-center justify-center gap-2.5 px-4 py-3 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white font-semibold rounded-xl border border-slate-700 transition-all cursor-pointer text-sm"
                >
                  <FolderArchive className="w-5 h-5 text-emerald-400" />
                  <span>Android Studio Project (.zip)</span>
                </button>
              </div>

              {/* Install instructions quick box */}
              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span>Quick USB / ADB Install</span>
                  </div>
                  <button
                    onClick={onOpenInstallGuide}
                    className="text-emerald-400 hover:underline flex items-center gap-1 font-medium"
                  >
                    Full Guide <ExternalLink className="w-3 h-3" />
                  </button>
                </div>

                <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between font-mono text-xs text-slate-300">
                  <span className="truncate pr-2">{adbCommand}</span>
                  <button
                    onClick={copyAdb}
                    className="p-1 hover:text-emerald-400 transition-colors shrink-0"
                    title="Copy command"
                  >
                    {copiedAdb ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Security & Certificate Fingerprint */}
              <div className="p-4 bg-slate-950/50 border border-slate-800 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
                    <Shield className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Certificate SHA-256 Fingerprint</span>
                  </div>
                  <button
                    onClick={copySha256}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    {copiedSha ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="p-2 bg-slate-900/80 rounded border border-slate-800/80 font-mono text-[11px] text-slate-400 break-all select-all">
                  {result.sha256Fingerprint}
                </div>
                <p className="text-[11px] text-slate-500">
                  Signed for: CN=APKForge, O={result.companyName || 'APKForge Studio'}. Valid for direct side-loading.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        {!isBuilding && (
          <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
            <span>Target SDK: 34 (Android 14/15)</span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer font-medium"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
