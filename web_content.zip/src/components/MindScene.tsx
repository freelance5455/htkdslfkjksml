"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Sparkles, Stars } from "@react-three/drei";
import { useRef, useMemo } from "react";
import * as THREE from "three";

function Core() {
  const group = useRef<THREE.Group>(null);
  const core = useRef<THREE.Mesh>(null);
  const wire = useRef<THREE.Mesh>(null);
  const ringA = useRef<THREE.Mesh>(null);
  const ringB = useRef<THREE.Mesh>(null);
  const ringC = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (core.current) {
      core.current.rotation.y = t * 0.12;
      core.current.rotation.x = Math.sin(t * 0.2) * 0.25;
    }
    if (wire.current) {
      wire.current.rotation.y = -t * 0.07;
      wire.current.rotation.z = t * 0.05;
    }
    if (ringA.current) ringA.current.rotation.z = t * 0.16;
    if (ringB.current) { ringB.current.rotation.z = -t * 0.11; ringB.current.rotation.x = Math.PI / 2.4 + Math.sin(t * 0.13) * 0.1; }
    if (ringC.current) { ringC.current.rotation.z = t * 0.07; ringC.current.rotation.y = t * 0.19; }
  });

  return (
    <group ref={group}>
      <Float speed={1.4} rotationIntensity={0.4} floatIntensity={0.9}>
        <mesh ref={core}>
          <icosahedronGeometry args={[1.7, 1]} />
          <meshStandardMaterial
            color="#0d0d16"
            metalness={0.85}
            roughness={0.2}
            emissive="#5a48e0"
            emissiveIntensity={0.32}
            flatShading
          />
        </mesh>
        <mesh ref={wire} scale={1.012}>
          <icosahedronGeometry args={[1.7, 1]} />
          <meshBasicMaterial color="#8b7cff" wireframe transparent opacity={0.14} />
        </mesh>
        <mesh>
          <icosahedronGeometry args={[1.0, 0]} />
          <meshBasicMaterial color="#dcd6ff" transparent opacity={0.85} />
        </mesh>
      </Float>

      <mesh ref={ringA} rotation={[Math.PI / 2.1, 0, 0]}>
        <torusGeometry args={[2.7, 0.012, 8, 128]} />
        <meshBasicMaterial color="#8b7cff" transparent opacity={0.5} />
      </mesh>
      <mesh ref={ringB}>
        <torusGeometry args={[3.35, 0.008, 8, 128]} />
        <meshBasicMaterial color="#e9c46a" transparent opacity={0.28} />
      </mesh>
      <mesh ref={ringC} rotation={[0.4, 0.2, 0]}>
        <torusGeometry args={[4.1, 0.006, 8, 128]} />
        <meshBasicMaterial color="#8b7cff" transparent opacity={0.16} />
      </mesh>

      <Sparkles count={180} scale={11} size={2.2} speed={0.28} color="#8b7cff" opacity={0.6} />
      <Sparkles count={60} scale={8} size={3.5} speed={0.15} color="#e9c46a" opacity={0.35} />
    </group>
  );
}

function Pylons() {
  const pyl = useMemo(
    () =>
      Array.from({ length: 9 }, (_, i) => {
        const angle = (i / 9) * Math.PI * 2;
        const r = 7.5 + (i % 3) * 1.2;
        return {
          pos: [Math.cos(angle) * r, -2.4 - (i % 2) * 0.7, Math.sin(angle) * r - 3] as [number, number, number],
          h: 2.5 + ((i * 7) % 4),
          rot: angle,
        };
      }),
    [],
  );
  return (
    <group>
      {pyl.map((p, i) => (
        <mesh key={i} position={p.pos} rotation={[0, p.rot, 0]}>
          <boxGeometry args={[0.55, p.h, 0.55]} />
          <meshStandardMaterial color="#0b0b13" metalness={0.9} roughness={0.3} emissive="#8b7cff" emissiveIntensity={0.06} />
        </mesh>
      ))}
    </group>
  );
}

function CameraDrift() {
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const targetX = (state.pointer.x ?? 0) * 0.9;
    const targetY = 0.35 + (state.pointer.y ?? 0) * 0.5;
    state.camera.position.x = THREE.MathUtils.lerp(state.camera.position.x, targetX + Math.sin(t * 0.07) * 0.4, 0.04);
    state.camera.position.y = THREE.MathUtils.lerp(state.camera.position.y, targetY, 0.04);
    state.camera.lookAt(0, 0.2, 0);
  });
  return null;
}

export default function MindScene({ dim = false }: { dim?: boolean }) {
  return (
    <Canvas
      dpr={[1, 1.75]}
      camera={{ position: [0, 0.35, 8.6], fov: 46 }}
      gl={{ antialias: true, alpha: true }}
      style={{ position: "absolute", inset: 0, opacity: dim ? 0.45 : 1, transition: "opacity 1s ease" }}
    >
      <fog attach="fog" args={["#06060a", 9, 22]} />
      <ambientLight intensity={0.25} />
      <pointLight position={[6, 5, 6]} intensity={80} color="#8b7cff" />
      <pointLight position={[-6, -3, 4]} intensity={40} color="#e9c46a" />
      <directionalLight position={[0, 8, 2]} intensity={0.6} color="#dcd6ff" />
      <Stars radius={60} depth={40} count={1800} factor={3} saturation={0.4} fade speed={0.6} />
      <Core />
      <Pylons />
      <CameraDrift />
    </Canvas>
  );
}
