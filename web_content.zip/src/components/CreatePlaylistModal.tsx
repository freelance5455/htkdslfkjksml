import React, { useState } from 'react';
import { X, Plus, Music } from 'lucide-react';
import { useMusic } from '../context/MusicContext';

interface CreatePlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (playlistId: string) => void;
}

export const CreatePlaylistModal: React.FC<CreatePlaylistModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  const { createPlaylist } = useMusic();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newPl = createPlaylist(title.trim(), description.trim());
    setTitle('');
    setDescription('');
    onClose();
    onCreated(newPl.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#1a1a1a] border border-white/10 shadow-2xl p-6 text-white">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-red-600/20 text-red-500">
              <Music className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-base">New Playlist</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              Playlist Title
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Late Night Vibes"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#121212] border border-white/10 focus:border-red-500 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
              autoFocus
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-400 block mb-1">
              Description (optional)
            </label>
            <textarea
              placeholder="Add an optional description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full bg-[#121212] border border-white/10 focus:border-red-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim()}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-40 text-xs font-bold transition shadow-lg shadow-red-600/30"
            >
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
