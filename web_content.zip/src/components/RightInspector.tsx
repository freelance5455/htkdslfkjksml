import React, { useState } from 'react';
import {
  AlignCenter,
  AlignJustify,
  AlignLeft,
  AlignRight,
  Bold,
  Check,
  Copy,
  Italic,
  Pipette,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import {
  CustomFont,
  OverlayElement,
  TextOverlayElement,
  UILanguage,
} from '../types/pdf';
import { BUNDLED_FONTS, detectTextScript, isRtlText } from '../utils/fonts';
import { UI_COPY } from '../utils/i18n';
import { convertBijoyToUnicode, looksLikeBijoyAnsi } from '../utils/bijoyToUnicode';
import { transliteratePhoneticBangla } from '../utils/banglaPhonetic';

interface RightInspectorProps {
  lang: UILanguage;
  selectedOverlay: OverlayElement | null;
  customFonts: CustomFont[];
  isPickingBgColor: boolean;
  onClose: () => void;
  onTogglePickBgColor: () => void;
  onUpdateOverlay: (id: string, updater: (prev: OverlayElement) => OverlayElement) => void;
  onResetTextOverlay: (id: string) => void;
  onDuplicateOverlay: (id: string) => void;
  onDeleteOverlay: (id: string) => void;
  onOpenFonts: () => void;
}

const SWATCH_COLORS = ['#0f172a', '#1e3a8a', '#1d4ed8', '#334155', '#991b1b', '#065f46', '#ffffff'];

export const RightInspector: React.FC<RightInspectorProps> = ({
  lang,
  selectedOverlay,
  customFonts,
  isPickingBgColor,
  onClose,
  onTogglePickBgColor,
  onUpdateOverlay,
  onResetTextOverlay,
  onDuplicateOverlay,
  onDeleteOverlay,
  onOpenFonts,
}) => {
  const t = UI_COPY[lang];
  const [inputMode, setInputMode] = useState<'system' | 'phonetic'>('system');
  const [phoneticDraft, setPhoneticDraft] = useState('');

  // Never render an empty placeholder inspector blocking the PDF
  if (!selectedOverlay) return null;

  const updateText = (patch: Partial<TextOverlayElement>) => {
    onUpdateOverlay(selectedOverlay.id, (prev) =>
      prev.kind === 'text' ? { ...prev, ...patch } : prev
    );
  };

  const panelWrapperClass =
    'fixed inset-x-0 bottom-0 max-h-[45vh] z-40 rounded-t-2xl shadow-2xl border-t border-slate-200 bg-white flex flex-col overflow-hidden lg:static lg:inset-auto lg:max-h-none lg:h-full lg:w-[280px] lg:rounded-none lg:shadow-none lg:border-t-0 lg:border-l lg:shrink-0';

  if (selectedOverlay.kind === 'text') {
    const showBijoyHelper = looksLikeBijoyAnsi(
      selectedOverlay.text,
      selectedOverlay.rawFontName || ''
    );
    const rtlMode = isRtlText(selectedOverlay.text);
    const arabicBundled = BUNDLED_FONTS.filter((f) => f.category.startsWith('arabic'));
    const urduPersianBundled = BUNDLED_FONTS.filter(
      (f) => f.category === 'urdu-nastaliq' || f.category === 'persian-sans'
    );
    const otherBundled = BUNDLED_FONTS.filter(
      (f) =>
        !f.category.startsWith('arabic') &&
        f.category !== 'urdu-nastaliq' &&
        f.category !== 'persian-sans'
    );
    const handleSmartTextChange = (nextText: string) => {
      if (!selectedOverlay.sourceBlockId && nextText.trim()) {
        const prevScript = detectTextScript(selectedOverlay.text);
        const nextScript = detectTextScript(nextText);
        if (nextScript !== prevScript) {
          const patch: Partial<TextOverlayElement> = { text: nextText };
          if (nextScript === 'ur') {
            patch.fontId = 'noto-nastaliq-urdu';
            patch.textAlign = 'right';
          } else if (nextScript === 'fa') {
            patch.fontId = 'vazirmatn-persian';
            patch.textAlign = 'right';
          } else if (nextScript === 'ar') {
            patch.fontId = 'noto-naskh-arabic';
            patch.textAlign = 'right';
          } else if (nextScript === 'bn') {
            patch.fontId = 'noto-sans-bengali';
            patch.textAlign = 'left';
          } else {
            patch.fontId = 'plus-jakarta-sans';
            patch.textAlign = 'left';
          }
          updateText(patch);
          return;
        }
      }
      updateText({ text: nextText });
    };
    const applyFontSize = (nextSize: number) => {
      const clamped = Math.max(6, Math.min(96, Number(nextSize.toFixed(1))));
      updateText({
        fontSize: clamped,
        height: Math.max(selectedOverlay.height, clamped * selectedOverlay.lineHeight),
      });
    };
    const phoneticPreview = transliteratePhoneticBangla(phoneticDraft);

    return (
      <aside
        data-inspector-panel="true"
        tabIndex={-1}
        className={panelWrapperClass}
      >
        {/* Panel Top Header */}
        <div className="px-3.5 py-2.5 border-b border-slate-200 bg-[#FAFAFB] flex items-center justify-between gap-2 shrink-0">
          <span className="text-xs font-semibold text-slate-800 truncate">
            {t.textContent}
          </span>
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="flex items-center gap-0.5 p-0.5 bg-slate-200/70 rounded-md">
              <button
                type="button"
                onClick={() => setInputMode('system')}
                className={`px-2 py-0.5 text-[11px] font-medium rounded cursor-pointer ${
                  inputMode === 'system'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                {t.inputSystem}
              </button>
              <button
                type="button"
                onClick={() => setInputMode('phonetic')}
                className={`px-2 py-0.5 text-[11px] font-medium rounded cursor-pointer ${
                  inputMode === 'phonetic'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                {t.inputPhonetic}
              </button>
            </div>
            <button
              type="button"
              onClick={onClose}
              data-tooltip={t.done}
              aria-label={t.done}
              className="p-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md cursor-pointer"
            >
              <Check className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-3.5 border-b border-slate-100 space-y-2.5">
            {inputMode === 'phonetic' && (
              <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="text-[11px] text-slate-500">{t.phoneticHint}</div>
                <input
                  type="text"
                  value={phoneticDraft}
                  onChange={(e) => setPhoneticDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && phoneticDraft.trim()) {
                      e.preventDefault();
                      const sep =
                        selectedOverlay.text && !selectedOverlay.text.endsWith(' ')
                          ? ' '
                          : '';
                      updateText({
                        text: selectedOverlay.text + sep + phoneticPreview,
                      });
                      setPhoneticDraft('');
                    }
                  }}
                  placeholder="amar sonar bangla..."
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded focus:outline-none focus:border-blue-600"
                />
                {phoneticDraft && (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-blue-800 truncate">
                      {phoneticPreview}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const sep =
                          selectedOverlay.text && !selectedOverlay.text.endsWith(' ')
                            ? ' '
                            : '';
                        updateText({
                          text: selectedOverlay.text + sep + phoneticPreview,
                        });
                        setPhoneticDraft('');
                      }}
                      className="px-2 py-1 text-[11px] font-semibold text-white bg-blue-700 rounded cursor-pointer shrink-0"
                    >
                      + Add
                    </button>
                  </div>
                )}
              </div>
            )}

            <textarea
              rows={Math.min(5, Math.max(2, selectedOverlay.text.split('\n').length))}
              dir={rtlMode ? 'rtl' : 'auto'}
              value={selectedOverlay.text}
              onChange={(e) => handleSmartTextChange(e.target.value)}
              className="w-full px-2.5 py-2 text-sm text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 resize-y leading-relaxed"
              style={{
                fontFamily:
                  '"Noto Sans Bengali Local", "Noto Naskh Arabic", "Vazirmatn", "Noto Nastaliq Urdu", "Cairo", "Plus Jakarta Sans", sans-serif',
              }}
            />

            {showBijoyHelper && (
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg space-y-2">
                <p className="text-[11px] text-amber-900 leading-snug">
                  {t.bijoyNotice}
                </p>
                <button
                  type="button"
                  onClick={() =>
                    updateText({ text: convertBijoyToUnicode(selectedOverlay.text) })
                  }
                  className="w-full py-1.5 px-2.5 text-xs font-semibold text-amber-950 bg-amber-200/70 hover:bg-amber-200 rounded cursor-pointer"
                >
                  {t.convertBijoy}
                </button>
              </div>
            )}
          </div>

          {/* Font & Typography */}
          <div className="p-3.5 border-b border-slate-100 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-800">
                {t.fontPreservation}
              </span>
              <button
                type="button"
                onClick={onOpenFonts}
                className="text-[11px] font-medium text-blue-700 hover:underline cursor-pointer"
              >
                + Google / TTF
              </button>
            </div>

            {selectedOverlay.rawFontName && (
              <div className="text-[11px] text-slate-500 truncate">
                {t.originalFont}:{' '}
                <span className="font-medium text-slate-700">
                  {selectedOverlay.rawFontName}
                </span>
              </div>
            )}

            <div>
              <label className="block text-[11px] text-slate-500 mb-1">
                {t.fontFamily}
              </label>
              <select
                value={selectedOverlay.fontId}
                onChange={(e) => updateText({ fontId: e.target.value })}
                className="w-full px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-blue-600"
              >
                {customFonts.length > 0 && (
                  <optgroup label={t.fontGroupDeviceGoogle}>
                    {customFonts.map((cf) => (
                      <option key={cf.id} value={cf.id}>
                        {cf.name}
                      </option>
                    ))}
                  </optgroup>
                )}
                <optgroup label={t.fontGroupBanglaEnglish}>
                  {otherBundled.map((bf) => (
                    <option key={bf.id} value={bf.id}>
                      {lang === 'bn' ? bf.labelBn : bf.label}
                    </option>
                  ))}
                </optgroup>
                <optgroup label={t.fontGroupArabic}>
                  {arabicBundled.map((bf) => (
                    <option key={bf.id} value={bf.id}>
                      {lang === 'bn' ? bf.labelBn : bf.label}
                    </option>
                  ))}
                </optgroup>
                <optgroup label={t.fontGroupUrduPersian}>
                  {urduPersianBundled.map((bf) => (
                    <option key={bf.id} value={bf.id}>
                      {lang === 'bn' ? bf.labelBn : bf.label}
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* Easy Font Size Resizer (A- / Input / A+ + Slider) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] text-slate-500">
                  {t.fontSize} (pt)
                </label>
                <span className="text-[11px] font-mono tabular-nums text-slate-600">
                  {selectedOverlay.fontSize} pt
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  data-tooltip={t.decreaseFontSize}
                  aria-label={t.decreaseFontSize}
                  onClick={() => applyFontSize(selectedOverlay.fontSize - 1)}
                  className="px-2.5 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-lg cursor-pointer shrink-0"
                >
                  A-
                </button>
                <input
                  type="number"
                  min={6}
                  max={96}
                  step={0.5}
                  value={selectedOverlay.fontSize}
                  onChange={(e) => applyFontSize(Number(e.target.value) || 12)}
                  className="w-full px-2 py-1.5 text-xs text-center font-mono tabular-nums bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
                <button
                  type="button"
                  data-tooltip={t.increaseFontSize}
                  aria-label={t.increaseFontSize}
                  onClick={() => applyFontSize(selectedOverlay.fontSize + 1)}
                  className="px-2.5 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-lg cursor-pointer shrink-0"
                >
                  A+
                </button>
              </div>

              <input
                type="range"
                min={6}
                max={72}
                step={0.5}
                value={Math.min(72, selectedOverlay.fontSize)}
                onChange={(e) => applyFontSize(Number(e.target.value))}
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-500 mb-1">
                {t.lineHeight}
              </label>
              <input
                type="number"
                min={0.9}
                max={2.5}
                step={0.05}
                value={selectedOverlay.lineHeight}
                onChange={(e) =>
                  updateText({
                    lineHeight: Math.max(0.9, Number(e.target.value) || 1.25),
                  })
                }
                className="w-full px-2 py-1.5 text-xs font-mono tabular-nums bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            {/* Style + Align */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  data-tooltip={t.bold}
                  aria-label={t.bold}
                  onClick={() =>
                    updateText({
                      fontWeight:
                        selectedOverlay.fontWeight === 'bold' ? 'normal' : 'bold',
                    })
                  }
                  className={`p-1.5 rounded-md border text-xs cursor-pointer ${
                    selectedOverlay.fontWeight === 'bold'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  data-tooltip={t.italic}
                  aria-label={t.italic}
                  onClick={() =>
                    updateText({
                      fontStyle:
                        selectedOverlay.fontStyle === 'italic' ? 'normal' : 'italic',
                    })
                  }
                  className={`p-1.5 rounded-md border text-xs cursor-pointer ${
                    selectedOverlay.fontStyle === 'italic'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-0.5 p-0.5 bg-slate-100 rounded-md">
                {(['left', 'center', 'right', 'justify'] as const).map((al) => {
                  const Icon =
                    al === 'left'
                      ? AlignLeft
                      : al === 'center'
                      ? AlignCenter
                      : al === 'right'
                      ? AlignRight
                      : AlignJustify;
                  const alignLabel =
                    al === 'left'
                      ? t.alignLeft
                      : al === 'center'
                      ? t.alignCenter
                      : al === 'right'
                      ? t.alignRight
                      : t.alignJustify;
                  return (
                    <button
                      key={al}
                      type="button"
                      data-tooltip={alignLabel}
                      aria-label={alignLabel}
                      onClick={() => updateText({ textAlign: al })}
                      className={`p-1.5 rounded cursor-pointer ${
                        selectedOverlay.textAlign === al
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Text Color */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] text-slate-500">{t.textColor}</span>
                <div className="flex items-center gap-2">
                  {selectedOverlay.originalColor &&
                    selectedOverlay.color.toLowerCase() !==
                      selectedOverlay.originalColor.toLowerCase() && (
                      <button
                        type="button"
                        onClick={() =>
                          updateText({ color: selectedOverlay.originalColor! })
                        }
                        className="text-[11px] font-medium text-blue-700 hover:underline cursor-pointer"
                      >
                        {t.originalColorBtn}
                      </button>
                    )}
                  <span className="text-[11px] font-mono tabular-nums text-slate-500">
                    {selectedOverlay.color.toUpperCase()}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <input
                  type="color"
                  value={selectedOverlay.color}
                  onChange={(e) => updateText({ color: e.target.value })}
                  className="w-6 h-6 rounded border border-slate-200 cursor-pointer p-0 bg-transparent"
                />
                {selectedOverlay.originalColor &&
                  !SWATCH_COLORS.includes(selectedOverlay.originalColor.toLowerCase()) && (
                    <button
                      type="button"
                      data-tooltip={t.originalColorBtn}
                      aria-label={t.originalColorBtn}
                      onClick={() =>
                        updateText({ color: selectedOverlay.originalColor! })
                      }
                      style={{ backgroundColor: selectedOverlay.originalColor }}
                      className={`w-5 h-5 rounded-full border cursor-pointer ${
                        selectedOverlay.color.toLowerCase() ===
                        selectedOverlay.originalColor.toLowerCase()
                          ? 'border-blue-600 ring-1 ring-blue-600'
                          : 'border-slate-400'
                      }`}
                    />
                  )}
                {SWATCH_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => updateText({ color: c })}
                    style={{ backgroundColor: c }}
                    className={`w-5 h-5 rounded-full border cursor-pointer ${
                      selectedOverlay.color.toLowerCase() === c
                        ? 'border-blue-600 ring-1 ring-blue-600'
                        : 'border-slate-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Background Mask Section */}
          {selectedOverlay.maskRect && (
            <div className="p-3.5 border-b border-slate-100 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-800">
                  {t.backgroundMask}
                </span>
                <input
                  type="checkbox"
                  checked={selectedOverlay.maskRect.enabled}
                  onChange={(e) =>
                    updateText({
                      maskRect: {
                        ...selectedOverlay.maskRect!,
                        enabled: e.target.checked,
                      },
                    })
                  }
                  className="accent-blue-700 cursor-pointer"
                />
              </div>

              {selectedOverlay.maskRect.enabled && (
                <>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <input
                        type="color"
                        value={selectedOverlay.maskRect.color}
                        onChange={(e) =>
                          updateText({
                            maskRect: {
                              ...selectedOverlay.maskRect!,
                              color: e.target.value,
                            },
                          })
                        }
                        className="w-6 h-6 rounded border border-slate-200 cursor-pointer p-0"
                      />
                      <span className="text-[11px] font-mono tabular-nums text-slate-600">
                        {selectedOverlay.maskRect.color.toUpperCase()}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={onTogglePickBgColor}
                      className={`inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md border cursor-pointer ${
                        isPickingBgColor
                          ? 'bg-blue-700 text-white border-blue-700'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <Pipette className="w-3 h-3" />
                      <span className="truncate">{t.pickFromPage}</span>
                    </button>
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                      <span>{t.maskPadding}</span>
                      <span className="font-mono tabular-nums">
                        {selectedOverlay.maskRect.padding} pt
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={8}
                      step={0.5}
                      value={selectedOverlay.maskRect.padding}
                      onChange={(e) =>
                        updateText({
                          maskRect: {
                            ...selectedOverlay.maskRect!,
                            padding: Number(e.target.value),
                          },
                        })
                      }
                      className="w-full accent-blue-700"
                    />
                  </div>
                </>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="p-3.5 flex flex-wrap gap-2">
            {selectedOverlay.originalText !== undefined && (
              <button
                type="button"
                onClick={() => onResetTextOverlay(selectedOverlay.id)}
                className="flex-1 py-2 px-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.resetToOriginal}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onDuplicateOverlay(selectedOverlay.id)}
              className="py-2 px-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{t.duplicateBlock}</span>
            </button>
            <button
              type="button"
              onClick={() => onDeleteOverlay(selectedOverlay.id)}
              className="py-2 px-2.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.deleteBlock}</span>
            </button>
          </div>
        </div>
      </aside>
    );
  }

  // Patch / Shape / Pen / Image Inspector
  const title =
    selectedOverlay.kind === 'patch'
      ? t.patchSettings
      : selectedOverlay.kind === 'shape'
      ? t.shapeSettings
      : selectedOverlay.kind === 'pen'
      ? t.penSettings
      : t.imageSettings;

  return (
    <aside
      data-inspector-panel="true"
      tabIndex={-1}
      className={panelWrapperClass}
    >
      <div className="px-3.5 py-2.5 border-b border-slate-200 bg-[#FAFAFB] flex items-center justify-between gap-2 shrink-0">
        <span className="text-xs font-semibold text-slate-800">{title}</span>
        <button
          type="button"
          onClick={onClose}
          data-tooltip={t.done}
          aria-label={t.done}
          className="p-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md cursor-pointer"
        >
          <Check className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {selectedOverlay.kind === 'patch' && (
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-600">{t.fillColor}</span>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={selectedOverlay.fillColor}
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'patch' ? { ...prev, fillColor: e.target.value } : prev
                  )
                }
                className="w-7 h-7 rounded border border-slate-200 cursor-pointer"
              />
              <button
                type="button"
                onClick={onTogglePickBgColor}
                className={`p-1.5 rounded border cursor-pointer ${
                  isPickingBgColor
                    ? 'bg-blue-700 text-white border-blue-700'
                    : 'bg-white text-slate-700 border-slate-200'
                }`}
                data-tooltip={t.pickFromPage}
                aria-label={t.pickFromPage}
              >
                <Pipette className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {selectedOverlay.kind === 'pen' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-600">{t.strokeColor}</span>
              <input
                type="color"
                value={selectedOverlay.strokeColor}
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'pen' ? { ...prev, strokeColor: e.target.value } : prev
                  )
                }
                className="w-7 h-7 rounded border border-slate-200 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                <span>{t.strokeWidth}</span>
                <span className="font-mono tabular-nums">
                  {selectedOverlay.strokeWidth} px
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={12}
                step={0.5}
                value={selectedOverlay.strokeWidth}
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'pen'
                      ? { ...prev, strokeWidth: Number(e.target.value) }
                      : prev
                  )
                }
                className="w-full accent-blue-700"
              />
            </div>
          </div>
        )}

        {selectedOverlay.kind === 'shape' && (
          <div className="space-y-3">
            <div>
              <label className="block text-[11px] text-slate-500 mb-1">
                {t.shapeType}
              </label>
              <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
                {(['rectangle', 'highlight', 'line'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() =>
                      onUpdateOverlay(selectedOverlay.id, (prev) =>
                        prev.kind === 'shape'
                          ? {
                              ...prev,
                              shapeType: st,
                              fillColor: st === 'highlight' ? '#fde047' : prev.fillColor,
                              opacity: st === 'highlight' ? 0.38 : 1,
                            }
                          : prev
                      )
                    }
                    className={`py-1.5 text-[11px] font-medium rounded cursor-pointer ${
                      selectedOverlay.shapeType === st
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    {t[st]}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-600">{t.fillColor}</span>
              <input
                type="color"
                value={
                  selectedOverlay.fillColor === 'transparent'
                    ? '#ffffff'
                    : selectedOverlay.fillColor
                }
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'shape' ? { ...prev, fillColor: e.target.value } : prev
                  )
                }
                className="w-7 h-7 rounded border border-slate-200 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-600">{t.borderColor}</span>
              <input
                type="color"
                value={selectedOverlay.strokeColor}
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'shape' ? { ...prev, strokeColor: e.target.value } : prev
                  )
                }
                className="w-7 h-7 rounded border border-slate-200 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                <span>{t.borderWidth}</span>
                <span className="font-mono tabular-nums">
                  {selectedOverlay.strokeWidth} px
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={6}
                step={0.5}
                value={selectedOverlay.strokeWidth}
                onChange={(e) =>
                  onUpdateOverlay(selectedOverlay.id, (prev) =>
                    prev.kind === 'shape'
                      ? { ...prev, strokeWidth: Number(e.target.value) }
                      : prev
                  )
                }
                className="w-full accent-blue-700"
              />
            </div>
          </div>
        )}

        <div>
          <div className="flex justify-between text-[11px] text-slate-500 mb-1">
            <span>{t.opacity}</span>
            <span className="font-mono tabular-nums">
              {Math.round(selectedOverlay.opacity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0.1}
            max={1}
            step={0.05}
            value={selectedOverlay.opacity}
            onChange={(e) =>
              onUpdateOverlay(selectedOverlay.id, (prev) => ({
                ...prev,
                opacity: Number(e.target.value),
              }))
            }
            className="w-full accent-blue-700"
          />
        </div>

        <div className="pt-2 border-t border-slate-100 flex gap-2">
          <button
            type="button"
            onClick={() => onDuplicateOverlay(selectedOverlay.id)}
            className="flex-1 py-2 px-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg inline-flex items-center justify-center gap-1 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{t.duplicateBlock}</span>
          </button>
          <button
            type="button"
            onClick={() => onDeleteOverlay(selectedOverlay.id)}
            className="flex-1 py-2 px-2.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg inline-flex items-center justify-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.deleteBlock}</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
