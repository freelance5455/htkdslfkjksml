import { useMemo, useState } from "react";
import { Check, Coins, Cookie, Crown, Fish, Flower2, Gem, Layers, Lock, Milk, Palette, Search, Shirt, X } from "lucide-react";
import { BOWS, COLLARS, FURS, HATS, OUTFITS, type AccessoryItem, type FurStyle, type Outfit, type Slot } from "../data/catalog";
import { FOODS, SHOP_ITEMS, type Food } from "../data/items";
import { CharmShape } from "./Cat";

/* ---------- Mini previews ---------- */
export function ItemPreview({ item }: { item: AccessoryItem }) {
  const p = item.primary;
  const s = item.secondary;
  if (item.slot === "bow") {
    return (
      <svg viewBox="0 0 60 44" className="h-10 w-14">
        <path d="M27 22 L6 10 Q2 22 6 34 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" strokeLinejoin="round" />
        <path d="M33 22 L54 10 Q58 22 54 34 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" strokeLinejoin="round" />
        <circle cx="30" cy="22" r="6.5" fill={s} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" />
      </svg>
    );
  }
  if (item.slot === "collar") {
    return (
      <svg viewBox="0 0 60 44" className="h-10 w-14">
        <path d="M8 12 Q30 34 52 12" fill="none" stroke={p} strokeWidth="6" strokeLinecap="round" />
        <g transform="translate(30 27) scale(0.85)">
          <CharmShape charm={item.charm ?? "bell"} color={p} />
        </g>
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 60 44" className="h-10 w-14">
      {item.style === "bruja" && (<g><path d="M22 30 C26 16 30 10 38 4 C39 14 40 22 42 30 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" /><ellipse cx="31" cy="31" rx="20" ry="4.5" fill={p} stroke="rgba(0,0,0,0.35)" strokeWidth="1.6" /><path d="M23 27 L41 27 L40 22 L24 22 Z" fill={s} /></g>)}
      {item.style === "corona" && (<g><path d="M12 32 L12 14 L21 22 L30 10 L39 22 L48 14 L48 32 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.8" strokeLinejoin="round" /><circle cx="30" cy="24" r="3.2" fill={s} /></g>)}
      {item.style === "gorro" && (<g><path d="M12 28 A18 15 0 0 1 48 28 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.8" /><rect x="12" y="26" width="36" height="7" rx="3.5" fill={s} /><circle cx="30" cy="9" r="4.5" fill={s} /></g>)}
      {item.style === "diadema" && (<g><path d="M12 30 A19 17 0 0 1 48 30" fill="none" stroke={p} strokeWidth="4" strokeLinecap="round" /><path d="M45 8 A7 7 0 1 0 45 20 A5.4 5.4 0 1 1 45 8 Z" fill={s} /></g>)}
      {item.style === "copa" && (<g><rect x="20" y="6" width="20" height="22" rx="2" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" /><rect x="20" y="20" width="20" height="5" fill={s} /><ellipse cx="30" cy="30" rx="21" ry="4" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.5" /></g>)}
      {item.style === "boina" && (<g><ellipse cx="30" cy="24" rx="20" ry="8" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" /><rect x="28.5" y="12" width="3.4" height="6" rx="1.7" fill={s} /></g>)}
      {item.style === "gorra" && (<g><path d="M12 28 A18 14 0 0 1 48 28 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.7" /><path d="M12 28 Q30 34 52 27 Q34 21 12 28Z" fill={s} /></g>)}
      {item.style === "flores" && (<g>{[14, 24, 34, 44].map((x, i) => (<g key={x} transform={`translate(${x} ${i % 2 ? 20 : 15})`}><circle r="5.4" fill={i % 2 ? s : p} stroke="rgba(0,0,0,0.2)" /><circle r="2" fill="#f5c451" /></g>))}</g>)}
      {item.style === "halo" && (<ellipse cx="30" cy="20" rx="17" ry="5.5" fill="none" stroke={p} strokeWidth="4.5" />)}
      {item.style === "conejo" && (<g><ellipse cx="20" cy="16" rx="5.5" ry="13" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.5" transform="rotate(-10 20 16)" /><ellipse cx="40" cy="16" rx="5.5" ry="13" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="1.5" transform="rotate(10 40 16)" /><ellipse cx="20" cy="17" rx="2.6" ry="8" fill={s} transform="rotate(-10 20 17)" /><ellipse cx="40" cy="17" rx="2.6" ry="8" fill={s} transform="rotate(10 40 17)" /></g>)}
    </svg>
  );
}

export function FurPreview({ fur }: { fur: FurStyle }) {
  return (
    <svg viewBox="0 0 60 44" className="h-10 w-14">
      <circle cx="30" cy="22" r="15" fill={fur.hex} stroke="rgba(0,0,0,0.35)" strokeWidth="1.6" />
      {fur.pattern === "liso" && <circle cx="30" cy="22" r="6" fill={fur.hex2} opacity="0.6" />}
      {fur.pattern === "rayas" && <g stroke={fur.hex2} strokeWidth="3" strokeLinecap="round"><path d="M22 14 v16 M30 12 v20 M38 14 v16" /></g>}
      {fur.pattern === "manchas" && <g fill={fur.hex2}><circle cx="23" cy="17" r="4.4" /><circle cx="36" cy="26" r="5" /><circle cx="27" cy="29" r="3" /></g>}
      {fur.pattern === "bicolor" && <ellipse cx="30" cy="29" rx="8" ry="6" fill="#fdfbf7" />}
      {fur.pattern === "carey" && <g fill={fur.hex2} opacity="0.8"><path d="M18 20 q7 -8 14 -3 q-3 8 -14 3Z" /><path d="M33 27 q8 -3 10 5 q-7 4 -10 -5Z" /></g>}
      {fur.pattern === "puntas" && <g fill={fur.hex2}><circle cx="19" cy="13" r="4.6" /><circle cx="41" cy="13" r="4.6" /><circle cx="30" cy="35" r="4.6" /></g>}
      {fur.pattern === "estrellas" && <path d="M30 13 l2.2 4.7 5.1.6 -3.8 3.5 1 5 -4.5 -2.5 -4.5 2.5 1 -5 -3.8 -3.5 5.1 -.6Z" fill="#fff" opacity="0.85" />}
      {fur.pattern === "corazones" && <path d="M30 31 C21 24 23.5 15.5 30 19.5 C36.5 15.5 39 24 30 31Z" fill="#f9a8d4" />}
      {fur.pattern === "degradado" && <path d="M15 22 a15 15 0 0 0 30 0 Z" fill={fur.hex2} opacity="0.75" />}
      {fur.pattern === "marmol" && <path d="M17 20 q7 -6 13 0 q6 6 13 0" stroke="#fff" strokeWidth="2.4" fill="none" opacity="0.6" strokeLinecap="round" />}
    </svg>
  );
}

/* ---------- Food sheet ---------- */
const FOOD_ICONS: Record<string, typeof Milk> = { leche: Milk, pescadito: Fish, galletita: Cookie };

interface FoodSheetProps {
  coins: number;
  onPick: (food: Food) => void;
  onClose: () => void;
}

export function FoodSheet({ coins, onPick, onClose }: FoodSheetProps) {
  return (
    <div className="sheet-up absolute inset-x-0 bottom-0 z-40 rounded-t-[28px] border-t-2 border-[#caa25a] bg-[#14121d] px-4 pb-5 pt-3 shadow-[0_-18px_50px_rgba(0,0,0,0.6)]">
      <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-white/20" />
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl font-semibold text-[#f5c451]">Comidita rica</h2>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-sm font-extrabold text-amber-300">
            <Coins className="h-4 w-4" /> {coins}
          </span>
          <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90">
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
      <div className="flex flex-col gap-2.5">
        {FOODS.map((food) => {
          const Icon = FOOD_ICONS[food.id];
          const afford = coins >= food.price;
          return (
            <button key={food.id} onClick={() => onPick(food)} className="flex min-h-[68px] items-center gap-3 rounded-2xl border border-white/10 bg-[#1f1f2a] px-3 py-2.5 text-left transition active:scale-[0.98]">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl" style={{ backgroundColor: food.bg }}>
                <Icon className="h-7 w-7" style={{ color: food.color }} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-display text-base font-semibold text-white">{food.name}</span>
                <span className="block text-xs font-bold text-white/55">{food.desc}</span>
              </span>
              <span className={`flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 font-display text-sm font-semibold ${afford ? "bg-[#f5c451] text-[#241a02]" : "bg-white/10 text-white/40"}`}>
                <Coins className="h-4 w-4" /> {food.price}
              </span>
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-center text-xs font-bold text-white/40">Gana moneditas acariciando, jugando y en los minijuegos</p>
    </div>
  );
}

/* ---------- Wardrobe sheet ---------- */
type WardTab = Slot | "sets" | "fur";

const TABS: { id: WardTab; label: string; Icon: typeof Crown }[] = [
  { id: "hat", label: "Sombreros", Icon: Crown },
  { id: "bow", label: "Moños", Icon: Flower2 },
  { id: "collar", label: "Collares", Icon: Gem },
  { id: "sets", label: "Conjuntos", Icon: Layers },
  { id: "fur", label: "Pelaje", Icon: Palette },
];

interface WardrobeSheetProps {
  coins: number;
  owned: string[];
  equipped: Record<Slot, string | null>;
  activeFurId: string;
  onAccessory: (item: AccessoryItem) => void;
  onOutfit: (outfit: Outfit) => void;
  onFur: (fur: FurStyle) => void;
  onClose: () => void;
}

const CATALOG_BY_SLOT: Record<Slot, AccessoryItem[]> = { hat: HATS, bow: BOWS, collar: COLLARS };

export function WardrobeSheet({ coins, owned, equipped, activeFurId, onAccessory, onOutfit, onFur, onClose }: WardrobeSheetProps) {
  const [tab, setTab] = useState<WardTab>("hat");
  const [query, setQuery] = useState("");

  const accessories = useMemo(() => {
    if (tab === "sets" || tab === "fur") return [];
    const shop = SHOP_ITEMS.filter((i) => i.slot === tab);
    const catalog = CATALOG_BY_SLOT[tab];
    return [...shop, ...catalog].filter((i) => i.name.toLowerCase().includes(query.toLowerCase()));
  }, [tab, query]);

  const outfits = useMemo(
    () => OUTFITS.filter((o) => o.name.toLowerCase().includes(query.toLowerCase()) || o.theme.toLowerCase().includes(query.toLowerCase())),
    [query]
  );
  const furs = useMemo(() => FURS.filter((f) => f.name.toLowerCase().includes(query.toLowerCase())), [query]);

  const currentEquipped = tab !== "sets" && tab !== "fur" ? equipped[tab] : null;

  const badge = (item: AccessoryItem) => {
    const isOwned = owned.includes(item.id);
    const isEquipped = currentEquipped === item.id;
    if (isEquipped)
      return <span className="mt-0.5 flex items-center gap-1 rounded-full bg-[#f5c451] px-2.5 py-1 text-[11px] font-extrabold text-[#241a02]"><Check className="h-3.5 w-3.5" /> PUESTO · QUITAR</span>;
    if (isOwned) return <span className="mt-0.5 rounded-full bg-emerald-400/20 px-2.5 py-1 text-[11px] font-extrabold text-emerald-300">TUYO · PONER</span>;
    if (item.exclusive)
      return <span className="mt-0.5 flex items-center gap-1 rounded-full bg-white/8 px-2.5 py-1 text-[11px] font-extrabold text-white/40"><Lock className="h-3.5 w-3.5" /> SOLO CON CÓDIGO</span>;
    const afford = coins >= (item.price ?? 0);
    return (
      <span className={`mt-0.5 flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold ${afford ? "bg-[#f5c451]/20 text-amber-300" : "bg-white/8 text-white/35"}`}>
        <Coins className="h-3.5 w-3.5" /> {item.price} · COMPRAR
      </span>
    );
  };

  return (
    <div className="sheet-up absolute inset-x-0 bottom-0 z-40 flex max-h-[78%] flex-col rounded-t-[28px] border-t-2 border-[#caa25a] bg-[#14121d] px-4 pb-5 pt-3 shadow-[0_-18px_50px_rgba(0,0,0,0.6)]">
      <div className="mx-auto mb-3 h-1.5 w-12 shrink-0 rounded-full bg-white/20" />
      <div className="mb-3 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-xl font-semibold text-[#f5c451]">
          <Shirt className="h-5 w-5" /> Vestidor mágico
        </h2>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-sm font-extrabold text-amber-300">
            <Coins className="h-4 w-4" /> {coins}
          </span>
          <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90">
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="no-scrollbar mb-2.5 flex shrink-0 gap-2 overflow-x-auto">
        {TABS.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex min-h-[42px] shrink-0 items-center justify-center gap-1.5 rounded-xl px-3 font-display text-[13px] font-semibold transition active:scale-95 ${
              tab === id ? "bg-[#f5c451] text-[#241a02]" : "border border-white/10 bg-white/8 text-white/70"
            }`}
          >
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </div>

      <label className="mb-2.5 flex shrink-0 items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2">
        <Search className="h-4 w-4 shrink-0 text-white/40" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar en el vestidor..."
          className="w-full bg-transparent text-sm font-bold text-white placeholder:text-white/30 focus:outline-none"
        />
      </label>

      <div className="no-scrollbar grid grid-cols-2 gap-2.5 overflow-y-auto pb-1">
        {tab !== "sets" && tab !== "fur" && (
          <>
            <button
              onClick={() => {
                const it = [...SHOP_ITEMS, ...CATALOG_BY_SLOT[tab]].find((i) => i.id === currentEquipped);
                if (it) onAccessory(it);
              }}
              disabled={!currentEquipped}
              className={`flex flex-col items-center gap-1 rounded-2xl border px-2 py-3 transition active:scale-[0.97] ${
                currentEquipped ? "border-dashed border-white/25 bg-white/5 text-white/80" : "border-white/5 bg-white/[0.03] text-white/30"
              }`}
            >
              <span className="flex h-11 items-center justify-center"><X className="h-7 w-7" /></span>
              <span className="font-display text-sm font-semibold">Quitar</span>
              <span className="text-[11px] font-bold text-white/45">{currentEquipped ? "Toca para quitar" : "Nada puesto"}</span>
            </button>
            {accessories.map((item) => (
              <button
                key={item.id}
                onClick={() => onAccessory(item)}
                className={`flex flex-col items-center gap-1 rounded-2xl border px-2 py-3 transition active:scale-[0.97] ${
                  currentEquipped === item.id ? "border-[#f5c451] bg-[#2a2210]" : "border-white/10 bg-[#1f1f2a]"
                }`}
              >
                <span className="flex h-11 items-center justify-center"><ItemPreview item={item} /></span>
                <span className="text-center font-display text-[13px] font-semibold leading-tight text-white">{item.name}</span>
                {badge(item)}
              </button>
            ))}
            {accessories.length === 0 && <p className="col-span-2 py-6 text-center text-sm font-bold text-white/40">Sin resultados para tu búsqueda.</p>}
          </>
        )}

        {tab === "sets" &&
          outfits.map((o) => {
            const isOwned = owned.includes(o.id);
            const isOn = equipped.hat === o.hatId && equipped.bow === o.bowId && equipped.collar === o.collarId;
            return (
              <button
                key={o.id}
                onClick={() => isOwned && onOutfit(o)}
                className={`flex flex-col items-center gap-1 rounded-2xl border px-2 py-3 text-center transition active:scale-[0.97] ${
                  isOn ? "border-[#f5c451] bg-[#2a2210]" : "border-white/10 bg-[#1f1f2a]"
                }`}
              >
                <span className="flex h-11 items-center justify-center gap-1">
                  {o.hatId && <span className="rounded-lg bg-black/30 px-1"><ItemPreview item={(CATALOG_BY_SLOT.hat.find((h) => h.id === o.hatId) ?? SHOP_ITEMS[0])} /></span>}
                </span>
                <span className="font-display text-[13px] font-semibold leading-tight text-white">{o.name}</span>
                <span className="text-[10px] font-bold leading-tight text-white/45">Sombrero + moño + collar · Tema {o.theme}</span>
                {isOn ? (
                  <span className="mt-0.5 flex items-center gap-1 rounded-full bg-[#f5c451] px-2.5 py-1 text-[11px] font-extrabold text-[#241a02]"><Check className="h-3.5 w-3.5" /> PUESTO</span>
                ) : isOwned ? (
                  <span className="mt-0.5 rounded-full bg-emerald-400/20 px-2.5 py-1 text-[11px] font-extrabold text-emerald-300">TUYO · EQUIPAR TODO</span>
                ) : (
                  <span className="mt-0.5 flex items-center gap-1 rounded-full bg-white/8 px-2.5 py-1 text-[11px] font-extrabold text-white/40"><Lock className="h-3.5 w-3.5" /> SOLO CON CÓDIGO</span>
                )}
              </button>
            );
          })}

        {tab === "fur" &&
          furs.map((fur) => {
            const isOwned = owned.includes(fur.id);
            const isActive = activeFurId === fur.id;
            return (
              <button
                key={fur.id}
                onClick={() => isOwned && onFur(fur)}
                className={`flex flex-col items-center gap-1 rounded-2xl border px-2 py-3 text-center transition active:scale-[0.97] ${
                  isActive ? "border-[#f5c451] bg-[#2a2210]" : "border-white/10 bg-[#1f1f2a]"
                }`}
              >
                <span className="flex h-11 items-center justify-center"><FurPreview fur={fur} /></span>
                <span className="font-display text-[13px] font-semibold leading-tight text-white">{fur.name}</span>
                {isActive ? (
                  <span className="mt-0.5 flex items-center gap-1 rounded-full bg-[#f5c451] px-2.5 py-1 text-[11px] font-extrabold text-[#241a02]"><Check className="h-3.5 w-3.5" /> PUESTO</span>
                ) : isOwned ? (
                  <span className="mt-0.5 rounded-full bg-emerald-400/20 px-2.5 py-1 text-[11px] font-extrabold text-emerald-300">TUYO · APLICAR</span>
                ) : (
                  <span className="mt-0.5 flex items-center gap-1 rounded-full bg-white/8 px-2.5 py-1 text-[11px] font-extrabold text-white/40"><Lock className="h-3.5 w-3.5" /> SOLO CON CÓDIGO</span>
                )}
              </button>
            );
          })}
      </div>
      <p className="mt-2 shrink-0 text-center text-[11px] font-bold text-white/35">
        Los artículos con candado son exclusivos: solo llegan con códigos de regalo de MICHILICIAS.
      </p>
    </div>
  );
}
