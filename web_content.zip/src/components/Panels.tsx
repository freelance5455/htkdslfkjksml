import { useState } from "react";
import { AREA_DEFS } from "../game/data/areas";
import { LAWS } from "../game/data/laws";
import { NPCS } from "../game/data/npcs";
import { ITEMS } from "../game/data/items";
import { AREA_NAME, npcMood } from "../game/engine";
import {
  NPC_STAT_LABELS,
  type GameState,
  type NpcStatKey,
} from "../game/types";
import { Portrait } from "./Portrait";

function Frame({
  title,
  onClose,
  children,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-2 backdrop-blur-[2px] sm:p-6">
      <div className={`panel pop flex max-h-[92vh] w-full flex-col ${wide ? "max-w-4xl" : "max-w-2xl"}`}>
        <div className="flex items-center justify-between border-b border-[#3a2b4c] px-4 py-2">
          <span className="panel-title">{title}</span>
          <button className="btn px-2 py-0.5 text-[11px]" onClick={onClose}>
            Fechar [Esc]
          </button>
        </div>
        <div className="overflow-y-auto p-3 sm:p-4">{children}</div>
      </div>
    </div>
  );
}

export function InventoryPanel({
  state,
  onClose,
  onUse,
}: {
  state: GameState;
  onClose: () => void;
  onUse: (id: string) => void;
}) {
  return (
    <Frame title={`Inventário — ${state.stats.wealth} moedas`} onClose={onClose}>
      {state.inventory.length === 0 ? (
        <p className="text-[13px] italic text-[#9d8fb0]">
          Você não carrega nada além do que veste. Comece carregando alguma coisa.
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {state.inventory.map((it) => {
            const def = ITEMS[it.id];
            if (!def) return null;
            return (
              <div key={it.id} className="flex gap-3 border border-[#3a2b4c] bg-[#1d1528] p-2">
                <div className="text-2xl leading-none">{def.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-[13px] font-semibold text-[#f7e3a8]">{def.name}</span>
                    <span className="mono text-[11px] text-[#9d8fb0]">x{it.count}</span>
                  </div>
                  <p className="text-[11px] leading-snug text-[#b6a9c6]">{def.desc}</p>
                  {def.use && (
                    <button className="btn mt-1.5 px-2 py-0.5 text-[11px]" onClick={() => onUse(it.id)}>
                      Usar
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Frame>
  );
}

const NPC_ORDER: NpcStatKey[] = ["trust", "respect", "fear", "loyalty", "ambition"];
const NPC_COLOR: Record<NpcStatKey, string> = {
  trust: "#7fd08a",
  respect: "#7fc4e8",
  fear: "#d0705a",
  loyalty: "#e8c06a",
  ambition: "#c79ae8",
};

export function RelationsPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const [sel, setSel] = useState<string>("rei");
  const npc = state.npcs[sel];
  const def = NPCS.find((n) => n.id === sel);

  return (
    <Frame title="Laços e Simpatias" onClose={onClose} wide>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1.1fr]">
        <div className="max-h-[60vh] overflow-y-auto pr-1">
          {NPCS.filter((n, i, arr) => arr.findIndex((o) => o.id === n.id) === i).map((n) => {
            const s = state.npcs[n.id];
            const mood = npcMood(s);
            return (
              <button
                key={n.id}
                onClick={() => setSel(n.id)}
                className={`flex w-full items-center gap-2 border-b border-[#2c2139] px-1 py-1.5 text-left transition ${
                  sel === n.id ? "bg-[#2c2140]" : "hover:bg-[#241a33]"
                }`}
              >
                <Portrait palette={n.palette} size={26} crown={n.crown} hood={n.hood} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] text-[#ecdcb8]">{n.name}</div>
                  <div className="truncate text-[10px]" style={{ color: mood.color }}>
                    {mood.label} · {AREA_NAME[s.areaId] ?? s.areaId}
                  </div>
                </div>
                <div className="mono text-[10px] text-[#e8c06a]">
                  {Math.round((s.trust + s.respect + s.loyalty - s.fear) / 2)}
                </div>
              </button>
            );
          })}
        </div>

        <div className="border border-[#3a2b4c] bg-[#1d1528] p-3">
          {npc && def && (
            <>
              <div className="flex gap-3">
                <Portrait palette={def.palette} size={64} crown={def.crown} hood={def.hood} />
                <div className="min-w-0">
                  <div className="text-[15px] font-semibold text-[#f7e3a8]">{def.name}</div>
                  <div className="text-[11px] italic text-[#9d8fb0]">{def.title}</div>
                  <div className="mt-1 text-[11px] text-[#b6a9c6]">{def.role}</div>
                </div>
              </div>
              <p className="mt-2 text-[12px] italic leading-snug text-[#b6a9c6]">{def.bio}</p>

              <div className="mt-3 space-y-1.5">
                {NPC_ORDER.map((k) => (
                  <div key={k} className="flex items-center gap-2">
                    <span className="w-[68px] text-[11px] text-[#9d8fb0]">{NPC_STAT_LABELS[k]}</span>
                    <div className="stat-bar flex-1">
                      <div
                        className="stat-fill"
                        style={{ width: `${npc[k]}%`, background: NPC_COLOR[k] }}
                      />
                    </div>
                    <span className="mono w-6 text-right text-[11px] text-[#ecdcb8]">{npc[k]}</span>
                  </div>
                ))}
              </div>

              <div className="mt-3">
                <div className="panel-title mb-1">O que lembra de você</div>
                {npc.memories.length === 0 ? (
                  <p className="text-[11px] italic text-[#6f6380]">
                    Ainda não tem história com você.
                  </p>
                ) : (
                  <ul className="space-y-1">
                    {npc.memories.slice(0, 5).map((m) => (
                      <li key={m.id} className="flex gap-2 text-[11px] leading-snug">
                        <span
                          className="mt-[3px] inline-block h-1.5 w-1.5 shrink-0"
                          style={{
                            background:
                              m.kind === "good" ? "#7fd08a" : m.kind === "bad" ? "#d0705a" : "#e8c06a",
                          }}
                        />
                        <span className="text-[#c9bcd8]">
                          <span className="mono text-[#7a6b8f]">L{m.mission}</span> {m.text}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </Frame>
  );
}

export function JournalPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const [sel, setSel] = useState(state.currentMission ?? 1);
  const law = LAWS[sel - 1];
  const done = state.completedMissions.includes(sel);
  const known = state.knownLaws.includes(sel);
  const isNext = state.currentMission === sel;

  return (
    <Frame title="Diário das 48 Leis" onClose={onClose} wide>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-[1.2fr_1fr]">
        <div className="max-h-[62vh] overflow-y-auto pr-1">
          {LAWS.map((l) => {
            const complete = state.completedMissions.includes(l.id);
            const current = state.currentMission === l.id;
            return (
              <button
                key={l.id}
                onClick={() => setSel(l.id)}
                className={`flex w-full items-start gap-2 border-b border-[#2c2139] px-2 py-1.5 text-left transition ${
                  sel === l.id ? "bg-[#2c2140]" : "hover:bg-[#241a33]"
                } ${l.id > state.completedMissions.length + 1 && !current ? "opacity-45" : ""}`}
              >
                <span className="mono w-6 shrink-0 text-[11px] text-[#7a6b8f]">{l.id}</span>
                <span className="flex-1 text-[12px] text-[#ecdcb8]">{l.title}</span>
                {complete ? (
                  <span className="mono text-[10px] text-[#7fd08a]">✓</span>
                ) : current ? (
                  <span className="mono text-[10px] text-[#e8c06a]">◆</span>
                ) : null}
              </button>
            );
          })}
        </div>
        <div className="border border-[#3a2b4c] bg-[#1d1528] p-3">
          <div className="panel-title">Lei {law.id}</div>
          <div className="text-[15px] font-semibold text-[#f7e3a8]">{law.title}</div>
          <div className="mt-1 text-[11px] uppercase tracking-widest text-[#9d8fb0]">{law.short}</div>
          {known ? (
            <p className="mt-3 border-l-2 border-[#e8c06a] pl-3 text-[13px] italic leading-relaxed text-[#d8cbe4]">
              {law.insight}
            </p>
          ) : (
            <p className="mt-3 text-[12px] italic text-[#6f6380]">
              {done
                ? "Você viveu esta lei, mas ainda não entendeu o que ela ensina."
                : "Complete o desafio desta lei para baixar sua sabedoria."}
            </p>
          )}
          {isNext && (
            <div className="mt-3 border border-[#4a3a5e] bg-[#2a1e3a] p-2 text-[12px] text-[#ecdcb8]">
              <span className="gold font-semibold">Desafio atual.</span> Encontre quem ofereceu esta lei.
            </div>
          )}
        </div>
      </div>
    </Frame>
  );
}

export function MapPanel({
  state,
  onClose,
  onTravel,
}: {
  state: GameState;
  onClose: () => void;
  onTravel: (areaId: string) => void;
}) {
  return (
    <Frame title="Mapa do Reino de Valdemar" onClose={onClose} wide>
      <div className="relative w-full" style={{ aspectRatio: "16 / 10" }}>
        <svg viewBox="0 0 100 62" className="h-full w-full">
          <defs>
            <radialGradient id="mg" cx="50%" cy="45%" r="70%">
              <stop offset="0%" stopColor="#2c2038" />
              <stop offset="100%" stopColor="#120d1a" />
            </radialGradient>
          </defs>
          <rect width="100" height="62" fill="url(#mg)" />
          <path
            d="M4 46 Q 16 34 26 36 T 46 28 T 66 22 T 92 26"
            stroke="#4a3a5e"
            strokeWidth="0.6"
            fill="none"
            strokeDasharray="1.4 1.2"
          />
          <path
            d="M8 56 Q 22 48 30 52 T 52 58 T 84 52"
            stroke="#4a3a5e"
            strokeWidth="0.5"
            fill="none"
            strokeDasharray="1.2 1.4"
          />
          <path
            d="M20 12 Q 34 8 44 12 T 72 14"
            stroke="#4a3a5e"
            strokeWidth="0.5"
            fill="none"
            strokeDasharray="1.2 1.4"
          />
          {AREA_DEFS.map((a) => {
            const unlocked = state.unlockedAreas.includes(a.id);
            const discovered = state.discoveredAreas.includes(a.id);
            const here = state.player.areaId === a.id;
            return (
              <g
                key={a.id}
                onClick={() => unlocked && onTravel(a.id)}
                style={{ cursor: unlocked ? "pointer" : "default" }}
              >
                <circle
                  cx={a.map.x}
                  cy={a.map.y}
                  r={here ? 3.4 : 2.4}
                  fill={here ? "#e8c06a" : unlocked ? (discovered ? "#7fc4e8" : "#4a6f9a") : "#33283f"}
                  stroke="#0d0914"
                  strokeWidth="0.4"
                />
                {here && (
                  <circle cx={a.map.x} cy={a.map.y} r={4.6} fill="none" stroke="#e8c06a" strokeWidth="0.3" opacity="0.7" />
                )}
                <text
                  x={a.map.x}
                  y={a.map.y + 5.4}
                  textAnchor="middle"
                  fontSize="2.4"
                  fill={unlocked && discovered ? "#d8cbe4" : "#5b4f6b"}
                  style={{ fontFamily: "ui-serif, Georgia, serif" }}
                >
                  {a.name}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
      <p className="mt-2 text-[11px] italic text-[#9d8fb0]">
        Regiões em azul são visitáveis; o círculo dourado é onde você está. Regiões bloqueadas ainda não podem ser alcançadas.
      </p>
      <div className="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-3">
        {AREA_DEFS.map((a) => {
          const unlocked = state.unlockedAreas.includes(a.id);
          const discovered = state.discoveredAreas.includes(a.id);
          const here = state.player.areaId === a.id;
          return (
            <button
              key={a.id}
              disabled={!unlocked || here}
              onClick={() => onTravel(a.id)}
              className="border border-[#3a2b4c] bg-[#1d1528] px-2 py-1.5 text-left text-[11px] text-[#c9bcd8] disabled:opacity-40"
            >
              <span className="block font-semibold text-[#e8c06a]">{a.name}</span>
              <span className="block text-[10px] text-[#9d8fb0]">
                {here ? "Você está aqui" : !unlocked ? "Bloqueada" : !discovered ? "Ainda não visitada" : a.subtitle}
              </span>
            </button>
          );
        })}
      </div>
    </Frame>
  );
}
