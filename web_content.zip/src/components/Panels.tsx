import {
  Bird,
  Columns2,
  Footprints,
  Glasses,
  Headphones,
  Monitor,
  MoveUpRight,
  Pause,
  Play,
  RotateCcw,
  ShieldCheck,
  Smartphone,
  Sun,
  Sunrise,
  Sunset,
  Volume2,
  Waves,
  Wind,
} from 'lucide-react';
import type { Settings, SoundLayer } from '../data/worlds';
import { defaultSettings } from '../data/worlds';
import { Slider, Toggle, Waveform } from './Interface';

interface PanelProps {
  settings: Settings;
  onChange: (settings: Partial<Settings>) => void;
}

export function SettingsPanel({ settings, onChange, onReset }: PanelProps & { onReset: () => void }) {
  return (
    <div className="settings-panel">
      <section className="settings-group">
        <div className="group-heading">
          <Glasses size={19} />
          <h3>Display & Atmosphere</h3>
        </div>
        <div className="setting-row">
          <div>
            <h4>Display Mode</h4>
            <p>Dual split-screen for VR headsets or single full-width screen.</p>
          </div>
          <div className="segmented-control">
            <button
              className={settings.displayMode === 'stereo' ? 'selected' : ''}
              aria-pressed={settings.displayMode === 'stereo'}
              onClick={() => onChange({ displayMode: 'stereo' })}
            >
              <Columns2 size={17} />
              VR Split View
            </button>
            <button
              className={settings.displayMode === 'single' ? 'selected' : ''}
              aria-pressed={settings.displayMode === 'single'}
              onClick={() => onChange({ displayMode: 'single' })}
            >
              <Monitor size={17} />
              Single Screen
            </button>
          </div>
        </div>
        <div className="setting-row">
          <div>
            <h4>Time of Day</h4>
            <p>Choose the sunlight and sky mood that brings you the most serenity.</p>
          </div>
          <div className="time-options">
            {[
              { id: 'morning', label: 'Morning', icon: Sunrise },
              { id: 'day', label: 'Midday', icon: Sun },
              { id: 'sunset', label: 'Sunset', icon: Sunset },
            ].map(time => (
              <button
                key={time.id}
                aria-pressed={settings.timeOfDay === time.id}
                className={settings.timeOfDay === time.id ? 'selected' : ''}
                onClick={() => onChange({ timeOfDay: time.id as Settings['timeOfDay'] })}
              >
                <time.icon size={19} />
                {time.label}
              </button>
            ))}
          </div>
        </div>
        <div className="setting-row">
          <div>
            <h4>Visual Quality</h4>
            <p>Real-time water reflections, tree density, and grass foliage.</p>
          </div>
          <select
            aria-label="Visual Quality"
            value={settings.quality}
            onChange={event => onChange({ quality: event.target.value as Settings['quality'] })}
          >
            <option value="balanced">Balanced (Recommended)</option>
            <option value="high">High Definition</option>
          </select>
        </div>
      </section>

      <section className="settings-group">
        <div className="group-heading">
          <Footprints size={19} />
          <h3>Motion & Comfort</h3>
        </div>
        <div className="setting-row">
          <div>
            <h4>Step Detection on Phone</h4>
            <p>Gentle device movement propels you forward automatically.</p>
          </div>
          <Toggle
            label="Step Detection on Phone"
            checked={settings.motionEnabled}
            onChange={value => onChange({ motionEnabled: value })}
          />
        </div>
        <div className="setting-row">
          <div>
            <h4>Head Tracking (Gyroscope)</h4>
            <p>Look around naturally by turning your phone or VR headset.</p>
          </div>
          <Toggle
            label="Head Tracking"
            checked={settings.headTracking}
            onChange={value => onChange({ headTracking: value })}
          />
        </div>
        <div className="setting-sliders">
          <Slider
            label="Movement Sensitivity"
            min={1}
            max={10}
            value={settings.sensitivity}
            suffix=" / 10"
            onChange={value => onChange({ sensitivity: value })}
          />
          <Slider
            label="Walking Speed"
            min={0.6}
            max={3}
            step={0.2}
            value={settings.speed}
            suffix=" m/s"
            onChange={value => onChange({ speed: value })}
          />
        </div>
      </section>

      <div className="settings-bottom">
        <span>
          <ShieldCheck size={16} />
          Your preferences are saved locally on this device.
        </span>
        <button
          className="text-button"
          onClick={() => {
            onChange(defaultSettings);
            onReset();
          }}
        >
          <RotateCcw size={14} />
          Reset Defaults
        </button>
      </div>
    </div>
  );
}

const soundLayers: { id: SoundLayer; name: string; description: string; icon: typeof Bird; color: string }[] = [
  { id: 'birds', name: 'Birdsong', description: 'Trills and chirps from the forest canopy.', icon: Bird, color: 'sage' },
  { id: 'water', name: 'Cascading Water & Lake', description: 'Gushing waterfalls, flowing streams, and soothing ripples.', icon: Waves, color: 'blue' },
  { id: 'wind', name: 'Breeze & Foliage', description: 'Gentle rustling whispers through pines and meadows.', icon: Wind, color: 'sand' },
];

export function SoundPanel({
  settings,
  onChange,
  playing,
  onToggle,
}: PanelProps & { playing: boolean; onToggle: () => void }) {
  return (
    <div className="sound-panel">
      <div className="sound-intro">
        <div className="sound-intro-copy">
          <span className="eyebrow">SOUNDS OF THE WILD</span>
          <h2>Let nature tell its story.</h2>
          <p>Compose your peaceful acoustic atmosphere. Every layer has its own place in the soundscape.</p>
          <button className="primary-button" onClick={onToggle}>
            {playing ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}
            {playing ? 'Pause Nature Sounds' : 'Play Nature Sounds'}
          </button>
        </div>
        <div className="sound-art">
          <span />
          <span />
          <span />
          <Bird size={48} strokeWidth={1} />
        </div>
      </div>

      <div className="sound-master">
        <Volume2 size={21} />
        <Slider label="Master Volume" value={settings.volume} onChange={value => onChange({ volume: value })} />
      </div>

      <div className="sound-layers">
        {soundLayers.map(layer => (
          <div className="sound-layer" key={layer.id}>
            <span className={`sound-layer-icon ${layer.color}`}>
              <layer.icon size={25} strokeWidth={1.4} />
            </span>
            <div className="sound-layer-title">
              <h3>{layer.name}</h3>
              <p>{layer.description}</p>
            </div>
            <Waveform small playing={playing && settings[layer.id] > 0} />
            <div className="sound-layer-slider">
              <Slider
                label={`${layer.name} Volume`}
                value={settings[layer.id]}
                onChange={value => onChange({ [layer.id]: value })}
              />
            </div>
            <Toggle
              label={`Toggle ${layer.name}`}
              checked={settings[layer.id] > 0}
              onChange={value => onChange({ [layer.id]: value ? 65 : 0 })}
            />
          </div>
        ))}
      </div>

      <div className="setting-row footstep-setting">
        <div className="group-heading">
          <Footprints size={21} />
          <div>
            <h4>Footstep Audio</h4>
            <p>Soft grass and gravel steps accompanying your 3D journey.</p>
          </div>
        </div>
        <Toggle
          label="Footstep Audio"
          checked={settings.footsteps}
          onChange={value => onChange({ footsteps: value })}
        />
      </div>

      <p className="headphone-note">
        <Headphones size={17} />
        Use headphones to experience the full 3D binaural stereo field.
      </p>
    </div>
  );
}

export function GuidePanel({ onStart }: { onStart: () => void }) {
  return (
    <div className="guide-panel">
      <span className="eyebrow">BEFORE YOU BEGIN</span>
      <h2>Nature never rushes.<br />Neither should you.</h2>
      <p className="guide-intro">Three simple steps to embark on your peaceful retreat.</p>

      <ol className="guide-steps">
        <li>
          <span className="guide-number">01</span>
          <Smartphone size={28} strokeWidth={1.2} />
          <div>
            <h3>Prepare your space & permit sensors.</h3>
            <p>Open via HTTPS on your phone. When prompted, allow motion and orientation access. Remain seated or standing in a safe spot.</p>
          </div>
        </li>
        <li>
          <span className="guide-number">02</span>
          <Glasses size={28} strokeWidth={1.2} />
          <div>
            <h3>Two lenses, one living world.</h3>
            <p>Rotate your phone into landscape mode and insert it into a Google Cardboard or VR headset. Without a headset, switch to Single Screen mode.</p>
          </div>
        </li>
        <li>
          <span className="guide-number">03</span>
          <Footprints size={28} strokeWidth={1.2} />
          <div>
            <h3>Step lightly or tap to walk.</h3>
            <p>Gentle rhythmic movement on your phone moves you forward. Stop moving to pause. Drag on screen or turn your head to look around.</p>
          </div>
        </li>
      </ol>

      <div className="keyboard-guide">
        <span>Desktop Controls:</span>
        <kbd>W</kbd>
        <span>or</span>
        <kbd>Space</kbd>
        <span>to walk forward.</span>
        <kbd>S</kbd>
        <span>for backward. Click and drag mouse to look around.</span>
      </div>

      <p className="safety-note">
        <ShieldCheck size={19} />
        Stay seated or stable. Do not shake your phone violently. Take a break if you feel any disorientation. Physical phone vibration motors are distinct from motion sensors.
      </p>

      <button className="primary-button" onClick={onStart}>
        Begin Journey <MoveUpRight size={17} />
      </button>
    </div>
  );
}
