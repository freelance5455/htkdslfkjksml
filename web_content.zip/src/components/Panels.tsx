"use client";
import { useEffect, useState } from "react";
import { hostOf, SEARCH_ENGINES, type SearchEngineId } from "@/lib/browser";
import type { Settings } from "@/lib/store";
import { Favicon, Icon, IconButton, Panel } from "./ui";

type Row = { id: number; url: string; title: string; visitedAt?: string; createdAt?: string; folder?: string; filename?: string; size?: number; status?: string; mime?: string };

function useList(endpoint: string, profileId: number, q = "") {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const reload = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${endpoint}?profileId=${profileId}&q=${encodeURIComponent(q)}`);
      const d = await r.json();
      setRows(Array.isArray(d) ? d : []);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endpoint, profileId, q]);
  return { rows, loading, reload };
}

export function HistoryPanel({ profileId, onOpen, onClose }: { profileId: number; onOpen: (u: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const { rows, loading, reload } = useList("/api/history", profileId, q);
  const groups = new Map<string, Row[]>();
  for (const r of rows) {
    const d = new Date(r.visitedAt!).toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });
    groups.set(d, [...(groups.get(d) || []), r]);
  }
  return (
    <Panel
      title="История"
      onClose={onClose}
      actions={
        <IconButton
          icon="trash"
          label="Очистить историю"
          onClick={async () => {
            if (confirm("Очистить всю историю?")) {
              await fetch(`/api/history?profileId=${profileId}`, { method: "DELETE" });
              reload();
            }
          }}
        />
      }
    >
      <div className="p-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск в истории" className="w-full rounded-xl border border-black/5 bg-white px-3 py-2 text-sm outline-none dark:border-white/10 dark:bg-white/5" />
      </div>
      {loading && rows.length === 0 && <div className="p-6 text-center text-sm text-slate-400">Загрузка…</div>}
      {!loading && rows.length === 0 && <div className="p-6 text-center text-sm text-slate-400">История пуста</div>}
      {[...groups.entries()].map(([day, items]) => (
        <div key={day}>
          <div className="px-4 pb-1 pt-3 text-[11px] font-semibold uppercase text-slate-400">{day}</div>
          {items.map((r) => (
            <div key={r.id} className="group flex items-center gap-2 px-3 py-1.5 hover:bg-black/5 dark:hover:bg-white/5">
              <span className="w-10 shrink-0 text-[10px] text-slate-400">{new Date(r.visitedAt!).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</span>
              <Favicon src={`https://www.google.com/s2/favicons?domain=${hostOf(r.url)}&sz=32`} title={r.title} />
              <button type="button" onClick={() => onOpen(r.url)} className="min-w-0 flex-1 text-left">
                <div className="truncate text-sm">{r.title || r.url}</div>
                <div className="truncate text-[11px] text-slate-400">{hostOf(r.url)}</div>
              </button>
              <IconButton
                icon="close"
                label="Удалить"
                size={13}
                className="!h-7 !w-7 opacity-0 group-hover:opacity-100"
                onClick={async () => {
                  await fetch(`/api/history?id=${r.id}`, { method: "DELETE" });
                  reload();
                }}
              />
            </div>
          ))}
        </div>
      ))}
    </Panel>
  );
}

export function BookmarksPanel({ profileId, onOpen, onClose }: { profileId: number; onOpen: (u: string) => void; onClose: () => void }) {
  const { rows, loading, reload } = useList("/api/bookmarks", profileId);
  const folders = new Map<string, Row[]>();
  for (const r of rows) folders.set(r.folder || "Закладки", [...(folders.get(r.folder || "Закладки") || []), r]);
  return (
    <Panel title="Закладки" onClose={onClose}>
      {loading && rows.length === 0 && <div className="p-6 text-center text-sm text-slate-400">Загрузка…</div>}
      {!loading && rows.length === 0 && <div className="p-6 text-center text-sm text-slate-400">Нажмите ☆ в панели, чтобы добавить закладку</div>}
      {[...folders.entries()].map(([f, items]) => (
        <div key={f}>
          <div className="px-4 pb-1 pt-3 text-[11px] font-semibold uppercase text-slate-400">📁 {f}</div>
          {items.map((r) => (
            <div key={r.id} className="group flex items-center gap-2 px-3 py-1.5 hover:bg-black/5 dark:hover:bg-white/5">
              <Favicon src={`https://www.google.com/s2/favicons?domain=${hostOf(r.url)}&sz=32`} title={r.title} />
              <button type="button" onClick={() => onOpen(r.url)} className="min-w-0 flex-1 text-left">
                <div className="truncate text-sm">{r.title || r.url}</div>
                <div className="truncate text-[11px] text-slate-400">{r.url}</div>
              </button>
              <IconButton
                icon="trash"
                label="Удалить"
                size={13}
                className="!h-7 !w-7 opacity-0 group-hover:opacity-100"
                onClick={async () => {
                  await fetch(`/api/bookmarks?id=${r.id}`, { method: "DELETE" });
                  reload();
                }}
              />
            </div>
          ))}
        </div>
      ))}
    </Panel>
  );
}

function fmtSize(n?: number) {
  if (!n) return "—";
  if (n < 1024) return n + " Б";
  if (n < 1048576) return (n / 1024).toFixed(1) + " КБ";
  return (n / 1048576).toFixed(1) + " МБ";
}

export function DownloadsPanel({ profileId, onClose }: { profileId: number; onClose: () => void }) {
  const { rows, reload } = useList("/api/downloads", profileId);
  const [url, setUrl] = useState("");
  return (
    <Panel
      title="Загрузки"
      onClose={onClose}
      actions={
        <IconButton
          icon="trash"
          label="Очистить список"
          onClick={async () => {
            await fetch(`/api/downloads?profileId=${profileId}`, { method: "DELETE" });
            reload();
          }}
        />
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!url.trim()) return;
          window.open(`/api/downloads/file?url=${encodeURIComponent(url.trim())}&profileId=${profileId}`, "_blank");
          setUrl("");
          setTimeout(reload, 1500);
        }}
        className="flex gap-1 p-2"
      >
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Скачать по ссылке…" className="min-w-0 flex-1 rounded-xl border border-black/5 bg-white px-3 py-2 text-sm outline-none dark:border-white/10 dark:bg-white/5" />
        <button type="submit" className="accent-bg rounded-xl px-3 text-white">
          <Icon name="download" size={16} />
        </button>
      </form>
      {rows.length === 0 && <div className="p-6 text-center text-sm text-slate-400">Загрузок пока нет</div>}
      {rows.map((r) => (
        <div key={r.id} className="flex items-center gap-3 px-3 py-2 hover:bg-black/5 dark:hover:bg-white/5">
          <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${r.status === "failed" ? "bg-red-500/10 text-red-500" : "bg-emerald-500/10 text-emerald-600"}`}>
            <Icon name={r.status === "failed" ? "close" : "download"} size={16} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm">{r.filename}</div>
            <div className="truncate text-[11px] text-slate-400">
              {fmtSize(r.size)} · {hostOf(r.url)} · {new Date(r.createdAt!).toLocaleString("ru-RU")}
            </div>
          </div>
          <a href={`/api/downloads/file?url=${encodeURIComponent(r.url)}&profileId=${profileId}`} target="_blank" rel="noreferrer" title="Скачать снова" className="text-slate-400 hover:accent-text">
            <Icon name="external" size={15} />
          </a>
        </div>
      ))}
    </Panel>
  );
}

const ACCENTS = ["#6366f1", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#ec4899", "#8b5cf6"];

type Ext = { id: string; name: string; desc: string; icon: string };
export const EXTENSIONS: Ext[] = [
  { id: "adblock", name: "Nova Shield", desc: "Блокировка трекеров и рекламы", icon: "shield" },
  { id: "readermode", name: "Режим чтения", desc: "Чистый текст без лишнего (через Nova AI)", icon: "doc" },
  { id: "translate", name: "Переводчик", desc: "Перевод страниц через ИИ", icon: "translate" },
  { id: "darkweb", name: "Тёмные сайты", desc: "Принудительная тёмная тема для страниц", icon: "moon" },
];

export function SettingsPanel({
  settings,
  onChange,
  onClose,
  extensions,
  onToggleExt,
}: {
  settings: Settings;
  onChange: (s: Partial<Settings>) => void;
  onClose: () => void;
  extensions: Record<string, boolean>;
  onToggleExt: (id: string) => void;
}) {
  const [code, setCode] = useState("");
  const [syncMsg, setSyncMsg] = useState("");
  const [providers, setProviders] = useState<string[]>([]);

  useEffect(() => {
    fetch("/api/ai/providers").then((r) => r.json()).then((d) => setProviders(d.providers || [])).catch(() => {});
  }, []);

  async function createAccount() {
    const r = await fetch("/api/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: settings.profileName || "Пользователь", settings }) });
    const p = await r.json();
    onChange({ profileId: p.id, syncCode: p.syncCode, profileName: p.name });
    setSyncMsg("Аккаунт создан. Введите этот код на другом устройстве.");
  }
  async function login() {
    const r = await fetch("/api/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code }) });
    const p = await r.json();
    if (p.error) return setSyncMsg(p.error);
    const s = (p.settings || {}) as Partial<Settings>;
    onChange({ ...s, profileId: p.id, syncCode: p.syncCode, profileName: p.name });
    setSyncMsg("Вход выполнен. Данные синхронизированы.");
  }

  const Toggle = ({ k, label, hint }: { k: keyof Settings; label: string; hint?: string }) => (
    <label className="flex cursor-pointer items-center gap-3 px-4 py-2.5 hover:bg-black/5 dark:hover:bg-white/5">
      <div className="min-w-0 flex-1">
        <div className="text-sm">{label}</div>
        {hint && <div className="text-[11px] text-slate-400">{hint}</div>}
      </div>
      <input type="checkbox" className="peer sr-only" checked={Boolean(settings[k])} onChange={(e) => onChange({ [k]: e.target.checked })} />
      <span className="relative h-6 w-10 rounded-full bg-slate-300 transition peer-checked:bg-[var(--accent)] after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:after:translate-x-4 dark:bg-slate-600" />
    </label>
  );

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="mb-2">
      <div className="px-4 pb-1 pt-3 text-[11px] font-semibold uppercase text-slate-400">{title}</div>
      <div className="mx-2 overflow-hidden rounded-2xl bg-white dark:bg-white/5">{children}</div>
    </div>
  );

  return (
    <Panel title="Настройки" onClose={onClose}>
      <Section title="Внешний вид">
        <div className="flex gap-1 p-2">
          {(["light", "dark", "system"] as const).map((t) => (
            <button key={t} type="button" onClick={() => onChange({ theme: t })} className={`flex flex-1 items-center justify-center gap-1 rounded-xl py-2 text-xs ${settings.theme === t ? "accent-bg text-white" : "bg-black/5 dark:bg-white/10"}`}>
              <Icon name={t === "light" ? "sun" : t === "dark" ? "moon" : "settings"} size={14} /> {t === "light" ? "Светлая" : t === "dark" ? "Тёмная" : "Системная"}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 px-4 pb-3">
          <span className="text-xs text-slate-400">Акцент:</span>
          {ACCENTS.map((c) => (
            <button key={c} type="button" onClick={() => onChange({ accent: c })} className={`h-6 w-6 rounded-full ring-offset-2 ${settings.accent === c ? "ring-2 ring-slate-400" : ""}`} style={{ background: c }} aria-label={c} />
          ))}
        </div>
      </Section>

      <Section title="Поиск">
        <div className="flex flex-wrap gap-1 p-2">
          {(Object.keys(SEARCH_ENGINES) as SearchEngineId[]).map((id) => (
            <button key={id} type="button" onClick={() => onChange({ engine: id })} className={`rounded-xl px-3 py-1.5 text-xs ${settings.engine === id ? "text-white" : "bg-black/5 dark:bg-white/10"}`} style={settings.engine === id ? { background: SEARCH_ENGINES[id].color } : {}}>
              {SEARCH_ENGINES[id].name}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Безопасность и производительность">
        <Toggle k="blockTrackers" label="Блокировать трекеры" hint="Nova Shield: 40+ доменов аналитики и рекламы" />
        <Toggle k="httpsOnly" label="Только HTTPS" hint="Автоматически повышать http → https" />
        <Toggle k="sleepTabs" label="Усыплять неактивные вкладки" hint="Освобождает память через 10 минут бездействия" />
        <Toggle k="compat" label="Режим совместимости" hint="Больше сайтов работает корректно (localStorage и т.п.)" />
      </Section>

      <Section title="Nova AI">
        <div className="px-4 py-2">
          <div className="mb-1 text-sm">Провайдер</div>
          <select value={settings.aiProvider} onChange={(e) => onChange({ aiProvider: e.target.value })} className="w-full rounded-xl border border-black/5 bg-white px-3 py-2 text-sm dark:border-white/10 dark:bg-slate-800">
            <option value="auto">Авто</option>
            {providers.map((p) => (
              <option key={p} value={p}>
                {p === "openai" ? "OpenAI" : p === "gemini" ? "Google Gemini" : p === "yandex" ? "YandexGPT" : "Автономный (без ключа)"}
              </option>
            ))}
          </select>
          <div className="mt-1 text-[11px] text-slate-400">Ключи задаются в .env: OPENAI_API_KEY, GEMINI_API_KEY, YANDEX_GPT_API_KEY</div>
        </div>
        <Toggle k="aiSearch" label="Поиск в интернете" hint="ИИ использует актуальные результаты поиска" />
        <Toggle k="tts" label="Озвучивать ответы" hint="Синтез речи для ответов Nova AI" />
      </Section>

      <Section title="Расширения">
        {EXTENSIONS.map((x) => (
          <label key={x.id} className="flex cursor-pointer items-center gap-3 px-4 py-2.5 hover:bg-black/5 dark:hover:bg-white/5">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-black/5 dark:bg-white/10">
              <Icon name={x.icon} size={16} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-sm">{x.name}</div>
              <div className="text-[11px] text-slate-400">{x.desc}</div>
            </div>
            <input type="checkbox" className="peer sr-only" checked={Boolean(extensions[x.id])} onChange={() => onToggleExt(x.id)} />
            <span className="relative h-6 w-10 rounded-full bg-slate-300 transition peer-checked:bg-[var(--accent)] after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:after:translate-x-4 dark:bg-slate-600" />
          </label>
        ))}
      </Section>

      <Section title="Аккаунт и синхронизация">
        <div className="space-y-2 p-4">
          {settings.syncCode ? (
            <>
              <div className="text-sm">
                👤 {settings.profileName} · <span className="text-slate-400">ID {settings.profileId}</span>
              </div>
              <div className="flex items-center gap-2 rounded-xl bg-black/5 px-3 py-2 font-mono text-sm tracking-wider dark:bg-white/10">
                <span className="flex-1">{settings.syncCode}</span>
                <IconButton icon="copy" label="Копировать" size={14} className="!h-7 !w-7" onClick={() => navigator.clipboard?.writeText(settings.syncCode)} />
              </div>
              <div className="text-[11px] text-slate-400">Введите этот код на другом устройстве — история, закладки, загрузки и диалоги ИИ будут общими.</div>
              <button type="button" onClick={() => onChange({ profileId: 0, syncCode: "", profileName: "" })} className="text-xs text-red-500">
                Выйти
              </button>
            </>
          ) : (
            <>
              <input value={settings.profileName} onChange={(e) => onChange({ profileName: e.target.value })} placeholder="Ваше имя" className="w-full rounded-xl border border-black/5 bg-white px-3 py-2 text-sm dark:border-white/10 dark:bg-slate-800" />
              <button type="button" onClick={createAccount} className="accent-bg w-full rounded-xl py-2 text-sm font-medium text-white">
                Создать аккаунт синхронизации
              </button>
              <div className="text-center text-[11px] text-slate-400">или</div>
              <div className="flex gap-1">
                <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="XXXX-XXXX-XXXX" className="min-w-0 flex-1 rounded-xl border border-black/5 bg-white px-3 py-2 font-mono text-sm uppercase dark:border-white/10 dark:bg-slate-800" />
                <button type="button" onClick={login} className="rounded-xl bg-black/5 px-3 text-sm dark:bg-white/10">
                  Войти
                </button>
              </div>
            </>
          )}
          {syncMsg && <div className="text-xs accent-text">{syncMsg}</div>}
        </div>
      </Section>
      <div className="p-4 text-center text-[11px] text-slate-400">NovaBrowser 1.0 · движок: Chromium (Electron / WebView) · веб-режим: Nova Proxy</div>
    </Panel>
  );
}
