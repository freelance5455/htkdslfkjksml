import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { BANDS, BAND_META } from '../data/constants';
import type { CefrBand, GameModeId, PersistedSettings, VocabStore } from '../types';
import { prefetchWordBundle, prefetchWordsBatch } from '../utils/prefetchEngine';
import {
  getBandDoneCount,
  getBandSubCount,
  getBandSubIndices,
  lvlKey,
} from '../utils/vocabLogic';
import { WordRow } from './WordRow';

interface CefrBandsListProps {
  store: VocabStore;
  settings: PersistedSettings;
  onOpenBand: (band: CefrBand) => void;
}

export function CefrBandsList({ store, settings, onOpenBand }: CefrBandsListProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {BANDS.map((b) => {
          const meta = BAND_META[b];
          const wordCount = store.byBand[b].length;
          const subTot = getBandSubCount(store, b, settings.levelSize);
          const subDone = getBandDoneCount(store, b, settings.levelSize, settings.completed);
          const pct = Math.round((subDone / Math.max(1, subTot)) * 100);

          return (
            <button
              key={b}
              type="button"
              onClick={() => onOpenBand(b)}
              className="tmn-card-hover flex items-center gap-4 rounded-2xl p-5 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
            >
              <div
                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl font-en text-xl font-extrabold text-white shadow-xs ${meta.bgClass}`}
              >
                {b}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-base font-extrabold text-slate-900 dark:text-slate-50">
                    {meta.ar}
                  </span>
                  <span className="font-code text-xs font-semibold tabular-nums text-slate-500 dark:text-slate-400">
                    {wordCount.toLocaleString('en-US')} كلمة
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {meta.desc} · مكتمل{' '}
                  <span className="font-code tabular-nums">
                    {subDone} / {subTot}
                  </span>
                </p>
                <div className="tmn-progress-track mt-3 h-1.5 w-full">
                  <div
                    className={`h-full rounded-full ${meta.bgClass}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
              <ChevronLeft className="h-5 w-5 shrink-0 text-slate-400" aria-hidden="true" />
            </button>
          );
        })}
      </div>
    </div>
  );
}

interface BandSubLevelsProps {
  store: VocabStore;
  settings: PersistedSettings;
  band: CefrBand;
  onOpenLevelDetail: (band: CefrBand, subIdx: number) => void;
  onToast: (msg: string) => void;
}

export function BandSubLevels({
  store,
  settings,
  band,
  onOpenLevelDetail,
  onToast,
}: BandSubLevelsProps) {
  const [filter, setFilter] = useState<'all' | 'todo' | 'done'>('all');
  const [page, setPage] = useState(0);
  const [jumpInput, setJumpInput] = useState('');

  const subTot = getBandSubCount(store, band, settings.levelSize);
  const filtered: number[] = [];
  for (let i = 0; i < subTot; i++) {
    const sc = settings.completed[lvlKey(band, i)] || 0;
    if (filter === 'done' && sc < 80) continue;
    if (filter === 'todo' && sc >= 80) continue;
    filtered.push(i);
  }

  const perPage = 24;
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const safePage = Math.min(Math.max(0, page), totalPages - 1);
  const slice = filtered.slice(safePage * perPage, (safePage + 1) * perPage);

  const handleJump = () => {
    const val = parseInt(jumpInput, 10);
    if (!val || val < 1 || val > subTot) {
      onToast(`أدخل رقماً بين 1 و ${subTot}`);
      return;
    }
    onOpenLevelDetail(band, val - 1);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div
          role="tablist"
          aria-label="تصفية المستويات"
          className="grid grid-cols-3 gap-1 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80 sm:w-80"
        >
          {(
            [
              { id: 'all', label: `الكل (${subTot})` },
              { id: 'todo', label: 'غير مكتمل' },
              { id: 'done', label: 'مكتمل' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={filter === t.id}
              onClick={() => {
                setFilter(t.id);
                setPage(0);
              }}
              className={`min-h-[38px] whitespace-nowrap rounded-lg px-2.5 text-xs font-bold transition-colors ${
                filter === t.id
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="number"
            min={1}
            max={subTot}
            value={jumpInput}
            onChange={(e) => setJumpInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleJump();
            }}
            aria-label="رقم المستوى للانتقال السريع"
            placeholder={`انتقال لرقم (1 – ${subTot})`}
            className="h-10 w-44 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-100"
          />
          <button
            type="button"
            onClick={handleJump}
            className="h-10 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
          >
            انتقال
          </button>
        </div>
      </div>

      {slice.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500 dark:border-slate-800 dark:bg-[#131c2e] dark:text-slate-400">
          لا توجد مستويات مطابقة لهذا الفلتر.
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {slice.map((subIdx) => {
            const idxs = getBandSubIndices(store, band, subIdx, settings.levelSize);
            const sc = settings.completed[lvlKey(band, subIdx)] || 0;
            const sample = idxs
              .slice(0, 3)
              .map((id) => store.words[id]?.en)
              .filter(Boolean)
              .join(', ');
            return (
              <button
                key={subIdx}
                type="button"
                onClick={() => onOpenLevelDetail(band, subIdx)}
                className={`tmn-card-hover flex flex-col gap-2.5 rounded-2xl p-4 text-start ${
                  sc >= 80 ? 'ring-1 ring-emerald-500/35' : ''
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                    المستوى {subIdx + 1}
                  </span>
                  <span
                    className={`font-code text-xs font-bold tabular-nums ${
                      sc >= 80
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : sc > 0
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-slate-400'
                    }`}
                  >
                    {sc >= 80 ? `${sc}% ✓` : sc > 0 ? `${sc}%` : 'جديد'}
                  </span>
                </div>
                <div
                  className="truncate font-en text-xs text-slate-500 dark:text-slate-400"
                  dir="ltr"
                >
                  {sample}
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${sc}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            type="button"
            disabled={safePage === 0}
            onClick={() => {
              setPage((p) => Math.max(0, p - 1));
              window.scrollTo({ top: 0 });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 disabled:opacity-40 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
            <span>السابق</span>
          </button>
          <span className="font-code text-xs font-bold tabular-nums text-slate-600 dark:text-slate-300">
            {safePage + 1} / {totalPages}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages - 1}
            onClick={() => {
              setPage((p) => Math.min(totalPages - 1, p + 1));
              window.scrollTo({ top: 0 });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 disabled:opacity-40 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200"
          >
            <span>التالي</span>
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  );
}

interface LevelDetailProps {
  store: VocabStore;
  settings: PersistedSettings;
  band: CefrBand;
  subIdx: number;
  favoritesSet: Set<number>;
  mistakesSet: Set<number>;
  masteredSet: Set<number>;
  onNavigateLevel: (band: CefrBand, subIdx: number) => void;
  onStartMode: (mode: GameModeId, band: CefrBand, subIdx: number) => void;
  onOpenWordDetail: (id: number) => void;
  onSpeak: (text: string) => void;
  onToggleFavorite: (id: number) => void;
}

export function LevelDetail({
  store,
  settings,
  band,
  subIdx,
  favoritesSet,
  mistakesSet,
  masteredSet,
  onNavigateLevel,
  onOpenWordDetail,
  onSpeak,
  onToggleFavorite,
}: LevelDetailProps) {
  const indices = getBandSubIndices(store, band, subIdx, settings.levelSize);
  const best = settings.completed[lvlKey(band, subIdx)] || 0;
  const totalSubs = getBandSubCount(store, band, settings.levelSize);

  useEffect(() => {
    const topWords = indices
      .slice(0, 12)
      .map((id) => store.words[id])
      .filter((w): w is NonNullable<typeof w> => Boolean(w));
    if (topWords.length > 0) {
      prefetchWordsBatch(
        topWords,
        {
          backendUrl: settings.backendUrl,
          pixabayKey: settings.pixabayKey,
          unsplashKey: settings.unsplashKey,
          uiLang: settings.uiLang || 'ar',
        },
        12,
        true
      );
    }
  }, [
    band,
    subIdx,
    settings.levelSize,
    settings.uiLang,
    store.words,
    settings.backendUrl,
    settings.pixabayKey,
    settings.unsplashKey,
  ]);

  return (
    <div className="space-y-6">
      <div className="tmn-card flex flex-wrap items-center justify-between gap-4 rounded-2xl p-5">
        <div className="flex items-center gap-3">
          <span
            className={`flex h-11 w-11 items-center justify-center rounded-xl font-en text-base font-extrabold text-white ${BAND_META[band].bgClass}`}
          >
            {band}
          </span>
          <div>
            <h1 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
              المستوى {subIdx + 1} · {BAND_META[band].ar}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              <span className="font-code tabular-nums">{indices.length}</span> كلمة · أفضل نتيجة:{' '}
              <span className="font-code font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                {best}%
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={subIdx === 0}
            onClick={() => onNavigateLevel(band, subIdx - 1)}
            aria-label="المستوى السابق"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            disabled={subIdx >= totalSubs - 1}
            onClick={() => onNavigateLevel(band, subIdx + 1)}
            aria-label="المستوى التالي"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      <div className="space-y-2.5">
        {indices.map((id) => {
          const w = store.words[id];
          if (!w) return null;
          return (
            <WordRow
              key={id}
              word={w}
              isFavorite={favoritesSet.has(id)}
              isMistake={mistakesSet.has(id)}
              isMastered={masteredSet.has(id)}
              onOpenDetail={onOpenWordDetail}
              onSpeak={onSpeak}
              onToggleFavorite={onToggleFavorite}
              onPrefetchWord={(entry) =>
                prefetchWordBundle(
                  entry,
                  {
                    backendUrl: settings.backendUrl,
                    pixabayKey: settings.pixabayKey,
                    unsplashKey: settings.unsplashKey,
                    uiLang: settings.uiLang || 'ar',
                  },
                  true
                )
              }
            />
          );
        })}
      </div>
    </div>
  );
}
