"use client";

import type { Player } from "@/lib/types";

/* ---------------- Cricket icons ---------------- */

export function BallIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <circle cx="12" cy="12" r="9" fill="#dc2626" />
      <path
        d="M7.5 4.2C8.6 6.6 8.8 9.4 8 12c-.8 2.6-2.4 4.8-4.6 6.3M16.5 4.2c-1.1 2.4-1.3 5.2-.5 7.8.8 2.6 2.4 4.8 4.6 6.3"
        stroke="#fde68a"
        strokeWidth="1.1"
        fill="none"
        strokeDasharray="2 1.6"
        strokeLinecap="round"
      />
      <circle cx="12" cy="12" r="9" fill="none" stroke="#7f1d1d" strokeWidth="1" />
    </svg>
  );
}

export function BatIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <rect
        x="13.4"
        y="1.9"
        width="4.6"
        height="12.5"
        rx="1.6"
        transform="rotate(35 15.7 8.1)"
        fill="#d4a373"
        stroke="#92400e"
        strokeWidth="0.8"
      />
      <rect
        x="6.2"
        y="14.6"
        width="2.1"
        height="7.4"
        rx="1"
        transform="rotate(35 7.2 18.3)"
        fill="#94a3b8"
      />
    </svg>
  );
}

export function StumpsIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <g fill="#e2e8f0">
        <rect x="5" y="6" width="2" height="15" rx="1" />
        <rect x="11" y="6" width="2" height="15" rx="1" />
        <rect x="17" y="6" width="2" height="15" rx="1" />
      </g>
      <g fill="#f59e0b">
        <rect x="4.5" y="4" width="6" height="1.8" rx="0.9" />
        <rect x="13.5" y="4" width="6" height="1.8" rx="0.9" />
      </g>
    </svg>
  );
}

/* ---------------- Compact action icons (16–20px) ---------------- */

const ico = "h-[18px] w-[18px]";

export function ScorecardIcon({ className = ico }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
      <rect x="3.5" y="3.5" width="17" height="17" rx="2.5" />
      <path d="M7.5 8.5h9M7.5 12h9M7.5 15.5h5.5" />
    </svg>
  );
}

export function BallByBallIcon({ className = ico }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
      <circle cx="5.5" cy="12" r="2.2" />
      <circle cx="12" cy="12" r="2.2" />
      <circle cx="18.5" cy="12" r="2.2" />
    </svg>
  );
}

export function CommentaryIcon({ className = ico }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M20.5 12.5a7.5 7.5 0 0 1-10.9 6.7L4 20.5l1.4-5.4A7.5 7.5 0 1 1 20.5 12.5Z" />
    </svg>
  );
}

export function HistoryIcon({ className = ico }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1" />
      <path d="M3.5 4.5V9h4.5M12 7.5V12l3 1.8" />
    </svg>
  );
}

/** Crossed bat & ball — the MATCH CRICKET brand mark. */
export function BatBallLogo({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <defs>
        <linearGradient id="mcWood" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f0c088" />
          <stop offset="100%" stopColor="#b9772f" />
        </linearGradient>
      </defs>
      {/* bat blade */}
      <rect
        x="19.5"
        y="4.5"
        width="11"
        height="24"
        rx="3"
        transform="rotate(38 25 16)"
        fill="url(#mcWood)"
        stroke="#7c4a12"
        strokeWidth="1.3"
      />
      {/* splice + handle */}
      <rect
        x="22.6"
        y="27"
        width="4.6"
        height="14"
        rx="2.3"
        transform="rotate(38 25 34)"
        fill="#334155"
        stroke="#1e293b"
        strokeWidth="1"
      />
      {/* ball */}
      <circle cx="14" cy="34" r="8" fill="#dc2626" stroke="#7f1d1d" strokeWidth="1.4" />
      <path
        d="M8.6 30.2c2.6 1 4.6 3.1 5.6 5.7M19.4 30.2c-2.6 1-4.6 3.1-5.6 5.7"
        stroke="#fde68a"
        strokeWidth="1.2"
        fill="none"
        strokeLinecap="round"
        strokeDasharray="1.8 1.5"
      />
    </svg>
  );
}

export function TrophyIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden fill="currentColor">
      <path d="M6 3h12v2h3v3a4 4 0 0 1-4 4h-.6A6 6 0 0 1 13 15.9V18h3v3H8v-3h3v-2.1A6 6 0 0 1 7.6 12H7a4 4 0 0 1-4-4V5h3V3Zm0 4H5v1a2 2 0 0 0 1 1.7V7Zm13 0h-1v2.7A2 2 0 0 0 19 8V7Z" />
    </svg>
  );
}

/* ---------------- Team logo ---------------- */

function hashHue(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return h;
}

export function TeamLogo({
  name,
  logo,
  size = 48,
}: {
  name: string;
  logo?: string;
  size?: number;
}) {
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  const hue = hashHue(name);
  if (logo) {
    // eslint-disable-next-line @next/next/no-img-element
    return (
      <img
        src={logo}
        alt={name}
        style={{ width: size, height: size }}
        className="rounded-xl border border-slate-700 object-cover"
      />
    );
  }
  return (
    <div
      style={{
        width: size,
        height: size,
        background: `linear-gradient(135deg, hsl(${hue} 70% 42%), hsl(${(hue + 40) % 360} 70% 26%))`,
        fontSize: size * 0.36,
      }}
      className="flex items-center justify-center rounded-xl font-black text-white shadow-inner ring-1 ring-white/10"
    >
      {initials}
    </div>
  );
}

/* ---------------- Player avatar ---------------- */

export function PlayerAvatar({
  player,
  size = 40,
  ring,
}: {
  player?: Player | null;
  size?: number;
  ring?: boolean;
}) {
  const name = player?.name ?? "?";
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  const hue = hashHue(name);
  const cls = `shrink-0 rounded-full object-cover ${ring ? "ring-2 ring-emerald-400" : "ring-1 ring-slate-700"}`;
  if (player?.photo) {
    // eslint-disable-next-line @next/next/no-img-element
    return (
      <img src={player.photo} alt={name} style={{ width: size, height: size }} className={cls} />
    );
  }
  return (
    <div
      style={{
        width: size,
        height: size,
        background: `linear-gradient(135deg, hsl(${hue} 55% 38%), hsl(${(hue + 50) % 360} 55% 22%))`,
        fontSize: size * 0.38,
      }}
      className={`flex items-center justify-center font-black text-white ${cls}`}
    >
      {initials}
    </div>
  );
}

/* ---------------- Badges ---------------- */

export function RoleBadges({ player }: { player: Player }) {
  return (
    <span className="inline-flex gap-1">
      {player.captain && (
        <span className="rounded bg-amber-400 px-1.5 text-[10px] font-black text-slate-900">C</span>
      )}
      {player.viceCaptain && (
        <span className="rounded bg-sky-400 px-1.5 text-[10px] font-black text-slate-900">VC</span>
      )}
      {player.wicketKeeper && (
        <span className="rounded bg-emerald-400 px-1.5 text-[10px] font-black text-slate-900">
          WK
        </span>
      )}
    </span>
  );
}

export function PlayerCard({
  player,
  onClick,
  index,
}: {
  player: Player;
  onClick?: () => void;
  index?: number;
}) {
  return (
    <button
      onClick={onClick}
      className="mc-btn flex w-full items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/50 px-3 py-2.5 text-left hover:border-emerald-500/50 hover:bg-slate-800/60"
    >
      {index !== undefined && (
        <span className="w-4 text-xs font-bold text-slate-600">{index + 1}</span>
      )}
      <PlayerAvatar player={player} size={40} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate text-sm font-bold">{player.name}</p>
          <RoleBadges player={player} />
        </div>
        <p className="text-[11px] text-slate-400">
          {player.role}
          {player.jersey ? ` · #${player.jersey}` : ""}
        </p>
      </div>
      <span className="text-xs text-slate-600">›</span>
    </button>
  );
}
