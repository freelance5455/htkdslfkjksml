"use client";

import { Suspense, useMemo, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, Float, OrbitControls } from "@react-three/drei";
import CalculatorModel from "./CalculatorModel";
import { CalcLights } from "./CalcScene";
import { colorNameToHex, type ScreenData } from "@/lib/calculator";

export default function ProductViewer3D({
  colors = [],
  modelNumber = "CLC-991CW",
  priceLabel = "",
  accent = "#a855f7",
}: {
  colors?: string[];
  modelNumber?: string;
  priceLabel?: string;
  accent?: string;
}) {
  const options = colors.length ? colors : ["Midnight Black"];
  const [active, setActive] = useState(0);
  const bodyColor = colorNameToHex(options[active]);

  const screen = useMemo<ScreenData>(
    () => ({
      expression: modelNumber,
      cursor: null,
      result: priceLabel || "0",
      error: null,
      shift: false,
      angle: "DEG",
      fraction: false,
    }),
    [modelNumber, priceLabel],
  );

  return (
    <div className="relative h-[480px] w-full overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-[#0a0e1a] to-black md:h-[600px]">
      <Canvas dpr={[1, 1.75]} camera={{ position: [0, 0, 15], fov: 36 }} gl={{ antialias: true, alpha: true }}>
        <Suspense fallback={null}>
          <CalcLights accent={accent} />
          <Float speed={1.4} rotationIntensity={0.2} floatIntensity={0.6}>
            <CalculatorModel screen={screen} bodyColor={bodyColor} accent={accent} modelLabel={modelNumber} />
          </Float>
          <ContactShadows position={[0, -4.9, 0]} opacity={0.6} scale={12} blur={2.6} far={6} color="#000" />
          <OrbitControls
            enablePan={false}
            enableZoom
            minDistance={9}
            maxDistance={20}
            autoRotate
            autoRotateSpeed={1.2}
            minPolarAngle={Math.PI / 2 - 0.6}
            maxPolarAngle={Math.PI / 2 + 0.45}
          />
        </Suspense>
      </Canvas>

      {options.length > 1 && (
        <div className="absolute left-4 top-4 flex flex-col gap-2">
          {options.map((name, i) => (
            <button
              key={name}
              onClick={() => setActive(i)}
              className={`flex items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-semibold backdrop-blur transition ${
                active === i
                  ? "border-purple-400/70 bg-purple-500/20 text-white"
                  : "border-white/10 bg-black/40 text-slate-400 hover:text-white"
              }`}
            >
              <span className="h-3.5 w-3.5 rounded-full border border-white/30" style={{ backgroundColor: colorNameToHex(name) }} />
              {name}
            </button>
          ))}
        </div>
      )}

      <div className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border border-white/10 bg-black/50 px-4 py-1.5 text-[11px] text-slate-400 backdrop-blur">
        🖱 Drag to rotate · Scroll to zoom · Pick a colour
      </div>
    </div>
  );
}
