import { useState } from 'react';
import { NoteEntry, Student } from '../types';
import { Plus, Search, Trash2, BookOpen } from 'lucide-react';

interface NotesViewProps {
  notes: NoteEntry[];
  students: Student[];
  onAddNote: () => void;
  onDeleteNote: (noteId: string) => void;
  onEditNote?: (note: NoteEntry) => void;
}

export const NotesView = ({
  notes,
  students,
  onAddNote,
  onDeleteNote,
}: NotesViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudentFilter, setSelectedStudentFilter] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredNotes = notes.filter((n) => {
    const matchesSearch =
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.studentName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStudent =
      selectedStudentFilter === 'all' || n.studentId === selectedStudentFilter;

    const matchesCategory =
      selectedCategory === 'all' || n.category === selectedCategory;

    return matchesSearch && matchesStudent && matchesCategory;
  });

  return (
    <div className="space-y-4">
      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#121214] p-4 rounded-2xl border border-zinc-800 shadow-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Ders notlarında, ödevlerde veya kelimelerde ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-zinc-900 focus:bg-zinc-850 rounded-xl border border-zinc-800 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 text-stone-100 transition-all placeholder:text-stone-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <select
            value={selectedStudentFilter}
            onChange={(e) => setSelectedStudentFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-zinc-900 rounded-xl border border-zinc-800 text-stone-200 font-semibold focus:outline-none"
          >
            <option value="all">Tüm Öğrenciler</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-xs bg-zinc-900 rounded-xl border border-zinc-800 text-stone-200 font-semibold focus:outline-none"
          >
            <option value="all">Tüm Kategoriler</option>
            <option value="Ders Notu">Ders Notu</option>
            <option value="Ödev & Görev">Ödev & Görev</option>
            <option value="Kelime Listesi">Kelime Listesi</option>
            <option value="Genel Değerlendirme">Genel Değerlendirme</option>
          </select>

          <button
            onClick={onAddNote}
            className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-rose-950/40 shrink-0 cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Not</span>
          </button>
        </div>
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredNotes.length === 0 ? (
          <div className="col-span-full bg-[#121214] rounded-2xl border border-zinc-800 p-12 text-center text-stone-500">
            <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm font-medium">Kayıtlı not bulunamadı.</p>
          </div>
        ) : (
          filteredNotes.map((note) => (
            <div
              key={note.id}
              className="bg-[#121214] rounded-2xl border border-zinc-800 p-5 shadow-xl hover:border-zinc-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      note.category === 'Ödev & Görev'
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                        : note.category === 'Kelime Listesi'
                        ? 'bg-sky-950/80 text-sky-300 border border-sky-500/40'
                        : note.category === 'Ders Notu'
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                        : 'bg-purple-950/80 text-purple-300 border border-purple-500/40'
                    }`}
                  >
                    {note.category}
                  </span>

                  <span className="text-[11px] text-stone-400 font-mono">
                    {note.date}
                  </span>
                </div>

                <h4 className="font-bold text-white text-sm mb-1">{note.title}</h4>
                <div className="text-xs font-semibold text-rose-400 mb-2">
                  👤 {note.studentName}
                </div>

                <p className="text-xs text-stone-300 whitespace-pre-wrap leading-relaxed line-clamp-4">
                  {note.content}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs">
                <span className="text-[11px] text-stone-400">Zeynep'in Günlüğü</span>
                <button
                  onClick={() => {
                    if (window.confirm(`'${note.title}' başlıklı notu silmek istediğinize emin misiniz?`)) {
                      onDeleteNote(note.id);
                    }
                  }}
                  className="p-1 text-stone-500 hover:text-rose-400 rounded transition-all cursor-pointer"
                  title="Notu sil"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
