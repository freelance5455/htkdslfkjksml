import React, { useState } from 'react';
import { User, Volume2, Users, X, Sparkles, Image as ImageIcon, Lock, Globe } from 'lucide-react';
import { Character, GenderTag } from '../types';

interface CreateModalProps {
  onClose: () => void;
  onCreateCharacter: (newChar: Character) => void;
}

export const CreateModal: React.FC<CreateModalProps> = ({
  onClose,
  onCreateCharacter,
}) => {
  const [activeStep, setActiveStep] = useState<'menu' | 'character_form'>('menu');

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [greeting, setGreeting] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [category, setCategory] = useState<'Female' | 'Male' | 'OC'>('Female');
  const [isPrivate, setIsPrivate] = useState(true);
  const [avatarUrl, setAvatarUrl] = useState(
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80'
  );

  const handleSaveCharacter = () => {
    if (!name.trim() || !greeting.trim()) {
      alert('الرجاء إدخال اسم الشخصية ورسالة الترحيب الأولى.');
      return;
    }

    const newChar: Character = {
      id: `custom-${Date.now()}`,
      name: name,
      nameAr: name,
      avatar: avatarUrl,
      description: description || 'شخصية مخصصة تم إنشاؤها عبر PinkVerse AI',
      category: category,
      likesCount: '1',
      chatsCount: '0',
      isPrivate: isPrivate,
      greeting: greeting,
      systemPrompt:
        systemPrompt ||
        `You are ${name}. Always respond in character with action narrative in parentheses.`,
      creatorName: 'samrae bounadar',
      createdAt: new Date().toISOString().split('T')[0],
    };

    onCreateCharacter(newChar);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 dir-rtl">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 text-white shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-pink-400" />
              <span>إنشاء</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              تحديد المحتوى المراد إنشاؤه
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Main Menu Options matching Screenshot 3 */}
        {activeStep === 'menu' && (
          <div className="space-y-3.5 py-2">
            {/* Option 1: Create Character */}
            <button
              onClick={() => setActiveStep('character_form')}
              className="w-full bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 rounded-2xl p-4 flex items-center space-x-4 space-x-reverse transition-all group text-right"
            >
              <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 group-hover:scale-110 transition-transform">
                <User className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-white text-base group-hover:text-pink-300 transition-colors">
                  إنشاء شخصية
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  تضمين الاسم، المظهر، نبرة الصوت وشخصية الـ AI
                </p>
              </div>
            </button>

            {/* Option 2: Voice */}
            <button
              onClick={() => alert('ميزة الصوت التفاعلي قيد التطوير وستتوفر قريباً!')}
              className="w-full bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 flex items-center space-x-4 space-x-reverse transition-all group text-right"
            >
              <div className="w-12 h-12 rounded-2xl bg-slate-700/80 border border-slate-600 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                <Volume2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-white text-base group-hover:text-pink-300 transition-colors">
                  صوت
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  إنشاء نموذج صوتي مخصص للشخصية
                </p>
              </div>
            </button>

            {/* Option 3: Group Chat */}
            <button
              onClick={() => alert('ميزة المحادثات الجماعية بين الشخصيات مفعلة للنسخة المميزة!')}
              className="w-full bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 rounded-2xl p-4 flex items-center space-x-4 space-x-reverse transition-all group text-right"
            >
              <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-300 group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-white text-base group-hover:text-blue-300 transition-colors">
                  محادثة جماعية
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  إنشاء غرفة تجمع عدة شخصيات للتفاعل المباشر
                </p>
              </div>
            </button>
          </div>
        )}

        {/* Step 2: Character Creation Form */}
        {activeStep === 'character_form' && (
          <div className="space-y-4 py-1 text-right">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                اسم الشخصية *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: ياسمين، سامر..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الوصف المختصر
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="شرح بسيط عن طبيعة الشخصية ودورها..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                رسالة الترحيب الأولى *
              </label>
              <textarea
                value={greeting}
                onChange={(e) => setGreeting(e.target.value)}
                rows={2}
                placeholder="(تلتفت إليك بابتسامة) أهلاً بك! كيف يمكنني مساعدتك اليوم؟"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500 resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                نوع الشخصية (التصنيف)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Female', 'Male', 'OC'] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-colors ${
                      category === cat
                        ? 'bg-pink-500 text-white border-pink-400'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    {cat === 'Female' ? 'إناث' : cat === 'Male' ? 'ذكور' : 'OC'}
                  </button>
                ))}
              </div>
            </div>

            {/* Visibility toggle: Private (خاص) vs Public */}
            <div className="flex items-center justify-between p-3 bg-slate-800/80 rounded-xl border border-slate-700">
              <div className="flex items-center space-x-2 space-x-reverse">
                {isPrivate ? <Lock className="w-4 h-4 text-pink-400" /> : <Globe className="w-4 h-4 text-green-400" />}
                <span className="text-xs font-bold text-white">
                  {isPrivate ? 'شخصية خاصة (خاص)' : 'شخصية عامة'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsPrivate(!isPrivate)}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  isPrivate ? 'bg-pink-600' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                    isPrivate ? 'right-6' : 'right-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse pt-2">
              <button
                onClick={handleSaveCharacter}
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-xl text-xs shadow-lg shadow-pink-500/20 transition-all"
              >
                حفظ وإنشاء الشخصية
              </button>
              <button
                onClick={() => setActiveStep('menu')}
                className="px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 py-3 rounded-xl text-xs font-semibold"
              >
                إلغاء
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
