import React, { useState } from 'react';
import { 
  RotateCcw, 
  Play, 
  Clock, 
  GitCommit, 
  GitBranch, 
  CheckCircle2, 
  ArrowRight, 
  Eye, 
  ShieldCheck,
  FastForward,
  Rewind
} from 'lucide-react';
import { Checkpoint } from '../types';

interface GodexReplayCenterViewProps {
  checkpoints: Checkpoint[];
  onRestoreCheckpoint: (checkpointId: string) => void;
  onSelectWorkspaceView: (view: any) => void;
}

export const GodexReplayCenterView: React.FC<GodexReplayCenterViewProps> = ({
  checkpoints = [],
  onRestoreCheckpoint,
  onSelectWorkspaceView
}) => {
  const [selectedCheckpointIndex, setSelectedCheckpointIndex] = useState<number>(0);

  const defaultCheckpoints = checkpoints.length > 0 ? checkpoints : [
    {
      id: 'cp-initial',
      timestamp: Date.now() - 1000 * 60 * 15,
      description: 'Initial project template scaffolded',
      files: {},
      author: 'GODEX Architect'
    },
    {
      id: 'cp-ast-mod',
      timestamp: Date.now() - 1000 * 60 * 8,
      description: 'Applied atomic visual & AST mutations',
      files: {},
      author: 'Coding Agent'
    },
    {
      id: 'cp-verified',
      timestamp: Date.now() - 1000 * 60 * 2,
      description: 'Verified full perceptual & layout regression',
      files: {},
      author: 'Verification Agent'
    }
  ];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#0A0F1C] overflow-y-auto font-sans p-6 space-y-6 select-none">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#18233C]">
        <div>
          <div className="flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-indigo-400" />
            <h1 className="text-xl font-bold text-white font-mono">REPLAY CENTER & TIME TRAVEL</h1>
            <span className="px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-500/40 text-indigo-300 text-xs font-mono">
              Deterministic Time-Travel
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Step backwards and forwards through any point in the autonomous engineering loop.
          </p>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setSelectedCheckpointIndex(Math.max(0, selectedCheckpointIndex - 1))}
            className="p-2 rounded-xl bg-[#121A2E] hover:bg-[#18233C] border border-[#1F2C4A] text-slate-200 transition-colors"
            title="Step Back"
          >
            <Rewind className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setSelectedCheckpointIndex(Math.min(defaultCheckpoints.length - 1, selectedCheckpointIndex + 1))}
            className="p-2 rounded-xl bg-[#121A2E] hover:bg-[#18233C] border border-[#1F2C4A] text-slate-200 transition-colors"
            title="Step Forward"
          >
            <FastForward className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Timeline Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Checkpoint list (Col 7) */}
        <div className="lg:col-span-7 space-y-3">
          <h3 className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">CHECKPOINT TIMELINE</h3>
          <div className="space-y-3">
            {defaultCheckpoints.map((cp, idx) => {
              const isSelected = selectedCheckpointIndex === idx;
              return (
                <div
                  key={cp.id}
                  onClick={() => setSelectedCheckpointIndex(idx)}
                  className={`p-4 rounded-2xl bg-[#0F1629] border ${
                    isSelected 
                      ? 'border-indigo-500/60 bg-[#141E36] ring-2 ring-indigo-500/30' 
                      : 'border-[#1E2942] hover:bg-[#121A30]'
                  } cursor-pointer transition-all duration-150 flex items-start justify-between gap-4`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                      isSelected ? 'bg-indigo-600 text-white' : 'bg-[#1A243B] text-neutral-400'
                    }`}>
                      <GitCommit className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white font-mono">{cp.description}</div>
                      <div className="text-[10px] font-mono text-neutral-400 mt-0.5">
                        Author: <span className="text-indigo-300">{cp.author || 'GODEX'}</span> • {new Date(cp.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRestoreCheckpoint(cp.id);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-300 text-xs font-mono shrink-0 transition-colors"
                  >
                    Restore State
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Active Inspection / Snapshot Preview (Col 5) */}
        <div className="lg:col-span-5 rounded-2xl bg-[#0F1629] border border-[#1E2942] p-5 shadow-xl flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">CHECKPOINT METADATA</span>
              <span className="text-[10px] font-mono text-emerald-400">Deterministic</span>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0E1A] border border-[#1A243B] space-y-2 text-xs font-mono">
              <div className="flex justify-between text-neutral-400">
                <span>Checkpoint ID:</span>
                <span className="text-slate-200">{defaultCheckpoints[selectedCheckpointIndex]?.id}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Timestamp:</span>
                <span className="text-slate-200">{new Date(defaultCheckpoints[selectedCheckpointIndex]?.timestamp).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Verification State:</span>
                <span className="text-emerald-400">PASS (100%)</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed pt-2">
              Time-travel restoration resets both the in-memory AST and DOM snapshot cache without risking orphaned mutations.
            </p>
          </div>

          <div className="pt-4 border-t border-[#1A243B]">
            <button
              onClick={() => onSelectWorkspaceView('studio')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Eye className="w-4 h-4" />
              <span>Inspect in Agent Studio</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
