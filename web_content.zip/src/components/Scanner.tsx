import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, 
  Image as ImageIcon, 
  Sparkles, 
  Send, 
  Mic, 
  MicOff, 
  Plus, 
  Trash2, 
  X, 
  RefreshCw, 
  Zap, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Layers, 
  CheckCircle2, 
  HelpCircle, 
  ChevronRight, 
  ArrowLeft, 
  ArrowRight,
  Maximize2,
  Calendar,
  User,
  Lightbulb,
  Award,
  FileQuestion,
  RotateCcw,
  Check,
  Eye,
  SlidersHorizontal,
  GraduationCap,
  Bookmark,
  Play,
  Pause,
  Square,
  Headphones,
  History,
  MessageSquare,
  Crown,
  ShieldCheck,
  CheckSquare
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { SAMPLE_SCANS } from '../presets';
import EduMindProPaymentModal from './EduMindProPaymentModal';

interface ScannerProps {
  language: Language;
  onIncrementScan: () => void;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
  onOpenProModal?: () => void;
}

export interface ScanKeyFact {
  type: 'topic' | 'key_point' | 'date' | 'person' | 'exam_tip' | 'revision';
  label: string;
  value: string;
}

export interface ScanSection {
  number: number;
  title: string;
  content: string;
  badge?: string;
}

export interface ScanMCQ {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface ScanFlashcard {
  front: string;
  back: string;
  hint?: string;
}

export interface ScanTutorResponse {
  topicTitle: string;
  pageCount: number;
  summary: string;
  detailedExplanation: string;
  sections: ScanSection[];
  keyFacts: ScanKeyFact[];
  bookExtractedHighlights: string[];
  aiAdditionalContext: string[];
  followUpQuestions: string[];
  quickRevisionPoints: string[];
  mcqs?: ScanMCQ[];
  flashcards?: ScanFlashcard[];
}

export interface ScanChatMessage {
  id: string;
  role: 'user' | 'assistant';
  query?: string;
  data?: ScanTutorResponse;
  actionUsed?: string;
  timestamp: string;
}

export default function Scanner({ 
  language, 
  onIncrementScan,
  userProfile,
  setUserProfile,
  onOpenProModal
}: ScannerProps) {
  // Attached pages state (Array of Base64 or URL images)
  const [attachedPages, setAttachedPages] = useState<string[]>([]);
  const [previewZoomImage, setPreviewZoomImage] = useState<string | null>(null);

  // Full-Screen Mobile Camera State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [isFlashOn, setIsFlashOn] = useState<boolean>(false);
  const [cameraShutterFlash, setCameraShutterFlash] = useState<boolean>(false);
  const [capturedInSession, setCapturedInSession] = useState<string[]>([]);

  // Maximum limits: Max 5 pages per scan request, Daily 3 Free Scans
  const MAX_PAGES_PER_SCAN = 5;
  const DAILY_FREE_SCANS = 3;

  // Daily Scan Limit System (3 Free Scans/day + Rewarded Ads + Pro)
  const currentDayKey = new Date().toISOString().slice(0, 10); // e.g. "2026-08-29"

  const [dailyScanCount, setDailyScanCount] = useState<number>(() => {
    try {
      const savedDay = localStorage.getItem('edumind_scan_day_key');
      const savedCount = localStorage.getItem('edumind_daily_scans_count');
      if (savedDay === currentDayKey && savedCount) {
        return parseInt(savedCount, 10);
      }
    } catch (e) {}
    return 0;
  });

  const [bonusScans, setBonusScans] = useState<number>(() => {
    try {
      const savedBonus = localStorage.getItem('edumind_bonus_scans');
      return savedBonus ? parseInt(savedBonus, 10) : 0;
    } catch (e) {
      return 0;
    }
  });

  // EduMind Pro Subscription State (৳99 / ₹99 per month for unlimited scans)
  const [isPro, setIsPro] = useState<boolean>(() => {
    try {
      if (userProfile?.isPro !== undefined) return Boolean(userProfile.isPro);
      const savedPro = localStorage.getItem('edumind_is_pro');
      return savedPro === 'true';
    } catch (e) {
      return false;
    }
  });

  useEffect(() => {
    if (userProfile?.isPro !== undefined) {
      setIsPro(Boolean(userProfile.isPro));
    }
  }, [userProfile?.isPro]);

  const [showProModal, setShowProModal] = useState<boolean>(false);
  const [rewardToast, setRewardToast] = useState<string>('');

  // Rewarded Sponsored Ad Modal state (Unlocks +2 Scans)
  const [showAdModal, setShowAdModal] = useState<boolean>(false);
  const [adWatchCountdown, setAdWatchCountdown] = useState<number>(5);
  const [isWatchingAd, setIsWatchingAd] = useState<boolean>(false);

  // AI Interaction & Chat State
  const [questionInput, setQuestionInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingHasImages, setLoadingHasImages] = useState<boolean>(false);
  const [scanError, setScanError] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<ScanChatMessage[]>([]);
  const [currentResponse, setCurrentResponse] = useState<ScanTutorResponse | null>(null);

  // Expanding text writing area & full-editor modal
  const [isTextExpanded, setIsTextExpanded] = useState<boolean>(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize question textarea so all typed text is always 100% visible
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollH = textareaRef.current.scrollHeight;
      // Auto-expand dynamically from 44px up to 200px (6-8 lines)
      const targetH = Math.min(Math.max(scrollH, 44), 200);
      textareaRef.current.style.height = `${targetH}px`;
    }
  }, [questionInput]);

  // Persistent Chat & Scan History Box State
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [savedScanSessions, setSavedScanSessions] = useState<{ id: string; title: string; date: string; messages: ScanChatMessage[] }[]>(() => {
    try {
      const saved = localStorage.getItem('edumind_scan_chat_history');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Voice Interaction (Speech-to-Text & Text-to-Speech)
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [activeSpeechText, setActiveSpeechText] = useState<string>('');

  // Interactive MCQ / Flashcard viewer states
  const [selectedMCQAnswers, setSelectedMCQAnswers] = useState<Record<number, number>>({});
  const [activeFlashcardIndex, setActiveFlashcardIndex] = useState<number>(0);
  const [isFlashcardFlipped, setIsFlashcardFlipped] = useState<boolean>(false);
  const [isProcessingImages, setIsProcessingImages] = useState<boolean>(false);

  // File Input Ref
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Ultra-Fast Client-Side Image Compression for Instant Upload & 10x Faster AI Processing
  const compressImageFile = async (file: File | Blob): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const MAX_DIM = 1024; // Compact dimension for instant upload & blazing fast AI processing
          let w = img.width;
          let h = img.height;

          if (w > MAX_DIM || h > MAX_DIM) {
            if (w > h) {
              h = Math.round((h * MAX_DIM) / w);
              w = MAX_DIM;
            } else {
              w = Math.round((w * MAX_DIM) / h);
              h = MAX_DIM;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, w, h);
            ctx.drawImage(img, 0, 0, w, h);
            resolve(canvas.toDataURL('image/jpeg', 0.75));
          } else {
            resolve((e.target?.result as string) || '');
          }
        };
        img.onerror = () => {
          resolve((e.target?.result as string) || '');
        };
        img.src = (e.target?.result as string) || '';
      };
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  };

  // Translations
  const isBn = language === 'bn';
  const isHi = language === 'hi';

  const t = {
    badge: isBn ? 'এআই স্টাডি স্ক্যানার' : isHi ? 'एआई स्टडी स्कैनर' : 'AI STUDY SCANNER',
    heroTitle: isBn ? 'বইয়ের যেকোনো পাতাকে বানান আপনার AI টিউটর' : isHi ? 'किसी भी पेज को बनाएं अपना AI ट्यूटर' : 'Turn Any Page Into Your AI Tutor',
    heroSubtitle: isBn ? 'আপনার বই, খাতা বা নোটের ছবি স্ক্যান করুন এবং এআই-কে যেকোনো প্রশ্ন করুন।' : isHi ? 'अपनी किताब या नोट्स स्कैन करें और AI से कुछ भी पूछें।' : 'Scan your book, notes or study material and ask AI anything about it.',
    addCardTitle: isBn ? 'পড়ার মেটেরিয়াল যোগ করুন' : isHi ? 'अध्ययन सामग्री जोड़ें' : 'Add Study Material',
    chooseGallery: isBn ? 'গ্যালারি থেকে বেছে নিন' : isHi ? 'गैलरी से चुनें' : 'Choose from Gallery',
    chooseGallerySub: isBn ? 'এক বা একাধিক ছবি সিলেক্ট করুন' : isHi ? 'एक या एकाधिक फोटो चुनें' : 'Select one or multiple photos',
    openCamera: isBn ? 'ক্যামেরা খুলুন' : isHi ? 'कैमरा खोलें' : 'Open Camera',
    openCameraSub: isBn ? 'এক বা একাধিক পাতা তুলুন' : isHi ? 'एक या कई पेज कैप्चर करें' : 'Capture one or multiple pages',
    emptyTitle: isBn ? 'পড়ার মেটেরিয়াল দিয়ে শুরু করুন' : isHi ? 'अध्ययन सामग्री से शुरुआत करें' : 'Start With Your Study Material',
    emptySub: isBn ? 'আপনার পাঠ্যবই বা নোটের ছবি তুলুন অথবা গ্যালারি থেকে পেজ আপলোড করুন।' : isHi ? 'अपनी किताब की फोटो लें या गैलरी से पेज अपलोड करें।' : 'Take a photo of your book or choose pages from your gallery.',
    trySample: isBn ? 'ইতিহাস, ভূগোল, বিজ্ঞান বা গণিত বই দিয়ে ট্রাই করুন:' : isHi ? 'इतिहास, भूगोल, विज्ञान या गणित की किताब से आज़माएं:' : 'Try it with your History, Geography, Science or Math book:',
    readyBadge: isBn ? 'পড়ার মেটেরিয়াল প্রস্তুত' : isHi ? 'अध्ययन सामग्री तैयार' : 'Study Material Ready',
    pagesAdded: (count: number) => isBn ? `${count}টি পাতা যুক্ত হয়েছে` : isHi ? `${count} पेज जोड़े गए` : `${count} Page${count > 1 ? 's' : ''} Added`,
    addMore: isBn ? '+ আরও পাতা যোগ করুন' : isHi ? '+ और पेज जोड़ें' : '+ Add More',
    scanAndUnderstand: isBn ? 'স্ক্যান ও সম্পূর্ণ পাঠ বুঝুন' : isHi ? 'स्कैन करें और समझें' : 'Scan & Understand',
    askTitle: isBn ? 'AI-কে যেকোনো প্রশ্ন করুন' : isHi ? 'AI से कुछ भी पूछें' : 'Ask AI Anything',
    askSub: isBn ? 'আপলোড করা মেটেরিয়াল সম্পর্কে যেকোনো প্রশ্ন জিজ্ঞাসা করুন।' : isHi ? 'इस सामग्री के बारे में कोई भी प्रश्न पूछें।' : 'Ask questions about this study material.',
    inputPlaceholder: isBn ? 'এই পাতাগুলো নিয়ে যেকোনো প্রশ্ন লিখুন বা বলুন...' : isHi ? 'इन पेजों के बारे में कुछ भी पूछें या बोलें...' : 'Ask anything about these pages...',
    suggestTitle: isBn ? 'সহজ প্রশ্ন আইডিয়া:' : isHi ? 'सुझाव प्रश्न:' : 'Quick Prompt Ideas:',
    suggest1: isBn ? 'এই বিষয়টি সহজ ভাষায় বুঝিয়ে দাও' : isHi ? 'इस विषय को आसान भाषा में समझाएं' : 'Explain this topic in simple language',
    suggest2: isBn ? 'গুরুত্বপূর্ণ পয়েন্টগুলো কী কী?' : isHi ? 'मुख्य बिंदु क्या हैं?' : 'What are the important points?',
    suggest3: isBn ? 'এখানে কারা প্রধান ব্যক্তিত্ব ছিলেন?' : isHi ? 'इसमें मुख्य व्यक्ति कौन थे?' : 'Who were the important people?',
    suggest4: isBn ? 'এই ঘটনাটি কেন ঘটেছিল?' : isHi ? 'यह घटना क्यों हुई?' : 'Why did this event happen?',
    suggest5: isBn ? 'এই অধ্যায় থেকে পরীক্ষার MCQ তৈরি করো' : isHi ? 'इस अध्याय से परीक्षा के MCQ बनाएं' : 'Create MCQs from this chapter',
    suggest6: isBn ? 'আমার পরীক্ষার জন্য গুরুত্বপূর্ণ বিষয়গুলো বলো' : isHi ? 'मेरी परीक्षा के लिए खास बातें बताएं' : 'Explain this for my exam',
    bookSource: isBn ? '📖 আপনার বই থেকে প্রাপ্ত তথ্য' : isHi ? '📖 आपकी किताब से' : '📖 From Your Book',
    aiSource: isBn ? '🧠 AI শিক্ষকের অতিরিক্ত বিশ্লেষণ ও ব্যাকগ্রাউন্ড' : isHi ? '🧠 AI शिक्षक का अतिरिक्त संदर्भ' : '🧠 AI Teacher Context',
    btnMCQs: isBn ? '📝 MCQ তৈরি করো' : isHi ? '📝 MCQ बनाएं' : 'Make MCQs',
    btnFlashcards: isBn ? '🗂️ ফ্ল্যাশকার্ড বানাও' : isHi ? '🗂️ फ्लैशकार्ड बनाएं' : 'Make Flashcards',
    btnRevision: isBn ? '⚡ ১-মিনিট কুইক রিভিশন' : isHi ? '⚡ 1-मिनट त्वरित रिवीज़न' : 'Quick Revision',
    btnSimpler: isBn ? '💡 আরও সহজভাবে বোঝাও' : isHi ? '💡 और आसान समझाएं' : 'Explain Simpler',
    btnReadAloud: isBn ? '🔊 পড়ে শোনাও' : isHi ? '🔊 बोलकर सुनाएं' : 'Read Aloud',
    btnPause: isBn ? '⏸ থামাও' : isHi ? '⏸ रोकें' : 'Pause',
    cameraTitle: isBn ? 'ফুল-স্ক্রিন এআই স্টাডি ক্যামেরা' : isHi ? 'फुल-स्क्रीन एआई स्टडी कैमरा' : 'Full-Screen AI Study Camera',
    cameraGuide: isBn ? 'বইয়ের পাতা সোজাভাবে ফ্রেমের মাঝে রাখুন' : isHi ? 'किताब का पेज सीधे फ्रेम में रखें' : 'Hold book page straight inside frame',
    capturedPages: (c: number) => isBn ? `${c}টি পাতা ক্যাপচার হয়েছে` : isHi ? `${c} पेज कैप्चर किए गए` : `${c} page${c > 1 ? 's' : ''} captured`,
    doneBtn: isBn ? 'সম্পন্ন (Done)' : isHi ? 'पूर्ण (Done)' : 'Done',
    retake: isBn ? 'রিমুভ' : isHi ? 'हटाएं' : 'Remove',
    clearAll: isBn ? 'সব মুছুন' : isHi ? 'सब हटाएं' : 'Clear All',
    analyzing: isBn ? 'AI আপনার বইয়ের পাতাগুলো গভীরভাবে বিশ্লেষণ করছে...' : isHi ? 'AI आपकी किताब के पेजों का गहन विश्लेषण कर रहा है...' : 'AI is reading & understanding your pages in depth...',
    analyzingPages: isBn ? 'AI আপনার বইয়ের পাতাগুলো স্ক্যান ও গভীরভাবে বিশ্লেষণ করছে...' : isHi ? 'AI आपकी किताब के पेजों को स्कैन और विश्लेषण कर रहा है...' : 'AI is scanning & reading your book pages in depth...',
    analyzingPagesSub: isBn ? 'বইয়ের প্রতিটা পয়েন্ট, সাল ও জটিল বিষয়ের নিখুঁত বিবরণ তৈরি হচ্ছে...' : isHi ? 'किताब के मुख्य बिंदु, तारीखें और स्टेप-बाय-स्टेप कॉन्सेप्ट तैयार हो रहे हैं...' : 'Synthesizing key points, textbook dates & step-by-step concepts...',
    answeringText: isBn ? 'StudySkill AI আপনার প্রশ্নের বিস্তারিত উত্তর তৈরি করছে...' : isHi ? 'StudySkill AI आपके प्रश्न का विस्तृत उत्तर तैयार कर रहा है...' : 'StudySkill AI is preparing your detailed answer...',
    answeringTextSub: isBn ? 'সহজ ব্যাখ্যা, মূল ধারণা ও পরীক্ষার জরুরি পয়েন্ট প্রস্তুত হচ্ছে...' : isHi ? 'सरल व्याख्या, मुख्य अवधारणाएं और परीक्षा के टिप्स तैयार हो रहे हैं...' : 'Generating clear explanation, key concepts & exam tips...'
  };

  // Quick modular prompt units (ছোট এবং ইউনিট ফরম্যাটে)
  interface PromptUnit {
    icon: string;
    label: string;
    prompt: string;
  }

  const promptUnits: PromptUnit[] = [
    {
      icon: '📝',
      label: isBn ? 'MCQ টেস্ট' : isHi ? 'MCQ टेस्ट' : 'MCQs',
      prompt: isBn ? 'এই অধ্যায় থেকে ৫টি গুরুত্বপূর্ণ MCQ টেস্ট তৈরি করো' : 'Create 5 high-yield MCQs for this topic'
    },
    {
      icon: '⚡',
      label: isBn ? 'কুইক রিভিশন' : isHi ? 'रिवीज़न' : 'Revision',
      prompt: isBn ? 'পরীক্ষার ১-মিনিট দ্রুত রিভিশন পয়েন্ট দিন' : 'Give 1-minute quick revision points'
    },
    {
      icon: '🔍',
      label: isBn ? 'মূল তথ্য' : isHi ? 'मुख्य तथ्य' : 'Key Facts',
      prompt: isBn ? 'মূল সূত্র, সাল ও জরুরি তথ্যসমূহ বের করো' : 'Key formulas, dates & important facts'
    },
    {
      icon: '💡',
      label: isBn ? 'সহজ ব্যাখ্যা' : isHi ? 'सरल व्याख्या' : 'Simple Explain',
      prompt: isBn ? 'বাস্তব জীবনের উদাহরণসহ সহজ ভাষায় বুঝিয়ে দাও' : 'Explain in simple terms with real-life examples'
    },
    {
      icon: '📌',
      label: isBn ? 'কমন প্রশ্ন' : isHi ? 'महत्वपूर्ण प्रश्न' : 'Exam FAQs',
      prompt: isBn ? 'পরীক্ষার সম্ভাব্য কমন প্রশ্ন ও উত্তর দাও' : 'Probable exam questions & answers'
    },
    {
      icon: '🃏',
      label: isBn ? 'ফ্ল্যাশকার্ড' : isHi ? 'फ़्लैशकार्ड' : 'Flashcards',
      prompt: isBn ? 'এই বিষয়ের ওপর মেমোরি ফ্ল্যাশকার্ড তৈরি করো' : 'Make flashcards for this topic'
    }
  ];

  // Stop camera & speech on unmount
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
      window.speechSynthesis?.cancel();
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
    };
  }, [cameraStream]);

  // Scroll to bottom of chat when new message arrives
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isLoading]);

  // Handle Gallery Selection (Multi-Image Fast Compressed Upload with 5 Max limit)
  const handleGallerySelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const availableSlots = MAX_PAGES_PER_SCAN - attachedPages.length;
    if (availableSlots <= 0) {
      setScanError(isBn ? 'একটি স্ক্যানে সর্বোচ্চ ৫টি ছবি/পাতা যোগ করা যাবে।' : 'Maximum 5 images allowed per scan request.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsProcessingImages(true);
    setScanError('');

    try {
      const fileList = Array.from(files) as File[];
      const compressPromises = fileList.map((f: File) => compressImageFile(f));
      const compressedList = await Promise.all(compressPromises);
      let validImages = compressedList.filter(img => Boolean(img && img.length > 50));

      if (validImages.length > availableSlots) {
        validImages = validImages.slice(0, availableSlots);
        setScanError(isBn ? 'একটি স্ক্যানে সর্বোচ্চ ৫টি পাতা যোগ করা যাবে (প্রথম ৫টি সিলেক্ট করা হয়েছে)।' : 'Max 5 pages allowed per scan request. First 5 selected.');
      }

      if (validImages.length > 0) {
        const updated = [...attachedPages, ...validImages];
        setAttachedPages(updated);

        // If user already typed a question in input, trigger search right away
        if (questionInput.trim()) {
          handleAskAITutor({
            customQuestion: questionInput.trim(),
            imagesOverride: updated
          });
        }
      }
    } catch (err: any) {
      console.error('Error processing gallery files:', err);
      setScanError(isBn ? 'ছবি লোড করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' : 'Failed to process images. Please try again.');
    } finally {
      setIsProcessingImages(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Camera Management (Full-Screen Camera Mode)
  const openCameraExperience = async (overrideFacing?: 'user' | 'environment') => {
    const mode = overrideFacing || facingMode;
    try {
      setIsCameraActive(true);
      setCapturedInSession([]);
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: mode, 
          width: { ideal: 1920 }, 
          height: { ideal: 1080 } 
        }
      });
      setCameraStream(stream);
      setTimeout(() => {
        const video = document.getElementById('camera-stream-video') as HTMLVideoElement;
        if (video) video.srcObject = stream;
      }, 100);
    } catch (err: any) {
      console.error('Camera open error:', err);
      setIsCameraActive(false);
      setScanError(
        isBn 
          ? 'ক্যামেরা চালু করতে সমস্যা হয়েছে। অনুগ্রহ করে ব্রাউজারে ক্যামেরার অনুমতি দিন।' 
          : 'Failed to access camera. Please allow camera permissions.'
      );
    }
  };

  const closeCameraExperience = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsCameraActive(false);
  };

  const toggleCameraFacing = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    openCameraExperience(nextMode);
  };

  const toggleFlash = async () => {
    if (!cameraStream) return;
    const tracks = cameraStream.getVideoTracks();
    if (!tracks || tracks.length === 0) return;
    const track = tracks[0];
    if (track) {
      try {
        const capabilities: any = track.getCapabilities?.() || {};
        if (capabilities.torch) {
          const nextFlash = !isFlashOn;
          await track.applyConstraints({
            advanced: [{ torch: nextFlash } as any]
          });
          setIsFlashOn(nextFlash);
        } else {
          setIsFlashOn(prev => !prev);
        }
      } catch (e) {
        setIsFlashOn(prev => !prev);
      }
    }
  };

  // Continuous Page Capture (Auto-Optimized Size & Fast Compression with max 5 pages check)
  const handleCaptureShutter = () => {
    const video = document.getElementById('camera-stream-video') as HTMLVideoElement;
    if (!video) return;

    if (attachedPages.length + capturedInSession.length >= MAX_PAGES_PER_SCAN) {
      setScanError(isBn ? 'একটি স্ক্যানে সর্বোচ্চ ৫টি পাতা যোগ করা যাবে।' : 'Maximum 5 pages allowed per scan request.');
      return;
    }

    // Trigger visual shutter flash
    setCameraShutterFlash(true);
    setTimeout(() => setCameraShutterFlash(false), 200);

    const canvas = document.createElement('canvas');
    const MAX_DIM = 1024;
    let w = video.videoWidth || 1024;
    let h = video.videoHeight || 720;
    if (w > MAX_DIM || h > MAX_DIM) {
      if (w > h) {
        h = Math.round((h * MAX_DIM) / w);
        w = MAX_DIM;
      } else {
        w = Math.round((w * MAX_DIM) / h);
        h = MAX_DIM;
      }
    }
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(video, 0, 0, w, h);
      const base64 = canvas.toDataURL('image/jpeg', 0.75);
      setCapturedInSession(prev => [...prev, base64]);
    }
  };

  const handleFinishCameraSession = () => {
    if (capturedInSession.length > 0) {
      const available = MAX_PAGES_PER_SCAN - attachedPages.length;
      const toAdd = capturedInSession.slice(0, available);
      setAttachedPages(prev => [...prev, ...toAdd]);
      setScanError('');
    }
    closeCameraExperience();
  };

  // Reorder & Remove Pages
  const handleRemovePage = (index: number) => {
    setAttachedPages(prev => prev.filter((_, i) => i !== index));
  };

  const handleMovePage = (index: number, direction: 'left' | 'right') => {
    if (direction === 'left' && index === 0) return;
    if (direction === 'right' && index === attachedPages.length - 1) return;
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    setAttachedPages(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
  };

  // Load a quick sample
  const handleLoadSample = (sample: typeof SAMPLE_SCANS[0]) => {
    setAttachedPages([sample.image]);
    setScanError('');
    handleAskAITutor({
      customQuestion: isBn 
        ? `${sample.title} সম্পর্কে সম্পূর্ণ ও বিস্তারিত বুঝিয়ে দাও।` 
        : `Tell me everything about ${sample.title} in detail.`,
      imagesOverride: [sample.image]
    });
  };

  // Activate EduMind Pro (৳99 / ₹99 per month for unlimited scans)
  const handleActivatePro = () => {
    setIsPro(true);
    try {
      localStorage.setItem('edumind_is_pro', 'true');
      localStorage.setItem('edumind_pro_expiry', new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString());
    } catch (e) {}
    if (setUserProfile) {
      setUserProfile(prev => ({
        ...prev,
        isPro: true,
        proPlan: 'monthly',
        proExpiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      }));
    }
    setShowProModal(false);
    setRewardToast(
      isBn 
        ? '👑 অভিনন্দন! StudySkill Pro সফলভাবে সক্রিয় করা হয়েছে। এখন আনলিমিটেড স্ক্যান ও ১০০% অ্যাড-ফ্রি পড়াশোনা উপভোগ করুন!'
        : '👑 Congratulations! StudySkill Pro activated successfully. Enjoy unlimited scans and ad-free learning!'
    );
    setTimeout(() => setRewardToast(''), 5000);
  };

  // Watch Rewarded Sponsored Ad to unlock +1 Bonus Scan
  const handleStartWatchAd = () => {
    setShowAdModal(true);
    setIsWatchingAd(true);
    setAdWatchCountdown(5);
    const interval = setInterval(() => {
      setAdWatchCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsWatchingAd(false);
          // Award +1 bonus scan as requested
          const nextBonus = bonusScans + 1;
          setBonusScans(nextBonus);
          try {
            localStorage.setItem('edumind_bonus_scans', nextBonus.toString());
          } catch (e) {}
          setShowAdModal(false);
          setRewardToast(
            isBn 
              ? '🎉 দারুণ! বিজ্ঞাপন দেখার জন্য আপনার অ্যাকাউন্টে ১টি অতিরিক্ত স্ক্যান যুক্ত হয়েছে!'
              : '🎉 Awesome! +1 Bonus Scan added to your account for watching the ad!'
          );
          setTimeout(() => setRewardToast(''), 4000);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Core AI Ask Functionality (Supports Unlimited Text Questions + 3 Daily Image Scans / Rewarded Ads / Pro Unlimited)
  const handleAskAITutor = async ({
    customQuestion,
    action = 'ask',
    imagesOverride
  }: {
    customQuestion?: string;
    action?: string;
    imagesOverride?: string[];
  }) => {
    const rawImagesToUse = imagesOverride || attachedPages;
    // Enforce max 5 images per request
    const imagesToUse = rawImagesToUse.slice(0, MAX_PAGES_PER_SCAN);
    const qText = (customQuestion !== undefined ? customQuestion : questionInput).trim();

    const isImageScan = imagesToUse.length > 0;
    const totalAllowedScans = DAILY_FREE_SCANS + bonusScans;

    // Check Daily Scan limit ONLY for Image Scans if user is NOT Pro (Text questions are always 100% UNLIMITED)
    if (isImageScan && !isPro && dailyScanCount >= totalAllowedScans) {
      setScanError(
        isBn 
          ? `আজকের ৩টি ফ্রি AI স্ক্যান শেষ হয়েছে (${dailyScanCount}/${totalAllowedScans})। একটি ছোট বিজ্ঞাপন দেখে আরও ১টি স্ক্যান আনলক করুন অথবা StudySkill Pro (৳৯৯/মাস) নিন!`
          : isHi 
          ? `आज का 3 फ्री स्कैन कोटा पूरा हो गया है। एक छोटा विज्ञापन देखकर +1 स्कैन अनलॉक करें या StudySkill Pro लें!`
          : `Daily 3 free scans used (${dailyScanCount}/${totalAllowedScans}). Watch a short ad to unlock +1 scan or upgrade to StudySkill Pro!`
      );
      setShowAdModal(true);
      return;
    }

    // Check if user has provided at least an image OR a question
    if (imagesToUse.length === 0 && !qText && action === 'ask') {
      setScanError(
        isBn 
          ? 'অনুগ্রহ করে কোনো প্রশ্ন লিখুন অথবা ক্যামেরা বা গ্যালারি থেকে পড়ার পাতার ছবি দিন।' 
          : isHi 
          ? 'कृपया कोई प्रश्न लिखें या कैमरा/गैलरी से पेज की फोटो जोड़ें।' 
          : 'Please enter a question or add a study page from camera/gallery.'
      );
      return;
    }

    setScanError('');
    setIsLoading(true);
    setLoadingHasImages(isImageScan);
    window.speechSynthesis?.cancel();
    setIsPlayingAudio(false);

    let effectiveAction = action;
    if (effectiveAction === 'ask' && qText) {
      const lower = qText.toLowerCase();
      if (lower.includes('mcq') || lower.includes('কুইজ') || lower.includes('প্রশ্নোত্তর') || lower.includes('quiz') || lower.includes('টেস্ট')) {
        effectiveAction = 'make_mcqs';
      } else if (lower.includes('ফ্ল্যাশ') || lower.includes('flashcard')) {
        effectiveAction = 'make_flashcards';
      } else if (lower.includes('রিভিশন') || lower.includes('revision') || lower.includes('এক মিনিট')) {
        effectiveAction = 'quick_revision';
      } else if (lower.includes('সহজ') || lower.includes('সহজভাবে') || lower.includes('simpler')) {
        effectiveAction = 'explain_simpler';
      }
    }

    // Append user message to chat UI immediately
    const userMsgId = 'usr_' + Date.now();
    const userMsg: ScanChatMessage = {
      id: userMsgId,
      role: 'user',
      query: qText || (effectiveAction === 'make_mcqs' ? (isBn ? '📝 ৫টি গুরুত্বপূর্ণ MCQ তৈরি করুন' : 'Generate 5 MCQs') : effectiveAction === 'make_flashcards' ? (isBn ? '🃏 ফ্ল্যাশকার্ড তৈরি করুন' : 'Generate Flashcards') : (isBn ? '📖 পড়ার পাতা বিশ্লেষণ ও বিশদ ব্যাখ্যা' : 'Analyze Study Material')),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setQuestionInput('');
    
    // Clear attached pages after scan dispatch so follow-up chat is pure high-speed text
    if (imagesToUse.length > 0) {
      setAttachedPages([]);
    }

    setTimeout(() => {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 50);

    try {
      // Build lightweight history context (last 3 messages for instant speed)
      const historyContext = chatMessages.slice(-3).map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        text: m.role === 'user' ? (m.query || '').slice(0, 150) : (m.data?.summary || '').slice(0, 150)
      }));

      const res = await fetch('/api/gemini/scan-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          images: imagesToUse,
          question: qText,
          chatHistory: historyContext,
          language,
          action: effectiveAction
        })
      });

      const contentType = res.headers.get('content-type') || '';
      let rawResponseData: any = null;

      if (contentType.includes('application/json')) {
        try {
          rawResponseData = await res.json();
        } catch (jsonErr) {
          rawResponseData = null;
        }
      } else {
        const textResp = await res.text();
        if (textResp && !textResp.includes('<!DOCTYPE') && !textResp.includes('<html')) {
          rawResponseData = { error: textResp.slice(0, 300) };
        }
      }

      if (!res.ok) {
        const errMsg = rawResponseData?.error || (
          isBn 
            ? 'পড়ার পাতা বিশ্লেষণ করতে সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' 
            : 'Failed to analyze study material. Please try again.'
        );
        throw new Error(errMsg);
      }

      if (!rawResponseData || typeof rawResponseData !== 'object') {
        throw new Error(
          isBn 
            ? 'সার্ভার থেকে সঠিক তথ্য পাওয়া যায়নি। অনুগ্রহ করে পুনরায় চেষ্টা করুন।' 
            : 'Invalid response format from server. Please try again.'
        );
      }

      // Clean and deduplicate sections to prevent any repetition
      const sanitizedSections: ScanSection[] = [];
      const seenSecKeys = new Set<string>();
      if (Array.isArray(rawResponseData?.sections)) {
        for (const sec of rawResponseData.sections) {
          if (!sec || typeof sec !== 'object') continue;
          const tKey = ((sec.title || '') + '|||' + (sec.content || '')).trim().toLowerCase();
          if (seenSecKeys.has(tKey)) continue;
          seenSecKeys.add(tKey);
          sanitizedSections.push({
            number: sanitizedSections.length + 1,
            title: sec.title || `পয়েন্ট ${sanitizedSections.length + 1}`,
            content: sec.content || '',
            badge: sec.badge || undefined
          });
          if (sanitizedSections.length >= 4) break;
        }
      }

      const data: ScanTutorResponse = {
        ...rawResponseData,
        sections: sanitizedSections
      };
      setCurrentResponse(data);
      setSelectedMCQAnswers({});
      setActiveFlashcardIndex(0);
      setIsFlashcardFlipped(false);

      const aiMsg: ScanChatMessage = {
        id: 'ai_' + Date.now(),
        role: 'assistant',
        data,
        actionUsed: action,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setChatMessages(prev => {
        const updated = [...prev, aiMsg];
        try {
          // Auto-save/update latest session in history
          const sessionTitle = data.topicTitle || userMsg.query || 'Study Session';
          const existingSessionId = (window as any).__current_scan_session_id || ('session_' + Date.now());
          (window as any).__current_scan_session_id = existingSessionId;
          
          setSavedScanSessions(oldSessions => {
            const idx = oldSessions.findIndex(s => s.id === existingSessionId);
            let nextSessions;
            if (idx >= 0) {
              nextSessions = [...oldSessions];
              nextSessions[idx] = { ...nextSessions[idx], title: sessionTitle, messages: updated };
            } else {
              nextSessions = [{
                id: existingSessionId,
                title: sessionTitle,
                date: new Date().toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
                messages: updated
              }, ...oldSessions.slice(0, 19)]; // Keep latest 20
            }
            try {
              localStorage.setItem('edumind_scan_chat_history', JSON.stringify(nextSessions));
            } catch (e) {}
            return nextSessions;
          });
        } catch (e) {}
        return updated;
      });
      onIncrementScan();

      // Only deduct/increment daily scan count if images were scanned and user is not Pro
      if (isImageScan && !isPro) {
        const nextDaily = dailyScanCount + 1;
        setDailyScanCount(nextDaily);
        try {
          localStorage.setItem('edumind_scan_day_key', currentDayKey);
          localStorage.setItem('edumind_daily_scans_count', nextDaily.toString());
        } catch (e) {}
      }
    } catch (err: any) {
      console.error('Scan error:', err);
      setScanError(err.message || 'An error occurred during AI tutor processing.');
    } finally {
      setIsLoading(false);
    }
  };

  // Voice Input (Speech-to-Text)
  const toggleVoiceInput = () => {
    if (isListening) {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setScanError(
        isBn 
          ? 'আপনার ব্রাউজারে সরাসরি ভয়েস ইনপুট সমর্থিত নয়।' 
          : 'Voice input is not supported on this browser.'
      );
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = isBn ? 'bn-IN' : isHi ? 'hi-IN' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event: any) => {
        const transcript = event?.results?.[0]?.[0]?.transcript;
        if (transcript) {
          setQuestionInput(transcript);
          setIsListening(false);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      setIsListening(false);
    }
  };

  // Text-to-Speech Playback
  const handleToggleAudio = (textToRead: string) => {
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      setActiveSpeechText('');
    } else {
      window.speechSynthesis.cancel();
      const cleanText = textToRead.replace(/[*#_`~]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 3000));
      utterance.lang = isBn ? 'bn-IN' : isHi ? 'hi-IN' : 'en-US';
      utterance.rate = 1.0;
      utterance.onstart = () => {
        setIsPlayingAudio(true);
        setActiveSpeechText(textToRead);
      };
      utterance.onend = () => {
        setIsPlayingAudio(false);
        setActiveSpeechText('');
      };
      utterance.onerror = () => {
        setIsPlayingAudio(false);
        setActiveSpeechText('');
      };
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleStopAudio = () => {
    window.speechSynthesis.cancel();
    setIsPlayingAudio(false);
    setActiveSpeechText('');
  };

  // Find the most recent tutor response for persistent audio / controls
  const latestTutorData = currentResponse || [...chatMessages].reverse().find(m => m.data)?.data || null;

  return (
    <div className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-6 space-y-5 max-w-5xl mx-auto w-full pb-72 sm:pb-80 md:pb-64 text-slate-100 font-sans">
      
      {/* ------------------------------------------------------------- */}
      {/* 📸 1. FULL-SCREEN MOBILE CAMERA EXPERIENCE                     */}
      {/* ------------------------------------------------------------- */}
      {isCameraActive && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between p-3 sm:p-5 text-white animate-in fade-in duration-200">
          
          {/* Shutter Flash Animation Effect */}
          {cameraShutterFlash && (
            <div className="absolute inset-0 bg-white/70 z-40 pointer-events-none transition-opacity duration-150" />
          )}

          {/* TOP CONTROLS BAR */}
          <div className="flex items-center justify-between z-20 bg-slate-900/90 backdrop-blur-md px-3 sm:px-4 py-2.5 rounded-2xl border border-slate-800 shadow-2xl">
            <button
              onClick={closeCameraExperience}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Back</span>
            </button>

            {/* LIVE PAGE COUNTER */}
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs font-black rounded-full">
                {t.capturedPages(capturedInSession.length)}
              </span>
            </div>

            {/* FLASH & CAMERA FLIP BUTTONS */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={toggleFlash}
                className={`p-2 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
                  isFlashOn 
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-lg shadow-amber-500/20' 
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
                title="Toggle Flash"
              >
                <Zap className="w-4 h-4" />
              </button>

              <button
                onClick={toggleCameraFacing}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded-xl text-xs font-bold cursor-pointer border border-slate-700 transition-colors"
                title="Switch Camera"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* LIVE CAMERA VIEWPORT & DOCUMENT RETICLE */}
          <div className="relative flex-1 my-2.5 sm:my-3 flex items-center justify-center overflow-hidden rounded-3xl bg-black border border-slate-800 shadow-2xl">
            <video
              id="camera-stream-video"
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />

            {/* DOCUMENT FRAMING RETICLE & AUTO-ALIGN GUIDE */}
            <div className="absolute inset-4 sm:inset-8 border-2 border-indigo-400/80 rounded-3xl pointer-events-none flex flex-col justify-between p-3.5 shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]">
              <div className="flex justify-between">
                <div className="w-8 h-8 sm:w-10 sm:h-10 border-t-4 border-l-4 border-indigo-400 rounded-tl-xl shadow-sm" />
                <div className="w-8 h-8 sm:w-10 sm:h-10 border-t-4 border-r-4 border-indigo-400 rounded-tr-xl shadow-sm" />
              </div>

              <div className="text-center text-[11px] sm:text-xs font-black text-indigo-100 bg-slate-900/90 backdrop-blur-md px-3.5 py-1.5 rounded-full mx-auto self-center border border-indigo-500/40 shadow-lg flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                <span>{t.cameraGuide}</span>
              </div>

              <div className="flex justify-between">
                <div className="w-8 h-8 sm:w-10 sm:h-10 border-b-4 border-l-4 border-indigo-400 rounded-bl-xl shadow-sm" />
                <div className="w-8 h-8 sm:w-10 sm:h-10 border-b-4 border-r-4 border-indigo-400 rounded-br-xl shadow-sm" />
              </div>
            </div>
          </div>

          {/* CONTINUOUS CAPTURES THUMBNAIL STRIP (If any pages captured) */}
          {capturedInSession.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto py-1 px-1 mb-2">
              {capturedInSession.map((img, idx) => (
                <div key={idx} className="relative shrink-0 w-12 h-14 rounded-lg overflow-hidden border border-indigo-400 shadow-md">
                  <img src={img} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[9px] font-black text-center text-indigo-200">
                    P{idx + 1}
                  </span>
                  <button
                    onClick={() => setCapturedInSession(prev => prev.filter((_, i) => i !== idx))}
                    className="absolute top-0.5 right-0.5 p-0.5 bg-rose-600 rounded-full text-white"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* BOTTOM CONTROLS & SHUTTER BUTTON */}
          <div className="flex items-center justify-between gap-3 z-20 px-2 py-1">
            
            {/* Gallery Shortcut */}
            <label className="p-3 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded-2xl cursor-pointer border border-slate-700 transition-colors flex items-center justify-center">
              <ImageIcon className="w-5 h-5" />
              <input 
                type="file" 
                multiple 
                accept="image/*" 
                className="hidden" 
                onChange={(e) => {
                  handleGallerySelect(e);
                  closeCameraExperience();
                }} 
              />
            </label>

            {/* LARGE SHUTTER BUTTON */}
            <div className="flex flex-col items-center gap-1">
              <button
                onClick={handleCaptureShutter}
                disabled={attachedPages.length + capturedInSession.length >= MAX_PAGES_PER_SCAN}
                className={`w-16 h-16 sm:w-18 sm:h-18 rounded-full p-1 shadow-2xl transition-transform flex items-center justify-center ring-4 ${
                  attachedPages.length + capturedInSession.length >= MAX_PAGES_PER_SCAN
                    ? 'bg-slate-700 opacity-60 cursor-not-allowed ring-slate-600'
                    : 'bg-gradient-to-tr from-indigo-600 via-purple-600 to-indigo-500 shadow-indigo-600/50 hover:scale-105 active:scale-95 cursor-pointer ring-indigo-500/30'
                }`}
                title={attachedPages.length + capturedInSession.length >= MAX_PAGES_PER_SCAN ? 'Max 5 pages reached' : 'Capture Page'}
              >
                <div className="w-full h-full rounded-full border-2 border-white/80 flex items-center justify-center bg-white/10">
                  <Camera className="w-7 h-7 text-white" />
                </div>
              </button>
              <span className="text-[10px] font-bold text-slate-300">
                {attachedPages.length + capturedInSession.length}/{MAX_PAGES_PER_SCAN} {isBn ? 'পাতা' : 'Pages'}
              </span>
            </div>

            {/* DONE BUTTON */}
            <button
              onClick={handleFinishCameraSession}
              disabled={capturedInSession.length === 0}
              className={`px-4 sm:px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-lg cursor-pointer ${
                capturedInSession.length > 0
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 active:scale-95'
                  : 'bg-slate-800 text-slate-500 border border-slate-700 opacity-60 cursor-not-allowed'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>{t.doneBtn}</span>
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 🔍 2. IMAGE ZOOM MODAL                                         */}
      {/* ------------------------------------------------------------- */}
      {previewZoomImage && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-4">
          <div className="relative max-w-2xl w-full max-h-[85vh] bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-3.5 border-b border-slate-800 bg-slate-900/90">
              <span className="text-xs font-black text-indigo-300">Page Preview</span>
              <button
                onClick={() => setPreviewZoomImage(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-2 flex items-center justify-center">
              <img src={previewZoomImage} alt="Zoom Preview" className="max-w-full max-h-[70vh] object-contain rounded-xl" />
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 🔔 FLOATING REWARD & PRO TOAST                                 */}
      {/* ------------------------------------------------------------- */}
      {rewardToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-emerald-600 via-indigo-600 to-purple-600 border border-emerald-300 text-white px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs sm:text-sm font-black animate-in fade-in slide-in-from-top-3 max-w-md w-[92%]">
          <Sparkles className="w-4 h-4 text-amber-300 animate-spin shrink-0" />
          <span>{rewardToast}</span>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 👑 EDU MIND PRO PAYMENT GATEWAY MODAL (৳৯৯ / ₹৯৯ প্রতি মাসে)  */}
      {/* ------------------------------------------------------------- */}
      {showProModal && (
        <EduMindProPaymentModal
          isOpen={showProModal}
          onClose={() => setShowProModal(false)}
          language={language}
          userProfile={userProfile}
          setUserProfile={setUserProfile}
          onPaymentSuccess={(sub) => {
            setIsPro(true);
            setShowProModal(false);
            setRewardToast(
              isBn
                ? '👑 অভিনন্দন! StudySkill Pro সফলভাবে সক্রিয় করা হয়েছে। আনলিমিটেড স্ক্যান উপভোগ করুন!'
                : '👑 Congratulations! StudySkill Pro activated successfully. Enjoy unlimited scans!'
            );
            setTimeout(() => setRewardToast(''), 5000);
          }}
        />
      )}

      {/* ------------------------------------------------------------- */}
      {/* 🎁 2.5 REWARDED AD / BONUS SCAN MODAL (3 Scans Limit -> +1)    */}
      {/* ------------------------------------------------------------- */}
      {showAdModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-4">
          <div className="relative max-w-lg w-full bg-slate-900 rounded-3xl overflow-hidden border border-indigo-500/40 shadow-2xl flex flex-col p-5 sm:p-6 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black rounded-md uppercase">
                  {isBn ? 'ফ্রি রিওয়ার্ডেড অ্যাড' : 'Rewarded Ad'}
                </span>
                <span className="text-sm font-bold text-white">
                  {isBn ? 'ফ্রি বোনাস AI স্ক্যান' : 'Free Bonus AI Scan'}
                </span>
              </div>
              {!isWatchingAd && (
                <button
                  onClick={() => setShowAdModal(false)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Sponsored Content Visual Box with Exact Requested Bengali Text */}
            <div className="relative rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/30 p-5 overflow-hidden text-center space-y-3">
              <div className="inline-flex p-3 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 mb-1">
                <Sparkles className="w-7 h-7 animate-pulse text-amber-400" />
              </div>
              <h4 className="text-base font-black text-white">
                {isBn ? 'একটি ছোট বিজ্ঞাপন দেখে আরও ১টি স্ক্যান আনলক করুন' : 'Watch a short ad to unlock +1 scan'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn 
                  ? 'আপনার আজকের ৩টি দৈনিক ফ্রি স্ক্যান শেষ হয়েছে। মাত্র ৫ সেকেন্ডের একটি বিজ্ঞাপন দেখে সাথে সাথে ১টি অতিরিক্ত স্ক্যান পেয়ে যান সম্পূর্ণ বিনামূল্যে।'
                  : 'Your daily 3 free scans have been used. Watch a 5-second sponsor ad to instantly unlock +1 bonus scan!'}
              </p>

              {isWatchingAd ? (
                <div className="py-2 space-y-2">
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-amber-400 via-orange-400 to-emerald-400 h-full transition-all duration-1000"
                      style={{ width: `${((5 - adWatchCountdown) / 5) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs font-black text-amber-300 animate-pulse">
                    {isBn ? `বিজ্ঞাপন চলছে... ${adWatchCountdown} সেকেন্ড বাকি (শেষ হলেই +১ স্ক্যান যোগ হবে)` : `Ad playing... ${adWatchCountdown}s remaining (+1 scan will be added)`}
                  </p>
                </div>
              ) : (
                <div className="pt-1">
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-500/30 inline-block">
                    {isBn ? '✓ বিজ্ঞাপন দেখা শেষ হলে সাথে সাথে +১ বোনাস স্ক্যান যুক্ত হবে!' : '✓ +1 bonus scan unlocked immediately after watching!'}
                  </span>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              {!isWatchingAd ? (
                <button
                  onClick={handleStartWatchAd}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-amber-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{isBn ? 'বিজ্ঞাপন দেখুন ও +১ স্ক্যান আনলক করুন (৫ সে)' : 'Watch 5s Ad for +1 Scan'}</span>
                </button>
              ) : null}

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowAdModal(false);
                    setShowProModal(true);
                  }}
                  className="flex-1 py-2.5 bg-indigo-950 hover:bg-indigo-900 border border-indigo-500/40 text-amber-300 font-bold text-xs rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isBn ? 'কিংবা আনলিমিটেড Pro নিন (৳৯৯/মাস)' : 'Or Get Pro (₹99/mo)'}</span>
                </button>

                <button
                  onClick={() => setShowAdModal(false)}
                  className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-2xl transition-all cursor-pointer"
                >
                  {isBn ? 'টেক্সট প্রশ্ন' : 'Text Free'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 🌟 3. COMPACT PERMANENT / STICKY HEADER & STATUS BAR          */}
      {/* ------------------------------------------------------------- */}
      <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-md border border-slate-800/90 rounded-2xl p-2.5 shadow-lg space-y-2">
        {/* Top Mini Strip: Ad / Sponsor & Quick Upgrade Buttons */}
        <div className="flex items-center justify-between gap-2 px-1">
          <div className="flex items-center gap-1.5 min-w-0">
            {isPro ? (
              <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 rounded-full flex items-center gap-1 shrink-0 font-mono shadow-xs">
                <Crown className="w-3 h-3 text-slate-950" />
                <span>StudySkill Pro</span>
              </span>
            ) : (
              <span className="text-[8px] font-black uppercase px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded border border-amber-500/30 shrink-0">
                {isBn ? 'ফ্রি প্ল্যান' : 'FREE'}
              </span>
            )}
            <span className="text-[11px] font-bold text-slate-300 truncate">
              {isPro 
                ? (isBn ? 'আনলিমিটেড স্ক্যান ও ১০০% বিজ্ঞাপন-মুক্ত' : 'Unlimited Scans & 100% Ad-Free')
                : (isBn ? 'দৈনিক ৩টি ফ্রি স্ক্যান • টেক্সট প্রশ্ন আনলিমিটেড' : '3 Daily Free Scans • Unlimited Text')}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {!isPro && (
              <>
                {/* Watch Ad for +1 Scan button */}
                <button
                  onClick={() => handleStartWatchAd()}
                  className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-[11px] font-bold rounded-lg flex items-center gap-1 transition-all cursor-pointer active:scale-95"
                  title={isBn ? 'একটি ছোট বিজ্ঞাপন দেখে আরও ১টি স্ক্যান আনলক করুন' : 'Watch ad for +1 scan'}
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>{isBn ? '+১ স্ক্যান (অ্যাড)' : '+1 Scan'}</span>
                </button>

                {/* Pro Upgrade Button */}
                <button
                  onClick={() => setShowProModal(true)}
                  className="px-2 py-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-[11px] font-black rounded-lg flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow-md shadow-amber-500/20"
                  title={isBn ? 'মাত্র ৳৯৯/মাসে StudySkill Pro নিন' : 'Upgrade to StudySkill Pro'}
                >
                  <Crown className="w-3 h-3 text-slate-950" />
                  <span>{isBn ? 'Pro (৳৯৯)' : 'Pro (₹99)'}</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Bottom Mini Strip: Status Badges, History & New Session */}
        <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1.5 border-t border-slate-800/80">
          <div className="flex items-center gap-1.5">
            {/* Image Scan Quota */}
            {isPro ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                <Crown className="w-3 h-3 text-amber-400" />
                <span>{isBn ? 'আনলিমিটেড স্ক্যান সক্রিয়' : 'Unlimited Pro Scans'}</span>
              </span>
            ) : (
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                dailyScanCount >= (DAILY_FREE_SCANS + bonusScans)
                  ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                  : 'bg-indigo-950/60 text-indigo-300 border-indigo-500/30'
              }`}>
                <Camera className="w-3 h-3 text-indigo-400" />
                <span>{isBn ? `আজকের স্ক্যান: ${dailyScanCount}/${DAILY_FREE_SCANS + bonusScans}` : `Today: ${dailyScanCount}/${DAILY_FREE_SCANS + bonusScans}`}</span>
              </span>
            )}

            {/* Free Unlimited Badge */}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>{isBn ? 'টেক্সট প্রশ্ন আনলিমিটেড' : 'Free Text'}</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Chat History Button */}
            <button
              onClick={() => setShowHistoryModal(true)}
              className="text-[11px] font-bold text-indigo-300 hover:text-indigo-200 bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-500/40 px-2.5 py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
            >
              <History className="w-3 h-3 text-indigo-400" />
              <span>{isBn ? `হিস্টোরি (${savedScanSessions.length})` : `History (${savedScanSessions.length})`}</span>
            </button>

            {/* New Session Button */}
            {(chatMessages.length > 0 || attachedPages.length > 0) && (
              <button
                onClick={() => {
                  delete (window as any).__current_scan_session_id;
                  setAttachedPages([]);
                  setCurrentResponse(null);
                  setChatMessages([]);
                  setScanError('');
                }}
                className="text-[11px] font-bold text-rose-400 hover:text-rose-300 bg-rose-950/60 hover:bg-rose-900 border border-rose-500/30 px-2.5 py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>{isBn ? 'নতুন সেশন' : 'New'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 📜 CHAT HISTORY MODAL / BOX                                    */}
      {/* ------------------------------------------------------------- */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {isBn ? 'চ্যাট ও স্ক্যান হিস্টোরি' : 'Chat & Scan History'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isBn ? 'পূর্বে স্ক্যান করা প্রশ্ন ও উত্তর ব্রাউজ করুন' : 'Browse your previous AI study tutor sessions'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Session List */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 scrollbar-thin">
              {savedScanSessions.length === 0 ? (
                <div className="py-12 text-center space-y-2">
                  <MessageSquare className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-xs font-bold text-slate-400">
                    {isBn ? 'এখনো কোনো হিস্টোরি সংরক্ষিত নেই।' : 'No study history saved yet.'}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {isBn ? 'বইয়ের পাতা স্ক্যান করলে বা প্রশ্ন জিজ্ঞাসা করলে এখানে স্বয়ংক্রিয়ভাবে জমা হবে।' : 'When you scan study materials or ask questions, sessions appear here.'}
                  </p>
                </div>
              ) : (
                savedScanSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-3 bg-slate-950/80 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/50 rounded-2xl transition-all flex items-center justify-between gap-3 group"
                  >
                    <div
                      onClick={() => {
                        (window as any).__current_scan_session_id = session.id;
                        setChatMessages(session.messages);
                        const lastAI = [...session.messages].reverse().find(m => m.data);
                        if (lastAI?.data) {
                          setCurrentResponse(lastAI.data);
                        }
                        setShowHistoryModal(false);
                      }}
                      className="flex-1 cursor-pointer min-w-0"
                    >
                      <h4 className="text-xs sm:text-sm font-bold text-slate-200 group-hover:text-indigo-300 truncate">
                        {session.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                        <span>📅 {session.date}</span>
                        <span>•</span>
                        <span>💬 {session.messages.length} {isBn ? 'বার্তা' : 'messages'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          (window as any).__current_scan_session_id = session.id;
                          setChatMessages(session.messages);
                          const lastAI = [...session.messages].reverse().find(m => m.data);
                          if (lastAI?.data) {
                            setCurrentResponse(lastAI.data);
                          }
                          setShowHistoryModal(false);
                        }}
                        className="px-2.5 py-1 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-bold rounded-lg border border-indigo-500/40 transition-all cursor-pointer"
                      >
                        {isBn ? 'খুলুন' : 'Open'}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          const updated = savedScanSessions.filter(s => s.id !== session.id);
                          setSavedScanSessions(updated);
                          try {
                            localStorage.setItem('edumind_scan_chat_history', JSON.stringify(updated));
                          } catch (err) {}
                        }}
                        className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-all"
                        title={isBn ? 'মুছে ফেলুন' : 'Delete'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer / Clear all history */}
            {savedScanSessions.length > 0 && (
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  {isBn ? `মোট ${savedScanSessions.length}টি সেশন সংরক্ষিত` : `Total ${savedScanSessions.length} sessions saved`}
                </span>
                <button
                  onClick={() => {
                    setSavedScanSessions([]);
                    try {
                      localStorage.removeItem('edumind_scan_chat_history');
                    } catch (e) {}
                  }}
                  className="text-xs text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                >
                  {isBn ? 'সব হিস্টোরি মুছুন' : 'Clear All History'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 📥 4. STUDY MATERIAL CANVAS & ATTACHED PAGES                  */}
      {/* ------------------------------------------------------------- */}
      {attachedPages.length > 0 && (
        <div className="bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-4 sm:p-5 shadow-xl backdrop-blur-md space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-black rounded-lg">
                ✓ {t.readyBadge}
              </span>
              <span className="text-xs font-bold text-slate-200">
                {t.pagesAdded(attachedPages.length)}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-indigo-300 font-bold border border-slate-700">
                {attachedPages.length}/{MAX_PAGES_PER_SCAN} {isBn ? 'সর্বোচ্চ ৫টি' : 'Max 5'}
              </span>
            </div>

            <div className="flex items-center gap-3">
              {attachedPages.length < MAX_PAGES_PER_SCAN ? (
                <label className="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer">
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t.addMore}</span>
                  <input 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleGallerySelect} 
                  />
                </label>
              ) : (
                <span className="text-[11px] font-bold text-amber-400">
                  {isBn ? '৫টি পাতা পূর্ণ হয়েছে' : 'Max 5 pages reached'}
                </span>
              )}

              <button
                onClick={() => {
                  setAttachedPages([]);
                  setCurrentResponse(null);
                }}
                className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-bold cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearAll}</span>
              </button>
            </div>
          </div>

          {/* THUMBNAILS ROW */}
          <div className="flex items-center gap-2.5 overflow-x-auto py-1 px-0.5 scrollbar-thin">
            {attachedPages.map((img, idx) => (
              <div 
                key={idx}
                className="relative shrink-0 w-20 sm:w-24 h-28 sm:h-32 rounded-xl overflow-hidden border border-indigo-500/40 bg-slate-950 shadow-md group"
              >
                <img 
                  src={img} 
                  alt={`Page ${idx + 1}`} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                />
                
                {/* Page Number Badge */}
                <span className="absolute top-1 left-1 bg-slate-900/90 text-indigo-300 border border-indigo-500/30 text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                  P{idx + 1}
                </span>

                {/* Zoom & Delete Controls */}
                <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-1">
                  <div className="flex justify-end">
                    <button
                      onClick={() => handleRemovePage(idx)}
                      className="p-1 bg-rose-600 hover:bg-rose-500 text-white rounded-md cursor-pointer"
                      title="Remove page"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    {idx > 0 && (
                      <button
                        onClick={() => handleMovePage(idx, 'left')}
                        className="p-0.5 bg-slate-800 text-slate-300 rounded text-[9px]"
                      >
                        ◀
                      </button>
                    )}
                    <button
                      onClick={() => setPreviewZoomImage(img)}
                      className="p-1 bg-indigo-600 text-white rounded-md mx-auto"
                      title="Zoom preview"
                    >
                      <Maximize2 className="w-3 h-3" />
                    </button>
                    {idx < attachedPages.length - 1 && (
                      <button
                        onClick={() => handleMovePage(idx, 'right')}
                        className="p-0.5 bg-slate-800 text-slate-300 rounded text-[9px]"
                      >
                        ▶
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* ADD MORE SQUARE */}
            <label className="shrink-0 w-20 sm:w-24 h-28 sm:h-32 rounded-xl border-2 border-dashed border-slate-700 hover:border-indigo-500 flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-indigo-300 cursor-pointer bg-slate-900/50 transition-colors">
              <Plus className="w-5 h-5" />
              <span className="text-[10px] font-black">{t.addMore}</span>
              <input 
                type="file" 
                multiple 
                accept="image/*" 
                className="hidden" 
                onChange={handleGallerySelect} 
              />
            </label>
          </div>

          {/* SCAN & UNDERSTAND BUTTON */}
          <div className="pt-1">
            <button
              onClick={() => handleAskAITutor({ 
                customQuestion: isBn 
                  ? 'এই পাতাগুলো সম্পূর্ণ বিশ্লেষণ করে মূল বিষয়টি সহজ ও বিস্তারিতভাবে বুঝিয়ে দাও।' 
                  : 'Analyze all pages and explain everything clearly in a structured educational format.' 
              })}
              disabled={isLoading}
              className="w-full py-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs sm:text-sm rounded-2xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98 disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.scanAndUnderstand}</span>
            </button>
          </div>
        </div>
      )}

      {/* IMAGE PROCESSING NOTICE */}
      {isProcessingImages && (
        <div className="p-3 bg-indigo-950/70 border border-indigo-500/50 rounded-2xl text-indigo-200 text-xs flex items-center gap-2 shadow-lg animate-pulse">
          <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin shrink-0" />
          <span>{isBn ? '⚡ ছবি প্রসেস ও দ্রুত আপলোডের জন্য অপ্টিমাইজ করা হচ্ছে...' : '⚡ Optimizing study pages for fast AI analysis...'}</span>
        </div>
      )}

      {/* ERROR NOTICE */}
      {scanError && (
        <div className="p-3.5 bg-rose-950/70 border border-rose-500/50 rounded-2xl text-rose-200 text-xs flex items-center gap-2 shadow-lg animate-in fade-in">
          <HelpCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{scanError}</span>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* ⏳ INITIAL FULL LOADING SPINNER (Only when no chat messages)  */}
      {/* ------------------------------------------------------------- */}
      {isLoading && chatMessages.length === 0 && (
        <div className="bg-slate-900/90 border border-indigo-500/40 rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-2xl backdrop-blur-md animate-pulse">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <div>
            <h4 className="text-sm font-black text-white">
              {loadingHasImages ? t.analyzingPages : t.answeringText}
            </h4>
            <p className="text-xs text-indigo-300 mt-1">
              {loadingHasImages ? t.analyzingPagesSub : t.answeringTextSub}
            </p>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 📚 7. CHAT CONVERSATION HISTORY & AI ANSWERS                   */}
      {/* ------------------------------------------------------------- */}
      {chatMessages.length > 0 && (
        <div className="space-y-6 pt-2">
          {chatMessages.map((msg) => {
            if (msg.role === 'user') {
              return (
                <div key={msg.id} className="flex justify-end">
                  <div className="max-w-[85%] sm:max-w-[75%] bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-3.5 rounded-2xl rounded-tr-xs shadow-lg space-y-1">
                    <p className="text-xs sm:text-sm font-semibold">{msg.query}</p>
                    <span className="text-[9px] text-indigo-200 block text-right font-mono">{msg.timestamp}</span>
                  </div>
                </div>
              );
            }

            const data = msg.data;
            if (!data) return null;

            return (
              <div key={msg.id} className="bg-slate-900/95 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-2xl space-y-6 backdrop-blur-md">
                
                {/* 1. HEADER: TOPIC & AUDIO CONTROLS (STICKY / স্থায়ী) */}
                <div className="sticky top-[72px] z-10 -mx-4 -mt-4 sm:-mx-6 sm:-mt-6 px-3.5 py-2.5 sm:px-5 sm:py-3 rounded-t-3xl bg-slate-950/95 backdrop-blur-md border-b border-slate-800/90 shadow-md flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="px-2 py-0.5 bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[10px] font-black rounded-md shrink-0">
                      {data.pageCount && data.pageCount > 0 
                        ? `${data.pageCount} ${isBn ? 'পাতা' : isHi ? 'पेज' : 'P'}`
                        : (isBn ? 'প্রশ্নোত্তর' : isHi ? 'प्रश्नोत्तर' : 'Q&A')}
                    </span>
                    <h3 className="text-xs sm:text-sm md:text-base font-black text-white font-display truncate">
                      {data.topicTitle}
                    </h3>
                  </div>

                  {/* Audio Read Aloud Button (থাই / স্থায়ী) */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleToggleAudio(`${data.topicTitle}. ${data.summary}. ${data.detailedExplanation}`)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all shadow-sm ${
                        isPlayingAudio && activeSpeechText.includes(data.topicTitle)
                          ? 'bg-rose-600 text-white shadow-rose-600/30 animate-pulse'
                          : 'bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 hover:text-white'
                      }`}
                      title={isBn ? 'সম্পূর্ণ উত্তরটি অডিওতে শুনুন' : 'Listen to this lesson'}
                    >
                      {isPlayingAudio && activeSpeechText.includes(data.topicTitle) ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5" />
                          <span>{t.btnPause}</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{t.btnReadAloud}</span>
                        </>
                      )}
                    </button>

                    {isPlayingAudio && activeSpeechText.includes(data.topicTitle) && (
                      <button
                        onClick={handleStopAudio}
                        className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700 transition-colors cursor-pointer"
                        title={isBn ? 'থামিয়ে দিন' : 'Stop Audio'}
                      >
                        <Square className="w-3 h-3 fill-current" />
                      </button>
                    )}
                  </div>
                </div>

                {/* 2. SUMMARY CARD */}
                {data.summary && (
                  <div className="p-4 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl space-y-1.5 shadow-inner">
                    <span className="text-[10px] font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Bookmark className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isBn ? 'সারসংক্ষেপ ও মূল নির্যাস' : 'Summary & Core Overview'}</span>
                    </span>
                    <p className="text-xs sm:text-sm text-slate-200 font-normal leading-relaxed">
                      {data.summary}
                    </p>
                  </div>
                )}

                {/* 3. KEY FACT CHIPS / BADGES (মূল হাইলাইটস ও তথ্যসমূহ) */}
                {data.keyFacts && data.keyFacts.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isBn ? 'মূল হাইলাইটস ও জরুরি তথ্যসমূহ (Key Facts & Highlights)' : 'Key Facts & Highlights'}</span>
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {data.keyFacts.map((fact, fIdx) => (
                        <div 
                          key={fIdx} 
                          className="p-3 bg-slate-950/90 border border-indigo-500/20 hover:border-indigo-500/40 rounded-xl space-y-1 shadow-sm transition-all"
                        >
                          <span className="text-[10px] font-extrabold text-indigo-400 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                            {fact.label}
                          </span>
                          <span className="text-xs font-bold text-white block leading-snug">
                            {fact.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4. STEP-BY-STEP DETAILED EDUCATIONAL BREAKDOWN */}
                {data.sections && data.sections.length > 0 && (
                  <div className="space-y-3">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isBn ? 'ধারাবাহিক বিশদ ব্যাখ্যা (Step-by-Step Lesson & Concepts)' : 'Step-by-Step Detailed Breakdown'}</span>
                    </span>

                    <div className="space-y-3">
                      {data.sections.filter((sec, idx, arr) => 
                        idx === arr.findIndex(s => (s.title + '|||' + s.content) === (sec.title + '|||' + sec.content))
                      ).slice(0, 4).map((sec, sIdx) => (
                        <div 
                          key={`sec_${sIdx}_${sec.number || sIdx}`}
                          className="p-4 bg-slate-950/80 border border-slate-800/90 rounded-2xl space-y-2.5 shadow-sm"
                        >
                          <div className="flex items-center justify-between gap-2 border-b border-slate-800/60 pb-2">
                            <h4 className="text-xs sm:text-sm font-black text-white flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-indigo-600/40 text-indigo-300 border border-indigo-500/40 text-[10px] font-black flex items-center justify-center shrink-0">
                                {sIdx + 1}
                              </span>
                              <span>{sec.title}</span>
                            </h4>
                            {sec.badge && (
                              <span className="px-2 py-0.5 bg-indigo-950/60 text-indigo-300 text-[10px] font-bold rounded-md border border-indigo-500/30 shrink-0">
                                {sec.badge}
                              </span>
                            )}
                          </div>

                          <p className="text-xs sm:text-sm text-slate-300 font-normal leading-relaxed pl-7 whitespace-pre-line">
                            {sec.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4.5 QUICK REVISION POINTS (পরীক্ষার দ্রুত রিভিশন পয়েন্ট) */}
                {data.quickRevisionPoints && data.quickRevisionPoints.length > 0 && (
                  <div className="p-4 bg-amber-950/20 border border-amber-500/30 rounded-2xl space-y-2">
                    <h5 className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isBn ? '⚡ পরীক্ষার ১-মিনিট দ্রুত রিভিশন পয়েন্ট' : '⚡ 1-Minute Quick Revision Points'}</span>
                    </h5>
                    <ul className="space-y-1.5 text-xs text-slate-200">
                      {data.quickRevisionPoints.map((pt, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-amber-400 font-black">✓</span>
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* 5. DUAL SOURCE DISTINCTION (BOOK HIGHLIGHTS vs AI CONTEXT) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  
                  {/* FROM BOOK */}
                  {data.bookExtractedHighlights && data.bookExtractedHighlights.length > 0 && (
                    <div className="p-4 bg-slate-950/90 border border-slate-800 rounded-2xl space-y-2">
                      <h5 className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>
                          {data.pageCount && data.pageCount > 0 
                            ? t.bookSource 
                            : (isBn ? '📌 মূল বইয়ের পয়েন্টসমূহ' : isHi ? '📌 मुख्य पुस्तक बिंदु' : '📌 Core Book Points')}
                        </span>
                      </h5>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {data.bookExtractedHighlights.map((pt, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-emerald-400 font-bold">•</span>
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* AI TEACHER CONTEXT */}
                  {data.aiAdditionalContext && data.aiAdditionalContext.length > 0 && (
                    <div className="p-4 bg-slate-950/90 border border-slate-800 rounded-2xl space-y-2">
                      <h5 className="text-xs font-black text-indigo-400 flex items-center gap-1.5">
                        <GraduationCap className="w-3.5 h-3.5" />
                        <span>{t.aiSource}</span>
                      </h5>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {data.aiAdditionalContext.map((pt, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-indigo-400 font-bold">•</span>
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* 6. INTERACTIVE MCQS (অনুশীলনী MCQ কুইজ) */}
                {data.mcqs && data.mcqs.length > 0 && (
                  <div className="p-4 bg-slate-950 border border-indigo-500/30 rounded-2xl space-y-4 shadow-md">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-purple-500/20 text-purple-300 rounded-lg border border-purple-500/30">
                          <FileQuestion className="w-4 h-4" />
                        </div>
                        <div>
                          <h5 className="text-xs sm:text-sm font-black text-white">
                            {isBn ? `অনুশীলনী MCQ কুইজ (${data.mcqs.length}টি প্রশ্ন)` : `Practice Quiz (${data.mcqs.length} MCQs)`}
                          </h5>
                          <span className="text-[10px] text-slate-400">
                            {isBn ? 'সঠিক অপশনটি নির্বাচন করে নিজেকে যাচাই করুন' : 'Test your knowledge by picking the right options'}
                          </span>
                        </div>
                      </div>

                      {/* Score Tracker & Retake button */}
                      {Object.keys(selectedMCQAnswers).length > 0 && (
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-black px-2.5 py-1 bg-indigo-950 text-indigo-300 border border-indigo-500/40 rounded-lg">
                            {isBn ? 'স্কোর: ' : 'Score: '}
                            {data.mcqs.filter((q, idx) => selectedMCQAnswers[idx] === q.correctIndex).length} / {data.mcqs.length}
                          </span>
                          <button
                            onClick={() => setSelectedMCQAnswers({})}
                            className="text-[10px] font-bold text-slate-400 hover:text-white px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-all cursor-pointer"
                          >
                            {isBn ? '🔄 রিসেট' : 'Reset'}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      {data.mcqs.map((q, qIdx) => {
                        const userAns = selectedMCQAnswers[qIdx];
                        const hasAnswered = userAns !== undefined;
                        const optionLabels = ['A', 'B', 'C', 'D'];

                        return (
                          <div key={qIdx} className="p-3.5 bg-slate-900/90 rounded-xl space-y-3 border border-slate-800">
                            <div className="flex items-start gap-2">
                              <span className="w-5 h-5 rounded-md bg-purple-600/30 text-purple-300 border border-purple-500/30 text-[11px] font-black flex items-center justify-center shrink-0 mt-0.5">
                                {qIdx + 1}
                              </span>
                              <p className="text-xs sm:text-sm font-bold text-white leading-snug">
                                {q.question}
                              </p>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {q.options.map((opt, optIdx) => {
                                const isCorrect = optIdx === q.correctIndex;
                                const isSelected = userAns === optIdx;

                                let btnStyle = 'bg-slate-800/80 hover:bg-slate-750 text-slate-300 border-slate-700';
                                if (hasAnswered) {
                                  if (isCorrect) {
                                    btnStyle = 'bg-emerald-950 border-emerald-500 text-emerald-200 shadow-sm';
                                  } else if (isSelected) {
                                    btnStyle = 'bg-rose-950 border-rose-500 text-rose-200';
                                  } else {
                                    btnStyle = 'bg-slate-900/50 text-slate-500 border-transparent';
                                  }
                                }

                                return (
                                  <button
                                    key={optIdx}
                                    onClick={() => setSelectedMCQAnswers(prev => ({ ...prev, [qIdx]: optIdx }))}
                                    disabled={hasAnswered}
                                    className={`p-2.5 text-xs text-left rounded-xl border font-medium transition-all flex items-center justify-between cursor-pointer gap-2 ${btnStyle}`}
                                  >
                                    <div className="flex items-center gap-2 min-w-0">
                                      <span className="w-4 h-4 rounded-full bg-slate-700/60 text-slate-300 text-[10px] font-bold flex items-center justify-center shrink-0">
                                        {optionLabels[optIdx] || optIdx + 1}
                                      </span>
                                      <span className="truncate">{opt}</span>
                                    </div>
                                    {hasAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                                  </button>
                                );
                              })}
                            </div>

                            {hasAnswered && (
                              <div className="text-[11px] text-slate-300 bg-slate-950/90 p-2.5 rounded-xl border border-indigo-500/20 space-y-1">
                                <span className="font-bold text-indigo-300 flex items-center gap-1">
                                  💡 {isBn ? 'সঠিক উত্তরের ব্যাখ্যা:' : 'Answer Explanation:'}
                                </span>
                                <p className="text-slate-300">{q.explanation}</p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 6.5 INSTANT STUDY ACTION BAR (MCQ কুইজ, ফ্ল্যাশ কার্ড, কুইক রিভিশন) */}
                <div className="p-3 bg-slate-950/90 border border-slate-800 rounded-2xl space-y-2">
                  <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">
                    {isBn ? '⚡ দ্রুত স্টাডি অ্যাকশন (Quick Study Actions)' : '⚡ Quick Study Actions'}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleAskAITutor({ 
                        action: 'make_mcqs', 
                        customQuestion: `${data.topicTitle} টপিক থেকে আরও ৫টি গুরুত্বপূর্ণ ও নতুন MCQ তৈরি করুন` 
                      })}
                      disabled={isLoading}
                      className="px-3 py-1.5 bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/40 text-purple-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      <FileQuestion className="w-3.5 h-3.5 text-purple-400" />
                      <span>{isBn ? '📝 নতুন ৫টি MCQ টেস্ট' : '📝 Generate 5 MCQs'}</span>
                    </button>

                    <button
                      onClick={() => handleAskAITutor({ 
                        action: 'quick_revision', 
                        customQuestion: `${data.topicTitle} এর ১ মিনিটের বুলেট রিভিশন পয়েন্ট দিন` 
                      })}
                      disabled={isLoading}
                      className="px-3 py-1.5 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/40 text-amber-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isBn ? '⚡ ১ মিনিটে রিভিশন' : '⚡ 1-Min Quick Revision'}</span>
                    </button>

                    <button
                      onClick={() => handleAskAITutor({ 
                        action: 'make_flashcards', 
                        customQuestion: `${data.topicTitle} এর মেমোরি ফ্ল্যাশ কার্ড তৈরি করুন` 
                      })}
                      disabled={isLoading}
                      className="px-3 py-1.5 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-500/40 text-indigo-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isBn ? '🃏 ফ্ল্যাশ কার্ড' : '🃏 Flashcards'}</span>
                    </button>

                    <button
                      onClick={() => handleAskAITutor({ 
                        action: 'explain_simpler', 
                        customQuestion: `${data.topicTitle} বাস্তব উদাহরণ দিয়ে আরও সহজ ভাষায় বুঝিয়ে বলো` 
                      })}
                      disabled={isLoading}
                      className="px-3 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{isBn ? '💡 বাস্তব উদাহরণসহ ব্যাখ্যা' : '💡 Explain with Examples'}</span>
                    </button>
                  </div>
                </div>

                {/* 7. INTERACTIVE FLASHCARDS (If generated) */}
                {data.flashcards && data.flashcards.length > 0 && (
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-white flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-amber-400" />
                        <span>Flashcard {activeFlashcardIndex + 1} of {data.flashcards.length}</span>
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setActiveFlashcardIndex(prev => Math.max(0, prev - 1));
                            setIsFlashcardFlipped(false);
                          }}
                          disabled={activeFlashcardIndex === 0}
                          className="p-1 bg-slate-800 text-slate-300 rounded disabled:opacity-40"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setActiveFlashcardIndex(prev => Math.min(data.flashcards!.length - 1, prev + 1));
                            setIsFlashcardFlipped(false);
                          }}
                          disabled={activeFlashcardIndex === data.flashcards.length - 1}
                          className="p-1 bg-slate-800 text-slate-300 rounded disabled:opacity-40"
                        >
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div
                      onClick={() => setIsFlashcardFlipped(prev => !prev)}
                      className="p-6 bg-gradient-to-br from-indigo-950/60 to-slate-900 border border-indigo-500/40 rounded-2xl text-center space-y-2 cursor-pointer shadow-lg min-h-[120px] flex flex-col items-center justify-center transition-all hover:scale-[1.01]"
                    >
                      <span className="text-[10px] font-black uppercase tracking-wider text-indigo-300">
                        {isFlashcardFlipped ? 'Answer / উত্তর' : 'Question / Concept (Click to flip)'}
                      </span>
                      <p className="text-xs sm:text-sm font-bold text-white">
                        {isFlashcardFlipped 
                          ? data.flashcards[activeFlashcardIndex].back 
                          : data.flashcards[activeFlashcardIndex].front}
                      </p>
                      {data.flashcards[activeFlashcardIndex].hint && !isFlashcardFlipped && (
                        <span className="text-[10px] text-amber-300 block">
                          💡 Hint: {data.flashcards[activeFlashcardIndex].hint}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* 8. SMART FOLLOW-UP QUESTIONS */}
                {data.followUpQuestions && data.followUpQuestions.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">
                      {isBn ? 'পরবর্তী প্রশ্ন আইডিয়া (Smart Follow-ups)' : 'Smart Follow-up Questions'}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {data.followUpQuestions.map((q, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleAskAITutor({ customQuestion: q })}
                          disabled={isLoading}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-indigo-950/70 border border-slate-700 hover:border-indigo-500/50 text-indigo-200 text-xs font-bold rounded-xl transition-all cursor-pointer text-left shadow-xs flex items-center gap-1.5"
                        >
                          <span>👉</span>
                          <span>{q}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            );
          })}

          {/* Inline Chat AI Thinking & Typing Bubble */}
          {isLoading && (
            <div className="flex items-start gap-2.5 animate-in fade-in slide-in-from-bottom-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-md">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-900/95 border border-indigo-500/40 rounded-2xl rounded-tl-xs p-3.5 shadow-lg flex items-center gap-3 backdrop-blur-md">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-xs font-bold text-indigo-200">
                  {loadingHasImages 
                    ? (isBn ? 'পাতা বিশ্লেষণ করা হচ্ছে...' : 'Analyzing study pages...') 
                    : (isBn ? 'StudySkill AI উত্তর লিখছে...' : 'StudySkill AI is replying...')}
                </span>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 🔍 8. PERMANENT UNIFIED BOTTOM DOCK (SEARCH + CAMERA + UPLOAD) */}
      {/* ------------------------------------------------------------- */}
      <div className="fixed bottom-16 md:bottom-0 left-0 right-0 z-40 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent pt-3 pb-2 sm:pb-4 px-2.5 sm:px-6 pointer-events-none">
        <div className="max-w-5xl mx-auto space-y-2 pointer-events-auto">
          
          {/* A. ACTIVE PAGES MINI-DRAWER (When pages are attached) */}
          {attachedPages.length > 0 && (
            <div className="bg-slate-900/90 border border-indigo-500/40 rounded-2xl p-2 px-3 shadow-xl backdrop-blur-md flex items-center justify-between gap-2 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-thin">
                <span className="text-[10px] font-black text-indigo-300 uppercase tracking-wider shrink-0 flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-indigo-400" />
                  <span>{attachedPages.length} {isBn ? 'পাতা' : 'Pages'}</span>
                </span>

                <div className="h-4 w-px bg-slate-700 shrink-0" />

                {attachedPages.map((img, idx) => (
                  <div key={idx} className="relative w-8 h-10 rounded-md overflow-hidden border border-indigo-500/40 shrink-0 group">
                    <img src={img} alt={`P${idx+1}`} className="w-full h-full object-cover" />
                    <button
                      onClick={() => handleRemovePage(idx)}
                      className="absolute inset-0 bg-rose-950/80 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <label className="text-[10px] font-black text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer bg-slate-800 px-2 py-1 rounded-lg border border-slate-700">
                  <Plus className="w-3 h-3" />
                  <span>{isBn ? 'আরও পাতা' : 'Add More'}</span>
                  <input 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleGallerySelect} 
                  />
                </label>

                <button
                  onClick={() => {
                    setAttachedPages([]);
                    setCurrentResponse(null);
                    setChatMessages([]);
                  }}
                  className="text-[10px] text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* 🔊 8.A PERMANENT STICKY "পড়ে শোনাও" AUDIO DOCK BAR (থাই / স্থায়ী) */}
          {latestTutorData && (
            <div className="bg-slate-900/95 border border-indigo-500/40 hover:border-indigo-500/60 rounded-2xl px-3 py-1.5 shadow-xl backdrop-blur-md flex items-center justify-between gap-2 animate-in fade-in">
              <div className="flex items-center gap-2 min-w-0">
                <div className={`p-1.5 rounded-xl shrink-0 flex items-center justify-center ${
                  isPlayingAudio ? 'bg-rose-500/20 text-rose-400 animate-pulse border border-rose-500/30' : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                }`}>
                  {isPlayingAudio ? (
                    <div className="flex items-end gap-0.5 h-3.5 w-3.5 justify-center">
                      <span className="w-0.5 bg-rose-400 animate-bounce h-full rounded-full" style={{ animationDelay: '0ms' }} />
                      <span className="w-0.5 bg-rose-400 animate-bounce h-2 rounded-full" style={{ animationDelay: '150ms' }} />
                      <span className="w-0.5 bg-rose-400 animate-bounce h-3 rounded-full" style={{ animationDelay: '300ms' }} />
                    </div>
                  ) : (
                    <Headphones className="w-3.5 h-3.5 text-indigo-400" />
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] font-black uppercase tracking-wider text-indigo-300">
                      {isPlayingAudio ? (isBn ? '🔊 পড়ে শোনাচ্ছে' : 'Reading Aloud') : (isBn ? '🔊 পড়ে শোনাও' : 'Read Aloud')}
                    </span>
                    {isPlayingAudio && (
                      <span className="text-[8px] font-black text-rose-400 bg-rose-950/80 px-1 py-0.2 rounded border border-rose-500/30 animate-pulse">
                        LIVE
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] font-bold text-white truncate block max-w-[160px] sm:max-w-[340px]">
                    {latestTutorData.topicTitle}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleToggleAudio(`${latestTutorData.topicTitle}. ${latestTutorData.summary}. ${latestTutorData.detailedExplanation}`)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-black flex items-center gap-1 cursor-pointer transition-all shadow-md active:scale-95 ${
                    isPlayingAudio
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                      : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white shadow-indigo-600/30'
                  }`}
                  title={isPlayingAudio ? t.btnPause : t.btnReadAloud}
                >
                  {isPlayingAudio ? (
                    <>
                      <Pause className="w-3 h-3 fill-current" />
                      <span>{t.btnPause}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3 h-3 fill-current" />
                      <span>{t.btnReadAloud}</span>
                    </>
                  )}
                </button>

                {isPlayingAudio && (
                  <button
                    onClick={handleStopAudio}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700 transition-colors cursor-pointer"
                    title={isBn ? 'সম্পূর্ণ থামান' : 'Stop Audio'}
                  >
                    <Square className="w-3 h-3 fill-current" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ⚡ 8.B SCROLLABLE QUICK PROMPT UNITS (ছোট ও ইউনিট আকারে) */}
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none">
            <span className="text-[9px] font-black uppercase text-indigo-400/90 tracking-wider shrink-0 px-1 flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-indigo-400" />
              <span>{isBn ? 'ইউনিট:' : 'Units:'}</span>
            </span>

            {promptUnits.map((u, idx) => (
              <button
                key={idx}
                onClick={() => handleAskAITutor({ customQuestion: u.prompt })}
                disabled={isLoading}
                className="text-[10px] font-bold bg-slate-900/90 hover:bg-indigo-950/80 border border-slate-800 hover:border-indigo-500/50 text-slate-300 hover:text-indigo-200 px-2 py-0.5 rounded-lg cursor-pointer transition-all shrink-0 whitespace-nowrap shadow-xs backdrop-blur-md active:scale-95 flex items-center gap-1"
                title={u.prompt}
              >
                <span>{u.icon}</span>
                <span>{u.label}</span>
              </button>
            ))}
          </div>

          {/* C. MAIN SEARCH & DOCK BAR */}
          <div className="bg-slate-900/95 border border-indigo-500/40 hover:border-indigo-500/60 rounded-3xl p-2 shadow-2xl backdrop-blur-xl transition-all">
            <div className="flex items-end gap-1.5 sm:gap-2">
              
              {/* 1. CAMERA QUICK BUTTON */}
              <button
                type="button"
                onClick={() => openCameraExperience()}
                className="p-2.5 sm:p-3 bg-gradient-to-tr from-indigo-600 via-purple-600 to-indigo-500 hover:opacity-95 active:scale-95 text-white rounded-2xl shadow-lg shadow-indigo-600/40 border border-indigo-400/30 transition-all cursor-pointer shrink-0 flex items-center justify-center group mb-0.5"
                title={isBn ? 'ক্যামেরা দিয়ে বইয়ের পাতার ছবি তুলুন' : 'Open Camera to scan pages'}
              >
                <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-white drop-shadow-sm group-hover:scale-110 transition-transform" />
              </button>

              {/* 2. PHOTO GALLERY UPLOAD BUTTON */}
              <label 
                className="p-2.5 sm:p-3 bg-slate-800 hover:bg-slate-700 hover:border-indigo-500/50 border border-slate-700/80 text-indigo-300 hover:text-white rounded-2xl transition-all cursor-pointer shrink-0 flex items-center justify-center shadow-md active:scale-95 mb-0.5"
                title={isBn ? 'গ্যালারি থেকে ফটো আপলোড করুন' : 'Upload photo from gallery'}
              >
                <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                <input 
                  ref={fileInputRef}
                  type="file" 
                  multiple 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleGallerySelect} 
                />
              </label>

              {/* 3. QUESTION / SEARCH INPUT (Auto-Expanding Multiline Textarea) */}
              <div className="flex-1 relative flex flex-col justify-center min-w-0">
                <div className="relative w-full flex items-center">
                  <textarea
                    ref={textareaRef}
                    value={questionInput}
                    onChange={(e) => setQuestionInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleAskAITutor({});
                      }
                    }}
                    rows={1}
                    spellCheck={false}
                    autoCorrect="off"
                    autoCapitalize="off"
                    autoComplete="off"
                    data-gramm="false"
                    data-gramm_editor="false"
                    data-enable-grammarly="false"
                    placeholder={
                      attachedPages.length > 0 
                        ? (isBn ? 'এই পাতাগুলো নিয়ে যেকোনো প্রশ্ন লিখুন...' : isHi ? 'इन पेजों के बारे में कुछ भी पूछें...' : 'Ask anything about these pages...')
                        : (isBn ? 'প্রশ্ন লিখুন বা বইয়ের পাতা স্ক্যান করুন...' : isHi ? 'प्रश्न लिखें या पेज स्कैन करें...' : 'Ask question or upload study pages...')
                    }
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-2xl pl-3 sm:pl-4 pr-14 sm:pr-16 py-2.5 sm:py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-colors resize-none leading-relaxed overflow-y-auto scrollbar-none min-h-[44px] max-h-[190px] whitespace-pre-wrap break-words"
                  />

                  {/* Right Action Icons: Clear Button & Expand Full View */}
                  <div className="absolute right-2.5 top-2.5 flex items-center gap-1 z-10">
                    {questionInput.trim().length > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setQuestionInput('');
                          if (textareaRef.current) {
                            textareaRef.current.style.height = '44px';
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                        title={isBn ? 'লেখা মুছুন' : 'Clear text'}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setIsTextExpanded(true)}
                      className="p-1 text-slate-400 hover:text-indigo-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                      title={isBn ? 'বড় করে সম্পূর্ণ লেখা দেখুন ও লিখুন' : 'Expand full view'}
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Micro details on multi-line typing */}
                {questionInput.trim().length > 40 && (
                  <div className="flex items-center justify-between px-2 pt-1 text-[10px] text-slate-400 font-medium">
                    <span>
                      {isBn 
                        ? `${questionInput.trim().split(/\s+/).length} টি শব্দ • ${questionInput.length} অক্ষর`
                        : `${questionInput.trim().split(/\s+/).length} words • ${questionInput.length} chars`}
                    </span>
                    <span className="text-indigo-300 hidden sm:inline">
                      {isBn ? 'নতুন লাইনের জন্য Shift + Enter' : 'Shift + Enter for new line'}
                    </span>
                  </div>
                )}
              </div>

              {/* 4. VOICE / MIC BUTTON */}
              <button
                type="button"
                onClick={toggleVoiceInput}
                className={`p-2.5 sm:p-3 rounded-2xl transition-all cursor-pointer shrink-0 border mb-0.5 ${
                  isListening 
                    ? 'bg-rose-600 text-white animate-pulse border-rose-500 shadow-lg shadow-rose-600/50' 
                    : 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border-slate-700/80 hover:border-indigo-500/40'
                }`}
                title={isListening ? 'Stop voice recording' : 'Speak your question'}
              >
                {isListening ? <MicOff className="w-4 h-4 sm:w-5 sm:h-5" /> : <Mic className="w-4 h-4 sm:w-5 sm:h-5" />}
              </button>

              {/* 5. SEND / ASK BUTTON */}
              <button
                type="button"
                onClick={() => handleAskAITutor({})}
                disabled={isLoading || (!questionInput.trim() && attachedPages.length === 0)}
                className="p-2.5 sm:p-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 disabled:opacity-40 text-white rounded-2xl font-black cursor-pointer transition-all shadow-lg shadow-indigo-600/40 active:scale-95 shrink-0 flex items-center justify-center mb-0.5"
                title={isBn ? 'প্রশ্ন পাঠান' : 'Send Question'}
              >
                <Send className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>

            </div>
          </div>

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 📝 9. FULL-SCREEN / EXPANDED QUESTION EDITOR MODAL            */}
      {/* ------------------------------------------------------------- */}
      {isTextExpanded && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl p-4 sm:p-6 w-full max-w-2xl shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {isBn ? 'সম্পূর্ণ প্রশ্ন লিখুন ও দেখুন' : isHi ? 'पूरा प्रश्न लिखें और देखें' : 'Full Question Editor'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isBn ? 'এখানে সম্পূর্ণ লেখা পরিষ্কারভাবে বড় স্ক্রিনে দেখা ও এডিট করা যায়' : 'View, edit and compose long questions with zero cut-off'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsTextExpanded(false)}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Big Spacious Textarea */}
            <div className="flex-1 flex flex-col space-y-2 min-h-[220px]">
              <textarea
                autoFocus
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                spellCheck={false}
                autoCorrect="off"
                autoCapitalize="off"
                autoComplete="off"
                data-gramm="false"
                data-gramm_editor="false"
                data-enable-grammarly="false"
                placeholder={
                  isBn 
                    ? 'এখানে আপনার বিস্তারিত প্রশ্ন, গণিতের সমীকরণ বা যেকোনো পড়ার সমস্যা সম্পূর্ণ লিখুন...' 
                    : isHi
                    ? 'यहाँ अपना विस्तृत प्रश्न या गणित का सवाल पूरा लिखें...'
                    : 'Type or paste your complete study question, math problem, or essay...'
                }
                rows={8}
                className="w-full flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-2xl p-4 text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none transition-colors resize-y leading-relaxed scrollbar-none"
              />

              {/* Word & Char Count */}
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>
                  {isBn 
                    ? `মোট: ${questionInput.trim() ? questionInput.trim().split(/\s+/).length : 0} টি শব্দ • ${questionInput.length} টি অক্ষর`
                    : `Total: ${questionInput.trim() ? questionInput.trim().split(/\s+/).length : 0} words • ${questionInput.length} characters`}
                </span>
                {questionInput.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => setQuestionInput('')}
                    className="text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                  >
                    {isBn ? 'সব মুছুন' : 'Clear All'}
                  </button>
                )}
              </div>
            </div>

            {/* Quick helper prompts in modal */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-400 font-bold mr-1">
                {isBn ? 'দ্রুত যোগ করুন:' : 'Add prompt:'}
              </span>
              {[
                isBn ? 'স্টেপ-বাই-স্টেপ সমাধান করো' : 'Solve step-by-step',
                isBn ? 'সহজ ভাষায় বুঝিয়ে দাও' : 'Explain in simple terms',
                isBn ? 'গুরুত্বপূর্ণ সূত্র ও পয়েন্ট দাও' : 'Give key formulas & points'
              ].map((sug, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setQuestionInput((prev) => (prev ? `${prev} (${sug})` : sug))}
                  className="text-[11px] bg-slate-800 hover:bg-slate-700 text-indigo-300 px-2.5 py-1 rounded-full border border-slate-700 transition-colors cursor-pointer"
                >
                  + {sug}
                </button>
              ))}
            </div>

            {/* Footer buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsTextExpanded(false)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                {isBn ? 'সংরক্ষণ ও বন্ধ করুন' : 'Done & Close'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsTextExpanded(false);
                  handleAskAITutor({});
                }}
                disabled={isLoading || (!questionInput.trim() && attachedPages.length === 0)}
                className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:opacity-95 disabled:opacity-40 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{isBn ? 'প্রশ্ন পাঠান' : 'Send Question'}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
