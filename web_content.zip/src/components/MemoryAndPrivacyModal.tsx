import React, { useState } from 'react';
import { Database, ShieldCheck, Trash2, Plus, X, Lock, Eye, AlertCircle } from 'lucide-react';
import { MemoryItem } from '../types';

import { voiceEngine } from '../services/voiceService';

interface MemoryAndPrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (key: string, value: string) => void;
  onDeleteMemory: (id: string) => void;
  onClearAllMemories: () => void;
  onClearChatHistory: () => void;
  cloudAiEnabled: boolean;
  onToggleCloudAi: () => void;
  fastMode: boolean;
  onToggleFastMode: () => void;
}

export const MemoryAndPrivacyModal: React.FC<MemoryAndPrivacyModalProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
  onClearAllMemories,
  onClearChatHistory,
  cloudAiEnabled,
  onToggleCloudAi,
  fastMode,
  onToggleFastMode,
}) => {
  const [activeTab, setActiveTab] = useState<'memory' | 'privacy'>('memory');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [elevenLabsKey, setElevenLabsKey] = useState<string>(() => voiceEngine.getElevenLabsApiKey());
  const [keySavedNotice, setKeySavedNotice] = useState<string>('');

  if (!isOpen) return null;

  const handleSaveElevenLabsKey = () => {
    voiceEngine.setElevenLabsApiKey(elevenLabsKey);
    setKeySavedNotice('ElevenLabs Voice Key updated in private local storage.');
    setTimeout(() => setKeySavedNotice(''), 3000);
  };

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    onAddMemory(newKey.trim(), newValue.trim());
    setNewKey('');
    setNewValue('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header with Tabs */}
        <div className="px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('memory')}
              className={`font-tech text-sm uppercase tracking-wide pb-1 flex items-center gap-1.5 transition-colors ${
                activeTab === 'memory'
                  ? 'text-cyan-300 border-b-2 border-cyan-400 font-bold'
                  : 'text-gray-400 hover:text-cyan-400'
              }`}
            >
              <Database className="w-4 h-4" />
              JARVIS Neural Memory ({memories.length})
            </button>
            <button
              onClick={() => setActiveTab('privacy')}
              className={`font-tech text-sm uppercase tracking-wide pb-1 flex items-center gap-1.5 transition-colors ${
                activeTab === 'privacy'
                  ? 'text-cyan-300 border-b-2 border-cyan-400 font-bold'
                  : 'text-gray-400 hover:text-cyan-400'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Privacy & Local Vault
            </button>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {activeTab === 'memory' ? (
          /* Neural Memory View */
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {/* Add Custom Fact/Preference */}
            <form onSubmit={handleCreateMemory} className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/20 space-y-2">
              <div className="text-xs font-tech text-cyan-300 uppercase">Teach JARVIS a Custom Fact or Rule</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Subject / Keyword (e.g. Boss Name)"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                  required
                />
                <input
                  type="text"
                  placeholder="Value / Detail (e.g. Tony Stark)"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 rounded-lg font-tech text-xs uppercase flex items-center justify-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Commit to Long-Term Memory
              </button>
            </form>

            {/* Stored Memory List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-tech text-cyan-300 uppercase">Stored Context Entries:</span>
                {memories.length > 0 && (
                  <button
                    onClick={onClearAllMemories}
                    className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Clear All Memory
                  </button>
                )}
              </div>

              {memories.length === 0 ? (
                <div className="text-center py-6 text-cyan-400/50 text-xs">
                  No custom facts stored yet. Tell JARVIS in chat: "Remember my favorite car is Audi R8" or add here.
                </div>
              ) : (
                memories.map((m) => (
                  <div
                    key={m.id}
                    className="p-2.5 rounded-xl bg-gray-950/60 border border-cyan-500/20 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-mono-tech text-cyan-400 font-bold uppercase">{m.key}</div>
                      <div className="text-xs text-cyan-100 mt-0.5">{m.value}</div>
                    </div>
                    <button
                      onClick={() => onDeleteMemory(m.id)}
                      className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Conversation Reset */}
            <div className="pt-2 border-t border-cyan-500/20 flex justify-end">
              <button
                onClick={onClearChatHistory}
                className="px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-950/80 border border-red-500/40 text-red-300 text-xs font-tech uppercase transition-colors"
              >
                Wipe Active Chat History
              </button>
            </div>
          </div>
        ) : (
          /* Privacy & Architecture Details */
          <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
            {/* Toggles */}
            <div className="space-y-3">
              <div className="p-3 bg-gray-950/70 rounded-xl border border-cyan-500/20 flex items-center justify-between">
                <div>
                  <div className="font-tech text-sm text-cyan-200">CLOUD AI CORE (GEMINI 3.8 FLASH)</div>
                  <div className="text-cyan-400/60 text-[11px] mt-0.5">
                    When enabled, complex reasoning and search use server-side Gemini. When disabled, only local native commands execute.
                  </div>
                </div>
                <button
                  onClick={onToggleCloudAi}
                  className={`px-3 py-1 rounded-full font-tech font-bold uppercase text-[11px] transition-colors ${
                    cloudAiEnabled ? 'bg-cyan-500 text-gray-950' : 'bg-gray-800 text-gray-400'
                  }`}
                >
                  {cloudAiEnabled ? 'ENABLED' : 'OFFLINE'}
                </button>
              </div>

              <div className="p-3 bg-gray-950/70 rounded-xl border border-cyan-500/20 flex items-center justify-between">
                <div>
                  <div className="font-tech text-sm text-cyan-200">ULTRA-FAST LATENCY MODE</div>
                  <div className="text-cyan-400/60 text-[11px] mt-0.5">
                    Uses minimal reasoning tokens and cache for sub-second responses on mobile devices.
                  </div>
                </div>
                <button
                  onClick={onToggleFastMode}
                  className={`px-3 py-1 rounded-full font-tech font-bold uppercase text-[11px] transition-colors ${
                    fastMode ? 'bg-amber-400 text-gray-950' : 'bg-gray-800 text-gray-400'
                  }`}
                >
                  {fastMode ? 'ACTIVE' : 'STANDARD'}
                </button>
              </div>

              {/* ElevenLabs Permanent Voice Integration */}
              <div className="p-3 bg-gray-950/70 rounded-xl border border-cyan-500/20 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-tech text-sm text-cyan-200">
                      ELEVENLABS VOICE INTELLIGENCE // GEORGE (JBFqnCBsd6RMkjVDRZzb)
                    </div>
                    <div className="text-cyan-400/60 text-[11px] mt-0.5">
                      Permanent British Male Voice (Model: eleven_multilingual_v2). Enter your ElevenLabs API Key for cloud synthesis, or leave blank to use the synchronized local British male neural baritone.
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input
                    type="password"
                    placeholder="ElevenLabs API Key (e.g. sk_...)"
                    value={elevenLabsKey}
                    onChange={(e) => setElevenLabsKey(e.target.value)}
                    className="flex-1 bg-gray-900 border border-cyan-500/30 rounded-lg px-2.5 py-1.5 text-xs text-cyan-100 font-mono focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={handleSaveElevenLabsKey}
                    className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-mono uppercase rounded-lg transition-colors cursor-pointer"
                  >
                    Save Key
                  </button>
                </div>
                {keySavedNotice && (
                  <div className="text-[11px] text-emerald-400 font-mono">
                    ✓ {keySavedNotice}
                  </div>
                )}
              </div>
            </div>

            {/* Privacy Architecture Audit */}
            <div className="p-3.5 bg-gray-950/80 rounded-xl border border-cyan-500/30 space-y-2">
              <div className="font-tech text-cyan-300 uppercase flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                Data Privacy Transparency Audit
              </div>
              <ul className="space-y-1.5 text-cyan-200/80 text-[11px] leading-relaxed">
                <li className="flex items-start gap-1.5">
                  <span className="text-cyan-400">•</span>
                  <span><strong>Contacts & Phonebook:</strong> 100% saved in your browser's private local storage. Never uploaded to Gemini or third parties.</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-cyan-400">•</span>
                  <span><strong>Voice Audio:</strong> Speech recognition and voice synthesis run on your device via standard browser speech APIs. Microphone recordings are not saved or sold.</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-cyan-400">•</span>
                  <span><strong>Permanent Voice Reference:</strong> Calibrated and permanently locked to Harman Sir's British male reference audio (<code className="text-cyan-300">voice-preview (1).mp3</code>) across English, Hindi, and Punjabi. Automatic voice switching is strictly disabled.</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-cyan-400">•</span>
                  <span><strong>Camera Feeds:</strong> The camera is only active while the Vision HUD is open. Frames are only sent when you explicitly tap "Inspect Frame".</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-cyan-400">•</span>
                  <span><strong>API Keys:</strong> Private credentials remain securely housed in server environment secrets and are never sent to the browser bundle.</span>
                </li>
              </ul>
            </div>
          </div>
        )}

        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-300/60 text-center">
          Encrypted local vault active. All user settings are saved on this device.
        </div>
      </div>
    </div>
  );
};
