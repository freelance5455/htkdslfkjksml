import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { getSubjectsForClass } from '../data/curriculum';
import { ClassLevel, CustomSubject, LanguageCode, Subject } from '../types/edutoon';
import { SubjectIcon } from './DashboardHome';
import { Logo } from './Logo';

interface SubjectsGridViewProps {
  classLevel: ClassLevel;
  defaultLanguage: LanguageCode;
  customSubjects?: CustomSubject[];
  onSelectSubject: (subjectId: string) => void;
}

export const SubjectsGridView: React.FC<SubjectsGridViewProps> = ({
  classLevel,
  defaultLanguage,
  customSubjects = [],
  onSelectSubject,
}) => {
  const [sectionLang, setSectionLang] = useState<LanguageCode>(defaultLanguage);
  const builtIn = getSubjectsForClass(classLevel);
  const extraSubjects: Subject[] = customSubjects
    .filter((cs) => cs.minClass <= classLevel && cs.maxClass >= classLevel)
    .filter((cs) => !builtIn.some((b) => b.id === cs.slug))
    .map((cs) => ({
      id: cs.slug,
      classLevel,
      titleEn: cs.titleEn,
      titleHi: cs.titleHi,
      descriptionEn: cs.descriptionEn,
      descriptionHi: cs.descriptionHi,
      accentHex: cs.accentHex,
      iconKey: cs.iconKey,
    }));
  const subjects = [...builtIn, ...extraSubjects];
  const isHi = sectionLang === 'hi';

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <Logo size="sm" />
          <div>
            <p className="text-xs font-medium text-slate-500">
              {isHi ? `कक्षा ${classLevel} पाठ्यक्रम` : `Class ${classLevel} Curriculum`}
            </p>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
              {isHi ? 'अपना विषय चुनें' : 'Select a Subject'}
            </h1>
          </div>
        </div>

        {/* Separate Hindi & English Learning Sections */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setSectionLang('hi')}
            className={`min-h-[40px] px-4 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              sectionLang === 'hi'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            हिंदी Learning Section
          </button>
          <button
            type="button"
            onClick={() => setSectionLang('en')}
            className={`min-h-[40px] px-4 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              sectionLang === 'en'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            English Learning Section
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map((sub) => (
          <button
            key={sub.id}
            type="button"
            onClick={() => onSelectSubject(sub.id)}
            className="bg-white rounded-3xl border border-slate-200 hover:border-sky-400 p-6 text-left transition-all flex flex-col justify-between gap-5 cursor-pointer group"
          >
            <div className="flex items-start justify-between gap-3">
              <div
                className="h-14 w-14 rounded-2xl flex items-center justify-center text-white shrink-0"
                style={{ backgroundColor: sub.accentHex }}
              >
                <SubjectIcon iconKey={sub.iconKey} className="h-7 w-7" />
              </div>
              <span className="text-xs font-medium text-slate-500">
                {isHi ? 'नोट्स + वीडियो' : 'Notes + Videos'}
              </span>
            </div>

            <div>
              <h2 className="font-display text-xl font-bold text-slate-900 group-hover:text-sky-700 transition-colors">
                {isHi ? sub.titleHi : sub.titleEn}
              </h2>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                {isHi ? sub.descriptionHi : sub.descriptionEn}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-sky-700">
              <span>{isHi ? 'विषय पृष्ठ खोलें' : 'Open Subject Page'}</span>
              <ChevronRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
