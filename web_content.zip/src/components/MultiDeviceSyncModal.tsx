import React, { useState } from 'react';
import {
  X,
  RefreshCw,
  Smartphone,
  Laptop,
  QrCode,
  ShieldCheck,
  UploadCloud,
  DownloadCloud,
  Check,
  Copy,
  AlertCircle,
  Key,
  Layers,
  Download,
} from 'lucide-react';
import { HebrewEvent, LocationPreset, SyncState, UserSettings } from '../types';
import {
  generateRoomCode,
  pushCalendarToCloud,
  pullCalendarFromCloud,
  generateICalFile,
  downloadFile,
} from '../services/syncService';

interface MultiDeviceSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  syncState: SyncState;
  onUpdateSyncState: (newState: SyncState) => void;
  events: HebrewEvent[];
  onSetEvents: (events: HebrewEvent[]) => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  location: LocationPreset;
}

export const MultiDeviceSyncModal: React.FC<MultiDeviceSyncModalProps> = ({
  isOpen,
  onClose,
  syncState,
  onUpdateSyncState,
  events,
  onSetEvents,
  settings,
  onUpdateSettings,
  location,
}) => {
  const [roomIdInput, setRoomIdInput] = useState(syncState.roomId || '');
  const [roomPinInput, setRoomPinInput] = useState(syncState.roomPin || '');
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const handleGenerateNewRoom = () => {
    const newCode = generateRoomCode();
    setRoomIdInput(`HEB-${newCode}`);
  };

  const handlePush = async () => {
    if (!roomIdInput.trim()) {
      alert('Please enter or generate a Sync Room Code first');
      return;
    }
    setIsBusy(true);
    setSyncStatusMsg('Syncing data to cloud server...');

    const res = await pushCalendarToCloud(
      roomIdInput.trim(),
      roomPinInput.trim(),
      events,
      settings,
      syncState.deviceName
    );

    setIsBusy(false);
    if (res.success) {
      onUpdateSyncState({
        ...syncState,
        roomId: roomIdInput.trim().toUpperCase(),
        roomPin: roomPinInput.trim(),
        isConnected: true,
        lastSyncedAt: res.timestamp || Date.now(),
        status: 'synced',
      });
      setSyncStatusMsg(`Synced successfully at ${new Date().toLocaleTimeString()}!`);
    } else {
      setSyncStatusMsg(`Sync error: ${res.error}`);
    }
  };

  const handlePull = async () => {
    if (!roomIdInput.trim()) {
      alert('Please enter a Sync Room Code to join');
      return;
    }
    setIsBusy(true);
    setSyncStatusMsg('Downloading synced calendar events...');

    const res = await pullCalendarFromCloud(roomIdInput.trim(), roomPinInput.trim());

    setIsBusy(false);
    if (res.success && res.data) {
      onSetEvents(res.data.events);
      if (res.data.settings) {
        onUpdateSettings(res.data.settings);
      }
      onUpdateSyncState({
        ...syncState,
        roomId: roomIdInput.trim().toUpperCase(),
        roomPin: roomPinInput.trim(),
        isConnected: true,
        lastSyncedAt: res.data.timestamp || Date.now(),
        status: 'synced',
      });
      setSyncStatusMsg(`Restored ${res.data.events.length} events from cloud!`);
    } else {
      setSyncStatusMsg(`Pull error: ${res.error || 'Room not found or incorrect PIN'}`);
    }
  };

  const handleCopyCode = () => {
    if (roomIdInput) {
      navigator.clipboard.writeText(roomIdInput);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleExportICal = () => {
    const icsContent = generateICalFile(events, location);
    downloadFile(icsContent, 'hebrew_calendar_sync.ics', 'text/calendar;charset=utf-8');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#252525] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#EAEAEA]">
                Multi-Device Calendar Sync
              </h3>
              <p className="text-xs text-[#888888]">
                Keep personal Hebrew events & Yahrzeits synchronized across devices
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* Sync Key / Room Pair */}
          <div className="p-5 rounded-2xl bg-[#161616] border border-[#2A2A2A] space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                  Sync Room Code
                </label>
                <button
                  type="button"
                  onClick={handleGenerateNewRoom}
                  className="text-xs text-[#C5A267] font-semibold hover:underline"
                >
                  Generate New Code
                </button>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. HEB-9482-L7K9"
                  value={roomIdInput}
                  onChange={(e) => setRoomIdInput(e.target.value.toUpperCase())}
                  className="flex-1 px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-sm font-mono font-bold text-[#C5A267] tracking-wider focus:border-[#C5A267] focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-medium text-[#888888] hover:text-[#EAEAEA] flex items-center gap-1.5 transition-colors"
                >
                  {copiedCode ? <Check className="w-4 h-4 text-[#C5A267]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider mb-1">
                Security PIN / Password (Optional)
              </label>
              <input
                type="password"
                placeholder="Optional 4-digit PIN"
                value={roomPinInput}
                onChange={(e) => setRoomPinInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-sm font-mono text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>

            {/* Sync Push / Pull Action Buttons */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                disabled={isBusy}
                onClick={handlePush}
                className="p-3 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors disabled:opacity-50"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Upload to Cloud</span>
              </button>

              <button
                type="button"
                disabled={isBusy}
                onClick={handlePull}
                className="p-3 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-bold text-[#EAEAEA] flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
              >
                <DownloadCloud className="w-4 h-4 text-[#C5A267]" />
                <span>Restore from Cloud</span>
              </button>
            </div>

            {syncStatusMsg && (
              <div className="p-3 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] text-xs text-[#C5A267] font-medium text-center">
                {syncStatusMsg}
              </div>
            )}
          </div>

          {/* External Calendar Direct Sync (.ICS) */}
          <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#252525] text-[#C5A267] flex items-center justify-center">
                <Laptop className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#EAEAEA]">
                  Sync with Apple / Google Calendar
                </div>
                <div className="text-[11px] text-[#888888]">
                  Export .ics calendar subscription file for your phone or desktop
                </div>
              </div>
            </div>

            <button
              onClick={handleExportICal}
              className="px-3.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-semibold text-[#D1D1D1] flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#C5A267]" />
              <span>Export .ICS</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2A2A2A] bg-[#161616] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
