import React, { useState } from 'react';
import {
  Image as ImageIcon,
  FileText,
  Globe,
  Upload,
  Sparkles,
  Download,
  Search,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import type { PdfAnalysisResult, SupportedLanguage } from '../types';

interface SharedToolProps {
  language: SupportedLanguage;
  onEarnXp: (amount: number) => void;
  onRecordTokens: (tokens: number) => void;
}

// Helper to create a clean educational diagram PNG on canvas for instant 1-click testing
function createSampleDiagramBase64(topic: 'cell' | 'optics'): string {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 400;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.fillStyle = '#070B22';
  ctx.fillRect(0, 0, 640, 400);

  ctx.strokeStyle = '#1E293B';
  for (let x = 0; x < 640; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 400);
    ctx.stroke();
  }

  if (topic === 'cell') {
    ctx.fillStyle = '#38BDF8';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText('EUKARYOTIC CELL & MITOCHONDRIA ATP SYNTHESIS', 40, 45);

    // Outer Cell Membrane
    ctx.strokeStyle = '#00F0FF';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.ellipse(320, 215, 220, 125, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Nucleus
    ctx.fillStyle = '#4F46E5';
    ctx.beginPath();
    ctx.arc(240, 210, 52, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '14px sans-serif';
    ctx.fillText('Nucleus (DNA)', 195, 215);

    // Mitochondrion
    ctx.strokeStyle = '#F43F5E';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(420, 210, 60, 32, 0.2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#FDA4AF';
    ctx.fillText('Mitochondria (36 ATP)', 355, 265);
  } else {
    ctx.fillStyle = '#A855F7';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText('OPTICAL PRISM DISPERSION (n = c / v)', 40, 45);

    // Prism Triangle
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(320, 90);
    ctx.lineTo(200, 310);
    ctx.lineTo(440, 310);
    ctx.closePath();
    ctx.stroke();

    // Incident White Ray
    ctx.strokeStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(80, 240);
    ctx.lineTo(260, 200);
    ctx.stroke();
    ctx.fillStyle = '#E2E8F0';
    ctx.font = '14px sans-serif';
    ctx.fillText('Incident White Light (λ = 400nm - 700nm)', 50, 270);
  }

  return canvas.toDataURL('image/png').split(',')[1] || '';
}

export const ImageAnalyzerModule: React.FC<SharedToolProps> = ({
  language,
  onEarnXp,
  onRecordTokens,
}) => {
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string>('');
  const [mimeType, setMimeType] = useState<string>('image/png');
  const [prompt, setPrompt] = useState<string>(
    'Explain this diagram in detail, extract all visible text and formulas, and list key exam takeaways.'
  );
  const [analysisText, setAnalysisText] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPEG, WEBP).');
      return;
    }
    setMimeType(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      setImagePreviewUrl(result);
      const b64 = result.split(',')[1] || '';
      setImageBase64(b64);
      setErrorMsg(null);
    };
    reader.readAsDataURL(file);
  };

  const loadSampleDiagram = (type: 'cell' | 'optics') => {
    const b64 = createSampleDiagramBase64(type);
    setImageBase64(b64);
    setMimeType('image/png');
    setImagePreviewUrl(`data:image/png;base64,${b64}`);
    setErrorMsg(null);
  };

  const handleAnalyzeImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageBase64) {
      setErrorMsg('Please upload an image or select a sample educational diagram first.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          mimeType,
          prompt,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Image analysis failed.');
      }
      setAnalysisText(data.text || '');
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(20);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error analyzing image.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">AI Image & Diagram Analyzer</h2>
          <p className="text-sm text-slate-400 mt-1">
            Upload photographs, charts, or science diagrams for multimodal vision analysis and OCR via <span className="font-mono text-cyan-300">gemini-4-hydrogen</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => loadSampleDiagram('cell')}
            className="px-3 py-1.5 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-medium text-cyan-300 transition whitespace-nowrap"
          >
            Load Biology Cell Diagram
          </button>
          <button
            type="button"
            onClick={() => loadSampleDiagram('optics')}
            className="px-3 py-1.5 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-medium text-purple-300 transition whitespace-nowrap"
          >
            Load Physics Prism Diagram
          </button>
        </div>
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form onSubmit={handleAnalyzeImage} className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <label className="flex flex-col items-center justify-center p-6 rounded-xl border-2 border-dashed border-slate-700 hover:border-cyan-400 bg-[#060919]/70 cursor-pointer transition text-center">
            <Upload className="w-7 h-7 text-cyan-400 mb-2" />
            <span className="text-sm font-semibold text-white">Upload Image or Diagram</span>
            <span className="text-xs text-slate-400 mt-1">Supports PNG, JPG, WEBP</span>
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>

          {imagePreviewUrl && (
            <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#060919]">
              <img
                src={imagePreviewUrl}
                alt="Uploaded preview for AI analysis"
                referrerPolicy="no-referrer"
                className="w-full max-h-56 object-contain"
              />
            </div>
          )}

          <div>
            <label htmlFor="image-prompt" className="block text-xs font-medium text-slate-300 mb-1.5">
              Question or Analysis Instruction ({language})
            </label>
            <textarea
              id="image-prompt"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            {isLoading ? 'Analyzing with Gemini 4 Hydrogen...' : 'Analyze Image Now'}
          </button>
        </form>

        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 min-h-[340px] flex flex-col">
          <h3 className="text-base font-bold text-white mb-3">Vision Analysis Output</h3>
          {isLoading ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-12 space-y-3">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-sm text-slate-300">Inspecting visual features, OCR text, and diagrams...</p>
            </div>
          ) : analysisText ? (
            <div className="prose prose-invert max-w-none text-sm text-slate-200 whitespace-pre-wrap leading-relaxed bg-[#060919]/80 p-4 rounded-xl border border-slate-800">
              {analysisText}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-12 text-slate-500">
              <ImageIcon className="w-10 h-10 mb-2 text-slate-600" />
              <p className="text-sm text-slate-300">No image analyzed yet</p>
              <p className="text-xs text-slate-500 mt-1">
                Upload a photo or click "Load Biology Cell Diagram" above to run real Gemini 4 Hydrogen vision analysis.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const SAMPLE_STUDY_DOCUMENT = `CHAPTER 4: ARTIFICIAL INTELLIGENCE & NEURAL ARCHITECTURES (CUET & CS REFERENCE)

1. Introduction to Modern Transformer Architectures
The Transformer architecture, introduced by Vaswani et al. in 2017 ("Attention Is All You Need"), replaced recurrent layers with self-attention mechanisms. Self-attention computes a weighted representation of all tokens in a sequence simultaneously, enabling massive parallelization during training.

2. Scaled Dot-Product Attention
Given Query (Q), Key (K), and Value (V) matrices of dimension d_k:
Attention(Q, K, V) = softmax((Q * K^T) / sqrt(d_k)) * V
Dividing by sqrt(d_k) prevents the dot products from growing too large in magnitude, which would push the softmax function into regions with extremely small gradients.

3. Multimodal Understanding & Context Memory
Modern foundation models such as Gemini 4 Hydrogen natively process interleaved text, images, audio, and PDF documents within a unified token space. Personal memory systems pair retrieval-augmented context with explicit user consent gates so private preferences remain under user control.`;

export const PdfReaderModule: React.FC<SharedToolProps> = ({
  language,
  onEarnXp,
  onRecordTokens,
}) => {
  const [fileName, setFileName] = useState<string>('');
  const [pdfBase64, setPdfBase64] = useState<string>('');
  const [documentText, setDocumentText] = useState<string>('');
  const [analysis, setAnalysis] = useState<PdfAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [qaQuestion, setQaQuestion] = useState('');
  const [qaAnswer, setQaAnswer] = useState('');
  const [qaLoading, setQaLoading] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setErrorMsg(null);

    if (file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = () => {
        const res = String(reader.result || '');
        setPdfBase64(res.split(',')[1] || '');
        setDocumentText(`Uploaded PDF File: ${file.name} (${Math.round(file.size / 1024)} KB)`);
      };
      reader.readAsDataURL(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => {
        setDocumentText(String(reader.result || ''));
        setPdfBase64('');
      };
      reader.readAsText(file);
    }
  };

  const loadSampleChapter = () => {
    setFileName('Chapter_4_AI_and_Neural_Architectures.pdf');
    setDocumentText(SAMPLE_STUDY_DOCUMENT);
    setPdfBase64('');
    setErrorMsg(null);
  };

  const runFullAnalysis = async () => {
    if (!pdfBase64 && !documentText) {
      setErrorMsg('Please upload a PDF/document or click "Load Sample Study PDF" first.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/analyze-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pdfBase64: pdfBase64 || undefined,
          extractedText: documentText || undefined,
          fileName: fileName || 'Document.pdf',
          mode: 'full_analysis',
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'PDF analysis failed.');
      }
      setAnalysis(data.analysis);
      setSelectedAnswers({});
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(30);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to analyze PDF document.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAskDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!qaQuestion.trim()) return;
    setQaLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/analyze-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pdfBase64: pdfBase64 || undefined,
          extractedText: documentText || SAMPLE_STUDY_DOCUMENT,
          fileName: fileName || 'Study_Chapter.pdf',
          mode: 'qa',
          question: qaQuestion,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to answer document question.');
      setQaAnswer(data.answer || '');
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error answering question.');
    } finally {
      setQaLoading(false);
    }
  };

  const handleDownloadNotes = () => {
    if (!analysis) return;
    const content = `# ${fileName || 'RAJU AI Document Notes'}\n\n## Executive Summary\n${
      analysis.executiveSummary
    }\n\n## Important Points\n${analysis.keyPoints.map((p) => `- ${p}`).join('\n')}\n\n## Detailed Study Notes\n${
      analysis.studyNotes
    }\n`;
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(fileName || 'study_notes').replace(/\.[^/.]+$/, '')}_notes.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const searchMatches =
    searchKeyword.trim() && documentText
      ? documentText
          .split('\n')
          .filter((line) => line.toLowerCase().includes(searchKeyword.toLowerCase()))
      : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Advanced PDF Reader & Notes Generator</h2>
          <p className="text-sm text-slate-400 mt-1">
            Upload any PDF textbook or research paper for chapter summaries, key point extraction, MCQs, and downloadable notes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadSampleChapter}
            className="px-3.5 py-2 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-semibold text-cyan-300 transition whitespace-nowrap"
          >
            Load Sample Study PDF
          </button>
          {analysis && (
            <button
              type="button"
              onClick={handleDownloadNotes}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download Notes (.md)
            </button>
          )}
        </div>
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Upload & Search Inside Document (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <label className="flex flex-col items-center justify-center p-5 rounded-xl border-2 border-dashed border-slate-700 hover:border-cyan-400 bg-[#060919]/70 cursor-pointer transition text-center">
              <FileText className="w-7 h-7 text-rose-400 mb-2" />
              <span className="text-sm font-semibold text-white">
                {fileName ? fileName : 'Select PDF or Text Document'}
              </span>
              <span className="text-xs text-slate-400 mt-1">Supports .pdf, .txt, .md</span>
              <input type="file" accept=".pdf,.txt,.md,application/pdf" onChange={handleFileChange} className="hidden" />
            </label>

            <button
              type="button"
              onClick={runFullAnalysis}
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              {isLoading ? 'Generating Summaries, Notes & MCQs...' : 'Analyze Document & Generate MCQs'}
            </button>

            {/* Search inside document */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <label htmlFor="pdf-search" className="block text-xs font-medium text-slate-300">
                Search Inside Document
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="pdf-search"
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="Search keyword or formula..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
                />
              </div>
              {searchKeyword.trim() && (
                <div className="p-2.5 rounded-xl bg-[#060919] border border-slate-800 text-xs space-y-1 max-h-36 overflow-y-auto">
                  {searchMatches.length === 0 ? (
                    <p className="text-slate-500">No occurrences found.</p>
                  ) : (
                    searchMatches.map((line, idx) => (
                      <p key={idx} className="text-cyan-200 border-b border-slate-800/60 pb-1">
                        {line}
                      </p>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Ask Question about Document */}
            <form onSubmit={handleAskDocument} className="pt-2 border-t border-slate-800 space-y-2">
              <label htmlFor="pdf-qa" className="block text-xs font-medium text-slate-300">
                Ask a Question About This Document
              </label>
              <div className="flex gap-2">
                <input
                  id="pdf-qa"
                  type="text"
                  value={qaQuestion}
                  onChange={(e) => setQaQuestion(e.target.value)}
                  placeholder="e.g., Why divide by sqrt(d_k)?"
                  className="flex-1 px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
                />
                <button
                  type="submit"
                  disabled={qaLoading}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold whitespace-nowrap"
                >
                  {qaLoading ? '...' : 'Ask'}
                </button>
              </div>
              {qaAnswer && (
                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-xs text-slate-200 whitespace-pre-wrap">
                  {qaAnswer}
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Right Structured Analysis Results (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {!analysis ? (
            <div className="p-8 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 min-h-[360px] flex flex-col items-center justify-center text-center">
              <FileText className="w-10 h-10 text-slate-600 mb-3" />
              <p className="text-sm font-semibold text-slate-200">Ready for Document Intelligence</p>
              <p className="text-xs text-slate-400 mt-1 max-w-md">
                Upload a PDF or click "Load Sample Study PDF" and then "Analyze Document & Generate MCQs" to extract chapter summaries, study notes, and interactive questions.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Executive Summary */}
              <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-2">
                <h3 className="text-base font-bold text-cyan-300">Executive Summary</h3>
                <p className="text-sm text-slate-200 leading-relaxed">{analysis.executiveSummary}</p>
              </div>

              {/* Key Points */}
              <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-2.5">
                <h3 className="text-base font-bold text-white">Important Points Extracted</h3>
                <ul className="space-y-1.5 text-xs text-slate-200">
                  {analysis.keyPoints.map((pt, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Generated MCQs from PDF */}
              <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-purple-400" />
                  Document Practice MCQs
                </h3>
                <div className="space-y-4">
                  {analysis.mcqs.map((q, qIdx) => {
                    const chosen = selectedAnswers[qIdx];
                    return (
                      <div key={qIdx} className="p-4 rounded-xl bg-[#060919]/80 border border-slate-800 space-y-2.5">
                        <p className="text-xs font-semibold text-white">
                          Q{qIdx + 1}. {q.question}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {q.options.map((opt, oIdx) => {
                            const isPicked = chosen === oIdx;
                            const isRight = q.correctIndex === oIdx;
                            let btnClass = 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700';
                            if (chosen !== undefined) {
                              if (isRight) btnClass = 'bg-emerald-950/70 border-emerald-500/60 text-emerald-200';
                              else if (isPicked) btnClass = 'bg-rose-950/70 border-rose-500/60 text-rose-200';
                            }
                            return (
                              <button
                                key={oIdx}
                                type="button"
                                onClick={() => setSelectedAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))}
                                className={`p-2.5 rounded-lg border text-left text-xs transition ${btnClass}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                        {chosen !== undefined && (
                          <p className="text-xs text-cyan-200 pt-1">
                            <strong>Explanation:</strong> {q.explanation}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const WebResearchModule: React.FC<SharedToolProps> = ({
  language,
  onEarnXp,
  onRecordTokens,
}) => {
  const [query, setQuery] = useState('');
  const [report, setReport] = useState('');
  const [sources, setSources] = useState<Array<{ title: string; uri: string }>>([]);
  const [searchQueries, setSearchQueries] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query.trim(),
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Web research query failed.');
      }
      setReport(data.report || '');
      setSources(data.sources || []);
      setSearchQueries(data.searchQueries || []);
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(25);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Web research failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const presetTopics = [
    'Latest ISRO Gaganyaan & space exploration updates',
    'CUET UG exam pattern and domain subject preparation strategies',
    'Breakthroughs in solid-state battery technology 2026',
    'JLPT Japanese Language Proficiency Test registration and tips',
  ];

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800/80">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Web Research Engine (Google Search Grounding)
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Live web search synthesis with verified source references powered by <span className="font-mono text-cyan-300">gemini-4-hydrogen</span> + <span className="font-mono text-cyan-300">googleSearch</span> grounding.
        </p>
      </div>

      <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Globe className="w-4 h-4 text-cyan-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Enter a research topic, current event, or scientific query..."
            aria-label="Research query"
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0B102B] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition whitespace-nowrap shrink-0 disabled:opacity-50"
        >
          <Search className="w-4 h-4" />
          {isLoading ? 'Researching Live Web...' : 'Run Grounded Research'}
        </button>
      </form>

      {/* Preset Quick Research Buttons */}
      <div className="flex flex-wrap gap-2">
        {presetTopics.map((topic) => (
          <button
            key={topic}
            type="button"
            onClick={() => setQuery(topic)}
            className="px-3 py-1.5 rounded-xl bg-[#0B102B] border border-slate-800 hover:border-cyan-400/60 text-xs text-slate-300 hover:text-white transition"
          >
            {topic}
          </button>
        ))}
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {report && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
            <h3 className="text-base font-bold text-white">Verified Research Report</h3>
            <div className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed bg-[#060919]/80 p-4 rounded-xl border border-slate-800">
              {report}
            </div>
          </div>

          <div className="lg:col-span-4 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white">Source Citations ({sources.length})</h3>
            {sources.length === 0 ? (
              <p className="text-xs text-slate-400">
                No external web links were returned in grounding chunks for this synthesis.
              </p>
            ) : (
              <div className="space-y-2.5">
                {sources.map((src, idx) => (
                  <a
                    key={idx}
                    href={src.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block p-3 rounded-xl bg-[#060919] border border-slate-800 hover:border-cyan-400/60 transition group"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-cyan-300 group-hover:underline truncate">
                        {src.title}
                      </span>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-1 font-mono">{src.uri}</p>
                  </a>
                ))}
              </div>
            )}

            {searchQueries.length > 0 && (
              <div className="pt-3 border-t border-slate-800 space-y-1.5">
                <p className="text-xs font-semibold text-slate-400">Executed Search Queries</p>
                {searchQueries.map((sq, i) => (
                  <p key={i} className="text-xs text-slate-300 font-mono">
                    · {sq}
                  </p>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
