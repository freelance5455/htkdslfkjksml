import React, { useState, useEffect, useCallback } from 'react';
import { Chess, Square, PieceSymbol, Color } from 'chess.js';
import { useApp } from '../context/AppContext';
import { 
  RotateCcw, 
  Trophy, 
  Bot, 
  Users, 
  Swords, 
  Undo2, 
  Sparkles, 
  Flame, 
  ChevronRight,
  ShieldAlert,
  Crown
} from 'lucide-react';

// Unicode Chess Pieces with clean styling
const PIECE_SYMBOLS: Record<string, string> = {
  'w-p': '♙',
  'w-n': '♘',
  'w-b': '♗',
  'w-r': '♖',
  'w-q': '♕',
  'w-k': '♔',
  'b-p': '♟',
  'b-n': '♞',
  'b-b': '♝',
  'b-r': '♜',
  'b-q': '♛',
  'b-k': '♚',
};

const PIECE_NAMES: Record<PieceSymbol, string> = {
  p: 'Pawn',
  n: 'Knight',
  b: 'Bishop',
  r: 'Rook',
  q: 'Queen',
  k: 'King'
};

type GameMode = 'ai' | 'pvp';
type Difficulty = 'easy' | 'medium' | 'hard';

export const ChessGame: React.FC = () => {
  const { user } = useApp();
  const [game, setGame] = useState<Chess>(() => new Chess());
  const [board, setBoard] = useState(game.board());
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [possibleMoves, setPossibleMoves] = useState<Square[]>([]);
  const [gameMode, setGameMode] = useState<GameMode>('ai');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [playerColor] = useState<Color>('w');
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [capturedWhite, setCapturedWhite] = useState<string[]>([]);
  const [capturedBlack, setCapturedBlack] = useState<string[]>([]);
  const [gameResult, setGameResult] = useState<string | null>(null);
  const [isCheck, setIsCheck] = useState(false);

  // Sync board state
  const updateBoardState = useCallback((chessInstance: Chess) => {
    setBoard(chessInstance.board());
    setIsCheck(chessInstance.inCheck());

    if (chessInstance.isCheckmate()) {
      const winner = chessInstance.turn() === 'w' ? 'Black' : 'White';
      setGameResult(`Checkmate! ${winner} wins the campus duel! 🏆`);
    } else if (chessInstance.isDraw()) {
      setGameResult('Stalemate / Draw! Well fought match. 🤝');
    }
  }, []);

  // AI Move Engine
  const makeAiMove = useCallback(() => {
    if (game.isGameOver() || game.turn() === playerColor) return;

    setIsAiThinking(true);
    setTimeout(() => {
      const moves = game.moves({ verbose: true });
      if (moves.length === 0) {
        setIsAiThinking(false);
        return;
      }

      let chosenMove = moves[0];

      if (difficulty === 'easy') {
        // Random move
        chosenMove = moves[Math.floor(Math.random() * moves.length)];
      } else if (difficulty === 'medium') {
        // Prefer captures and checks, otherwise random
        const captureMoves = moves.filter(m => m.captured);
        const checkMoves = moves.filter(m => {
          const testGame = new Chess(game.fen());
          testGame.move(m);
          return testGame.inCheck();
        });

        if (captureMoves.length > 0 && Math.random() < 0.7) {
          chosenMove = captureMoves[Math.floor(Math.random() * captureMoves.length)];
        } else if (checkMoves.length > 0 && Math.random() < 0.6) {
          chosenMove = checkMoves[Math.floor(Math.random() * checkMoves.length)];
        } else {
          chosenMove = moves[Math.floor(Math.random() * moves.length)];
        }
      } else {
        // Hard: Evaluate piece value captures
        const pieceValues: Record<string, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
        let bestScore = -999;

        for (const m of moves) {
          let score = 0;
          if (m.captured) {
            score += (pieceValues[m.captured] || 1) * 10 - (pieceValues[m.piece] || 1);
          }
          if (m.san.includes('+')) score += 5;
          if (['e4', 'd4', 'e5', 'd5'].includes(m.to)) score += 2; // Center control

          // Add slight jitter for unpredictability
          score += Math.random() * 2;

          if (score > bestScore) {
            bestScore = score;
            chosenMove = m;
          }
        }
      }

      // Execute AI Move
      const result = game.move(chosenMove);
      if (result) {
        if (result.captured) {
          setCapturedWhite(prev => [...prev, result.captured as string]);
        }
        setMoveHistory(prev => [...prev, result.san]);
        updateBoardState(game);
      }
      setIsAiThinking(false);
    }, 450);
  }, [game, difficulty, playerColor, updateBoardState]);

  // Handle Square Click
  const handleSquareClick = (square: Square) => {
    if (game.isGameOver() || (gameMode === 'ai' && game.turn() !== playerColor)) {
      return;
    }

    const pieceOnSquare = game.get(square);

    // If a piece was already selected
    if (selectedSquare) {
      if (selectedSquare === square) {
        // Deselect
        setSelectedSquare(null);
        setPossibleMoves([]);
        return;
      }

      // Attempt to move
      try {
        const move = game.move({
          from: selectedSquare,
          to: square,
          promotion: 'q', // auto-promote to Queen for speed
        });

        if (move) {
          if (move.captured) {
            if (move.color === 'w') {
              setCapturedBlack(prev => [...prev, move.captured as string]);
            } else {
              setCapturedWhite(prev => [...prev, move.captured as string]);
            }
          }
          setMoveHistory(prev => [...prev, move.san]);
          setSelectedSquare(null);
          setPossibleMoves([]);
          updateBoardState(game);

          // Trigger AI if in AI mode
          if (gameMode === 'ai' && !game.isGameOver()) {
            setTimeout(makeAiMove, 300);
          }
          return;
        }
      } catch {
        // Invalid move, check if selecting another of player's own pieces
      }
    }

    // Select piece if it belongs to current player's turn
    if (pieceOnSquare && pieceOnSquare.color === game.turn()) {
      setSelectedSquare(square);
      const moves = game.moves({ square, verbose: true });
      setPossibleMoves(moves.map(m => m.to as Square));
    } else {
      setSelectedSquare(null);
      setPossibleMoves([]);
    }
  };

  // Reset Game
  const handleResetGame = () => {
    const newG = new Chess();
    setGame(newG);
    setBoard(newG.board());
    setSelectedSquare(null);
    setPossibleMoves([]);
    setMoveHistory([]);
    setCapturedWhite([]);
    setCapturedBlack([]);
    setGameResult(null);
    setIsCheck(false);
  };

  // Undo Last Move
  const handleUndoMove = () => {
    if (moveHistory.length === 0) return;
    if (gameMode === 'ai') {
      game.undo(); // Undo AI
      game.undo(); // Undo User
      setMoveHistory(prev => prev.slice(0, -2));
    } else {
      game.undo();
      setMoveHistory(prev => prev.slice(0, -1));
    }
    updateBoardState(game);
    setSelectedSquare(null);
    setPossibleMoves([]);
    setGameResult(null);
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Game Header Bar */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900/90 via-slate-950 to-slate-900 border border-cyan-500/30 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Swords className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Secret Campus Chess</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
                  LIVE
                </span>
              </h2>
              <p className="text-xs text-slate-400">Challenge campus minds anonymously</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleResetGame}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all text-xs flex items-center gap-1"
              title="Restart Game"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={handleUndoMove}
              disabled={moveHistory.length === 0}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all text-xs disabled:opacity-40"
              title="Undo Move"
            >
              <Undo2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode & Difficulty Selector */}
        <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
          <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              onClick={() => { setGameMode('ai'); handleResetGame(); }}
              className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 font-semibold transition-all ${
                gameMode === 'ai' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              <span>vs AI Bot</span>
            </button>
            <button
              onClick={() => { setGameMode('pvp'); handleResetGame(); }}
              className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 font-semibold transition-all ${
                gameMode === 'pvp' ? 'bg-pink-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>2 Players</span>
            </button>
          </div>

          {gameMode === 'ai' && (
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              {(['easy', 'medium', 'hard'] as Difficulty[]).map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`flex-1 py-1.5 rounded-lg uppercase text-[10px] font-bold transition-all ${
                    difficulty === d 
                      ? 'bg-purple-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Opponent Info / Status */}
      <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-slate-800 flex items-center justify-center text-sm">
            {gameMode === 'ai' ? '🤖' : '👤'}
          </div>
          <div>
            <div className="font-bold text-slate-200">
              {gameMode === 'ai' ? `Campus Bot (${difficulty.toUpperCase()})` : 'Player 2 (Black)'}
            </div>
            <div className="text-[10px] text-slate-400">
              {game.turn() === 'b' ? (isAiThinking ? 'Calculating move...' : 'Thinking...') : 'Waiting for turn'}
            </div>
          </div>
        </div>

        {/* Captured Black Pieces */}
        <div className="flex items-center gap-0.5 text-base">
          {capturedBlack.map((p, i) => (
            <span key={i} className="text-slate-300">{PIECE_SYMBOLS[`b-${p}`]}</span>
          ))}
        </div>
      </div>

      {/* Check / Status Notification */}
      {isCheck && !gameResult && (
        <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center justify-center gap-2 font-bold animate-pulse">
          <ShieldAlert className="w-4 h-4" />
          <span>CHECK! King under immediate threat!</span>
        </div>
      )}

      {/* Game Over Dialog */}
      {gameResult && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950 via-purple-950 to-slate-950 border border-cyan-400 text-center space-y-2 animate-in zoom-in-95">
          <div className="inline-flex p-2 rounded-full bg-cyan-500/20 text-cyan-300 mb-1">
            <Trophy className="w-6 h-6 text-amber-400" />
          </div>
          <h3 className="text-base font-bold text-white">{gameResult}</h3>
          <p className="text-xs text-slate-300">Earned +50 Campus Gamer Respect!</p>
          <button
            onClick={handleResetGame}
            className="mt-2 px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20"
          >
            Play Again
          </button>
        </div>
      )}

      {/* CHESSBOARD (8x8 Grid) */}
      <div className="p-2 sm:p-3 rounded-3xl bg-slate-950 border border-slate-800 shadow-2xl">
        <div className="grid grid-cols-8 grid-rows-8 gap-0 rounded-2xl overflow-hidden border border-slate-700/60 aspect-square w-full max-w-[420px] mx-auto select-none">
          {board.map((row, rowIndex) =>
            row.map((piece, colIndex) => {
              const file = String.fromCharCode('a'.charCodeAt(0) + colIndex);
              const rank = 8 - rowIndex;
              const squareName = `${file}${rank}` as Square;
              const isDark = (rowIndex + colIndex) % 2 === 1;
              const isSelected = selectedSquare === squareName;
              const isTarget = possibleMoves.includes(squareName);

              return (
                <button
                  key={squareName}
                  type="button"
                  onClick={() => handleSquareClick(squareName)}
                  className={`relative flex items-center justify-center transition-all ${
                    isDark ? 'bg-[#1e293b]' : 'bg-[#334155]'
                  } ${
                    isSelected ? '!bg-cyan-600/70 shadow-inner' : ''
                  } ${
                    isTarget ? '!bg-emerald-500/40 hover:!bg-emerald-500/60' : ''
                  } active:scale-95`}
                >
                  {/* File & Rank indicators on edges */}
                  {colIndex === 0 && (
                    <span className="absolute top-0.5 left-1 text-[8px] font-mono font-bold text-slate-400 opacity-60">
                      {rank}
                    </span>
                  )}
                  {rowIndex === 7 && (
                    <span className="absolute bottom-0.5 right-1 text-[8px] font-mono font-bold text-slate-400 opacity-60">
                      {file}
                    </span>
                  )}

                  {/* Possible Move Target Dot */}
                  {isTarget && !piece && (
                    <div className="w-3 h-3 rounded-full bg-emerald-400/80 shadow-sm" />
                  )}

                  {/* Chess Piece Symbol */}
                  {piece && (
                    <span
                      className={`text-2xl sm:text-3xl leading-none select-none transition-transform ${
                        piece.color === 'w' 
                          ? 'text-cyan-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]' 
                          : 'text-pink-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                      } ${isSelected ? 'scale-115' : ''}`}
                    >
                      {PIECE_SYMBOLS[`${piece.color}-${piece.type}`]}
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Player (White) Info */}
      <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center text-sm font-bold">
            {user.avatarEmoji || '🦊'}
          </div>
          <div>
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <span>@{user.avatarName || 'Campus Student'} (White)</span>
              <Crown className="w-3 h-3 text-cyan-400" />
            </div>
            <div className="text-[10px] text-slate-400">
              {game.turn() === 'w' ? 'Your turn to move!' : 'Opponent moving...'}
            </div>
          </div>
        </div>

        {/* Captured White Pieces */}
        <div className="flex items-center gap-0.5 text-base">
          {capturedWhite.map((p, i) => (
            <span key={i} className="text-slate-300">{PIECE_SYMBOLS[`w-${p}`]}</span>
          ))}
        </div>
      </div>

      {/* Move History / Notation Log */}
      {moveHistory.length > 0 && (
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Move History</span>
            <span className="font-mono text-cyan-400">{moveHistory.length} moves</span>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto font-mono text-xs">
            {moveHistory.map((m, idx) => (
              <span 
                key={idx} 
                className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-[11px]"
              >
                {idx % 2 === 0 ? `${Math.floor(idx / 2) + 1}. ` : ''}{m}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
