"use client";

import { useEffect, useState } from "react";
import { Lock, Delete, ShieldCheck } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";

const PIN_KEY = "ct_passcode";
export const getStoredPin = () =>
  (typeof window !== "undefined" && localStorage.getItem(PIN_KEY)) || "1234";
export const setStoredPin = (pin: string) => localStorage.setItem(PIN_KEY, pin);

export default function PasscodeGatekeeper() {
  const locked = useTradingStore((s) => s.locked);
  const setLocked = useTradingStore((s) => s.setLocked);
  const [entry, setEntry] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    if (entry.length === 4) {
      if (entry === getStoredPin()) {
        setLocked(false);
        setEntry("");
        setError(false);
      } else {
        setError(true);
        setTimeout(() => { setEntry(""); setError(false); }, 600);
      }
    }
  }, [entry, setLocked]);

  if (!locked) return null;

  const press = (d: string) => entry.length < 4 && setEntry(entry + d);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#0f172a]/95 backdrop-blur-sm">
      <div className="slide-in w-80 rounded-2xl border border-slate-700 bg-slate-900 p-8 text-center shadow-2xl">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10">
          <Lock className="h-7 w-7 text-emerald-400" />
        </div>
        <h2 className="text-lg font-bold text-white">מגן קוד פרטי</h2>
        <p className="mt-1 text-xs text-slate-400">הזן קוד בן 4 ספרות לפתיחת האפליקציה (ברירת מחדל: 1234)</p>

        <div className={`my-6 flex justify-center gap-3 ${error ? "animate-pulse" : ""}`} dir="ltr">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={`h-4 w-4 rounded-full border-2 transition-colors ${
                entry.length > i
                  ? error ? "border-red-500 bg-red-500" : "border-emerald-400 bg-emerald-400"
                  : "border-slate-600"
              }`}
            />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-3" dir="ltr">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
            <button
              key={d}
              onClick={() => press(d)}
              className="rounded-xl bg-slate-800 py-3 text-lg font-semibold text-white transition hover:bg-slate-700 active:scale-95"
            >
              {d}
            </button>
          ))}
          <div />
          <button
            onClick={() => press("0")}
            className="rounded-xl bg-slate-800 py-3 text-lg font-semibold text-white transition hover:bg-slate-700 active:scale-95"
          >
            0
          </button>
          <button
            onClick={() => setEntry(entry.slice(0, -1))}
            className="flex items-center justify-center rounded-xl bg-slate-800 py-3 text-slate-400 transition hover:bg-slate-700 active:scale-95"
          >
            <Delete className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="h-3.5 w-3.5" />
          הקוד נשמר מקומית במכשיר בלבד (localStorage)
        </div>
      </div>
    </div>
  );
}
