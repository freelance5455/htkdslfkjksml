import React, { useState } from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { ShieldCheck, Lock, KeyRound, Delete, CheckCircle2, AlertCircle, X } from 'lucide-react';

interface ParentPinModalProps {
  isOpen: boolean;
  onClose?: () => void;
  isLockedScreen?: boolean;
}

export const ParentPinModal: React.FC<ParentPinModalProps> = ({
  isOpen,
  onClose,
  isLockedScreen = false
}) => {
  const { 
    unlockParentDashboard, 
    setParentPin, 
    parentPin, 
    language 
  } = useParentControl();

  const [enteredPin, setEnteredPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isChangingPin, setIsChangingPin] = useState(false);
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const isAr = language === 'ar';

  const handleDigit = (digit: string) => {
    if (enteredPin.length < 6) {
      const next = enteredPin + digit;
      setEnteredPin(next);
      setErrorMsg('');

      // Auto-submit on 4 digits if pin is 4 digits
      if (next.length === parentPin.length) {
        if (unlockParentDashboard(next)) {
          setEnteredPin('');
          if (onClose) onClose();
        } else {
          setErrorMsg(isAr ? 'الرمز السري غير صحيح! الرمز الافتراضي هو 1234' : 'Incorrect PIN! Default is 1234');
          setTimeout(() => setEnteredPin(''), 500);
        }
      }
    }
  };

  const handleDelete = () => {
    setEnteredPin(prev => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setEnteredPin('');
    setErrorMsg('');
  };

  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentPinInput !== parentPin) {
      setErrorMsg(isAr ? 'الرمز الحالي غير صحيح' : 'Current PIN is incorrect');
      return;
    }
    if (newPinInput.length < 4) {
      setErrorMsg(isAr ? 'الرمز الجديد يجب أن يتكون من 4 أرقام على الأقل' : 'New PIN must be at least 4 digits');
      return;
    }
    if (newPinInput !== confirmPinInput) {
      setErrorMsg(isAr ? 'الرمز الجديد وتأكيده غير متطابقين' : 'New PINs do not match');
      return;
    }

    setParentPin(newPinInput);
    setSuccessMsg(isAr ? 'تم تغيير رمز الحماية بنجاح!' : 'PIN successfully changed!');
    setTimeout(() => {
      setIsChangingPin(false);
      setCurrentPinInput('');
      setNewPinInput('');
      setConfirmPinInput('');
      setSuccessMsg('');
      if (onClose) onClose();
    }, 1200);
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 ${
      isLockedScreen 
        ? 'bg-slate-950/90 backdrop-blur-xl' 
        : 'bg-black/60 backdrop-blur-sm'
    }`}>
      <div 
        id="parent-pin-modal-card"
        className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200/80 dark:border-slate-800 text-center animate-in fade-in zoom-in-95 duration-200 transition-colors"
      >
        {!isLockedScreen && onClose && (
          <div className="flex justify-end mb-1">
            <button 
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        <div className="mx-auto w-14 h-14 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center mb-3 shadow-xs">
          <Lock className="w-7 h-7 text-indigo-600 dark:text-indigo-400" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1">
          {isChangingPin 
            ? (isAr ? 'تغيير رمز حماية ولي الأمر' : 'Change Parent PIN')
            : (isAr ? 'تأكيد هوية ولي الأمر' : 'Parent Authentication Required')}
        </h3>
        
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 leading-relaxed">
          {isChangingPin
            ? (isAr ? 'قم بإدخال الرمز الحالي ثم حدد رمزاً جديداً' : 'Enter current PIN and choose a new 4-digit code')
            : (isAr ? 'لوحة التحكم محمية برمز PIN لمنع تعديل إعدادات الأطفال بدون إذن (الافتراضي: 1234)' : 'Dashboard is secured with Master PIN to prevent child tampering (Default: 1234)')}
        </p>

        {isChangingPin ? (
          <form onSubmit={handleSaveNewPin} className="space-y-3 text-start">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                {isAr ? 'الرمز الحالي' : 'Current PIN'}
              </label>
              <input
                type="password"
                maxLength={6}
                value={currentPinInput}
                onChange={e => setCurrentPinInput(e.target.value)}
                placeholder="1234"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-indigo-500 font-mono tracking-widest text-center"
                required
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                {isAr ? 'الرمز الجديد (4 أرقام)' : 'New PIN (4 digits)'}
              </label>
              <input
                type="password"
                maxLength={6}
                value={newPinInput}
                onChange={e => setNewPinInput(e.target.value)}
                placeholder="••••"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-indigo-500 font-mono tracking-widest text-center"
                required
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                {isAr ? 'تأكيد الرمز الجديد' : 'Confirm New PIN'}
              </label>
              <input
                type="password"
                maxLength={6}
                value={confirmPinInput}
                onChange={e => setConfirmPinInput(e.target.value)}
                placeholder="••••"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-indigo-500 font-mono tracking-widest text-center"
                required
              />
            </div>

            {errorMsg && (
              <div className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 p-2 rounded-xl border border-rose-100 dark:border-rose-900/50">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 p-2 rounded-xl border border-emerald-100 dark:border-emerald-900/50">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-700 transition-colors shadow-xs"
              >
                {isAr ? 'حفظ الرمز' : 'Save PIN'}
              </button>
              <button
                type="button"
                onClick={() => setIsChangingPin(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </form>
        ) : (
          <div>
            {/* PIN Dots Indicator */}
            <div className="flex justify-center gap-3 mb-4">
              {[0, 1, 2, 3].map((idx) => {
                const filled = enteredPin.length > idx;
                return (
                  <div
                    key={idx}
                    className={`w-3.5 h-3.5 rounded-full border-2 transition-all ${
                      filled 
                        ? 'bg-indigo-600 border-indigo-600 scale-110 shadow-xs' 
                        : 'border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800'
                    }`}
                  />
                );
              })}
            </div>

            {errorMsg && (
              <div className="mb-3 text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 p-2 rounded-xl border border-rose-100 dark:border-rose-900/50 flex items-center justify-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto mb-4">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  onClick={() => handleDigit(digit)}
                  className="h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600 dark:hover:text-indigo-400 text-slate-800 dark:text-slate-100 font-bold text-lg border border-slate-200/60 dark:border-slate-700 active:scale-95 transition-all shadow-xs"
                >
                  {digit}
                </button>
              ))}
              <button
                onClick={handleClear}
                className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-850 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 font-medium text-xs active:scale-95 transition-all border border-slate-200/60 dark:border-slate-700"
              >
                {isAr ? 'مسح' : 'Clear'}
              </button>
              <button
                onClick={() => handleDigit('0')}
                className="h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600 dark:hover:text-indigo-400 text-slate-800 dark:text-slate-100 font-bold text-lg border border-slate-200/60 dark:border-slate-700 active:scale-95 transition-all shadow-xs"
              >
                0
              </button>
              <button
                onClick={handleDelete}
                className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-850 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center active:scale-95 transition-all border border-slate-200/60 dark:border-slate-700"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>

            {/* Change PIN toggle */}
            <button
              onClick={() => setIsChangingPin(true)}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 font-semibold flex items-center justify-center gap-1 mx-auto transition-colors"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isAr ? 'تغيير الرمز السري' : 'Change Master PIN'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
