import React, { useState } from 'react';
import { 
  Printer, 
  Share2, 
  X, 
  CheckCircle2, 
  Tv, 
  QrCode, 
  Download, 
  Smartphone,
  Copy,
  Check
} from 'lucide-react';
import { Payment, Customer, BusinessProfile, Language } from '../types';
import { translations } from '../translations';
import { receiptService } from '../services/receiptService';

import { WhatsAppDispatchPayload } from './WhatsAppDispatchModal';

interface ReceiptModalProps {
  payment: Payment;
  customer?: Customer;
  profile: BusinessProfile;
  language: Language;
  onClose: () => void;
  onOpenWhatsAppModal?: (payload: WhatsAppDispatchPayload) => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  payment,
  customer,
  profile,
  language,
  onClose,
  onOpenWhatsAppModal,
}) => {
  const t = translations[language];
  const [receiptStyle, setReceiptStyle] = useState<'thermal' | 'deluxe'>('thermal');
  const [copiedUpi, setCopiedUpi] = useState(false);

  const qrUrl = receiptService.getUpiQrCodeUrl(profile.upiId, profile.name, payment.amount, payment.receiptNo);
  const whatsappUrl = customer ? receiptService.getWhatsAppReceiptUrl(payment, customer, profile) : '#';

  const handlePrint = () => {
    window.print();
  };

  const copyUpiId = () => {
    navigator.clipboard.writeText(profile.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden my-6">
        
        {/* Modal Top Bar - Hidden during print */}
        <div className="no-print p-4 bg-slate-850 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setReceiptStyle('thermal')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                receiptStyle === 'thermal' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              Thermal 80mm
            </button>
            <button
              onClick={() => setReceiptStyle('deluxe')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                receiptStyle === 'deluxe' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              Standard Invoice
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.printReceipt}</span>
            </button>
            {customer && (
              <button
                onClick={() => {
                  if (onOpenWhatsAppModal) {
                    onOpenWhatsAppModal({
                      mode: 'RECEIPT',
                      customer,
                      payment,
                    });
                  } else {
                    window.open(whatsappUrl, '_blank');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 text-xs font-black transition shadow-sm"
                title="Send Receipt directly via WhatsApp"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper Container */}
        <div className="p-4 sm:p-6 bg-slate-950 flex justify-center overflow-x-auto">
          
          {/* THE PRINTABLE RECEIPT CONTENT (ID: printable-receipt for @media print) */}
          <div
            id="printable-receipt"
            className={
              receiptStyle === 'thermal'
                ? 'w-full max-w-[340px] bg-white text-slate-900 p-5 rounded-lg shadow-xl font-mono text-xs border border-slate-300'
                : 'w-full max-w-[420px] bg-white text-slate-900 p-6 rounded-lg shadow-xl text-xs border border-slate-300'
            }
          >
            {/* Header */}
            <div className="text-center pb-3 border-b-2 border-dashed border-slate-400 space-y-1">
              <h2 className="font-black text-sm tracking-wider uppercase">
                {profile.name}
              </h2>
              <p className="text-[10px] text-slate-600 font-sans">
                {profile.tagline}
              </p>
              <p className="text-[10px] text-slate-700">
                {profile.address}, {profile.village}, {profile.district} - {profile.pincode}
              </p>
              <p className="text-[10px] font-bold text-slate-900">
                Mobile: {profile.phone}
              </p>
              {profile.gstin && (
                <p className="text-[9px] text-slate-500">
                  GSTIN: {profile.gstin}
                </p>
              )}
            </div>

            {/* Receipt Subtitle Badge */}
            <div className="text-center py-2 border-b border-dashed border-slate-300">
              <span className="font-bold text-[11px] tracking-widest uppercase bg-slate-100 px-3 py-0.5 rounded">
                PAYMENT RECEIPT
              </span>
            </div>

            {/* Receipt Info Grid */}
            <div className="py-3 border-b border-dashed border-slate-300 space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Receipt No:</span>
                <span className="font-bold">{payment.receiptNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date &amp; Time:</span>
                <span>{receiptService.formatDate(payment.paymentDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Billing Cycle:</span>
                <span className="font-bold">{payment.billingMonth}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer ID:</span>
                <span className="font-bold">{payment.customerCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer Name:</span>
                <span className="font-bold text-right">{payment.customerName}</span>
              </div>
              {customer && (
                <>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Area / Street:</span>
                    <span>{customer.area}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Service:</span>
                    <span className="font-bold">{customer.serviceType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Plan:</span>
                    <span>{customer.planName}</span>
                  </div>
                </>
              )}
            </div>

            {/* Amount Calculation Box */}
            <div className="py-3 border-b-2 border-dashed border-slate-400 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-600">Payment Mode:</span>
                <span className="font-bold uppercase">
                  {payment.paymentMethod} {payment.upiRefNo ? `(${payment.upiRefNo})` : ''}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 px-3 bg-slate-100 rounded">
                <span className="font-bold text-sm">AMOUNT RECEIVED:</span>
                <span className="font-black text-base text-slate-950 font-sans">
                  {receiptService.formatCurrency(payment.amount)}
                </span>
              </div>
              {customer && (
                <div className="flex justify-between text-[11px] pt-1">
                  <span className="text-slate-600">Remaining Dues:</span>
                  <span className={`font-bold font-sans ${customer.totalOutstanding > 0 ? 'text-red-600' : 'text-green-700'}`}>
                    {receiptService.formatCurrency(customer.totalOutstanding)}
                  </span>
                </div>
              )}
            </div>

            {/* QR Code and Verification */}
            <div className="py-3 text-center space-y-2 border-b border-dashed border-slate-300">
              <p className="text-[10px] text-slate-600">
                Scan to pay next dues via PhonePe / GPay:
              </p>
              <div className="flex justify-center">
                <img
                  src={qrUrl}
                  alt="UPI QR Code"
                  className="w-24 h-24 border border-slate-300 rounded p-1 bg-white"
                />
              </div>
              <p className="text-[10px] font-bold text-slate-800">
                UPI ID: {profile.upiId}
              </p>
            </div>

            {/* Sign and Footer */}
            <div className="pt-3 text-center space-y-2">
              <div className="flex justify-between items-end pt-4 pb-2 text-[10px] text-slate-500">
                <span>Collector: {payment.collectedBy}</span>
                <span className="border-t border-slate-400 px-3">Authorized Signature</span>
              </div>
              <p className="text-[9px] text-slate-500 italic">
                {profile.receiptFooterText}
              </p>
              <p className="text-[9px] font-bold text-slate-700">
                *** COMPUTER GENERATED OFFICIAL RECEIPT ***
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
