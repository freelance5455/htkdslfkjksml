import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';
import { SaleTransaction, StoreSettings } from '../types';
import { X, Printer, CheckCircle2, RotateCcw, Store } from 'lucide-react';

interface ReceiptModalProps {
  sale: SaleTransaction;
  settings: StoreSettings;
  onClose: () => void;
  onRefund?: (saleId: string) => void;
  onNavigateToSettings?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  sale,
  settings,
  onClose,
  onRefund,
  onNavigateToSettings
}) => {
  const barcodeRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (barcodeRef.current && sale.receiptNumber) {
      try {
        JsBarcode(barcodeRef.current, sale.receiptNumber, {
          format: 'CODE128',
          lineColor: '#1e293b',
          width: 1.5,
          height: 35,
          displayValue: false,
          margin: 0
        });
      } catch (e) {
        console.error('Barcode render error:', e);
      }
    }
  }, [sale.receiptNumber]);

  const handlePrint = () => {
    window.print();
  };

  const isRefunded = sale.status === 'refunded';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <CheckCircle2 className={`w-5 h-5 ${isRefunded ? 'text-amber-400' : 'text-emerald-400'}`} />
            <h3 className="font-bold text-slate-100">
              {isRefunded ? 'Refunded Transaction' : 'Transaction Receipt'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Paper Receipt Box */}
          <div
            id="printableArea"
            className="bg-white text-slate-900 font-mono p-5 rounded-xl border border-slate-200 shadow-md text-xs space-y-3"
          >
            {/* Header info */}
            <div className="text-center space-y-1 pb-3 border-b border-dashed border-slate-300">
              <h2 className="text-base font-extrabold uppercase tracking-wider text-slate-950">
                {settings.storeName}
              </h2>
              {settings.tagline && <p className="text-[11px] text-slate-700 font-medium">{settings.tagline}</p>}
              {settings.receiptHeaderNote && (
                <p className="text-[10px] text-slate-500 uppercase tracking-widest border-y border-slate-200 py-0.5 my-1">
                  {settings.receiptHeaderNote}
                </p>
              )}
              {settings.address && <p className="text-[10px] text-slate-600">{settings.address}</p>}
              <div className="text-[10px] text-slate-600 flex flex-wrap justify-center gap-x-2">
                {settings.phone && <span>Tel: {settings.phone}</span>}
                {settings.email && <span>Email: {settings.email}</span>}
              </div>
              {settings.tin && (
                <p className="text-[10px] text-slate-600 font-semibold">{settings.tin}</p>
              )}
              <div className="pt-2 text-[10px] text-slate-500 flex justify-between border-t border-slate-200 mt-1">
                <span>{new Date(sale.timestamp).toLocaleString()}</span>
                <span className="font-bold text-slate-700">{sale.receiptNumber}</span>
              </div>
              {sale.cashierNote && (
                <div className="text-[10px] text-slate-600 text-left pt-0.5">
                  Ref / Note: <span className="font-semibold">{sale.cashierNote}</span>
                </div>
              )}
              {isRefunded && (
                <div className="bg-amber-100 text-amber-800 font-bold py-1 px-2 rounded text-center text-[10px] uppercase mt-1">
                  *** REFUNDED / VOIDED TRANSACTION ***
                </div>
              )}
            </div>

            {/* Line Items */}
            <div className="space-y-2 py-1 border-b border-dashed border-slate-300">
              <div className="flex justify-between font-bold text-slate-700 text-[11px]">
                <span>ITEM</span>
                <span>TOTAL</span>
              </div>
              {sale.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start text-[11px]">
                  <div className="flex-1 pr-2">
                    <span className="font-bold text-slate-900">{item.name}</span>
                    <div className="text-[10px] text-slate-500">
                      {item.quantity} x {settings.currency}{item.price.toFixed(2)}
                    </div>
                  </div>
                  <span className="font-bold text-slate-950">
                    {settings.currency}{item.subtotal.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            {/* Totals Summary */}
            <div className="space-y-1 pt-1 border-b border-dashed border-slate-300 pb-2 text-[11px]">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span>{settings.currency}{sale.subtotal.toFixed(2)}</span>
              </div>
              {sale.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount:</span>
                  <span>-{settings.currency}{sale.discount.toFixed(2)}</span>
                </div>
              )}
              {sale.tax > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Tax ({settings.taxRate}%):</span>
                  <span>{settings.currency}{sale.tax.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-black text-slate-950 pt-1 border-t border-slate-300">
                <span>TOTAL:</span>
                <span className="text-base">{settings.currency}{sale.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Payment Details */}
            <div className="space-y-1 text-[10px] text-slate-600 pb-2">
              <div className="flex justify-between">
                <span>Payment Method:</span>
                <span className="uppercase font-bold text-slate-800">{sale.paymentMethod}</span>
              </div>
              {sale.paymentMethod === 'cash' && (
                <>
                  <div className="flex justify-between">
                    <span>Cash Tendered:</span>
                    <span>{settings.currency}{sale.amountPaid.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>Change:</span>
                    <span>{settings.currency}{sale.change.toFixed(2)}</span>
                  </div>
                </>
              )}
            </div>

            {/* Barcode & Footer Note */}
            <div className="pt-2 text-center space-y-2">
              <div className="flex justify-center">
                <svg ref={barcodeRef} className="max-w-[180px] h-8"></svg>
              </div>
              <p className="text-[10px] text-slate-500 leading-tight">
                {settings.receiptFooter}
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={handlePrint}
              className="flex-1 py-3 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Receipt
            </button>
            {onNavigateToSettings && (
              <button
                onClick={() => {
                  onClose();
                  onNavigateToSettings();
                }}
                className="py-3 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition cursor-pointer"
                title="Change store name, address, phone & footer on receipts"
              >
                <Store className="w-3.5 h-3.5 text-cyan-400" />
                Store Info
              </button>
            )}
            {onRefund && !isRefunded && (
              <button
                onClick={() => {
                  if (confirm('Void and refund this transaction? Inventory stock will be restored.')) {
                    onRefund(sale.id);
                  }
                }}
                className="py-3 px-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-rose-500/20 transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Refund
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
