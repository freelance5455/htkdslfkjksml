import React, { useState } from 'react';
import { CheckCircle, X, Share2, Copy, Check, Download, ShieldCheck } from 'lucide-react';
import { WithdrawalRecord } from '../types';
import { triggerHaptic, soundEngine } from '../utils/audio';

interface ReceiptModalProps {
  receipt: WithdrawalRecord | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ receipt, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!receipt) return null;

  const isEasypaisa = receipt.method === 'easypaisa';
  const brandColor = isEasypaisa ? '#00C25E' : '#ED1C24';
  const bankTitle = isEasypaisa ? 'Telenor Microfinance Bank' : 'Mobilink Microfinance Bank';

  const handleCopy = () => {
    triggerHaptic('light');
    const text = `Tap Tap Cash Withdrawal Receipt\nTransaction ID: ${receipt.trxId}\nMethod: ${receipt.methodName}\nAmount: PKR ${receipt.amountPKR}\nTo: ${receipt.accountTitle} (${receipt.accountNumber})\nStatus: Successful`;
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    triggerHaptic('light');
    if (navigator.share) {
      navigator.share({
        title: 'Tap Tap Cash Payout Receipt',
        text: `I just withdrew Rs. ${receipt.amountPKR} to my ${receipt.methodName} account on Tap Tap Cash! Trx ID: ${receipt.trxId}`,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl overflow-hidden shadow-2xl">
        {/* Receipt Header Banner */}
        <div
          className="p-5 text-center text-white relative"
          style={{
            background: isEasypaisa
              ? 'linear-gradient(135deg, #00C25E 0%, #008742 100%)'
              : 'linear-gradient(135deg, #ED1C24 0%, #B30006 100%)',
          }}
        >
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="absolute top-3.5 right-3.5 w-7 h-7 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-12 h-12 bg-white rounded-2xl mx-auto mb-2 p-1.5 shadow-lg flex items-center justify-center">
            {receipt.method === 'easypaisa' ? (
              <img
                src="/src/assets/images/easypaisa_badge_1791924592372.jpg"
                alt="Easypaisa"
                className="w-full h-full object-contain rounded-xl"
              />
            ) : receipt.method === 'jazzcash' ? (
              <img
                src="/src/assets/images/jazzcash_badge_1791924591954.jpg"
                alt="JazzCash"
                className="w-full h-full object-contain rounded-xl"
              />
            ) : (
              <span className="text-slate-900 font-black text-sm">BANK</span>
            )}
          </div>

          <h2 className="text-base font-extrabold tracking-tight font-display">
            {receipt.methodName} E-Receipt
          </h2>
          <p className="text-[11px] text-white/90 font-medium">
            {bankTitle} · 1Link Switch
          </p>
        </div>

        {/* Receipt Content */}
        <div className="p-5 space-y-4">
          {/* Amount Box */}
          <div className="text-center py-2 bg-slate-950/60 border border-slate-800 rounded-2xl">
            <span className="text-xs text-slate-400 font-medium">Cash Transferred</span>
            <div className="text-3xl font-black text-emerald-400 font-mono-num font-display mt-0.5">
              Rs. {receipt.amountPKR.toFixed(2)}
            </div>
            <div className="inline-flex items-center gap-1 mt-1 text-[11px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
              <CheckCircle className="w-3 h-3 text-emerald-400" />
              <span>Transferred Successfully</span>
            </div>
          </div>

          {/* Details Table */}
          <div className="space-y-2 text-xs divide-y divide-slate-800/80">
            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Transaction ID:</span>
              <span className="font-mono text-slate-200 font-bold tracking-tight">
                {receipt.trxId}
              </span>
            </div>

            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Account Title:</span>
              <span className="font-semibold text-white">{receipt.accountTitle}</span>
            </div>

            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Receiver Account:</span>
              <span className="font-mono text-slate-200 font-semibold">
                {receipt.accountNumber}
              </span>
            </div>

            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Coins Deducted:</span>
              <span className="font-mono text-amber-400 font-bold">
                {receipt.coinsDebited.toLocaleString()} Coins
              </span>
            </div>

            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Processing Fee:</span>
              <span className="font-semibold text-emerald-400">Rs. 0 (100% Free)</span>
            </div>

            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-400">Settlement Time:</span>
              <span className="text-slate-300 font-mono text-[11px]">
                {new Date(receipt.timestamp).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Verification Badge */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 flex items-center gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Digital seal authenticated by State Bank of Pakistan electronic funds regulations.</span>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleCopy}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Info'}</span>
            </button>

            <button
              onClick={handleShare}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share Receipt</span>
            </button>
          </div>

          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs hover:brightness-105 transition-all shadow-md"
          >
            Continue Playing & Earning
          </button>
        </div>
      </div>
    </div>
  );
};
