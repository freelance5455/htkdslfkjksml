import React from 'react';
import { CheckCircle2, Download, Printer, Share2, X, Wallet, ShieldCheck } from 'lucide-react';
import { Transaction } from '../types';
import { formatRupiah } from '../utils/formatters';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction,
}) => {
  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const isIncome = transaction.type === 'topup' || transaction.type === 'qris_receive' || transaction.type === 'to_wallet';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Receipt Header Banner */}
        <div className="bg-slate-900 text-white p-5 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white rounded-full transition-colors"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-12 h-12 mx-auto mb-2 bg-emerald-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/30">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <p className="text-[10px] tracking-widest uppercase font-mono text-emerald-400 font-bold">
            Transaksi Berhasil
          </p>
          <h3 className="text-xl font-extrabold font-mono mt-1">
            {isIncome ? '+' : '-'}{formatRupiah(transaction.amount)}
          </h3>
          <p className="text-xs text-slate-300 mt-0.5">{transaction.title}</p>
        </div>

        {/* Paper Cut Effect Line */}
        <div className="relative h-4 bg-slate-900">
          <div className="absolute inset-x-0 bottom-0 flex justify-between overflow-hidden">
            {[...Array(16)].map((_, i) => (
              <div key={i} className="w-3 h-3 bg-white rotate-45 transform translate-y-1.5" />
            ))}
          </div>
        </div>

        {/* Receipt Body Details */}
        <div className="p-6 space-y-4">
          <div className="text-center pb-2 border-b border-slate-100">
            <p className="text-[11px] font-mono text-slate-400">NOMOR REFERENSI</p>
            <p className="text-xs font-mono font-bold text-slate-800 tracking-wider">
              {transaction.referenceCode}
            </p>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between text-slate-500">
              <span>Waktu Transaksi</span>
              <span className="font-semibold text-slate-900">{transaction.timestamp}</span>
            </div>

            <div className="flex items-center justify-between text-slate-500">
              <span>Metode Pembayaran</span>
              <span className="font-semibold text-slate-900">{transaction.paymentMethodName}</span>
            </div>

            <div className="flex items-center justify-between text-slate-500">
              <span>Rekening / E-Wallet</span>
              <span className="font-mono font-semibold text-slate-900 text-right truncate max-w-[170px]">
                {transaction.sourceAccount}
              </span>
            </div>

            {transaction.merchantName && (
              <div className="flex items-center justify-between text-slate-500">
                <span>Merchant / Penerima</span>
                <span className="font-semibold text-slate-900 text-right truncate max-w-[170px]">
                  {transaction.merchantName}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between text-slate-500">
              <span>Tujuan Saldo</span>
              <span className="font-semibold text-slate-900">
                {transaction.destination === 'savings' ? 'Tabungan Siswa' : 'Dompet Saku Harian'}
              </span>
            </div>

            {transaction.note && (
              <div className="flex items-start justify-between text-slate-500 pt-1">
                <span>Catatan</span>
                <span className="font-medium text-slate-800 text-right max-w-[180px]">
                  {transaction.note}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between text-slate-500 pt-2 border-t border-slate-100">
              <span>Status Otorisasi</span>
              <span className="font-semibold text-emerald-600 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                PIN Terverifikasi
              </span>
            </div>
          </div>

          {/* Security stamp */}
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-2">
            <Wallet className="w-4 h-4 text-emerald-600 shrink-0" />
            <p className="text-[10px] text-emerald-800 leading-tight">
              Bukti resmi transaksi dompet digital siswa sekolah SakuSiswa. Sah tanpa tanda tangan basah.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Bukti</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm"
            >
              Selesai
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
