import React from 'react';
import { X, Printer, Share2, Check, Copy } from 'lucide-react';
import { Product, StoreData, Transaction } from '../types';
import { formatMoney, formatDisplayDate } from '../utils/formatters';
import { feedback } from '../utils/haptics';

interface ReceiptModalProps {
  transaction: Transaction | null;
  product: Product | null;
  store: StoreData;
  isOpen: boolean;
  onClose: () => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  product,
  store,
  isOpen,
  onClose,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !transaction) return null;

  const isSale = transaction.type === 'S';
  const total = transaction.qty * transaction.rate;

  const handlePrint = () => {
    feedback.vibrateSoft(hapticsEnabled);
    feedback.playTap(soundEnabled);
    window.print();
  };

  const handleShare = async () => {
    feedback.vibrateSoft(hapticsEnabled);
    feedback.playTap(soundEnabled);

    const text = `
=== ${store.co.toUpperCase()} ===
${store.tagline || 'Invoice Slip'}
Date: ${formatDisplayDate(transaction.date)} ${transaction.time || ''}
Receipt #: ${transaction.id}
Type: ${isSale ? 'SALES RECEIPT' : 'PURCHASE VOUCHER'}
--------------------------------
${isSale ? 'Customer' : 'Supplier'}: ${transaction.cust || 'Walk-in'}
Payment: ${(transaction.paymentMethod || 'cash').toUpperCase()}
--------------------------------
Item: ${product ? product.name : 'Stock Item'}
Qty: ${transaction.qty} ${product ? product.unit : ''} @ ${formatMoney(transaction.rate, store.cur)}
--------------------------------
TOTAL: ${formatMoney(total, store.cur)}
================================
Thank you for your business!
    `.trim();

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${store.co} - Receipt ${transaction.id}`,
          text,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      feedback.vibrateSuccess(hapticsEnabled);
    } catch {
      // fallback
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-300">
            {isSale ? 'Sale Receipt Slip' : 'Purchase Voucher'}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-full bg-slate-800 text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Thermal Slip Content */}
        <div className="p-5 overflow-y-auto bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-200">
          <div id="printable-receipt" className="bg-white p-5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 shadow-xs text-slate-900">
            {/* Store details */}
            <div className="text-center pb-3 border-b border-dashed border-slate-300">
              <div className="font-bold text-base tracking-tight">{store.co}</div>
              {store.tagline && <div className="text-[10px] text-slate-500">{store.tagline}</div>}
              {store.address && <div className="text-[10px] text-slate-500 mt-0.5">{store.address}</div>}
              {store.phone && <div className="text-[10px] text-slate-500">Tel: {store.phone}</div>}
            </div>

            {/* Meta */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Receipt No:</span>
                <span className="font-semibold">{transaction.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date & Time:</span>
                <span>{transaction.date} {transaction.time || ''}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{isSale ? 'Customer' : 'Supplier'}:</span>
                <span className="font-semibold">{transaction.cust || (isSale ? 'Walk-in Customer' : 'Standard Supplier')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment:</span>
                <span className="uppercase font-semibold text-emerald-700">
                  {transaction.paymentMethod || 'cash'}
                </span>
              </div>
            </div>

            {/* Item Table */}
            <div className="py-3 border-b border-dashed border-slate-300">
              <div className="flex justify-between font-bold text-[11px] mb-1.5 text-slate-700">
                <span>ITEM</span>
                <span>TOTAL</span>
              </div>
              <div className="space-y-1">
                <div className="font-medium text-[11px] leading-tight">
                  {product ? product.name : 'Unknown Product'}
                </div>
                <div className="flex justify-between text-[11px] text-slate-600">
                  <span>
                    {transaction.qty} {product ? product.unit : ''} × {formatMoney(transaction.rate, store.cur)}
                  </span>
                  <span className="font-bold text-slate-900">
                    {formatMoney(total, store.cur)}
                  </span>
                </div>
              </div>
            </div>

            {/* Total */}
            <div className="py-3 border-b border-dashed border-slate-300 flex items-center justify-between text-sm">
              <span className="font-bold">TOTAL AMOUNT</span>
              <span className="font-extrabold text-base text-red-600">
                {formatMoney(total, store.cur)}
              </span>
            </div>

            {/* Simulated Barcode */}
            <div className="pt-4 text-center">
              <div className="flex justify-center gap-1 h-8 items-stretch mb-1">
                {Array.from({ length: 32 }).map((_, i) => (
                  <div
                    key={i}
                    className={`bg-slate-900 ${
                      i % 3 === 0 ? 'w-1' : i % 5 === 0 ? 'w-1.5' : 'w-0.5'
                    }`}
                  />
                ))}
              </div>
              <div className="text-[9px] tracking-widest text-slate-500 font-mono">
                *{transaction.id}*
              </div>
              <div className="text-[10px] text-slate-500 mt-2 font-sans font-medium">
                Thank you for your visit!
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition text-slate-800 dark:text-slate-100"
          >
            <Printer className="w-3.5 h-3.5" />
            Print POS
          </button>
          <button
            type="button"
            onClick={handleShare}
            className="flex-1 py-2.5 px-3 rounded-xl bg-[#d9262c] hover:bg-red-700 font-semibold text-xs text-white flex items-center justify-center gap-1.5 transition shadow-sm"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                Copied!
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5" />
                Share Slip
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
