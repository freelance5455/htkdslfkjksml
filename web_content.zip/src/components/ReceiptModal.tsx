import { useEffect, useState } from 'react';
import { CheckCircle2, Download, ShieldCheck, X } from 'lucide-react';
import { apiRequest } from '../api.ts';
import type { ReceiptDetail } from '../types.ts';
import { formatDateTime, formatInrExact, formatNumber, formatPaymentMethodLabel } from '../utils/format.ts';
import { StatusLabel } from './StatusLabel.tsx';

interface ReceiptModalProps {
  paymentCode: string | null;
  onClose: () => void;
}

export function ReceiptModal({ paymentCode, onClose }: ReceiptModalProps) {
  const [receipt, setReceipt] = useState<ReceiptDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!paymentCode) {
      setReceipt(null);
      return;
    }
    let active = true;
    setLoading(true);
    setError('');
    apiRequest<{ receipt: ReceiptDetail }>(`/api/payments/receipt/${encodeURIComponent(paymentCode)}`)
      .then((res) => {
        if (active) setReceipt(res.receipt);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load receipt.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [paymentCode]);

  if (!paymentCode) return null;

  const handleDownloadHtmlReceipt = () => {
    if (!receipt) return;
    const html = `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Receipt ${receipt.receipt_number || receipt.payment_code}</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; background: radial-gradient(circle at top left, #2e1065, #08071a 60%); color: #f8fafc; padding: 32px; }
  .card { max-width: 600px; margin: 0 auto; background: rgba(16, 18, 44, 0.92); border: 1px solid rgba(255,255,255,0.16); border-radius: 16px; padding: 28px; }
  h1 { margin: 0 0 6px; font-size: 20px; background: linear-gradient(90deg, #f472b6, #60a5fa, #22d3ee); -webkit-background-clip: text; color: transparent; }
  .muted { color: #cbd5e1; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 14px; }
  td { padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }
  td.val { text-align: right; font-family: monospace; color: #67e8f9; }
</style>
</head>
<body>
  <div class="card">
    <h1>SOCIAL BOOST — Payment Receipt</h1>
    <div class="muted">Verified server-side record · ${receipt.receipt_number || receipt.payment_code}</div>
    <table>
      <tr><td>Customer</td><td class="val">${receipt.customer_name} (${receipt.customer_email})</td></tr>
      <tr><td>Payment ID</td><td class="val">${receipt.payment_code}</td></tr>
      <tr><td>Gateway Order ID</td><td class="val">${receipt.gateway_order_id}</td></tr>
      <tr><td>Gateway Payment ID</td><td class="val">${receipt.gateway_payment_id || '—'}</td></tr>
      <tr><td>Purpose</td><td class="val">${receipt.purpose === 'wallet_topup' ? 'Wallet Top-up' : `Order ${receipt.order_code || ''}`}</td></tr>
      ${receipt.service_name_snapshot ? `<tr><td>Service</td><td class="val">${receipt.service_name_snapshot} (${formatNumber(receipt.quantity)} qty)</td></tr>` : ''}
      <tr><td>Method</td><td class="val">${formatPaymentMethodLabel(receipt.method)}</td></tr>
      <tr><td>Verification</td><td class="val">${receipt.webhook_verified ? 'Verified' : 'Pending'}</td></tr>
      <tr><td>Verified At</td><td class="val">${formatDateTime(receipt.verified_at || receipt.created_at)}</td></tr>
      <tr><td><strong>Amount Paid</strong></td><td class="val"><strong>${formatInrExact(receipt.amount_paise)}</strong></td></tr>
    </table>
  </div>
</body>
</html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${receipt.receipt_number || receipt.payment_code}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl sb-surface p-6 space-y-5 max-h-[90dvh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-cyan-400" />
            <h3 className="text-base font-bold text-gradient-aurora">Payment Receipt</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close receipt"
            className="min-h-[40px] min-w-[40px] rounded-xl bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-slate-200 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {loading && <p className="text-sm text-cyan-300 py-8 text-center">Loading verified receipt...</p>}
        {error && <p className="text-sm text-rose-300 py-4">{error}</p>}

        {receipt && (
          <div className="space-y-4">
            <div className="rounded-xl sb-surface-inner p-4 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs text-slate-400">Amount Payable / Paid</div>
                <div className="text-2xl font-extrabold font-mono tabular-nums text-gradient-sunset mt-0.5">
                  {formatInrExact(receipt.amount_paise)}
                </div>
              </div>
              <StatusLabel status={receipt.status} />
            </div>

            <dl className="divide-y divide-white/[0.08] text-xs">
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Receipt Number</dt>
                <dd className="font-mono text-amber-300">{receipt.receipt_number || 'Pending capture'}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Payment Code</dt>
                <dd className="font-mono text-cyan-300">{receipt.payment_code}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Gateway Order ID</dt>
                <dd className="font-mono text-slate-200 truncate max-w-[230px]">{receipt.gateway_order_id}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Gateway Payment / UTR ID</dt>
                <dd className="font-mono text-slate-200 truncate max-w-[230px]">{receipt.gateway_payment_id || '—'}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Payment Method</dt>
                <dd className="text-white font-semibold">{formatPaymentMethodLabel(receipt.method)}</dd>
              </div>
              {receipt.order_code && (
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-slate-400">Order Reference</dt>
                  <dd className="font-mono text-fuchsia-300">
                    {receipt.order_code} · {receipt.service_name_snapshot}
                  </dd>
                </div>
              )}
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Verification</dt>
                <dd className="inline-flex items-center gap-1 text-emerald-300">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>{receipt.webhook_verified ? 'Verified Server-Side' : 'Pending Verification'}</span>
                </dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-400">Timestamp</dt>
                <dd className="font-mono text-slate-300">{formatDateTime(receipt.verified_at || receipt.created_at)}</dd>
              </div>
            </dl>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={handleDownloadHtmlReceipt}
                className="flex-1 min-h-[44px] rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                <span>Download Receipt</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-5 rounded-xl border border-white/12 bg-white/[0.06] hover:bg-white/[0.12] text-xs font-medium text-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
