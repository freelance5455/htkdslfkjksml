import React, { useState } from 'react';
import { X, Layers, ChevronLeft, ChevronRight, RotateCw, Sparkles, RefreshCw, Search, Shuffle } from 'lucide-react';
import { Flashcard, filterFlashcards } from '../utils/quiz-state';

interface FlashcardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTopic?: string;
}

const DEFAULT_FLASHCARDS: Flashcard[] = [
  {
    id: 'f1',
    front: 'The Fundamental Theorem of Calculus',
    back: 'Connects differentiation and integration: if f is continuous on [a, b] and F is an antiderivative of f, then ∫[a to b] f(x) dx = F(b) - F(a).',
    category: 'Calculus',
  },
  {
    id: 'f2',
    front: 'Big-O: Quicksort Worst-Case vs Average-Case',
    back: 'Average case: O(n log n). Worst case: O(n²) when the pivot chosen is consistently the smallest or largest element (e.g. already sorted array without randomized pivot).',
    category: 'Computer Science',
  },
  {
    id: 'f3',
    front: 'Heisenberg Uncertainty Principle',
    back: 'States that the more precisely the position (x) of some particle is determined, the less precisely its momentum (p) can be known: Δx · Δp ≥ ℏ/2.',
    category: 'Physics',
  },
  {
    id: 'f4',
    front: 'Oxidation vs Reduction (OIL RIG)',
    back: 'Oxidation Is Loss of electrons (increase in oxidation state). Reduction Is Gain of electrons (decrease in oxidation state).',
    category: 'Chemistry',
  },
  {
    id: 'f5',
    front: 'Ethos, Pathos, and Logos',
    back: 'The rhetorical appeals formulated by Aristotle: Ethos (appeal to character/credibility), Pathos (appeal to emotion), and Logos (appeal to logic and reasoned argument).',
    category: 'Writing & Rhetoric',
  },
];

export const FlashcardsModal: React.FC<FlashcardsModalProps> = ({
  isOpen,
  onClose,
  initialTopic = 'Core Academic Concepts',
}) => {
  const [topic, setTopic] = useState(initialTopic || 'Core Academic Concepts');
  const [cards, setCards] = useState<Flashcard[]>(DEFAULT_FLASHCARDS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredCards = filterFlashcards(cards, searchQuery);
  const currentCard = filteredCards[currentIndex] || filteredCards[0];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % filteredCards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentIndex(0);
  };

  const handleGenerate = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const targetTopic = topic.trim() || 'Core Academic Concepts';

    setIsGenerating(true);
    setError(null);
    setIsFlipped(false);

    try {
      const res = await fetch('/api/generate-flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: targetTopic,
          count: 5,
        }),
      });

      if (!res.ok) throw new Error('Failed to generate flashcards');
      const data = await res.json();
      if (data.flashcards && data.flashcards.length > 0) {
        setCards(data.flashcards);
        setCurrentIndex(0);
        setSearchQuery('');
      }
    } catch (err: any) {
      console.error(err);
      setError('Showing curated flashcards for your study session.');
      setCards(DEFAULT_FLASHCARDS);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Flashcards Study Deck</h3>
              <p className="text-[11px] text-slate-500">Active recall & rapid concept drills</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close flashcards modal"
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Generate / Search Toolbar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 space-y-2">
          <form onSubmit={handleGenerate} className="flex gap-2">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Generate flashcards on any subject..."
              aria-label="Flashcard topic"
              className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500 shadow-2xs"
            />
            <button
              type="submit"
              disabled={isGenerating}
              aria-label="Generate flashcards"
              className="px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 transition shrink-0 shadow-2xs cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Creating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate</span>
                </>
              )}
            </button>
          </form>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentIndex(0);
              }}
              placeholder="Filter deck by keyword or subject..."
              aria-label="Search flashcards"
              className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
          </div>
          {error && <p className="text-xs text-purple-700 font-medium">{error}</p>}
        </div>

        {/* Card Stage with native interactive button */}
        <div className="flex-1 p-6 flex flex-col items-center justify-center min-h-[300px]">
          {filteredCards.length === 0 ? (
            <div className="text-center text-slate-400 text-xs py-10">
              <p>No flashcards matched your search.</p>
              <button
                onClick={() => setSearchQuery('')}
                className="mt-2 text-purple-600 font-medium underline"
              >
                Clear filter
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsFlipped(!isFlipped)}
              aria-label={isFlipped ? 'Card answer: click to see question' : 'Card question: click to see answer'}
              className="w-full max-w-md h-64 border-2 border-slate-200 hover:border-purple-400 rounded-2xl p-6 bg-white shadow-sm flex flex-col justify-between cursor-pointer transition-all duration-200 select-none text-center relative hover:shadow-md focus:outline-none focus:ring-2 focus:ring-purple-400"
            >
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium w-full">
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 uppercase tracking-wider text-[10px] font-semibold">
                  {currentCard.category || 'Concept'}
                </span>
                <span className="flex items-center space-x-1 text-purple-600 font-semibold">
                  <RotateCw className="w-3 h-3" />
                  <span>{isFlipped ? 'Viewing Answer' : 'Click to Flip'}</span>
                </span>
              </div>

              <div className="my-auto px-2">
                {isFlipped ? (
                  <p className="text-slate-800 text-sm leading-relaxed font-normal">
                    {currentCard.back}
                  </p>
                ) : (
                  <h4 className="text-slate-900 text-base font-bold leading-snug">
                    {currentCard.front}
                  </h4>
                )}
              </div>

              <div className="text-[11px] text-slate-400 w-full flex items-center justify-between">
                <span>Card {currentIndex + 1} of {filteredCards.length}</span>
                <span className="text-purple-600 underline text-[10px]">Click anywhere to flip</span>
              </div>
            </button>
          )}
        </div>

        {/* Navigation Footer */}
        {filteredCards.length > 0 && (
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handlePrev}
                aria-label="Previous flashcard"
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 transition flex items-center space-x-1 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>
              <button
                type="button"
                onClick={handleNext}
                aria-label="Next flashcard"
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 transition flex items-center space-x-1 cursor-pointer"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={handleShuffle}
              aria-label="Shuffle flashcards"
              className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg bg-white hover:bg-slate-100 transition flex items-center space-x-1 cursor-pointer"
              title="Shuffle card order"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Shuffle</span>
            </button>

            <span className="text-xs font-semibold text-slate-600">
              {currentIndex + 1} / {filteredCards.length}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
