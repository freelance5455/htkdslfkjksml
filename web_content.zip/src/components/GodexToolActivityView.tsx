/**
 * GODEX Phase 1 - Tool Activity & Registry View
 * Dynamic Tool Registry from ToolSystem with 6 categories:
 * READ, WRITE, DELETE, EXECUTE, GIT, MISSION
 * Showing tool definitions, permission tiers, approval requirements, and live audit history.
 */

import React, { useState, useEffect } from 'react';
import { 
  Wrench, 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Terminal, 
  GitBranch, 
  Layers, 
  FileCode, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Filter,
  Search
} from 'lucide-react';
import { ToolSystem } from '../coding/toolSystem';
import { ToolDefinition, ToolPermissionTier, ToolCallAuditRecord } from '../coding/agentTypes';

export type ToolCategoryFilter = 'ALL' | 'READ' | 'WRITE' | 'DELETE' | 'EXECUTE' | 'GIT' | 'MISSION';

export const GodexToolActivityView: React.FC = () => {
  const [tools, setTools] = useState<ToolDefinition[]>([]);
  const [auditLogs, setAuditLogs] = useState<ToolCallAuditRecord[]>([]);
  const [activeCategory, setActiveCategory] = useState<ToolCategoryFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTool, setSelectedTool] = useState<ToolDefinition | null>(null);

  useEffect(() => {
    ToolSystem.initialize();
    setTools(ToolSystem.getAllTools());
    setAuditLogs(ToolSystem.getAuditLogs());

    const interval = setInterval(() => {
      setAuditLogs(ToolSystem.getAuditLogs());
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const getTierBadge = (tier: ToolPermissionTier) => {
    switch (tier) {
      case 'READ':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">READ</span>;
      case 'WRITE':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">WRITE</span>;
      case 'DELETE':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">DELETE (GATE)</span>;
      case 'EXECUTE':
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800">EXECUTE</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-neutral-900 text-neutral-400 border border-neutral-700">{tier}</span>;
    }
  };

  const getToolCategory = (tool: ToolDefinition): 'READ' | 'WRITE' | 'DELETE' | 'EXECUTE' | 'GIT' | 'MISSION' => {
    if (tool.name.startsWith('GIT_') || tool.name === 'RELEASE_AUDIT') return 'GIT';
    if (tool.name.includes('MISSION')) return 'MISSION';
    if (tool.name.includes('RUN_') || tool.name.includes('EXECUTE_')) return 'EXECUTE';
    if (tool.tier === 'DELETE') return 'DELETE';
    if (tool.tier === 'WRITE') return 'WRITE';
    return 'READ';
  };

  const filteredTools = tools.filter(t => {
    const cat = getToolCategory(t);
    const matchesCategory = activeCategory === 'ALL' || cat === activeCategory || t.tier === activeCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q || t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex-1 h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#08090D] select-text">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#182030]">
        <div>
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Wrench className="w-4 h-4 text-cyan-400" />
            <span>GODEX Governed Tool System</span>
          </h3>
          <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
            Registered capabilities with immutable audit logs and approval boundaries
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-[11px]">
          <span className="px-2.5 py-1 rounded bg-[#101624] text-cyan-300 border border-cyan-800/60 font-bold">
            {tools.length} Tools Registered
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(['ALL', 'READ', 'WRITE', 'DELETE', 'EXECUTE', 'GIT', 'MISSION'] as ToolCategoryFilter[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-2.5 py-1 rounded-lg transition-all text-[10px] font-bold whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-xs'
                  : 'bg-[#0E131E] text-neutral-400 hover:text-neutral-200 border border-[#1A2234]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search registered tools..."
            className="w-full pl-8 pr-3 py-1 rounded-lg bg-[#0E131E] border border-[#1C2538] text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-cyan-500 text-xs font-mono"
          />
        </div>
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredTools.map((tool) => {
          const isSelected = selectedTool?.name === tool.name;
          const category = getToolCategory(tool);
          const relatedLogs = auditLogs.filter(l => l.toolName === tool.name);

          return (
            <div
              key={tool.name}
              onClick={() => setSelectedTool(isSelected ? null : tool)}
              className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between space-y-3 cursor-pointer ${
                isSelected
                  ? 'bg-[#121927] border-cyan-500 shadow-md ring-1 ring-cyan-500/30'
                  : 'bg-[#0A0D15] border-[#182234] hover:border-[#222E44]'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-white tracking-wide">{tool.name}</span>
                  {getTierBadge(tool.tier)}
                </div>

                <p className="text-[11px] text-neutral-400 leading-relaxed font-sans line-clamp-2">
                  {tool.description}
                </p>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-[#161D2C] font-mono text-[10px]">
                <div className="flex items-center justify-between text-neutral-500">
                  <span>Category: <strong className="text-neutral-300">{category}</strong></span>
                  <span>Approval: <strong className={tool.requiresApproval ? 'text-amber-400' : 'text-emerald-400'}>{tool.requiresApproval ? 'REQUIRED' : 'AUTO'}</strong></span>
                </div>
                {relatedLogs.length > 0 && (
                  <div className="text-cyan-400 text-[9px]">
                    Executed {relatedLogs.length} time(s) · Last {new Date(relatedLogs[0].timestamp).toLocaleTimeString()}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Live Tool Audit Log Stream */}
      <div className="space-y-2 pt-4 border-t border-[#182030]">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Audit Execution Stream ({auditLogs.length})</span>
          </span>
          <span className="text-[10px] text-neutral-500">Deterministic Ledger</span>
        </div>

        {auditLogs.length === 0 ? (
          <div className="p-6 text-center text-neutral-500 rounded-xl bg-[#0A0D15] border border-[#182234] font-mono text-xs">
            No tool calls executed yet. Trigger an operation in Chat to inspect live tool execution.
          </div>
        ) : (
          <div className="space-y-2 font-mono text-[11px]">
            {auditLogs.slice(0, 8).map((log) => (
              <div
                key={log.id}
                className="p-2.5 rounded-lg bg-[#0C1018] border border-[#182030] flex flex-col md:flex-row md:items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2 truncate">
                  {log.result.success ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  )}
                  <span className="font-bold text-cyan-300">{log.toolName}</span>
                  <span className="text-neutral-400 truncate text-[10px]">
                    {JSON.stringify(log.args).slice(0, 80)}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[10px] text-neutral-500 shrink-0">
                  <span>{log.result.durationMs}ms</span>
                  <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
