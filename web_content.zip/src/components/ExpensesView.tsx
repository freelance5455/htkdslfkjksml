import React, { useState, useMemo } from "react";
import { 
  Plus, 
  Trash2, 
  IndianRupee, 
  Wallet, 
  Fuel, 
  Zap, 
  Wrench, 
  Pipette, 
  Users, 
  Coins, 
  Building2, 
  ReceiptText, 
  Filter, 
  Search, 
  Calendar,
  FileDown,
  ArrowDownRight,
  ArrowUpRight,
  TrendingUp,
  Tag,
  CheckCircle2,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Record, ExpenseUsage, Language } from "../types";
import { TRANSLATIONS } from "../translations";
import { format } from "date-fns";

interface ExpensesViewProps {
  language: Language;
  expenses: ExpenseUsage[];
  records: Record[];
  onAddExpense: (expense: Omit<ExpenseUsage, "id">) => void;
  onDeleteExpense: (id: string) => void;
  onOpenPdfModal: () => void;
}

export const CATEGORY_ICONS: { [key: string]: React.ElementType } = {
  diesel: Fuel,
  electricity: Zap,
  motor_repair: Wrench,
  pipeline: Pipette,
  labor: Users,
  parts: Coins,
  bank_deposit: Building2,
  other: ReceiptText
};

export const CATEGORY_COLORS: { [key: string]: { bg: string; text: string; border: string } } = {
  diesel: { bg: "bg-amber-500/10", text: "text-amber-700 dark:text-amber-400", border: "border-amber-500/30" },
  electricity: { bg: "bg-yellow-500/10", text: "text-yellow-700 dark:text-yellow-400", border: "border-yellow-500/30" },
  motor_repair: { bg: "bg-blue-500/10", text: "text-blue-700 dark:text-blue-400", border: "border-blue-500/30" },
  pipeline: { bg: "bg-cyan-500/10", text: "text-cyan-700 dark:text-cyan-400", border: "border-cyan-500/30" },
  labor: { bg: "bg-emerald-500/10", text: "text-emerald-700 dark:text-emerald-400", border: "border-emerald-500/30" },
  parts: { bg: "bg-purple-500/10", text: "text-purple-700 dark:text-purple-400", border: "border-purple-500/30" },
  bank_deposit: { bg: "bg-indigo-500/10", text: "text-indigo-700 dark:text-indigo-400", border: "border-indigo-500/30" },
  other: { bg: "bg-gray-500/10", text: "text-gray-700 dark:text-gray-300", border: "border-gray-500/30" }
};

export const getCategoryName = (cat: string, t: any): string => {
  switch (cat) {
    case "diesel": return t.catDiesel || "डीजल / ईंधन";
    case "electricity": return t.catElectricity || "बिजली बिल";
    case "motor_repair": return t.catMotorRepair || "मोटर/पंप मरम्मत";
    case "pipeline": return t.catPipeline || "पाइपलाइन व नोजल";
    case "labor": return t.catLabor || "मजदूर/ऑपरेटर";
    case "parts": return t.catParts || "तेल/ग्रीस/पार्ट्स";
    case "bank_deposit": return t.catBankDeposit || "बैंक बचत जमा";
    case "other": return t.catOther || "अन्य खर्च";
    default: return cat;
  }
};

export default function ExpensesView({
  language,
  expenses,
  records,
  onAddExpense,
  onDeleteExpense,
  onOpenPdfModal
}: ExpensesViewProps) {
  const t = TRANSLATIONS[language];

  const [showAddForm, setShowAddForm] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterSourceParty, setFilterSourceParty] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("all");

  const [formData, setFormData] = useState({
    title: "",
    amount: "",
    category: "diesel",
    paidTo: "",
    sourceParty: "",
    paymentMode: "Cash",
    date: format(new Date(), "yyyy-MM-dd"),
    billNo: "",
    note: ""
  });

  // Calculate distinct paying parties from records
  const partyPaymentTotals = useMemo(() => {
    const map: { [party: string]: { paid: number; spent: number } } = {};

    records.forEach(r => {
      const p = (r.farmer && r.farmer.trim()) ? r.farmer.trim() : "अज्ञात पार्टी";
      if (!map[p]) map[p] = { paid: 0, spent: 0 };
      map[p].paid += (r.paymentReceived || 0);
    });

    expenses.forEach(e => {
      if (e.sourceParty && e.sourceParty.trim() && map[e.sourceParty.trim()]) {
        map[e.sourceParty.trim()].spent += (e.amount || 0);
      }
    });

    return map;
  }, [records, expenses]);

  const distinctPayingParties = useMemo(() => {
    return Object.keys(partyPaymentTotals).filter(p => partyPaymentTotals[p].paid > 0);
  }, [partyPaymentTotals]);

  // Overall Financials
  const totalCashIn = useMemo(() => {
    return records.reduce((sum, r) => sum + (r.paymentReceived || 0), 0);
  }, [records]);

  const totalCashOut = useMemo(() => {
    return expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  }, [expenses]);

  const netCashInHand = totalCashIn - totalCashOut;

  // Category breakdown
  const categoryTotals = useMemo(() => {
    const map: { [cat: string]: { amount: number; count: number } } = {
      diesel: { amount: 0, count: 0 },
      electricity: { amount: 0, count: 0 },
      motor_repair: { amount: 0, count: 0 },
      pipeline: { amount: 0, count: 0 },
      labor: { amount: 0, count: 0 },
      parts: { amount: 0, count: 0 },
      bank_deposit: { amount: 0, count: 0 },
      other: { amount: 0, count: 0 }
    };

    expenses.forEach(e => {
      const cat = e.category || "other";
      if (!map[cat]) map[cat] = { amount: 0, count: 0 };
      map[cat].amount += e.amount || 0;
      map[cat].count += 1;
    });

    return map;
  }, [expenses]);

  // Filtered expenses
  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      const matchCat = filterCategory === "all" || e.category === filterCategory;
      const matchParty = filterSourceParty === "all" || 
        (filterSourceParty === "__general__" ? (!e.sourceParty || e.sourceParty === "") : e.sourceParty === filterSourceParty);
      const matchSearch = searchTerm === "all" || searchTerm === "" ||
        e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (e.paidTo && e.paidTo.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (e.sourceParty && e.sourceParty.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchCat && matchParty && matchSearch;
    });
  }, [expenses, filterCategory, filterSourceParty, searchTerm]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(formData.amount) || 0;
    if (!formData.title || amt <= 0) return;

    onAddExpense({
      title: formData.title.trim(),
      amount: amt,
      category: formData.category,
      paidTo: formData.paidTo.trim() || undefined,
      sourceParty: formData.sourceParty.trim() || undefined,
      paymentMode: formData.paymentMode || "Cash",
      date: formData.date || format(new Date(), "yyyy-MM-dd"),
      billNo: formData.billNo.trim() || undefined,
      note: formData.note.trim() || undefined
    });

    setFormData({
      title: "",
      amount: "",
      category: "diesel",
      paidTo: "",
      sourceParty: "",
      paymentMode: "Cash",
      date: format(new Date(), "yyyy-MM-dd"),
      billNo: "",
      note: ""
    });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      
      {/* 4 KPI Key Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-emerald-600 to-teal-800 text-white border-none shadow-md rounded-2xl overflow-hidden relative">
          <CardHeader className="pb-1">
            <CardTitle className="text-xs font-bold text-emerald-100 uppercase tracking-wider flex items-center justify-between">
              <span>कुल जमा वसूली (Cash Inflow)</span>
              <ArrowDownRight className="w-4 h-4 text-emerald-200" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl md:text-3xl font-bold font-sans text-white">
              ₹ {totalCashIn.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
            </div>
            <p className="text-[11px] text-emerald-100/80 mt-1 font-sans">पार्टियों से प्राप्त कुल पेमेंट</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-rose-600 to-red-800 text-white border-none shadow-md rounded-2xl overflow-hidden relative">
          <CardHeader className="pb-1">
            <CardTitle className="text-xs font-bold text-rose-100 uppercase tracking-wider flex items-center justify-between">
              <span>{t.totalExpenses} (Cash Outflow)</span>
              <ArrowUpRight className="w-4 h-4 text-rose-200" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl md:text-3xl font-bold font-sans text-white">
              ₹ {totalCashOut.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
            </div>
            <p className="text-[11px] text-rose-100/80 mt-1 font-sans">{expenses.length} खर्च प्रविष्टियां दर्ज</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-600 to-indigo-800 text-white border-none shadow-md rounded-2xl overflow-hidden relative">
          <CardHeader className="pb-1">
            <CardTitle className="text-xs font-bold text-blue-100 uppercase tracking-wider flex items-center justify-between">
              <span>{t.netInHand}</span>
              <Wallet className="w-4 h-4 text-indigo-200" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl md:text-3xl font-bold font-sans text-white">
              ₹ {netCashInHand.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
            </div>
            <p className="text-[11px] text-blue-100/80 mt-1 font-sans">
              {netCashInHand >= 0 ? "शुद्ध बचत रोकड़ उपलब्ध" : "खर्च अधिक है"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border border-border/60 shadow-md rounded-2xl p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-muted-foreground uppercase flex items-center justify-between">
              <span>पेमेंट उपयोग ट्रैक</span>
              <CheckCircle2 className="w-4 h-4 text-primary" />
            </div>
            <div className="text-lg font-bold text-foreground mt-2">
              {distinctPayingParties.length} पार्टियों का हिसाब
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">स्पष्ट रोकड़ एवं खर्च मिलान</p>
          </div>
          <div className="pt-2 flex gap-2">
            <Button
              onClick={() => setShowAddForm(true)}
              size="sm"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-xs rounded-xl h-8 w-full gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.addExpenseBtn}</span>
            </Button>
          </div>
        </Card>
      </div>

      {/* Add Expense Form Modal / Inline Drawer */}
      {showAddForm && (
        <Card className="border border-primary/30 shadow-xl bg-card rounded-3xl p-5 md:p-6 relative">
          <div className="flex items-center justify-between pb-4 border-b border-border/60 mb-5">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 bg-primary/10 text-primary rounded-xl">
                <Plus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-foreground">{t.addExpenseBtn}</h3>
                <p className="text-xs text-muted-foreground">पेमेंट का उपयोग कहाँ किया, उसकी स्पष्ट प्रविष्टि करें</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowAddForm(false)}
              className="rounded-full"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              
              {/* Expense Title */}
              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs font-bold text-foreground">{t.expenseTitle} *</Label>
                <Input
                  required
                  placeholder="उदा. 40 लीटर डीजल, मोटर रिवाइंडिंग, पाइप फिटिंग, ऑपरेटर मजदूरी"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  className="h-10 bg-background rounded-xl"
                  autoFocus
                />
              </div>

              {/* Amount */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">खर्च राशि (₹) *</Label>
                <div className="relative">
                  <IndianRupee className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    required
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                    className="h-10 pl-8 font-bold text-base bg-background rounded-xl"
                  />
                </div>
              </div>

              {/* Category */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">{t.expenseCategory}</Label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="diesel">⛽ {t.catDiesel}</option>
                  <option value="electricity">⚡ {t.catElectricity}</option>
                  <option value="motor_repair">🔧 {t.catMotorRepair}</option>
                  <option value="pipeline">🚿 {t.catPipeline}</option>
                  <option value="labor">👷 {t.catLabor}</option>
                  <option value="parts">⚙️ {t.catParts}</option>
                  <option value="bank_deposit">🏦 {t.catBankDeposit}</option>
                  <option value="other">📝 {t.catOther}</option>
                </select>
              </div>

              {/* Source Party - KEY USER FEATURE! */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-primary" />
                  <span>{t.sourceParty}</span>
                </Label>
                <select
                  value={formData.sourceParty}
                  onChange={(e) => setFormData(prev => ({ ...prev, sourceParty: e.target.value }))}
                  className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">💼 {t.generalPool}</option>
                  {distinctPayingParties.map(party => (
                    <option key={party} value={party}>
                      👤 {party} (जमा: ₹{partyPaymentTotals[party].paid} | शेष: ₹{partyPaymentTotals[party].paid - partyPaymentTotals[party].spent})
                    </option>
                  ))}
                </select>
              </div>

              {/* Paid To */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">{t.paidTo}</Label>
                <Input
                  placeholder="उदा. किसान ऑटोमोबाइल्स, पेट्रोल पंप, रामू कारीगर"
                  value={formData.paidTo}
                  onChange={(e) => setFormData(prev => ({ ...prev, paidTo: e.target.value }))}
                  className="h-10 bg-background rounded-xl"
                />
              </div>

              {/* Date */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">{t.date}</Label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  className="h-10 bg-background rounded-xl text-xs"
                />
              </div>

              {/* Payment Mode */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">{t.paymentMode}</Label>
                <select
                  value={formData.paymentMode}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentMode: e.target.value }))}
                  className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium"
                >
                  <option value="Cash">{t.modeCash}</option>
                  <option value="UPI">{t.modeUPI}</option>
                  <option value="Bank">{t.modeBank}</option>
                  <option value="Cheque">{t.modeCheque}</option>
                </select>
              </div>

              {/* Bill No / Reference */}
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-foreground">बिल / रसीद नंबर (वैकल्पिक)</Label>
                <Input
                  placeholder="उदा. बिल #4502"
                  value={formData.billNo}
                  onChange={(e) => setFormData(prev => ({ ...prev, billNo: e.target.value }))}
                  className="h-10 bg-background rounded-xl"
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-3">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setShowAddForm(false)}
                className="rounded-xl h-10 px-4 text-muted-foreground"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-xl h-10 px-6 gap-1.5 shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>खर्च सहेजें (Save Expense)</span>
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Category-wise Breakdown Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
        {[
          { key: "diesel", icon: Fuel, label: "डीजल" },
          { key: "electricity", icon: Zap, label: "बिजली" },
          { key: "motor_repair", icon: Wrench, label: "मोटर/पंप" },
          { key: "pipeline", icon: Pipette, label: "पाइपलाइन" },
          { key: "labor", icon: Users, label: "मजदूरी" },
          { key: "parts", icon: Coins, label: "पार्ट्स/तेल" },
          { key: "bank_deposit", icon: Building2, label: "बैंक जमा" },
          { key: "other", icon: ReceiptText, label: "अन्य खर्च" },
        ].map((item) => {
          const Icon = item.icon;
          const stat = categoryTotals[item.key] || { amount: 0, count: 0 };
          const color = CATEGORY_COLORS[item.key];
          const isSelected = filterCategory === item.key;

          return (
            <button
              key={item.key}
              type="button"
              onClick={() => setFilterCategory(isSelected ? "all" : item.key)}
              className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${color.bg} ${
                isSelected ? "ring-2 ring-primary border-primary shadow-sm" : color.border
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <Icon className={`w-4 h-4 ${color.text}`} />
                <span className="text-[10px] font-sans text-muted-foreground">{stat.count}</span>
              </div>
              <div>
                <div className="text-xs font-bold text-foreground">{item.label}</div>
                <div className={`text-xs font-bold font-sans mt-0.5 ${color.text}`}>
                  ₹{stat.amount.toLocaleString('en-IN')}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Party Payment Utilization Matrix - Track Which Party's Money Was Used Where */}
      {distinctPayingParties.length > 0 && (
        <Card className="border border-border/60 shadow-lg bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
          <CardHeader className="border-b border-border/40 pb-4">
            <CardTitle className="text-base md:text-lg font-bold flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                <span>पार्टी पेमेंट उपयोग एवं रोकड़ मिलान (Party Fund Utilization)</span>
              </div>
              <span className="text-xs text-muted-foreground font-normal">
                पार्टी से आया पेमेंट ➔ कहाँ खर्च हुआ
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/40 bg-muted/40">
                    <TableHead className="font-bold">किसान / पार्टी</TableHead>
                    <TableHead className="font-bold text-right">कुल प्राप्त जमा (Paid)</TableHead>
                    <TableHead className="font-bold text-right">खर्च में उपयोग किया (Utilized)</TableHead>
                    <TableHead className="font-bold text-right">रोकड़ में शेष बचत (In Pool)</TableHead>
                    <TableHead className="font-bold text-center">फिल्टर</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {distinctPayingParties.map(party => {
                    const info = partyPaymentTotals[party];
                    const remaining = info.paid - info.spent;
                    const isFiltered = filterSourceParty === party;

                    return (
                      <TableRow key={party} className={`border-border/40 hover:bg-muted/20 ${isFiltered ? "bg-primary/5 font-semibold" : ""}`}>
                        <TableCell className="font-bold text-sm text-foreground">
                          👤 {party}
                        </TableCell>
                        <TableCell className="text-right font-sans font-bold text-emerald-600 dark:text-emerald-400">
                          ₹ {info.paid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </TableCell>
                        <TableCell className="text-right font-sans font-bold text-rose-600 dark:text-rose-400">
                          ₹ {info.spent.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </TableCell>
                        <TableCell className="text-right font-sans font-bold text-blue-600 dark:text-blue-400">
                          ₹ {remaining.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            size="sm"
                            variant={isFiltered ? "default" : "outline"}
                            onClick={() => setFilterSourceParty(isFiltered ? "all" : party)}
                            className="h-7 text-xs rounded-lg px-2.5"
                          >
                            {isFiltered ? "फिल्टर हटाया" : "खर्च देखें"}
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Expenses Log Table */}
      <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
        <CardHeader className="border-b border-border/40 pb-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <ReceiptText className="w-5 h-5 text-primary" />
                <span>{t.expenseList}</span>
                <span className="text-xs bg-primary/10 text-primary px-2.5 py-0.5 rounded-full font-sans font-normal">
                  {filteredExpenses.length} खर्च
                </span>
              </CardTitle>
              <CardDescription>सभी खर्चों और पेमेंट उपयोग का सम्पूर्ण हिसाब-किताब</CardDescription>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="खर्च / पार्टी / दुकान खोजें..."
                  value={searchTerm === "all" ? "" : searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="h-9 pl-8 text-xs bg-background rounded-xl w-[200px]"
                />
              </div>

              {/* Category Filter */}
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="h-9 rounded-xl border border-input bg-background px-2.5 text-xs font-medium"
              >
                <option value="all">सभी मद / खर्च</option>
                <option value="diesel">डीजल</option>
                <option value="electricity">बिजली</option>
                <option value="motor_repair">मोटर मरम्मत</option>
                <option value="pipeline">पाइपलाइन</option>
                <option value="labor">मजदूर</option>
                <option value="parts">पार्ट्स</option>
                <option value="bank_deposit">बैंक जमा</option>
                <option value="other">अन्य</option>
              </select>

              {/* Source Party Filter */}
              <select
                value={filterSourceParty}
                onChange={(e) => setFilterSourceParty(e.target.value)}
                className="h-9 rounded-xl border border-input bg-background px-2.5 text-xs font-medium"
              >
                <option value="all">सभी स्रोत (पार्टी)</option>
                <option value="__general__">💼 सामान्य रोकड़ (General Pool)</option>
                {distinctPayingParties.map(p => (
                  <option key={p} value={p}>👤 {p}</option>
                ))}
              </select>

              {(filterCategory !== "all" || filterSourceParty !== "all" || (searchTerm !== "all" && searchTerm !== "")) && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setFilterCategory("all");
                    setFilterSourceParty("all");
                    setSearchTerm("all");
                  }}
                  className="h-9 text-xs text-muted-foreground rounded-xl"
                >
                  रीसेट
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {filteredExpenses.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-3">
              <div className="p-4 bg-muted/60 rounded-full w-14 h-14 mx-auto flex items-center justify-center text-muted-foreground">
                <ReceiptText className="w-7 h-7" />
              </div>
              <div className="text-base font-bold text-foreground">कोई खर्च रिकॉर्ड नहीं मिला</div>
              <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                डीजल, बिजली बिल, मोटर मरम्मत या अन्य खर्च दर्ज करें ताकि यह साफ रहे कि कौन सा पेमेंट कहाँ इस्तेमाल हुआ।
              </p>
              <Button
                onClick={() => setShowAddForm(true)}
                className="bg-primary text-primary-foreground font-bold text-xs rounded-xl h-9 px-4 gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>पहला खर्च दर्ज करें</span>
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/40 bg-muted/40">
                    <TableHead className="font-bold">{t.date}</TableHead>
                    <TableHead className="font-bold">खर्च विवरण / सामान</TableHead>
                    <TableHead className="font-bold">{t.expenseCategory}</TableHead>
                    <TableHead className="font-bold">किस पार्टी के पेमेंट से खर्च</TableHead>
                    <TableHead className="font-bold">{t.paidTo}</TableHead>
                    <TableHead className="font-bold">{t.paymentMode}</TableHead>
                    <TableHead className="font-bold text-right">खर्च राशि (₹)</TableHead>
                    <TableHead className="font-bold text-center">हटाएं</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.map((exp) => {
                    const color = CATEGORY_COLORS[exp.category] || CATEGORY_COLORS.other;
                    const Icon = CATEGORY_ICONS[exp.category] || ReceiptText;

                    return (
                      <TableRow key={exp.id} className="border-border/40 hover:bg-muted/20">
                        <TableCell className="font-sans text-xs text-muted-foreground">
                          {format(new Date(exp.date), "dd/MM/yyyy")}
                        </TableCell>
                        <TableCell className="font-bold text-sm text-foreground">
                          <div>{exp.title}</div>
                          {exp.billNo && (
                            <span className="text-[10px] text-muted-foreground font-sans font-normal">
                              बिल #{exp.billNo}
                            </span>
                          )}
                          {exp.note && (
                            <span className="text-[10px] text-muted-foreground italic block font-normal">
                              {exp.note}
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold ${color.bg} ${color.text} border ${color.border}`}>
                            <Icon className="w-3.5 h-3.5" />
                            <span>{getCategoryName(exp.category, t)}</span>
                          </span>
                        </TableCell>
                        <TableCell>
                          {exp.sourceParty ? (
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-md">
                              👤 {exp.sourceParty}
                            </span>
                          ) : (
                            <span className="text-xs text-muted-foreground italic">
                              💼 सामान्य रोकड़
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-xs font-medium text-foreground">
                          {exp.paidTo || "-"}
                        </TableCell>
                        <TableCell className="text-xs font-medium text-muted-foreground font-sans">
                          {exp.paymentMode || "Cash"}
                        </TableCell>
                        <TableCell className="text-right font-sans font-bold text-sm text-rose-600 dark:text-rose-400">
                          ₹ {exp.amount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onDeleteExpense(exp.id)}
                            className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
