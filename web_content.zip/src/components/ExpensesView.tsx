import React, { useMemo } from 'react';
import {
  Briefcase,
  Cloud,
  Laptop,
  Megaphone,
  Plus,
  Trash2,
  Utensils,
} from 'lucide-react';
import { ExpenseCategory, ExpenseItem } from '../types';
import { formatDateShort, formatINR } from '../utils/formatters';

interface ExpensesViewProps {
  expenses: ExpenseItem[];
  onAddExpenseClick: () => void;
  onDeleteExpense: (id: string) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  onAddExpenseClick,
  onDeleteExpense,
}) => {
  const totalExpenses = useMemo(
    () => expenses.reduce((sum, item) => sum + item.amount, 0),
    [expenses]
  );

  const getCategoryIcon = (cat: ExpenseCategory) => {
    switch (cat) {
      case 'Hardware':
        return <Laptop className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
      case 'Team & Events':
        return <Utensils className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
      case 'Cloud & Hosting':
        return <Cloud className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
      case 'Marketing':
        return <Megaphone className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
      default:
        return <Briefcase className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">Expense Manager</h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Track studio hardware, team events, and cloud spend
          </p>
        </div>

        <button
          type="button"
          onClick={onAddExpenseClick}
          className="btn-primary h-11 px-4 text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" strokeWidth={1.75} />
          <span>Add Expense</span>
        </button>
      </div>

      {/* Single Unified Surface: Summary Header + 1px Divided Expense Rows */}
      <section className="surface-card overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-slate-50/60">
          <div className="space-y-0.5">
            <p className="text-xs font-medium text-slate-500">Monthly Expense Total</p>
            <p className="font-display text-3xl font-bold text-[#0F172A] tabular-nums">
              {formatINR(totalExpenses)}
            </p>
            <p className="text-xs text-slate-500 pt-0.5">
              {expenses.length} recorded studio {expenses.length === 1 ? 'expense' : 'expenses'}
            </p>
          </div>

          <button
            type="button"
            onClick={onAddExpenseClick}
            className="btn-secondary h-10 px-4 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" strokeWidth={1.75} />
            <span>Log Expense</span>
          </button>
        </div>

        {expenses.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-slate-500">No expenses recorded yet.</p>
            <button
              type="button"
              onClick={onAddExpenseClick}
              className="btn-primary px-4 py-2.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" strokeWidth={1.75} />
              <span>Add First Expense</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {expenses.map((expense) => (
              <div
                key={expense.id}
                className="px-5 py-4 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-10 h-10 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
                    {getCategoryIcon(expense.category)}
                  </div>
                  <div className="min-w-0 space-y-0.5">
                    <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A] truncate">
                      {expense.title}
                    </h2>
                    <p className="text-xs text-slate-500 truncate">
                      {expense.category} · {formatDateShort(expense.date)}
                      {expense.note ? ` · ${expense.note}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <p className="font-display text-base font-bold text-[#0F172A] tabular-nums">
                    {formatINR(expense.amount)}
                  </p>
                  <button
                    type="button"
                    onClick={() => onDeleteExpense(expense.id)}
                    aria-label={`Delete ${expense.title}`}
                    className="w-8 h-8 rounded-[8px] hover:bg-slate-100 text-slate-400 hover:text-red-600 flex items-center justify-center transition-colors duration-150 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" strokeWidth={1.75} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
