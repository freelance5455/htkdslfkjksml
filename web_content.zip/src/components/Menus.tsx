import { useState, type ReactNode } from 'react';
import heroImg from '../assets/hero.jpg';
import { MAPS } from '../game/maps';
import { MODES, type GameConfig, type ModeId, type MatchResult } from '../game/Engine';
import { WEAPONS, W, TYPE_FA, SKIN_PRESETS } from '../game/weapons';
import { CODES, DEFAULT_SKIN, fa, faNum, isFullMod, levelFromXp, redeemCode, resetSave, setSave, useSave, type Mods, type Pattern, type SkinColors, type Difficulty } from '../game/store';
import { audio } from '../game/audio';
import { GunSil, Ico } from './Icons';
import WeaponPreview from './WeaponPreview';

function TopBar({ title, onBack }: { title: string; onBack?: () => void }) {
  const s = useSave();
  return (
    <div className="flex items-center gap-3 px-3 py-2 bg-black/60 border-b border-white/10 shrink-0">
      {onBack && <button onClick={() => { audio.ui(); onBack(); }} className="btn-mil px-4 py-1.5 rounded text-sm">→ بازگشت</button>}
      <div className="font-black text-lg tall:text-xl text-amber-400">{title}</div>
      <div className="flex-1" />
      {isFullMod(s.mods) && <div className="px-2 py-0.5 rounded bg-gradient-to-l from-red-600 to-amber-500 text-[11px] font-black shine">مود کامل فعال</div>}
      <div className="flex items-center gap-1.5 bg-black/50 px-3 py-1 rounded-full border border-amber-500/40">
        <span className="w-5 h-5">{Ico.coin()}</span><span className="font-black text-amber-300 text-sm">{faNum(s.coins)}</span>
      </div>
    </div>
  );
}

/* ================= MAIN MENU ================= */
export function MainMenu({ go }: { go: (s: string) => void }) {
  const s = useSave();
  const lv = levelFromXp(s.xp);
  const full = isFullMod(s.mods);
  const items: [string, string, string][] = [
    ['play', 'شروع نبرد', '⚔'],
    ['armory', 'اسلحه‌خانه و اسکین', '🔫'],
    ['codes', 'کدهای مخفی', '🔑'],
    ['settings', 'تنظیمات', '⚙'],
  ];
  return (
    <div className="fixed inset-0 overflow-hidden">
      <img src={heroImg} className="absolute inset-0 w-full h-full object-cover scale-105" alt="" />
      <div className="absolute inset-0 bg-gradient-to-l from-black/95 via-black/70 to-black/10" />
      <div className="absolute inset-0 noise-bg opacity-60" />
      <div className="relative h-full flex flex-col p-2.5 tall:p-6">
        <div className="flex items-center gap-3">
          <div className="metal-panel rounded-xl px-3 py-2 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center font-black text-black text-lg">{fa(lv.lvl)}</div>
            <div>
              <div className="font-bold text-sm">{s.name}</div>
              <div className="w-28 h-1.5 bg-white/10 rounded mt-1 overflow-hidden"><div className="h-full bg-amber-400" style={{ width: `${(lv.cur / lv.need) * 100}%` }} /></div>
              <div className="text-[10px] text-white/50 mt-0.5">سطح {fa(lv.lvl)} · {faNum(lv.cur)}/{faNum(lv.need)} XP</div>
            </div>
          </div>
          <div className="metal-panel rounded-xl px-3 py-2 flex items-center gap-2">
            <span className="w-6 h-6">{Ico.coin()}</span><span className="font-black text-amber-300">{faNum(s.coins)}</span>
          </div>
          {full && <div className="px-3 py-2 rounded-xl bg-gradient-to-l from-red-600 to-amber-500 font-black text-sm shine pop-in">⚡ مود کامل فعال است</div>}
        </div>
        <div className="flex-1 flex flex-col justify-center max-w-[460px]">
          <div className="fade-up">
            <div className="hidden tall:block text-sm tracking-[0.5em] text-amber-200/80 font-ops" dir="ltr">COUNTER · OPS · ELITE</div>
            <h1 className="title-grunge text-4xl tall:text-7xl leading-[1.15]">ضدترور</h1>
            <div className="text-lg tall:text-3xl font-black text-white/90 -mt-1">عملیات نهایی</div>
          </div>
          <div className="flex flex-col gap-1.5 tall:gap-2 mt-3 tall:mt-6 w-[min(340px,70vw)]">
            {items.map(([k, t, ic], i) => (
              <button key={k} onClick={() => { audio.init(); audio.ui(); go(k); }}
                className={`btn-mil fade-up rounded-lg py-1.5 tall:py-3.5 px-5 text-right text-base tall:text-lg flex items-center gap-3 ${i === 0 ? 'btn-gold' : ''}`} style={{ animationDelay: `${i * 70}ms` }}>
                <span className="text-xl w-7 text-center">{ic}</span>{t}
                {k === 'codes' && full && <span className="mr-auto text-[10px] px-1.5 rounded bg-red-600 text-white">MOD</span>}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-end justify-between text-[11px] text-white/40">
          <div>کشته‌ها: {faNum(s.kills)} · برد: {faNum(s.wins)} · مسابقات: {faNum(s.matches)}</div>
          <div dir="ltr">v2.6 · WebGL</div>
        </div>
      </div>
    </div>
  );
}

/* ================= PLAY SETUP ================= */
export function PlayMenu({ onBack, onStart }: { onBack: () => void; onStart: (c: GameConfig) => void }) {
  const s = useSave();
  const [map, setMap] = useState('desert');
  const [mode, setMode] = useState<ModeId>('classic');
  const [team, setTeam] = useState<'ct' | 't'>('ct');
  const diff = s.settings.difficulty;
  const setDiff = (d: Difficulty) => setSave(x => ({ ...x, settings: { ...x.settings, difficulty: d } }));
  const bots = s.settings.bots;
  const teamMode = mode === 'classic' || mode === 'knives' || mode === 'sniper';
  const m = MAPS.find(x => x.id === map)!;
  const diffs: [Difficulty, string][] = [['easy', 'آسان'], ['normal', 'معمولی'], ['hard', 'سخت'], ['pro', 'حرفه‌ای']];
  return (
    <div className="fixed inset-0 flex flex-col bg-[#101113] noise-bg">
      <TopBar title="انتخاب نقشه و حالت بازی" onBack={onBack} />
      <div className="flex-1 min-h-0 flex gap-2 p-2">
        <div className="flex-[1.3] min-w-0 scroll-y">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {MAPS.map(mp => (
              <button key={mp.id} onClick={() => { audio.ui(); setMap(mp.id); if (mp.id === 'castle' && mode !== 'zombie') setMode('zombie'); }}
                className={`relative rounded-lg overflow-hidden aspect-[16/10] border-2 transition ${map === mp.id ? 'border-amber-400 shadow-[0_0_18px_rgba(245,197,24,.45)]' : 'border-white/10 opacity-80 hover:opacity-100'}`}>
                <img src={mp.img} className="absolute inset-0 w-full h-full object-cover" alt="" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
                <div className="absolute bottom-1 right-2 text-right">
                  <div className="font-black text-sm tall:text-base text-white drop-shadow">{mp.name}</div>
                  <div className="text-[9px] font-ops text-amber-300/90" dir="ltr">{mp.en}</div>
                </div>
                {map === mp.id && <div className="absolute top-1 left-1 bg-amber-400 text-black text-[10px] font-black px-1.5 rounded">✓</div>}
              </button>
            ))}
          </div>
          <div className="text-xs text-white/60 mt-2 px-1">{m.desc}</div>
        </div>
        <div className="flex-1 min-w-0 flex flex-col gap-2 scroll-y">
          <div className="metal-panel rounded-lg p-2">
            <div className="text-xs text-white/50 mb-1">حالت بازی</div>
            <div className="grid grid-cols-2 gap-1">
              {MODES.map(md => (
                <button key={md.id} onClick={() => { audio.ui(); setMode(md.id); }}
                  className={`btn-mil rounded py-1.5 px-2 text-sm text-right flex items-center gap-1.5 ${mode === md.id ? '!border-amber-400 text-amber-300' : ''}`}>
                  <span>{md.icon}</span>{md.name}
                </button>
              ))}
            </div>
            <div className="text-[11px] text-white/60 mt-1.5 leading-5">{MODES.find(x => x.id === mode)!.desc}</div>
          </div>
          <div className="metal-panel rounded-lg p-2">
            <div className="text-xs text-white/50 mb-1">سختی ربات‌ها</div>
            <div className="grid grid-cols-4 gap-1">
              {diffs.map(([d, t]) => <button key={d} onClick={() => setDiff(d)} className={`btn-mil rounded py-1 text-xs ${diff === d ? '!border-amber-400 text-amber-300' : ''}`}>{t}</button>)}
            </div>
            {mode !== 'zombie' && (
              <>
                <div className="text-xs text-white/50 mt-2 flex justify-between"><span>تعداد ربات‌ها</span><span className="text-amber-300 font-bold">{fa(bots)}</span></div>
                <input type="range" min={1} max={13} value={bots} className="w-full" onChange={e => setSave(x => ({ ...x, settings: { ...x.settings, bots: +e.target.value } }))} />
              </>
            )}
            {teamMode && (
              <div className="grid grid-cols-2 gap-1 mt-1">
                <button onClick={() => setTeam('ct')} className={`btn-mil rounded py-1.5 text-xs ${team === 'ct' ? '!border-sky-400 text-sky-300' : ''}`}>🛡 ضدتروریست</button>
                <button onClick={() => setTeam('t')} className={`btn-mil rounded py-1.5 text-xs ${team === 't' ? '!border-orange-400 text-orange-300' : ''}`}>💣 تروریست</button>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="flex gap-2 p-2 pt-0 shrink-0">
        <button onClick={() => { audio.init(); audio.unlock(); onStart({ mapId: map, mode, bots, difficulty: diff, team }); }} className="btn-mil btn-gold flex-1 py-3 rounded-lg text-xl">▶ شروع</button>
        <button onClick={onBack} className="btn-mil px-8 py-3 rounded-lg">بازگشت</button>
      </div>
    </div>
  );
}

/* ================= ARMORY ================= */
export function Armory({ onBack }: { onBack: () => void }) {
  const s = useSave();
  const [sel, setSel] = useState('ak47');
  const [msg, setMsg] = useState('');
  const def = W[sel];
  const skin: SkinColors = s.skins[sel] || DEFAULT_SKIN;
  const owned = s.owned.includes(sel) || s.mods.allUnlocked;
  const list = WEAPONS.filter(w => w.type !== 'grenade');
  const setSkin = (p: Partial<SkinColors>) => setSave(x => ({ ...x, skins: { ...x.skins, [sel]: { ...(x.skins[sel] || DEFAULT_SKIN), ...p } } }));
  const unlock = () => {
    if (s.coins < def.unlock) { audio.error(); setMsg('سکه کافی نداری!'); setTimeout(() => setMsg(''), 1600); return; }
    audio.unlock();
    setSave(x => ({ ...x, coins: x.coins - def.unlock, owned: [...x.owned, sel] }));
  };
  const equip = () => {
    audio.buy();
    if (def.slot === 0) setSave(x => ({ ...x, primary: sel }));
    if (def.slot === 1) setSave(x => ({ ...x, secondary: sel }));
  };
  const equipped = s.primary === sel || s.secondary === sel;
  const stats: [string, number][] = [
    ['قدرت', Math.min(1, def.damage / 115)],
    ['سرعت شلیک', Math.min(1, def.fireRate / 14)],
    ['دقت', Math.max(0.05, 1 - def.spread * 30)],
    ['تحرک', Math.min(1, (def.speedMul - 0.7) / 0.45)],
    ['برد', Math.min(1, def.range / 250)],
  ];
  const patterns: [Pattern, string][] = [['solid', 'ساده'], ['stripes', 'راه‌راه'], ['camo', 'استتار'], ['tiger', 'ببری'], ['digital', 'دیجیتال'], ['hex', 'شش‌ضلعی']];
  return (
    <div className="fixed inset-0 flex flex-col bg-[#0e0f11]">
      <TopBar title="اسلحه‌خانه" onBack={onBack} />
      <div className="flex-1 min-h-0 flex gap-2 p-2">
        <div className="w-[30%] min-w-[150px] scroll-y flex flex-col gap-1">
          {list.map(w => {
            const own = s.owned.includes(w.id) || s.mods.allUnlocked;
            return (
              <button key={w.id} onClick={() => { audio.ui(); setSel(w.id); }}
                className={`flex items-center gap-2 rounded-md px-2 py-1.5 border text-right transition ${sel === w.id ? 'bg-amber-500/15 border-amber-400' : 'bg-white/[0.03] border-white/5 hover:border-white/20'}`}>
                <GunSil type={w.type} className={`w-12 h-4 shrink-0 ${own ? 'text-white/85' : 'text-white/25'}`} />
                <div className="flex-1 min-w-0">
                  <div className={`text-xs font-bold truncate ${own ? '' : 'text-white/40'}`}>{w.name}</div>
                  <div className="text-[9px] text-white/40">{TYPE_FA[w.type]}</div>
                </div>
                {!own && <span className="w-3.5 h-3.5 text-amber-400 shrink-0">{Ico.lock()}</span>}
                {(s.primary === w.id || s.secondary === w.id) && <span className="text-[9px] text-lime-400 shrink-0">✓</span>}
              </button>
            );
          })}
        </div>
        <div className="flex-1 min-w-0 flex flex-col rounded-lg overflow-hidden relative" style={{ background: 'radial-gradient(ellipse at 50% 40%, #3a3330 0%, #1a1716 60%, #0c0b0b 100%)' }}>
          <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent 0 22px, rgba(0,0,0,.6) 22px 24px), repeating-linear-gradient(90deg, transparent 0 46px, rgba(0,0,0,.5) 46px 48px)' }} />
          <div className="relative flex-1 min-h-0"><WeaponPreview id={sel} skin={skin} /></div>
          <div className="absolute top-2 right-3 text-right pointer-events-none">
            <div className="font-black text-xl text-white drop-shadow">{def.name}</div>
            <div className="text-[10px] font-ops text-amber-300" dir="ltr">{def.en}</div>
          </div>
          <div className="relative p-2 bg-black/50 grid grid-cols-5 gap-2">
            {stats.map(([n, v]) => (
              <div key={n}><div className="text-[9px] text-white/60">{n}</div><div className="h-1.5 bg-white/10 rounded overflow-hidden"><div className="h-full bg-gradient-to-l from-amber-300 to-amber-600" style={{ width: `${v * 100}%` }} /></div></div>
            ))}
          </div>
          <div className="relative flex gap-2 p-2 bg-black/60">
            {owned ? (
              def.slot === 2 ? <div className="flex-1 text-center text-xs text-white/60 py-2">چاقو همیشه همراه شماست</div> :
                <button onClick={equip} disabled={equipped} className={`btn-mil flex-1 py-2 rounded ${equipped ? 'opacity-60' : 'btn-gold'}`}>{equipped ? '✓ مجهز شده' : def.slot === 0 ? 'تجهیز به عنوان سلاح اصلی' : 'تجهیز به عنوان کلت'}</button>
            ) : (
              <button onClick={unlock} className="btn-mil btn-gold flex-1 py-2 rounded flex items-center justify-center gap-2">باز کردن با <span className="w-4 h-4">{Ico.coin()}</span>{faNum(def.unlock)}</button>
            )}
            {msg && <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-red-600 px-3 py-1 rounded text-xs shake">{msg}</div>}
          </div>
        </div>
        <div className="w-[27%] min-w-[150px] metal-panel rounded-lg p-2 scroll-y flex flex-col gap-2">
          <div className="text-sm font-black text-amber-400">🎨 ساخت اسکین</div>
          {(['c1', 'c2', 'c3'] as const).map((k, i) => (
            <label key={k} className="flex items-center gap-2 text-xs">
              <span className="w-14">رنگ {fa(i + 1)}</span>
              <input type="color" value={skin[k]} onChange={e => setSkin({ [k]: e.target.value })} className="flex-1 h-7 rounded cursor-pointer" />
            </label>
          ))}
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={skin.metal} onChange={e => setSkin({ metal: e.target.checked })} className="w-4 h-4 accent-amber-400" /> فلزی (براق)
          </label>
          <div className="text-[11px] text-white/50">طرح</div>
          <div className="grid grid-cols-3 gap-1">
            {patterns.map(([p, n]) => <button key={p} onClick={() => setSkin({ pattern: p })} className={`btn-mil rounded py-1 text-[10px] ${skin.pattern === p ? '!border-amber-400 text-amber-300' : ''}`}>{n}</button>)}
          </div>
          <div className="text-[11px] text-white/50">اسکین‌های آماده</div>
          <div className="grid grid-cols-3 gap-1">
            {SKIN_PRESETS.map(p => (
              <button key={p.name} onClick={() => { audio.ui(); setSkin(p.skin); }} className="rounded overflow-hidden border border-white/10 hover:border-amber-400">
                <div className="h-5 flex"><div className="flex-1" style={{ background: p.skin.c1 }} /><div className="flex-1" style={{ background: p.skin.c2 }} /><div className="w-2" style={{ background: p.skin.c3 }} /></div>
                <div className="text-[9px] py-0.5 bg-black/60">{p.name}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= CODES ================= */
const MOD_LABELS: { k: keyof Mods; t: string; need: 'code1' | 'code2' | 'code3' }[] = [
  { k: 'infMoney', t: 'پول نامحدود', need: 'code1' },
  { k: 'allUnlocked', t: 'همه اسلحه‌ها باز', need: 'code1' },
  { k: 'god', t: 'جان بی‌نهایت', need: 'code2' },
  { k: 'infAmmo', t: 'مهمات بی‌نهایت', need: 'code2' },
  { k: 'noReload', t: 'خشاب‌گذاری فوری', need: 'code2' },
  { k: 'oneShot', t: 'کشتن با یک تیر', need: 'code3' },
  { k: 'noRecoil', t: 'بدون لگد', need: 'code3' },
  { k: 'speed', t: 'سرعت ۲ برابر', need: 'code3' },
  { k: 'highJump', t: 'پرش بلند', need: 'code3' },
  { k: 'wallhack', t: 'دید از پشت دیوار', need: 'code3' },
  { k: 'rapidFire', t: 'شلیک سریع', need: 'code3' },
  { k: 'aimAssist', t: 'کمک نشانه‌گیری', need: 'code3' },
];

export function CodesScreen({ onBack }: { onBack: () => void }) {
  const s = useSave();
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ t: string; ok: boolean; k: number } | null>(null);
  const press = (d: string) => { audio.click(0.3); setCode(c => (c.length < 6 ? c + d : c)); };
  const submit = () => {
    const r = redeemCode(code);
    if (r === null) { audio.error(); setMsg({ t: 'کد نامعتبر است!', ok: false, k: Date.now() }); }
    else if (r === 'used') { audio.error(); setMsg({ t: 'این کد قبلاً فعال شده است', ok: false, k: Date.now() }); }
    else { audio.unlock(); setMsg({ t: `✓ ${r.title} فعال شد!`, ok: true, k: Date.now() }); }
    setCode('');
  };
  const full = isFullMod(s.mods);
  return (
    <div className="fixed inset-0 flex flex-col bg-[#0b0b0d]">
      <TopBar title="🔑 کدهای مخفی" onBack={onBack} />
      <div className="flex-1 min-h-0 flex gap-3 p-3">
        <div className="w-[40%] min-w-[220px] metal-panel rounded-xl p-3 flex flex-col items-center scroll-y">
          <div className="text-sm text-white/70 mb-2">کد ۶ رقمی را وارد کنید</div>
          <div key={msg && !msg.ok ? msg.k : 0} className={`flex gap-1.5 mb-2 ${msg && !msg.ok ? 'shake' : ''}`} dir="ltr">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className={`w-9 h-11 tall:w-11 tall:h-13 rounded-md border-2 flex items-center justify-center text-2xl font-black ${code[i] ? 'border-amber-400 bg-amber-400/10 text-amber-300' : 'border-white/15 bg-black/40'}`}>{code[i] ? fa(code[i]) : ''}</div>
            ))}
          </div>
          {msg && <div key={msg.k} className={`text-sm font-bold mb-2 pop-in ${msg.ok ? 'text-lime-400' : 'text-red-400'}`}>{msg.t}</div>}
          <div className="grid grid-cols-3 gap-1.5 w-full max-w-[260px]" dir="ltr">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(d => <button key={d} onClick={() => press(d)} className="btn-mil rounded-lg py-2 text-xl">{fa(d)}</button>)}
            <button onClick={() => { audio.click(0.3); setCode(c => c.slice(0, -1)); }} className="btn-mil rounded-lg py-2 text-red-300">⌫</button>
            <button onClick={() => press('0')} className="btn-mil rounded-lg py-2 text-xl">{fa(0)}</button>
            <button onClick={submit} disabled={code.length < 6} className={`btn-mil rounded-lg py-2 ${code.length === 6 ? 'btn-gold' : 'opacity-50'}`}>✓</button>
          </div>
        </div>
        <div className="flex-1 min-w-0 scroll-y flex flex-col gap-2">
          {full && (
            <div className="rounded-xl p-3 bg-gradient-to-l from-red-700/80 via-amber-600/70 to-red-700/80 border border-amber-300 text-center pop-in shine">
              <div className="text-xl font-black">⚡ تبریک! بازی کاملاً مود شد ⚡</div>
              <div className="text-xs text-white/90">همه قابلیت‌های ویژه فعال هستند – می‌توانید هر کدام را خاموش یا روشن کنید</div>
            </div>
          )}
          {CODES.map(c => {
            const on = s.mods[c.key];
            return (
              <div key={c.key} className={`rounded-xl p-3 border transition ${on ? 'bg-black/50' : 'bg-white/[0.03] border-white/10'}`} style={on ? { borderColor: c.color, boxShadow: `0 0 18px ${c.color}44` } : {}}>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: on ? c.color : '#333', color: '#000' }}>{on ? '✓' : <span className="w-4 h-4 text-white/60">{Ico.lock()}</span>}</div>
                  <div className="font-black" style={{ color: on ? c.color : '#aaa' }}>{on ? c.title : 'پکیج قفل شده'}</div>
                  <div className="flex-1" />
                  <div className={`text-[10px] px-2 py-0.5 rounded ${on ? 'bg-lime-500 text-black font-bold' : 'bg-white/10 text-white/50'}`}>{on ? 'فعال' : 'غیرفعال'}</div>
                </div>
                {on ? (
                  <div className="flex flex-wrap gap-1 mt-2">{c.desc.map(d => <span key={d} className="text-[11px] bg-white/10 rounded px-2 py-0.5">{d}</span>)}</div>
                ) : <div className="text-[11px] text-white/40 mt-1">برای باز کردن این پکیج کد مخفی را وارد کنید...</div>}
              </div>
            );
          })}
          {(s.mods.code1 || s.mods.code2 || s.mods.code3) && (
            <div className="metal-panel rounded-xl p-3">
              <div className="text-sm font-black text-amber-400 mb-2">🛠 منوی مود</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-1.5">
                {MOD_LABELS.filter(m => s.mods[m.need]).map(m => (
                  <button key={m.k} onClick={() => { audio.click(0.3); setSave(x => ({ ...x, mods: { ...x.mods, [m.k]: !x.mods[m.k] } })); }}
                    className={`flex items-center justify-between rounded-md px-2 py-1.5 text-xs border ${s.mods[m.k] ? 'bg-lime-500/15 border-lime-400/60' : 'bg-black/30 border-white/10'}`}>
                    <span>{m.t}</span>
                    <span className={`w-8 h-4 rounded-full relative transition ${s.mods[m.k] ? 'bg-lime-500' : 'bg-white/20'}`}><span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${s.mods[m.k] ? 'left-0.5' : 'left-4'}`} /></span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================= SETTINGS ================= */
function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 py-2 border-b border-white/5"><div className="w-36 text-sm text-white/80 shrink-0">{label}</div><div className="flex-1 flex items-center gap-2">{children}</div></div>
  );
}

export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const s = useSave();
  const st = s.settings;
  const set = (p: Partial<typeof st>) => setSave(x => ({ ...x, settings: { ...x.settings, ...p } }));
  const [confirm, setConfirm] = useState(false);
  return (
    <div className="fixed inset-0 flex flex-col bg-[#0e0f11]">
      <TopBar title="⚙ تنظیمات" onBack={onBack} />
      <div className="flex-1 min-h-0 scroll-y p-3">
        <div className="max-w-[720px] mx-auto metal-panel rounded-xl px-4 py-2">
          <Row label="نام بازیکن"><input value={s.name} maxLength={14} onChange={e => setSave(x => ({ ...x, name: e.target.value }))} className="flex-1 bg-black/50 border border-white/15 rounded px-2 py-1 text-sm outline-none focus:border-amber-400" /></Row>
          <Row label="حساسیت نشانه‌گیری"><input type="range" min={0.2} max={3} step={0.1} value={st.sens} onChange={e => set({ sens: +e.target.value })} className="flex-1" /><span className="w-10 text-amber-300 text-sm">{fa(st.sens.toFixed(1))}</span></Row>
          <Row label="میدان دید (FOV)"><input type="range" min={60} max={100} step={1} value={st.fov} onChange={e => set({ fov: +e.target.value })} className="flex-1" /><span className="w-10 text-amber-300 text-sm">{fa(st.fov)}</span></Row>
          <Row label="صدا"><input type="range" min={0} max={1} step={0.05} value={st.volume} onChange={e => { set({ volume: +e.target.value }); audio.setVolume(+e.target.value); }} className="flex-1" /><span className="w-10 text-amber-300 text-sm">{fa(Math.round(st.volume * 100))}</span></Row>
          <Row label="کیفیت گرافیک">
            {([['low', 'پایین'], ['med', 'متوسط'], ['high', 'بالا (HD)']] as const).map(([q, t]) => <button key={q} onClick={() => set({ quality: q })} className={`btn-mil flex-1 rounded py-1.5 text-xs ${st.quality === q ? '!border-amber-400 text-amber-300' : ''}`}>{t}</button>)}
          </Row>
          <Row label="اندازه دکمه‌ها"><input type="range" min={0.75} max={1.3} step={0.05} value={st.btnScale} onChange={e => set({ btnScale: +e.target.value })} className="flex-1" /><span className="w-10 text-amber-300 text-sm">{fa(Math.round(st.btnScale * 100))}٪</span></Row>
          <Row label="دکمه شلیک چپ"><button onClick={() => set({ leftFire: !st.leftFire })} className={`btn-mil rounded px-4 py-1 text-xs ${st.leftFire ? 'text-lime-400' : ''}`}>{st.leftFire ? 'روشن' : 'خاموش'}</button></Row>
          <Row label="نمایش FPS"><button onClick={() => set({ showFps: !st.showFps })} className={`btn-mil rounded px-4 py-1 text-xs ${st.showFps ? 'text-lime-400' : ''}`}>{st.showFps ? 'روشن' : 'خاموش'}</button></Row>
          <Row label="پاک کردن پیشرفت">
            {!confirm ? <button onClick={() => setConfirm(true)} className="btn-mil rounded px-4 py-1 text-xs text-red-400">ریست کامل</button> :
              <><span className="text-xs text-red-300">مطمئنی؟</span><button onClick={() => { resetSave(); setConfirm(false); }} className="btn-mil rounded px-3 py-1 text-xs text-red-400">بله</button><button onClick={() => setConfirm(false)} className="btn-mil rounded px-3 py-1 text-xs">خیر</button></>}
          </Row>
          <div className="text-[11px] text-white/40 py-2 leading-6">کنترل موبایل: سمت چپ صفحه جوی‌استیک حرکت · کشیدن انگشت در سمت راست برای چرخش دوربین · دکمه شلیک را هم می‌توانید بکشید تا همزمان نشانه بگیرید.</div>
        </div>
      </div>
    </div>
  );
}

/* ================= RESULTS ================= */
export function Results({ r, onAgain, onMenu }: { r: MatchResult; onAgain: () => void; onMenu: () => void }) {
  const title = r.win === null ? 'مساوی' : r.win ? 'پیروزی' : 'شکست';
  const col = r.win === null ? '#ddd' : r.win ? '#ffd000' : '#ff4a4a';
  const items: [string, string][] = [['کشته', fa(r.kills)], ['مرگ', fa(r.deaths)], ['هدشات', fa(r.hs)], ['K/D', fa((r.kills / Math.max(1, r.deaths)).toFixed(2))]];
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black">
      <img src={heroImg} className="absolute inset-0 w-full h-full object-cover opacity-25 blur-sm" alt="" />
      <div className="relative metal-panel rounded-2xl p-5 w-[min(560px,92vw)] text-center pop-in">
        <div className="text-5xl tall:text-6xl font-black" style={{ color: col, textShadow: `0 0 30px ${col}66` }}>{title}</div>
        <div className="text-white/80 mt-1">{r.title}</div>
        <div className="text-xs text-white/50 mt-1">{MODES.find(m => m.id === r.mode)?.name} · {r.map} · نتیجه: {fa(r.score)}</div>
        <div className="grid grid-cols-4 gap-2 my-4">
          {items.map(([k, v]) => <div key={k} className="bg-black/40 rounded-lg py-2"><div className="text-2xl font-black">{v}</div><div className="text-[11px] text-white/50">{k}</div></div>)}
        </div>
        <div className="flex justify-center gap-4 mb-4">
          <div className="flex items-center gap-1.5 bg-amber-500/15 border border-amber-400/50 rounded-full px-4 py-1"><span className="w-5 h-5">{Ico.coin()}</span><span className="font-black text-amber-300">+{faNum(r.coins)}</span></div>
          <div className="flex items-center gap-1.5 bg-sky-500/15 border border-sky-400/50 rounded-full px-4 py-1"><span className="font-black text-sky-300">+{faNum(r.xp)} XP</span></div>
        </div>
        <div className="flex gap-2">
          <button onClick={onAgain} className="btn-mil btn-gold flex-1 py-3 rounded-lg text-lg">↻ دوباره</button>
          <button onClick={onMenu} className="btn-mil flex-1 py-3 rounded-lg">منوی اصلی</button>
        </div>
      </div>
    </div>
  );
}
