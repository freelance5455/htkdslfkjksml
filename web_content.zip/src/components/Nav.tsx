import { IconLogo } from "./Icons";

interface Props {
  online: boolean;
}

const LINKS = [
  { href: "#models", label: "Models" },
  { href: "#forge", label: "Forge" },
  { href: "#arcade", label: "Arcade" },
  { href: "#voice", label: "Voice" },
];

export default function Nav({ online }: Props) {
  return (
    <header className="fixed top-0 inset-x-0 z-50 border-b border-line/70 bg-ink/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-5 h-16 flex items-center gap-6">
        <a href="#top" className="flex items-center gap-2.5 group">
          <IconLogo size={30} className="transition-transform duration-500 group-hover:rotate-[360deg]" />
          <span className="font-display font-bold tracking-wide text-[15px] text-snow">
            YUNO<span className="text-ember">AI</span>
          </span>
          <span className="hidden sm:inline-block font-mono text-[9px] tracking-[0.22em] text-teal border border-teal/40 px-1.5 py-0.5 clip-tag">
            v2.4
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-1 ml-4">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="px-3.5 py-2 text-[13px] font-medium text-fog hover:text-ember transition-colors relative group"
            >
              {l.label}
              <span className="absolute left-3.5 right-3.5 -bottom-[1px] h-px bg-ember scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300" />
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <span
            className={`hidden sm:flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] px-2.5 py-1.5 clip-tag border ${
              online ? "border-line2 text-fog" : "border-teal/50 text-teal"
            }`}
            title={online ? "Connected — but everything still runs locally" : "No network — fully operational"}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${online ? "bg-teal pulse-dot" : "bg-ember pulse-dot-ember"}`} />
            {online ? "LOCAL RUNTIME" : "OFFLINE MODE"}
          </span>
          <a
            href="#forge"
            className="btn-primary clip-hud-sm px-4 py-2 text-[12px] font-bold font-mono tracking-[0.14em]"
          >
            START FORGING
          </a>
        </div>
      </div>
    </header>
  );
}
