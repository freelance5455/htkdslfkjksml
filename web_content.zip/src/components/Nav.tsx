import { useEffect, useState } from "react";
import { Contrast, Download, Menu, MonitorPlay, X } from "lucide-react";
import Logo from "./Logo";
import { NAV_LINKS } from "../lib/data";

export default function Nav({ onOpenApp }: { onOpenApp?: () => void }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [hc, setHc] = useState(false);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const y = window.scrollY || 0;
        setScrolled(y > 24);
        const max = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(max > 0 ? Math.min(1, y / max) : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("hc", hc);
    return () => document.documentElement.classList.remove("hc");
  }, [hc]);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      {/* scroll progress */}
      <div
        aria-hidden="true"
        className="h-[2.5px] origin-left bg-gradient-to-r from-cyanx via-electric to-violetx"
        style={{ transform: `scaleX(${progress})` }}
      />
      <nav
        className={`mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 transition-all duration-300 sm:px-6 ${
          scrolled ? "my-2 rounded-2xl border border-white/10 bg-[#060b24]/85 py-2 shadow-2xl shadow-black/50 backdrop-blur-xl" : "py-3"
        }`}
        aria-label="Navegación principal"
      >
        <Logo compact={scrolled} />

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setHc((v) => !v)}
            aria-pressed={hc}
            title="Alternar modo de alto contraste"
            aria-label="Alternar modo de alto contraste"
            className="ghost-btn hidden h-10 w-10 items-center justify-center rounded-xl text-slate-200 sm:flex"
          >
            <Contrast size={18} strokeWidth={2} />
          </button>
          {onOpenApp ? (
            <button onClick={onOpenApp} className="grad-btn hidden h-10 items-center gap-2 rounded-xl px-4 text-sm font-bold text-white sm:inline-flex">
              <MonitorPlay size={16} strokeWidth={2.5} />
              Abrir TV LO3
            </button>
          ) : (
            <a
              href="#descargar"
              className="grad-btn hidden h-10 items-center gap-2 rounded-xl px-4 text-sm font-bold text-white sm:inline-flex"
            >
              <Download size={16} strokeWidth={2.5} />
              Descargar APK
            </a>
          )}
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* mobile panel */}
      {open && (
        <div id="mobile-menu" className="mx-4 rounded-2xl border border-white/10 bg-[#060b24]/95 p-4 shadow-2xl backdrop-blur-xl lg:hidden">
          <ul className="grid gap-1">
            {NAV_LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-xl px-4 py-3 text-base font-medium text-slate-100 transition-colors hover:bg-white/5"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex items-center gap-2 border-t border-white/10 pt-3">
            {onOpenApp ? (
              <button onClick={() => { setOpen(false); onOpenApp(); }} className="grad-btn flex h-12 flex-1 items-center justify-center gap-2 rounded-xl font-bold text-white">
                <MonitorPlay size={18} /> Abrir TV LO3
              </button>
            ) : (
              <a
                href="#descargar"
                onClick={() => setOpen(false)}
                className="grad-btn flex h-12 flex-1 items-center justify-center gap-2 rounded-xl font-bold text-white"
              >
                <Download size={18} /> Descargar APK gratis
              </a>
            )}
            <button
              type="button"
              onClick={() => setHc((v) => !v)}
              aria-pressed={hc}
              aria-label="Alternar modo de alto contraste"
              className="ghost-btn flex h-12 w-12 items-center justify-center rounded-xl text-slate-100"
            >
              <Contrast size={20} />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
