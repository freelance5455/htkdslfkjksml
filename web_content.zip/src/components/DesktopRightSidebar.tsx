import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Gift, 
  Share2, 
  Copy, 
  Check, 
  Sparkles, 
  Trophy, 
  ShieldCheck, 
  Flame, 
  ArrowRight, 
  Coins 
} from 'lucide-react';
import { INITIAL_LEADERBOARD } from '../utils/mockData';

export const DesktopRightSidebar: React.FC = () => {
  const { 
    user, 
    referralCode, 
    secretCoins, 
    simulateInviteFriend, 
    setActiveTab, 
    polls, 
    votePoll 
  } = useApp();

  const [copied, setCopied] = useState(false);

  const deepLink = `https://secretgossip.app/join?campus=${user.collegeCode}&ref=${referralCode}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(deepLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const activePoll = polls[0];

  return (
    <aside className="w-80 shrink-0 hidden xl:flex flex-col gap-5 py-6 pl-4 pr-2 sticky top-0 h-screen overflow-y-auto border-l border-slate-800/80">
      
      {/* 1. Mini Referral Widget Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121629] via-[#0d1020] to-[#070912] border border-cyan-500/40 p-4 shadow-xl neon-glow-cyan space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-amber-400 font-bold">
            <Gift className="w-4 h-4" />
            <span>Referral Engine</span>
          </div>
          <span className="font-mono text-[10px] text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/30">
            +100 🪙 / friend
          </span>
        </div>

        <div>
          <h4 className="font-display font-extrabold text-sm text-slate-100">
            Invite College Friends
          </h4>
          <p className="text-[11px] text-slate-300 leading-relaxed mt-0.5">
            Earn Secret Coins to unlock Post Flame Boosts and exclusive VIP badges.
          </p>
        </div>

        {/* Link Bar with 1-click copy */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px]">
          <span className="font-mono text-cyan-400 truncate pl-2 flex-1">
            {referralCode}
          </span>
          <button
            onClick={handleCopy}
            className="px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-[10px] transition-all flex items-center gap-1"
          >
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <div className="flex items-center justify-between pt-1 text-[11px]">
          <button
            onClick={simulateInviteFriend}
            className="text-purple-300 hover:text-purple-200 flex items-center gap-1 text-[10px] font-semibold"
            title="Simulate someone joining"
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>Simulate Invite</span>
          </button>

          <button
            onClick={() => setActiveTab('referral')}
            className="text-cyan-400 hover:underline font-semibold flex items-center gap-0.5"
          >
            <span>Coins Shop</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 2. Campus Dilemma Poll Preview */}
      {activePoll && (
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold tracking-wider">
              {activePoll.category}
            </span>
            <span className="text-[10px] text-slate-500">{activePoll.expiresIn}</span>
          </div>

          <h5 className="font-semibold text-xs text-slate-200 leading-snug">
            {activePoll.question}
          </h5>

          <div className="space-y-1.5 pt-1">
            {activePoll.options.slice(0, 2).map(opt => {
              const hasVoted = Boolean(activePoll.userVotedOptionId);
              const percentage = activePoll.totalVotes > 0 
                ? Math.round((opt.votes / activePoll.totalVotes) * 100) 
                : 50;

              return (
                <button
                  key={opt.id}
                  onClick={() => votePoll(activePoll.id, opt.id)}
                  disabled={hasVoted}
                  className={`w-full p-2 rounded-xl border text-left text-xs transition-all relative overflow-hidden ${
                    activePoll.userVotedOptionId === opt.id 
                      ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200' 
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {hasVoted && (
                    <div 
                      className="absolute top-0 bottom-0 left-0 bg-cyan-500/20"
                      style={{ width: `${percentage}%` }}
                    />
                  )}
                  <div className="relative z-10 flex items-center justify-between text-[11px]">
                    <span className="truncate pr-2">{opt.text}</span>
                    {hasVoted && <span className="font-mono font-bold">{percentage}%</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. Top Whispers Hall of Fame Preview */}
      <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between">
          <h4 className="font-display font-bold text-xs text-slate-200 flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>Top Campus Ranks</span>
          </h4>
          <button
            onClick={() => setActiveTab('leaderboard')}
            className="text-[10px] text-cyan-400 hover:underline font-semibold"
          >
            Full View →
          </button>
        </div>

        <div className="space-y-2">
          {INITIAL_LEADERBOARD.slice(0, 3).map((item, idx) => (
            <div key={item.rank} className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-slate-500 w-3">{idx + 1}</span>
                <span className="text-base">{item.emoji}</span>
                <span className="text-slate-300 font-medium truncate max-w-[110px]">{item.name}</span>
              </div>
              <span className="font-mono text-[11px] text-amber-300 font-semibold">{item.karma}k</span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Privacy & Zero-Knowledge Cryptography Card */}
      <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
        <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Zero-Identity Leakage</span>
        </div>
        <p className="text-[10px] text-slate-500 leading-relaxed">
          Your real phone & email are one-way SHA-256 hashed. Even platform engineers and college administrators cannot trace a confession back to you.
        </p>
      </div>

    </aside>
  );
};
