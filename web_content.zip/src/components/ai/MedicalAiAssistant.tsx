import React, { useState } from 'react';
import { Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { 
  Bot, 
  Send, 
  Sparkles, 
  AlertTriangle, 
  Wifi, 
  WifiOff, 
  RotateCcw,
  BookOpen,
  CheckCircle2
} from 'lucide-react';

interface Props {
  language: Language;
  soundEnabled: boolean;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  source?: 'gemini-live' | 'local-offline';
}

const PRESET_QUESTIONS = [
  'شرح مبدأ ALARA في مستشفيات الجزائر',
  'كيفية إعطاء أمر حبس النفس للمريض بالدارجة والفرنسية',
  'الفرق الجوهري بين T1 و T2 في الرنين المغناطيسي',
  'معايير نجاح صورة الصدر PA الوقوفية',
  'موانع حقن مادة التباين اليودية في السكانير'
];

export const MedicalAiAssistant: React.FC<Props> = ({ language, soundEnabled }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: language === 'ar'
        ? 'أهلاً بك أيها الصياد! أنا المساعد الذكي "ظِل الأشعة" (Shadow Radiology AI). يمكنني شرح الدروس، التفسير الفيزيائي للأشعة، تحليل الوضعيات الشعاعية، وتقديم نصائح للمتدربين في المستشفيات الجزائرية. كيف أساعدك اليوم؟'
        : 'Bienvenue, Chasseur ! Je suis l’IA pédagogique Shadow Radiology. Je peux vous expliquer les incidences, la physique des rayonnements, l’IRM, le scanner TDM et la radioprotection. Quelle est votre question ?',
      source: 'local-offline'
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOnlineMode, setIsOnlineMode] = useState<boolean>(true);

  // Local offline knowledge base answers for instant reliable assistance
  const getOfflineMedicalAnswer = (query: string): string => {
    const q = query.toLowerCase();

    if (q.includes('alara') || q.includes('وقاية') || q.includes('حماية')) {
      return `🛡️ **مبدأ ALARA وقوانين الوقاية الإشعاعية في الجزائر**:
1. **المفهوم**: "As Low As Reasonably Achievable" أي إبقاء التعرض عند أدنى حد ممكن منطقياً.
2. **الأركان الثلاثة**:
   - **الزمن**: تقليص وقت التعريض وسرعة إنجاز الفحص.
   - **المسافة**: مضاعفة المسافة عن الأنبوب يقلل الجرعة إلى الربع (قانون 1/d²).
   - **الحاجز**: ارتداء مريلة الرصاص (0.5 mm Pb)، واقي الغدة الدرقية، والنظارات الرصاصية.
3. **الحد القانوني للمهنيين (Manipulateurs)**: 20 ملي سيفرت (20 mSv) سنوياً حسب التشريع الجزائري.
⚠️ *تنويه: المحتوى تعليمي لطلبة الشبه طبي.*`;
    }

    if (q.includes('نفس') || q.includes('دارجة') || q.includes('توجيه') || q.includes('patient') || q.includes('صدر')) {
      return `🗣️ **توجيه المريض لصورة الصدر (Communication Soignant-Soigné)**:
1. **باللغة الفرنسية**:
   - « Enlevez les chaînes métalliques et soutiens-gorge. »
   - « Collez la poitrine à la plaque, roulez les épaules en avant. »
   - « Inspirez à fond... Bloquez la respiration ! ... Respirez. »
2. **بالدارجة الجزائرية**:
   - « نحّي السنسلة والخواتم والحديد اللي في صدرك. »
   - « لصّق صدرك مليح في اللوحة ودور كتافك ومرافقك للقدام. »
   - « تنفس مليح بعمق... احكم النفس وما تتحركش ! ... تنفس عادي خلاص. »
3. **أهمية ذلك**: الشهيق العميق يظهر 10 أضلاع خلفية فوق الحجاب الحاجز لطرد الشبهات المرضية.`;
    }

    if (q.includes('t1') || q.includes('t2') || q.includes('رنين') || q.includes('irm')) {
      return `🧲 **المقارنة بين تسلسلي T1 و T2 في الرنين المغناطيسي (IRM)**:
- **تسلسل T1 (تشريحي)**:
  - الماء والسائل الدماغي (LCR): **أسود معتم** (Hypointense).
  - الدهون (Graisse): **بيضاء ناصعة** (Hyperintense).
  - الاستعمال: دراسة التشريح الدقيق ومتابعة التباين بعد حقن الغادولينيوم.
- **تسلسل T2 (مرضي - Pathologique)**:
  - الماء والالتهابات والوذمات: **بيضاء مضيئة** (Hyperintense).
  - الاستعمال: كشف الأورام والوذمات والارتشاحات المفصلية.
💡 *قاعدة الحفظ السريعة: في T1 الماء أسود، وفي T2 الماء أبيض.*`;
    }

    if (q.includes('تباين') || q.includes('يود') || q.includes('سكانير') || q.includes('contraste') || q.includes('tdm')) {
      return `💉 **بروتوكول مادة التباين اليودية (PCI) في المفراس TDM**:
1. **الموانع والفحوصات القبلية**:
   - فحص وظائف الكلى: الكرياتينين ومعدل الترشيح DFG > 30 ml/min.
   - التحقق الصارم من غياب صدمة تحسسية سابقة.
2. **الكانيولا الوريدية**: مقاس 18G أو 20G لتحمل ضخ الحاقن الآلي (3 إلى 4 ml/s).
3. **طمأنة المريض**: إخباره بأن إحساس الحرارة وسخونة الحلق أمر طبيعي يزول خلال 30 ثانية.
4. **في حال الطوارئ التحسسية**: إيقاف الحقن فوراً واستدعاء طبيب التخدير وحقن الأدرينالين.`;
    }

    return `💡 **إجابة المساعد الطبي (ظِل الأشعة)**:
بناءً على المعارف الشعاعية المعتمدة لطلبة الشبه طبي:
- سؤالك يتعلق بموضوع تقني دقيق في التصوير الطبي.
- ننصح بالرجوع إلى وحدة الأكاديمية لمراجعة بروتوكولات الفحص وخطوات السلامة الإشعاعية.
- في الممارسة العملية الاستشفائية، راجع دائماً مع التقني المشرف (Manipulateur Référent) قبل تطبيق أي تقنية على مريض حقيقي.`;
  };

  const handleSendMessage = async (textToSend?: string) => {
    const prompt = (textToSend || inputPrompt).trim();
    if (!prompt || isLoading) return;

    soundManager.playTick(soundEnabled);
    const userMsg: Message = { id: `u-${Date.now()}`, role: 'user', content: prompt };
    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    // Try calling live backend first
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          conversationHistory: messages.slice(-4),
          language
        })
      });

      if (response.ok) {
        const data = await response.json();
        const aiMsg: Message = {
          id: `ai-${Date.now()}`,
          role: 'assistant',
          content: data.reply,
          source: 'gemini-live'
        };
        setMessages((prev) => [...prev, aiMsg]);
        setIsOnlineMode(true);
        soundManager.playSuccess(soundEnabled);
      } else {
        // Fallback to offline knowledge base
        throw new Error('API unavailable, switching to local offline engine');
      }
    } catch {
      // Local offline engine response
      setIsOnlineMode(false);
      const offlineReply = getOfflineMedicalAnswer(prompt);
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: offlineReply,
        source: 'local-offline'
      };
      setMessages((prev) => [...prev, aiMsg]);
      soundManager.playTick(soundEnabled);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {/* AI Header Card */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-indigo-950 p-4 rounded-2xl border border-purple-500/40 shadow-neon-purple text-right">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-400 flex items-center justify-center text-purple-300">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-100 flex items-center gap-2">
                <span>المساعد الطبي الذكي (Shadow Radiology AI)</span>
                <span className="text-[10px] bg-purple-900/80 text-purple-300 px-2 py-0.5 rounded-full border border-purple-400/40 font-mono">
                  Gemini 2.5 + Local Engine
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                شرح المفاهيم الطبية الشعاعية وتقديم أمثلة تعليمية تفاعلية بالفرنسية والعربية.
              </p>
            </div>
          </div>

          {/* Mode Indicator */}
          <div className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-black/60 border border-purple-900/40">
            {isOnlineMode ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300">متصل (Gemini AI)</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-amber-300">وضع المعرفة المحلي (Offline)</span>
              </>
            )}
          </div>
        </div>

        {/* Quick Prompt Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-3 pb-1 no-scrollbar text-xs">
          <span className="text-purple-400 font-bold whitespace-nowrap">أسئلة شائعة:</span>
          {PRESET_QUESTIONS.map((pq, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(pq)}
              className="px-3 py-1 bg-purple-950/70 hover:bg-purple-800 text-purple-200 rounded-lg border border-purple-800/40 whitespace-nowrap transition-colors"
            >
              {pq}
            </button>
          ))}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="h-[420px] overflow-y-auto bg-slate-950/70 p-4 rounded-2xl border border-purple-900/30 flex flex-col gap-3">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col max-w-[85%] text-right text-xs md:text-sm leading-relaxed p-3.5 rounded-2xl ${
              msg.role === 'user'
                ? 'self-start bg-purple-700 text-white rounded-br-sm shadow-md'
                : 'self-end bg-slate-900/90 text-slate-100 border border-purple-900/50 rounded-bl-sm shadow-inner'
            }`}
          >
            {msg.role === 'assistant' && (
              <div className="flex items-center justify-between text-[10px] text-purple-400 mb-1 border-b border-purple-900/40 pb-1">
                <span className="font-bold">ظِل الأشعة (AI Mentor)</span>
                <span>{msg.source === 'gemini-live' ? '⚡ ذكاء سحابي' : '💾 محرك محلي'}</span>
              </div>
            )}
            <div className="whitespace-pre-line">{msg.content}</div>
          </div>
        ))}

        {isLoading && (
          <div className="self-end bg-slate-900/90 p-3 rounded-2xl border border-purple-900/50 text-xs text-purple-300 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            <span>جاري استحضار المعرفة الشعاعية...</span>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2"
      >
        <input
          type="text"
          value={inputPrompt}
          onChange={(e) => setInputPrompt(e.target.value)}
          placeholder="اطرح سؤالك حول الأشعة، الفيزياء، أو وضعيات المرضى..."
          className="flex-1 px-4 py-3 bg-slate-950/80 text-slate-100 placeholder-slate-500 rounded-xl border border-purple-500/40 focus:outline-none focus:border-purple-400 text-sm"
        />
        <button
          type="submit"
          disabled={!inputPrompt.trim() || isLoading}
          className="p-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl shadow-neon-purple transition-all active:scale-95 disabled:opacity-50"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>

      {/* Medical Disclaimer */}
      <div className="text-[10px] text-slate-500 text-center leading-normal">
        المساعد الذكي مخصص لطلبة الشبه طبي للدراسة الأكاديمية فقط. لا تستخدمه لتشخيص أو علاج الحالات السريرية الحقيقية.
      </div>
    </div>
  );
};
