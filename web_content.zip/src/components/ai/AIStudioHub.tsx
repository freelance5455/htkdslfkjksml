import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  Camera,
  Star,
  MessageSquare,
  Send,
  CheckCircle,
  Copy,
  ChevronRight,
  TrendingUp,
  Cpu,
} from 'lucide-react';

export const AIStudioHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'voice' | 'drafter' | 'reviews' | 'assistant'>('voice');

  // Voice Search Tester
  const [voiceQuery, setVoiceQuery] = useState<string>('Mujhe running shoes dikhao 2000 ke andar with good grip');
  const [voiceResult, setVoiceResult] = useState<any>(null);
  const [isVoiceTesting, setIsVoiceTesting] = useState<boolean>(false);

  // Product Drafter Tester
  const [draftTitle, setDraftTitle] = useState<string>('PCMart ThunderBass 700 ANC Wireless Headphones');
  const [draftCategory, setDraftCategory] = useState<string>('Audio');
  const [draftFeatures, setDraftFeatures] = useState<string>('40mm titanium drivers, 45-hour battery, plush memory foam, 3-mode ANC, low latency');
  const [draftResult, setDraftResult] = useState<any>(null);
  const [isDrafting, setIsDrafting] = useState<boolean>(false);

  // Review Summary Tester
  const [reviewInput, setReviewInput] = useState<string>(
    '1. "Outstanding ANC performance, cancelled out train noise completely on my commute. 5/5"\n' +
    '2. "Soundstage is clear, bass has punch without distortion. Fast 2-day delivery! 5/5"\n' +
    '3. "Ear cushions are very comfortable for 4-hour gaming sessions. Case is a bit large though. 4/5"'
  );
  const [reviewResult, setReviewResult] = useState<any>(null);
  const [isReviewTesting, setIsReviewTesting] = useState<boolean>(false);

  // Conversational Assistant Tester
  const [assistantInput, setAssistantInput] = useState<string>('Which smartwatch is best for swimming and battery life under 4000?');
  const [assistantReply, setAssistantReply] = useState<string>('');
  const [isAssistantTesting, setIsAssistantTesting] = useState<boolean>(false);

  // 1. Run Voice Search Intent
  const runVoiceTest = async (queryToTest?: string) => {
    setIsVoiceTesting(true);
    const q = queryToTest || voiceQuery;
    try {
      const res = await fetch('/api/ai/voice-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q }),
      });
      const data = await res.json();
      setVoiceResult(data.data || data);
    } catch (err: any) {
      setVoiceResult({ error: err.message });
    } finally {
      setIsVoiceTesting(false);
    }
  };

  // 2. Run Product Drafter
  const runDrafterTest = async () => {
    setIsDrafting(true);
    try {
      const res = await fetch('/api/ai/describe-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: draftTitle,
          category: draftCategory,
          initialFeatures: draftFeatures,
        }),
      });
      const data = await res.json();
      setDraftResult(data.data || data.fallback);
    } catch (err: any) {
      setDraftResult({ error: err.message });
    } finally {
      setIsDrafting(false);
    }
  };

  // 3. Run Review Summary
  const runReviewTest = async () => {
    setIsReviewTesting(true);
    try {
      const res = await fetch('/api/ai/review-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: draftTitle,
          reviews: reviewInput.split('\n').map((line, i) => ({ rating: 5, comment: line })),
        }),
      });
      const data = await res.json();
      setReviewResult(data.data || data);
    } catch (err: any) {
      setReviewResult({ error: err.message });
    } finally {
      setIsReviewTesting(false);
    }
  };

  // 4. Run Assistant
  const runAssistantTest = async () => {
    setIsAssistantTesting(true);
    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: assistantInput,
        }),
      });
      const data = await res.json();
      setAssistantReply(data.reply || 'Here is your recommendation.');
    } catch (err: any) {
      setAssistantReply('Assistant connection error: ' + err.message);
    } finally {
      setIsAssistantTesting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#FFD447]" />
            <h1 className="text-xl font-black text-white">PCMART AI & Automation Services Hub</h1>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Powered by Server-Side Gemini 3.8 Flash for multi-lingual search, photo drafting, and review analysis.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="bg-blue-950 text-blue-300 border border-blue-500/40 px-2.5 py-1 rounded-full font-mono font-bold">
            model: gemini-3.8-flash
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-6 flex gap-6 text-xs font-bold text-slate-400 overflow-x-auto">
        <button
          onClick={() => setActiveTab('voice')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'voice' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          1. Hindi / English Voice Search AI
        </button>
        <button
          onClick={() => setActiveTab('drafter')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'drafter' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          2. Photo to Product Description Drafter
        </button>
        <button
          onClick={() => setActiveTab('reviews')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'reviews' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          3. Genuine Review Sentiment & Authenticity
        </button>
        <button
          onClick={() => setActiveTab('assistant')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'assistant' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          4. Grounded Shopping Concierge
        </button>
      </div>

      {/* Content Body */}
      <div className="p-6 flex-1 space-y-6">
        {/* TAB 1: VOICE SEARCH */}
        {activeTab === 'voice' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Mic className="w-4 h-4 text-[#FFD447]" /> Test Voice & Natural Language Queries
              </h3>
              <p className="text-slate-400">
                The user can speak in Hindi, Hinglish, or English. Gemini analyzes intent, extracts normalized categories, price caps, and keywords.
              </p>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Spoken Voice Transcript / Query</label>
                <textarea
                  rows={3}
                  value={voiceQuery}
                  onChange={(e) => setVoiceQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              {/* Sample phrases chips */}
              <div className="space-y-1.5">
                <span className="text-[10px] text-slate-400 block font-semibold">Try sample voice inputs:</span>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      const q = 'Mujhe wireless earbuds dikhao best quality under 3000';
                      setVoiceQuery(q);
                      runVoiceTest(q);
                    }}
                    className="text-[11px] bg-slate-950 border border-slate-800 hover:border-[#FFD447] text-slate-300 px-2.5 py-1 rounded-xl"
                  >
                    Hindi: "Mujhe wireless earbuds dikhao under 3000"
                  </button>
                  <button
                    onClick={() => {
                      const q = 'Waterproof smartwatch with AMOLED screen for swimming';
                      setVoiceQuery(q);
                      runVoiceTest(q);
                    }}
                    className="text-[11px] bg-slate-950 border border-slate-800 hover:border-[#FFD447] text-slate-300 px-2.5 py-1 rounded-xl"
                  >
                    English: "Waterproof smartwatch with AMOLED"
                  </button>
                  <button
                    onClick={() => {
                      const q = 'Pure cotton handcrafted kurta set for festival under 2000';
                      setVoiceQuery(q);
                      runVoiceTest(q);
                    }}
                    className="text-[11px] bg-slate-950 border border-slate-800 hover:border-[#FFD447] text-slate-300 px-2.5 py-1 rounded-xl"
                  >
                    Hinglish: "Pure cotton handcrafted kurta set under 2000"
                  </button>
                </div>
              </div>

              <button
                onClick={() => runVoiceTest()}
                disabled={isVoiceTesting}
                className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow disabled:opacity-50"
              >
                {isVoiceTesting ? 'Analyzing with Gemini 3.8 Flash...' : 'Extract Search Filters'}
              </button>
            </div>

            {/* Results viewer */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider mb-2">
                  Structured Intent Output
                </h4>
                {voiceResult ? (
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-emerald-400 overflow-x-auto">
                    <pre>{JSON.stringify(voiceResult, null, 2)}</pre>
                  </div>
                ) : (
                  <div className="py-16 text-center text-slate-500">
                    Click "Extract Search Filters" to test the server endpoint.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCT DRAFTER */}
        {activeTab === 'drafter' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#FFD447]" /> Product Listing Auto-Drafter
              </h3>
              <p className="text-slate-400">
                Helps merchants craft compelling, high-converting product pages with price intelligence and bullet points.
              </p>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Product Title / Concept</label>
                <input
                  type="text"
                  value={draftTitle}
                  onChange={(e) => setDraftTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Category</label>
                <input
                  type="text"
                  value={draftCategory}
                  onChange={(e) => setDraftCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Raw Features & Specifications</label>
                <textarea
                  rows={3}
                  value={draftFeatures}
                  onChange={(e) => setDraftFeatures(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                />
              </div>

              <button
                onClick={runDrafterTest}
                disabled={isDrafting}
                className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow disabled:opacity-50"
              >
                {isDrafting ? 'Drafting with Gemini...' : 'Generate Catalog Copy & Pricing'}
              </button>
            </div>

            {/* Results viewer */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs">
              <h4 className="text-xs font-black text-white uppercase tracking-wider mb-2">
                Generated Marketing Copy
              </h4>
              {draftResult ? (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold">SEO TITLE</span>
                    <span className="font-bold text-white text-sm">{draftResult.productTitle}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold">MARKETING HOOK</span>
                    <p className="text-slate-200">{draftResult.shortHook}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold">RECOMMENDED PRICING</span>
                    <div className="flex gap-4">
                      <span>MRP: ₹{draftResult.suggestedMmr}</span>
                      <span className="font-bold text-[#FFD447]">
                        Selling Price: ₹{draftResult.suggestedSellingPrice}
                      </span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold">BULLET POINTS</span>
                    <ul className="list-disc list-inside text-slate-300 space-y-1">
                      {draftResult.bulletPoints?.map((b: string, i: number) => (
                        <li key={i}>{b}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center text-slate-500">
                  Fill specs and click Generate to run the AI drafter.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: REVIEWS */}
        {activeTab === 'reviews' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Star className="w-4 h-4 text-[#FFD447]" /> Review Sentiment & Authenticity Auditor
              </h3>
              <p className="text-slate-400">
                Summarizes customer feedback into actionable pros, cons, and verified authenticity score.
              </p>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Customer Reviews Input</label>
                <textarea
                  rows={6}
                  value={reviewInput}
                  onChange={(e) => setReviewInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
                />
              </div>

              <button
                onClick={runReviewTest}
                disabled={isReviewTesting}
                className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow disabled:opacity-50"
              >
                {isReviewTesting ? 'Auditing Reviews...' : 'Analyze Customer Sentiment'}
              </button>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs">
              <h4 className="text-xs font-black text-white uppercase tracking-wider mb-2">
                Audited Review Summary
              </h4>
              {reviewResult ? (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-sm">Sentiment Verdict: {reviewResult.verdict}</span>
                    <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded font-bold">
                      {reviewResult.authenticityScore}% Authenticity
                    </span>
                  </div>
                  <p className="text-slate-200">{reviewResult.summary}</p>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div className="p-2 bg-emerald-950/30 rounded-lg border border-emerald-900/40">
                      <span className="font-bold text-emerald-400 block mb-1">Key Pros:</span>
                      <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                        {reviewResult.pros?.map((p: string, i: number) => (
                          <li key={i}>{p}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-2 bg-amber-950/30 rounded-lg border border-amber-900/40">
                      <span className="font-bold text-amber-400 block mb-1">Areas for Polish:</span>
                      <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                        {reviewResult.cons?.map((c: string, i: number) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center text-slate-500">
                  Click Analyze Customer Sentiment to test this endpoint.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: CONCIERGE ASSISTANT */}
        {activeTab === 'assistant' && (
          <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 text-xs">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#FFD447]" /> Catalogue-Grounded Shopping Assistant
            </h3>
            <p className="text-slate-400">
              Directly queries the server-side assistant endpoint with PCMART catalog grounding.
            </p>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Customer Query</label>
              <textarea
                rows={2}
                value={assistantInput}
                onChange={(e) => setAssistantInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white"
              />
            </div>

            <button
              onClick={runAssistantTest}
              disabled={isAssistantTesting}
              className="w-full py-3 bg-[#1746A2] hover:bg-blue-600 text-white font-bold rounded-xl shadow disabled:opacity-50"
            >
              {isAssistantTesting ? 'Consulting Catalogue...' : 'Ask PC Assistant'}
            </button>

            {assistantReply && (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 mt-4">
                <span className="font-bold text-[#FFD447] block text-xs">PC Assistant Response:</span>
                <p className="text-slate-200 leading-relaxed whitespace-pre-wrap">{assistantReply}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
