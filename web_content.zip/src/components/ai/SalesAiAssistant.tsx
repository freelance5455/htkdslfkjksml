import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, X, Loader2, Lightbulb, Copy, Check } from 'lucide-react';
import { Product, Invoice, Customer, StoreSettings } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  invoices: Invoice[];
  customers: Customer[];
  settings: StoreSettings;
}

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

export const SalesAiAssistant: React.FC<Props> = ({
  isOpen,
  onClose,
  products,
  invoices,
  customers,
  settings,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: `مرحباً بك! أنا مستشارك المالي والذكي المدمج في نظام **${settings.storeName}**.\n\nيمكنني مساعدتك في:\n- تحليل المبيعات وهوامش الربح اليومية والشهرية.\n- كشف الأصناف الراكدة ونواقص المخزون واقتراح كميات الشراء المثلى.\n- صياغة عروض ترويجية وتخفيضات ذكية.\n\nما الذي تود تحليله الآن؟`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    'حلل لي مبيعات اليوم واقترح طرق لزيادة الأرباح',
    'ما هي الأصناف المنخفضة التي تتطلب إعادة طلب عاجل؟',
    'اقترح فكرة عرض ترويجي لحزمة منتجات (Bundle)',
    'كيف أقلل الديون المعلقة لدى العملاء؟',
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || input.trim();
    if (!textToSend || isLoading) return;

    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: textToSend }]);
    setIsLoading(true);

    try {
      // Build snapshot context of store
      const lowStockProducts = products
        .filter((p) => p.stock <= p.minStock)
        .map((p) => ({ name: p.name, stock: p.stock, minStock: p.minStock, cost: p.costPrice, price: p.sellingPrice }));

      const totalSalesRevenue = invoices.reduce((s, i) => s + i.grandTotal, 0);
      const totalInvoicesCount = invoices.length;
      const totalDebts = customers.reduce((s, c) => s + c.balance, 0);

      const contextData = {
        storeName: settings.storeName,
        totalProductsCount: products.length,
        lowStockItems: lowStockProducts,
        totalSalesRevenue,
        totalInvoicesCount,
        totalDebts,
        recentInvoicesSample: invoices.slice(0, 5).map((inv) => ({
          number: inv.invoiceNumber,
          total: inv.grandTotal,
          payment: inv.paymentMethod,
          itemsCount: inv.items.length,
        })),
      };

      const res = await fetch('/api/gemini/sales-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          context: contextData,
        }),
      });

      const data = await res.json();
      if (data.error) {
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', text: `⚠️ تنبيه: ${data.error}` },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', text: data.text || 'لم يتم استلام نص.' },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'عذراً، تعذر الاتصال بخدمة المساعد الذكي حالياً. يرجى التحقق من اتصال الإنترنت أو إعدادات السيرفر.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-slate-850 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-1.5">
                <span>المساعد الذكي لإدارة المبيعات والمخزون</span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30 font-mono">
                  Gemini 3.8
                </span>
              </h3>
              <p className="text-xs text-slate-400">تحليل فوري لحركة المبيعات ومؤشرات الأداء والنواقص</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${
                msg.role === 'user' ? 'justify-start flex-row-reverse' : 'justify-start'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                }`}
              >
                {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`relative group max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white rounded-br-none'
                    : 'bg-slate-800/90 text-slate-200 border border-slate-700/80 rounded-bl-none shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {msg.role === 'assistant' && (
                  <button
                    onClick={() => handleCopy(msg.text, idx)}
                    className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition p-1 bg-slate-750 hover:bg-slate-700 rounded text-slate-400 hover:text-white"
                    title="نسخ النص"
                  >
                    {copiedIdx === idx ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 items-center text-xs text-slate-400 p-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
              <span>جاري تحليل البيانات وصياغة التوصيات...</span>
            </div>
          )}
        </div>

        {/* Quick prompt suggestions */}
        <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto flex gap-1.5 scrollbar-none">
          {quickPrompts.map((qp, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(qp)}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-750 rounded-xl text-[11px] whitespace-nowrap transition disabled:opacity-50"
            >
              <Lightbulb className="w-3 h-3 text-amber-400" />
              <span>{qp}</span>
            </button>
          ))}
        </div>

        {/* Input box */}
        <div className="p-3 bg-slate-850 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اكتب استفسارك هنا (مثال: ما هو الصنف الأعلى ربحاً؟)..."
              disabled={isLoading}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 transition shadow-inner"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl shadow-md transition"
            >
              <Send className="w-4 h-4 rtl:rotate-180" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
