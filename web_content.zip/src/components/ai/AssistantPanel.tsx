import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertCircle, Send, Sparkles, X } from 'lucide-react';
import type { Lesson, Subject, Unit } from '../../types';
import { askAssistant, isAssistantConfigured, type ChatMessage } from '../../services/ai';
import { MathText } from '../ui/MathText';
import { cn } from '../../utils/format';

const SUGGESTIONS = ['اشرح لي الفكرة الأساسية ببساطة', 'أعطني مثالاً محلولاً خطوة بخطوة', 'كيف أتذكّر هذا الدرس في الامتحان؟'];

export function AssistantPanel({
  open,
  onClose,
  lesson,
  subject,
  unit,
}: {
  open: boolean;
  onClose: () => void;
  lesson: Lesson;
  subject: Subject;
  unit: Unit;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) setError(null);
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, loading]);

  const send = async (question: string) => {
    const q = question.trim();
    if (!q || loading) return;
    setInput('');
    setError(null);
    const history = messages;
    setMessages((prev) => [...prev, { role: 'user', text: q }]);
    setLoading(true);
    try {
      const answer = await askAssistant({ lesson, subject, unit, history, question: q });
      setMessages((prev) => [...prev, { role: 'model', text: answer }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذّر الحصول على إجابة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="fixed inset-x-0 bottom-0 z-[75] mx-auto flex h-[72dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border border-[var(--line)] bg-[var(--surface)] shadow-2xl sm:bottom-4 sm:h-[64dvh] sm:rounded-3xl"
          role="dialog"
          aria-label="المساعد الدراسي"
        >
          <header className="flex items-center gap-2 border-b border-[var(--line)] px-4 py-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]">
              <Sparkles size={16} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-sm text-[var(--ink)]">مساعد منارة</p>
              <p className="truncate text-[0.66rem] text-[var(--ink-soft)]">{lesson.title}</p>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق المساعد"
              className="focus-ring flex h-9 w-9 items-center justify-center rounded-full text-[var(--ink-soft)] hover:bg-[var(--surface-2)]"
            >
              <X size={18} />
            </button>
          </header>

          {!isAssistantConfigured ? (
            <div className="flex items-start gap-2 bg-[var(--gold-soft)] px-4 py-2 text-[0.68rem] leading-relaxed text-[#7a5206] dark:text-[var(--gold)]">
              <AlertCircle size={14} className="mt-0.5 shrink-0" />
              المساعد يعمل حالياً في وضع محلي (بدون مفتاح Gemini). أضف مفتاحك في متغير البيئة لتفعيل الإجابات الكاملة.
            </div>
          ) : null}

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
            {messages.length === 0 && !loading ? (
              <div className="space-y-2">
                <p className="text-[0.78rem] leading-relaxed text-[var(--ink-soft)]">
                  اسألني عن أي فكرة في هذا الدرس. سأشرح بمنهج البكالوريا العلمية السورية، وأعرض المعادلات بشكل واضح.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => void send(s)}
                      className="focus-ring rounded-full border border-[var(--line)] px-2.5 py-1.5 text-[0.68rem] text-[var(--ink)] hover:bg-[var(--surface-2)]"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}

            {messages.map((message, i) => (
              <div
                key={i}
                className={cn(
                  'max-w-[92%] rounded-2xl px-3 py-2',
                  message.role === 'user'
                    ? 'ms-auto bg-[var(--brand)] text-[var(--brand-ink)]'
                    : 'bg-[var(--surface-2)] text-[var(--ink)]',
                )}
              >
                {message.role === 'user' ? (
                  <p className="text-[0.82rem] leading-relaxed">{message.text}</p>
                ) : (
                  <MathText text={message.text} className="text-[0.84rem]" />
                )}
              </div>
            ))}

            {loading ? (
              <div className="flex items-center gap-1.5 rounded-2xl bg-[var(--surface-2)] px-3 py-2.5">
                {[0, 1, 2].map((i) => (
                  <motion.span
                    key={i}
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.15 }}
                    className="h-1.5 w-1.5 rounded-full bg-[var(--ink-soft)]"
                  />
                ))}
                <span className="ms-1 text-[0.68rem] text-[var(--ink-soft)]">يفكّر…</span>
              </div>
            ) : null}

            {error ? (
              <p className="rounded-2xl bg-[#fdece2] px-3 py-2 text-[0.72rem] leading-relaxed text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f]">
                {error}
              </p>
            ) : null}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
            className="flex items-end gap-2 border-t border-[var(--line)] p-3"
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  void send(input);
                }
              }}
              rows={1}
              placeholder="اكتب سؤالك عن الدرس…"
              aria-label="سؤالك للمساعد"
              className="focus-ring max-h-24 min-h-11 flex-1 resize-none rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 py-2.5 text-[0.82rem] text-[var(--ink)] placeholder:text-[var(--ink-soft)]/70"
            />
            <button
              type="submit"
              disabled={loading || input.trim().length === 0}
              aria-label="إرسال"
              className="focus-ring flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--brand)] text-[var(--brand-ink)] disabled:opacity-40"
            >
              <Send size={17} className="-scale-x-100" />
            </button>
          </form>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
