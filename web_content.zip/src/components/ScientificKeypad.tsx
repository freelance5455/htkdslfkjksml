import type { AngleMode } from '../types/calculator';
import { RegularKeypad, type RegularKeypadProps } from './RegularKeypad';

interface ScientificKeypadProps extends Omit<RegularKeypadProps, 'compact'> {
  angleMode: AngleMode;
  forceScientific: boolean;
  hasMemory: boolean;
  onToggleAngleMode: () => void;
  onToggleScientificNotation: () => void;
  onMemoryClear: () => void;
  onMemoryRecall: () => void;
  onMemoryAdd: () => void;
  onMemorySubtract: () => void;
  onInsertFunc: (fnToken: string) => void;
  onInsertConst: (constSymbol: 'π' | 'e') => void;
  onInsertPostfix: (postfix: '²' | '³' | '!') => void;
  onInsertBinary: (op: '^' | 'mod' | '/') => void;
  onInsertParen: (paren: '(' | ')') => void;
  onReciprocal: () => void;
  onInsertExpNotation: () => void;
  onPowerOfTen: () => void;
  onExpOfE: () => void;
}

export function ScientificKeypad({
  angleMode,
  forceScientific,
  hasMemory,
  onToggleAngleMode,
  onToggleScientificNotation,
  onMemoryClear,
  onMemoryRecall,
  onMemoryAdd,
  onMemorySubtract,
  onInsertFunc,
  onInsertConst,
  onInsertPostfix,
  onInsertBinary,
  onInsertParen,
  onReciprocal,
  onInsertExpNotation,
  onPowerOfTen,
  onExpOfE,
  ...regularProps
}: ScientificKeypadProps) {
  const memBtn =
    'calc-key h-9 sm:h-10 rounded-xl text-xs font-mono font-semibold flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';
  const memNeutral = `${memBtn} bg-zinc-100/90 hover:bg-zinc-200 dark:bg-zinc-800/60 dark:hover:bg-zinc-700/70 text-zinc-700 dark:text-zinc-200`;
  const memActive = `${memBtn} bg-blue-600 text-white shadow-sm`;

  const sciBtn =
    'calc-key h-10 sm:h-11 rounded-xl text-xs sm:text-sm font-medium flex items-center justify-center bg-zinc-100/85 hover:bg-zinc-200/85 dark:bg-zinc-800/50 dark:hover:bg-zinc-700/70 text-zinc-800 dark:text-zinc-200 border border-zinc-200/60 dark:border-zinc-700/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 whitespace-nowrap';

  return (
    <div className="space-y-2 sm:space-y-2.5">
      {/* Angle Mode, Scientific Notation, and Memory Functions Strip */}
      <div className="grid grid-cols-6 gap-1.5 sm:gap-2">
        <button
          type="button"
          onClick={onToggleAngleMode}
          className={memActive}
          title="Switch between Degrees and Radians"
        >
          {angleMode}
        </button>
        <button
          type="button"
          onClick={onToggleScientificNotation}
          className={forceScientific ? memActive : memNeutral}
          title="Toggle Scientific Notation Display (F-E)"
        >
          F-E
        </button>
        <button
          type="button"
          onClick={onMemoryClear}
          className={`${memNeutral} ${!hasMemory ? 'opacity-60' : ''}`}
          title="Memory Clear"
        >
          MC
        </button>
        <button
          type="button"
          onClick={onMemoryRecall}
          className={`${memNeutral} ${!hasMemory ? 'opacity-60' : ''}`}
          title="Memory Recall"
        >
          MR
        </button>
        <button
          type="button"
          onClick={onMemoryAdd}
          className={memNeutral}
          title="Memory Add"
        >
          M+
        </button>
        <button
          type="button"
          onClick={onMemorySubtract}
          className={memNeutral}
          title="Memory Subtract"
        >
          M−
        </button>
      </div>

      {/* 5x5 Scientific Function Grid */}
      <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
        {/* Row 1: Trigonometry & Logarithms */}
        <button type="button" onClick={() => onInsertFunc('sin(')} className={sciBtn}>
          sin
        </button>
        <button type="button" onClick={() => onInsertFunc('cos(')} className={sciBtn}>
          cos
        </button>
        <button type="button" onClick={() => onInsertFunc('tan(')} className={sciBtn}>
          tan
        </button>
        <button type="button" onClick={() => onInsertFunc('log(')} className={sciBtn}>
          log
        </button>
        <button type="button" onClick={() => onInsertFunc('ln(')} className={sciBtn}>
          ln
        </button>

        {/* Row 2: Inverse Trigonometry & Base Powers */}
        <button type="button" onClick={() => onInsertFunc('sin⁻¹(')} className={sciBtn}>
          sin⁻¹
        </button>
        <button type="button" onClick={() => onInsertFunc('cos⁻¹(')} className={sciBtn}>
          cos⁻¹
        </button>
        <button type="button" onClick={() => onInsertFunc('tan⁻¹(')} className={sciBtn}>
          tan⁻¹
        </button>
        <button type="button" onClick={onPowerOfTen} className={sciBtn}>
          10ˣ
        </button>
        <button type="button" onClick={onExpOfE} className={sciBtn}>
          eˣ
        </button>

        {/* Row 3: Powers & Roots */}
        <button type="button" onClick={() => onInsertPostfix('²')} className={sciBtn} aria-label="Square">
          x²
        </button>
        <button type="button" onClick={() => onInsertFunc('√(')} className={sciBtn} aria-label="Square Root">
          √x
        </button>
        <button type="button" onClick={() => onInsertPostfix('³')} className={sciBtn} aria-label="Cube">
          x³
        </button>
        <button type="button" onClick={() => onInsertFunc('∛(')} className={sciBtn} aria-label="Cube Root">
          ∛x
        </button>
        <button type="button" onClick={() => onInsertBinary('^')} className={sciBtn} aria-label="Power">
          xʸ
        </button>

        {/* Row 4: Reciprocal, Factorial, Absolute, Modulo, Scientific EXP */}
        <button type="button" onClick={onReciprocal} className={sciBtn} aria-label="Reciprocal">
          1/x
        </button>
        <button type="button" onClick={() => onInsertPostfix('!')} className={sciBtn} aria-label="Factorial">
          n!
        </button>
        <button type="button" onClick={() => onInsertFunc('abs(')} className={sciBtn} aria-label="Absolute Value">
          |x|
        </button>
        <button type="button" onClick={() => onInsertBinary('mod')} className={sciBtn} aria-label="Modulus">
          mod
        </button>
        <button type="button" onClick={onInsertExpNotation} className={sciBtn} aria-label="Scientific Notation Exponent">
          EXP
        </button>

        {/* Row 5: Parentheses, Constants, Fraction Slash */}
        <button type="button" onClick={() => onInsertParen('(')} className={sciBtn} aria-label="Open Parenthesis">
          (
        </button>
        <button type="button" onClick={() => onInsertParen(')')} className={sciBtn} aria-label="Close Parenthesis">
          )
        </button>
        <button type="button" onClick={() => onInsertConst('π')} className={sciBtn} aria-label="Pi">
          π
        </button>
        <button type="button" onClick={() => onInsertConst('e')} className={sciBtn} aria-label="Euler's Number">
          e
        </button>
        <button type="button" onClick={() => onInsertBinary('/')} className={sciBtn} aria-label="Fraction Slash">
          a/b
        </button>
      </div>

      {/* Main Numeric & Arithmetic Pad */}
      <RegularKeypad {...regularProps} compact />
    </div>
  );
}
