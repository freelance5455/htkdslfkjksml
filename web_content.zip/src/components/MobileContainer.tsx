import React, { useState } from 'react';
import {
  Home,
  PieChart,
  Target,
  ShoppingBag,
  Settings,
  Plus,
  Lock,
  WifiOff,
  Smartphone,
  Maximize2,
  Minimize2,
  Database,
  ShieldCheck,
  X,
} from 'lucide-react';
import { AppSettings, ThemeMode, NavigationTab } from '../types';
import { getDualAccentInfo, getThemeToneStyles } from '../utils/theme';
import { AppLogo } from './AppLogo';

interface MobileContainerProps {
  children: React.ReactNode;
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenAddModal: () => void;
  onOpenManageCategories?: () => void;
  onLockApp: () => void;
  isPinEnabled: boolean;
  appSettings: AppSettings;
  hideBottomNav?: boolean;
}

export const MobileContainer: React.FC<MobileContainerProps> = ({
  children,
  activeTab,
  onTabChange,
  onOpenAddModal,
  onOpenManageCategories,
  onLockApp,
  isPinEnabled,
  appSettings,
  hideBottomNav = false,
}) => {
  const [isMobileFrameView, setIsMobileFrameView] = useState(true);
  const [showOfflineModal, setShowOfflineModal] = useState(false);

  const isEn = appSettings.language === 'en';

  // Compute theme background class based on themeMode
  const isLight = appSettings.themeMode === 'light';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );
  const toneConfig = getThemeToneStyles(
    appSettings.themeMode,
    appSettings.themeShade,
    isEn
  );

  const getThemeBgClass = () => {
    if (appSettings.themeMode === 'oled') return 'text-white';
    if (isLight) return 'text-slate-900';
    return 'text-slate-100'; // Sleek deep gray dark mode
  };

  return (
    <div
      className={`min-h-screen ${
        isLight ? 'text-slate-900' : 'text-slate-100'
      } flex flex-col items-center justify-start sm:py-6 sm:px-4 font-sans antialiased selection:bg-[var(--color-primary)] selection:text-white transition-colors duration-200`}
      style={{ backgroundColor: toneConfig.outerBg }}
    >
      {/* Top Frame Control Switcher (For testing Mobile Frame vs Fluid) */}
      <div
        className={`w-full max-w-md hidden sm:flex items-center justify-between mb-3 px-2 text-xs ${
          isLight ? 'text-sky-800' : 'text-gray-400'
        }`}
      >
        <div
          className="flex items-center gap-1.5 font-bold"
          style={{ color: dualAccent.primary.hex }}
        >
          <Smartphone className="w-4 h-4" />
          <span>{isEn ? 'Mobile App View (Android / iOS Layout)' : 'মোবাইল অ্যাপস ভিউ (Android / iOS Layout)'}</span>
        </div>

        <button
          onClick={() => setIsMobileFrameView(!isMobileFrameView)}
          className={`flex items-center gap-1 px-2.5 py-1 ${
            isLight
              ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
              : 'bg-gray-900 hover:bg-gray-800 border-gray-800 text-gray-300'
          } border rounded-lg transition`}
        >
          {isMobileFrameView ? (
            <>
              <Maximize2 className="w-3 h-3" /> {isEn ? 'Full Screen' : 'ফুল স্ক্রিন'}
            </>
          ) : (
            <>
              <Minimize2 className="w-3 h-3" /> {isEn ? 'Mobile Frame' : 'মোবাইল ফ্রেম'}
            </>
          )}
        </button>
      </div>

      {/* Main Container Phone Chassis */}
      <div
        className={`w-full ${
          isMobileFrameView
            ? 'max-w-md sm:rounded-[40px] sm:border-[8px]'
            : 'max-w-3xl rounded-none'
        } flex flex-col h-screen sm:h-[860px] overflow-hidden relative border-x-0 border-y-0 sm:border transition-colors duration-200`}
        style={{
          backgroundColor: toneConfig.chassisBg,
          borderColor: isLight ? `rgba(var(--color-primary-rgb), 0.25)` : '#1e293b',
          boxShadow: isLight
            ? `0 20px 50px rgba(var(--color-primary-rgb), 0.15)`
            : '0 25px 60px -15px rgba(0,0,0,0.8)',
        }}
      >
        {/* App Bar Header */}
        <header
          className={`px-5 py-3 border-b ${
            isLight ? 'border-slate-200/80 text-slate-900 shadow-xs' : 'border-slate-850 text-white'
          } flex items-center justify-between shrink-0 backdrop-blur-md sticky top-0 z-30 transition-colors duration-200`}
          style={{
            backgroundColor: toneConfig.headerBg,
            borderColor: toneConfig.cardBorder,
          }}
        >
          <div
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => onTabChange('dashboard')}
          >
            <AppLogo
              size="md"
              gradient={dualAccent.gradient}
              glowColor={dualAccent.primary.hex}
              className="transition-transform hover:scale-105 active:scale-95"
            />
            <div>
              <h1
                className={`text-sm font-black tracking-tight flex items-center gap-1.5 ${
                  isLight ? 'text-slate-900' : 'text-white'
                }`}
              >
                Onu Finance
              </h1>
              <p
                className="text-[10px] font-semibold"
                style={{ color: dualAccent.primary.hex }}
              >
                {appSettings.language === 'en' ? 'Personal Finance & Budget' : 'হিসাব কিতাব ও বাজেট'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Offline Button */}
            <button
              onClick={() => setShowOfflineModal(true)}
              className="px-2.5 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 shadow-2xs"
              style={{
                backgroundColor: `${dualAccent.secondary.hex}18`,
                borderColor: `${dualAccent.secondary.hex}45`,
                color: dualAccent.secondary.hex,
              }}
              title={appSettings.language === 'en' ? 'Offline - Tap for details' : 'অফলাইন - বিস্তারিত দেখতে ট্যাপ করুন'}
              id="header-offline-mode-btn"
            >
              <span className="relative flex h-2 w-2">
                <span
                  className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
                  style={{ backgroundColor: dualAccent.secondary.hex }}
                ></span>
                <span
                  className="relative inline-flex rounded-full h-2 w-2"
                  style={{ backgroundColor: dualAccent.secondary.hex }}
                ></span>
              </span>
              <WifiOff className="w-3.5 h-3.5" style={{ color: dualAccent.secondary.hex }} />
              <span className="text-[11px] font-bold tracking-tight">
                {appSettings.language === 'en' ? 'Offline' : 'অফলাইন'}
              </span>
            </button>

            {isPinEnabled && (
              <button
                onClick={onLockApp}
                className={`p-2 rounded-xl border transition ${
                  isLight
                    ? 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-600'
                    : 'bg-rose-950/60 hover:bg-rose-900 border-rose-800 text-rose-300'
                }`}
                title={appSettings.language === 'en' ? 'Lock App' : 'অ্যাপ এখনই লক করুন'}
              >
                <Lock className="w-4 h-4" />
              </button>
            )}
          </div>
        </header>

        {/* Scrollable Viewport Content */}
        <main className="flex-1 overflow-y-auto px-4 pt-4 pb-6">
          {children}
        </main>

        {/* Bottom Mobile Navigation Bar (Locked at Bottom, 5 Equal Grid Columns) */}
        <nav
          className={`shrink-0 ${
            hideBottomNav ? 'hidden pointer-events-none' : 'grid grid-cols-5'
          } ${
            isLight
              ? 'border-slate-200/80 text-slate-900 shadow-lg'
              : 'border-slate-800 shadow-2xl'
          } border-t py-2.5 px-1 items-center justify-items-center z-40 transition-colors duration-200`}
          style={{
            backgroundColor: toneConfig.headerBg,
            borderColor: toneConfig.cardBorder,
          }}
          id="always-visible-bottom-nav"
          aria-hidden={hideBottomNav ? 'true' : undefined}
        >
          {/* Col 1: Home */}
          <button
            onClick={() => onTabChange('dashboard')}
            className={`w-full flex flex-col items-center justify-center gap-1 py-1 rounded-2xl transition ${
              activeTab === 'dashboard'
                ? 'font-bold'
                : isLight
                ? 'text-slate-500 hover:text-slate-900'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            style={activeTab === 'dashboard' ? dualAccent.activeTabSecondaryStyle : undefined}
            id="bottom-nav-dashboard-btn"
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px]">
              {appSettings.language === 'en' ? 'Home' : 'হোম'}
            </span>
          </button>

          {/* Col 2: Budget */}
          <button
            onClick={() => onTabChange('budget')}
            className={`w-full flex flex-col items-center justify-center gap-1 py-1 rounded-2xl transition ${
              activeTab === 'budget'
                ? 'font-bold'
                : isLight
                ? 'text-slate-500 hover:text-slate-900'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            style={activeTab === 'budget' ? dualAccent.activeTabPrimaryStyle : undefined}
            id="bottom-nav-budget-btn"
          >
            <Target className="w-5 h-5" />
            <span className="text-[10px]">
              {appSettings.language === 'en' ? 'Budget' : 'বাজেট'}
            </span>
          </button>

          {/* Col 3: Quick Floating Add Button (+) */}
          <button
            onClick={onOpenAddModal}
            className={`w-12 h-12 rounded-full text-white flex items-center justify-center transform active:scale-95 hover:scale-105 transition border-2 ${
              isLight ? 'border-white' : 'border-slate-800'
            } -mt-5`}
            style={{
              background: dualAccent.gradient,
              boxShadow: dualAccent.dualGlow,
            }}
            title={appSettings.language === 'en' ? 'Add Transaction' : 'নতুন হিসাব যোগ করুন'}
            id="bottom-nav-add-btn"
          >
            <Plus className="w-6 h-6 stroke-[3]" />
          </button>

          {/* Col 4: Shopping */}
          <button
            onClick={() => onTabChange('shopping')}
            className={`w-full flex flex-col items-center justify-center gap-1 py-1 rounded-2xl transition ${
              activeTab === 'shopping'
                ? 'font-bold'
                : isLight
                ? 'text-slate-500 hover:text-slate-900'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            style={activeTab === 'shopping' ? dualAccent.activeTabPrimaryStyle : undefined}
            id="bottom-nav-shopping-btn"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="text-[10px]">
              {appSettings.language === 'en' ? 'Shopping' : 'বাজার'}
            </span>
          </button>

          {/* Col 5: Settings */}
          <button
            onClick={() => onTabChange('settings')}
            className={`w-full flex flex-col items-center justify-center gap-1 py-1 rounded-2xl transition ${
              activeTab === 'settings' || activeTab === 'security' || activeTab === 'theme' || activeTab === 'language'
                ? 'font-bold'
                : isLight
                ? 'text-slate-500 hover:text-slate-900'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            style={
              activeTab === 'settings' || activeTab === 'security' || activeTab === 'theme' || activeTab === 'language'
                ? dualAccent.activeTabSecondaryStyle
                : undefined
            }
            id="bottom-nav-settings-btn"
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px]">
              {appSettings.language === 'en' ? 'Settings' : 'সেটিংস'}
            </span>
          </button>
        </nav>

        {/* Offline Mode Info Modal */}
        {showOfflineModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
            <div
              className={`w-full max-w-sm rounded-3xl p-5 border shadow-2xl space-y-4 ${
                isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-700 text-white'
              }`}
              style={{ borderColor: toneConfig.cardBorder }}
            >
              <div className="flex items-center justify-between pb-2 border-b border-black/5 dark:border-white/10">
                <div className="flex items-center gap-2.5">
                  <div
                    className="p-2 rounded-xl border"
                    style={{
                      backgroundColor: `${dualAccent.secondary.hex}20`,
                      borderColor: `${dualAccent.secondary.hex}40`,
                      color: dualAccent.secondary.hex,
                    }}
                  >
                    <WifiOff className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-black">
                      {isEn ? 'Offline Active' : 'অফলাইন সক্রিয়'}
                    </h2>
                    <span
                      className="text-[10px] font-bold flex items-center gap-1"
                      style={{ color: dualAccent.secondary.hex }}
                    >
                      <span
                        className="w-1.5 h-1.5 rounded-full inline-block"
                        style={{ backgroundColor: dualAccent.secondary.hex }}
                      ></span>
                      {isEn ? '100% Offline Capable' : '১০০% অফলাইনে ব্যবহারযোগ্য'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setShowOfflineModal(false)}
                  className={`p-1.5 rounded-xl border transition ${
                    isLight
                      ? 'border-slate-200 hover:bg-slate-100 text-slate-500'
                      : 'border-slate-700 hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                {isEn
                  ? 'Onu Finance operates completely offline! All your transactions, budgets, and shopping lists are safely stored inside your browser/device local storage. No internet connection is required to track your finances.'
                  : 'Onu Finance সম্পূর্ণ অফলাইনে কাজ করে! আপনার সমস্ত লেনদেন, বাজেট এবং শপিং তালিকা নিরাপদে আপনার ডিভাইসের লোকাল মেমোরিতে (Local Storage) সংরক্ষিত থাকে। ইন্টারনেট সংযোগ ছাড়াই সব ফিচার কাজ করে।'}
              </p>

              {/* Feature Points */}
              <div className="space-y-2 text-xs">
                <div
                  className={`p-2.5 rounded-2xl border flex items-center gap-2.5 ${
                    isLight ? 'bg-slate-50 border-slate-200/80' : 'bg-slate-800/80 border-slate-700/60'
                  }`}
                  style={{ borderColor: toneConfig.cardBorder }}
                >
                  <Database
                    className="w-4 h-4 shrink-0"
                    style={{ color: dualAccent.primary.hex }}
                  />
                  <div>
                    <p className="font-bold text-[11px]">{isEn ? 'Local Device Storage' : 'ডিভাইসের নিজস্ব স্টোরেজ'}</p>
                    <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {isEn ? 'Data never leaves your phone or browser' : 'আপনার ডেটা বাইরের কোনো সার্ভারে যায় না'}
                    </p>
                  </div>
                </div>

                <div
                  className={`p-2.5 rounded-2xl border flex items-center gap-2.5 ${
                    isLight ? 'bg-slate-50 border-slate-200/80' : 'bg-slate-800/80 border-slate-700/60'
                  }`}
                  style={{ borderColor: toneConfig.cardBorder }}
                >
                  <ShieldCheck
                    className="w-4 h-4 shrink-0"
                    style={{ color: dualAccent.secondary.hex }}
                  />
                  <div>
                    <p className="font-bold text-[11px]">{isEn ? 'Encrypted Security & Backup' : 'নিরাপদ পিন ও ব্যাকআপ'}</p>
                    <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {isEn ? 'Export JSON backup anytime in Settings' : 'সেটিংস থেকে যেকোনো সময় JSON ব্যাকআপ নিতে পারেন'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowOfflineModal(false);
                    onTabChange('security');
                  }}
                  className="flex-1 py-2 px-3 border rounded-xl text-xs font-bold transition text-center"
                  style={{
                    borderColor: `${dualAccent.secondary.hex}60`,
                    color: dualAccent.secondary.hex,
                  }}
                >
                  {isEn ? 'Backup Settings' : 'ব্যাকআপ সেটিংস'}
                </button>
                <button
                  onClick={() => setShowOfflineModal(false)}
                  className="flex-1 py-2 px-3 text-white rounded-xl text-xs font-bold transition"
                  style={dualAccent.primaryButtonStyle}
                >
                  {isEn ? 'Got It' : 'ঠিক আছে'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};


