import React, { useState } from 'react';
import { SubjectCategory, Topic } from '../types';
import { X, Plus, Trash2, Tag, Check, Edit2, AlertTriangle, BookOpen } from 'lucide-react';

interface CategoryManagerModalProps {
  isOpen: boolean;
  categories: SubjectCategory[];
  topics?: Topic[];
  onClose: () => void;
  onAddCategory: (category: SubjectCategory) => void;
  onUpdateCategory?: (category: SubjectCategory) => void;
  onDeleteCategory: (categoryId: string, reassignmentCategoryId?: string) => void;
}

const PRESET_COLORS = [
  '#0284c7', // sky
  '#f43f5e', // rose
  '#10b981', // emerald
  '#6366f1', // indigo
  '#f59e0b', // amber
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#14b8a6', // teal
  '#06b6d4', // cyan
  '#64748b', // slate
];

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  categories,
  topics = [],
  onClose,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
}) => {
  // Form state for creating or editing
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Deletion confirmation state
  const [pendingDeleteCat, setPendingDeleteCat] = useState<SubjectCategory | null>(null);
  const [reassignTargetId, setReassignTargetId] = useState<string>('');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingId && onUpdateCategory) {
      const existing = categories.find((c) => c.id === editingId);
      if (existing) {
        onUpdateCategory({
          ...existing,
          name: name.trim(),
          description: description.trim(),
          color: selectedColor,
        });
      }
    } else {
      const newCategory: SubjectCategory = {
        id: `cat-${Date.now()}`,
        name: name.trim(),
        description: description.trim() || 'Custom subject discipline',
        color: selectedColor,
        iconName: 'Folder',
      };
      onAddCategory(newCategory);
    }

    resetForm();
  };

  const handleStartEdit = (cat: SubjectCategory) => {
    setEditingId(cat.id);
    setName(cat.name);
    setDescription(cat.description || '');
    setSelectedColor(cat.color);
    setPendingDeleteCat(null);
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setSelectedColor(PRESET_COLORS[0]);
    setEditingId(null);
  };

  const promptDelete = (cat: SubjectCategory) => {
    // Check if topics exist for this category
    const count = topics.filter((t) => t.categoryId === cat.id).length;
    const remaining = categories.filter((c) => c.id !== cat.id);
    setReassignTargetId(remaining[0]?.id || '');

    if (count > 0 && remaining.length > 0) {
      setPendingDeleteCat(cat);
    } else {
      // Direct delete if 0 topics
      onDeleteCategory(cat.id);
    }
  };

  const confirmDelete = () => {
    if (!pendingDeleteCat) return;
    onDeleteCategory(pendingDeleteCat.id, reassignTargetId);
    setPendingDeleteCat(null);
  };

  const getTopicCount = (catId: string) => {
    return topics.filter((t) => t.categoryId === catId).length;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="category-modal-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h2 id="category-modal-title" className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Manage Study Subjects
              </h2>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Add, customize, edit, or delete subject disciplines as you wish
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Deletion Warning Overlay */}
          {pendingDeleteCat && (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl space-y-3 animate-in fade-in">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-xs font-semibold text-rose-900 dark:text-rose-200">
                    Delete Subject: "{pendingDeleteCat.name}"?
                  </div>
                  <p className="text-xs text-rose-700 dark:text-rose-300">
                    You have{' '}
                    <strong>{getTopicCount(pendingDeleteCat.id)} topics</strong> currently
                    assigned to this subject. Please choose where to reassign them:
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-rose-900 dark:text-rose-200 mb-1">
                  Reassign topics to:
                </label>
                <select
                  value={reassignTargetId}
                  onChange={(e) => setReassignTargetId(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                >
                  {categories
                    .filter((c) => c.id !== pendingDeleteCat.id)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setPendingDeleteCat(null)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-rose-100/60 dark:hover:bg-rose-900/40 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={confirmDelete}
                  className="px-3.5 py-1.5 text-xs font-medium text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs transition-colors"
                >
                  Confirm Delete & Reassign
                </button>
              </div>
            </div>
          )}

          {/* Add / Edit Subject Form */}
          <form
            onSubmit={handleSave}
            className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3.5"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
              <span>{editingId ? `Edit Subject: ${name}` : 'Add New Subject'}</span>
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-normal"
                >
                  Cancel Edit
                </button>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Subject Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Cognitive Psychology, Pharmacology, Discrete Math"
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Optional Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Memory mechanisms, neural circuits, and cognition"
                className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Subject Accent Color
              </label>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {PRESET_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className="w-7 h-7 rounded-full flex items-center justify-center transition-transform hover:scale-110 shadow-xs"
                    style={{ backgroundColor: color }}
                    aria-label={`Select color ${color}`}
                  >
                    {selectedColor === color && <Check className="w-4 h-4 text-white stroke-[2.5]" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-3.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
              >
                {editingId ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                <span>{editingId ? 'Save Subject Changes' : 'Add Subject'}</span>
              </button>
            </div>
          </form>

          {/* Existing Subjects List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 pb-1">
              <span>Your Subjects ({categories.length})</span>
              <span className="text-[11px] text-slate-500 font-normal">
                Click trash to delete any subject
              </span>
            </div>

            {categories.map((cat) => {
              const topicCount = getTopicCount(cat.id);
              const isOnlyOne = categories.length <= 1;

              return (
                <div
                  key={cat.id}
                  className="p-3 bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs group hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className="w-3 h-3 rounded-full shrink-0 shadow-xs"
                      style={{ backgroundColor: cat.color }}
                    />
                    <div className="truncate">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {cat.name}
                        </span>
                        <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800 px-1.5 py-0.2 rounded-md shrink-0">
                          {topicCount} {topicCount === 1 ? 'topic' : 'topics'}
                        </span>
                      </div>
                      {cat.description && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {cat.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {/* Edit button */}
                    <button
                      type="button"
                      onClick={() => handleStartEdit(cat)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-md transition-colors"
                      title={`Edit ${cat.name}`}
                      aria-label={`Edit ${cat.name}`}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete button (available on all subjects, disabled if only 1 remaining) */}
                    <button
                      type="button"
                      onClick={() => promptDelete(cat)}
                      disabled={isOnlyOne}
                      className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 disabled:opacity-30 disabled:cursor-not-allowed rounded-md transition-colors"
                      title={
                        isOnlyOne
                          ? 'At least one subject must remain'
                          : `Delete ${cat.name}`
                      }
                      aria-label={`Delete ${cat.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Deleted subjects automatically reassign their topics safely.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 transition-colors shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
