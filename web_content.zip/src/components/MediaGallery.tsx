import React, { useState } from 'react';
import { Image as ImageIcon, Video, Download, Trash2, Play, Sparkles, ExternalLink } from 'lucide-react';
import { LogoItem, VideoItem } from '../types';

interface MediaGalleryProps {
  logos: LogoItem[];
  videos: VideoItem[];
  onSelectLogo: (logo: LogoItem) => void;
  onSelectVideo: (video: VideoItem) => void;
  onAnimateLogo: (logo: LogoItem) => void;
}

export const MediaGallery: React.FC<MediaGalleryProps> = ({
  logos,
  videos,
  onSelectLogo,
  onSelectVideo,
  onAnimateLogo,
}) => {
  const [filter, setFilter] = useState<'all' | 'logos' | 'videos'>('all');

  return (
    <div className="p-4 lg:p-6 w-full max-w-7xl mx-auto space-y-6">
      {/* Header & Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-indigo-400" />
            Media & Brand Asset Showcase
          </h2>
          <p className="text-xs text-slate-400">All generated logos ({logos.length}) and animated video clips ({videos.length})</p>
        </div>

        <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              filter === 'all' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Assets ({logos.length + videos.length})
          </button>
          <button
            onClick={() => setFilter('logos')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              filter === 'logos' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Logos ({logos.length})
          </button>
          <button
            onClick={() => setFilter('videos')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              filter === 'videos' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Videos ({videos.length})
          </button>
        </div>
      </div>

      {/* Grid of Items */}
      {logos.length === 0 && videos.length === 0 ? (
        <div className="p-12 text-center border-2 border-dashed border-slate-800 rounded-3xl text-slate-500">
          <Sparkles className="w-10 h-10 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No logos or videos created yet. Start designing in the Logo Designer!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {/* Logos */}
          {(filter === 'all' || filter === 'logos') &&
            logos.map((logo) => (
              <div
                key={logo.id}
                className="group glass-card rounded-2xl overflow-hidden border border-slate-800 hover:border-indigo-500/50 transition-all shadow-md flex flex-col"
              >
                <div className="relative aspect-square bg-slate-950 flex items-center justify-center p-3">
                  <img src={logo.imageUrl} alt={logo.brandName} className="max-h-full max-w-full object-contain" />
                  <span className="absolute top-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-900/90 text-indigo-300 border border-slate-700">
                    {logo.imageSize} • {logo.aspectRatio}
                  </span>
                </div>

                <div className="p-3.5 flex flex-col gap-2 flex-1 justify-between bg-slate-900/40">
                  <div>
                    <h4 className="font-bold text-white text-sm truncate">{logo.brandName}</h4>
                    <p className="text-[11px] text-slate-400 truncate">{logo.industry} • {logo.style}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                    <button
                      onClick={() => onAnimateLogo(logo)}
                      className="flex-1 py-1.5 px-2 bg-gradient-to-r from-pink-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1 shadow-sm"
                    >
                      <Video className="w-3.5 h-3.5" /> Animate
                    </button>
                    <a
                      href={logo.imageUrl}
                      download={`${logo.brandName}_logo.png`}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                      title="Download"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            ))}

          {/* Videos */}
          {(filter === 'all' || filter === 'videos') &&
            videos.map((vid) => (
              <div
                key={vid.id}
                className="group glass-card rounded-2xl overflow-hidden border border-slate-800 hover:border-pink-500/50 transition-all shadow-md flex flex-col"
              >
                <div className="relative aspect-video bg-black flex items-center justify-center">
                  <video src={vid.videoUrl} className="w-full h-full object-contain" controls />
                  <span className="absolute top-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-950/90 text-pink-300 border border-pink-500/40">
                    {vid.aspectRatio} • {vid.duration}
                  </span>
                </div>

                <div className="p-3.5 flex flex-col gap-2 flex-1 justify-between bg-slate-900/40">
                  <div>
                    <h4 className="font-bold text-white text-sm truncate">{vid.brandName} Animation</h4>
                    <p className="text-[11px] text-slate-400 truncate">{vid.motionPreset}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <span className="text-[10px] text-purple-400 font-mono">gemini-omni-1.1-flash</span>
                    <a
                      href={vid.videoUrl}
                      download={`${vid.brandName}_video.mp4`}
                      className="p-1.5 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-xs flex items-center gap-1 font-semibold"
                    >
                      <Download className="w-3.5 h-3.5" /> MP4
                    </a>
                  </div>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
};
