import React, { useState } from 'react';
import {
  Team,
  Manhwa,
  Chapter,
  TeamMember,
  TeamMemberRole,
  WorkType,
  PublicationStatus,
  WORK_TYPE_LABELS,
  TEAM_ROLE_LABELS,
  PUBLICATION_STATUS_LABELS,
  MANHWA_GENRES,
  AssignedMember
} from '../types';
import { useAuth } from '../context/AuthContext';
import { hartHost } from '../services/hartHostService';
import { hartPublishingService } from '../services/hartPublishingService';
import { hartTeamService } from '../services/hartTeamService';
import { SmartImage } from './SmartImage';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc
} from 'firebase/firestore';
import {
  BookOpen,
  Plus,
  Trash2,
  Edit,
  Layers,
  Upload,
  CheckCircle,
  AlertCircle,
  Users,
  Shield,
  Eye,
  Settings,
  X,
  ExternalLink,
  Crown,
  Search,
  Send,
  UserPlus,
  ArrowRight,
  Globe,
  MessageCircle,
  FileText,
  Clock,
  Sparkles,
  Archive,
  RefreshCw
} from 'lucide-react';

interface TeamStudioProps {
  team: Team;
  allManhwas: Manhwa[];
  allChapters: Chapter[];
  onBackToTeams: () => void;
  onSelectManhwaToRead: (m: Manhwa) => void;
}

export const TeamStudio: React.FC<TeamStudioProps> = ({
  team,
  allManhwas,
  allChapters,
  onBackToTeams,
  onSelectManhwaToRead
}) => {
  const { user, profile, isOwner } = useAuth();

  // Active studio tab
  const [activeTab, setActiveTab] = useState<'works' | 'chapters' | 'members' | 'invite' | 'settings'>('works');

  // Filter works belonging to this team
  const teamWorks = allManhwas.filter((m) => m.teamId === team.id && !m.isDeleted);
  const teamChapters = allChapters.filter((c) => c.teamId === team.id || teamWorks.some((w) => w.id === c.manhwaId));

  // Current user role in team
  const userMember = team.members.find((m) => m.uid === user?.uid);
  const isLeader = Boolean(user && (team.leaderId === user.uid || isOwner));
  const isManager = Boolean(user && (isLeader || userMember?.role === 'manager'));
  const canPublish = Boolean(user && (isLeader || isManager || userMember?.role === 'editor' || userMember?.role === 'translator'));

  // Work Lifecycle Filter (All, Published, Drafts, Pending Review, Unpublished, Rejected)
  const [statusFilter, setStatusFilter] = useState<'all' | PublicationStatus>('all');

  const filteredWorks = teamWorks.filter((w) => {
    if (statusFilter === 'all') return true;
    const currentStatus = w.publicationStatus || 'published';
    return currentStatus === statusFilter;
  });

  // Add / Edit Work Modal
  const [showWorkModal, setShowWorkModal] = useState(false);
  const [editingWork, setEditingWork] = useState<Manhwa | null>(null);
  const [workTitle, setWorkTitle] = useState('');
  const [workTitleOriginal, setWorkTitleOriginal] = useState('');
  const [workType, setWorkType] = useState<WorkType>('manhwa');
  const [workDesc, setWorkDesc] = useState('');
  const [workGenres, setWorkGenres] = useState<string[]>(['أكشن', 'فانتازيا']);
  const [workStatus, setWorkStatus] = useState<'ongoing' | 'completed' | 'hiatus'>('ongoing');
  const [workPublicationStatus, setWorkPublicationStatus] = useState<PublicationStatus>('published');
  const [workAuthor, setWorkAuthor] = useState('');
  const [workArtist, setWorkArtist] = useState('');
  const [assignedMembers, setAssignedMembers] = useState<AssignedMember[]>([]);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState('');
  const [isSavingWork, setIsSavingWork] = useState(false);
  const [workProgress, setWorkProgress] = useState(0);
  const [workFormError, setWorkFormError] = useState('');
  const [workSuccessAlert, setWorkSuccessAlert] = useState('');

  // Chapter Manager Modal
  const [managingWork, setManagingWork] = useState<Manhwa | null>(null);
  const [chapterNum, setChapterNum] = useState<number>(1);
  const [chapterTitle, setChapterTitle] = useState('');
  const [novelContent, setNovelContent] = useState('');
  const [chapterPages, setChapterPages] = useState<{ filename: string; blob: Blob; preview: string }[]>([]);
  const [isProcessingChapter, setIsProcessingChapter] = useState(false);
  const [chapterProgress, setChapterProgress] = useState(0);
  const [chapterStatusText, setChapterStatusText] = useState('');
  const [chapterError, setChapterError] = useState('');

  // Team Settings Form State
  const [settingsName, setSettingsName] = useState(team.name);
  const [settingsDesc, setSettingsDesc] = useState(team.description || '');
  const [settingsDiscord, setSettingsDiscord] = useState(team.discordUrl || '');
  const [settingsTelegram, setSettingsTelegram] = useState(team.telegramUrl || '');
  const [settingsWebsite, setSettingsWebsite] = useState(team.websiteUrl || '');
  const [settingsLogoFile, setSettingsLogoFile] = useState<File | null>(null);
  const [settingsLogoPreview, setSettingsLogoPreview] = useState(team.logoUrl || '');
  const [settingsBannerFile, setSettingsBannerFile] = useState<File | null>(null);
  const [settingsBannerPreview, setSettingsBannerPreview] = useState(team.bannerUrl || '');
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState('');

  // Member Search & Invite State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundUser, setFoundUser] = useState<any | null>(null);
  const [inviteRole, setInviteRole] = useState<TeamMemberRole>('translator');
  const [isSendingInvite, setIsSendingInvite] = useState(false);
  const [inviteError, setInviteError] = useState('');
  const [inviteSuccess, setInviteSuccess] = useState('');

  // Stats calculation
  const totalViews = teamWorks.reduce((acc, curr) => acc + (curr.views || 0), 0);
  const publishedCount = teamWorks.filter((w) => (w.publicationStatus || 'published') === 'published').length;
  const draftCount = teamWorks.filter((w) => w.publicationStatus === 'draft').length;
  const pendingCount = teamWorks.filter((w) => w.publicationStatus === 'pending_review').length;

  // Open New Work Modal
  const handleOpenNewWork = () => {
    setEditingWork(null);
    setWorkTitle('');
    setWorkTitleOriginal('');
    setWorkType('manhwa');
    setWorkDesc('');
    setWorkGenres(['أكشن', 'فانتازيا']);
    setWorkStatus('ongoing');
    setWorkPublicationStatus('published');
    setWorkAuthor('');
    setWorkArtist('');
    setAssignedMembers([]);
    setCoverFile(null);
    setCoverPreview('');
    setWorkFormError('');
    setShowWorkModal(true);
  };

  // Open Edit Work Modal
  const handleOpenEditWork = (m: Manhwa) => {
    setEditingWork(m);
    setWorkTitle(m.title);
    setWorkTitleOriginal(m.titleOriginal || '');
    setWorkType(m.type || 'manhwa');
    setWorkDesc(m.description);
    setWorkGenres(m.genres || []);
    setWorkStatus(m.status);
    setWorkPublicationStatus(m.publicationStatus || 'published');
    setWorkAuthor(m.author || '');
    setWorkArtist(m.artist || '');
    setAssignedMembers(m.assignedMembers || []);
    setCoverPreview(m.coverUrl);
    setCoverFile(null);
    setWorkFormError('');
    setShowWorkModal(true);
  };

  // Save Work (Draft or Published)
  const handleSaveWorkSubmit = async (e: React.FormEvent, forceStatus?: PublicationStatus) => {
    e.preventDefault();
    if (!user || !profile) return;
    setWorkFormError('');

    if (!workTitle.trim() || !workDesc.trim()) {
      setWorkFormError('يرجى ملء جميع الحقول الإلزامية (عنوان العمل والقصة).');
      return;
    }

    if (!editingWork && !coverFile && !coverPreview) {
      setWorkFormError('يرجى اختيار صورة الغلاف للعمل من هاتفك أو جهازك.');
      return;
    }

    setIsSavingWork(true);
    setWorkProgress(20);

    try {
      let finalCover = coverPreview;

      if (coverFile) {
        setWorkProgress(45);
        const opt = await hartHost.optimizeImage(coverFile, 800, 0.85);
        setWorkProgress(75);
        finalCover = await hartHost.uploadMedia(opt, 'covers', `${workTitle}_cover`);
      }

      const targetStatus = forceStatus || workPublicationStatus;
      const allowedEditors = Array.from(new Set([user.uid, team.leaderId, ...assignedMembers.map((am) => am.uid)]));
      const now = new Date().toISOString();

      if (editingWork) {
        const docRef = doc(db, 'manhwas', editingWork.id);
        await updateDoc(docRef, {
          title: workTitle.trim(),
          titleOriginal: workTitleOriginal.trim(),
          type: workType,
          description: workDesc.trim(),
          genres: workGenres,
          status: workStatus,
          publicationStatus: targetStatus,
          publishedAt: targetStatus === 'published' ? (editingWork.publishedAt || now) : editingWork.publishedAt,
          author: workAuthor.trim(),
          artist: workArtist.trim(),
          coverUrl: finalCover,
          teamId: team.id,
          teamName: team.name,
          assignedMembers,
          allowedEditors,
          updatedAt: now
        });

        await hartPublishingService.logAudit({
          actor: profile,
          action: 'edit_team_work',
          targetType: 'manhwa',
          targetId: editingWork.id,
          targetName: workTitle.trim(),
          details: `تم تحديث بيانات العمل وحالة النشر إلى: ${targetStatus}`
        });

        setWorkSuccessAlert(`تم تحديث وحفظ العمل "${workTitle.trim()}" بنجاح!`);
      } else {
        const payload: Omit<Manhwa, 'id'> = {
          title: workTitle.trim(),
          titleOriginal: workTitleOriginal.trim(),
          type: workType,
          description: workDesc.trim(),
          genres: workGenres,
          status: workStatus,
          publicationStatus: targetStatus,
          publishedAt: targetStatus === 'published' ? now : undefined,
          author: workAuthor.trim(),
          artist: workArtist.trim(),
          coverUrl: finalCover,
          teamId: team.id,
          teamName: team.name,
          views: 0,
          rating: 5.0,
          ratingCount: 1,
          publisherId: user.uid,
          publisherName: profile.displayName || user.displayName || 'ناشر الفريق',
          assignedMembers,
          allowedEditors,
          createdAt: now,
          updatedAt: now
        };

        const docRef = await addDoc(collection(db, 'manhwas'), payload);

        await hartPublishingService.logAudit({
          actor: profile,
          action: 'create_team_work',
          targetType: 'manhwa',
          targetId: docRef.id,
          targetName: workTitle.trim(),
          details: `تم إنشاء العمل تحت فريق ${team.name} بحالة: ${targetStatus}`
        });

        setWorkSuccessAlert(`تم إنشاء العمل "${workTitle.trim()}" بنجاح وحفظه بحالة [${PUBLICATION_STATUS_LABELS[targetStatus].ar}]!`);
      }

      setShowWorkModal(false);
      setTimeout(() => setWorkSuccessAlert(''), 3500);
    } catch (err: any) {
      console.error('Save work error:', err);
      setWorkFormError(err.message || 'فشل حفظ العمل');
    } finally {
      setIsSavingWork(false);
      setWorkProgress(0);
    }
  };

  // Quick One-Click Publish or Unpublish
  const handleTogglePublishWork = async (m: Manhwa) => {
    if (!profile) return;
    const isCurrentlyPublished = (m.publicationStatus || 'published') === 'published';
    try {
      if (isCurrentlyPublished) {
        await hartPublishingService.unpublishWork(m.id, profile, m.title);
        setWorkSuccessAlert(`تم سحب العمل "${m.title}" وإلغاء نشره.`);
      } else {
        await hartPublishingService.publishWork(m.id, profile, m.title);
        setWorkSuccessAlert(`تم نشر العمل "${m.title}" رسمياً وهو متاح الآن للجمهور!`);
      }
      setTimeout(() => setWorkSuccessAlert(''), 3500);
    } catch (err: any) {
      alert(err.message || 'فشل تحديث حالة النشر');
    }
  };

  // Soft Delete Work
  const handleDeleteWork = async (m: Manhwa) => {
    if (!profile) return;
    if (!window.confirm(`هل أنت متأكد من حذف العمل "${m.title}"؟ سيتم نقله لسلة المحذوفات.`)) return;
    try {
      await hartPublishingService.toggleDeleteWork(m.id, true, profile, m.title);
      setWorkSuccessAlert(`تم نقل العمل "${m.title}" إلى سلة المحذوفات.`);
      setTimeout(() => setWorkSuccessAlert(''), 3500);
    } catch (err: any) {
      alert(err.message || 'فشل حذف العمل');
    }
  };

  // Open Chapter Manager for a specific work
  const handleOpenChapters = (work: Manhwa) => {
    setManagingWork(work);
    const existingWorkChapters = allChapters
      .filter((c) => c.manhwaId === work.id)
      .sort((a, b) => b.chapterNumber - a.chapterNumber);
    const nextNum = existingWorkChapters.length > 0 ? existingWorkChapters[0].chapterNumber + 1 : 1;
    setChapterNum(nextNum);
    setChapterTitle(`الفصل ${nextNum}`);
    setNovelContent('');
    setChapterPages([]);
    setChapterError('');
    setChapterStatusText('');
  };

  // Handle Multi Pages File Select
  const handleChapterPagesSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files).sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' })
    );

    const items = files.map((f) => ({
      filename: f.name,
      blob: f,
      preview: URL.createObjectURL(f)
    }));

    setChapterPages((prev) => [...prev, ...items]);
  };

  // Save Chapter
  const handleSaveChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!managingWork || !user || !profile) return;
    setChapterError('');

    if (managingWork.type === 'novel') {
      if (!novelContent.trim()) {
        setChapterError('يرجى كتابة نص الفصل للرواية.');
        return;
      }
    } else {
      if (chapterPages.length === 0) {
        setChapterError('يرجى اختيار صور وصفحات الفصل من جهازك.');
        return;
      }
    }

    setIsProcessingChapter(true);
    setChapterProgress(10);
    setChapterStatusText('جاري معالجة صفحات وفصول العمل عبر محرك التخزين...');

    try {
      let pageUrls: string[] = [];

      if (managingWork.type !== 'novel' && chapterPages.length > 0) {
        const blobs = chapterPages.map((p) => p.blob);
        pageUrls = await hartHost.uploadMultiple(
          blobs,
          'chapters',
          (percent) => setChapterProgress(Math.min(90, Math.round(percent * 0.85) + 10))
        );
      }

      setChapterStatusText('جاري تثبيت سجل الفصل في قاعدة البيانات...');
      const now = new Date().toISOString();

      const chapterPayload: Omit<Chapter, 'id'> = {
        manhwaId: managingWork.id,
        chapterNumber: Number(chapterNum),
        title: chapterTitle.trim() || `الفصل ${chapterNum}`,
        pages: pageUrls,
        pagesCount: pageUrls.length,
        novelContent: managingWork.type === 'novel' ? novelContent.trim() : undefined,
        teamId: team.id,
        publisherId: user.uid,
        publicationStatus: 'published',
        views: 0,
        createdAt: now,
        updatedAt: now
      };

      await addDoc(collection(db, 'chapters'), chapterPayload);

      // Update work's latest chapter info
      await updateDoc(doc(db, 'manhwas', managingWork.id), {
        latestChapterNumber: Number(chapterNum),
        latestChapterTitle: chapterTitle.trim() || `الفصل ${chapterNum}`,
        updatedAt: now
      });

      await hartPublishingService.logAudit({
        actor: profile,
        action: 'publish_chapter',
        targetType: 'chapter',
        targetId: managingWork.id,
        targetName: `${managingWork.title} - ${chapterTitle.trim()}`,
        details: `تم رفع ونشر الفصل رقم ${chapterNum} بنجاح`
      });

      setChapterStatusText('تم نشر وتثبيت الفصل بنجاح!');
      setChapterNum((prev) => prev + 1);
      setChapterTitle(`الفصل ${Number(chapterNum) + 1}`);
      setNovelContent('');
      setChapterPages([]);

      setTimeout(() => {
        setChapterStatusText('');
      }, 3000);
    } catch (err: any) {
      console.error('Error saving chapter:', err);
      setChapterError(err.message || 'فشل حفظ الفصل');
    } finally {
      setIsProcessingChapter(false);
      setChapterProgress(0);
    }
  };

  // Delete Chapter
  const handleDeleteChapter = async (ch: Chapter) => {
    if (!profile) return;
    if (!window.confirm(`هل أنت متأكد من حذف الفصل رقم ${ch.chapterNumber}؟`)) return;
    try {
      await deleteDoc(doc(db, 'chapters', ch.id));
      await hartPublishingService.logAudit({
        actor: profile,
        action: 'delete_chapter',
        targetType: 'chapter',
        targetId: ch.id,
        targetName: `${ch.title || ch.chapterNumber}`,
        details: 'تم حذف الفصل نهائياً'
      });
    } catch (err: any) {
      alert(err.message || 'فشل حذف الفصل');
    }
  };

  // Search User to Invite
  const handleSearchInviteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setInviteError('');
    setInviteSuccess('');
    setFoundUser(null);
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      const res = await hartTeamService.searchUser(searchQuery.trim());
      if (!res) {
        setInviteError('لم يتم العثور على أي مستخدم مطابق لهذا المعرّف.');
      } else {
        const alreadyIn = team.members.some((m) => m.uid === res.uid);
        if (alreadyIn) {
          setInviteError(`المستخدم "${res.displayName}" عضو بالفعل في هذا الفريق.`);
        }
        setFoundUser(res);
      }
    } catch (err: any) {
      setInviteError(err.message || 'خطأ في البحث');
    } finally {
      setIsSearching(false);
    }
  };

  // Send Invitation
  const handleSendTeamInvitation = async () => {
    if (!foundUser || !profile) return;
    setIsSendingInvite(true);
    setInviteError('');
    setInviteSuccess('');
    try {
      await hartTeamService.sendTeamInvitation({
        team,
        sender: profile,
        targetUser: foundUser,
        role: inviteRole
      });
      setInviteSuccess(`تم إرسال دعوة انضمام رسمية بنجاح إلى "${foundUser.displayName}".`);
      setFoundUser(null);
      setSearchQuery('');
    } catch (err: any) {
      setInviteError(err.message || 'فشل إرسال الدعوة');
    } finally {
      setIsSendingInvite(false);
    }
  };

  // Save Team Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setIsSavingSettings(true);
    setSettingsMsg('');
    try {
      let finalLogo = team.logoUrl;
      let finalBanner = team.bannerUrl;

      if (settingsLogoFile) {
        const opt = await hartHost.optimizeImage(settingsLogoFile, 400, 0.85);
        finalLogo = await hartHost.uploadMedia(opt, 'teams', `${settingsName}_logo`);
      }

      if (settingsBannerFile) {
        const opt = await hartHost.optimizeImage(settingsBannerFile, 1200, 0.85);
        finalBanner = await hartHost.uploadMedia(opt, 'teams', `${settingsName}_banner`);
      }

      await hartTeamService.updateTeamSettings(team.id, {
        name: settingsName.trim(),
        description: settingsDesc.trim(),
        logoUrl: finalLogo,
        bannerUrl: finalBanner,
        discordUrl: settingsDiscord.trim(),
        telegramUrl: settingsTelegram.trim(),
        websiteUrl: settingsWebsite.trim()
      });

      setSettingsMsg('تم حفظ وتحديث إعدادات الفريق بنجاح!');
      setTimeout(() => setSettingsMsg(''), 3000);
    } catch (err: any) {
      alert(err.message || 'فشل حفظ الإعدادات');
    } finally {
      setIsSavingSettings(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      
      {/* Top Studio Header with Team Identity */}
      <div className="relative overflow-hidden rounded-3xl bg-[#101627] border border-purple-500/30 p-6 sm:p-8 mb-8 shadow-2xl">
        {team.bannerUrl && (
          <div className="absolute inset-0 opacity-25 pointer-events-none">
            <SmartImage src={team.bannerUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#101627] via-[#101627]/70 to-transparent"></div>
          </div>
        )}

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <SmartImage
              src={team.logoUrl}
              alt={team.name}
              fallbackText={team.name}
              containerClassName="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border-2 border-purple-400/40 shadow-2xl shrink-0 bg-[#151b2d]"
              className="w-full h-full object-cover"
            />

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-purple-600 to-pink-600 text-white uppercase tracking-wider">
                  استوديو النشر المستقل
                </span>
                {team.isVerified && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                    فريق موثّق
                  </span>
                )}
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">{team.name}</h1>
              <p className="text-xs text-gray-400 mt-1 flex items-center gap-2">
                <span>القائد: <strong className="text-purple-300">{team.leaderName}</strong></span>
                <span>•</span>
                <span>دورك: <strong className="text-pink-300">{isLeader ? 'قائد ومؤسس' : TEAM_ROLE_LABELS[userMember?.role || 'member']}</strong></span>
              </p>
            </div>
          </div>

          {/* Quick Actions Header */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
            <button
              onClick={onBackToTeams}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <ArrowRight className="w-4 h-4" />
              <span>العودة لجميع الفرق</span>
            </button>

            {canPublish && (
              <button
                onClick={handleOpenNewWork}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-900/40 hover:scale-105 transition-transform"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء عمل جديد للفريق</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 relative z-10">
          <div className="p-3 bg-[#151b2d]/80 rounded-2xl border border-white/5 text-center">
            <span className="text-lg font-black text-white">{teamWorks.length}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">إجمالي الأعمال</span>
          </div>

          <div className="p-3 bg-[#151b2d]/80 rounded-2xl border border-white/5 text-center">
            <span className="text-lg font-black text-emerald-400">{publishedCount}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">أعمال منشورة علناً</span>
          </div>

          <div className="p-3 bg-[#151b2d]/80 rounded-2xl border border-white/5 text-center">
            <span className="text-lg font-black text-amber-400">{draftCount + pendingCount}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">مسودات وقيد المراجعة</span>
          </div>

          <div className="p-3 bg-[#151b2d]/80 rounded-2xl border border-white/5 text-center">
            <span className="text-lg font-black text-purple-300">{totalViews}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">إجمالي المشاهدات</span>
          </div>
        </div>
      </div>

      {/* Global Success / Alert Banner */}
      {workSuccessAlert && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-3 animate-in fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="font-bold">{workSuccessAlert}</span>
        </div>
      )}

      {/* Studio Tab Navigation */}
      <div className="flex items-center gap-2 mb-6 border-b border-white/10 pb-3 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('works')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'works'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
              : 'bg-[#151b2d] text-gray-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>أعمال الفريق ومنشوراته ({teamWorks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('members')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'members'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
              : 'bg-[#151b2d] text-gray-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>طاقم العمل والصلاحيات ({team.members?.length || 1})</span>
        </button>

        {isManager && (
          <button
            onClick={() => setActiveTab('invite')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === 'invite'
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-900/40'
                : 'bg-purple-950/40 text-purple-300 hover:text-white border border-purple-500/30'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>دعوة أعضاء بالمعرّف الفريد</span>
          </button>
        )}

        {isManager && (
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === 'settings'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                : 'bg-[#151b2d] text-gray-400 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>هوية وإعدادات الفريق</span>
          </button>
        )}
      </div>

      {/* TAB 1: WORKS & PUBLISHING PIPELINE */}
      {activeTab === 'works' && (
        <div>
          {/* Lifecycle Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-[#101627] p-4 rounded-2xl border border-white/5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-gray-400 ml-2">تصفية حسب الحالة:</span>

              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  statusFilter === 'all' ? 'bg-purple-600 text-white' : 'bg-[#151b2d] text-gray-400 hover:text-white'
                }`}
              >
                الكل ({teamWorks.length})
              </button>

              <button
                onClick={() => setStatusFilter('published')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                  statusFilter === 'published' ? 'bg-emerald-600 text-white' : 'bg-[#151b2d] text-emerald-400 hover:text-emerald-300'
                }`}
              >
                <span>منشور علناً</span>
                <span>({teamWorks.filter((w) => (w.publicationStatus || 'published') === 'published').length})</span>
              </button>

              <button
                onClick={() => setStatusFilter('draft')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                  statusFilter === 'draft' ? 'bg-amber-600 text-white' : 'bg-[#151b2d] text-amber-300 hover:text-amber-200'
                }`}
              >
                <span>مسودات</span>
                <span>({teamWorks.filter((w) => w.publicationStatus === 'draft').length})</span>
              </button>

              <button
                onClick={() => setStatusFilter('pending_review')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                  statusFilter === 'pending_review' ? 'bg-sky-600 text-white' : 'bg-[#151b2d] text-sky-400 hover:text-sky-300'
                }`}
              >
                <span>بانتظار المراجعة</span>
                <span>({teamWorks.filter((w) => w.publicationStatus === 'pending_review').length})</span>
              </button>

              <button
                onClick={() => setStatusFilter('unpublished')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  statusFilter === 'unpublished' ? 'bg-gray-700 text-white' : 'bg-[#151b2d] text-gray-400'
                }`}
              >
                مسحوب ({teamWorks.filter((w) => w.publicationStatus === 'unpublished').length})
              </button>
            </div>

            {canPublish && (
              <button
                onClick={handleOpenNewWork}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-bold rounded-xl shadow-md shadow-purple-900/30"
              >
                + إضافة عمل جديد
              </button>
            )}
          </div>

          {/* Works Grid */}
          {filteredWorks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredWorks.map((work) => {
                const pubStatus = work.publicationStatus || 'published';
                const statusMeta = PUBLICATION_STATUS_LABELS[pubStatus] || PUBLICATION_STATUS_LABELS.published;
                const workChs = allChapters.filter((c) => c.manhwaId === work.id);
                const isPublished = pubStatus === 'published';

                return (
                  <div
                    key={work.id}
                    className="p-5 bg-[#101627] hover:bg-[#141b2f] rounded-3xl border border-white/5 hover:border-purple-500/30 shadow-xl transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Work Header with Cover & Meta */}
                      <div className="flex gap-4 mb-4">
                        <SmartImage
                          src={work.coverUrl}
                          alt={work.title}
                          fallbackText={work.title}
                          className="w-full h-full object-cover rounded-xl"
                          aspectRatio="aspect-[3/4]"
                          containerClassName="w-20 h-28 rounded-xl shadow-lg border border-purple-500/20 shrink-0 bg-[#151b2d] overflow-hidden"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.bg} ${statusMeta.color} ${statusMeta.border}`}>
                              {statusMeta.ar}
                            </span>
                            <span className="text-[10px] text-gray-400 px-1.5 py-0.5 rounded bg-white/5">
                              {WORK_TYPE_LABELS[work.type || 'manhwa']?.ar || 'مانهوا'}
                            </span>
                          </div>

                          <h3 className="text-base font-bold text-white truncate group-hover:text-purple-300">
                            {work.title}
                          </h3>

                          {work.titleOriginal && (
                            <p className="text-[11px] text-gray-500 truncate dir-ltr text-right">
                              {work.titleOriginal}
                            </p>
                          )}

                          <div className="flex items-center gap-2 text-xs text-gray-400 mt-2">
                            <span className="text-purple-300 font-bold">{workChs.length} فصل</span>
                            <span>•</span>
                            <span>{work.views || 0} قراءة</span>
                          </div>
                        </div>
                      </div>

                      {/* Assigned Contributor Badges */}
                      {work.assignedMembers && work.assignedMembers.length > 0 && (
                        <div className="mb-4 pt-3 border-t border-white/5">
                          <span className="text-[10px] text-gray-500 block mb-1.5">الطاقم المخصص للعمل:</span>
                          <div className="flex flex-wrap gap-1.5">
                            {work.assignedMembers.map((am) => (
                              <span
                                key={am.uid}
                                className="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-[#151b2d] text-purple-300 border border-purple-800/40"
                              >
                                {am.displayName} ({TEAM_ROLE_LABELS[am.role as TeamMemberRole] || am.role})
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Work Action Controls */}
                    <div className="pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {/* Manage Chapters */}
                        <button
                          type="button"
                          onClick={() => handleOpenChapters(work)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/30"
                        >
                          <Layers className="w-3.5 h-3.5" />
                          <span>إدارة الفصول ({workChs.length})</span>
                        </button>

                        {/* Preview / Read */}
                        <button
                          type="button"
                          onClick={() => onSelectManhwaToRead(work)}
                          className="p-1.5 text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
                          title="معاينة وقراءة"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Edit Work Details */}
                        <button
                          type="button"
                          onClick={() => handleOpenEditWork(work)}
                          className="p-1.5 text-gray-400 hover:text-purple-300 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
                          title="تعديل تفاصيل العمل"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Publishing State Actions */}
                      <div className="flex items-center gap-2">
                        {isPublished ? (
                          <button
                            type="button"
                            onClick={() => handleTogglePublishWork(work)}
                            className="px-3 py-1 bg-amber-950/40 hover:bg-amber-950/70 text-amber-300 border border-amber-500/40 text-xs font-bold rounded-xl transition-colors"
                            title="سحب العمل من النشر العام"
                          >
                            سحب النشر
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleTogglePublishWork(work)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-900/40 transition-colors"
                            title="نشر العمل وجعله متاحاً للمستخدمين"
                          >
                            نشر الآن
                          </button>
                        )}

                        {isManager && (
                          <button
                            type="button"
                            onClick={() => handleDeleteWork(work)}
                            className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-950/30 rounded-xl transition-colors"
                            title="حذف العمل"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-20 text-center bg-[#101627] rounded-3xl border border-white/5 p-8 max-w-md mx-auto">
              <BookOpen className="w-12 h-12 text-gray-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">لا توجد أعمال تطابق هذا التصنيف</h3>
              <p className="text-xs text-gray-400 mb-6">
                يمكنك إنشاء عمل جديد للفريق وحفظه كمسودة أو نشره مباشرة في المنصة.
              </p>
              {canPublish && (
                <button
                  onClick={handleOpenNewWork}
                  className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl text-xs font-bold"
                >
                  إنشاء عمل جديد الآن
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MEMBERS & ROLES */}
      {activeTab === 'members' && (
        <div className="bg-[#101627] rounded-3xl border border-white/5 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-white/5">
            <div>
              <h3 className="text-base font-bold text-white">طاقم عمل الفريق والصلاحيات</h3>
              <p className="text-xs text-gray-400">
                إدارة أعضاء الفريق وتعيين أدوار المترجمين والمحررين والمدققين
              </p>
            </div>
            <span className="text-xs font-bold text-purple-300 bg-purple-950/60 px-3 py-1 rounded-full border border-purple-800/40">
              {team.members?.length || 1} أعضاء
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {team.members?.map((member) => {
              const isMemberLeader = member.uid === team.leaderId;
              const canEditRole = isManager && !isMemberLeader;

              return (
                <div
                  key={member.uid}
                  className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 flex flex-col justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl overflow-hidden border border-purple-500/30 bg-[#0d121f] shrink-0 flex items-center justify-center">
                      {member.photoUrl ? (
                        <SmartImage src={member.photoUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
                      ) : (
                        <span className="font-bold text-sm text-purple-300">
                          {member.displayName[0]?.toUpperCase()}
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white truncate">{member.displayName}</h4>
                        {isMemberLeader && (
                          <span title="قائد ومؤسس الفريق">
                            <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-2">
                        {member.uniqueId && <span className="font-mono text-purple-300 dir-ltr">{member.uniqueId}</span>}
                        <span>•</span>
                        <span>انضم {new Date(member.joinedAt).toLocaleDateString('ar-EG')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
                    {canEditRole ? (
                      <div className="flex items-center gap-2 flex-1">
                        <label className="text-[10px] text-gray-400 shrink-0">الدور:</label>
                        <select
                          value={member.role}
                          onChange={async (e) => {
                            if (!user) return;
                            try {
                              await hartTeamService.updateMemberRole({
                                team,
                                targetUid: member.uid,
                                newRole: e.target.value as TeamMemberRole,
                                currentUid: user.uid,
                                isPlatformOwner: isOwner
                              });
                            } catch (err: any) {
                              alert(err.message || 'فشل تعديل الدور');
                            }
                          }}
                          className="bg-[#101627] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-purple-300 outline-none flex-1"
                        >
                          <option value="manager">مدير الفريق (Manager)</option>
                          <option value="editor">محرر أعمال (Editor)</option>
                          <option value="translator">مترجم (Translator)</option>
                          <option value="typesetter">محرر نصوص (Typesetter)</option>
                          <option value="cleaner">مبيّض (Cleaner)</option>
                          <option value="proofreader">مدقق لغوي (Proofreader)</option>
                          <option value="member">عضو عادي (Member)</option>
                        </select>
                      </div>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800/40">
                        {TEAM_ROLE_LABELS[member.role] || member.role}
                      </span>
                    )}

                    {isLeader && !isMemberLeader && (
                      <button
                        type="button"
                        onClick={async () => {
                          if (!user) return;
                          if (!window.confirm(`هل أنت متأكد من إزالة العضو "${member.displayName}"؟`)) return;
                          try {
                            await hartTeamService.removeMember({
                              team,
                              targetUid: member.uid,
                              currentUid: user.uid,
                              isPlatformOwner: isOwner
                            });
                          } catch (err: any) {
                            alert(err.message || 'فشل إزالة العضو');
                          }
                        }}
                        className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-950/40 rounded-lg transition-colors"
                        title="إزالة العضو"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: INVITE BY UNIQUE ID */}
      {activeTab === 'invite' && isManager && (
        <div className="bg-[#101627] rounded-3xl border border-white/5 p-6 shadow-xl space-y-6">
          <div>
            <h3 className="text-base font-bold text-white mb-1">دعوة عضو جديد عبر المعرّف الفريد</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              ابحث عن أي قارئ أو مترجم مسجل في المنصة باستخدام معرّف الحساب الفريد (مثل <span className="font-mono text-purple-300">MH-842910</span>) أو بريده الإلكتروني.
            </p>
          </div>

          <form onSubmit={handleSearchInviteUser} className="flex gap-2 max-w-xl">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="أدخل معرّف الحساب (MH-XXXXXX) أو البريد الإلكتروني"
                className="w-full bg-[#151b2d] border border-white/10 rounded-xl pr-9 pl-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSearching}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all"
            >
              {isSearching ? 'جاري البحث...' : 'بحث'}
            </button>
          </form>

          {inviteError && (
            <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2 max-w-xl">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{inviteError}</span>
            </div>
          )}

          {inviteSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2 max-w-xl">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{inviteSuccess}</span>
            </div>
          )}

          {foundUser && (
            <div className="p-4 bg-[#151b2d] rounded-2xl border border-purple-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 max-w-xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl overflow-hidden border border-purple-500/40 bg-[#0d121f] shrink-0 flex items-center justify-center">
                  {foundUser.photoUrl ? (
                    <SmartImage src={foundUser.photoUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
                  ) : (
                    <span className="font-bold text-base text-purple-300">{foundUser.displayName[0]?.toUpperCase()}</span>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">{foundUser.displayName}</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="font-mono text-purple-300 text-xs font-bold">{foundUser.uniqueId}</span>
                    <span className="text-[11px] text-gray-400 dir-ltr text-right">{foundUser.email}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as TeamMemberRole)}
                  className="bg-[#101627] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                >
                  <option value="translator">مترجم</option>
                  <option value="editor">محرر أعمال</option>
                  <option value="typesetter">محرر نصوص</option>
                  <option value="cleaner">مبيّض</option>
                  <option value="proofreader">مدقق لغوي</option>
                  <option value="manager">مدير</option>
                  <option value="member">عضو</option>
                </select>

                <button
                  type="button"
                  disabled={isSendingInvite}
                  onClick={handleSendTeamInvitation}
                  className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40 disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingInvite ? 'جاري الإرسال...' : 'إرسال الدعوة'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: TEAM SETTINGS & BRANDING */}
      {activeTab === 'settings' && isManager && (
        <form onSubmit={handleSaveSettings} className="bg-[#101627] rounded-3xl border border-white/5 p-6 sm:p-8 shadow-xl space-y-4 max-w-2xl">
          <h3 className="text-base font-bold text-white mb-2">تعديل هوية وإعدادات الفريق</h3>

          {settingsMsg && (
            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>{settingsMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">اسم الفريق *</label>
            <input
              type="text"
              required
              value={settingsName}
              onChange={(e) => setSettingsName(e.target.value)}
              className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
            />
          </div>

          {/* Logo Upload */}
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">شعار الفريق (Logo)</label>
            <div className="flex items-center gap-4">
              {settingsLogoPreview ? (
                <img src={settingsLogoPreview} alt="Logo" className="w-16 h-16 rounded-2xl object-cover border border-purple-500/40 shrink-0" />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-xs shrink-0">
                  شعار
                </div>
              )}
              <div>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-purple-300 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>تغيير الشعار من جهازك</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setSettingsLogoFile(e.target.files[0]);
                        setSettingsLogoPreview(URL.createObjectURL(e.target.files[0]));
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Banner Upload */}
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">غلاف الفريق العريض (Banner)</label>
            <div className="flex items-center gap-4">
              {settingsBannerPreview ? (
                <img src={settingsBannerPreview} alt="Banner" className="w-28 h-16 rounded-xl object-cover border border-purple-500/40 shrink-0" />
              ) : (
                <div className="w-28 h-16 rounded-xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-[10px] shrink-0">
                  غلاف
                </div>
              )}
              <div>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-pink-300 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>تغيير الغلاف</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setSettingsBannerFile(e.target.files[0]);
                        setSettingsBannerPreview(URL.createObjectURL(e.target.files[0]));
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">نبذة عن الفريق</label>
            <textarea
              rows={3}
              value={settingsDesc}
              onChange={(e) => setSettingsDesc(e.target.value)}
              className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1">ديسكورد</label>
              <input
                type="text"
                value={settingsDiscord}
                onChange={(e) => setSettingsDiscord(e.target.value)}
                placeholder="discord.gg/..."
                className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1">تليجرام</label>
              <input
                type="text"
                value={settingsTelegram}
                onChange={(e) => setSettingsTelegram(e.target.value)}
                placeholder="t.me/..."
                className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1">الموقع الإلكتروني</label>
              <input
                type="text"
                value={settingsWebsite}
                onChange={(e) => setSettingsWebsite(e.target.value)}
                placeholder="https://..."
                className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              type="submit"
              disabled={isSavingSettings}
              className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40"
            >
              {isSavingSettings ? 'جاري الحفظ...' : 'حفظ إعدادات الفريق'}
            </button>
          </div>
        </form>
      )}

      {/* CREATE / EDIT WORK MODAL */}
      {showWorkModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl relative p-6 sm:p-8 flex flex-col">
            <button
              onClick={() => setShowWorkModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-4">
              {editingWork ? `تعديل العمل: ${editingWork.title}` : 'إنشاء ونشر عمل جديد للفريق'}
            </h2>

            {workFormError && (
              <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{workFormError}</span>
              </div>
            )}

            <form onSubmit={(e) => handleSaveWorkSubmit(e)} className="space-y-4">
              
              {/* Work Type Selection */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">نوع العمل *</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {(['manhwa', 'manga', 'manhua', 'comic', 'novel'] as WorkType[]).map((t) => {
                    const info = WORK_TYPE_LABELS[t];
                    return (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setWorkType(t)}
                        className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                          workType === t
                            ? 'bg-purple-600/30 border-purple-500 text-white'
                            : 'bg-[#151b2d] border-white/5 text-gray-400 hover:text-white'
                        }`}
                      >
                        <span className="text-base">{info.flag}</span>
                        <span>{info.ar}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Title & Original Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">عنوان العمل (بالعربية) *</label>
                  <input
                    type="text"
                    required
                    value={workTitle}
                    onChange={(e) => setWorkTitle(e.target.value)}
                    placeholder="مثال: بداية الماجي الساحر"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">الاسم الأصلي / الإنجليزي</label>
                  <input
                    type="text"
                    value={workTitleOriginal}
                    onChange={(e) => setWorkTitleOriginal(e.target.value)}
                    placeholder="The Beginning After The End"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none dir-ltr text-right"
                  />
                </div>
              </div>

              {/* Cover Upload via Hart Host */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">صورة الغلاف (Cover) *</label>
                <div className="flex items-center gap-4">
                  {coverPreview ? (
                    <SmartImage
                      src={coverPreview}
                      alt="Cover"
                      aspectRatio="aspect-[3/4]"
                      containerClassName="w-20 h-28 rounded-xl border border-purple-500/40 shrink-0 bg-[#151b2d] overflow-hidden"
                      className="w-full h-full object-cover"
                      fallbackText="غلاف"
                    />
                  ) : (
                    <div className="w-20 h-28 rounded-xl bg-[#151b2d] border border-dashed border-white/20 flex flex-col items-center justify-center text-gray-500 text-[10px] shrink-0">
                      <span>لا يوجد غلاف</span>
                    </div>
                  )}

                  <div className="flex-1">
                    <label className="inline-flex items-center gap-2 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-purple-300 cursor-pointer transition-colors">
                      <Upload className="w-4 h-4" />
                      <span>اختر الغلاف من هاتفك أو جهازك</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setCoverFile(e.target.files[0]);
                            setCoverPreview(URL.createObjectURL(e.target.files[0]));
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[10px] text-gray-500 mt-1">يتم ضغطه وحفظه بشكل دائم لجميع المستخدمين</p>
                  </div>
                </div>
              </div>

              {/* Story Description */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">القصة والنبذة *</label>
                <textarea
                  rows={3}
                  required
                  value={workDesc}
                  onChange={(e) => setWorkDesc(e.target.value)}
                  placeholder="اكتب قصة مشوقة عن العمل لجذب القراء..."
                  className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                />
              </div>

              {/* Genres */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">التصنيفات</label>
                <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto no-scrollbar p-2 bg-[#151b2d] rounded-xl border border-white/5">
                  {MANHWA_GENRES.map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => {
                        if (workGenres.includes(g)) {
                          setWorkGenres(workGenres.filter((item) => item !== g));
                        } else {
                          setWorkGenres([...workGenres, g]);
                        }
                      }}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        workGenres.includes(g)
                          ? 'bg-purple-600 text-white shadow-sm'
                          : 'bg-[#101627] text-gray-400 hover:text-white'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Author, Artist, Status, Publication Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">حالة العمل</label>
                  <select
                    value={workStatus}
                    onChange={(e) => setWorkStatus(e.target.value as any)}
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  >
                    <option value="ongoing">مستمرة</option>
                    <option value="completed">مكتملة</option>
                    <option value="hiatus">متوقفة مؤقتاً</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">المؤلف (Author)</label>
                  <input
                    type="text"
                    value={workAuthor}
                    onChange={(e) => setWorkAuthor(e.target.value)}
                    placeholder="اسم المؤلف"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">الرسام (Artist)</label>
                  <input
                    type="text"
                    value={workArtist}
                    onChange={(e) => setWorkArtist(e.target.value)}
                    placeholder="اسم الرسام"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {/* Assigned Members Selection */}
              <div className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 space-y-2">
                <label className="block text-xs font-bold text-purple-300">
                  تعيين أعضاء الفريق لهذا العمل (صلاحيات التحرير ورفع الفصول):
                </label>
                <div className="flex flex-wrap gap-2">
                  {team.members?.map((m) => {
                    const isSelected = assignedMembers.some((am) => am.uid === m.uid);
                    return (
                      <button
                        key={m.uid}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setAssignedMembers(assignedMembers.filter((am) => am.uid !== m.uid));
                          } else {
                            setAssignedMembers([...assignedMembers, { uid: m.uid, displayName: m.displayName, role: m.role }]);
                          }
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-sm border border-purple-400/40'
                            : 'bg-[#101627] text-gray-400 hover:text-white border border-white/5'
                        }`}
                      >
                        <span>{m.displayName}</span>
                        <span className="text-[10px] opacity-75">({TEAM_ROLE_LABELS[m.role] || m.role})</span>
                        {isSelected && <CheckCircle className="w-3.5 h-3.5" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Publication Status Selector */}
              <div className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <label className="block text-xs font-bold text-white mb-0.5">حالة النشر الرسمية للعمل:</label>
                  <span className="text-[10px] text-gray-400">
                    يمكنك حفظ العمل كمسودة للعمل عليها لاحقاً أو نشره فوراً ليظهر للجمهور.
                  </span>
                </div>

                <select
                  value={workPublicationStatus}
                  onChange={(e) => setWorkPublicationStatus(e.target.value as PublicationStatus)}
                  className="bg-[#101627] border border-white/10 rounded-xl px-4 py-2 text-xs font-bold text-purple-300 outline-none"
                >
                  <option value="published">منشور علناً في الموقع (Published)</option>
                  <option value="draft">حفظ كمسودة خاصة (Draft)</option>
                  <option value="pending_review">إرسال للمراجعة (Pending Review)</option>
                  <option value="unpublished">غير منشور / مسحوب (Unpublished)</option>
                </select>
              </div>

              {/* Progress Bar */}
              {isSavingWork && (
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-400">
                    <span>جاري معالجة ورفع الغلاف وتثبيت السجل...</span>
                    <span>{workProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-600 transition-all duration-300" style={{ width: `${workProgress}%` }}></div>
                  </div>
                </div>
              )}

              {/* Submit Buttons */}
              <div className="pt-4 flex flex-wrap items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowWorkModal(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-gray-300"
                >
                  إلغاء
                </button>

                <button
                  type="button"
                  disabled={isSavingWork}
                  onClick={(e) => handleSaveWorkSubmit(e, 'draft')}
                  className="px-4 py-2 bg-amber-950/40 hover:bg-amber-950/70 border border-amber-500/30 text-amber-300 rounded-xl text-xs font-bold transition-all disabled:opacity-50"
                >
                  حفظ كمسودة فقط
                </button>

                <button
                  type="submit"
                  disabled={isSavingWork}
                  className="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40 transition-all disabled:opacity-50"
                >
                  {isSavingWork ? 'جاري الحفظ...' : 'نشر وتثبيت العمل الآن'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* CHAPTER MANAGER MODAL */}
      {managingWork && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl relative p-6 sm:p-8 flex flex-col">
            <button
              onClick={() => setManagingWork(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white z-20"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-4 mb-6 pb-4 border-b border-white/5">
              <SmartImage
                src={managingWork.coverUrl}
                alt={managingWork.title}
                fallbackText={managingWork.title}
                className="w-full h-full object-cover"
                aspectRatio="aspect-[3/4]"
                containerClassName="w-14 h-20 rounded-xl border border-purple-500/30 shrink-0 bg-[#151b2d] overflow-hidden"
              />

              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-500/40">
                  {WORK_TYPE_LABELS[managingWork.type || 'manhwa']?.ar || 'مانهوا'}
                </span>
                <h2 className="text-xl font-bold text-white mt-1">استوديو فصول: {managingWork.title}</h2>
                <p className="text-xs text-gray-400">
                  إجمالي الفصول المرفوعة: {allChapters.filter((c) => c.manhwaId === managingWork.id).length} فصل
                </p>
              </div>
            </div>

            {/* Chapters Table */}
            <div className="mb-8">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <span>قائمة فصول العمل</span>
              </h3>

              <div className="space-y-2 max-h-52 overflow-y-auto no-scrollbar">
                {allChapters
                  .filter((c) => c.manhwaId === managingWork.id)
                  .sort((a, b) => b.chapterNumber - a.chapterNumber)
                  .map((ch) => (
                    <div
                      key={ch.id}
                      className="p-3 bg-[#151b2d] rounded-xl border border-white/5 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-purple-900/40 text-purple-300 font-black flex items-center justify-center border border-purple-800/40">
                          {ch.chapterNumber}
                        </span>
                        <div>
                          <h4 className="font-bold text-white">{ch.title}</h4>
                          <span className="text-[10px] text-gray-400">
                            {managingWork.type === 'novel' ? 'فصل رواية مكتوب' : `${ch.pagesCount || ch.pages?.length || 0} صفحة`} • {new Date(ch.createdAt).toLocaleDateString('ar-EG')}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteChapter(ch)}
                        className="p-1.5 text-gray-500 hover:text-red-400 hover:bg-red-950/40 rounded-lg transition-colors"
                        title="حذف الفصل"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                {allChapters.filter((c) => c.manhwaId === managingWork.id).length === 0 && (
                  <div className="p-4 bg-[#151b2d] rounded-xl text-center text-xs text-gray-400">
                    لم يتم رفع أي فصول بعد. استخدم النموذج أدناه لنشر أول فصل!
                  </div>
                )}
              </div>
            </div>

            {/* Upload New Chapter Form */}
            <div className="p-5 bg-[#151b2d] rounded-2xl border border-purple-500/30">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-purple-400" />
                <span>رفع ونشر فصل جديد لهذا العمل</span>
              </h3>

              {chapterError && (
                <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{chapterError}</span>
                </div>
              )}

              {chapterStatusText && (
                <div className="p-3 mb-4 rounded-xl bg-purple-950/60 border border-purple-500/40 text-xs text-purple-300 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping"></span>
                  <span>{chapterStatusText}</span>
                </div>
              )}

              <form onSubmit={handleSaveChapter} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">رقم الفصل *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={chapterNum}
                      onChange={(e) => setChapterNum(Number(e.target.value))}
                      className="w-full bg-[#101627] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">عنوان الفصل (اختياري)</label>
                    <input
                      type="text"
                      value={chapterTitle}
                      onChange={(e) => setChapterTitle(e.target.value)}
                      placeholder="مثال: الفصل 1: بداية الرحلة"
                      className="w-full bg-[#101627] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* If Novel: Text Editor */}
                {managingWork.type === 'novel' ? (
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">محتوى ونص الفصل *</label>
                    <textarea
                      rows={10}
                      required
                      value={novelContent}
                      onChange={(e) => setNovelContent(e.target.value)}
                      placeholder="الصق نص الفصل هنا مع التنسيق والفقرات..."
                      className="w-full bg-[#101627] border border-white/10 rounded-xl p-4 text-xs text-white outline-none leading-relaxed font-sans focus:border-purple-500"
                    />
                  </div>
                ) : (
                  /* If Manhwa / Manga / Comic: Multi-Pages Image Upload */
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5">
                      صفحات وصور الفصل (بالترتيب) *
                    </label>

                    <div className="p-4 bg-[#101627] rounded-xl border border-dashed border-white/20 text-center">
                      <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#171f33] hover:bg-[#202b46] border border-white/10 text-xs font-bold text-purple-300 rounded-xl cursor-pointer transition-colors">
                        <Upload className="w-4 h-4" />
                        <span>اختيار الصفحات من هاتفك أو جهازك (متعدد)</span>
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleChapterPagesSelect}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[10px] text-gray-500 mt-2">
                        يدعم اختيار عشرات الصفحات دفعة واحدة. ترتب الصور حسب الاسم تلقائياً.
                      </p>
                    </div>

                    {chapterPages.length > 0 && (
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                          <span>الصفحات المختارة: <strong className="text-purple-300">{chapterPages.length} صفحة</strong></span>
                          <button
                            type="button"
                            onClick={() => setChapterPages([])}
                            className="text-[10px] text-red-400 hover:underline"
                          >
                            مسح الكل
                          </button>
                        </div>

                        <div className="flex gap-2 overflow-x-auto no-scrollbar p-2 bg-[#101627] rounded-xl border border-white/5">
                          {chapterPages.map((page, idx) => (
                            <div key={idx} className="relative w-16 h-24 shrink-0 rounded-lg overflow-hidden border border-white/10 group">
                              <img src={page.preview} alt="" className="w-full h-full object-cover" />
                              <span className="absolute bottom-0 inset-x-0 bg-black/80 text-[9px] font-mono text-center text-white py-0.5">
                                {idx + 1}
                              </span>
                              <button
                                type="button"
                                onClick={() => setChapterPages(chapterPages.filter((_, i) => i !== idx))}
                                className="absolute top-1 right-1 p-0.5 bg-red-600 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Chapter Progress */}
                {isProcessingChapter && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] text-purple-400">
                      <span>جاري رفع وتأمين صفحات الفصل للتخزين الدائم...</span>
                      <span>{chapterProgress}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                      <div className="h-full bg-purple-600 transition-all duration-300" style={{ width: `${chapterProgress}%` }}></div>
                    </div>
                  </div>
                )}

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={isProcessingChapter}
                    className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-900/40 disabled:opacity-50"
                  >
                    {isProcessingChapter ? 'جاري الرفع والنشر...' : 'نشر وتثبيت الفصل الآن'}
                  </button>
                </div>
              </form>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
