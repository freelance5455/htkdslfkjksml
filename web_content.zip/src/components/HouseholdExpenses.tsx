import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Download,
  Edit2,
  Trash2,
  Tag,
  Wallet,
  Calendar,
  Layers,
  Settings,
  X,
  CreditCard,
} from 'lucide-react';
import { AppSettings, ExpenseCategory, HouseholdExpense } from '../types';
import { translations } from '../utils/translations';
import { StorageService } from '../utils/storage';

interface HouseholdExpensesProps {
  records: HouseholdExpense[];
  categories: ExpenseCategory[];
  onUpdateRecords: (records: HouseholdExpense[]) => void;
  onUpdateCategories: (categories: ExpenseCategory[]) => void;
  settings: AppSettings;
}

export const HouseholdExpenses: React.FC<HouseholdExpensesProps> = ({
  records,
  categories,
  onUpdateRecords,
  onUpdateCategories,
  settings,
}) => {
  const t = translations[settings.language];
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<HouseholdExpense | null>(null);

  // Form State
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [paidTo, setPaidTo] = useState('');
  const [remarks, setRemarks] = useState('');

  // Category Management Form State
  const [newCatName, setNewCatName] = useState('');
  const [newCatUrdu, setNewCatUrdu] = useState('');

  // Filtered active records
  const activeRecords = useMemo(() => {
    return records
      .filter((r) => !r.isDeleted)
      .filter((r) => {
        const matchesSearch =
          search === '' ||
          r.description.toLowerCase().includes(search.toLowerCase()) ||
          (r.paidTo && r.paidTo.toLowerCase().includes(search.toLowerCase())) ||
          r.categoryName.toLowerCase().includes(search.toLowerCase());
        const matchesCat = categoryFilter === '' || r.categoryId === categoryFilter;
        const matchesMonth = monthFilter === '' || r.date.startsWith(monthFilter);
        return matchesSearch && matchesCat && matchesMonth;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [records, search, categoryFilter, monthFilter]);

  // Aggregate stats
  const { totalSpent, categoryTotals, monthlyTotals, currentMonthSpent } = useMemo(() => {
    const active = records.filter((r) => !r.isDeleted);
    let total = 0;
    const catMap: Record<string, { name: string; amount: number; count: number }> = {};
    const monthMap: Record<string, number> = {};

    const currentMonthKey = new Date().toISOString().slice(0, 7);
    let curMonthTotal = 0;

    for (const r of active) {
      const amt = Number(r.amount) || 0;
      total += amt;

      const cId = r.categoryId || 'cat_other';
      if (!catMap[cId]) {
        catMap[cId] = { name: r.categoryName || 'Other', amount: 0, count: 0 };
      }
      catMap[cId].amount += amt;
      catMap[cId].count += 1;

      const mKey = r.date.slice(0, 7);
      monthMap[mKey] = (monthMap[mKey] || 0) + amt;
      if (mKey === currentMonthKey) {
        curMonthTotal += amt;
      }
    }

    return {
      totalSpent: total,
      categoryTotals: catMap,
      monthlyTotals: monthMap,
      currentMonthSpent: curMonthTotal,
    };
  }, [records]);

  // Open add record
  const handleOpenAdd = () => {
    setEditingRecord(null);
    setDate(new Date().toISOString().slice(0, 10));
    setCategoryId(categories[0]?.id || 'cat_grocery');
    setDescription('');
    setAmount('');
    setPaymentMethod('Cash');
    setPaidTo('');
    setRemarks('');
    setIsModalOpen(true);
  };

  // Open edit record
  const handleOpenEdit = (rec: HouseholdExpense) => {
    setEditingRecord(rec);
    setDate(rec.date);
    setCategoryId(rec.categoryId);
    setDescription(rec.description);
    setAmount(rec.amount);
    setPaymentMethod(rec.paymentMethod);
    setPaidTo(rec.paidTo || '');
    setRemarks(rec.remarks || '');
    setIsModalOpen(true);
  };

  // Save Expense Record
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(amount);
    if (!description.trim()) {
      alert('Please enter expense description');
      return;
    }
    if (amt <= 0) {
      alert('Amount must be greater than zero');
      return;
    }

    const matchedCat = categories.find((c) => c.id === categoryId);
    const categoryName = matchedCat ? (settings.language === 'ur' && matchedCat.nameUrdu ? matchedCat.nameUrdu : matchedCat.name) : 'Other';

    if (editingRecord) {
      const old = { ...editingRecord };
      const updated: HouseholdExpense = {
        ...editingRecord,
        date,
        categoryId,
        categoryName,
        description: description.trim(),
        amount: amt,
        paymentMethod,
        paidTo: paidTo.trim(),
        remarks: remarks.trim(),
        updatedAt: new Date().toISOString(),
      };
      const newRecords = records.map((r) => (r.id === editingRecord.id ? updated : r));
      onUpdateRecords(newRecords);
      StorageService.saveExpenses(newRecords);
      StorageService.addAuditLog('UPDATE', 'Expenses', `Updated expense "${description}"`, old, updated);
    } else {
      const newRec: HouseholdExpense = {
        id: `exp_${Date.now()}`,
        date,
        categoryId,
        categoryName,
        description: description.trim(),
        amount: amt,
        paymentMethod,
        paidTo: paidTo.trim(),
        remarks: remarks.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const newRecords = [newRec, ...records];
      onUpdateRecords(newRecords);
      StorageService.saveExpenses(newRecords);
      StorageService.addAuditLog('CREATE', 'Expenses', `Added expense "${description}" of Rs. ${amt}`, null, newRec);
    }

    setIsModalOpen(false);
  };

  // Delete Record (Soft delete)
  const handleDelete = (rec: HouseholdExpense) => {
    if (window.confirm(t.confirmDelete)) {
      const updatedList = records.map((r) => (r.id === rec.id ? { ...r, isDeleted: true } : r));
      onUpdateRecords(updatedList);
      StorageService.saveExpenses(updatedList);
      StorageService.moveToRecycleBin('Expenses', rec.id, `${rec.description} (Rs. ${rec.amount})`, rec);
    }
  };

  // Add new Category
  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    const newCat: ExpenseCategory = {
      id: `cat_${Date.now()}`,
      name: newCatName.trim(),
      nameUrdu: newCatUrdu.trim() || undefined,
      color: '#6366f1',
    };
    const updatedCats = [...categories, newCat];
    onUpdateCategories(updatedCats);
    StorageService.saveExpenseCategories(updatedCats);
    StorageService.addAuditLog('CREATE', 'Settings', `Added expense category: ${newCat.name}`);
    setNewCatName('');
    setNewCatUrdu('');
  };

  // Delete Category
  const handleDeleteCategory = (catId: string) => {
    if (categories.length <= 1) {
      alert('At least one category must remain.');
      return;
    }
    if (window.confirm('Delete this category? Existing expenses will retain their label.')) {
      const updated = categories.filter((c) => c.id !== catId);
      onUpdateCategories(updated);
      StorageService.saveExpenseCategories(updated);
      StorageService.addAuditLog('DELETE', 'Settings', `Deleted category ID: ${catId}`);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const rows = activeRecords.map((r) => ({
      Date: r.date,
      Category: r.categoryName,
      Description: r.description,
      Amount: r.amount,
      'Payment Method': r.paymentMethod,
      'Paid To': r.paidTo || '',
      Remarks: r.remarks || '',
    }));
    StorageService.exportToCsv('Household_Expenses_Export', rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-lg">
            <Receipt className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {t.householdExpenses}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Track household & personal spending across customizable categories
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsCategoryModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Settings className="w-4 h-4 text-slate-500" />
            <span>{t.manageCategories}</span>
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addExpense}</span>
          </button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.totalExpenses}</span>
            <Wallet className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {settings.currencySymbol} {totalSpent.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">All-time recorded</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>This Month</span>
            <Calendar className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-blue-600 dark:text-blue-400">
            {settings.currencySymbol} {currentMonthSpent.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Current billing cycle</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Active Categories</span>
            <Tag className="w-4 h-4 text-purple-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-purple-600 dark:text-purple-400">
            {categories.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">Custom configurable</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Filtered Total</span>
            <Receipt className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-amber-600 dark:text-amber-400">
            {settings.currencySymbol}{' '}
            {activeRecords.reduce((sum, r) => sum + r.amount, 0).toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">{activeRecords.length} records in view</p>
        </div>
      </div>

      {/* Category Breakdown Progress Bar cards */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
        <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
          Category-Wise Distribution
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Object.entries(categoryTotals).map(([catId, data]) => {
            const pct = totalSpent > 0 ? (data.amount / totalSpent) * 100 : 0;
            return (
              <div key={catId} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-900 dark:text-white">
                  <span>{data.name}</span>
                  <span>{settings.currencySymbol} {data.amount.toLocaleString()}</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.max(3, pct))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>{data.count} entries</span>
                  <span>{pct.toFixed(1)}% of total</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-auto rtl:right-3" />
          <input
            type="text"
            placeholder="Search description, paid to, category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 border-0"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {settings.language === 'ur' && c.nameUrdu ? c.nameUrdu : c.name}
            </option>
          ))}
        </select>

        <input
          type="month"
          value={monthFilter}
          onChange={(e) => setMonthFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        />

        {monthFilter && (
          <button
            type="button"
            onClick={() => setMonthFilter('')}
            className="text-xs text-rose-500 hover:underline"
          >
            Clear Month
          </button>
        )}
      </div>

      {/* Records Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">{t.category}</th>
                <th className="px-4 py-3">{t.description}</th>
                <th className="px-4 py-3">{t.amount}</th>
                <th className="px-4 py-3">{t.paymentMethod}</th>
                <th className="px-4 py-3">{t.paidTo}</th>
                <th className="px-4 py-3">{t.remarks}</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No household expenses found.
                  </td>
                </tr>
              ) : (
                activeRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                      {r.date}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        {r.categoryName}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white max-w-sm">
                      {r.description}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white whitespace-nowrap">
                      {settings.currencySymbol} {r.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {r.paymentMethod}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {r.paidTo || '—'}
                    </td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                      {r.remarks || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(r)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit"
                          aria-label={`Edit expense ${r.description}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(r)}
                          className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          title="Move to Recycle Bin"
                          aria-label={`Delete expense ${r.description}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-600" />
                {editingRecord ? 'Edit Expense' : t.addExpense}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Category *
                  </label>
                  <select
                    required
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {settings.language === 'ur' && c.nameUrdu ? c.nameUrdu : c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Description *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monthly kitchen ration"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Amount ({settings.currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Payment Method
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Bank">Bank Transfer</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="JazzCash">JazzCash</option>
                    <option value="Card">Debit/Credit Card</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Paid To
                  </label>
                  <input
                    type="text"
                    placeholder="Merchant / person"
                    value={paidTo}
                    onChange={(e) => setPaidTo(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Remarks
                  </label>
                  <input
                    type="text"
                    placeholder="Optional notes"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition"
                >
                  {editingRecord ? 'Update' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Manager Modal */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Tag className="w-5 h-5 text-purple-600" />
                {t.manageCategories}
              </h3>
              <button
                type="button"
                onClick={() => setIsCategoryModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            {/* Existing Categories List */}
            <div className="mt-4 max-h-56 overflow-y-auto space-y-1.5 pr-1">
              {categories.map((c) => (
                <div
                  key={c.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800 text-xs"
                >
                  <div>
                    <span className="font-semibold text-slate-900 dark:text-white">{c.name}</span>
                    {c.nameUrdu && <span className="text-slate-400 ml-2">({c.nameUrdu})</span>}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeleteCategory(c.id)}
                    className="p-1 text-slate-400 hover:text-rose-600"
                    title="Delete category"
                    aria-label={`Delete category ${c.name}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Category Form */}
            <form onSubmit={handleAddCategory} className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Category Name (En)"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
                <input
                  type="text"
                  placeholder="اردو نام (اختیاری)"
                  value={newCatUrdu}
                  onChange={(e) => setNewCatUrdu(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 rtl:text-right"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-lg transition"
              >
                Add Category
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
