import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import confetti from 'canvas-confetti';
import { Product, CartItem, StoreSettings, SaleTransaction, SaleItem } from '../types';
import { soundEffects } from '../utils/audio';
import { 
  Camera, 
  CameraOff, 
  RefreshCw, 
  Trash2, 
  Plus, 
  Minus, 
  Search, 
  CreditCard, 
  Banknote, 
  Smartphone, 
  CheckCircle,
  X,
  Package,
  Sparkles,
  ShoppingBag,
  CheckCircle2,
  Barcode as BarcodeIcon,
  Sliders,
  ArrowRight,
  Layers
} from 'lucide-react';

interface SaleTerminalViewProps {
  inventory: Product[];
  settings: StoreSettings;
  onSaleComplete: (sale: SaleTransaction) => void;
  onInventoryUpdate: (updatedInventory: Product[]) => void;
}

export const SaleTerminalView: React.FC<SaleTerminalViewProps> = ({
  inventory,
  settings,
  onSaleComplete,
  onInventoryUpdate
}) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [manualCode, setManualCode] = useState('');
  const [scannerActive, setScannerActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [scannerError, setScannerError] = useState<string | null>(null);

  // Quick Catalog Picker
  const [catalogSearch, setCatalogSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Checkout modal
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'ewallet'>('cash');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [cashierNote, setCashierNote] = useState('');

  // Scanned Item Notice & Quantity Prompt modal state
  interface ScannedItemPromptData {
    product: Product;
    quantity: number;
    existingInCartQty: number;
    maxAvailable: number;
  }
  const [scannedPrompt, setScannedPrompt] = useState<ScannedItemPromptData | null>(null);
  const [askQuantityOnScan, setAskQuantityOnScan] = useState<boolean>(settings.promptQuantityOnScan ?? true);
  const [scannedToast, setScannedToast] = useState<string | null>(null);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const lastScannedCodeRef = useRef<{ code: string; time: number } | null>(null);

  // Categories list
  const categories = ['All', ...Array.from(new Set(inventory.map(i => i.category).filter(Boolean)))];

  // Cart calculations
  const subtotal = cart.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = (taxableAmount * settings.taxRate) / 100;
  const totalAmount = taxableAmount + taxAmount;
  const totalItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Cash change
  const numericCashTendered = parseFloat(cashTendered) || 0;
  const changeAmount = Math.max(0, numericCashTendered - totalAmount);

  // Add product with specific quantity helper
  const addProductToCartWithQty = useCallback((product: Product, quantityToAdd: number) => {
    if (quantityToAdd <= 0) return;
    const currentStock = inventory.find(i => i.id === product.id)?.stock ?? product.stock;
    
    setCart(prevCart => {
      const existing = prevCart.find(item => item.product.id === product.id);
      if (existing) {
        const nextTotal = existing.quantity + quantityToAdd;
        if (nextTotal > currentStock) {
          if (settings.enableSound) soundEffects.playErrorBuzz();
          alert(`Cannot add ${quantityToAdd} more. Only ${currentStock - existing.quantity} additional units available in stock.`);
          return prevCart;
        }
        if (settings.enableSound) soundEffects.playScanBeep();
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: nextTotal }
            : item
        );
      } else {
        if (quantityToAdd > currentStock) {
          if (settings.enableSound) soundEffects.playErrorBuzz();
          alert(`Cannot add ${quantityToAdd}. Only ${currentStock} units available in stock.`);
          return prevCart;
        }
        if (settings.enableSound) soundEffects.playScanBeep();
        return [...prevCart, { product, quantity: quantityToAdd }];
      }
    });

    setScannedToast(`Added ${quantityToAdd}x ${product.name} to cart`);
    setTimeout(() => setScannedToast(null), 2500);
  }, [inventory, settings.enableSound]);

  // Notice that item was scanned and ask quantity or open prompt
  const triggerItemScannedNotice = useCallback((product: Product) => {
    if (settings.enableSound) soundEffects.playScanBeep();

    const currentStock = inventory.find(i => i.id === product.id)?.stock ?? product.stock;
    const existingCartItem = cart.find(c => c.product.id === product.id);
    const existingQty = existingCartItem ? existingCartItem.quantity : 0;
    const maxAvailable = Math.max(0, currentStock - existingQty);

    if (maxAvailable <= 0) {
      if (settings.enableSound) soundEffects.playErrorBuzz();
      alert(`"${product.name}" is already at maximum available stock in your cart (${currentStock} units).`);
      return;
    }

    if (askQuantityOnScan) {
      setScannedPrompt({
        product,
        quantity: 1,
        existingInCartQty: existingQty,
        maxAvailable
      });
    } else {
      addProductToCartWithQty(product, 1);
    }
  }, [inventory, cart, askQuantityOnScan, addProductToCartWithQty, settings.enableSound]);

  // Handle scanned code
  const handleDecodedCode = useCallback((code: string) => {
    const trimmed = code.trim();
    if (!trimmed) return;

    // Do not trigger another scan while the quantity prompt is open
    if (scannedPrompt) return;

    // Prevent immediate double scan trigger within 1.2s for identical code
    const now = Date.now();
    if (
      lastScannedCodeRef.current &&
      lastScannedCodeRef.current.code === trimmed &&
      now - lastScannedCodeRef.current.time < 1200
    ) {
      return;
    }
    lastScannedCodeRef.current = { code: trimmed, time: now };

    const matchedProduct = inventory.find(
      i => i.code.toLowerCase() === trimmed.toLowerCase()
    );

    if (matchedProduct) {
      triggerItemScannedNotice(matchedProduct);
    } else {
      if (settings.enableSound) soundEffects.playErrorBuzz();
      alert(`Barcode "${trimmed}" not recognized in inventory.`);
    }
  }, [inventory, scannedPrompt, triggerItemScannedNotice, settings.enableSound]);

  // Start Scanner
  const startScanner = useCallback(async () => {
    setScannerError(null);
    try {
      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode("reader");
      }

      await html5QrCodeRef.current.start(
        { facingMode: facingMode },
        {
          fps: 15,
          qrbox: { width: 250, height: 250 },
          aspectRatio: 1.0
        },
        (decodedText) => {
          handleDecodedCode(decodedText);
        },
        () => {
          // ignore frames with no barcode
        }
      );
      setScannerActive(true);
    } catch (err: unknown) {
      console.error('Camera start failed:', err);
      const msg = err instanceof Error ? err.message : String(err);
      setScannerError('Camera access failed: ' + msg);
      setScannerActive(false);
    }
  }, [facingMode, handleDecodedCode]);

  // Stop Scanner
  const stopScanner = useCallback(async () => {
    if (html5QrCodeRef.current && scannerActive) {
      try {
        await html5QrCodeRef.current.stop();
        await html5QrCodeRef.current.clear();
      } catch (e) {
        console.error(e);
      }
      setScannerActive(false);
    }
  }, [scannerActive]);

  // Flip camera
  const toggleFacingMode = async () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    if (scannerActive) {
      await stopScanner();
      setTimeout(() => {
        startScanner();
      }, 300);
    }
  };

  // Clean up scanner on unmount
  useEffect(() => {
    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(() => {});
      }
    };
  }, []);

  // Handle Manual Code input
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    const targetCode = manualCode.trim();
    const matchedProduct = inventory.find(
      i => i.code.toLowerCase() === targetCode.toLowerCase()
    );
    if (matchedProduct) {
      triggerItemScannedNotice(matchedProduct);
    } else {
      if (settings.enableSound) soundEffects.playErrorBuzz();
      alert(`Barcode "${targetCode}" not recognized in inventory.`);
    }
    setManualCode('');
  };

  // Cart quantity adjustments
  const updateQuantity = (productId: string, delta: number) => {
    const targetProduct = inventory.find(i => i.id === productId);
    if (!targetProduct) return;

    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          if (newQty > targetProduct.stock) {
            alert(`Cannot exceed available stock of ${targetProduct.stock}`);
            return item;
          }
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(i => i.product.id !== productId));
  };

  const clearCart = () => {
    if (cart.length > 0) {
      setCart([]);
    }
  };

  // Open Checkout
  const handleOpenCheckout = () => {
    if (cart.length === 0) {
      alert('Cart is empty. Add products first.');
      return;
    }
    setCashTendered(totalAmount.toFixed(2));
    setShowCheckoutModal(true);
  };

  // Complete Sale
  const handleFinishCheckout = () => {
    if (paymentMethod === 'cash' && numericCashTendered < totalAmount) {
      alert('Cash tendered is less than the total amount!');
      return;
    }

    // Deduct stock from inventory
    const updatedInventory = inventory.map(item => {
      const cartItem = cart.find(c => c.product.id === item.id);
      if (cartItem) {
        return {
          ...item,
          stock: Math.max(0, item.stock - cartItem.quantity)
        };
      }
      return item;
    });

    // Create Sale Transaction
    const now = new Date();
    const dateCode = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomHex = Math.floor(1000 + Math.random() * 9000);
    const receiptNumber = `TAL-${dateCode}-${randomHex}`;

    const saleItems: SaleItem[] = cart.map(c => ({
      productId: c.product.id,
      code: c.product.code,
      name: c.product.name,
      price: c.product.price,
      costPrice: c.product.costPrice || 0,
      quantity: c.quantity,
      subtotal: c.product.price * c.quantity
    }));

    const saleRecord: SaleTransaction = {
      id: `sale-${Date.now()}`,
      receiptNumber,
      timestamp: now.toISOString(),
      items: saleItems,
      subtotal,
      discount: discountAmount,
      tax: taxAmount,
      total: totalAmount,
      paymentMethod,
      amountPaid: paymentMethod === 'cash' ? numericCashTendered : totalAmount,
      change: paymentMethod === 'cash' ? changeAmount : 0,
      cashierNote: cashierNote.trim() || undefined,
      status: 'completed'
    };

    // Update parent state
    onInventoryUpdate(updatedInventory);
    onSaleComplete(saleRecord);

    // Audio & Confetti
    if (settings.enableSound) {
      soundEffects.playSuccessChime();
    }
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    // Reset Cart & Modal
    setCart([]);
    setShowCheckoutModal(false);
    setDiscountPercent(0);
    setCashierNote('');
  };

  // Filtered Catalog
  const filteredCatalog = inventory.filter(p => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(catalogSearch.toLowerCase()) ||
                          p.code.toLowerCase().includes(catalogSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-300">
      {/* Left Column: Scanner, Manual Entry & Catalog (7 Cols) */}
      <div className="lg:col-span-7 space-y-4">
        {/* Scanner Terminal Card */}
        <div className="glass-card rounded-3xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Camera className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100">Live Barcode & QR Scanner</h3>
                <p className="text-[10px] text-slate-400">Position barcode inside camera frame</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setAskQuantityOnScan(!askQuantityOnScan)}
                title="When scanned, ask how many units or if there are additional items"
                className={`text-xs px-2.5 py-1.5 rounded-xl border font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                  askQuantityOnScan
                    ? 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Ask Qty: {askQuantityOnScan ? 'ON' : 'OFF'}</span>
              </button>

              <button
                type="button"
                onClick={toggleFacingMode}
                className="text-xs text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 px-2.5 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Flip
              </button>
            </div>
          </div>

          {/* Camera Viewport */}
          <div className="relative bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 min-h-[220px] flex items-center justify-center">
            <div id="reader" className="w-full h-full"></div>
            
            {scannerActive && <div className="scan-laser-line" />}

            {!scannerActive && (
              <div className="text-center p-6 space-y-2 z-10">
                <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 text-slate-500 mx-auto flex items-center justify-center">
                  <CameraOff className="w-6 h-6" />
                </div>
                <p className="text-xs text-slate-400 font-medium">Scanner is currently paused</p>
                <p className="text-[11px] text-slate-500">Tap Start Camera below or scan using hardware/keyboard</p>
              </div>
            )}
          </div>

          {scannerError && (
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
              <span>{scannerError}</span>
            </div>
          )}

          {/* Scanner Controls */}
          <div className="flex gap-2">
            {!scannerActive ? (
              <button
                onClick={startScanner}
                className="flex-1 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md shadow-cyan-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                Start Camera Scanner
              </button>
            ) : (
              <button
                onClick={stopScanner}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <CameraOff className="w-4 h-4" />
                Stop Camera
              </button>
            )}
          </div>
        </div>

        {/* Hardware / Manual Input bar */}
        <div className="glass-card rounded-2xl p-3">
          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                value={manualCode}
                onChange={e => setManualCode(e.target.value)}
                placeholder="Scan or type barcode (e.g. 1001) & press Enter..."
                className="w-full bg-slate-900/90 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs transition cursor-pointer"
            >
              Add Code
            </button>
          </form>
        </div>

        {/* Quick Product Catalog Grid */}
        <div className="glass-card rounded-3xl p-4 sm:p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-sm text-slate-100">Quick Touch Catalog</h3>
            </div>
            
            {/* Search within catalog */}
            <input
              type="text"
              value={catalogSearch}
              onChange={e => setCatalogSearch(e.target.value)}
              placeholder="Search products..."
              className="bg-slate-900/80 border border-slate-800 rounded-xl px-3 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 max-w-xs"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto pr-1">
            {filteredCatalog.map(product => {
              const isOutOfStock = product.stock <= 0;
              return (
                <button
                  key={product.id}
                  onClick={() => triggerItemScannedNotice(product)}
                  disabled={isOutOfStock}
                  className={`text-left p-3 rounded-2xl border transition flex flex-col justify-between cursor-pointer group ${
                    isOutOfStock
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : 'bg-slate-900/80 border-slate-800 hover:border-cyan-500/40 hover:bg-slate-900'
                  }`}
                >
                  <div>
                    <span className="text-[10px] text-slate-500 font-mono block">
                      {product.code}
                    </span>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition line-clamp-2">
                      {product.name}
                    </span>
                  </div>

                  <div className="mt-2 flex items-center justify-between pt-1 border-t border-slate-800/60">
                    <span className="text-xs font-black text-cyan-400">
                      {settings.currency}{product.price.toFixed(2)}
                    </span>
                    <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                      product.stock <= 3 
                        ? 'bg-amber-500/20 text-amber-300' 
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {product.stock} left
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Column: Active Cart & Checkout (5 Cols) */}
      <div className="lg:col-span-5 space-y-4">
        <div className="glass-card rounded-3xl p-5 space-y-4 sticky top-20">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-base text-slate-100">Sale Cart</h3>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-bold border border-cyan-500/20">
                {totalItemsCount} items
              </span>
            </div>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>
            )}
          </div>

          {/* Cart Items List */}
          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {cart.length === 0 ? (
              <div className="text-center py-10 space-y-2 text-slate-500">
                <ShoppingBag className="w-10 h-10 mx-auto text-slate-600" />
                <p className="text-xs font-medium">Cart is currently empty</p>
                <p className="text-[11px] text-slate-600">Scan barcodes with camera or tap products on the left catalog</p>
              </div>
            ) : (
              cart.map(item => (
                <div
                  key={item.product.id}
                  className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-xs text-slate-100 block truncate">
                      {item.product.name}
                    </span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs font-bold text-cyan-400">
                        {settings.currency}{item.product.price.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {item.product.code}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => updateQuantity(item.product.id, -1)}
                      className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center font-bold text-xs transition cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs font-bold w-6 text-center text-slate-100">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.product.id, 1)}
                      className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center font-bold text-xs transition cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Totals Breakdown */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Subtotal:</span>
              <span className="font-mono text-slate-200">{settings.currency}{subtotal.toFixed(2)}</span>
            </div>

            {/* Discount selector */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Discount:</span>
              <div className="flex items-center gap-1">
                {[0, 5, 10, 15].map(pct => (
                  <button
                    key={pct}
                    onClick={() => setDiscountPercent(pct)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer transition ${
                      discountPercent === pct
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {settings.taxRate > 0 && (
              <div className="flex justify-between text-xs text-slate-400">
                <span>Tax ({settings.taxRate}%):</span>
                <span className="font-mono text-slate-200">{settings.currency}{taxAmount.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between items-baseline pt-2 border-t border-slate-800">
              <span className="text-sm font-bold text-slate-300">Total Due:</span>
              <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 font-mono">
                {settings.currency}{totalAmount.toFixed(2)}
              </span>
            </div>

            {/* Checkout Trigger */}
            <button
              onClick={handleOpenCheckout}
              disabled={cart.length === 0}
              className={`w-full py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider transition shadow-lg flex items-center justify-center gap-2 cursor-pointer ${
                cart.length === 0
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed shadow-none'
                  : 'bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/25'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              Pay {settings.currency}{totalAmount.toFixed(2)}
            </button>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl space-y-4 p-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-100">Complete Payment</h3>
                <p className="text-xs text-slate-400">Total Due: <span className="text-cyan-400 font-bold">{settings.currency}{totalAmount.toFixed(2)}</span></p>
              </div>
              <button
                onClick={() => setShowCheckoutModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400">Payment Method</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setPaymentMethod('cash')}
                  className={`p-3 rounded-2xl border text-center transition flex flex-col items-center gap-1.5 cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-slate-800/60 border-slate-800 text-slate-400'
                  }`}
                >
                  <Banknote className="w-5 h-5" />
                  <span className="text-xs font-bold">Cash</span>
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-2xl border text-center transition flex flex-col items-center gap-1.5 cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-slate-800/60 border-slate-800 text-slate-400'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  <span className="text-xs font-bold">Card</span>
                </button>
                <button
                  onClick={() => setPaymentMethod('ewallet')}
                  className={`p-3 rounded-2xl border text-center transition flex flex-col items-center gap-1.5 cursor-pointer ${
                    paymentMethod === 'ewallet'
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-slate-800/60 border-slate-800 text-slate-400'
                  }`}
                >
                  <Smartphone className="w-5 h-5" />
                  <span className="text-xs font-bold">E-Wallet</span>
                </button>
              </div>
            </div>

            {/* Cash Tendered & Quick Bills */}
            {paymentMethod === 'cash' && (
              <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Cash Tendered ({settings.currency})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={cashTendered}
                    onChange={e => setCashTendered(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-base font-bold text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Quick denomination buttons */}
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCashTendered(totalAmount.toFixed(2))}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-cyan-400 rounded-lg cursor-pointer"
                  >
                    Exact
                  </button>
                  {[50, 100, 200, 500, 1000].filter(b => b >= totalAmount || b === 50).map(bill => (
                    <button
                      key={bill}
                      type="button"
                      onClick={() => setCashTendered(bill.toString())}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-slate-300 rounded-lg cursor-pointer"
                    >
                      {settings.currency}{bill}
                    </button>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-sm">
                  <span className="text-slate-400 font-medium">Change Due:</span>
                  <span className={`font-mono font-bold text-base ${changeAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {settings.currency}{changeAmount.toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* Cashier Note */}
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Cashier Note / Customer Ref (Optional)</label>
              <input
                type="text"
                value={cashierNote}
                onChange={e => setCashierNote(e.target.value)}
                placeholder="e.g. Table 4 / Order #12"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Final Action Button */}
            <button
              onClick={handleFinishCheckout}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold rounded-2xl text-sm shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle className="w-5 h-5" />
              Complete Transaction & Print Receipt
            </button>
          </div>
        </div>
      )}

      {/* Scanned Item Notice & Quantity Modal */}
      {scannedPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl shadow-cyan-950/60 my-auto animate-in zoom-in-95 duration-200">
            {/* Notice header */}
            <div className="p-4 sm:p-5 bg-gradient-to-r from-cyan-950/80 via-slate-900 to-blue-950/80 border-b border-cyan-500/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="relative">
                    <span className="w-3 h-3 rounded-full bg-cyan-400 absolute inset-0 animate-ping opacity-75" />
                    <div className="w-9 h-9 rounded-2xl bg-cyan-500 text-slate-950 flex items-center justify-center font-bold relative z-10 shadow-lg shadow-cyan-500/30">
                      <CheckCircle2 className="w-5 h-5 text-slate-950" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-sm text-white">Item Scanned!</h3>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        Notice
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">Barcode: <span className="font-mono text-cyan-400">{scannedPrompt.product.code}</span></p>
                  </div>
                </div>
                <button
                  onClick={() => setScannedPrompt(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-5 space-y-4">
              {/* Product Info Card */}
              <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0 pr-2">
                    <h4 className="font-black text-base text-slate-100 truncate">{scannedPrompt.product.name}</h4>
                    <span className="text-[11px] font-semibold text-slate-400">
                      {scannedPrompt.product.category} • {scannedPrompt.product.unit}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-base font-black text-cyan-400">
                      {settings.currency}{scannedPrompt.product.price.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-500 block">per {scannedPrompt.product.unit}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                  <span className="text-slate-400">
                    Stock in Store: <strong className="text-slate-200">{scannedPrompt.product.stock} {scannedPrompt.product.unit}</strong>
                  </span>
                  <span className="text-emerald-400 font-semibold">
                    Available: {scannedPrompt.maxAvailable} units
                  </span>
                </div>

                {scannedPrompt.existingInCartQty > 0 && (
                  <div className="text-[11px] text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/20 flex items-center justify-between">
                    <span>Already in active cart:</span>
                    <span className="font-bold">{scannedPrompt.existingInCartQty} {scannedPrompt.product.unit}</span>
                  </div>
                )}
              </div>

              {/* Quantity question and controls */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-200">
                    How many units to add?
                  </label>
                  <span className="text-[11px] text-slate-400">
                    (Max available: {scannedPrompt.maxAvailable})
                  </span>
                </div>

                {/* Big numeric stepper */}
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setScannedPrompt({
                        ...scannedPrompt,
                        quantity: Math.max(1, scannedPrompt.quantity - 1)
                      });
                    }}
                    disabled={scannedPrompt.quantity <= 1}
                    className="w-12 h-12 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded-2xl flex items-center justify-center font-black text-lg transition cursor-pointer"
                  >
                    <Minus className="w-5 h-5" />
                  </button>

                  <div className="flex-1 relative">
                    <input
                      type="number"
                      min="1"
                      max={scannedPrompt.maxAvailable}
                      value={scannedPrompt.quantity}
                      onChange={e => {
                        const val = parseInt(e.target.value, 10);
                        if (isNaN(val) || val < 1) {
                          setScannedPrompt({ ...scannedPrompt, quantity: 1 });
                        } else {
                          setScannedPrompt({
                            ...scannedPrompt,
                            quantity: Math.min(scannedPrompt.maxAvailable, val)
                          });
                        }
                      }}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addProductToCartWithQty(scannedPrompt.product, scannedPrompt.quantity);
                          setScannedPrompt(null);
                        }
                      }}
                      autoFocus
                      className="w-full text-center py-2.5 bg-slate-950 border border-slate-700 rounded-2xl text-2xl font-black text-cyan-300 focus:outline-none focus:border-cyan-500 font-mono shadow-inner"
                    />
                    <span className="text-[10px] text-slate-500 uppercase font-semibold absolute right-3 top-3.5">
                      {scannedPrompt.product.unit}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setScannedPrompt({
                        ...scannedPrompt,
                        quantity: Math.min(scannedPrompt.maxAvailable, scannedPrompt.quantity + 1)
                      });
                    }}
                    disabled={scannedPrompt.quantity >= scannedPrompt.maxAvailable}
                    className="w-12 h-12 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded-2xl flex items-center justify-center font-black text-lg transition cursor-pointer"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>

                {/* Quick Preset Chips */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[1, 2, 3, 5, 10, 12].filter(q => q <= scannedPrompt.maxAvailable).map(q => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setScannedPrompt({ ...scannedPrompt, quantity: q })}
                      className={`px-3 py-1.5 text-xs rounded-xl font-bold transition cursor-pointer ${
                        scannedPrompt.quantity === q
                          ? 'bg-cyan-500 text-slate-950 shadow-md'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {q} {q === 12 ? '(Dozen)' : ''}
                    </button>
                  ))}
                  {scannedPrompt.maxAvailable > 1 && (
                    <button
                      type="button"
                      onClick={() => setScannedPrompt({ ...scannedPrompt, quantity: scannedPrompt.maxAvailable })}
                      className={`px-3 py-1.5 text-xs rounded-xl font-bold transition cursor-pointer ${
                        scannedPrompt.quantity === scannedPrompt.maxAvailable
                          ? 'bg-cyan-500 text-slate-950'
                          : 'bg-slate-800/80 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30'
                      }`}
                    >
                      All ({scannedPrompt.maxAvailable})
                    </button>
                  )}
                </div>

                {/* Subtotal Banner */}
                <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl flex items-center justify-between text-xs">
                  <span className="text-slate-300">
                    Subtotal for {scannedPrompt.quantity} {scannedPrompt.product.unit}:
                  </span>
                  <span className="text-base font-black text-cyan-300 font-mono">
                    {settings.currency}{(scannedPrompt.quantity * scannedPrompt.product.price).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Action Buttons: Add & Scan Next, Add & Checkout, Cancel */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      addProductToCartWithQty(scannedPrompt.product, scannedPrompt.quantity);
                      setScannedPrompt(null);
                    }}
                    className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black rounded-2xl text-xs sm:text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 cursor-pointer transition"
                  >
                    <Plus className="w-4 h-4" />
                    Add & Scan Next Item
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      addProductToCartWithQty(scannedPrompt.product, scannedPrompt.quantity);
                      setScannedPrompt(null);
                      setTimeout(() => handleOpenCheckout(), 120);
                    }}
                    className="px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black rounded-2xl text-xs sm:text-sm shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5 cursor-pointer transition"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Checkout
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setScannedPrompt(null)}
                  className="w-full py-2 bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-semibold rounded-xl cursor-pointer transition"
                >
                  Cancel / Ignore Scan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Scanned Toast notification */}
      {scannedToast && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border border-cyan-500/40 text-cyan-200 px-4 py-2.5 rounded-2xl shadow-xl shadow-cyan-950/60 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>{scannedToast}</span>
        </div>
      )}
    </div>
  );
};
