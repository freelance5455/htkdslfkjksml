import React, { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import {
  BookPlus,
  CheckCircle,
  CreditCard,
  Megaphone,
  ShieldAlert,
  Smartphone,
  Users,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { COMMON_SUBJECT_NAMES, TEVETA_COLLEGES } from '../lib/tevetaCatalog';
import type {
  LibrarySection,
  PaymentRecord,
  ReportItem,
  UserProfile,
} from '../types';

interface AdminDashboardModalProps {
  open: boolean;
  onClose: () => void;
  adminProfile: UserProfile;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  open,
  onClose,
  adminProfile,
}) => {
  const [tab, setTab] = useState<'stats' | 'library' | 'courses' | 'users' | 'payments' | 'reports' | 'release'>('stats');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [statusNote, setStatusNote] = useState<string | null>(null);

  // New library material form
  const [matTitle, setMatTitle] = useState('');
  const [matSection, setMatSection] = useState<LibrarySection>('common');
  const [matSubject, setMatSubject] = useState<string>(COMMON_SUBJECT_NAMES[0]);
  const [matCourse, setMatCourse] = useState('All Technical Programmes');
  const [matCollege, setMatCollege] = useState('All TEVETA Colleges');
  const [matLevel, setMatLevel] = useState('Level 1 - 2');
  const [matYear, setMatYear] = useState('2026');
  const [matDocType, setMatDocType] = useState<'notes' | 'pdf' | 'manual' | 'diagram' | 'worksheet' | 'past_paper'>('notes');
  const [matSummary, setMatSummary] = useState('');
  const [matContent, setMatContent] = useState('');
  const [matFileUrl, setMatFileUrl] = useState('');

  // New course form
  const [courseName, setCourseName] = useState('');
  const [courseTrade, setCourseTrade] = useState('');
  const [courseCollege, setCourseCollege] = useState(TEVETA_COLLEGES[0]);
  const [courseDept, setCourseDept] = useState('');
  const [courseQual, setCourseQual] = useState('TEVETA National Certificate');
  const [courseLevel, setCourseLevel] = useState('Level 1 - 3');
  const [courseDesc, setCourseDesc] = useState('');

  // Announcement
  const [announceTitle, setAnnounceTitle] = useState('');
  const [announceBody, setAnnounceBody] = useState('');
  const [announceCollege, setAnnounceCollege] = useState('All TEVETA Colleges');

  useEffect(() => {
    if (!open) return;
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => setUsers(snap.docs.map((d) => d.data() as UserProfile)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );
    const unsubPayments = onSnapshot(
      collection(db, 'payments'),
      (snap) => setPayments(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PaymentRecord, 'id'>) }))),
      (err) => handleFirestoreError(err, OperationType.LIST, 'payments')
    );
    const unsubReports = onSnapshot(
      collection(db, 'reports'),
      (snap) => setReports(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ReportItem, 'id'>) }))),
      (err) => handleFirestoreError(err, OperationType.LIST, 'reports')
    );
    return () => {
      unsubUsers();
      unsubPayments();
      unsubReports();
    };
  }, [open]);

  if (!open) return null;

  const handleUploadMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'libraryMaterials'), {
        title: matTitle.trim(),
        section: matSection,
        subject: matSubject.trim(),
        courseName: matCourse.trim(),
        college: matCollege,
        level: matLevel,
        year: matYear,
        docType: matDocType,
        summary: matSummary.trim(),
        contentMarkdown: matContent.trim(),
        fileUrl: matFileUrl.trim(),
        isAuthorized: true,
        uploadedBy: adminProfile.uid,
        createdAt: serverTimestamp(),
      });
      setStatusNote(`Published "${matTitle}" to the TEVETA Library.`);
      setMatTitle('');
      setMatSummary('');
      setMatContent('');
      setMatFileUrl('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'libraryMaterials');
    }
  };

  const handleAddCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'libraryCourses'), {
        name: courseName.trim(),
        trade: courseTrade.trim(),
        college: courseCollege,
        department: courseDept.trim(),
        qualification: courseQual.trim(),
        level: courseLevel.trim(),
        description: courseDesc.trim(),
        createdBy: adminProfile.uid,
        createdAt: serverTimestamp(),
      });
      setStatusNote(`Added course "${courseName}" to TEVETA directory.`);
      setCourseName('');
      setCourseTrade('');
      setCourseDept('');
      setCourseDesc('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'libraryCourses');
    }
  };

  const handleSendAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const targetTag =
        announceCollege === 'All TEVETA Colleges'
          ? 'Official Notice · All TEVETA Colleges'
          : `Official Notice · ${announceCollege}`;
      await addDoc(collection(db, 'posts'), {
        authorId: adminProfile.uid,
        authorName: adminProfile.fullName,
        authorUsername: adminProfile.username,
        authorPhoto: adminProfile.photoUrl || '',
        authorCourse: targetTag,
        content: `${announceTitle.trim()}\n\n${announceBody.trim()}`,
        mediaUrl: '',
        mediaType: 'none',
        category: 'announcement',
        courseTag: targetTag,
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      const recipients = users.filter(
        (u) =>
          u.uid !== adminProfile.uid &&
          (announceCollege === 'All TEVETA Colleges' || u.college === announceCollege)
      );
      await Promise.all(
        recipients.map((u) =>
          addDoc(collection(db, 'notifications'), {
            recipientUid: u.uid,
            actorUid: adminProfile.uid,
            type: 'announcement',
            title: announceTitle.trim(),
            body: `[${announceCollege}] ${announceBody.trim().slice(0, 320)}`,
            read: false,
            createdAt: serverTimestamp(),
          })
        )
      );
      setStatusNote(`Broadcast notice sent to ${recipients.length} student(s) (${announceCollege}).`);
      setAnnounceTitle('');
      setAnnounceBody('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'posts');
    }
  };

  const handlePromoteAdmin = async (u: UserProfile) => {
    try {
      await setDoc(doc(db, 'admins', u.uid), {
        uid: u.uid,
        fullName: u.fullName,
        username: u.username,
        role: 'admin',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'users', u.uid), {
        role: 'admin',
        updatedAt: serverTimestamp(),
      });
      setStatusNote(`Granted administrator role to ${u.fullName}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `admins/${u.uid}`);
    }
  };

  const handleConfirmPaymentAndActivate = async (p: PaymentRecord) => {
    try {
      await updateDoc(doc(db, 'payments', p.id), {
        status: 'confirmed',
        gatewayMessage: 'Verified and activated by administrator',
      });
      await updateDoc(doc(db, 'users', p.uid, 'private', 'info'), {
        subscriptionStatus: 'active',
        subscriptionExpiresAt: Timestamp.fromMillis(Date.now() + 30 * 24 * 60 * 60 * 1000),
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'notifications'), {
        recipientUid: p.uid,
        actorUid: adminProfile.uid,
        type: 'membership',
        title: 'Monthly Membership Active',
        body: `Your MWK ${p.amountMwk} subscription (${p.reference}) is now active for 30 days.`,
        read: false,
        createdAt: serverTimestamp(),
      });
      setStatusNote(`Confirmed payment ${p.reference} and activated 30-day membership.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `payments/${p.id}`);
    }
  };

  const handleResolveReport = async (rep: ReportItem) => {
    try {
      await updateDoc(doc(db, 'reports', rep.id), {
        status: 'resolved',
      });
      if (rep.targetType === 'post') {
        await deleteDoc(doc(db, 'posts', rep.targetId));
      }
      setStatusNote(`Resolved report ${rep.id}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reports/${rep.id}`);
    }
  };

  const confirmedRevenue = payments
    .filter((p) => p.status === 'confirmed')
    .reduce((sum, p) => sum + (p.amountMwk || 0), 0);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div>
            <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              Administrator Control Center
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Restricted to authorized owner ({adminProfile.fullName})
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 pt-3 border-b border-slate-200 dark:border-slate-800 flex gap-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'stats', label: 'Overview & Alerts' },
            { id: 'library', label: 'Upload Material' },
            { id: 'courses', label: 'Manage Courses' },
            { id: 'users', label: `Users (${users.length})` },
            { id: 'payments', label: `Payments (${payments.length})` },
            { id: 'reports', label: `Reports (${reports.length})` },
            { id: 'release', label: 'Android APK / Play Store' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl whitespace-nowrap border-b-2 transition-colors cursor-pointer ${
                tab === item.id
                  ? 'border-blue-700 text-blue-700 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {statusNote && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
              <span>{statusNote}</span>
              <button type="button" onClick={() => setStatusNote(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {tab === 'stats' && (
            <div className="space-y-6">
              <div className="grid sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <p className="text-xs text-slate-500 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-blue-600" /> Registered Users
                  </p>
                  <p className="font-display text-2xl font-bold mt-1 tabular-nums">{users.length}</p>
                </div>
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <p className="text-xs text-slate-500 flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-600" /> Verified Revenue
                  </p>
                  <p className="font-display text-2xl font-bold mt-1 tabular-nums">
                    MWK {confirmedRevenue.toLocaleString()}
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <p className="text-xs text-slate-500 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-amber-600" /> Open Reports
                  </p>
                  <p className="font-display text-2xl font-bold mt-1 tabular-nums">
                    {reports.filter((r) => r.status === 'open').length}
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <p className="text-xs text-slate-500 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-blue-600" /> Price Setting
                  </p>
                  <p className="font-display text-2xl font-bold mt-1 tabular-nums">MWK 1,000</p>
                </div>
              </div>

              <form onSubmit={handleSendAnnouncement} className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="font-display font-bold text-sm flex items-center gap-2">
                  <Megaphone className="w-4 h-4 text-blue-600" />
                  <span>Send Student Notice / Platform Announcement</span>
                </h3>
                <select
                  value={announceCollege}
                  onChange={(e) => setAnnounceCollege(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="All TEVETA Colleges">All TEVETA Colleges (National Broadcast)</option>
                  {TEVETA_COLLEGES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={announceTitle}
                  onChange={(e) => setAnnounceTitle(e.target.value)}
                  placeholder="Announcement headline..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                />
                <textarea
                  rows={3}
                  required
                  value={announceBody}
                  onChange={(e) => setAnnounceBody(e.target.value)}
                  placeholder="Write official notice for students across TEVETA colleges..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                />
                <button
                  type="submit"
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Publish Announcement
                </button>
              </form>
            </div>
          )}

          {tab === 'library' && (
            <form onSubmit={handleUploadMaterial} className="space-y-3 max-w-2xl">
              <h3 className="font-display font-bold text-base flex items-center gap-2">
                <BookPlus className="w-5 h-5 text-blue-600" />
                <span>Upload Authorized TEVETA Educational Material</span>
              </h3>
              <input
                type="text"
                required
                value={matTitle}
                onChange={(e) => setMatTitle(e.target.value)}
                placeholder="Document title (e.g. Solar Inverter Sizing Manual)"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <div className="grid sm:grid-cols-3 gap-3">
                <select
                  value={matSection}
                  onChange={(e) => setMatSection(e.target.value as LibrarySection)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="common">Common Subject</option>
                  <option value="course">Course-Specific</option>
                  <option value="practical">Practical Training</option>
                  <option value="fundamentals">Fundamentals</option>
                  <option value="past_paper">Exam Prep / Past Paper</option>
                </select>
                <input
                  type="text"
                  required
                  value={matSubject}
                  onChange={(e) => setMatSubject(e.target.value)}
                  placeholder="Subject name"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
                <select
                  value={matDocType}
                  onChange={(e) => setMatDocType(e.target.value as typeof matDocType)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="notes">Learning Notes</option>
                  <option value="pdf">PDF Document</option>
                  <option value="manual">Practical Manual</option>
                  <option value="diagram">Technical Diagram</option>
                  <option value="worksheet">Worksheet</option>
                  <option value="past_paper">Past Paper</option>
                </select>
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  value={matCourse}
                  onChange={(e) => setMatCourse(e.target.value)}
                  placeholder="Programme / Course"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
                <select
                  value={matCollege}
                  onChange={(e) => setMatCollege(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="All TEVETA Colleges">All TEVETA Colleges</option>
                  {TEVETA_COLLEGES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <input
                  type="text"
                  value={matLevel}
                  onChange={(e) => setMatLevel(e.target.value)}
                  placeholder="Level (e.g. Level 2)"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
              </div>
              <input
                type="url"
                value={matFileUrl}
                onChange={(e) => setMatFileUrl(e.target.value)}
                placeholder="Authorized PDF / Video URL (optional)"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              />
              <input
                type="text"
                required
                value={matSummary}
                onChange={(e) => setMatSummary(e.target.value)}
                placeholder="Short summary for library cards..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <textarea
                rows={6}
                required
                value={matContent}
                onChange={(e) => setMatContent(e.target.value)}
                placeholder="Full learning notes, worked calculations, safety precautions, and exercises..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                className="min-h-[44px] px-5 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold"
              >
                Publish to TEVETA Library
              </button>
            </form>
          )}

          {tab === 'courses' && (
            <form onSubmit={handleAddCourse} className="space-y-3 max-w-xl">
              <h3 className="font-display font-bold text-base">Add Verified TEVETA Programme</h3>
              <input
                type="text"
                required
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                placeholder="Qualification / Course Name"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={courseTrade}
                  onChange={(e) => setCourseTrade(e.target.value)}
                  placeholder="Trade / Occupation"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  required
                  value={courseDept}
                  onChange={(e) => setCourseDept(e.target.value)}
                  placeholder="Department"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                <select
                  value={courseCollege}
                  onChange={(e) => setCourseCollege(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  {TEVETA_COLLEGES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={courseQual}
                  onChange={(e) => setCourseQual(e.target.value)}
                  placeholder="Qualification"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  required
                  value={courseLevel}
                  onChange={(e) => setCourseLevel(e.target.value)}
                  placeholder="Level"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                />
              </div>
              <textarea
                rows={3}
                value={courseDesc}
                onChange={(e) => setCourseDesc(e.target.value)}
                placeholder="Course scope & core modules..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
              >
                Save Course to Directory
              </button>
            </form>
          )}

          {tab === 'users' && (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {users.map((u) => (
                <div key={u.uid} className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <p className="font-semibold text-sm text-slate-900 dark:text-white">
                      {u.fullName} (@{u.username})
                    </p>
                    <p className="text-slate-500">
                      {u.role} · {u.college || 'Malawi'} · {u.course || 'General'}
                    </p>
                  </div>
                  {u.role !== 'admin' && (
                    <button
                      type="button"
                      onClick={() => handlePromoteAdmin(u)}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      Make Moderator/Admin
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {tab === 'payments' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500">
                Only verify and activate payments backed by confirmed Airtel Money / TNM Mpamba merchant settlement references.
              </p>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {payments.map((p) => (
                  <div key={p.id} className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div>
                      <p className="font-semibold text-sm">
                        {p.reference} · MWK {p.amountMwk} ({p.provider.replace('_', ' ')})
                      </p>
                      <p className="text-slate-500">
                        User: {p.uid} · Status: {p.status} · {p.gatewayMessage}
                      </p>
                    </div>
                    {p.status === 'pending' && (
                      <button
                        type="button"
                        onClick={() => handleConfirmPaymentAndActivate(p)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold"
                      >
                        Verify & Activate 30d
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'reports' && (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {reports.length === 0 ? (
                <p className="text-xs text-slate-500">No reports filed.</p>
              ) : (
                reports.map((rep) => (
                  <div key={rep.id} className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div>
                      <p className="font-semibold text-sm">
                        {rep.targetType.toUpperCase()} ({rep.targetId}) — {rep.status}
                      </p>
                      <p className="text-slate-500">{rep.reason}</p>
                    </div>
                    {rep.status === 'open' && (
                      <button
                        type="button"
                        onClick={() => handleResolveReport(rep)}
                        className="px-3 py-1.5 rounded-lg bg-red-600 text-white font-semibold"
                      >
                        Resolve & Remove Content
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'release' && (
            <div className="space-y-4 text-xs leading-relaxed text-slate-700 dark:text-slate-300">
              <div className="flex items-center gap-2 text-sm font-display font-bold text-slate-900 dark:text-white">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <span>Android PWA, Signed APK & Google Play AAB Delivery Guide</span>
              </div>
              <p>
                This live full-stack application runs as an installable Android Progressive Web App (PWA) with offline note caching, WebRTC calls, Firebase Auth/Firestore, and server-side Gemini AI.
              </p>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                <p className="font-semibold text-slate-900 dark:text-white">
                  1. Generating Signed APK & Play Store AAB from this Production Build
                </p>
                <p>
                  Because this cloud runtime executes Node.js/Vite rather than local Android Gradle SDK, package the production web bundle using Capacitor or Trusted Web Activity (Bubblewrap) on your workstation:
                </p>
                <pre className="p-3 rounded-lg bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto">
{`npm run build
npx @capacitor/cli init "TEVET POWER APP" "mw.tevetpower.app" --web-dir=dist
npx cap add android && npx cap sync android
cd android && ./gradlew assembleRelease   # Signed APK
cd android && ./gradlew bundleRelease     # Play Store AAB`}
                </pre>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5">
                <p className="font-semibold text-slate-900 dark:text-white">
                  2. Configuring Live Malawi Mobile Money Merchant APIs
                </p>
                <p>
                  Set <code>AIRTEL_MONEY_CLIENT_ID</code>, <code>AIRTEL_MONEY_CLIENT_SECRET</code>, <code>TNM_MPAMBA_API_KEY</code>, <code>TNM_MPAMBA_MERCHANT_CODE</code>, and <code>PAYMENT_WEBHOOK_SECRET</code> in your server environment secrets. Admin payment numbers stay private on the server and are never exposed in client code.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
