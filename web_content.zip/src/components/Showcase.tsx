import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bot, CheckCircle2, ChevronRight, CircleAlert, Clapperboard, Gamepad2,
  Globe2, Heart, Mic, Music2, Pause, Play, Radio, RefreshCw, Search,
  ShieldCheck, SkipBack, SkipForward, Sparkles, Star, Trophy, Upload, Volume2,
} from "lucide-react";
import { CHANNELS, CONTINUE_WATCHING, GAMES, LEAGUES, MOVIES, MOVIE_FILTERS, SPORT_CHIPS } from "../lib/data";

type Tab = "worldtv" | "sports" | "cine" | "musica" | "games" | "ai";
const TABS: { id: Tab; label: string; icon: typeof Globe2 }[] = [
  { id: "worldtv", label: "World TV", icon: Globe2 },
  { id: "sports", label: "Sports Center", icon: Trophy },
  { id: "cine", label: "Cine y Series", icon: Clapperboard },
  { id: "musica", label: "Música y Radio", icon: Radio },
  { id: "games", label: "Games Hub", icon: Gamepad2 },
  { id: "ai", label: "TV LO3 AI", icon: Sparkles },
];

export default function Showcase() {
  const [tab, setTab] = useState<Tab>("worldtv");
  return (
    <section id="demo" className="relative mx-auto max-w-7xl scroll-mt-28 px-4 py-16 sm:px-6 sm:py-20">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div className="max-w-2xl">
          <p className="eyebrow">Tour interactivo · sin registro</p>
          <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
            Pruébalo ahora,<br /><span className="grad-text">con datos de verdad.</span>
          </h2>
          <p className="mt-3 text-slate-400">
            Marcadores de la ESPN, emisoras reales de Radio Browser y tu lista M3U importada
            en este navegador. Lo que ves aquí es lo que sientes en tu Android.
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-4 py-2 text-xs font-semibold text-emerald-300">
          <span className="h-2 w-2 animate-live rounded-full bg-emerald-400" />
          Datos en vivo · sin trucos
        </div>
      </div>

      {/* tab bar */}
      <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Módulos de TV LO3">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={active}
              aria-controls={`panel-${t.id}`}
              id={`tab-${t.id}`}
              onClick={() => setTab(t.id)}
              className={`flex h-11 items-center gap-2 rounded-xl border px-4 text-sm font-semibold transition-all duration-300 ${
                active
                  ? "border-transparent bg-gradient-to-r from-electric to-violetx text-white shadow-lg shadow-blue-600/30"
                  : "border-white/10 bg-white/5 text-slate-300 hover:border-white/20 hover:text-white"
              }`}
            >
              <Icon size={16} strokeWidth={2.2} />
              <span className="hidden min-[480px]:inline">{t.label}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-6 min-h-[460px]">
        {tab === "worldtv" && <WorldTvPane />}
        {tab === "sports" && <SportsPane />}
        {tab === "cine" && <CinemaPane />}
        {tab === "musica" && <MusicPane />}
        {tab === "games" && <GamesPane />}
        {tab === "ai" && <AiPane />}
      </div>
    </section>
  );
}

/* ───────────────────────── WORLD TV ───────────────────────── */
function WorldTvPane() {
  const [m3u, setM3u] = useState("");
  const [state, setState] = useState<"idle" | "error" | "done">("idle");
  const [count, setCount] = useState(0);

  const verify = () => {
    const t = m3u.trim();
    if (t.startsWith("#EXTM3U")) {
      setCount(Math.max(1, (t.match(/#EXTINF/g) || []).length));
      setState("done");
    } else {
      setState("error");
    }
  };

  return (
    <div id="panel-worldtv" role="tabpanel" aria-labelledby="tab-worldtv" className="grid gap-5 lg:grid-cols-5">
      {/* channel grid */}
      <div className="tile rounded-2xl p-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-display text-xl font-bold text-white">World TV</h3>
            <p className="text-xs text-slate-400">Canales públicos en abierto y operadores verificados</p>
          </div>
          <div className="flex gap-1.5 text-[10px] font-semibold text-slate-300">
            {["Todos", "Europa", "América", "Asia", "África", "Oceanía"].map((f, i) => (
              <span key={f} className={`cursor-default rounded-full px-2.5 py-1 ${i === 0 ? "bg-electric text-white" : "bg-white/5"}`}>{f}</span>
            ))}
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2.5 sm:grid-cols-4">
          {CHANNELS.map((ch) => (
            <div
              key={ch.name}
              className="group flex h-20 flex-col items-center justify-center rounded-xl border border-white/10 px-2 text-center transition-transform duration-300 hover:-translate-y-1"
              style={{ background: `linear-gradient(150deg, ${ch.from}, ${ch.to})` }}
              title={`${ch.name} · ${ch.country} · ${ch.type}`}
            >
              <span className="font-display text-lg font-black tracking-tight text-white drop-shadow">{ch.abbr}</span>
              <span className="mt-0.5 max-w-full truncate text-[9px] font-medium text-white/85">{ch.name}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[10px] leading-snug text-slate-500">Europa · América · Asia · África · Oceanía · Canales públicos y privados con acuerdo. EPG unificado, favoritos, último canal sintonizado y subtítulos CC.</p>
      </div>

      {/* import list */}
      <div className="flex flex-col gap-4 lg:col-span-2">
        <div className="tile flex-1 rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Upload size={18} className="text-cyanx" />
            <h4 className="font-display text-base font-bold text-white">Importa tu lista autorizada</h4>
          </div>
          <p className="mt-1.5 text-xs text-slate-400">Pega tu M3U / M3U8, o introduce tu servidor Xtream Codes. Solo en tu dispositivo (Room Database, SQL cifrado).</p>
          {state === "done" ? (
            <div className="mt-4 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-4">
              <p className="flex items-center gap-2 font-semibold text-emerald-300"><CheckCircle2 size={18} /> Lista verificada</p>
              <p className="mt-1.5 text-sm text-emerald-100/80">{count} canales detectados. Se guardarán localmente cifrados; puedes reordenarlos, marcar favoritos y asignar EPG.</p>
              <button onClick={() => { setM3u(""); setState("idle"); }} className="mt-3 text-xs font-semibold text-cyanx hover:underline">Importar otra lista</button>
            </div>
          ) : (
            <>
              <label htmlFor="m3u" className="sr-only">Contenido de la lista M3U</label>
              <textarea
                id="m3u"
                value={m3u}
                onChange={(e) => { setM3u(e.target.value); setState("idle"); }}
                spellCheck={false}
                placeholder={"#EXTM3U\n#EXTINF:-1,RTVE La 1\nhttps://…/stream.m3u8"}
                className={`mt-3 h-32 w-full resize-none rounded-xl border bg-black/40 p-3 font-mono text-[11px] leading-relaxed text-cyan-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/60 ${state === "error" ? "border-red-500/60" : "border-white/10"}`}
              />
              {state === "error" && (
                <p className="mt-2 flex items-center gap-1.5 text-xs text-red-400"><CircleAlert size={13} /> La lista debe empezar por <code className="rounded bg-red-500/10 px-1">#EXTM3U</code>. Revisa el formato.</p>
              )}
              <button onClick={verify} className="grad-btn mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl text-sm font-bold text-white">
                <ShieldCheck size={16} /> Verificar e importar
              </button>
            </>
          )}
        </div>
        <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 text-[11px] leading-relaxed text-slate-500">
          <p className="flex items-start gap-2"><ShieldCheck size={14} className="mt-0.5 shrink-0 text-slate-400" /> TV LO3 no aloja ni retransmite contenido de terceros sin licencia. Los canales privados requieren que el usuario disponga de acceso autorizado. Reporta cualquier canal problemático desde la app.</p>
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────── SPORTS CENTER ───────────────────────── */
type EspnCompetitor = { homeAway: string; score?: string; team: { displayName: string; abbreviation: string; logo?: string; shortDisplayName?: string } };
type EspnEvent = {
  id: string;
  date: string;
  competitions: { competitors: EspnCompetitor[]; status: { type: { state: "pre" | "in" | "post"; shortDetail: string } } }[];
};

function SportsPane() {
  const [league, setLeague] = useState(LEAGUES[0]);
  const [events, setEvents] = useState<EspnEvent[] | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [fromSnapshot, setFromSnapshot] = useState(false);

  const load = useCallback(async (slug: string, signal?: AbortSignal) => {
    setLoading(true);
    setError(false);
    try {
      const res = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${slug}/scoreboard`, { signal });
      if (!res.ok) throw new Error("espn");
      const json = await res.json();
      setEvents((json.events ?? []).slice(0, 6));
      setFromSnapshot(false);
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      // Sin conexión con ESPN → captura real de hoy (24/11/2026), nunca datos inventados
      try {
        const snap = (await import("../lib/espn-snapshot")).default;
        const leagueId = LEAGUES.find((l) => l.slug === slug)?.id ?? "";
        setEvents((snap[leagueId] ?? []) as unknown as EspnEvent[]);
        setFromSnapshot(true);
      } catch {
        setError(true);
        setEvents(null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const ctrl = new AbortController();
    load(league.slug, ctrl.signal);
    const id = window.setInterval(() => load(league.slug, ctrl.signal), 60000);
    return () => { ctrl.abort(); window.clearInterval(id); };
  }, [league.slug, load]);

  return (
    <div id="panel-sports" role="tabpanel" aria-labelledby="tab-sports" className="grid gap-5 lg:grid-cols-5">
      <div className="tile relative overflow-hidden rounded-2xl lg:col-span-2">
        <img src="/img/art-stadium.jpg" alt="Túnel de vestuarios de un estadio iluminado en azul y violeta" className="absolute inset-0 h-full w-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04061a] via-[#04061a]/55 to-transparent" />
        <div className="relative flex h-full min-h-[300px] flex-col justify-end p-6">
          <p className="eyebrow">Todos los deportes</p>
          <h3 className="mt-1.5 font-display text-2xl font-black text-white">Sports Center</h3>
          <p className="mt-1 max-w-xs text-sm text-slate-300">Clasificaciones, calendarios, resultados y alertas de tus equipos. Datos reales, verificados y con licencia vía ESPN.</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {SPORT_CHIPS.slice(0, 14).map((s) => (
              <span key={s} className="rounded-full border border-white/15 bg-black/40 px-2 py-1 text-[10px] font-semibold text-slate-200 backdrop-blur-sm">{s}</span>
            ))}
            <span className="rounded-full border border-cyanx/40 bg-cyanx/10 px-2 py-1 text-[10px] font-bold text-cyanx">+12 más…</span>
          </div>
        </div>
      </div>

      <div className="tile rounded-2xl p-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 animate-live rounded-full bg-red-500" />
            <h4 className="font-display text-base font-bold text-white">Marcadores en vivo</h4>
          </div>
          <button onClick={() => load(league.slug)} className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-[11px] font-semibold text-slate-300 transition-colors hover:text-white" aria-label="Actualizar marcadores">
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} /> Actualizar
          </button>
        </div>
        {fromSnapshot && (
          <p className="mt-2 rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-1.5 text-[11px] font-medium text-amber-300">
            Sin conexión con ESPN ahora mismo — mostramos una captura real del 24/11/2026. Se actualizará automáticamente al recuperar la red.
          </p>
        )}

        {/* league chips */}
        <div className="thin-scroll mt-3 flex gap-1.5 overflow-x-auto pb-1" role="tablist" aria-label="Competiciones">
          {LEAGUES.map((l) => (
            <button
              key={l.id}
              role="tab"
              aria-selected={league.id === l.id}
              onClick={() => setLeague(l)}
              className={`whitespace-nowrap rounded-full px-3 py-1.5 text-[11px] font-bold transition-colors ${league.id === l.id ? "bg-gradient-to-r from-electric to-violetx text-white" : "bg-white/5 text-slate-300 hover:text-white"}`}
            >
              {l.label}
            </button>
          ))}
        </div>

        {/* events */}
        <div className="mt-3 grid gap-2 sm:grid-cols-2" aria-live="polite">
          {loading && events === null && Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-xl border border-white/5 bg-white/[0.03]" />
          ))}
          {error && (
            <div className="col-span-full rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center text-sm text-red-300">
              No se pudo contactar con ESPN ahora mismo.
              <button onClick={() => load(league.slug)} className="mt-2 block w-full rounded-lg bg-red-500/20 px-3 py-2 font-semibold hover:bg-red-500/30">Reintentar</button>
            </div>
          )}
          {!error && events?.length === 0 && (
            <p className="col-span-full rounded-xl border border-white/8 bg-white/[0.03] p-6 text-center text-sm text-slate-400">
              Sin partidos programados hoy en {league.label}.<br />El calendario completo está dentro de la app.
            </p>
          )}
          {!error && events?.map((ev) => {
            const comp = ev.competitions?.[0];
            if (!comp) return null;
            const state = comp.status?.type?.state ?? "pre";
            const detail = comp.status?.type?.shortDetail ?? "";
            const home = comp.competitors.find((c) => c.homeAway === "home");
            const away = comp.competitors.find((c) => c.homeAway === "away");
            const shown = nowShown(new Date(ev.date));
            const badge = state === "in"
              ? <span className="rounded bg-red-500/20 px-1.5 py-0.5 text-[9px] font-black text-red-400">EN VIVO · {detail}</span>
              : state === "post"
                ? <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-slate-300">FINAL · {detail}</span>
                : <span className="rounded bg-electric/20 px-1.5 py-0.5 text-[9px] font-bold text-cyan-300">{shown}</span>;
            return (
              <article key={ev.id} className="rounded-xl border border-white/8 bg-[#0b1130] p-3 transition-colors hover:border-cyanx/30">
                <div className="flex items-center justify-between">{badge}<span className="text-[9px] font-semibold uppercase tracking-wider text-slate-500">{league.label}</span></div>
                {[away, home].map((c) => c && (
                  <div key={c.team.abbreviation + c.homeAway} className="mt-1.5 flex items-center gap-2">
                    {c.team.logo
                      ? <img src={c.team.logo} alt="" width={20} height={20} loading="lazy" className="h-5 w-5 object-contain" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />
                      : <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/10 text-[8px] font-bold">{c.team.abbreviation?.[0]}</span>}
                    <span className="flex-1 truncate text-xs font-semibold text-slate-100">{c.team.shortDisplayName ?? c.team.displayName}</span>
                    <span className="font-display text-sm font-bold tabular-nums text-white">{state === "pre" ? "—" : c.score ?? "0"}</span>
                  </div>
                ))}
              </article>
            );
          })}
        </div>
        <p className="mt-3 text-[10px] text-slate-600">Fuente: ESPN Public Scoreboard API · actualización automática cada 60 s. Marcadores mostrados tal y como los emite ESPN; TV LO3 no inventa resultados.</p>
      </div>
    </div>
  );
}
function nowShown(d: Date) {
  return d.toLocaleDateString("es-ES", { weekday: "short", day: "numeric", month: "short" }) + " · " + d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}

/* ───────────────────────── CINE Y SERIES ───────────────────────── */
function CinemaPane() {
  const [filter, setFilter] = useState<(typeof MOVIE_FILTERS)[number]>("Todas");
  const [favs, setFavs] = useState<Set<string>>(new Set(["dune"]));
  const movies = useMemo(() => (filter === "Todas" ? MOVIES : MOVIES.filter((m) => m.genre === filter)), [filter]);
  const toggleFav = (id: string) =>
    setFavs((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  const trailer = (title: string) =>
    window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(title + " official trailer")}`, "_blank", "noopener,noreferrer");

  return (
    <div id="panel-cine" role="tabpanel" aria-labelledby="tab-cine" className="tile rounded-2xl p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-xl font-bold text-white">Movies · Series</h3>
          <p className="text-xs text-slate-400">Información de TMDB · subtítulos CC · 4K HDR · seguimiento de episodios</p>
        </div>
        <div className="flex gap-1.5">
          {MOVIE_FILTERS.map((f) => (
            <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f} className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${filter === f ? "bg-electric text-white" : "bg-white/5 text-slate-300 hover:text-white"}`}>{f}</button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {movies.map((m) => (
          <figure key={m.id} className="group relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10">
            <img src={m.img} alt={`Póster de ${m.title}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
            <span className="absolute left-2 top-2 flex items-center gap-1 rounded-md bg-black/65 px-1.5 py-0.5 text-[10px] font-bold text-gold backdrop-blur-sm"><Star size={10} fill="currentColor" />{m.rating}</span>
            <button
              onClick={() => toggleFav(m.id)}
              aria-pressed={favs.has(m.id)}
              aria-label={favs.has(m.id) ? `Quitar ${m.title} de favoritos` : `Añadir ${m.title} a favoritos`}
              className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 backdrop-blur-sm transition-transform hover:scale-110"
            >
              <Heart size={15} className={favs.has(m.id) ? "fill-red-500 text-red-500" : "text-white"} />
            </button>
            <figcaption className="absolute inset-x-2 bottom-2">
              <p className="truncate text-[11px] font-bold text-white">{m.title}</p>
              <p className="text-[9px] text-slate-400">{m.year} · {m.genre} · {m.runtime}</p>
              <button onClick={() => trailer(m.title)} className="mt-1.5 flex h-7 w-full items-center justify-center gap-1 rounded-md bg-white/15 text-[10px] font-bold text-white backdrop-blur-sm transition-colors hover:bg-cyanx hover:text-abyss">
                <Play size={10} fill="currentColor" /> Tráiler oficial
              </button>
            </figcaption>
          </figure>
        ))}
      </div>

      {/* continue watching */}
      <div className="mt-5">
        <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">Continuar viendo</p>
        <div className="mt-2 grid gap-2 sm:grid-cols-3">
          {CONTINUE_WATCHING.map((c) => (
            <div key={c.title} className="rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-xs font-semibold text-slate-100">{c.title}</p>
                <Play size={12} className="shrink-0 text-cyanx" fill="currentColor" />
              </div>
              <p className="mt-0.5 text-[10px] text-slate-500">{c.meta}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-r from-cyanx to-violetx" style={{ width: `${c.progress}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
      <p className="mt-3 text-[10px] text-slate-600">Carteles generados con IA · Fichas, sinopsis y valoraciones de TMDB · Tráilers alojados en canales oficiales de YouTube · Seguimiento de episodios para Series.</p>
    </div>
  );
}

/* ───────────────────────── MÚSICA Y RADIO ───────────────────────── */
type Station = { id: string; name: string; stream: string; favicon?: string; codec?: string; bitrate?: number };
const RADIO_COUNTRIES = [
  { code: "ES", label: "España" },
  { code: "MX", label: "México" },
  { code: "AR", label: "Argentina" },
  { code: "CO", label: "Colombia" },
  { code: "US", label: "USA" },
];

function MusicPane() {
  const [country, setCountry] = useState("ES");
  const [stations, setStations] = useState<Station[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState<Station | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.75);
  const [liked, setLiked] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const ctrl = new AbortController();
    setLoading(true);
    fetch(`https://de1.api.radio-browser.info/json/stations/search?countrycode=${country}&limit=16&hidebroken=true&order=votes&reverse=true`, { signal: ctrl.signal })
      .then((r) => r.json())
      .then((rows: { stationuuid: string; name: string; url_resolved: string; url: string; favicon?: string; codec?: string; bitrate?: number }[]) => {
        setStations(rows.map((s) => ({ id: s.stationuuid, name: s.name.trim(), stream: s.url_resolved || s.url, favicon: s.favicon, codec: s.codec, bitrate: s.bitrate })));
      })
      .catch(() => setStations([]))
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  }, [country]);

  useEffect(() => () => { audioRef.current?.pause(); }, []);
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);

  const play = (s: Station) => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing?.id === s.id && isPlaying) { audio.pause(); setIsPlaying(false); return; }
    audio.src = s.stream;
    audio.volume = volume;
    audio.play().then(() => { setPlaying(s); setIsPlaying(true); }).catch(() => { setPlaying(s); setIsPlaying(false); });
    setPlaying(s);
    setIsPlaying(true);
  };
  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !playing) return;
    if (isPlaying) { audio.pause(); setIsPlaying(false); } else { audio.play().catch(() => {}); setIsPlaying(true); }
  };

  const shown = stations.filter((s) => s.name.toLowerCase().includes(query.trim().toLowerCase()));

  return (
    <div id="panel-musica" role="tabpanel" aria-labelledby="tab-musica" className="grid gap-5 lg:grid-cols-5">
      <audio ref={audioRef} preload="none" />
      {/* now playing */}
      <div className="tile relative overflow-hidden rounded-2xl lg:col-span-2">
        <img src="/img/art-headphones.jpg" alt="Auriculares de neón entre ondas de ecualizador" className="absolute inset-0 h-full w-full object-cover object-[50%_28%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04061a] via-[#04061a]/60 to-transparent" />
        <div className="relative flex h-full min-h-[280px] flex-col justify-end p-6">
          <p className="eyebrow">TV LO3 Music</p>
          <h3 className="mt-1 font-display text-2xl font-black text-white">{playing ? playing.name : "La Vida Es Mejor"}</h3>
          <p className="text-sm text-slate-300">{playing ? "En directo · Radio Browser" : "Bad Bunny · Un Verano Sin Ti"}</p>
          {/* equalizer */}
          <div className={`mt-4 flex h-10 items-end gap-1 ${isPlaying ? "" : "eq-paused"}`} aria-hidden="true">
            {Array.from({ length: 34 }).map((_, i) => (
              <span key={i} className="eq-bar w-1.5 rounded-sm bg-gradient-to-t from-electric via-cyanx to-lilac" style={{ height: "100%", animationDelay: `${(i * 97) % 900}ms`, animationDuration: `${0.7 + (i % 5) * 0.13}s` }} />
            ))}
          </div>
          <div className="mt-4 flex items-center gap-3">
            <SkipBack size={18} className="cursor-pointer text-slate-300 hover:text-white" />
            <button onClick={togglePlay} aria-label={isPlaying ? "Pausar" : "Reproducir"} className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 text-[#03102a] transition-transform hover:scale-105">
              {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
            <SkipForward size={18} className="cursor-pointer text-slate-300 hover:text-white" />
            <button onClick={() => setLiked((v) => !v)} aria-pressed={liked} aria-label="Me gusta" className="ml-auto transition-transform hover:scale-110">
              <Heart size={20} className={liked ? "fill-red-500 text-red-500" : "text-slate-300"} />
            </button>
            <Volume2 size={17} className="text-slate-400" aria-hidden="true" />
            <input type="range" min={0} max={1} step={0.01} value={volume} onChange={(e) => setVolume(Number(e.target.value))} aria-label="Volumen" className="h-1 w-20 cursor-pointer accent-cyan-400" />
          </div>
        </div>
      </div>

      {/* live radio */}
      <div className="tile flex flex-col rounded-2xl p-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h4 className="flex items-center gap-2 font-display text-base font-bold text-white"><Radio size={17} className="text-cyanx" /> Radio en vivo</h4>
          <div className="flex flex-wrap gap-1.5">
            {RADIO_COUNTRIES.map((c) => (
              <button key={c.code} onClick={() => setCountry(c.code)} aria-pressed={country === c.code} className={`rounded-full px-2.5 py-1 text-[10px] font-bold transition-colors ${country === c.code ? "bg-electric text-white" : "bg-white/5 text-slate-300 hover:text-white"}`}>{c.label}</button>
            ))}
          </div>
        </div>
        <div className="relative mt-3">
          <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <label htmlFor="radio-search" className="sr-only">Buscar emisora</label>
          <input id="radio-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar emisora…" className="h-10 w-full rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/50" />
        </div>
        <ul className="thin-scroll mt-3 max-h-56 flex-1 space-y-1.5 overflow-y-auto pr-1">
          {loading && Array.from({ length: 5 }).map((_, i) => <li key={i} className="h-12 animate-pulse rounded-xl bg-white/[0.04]" />)}
          {!loading && shown.length === 0 && <li className="rounded-xl border border-white/8 p-4 text-center text-xs text-slate-500">Sin resultados para “{query}”.</li>}
          {!loading && shown.map((s) => {
            const active = playing?.id === s.id;
            return (
              <li key={s.id} className={`flex items-center gap-3 rounded-xl border p-2 transition-colors ${active ? "border-cyanx/40 bg-cyanx/5" : "border-white/6 bg-white/[0.02] hover:border-white/15"}`}>
                {s.favicon
                  ? <img src={s.favicon} alt="" width={36} height={36} loading="lazy" className="h-9 w-9 rounded-lg object-cover" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
                  : <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-panel3"><Music2 size={16} className="text-cyanx" /></span>}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs font-semibold text-slate-100">{s.name}</span>
                  <span className="text-[9px] uppercase tracking-wider text-slate-500">{s.codec || "MP3"} · {s.bitrate || 128} kbps</span>
                </span>
                <button onClick={() => play(s)} aria-label={active && isPlaying ? `Pausar ${s.name}` : `Escuchar ${s.name}`} aria-pressed={active && isPlaying} className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-all ${active && isPlaying ? "bg-cyanx text-abyss" : "bg-white/10 text-white hover:bg-electric"}`}>
                  {active && isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-3 text-[10px] text-slate-600">Emisoras públicas reales vía Radio Browser (directorio comunitario). Streams ajenos a TV LO3; derechos de cada emisora. Podcasts, letras y ecualizador de 10 bandas dentro de la app.</p>
      </div>
    </div>
  );
}

/* ───────────────────────── GAMES HUB ───────────────────────── */
function GamesPane() {
  return (
    <div id="panel-games" role="tabpanel" aria-labelledby="tab-games" className="grid gap-5 lg:grid-cols-5">
      <div className="tile relative overflow-hidden rounded-2xl lg:col-span-2">
        <img src="/img/art-controller.jpg" alt="Mando de videojuego flotando con geometría de neón" className="absolute inset-0 h-full w-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04061a] via-[#04061a]/55 to-transparent" />
        <div className="relative flex h-full min-h-[300px] flex-col justify-end p-6">
          <p className="eyebrow">Juega · Compite · Gana</p>
          <h3 className="mt-1 font-display text-2xl font-black text-white">Games Hub</h3>
          <ul className="mt-2 space-y-1.5 text-xs text-slate-200">
            {["Logros y guardado en la nube", "Mandos Bluetooth plug & play", "Instalación autorizada vía TV LO3 Store", "Categorías: Fútbol, Carreras, Lucha, Familia…"].map((t) => (
              <li key={t} className="flex items-center gap-2"><CheckCircle2 size={13} className="text-emerald-400" />{t}</li>
            ))}
          </ul>
        </div>
      </div>
      <div className="tile rounded-2xl p-5 lg:col-span-3">
        <div className="flex items-center justify-between">
          <h4 className="font-display text-base font-bold text-white">Catálogo destacado</h4>
          <span className="flex items-center gap-1.5 rounded-full border border-violetx/40 bg-violetx/10 px-3 py-1 text-[10px] font-bold text-lilac"><Gamepad2 size={12} /> 2.400+ juegos</span>
        </div>
        <ol className="mt-4 space-y-2">
          {GAMES.map((g) => (
            <li key={g.rank} className="group flex items-center gap-3 rounded-xl border border-white/6 bg-white/[0.02] p-2.5 transition-colors hover:border-violetx/40">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violetx to-electric font-display text-base font-black text-white">{g.rank}</span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-slate-100">{g.name}</p>
                <p className="text-[10px] text-slate-500">{g.genre} · {g.tag}</p>
                <div className="mt-1.5 h-1 w-full max-w-52 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-violetx to-cyanx transition-all duration-700" style={{ width: `${g.rating * 10}%` }} />
                </div>
              </div>
              <span className="flex shrink-0 items-center gap-1 font-display text-sm font-bold text-gold"><Star size={12} fill="currentColor" />{g.rating}</span>
            </li>
          ))}
        </ol>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {["Fútbol", "Baloncesto", "Carreras", "Acción", "Aventura", "Simulación", "Estrategia", "Lucha", "Familia", "Multijugador"].map((c) => (
            <span key={c} className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-semibold text-slate-300">{c}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────── TV LO3 AI ───────────────────────── */
type Msg = { role: "user" | "ai"; text: string };
const SUGGESTIONS = ["Recomiéndame ciencia ficción", "¿Qué hay hoy en LaLiga?", "Modo Kids para mis hijos"];
function answerFor(q: string): string {
  const t = q.toLowerCase();
  if (t.includes("dune") || t.includes("ciencia") || t.includes("ficción") || t.includes("sci"))
    return "Te propongo «Dune: Parte Dos» (TMDB 8.7) — épico visual puro, 4K HDR y subtítulos CC. También «Interstellar» (8.7) para maratón dominical. Ambos están en tu lista de Continuar viendo.";
  if (t.includes("liga") || t.includes("fútbol") || t.includes("futbol") || t.includes("deporte") || t.includes("nba"))
    return "En Sports Center tienes LaLiga, Premier, Champions, NBA, NFL y más, con marcadores EN VIVO de ESPN sincronizados cada 60 segundos. ¿Quieres que active alertas para el Real Madrid o el Barça?";
  if (t.includes("radio") || t.includes("música") || t.includes("musica"))
    return "Abre Música y Radio: emisoras reales de Radio Browser (España, México, Argentina…), ecualizador de 10 bandas y letras cuando estén disponibles. ¿Pongo «La Vida Es Mejor» de Bad Bunny?";
  if (t.includes("kid") || t.includes("niñ") || t.includes("hijo"))
    return "Activa Perfil Kids: PIN parental, filtros por edad, horarios de uso y catálogo exclusivamente infantil. Todo se gestiona desde Ajustes → Controles parentales.";
  if (t.includes("premium") || t.includes("precio") || t.includes("plan") || t.includes("gratis"))
    return "FREE es gratis para siempre: canales públicos, catálogo completo y radio. PREMIUM (4,99 €/mes) elimina anuncios y desbloquea 4K HDR, EPG completo, offline y yo — TV LO3 AI, tuyo sin límites.";
  if (t.includes("m3u") || t.includes("lista") || t.includes("iptv") || t.includes("xtream"))
    return "Pega tu lista en World TV → Importar lista: soporto M3U, M3U8 y Xtream Codes. Se cifra localmente en Room Database y nunca sale de tu dispositivo salvo que tú la sincronices.";
  if (t.includes("offline") || t.includes("sin conexión"))
    return "El modo offline prioriza tus archivos locales: vídeo, música, fotos y documentos. Las descargas PREMIUM también quedan disponibles sin cobertura. Ideal para viajes.";
  return "Puedo ayudarte con cine, series, deportes en vivo, radio, tu biblioteca o la configuración. Prueba: «recomiéndame terror», «¿qué juega la NBA?» o «activar modo Kids». En PREMIUM respondo con voz y contexto completo.";
}

function AiPane() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "ai", text: "¡Hola! Soy TV LO3 AI. Pregúntame por películas, series, deportes o apps — o pulsa una sugerencia." },
  ]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = (raw: string) => {
    const q = raw.trim();
    if (!q) return;
    setMessages((m) => [...m, { role: "user", text: q }, { role: "ai", text: answerFor(q) }]);
    setInput("");
  };
  const voice = () => {
    setListening(true);
    window.setTimeout(() => {
      setListening(false);
      const sample = SUGGESTIONS[Math.floor(Math.random() * SUGGESTIONS.length)];
      send(sample);
    }, 1600);
  };

  return (
    <div id="panel-ai" role="tabpanel" aria-labelledby="tab-ai" className="grid gap-5 lg:grid-cols-5">
      {/* chat */}
      <div className="tile flex min-h-[380px] flex-col overflow-hidden rounded-2xl lg:col-span-3">
        <div className="flex items-center justify-between border-b border-white/8 bg-white/[0.03] px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-violetx"><Bot size={18} className="text-white" /></span>
            <div>
              <p className="text-sm font-bold text-white">TV LO3 AI</p>
              <p className="flex items-center gap-1 text-[10px] text-emerald-400"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> en línea · español</p>
            </div>
          </div>
          <button onClick={voice} aria-pressed={listening} aria-label="Activar búsqueda por voz" className={`flex h-9 w-9 items-center justify-center rounded-full transition-all ${listening ? "animate-live bg-red-500 text-white" : "bg-white/8 text-slate-300 hover:text-white"}`}>
            <Mic size={17} strokeWidth={2} className={listening ? "animate-pulse" : ""} />
          </button>
        </div>
        {listening && <p className="border-b border-red-500/20 bg-red-500/10 px-4 py-1.5 text-center text-[11px] font-semibold text-red-300">Escuchando… habla ahora</p>}
        <div ref={scrollRef} className="thin-scroll max-h-64 flex-1 space-y-2.5 overflow-y-auto p-4" aria-live="polite">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-snug ${m.role === "user" ? "rounded-br-md bg-electric text-white" : "rounded-bl-md border border-white/8 bg-panel3/70 text-slate-100"}`}>{m.text}</div>
            </div>
          ))}
        </div>
        <div className="border-t border-white/8 p-3">
          <div className="flex gap-1.5 overflow-x-auto pb-2">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="whitespace-nowrap rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[10px] font-medium text-slate-300 hover:border-cyanx/40 hover:text-white">{s}</button>
            ))}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2">
            <label htmlFor="ai-input" className="sr-only">Escribe tu pregunta</label>
            <input id="ai-input" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Pregúntame lo que sea…" className="h-11 flex-1 rounded-xl border border-white/10 bg-black/30 px-4 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-violetx/60" />
            <button type="submit" aria-label="Enviar" className="grad-btn flex h-11 w-11 items-center justify-center rounded-xl text-white"><ChevronRight size={18} strokeWidth={2.5} /></button>
          </form>
        </div>
      </div>

      {/* capabilities */}
      <div className="flex flex-col gap-4 lg:col-span-2">
        <div className="tile flex-1 rounded-2xl p-5">
          <h4 className="font-display text-base font-bold text-white">Lo que puede hacer</h4>
          <ul className="mt-3 space-y-2 text-[13px] text-slate-200">
            {[
              "Buscar películas, series y episodios",
              "Recomendar según tu historial y gustos",
              "Marcadores, calendarios y lesiones de tu equipo",
              "Diagnóstico y configuración inteligente del sistema",
              "Organizar tu biblioteca y detectar duplicados",
              "Control de voz manos libres (Premium)",
            ].map((t) => <li key={t} className="flex items-start gap-2"><CheckCircle2 size={14} className="mt-0.5 shrink-0 text-cyanx" />{t}</li>)}
          </ul>
        </div>
        <div className="rounded-2xl border border-violetx/25 bg-violetx/8 p-4 text-xs text-violet-200/80">
          <p className="flex items-center gap-2 font-bold text-lilac"><Sparkles size={13} /> Demo local</p>
          <p className="mt-1">Esta demo corre en tu navegador con respuestas predefinidas. La IA completa con voz y memoria llega incluida en PREMIUM y PRO — sin coste extra.</p>
        </div>
        <a href="#precios" className="ghost-btn flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-bold text-white">Desbloquear TV LO3 AI con Premium <ChevronRight size={15} /></a>
      </div>
    </div>
  );
}
