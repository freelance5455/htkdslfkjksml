import { useState } from "react";
import { showcaseTabs } from "../data/content";
import { cn } from "../utils/cn";
import { CheckIcon, ArrowRightIcon } from "./icons";

export function Showcase() {
  const [active, setActive] = useState(showcaseTabs[0].id);
  const tab = showcaseTabs.find((t) => t.id === active) ?? showcaseTabs[0];

  return (
    <section id="showcase" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute top-1/2 left-0 h-[500px] w-[500px] -translate-y-1/2 rounded-full bg-brand-600/10 blur-[140px]" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
            Product
          </p>
          <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            A command center built for{" "}
            <span className="text-gradient-brand">modern operators</span>
          </h2>
          <p className="reveal delay-200 mt-4 text-base text-ink-400 sm:text-lg">
            Design, launch, and govern mission-critical workflows from a single
            beautiful surface—powered by AI that learns your business.
          </p>
        </div>

        {/* Tabs */}
        <div className="reveal delay-300 mt-10 flex justify-center">
          <div
            className="inline-flex rounded-full border border-white/10 bg-white/5 p-1 backdrop-blur-md"
            role="tablist"
            aria-label="Product capabilities"
          >
            {showcaseTabs.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={active === t.id}
                onClick={() => setActive(t.id)}
                className={cn(
                  "relative rounded-full px-4 py-2 text-sm font-medium transition-all duration-300 sm:px-6",
                  active === t.id
                    ? "bg-white text-ink-950 shadow-lg"
                    : "text-ink-400 hover:text-white"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content panel */}
        <div className="reveal delay-400 mt-10 grid items-center gap-8 lg:grid-cols-2 lg:gap-14">
          <div key={tab.id} className="animate-fade-in-up">
            <h3 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">
              {tab.title}
            </h3>
            <p className="mt-4 text-base leading-relaxed text-ink-400">
              {tab.description}
            </p>
            <ul className="mt-6 space-y-3">
              {tab.points.map((point) => (
                <li key={point} className="flex items-start gap-3 text-sm text-ink-200">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-500/20 text-brand-300">
                    <CheckIcon size={12} />
                  </span>
                  {point}
                </li>
              ))}
            </ul>
            <button type="button" className="btn-primary mt-8">
              Explore the platform
              <ArrowRightIcon size={16} />
            </button>
          </div>

          {/* Visual panel */}
          <div
            key={`visual-${tab.id}`}
            className="animate-fade-in-up relative"
            style={{ animationDelay: "80ms" }}
          >
            <div className="glow-soft relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-ink-900 to-ink-950">
              <div className="absolute inset-0 bg-gradient-to-br from-brand-600/10 via-transparent to-fuchsia-600/10" />
              <div className="relative aspect-[4/3] p-6 sm:p-8">
                {/* Fake workflow canvas */}
                <div className="flex h-full flex-col justify-center gap-4">
                  <WorkflowNode
                    label={
                      tab.id === "automate"
                        ? "Trigger: Deal closed"
                        : tab.id === "orchestrate"
                          ? "Salesforce ↔ HubSpot"
                          : "Scale: 10k concurrent"
                    }
                    sub={
                      tab.id === "automate"
                        ? "Salesforce opportunity"
                        : tab.id === "orchestrate"
                          ? "Bi-directional sync"
                          : "Global edge network"
                    }
                    color="brand"
                    delay={0}
                  />
                  <div className="ml-8 flex items-center gap-2">
                    <div className="h-8 w-px bg-gradient-to-b from-brand-400/60 to-fuchsia-400/60" />
                    <span className="text-[10px] font-medium tracking-wider text-ink-500 uppercase">
                      {tab.id === "automate"
                        ? "AI designs 4 steps"
                        : tab.id === "orchestrate"
                          ? "Resolving conflicts"
                          : "Auto-scaling"}
                    </span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <WorkflowNode
                      label={
                        tab.id === "automate"
                          ? "Provision accounts"
                          : tab.id === "orchestrate"
                            ? "Notion workspace"
                            : "Workspace EU"
                      }
                      sub={
                        tab.id === "automate"
                          ? "Okta + Google Workspace"
                          : tab.id === "orchestrate"
                            ? "Synced 2s ago"
                            : "Frankfurt · healthy"
                      }
                      color="violet"
                      delay={100}
                    />
                    <WorkflowNode
                      label={
                        tab.id === "automate"
                          ? "Notify CS team"
                          : tab.id === "orchestrate"
                            ? "Slack #revenue"
                            : "Workspace US"
                      }
                      sub={
                        tab.id === "automate"
                          ? "Slack + Linear ticket"
                          : tab.id === "orchestrate"
                            ? "Event streamed"
                            : "Virginia · healthy"
                      }
                      color="fuchsia"
                      delay={200}
                    />
                  </div>
                  <div className="ml-8 flex items-center gap-2">
                    <div className="h-6 w-px bg-gradient-to-b from-fuchsia-400/60 to-emerald-400/40" />
                  </div>
                  <WorkflowNode
                    label={
                      tab.id === "automate"
                        ? "Schedule onboarding"
                        : tab.id === "orchestrate"
                          ? "All systems aligned"
                          : "Observability active"
                    }
                    sub={
                      tab.id === "automate"
                        ? "Calendly + email sequence"
                        : tab.id === "orchestrate"
                          ? "0 conflicts remaining"
                          : "P99 latency 48ms"
                    }
                    color="emerald"
                    delay={300}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function WorkflowNode({
  label,
  sub,
  color,
  delay,
}: {
  label: string;
  sub: string;
  color: "brand" | "violet" | "fuchsia" | "emerald";
  delay: number;
}) {
  const colors = {
    brand: "border-brand-400/30 bg-brand-500/10",
    violet: "border-violet-400/30 bg-violet-500/10",
    fuchsia: "border-fuchsia-400/30 bg-fuchsia-500/10",
    emerald: "border-emerald-400/30 bg-emerald-500/10",
  };
  const dots = {
    brand: "bg-brand-400",
    violet: "bg-violet-400",
    fuchsia: "bg-fuchsia-400",
    emerald: "bg-emerald-400",
  };

  return (
    <div
      className={cn(
        "glass flex items-center gap-3 rounded-xl border px-4 py-3 transition-all duration-300 hover:scale-[1.02]",
        colors[color]
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      <span className={cn("h-2.5 w-2.5 shrink-0 rounded-full", dots[color])} />
      <div className="min-w-0">
        <div className="truncate text-sm font-medium text-white">{label}</div>
        <div className="truncate text-xs text-ink-500">{sub}</div>
      </div>
    </div>
  );
}
