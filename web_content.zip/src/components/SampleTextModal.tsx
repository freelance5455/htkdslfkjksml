import React, { useState } from 'react';
import { X, BookOpen, Newspaper, Cpu, Flame, Clapperboard, Moon, Check, ArrowRight } from 'lucide-react';
import { SAMPLE_TELUGU_TEXTS, SampleTeluguText } from '../utils/sampleTexts';

interface SampleTextModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSample: (sample: SampleTeluguText) => void;
}

export const SampleTextModal: React.FC<SampleTextModalProps> = ({
  isOpen,
  onClose,
  onSelectSample,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', name: 'అన్నీ (All)' },
    { id: 'story', name: 'కథలు (Story)' },
    { id: 'news', name: 'వార్తలు (News)' },
    { id: 'tech', name: 'టెక్నాలజీ & ఏఐ (Tech)' },
    { id: 'motivational', name: 'మోటివేషనల్ (Motivational)' },
    { id: 'cinematic', name: 'సినిమాటిక్ (Cinematic)' },
    { id: 'calm', name: 'ప్రశాంతం (Calm)' },
  ];

  const filtered = SAMPLE_TELUGU_TEXTS.filter((s) => {
    if (selectedCategory === 'all') return true;
    return s.category === selectedCategory;
  });

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'story':
        return <BookOpen className="w-4 h-4 text-amber-400" />;
      case 'news':
        return <Newspaper className="w-4 h-4 text-blue-400" />;
      case 'tech':
        return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'motivational':
        return <Flame className="w-4 h-4 text-orange-400" />;
      case 'cinematic':
        return <Clapperboard className="w-4 h-4 text-purple-400" />;
      case 'calm':
        return <Moon className="w-4 h-4 text-emerald-400" />;
      default:
        return <BookOpen className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl bg-[#101522] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                ఉదాహరణ తెలుగు స్క్రిప్ట్స్ (Sample Telugu Texts)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                వాయిస్ మరియు వ్యాఖ్యాన రీతులను పరీక్షించడానికి సిద్ధంగా ఉన్న స్క్రిప్ట్‌లను ఎంచుకోండి
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="p-3 border-b border-slate-800 bg-slate-900/40 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Samples List */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3.5 divide-y divide-slate-800/60">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="pt-3.5 first:pt-0 group hover:bg-slate-900/40 p-3 rounded-xl transition-all"
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  {getCategoryIcon(item.category)}
                  <h4 className="text-sm font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                    {item.title}
                  </h4>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onSelectSample(item);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all shadow-sm cursor-pointer shrink-0"
                >
                  <span>ఎంచుకోండి (Use)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <p className="text-xs font-telugu text-slate-300 leading-relaxed bg-[#0a0d14]/70 p-3 rounded-xl border border-slate-800/80">
                {item.text}
              </p>

              <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-500">
                <span>సిఫార్సు చేయబడిన రీతి: <strong className="text-slate-400">{item.recommendedStyle || item.presetStyle}</strong></span>
                <span>•</span>
                <span>అక్షరాలు: {item.text.length}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
