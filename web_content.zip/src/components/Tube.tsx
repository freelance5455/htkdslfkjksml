import { memo, useEffect, useId, useRef, useState } from "react";
import { LIQUID_COLORS, SkinId } from "../game";
import { downFor, levelFor, P } from "../liquidPhysics";

/**
 * Damped spring for liquid slosh. The surface lags behind glass rotation,
 * gets kicked by lifting and by incoming liquid, then settles naturally.
 */
function useSlosh(tilt: number, units: number, lifted: boolean, hold: boolean) {
  const state = useRef({ a: 0, v: 0, tilt, units, lifted, running: false, raf: 0 });
  const [, force] = useState(0);

  useEffect(() => {
    const s = state.current;
    const dTilt = tilt - s.tilt;
    const dUnits = units - s.units;
    if (hold) {
      // Actively pouring: liquid is pinned to the lip, so nothing accumulates.
      s.a = 0;
      s.v = 0;
      s.tilt = tilt;
      s.units = units;
      s.lifted = lifted;
      return;
    }
    s.a -= dTilt * 0.22;
    if (lifted !== s.lifted) s.v += lifted ? 1.6 : -1.1;
    if (dUnits > 0.0001) s.v += (Math.random() - 0.5) * Math.min(1, dUnits * 25) * 1.8;
    if (dUnits < -0.0001) s.v += Math.max(-0.4, dUnits * 6);
    s.tilt = tilt;
    s.units = units;
    s.lifted = lifted;
    if (!s.running && (Math.abs(s.a) > 0.002 || Math.abs(s.v) > 0.01)) {
      s.running = true;
      let last = performance.now();
      const step = (now: number) => {
        const dt = Math.min(0.033, (now - last) / 1000);
        last = now;
        // Heavier, slower slosh like real liquid in a narrow glass.
        const w = 5.2;
        const z = 0.09;
        s.v += (-w * w * s.a - 2 * z * w * s.v) * dt;
        s.a = Math.max(-0.45, Math.min(0.45, s.a + s.v * dt));
        if (Math.abs(s.a) < 0.0015 && Math.abs(s.v) < 0.008) {
          s.a = 0;
          s.v = 0;
          s.running = false;
          force((n) => n + 1);
          return;
        }
        force((n) => n + 1);
        s.raf = requestAnimationFrame(step);
      };
      s.raf = requestAnimationFrame(step);
    }
  }, [tilt, units, lifted, hold]);

  useEffect(() => () => cancelAnimationFrame(state.current.raf), []);
  return state.current;
}

export interface VisualLayer {
  color: number;
  units: number;
}

export function makeLayers(tube: number[]): VisualLayer[] {
  const layers: VisualLayer[] = [];
  tube.forEach((color) => {
    const last = layers[layers.length - 1];
    if (last?.color === color) last.units += 1;
    else layers.push({ color, units: 1 });
  });
  return layers;
}

interface TubeGraphicProps {
  tube?: number[];
  layers?: VisualLayer[];
  skin?: SkinId;
  active?: boolean;
  /** Glass tilt in radians; liquid surfaces counter-rotate toward gravity. */
  tilt?: number;
  /** Tube is lifted (selected) — kicks the liquid into a gentle slosh. */
  lifted?: boolean;
  complete?: boolean;
  className?: string;
}

const BOTTOM = 196;
const UNIT = 43.5;
const OUTER_SHAPE = "M12 13 L12 173 Q12 207 40 207 Q68 207 68 173 L68 13 Z";
const OUTER_OPEN = "M12 13 L12 173 Q12 207 40 207 Q68 207 68 173 L68 13";
const INNER_SHAPE = "M19 20 L19 173 Q19 196 40 196 Q61 196 61 173 L61 20 Z";
const PUNT_SHAPE =
  "M12 162 L12 173 Q12 207 40 207 Q68 207 68 173 L68 162 Z " +
  "M19 162 L19 173 Q19 196 40 196 Q61 196 61 173 L61 162 Z";

interface Surface {
  /** Point on the surface line at the tube's centerline. */
  center: P;
  /** Unit tangent along the (gravity-level) surface. */
  tan: P;
  down: P;
  /** Half the chord across the inner cavity. */
  halfChord: number;
  angleDeg: number;
}

function surfaceFor(theta: number, level: number): Surface {
  const down = downFor(theta);
  const tan = { x: down.y, y: -down.x };
  const cos = Math.max(0.2, down.y);
  // Point on the line at x = 40 (cavity centerline).
  const center = { x: 40, y: (level - 40 * down.x) / cos };
  return {
    center,
    tan,
    down,
    halfChord: Math.min(60, 21 / cos),
    angleDeg: (Math.atan2(tan.y, tan.x) * 180) / Math.PI,
  };
}

/** Polygon covering everything below a surface; top edge optionally waved. */
function liquidPolygon(s: Surface, amp: number, phase: number): string {
  const pts: P[] = [];
  const at = (u: number, off: number) => ({
    x: s.center.x + s.tan.x * u - s.down.x * off,
    y: s.center.y + s.tan.y * u - s.down.y * off,
  });
  pts.push(at(-260, 0));
  const span = s.halfChord + 2;
  if (amp > 0.01) {
    for (let u = -span; u <= span + 0.01; u += 3) {
      // Two travelling waves + meniscus climb at the glass walls.
      const edge = Math.max(0, Math.abs(u) / span - 0.82) * 6;
      const wave = Math.sin(u * 0.2 + phase) * amp + Math.sin(u * 0.43 - phase * 1.7) * amp * 0.4;
      pts.push(at(u, wave + edge));
    }
  } else {
    pts.push(at(-span, 1.2), at(0, 0), at(span, 1.2));
  }
  pts.push(at(260, 0));
  pts.push({ x: pts[pts.length - 1].x + s.down.x * 500, y: pts[pts.length - 1].y + s.down.y * 500 });
  pts.push({ x: pts[0].x + s.down.x * 500, y: pts[0].y + s.down.y * 500 });
  return `M ${pts.map((p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" L ")} Z`;
}

const CONDENSATION: Array<{ cx: number; cy: number; r: number; delay: string }> = [
  { cx: 29, cy: 66, r: 1.1, delay: "0s" },
  { cx: 53, cy: 58, r: 0.8, delay: "-1.3s" },
  { cx: 34, cy: 118, r: 0.9, delay: "-2.1s" },
  { cx: 51, cy: 148, r: 1.2, delay: "-0.6s" },
  { cx: 27, cy: 158, r: 0.7, delay: "-2.8s" },
];

function TubeGraphic({
  tube = [],
  layers,
  skin = "classic",
  active = false,
  tilt = 0,
  lifted = false,
  complete = false,
  className = "",
}: TubeGraphicProps) {
  const uid = useId().replace(/:/g, "");
  const visualLayers = (layers ?? makeLayers(tube)).filter((layer) => layer.units > 0.005);
  const colorIndexes = [...new Set(visualLayers.map((layer) => layer.color))];
  const totalUnits = visualLayers.reduce((sum, layer) => sum + layer.units, 0);
  const bottomColor = visualLayers.length ? visualLayers[0].color : -1;
  const pouringHold = active && Math.abs(tilt) > 0.1;
  const slosh = useSlosh(tilt, totalUnits, lifted, pouringHold);
  // Effective surface tilt = glass tilt + liquid lag (slosh).
  // While actively pouring, liquid hugs the lip (no lag away from it).
  const theta = pouringHold ? tilt : tilt + slosh.a;
  const settled = Math.abs(theta) < 0.004;
  const now = typeof performance !== "undefined" ? performance.now() : 0;
  const waveAmp = Math.min(2.6, Math.abs(slosh.v) * 2.2) + (active ? 1.1 : 0) + (Math.abs(tilt) > 0.05 ? 0.35 : 0);
  const wavePhase = (now / 1000) * (active ? 9 : 6);
  let cursor = 0;
  const positioned = visualLayers.map((layer, index) => {
    const yBottom = BOTTOM - cursor * UNIT;
    cursor += layer.units;
    const yTop = BOTTOM - cursor * UNIT;
    const level = settled ? yTop : levelFor(theta, cursor);
    const surface = surfaceFor(settled ? 0 : theta, level);
    return { ...layer, index, yBottom, yTop, surface, top: index === visualLayers.length - 1 };
  });

  const isBamboo = skin === "bamboo";
  const isNeon = skin === "neon";
  const isCrystal = skin === "crystal";
  const isFrost = skin === "frost";
  const isSunset = skin === "sunset";
  const glassStroke = isBamboo
    ? "#c8ae70"
    : isNeon
      ? "#69fff1"
      : isFrost
        ? "#eaf7ff"
        : isSunset
          ? "#ffcf8f"
          : "#d5f8ff";
  const tiltShift = Math.max(-5, Math.min(5, tilt * 5));
  const streakBoost = Math.min(0.16, Math.abs(tilt) * 0.08);

  return (
    <svg
      className={`tube-graphic skin-${skin} ${active ? "is-pouring" : ""} ${complete ? "is-complete" : ""} ${className}`}
      viewBox="0 0 80 220"
      role="img"
      aria-label={`${totalUnits.toFixed(totalUnits % 1 ? 1 : 0)} of 4 liquid units`}
    >
      <defs>
        <clipPath id={`${uid}-inside`}>
          <path d={INNER_SHAPE} />
        </clipPath>
        <clipPath id={`${uid}-outer`}>
          <path d={OUTER_SHAPE} />
        </clipPath>

        {/* Cylindrical glass: dark TIR edges, soft window band, clear middle. */}
        <linearGradient id={`${uid}-wall`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={isSunset ? "#5c3a17" : isFrost ? "#274b5c" : "#123c4c"} stopOpacity=".62" />
          <stop offset=".055" stopColor={isSunset ? "#ffe9c4" : "#ffffff"} stopOpacity={isFrost ? ".44" : ".34"} />
          <stop offset=".11" stopColor={isSunset ? "#4a2f14" : "#0a2a38"} stopOpacity=".3" />
          <stop offset=".2" stopColor={isSunset ? "#ffd9a0" : "#bfe9f2"} stopOpacity={isFrost ? ".14" : ".07"} />
          <stop offset=".38" stopColor={isSunset ? "#ffdfae" : "#d9fbff"} stopOpacity={isFrost ? ".1" : ".02"} />
          <stop offset=".55" stopColor={isSunset ? "#ffc887" : "#9fd4e2"} stopOpacity={isFrost ? ".12" : ".045"} />
          <stop offset=".74" stopColor={isSunset ? "#ffdfae" : "#d9fbff"} stopOpacity={isFrost ? ".1" : ".02"} />
          <stop offset=".86" stopColor={isSunset ? "#4a2f14" : "#0a2a38"} stopOpacity=".26" />
          <stop offset=".935" stopColor={isSunset ? "#ffe9c4" : "#ffffff"} stopOpacity={isFrost ? ".36" : ".26"} />
          <stop offset="1" stopColor={isSunset ? "#5c3a17" : isFrost ? "#274b5c" : "#123c4c"} stopOpacity=".6" />
        </linearGradient>
        {/* Front wall fresnel: bright at grazing edges, invisible head-on. */}
        <linearGradient id={`${uid}-front`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".42" />
          <stop offset=".07" stopColor="#ffffff" stopOpacity=".1" />
          <stop offset=".22" stopColor="#ffffff" stopOpacity="0" />
          <stop offset=".78" stopColor="#ffffff" stopOpacity="0" />
          <stop offset=".93" stopColor="#ffffff" stopOpacity=".09" />
          <stop offset="1" stopColor="#ffffff" stopOpacity=".46" />
        </linearGradient>
        {/* Thick rounded base glass. */}
        <linearGradient id={`${uid}-punt`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f2ffff" stopOpacity=".62" />
          <stop offset=".3" stopColor="#a9d9e4" stopOpacity=".28" />
          <stop offset=".62" stopColor="#41697d" stopOpacity=".42" />
          <stop offset=".85" stopColor="#d9f4fa" stopOpacity=".34" />
          <stop offset="1" stopColor="#ffffff" stopOpacity=".5" />
        </linearGradient>
        {/* Rounded torus lip: top catchlight, side tone, under-shadow, bounce. */}
        <linearGradient id={`${uid}-rim`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".95" />
          <stop offset=".22" stopColor="#cfeff6" stopOpacity=".55" />
          <stop offset=".45" stopColor="#7fa8b8" stopOpacity=".35" />
          <stop offset=".68" stopColor="#0a3040" stopOpacity=".62" />
          <stop offset=".86" stopColor="#3d6a7e" stopOpacity=".4" />
          <stop offset="1" stopColor="#ffffff" stopOpacity=".42" />
        </linearGradient>
        {/* Vertical envelope for highlight streaks. */}
        <linearGradient id={`${uid}-streak`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset=".12" stopColor="#ffffff" stopOpacity=".95" />
          <stop offset=".7" stopColor="#ffffff" stopOpacity=".7" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        {/* Soft horizontal falloff so streak edges melt into the glass. */}
        <linearGradient id={`${uid}-streak-soft`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset=".3" stopColor="#ffffff" stopOpacity=".9" />
          <stop offset=".55" stopColor="#ffffff" stopOpacity="1" />
          <stop offset=".8" stopColor="#ffffff" stopOpacity=".5" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        {/* Beer–Lambert depth: taller columns absorb more light downward. */}
        <linearGradient id={`${uid}-depth`} gradientUnits="userSpaceOnUse" x1="0" y1="20" x2="0" y2="196">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".14" />
          <stop offset=".22" stopColor="#ffffff" stopOpacity="0" />
          <stop offset=".6" stopColor="#00141d" stopOpacity=".1" />
          <stop offset="1" stopColor="#00141d" stopOpacity=".38" />
        </linearGradient>
        {/* Path-length darkening at the cylinder walls. */}
        <linearGradient id={`${uid}-edge`} gradientUnits="userSpaceOnUse" x1="19" y1="0" x2="61" y2="0">
          <stop offset="0" stopColor="#000d13" stopOpacity=".5" />
          <stop offset=".13" stopColor="#000d13" stopOpacity=".06" />
          <stop offset=".3" stopColor="#000d13" stopOpacity="0" />
          <stop offset=".7" stopColor="#000d13" stopOpacity="0" />
          <stop offset=".87" stopColor="#000d13" stopOpacity=".06" />
          <stop offset="1" stopColor="#000d13" stopOpacity=".5" />
        </linearGradient>
        {/* Floor shadow falloff. */}
        <radialGradient id={`${uid}-shadow`} cx=".5" cy=".5" r=".5">
          <stop offset="0" stopColor="#000a12" stopOpacity=".42" />
          <stop offset=".55" stopColor="#000a12" stopOpacity=".22" />
          <stop offset="1" stopColor="#000a12" stopOpacity="0" />
        </radialGradient>
        {bottomColor >= 0 && (
          <radialGradient id={`${uid}-floor`} cx=".5" cy=".5" r=".5">
            <stop offset="0" stopColor={LIQUID_COLORS[bottomColor].base} stopOpacity=".55" />
            <stop offset=".6" stopColor={LIQUID_COLORS[bottomColor].base} stopOpacity=".18" />
            <stop offset="1" stopColor={LIQUID_COLORS[bottomColor].base} stopOpacity="0" />
          </radialGradient>
        )}
        {isBamboo && (
          <linearGradient id={`${uid}-wood`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#3a2410" />
            <stop offset=".22" stopColor="#8a5f2c" />
            <stop offset=".45" stopColor="#d9ab62" />
            <stop offset=".62" stopColor="#a97e44" />
            <stop offset=".85" stopColor="#5d3c1c" />
            <stop offset="1" stopColor="#33200e" />
          </linearGradient>
        )}
        {isSunset && (
          <linearGradient id={`${uid}-amber`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffdf9e" stopOpacity=".5" />
            <stop offset=".45" stopColor="#ff9d5c" stopOpacity=".28" />
            <stop offset="1" stopColor="#c65a2e" stopOpacity=".42" />
          </linearGradient>
        )}
        {isFrost && (
          <linearGradient id={`${uid}-ice`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffffff" stopOpacity=".5" />
            <stop offset=".4" stopColor="#cdeefb" stopOpacity=".14" />
            <stop offset="1" stopColor="#eaf7ff" stopOpacity=".34" />
          </linearGradient>
        )}
        {isCrystal && (
          <linearGradient id={`${uid}-rainbow`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffb3c0" stopOpacity=".65" />
            <stop offset=".25" stopColor="#ffedb0" stopOpacity=".65" />
            <stop offset=".5" stopColor="#b6ffd0" stopOpacity=".65" />
            <stop offset=".75" stopColor="#b3d9ff" stopOpacity=".65" />
            <stop offset="1" stopColor="#dcc2ff" stopOpacity=".65" />
          </linearGradient>
        )}
        <filter id={`${uid}-glow`} x="-80%" y="-50%" width="260%" height="200%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id={`${uid}-soft`} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="0.7" />
        </filter>
        {colorIndexes.map((color) => {
          const palette = LIQUID_COLORS[color];
          return (
            <g key={color}>
              {/* Cylindrical volume: dark limbs, bright window band left-of-center. */}
              <linearGradient id={`${uid}-liquid-${color}`} gradientUnits="userSpaceOnUse" x1="19" y1="0" x2="61" y2="0">
                <stop offset="0" stopColor={palette.dark} />
                <stop offset=".1" stopColor={palette.dark} />
                <stop offset=".22" stopColor={palette.base} />
                <stop offset=".34" stopColor={palette.light} />
                <stop offset=".44" stopColor={palette.base} />
                <stop offset=".62" stopColor={palette.base} />
                <stop offset=".82" stopColor={palette.dark} />
                <stop offset="1" stopColor={palette.dark} />
              </linearGradient>
              {/* Top surface: bright center fading to saturated dark limbs. */}
              <radialGradient id={`${uid}-surface-${color}`} cx=".42" cy=".42" r=".75">
                <stop offset="0" stopColor={palette.light} />
                <stop offset=".45" stopColor={palette.base} />
                <stop offset=".8" stopColor={palette.base} />
                <stop offset="1" stopColor={palette.dark} />
              </radialGradient>
            </g>
          );
        })}
      </defs>

      {/* Grounded contact: wide ambient occlusion + tight contact + liquid bounce. */}
      <ellipse cx="40" cy="211.5" rx="30" ry="6" fill={`url(#${uid}-shadow)`} />
      <ellipse className="tube-contact-shadow" cx="40" cy="210.5" rx="19" ry="2.6" />
      {bottomColor >= 0 && (
        <ellipse className="floor-glow" cx="40" cy="211.5" rx="23" ry="3.2" fill={`url(#${uid}-floor)`} />
      )}

      {/* Back wall of the glass cylinder. */}
      <path className="glass-back" d={OUTER_SHAPE} fill={`url(#${uid}-wall)`} />
      <path d={INNER_SHAPE} fill={`url(#${uid}-edge)`} opacity=".22" />
      {/* Frost: icy wash creeping over the glass. */}
      {isFrost && (
        <g clipPath={`url(#${uid}-outer)`} className="frost-wash">
          <rect x="9" y="11" width="62" height="60" fill={`url(#${uid}-ice)`} opacity=".55" />
          <rect x="9" y="150" width="62" height="58" fill={`url(#${uid}-ice)`} opacity=".4" transform="rotate(180 40 179)" />
        </g>
      )}
      {/* Sunset: warm amber glow soaked into the glass. */}
      {isSunset && (
        <g clipPath={`url(#${uid}-outer)`}>
          <rect x="9" y="11" width="62" height="197" fill={`url(#${uid}-amber)`} opacity=".5" />
        </g>
      )}

      {isBamboo && (
        <g clipPath={`url(#${uid}-outer)`}>
          <rect x="9" y="11" width="11" height="196" fill={`url(#${uid}-wood)`} />
          <rect x="60" y="11" width="11" height="196" fill={`url(#${uid}-wood)`} />
          <rect x="18.5" y="11" width="1.6" height="196" fill="#241507" opacity=".6" />
          <rect x="59.9" y="11" width="1.6" height="196" fill="#241507" opacity=".6" />
        </g>
      )}

      {/* ---------------- Liquid ---------------- */}
      <g clipPath={`url(#${uid}-inside)`} className="liquid-clip">
        {/* Bodies: top layer first, each lower layer paints over everything below its own surface. */}
        {[...positioned].reverse().map((layer) => {
          const palette = LIQUID_COLORS[layer.color];
          const path = liquidPolygon(layer.surface, layer.top ? waveAmp : 0, wavePhase);
          return (
            <g key={`body-${layer.index}-${layer.color}`}>
              <path className="liquid-body-base" d={path} fill={palette.base} />
              <path className="liquid-body" d={path} fill={`url(#${uid}-liquid-${layer.color})`} />
              <path className="liquid-depth" d={path} fill={`url(#${uid}-depth)`} />
            </g>
          );
        })}
        {totalUnits > 0.01 && (
          <path d={INNER_SHAPE} fill={`url(#${uid}-edge)`} className="liquid-edge-shade" />
        )}
        {/* Bottom occlusion + caustic, only when upright. */}
        {settled && positioned.length > 0 && (
          <g>
            <path d="M19 196 L19 182 Q40 190 61 182 L61 196 Z" fill="#000d13" opacity=".22" filter={`url(#${uid}-soft)`} />
            <path
              d="M24 187 Q40 193 56 187"
              fill="none"
              stroke={LIQUID_COLORS[positioned[0].color].light}
              strokeOpacity=".35"
              strokeWidth="2.4"
              strokeLinecap="round"
              filter={`url(#${uid}-soft)`}
            />
          </g>
        )}
        {/* Layer seams and the glossy top meniscus, aligned to gravity. */}
        {positioned.map((layer) => {
          const palette = LIQUID_COLORS[layer.color];
          const s = layer.surface;
          const ax = s.center.x - s.tan.x * s.halfChord;
          const ay = s.center.y - s.tan.y * s.halfChord;
          const bx = s.center.x + s.tan.x * s.halfChord;
          const by = s.center.y + s.tan.y * s.halfChord;
          const transform = `rotate(${s.angleDeg} ${s.center.x} ${s.center.y})`;
          const cx = s.center.x;
          const cy = s.center.y;
          const hc = s.halfChord;
          if (!layer.top) {
            return (
              <g key={`seam-${layer.index}`}>
                <line x1={ax} y1={ay} x2={bx} y2={by} stroke="#000d13" strokeOpacity=".35" strokeWidth="1.6" transform={`translate(${s.down.x * 1.6} ${s.down.y * 1.6})`} />
                <line x1={ax} y1={ay} x2={bx} y2={by} stroke={palette.light} strokeOpacity=".45" strokeWidth="1.1" />
              </g>
            );
          }
          return (
            <g key={`surface-${layer.index}`} transform={transform} className={settled ? "liquid-surface" : undefined}>
              <ellipse cx={cx} cy={cy + 0.4} rx={hc} ry="4.8" fill={palette.dark} opacity=".6" />
              <ellipse cx={cx} cy={cy - 0.5} rx={hc - 1.2} ry="3.9" fill={`url(#${uid}-surface-${layer.color})`} />
              <path
                className="surface-back-crescent"
                d={`M${cx - hc + 4} ${cy - 1.4} Q${cx} ${cy - 5} ${cx + hc - 4} ${cy - 1.4}`}
                fill="none"
                stroke="#ffffff"
                strokeOpacity=".5"
                strokeWidth="1.2"
                strokeLinecap="round"
              />
              <path
                className="surface-front-arc"
                d={`M${cx - hc + 3} ${cy + 1} Q${cx} ${cy + 5.2} ${cx + hc - 3} ${cy + 1}`}
                fill="none"
                stroke={palette.dark}
                strokeOpacity=".7"
                strokeWidth="1.6"
                strokeLinecap="round"
              />
              <ellipse className="surface-dot" cx={cx - 8} cy={cy - 1.4} rx="5.2" ry="1.2" fill="#ffffff" opacity=".55" filter={`url(#${uid}-soft)`} />
              <ellipse className="surface-core" cx={cx - 10} cy={cy - 1.5} rx="2" ry="0.6" fill="#ffffff" opacity=".85" />
            </g>
          );
        })}
        {/* Window light shaft crossing the water column. */}
        {totalUnits > 0.15 && (
          <polygon className="liquid-shaft" points="29,20 38,20 30,196 22,196" fill="#ffffff" opacity=".07" />
        )}
        {totalUnits > 0.15 && (
          <polygon className="liquid-shaft liquid-shaft-dim" points="52,20 55,20 50,196 47,196" fill="#ffffff" opacity=".045" />
        )}
        {/* Rising micro-bubbles with specular dots. */}
        {totalUnits > 0.15 &&
          Array.from({ length: active ? 8 : 4 }, (_, index) => {
            const available = Math.max(14, totalUnits * UNIT - 10);
            const cy = BOTTOM - 7 - ((index * 29 + visualLayers[0].color * 11) % available);
            const cx = 25 + ((index * 17 + visualLayers[0].color * 7) % 30);
            const r = index % 3 === 0 ? 1.7 : 1;
            return (
              <g
                key={index}
                className="liquid-bubble-wrap"
                style={{ animationDelay: `${-index * 0.43}s`, animationDuration: `${2.1 + (index % 4) * 0.5}s` }}
              >
                <circle className="liquid-bubble" cx={cx} cy={cy} r={r} />
                <circle cx={cx - r * 0.3} cy={cy - r * 0.35} r={r * 0.32} fill="#ffffff" opacity=".8" />
              </g>
            );
          })}
        <path className="liquid-refraction" d="M25 25 Q20 95 27 183" />
      </g>

      {/* Thick glass punt between the inner and outer bottom curves. */}
      <path
        d={PUNT_SHAPE}
        fillRule="evenodd"
        fill={isBamboo ? `url(#${uid}-wood)` : `url(#${uid}-punt)`}
        opacity={isNeon ? ".85" : "1"}
      />
      {!isBamboo && (
        <g>
          <path className="punt-inner-line" d="M19 173 Q19 196 40 196 Q61 196 61 173" />
          <path className="punt-outer-glow" d="M14 172 Q14 204 40 205.5 Q66 204 66 172" />
          <path className="glass-bottom-glint" d="M22 188 Q29 203 43 201" />
          <path className="glass-bottom-glint glass-bottom-glint-right" d="M58 188 Q51 203 37 201" />
        </g>
      )}

      {/* Front wall fresnel sheen over the contents. */}
      <path className="glass-front-wall" d={OUTER_SHAPE} fill={`url(#${uid}-front)`} opacity={isBamboo ? ".3" : isNeon ? ".95" : ".85"} />

      {/* Silhouette: dark TIR core with a bright polished lip. */}
      <path className="glass-outline-shadow" d={OUTER_OPEN} fill="none" stroke="#07222e" strokeWidth="3.6" strokeLinecap="round" opacity=".55" />
      <path
        className="glass-outline"
        d={OUTER_OPEN}
        fill="none"
        stroke={glassStroke}
        strokeWidth={isBamboo ? 2 : 2.2}
        strokeLinecap="round"
        filter={isNeon ? `url(#${uid}-glow)` : undefined}
      />
      {isCrystal && (
        <path className="crystal-rainbow" d={OUTER_OPEN} fill="none" stroke={`url(#${uid}-rainbow)`} strokeWidth="1.1" />
      )}
      {!isBamboo && <path className="glass-inner-edge" d="M18 23 L18 172 Q18 201 40 201 Q62 201 62 172 L62 23" />}
      {!isBamboo && (
        <g className="fresnel-edges">
          <path className="fresnel fresnel-left" d="M13.6 28 L13.6 170 Q13.6 199 26 205" />
          <path className="fresnel fresnel-right" d="M66.4 28 L66.4 170 Q66.4 199 54 205" />
        </g>
      )}

      {/* Window reflections: soft wide band + hot core + right fill. */}
      <g className="glass-highlights" transform={tiltShift ? `translate(${tiltShift} 0)` : undefined}>
        <rect
          className="glass-sheen glass-sheen-soft"
          x="21"
          y="32"
          width="9"
          height="132"
          rx="4.5"
          fill={`url(#${uid}-streak-soft)`}
          opacity={0.3 + streakBoost}
          filter={`url(#${uid}-soft)`}
        />
        <rect
          className="glass-sheen glass-sheen-wide"
          x="24.4"
          y="34"
          width="2.6"
          height="128"
          rx="1.3"
          fill={`url(#${uid}-streak)`}
          opacity={0.75 + streakBoost}
        />
        <rect
          className="glass-sheen glass-sheen-thin"
          x="55.4"
          y="44"
          width="2.1"
          height="118"
          rx="1.05"
          fill={`url(#${uid}-streak)`}
          opacity={0.42 + streakBoost}
        />
        {!isBamboo && <ellipse className="glass-glint-travel" cx="25.7" cy="30" rx="2.2" ry="7" fill="#ffffff" filter={`url(#${uid}-soft)`} />}
      </g>

      {!isBamboo && !isNeon && !isSunset && (
        <g className="condensation">
          {CONDENSATION.map((drop, index) => (
            <g key={index}>
              <circle cx={drop.cx} cy={drop.cy} r={drop.r} style={{ animationDelay: drop.delay }} />
              <circle cx={drop.cx - drop.r * 0.3} cy={drop.cy - drop.r * 0.35} r={drop.r * 0.3} fill="#ffffff" opacity=".75" />
            </g>
          ))}
        </g>
      )}

      {isCrystal && (
        <g>
          <g className="crystal-facets">
            <path d="M13 52 L27 68 L13 93 M67 39 L53 61 L67 83 M14 131 L29 147 L15 174 M66 123 L51 143 L64 168" />
            <path d="M23 187 L40 202 L57 186" />
            <path className="crystal-center-facet" d="M40 30 L40 188" />
          </g>
          <g className="crystal-twinkles">
            <path d="M25 48 v8 M21 52 h8" />
            <path d="M57 138 v7 M53.5 141.5 h7" />
          </g>
        </g>
      )}
      {isBamboo && (
        <g className="bamboo-nodes">
          {[66, 122, 176].map((y) => (
            <g key={y}>
              <path d={`M10.5 ${y} Q15 ${y + 3.5} 20.5 ${y + 2}`} />
              <path d={`M69.5 ${y} Q65 ${y + 3.5} 59.5 ${y + 2}`} />
              <path className="bamboo-ring-light" d={`M10.5 ${y - 1.6} Q15 ${y + 1.4} 20.5 ${y}`} />
              <path className="bamboo-ring-light" d={`M69.5 ${y - 1.6} Q65 ${y + 1.4} 59.5 ${y}`} />
            </g>
          ))}
          <path className="bamboo-grain" d="M14.5 24 Q13.5 90 15 160 M17.5 40 Q16.8 110 17.4 168 M62.5 40 Q63.2 110 62.6 168 M65.5 24 Q66.5 90 65 160" />
        </g>
      )}
      {isNeon && (
        <g>
          <path className="neon-core" d="M15 20 L15 172 Q15 203 40 203 Q65 203 65 172 L65 20" />
          <path className="neon-edge" d="M13.4 26 L13.4 170 Q13.4 200 26 205.4" />
          <path className="neon-edge" d="M66.6 26 L66.6 170 Q66.6 200 54 205.4" />
        </g>
      )}
      {isFrost && (
        <g>
          <g className="frost-fractals">
            <path d="M14 60 L24 70 M19 60 L19 72 M14 66 L24 64" />
            <path d="M56 110 L66 120 M61 110 L61 122 M56 116 L66 114" />
            <path d="M15 150 L25 160 M20 150 L20 162 M15 156 L25 154" />
          </g>
          <g className="frost-flakes">
            <path d="M28 44 v9 M23.5 48.5 h9 M25 45.5 l6 6 M31 45.5 l-6 6" />
            <path d="M54 168 v7 M50.5 171.5 h7" />
          </g>
        </g>
      )}
      {isSunset && (
        <g>
          <path className="sunset-band" d="M13 60 Q40 50 67 60" />
          <path className="sunset-band sunset-band-low" d="M13 150 Q40 140 67 150" />
          <g className="sunset-embers">
            <circle cx="26" cy="96" r="1.1" />
            <circle cx="52" cy="82" r="0.8" />
            <circle cx="45" cy="128" r="1" />
            <circle cx="31" cy="142" r="0.7" />
          </g>
        </g>
      )}

      {/* ---------------- Rim: thick rounded torus ---------------- */}
      <ellipse className="glass-rim-back" cx="40" cy="13.5" rx="23" ry="4.1" />
      <path className="rim-inner-back-glow" d="M20 12.6 Q40 8.2 60 12.6" />
      <ellipse
        className="glass-rim-outer"
        cx="40"
        cy="12.5"
        rx="29"
        ry="7"
        fill={isBamboo ? `url(#${uid}-wood)` : `url(#${uid}-rim)`}
        stroke={isBamboo ? "#7c5a30" : glassStroke}
      />
      <ellipse className="glass-rim-band" cx="40" cy="12.5" rx="26" ry="5.9" />
      <ellipse className="glass-rim-inner" cx="40" cy="12.8" rx="22.5" ry="3.9" />
      <path className="rim-inner-front-edge" d="M18.5 13.4 Q40 17.8 61.5 13.4" />
      <path className="rim-back-lip" d="M17.5 11.4 Q40 6.4 62.5 11.4" />
      <path className="rim-spark" d="M12.8 13.6 Q40 20.8 67.2 13.6" />
      <path className="rim-side-glint rim-side-left" d="M11.8 11.5 Q11.2 13.4 13 15.2" />
      <path className="rim-side-glint rim-side-right" d="M68.2 11.5 Q68.8 13.4 67 15.2" />
      <ellipse className="rim-dot" cx="22" cy="9.6" rx="3.4" ry="1.1" fill="#ffffff" opacity={isCrystal ? ".9" : ".7"} filter={`url(#${uid}-soft)`} />
      <ellipse className="rim-core" cx="21" cy="9.4" rx="1.4" ry="0.5" fill="#ffffff" opacity=".95" />

      {/* Animated lid: drops in with a bounce once the glass is sorted. */}
      {complete && bottomColor >= 0 && (
        <g className="tube-cap">
          <rect x="9" y="1" width="62" height="15" rx="5" fill={LIQUID_COLORS[bottomColor].dark} />
          <rect x="9" y="1" width="62" height="12" rx="5" fill={`url(#${uid}-liquid-${bottomColor})`} />
          <rect x="12" y="3" width="56" height="3" rx="1.5" fill="#ffffff" opacity=".45" />
          <rect x="9" y="13" width="62" height="3" rx="1.5" fill="#000d13" opacity=".35" />
          {[18, 26, 34, 42, 50, 58].map((x) => (
            <rect key={x} x={x} y="6" width="2" height="6" rx="1" fill="#000d13" opacity=".18" />
          ))}
        </g>
      )}
      {complete && (
        <g className="complete-sparkles" filter={isNeon ? `url(#${uid}-glow)` : undefined}>
          <path d="M70 35 v10 M65 40 h10" />
          <path d="M8 73 v7 M4.5 76.5 h7" />
        </g>
      )}
    </svg>
  );
}

// Only the two tubes involved in a pour need to rerender on each animation frame.
export default memo(TubeGraphic);
