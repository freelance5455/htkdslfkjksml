import React from 'react';
import { Smartphone, Download, HelpCircle, Code, Layers } from 'lucide-react';

interface TopNavProps {
  onBuildApk: () => void;
  onOpenHelp: () => void;
  onOpenInspector: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isBuilding: boolean;
  hasFiles: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  onBuildApk,
  onOpenHelp,
  onOpenInspector,
  activeTab,
  setActiveTab,
  isBuilding,
  hasFiles,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3.5 flex items-center justify-between gap-8">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20 font-black text-lg">
          <Smartphone className="w-5 h-5 text-slate-950" />
        </div>
        <div className="flex flex-col">
          <a href="/" className="text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0">
            APKForge Studio
          </a>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            ZIP & HTML to Android APK Compiler
          </span>
        </div>
      </div>

      {/* Zone 2: Clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('source')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'source' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Source & Files</span>
        </button>
        <button
          onClick={() => setActiveTab('branding')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'branding' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          <span>App Branding & Version</span>
        </button>
        <button
          onClick={() => setActiveTab('icon')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'icon' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          <span>Icon Studio</span>
        </button>
        <button
          onClick={() => setActiveTab('engine')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'engine' ? 'text-emerald-400 font-semibold' : ''
          }`}
        >
          <span>Android Permissions</span>
        </button>
        <button
          onClick={onOpenInspector}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-slate-400"
        >
          <Code className="w-4 h-4" />
          <span>Manifest Inspector</span>
        </button>
      </nav>

      {/* Zone 3: Primary action button + guide */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenHelp}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-lg transition-colors"
          title="Android Installation Guide"
          aria-label="Installation Guide"
        >
          <HelpCircle className="w-5 h-5" />
        </button>

        <button
          onClick={onBuildApk}
          disabled={isBuilding || !hasFiles}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 disabled:opacity-50 disabled:pointer-events-none rounded-lg shadow-sm shadow-emerald-500/20 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>{isBuilding ? 'Building APK...' : 'Build Signed APK'}</span>
        </button>
      </div>
    </header>
  );
};
