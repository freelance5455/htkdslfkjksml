import React, { useState } from 'react';
import { 
  Trophy, 
  Copy, 
  Check, 
  Plus, 
  RotateCcw, 
  Share2, 
  Flame, 
  MapPin, 
  Settings2, 
  Radio, 
  ShieldCheck, 
  AlertCircle
} from 'lucide-react';
import { MatchRoom, TeamScore, MapName, GameMode } from '../types';
import { FFWS_POINTS_SYSTEM } from '../data/freeFireData';
import { sounds } from '../utils/soundEffects';

interface TournamentPanelProps {
  roomConfig: MatchRoom;
  setRoomConfig: React.Dispatch<React.SetStateAction<MatchRoom>>;
  teams: TeamScore[];
  setTeams: React.Dispatch<React.SetStateAction<TeamScore[]>>;
}

export const TournamentPanel: React.FC<TournamentPanelProps> = ({
  roomConfig,
  setRoomConfig,
  teams,
  setTeams,
}) => {
  const [copiedRoom, setCopiedRoom] = useState(false);
  const [copiedBroadcast, setCopiedBroadcast] = useState(false);
  const [activeMatchTab, setActiveMatchTab] = useState<'match1' | 'match2' | 'overall'>('match1');
  const [isEditingRoom, setIsEditingRoom] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamTag, setNewTeamTag] = useState('');

  // Handle score updates
  const updateKills = (id: string, delta: number) => {
    sounds.playClick();
    setTeams(prev => prev.map(t => {
      if (t.id === id) {
        const newKills = Math.max(0, t.kills + delta);
        const killPoints = newKills;
        const totalPoints = t.placementPoints + killPoints;
        return {
          ...t,
          kills: newKills,
          killPoints,
          totalPoints
        };
      }
      return t;
    }));
  };

  const updatePlacement = (id: string, newRank: number) => {
    sounds.playClick();
    const rank = Math.min(12, Math.max(1, newRank));
    const placementPoints = FFWS_POINTS_SYSTEM[rank] ?? 0;
    setTeams(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          placementRank: rank,
          placementPoints,
          booyah: rank === 1,
          totalPoints: placementPoints + t.killPoints
        };
      }
      return t;
    }));
  };

  const setBooyah = (id: string) => {
    sounds.playBooyah();
    setTeams(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          booyah: true,
          placementRank: 1,
          placementPoints: 12,
          totalPoints: 12 + t.killPoints
        };
      }
      // If another team was 1, bump them down
      if (t.placementRank === 1 && t.id !== id) {
        return {
          ...t,
          booyah: false,
          placementRank: 2,
          placementPoints: 9,
          totalPoints: 9 + t.killPoints
        };
      }
      return t;
    }));
  };

  const handleAddTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;
    sounds.playClick();
    const newId = 'team-' + Date.now();
    const newTag = newTeamTag.trim() || newTeamName.slice(0, 4).toUpperCase();
    const newRank = Math.min(12, teams.length + 1);
    const placementPts = FFWS_POINTS_SYSTEM[newRank] || 0;

    const newTeam: TeamScore = {
      id: newId,
      teamName: newTeamName.trim().toUpperCase(),
      tag: newTag,
      kills: 0,
      placementRank: newRank,
      booyah: false,
      placementPoints: placementPts,
      killPoints: 0,
      totalPoints: placementPts,
      players: ['Player 1', 'Player 2', 'Player 3', 'Player 4']
    };

    setTeams(prev => [...prev, newTeam]);
    setNewTeamName('');
    setNewTeamTag('');
  };

  const sortedTeams = [...teams].sort((a, b) => {
    if (b.totalPoints !== a.totalPoints) {
      return b.totalPoints - a.totalPoints; // highest points first
    }
    if (b.killPoints !== a.killPoints) {
      return b.killPoints - a.killPoints; // tie breaker: most kills
    }
    return a.placementRank - b.placementRank;
  });

  const generateBroadcastText = () => {
    return `🔥 FREE FIRE ESPORTS SCRIMS / TOURNAMENT 🔥
━━━━━━━━━━━━━━━━━━━━━
🏆 Match: #${roomConfig.matchNumber} (${roomConfig.roomType})
🗺️ Map: ${roomConfig.map} | Mode: ${roomConfig.mode}
🔑 Room ID: ${roomConfig.roomId}
🔒 Password: ${roomConfig.roomPass}
⚙️ Settings: HP: ${roomConfig.defaultHp} | EP: ${roomConfig.ep} | Limited Ammo: ${roomConfig.limitedAmmo ? 'YES' : 'NO'}
📜 Rules: ${roomConfig.notes}
━━━━━━━━━━━━━━━━━━━━━
⚠️ Enter slots as per assigned guild tags. Emulators/cheats strictly prohibited.`;
  };

  const copyBroadcast = () => {
    navigator.clipboard.writeText(generateBroadcastText());
    setCopiedBroadcast(true);
    sounds.playClick();
    setTimeout(() => setCopiedBroadcast(false), 2000);
  };

  const copyRoomCreds = () => {
    navigator.clipboard.writeText(`Room ID: ${roomConfig.roomId} | Pass: ${roomConfig.roomPass}`);
    setCopiedRoom(true);
    sounds.playClick();
    setTimeout(() => setCopiedRoom(false), 2000);
  };

  const generatePointsSummary = () => {
    let summary = `🏆 FREE FIRE LEADERBOARD - MATCH #${roomConfig.matchNumber} 🏆\n`;
    summary += `Map: ${roomConfig.map} | System: Official FFWS Rules\n`;
    summary += `─────────────────────────────────────────\n`;
    sortedTeams.forEach((team, idx) => {
      const booyahBadge = team.booyah ? '👑 BOOYAH!' : '';
      summary += `#${idx + 1} [${team.tag}] ${team.teamName} - ${team.totalPoints} PTS (Pl: ${team.placementPoints} | Kills: ${team.kills}) ${booyahBadge}\n`;
    });
    navigator.clipboard.writeText(summary);
    sounds.playClick();
    alert('Leaderboard summary copied to clipboard!');
  };

  const mapsList: MapName[] = ['Bermuda', 'Purgatory', 'Kalahari', 'Alpine', 'Nexterra'];
  const modesList: GameMode[] = ['Battle Royale', 'Clash Squad (4v4)', 'Lone Wolf (1v1)'];

  return (
    <div className="space-y-6">
      {/* Top Scrim Room Distribution Bar */}
      <div className="bg-gradient-to-r from-[#121626] via-[#181c2f] to-[#121626] border border-orange-500/30 rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        {/* Background glow decoration */}
        <div className="absolute -right-16 -top-16 w-56 h-56 bg-orange-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-500/20 text-orange-400 border border-orange-500/30 font-rajdhani">
                ROOM CONTROL ROOM
              </span>
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Radio className="w-3.5 h-3.5 text-green-400 animate-pulse" /> Lobby Ready
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-heading text-white flex items-center gap-2">
              {roomConfig.roomType}: Match #{roomConfig.matchNumber}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-slate-300">
              <span className="flex items-center gap-1 text-amber-400 font-semibold">
                <MapPin className="w-4 h-4" /> {roomConfig.map}
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-300">{roomConfig.mode}</span>
              <span className="text-slate-600">•</span>
              <span className="text-emerald-400">HP: {roomConfig.defaultHp} / EP: {roomConfig.ep}</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-400">Limited Ammo: {roomConfig.limitedAmmo ? 'Yes' : 'No'}</span>
            </div>
          </div>

          {/* Credentials Display and Quick Copy */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
            <div className="flex items-center bg-[#090b12] border border-orange-500/40 rounded-xl px-4 py-2 gap-3 flex-1 lg:flex-initial">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">ROOM ID</div>
                <div className="text-base sm:text-lg font-mono font-bold text-orange-400 tracking-wider">
                  {roomConfig.roomId}
                </div>
              </div>
              <div className="w-[1px] h-8 bg-slate-800"></div>
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">PASS</div>
                <div className="text-base sm:text-lg font-mono font-bold text-amber-300">
                  {roomConfig.roomPass}
                </div>
              </div>
            </div>

            <button
              onClick={copyRoomCreds}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-[#1b2238] hover:bg-[#252f4c] text-orange-300 text-xs font-semibold rounded-xl border border-orange-500/30 transition-all cursor-pointer"
            >
              {copiedRoom ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedRoom ? 'Copied!' : 'Copy ID & Pass'}</span>
            </button>

            <button
              onClick={copyBroadcast}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-orange-600/30 transition-all cursor-pointer"
            >
              {copiedBroadcast ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedBroadcast ? 'Broadcast Copied!' : 'Broadcast to WhatsApp / Discord'}</span>
            </button>

            <button
              onClick={() => setIsEditingRoom(!isEditingRoom)}
              className="p-2.5 bg-[#1b2238] hover:bg-[#252f4c] text-slate-300 rounded-xl border border-slate-700 transition-colors cursor-pointer"
              title="Edit Room Settings"
            >
              <Settings2 className="w-4 h-4 text-slate-300" />
            </button>
          </div>
        </div>

        {/* Expandable Room Editor */}
        {isEditingRoom && (
          <div className="mt-5 pt-5 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Room ID</label>
              <input
                type="text"
                value={roomConfig.roomId}
                onChange={e => setRoomConfig(prev => ({ ...prev, roomId: e.target.value }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Room Password</label>
              <input
                type="text"
                value={roomConfig.roomPass}
                onChange={e => setRoomConfig(prev => ({ ...prev, roomPass: e.target.value }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Map</label>
              <select
                value={roomConfig.map}
                onChange={e => setRoomConfig(prev => ({ ...prev, map: e.target.value as MapName }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
              >
                {mapsList.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Game Mode</label>
              <select
                value={roomConfig.mode}
                onChange={e => setRoomConfig(prev => ({ ...prev, mode: e.target.value as GameMode }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
              >
                {modesList.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Match #</label>
              <input
                type="number"
                min={1}
                value={roomConfig.matchNumber}
                onChange={e => setRoomConfig(prev => ({ ...prev, matchNumber: Number(e.target.value) }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Limited Ammo</label>
              <button
                type="button"
                onClick={() => setRoomConfig(prev => ({ ...prev, limitedAmmo: !prev.limitedAmmo }))}
                className={`w-full py-2 rounded-lg font-bold border transition-colors ${
                  roomConfig.limitedAmmo 
                    ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300' 
                    : 'bg-red-950/70 border-red-500 text-red-300'
                }`}
              >
                {roomConfig.limitedAmmo ? 'Limited Ammo: ON' : 'Limited Ammo: NO (Unlimited)'}
              </button>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-slate-400 font-semibold mb-1">Tournament Rules Note</label>
              <input
                type="text"
                value={roomConfig.notes}
                onChange={e => setRoomConfig(prev => ({ ...prev, notes: e.target.value }))}
                className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* Official FFWS Points System Reference Banner */}
      <div className="bg-[#101422] border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-orange-400" />
          <span className="font-bold text-slate-200">Official FFWS Scoring Matrix:</span>
          <span className="text-slate-400 hidden sm:inline">1 Kill = 1 Point</span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 rounded font-bold">1st (Booyah): 12pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">2nd: 9pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">3rd: 8pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">4th: 7pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">5th: 6pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">6th: 5pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">7th-10th: 4-1pt</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-500 rounded">11th-12th: 0pt</span>
        </div>
      </div>

      {/* Leaderboard Management Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveMatchTab('match1')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeMatchTab === 'match1'
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/30'
                : 'bg-[#141828] text-slate-400 hover:text-white'
            }`}
          >
            Live Match #{roomConfig.matchNumber} Standings
          </button>
          <button
            onClick={() => setActiveMatchTab('overall')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeMatchTab === 'overall'
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/30'
                : 'bg-[#141828] text-slate-400 hover:text-white'
            }`}
          >
            Tournament Summary
          </button>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={generatePointsSummary}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#171d30] hover:bg-[#202842] text-xs font-bold text-amber-300 border border-amber-500/30 rounded-lg cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Export Scorecard</span>
          </button>

          <button
            onClick={() => {
              if (confirm('Reset scores for this match?')) {
                setTeams(prev => prev.map((t, idx) => {
                  const initialRank = idx + 1;
                  const pl = FFWS_POINTS_SYSTEM[initialRank] || 0;
                  return {
                    ...t,
                    kills: 0,
                    killPoints: 0,
                    placementRank: initialRank,
                    placementPoints: pl,
                    booyah: initialRank === 1,
                    totalPoints: pl
                  };
                }));
                sounds.playClick();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#171d30] hover:bg-[#202842] text-xs font-medium text-slate-400 hover:text-red-400 border border-slate-700 rounded-lg cursor-pointer"
            title="Reset Scores"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Live Standings Table */}
      <div className="bg-[#0f1322] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-[#161c2e] text-slate-300 border-b border-slate-800 font-heading tracking-wide uppercase text-[11px]">
              <tr>
                <th className="py-3 px-3 sm:px-4 text-center w-14">Rank</th>
                <th className="py-3 px-3 sm:px-4">Team / Roster</th>
                <th className="py-3 px-3 sm:px-4 text-center">Placement</th>
                <th className="py-3 px-3 sm:px-4 text-center">Place Pts</th>
                <th className="py-3 px-3 sm:px-4 text-center">Kills (1 pt)</th>
                <th className="py-3 px-3 sm:px-4 text-center font-bold text-orange-400">Total Pts</th>
                <th className="py-3 px-3 sm:px-4 text-center w-28">Booyah Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {sortedTeams.map((team, index) => {
                const isBooyah = team.booyah;
                const isTop3 = index < 3;
                return (
                  <tr
                    key={team.id}
                    className={`transition-colors hover:bg-[#151a2d] ${
                      isBooyah ? 'bg-orange-950/20 border-l-4 border-l-amber-500' : ''
                    }`}
                  >
                    {/* Rank Badge */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <div className="flex items-center justify-center">
                        {index === 0 ? (
                          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-yellow-400 to-amber-600 text-black font-extrabold flex items-center justify-center shadow-md shadow-yellow-500/20 font-rajdhani">
                            #1
                          </div>
                        ) : index === 1 ? (
                          <div className="w-7 h-7 rounded-lg bg-slate-300 text-black font-extrabold flex items-center justify-center font-rajdhani">
                            #2
                          </div>
                        ) : index === 2 ? (
                          <div className="w-7 h-7 rounded-lg bg-amber-700 text-white font-extrabold flex items-center justify-center font-rajdhani">
                            #3
                          </div>
                        ) : (
                          <span className="font-mono text-slate-400 font-bold">#{index + 1}</span>
                        )}
                      </div>
                    </td>

                    {/* Team Info */}
                    <td className="py-3 px-3 sm:px-4">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-[#1b2238] text-orange-400 border border-orange-500/20 font-mono text-[10px] rounded font-bold">
                          {team.tag}
                        </span>
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            {team.teamName}
                            {isBooyah && (
                              <span className="text-[10px] bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-black px-1.5 py-0.2 rounded-full uppercase tracking-tighter">
                                👑 Booyah
                              </span>
                            )}
                          </div>
                          {team.players && team.players.length > 0 && (
                            <div className="text-[11px] text-slate-400 hidden sm:block">
                              {team.players.join(' • ')}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Placement Rank Selector */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <select
                        value={team.placementRank}
                        onChange={e => updatePlacement(team.id, Number(e.target.value))}
                        className="bg-[#090b14] border border-slate-700 rounded px-2 py-1 text-slate-200 font-mono text-xs cursor-pointer focus:border-orange-500"
                      >
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(r => (
                          <option key={r} value={r}>
                            #{r} ({FFWS_POINTS_SYSTEM[r]} pts)
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Placement Points */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-bold text-slate-300">
                      {team.placementPoints}
                    </td>

                    {/* Kill Counter Stepper */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <div className="inline-flex items-center gap-1 bg-[#0a0d17] border border-slate-700/80 rounded-lg p-0.5">
                        <button
                          onClick={() => updateKills(team.id, -1)}
                          className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          -
                        </button>
                        <span className="w-8 text-center font-mono font-bold text-yellow-300">
                          {team.kills}
                        </span>
                        <button
                          onClick={() => updateKills(team.id, 1)}
                          className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </td>

                    {/* Total Points */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <span className="font-heading text-base sm:text-lg font-bold text-orange-400 font-mono">
                        {team.totalPoints}
                      </span>
                    </td>

                    {/* Booyah Button */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <button
                        onClick={() => setBooyah(team.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          isBooyah
                            ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-black shadow-md shadow-amber-500/30'
                            : 'bg-[#1a2034] hover:bg-orange-600/30 text-slate-300 hover:text-yellow-400 border border-slate-700/70'
                        }`}
                      >
                        {isBooyah ? '👑 BOOYAH!' : 'Set Booyah'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Team Inline Form */}
      <form onSubmit={handleAddTeam} className="bg-[#111524] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center gap-3">
        <div className="flex items-center gap-2 text-slate-400 text-xs sm:text-sm font-semibold whitespace-nowrap">
          <Plus className="w-4 h-4 text-orange-400" />
          <span>Add Registered Team:</span>
        </div>
        <input
          type="text"
          placeholder="e.g. GODLIKE ESPORTS"
          value={newTeamName}
          onChange={e => setNewTeamName(e.target.value)}
          className="bg-[#090b14] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 flex-1 focus:border-orange-500"
        />
        <input
          type="text"
          placeholder="Tag: GODL"
          value={newTeamTag}
          onChange={e => setNewTeamTag(e.target.value)}
          className="bg-[#090b14] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 w-28 uppercase focus:border-orange-500"
        />
        <button
          type="submit"
          className="w-full sm:w-auto px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
        >
          Add to Lobby
        </button>
      </form>
    </div>
  );
};
