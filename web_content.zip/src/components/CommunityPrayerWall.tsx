// JUHNKRIX MUSIKA - Community Prayer Wall Component
// Displays public prayer requests and praise reports in real-time. Users can 'Join in Prayer' by clicking an interactive 'Agree' button that logs their participation in the JM-WALLET.

import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Sparkles, 
  Send, 
  Users, 
  ShieldCheck, 
  Flame, 
  CheckCircle2, 
  Globe,
  MessageCircle,
  Clock
} from 'lucide-react';
import { cloudflareEventLogger } from '../lib/cloudflareEventLogger';

export interface PrayerRequestItem {
  id: string;
  author: string;
  content: string;
  category: 'Healing' | 'Financial Breakthrough' | 'Family Deliverance' | 'Spiritual Growth' | 'Global Revival';
  agreeCount: number;
  timestamp: string;
  agreedByMe?: boolean;
}

const PRAYER_STORAGE_KEY = 'jm_community_prayer_wall_v1';

const INITIAL_PRAYERS: PrayerRequestItem[] = [
  {
    id: 'praying-001',
    author: 'Sister Mary in London',
    content: 'Believing God for divine financial turnaround and complete healing for my household during this prophetic season.',
    category: 'Financial Breakthrough',
    agreeCount: 124,
    timestamp: '10 mins ago',
    agreedByMe: false
  },
  {
    id: 'praying-002',
    author: 'Brother David in Lagos',
    content: 'Join me in agreeing for supernatural breakthroughs in my career and unhindered propagation of the Gospel across nations.',
    category: 'Global Revival',
    agreeCount: 256,
    timestamp: '25 mins ago',
    agreedByMe: false
  },
  {
    id: 'praying-003',
    author: 'Anointed Believer in New York',
    content: 'Praying for restoration of peace, divine health, and overflowing grace for all 50 million JUHNKRIX MUSIKA miners.',
    category: 'Healing',
    agreeCount: 389,
    timestamp: '1 hour ago',
    agreedByMe: true
  }
];

interface CommunityPrayerWallProps {
  onJoinPrayerReward?: () => void;
}

export const CommunityPrayerWall: React.FC<CommunityPrayerWallProps> = ({ onJoinPrayerReward }) => {
  const [prayers, setPrayers] = useState<PrayerRequestItem[]>(() => {
    try {
      const stored = localStorage.getItem(PRAYER_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_PRAYERS;
  });

  const [newContent, setNewContent] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCategory, setNewCategory] = useState<PrayerRequestItem['category']>('Global Revival');
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(PRAYER_STORAGE_KEY, JSON.stringify(prayers));
    } catch {}
  }, [prayers]);

  const handleAgreeInPrayer = async (id: string) => {
    setPrayers(prev => prev.map(p => {
      if (p.id === id) {
        const nextAgreed = !p.agreedByMe;
        const nextCount = nextAgreed ? p.agreeCount + 1 : p.agreeCount - 1;
        return {
          ...p,
          agreeCount: Math.max(0, nextCount),
          agreedByMe: nextAgreed
        };
      }
      return p;
    }));

    // Log telemetry and trigger JM-WALLET reward credit
    await cloudflareEventLogger.logAndSignEvent('PRAYER_AGREE', id);
    if (onJoinPrayerReward) {
      onJoinPrayerReward();
    }

    setNotice('🙏 Amen! Your prayer agreement has been cryptographically logged in your JM-WALLET (+0.0050 JMC Prophetic Bonus).');
    setTimeout(() => setNotice(null), 5000);
  };

  const handlePostPrayerRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;

    const item: PrayerRequestItem = {
      id: `praying-${Date.now()}`,
      author: newAuthor.trim() ? newAuthor.trim() : 'Anonymous Believer',
      content: newContent.trim(),
      category: newCategory,
      agreeCount: 1,
      timestamp: 'Just now',
      agreedByMe: true
    };

    setPrayers(prev => [item, ...prev]);
    setNewContent('');
    setNewAuthor('');
    setNotice('✨ Your prayer request has been published to the global sanctuary network.');
    setTimeout(() => setNotice(null), 4000);
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/60 border-2 border-indigo-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-amber-100">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-indigo-500/30">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/40 text-[10px] font-mono font-bold">
            <Users className="w-3.5 h-3.5 text-indigo-400" />
            <span>GLOBAL COMMUNITY PRAYER WALL</span>
          </div>
          <h2 className="text-2xl font-bold font-serif text-white">Agreeing Together in Prayer</h2>
          <p className="text-xs text-slate-300">
            Submit your prayer requests or join in agreeing with believers worldwide. Every &quot;Agree in Prayer&quot; click securely logs participation in your JM-WALLET.
          </p>
        </div>

        <div className="bg-slate-950 p-3 rounded-2xl border border-indigo-500/30 font-mono text-xs text-right space-y-1 shrink-0">
          <div className="text-indigo-300 font-bold flex items-center justify-end space-x-1">
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span>Global Sanctuary Network</span>
          </div>
          <div className="text-slate-400">Active Intercessors: <strong className="text-white">50,000,000+</strong></div>
        </div>
      </div>

      {notice && (
        <div className="p-4 rounded-2xl bg-emerald-950/90 border border-emerald-400 text-emerald-200 text-xs sm:text-sm flex items-center space-x-3 shadow-xl">
          <Sparkles className="w-5 h-5 text-yellow-300 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Post Prayer Request Form */}
      <form onSubmit={handlePostPrayerRequest} className="bg-slate-950/90 p-5 rounded-2xl border border-indigo-500/30 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider font-mono">Submit Prayer Request or Praise Report</span>
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1">
            {(['Healing', 'Financial Breakthrough', 'Family Deliverance', 'Spiritual Growth', 'Global Revival'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setNewCategory(cat)}
                className={`px-2.5 py-1 rounded-xl text-[10px] font-bold transition-all whitespace-nowrap font-mono ${
                  newCategory === cat
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-indigo-200 border border-indigo-500/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="text"
            placeholder="Your Name or Location (Optional)..."
            value={newAuthor}
            onChange={(e) => setNewAuthor(e.target.value)}
            className="bg-slate-900 border border-indigo-500/30 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-400"
          />
          <div className="sm:col-span-2 flex gap-2">
            <input
              type="text"
              required
              placeholder="Type your prayer request here..."
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              className="w-full bg-slate-900 border border-indigo-500/30 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-400"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all shrink-0 flex items-center space-x-1.5 font-mono"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Share Request</span>
            </button>
          </div>
        </div>
      </form>

      {/* Prayers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {prayers.map((prayer) => (
          <div
            key={prayer.id}
            className={`bg-slate-900/90 border-2 rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-xl transition-all ${
              prayer.agreedByMe ? 'border-indigo-500/60 shadow-indigo-500/10' : 'border-indigo-500/20'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  {prayer.category}
                </span>
                <span className="text-[10px] font-mono text-slate-400 flex items-center space-x-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span>{prayer.timestamp}</span>
                </span>
              </div>

              <p className="text-sm text-slate-200 leading-relaxed font-serif">
                &quot;{prayer.content}&quot;
              </p>

              <span className="text-xs font-mono text-amber-300 block">
                — {prayer.author}
              </span>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 flex items-center space-x-1">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                <span><strong>{prayer.agreeCount}</strong> Believers Agreeing</span>
              </span>

              <button
                onClick={() => handleAgreeInPrayer(prayer.id)}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center space-x-2 transition-all cursor-pointer shadow-lg ${
                  prayer.agreedByMe
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${prayer.agreedByMe ? 'fill-white' : ''}`} />
                <span>{prayer.agreedByMe ? 'Agreed in Prayer ✓' : 'Agree in Prayer'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
