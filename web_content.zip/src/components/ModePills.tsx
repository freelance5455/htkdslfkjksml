import React from 'react';
import { Calculator, Sparkles, CreditCard, Compass, ArrowLeftRight } from 'lucide-react';
import { audioService } from '../services/audioService';

export type AppMode = 'calc' | 'ai' | 'finance' | 'formula' | 'units';

interface ModePillsProps {
  currentMode: AppMode;
  onChangeMode: (mode: AppMode) => void;
}

const MODES: Array<{ id: AppMode; label: string; icon: React.ReactNode; badge?: string }> = [
  { id: 'calc', label: 'Calc', icon: <Calculator className="w-3.5 h-3.5" /> },
  { id: 'ai', label: 'AI Solver', icon: <Sparkles className="w-3.5 h-3.5" />, badge: 'VIP' },
  { id: 'finance', label: 'Finance', icon: <CreditCard className="w-3.5 h-3.5" /> },
  { id: 'formula', label: 'Formulas', icon: <Compass className="w-3.5 h-3.5" /> },
  { id: 'units', label: 'Units', icon: <ArrowLeftRight className="w-3.5 h-3.5" /> },
];

export const ModePills: React.FC<ModePillsProps> = ({ currentMode, onChangeMode }) => {
  return (
    <div className="w-full bg-[#0a0c12]/90 border-b border-amber-500/15 px-3 py-2 overflow-x-auto scrollbar-none z-10">
      <div className="flex items-center gap-1.5 min-w-max">
        {MODES.map((mode) => {
          const isActive = currentMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => {
                audioService.playKeyClick();
                onChangeMode(mode.id);
              }}
              className={`relative px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 flex items-center gap-1.5 select-none ${
                isActive
                  ? 'bg-gradient-to-r from-amber-500/25 via-amber-400/20 to-amber-500/25 text-amber-200 border border-amber-400/50 shadow-[0_0_15px_rgba(245,158,11,0.25)] font-semibold'
                  : 'bg-zinc-900/60 hover:bg-zinc-800/80 text-zinc-400 hover:text-zinc-200 border border-zinc-800/80'
              }`}
            >
              <span className={isActive ? 'text-amber-400' : 'text-zinc-500'}>
                {mode.icon}
              </span>
              <span>{mode.label}</span>
              {mode.badge && (
                <span
                  className={`text-[9px] px-1 py-0.2 rounded font-mono font-bold ${
                    isActive
                      ? 'bg-amber-400 text-black'
                      : 'bg-zinc-800 text-amber-400/80 border border-amber-500/30'
                  }`}
                >
                  {mode.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
