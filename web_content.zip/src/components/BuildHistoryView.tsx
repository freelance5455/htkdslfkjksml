import { useMemo, useState } from 'react';
import { Download, FolderArchive, Search, Trash2 } from 'lucide-react';
import type { BuildArtifactSummary, SourceMode } from '../types/apk';

interface BuildHistoryViewProps {
  builds: BuildArtifactSummary[];
  onStartNewBuild: () => void;
  onClearHistory: () => void;
}

export function BuildHistoryView({
  builds,
  onStartNewBuild,
  onClearHistory,
}: BuildHistoryViewProps) {
  const [query, setQuery] = useState('');
  const [modeFilter, setModeFilter] = useState<'all' | SourceMode>('all');

  const filtered = useMemo(() => {
    return builds.filter((b) => {
      if (modeFilter !== 'all' && b.sourceMode !== modeFilter) return false;
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return (
        b.appName.toLowerCase().includes(q) ||
        b.packageId.toLowerCase().includes(q) ||
        b.sourceTarget.toLowerCase().includes(q)
      );
    });
  }, [builds, query, modeFilter]);

  if (builds.length === 0) {
    return (
      <section className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-4">
          <FolderArchive className="w-5 h-5 text-slate-600" />
        </div>
        <h2 className="text-lg font-display font-semibold text-slate-900">
          No APK builds compiled yet
        </h2>
        <p className="text-sm text-slate-600 max-w-md mx-auto mt-2">
          Configure a website URL or upload an HTML bundle in the Builder, then compile your first signed Android APK package.
        </p>
        <button
          type="button"
          onClick={onStartNewBuild}
          className="mt-6 px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors whitespace-nowrap"
        >
          Open APK Builder
        </button>
      </section>
    );
  }

  return (
    <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-display font-semibold text-slate-900">
            Compiled Android Packages
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
            {builds.length} build{builds.length === 1 ? '' : 's'} generated this session
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter by name or package ID..."
              className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 w-56"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['all', 'url', 'html'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setModeFilter(mode)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  modeFilter === mode
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {mode === 'all' ? 'All' : mode === 'url' ? 'Website URL' : 'HTML Bundle'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={onClearHistory}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-red-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
              <th className="py-2.5 px-6">Application</th>
              <th className="py-2.5 px-4">Package ID</th>
              <th className="py-2.5 px-4">Source</th>
              <th className="py-2.5 px-4 text-right">APK Size</th>
              <th className="py-2.5 px-4">SHA-256</th>
              <th className="py-2.5 px-6 text-right">Artifacts</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {filtered.map((build) => (
              <tr key={build.id} className="hover:bg-slate-50/80 transition-colors">
                <td className="py-3 px-6">
                  <div className="font-medium text-slate-900">{build.appName}</div>
                  <div className="text-slate-500 tabular-nums mt-0.5">
                    v{build.versionName} ({build.versionCode}) ·{' '}
                    {new Date(build.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                    {build.builtOffline ? ' · Offline Build' : ''}
                  </div>
                </td>
                <td className="py-3 px-4 font-mono text-slate-700">{build.packageId}</td>
                <td className="py-3 px-4 text-slate-600 max-w-[220px] truncate">
                  {build.sourceMode === 'url'
                    ? 'URL'
                    : build.sourceMode === 'code'
                      ? 'HTML Code'
                      : 'HTML'}{' '}
                  · {build.sourceTarget}
                </td>
                <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                  {(build.apkSizeBytes / 1024).toFixed(1)} KB
                </td>
                <td className="py-3 px-4 font-mono tabular-nums text-slate-500">
                  {build.sha256.slice(0, 12)}...
                </td>
                <td className="py-3 px-6 text-right">
                  <div className="inline-flex items-center gap-2">
                    <a
                      href={build.apkBlobUrl || `/api/builds/${build.id}/apk`}
                      download={`${build.appName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'app'}-v${build.versionName}.apk`}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 font-medium text-white bg-emerald-600 rounded-md hover:bg-emerald-700 transition-colors whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5" />
                      .APK
                    </a>
                    <a
                      href={build.gradleBlobUrl || `/api/builds/${build.id}/gradle`}
                      download={`${build.appName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'app'}-android-studio.zip`}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap"
                    >
                      Gradle .ZIP
                    </a>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
