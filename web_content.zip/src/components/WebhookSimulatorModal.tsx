import React, { useState } from 'react';
import { X, Send, Mail, MessageSquare, Sparkles, CheckCircle2 } from 'lucide-react';
import { Mailbox, PhoneNumber } from '../types/index.ts';

interface WebhookSimulatorModalProps {
  mailboxes: Mailbox[];
  phoneNumbers: PhoneNumber[];
  onClose: () => void;
  onSendEmail: (params: {
    toAddress: string;
    fromAddress: string;
    fromName: string;
    subject: string;
    htmlBody: string;
    plainText: string;
  }) => void;
  onSendSms: (phoneNumberId: string, fromNumber: string, senderName: string, text: string) => void;
}

export const WebhookSimulatorModal: React.FC<WebhookSimulatorModalProps> = ({
  mailboxes,
  phoneNumbers,
  onClose,
  onSendEmail,
  onSendSms,
}) => {
  const [tab, setTab] = useState<'email' | 'sms'>('email');
  const [sentSuccess, setSentSuccess] = useState(false);

  // Email state
  const [selectedMailboxAddress, setSelectedMailboxAddress] = useState(mailboxes[0]?.address || '');
  const [emailPreset, setEmailPreset] = useState<'custom' | 'instagram' | 'telegram' | 'facebook' | 'github'>('instagram');
  const [fromName, setFromName] = useState('Instagram Security');
  const [fromAddress, setFromAddress] = useState('security@mail.instagram.com');
  const [code, setCode] = useState('819302');
  const [subject, setSubject] = useState('819302 is your Instagram verification code');

  // SMS state
  const [selectedNumberId, setSelectedNumberId] = useState(phoneNumbers[0]?.id || '');
  const [smsPreset, setSmsPreset] = useState<'telegram' | 'whatsapp' | 'uber' | 'custom'>('telegram');
  const [smsSender, setSmsSender] = useState('Telegram');
  const [smsFromNumber, setSmsFromNumber] = useState('+1 (800) 555-0199');
  const [smsCode, setSmsCode] = useState('491028');
  const [smsText, setSmsText] = useState('Your Telegram verification code is 491028. Never give this code to anyone.');

  const handleSelectEmailPreset = (preset: 'instagram' | 'telegram' | 'facebook' | 'github' | 'custom') => {
    setEmailPreset(preset);
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    setCode(newCode);

    if (preset === 'instagram') {
      setFromName('Instagram Security');
      setFromAddress('security@mail.instagram.com');
      setSubject(`${newCode} is your Instagram verification code`);
    } else if (preset === 'telegram') {
      setFromName('Telegram Notification');
      setFromAddress('login@telegram.org');
      setSubject(`Telegram login code: ${newCode}`);
    } else if (preset === 'facebook') {
      setFromName('Facebook Security');
      setFromAddress('security@facebookmail.com');
      setSubject(`${newCode} is your Facebook confirmation code`);
    } else if (preset === 'github') {
      setFromName('GitHub Security');
      setFromAddress('security@github.com');
      setSubject(`GitHub verification: Your code is ${newCode}`);
    }
  };

  const handleSelectSmsPreset = (preset: 'telegram' | 'whatsapp' | 'uber' | 'custom') => {
    setSmsPreset(preset);
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    setSmsCode(newCode);

    if (preset === 'telegram') {
      setSmsSender('Telegram');
      setSmsFromNumber('+1 (800) 555-0199');
      setSmsText(`Telegram code: ${newCode}. You can also use this link to log in: https://t.me/login/${newCode}`);
    } else if (preset === 'whatsapp') {
      setSmsSender('WhatsApp');
      setSmsFromNumber('+1 (650) 555-0142');
      setSmsText(`Your WhatsApp code is ${newCode}. Do not share this code.`);
    } else if (preset === 'uber') {
      setSmsSender('Uber');
      setSmsFromNumber('+1 (800) 555-0199');
      setSmsText(`Your Uber verification code is ${newCode}. Valid for 10 minutes.`);
    }
  };

  const handleDispatchEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMailboxAddress) return;

    const htmlBody = `<div style="font-family:sans-serif;padding:20px;color:#0f172a;max-width:500px;margin:0 auto;border:1px solid #e2e8f0;border-radius:12px;">
      <h2 style="color:#1e3a8a;margin-bottom:12px;">${fromName}</h2>
      <p style="font-size:14px;color:#334155;">Hello, please use the following one-time verification code to verify your account:</p>
      <div style="background:#eff6ff;border:2px dashed #3b82f6;padding:16px;margin:18px 0;border-radius:8px;text-align:center;">
        <span style="font-size:32px;font-weight:bold;letter-spacing:6px;color:#1d4ed8;font-family:monospace;">${code}</span>
      </div>
      <p style="color:#64748b;font-size:12px;">This code will expire in 10 minutes. If you did not request this, please disregard.</p>
    </div>`;

    onSendEmail({
      toAddress: selectedMailboxAddress,
      fromAddress,
      fromName,
      subject,
      htmlBody,
      plainText: `Hi! Your ${fromName} verification code is ${code}. Expires in 10 minutes.`,
    });

    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 1200);
  };

  const handleDispatchSms = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedNumberId) return;

    onSendSms(selectedNumberId, smsFromNumber, smsSender, smsText);

    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mb-4">
          <Send className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 mb-1">Instant Verification Test Simulator</h3>
        <p className="text-xs text-slate-500 mb-5">
          Simulate incoming emails and SMS verification codes to verify real-time OTP detection, sound, and 1-tap copy.
        </p>

        {sentSuccess ? (
          <div className="p-8 text-center bg-blue-50 rounded-2xl border border-blue-200">
            <CheckCircle2 className="w-12 h-12 text-blue-600 mx-auto mb-2 animate-bounce" />
            <h4 className="text-base font-bold text-slate-900">Verification Code Dispatched!</h4>
            <p className="text-xs text-slate-600 mt-1">Check your inbox or active phone lines now.</p>
          </div>
        ) : (
          <>
            {/* TABS */}
            <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-5">
              <button
                type="button"
                onClick={() => setTab('email')}
                className={`py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  tab === 'email' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Simulate Inbound Email</span>
              </button>
              <button
                type="button"
                onClick={() => setTab('sms')}
                className={`py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  tab === 'sms' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Simulate Inbound SMS</span>
              </button>
            </div>

            {tab === 'email' ? (
              <form onSubmit={handleDispatchEmail} className="space-y-4">
                {/* PRESETS */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>Quick App Presets</span>
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { id: 'instagram', label: 'Instagram' },
                      { id: 'telegram', label: 'Telegram' },
                      { id: 'facebook', label: 'Facebook' },
                      { id: 'github', label: 'GitHub' },
                    ].map((p) => (
                      <button
                        type="button"
                        key={p.id}
                        onClick={() => handleSelectEmailPreset(p.id as any)}
                        className={`p-2 rounded-xl text-xs font-bold border transition-all text-center ${
                          emailPreset === p.id
                            ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Email Address</label>
                  <input
                    type="text"
                    value={selectedMailboxAddress}
                    onChange={(e) => setSelectedMailboxAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">From Sender</label>
                    <input
                      type="text"
                      value={fromName}
                      onChange={(e) => setFromName(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Verification Code</label>
                    <input
                      type="text"
                      value={code}
                      onChange={(e) => {
                        setCode(e.target.value);
                        setSubject(`${fromName}: Your verification code is ${e.target.value}`);
                      }}
                      className="w-full bg-blue-50 border border-blue-300 font-mono font-bold text-blue-700 rounded-xl px-3.5 py-2 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-md shadow-blue-600/20 active:scale-98 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Test Email to Inbox</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleDispatchSms} className="space-y-4">
                {/* PRESETS */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>Quick SMS Presets</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'telegram', label: 'Telegram' },
                      { id: 'whatsapp', label: 'WhatsApp' },
                      { id: 'uber', label: 'Uber' },
                    ].map((p) => (
                      <button
                        type="button"
                        key={p.id}
                        onClick={() => handleSelectSmsPreset(p.id as any)}
                        className={`p-2 rounded-xl text-xs font-bold border transition-all text-center ${
                          smsPreset === p.id
                            ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Select Phone Line</label>
                  {phoneNumbers.length === 0 ? (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-800">
                      No active rented phone lines. Rent a line first from the Numbers tab!
                    </div>
                  ) : (
                    <select
                      value={selectedNumberId}
                      onChange={(e) => setSelectedNumberId(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-800"
                    >
                      {phoneNumbers.map((n) => (
                        <option key={n.id} value={n.id}>
                          {n.flag} {n.number} ({n.countryName})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">SMS Message Body</label>
                  <textarea
                    value={smsText}
                    onChange={(e) => setSmsText(e.target.value)}
                    rows={3}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900"
                  />
                </div>

                <button
                  type="submit"
                  disabled={phoneNumbers.length === 0}
                  className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-md shadow-blue-600/20 active:scale-98 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Test SMS</span>
                </button>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
};
