import React, { useState } from 'react';
import { UserProfile } from '../types';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';
import { STORAGE_KEY, fileToBase64, contactDeveloper } from '../utils/helpers';
import { playAppSound } from '../utils/audio';
import { VipName } from './VipName';
import {
  Camera,
  Edit2,
  Check,
  X,
  Lock,
  Palette,
  Bell,
  Shield,
  PhoneCall,
  LogOut,
  Copy,
  ChevronLeft,
  Crown,
  Eye,
  Trash2,
  Share2,
  Key,
  Download
} from 'lucide-react';

interface WhatsAppProfileSettingsProps {
  currentUser: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  onOpenWallpaperModal: () => void;
  onOpenVipModal: () => void;
  onOpenInstallModal?: () => void;
  onLogout: () => void;
  onToast: (msg: string) => void;
}

const WHATSAPP_STATUS_PRESETS = [
  'متاح 🟢',
  'مشغول 🔴',
  'في العمل 💼',
  'في النادي الملكي 👑',
  'عالم عاصف الفاخر ✨',
  'نائم 🌙',
  'لا يمكنني الرد الآن'
];

export const WhatsAppProfileSettings: React.FC<WhatsAppProfileSettingsProps> = ({
  currentUser,
  onUpdateUser,
  onOpenWallpaperModal,
  onOpenVipModal,
  onOpenInstallModal,
  onLogout,
  onToast
}) => {
  // Edit states
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(currentUser.name);

  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [statusInput, setStatusInput] = useState(currentUser.statusText || 'متاح 🟢');

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const [showBlockedModal, setShowBlockedModal] = useState(false);
  const [showAvatarViewer, setShowAvatarViewer] = useState(false);

  // Settings toggles
  const [soundEnabled, setSoundEnabled] = useState(currentUser.soundEnabled !== false);
  const [privacyLastSeen, setPrivacyLastSeen] = useState<'everyone' | 'nobody'>(
    currentUser.privacyLastSeen || 'everyone'
  );

  // Save Name
  const handleSaveName = async () => {
    const val = nameInput.trim();
    if (!val) return;
    try {
      const updated = { ...currentUser, name: val };
      await setDoc(doc(db, 'users', currentUser.id), { name: val }, { merge: true });
      onUpdateUser(updated);
      setIsEditingName(false);
      playAppSound('click');
      onToast('تم تحديث الاسم الشخصي بنجاح ✦');
    } catch {
      onToast('تعذر حفظ الاسم');
    }
  };

  // Save Status
  const handleSaveStatus = async (newVal?: string) => {
    const val = (newVal !== undefined ? newVal : statusInput).trim();
    try {
      const updated = { ...currentUser, statusText: val };
      await setDoc(doc(db, 'users', currentUser.id), { statusText: val }, { merge: true });
      onUpdateUser(updated);
      setStatusInput(val);
      setIsEditingStatus(false);
      playAppSound('click');
      onToast('تم تحديث الحالة الشخصية ✦');
    } catch {
      onToast('تعذر حفظ الحالة');
    }
  };

  // Upload Avatar
  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onToast('جارِ رفع وحفظ الصورة الشخصية...');
    try {
      const base64 = await fileToBase64(file);
      const updated = { ...currentUser, avatar: base64 };
      await setDoc(doc(db, 'users', currentUser.id), { avatar: base64 }, { merge: true });
      onUpdateUser(updated);
      playAppSound('vip');
      onToast('تم تحديث الصورة الشخصية بنجاح 👑');
    } catch {
      onToast('حدث خطأ أثناء معالجة الصورة');
    }
  };

  // Remove Avatar
  const handleRemoveAvatar = async () => {
    try {
      const updated = { ...currentUser, avatar: '' };
      await setDoc(doc(db, 'users', currentUser.id), { avatar: '' }, { merge: true });
      onUpdateUser(updated);
      setShowAvatarViewer(false);
      playAppSound('click');
      onToast('تمت إزالة الصورة الشخصية');
    } catch {
      onToast('تعذر إزالة الصورة');
    }
  };

  // Toggle Sound
  const handleToggleSound = async () => {
    const nextVal = !soundEnabled;
    setSoundEnabled(nextVal);
    const updated = { ...currentUser, soundEnabled: nextVal };
    await setDoc(doc(db, 'users', currentUser.id), { soundEnabled: nextVal }, { merge: true });
    onUpdateUser(updated);
    onToast(nextVal ? 'تم تفعيل أصوات التطبيق 🔔' : 'تم كتم أصوات التطبيق 🔕');
  };

  // Toggle Privacy Last Seen
  const handleToggleLastSeen = async () => {
    const nextVal: 'everyone' | 'nobody' = privacyLastSeen === 'everyone' ? 'nobody' : 'everyone';
    setPrivacyLastSeen(nextVal);
    const updated = { ...currentUser, privacyLastSeen: nextVal };
    await setDoc(doc(db, 'users', currentUser.id), { privacyLastSeen: nextVal }, { merge: true });
    onUpdateUser(updated);
    onToast(nextVal === 'everyone' ? 'آخر ظهور مرئي للجميع' : 'تم إخفاء آخر ظهور عن الجميع 🔒');
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (oldPassword !== currentUser.pass) {
      onToast('كلمة المرور الحالية غير صحيحة');
      return;
    }
    if (newPassword.length < 4) {
      onToast('كلمة المرور الجديدة يجب أن تكون 4 خانات على الأقل');
      return;
    }

    try {
      const updated = { ...currentUser, pass: newPassword };
      await setDoc(doc(db, 'users', currentUser.id), { pass: newPassword }, { merge: true });
      onUpdateUser(updated);
      setShowPasswordModal(false);
      setOldPassword('');
      setNewPassword('');
      playAppSound('click');
      onToast('تم تغيير كلمة المرور بنجاح 🔐');
    } catch {
      onToast('حدث خطأ أثناء تغيير كلمة المرور');
    }
  };

  // Unblock user
  const handleUnblockUser = async (targetId: string) => {
    const list = (currentUser.blockedUsers || []).filter((id) => id !== targetId);
    const updated = { ...currentUser, blockedUsers: list };
    await setDoc(doc(db, 'users', currentUser.id), { blockedUsers: list }, { merge: true });
    onUpdateUser(updated);
    playAppSound('click');
    onToast('تم إلغاء حظر المستخدم');
  };

  const inviteLink = `${window.location.origin}${window.location.pathname}?ref=${currentUser.id}`;

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* 1. Header Profile Card (WhatsApp Style) */}
      <div className="glass-panel rounded-3xl p-5 border border-white/10 shadow-xl text-center relative overflow-hidden">
        {/* Avatar with Camera badge */}
        <div className="relative w-28 h-28 mx-auto mb-3">
          <div
            onClick={() => setShowAvatarViewer(true)}
            className="w-full h-full rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-4xl overflow-hidden border-3 border-[#25d366] shadow-xl cursor-pointer hover:opacity-90 transition"
          >
            {currentUser.avatar ? (
              <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
            ) : (
              (currentUser.name[0] || 'A').toUpperCase()
            )}
          </div>
          <label className="absolute bottom-0 right-0 bg-[#25d366] hover:bg-[#20ba59] text-black p-2 rounded-full cursor-pointer shadow-lg hover:scale-105 transition">
            <Camera className="w-4 h-4" />
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleAvatarChange}
            />
          </label>
        </div>

        {/* Name with inline edit */}
        <div className="mb-1">
          {isEditingName ? (
            <div className="flex items-center justify-center gap-2 max-w-xs mx-auto">
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                className="glass-input rounded-xl px-3 py-1.5 text-sm text-white font-bold outline-none text-center"
                autoFocus
              />
              <button
                onClick={handleSaveName}
                className="p-2 rounded-xl bg-[#25d366] text-black hover:bg-[#20ba59]"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setIsEditingName(false);
                  setNameInput(currentUser.name);
                }}
                className="p-2 rounded-xl bg-white/10 text-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2">
              <VipName
                name={currentUser.name}
                vipLevel={currentUser.vipLevel}
                isFounder={currentUser.id === 'ASEF-777777'}
                className="text-lg font-black text-white"
              />
              <button
                onClick={() => setIsEditingName(true)}
                className="p-1 rounded-lg text-gray-400 hover:text-white transition"
                title="تعديل الاسم"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Status / About with inline edit */}
        <div className="mb-3">
          {isEditingStatus ? (
            <div className="max-w-sm mx-auto space-y-2">
              <div className="flex items-center justify-center gap-2">
                <input
                  type="text"
                  value={statusInput}
                  onChange={(e) => setStatusInput(e.target.value)}
                  placeholder="اكتب حالتك..."
                  className="glass-input rounded-xl px-3 py-1.5 text-xs text-white outline-none text-center flex-1"
                  autoFocus
                />
                <button
                  onClick={() => handleSaveStatus()}
                  className="p-2 rounded-xl bg-[#25d366] text-black"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    setIsEditingStatus(false);
                    setStatusInput(currentUser.statusText || '');
                  }}
                  className="p-2 rounded-xl bg-white/10 text-gray-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Quick WhatsApp Presets */}
              <div className="flex flex-wrap gap-1.5 justify-center pt-1">
                {WHATSAPP_STATUS_PRESETS.map((pst) => (
                  <button
                    key={pst}
                    onClick={() => handleSaveStatus(pst)}
                    className="text-[10px] px-2.5 py-1 rounded-full bg-white/10 hover:bg-[#25d366]/20 text-gray-300 hover:text-[#25d366] transition border border-white/5"
                  >
                    {pst}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-1.5 text-xs text-gray-300">
              <span className="italic">"{currentUser.statusText || 'متاح 🟢'}"</span>
              <button
                onClick={() => setIsEditingStatus(true)}
                className="p-1 rounded-lg text-gray-400 hover:text-white transition"
                title="تعديل الحالة"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Account IDs & Share Info */}
        <div className="bg-black/40 rounded-2xl p-3 border border-white/5 max-w-sm mx-auto space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-400 font-medium">معرّف ASEF الملكي:</span>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-[#25d366]">{currentUser.id}</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(currentUser.id);
                  playAppSound('click');
                  onToast('تم نسخ المعرّف 📋');
                }}
                className="text-gray-400 hover:text-white"
                title="نسخ"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-400 font-medium">اسم المستخدم (اليوزر):</span>
            <span className="font-bold text-gray-200">@{currentUser.username || 'user'}</span>
          </div>
        </div>

        {/* Badges Bar */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-3 pt-3 border-t border-white/10">
          <span className="px-3 py-1 rounded-full bg-white/10 text-white text-xs font-bold border border-white/10">
            {currentUser.rank || 'عضو ذهبي 👑'}
          </span>
          <button
            onClick={onOpenVipModal}
            className="px-3 py-1 rounded-full bg-[#ffd700]/15 text-[#ffd700] hover:bg-[#ffd700]/25 text-xs font-bold border border-[#ffd700]/30 transition flex items-center gap-1 cursor-pointer"
          >
            <Crown className="w-3.5 h-3.5" />
            <span>⭐ النقاط: {currentUser.points || 0}</span>
          </button>
          <button
            onClick={onOpenVipModal}
            className="px-3 py-1 rounded-full bg-[#25d366]/15 text-[#25d366] hover:bg-[#25d366]/25 text-xs font-bold border border-[#25d366]/30 transition cursor-pointer"
          >
            VIP {currentUser.vipLevel || 0}
          </button>
        </div>
      </div>

      {/* 2. VIP Recharge & Upgrade Center (شحن الـ VIP في صفحة حسابي) */}
      <div className="glass-panel rounded-3xl p-4 sm:p-5 border border-[#ffd700]/30 shadow-xl bg-gradient-to-b from-[#ffd700]/10 via-black/40 to-transparent">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#ffd700] to-[#ffa500] text-black flex items-center justify-center font-black text-lg shrink-0 shadow-lg shadow-[#ffd700]/20">
            ⭐
          </div>
          <div className="text-right">
            <h4 className="text-sm font-black text-[#ffd700]">شحن وترقية مستوى الـ VIP الملكي</h4>
            <p className="text-[11px] text-gray-300">
              كل 100 نقطة ترفعك مستوى إضافي وتمنحك ألواناً متوهجة وشارة مميزة بجانب اسمك
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 my-3 text-xs bg-black/40 p-3 rounded-2xl border border-white/5">
          <div className="text-right">
            <span className="text-gray-400 block text-[11px]">مستواك الحالي:</span>
            <span className="font-black text-[#25d366] text-sm">
              {currentUser.vipLevel > 0 ? `VIP ${currentUser.vipLevel}` : 'عضو قياسي'}
            </span>
          </div>
          <div className="text-right">
            <span className="text-gray-400 block text-[11px]">رصيد نجومك:</span>
            <span className="font-black text-[#ffd700] text-sm">
              ⭐ {currentUser.points || 0} نجمة
            </span>
          </div>
        </div>

        <button
          onClick={onOpenVipModal}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#ffd700] via-[#ffa500] to-[#ffd700] text-black font-black text-xs hover:opacity-95 transition shadow-lg shadow-[#ffd700]/25 cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Crown className="w-4 h-4" />
          <span>ترقية وشحن رتبة VIP بالنقاط 👑</span>
        </button>
      </div>

      {/* 2. WhatsApp Settings Sections List */}
      <div className="glass-panel rounded-3xl border border-white/10 shadow-xl overflow-hidden divide-y divide-white/10">
        {/* Section: Install App on Phone */}
        <div
          onClick={onOpenInstallModal}
          className="flex items-center justify-between p-4 bg-gradient-to-r from-[#25d366]/15 via-[#00a884]/10 to-transparent hover:bg-[#25d366]/20 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#25d366]/20 border border-[#25d366]/40 text-[#25d366] flex items-center justify-center shadow-lg shadow-[#25d366]/20">
              <Download className="w-5 h-5 animate-bounce" />
            </div>
            <div className="text-right">
              <b className="text-sm text-white flex items-center gap-2">
                <span>تنزيل وتثبيت التطبيق على الهاتف</span>
                <span className="text-[10px] bg-[#25d366] text-black font-black px-2 py-0.5 rounded-full shadow">
                  تطبيق أصلي 📲
                </span>
              </b>
              <span className="text-[11px] text-gray-300">
                شرح التثبيت بالخطوات لهواتف الأندرويد والآيفون والكمبيوتر
              </span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-[#25d366]" />
        </div>

        {/* Section: Chats & Wallpaper */}
        <div
          onClick={onOpenWallpaperModal}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#00a884]/20 text-[#25d366] flex items-center justify-center">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">مظهر وخلفية الشاشة</b>
              <span className="text-[11px] text-gray-400">
                تخصيص خلفية التطبيق والمحادثات، رفع صورة خاصة، وضبط الشفافية
              </span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </div>

        {/* Section: Privacy */}
        <div
          onClick={handleToggleLastSeen}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">الخصوصية وآخر ظهور</b>
              <span className="text-[11px] text-gray-400">
                {privacyLastSeen === 'everyone'
                  ? 'حالة الظهور مرئية للجميع'
                  : 'حالة الظهور مخفية عن الجميع 🔒'}
              </span>
            </div>
          </div>
          <span className="text-xs bg-white/10 px-2.5 py-1 rounded-lg text-gray-300">
            {privacyLastSeen === 'everyone' ? 'الكل' : 'لا أحد'}
          </span>
        </div>

        {/* Section: Notifications & Sounds */}
        <div
          onClick={handleToggleSound}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">نغمات وأصوات التطبيق</b>
              <span className="text-[11px] text-gray-400">
                تشغيل أو كتم أصوات إرسال واستلام الرسائل والتنبيهات
              </span>
            </div>
          </div>
          <div
            className={`w-11 h-6 rounded-full transition p-1 flex items-center ${
              soundEnabled ? 'bg-[#25d366] justify-end' : 'bg-gray-600 justify-start'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-black shadow" />
          </div>
        </div>

        {/* Section: Blocked contacts */}
        <div
          onClick={() => setShowBlockedModal(true)}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">جهات الاتصال المحظورة</b>
              <span className="text-[11px] text-gray-400">
                {currentUser.blockedUsers?.length || 0} جهات محظورة
              </span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </div>

        {/* Section: Security / Password */}
        <div
          onClick={() => setShowPasswordModal(true)}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">الأمان وكلمة المرور</b>
              <span className="text-[11px] text-gray-400">تغيير كلمة المرور الخاصة بحسابك الملكي</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </div>

        {/* Section: Invite Friends (+5 stars) */}
        <div
          onClick={() => {
            navigator.clipboard.writeText(inviteLink);
            playAppSound('click');
            onToast('تم نسخ رابط الدعوة الخاص بك! 🔗 (+5 نجوم)');
          }}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#ffd700]/20 text-[#ffd700] flex items-center justify-center">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">دعوة صديق (+5 نجوم)</b>
              <span className="text-[11px] text-gray-400">
                انسخ رابطك وشاركه لترقية مستواك الملكي فور تسجيل الأصدقاء
              </span>
            </div>
          </div>
          <Copy className="w-4 h-4 text-[#ffd700]" />
        </div>

        {/* Section: Developer Contact */}
        <div
          onClick={contactDeveloper}
          className="flex items-center justify-between p-4 hover:bg-white/5 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#25d366]/20 text-[#25d366] flex items-center justify-center">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-white block">مساعدة وتواصل مع المطور</b>
              <span className="text-[11px] text-gray-400">
                تواصل واتساب مباشر مع الأستاذ عاصف الحاتمي (+967 738 654 396)
              </span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </div>

        {/* Section: Logout */}
        <div
          onClick={onLogout}
          className="flex items-center justify-between p-4 hover:bg-red-500/10 transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center">
              <LogOut className="w-5 h-5" />
            </div>
            <div>
              <b className="text-sm text-red-400 block">تسجيل الخروج</b>
              <span className="text-[11px] text-gray-400">الخروج بأمان من هذا الجهاز</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-red-400" />
        </div>
      </div>

      {/* Fullscreen Avatar Viewer Modal */}
      {showAvatarViewer && (
        <div
          className="fixed inset-0 z-[99999] bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setShowAvatarViewer(false)}
        >
          <div className="relative max-w-sm text-center" onClick={(e) => e.stopPropagation()}>
            <div className="w-64 h-64 mx-auto rounded-full overflow-hidden border-4 border-[#25d366] shadow-2xl mb-4 bg-[#1f2c34] flex items-center justify-center text-6xl font-bold text-white">
              {currentUser.avatar ? (
                <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                (currentUser.name[0] || 'A').toUpperCase()
              )}
            </div>
            <div className="flex gap-2 justify-center">
              <button
                onClick={handleRemoveAvatar}
                className="px-4 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-bold transition flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>حذف الصورة</span>
              </button>
              <button
                onClick={() => setShowAvatarViewer(false)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm glass-panel-heavy rounded-2xl border border-white/10 p-5">
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-white/10">
              <h3 className="font-bold text-sm text-white">تغيير كلمة المرور</h3>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="block text-xs text-gray-300 mb-1 text-right">
                  كلمة المرور الحالية
                </label>
                <input
                  type="password"
                  required
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#25d366]"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-300 mb-1 text-right">
                  كلمة المرور الجديدة
                </label>
                <input
                  type="password"
                  required
                  minLength={4}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#25d366]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#25d366] text-black font-extrabold text-xs transition shadow-md mt-2"
              >
                حفظ كلمة المرور الجديدة
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Blocked Users Modal */}
      {showBlockedModal && (
        <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm glass-panel-heavy rounded-2xl border border-white/10 p-5">
            <div className="flex justify-between items-center mb-3 pb-2 border-b border-white/10">
              <h3 className="font-bold text-sm text-white">جهات الاتصال المحظورة</h3>
              <button
                onClick={() => setShowBlockedModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2">
              {(!currentUser.blockedUsers || currentUser.blockedUsers.length === 0) ? (
                <div className="text-center py-8 text-gray-400 text-xs">
                  لا توجد أي جهات اتصال محظورة
                </div>
              ) : (
                currentUser.blockedUsers.map((bId) => (
                  <div
                    key={bId}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5"
                  >
                    <span className="text-xs text-white font-mono">{bId}</span>
                    <button
                      onClick={() => handleUnblockUser(bId)}
                      className="px-2.5 py-1 rounded-lg bg-[#25d366]/20 text-[#25d366] hover:bg-[#25d366]/30 text-xs font-bold transition"
                    >
                      إلغاء الحظر
                    </button>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setShowBlockedModal(false)}
              className="w-full mt-3 py-2 rounded-xl bg-white/10 text-gray-300 text-xs font-bold"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
