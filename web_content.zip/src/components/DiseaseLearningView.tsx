import React, { useState, useEffect } from 'react';
import {
  Search,
  Bookmark,
  ArrowRight,
  Globe,
  BookOpen,
  Activity,
  HeartPulse,
  Wind,
  Bug,
  ShieldAlert,
  Thermometer,
  ShieldPlus,
  ThermometerSnowflake,
  Flame,
  Zap,
  Droplet,
  Heart,
  Share2,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { DISEASES_DATA } from '../data/diseaseData';
import { DiseaseItem, DiseaseLanguage } from '../types/disease';
import { DiseaseDetailView } from './DiseaseDetailView';

interface DiseaseLearningViewProps {
  onBack: () => void;
}

export const DiseaseLearningView: React.FC<DiseaseLearningViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<DiseaseLanguage>('English');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDisease, setSelectedDisease] = useState<DiseaseItem | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // Load bookmarks from LocalStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_bookmarked_diseases');
      if (saved) {
        setBookmarkedIds(JSON.parse(saved));
      }
    } catch (err) {
      console.warn('Failed to load bookmarked diseases:', err);
    }
  }, []);

  // Save bookmarks
  const toggleBookmark = (diseaseId: string) => {
    setBookmarkedIds((prev) => {
      let updated: string[];
      if (prev.includes(diseaseId)) {
        updated = prev.filter((id) => id !== diseaseId);
      } else {
        updated = [...prev, diseaseId];
      }
      try {
        localStorage.setItem('mediguide_bookmarked_diseases', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save bookmarked diseases:', err);
      }
      return updated;
    });
  };

  // Helper to render card icons
  const renderIcon = (iconName: string) => {
    const props = { className: "w-5 h-5 text-white" };
    switch (iconName) {
      case 'Activity': return <Activity {...props} />;
      case 'HeartPulse': return <HeartPulse {...props} />;
      case 'Wind': return <Wind {...props} />;
      case 'Bug': return <Bug {...props} />;
      case 'ShieldAlert': return <ShieldAlert {...props} />;
      case 'Thermometer': return <Thermometer {...props} />;
      case 'Lungs': return <Wind {...props} />;
      case 'ShieldPlus': return <ShieldPlus {...props} />;
      case 'ThermometerSnowflake': return <ThermometerSnowflake {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'Zap': return <Zap {...props} />;
      case 'Droplet': return <Droplet {...props} />;
      case 'Heart': return <Heart {...props} />;
      default: return <BookOpen {...props} />;
    }
  };

  // Quick share card
  const handleQuickShare = async (e: React.MouseEvent, disease: DiseaseItem) => {
    e.stopPropagation();
    const content = disease.content[selectedLanguage] || disease.content.English;
    const text = `🦠 ${content.name}\n\n${content.summary}\n\nLearn more on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.name,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(disease.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Failed to copy:', err);
    }
  };

  // Filter diseases based on search, category & bookmarks
  const filteredDiseases = DISEASES_DATA.filter((item) => {
    const content = item.content[selectedLanguage] || item.content.English;
    const query = searchQuery.toLowerCase().trim();

    // Search filter across name, summary, causes, and symptoms
    const matchesSearch =
      !query ||
      content.name.toLowerCase().includes(query) ||
      content.summary.toLowerCase().includes(query) ||
      content.symptoms.some((s) => s.toLowerCase().includes(query)) ||
      content.causes.some((c) => c.toLowerCase().includes(query));

    // Category filter
    let matchesCategory = true;
    if (selectedCategory === 'Bookmarked') {
      matchesCategory = bookmarkedIds.includes(item.id);
    } else if (selectedCategory !== 'All') {
      matchesCategory = item.category === selectedCategory;
    }

    return matchesSearch && matchesCategory;
  });

  const categories = ['All', 'Bookmarked', 'Chronic', 'Infectious', 'Respiratory', 'Vector-borne', 'Digestive', 'General'];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Disease Learning"
        subtitle="Disease Learning Library"
        onBack={onBack}
        badge="Verified Medical"
        badgeColor="bg-emerald-100 text-emerald-800 border-emerald-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Main Banner Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-700 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 text-white">
                <span className="text-2xl">🦠</span>
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Disease Learning Library</h1>
                <p className="text-xs text-emerald-100 mt-0.5 font-medium">
                  Verified educational guides for 15+ common medical conditions.
                </p>
              </div>
            </div>
          </div>

          {/* Language Selector Header Bar */}
          <div className="pt-3 border-t border-white/20 flex flex-wrap items-center justify-between gap-2 text-xs relative z-10">
            <div className="flex items-center gap-1.5 font-bold text-emerald-100">
              <Globe className="w-4 h-4 text-emerald-200" />
              <span>Language: English (हिन्दी / मराठी)</span>
            </div>

            {/* Language Switcher Tabs */}
            <div className="flex bg-black/25 p-1 rounded-2xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as DiseaseLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-white text-emerald-900 shadow-md'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              selectedLanguage === 'Hindi'
                ? 'बीमारी, लक्षण या कारण खोजें (जैसे: डेंगू, दमा, बुखार)...'
                : selectedLanguage === 'Marathi'
                ? 'आजार, लक्षणे किंवा कारणे शोधा (उदा: डेंग्यू, ताण, ताप)...'
                : 'Search diseases, symptoms, causes (e.g. Dengue, Diabetes, Fever)...'
            }
            className="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold bg-slate-100 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-bold no-scrollbar">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 rounded-2xl whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {cat === 'Bookmarked' && (
                  <Bookmark className={`w-3.5 h-3.5 ${bookmarkedIds.length > 0 ? 'fill-amber-400 text-amber-500' : ''}`} />
                )}
                <span>
                  {cat === 'All'
                    ? selectedLanguage === 'Hindi'
                      ? 'सभी बीमारियां'
                      : selectedLanguage === 'Marathi'
                      ? 'सर्व आजार'
                      : 'All Diseases'
                    : cat === 'Bookmarked'
                    ? `${selectedLanguage === 'Hindi' ? 'बुकमार्क' : selectedLanguage === 'Marathi' ? 'बुकमार्क' : 'Bookmarked'} (${bookmarkedIds.length})`
                    : cat}
                </span>
              </button>
            );
          })}
        </div>

        {/* Results Counter */}
        <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1">
          <span>
            {selectedLanguage === 'Hindi'
              ? `कुल ${filteredDiseases.length} बीमारियां उपलब्ध हैं`
              : selectedLanguage === 'Marathi'
              ? `एकूण ${filteredDiseases.length} आजार उपलब्ध आहेत`
              : `Showing ${filteredDiseases.length} verified disease guides`}
          </span>
          <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/60 font-semibold">
            Language: {selectedLanguage === 'English' ? 'English' : selectedLanguage === 'Hindi' ? 'हिन्दी' : 'मराठी'}
          </span>
        </div>

        {/* Disease Cards Grid */}
        {filteredDiseases.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200/80 space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-sm">
              {selectedLanguage === 'Hindi'
                ? 'कोई बीमारी नहीं मिली'
                : selectedLanguage === 'Marathi'
                ? 'कोणताही आजार आढळला नाही'
                : 'No Diseases Found'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {selectedCategory === 'Bookmarked'
                ? 'You have not bookmarked any disease yet. Click the bookmark icon on any disease card to save it here.'
                : 'Try adjusting your search terms or selecting a different category filter above.'}
            </p>
            {(searchQuery || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredDiseases.map((disease) => {
              const content = disease.content[selectedLanguage] || disease.content.English;
              const isBookmarked = bookmarkedIds.includes(disease.id);

              return (
                <motion.div
                  key={disease.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => setSelectedDisease(disease)}
                  className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between space-y-3 cursor-pointer group"
                >
                  <div className="space-y-2">
                    {/* Top Row: Category & Action Buttons */}
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-extrabold ${disease.badgeBg} ${disease.badgeText} px-2.5 py-0.5 rounded-lg border`}>
                        {content.category}
                      </span>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => toggleBookmark(disease.id)}
                          className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                            isBookmarked
                              ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                              : 'bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Bookmark Disease"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-600' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => handleQuickShare(e, disease)}
                          className="p-1.5 bg-slate-100 text-slate-500 rounded-xl hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                          title="Share Disease"
                        >
                          {copiedShareId === disease.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Share2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Disease Title & Icon */}
                    <div className="flex items-start gap-3 pt-1">
                      <div className={`p-2.5 bg-gradient-to-br ${disease.bgGradient} rounded-2xl shrink-0 shadow-xs group-hover:scale-105 transition-transform`}>
                        {renderIcon(disease.iconName)}
                      </div>

                      <div className="space-y-1">
                        <h3 className="font-extrabold text-sm text-slate-900 leading-snug group-hover:text-emerald-700 transition-colors">
                          {content.name}
                        </h3>
                        <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                          {content.summary}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Action bar */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-emerald-700">
                    <span className="text-[10px] text-slate-400 font-medium">12 Full Sections • Verified</span>
                    <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      {selectedLanguage === 'Hindi'
                        ? 'विस्तार से पढ़ें'
                        : selectedLanguage === 'Marathi'
                        ? 'सविस्तर वाचा'
                        : 'Read Medical Guide'}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Disease Detail Modal */}
      <AnimatePresence>
        {selectedDisease && (
          <DiseaseDetailView
            disease={selectedDisease}
            currentLanguage={selectedLanguage}
            onLanguageChange={(lang) => setSelectedLanguage(lang)}
            isBookmarked={bookmarkedIds.includes(selectedDisease.id)}
            onToggleBookmark={toggleBookmark}
            onClose={() => setSelectedDisease(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
