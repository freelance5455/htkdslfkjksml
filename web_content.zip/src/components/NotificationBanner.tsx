import React, { useEffect, useRef, useCallback } from 'react';
import { Trophy, Award, X, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useWorkout } from '../context/WorkoutContext';
import { playConfettiPopSound, playPopSound } from '../utils/audio';

export const NotificationBanner: React.FC = () => {
  const {
    recentPRNotification,
    dismissPRNotification,
    recentAchievementNotification,
    dismissAchievementNotification,
    user
  } = useWorkout();

  const lastPRIdRef = useRef<string | null>(null);
  const lastAchievementIdRef = useRef<string | null>(null);

  // Trigger celebratory confetti for Personal Records
  const firePRConfetti = useCallback(() => {
    try {
      // Primary burst right under the notification banner
      confetti({
        particleCount: 65,
        spread: 75,
        origin: { y: 0.12, x: 0.5 },
        colors: ['#06b6d4', '#22d3ee', '#67e8f9', '#facc15', '#ffffff'],
        disableForReducedMotion: true,
        zIndex: 9999
      });

      // Staggered dual-wing celebration bursts
      const timer = setTimeout(() => {
        confetti({
          particleCount: 35,
          angle: 60,
          spread: 55,
          origin: { x: 0.32, y: 0.14 },
          colors: ['#06b6d4', '#38bdf8', '#fbbf24', '#ffffff'],
          disableForReducedMotion: true,
          zIndex: 9999
        });
        confetti({
          particleCount: 35,
          angle: 120,
          spread: 55,
          origin: { x: 0.68, y: 0.14 },
          colors: ['#06b6d4', '#38bdf8', '#fbbf24', '#ffffff'],
          disableForReducedMotion: true,
          zIndex: 9999
        });
      }, 150);

      return () => clearTimeout(timer);
    } catch {
      // Fallback gracefully if canvas context is unavailable
    }
  }, []);

  // Trigger celebratory confetti for Achievements
  const fireAchievementConfetti = useCallback(() => {
    try {
      // High-energy star & circle fiesta
      confetti({
        particleCount: 85,
        spread: 100,
        origin: { y: 0.12, x: 0.5 },
        colors: ['#fbbf24', '#f59e0b', '#06b6d4', '#a855f7', '#ec4899', '#ffffff'],
        shapes: ['star', 'circle'],
        disableForReducedMotion: true,
        zIndex: 9999
      });

      // Secondary floating shimmer shower
      const timer = setTimeout(() => {
        confetti({
          particleCount: 45,
          spread: 120,
          startVelocity: 35,
          origin: { y: 0.14, x: 0.5 },
          colors: ['#ffd700', '#22d3ee', '#c084fc', '#ffffff'],
          disableForReducedMotion: true,
          zIndex: 9999
        });
      }, 180);

      return () => clearTimeout(timer);
    } catch {
      // Fallback gracefully
    }
  }, []);

  // Interactive micro-burst when user taps or clicks the notification banner
  const handleBannerClick = (e: React.MouseEvent<HTMLDivElement>, isPR: boolean) => {
    if (user.soundEnabled) {
      playConfettiPopSound();
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    try {
      confetti({
        particleCount: 30,
        spread: 60,
        startVelocity: 25,
        origin: { x, y },
        colors: isPR
          ? ['#06b6d4', '#22d3ee', '#facc15', '#ffffff']
          : ['#fbbf24', '#a855f7', '#06b6d4', '#ffffff'],
        disableForReducedMotion: true,
        zIndex: 9999
      });
    } catch {
      // Ignore
    }
  };

  // PR Notification Timer & Confetti
  useEffect(() => {
    if (recentPRNotification && recentPRNotification.id !== lastPRIdRef.current) {
      lastPRIdRef.current = recentPRNotification.id;
      if (user.soundEnabled) playConfettiPopSound();
      firePRConfetti();
      const timer = setTimeout(() => {
        dismissPRNotification();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [recentPRNotification, dismissPRNotification, firePRConfetti, user.soundEnabled]);

  // Achievement Notification Timer & Confetti
  useEffect(() => {
    if (
      recentAchievementNotification &&
      recentAchievementNotification.id !== lastAchievementIdRef.current
    ) {
      lastAchievementIdRef.current = recentAchievementNotification.id;
      if (user.soundEnabled) playConfettiPopSound();
      fireAchievementConfetti();
      const timer = setTimeout(() => {
        dismissAchievementNotification();
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [recentAchievementNotification, dismissAchievementNotification, fireAchievementConfetti, user.soundEnabled]);

  if (!recentPRNotification && !recentAchievementNotification) {
    return null;
  }

  return (
    <div className="fixed top-4 left-0 right-0 z-50 px-4 max-w-md mx-auto pointer-events-none flex flex-col gap-3">
      {/* PR Toast with Scale-Up Spring Animation, Shimmer, and Confetti */}
      {recentPRNotification && (
        <div
          key={recentPRNotification.id}
          onClick={(e) => handleBannerClick(e, true)}
          className="pointer-events-auto relative overflow-hidden bg-gradient-to-r from-[#0c1424] via-[#0d1e2e] to-[#071926] border-2 border-cyan-400/80 rounded-2xl p-3.5 shadow-2xl shadow-cyan-500/30 backdrop-blur-xl animate-banner-scale-up hover:scale-[1.02] active:scale-[0.98] transition-transform cursor-pointer group"
        >
          {/* Shimmer Light Reflection Sweep */}
          <div className="absolute inset-0 w-1/3 bg-gradient-to-r from-transparent via-cyan-400/15 to-transparent pointer-events-none animate-shine-sweep" />

          {/* Radial cyan glow aura */}
          <div className="absolute -top-12 -right-12 w-28 h-28 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Scaled-up Bouncing Trophy Badge */}
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 p-[1px] shadow-lg shadow-cyan-500/40 shrink-0 animate-badge-pop">
                <div className="w-full h-full rounded-[11px] bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center text-cyan-300">
                  <Trophy className="w-5 h-5 fill-cyan-400/30 stroke-[2.2]" />
                </div>
              </div>

              <div>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[11px] font-black uppercase tracking-wider text-cyan-400">
                    New Personal Record!
                  </span>
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spark-rotate shrink-0" />
                </div>

                <div className="text-sm font-extrabold text-white leading-tight">
                  {recentPRNotification.exerciseName}
                </div>

                <div className="text-xs text-slate-300 font-mono mt-0.5 flex items-center gap-1.5">
                  <span className="font-bold text-white text-sm">
                    {recentPRNotification.value} {recentPRNotification.unit}
                  </span>
                  {recentPRNotification.previousValue ? (
                    <span className="text-cyan-400 font-extrabold text-[11px] bg-cyan-950/80 px-1.5 py-0.5 rounded-md border border-cyan-500/40">
                      +{recentPRNotification.value - recentPRNotification.previousValue} PR Gain!
                    </span>
                  ) : (
                    <span className="text-cyan-400 font-extrabold text-[11px] bg-cyan-950/80 px-1.5 py-0.5 rounded-md border border-cyan-500/40">
                      First Milestone!
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                dismissPRNotification();
              }}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700/80 transition-all shrink-0 active:scale-90"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Auto-Dismiss Progression Line Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-neutral-950/60 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-cyan-300"
              style={{
                animation: 'shrinkWidth 5s linear forwards'
              }}
            />
          </div>
        </div>
      )}

      {/* Achievement Toast with Scale-Up Spring Animation, Golden Glow, and Confetti */}
      {recentAchievementNotification && (
        <div
          key={recentAchievementNotification.id}
          onClick={(e) => handleBannerClick(e, false)}
          className="pointer-events-auto relative overflow-hidden bg-gradient-to-r from-[#1c142b] via-[#1a1936] to-[#0f192b] border-2 border-amber-400/80 rounded-2xl p-3.5 shadow-2xl shadow-amber-500/25 backdrop-blur-xl animate-banner-scale-up hover:scale-[1.02] active:scale-[0.98] transition-transform cursor-pointer group"
        >
          {/* Shimmer Light Reflection Sweep */}
          <div className="absolute inset-0 w-1/3 bg-gradient-to-r from-transparent via-amber-300/20 to-transparent pointer-events-none animate-shine-sweep" />

          {/* Radial golden glow aura */}
          <div className="absolute -top-12 -right-12 w-28 h-28 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Scaled-up Bouncing Award Badge */}
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-300 via-amber-400 to-yellow-500 p-[1px] shadow-lg shadow-amber-500/40 shrink-0 animate-badge-pop">
                <div className="w-full h-full rounded-[11px] bg-neutral-950/85 backdrop-blur-sm flex items-center justify-center text-amber-300">
                  <Award className="w-5 h-5 fill-amber-300/30 stroke-[2.2]" />
                </div>
              </div>

              <div>
                <div className="text-[11px] font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5 mb-0.5">
                  <span>Achievement Unlocked!</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spark-rotate shrink-0" />
                </div>

                <div className="text-sm font-extrabold text-white leading-tight">
                  {recentAchievementNotification.title}
                </div>

                <div className="text-xs text-slate-300 leading-snug mt-0.5 max-w-[240px]">
                  {recentAchievementNotification.description}
                </div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                dismissAchievementNotification();
              }}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700/80 transition-all shrink-0 active:scale-90"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Auto-Dismiss Progression Line Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-neutral-950/60 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 via-yellow-300 to-cyan-400"
              style={{
                animation: 'shrinkWidth 6s linear forwards'
              }}
            />
          </div>
        </div>
      )}

      {/* Global CSS animation for smooth line shrinkage */}
      <style>{`
        @keyframes shrinkWidth {
          from {
            width: 100%;
          }
          to {
            width: 0%;
          }
        }
      `}</style>
    </div>
  );
};
