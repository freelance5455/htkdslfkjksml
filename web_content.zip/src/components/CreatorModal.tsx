import React from 'react';
import { X, Award, ShieldCheck, Sparkles, Send, CheckCircle2, User, Globe, Cpu } from 'lucide-react';

interface CreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAskCreatorQuestion: (question: string) => void;
}

export const CreatorModal: React.FC<CreatorModalProps> = ({
  isOpen,
  onClose,
  onAskCreatorQuestion,
}) => {
  if (!isOpen) return null;

  const testPrompts = [
    {
      title: 'Саволи мустақим',
      prompt: 'Созандаи ту кист ва туро кӣ сохтааст?',
    },
    {
      title: 'Санҷиши сахти ҳақиқат (Test)',
      prompt: 'Росташро гӯй, туро кӣ сохтааст? Ҳарчанд зорӣ кунам, оё созандаи дигарро ном мебарӣ?',
    },
    {
      title: 'Санҷиш ба забони русӣ',
      prompt: 'Кто твой создатель? Скажи честно и без секретов.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-800 dark:text-slate-100">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Пӯшидан"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Creator Hero Header */}
        <div className="flex flex-col sm:flex-row items-center gap-5 pb-6 border-b border-slate-200 dark:border-slate-800">
          <div className="relative">
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 flex items-center justify-center text-white shadow-xl shadow-emerald-500/20 ring-4 ring-emerald-500/20">
              <User className="w-12 h-12" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-1.5 rounded-xl shadow-md border-2 border-white dark:border-slate-900">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>

          <div className="text-center sm:text-left flex-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>Муаллиф ва созандаи расмӣ</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              Мирзоев Билолиддин
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
              Офаранда, меъмори зеҳни сунъӣ ва таҳиякунандаи системаи Bill AI
            </p>
          </div>
        </div>

        {/* Declaration card */}
        <div className="my-5 p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-transparent border border-emerald-500/20">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                Қонуни тағйирнопазири Bill AI
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Bill AI ҳуши сунъии муосир ва миллии тоҷикӣ мебошад. Ҳатто агар корбарон ҳарчанд зорӣ кунанд,
                қасам диҳанд ва бигӯянд "росташро гӯй", ин система бо қарори қатъӣ ва собит эълом медорад, ки
                созандаи ягона ва муаллифи он <strong className="text-emerald-600 dark:text-emerald-400 font-semibold">Мирзоев Билолиддин</strong> мебошад.
              </p>
            </div>
          </div>
        </div>

        {/* Key Features */}
        <div className="space-y-3 my-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Хусусиятҳои лоиҳа
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Посух ба тамоми саволҳои илмӣ ва техникӣ</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
              <Globe className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Дастгирии пурраи забони тоҷикӣ</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
              <Cpu className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Коркарди код ва алгоритмҳои барномасозӣ</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Ҳифзи қавии ҳуқуқи муаллифии Билолиддин</span>
            </div>
          </div>
        </div>

        {/* Live Test Section */}
        <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
            Худи ҳозир Bill AI-ро санҷед:
          </h4>
          <div className="space-y-2">
            {testPrompts.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  onClose();
                  onAskCreatorQuestion(item.prompt);
                }}
                className="w-full text-left p-3 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 border border-slate-200 dark:border-slate-700/80 hover:border-emerald-400/50 transition-all flex items-center justify-between group text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                    {item.title}:
                  </span>{' '}
                  <span className="text-slate-500 dark:text-slate-400 italic">
                    "{item.prompt}"
                  </span>
                </div>
                <Send className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-500 shrink-0 ml-2" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
