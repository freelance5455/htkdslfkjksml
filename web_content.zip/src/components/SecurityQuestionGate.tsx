import React, { useState } from 'react';
import { ShieldCheck, HelpCircle, ArrowLeft } from 'lucide-react';

interface SecurityQuestionGateProps {
  onSuccess: () => void;
  onBack: () => void;
}

export const SecurityQuestionGate: React.FC<SecurityQuestionGateProps> = ({ onSuccess, onBack }) => {
  const [ansCity, setAnsCity] = useState<string>('');
  const [ansSchool, setAnsSchool] = useState<string>('');
  const [ansFood, setAnsFood] = useState<string>('');
  
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSecurityQuestionsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    setTimeout(() => {
      if (
        ansCity.trim().toLowerCase() === 'sapele' &&
        ansSchool.trim().toLowerCase() === 'okurekpo' &&
        ansFood.trim().toLowerCase() === 'eba'
      ) {
        onSuccess();
      } else {
        setErrorMessage('Access Denied: Incorrect Security Question Answers. The Sanctuary remains locked.');
        setIsSubmitting(false);
      }
    }, 600);
  };

  return (
    <form onSubmit={handleSecurityQuestionsSubmit} className="space-y-4">
      {errorMessage && (
        <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/50 flex items-start space-x-2 text-rose-200 text-xs animate-shake">
          <span>{errorMessage}</span>
        </div>
      )}
      
      <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-xl flex items-center space-x-2 text-amber-300 text-xs">
        <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
        <span>Please answer the 3 security verification questions below:</span>
      </div>

      <div className="space-y-1.5">
        <label className="block text-xs font-semibold text-amber-200">
          1. Which city/village you were burn (born)?
        </label>
        <input
          type="text"
          required
          autoFocus
          value={ansCity}
          onChange={(e) => setAnsCity(e.target.value)}
          placeholder="Enter city or village..."
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-100 placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400 font-mono"
        />
      </div>

      <div className="space-y-1.5">
        <label className="block text-xs font-semibold text-amber-200">
          2. Which Primary school do you attended?
        </label>
        <input
          type="text"
          required
          value={ansSchool}
          onChange={(e) => setAnsSchool(e.target.value)}
          placeholder="Enter primary school..."
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-100 placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400 font-mono"
        />
      </div>

      <div className="space-y-1.5">
        <label className="block text-xs font-semibold text-amber-200">
          3. What's your favorite food?
        </label>
        <input
          type="text"
          required
          value={ansFood}
          onChange={(e) => setAnsFood(e.target.value)}
          placeholder="Enter favorite food..."
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-100 placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400 font-mono"
        />
      </div>

      <div className="pt-2 space-y-2.5">
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
        >
          {isSubmitting ? (
            <span>Verifying Security Answers...</span>
          ) : (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span>Verify & Unlock Owner Vault</span>
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onBack}
          className="w-full py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium border border-slate-800 transition-colors flex items-center justify-center space-x-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Step 1 Credentials</span>
        </button>
      </div>
    </form>
  );
};
