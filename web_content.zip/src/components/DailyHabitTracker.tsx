import React, { useState } from 'react';
import {
  Droplets,
  Sparkles,
  Flame,
  Dumbbell,
  Moon,
  Target,
  Plus,
  Trash2,
  X,
  CheckCircle2
} from 'lucide-react';
import { useWorkout } from '../context/WorkoutContext';
import { DailyHabit, HabitIconName } from '../types';

const PARTICLE_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315];

export const DailyHabitTracker: React.FC = () => {
  const { dailyHabits, toggleDailyHabit, addDailyHabit, deleteDailyHabit } = useWorkout();

  const [justCompletedId, setJustCompletedId] = useState<string | null>(null);
  const [allClearBannerPulse, setAllClearBannerPulse] = useState<boolean>(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newSubtitle, setNewSubtitle] = useState<string>('');
  const [newIcon, setNewIcon] = useState<HabitIconName>('droplets');

  const getTodayKey = () => {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const todayKey = getTodayKey();

  const completedCount = dailyHabits.filter((h) => h.completedDates.includes(todayKey)).length;
  const totalCount = dailyHabits.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const isAllComplete = totalCount > 0 && completedCount === totalCount;

  const handleToggleHabit = (habit: DailyHabit) => {
    const result = toggleDailyHabit(habit.id, todayKey);
    if (result.completed) {
      setJustCompletedId(habit.id);
      setTimeout(() => {
        setJustCompletedId((prev) => (prev === habit.id ? null : prev));
      }, 850);

      if (result.allCompleted) {
        setAllClearBannerPulse(true);
        setTimeout(() => setAllClearBannerPulse(false), 1400);
      }
    } else {
      if (justCompletedId === habit.id) {
        setJustCompletedId(null);
      }
    }
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    addDailyHabit(
      newTitle.trim(),
      newSubtitle.trim() || 'Daily recovery & discipline goal',
      newIcon
    );
    setNewTitle('');
    setNewSubtitle('');
    setNewIcon('target');
    setIsAddModalOpen(false);
  };

  const renderHabitIcon = (icon: HabitIconName, isDone: boolean) => {
    const cls = `w-4 h-4 transition-transform duration-300 ${
      isDone ? 'text-cyan-300 scale-110' : 'text-cyan-400/80 group-hover:text-cyan-300'
    }`;
    switch (icon) {
      case 'droplets':
        return <Droplets className={cls} />;
      case 'stretch':
        return <Sparkles className={cls} />;
      case 'protein':
        return <Flame className={cls} />;
      case 'hang':
        return <Dumbbell className={cls} />;
      case 'sleep':
        return <Moon className={cls} />;
      default:
        return <Target className={cls} />;
    }
  };

  // Ring geometry (r = 16 -> circumference = 100.53)
  const radius = 16;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="rounded-3xl bg-[#12151c] border border-neutral-800 p-4 sm:p-5 space-y-4 relative overflow-hidden">
      {/* Subtle Ambient Top Glow when all habits are completed */}
      {isAllComplete && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-700"
          style={{
            background:
              'radial-gradient(circle at 50% 0%, rgba(34, 211, 238, 0.16), transparent 65%)'
          }}
        />
      )}

      {/* Header Row */}
      <div className="relative z-10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {/* Circular Animated Progress Ring */}
          <div className="relative w-11 h-11 flex items-center justify-center shrink-0">
            <svg className="w-11 h-11 -rotate-90" viewBox="0 0 40 40">
              <circle
                cx="20"
                cy="20"
                r={radius}
                fill="none"
                stroke="#1e2430"
                strokeWidth="3.5"
              />
              <circle
                cx="20"
                cy="20"
                r={radius}
                fill="none"
                stroke={isAllComplete ? '#67e8f9' : '#22d3ee'}
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-500 ease-out"
              />
            </svg>
            <span className="absolute text-[10px] font-extrabold font-mono text-white">
              {completedCount}/{totalCount}
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">Daily Habit Tracker</h2>
              <span className="text-[11px] font-mono font-bold text-cyan-400">
                {progressPercent}%
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Mark off daily recovery, hydration & mobility goals
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsAddModalOpen(true)}
          className="px-2.5 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-cyan-500/40 text-xs font-semibold text-cyan-400 transition-all flex items-center gap-1 active:scale-95 shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Goal</span>
        </button>
      </div>

      {/* Horizontal Progress Bar */}
      <div className="relative z-10 w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden">
        <div
          style={{ width: `${progressPercent}%` }}
          className={`h-full rounded-full transition-all duration-500 ease-out ${
            isAllComplete
              ? 'bg-gradient-to-r from-cyan-400 via-sky-300 to-cyan-300 glow-cyan-md'
              : 'bg-gradient-to-r from-cyan-600 to-cyan-400 glow-cyan-sm'
          }`}
        />
      </div>

      {/* Celebratory All-Complete Banner */}
      {isAllComplete && (
        <div
          className={`relative z-10 p-3 rounded-2xl bg-gradient-to-r from-cyan-500/15 via-cyan-500/10 to-sky-500/15 border border-cyan-400/40 flex items-center justify-between gap-3 ${
            allClearBannerPulse ? 'animate-banner-scale-up' : ''
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-400 text-neutral-950 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(34,211,238,0.5)]">
              <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <div className="text-xs font-extrabold text-white">
                All Daily Habits Complete!
              </div>
              <div className="text-[11px] text-cyan-300">
                100% daily recovery & calisthenics discipline locked in for today.
              </div>
            </div>
          </div>
          <Sparkles className="w-4 h-4 text-cyan-300 shrink-0 animate-pulse" />
        </div>
      )}

      {/* Habits Grid */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {dailyHabits.map((habit) => {
          const isCompleted = habit.completedDates.includes(todayKey);
          const isAnimating = justCompletedId === habit.id;

          return (
            <div
              key={habit.id}
              onClick={() => handleToggleHabit(habit)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleToggleHabit(habit);
                }
              }}
              className={`group relative overflow-hidden rounded-2xl p-3.5 border transition-all duration-300 cursor-pointer select-none flex items-center justify-between gap-3 active:scale-[0.98] ${
                isCompleted
                  ? 'bg-gradient-to-r from-cyan-950/35 via-[#131c27] to-[#12151c] border-cyan-500/50 shadow-[0_0_20px_-6px_rgba(34,211,238,0.3)]'
                  : 'bg-neutral-900/70 hover:bg-neutral-900 border-neutral-800/90 hover:border-cyan-500/30'
              }`}
            >
              {/* Luminous Shimmer Sweep on Completion */}
              {isAnimating && (
                <div
                  className="pointer-events-none absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-cyan-300/30 to-transparent animate-habit-card-sweep"
                />
              )}

              {/* Left Icon + Copy */}
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300 ${
                    isCompleted
                      ? 'bg-cyan-500/20 border border-cyan-400/40 shadow-[0_0_12px_rgba(34,211,238,0.25)]'
                      : 'bg-neutral-950 border border-neutral-800 group-hover:border-cyan-500/30'
                  }`}
                >
                  {renderHabitIcon(habit.icon, isCompleted)}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3
                      className={`text-xs font-bold truncate transition-colors duration-300 ${
                        isCompleted ? 'text-cyan-200' : 'text-white group-hover:text-cyan-300'
                      }`}
                    >
                      {habit.title}
                    </h3>
                    {isAnimating && (
                      <span className="text-[10px] font-extrabold font-mono text-cyan-300 animate-bounce">
                        +1 DONE
                      </span>
                    )}
                  </div>
                  <p
                    className={`text-[11px] truncate transition-colors ${
                      isCompleted ? 'text-cyan-400/80' : 'text-slate-400'
                    }`}
                  >
                    {isCompleted ? 'Completed for today' : habit.subtitle}
                  </p>
                </div>
              </div>

              {/* Right Action Area: Delete (if custom) + Animated Check Orb */}
              <div className="flex items-center gap-2 shrink-0">
                {habit.isCustom && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteDailyHabit(habit.id);
                    }}
                    className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-neutral-800/80 transition-colors"
                    title="Delete custom habit"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Satisfying Animated Check Button */}
                <div className="relative flex items-center justify-center w-7 h-7">
                  {/* Expanding Cyan Sonar Ring on Completion */}
                  {isAnimating && (
                    <span className="pointer-events-none absolute inset-0 rounded-xl border-2 border-cyan-400 animate-habit-ring-burst" />
                  )}

                  {/* 8 Radial Cyan Spark Particles on Completion */}
                  {isAnimating &&
                    PARTICLE_ANGLES.map((angle) => (
                      <span
                        key={angle}
                        style={{ '--particle-angle': `${angle}deg` } as React.CSSProperties}
                        className="pointer-events-none absolute w-1.5 h-1.5 rounded-full bg-cyan-300 shadow-[0_0_6px_#22d3ee] animate-habit-particle"
                      />
                    ))}

                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      isCompleted
                        ? 'bg-cyan-400 text-neutral-950 shadow-[0_0_14px_rgba(34,211,238,0.65)]'
                        : 'bg-neutral-950 border border-neutral-700 group-hover:border-cyan-400/60'
                    } ${isAnimating ? 'animate-habit-check-pop' : ''}`}
                  >
                    {isCompleted && (
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        className="w-4 h-4 stroke-neutral-950"
                        strokeWidth="3.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path
                          d="M5 13l4 4L19 7"
                          className={isAnimating ? 'animate-checkmark-draw' : ''}
                        />
                      </svg>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom Daily Habit Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateHabit}
            className="bg-[#12151c] border border-neutral-800 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Add Daily Habit</h3>
                <p className="text-xs text-slate-400">Create a custom daily discipline goal</p>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl bg-neutral-900 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Habit Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Creatine 5g, 15m Foam Roll, Cold Shower"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Daily Target / Cue
                </label>
                <input
                  type="text"
                  placeholder="e.g., Post-workout recovery protocol"
                  value={newSubtitle}
                  onChange={(e) => setNewSubtitle(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Category Icon
                </label>
                <div className="grid grid-cols-6 gap-2">
                  {(
                    [
                      { id: 'droplets', label: 'Water' },
                      { id: 'stretch', label: 'Stretch' },
                      { id: 'protein', label: 'Fuel' },
                      { id: 'hang', label: 'Hang' },
                      { id: 'sleep', label: 'Sleep' },
                      { id: 'target', label: 'Goal' }
                    ] as { id: HabitIconName; label: string }[]
                  ).map((item) => (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setNewIcon(item.id)}
                      className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                        newIcon === item.id
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-neutral-900 border-neutral-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {renderHabitIcon(item.id, newIcon === item.id)}
                      <span className="text-[9px] font-semibold">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-900 text-slate-400 hover:text-white text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!newTitle.trim()}
                className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-neutral-950 text-xs font-bold shadow-md shadow-cyan-500/20 transition-all active:scale-95"
              >
                Save Habit
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
