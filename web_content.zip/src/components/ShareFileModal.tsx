import React, { useState } from 'react';
import {
  X,
  Share2,
  FileSpreadsheet,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Download,
  Send,
  MessageCircle
} from 'lucide-react';
import { shareFileNative, openWhatsAppWithMessage } from '../utils/fileShare';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  codeOrNumber: string;
  getPdfBlob: () => Promise<Blob>;
  getExcelBlob: () => Promise<Blob> | Blob;
}

export const ShareFileModal: React.FC<Props> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  codeOrNumber,
  getPdfBlob,
  getExcelBlob
}) => {
  if (!isOpen) return null;

  const [selectedFormat, setSelectedFormat] = useState<'pdf' | 'excel'>('pdf');
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const cleanFilename = (ext: string) => {
    const safe = (codeOrNumber || 'documento').replace(/[^a-zA-Z0-9_-]/g, '_');
    return `Sfiller_${safe}.${ext}`;
  };

  const handleShareNative = async () => {
    setIsProcessing(true);
    setFeedback({ type: 'info', text: 'Preparazione file per il menu di condivisione...' });
    try {
      const isPdf = selectedFormat === 'pdf';
      const blob = isPdf ? await getPdfBlob() : await getExcelBlob();
      const ext = isPdf ? 'pdf' : 'xls';
      const mime = isPdf ? 'application/pdf' : 'application/vnd.ms-excel';
      const filename = cleanFilename(ext);

      const result = await shareFileNative({
        title: `${title} - ${codeOrNumber}`,
        text: `In allegato documento ${isPdf ? 'PDF' : 'Excel'}: ${title} (${codeOrNumber}) - Sfiller Sabbiatura & Verniciatura.`,
        filename,
        blob,
        mimeType: mime
      });

      if (result.success) {
        setFeedback({ type: 'success', text: result.message });
        setTimeout(() => {
          onClose();
        }, 2200);
      } else {
        setFeedback({ type: 'info', text: result.message });
      }
    } catch (err: any) {
      console.error(err);
      setFeedback({ type: 'error', text: 'Errore durante la preparazione del file per la condivisione.' });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleShareDirectWhatsApp = async () => {
    setIsProcessing(true);
    setFeedback({ type: 'info', text: 'Preparazione file per WhatsApp...' });
    try {
      const isPdf = selectedFormat === 'pdf';
      const blob = isPdf ? await getPdfBlob() : await getExcelBlob();
      const ext = isPdf ? 'pdf' : 'xls';
      const mime = isPdf ? 'application/pdf' : 'application/vnd.ms-excel';
      const filename = cleanFilename(ext);

      // Su smartphone Android (Google Pixel 9), la Web Share API apre il foglio di sistema
      // con WhatsApp in prima posizione e passa direttamente il file!
      const file = new File([blob], filename, { type: mime });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `${title} - ${codeOrNumber}`,
          text: `Ecco il documento ${isPdf ? 'PDF' : 'Excel'}: *${title}* (${codeOrNumber}) da Sfiller Sabbiatura e Verniciatura.`,
          files: [file]
        });
        setFeedback({ type: 'success', text: 'File inviato a WhatsApp!' });
        setTimeout(() => onClose(), 2000);
      } else {
        // Fallback: scarica il file e apri WhatsApp con il messaggio di testo
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        openWhatsAppWithMessage(
          `*${title} (${codeOrNumber})*\nIl file ${filename} è stato scaricato sul tuo Pixel 9. Puoi allegarlo alla chat WhatsApp.`
        );
        setFeedback({
          type: 'success',
          text: `File scaricato sul Pixel 9 e WhatsApp avviato.`
        });
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error(err);
        setFeedback({ type: 'error', text: 'Impossibile completare la condivisione WhatsApp.' });
      } else {
        setFeedback(null);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadOnly = async () => {
    setIsProcessing(true);
    try {
      const isPdf = selectedFormat === 'pdf';
      const blob = isPdf ? await getPdfBlob() : await getExcelBlob();
      const ext = isPdf ? 'pdf' : 'xls';
      const filename = cleanFilename(ext);

      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setFeedback({ type: 'success', text: `File "${filename}" salvato sul dispositivo.` });
    } catch (err) {
      setFeedback({ type: 'error', text: 'Errore nel download del file.' });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      {/* Responsive Sheet: Bottom-sheet on Google Pixel 9 / mobile, modal dialog on tablet/desktop */}
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl border border-neutral-300 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Pixel 9 grabber bar indicator for mobile bottom sheet */}
        <div className="sm:hidden pt-3 pb-1 flex justify-center">
          <div className="w-12 h-1.5 bg-neutral-300 rounded-full" />
        </div>

        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-neutral-900 leading-tight">
                Condividi File su Smartphone
              </h3>
              <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
                {codeOrNumber} · WhatsApp & Altre App
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-900 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto">
          {/* Document Summary Card */}
          <div className="p-3 bg-neutral-100/70 border border-neutral-200 rounded-xl space-y-1">
            <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider block">
              Documento Selezionato
            </span>
            <h4 className="text-xs sm:text-sm font-bold text-neutral-900 leading-snug">
              {title}
            </h4>
            {subtitle && (
              <p className="text-[11px] text-neutral-600 line-clamp-1">{subtitle}</p>
            )}
          </div>

          {/* Scegli Formato File */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block">
              1. Scegli il Formato da Condividere:
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setSelectedFormat('pdf')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                  selectedFormat === 'pdf'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-sm ring-1 ring-neutral-900'
                    : 'border-neutral-200 bg-white text-neutral-800 hover:bg-neutral-50'
                }`}
              >
                <FileText
                  className={`w-6 h-6 shrink-0 ${
                    selectedFormat === 'pdf' ? 'text-amber-400' : 'text-neutral-500'
                  }`}
                />
                <div>
                  <div className="font-bold text-xs">PDF Formattato</div>
                  <div
                    className={`text-[10px] ${
                      selectedFormat === 'pdf' ? 'text-neutral-300' : 'text-neutral-500'
                    }`}
                  >
                    Pronto per stampa / lettura
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFormat('excel')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                  selectedFormat === 'excel'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-sm ring-1 ring-neutral-900'
                    : 'border-neutral-200 bg-white text-neutral-800 hover:bg-neutral-50'
                }`}
              >
                <FileSpreadsheet
                  className={`w-6 h-6 shrink-0 ${
                    selectedFormat === 'excel' ? 'text-emerald-400' : 'text-emerald-600'
                  }`}
                />
                <div>
                  <div className="font-bold text-xs">Excel (.xls)</div>
                  <div
                    className={`text-[10px] ${
                      selectedFormat === 'excel' ? 'text-neutral-300' : 'text-neutral-500'
                    }`}
                  >
                    Tabelle e formule modificabili
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Feedback message banner */}
          {feedback && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-center gap-2.5 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : feedback.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : 'bg-neutral-100 border-neutral-300 text-neutral-800'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : feedback.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              ) : (
                <Loader2 className="w-4 h-4 animate-spin text-neutral-700 shrink-0" />
              )}
              <span className="leading-snug">{feedback.text}</span>
            </div>
          )}

          {/* 2. Azioni di Condivisione (Pixel 9 Touch-Optimized) */}
          <div className="space-y-2.5 pt-1">
            <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block">
              2. Modalità di Condivisione:
            </label>

            {/* Pulsante Invia a WhatsApp in evidenza */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleShareDirectWhatsApp}
              className="w-full min-h-[48px] px-4 py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-between shadow-sm transition-all"
            >
              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                <span>Condividi su WhatsApp</span>
              </div>
              <Send className="w-4 h-4 opacity-80" />
            </button>

            {/* Menu Condivisione Nativa Pixel 9 / Android (Tutte le App) */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleShareNative}
              className="w-full min-h-[46px] px-4 py-3 bg-neutral-900 hover:bg-neutral-800 active:bg-black text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-between shadow-sm transition-all"
            >
              <div className="flex items-center gap-2.5">
                <Share2 className="w-4 h-4" />
                <span>Menu Condivisione Smartphone (Tutte le App)</span>
              </div>
              <span className="text-[10px] font-mono text-neutral-400">Android</span>
            </button>

            {/* Download Diretto */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleDownloadOnly}
              className="w-full min-h-[44px] px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-all border border-neutral-200"
            >
              <Download className="w-4 h-4 text-neutral-600" />
              <span>Scarica Solamente il File sul Telefono</span>
            </button>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-neutral-50 border-t border-neutral-200 text-center text-[10px] text-neutral-500 font-mono">
          Ottimizzato per Google Pixel 9 &middot; Web Share API v2
        </div>
      </div>
    </div>
  );
};
