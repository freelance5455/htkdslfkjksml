import React from 'react';
import { 
  Flame, 
  BookOpen, 
  Zap, 
  Rotate3d, 
  Trophy, 
  Bot, 
  User 
} from 'lucide-react';
import { soundManager } from '../../utils/audio';

export type TabType = 'dungeon' | 'dictionary' | 'academy' | '3d' | 'quiz' | 'ai' | 'profile';

interface Props {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  soundEnabled: boolean;
}

export const BottomNavBar: React.FC<Props> = ({ activeTab, onChangeTab, soundEnabled }) => {
  const tabs = [
    { id: 'dungeon' as TabType, label: 'البوابات', icon: Flame },
    { id: 'dictionary' as TabType, label: 'القاموس', icon: BookOpen },
    { id: 'academy' as TabType, label: 'الأكاديمية', icon: Zap },
    { id: '3d' as TabType, label: 'Anatomie 3D', icon: Rotate3d },
    { id: 'quiz' as TabType, label: 'التحديات', icon: Trophy },
    { id: 'ai' as TabType, label: 'الذكاء الطبي', icon: Bot },
    { id: 'profile' as TabType, label: 'الصياد', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-purple-500/30 px-2 py-1.5 pb-safe shadow-[0_-5px_25px_rgba(139,92,246,0.15)]">
      <div className="max-w-xl mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (!isActive) {
                  soundManager.playSlash(soundEnabled);
                  onChangeTab(tab.id);
                }
              }}
              className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active Neon Glow Pill */}
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-t from-purple-600/40 to-transparent rounded-xl border-t-2 border-purple-400" />
              )}

              <Icon className={`w-5 h-5 relative z-10 transition-transform ${isActive ? 'scale-110 text-purple-400' : ''}`} />
              <span className={`text-[10px] relative z-10 mt-1 font-bold ${isActive ? 'text-purple-300' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
