import React from 'react';
import {
  Home,
  Library,
  Users,
  Search,
  Calendar,
  BarChart3,
  Quote,
  User,
} from 'lucide-react';

interface TabBarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
}

export const TabBar: React.FC<TabBarProps> = ({ activeTab, onNavigate }) => {
  const tabs = [
    { id: 'inicio', label: 'Inicio', icon: Home },
    { id: 'biblioteca', label: 'Biblioteca', icon: Library },
    { id: 'comunidad', label: 'Comunidad', icon: Users },
    { id: 'buscar', label: 'Buscar', icon: Search },
    { id: 'frases', label: 'Frases', icon: Quote },
    { id: 'perfil', label: 'Perfil', icon: User },
  ];

  return (
    <nav
      aria-label="Navegación principal"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 glass-panel border-t border-white/[0.08] px-1 py-1 pb-[max(0.5rem,env(safe-area-inset-bottom))]"
    >
      <div className="grid grid-cols-6 items-center h-14">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors group relative ${
                isActive ? 'text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 stroke-[2.2]' : 'group-hover:scale-105'
                  }`}
                  style={isActive ? { color: 'var(--system-accent, #ffffff)' } : undefined}
                />
                {isActive && (
                  <span
                    className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: 'var(--system-accent, #ffffff)' }}
                  />
                )}
              </div>
              <span
                className={`text-[9.5px] tracking-tight mt-1 truncate max-w-[48px] ${
                  isActive ? 'font-semibold' : 'font-normal'
                }`}
                style={isActive ? { color: 'var(--system-accent, #ffffff)' } : undefined}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
