import React from 'react';
import { ArrowLeft, MoreVertical, Smartphone, Monitor, Moon, Sun, Sparkles } from 'lucide-react';
import { AppThemeSettings } from '../../types';

interface M3TopAppBarProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  actions?: React.ReactNode;
  themeSettings: AppThemeSettings;
  onToggleTheme: () => void;
  onToggleDeviceMode: () => void;
}

export const M3TopAppBar: React.FC<M3TopAppBarProps> = ({
  title,
  subtitle,
  showBack,
  onBack,
  actions,
  themeSettings,
  onToggleTheme,
  onToggleDeviceMode
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md border-b border-neutral-200/80 dark:border-neutral-800 transition-colors">
      <div className="flex items-center gap-3 min-w-0">
        {showBack && (
          <button
            type="button"
            onClick={onBack}
            className="p-2 -ml-1 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors active:scale-95"
            aria-label="Navigate back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}
        <div className="min-w-0">
          <h1 className="text-lg font-bold text-neutral-900 dark:text-white truncate flex items-center gap-2">
            <span>{title}</span>
          </h1>
          {subtitle && (
            <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">{subtitle}</p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        {/* Device Mode Toggle Button (Mobile vs Full Studio) */}
        <button
          type="button"
          onClick={onToggleDeviceMode}
          title={themeSettings.deviceMode === 'phone' ? 'Switch to Full-Screen Studio' : 'Switch to Pixel 8 Mobile Frame'}
          aria-label={themeSettings.deviceMode === 'phone' ? 'Full Screen View' : 'Phone View'}
          className="p-2 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
        >
          {themeSettings.deviceMode === 'phone' ? (
            <Monitor className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          ) : (
            <Smartphone className="w-4 h-4 text-neutral-600 dark:text-neutral-300" />
          )}
        </button>

        {/* Dark/Light mode toggle */}
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label="Toggle dark mode"
          className="p-2 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
        >
          {themeSettings.isDark ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-neutral-600" />
          )}
        </button>

        {actions}
      </div>
    </header>
  );
};
