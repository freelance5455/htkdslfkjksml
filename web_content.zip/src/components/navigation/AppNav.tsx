import React from 'react';
import { MessageSquare, CircleDot, Users, Phone, User, Settings, Shield } from 'lucide-react';
import { Profile } from '../../types';

export type ActiveTab = 'chats' | 'status' | 'friends' | 'calls' | 'profile' | 'settings';

type AppNavProps = {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  totalUnreadCount: number;
  pendingRequestsCount: number;
  currentUserProfile: Profile | null;
  onOpenSetup: () => void;
};

export const AppNav: React.FC<AppNavProps> = ({
  activeTab,
  onChangeTab,
  totalUnreadCount,
  pendingRequestsCount,
  currentUserProfile,
  onOpenSetup,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'chats',
      label: 'Chats',
      icon: <MessageSquare className="w-5 h-5" />,
      badge: totalUnreadCount,
    },
    {
      id: 'status',
      label: 'Updates',
      icon: <CircleDot className="w-5 h-5" />,
    },
    {
      id: 'friends',
      label: 'Friends',
      icon: <Users className="w-5 h-5" />,
      badge: pendingRequestsCount,
    },
    {
      id: 'calls',
      label: 'Calls',
      icon: <Phone className="w-5 h-5" />,
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: currentUserProfile?.avatar_url ? (
        <div className="w-6 h-6 rounded-full overflow-hidden border border-neutral-600">
          <img
            src={currentUserProfile.avatar_url}
            alt={currentUserProfile.display_name}
            className="w-full h-full object-cover"
          />
        </div>
      ) : (
        <User className="w-5 h-5" />
      ),
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings className="w-5 h-5" />,
    },
  ];

  return (
    <>
      {/* Desktop Left Rail (hidden on mobile) */}
      <nav
        id="desktop-nav-rail"
        className="hidden md:flex flex-col items-center justify-between w-16 bg-neutral-950 border-r border-neutral-800/80 py-4 select-none shrink-0 z-30"
      >
        <div className="flex flex-col items-center space-y-6">
          {/* Logo */}
          <div
            className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-950/50 cursor-pointer"
            title="Nexa Messenger"
            onClick={() => onChangeTab('chats')}
          >
            <Shield className="w-5 h-5" />
          </div>

          {/* Nav Icons */}
          <div className="flex flex-col items-center space-y-3">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-item-desktop-${item.id}`}
                  onClick={() => onChangeTab(item.id)}
                  className={`relative p-3 rounded-2xl transition-all ${
                    isActive
                      ? 'bg-emerald-600/15 text-emerald-400 border border-emerald-500/30'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
                  }`}
                  title={item.label}
                >
                  {item.icon}
                  {Boolean(item.badge && item.badge > 0) && (
                    <span className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom User Avatar / Quick Settings */}
        <div className="flex flex-col items-center space-y-2">
          <button
            onClick={onOpenSetup}
            className="p-2 text-neutral-500 hover:text-neutral-300 rounded-xl hover:bg-neutral-900 transition-colors"
            title="Supabase Database Settings"
          >
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md border border-neutral-700 bg-neutral-900">
              SQL
            </span>
          </button>
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar (hidden on desktop) */}
      <nav
        id="mobile-bottom-nav"
        className="md:hidden h-16 bg-neutral-950 border-t border-neutral-800 flex items-center justify-around px-2 select-none shrink-0 z-30"
      >
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-mobile-${item.id}`}
              onClick={() => onChangeTab(item.id)}
              className={`relative flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-colors ${
                isActive ? 'text-emerald-400 font-semibold' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <div className="relative">
                {item.icon}
                {Boolean(item.badge && item.badge > 0) && (
                  <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
