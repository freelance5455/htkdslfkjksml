import React from 'react';
import { Home, FolderOpen, Wrench, Settings } from 'lucide-react';

export type MainTab = 'home' | 'files' | 'tools' | 'settings';

interface M3BottomNavigationProps {
  currentTab: MainTab;
  onTabChange: (tab: MainTab) => void;
  accentColor?: string;
}

export const M3BottomNavigation: React.FC<M3BottomNavigationProps> = ({
  currentTab,
  onTabChange,
  accentColor = '#1972E8'
}) => {
  const tabs = [
    { id: 'home' as MainTab, label: 'Home', icon: Home },
    { id: 'files' as MainTab, label: 'Files', icon: FolderOpen },
    { id: 'tools' as MainTab, label: 'Tools', icon: Wrench },
    { id: 'settings' as MainTab, label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="sticky bottom-0 z-30 flex items-center justify-around px-2 py-2 bg-neutral-50/95 dark:bg-neutral-900/95 backdrop-blur-md border-t border-neutral-200/80 dark:border-neutral-800 transition-colors">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;

        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onTabChange(tab.id)}
            aria-label={`Tab ${tab.label}`}
            className="flex flex-col items-center justify-center flex-1 py-1 transition-all group"
          >
            <div
              className={`flex items-center justify-center px-4 py-1 rounded-full transition-all duration-200 ${
                isActive
                  ? 'bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-medium scale-105'
                  : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
              }`}
            >
              <Icon className="w-5 h-5 transition-transform" />
            </div>
            <span
              className={`text-[11px] mt-1 tracking-tight transition-colors ${
                isActive
                  ? 'text-blue-700 dark:text-blue-300 font-semibold'
                  : 'text-neutral-500 dark:text-neutral-400'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
