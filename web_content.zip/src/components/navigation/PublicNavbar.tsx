import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Store as StoreIcon, 
  Globe, 
  ArrowRight,
  LogIn,
  UserPlus,
  LayoutDashboard
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const PublicNavbar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { language, setLanguage, setIsAuthModalOpen, setAuthModalMode } = useApp();
  const { currentUser, logout } = useAuth();
  const isBn = language === 'bn';
  const isDashboardRoute = location.pathname.startsWith('/dashboard');

  const scrollToSection = (id: string) => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 text-white border-b border-slate-800/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Public Brand Logo */}
          <Link 
            to="/"
            className="flex items-center gap-3 group text-left focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform font-bold">
              <StoreIcon className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-200 bg-clip-text text-transparent">
                  Shanju
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Cloud Commerce
                </span>
              </div>
              <span className="text-[10px] text-slate-400 hidden sm:block">
                {isBn ? 'ই-কমার্স ক্লাউড প্ল্যাটফর্ম' : 'Next-Gen E-Commerce SaaS Engine'}
              </span>
            </div>
          </Link>

          {/* Public Marketing Links (Desktop) - Strictly Informational */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-300">
            <button
              onClick={() => scrollToSection('features')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'ফিচারসমূহ' : 'Features'}
            </button>
            <button
              onClick={() => scrollToSection('how-it-works')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'কিভাবে কাজ করে' : 'How It Works'}
            </button>
            <button
              onClick={() => scrollToSection('calculator')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'সাশ্রয় ক্যালকুলেটর' : 'ROI Calculator'}
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'মূল্য তালিকা' : 'Pricing'}
            </button>
            <button
              onClick={() => scrollToSection('testimonials')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'গ্রাহকদের রিভিউ' : 'Testimonials'}
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              {isBn ? 'প্রশ্নোত্তর' : 'FAQ'}
            </button>
          </nav>

          {/* Public Right Action Controls */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* Language Switcher */}
            <button
              id="public-language-toggle-btn"
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-slate-300 border border-slate-800 transition-colors cursor-pointer"
              title="Toggle Language"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
            </button>

            {/* Public Sign In / Account Buttons */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                {!isDashboardRoute && (
                  <Link
                    to="/dashboard"
                    className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-xs font-semibold transition-all cursor-pointer"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5" />
                    <span>{isBn ? 'ড্যাশবোর্ড' : 'Dashboard'}</span>
                  </Link>
                )}
                <span className="text-xs text-slate-400 hidden md:inline truncate max-w-[120px]">
                  {currentUser.displayName || currentUser.email}
                </span>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:text-white text-xs font-semibold transition-all cursor-pointer"
                >
                  {isBn ? 'লগআউট' : 'Sign Out'}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setAuthModalMode('login');
                    setIsAuthModalOpen(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-slate-700 text-xs font-semibold transition-all cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isBn ? 'লগইন' : 'Sign In'}</span>
                </button>
                <button
                  onClick={() => {
                    setAuthModalMode('register');
                    setIsAuthModalOpen(true);
                  }}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold transition-all cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{isBn ? 'একাউন্ট খুলুন' : 'Sign Up'}</span>
                </button>
              </div>
            )}

            {/* Primary Action Button */}
            {!currentUser ? (
              <button
                onClick={() => {
                  setAuthModalMode('register');
                  setIsAuthModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 text-slate-950 font-black text-xs shadow-md shadow-emerald-500/20 transition-all transform hover:scale-[1.02] cursor-pointer"
              >
                <span>{isBn ? 'শুরু করুন' : 'Get Started'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : !isDashboardRoute ? (
              <Link
                to="/dashboard"
                className="flex sm:hidden items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>{isBn ? 'ড্যাশবোর্ড' : 'Dashboard'}</span>
              </Link>
            ) : null}
          </div>
        </div>
      </div>
    </header>
  );
};
