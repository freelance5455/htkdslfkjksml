import React from 'react';
import {
  BookOpen,
  Plus,
  Shuffle,
  Settings,
  Search,
  Upload,
} from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  onOpenAddBook: () => void;
  onOpenImportBook?: () => void;
  onOpenRandomBook: () => void;
  onOpenSettings: () => void;
  onNavigate: (tab: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onOpenAddBook,
  onOpenImportBook,
  onOpenRandomBook,
  onOpenSettings,
  onNavigate,
}) => {
  const navItems = [
    { id: 'inicio', label: 'Inicio' },
    { id: 'biblioteca', label: 'Biblioteca' },
    { id: 'comunidad', label: 'Comunidad' },
    { id: 'buscar', label: 'Buscar' },
    { id: 'calendario', label: 'Calendario' },
    { id: 'frases', label: 'Mis frases' },
    { id: 'perfil', label: 'Perfil' },
  ];

  return (
    <header className="sticky top-0 z-30 w-full glass-panel border-b border-white/[0.08] px-4 md:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onNavigate('inicio')}
          className="flex items-center gap-2.5 text-left group focus:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-white/[0.06] border border-white/10 flex items-center justify-center text-zinc-200 group-hover:text-white group-hover:border-white/20 transition-colors">
            <BookOpen className="w-4 h-4" />
          </div>
          <span className="text-base md:text-lg font-bold tracking-tight text-white font-['Syne']">
            Mi Biblioteca
          </span>
        </button>

        {/* Zone 2: Navigation Links for Tablet / Desktop */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs lg:text-sm font-medium transition-all ${
                  isActive
                    ? 'text-white bg-white/15 shadow-sm border font-semibold'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                }`}
                style={isActive ? { borderColor: 'var(--system-accent, rgba(255,255,255,0.3))' } : undefined}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Search for Mobile (Screen 1 in IMG_0575) */}
          <button
            onClick={() => onNavigate('buscar')}
            title="Buscar libros"
            className="md:hidden w-8 h-8 rounded-lg bg-white/[0.05] hover:bg-white/10 active:scale-95 border border-white/10 flex items-center justify-center text-zinc-300 hover:text-white transition-all"
            aria-label="Buscar"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenRandomBook}
            title="Elegir libro aleatorio"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-white/[0.05] hover:bg-white/10 active:scale-95 border border-white/10 flex items-center justify-center text-zinc-300 hover:text-white transition-all"
            aria-label="Qué leer aleatorio"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettings}
            title="Configuración"
            className="w-9 h-9 rounded-lg bg-white/[0.05] hover:bg-white/10 active:scale-95 border border-white/10 flex items-center justify-center text-zinc-300 hover:text-white transition-all"
            aria-label="Abrir configuración"
          >
            <Settings className="w-4 h-4" />
          </button>

          {onOpenImportBook && (
            <button
              onClick={onOpenImportBook}
              title="Importar libro (.epub, .pdf, .txt, .json)"
              className="px-3 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/10 text-zinc-200 hover:text-white border border-white/10 text-xs md:text-sm font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Upload className="w-3.5 h-3.5 text-zinc-300" />
              <span className="hidden sm:inline">Importar</span>
            </button>
          )}

          <button
            onClick={onOpenAddBook}
            className="px-3.5 py-1.5 rounded-lg bg-white/[0.1] hover:bg-white/[0.16] text-white border border-white/20 text-xs md:text-sm font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Agregar libro</span>
          </button>
        </div>
      </div>
    </header>
  );
};
