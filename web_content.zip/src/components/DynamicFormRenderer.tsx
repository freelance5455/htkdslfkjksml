import React, { useEffect, useMemo, useState } from 'react';
import { Calculator } from 'lucide-react';
import { evaluateRecordValues } from '../engine/calculations';
import type {
  CustomModule,
  CustomRecord,
  CustomSubmodule,
  FieldDefinition,
  FieldMapping,
  FormulaDefinition,
  MasterList,
} from '../types/app';

interface DynamicFormRendererProps {
  submoduleId: string;
  fields: FieldDefinition[];
  formulas: FormulaDefinition[];
  mappings: FieldMapping[];
  masterLists: MasterList[];
  allRecords: CustomRecord[];
  modules: CustomModule[];
  submodules: CustomSubmodule[];
  currency: string;
  initialValues?: Record<string, unknown>;
  submitLabel?: string;
  onSubmit: (values: Record<string, unknown>) => void | Promise<void>;
  onCancel?: () => void;
  sandboxNotice?: string;
}

export const DynamicFormRenderer: React.FC<DynamicFormRendererProps> = ({
  submoduleId,
  fields,
  formulas,
  mappings,
  masterLists,
  allRecords,
  modules,
  submodules,
  currency,
  initialValues,
  submitLabel = 'Save Record',
  onSubmit,
  onCancel,
  sandboxNotice,
}) => {
  const visibleFields = useMemo(
    () =>
      fields
        .filter((f) => f.submoduleId === submoduleId && f.visible)
        .sort((a, b) => a.position - b.position),
    [fields, submoduleId]
  );

  const buildDefaults = () => {
    const init: Record<string, unknown> = {};
    for (const f of visibleFields) {
      if (initialValues && initialValues[f.name] !== undefined) {
        init[f.name] = initialValues[f.name];
      } else if (f.type === 'checkbox') {
        init[f.name] = f.defaultValue === 'true';
      } else if (f.type === 'yesno') {
        init[f.name] = f.defaultValue || 'Yes';
      } else if (f.type === 'multiselect') {
        init[f.name] = f.defaultValue ? f.defaultValue.split(',').map((s) => s.trim()) : [];
      } else {
        init[f.name] = f.defaultValue ?? '';
      }
    }
    return init;
  };

  const [rawValues, setRawValues] = useState<Record<string, unknown>>(buildDefaults);

  useEffect(() => {
    setRawValues(buildDefaults());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submoduleId, initialValues]);

  const evaluated = useMemo(
    () =>
      evaluateRecordValues({
        submoduleId,
        rawValues,
        fields,
        formulas,
        mappings,
        allRecords,
        modules,
        submodules,
      }),
    [submoduleId, rawValues, fields, formulas, mappings, allRecords, modules, submodules]
  );

  const getFieldOptions = (field: FieldDefinition): string[] => {
    if (field.masterListId) {
      const ml = masterLists.find((m) => m.id === field.masterListId);
      if (ml) {
        return [...ml.options].sort((a, b) => a.position - b.position).map((o) => o.label);
      }
    }
    return field.dropdownOptions || [];
  };

  const handleChange = (name: string, value: unknown) => {
    setRawValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(evaluated.values);
  };

  if (visibleFields.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-sm text-slate-600">
        No visible fields configured for this submodule yet. Add fields in Settings → Field Builder.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {sandboxNotice && (
        <div className="rounded-lg bg-amber-50 border border-amber-200 px-3.5 py-2 text-xs font-medium text-amber-800">
          {sandboxNotice}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {visibleFields.map((field) => {
          const val = field.type === 'formula' ? evaluated.values[field.name] : rawValues[field.name];
          const err = evaluated.errors[field.name];
          const options = getFieldOptions(field);
          const inputId = `dyn-field-${field.id}`;
          const isReadOnly = !field.editable || field.type === 'formula';

          return (
            <div
              key={field.id}
              className={field.type === 'notes' ? 'sm:col-span-2' : ''}
            >
              <label
                htmlFor={inputId}
                className="flex items-center justify-between gap-2 text-xs font-semibold text-slate-700 mb-1"
              >
                <span className="flex items-center gap-1.5">
                  <span
                    className="w-2 h-2 rounded-xs inline-block"
                    style={{ backgroundColor: field.color || '#0B1F3A' }}
                    aria-hidden="true"
                  />
                  <span>
                    {field.label}
                    {field.required && field.type !== 'formula' ? ' *' : ''}
                  </span>
                </span>
                {field.type === 'currency' && (
                  <span className="text-[11px] font-normal text-slate-400">{currency}</span>
                )}
                {field.type === 'percentage' && (
                  <span className="text-[11px] font-normal text-slate-400">%</span>
                )}
                {field.type === 'formula' && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-normal text-emerald-700">
                    <Calculator className="w-3 h-3" aria-hidden="true" />
                    Auto
                  </span>
                )}
              </label>

              {field.type === 'text' && (
                <input
                  id={inputId}
                  type="text"
                  required={field.required}
                  readOnly={isReadOnly}
                  placeholder={field.placeholder}
                  value={String(val ?? '')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white disabled:bg-slate-100"
                />
              )}

              {(field.type === 'number' || field.type === 'currency' || field.type === 'percentage') && (
                <input
                  id={inputId}
                  type="number"
                  step={field.decimalPlaces > 0 ? Math.pow(10, -field.decimalPlaces).toString() : '1'}
                  min={field.minValue}
                  max={field.maxValue}
                  required={field.required}
                  readOnly={isReadOnly}
                  placeholder={field.placeholder || '0'}
                  value={val === undefined || val === null ? '' : String(val)}
                  onChange={(e) => handleChange(field.name, e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num bg-white"
                />
              )}

              {field.type === 'date' && (
                <input
                  id={inputId}
                  type="date"
                  required={field.required}
                  readOnly={isReadOnly}
                  value={String(val ?? '')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                />
              )}

              {field.type === 'time' && (
                <input
                  id={inputId}
                  type="time"
                  required={field.required}
                  readOnly={isReadOnly}
                  value={String(val ?? '')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                />
              )}

              {field.type === 'dropdown' && (
                <select
                  id={inputId}
                  required={field.required}
                  disabled={isReadOnly}
                  value={String(val ?? '')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                >
                  <option value="">Select {field.label}...</option>
                  {options.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                  {/* Preserve historical saved value if master list option was renamed */}
                  {Boolean(val) && !options.includes(String(val)) && (
                    <option value={String(val)}>{String(val)} (Saved)</option>
                  )}
                </select>
              )}

              {field.type === 'multiselect' && (
                <div className="rounded-lg border border-slate-300 p-2.5 bg-white max-h-36 overflow-y-auto space-y-1.5">
                  {options.length === 0 ? (
                    <span className="text-xs text-slate-400">No options configured</span>
                  ) : (
                    options.map((opt) => {
                      const arr = Array.isArray(val) ? (val as string[]) : [];
                      const checked = arr.includes(opt);
                      return (
                        <label key={opt} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                          <input
                            type="checkbox"
                            disabled={isReadOnly}
                            checked={checked}
                            onChange={(e) => {
                              const next = e.target.checked
                                ? [...arr, opt]
                                : arr.filter((x) => x !== opt);
                              handleChange(field.name, next);
                            }}
                          />
                          <span>{opt}</span>
                        </label>
                      );
                    })
                  )}
                </div>
              )}

              {field.type === 'checkbox' && (
                <label className="flex items-center gap-2.5 py-2 px-3 rounded-lg border border-slate-200 bg-slate-50 text-sm text-slate-800 cursor-pointer">
                  <input
                    id={inputId}
                    type="checkbox"
                    disabled={isReadOnly}
                    checked={Boolean(val)}
                    onChange={(e) => handleChange(field.name, e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  <span>{field.placeholder || 'Checked / Enabled'}</span>
                </label>
              )}

              {field.type === 'yesno' && (
                <select
                  id={inputId}
                  disabled={isReadOnly}
                  value={String(val || 'Yes')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                >
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                </select>
              )}

              {field.type === 'notes' && (
                <textarea
                  id={inputId}
                  rows={2}
                  required={field.required}
                  readOnly={isReadOnly}
                  placeholder={field.placeholder}
                  value={String(val ?? '')}
                  onChange={(e) => handleChange(field.name, e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                />
              )}

              {field.type === 'formula' && (
                <div
                  id={inputId}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono-num font-bold ${
                    err
                      ? 'border-red-300 bg-red-50 text-red-700'
                      : 'border-emerald-200 bg-emerald-50/70 text-emerald-900'
                  }`}
                >
                  {err ? `Error: ${err}` : String(val ?? '0')}
                </div>
              )}

              {err && field.type !== 'formula' && (
                <p className="mt-1 text-xs text-red-600">{err}</p>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          className="px-5 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
        >
          {submitLabel}
        </button>
      </div>
    </form>
  );
};
