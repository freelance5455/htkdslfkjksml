import React from 'react';
import { AvatarConfig, WorldConfig } from '../types/game';

export const MiniAvatarIcon: React.FC<{ avatar: AvatarConfig; size?: number }> = ({
  avatar,
  size = 36,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 40 40"
    className="rounded-full shrink-0 bg-slate-800 border border-white/15"
    aria-hidden="true"
  >
    <rect width="40" height="40" fill="#18181b" />
    {/* Arms */}
    <rect x="6" y="18" width="6" height="12" rx="1" fill={avatar.skinColor} />
    <rect x="28" y="18" width="6" height="12" rx="1" fill={avatar.skinColor} />
    {/* Legs */}
    <rect x="13" y="30" width="6.5" height="10" fill={avatar.pantsColor} />
    <rect x="20.5" y="30" width="6.5" height="10" fill={avatar.pantsColor} />
    {/* Torso */}
    <rect x="13" y="18" width="14" height="12" rx="1" fill={avatar.shirtColor} />
    {/* Head */}
    {!avatar.headless && (
      <>
        <rect x="14" y="8" width="12" height="10" rx="1" fill={avatar.skinColor} />
        <rect x="16.5" y="11" width="2.2" height="3.8" fill="#09090b" />
        <rect x="21.3" y="11" width="2.2" height="3.8" fill="#09090b" />
      </>
    )}
    {/* Hair */}
    {!avatar.headless && avatar.hairStyle && avatar.hairStyle !== 'none' && (
      <>
        {avatar.hairStyle === 'mohawk' ? (
          <rect x="18" y="3.5" width="4" height="5" rx="1" fill={avatar.hairColor || '#18181b'} />
        ) : avatar.hairStyle === 'long' ? (
          <>
            <rect x="13" y="6" width="14" height="4" rx="1.5" fill={avatar.hairColor || '#18181b'} />
            <rect x="12.2" y="8" width="2.2" height="12" rx="1" fill={avatar.hairColor || '#18181b'} />
            <rect x="25.6" y="8" width="2.2" height="12" rx="1" fill={avatar.hairColor || '#18181b'} />
          </>
        ) : avatar.hairStyle === 'curly' ? (
          <>
            <circle cx="15.5" cy="7.5" r="3" fill={avatar.hairColor || '#18181b'} />
            <circle cx="20" cy="6.5" r="3.4" fill={avatar.hairColor || '#18181b'} />
            <circle cx="24.5" cy="7.5" r="3" fill={avatar.hairColor || '#18181b'} />
          </>
        ) : (
          <rect x="13" y="6" width="14" height="4" rx="1.5" fill={avatar.hairColor || '#18181b'} />
        )}
      </>
    )}
    {avatar.hatStyle === 'crown' && (
      <polygon points="14,8 16,4 20,7 24,4 26,8" fill="#eab308" />
    )}
    {avatar.hatStyle === 'cap' && (
      <rect x="13" y="5.5" width="14" height="3.5" rx="1" fill={avatar.hatColor} />
    )}
    {avatar.hatStyle === 'party' && (
      <polygon points="15,8 20,2 25,8" fill={avatar.hatColor} />
    )}
  </svg>
);

export const GameThumbnail: React.FC<{ theme: WorldConfig['thumbTheme'] }> = ({ theme }) => {
  switch (theme) {
    case 'pickbux':
      return (
        <div className="relative w-full h-full bg-gradient-to-br from-cyan-400 via-teal-400 to-lime-300 overflow-hidden flex items-center justify-center p-3">
          <div className="transform -rotate-6 text-center leading-tight">
            <div className="font-display font-extrabold text-[11px] tracking-wider text-white drop-shadow">
              MENDAPATKAN
            </div>
            <div className="font-display font-black text-base text-cyan-950 bg-white/80 px-2 py-0.5 rounded mt-0.5">
              SLAPBUX
            </div>
            <div className="font-display font-extrabold text-[11px] text-white mt-0.5 drop-shadow">
              SECARA GRATIS
            </div>
          </div>
          <div className="absolute right-2 bottom-1 w-9 h-9 rounded-lg bg-amber-300 border-2 border-slate-900 flex items-center justify-center font-display font-bold text-slate-900 text-xs">
            SB
          </div>
        </div>
      );

    case 'voice':
      return (
        <div className="relative w-full h-full bg-gradient-to-br from-amber-500 via-orange-500 to-red-600 overflow-hidden flex flex-col items-center justify-end pb-2">
          <div className="flex items-end gap-2 mb-1">
            <div className="w-10 h-10 rounded-lg bg-amber-300 border-2 border-slate-900 flex items-center justify-center gap-1.5">
              <span className="w-1.5 h-2.5 bg-slate-900 rounded-sm" />
              <span className="w-1.5 h-2.5 bg-slate-900 rounded-sm" />
            </div>
            <div className="w-8 h-8 rounded-lg bg-amber-200 border-2 border-slate-900 flex items-center justify-center gap-1">
              <span className="w-1 h-2 bg-slate-900 rounded-sm" />
              <span className="w-1 h-2 bg-slate-900 rounded-sm" />
            </div>
          </div>
          <div className="font-display font-black text-sm tracking-tight text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
            INDO VOICE
          </div>
        </div>
      );

    case 'hangout':
      return (
        <div className="relative w-full h-full bg-gradient-to-br from-slate-900 via-zinc-900 to-indigo-950 overflow-hidden flex items-center justify-between px-4">
          <div className="space-y-1">
            <div className="text-[10px] font-semibold text-rose-400">MALAM KOMUNITAS</div>
            <div className="font-display font-bold text-sm text-white">INDO HANGOUT</div>
          </div>
          <div className="w-12 h-14 rounded-t-xl bg-gradient-to-b from-slate-300 to-slate-700 border border-white/20 opacity-85" />
        </div>
      );

    case 'santai':
      return (
        <div className="relative w-full h-full bg-gradient-to-b from-sky-200 to-sky-400 overflow-hidden flex flex-col justify-end">
          <div className="h-4 bg-sky-500 w-full" />
          <div className="h-4 bg-amber-200 w-full" />
          <div className="h-7 bg-emerald-400 w-full flex items-center justify-center">
            <div className="w-4 h-3 bg-sky-200 border border-emerald-700" />
          </div>
        </div>
      );

    case 'obbyez':
      return (
        <div className="relative w-full h-full bg-gradient-to-b from-cyan-300 to-sky-200 overflow-hidden flex flex-col justify-end">
          <div className="relative h-14 bg-rose-500 w-full p-2 flex items-center justify-between">
            <div className="w-7 h-5 bg-amber-100 border border-rose-900 transform -skew-x-12" />
            <div className="flex gap-1.5">
              <div className="w-4 h-4 bg-pink-200 border border-rose-900" />
              <div className="w-4 h-4 bg-pink-200 border border-rose-900" />
              <div className="w-4 h-4 bg-pink-200 border border-rose-900" />
            </div>
          </div>
        </div>
      );

    case 'rainbow':
      return (
        <div className="relative w-full h-full bg-gradient-to-b from-sky-400 to-blue-600 overflow-hidden flex items-end justify-center gap-1 p-3">
          {['#f43f5e', '#fb923c', '#facc15', '#4ade80', '#38bdf8', '#a855f7'].map((c, idx) => (
            <div
              key={c}
              style={{ backgroundColor: c, height: `${26 + idx * 8}%` }}
              className="w-4 rounded-t border border-black/20"
            />
          ))}
        </div>
      );

    case 'lava':
      return (
        <div className="relative w-full h-full bg-gradient-to-b from-amber-950 via-red-900 to-orange-600 overflow-hidden flex items-end justify-center gap-2 p-3">
          <div className="w-8 h-5 bg-slate-700 border-t-2 border-slate-400 rounded-t" />
          <div className="w-7 h-7 bg-slate-700 border-t-2 border-slate-400 rounded-t" />
          <div className="w-8 h-9 bg-slate-700 border-t-2 border-amber-400 rounded-t" />
        </div>
      );

    default:
      return (
        <div className="relative w-full h-full bg-gradient-to-b from-sky-300 to-emerald-500 overflow-hidden flex items-end justify-around p-3">
          <div className="w-8 h-12 bg-blue-500 border-t-4 border-blue-300" />
          <div className="w-6 h-8 bg-amber-100 border-t-4 border-rose-500" />
          <div className="w-8 h-14 bg-rose-500 border-t-4 border-amber-400" />
        </div>
      );
  }
};
