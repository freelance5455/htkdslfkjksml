import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, CheckCircle2, Clock, MapPin, Phone, ArrowRight } from "lucide-react";
import { Dish } from "../types";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDish?: Dish | null;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  initialDish,
}) => {
  const [orderType, setOrderType] = useState<"pickup" | "dinein">("pickup");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [specialInstructions, setSpecialInstructions] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#17201C]/75 backdrop-blur-xs"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame z-10 my-auto shadow-2xl p-5 sm:p-8"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/80 border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {!isSubmitted ? (
            <div>
              <div className="text-[10px] uppercase tracking-widest text-[#9BAF82] font-semibold mb-1">
                Kaloreez Wholesome Kitchen
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#17201C] mb-2">
                Order for Pickup or Table
              </h3>
              <p className="text-xs text-[#17201C]/70 font-sans mb-4">
                Freshly prepared with unrefined oils and clean whole grains in Daspalla Hills, Vizag.
              </p>

              {/* Direct Call Quick Option */}
              <div className="mb-5 p-3 bg-[#F4F0E7] border border-[#D8D0C2] rounded-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs font-sans text-[#17201C]">
                  <Phone className="w-4 h-4 text-[#9BAF82] shrink-0" />
                  <span>Prefer to place your order by call?</span>
                </div>
                <a
                  href={`tel:${RESTAURANT_INFO.phone}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-[11px] font-semibold tracking-wider uppercase hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors shrink-0"
                  title="Direct Phone Call"
                >
                  <Phone className="w-3 h-3" />
                  <span>Call Now</span>
                </a>
              </div>

              {initialDish && (
                <div className="p-3 bg-[#F4F0E7] border border-[#D8D0C2] rounded-xs mb-5 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-[#9BAF82] font-semibold">Selected Item</div>
                    <div className="font-serif text-base text-[#17201C]">{initialDish.name}</div>
                  </div>
                  <div className="text-sm font-serif font-bold text-[#B96D52]">
                    {initialDish.price || "Standard menu price"}
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans">
                {/* Order Type Toggle */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrderType("pickup")}
                    className={`py-2 px-3 rounded-xs border text-center font-medium transition-colors cursor-pointer ${
                      orderType === "pickup"
                        ? "bg-[#17201C] text-[#F4F0E7] border-[#17201C]"
                        : "bg-white text-[#17201C]/70 border-[#D8D0C2]"
                    }`}
                  >
                    Takeaway Pickup (25 mins)
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType("dinein")}
                    className={`py-2 px-3 rounded-xs border text-center font-medium transition-colors cursor-pointer ${
                      orderType === "dinein"
                        ? "bg-[#17201C] text-[#F4F0E7] border-[#17201C]"
                        : "bg-white text-[#17201C]/70 border-[#D8D0C2]"
                    }`}
                  >
                    Dine-in / Table Service
                  </button>
                </div>

                <div>
                  <label className="block uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="E.g., Ananya Rao"
                    className="w-full p-2.5 bg-white border border-[#D8D0C2] rounded-xs focus:outline-none focus:border-[#9BAF82]"
                  />
                </div>

                <div>
                  <label className="block uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full p-2.5 bg-white border border-[#D8D0C2] rounded-xs focus:outline-none focus:border-[#9BAF82]"
                  />
                </div>

                <div>
                  <label className="block uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1">
                    Dietary Notes / Table Requests
                  </label>
                  <textarea
                    rows={2}
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    placeholder="Allergies, seed-oil preferences, or warm plate requests..."
                    className="w-full p-2.5 bg-white border border-[#D8D0C2] rounded-xs focus:outline-none focus:border-[#9BAF82]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3 rounded-full bg-[#17201C] text-[#F4F0E7] font-semibold tracking-widest uppercase hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors cursor-pointer"
                  >
                    Confirm & Send to Kitchen
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#9BAF82]/20 text-[#17201C] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6 text-[#9BAF82]" />
              </div>

              <h3 className="font-serif text-3xl text-[#17201C]">
                Your Order is Received
              </h3>

              <p className="text-xs sm:text-sm text-[#17201C]/75 font-sans leading-relaxed">
                Thank you, <span className="font-semibold">{customerName}</span>. Our team in Daspalla Hills has registered your {orderType === "pickup" ? "takeaway request" : "table reservation"}.
              </p>

              <div className="p-4 bg-[#F4F0E7] rounded-xs border border-[#D8D0C2] text-xs font-sans text-left space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>{RESTAURANT_INFO.address.fullText}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>Ready in approx. 20–25 minutes</span>
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-[#D8D0C2]/50">
                  <Phone className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <a href={`tel:${RESTAURANT_INFO.phone}`} className="font-bold underline">
                    Call Host Desk: {RESTAURANT_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsSubmitted(false);
                  onClose();
                }}
                className="w-full py-2.5 rounded-full border border-[#17201C] text-xs uppercase tracking-wider hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
              >
                Close & Return to Eatery
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
