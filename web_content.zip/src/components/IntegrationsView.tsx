import {
  Blocks,
  Cpu,
  Download,
  FolderCode,
  FolderDown,
  ShieldCheck,
  Smartphone,
  Terminal,
  Zap,
} from 'lucide-react';
import {
  detectAndroidRuntime,
  getForegroundVoicePolicySummary,
  usePWAInstall,
} from '../lib/androidBridge';
import type { AIModelAdapterInfo, IntegrationPluginInfo } from '../lib/jarvisTypes';

interface IntegrationsViewProps {
  models: AIModelAdapterInfo[];
  activeModelId: string;
  onSelectModel: (id: string) => void;
  integrations: IntegrationPluginInfo[];
  onExportProject?: () => void;
  onSaveProject?: () => void;
  exportStatus?: 'idle' | 'exporting' | 'saving';
}

const CATEGORY_ICON = {
  files: FolderCode,
  android: Smartphone,
  computer: Terminal,
  services: Blocks,
};

export function IntegrationsView({
  models,
  activeModelId,
  onSelectModel,
  integrations,
  onExportProject,
  onSaveProject,
  exportStatus = 'idle',
}: IntegrationsViewProps) {
  const androidRuntime = detectAndroidRuntime();
  const { isInstallable, isInstalled, install } = usePWAInstall();

  return (
    <div className="mx-auto max-w-4xl px-4 py-7 sm:px-6" data-testid="integrations-view">
      <div className="mb-8">
        <h1 className="font-display text-2xl font-semibold text-slate-50 sm:text-3xl">
          AI Brain &amp; Modular Integrations
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
          Switch Gemini speed tiers and inspect modular plugin contracts prepared for Android APK wrapping, desktop tools, local files, and external services.
        </p>
      </div>

      {/* Security, Permissions & Android APK Readiness */}
      <section className="mb-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-amber-400/20 bg-[#0B1018] p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/12 text-amber-300">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-base font-semibold text-slate-100">
                Secure Backend &amp; Mic Privacy
              </h2>
              <p className="mt-1 text-sm text-slate-400">
                All Gemini API keys stay isolated on the backend server. Your phone&apos;s built-in microphone is only accessed after explicit permission when Talk mode is active and stops immediately on Stop.
              </p>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-sky-400/20 bg-[#0B1018] p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500/12 text-sky-300">
              <Smartphone className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Android APK &amp; PWA Ready
              </h2>
              <p className="mt-1 text-sm text-slate-400">
                {getForegroundVoicePolicySummary(androidRuntime)}
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                <span className="rounded-lg border border-white/10 bg-[#05070B] px-2.5 py-1 font-mono text-slate-300">
                  {androidRuntime.isCapacitorNative
                    ? 'Android Native Wrapper'
                    : isInstalled
                      ? 'Installed App Mode'
                      : 'PWA / Capacitor Ready'}
                </span>
                {isInstallable && !isInstalled && (
                  <button
                    type="button"
                    onClick={() => void install()}
                    className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg bg-sky-500 px-3 py-1 font-semibold text-slate-950 hover:bg-sky-400"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Install App</span>
                  </button>
                )}
                {onExportProject && (
                  <button
                    type="button"
                    disabled={exportStatus !== 'idle'}
                    onClick={() => onExportProject()}
                    className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-sky-400/35 bg-sky-500/12 px-3 py-1 font-semibold text-sky-200 hover:bg-sky-500/20 disabled:opacity-50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>{exportStatus === 'exporting' ? 'Exporting…' : 'Export Project'}</span>
                  </button>
                )}
                {onSaveProject && (
                  <button
                    type="button"
                    disabled={exportStatus !== 'idle'}
                    onClick={() => onSaveProject()}
                    className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-amber-400/35 bg-amber-500/12 px-3 py-1 font-semibold text-amber-200 hover:bg-amber-500/20 disabled:opacity-50"
                  >
                    <FolderDown className="h-3.5 w-3.5" />
                    <span>{exportStatus === 'saving' ? 'Saving…' : 'Save Project'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Brain Adapters */}
      <section className="mb-9">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="h-4 w-4 text-sky-400" />
            <h2 className="font-display text-base font-semibold text-slate-100">
              Gemini Brain Adapters
            </h2>
          </div>
          <span className="font-mono text-xs text-slate-400 tabular-nums">
            {models.length} adapters
          </span>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {models.map((model, idx) => {
            const isSelected = activeModelId === model.id;
            const spanFull = models.length % 2 === 1 && idx === models.length - 1;
            return (
              <div
                key={model.id}
                className={`flex flex-col justify-between rounded-2xl border p-5 transition-colors ${
                  spanFull ? 'sm:col-span-2' : ''
                } ${
                  isSelected
                    ? 'border-sky-400/50 bg-sky-500/8'
                    : 'border-white/8 bg-[#0B1018]'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-display text-base font-semibold text-slate-100">
                        {model.name}
                      </h3>
                      <div className="mt-0.5 text-xs text-slate-400">
                        {model.provider} · {model.latencyTier}
                      </div>
                    </div>
                    <span className="font-mono text-[11px] text-amber-300">
                      {model.status === 'active' ? 'Ready' : 'Slot'}
                    </span>
                  </div>

                  <p className="mt-3 text-sm leading-relaxed text-slate-300">
                    {model.description}
                  </p>
                  <div className="mt-3 text-xs text-slate-400">
                    {model.capabilities.join(' · ')}
                  </div>
                </div>

                <div className="mt-4 border-t border-white/6 pt-3">
                  {model.status === 'active' ? (
                    <button
                      type="button"
                      onClick={() => onSelectModel(model.id)}
                      className={`min-h-[40px] w-full rounded-xl px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                        isSelected
                          ? 'bg-sky-500/20 text-sky-200 border border-sky-400/40'
                          : 'bg-[#05070B] text-slate-200 border border-white/10 hover:border-sky-400/40'
                      }`}
                    >
                      {isSelected ? 'Selected Brain' : 'Switch to This Brain'}
                    </button>
                  ) : (
                    <div className="text-xs text-slate-400">
                      Configure via server <code className="font-mono text-slate-300">AIRegistry</code> plugin
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Modular Integration Architecture */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-400" />
            <h2 className="font-display text-base font-semibold text-slate-100">
              Modular Capability Plugins
            </h2>
          </div>
          <span className="font-mono text-xs text-slate-400 tabular-nums">
            {integrations.length} modules
          </span>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {integrations.map((plugin) => {
            const Icon = CATEGORY_ICON[plugin.category] || Blocks;
            return (
              <div
                key={plugin.id}
                className="rounded-2xl border border-white/8 bg-[#0B1018] p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-500/12 text-sky-300">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="font-display text-sm font-semibold text-slate-100">
                        {plugin.name}
                      </h3>
                      <div className="mt-0.5 text-xs text-slate-400">
                        {plugin.status === 'active'
                          ? 'Active in Chat Composer'
                          : plugin.status === 'ready'
                            ? 'Adapter Contract Ready'
                            : 'Expandable Slot'}
                      </div>
                    </div>
                  </div>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-slate-300">
                  {plugin.description}
                </p>
                <div className="mt-3 text-xs text-slate-400">
                  {plugin.capabilities.join(' · ')}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
