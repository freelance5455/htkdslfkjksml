import React from 'react';
import {
  ScriptScene,
} from '../data/scriptData';
import {
  Mic,
  Copy,
  Check,
  TrendingUp,
  Briefcase,
  Wrench,
  Video,
  Layers,
  Clock,
  Sparkles,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { calculateEstimatedDuration, formatTime } from '../utils/scriptUtils';

interface SceneDirectorProps {
  scenes: ScriptScene[];
  selectedSceneIndex: number;
  setSelectedSceneIndex: (index: number) => void;
  onGenerateTTSForScene: (scene: ScriptScene) => void;
  isGeneratingTTS: boolean;
  onNavigateToTeleprompter: () => void;
}

export const SceneDirector: React.FC<SceneDirectorProps> = ({
  scenes,
  selectedSceneIndex,
  setSelectedSceneIndex,
  onGenerateTTSForScene,
  isGeneratingTTS,
  onNavigateToTeleprompter,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);
  const activeScene = scenes[selectedSceneIndex] || scenes[0];

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const estimatedDuration = calculateEstimatedDuration(activeScene.textBn);

  return (
    <div className="space-y-6 pb-28">
      {/* Top Banner Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-emerald-950/40 to-slate-900 border border-emerald-900/40 p-6 sm:p-8">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            ২০২৭ ক্যারিয়ার ও কনটেন্ট স্টুডিও
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-bengali tracking-tight leading-tight">
            ২০২৭ সালের আগেই শিখুন <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">শীর্ষ ৫টি ইন-ডিমান্ড স্কিল</span>
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-300 font-bengali leading-relaxed">
            প্রযুক্তির এই দ্রুত পরিবর্তনের যুগে ঐতিহ্যবাহী স্কিল নিয়ে বসে থাকলে পিছিয়ে পড়তে হবে। ভিডিও স্ক্রিপ্টের ৭টি দৃশ্য সরাসরি পরিচালনা করুন, Gemini 3.8 Flash TTS দিয়ে ভয়েসওভার জেনারেট করুন এবং Lyria AI ব্যাকগ্রাউন্ড মিউজিক ট্র্যাক যুক্ত করুন।
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onGenerateTTSForScene(activeScene)}
              disabled={isGeneratingTTS}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50 cursor-pointer"
            >
              <Mic className="w-4 h-4 fill-slate-950" />
              <span className="font-bengali">
                {isGeneratingTTS ? 'ভয়েস তৈরি হচ্ছে...' : 'এই দৃশ্যের জন্য Gemini TTS তৈরি করুন'}
              </span>
            </button>

            <button
              onClick={onNavigateToTeleprompter}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium border border-slate-700 transition cursor-pointer"
            >
              <Video className="w-4 h-4 text-emerald-400" />
              <span className="font-bengali">টেলিপম্পটারে রিহার্সাল শুরু করুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* Scene Navigation Carousel */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none" aria-label="Scene List">
        {scenes.map((scene, idx) => {
          const isSelected = selectedSceneIndex === idx;
          return (
            <button
              key={scene.id}
              onClick={() => setSelectedSceneIndex(idx)}
              className={`flex-shrink-0 flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-left border transition cursor-pointer ${
                isSelected
                  ? 'bg-slate-800/90 border-emerald-500/80 text-white shadow-md shadow-emerald-950/40 ring-1 ring-emerald-500/40'
                  : 'bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center font-mono ${
                  isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {idx === 0 ? 'H' : idx === scenes.length - 1 ? 'O' : idx}
              </div>
              <div className="max-w-[130px] sm:max-w-[160px] truncate">
                <p className="text-xs font-medium font-bengali truncate">{scene.titleBn}</p>
                <p className="text-[10px] text-slate-400 font-mono truncate">{scene.badge}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Scene Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column: Full Script & Voice Generation */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Scene #{activeScene.order} • {activeScene.badge}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                    <Clock className="w-3.5 h-3.5" /> ~{formatTime(estimatedDuration)}
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-white font-bengali mt-1">
                  {activeScene.titleBn}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(activeScene.textBn, activeScene.id)}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                  title="Copy Scene Script"
                  aria-label="Copy Bengali Script"
                >
                  {copiedId === activeScene.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => onGenerateTTSForScene(activeScene)}
                  disabled={isGeneratingTTS}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span className="font-bengali">ভয়েস জেনারেট</span>
                </button>
              </div>
            </div>

            {/* Script Text Box with styled formatting */}
            <div className="mt-4 p-4 sm:p-5 rounded-xl bg-slate-950/70 border border-slate-800/80">
              <p className="font-bengali text-slate-200 text-base sm:text-lg leading-relaxed whitespace-pre-line font-medium">
                {activeScene.textBn}
              </p>
            </div>

            {/* Key Terms tags */}
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">কীওয়ার্ড:</span>
              {activeScene.keyTerms.map((term, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 rounded-md text-xs font-mono bg-slate-800 text-cyan-300 border border-cyan-900/50"
                >
                  {term}
                </span>
              ))}
            </div>

            {/* Director Voice Direction Note */}
            <div className="mt-4 p-3 rounded-lg bg-slate-800/40 border border-slate-700/60 flex items-start gap-2.5 text-xs text-slate-300">
              <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300">ভয়েস ডিরেকশন ও ডেলিভারি টিপ:</strong>{' '}
                <span className="text-slate-300">{activeScene.voiceNotes}</span>
              </div>
            </div>
          </div>

          {/* Concrete Learning Roadmap for this scene */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
            <h3 className="text-base font-bold text-white font-bengali flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              এই স্কিলটি শুরু করার ৩-ধাপের কার্যকরী রোডম্যাপ
            </h3>
            <div className="mt-3 space-y-2.5">
              {activeScene.learningSteps.map((step, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/50 border border-slate-800/60">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold flex items-center justify-center flex-shrink-0">
                    {i + 1}
                  </div>
                  <p className="text-xs sm:text-sm font-bengali text-slate-200 leading-normal">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Production Visuals, Market Stats & Tools */}
        <div className="lg:col-span-5 space-y-6">
          {/* Market Stats Card */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-emerald-400" />
                ২০২৭ মার্কেট ডিমান্ড ও স্যালারি
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                {activeScene.marketStat.demandLevel}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[11px] text-slate-400 font-bengali">ডিমান্ড গ্রোথ (২০২৪-২৭)</span>
                <p className="text-lg sm:text-xl font-extrabold text-emerald-400 font-mono mt-0.5">
                  {activeScene.marketStat.growthRate}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[11px] text-slate-400 font-bengali">গ্লোবাল রিমোট স্যালারি</span>
                <p className="text-sm sm:text-base font-bold text-cyan-300 font-mono mt-0.5">
                  {activeScene.marketStat.remoteSalary}
                </p>
              </div>

              <div className="col-span-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[11px] text-slate-400 font-bengali">বাংলাদেশি মার্কেট ও এজেন্সি রেঞ্জ</span>
                <p className="text-sm sm:text-base font-bold text-amber-300 font-bengali mt-0.5">
                  {activeScene.marketStat.localSalary}
                </p>
              </div>
            </div>
          </div>

          {/* Video Production Director's Cues (B-Roll & Lower Thirds) */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
              <Video className="w-4 h-4 text-cyan-400" />
              ভিডিও প্রোডাকশন সিগন্যাল ও B-Roll পরিকল্পনা
            </h3>

            <div className="mt-3 space-y-3">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                <span className="text-[11px] text-cyan-400 font-bengali font-bold block mb-1">
                  🎥 রিকমেন্ডেড B-Roll দৃশ্য পরিকল্পনা:
                </span>
                <p className="text-xs text-slate-300 italic font-sans">
                  "{activeScene.bRollPrompt}"
                </p>
              </div>

              <div>
                <span className="text-[11px] text-slate-400 font-bengali block mb-2">
                  📺 স্ক্রিনে ভেসে ওঠার টেক্সট / লোয়ার থার্ড:
                </span>
                <div className="space-y-1.5">
                  {activeScene.onScreenGraphics.map((graphic, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 text-xs font-bengali text-slate-200 bg-slate-800/60 px-2.5 py-1.5 rounded-lg border border-slate-700/60"
                    >
                      <Layers className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>{graphic}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Tools Required */}
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
              <Wrench className="w-4 h-4 text-emerald-400" />
              প্রয়োজনীয় টুলস ও প্ল্যাটফর্ম
            </h3>

            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {activeScene.tools.map((tool, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-white">{tool.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                      {tool.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                    {tool.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
