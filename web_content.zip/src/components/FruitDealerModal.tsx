import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Flame, Sparkles, X, Zap } from 'lucide-react';
import { FRUITS } from '../game/worldData';
import { FruitType, PlayerStats } from '../types/game';

interface FruitDealerModalProps {
  stats: PlayerStats;
  onClose: () => void;
  onSpin: () => FruitType | null;
  onEatDirectly: (fruit: FruitType) => void;
}

export const FruitDealerModal: React.FC<FruitDealerModalProps> = ({
  stats,
  onClose,
  onSpin,
  onEatDirectly,
}) => {
  const [spinning, setSpinning] = useState(false);
  const [spunFruit, setSpunFruit] = useState<FruitType | null>(null);
  const [selectedFruitPreview, setSelectedFruitPreview] = useState<FruitType>('flame');

  const handleSpinClick = () => {
    if (spinning) return;
    setSpinning(true);
    setSpunFruit(null);

    let counter = 0;
    const interval = setInterval(() => {
      counter++;
      const keys = Object.keys(FRUITS) as FruitType[];
      setSelectedFruitPreview(keys[counter % keys.length]);

      if (counter > 15) {
        clearInterval(interval);
        const result = onSpin();
        setSpinning(false);
        if (result) {
          setSpunFruit(result);
          setSelectedFruitPreview(result);
          confetti({ particleCount: 75, spread: 70, origin: { y: 0.6 } });
        }
      }
    }, 90);
  };

  const previewData = FRUITS[selectedFruitPreview];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Blox Fruit Dealer</h2>
              <p className="text-xs text-slate-400">Spin random Devil Fruits or examine legendary fruit powers</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Gacha Spin Banner */}
          <div className="bg-gradient-to-r from-purple-950/60 to-slate-950 border border-purple-600/40 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-purple-300 uppercase bg-purple-900/50 px-2 py-0.5 rounded border border-purple-700">
                  Fruit Gacha
                </span>
                <span className="text-xs text-slate-400">Instant Store or Eat</span>
              </div>
              <h3 className="text-lg font-bold text-white mt-1">Spin Random Devil Fruit</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                Chances for Common, Rare, Legendary, or Mythical Buddha fruit!
              </p>
              <div className="mt-2 text-xs font-mono text-emerald-400 font-bold">
                Cost: 25,000 Beli (You have: {stats.beli.toLocaleString()} Beli)
              </div>
            </div>

            <button
              onClick={handleSpinClick}
              disabled={spinning || stats.beli < 25000}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg cursor-pointer transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shrink-0 flex items-center gap-2"
            >
              <Sparkles className={`w-4 h-4 ${spinning ? 'animate-spin' : ''}`} />
              <span>{spinning ? 'Rolling...' : 'Spin Fruit (25,000)'}</span>
            </button>
          </div>

          {/* Won Fruit Notification */}
          {spunFruit && (
            <div className="bg-emerald-950/60 border border-emerald-500/60 rounded-xl p-4 flex items-center justify-between gap-4 animate-bounce">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-800/40 border border-emerald-500/50 flex items-center justify-center text-emerald-300">
                  <Flame className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold uppercase">Spun Fruit Revealed!</span>
                  <div className="font-bold text-white text-base">{FRUITS[spunFruit]?.name}</div>
                  <span className="text-xs text-slate-300">Added to your fruit inventory bag!</span>
                </div>
              </div>
              <button
                onClick={() => {
                  onEatDirectly(spunFruit);
                  setSpunFruit(null);
                }}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-transform active:scale-95 cursor-pointer shrink-0"
              >
                Eat Immediately
              </button>
            </div>
          )}

          {/* Fruit Encyclopedia Tabs */}
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Fruit Codex & Power Preview
            </div>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
              {(Object.keys(FRUITS) as FruitType[]).map((fKey) => {
                const f = FRUITS[fKey];
                const isSelected = selectedFruitPreview === fKey;
                return (
                  <button
                    key={fKey}
                    onClick={() => setSelectedFruitPreview(fKey)}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-950/80 border-purple-500 shadow-md'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-bold text-slate-200 truncate">{f.name.split(' ')[0]}</div>
                    <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">{f.rarity}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Fruit Skill Showcase */}
          {previewData && (
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-bold text-white">{previewData.name}</h4>
                    <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-purple-300 border border-slate-700">
                      {previewData.rarity}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">{previewData.description}</p>
                </div>
              </div>

              {/* Skills list */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs font-bold text-slate-400 uppercase">Skill Mastery Unlocks:</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {previewData.skills.map((skill) => (
                    <div
                      key={skill.id}
                      className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-start gap-2.5"
                    >
                      <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-xs text-amber-400 shrink-0">
                        {skill.key}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-200">{skill.name}</span>
                          <span className="text-[10px] font-mono text-purple-400">
                            Mastery {skill.requiredMastery}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{skill.description}</p>
                        <div className="mt-1 flex items-center gap-2 text-[10px] font-mono text-slate-500">
                          <span>Energy: {skill.energyCost}</span>
                          <span>·</span>
                          <span>CD: {skill.cooldown}s</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
