import React, { useMemo, useRef, useState } from 'react';
import {
  Eye,
  Film,
  FolderOpen,
  Image as ImageIcon,
  Images,
  Play,
  Search,
  Sparkles,
  Trash2,
  UploadCloud,
  Video,
  X,
} from 'lucide-react';
import {
  extractGalleryFolders,
  formatFileSize,
  GalleryItem,
  PROJECTION_OPTIONS,
  Video360Projection,
} from '../vr/vrState';
import { extractDroppedMediaFiles, FileWithFolder } from '../vr/mediaScanner';

interface GalleryBrowserModalProps {
  open: boolean;
  onClose: () => void;
  items: GalleryItem[];
  onImportFiles: (files: FileList) => Promise<void>;
  onImportEntries?: (entries: FileWithFolder[]) => Promise<void>;
  onScanDirectory: () => Promise<{ supported: boolean }>;
  onRemoveItem: (id: string) => void;
  onClearDeviceItems?: () => void;
  onOpenItem: (
    item: GalleryItem,
    target: '360' | 'cinema',
    projection?: Video360Projection
  ) => void;
  onEnterVRGallery: () => void;
}

export const GalleryBrowserModal: React.FC<GalleryBrowserModalProps> = ({
  open,
  onClose,
  items,
  onImportFiles,
  onImportEntries,
  onScanDirectory,
  onRemoveItem,
  onClearDeviceItems,
  onOpenItem,
  onEnterVRGallery,
}) => {
  const [tab, setTab] = useState<'all' | 'device' | 'video' | 'image'>('all');
  const [folderFilter, setFolderFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [selectedProj, setSelectedProj] = useState<Video360Projection>('360-mono');
  const [busy, setBusy] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [previewItemId, setPreviewItemId] = useState<string | null>(null);

  const filesInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  const folders = useMemo(() => extractGalleryFolders(items), [items]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((item) => {
      if (tab === 'device' && item.sourceType !== 'device') return false;
      if (tab === 'video' && item.kind !== 'video') return false;
      if (tab === 'image' && item.kind !== 'image') return false;
      if (
        folderFilter !== 'all' &&
        (item.folderName || 'المعرض المحلي') !== folderFilter
      ) {
        return false;
      }
      if (
        q &&
        !item.name.toLowerCase().includes(q) &&
        !(item.folderName || '').toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [items, tab, folderFilter, search]);

  const previewItem = useMemo(
    () => items.find((i) => i.id === previewItemId) ?? null,
    [items, previewItemId]
  );

  if (!open) return null;

  const deviceCount = items.filter((i) => i.sourceType === 'device').length;

  const handleBrowseFolder = async () => {
    setBusy(true);
    try {
      const res = await onScanDirectory();
      if (!res.supported) {
        folderInputRef.current?.click();
      }
    } finally {
      setBusy(false);
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    if (!e.dataTransfer) return;

    setBusy(true);
    try {
      const entries = await extractDroppedMediaFiles(e.dataTransfer);
      if (entries.length > 0 && onImportEntries) {
        await onImportEntries(entries);
      } else if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        await onImportFiles(e.dataTransfer.files);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-label="متصفح الملفات والمعرض"
    >
      <div
        onDragOver={(e) => {
          e.preventDefault();
          if (!dragOver) setDragOver(true);
        }}
        onDragLeave={(e) => {
          if (e.currentTarget.contains(e.relatedTarget as Node)) return;
          setDragOver(false);
        }}
        onDrop={(e) => void handleDrop(e)}
        className={`relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl bg-[#101622] border text-slate-100 shadow-2xl overflow-hidden transition-colors ${
          dragOver ? 'border-teal-400 ring-2 ring-teal-400/50' : 'border-slate-700/80'
        }`}
      >
        {/* Drag-and-Drop Overlay */}
        {dragOver && (
          <div className="pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-[#09121f]/90 border-2 border-dashed border-teal-400 rounded-2xl">
            <UploadCloud className="w-12 h-12 text-teal-400" />
            <p className="text-base font-bold text-teal-200">
              أفلت الملفات أو المجلدات هنا لإضافتها فوراً للمعرض
            </p>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800 bg-[#0d121d]">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Images className="w-5 h-5 text-teal-400" />
              <span>تصفح الملفات والمعرض مباشرة</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              اسحب وأفلت أو اختر صورك وفيديوهاتك ومجلداتك وشغّلها في السينما أو مشغل 360° / 3D
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onEnterVRGallery();
                onClose();
              }}
              className="hidden sm:flex items-center gap-1.5 rounded-lg bg-sky-500/20 border border-sky-400/50 px-3 py-2 text-xs font-semibold text-sky-300 hover:bg-sky-500/30 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>غرفة المعرض VR</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق المعرض والملفات"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Toolbar: Pick Gallery Files or Browse Folder */}
        <div className="px-5 py-3 bg-[#121928] border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => filesInputRef.current?.click()}
              className="flex items-center gap-2 rounded-lg bg-teal-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-teal-400 transition-colors disabled:opacity-60"
            >
              <Images className="w-4 h-4" />
              <span>اختيار صور وفيديو</span>
            </button>

            <button
              type="button"
              disabled={busy}
              onClick={() => void handleBrowseFolder()}
              className="flex items-center gap-2 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 transition-colors disabled:opacity-60"
            >
              <FolderOpen className="w-4 h-4" />
              <span>{busy ? 'جاري الفحص...' : 'تصفح مجلد كامل'}</span>
            </button>

            {deviceCount > 0 && onClearDeviceItems && (
              <button
                type="button"
                onClick={() => {
                  setPreviewItemId(null);
                  onClearDeviceItems();
                }}
                className="flex items-center gap-1.5 rounded-lg bg-red-500/15 border border-red-500/40 px-2.5 py-2 text-xs font-medium text-red-300 hover:bg-red-500/25 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>مسح ملفات الجهاز ({deviceCount})</span>
              </button>
            )}

            {/* Hidden Native File & Folder Pickers */}
            <input
              ref={filesInputRef}
              type="file"
              multiple
              accept="video/*,image/*"
              className="sr-only"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  setBusy(true);
                  void onImportFiles(e.target.files).finally(() => setBusy(false));
                  e.target.value = '';
                }
              }}
            />
            <input
              ref={folderInputRef}
              type="file"
              multiple
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              {...({ webkitdirectory: '', directory: '' } as any)}
              className="sr-only"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  setBusy(true);
                  void onImportFiles(e.target.files).finally(() => setBusy(false));
                  e.target.value = '';
                }
              }}
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400 whitespace-nowrap">نمط 360°/3D:</span>
            <select
              value={selectedProj}
              onChange={(e) => setSelectedProj(e.target.value as Video360Projection)}
              aria-label="نمط عرض 360 أو 180 أو 3D"
              className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-xs text-teal-300"
            >
              {PROJECTION_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Filters, Folder Chips & Search */}
        <div className="px-5 py-2.5 border-b border-slate-800/70 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'all' as const, label: `الكل (${items.length})` },
                { id: 'device' as const, label: `ملفات الجهاز (${deviceCount})` },
                {
                  id: 'video' as const,
                  label: `فيديو (${items.filter((i) => i.kind === 'video').length})`,
                },
                {
                  id: 'image' as const,
                  label: `صور المعرض (${items.filter((i) => i.kind === 'image').length})`,
                },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                    tab === t.id
                      ? 'bg-sky-500 text-slate-950 font-bold'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="relative flex-1 min-w-[180px] max-w-xs">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="بحث في الملفات أو المجلد..."
                className="w-full rounded-lg bg-slate-900 border border-slate-700 pr-8 pl-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500"
              />
            </div>
          </div>

          {folders.length > 1 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              <button
                type="button"
                onClick={() => setFolderFilter('all')}
                className={`shrink-0 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
                  folderFilter === 'all'
                    ? 'bg-teal-500/25 text-teal-300 border border-teal-400/50'
                    : 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                كل المجلدات
              </button>
              {folders.map((f) => (
                <button
                  key={f.name}
                  type="button"
                  onClick={() => setFolderFilter(f.name)}
                  className={`shrink-0 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    folderFilter === f.name
                      ? 'bg-teal-500/25 text-teal-300 border border-teal-400/50'
                      : 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {f.name} ({f.count})
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Inline Media Preview Panel */}
        {previewItem && (
          <div className="px-5 py-3 bg-[#090d16] border-b border-slate-800 flex flex-col sm:flex-row items-center gap-4">
            <div className="w-full sm:w-64 h-36 rounded-lg overflow-hidden bg-black flex items-center justify-center shrink-0 border border-slate-800">
              {previewItem.sourceType === 'device' ? (
                previewItem.kind === 'video' ? (
                  <video
                    key={previewItem.id}
                    src={previewItem.url}
                    controls
                    autoPlay
                    playsInline
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <img
                    src={previewItem.url}
                    alt={previewItem.name}
                    className="w-full h-full object-contain"
                  />
                )
              ) : (
                <div className="flex flex-col items-center justify-center text-slate-400 text-xs gap-1.5">
                  <Sparkles className="w-7 h-7 text-sky-400" />
                  <span>عرض ثلاثي الأبعاد تفاعلي</span>
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0 space-y-2 w-full">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white truncate">{previewItem.name}</h3>
                  <p className="text-xs text-slate-400">
                    {previewItem.folderName || 'المعرض المحلي'} · {formatFileSize(previewItem.sizeBytes)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setPreviewItemId(null)}
                  aria-label="إغلاق المعاينة"
                  className="rounded-md bg-slate-800 p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onOpenItem(previewItem, 'cinema');
                    onClose();
                  }}
                  className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>تشغيل في السينما</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onOpenItem(
                      previewItem,
                      '360',
                      previewItem.defaultTarget === '360'
                        ? previewItem.defaultProjection
                        : selectedProj
                    );
                    onClose();
                  }}
                  className="flex items-center gap-1.5 rounded-lg bg-teal-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-teal-400"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>تشغيل 360° / 3D</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Media Grid */}
        <div className="flex-1 overflow-y-auto p-5">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-14 text-center space-y-3">
              <FolderOpen className="w-10 h-10 text-slate-600" />
              <p className="text-sm font-medium text-slate-300">
                لا توجد ملفات مطابقة حالياً
              </p>
              <p className="text-xs text-slate-400 max-w-md">
                اسحب الملفات والمجلدات وأفلتها هنا، أو اضغط «اختيار صور وفيديو» أو «تصفح مجلد كامل».
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {filtered.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col rounded-xl border border-slate-800 bg-[#151d2e] overflow-hidden hover:border-slate-600 transition-colors"
                >
                  {/* Thumbnail Preview */}
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => setPreviewItemId(item.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        setPreviewItemId(item.id);
                      }
                    }}
                    className="relative h-32 bg-slate-900 overflow-hidden cursor-pointer group"
                  >
                    {item.thumbnailDataUrl ? (
                      <img
                        src={item.thumbnailDataUrl}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div
                        className="w-full h-full flex items-center justify-center"
                        style={{
                          background: `linear-gradient(135deg, #0f172a 0%, ${
                            item.accentColor || '#1e3a5f'
                          }55 100%)`,
                        }}
                      >
                        {item.kind === 'image' ? (
                          <ImageIcon className="w-9 h-9 text-teal-300/80" />
                        ) : (
                          <Video className="w-9 h-9 text-amber-300/80" />
                        )}
                      </div>
                    )}

                    <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/35 transition-colors">
                      <span className="opacity-0 group-hover:opacity-100 rounded-full bg-black/75 p-2 text-white transition-opacity">
                        <Play className="w-4 h-4" />
                      </span>
                    </div>

                    <div className="absolute top-2 right-2 flex items-center gap-1">
                      <span
                        className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                          item.kind === 'image'
                            ? 'bg-teal-500 text-slate-950'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        {item.kind === 'image' ? 'صورة' : 'فيديو'}
                      </span>
                      {item.sourceType === 'device' && (
                        <span className="rounded bg-emerald-500/90 px-2 py-0.5 text-[10px] font-bold text-slate-950">
                          جهازك
                        </span>
                      )}
                    </div>

                    {item.sourceType === 'device' && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (previewItemId === item.id) setPreviewItemId(null);
                          onRemoveItem(item.id);
                        }}
                        aria-label={`حذف ${item.name}`}
                        className="absolute top-2 left-2 rounded-md bg-black/70 p-1.5 text-slate-300 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Card Details */}
                  <div className="p-3 flex-1 flex flex-col justify-between gap-2.5">
                    <div>
                      <h3
                        className="text-xs font-bold text-white truncate"
                        title={item.name}
                      >
                        {item.name}
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                        {item.folderName || 'المعرض المحلي'} · {formatFileSize(item.sizeBytes)}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          onOpenItem(item, 'cinema');
                          onClose();
                        }}
                        className="flex items-center justify-center gap-1 rounded-lg bg-amber-500/20 border border-amber-500/40 px-2 py-1.5 text-[11px] font-semibold text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition-colors"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>في السينما</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onOpenItem(
                            item,
                            '360',
                            item.defaultTarget === '360' ? item.defaultProjection : selectedProj
                          );
                          onClose();
                        }}
                        className="flex items-center justify-center gap-1 rounded-lg bg-teal-500/20 border border-teal-500/40 px-2 py-1.5 text-[11px] font-semibold text-teal-300 hover:bg-teal-500 hover:text-slate-950 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>360° / 3D</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

