import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AlarmItem } from '../../types';
import {
  Bell,
  Plus,
  Clock,
  Trash2,
  Edit2,
  Volume2,
  Sparkles,
  Check,
  X,
  Compass,
  GraduationCap,
  Sun,
  Moon,
  AlertCircle,
} from 'lucide-react';
import { formatTime24to12 } from '../../utils/prayerCalculator';
import { playNotificationChime } from '../../utils/notifications';

const DAYS_NAMES_SHORT = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

export const AlarmsView: React.FC = () => {
  const {
    alarms,
    addAlarm,
    updateAlarm,
    deleteAlarm,
    toggleAlarm,
    activeRingingAlarm,
    dismissActiveAlarm,
    snoozeActiveAlarm,
  } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAlarm, setEditingAlarm] = useState<AlarmItem | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [time, setTime] = useState('06:00');
  const [daysOfWeek, setDaysOfWeek] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [category, setCategory] = useState<AlarmItem['category']>('general');
  const [sound, setSound] = useState<AlarmItem['sound']>('bell');

  const handleOpenAdd = () => {
    setEditingAlarm(null);
    setTitle('');
    setTime('06:00');
    setDaysOfWeek([0, 1, 2, 3, 4, 5, 6]);
    setCategory('general');
    setSound('bell');
    setShowAddModal(true);
  };

  const handleOpenEdit = (alarm: AlarmItem) => {
    setEditingAlarm(alarm);
    setTitle(alarm.title);
    setTime(alarm.time);
    setDaysOfWeek(alarm.daysOfWeek);
    setCategory(alarm.category);
    setSound(alarm.sound);
    setShowAddModal(true);
  };

  const toggleDaySelection = (dayIdx: number) => {
    if (daysOfWeek.includes(dayIdx)) {
      if (daysOfWeek.length > 1) {
        setDaysOfWeek(daysOfWeek.filter((d) => d !== dayIdx));
      }
    } else {
      setDaysOfWeek([...daysOfWeek, dayIdx].sort());
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (editingAlarm) {
      updateAlarm(editingAlarm.id, {
        title: title.trim(),
        time,
        daysOfWeek,
        category,
        sound,
      });
    } else {
      addAlarm({
        title: title.trim(),
        time,
        daysOfWeek,
        isEnabled: true,
        category,
        sound,
      });
    }

    setShowAddModal(false);
    playNotificationChime('success');
  };

  const testAlarmSound = () => {
    playNotificationChime('alarm');
  };

  // Quick preset templates
  const applyPreset = (presetTitle: string, presetTime: string, presetCategory: AlarmItem['category']) => {
    setTitle(presetTitle);
    setTime(presetTime);
    setCategory(presetCategory);
    setDaysOfWeek([0, 1, 2, 3, 4, 5, 6]);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-700 via-pink-700 to-rose-600 p-6 text-white shadow-sm border border-rose-400/30">
        <div
          className="absolute inset-0 opacity-15 bg-cover bg-center pointer-events-none mix-blend-overlay"
          style={{ backgroundImage: `url('/public/assets/aistudio/images_5d51feea.jpg')` }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-200 text-xs font-semibold mb-1">
              <Bell className="w-4 h-4 text-pink-300" />
              <span>المنبهات الذكية والتذكيرات الصوتية</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight">المنبهات وإدارة الاستيقاظ</h2>
            <p className="text-xs text-rose-100/90 mt-1 max-w-xl">
              ضبط منبهات لصلاة الفجر، جلسات المذاكرة، قراءة الأذكار، والمواعيد مع رنين صوتي هادئ وخاصية الغفوة
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={testAlarmSound}
              className="px-3.5 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold backdrop-blur-md border border-white/30 transition-all flex items-center gap-1.5"
              title="تجربة صوت المنبه"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>تجربة الرنين</span>
            </button>
            <button
              onClick={handleOpenAdd}
              className="px-3.5 py-2 rounded-xl bg-white text-rose-800 hover:bg-rose-50 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة منبه جديد</span>
            </button>
          </div>
        </div>
      </div>

      {/* Active Ringing Alarm Alert (if any) */}
      {activeRingingAlarm && (
        <div className="p-5 rounded-3xl bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-xl border-2 border-white/50 animate-pulse flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <span className="text-xs font-bold text-rose-200">المنبه يرن الآن!</span>
              <h3 className="text-xl font-bold">{activeRingingAlarm.title}</h3>
              <p className="text-xs text-rose-100">الموعد المحدد: {formatTime24to12(activeRingingAlarm.time)}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => snoozeActiveAlarm(5)}
              className="px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-md transition-colors"
            >
              غفوة 5 دقائق
            </button>
            <button
              onClick={dismissActiveAlarm}
              className="px-5 py-2 rounded-xl bg-white text-rose-700 hover:bg-rose-50 font-bold text-xs shadow-md transition-colors"
            >
              إيقاف المنبه
            </button>
          </div>
        </div>
      )}

      {/* Alarms Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {alarms.map((alarm) => {
          return (
            <div
              key={alarm.id}
              className={`p-5 rounded-3xl border transition-all duration-200 ${
                alarm.isEnabled
                  ? 'bg-white dark:bg-[#180d15] border-rose-100 dark:border-rose-950/60 shadow-xs'
                  : 'bg-slate-50/50 dark:bg-rose-950/20 border-slate-200/60 dark:border-rose-950/40 opacity-60'
              }`}
            >
              {/* Header row: Category and Toggle switch */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-900/40">
                  {alarm.category === 'fajr'
                    ? 'صلاة الفجر'
                    : alarm.category === 'study'
                    ? 'جلسة مذاكرة'
                    : alarm.category === 'adhkar'
                    ? 'أذكار وورد'
                    : alarm.category === 'medication'
                    ? 'موعد دواء'
                    : 'منبه عام'}
                </span>

                {/* Toggle switch */}
                <button
                  onClick={() => toggleAlarm(alarm.id)}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors duration-200 ${
                    alarm.isEnabled ? 'bg-rose-600 justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'
                  }`}
                  aria-label="تفعيل المنبه"
                >
                  <div className="bg-white w-4 h-4 rounded-full shadow-sm" />
                </button>
              </div>

              {/* Time display */}
              <div className="py-2">
                <div className="text-3xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-rose-100">
                  {formatTime24to12(alarm.time)}
                </div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-rose-200 mt-1">
                  {alarm.title}
                </h4>
              </div>

              {/* Repeat Days badges */}
              <div className="flex items-center gap-1 my-3 flex-wrap">
                {DAYS_NAMES_SHORT.map((dayName, idx) => {
                  const isActive = alarm.daysOfWeek.includes(idx);
                  return (
                    <span
                      key={dayName}
                      className={`text-[10px] font-medium px-2 py-0.5 rounded-md ${
                        isActive
                          ? 'bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 font-bold'
                          : 'text-slate-300 dark:text-rose-400/30'
                      }`}
                    >
                      {dayName}
                    </span>
                  );
                })}
              </div>

              {/* Actions Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-rose-50 dark:border-rose-950/50 text-xs">
                <button
                  onClick={testAlarmSound}
                  className="text-slate-400 hover:text-rose-600 flex items-center gap-1 text-[11px]"
                  title="سماع الصوت"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>نغمة هادئة</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(alarm)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-300"
                    title="تعديل"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`هل أنت متأكد من حذف منبه ${alarm.title}؟`)) {
                        deleteAlarm(alarm.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                    title="حذف"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Alarm Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-[#180d15] rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-100 dark:border-rose-950/80">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100 dark:border-rose-950/60 mb-4">
              <h3 className="font-bold text-base text-slate-900 dark:text-rose-50">
                {editingAlarm ? 'تعديل المنبه' : 'إضافة منبه ذكي جديد'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-rose-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Templates Buttons */}
            {!editingAlarm && (
              <div className="mb-4 space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-500 dark:text-rose-200/70">
                  نماذج سريعة جاهزة:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => applyPreset('استيقاظ لصلاة الفجر', '04:30', 'fajr')}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/50"
                  >
                    صلاة الفجر (04:30)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('أذكار الصباح والورد', '06:00', 'adhkar')}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/50"
                  >
                    أذكار الصباح (06:00)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('جلسة المذاكرة الأولى', '08:00', 'study')}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/50"
                  >
                    المذاكرة (08:00)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('أذكار المساء', '16:30', 'adhkar')}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/50"
                  >
                    أذكار المساء (16:30)
                  </button>
                </div>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  عنوان المنبه *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: منبه الاستيقاظ / موعد جلسة المذاكرة"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    وقت الرنين الدقيق
                  </label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full px-3 py-2 text-base rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    التصنيف
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as AlarmItem['category'])}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  >
                    <option value="general">منبه عام</option>
                    <option value="fajr">صلاة الفجر</option>
                    <option value="study">جلسة مذاكرة</option>
                    <option value="adhkar">أذكار وورد</option>
                    <option value="medication">موعد دواء</option>
                  </select>
                </div>
              </div>

              {/* Repeat Days Selection */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1.5">
                  أيام التكرار الأسبوعية
                </label>
                <div className="grid grid-cols-7 gap-1">
                  {DAYS_NAMES_SHORT.map((dayName, idx) => {
                    const isSelected = daysOfWeek.includes(idx);
                    return (
                      <button
                        type="button"
                        key={dayName}
                        onClick={() => toggleDaySelection(idx)}
                        className={`py-2 text-center rounded-xl font-bold transition-all ${
                          isSelected
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'bg-rose-50/50 dark:bg-rose-950/40 text-slate-600 dark:text-rose-200 border border-rose-100 dark:border-rose-900/30'
                        }`}
                      >
                        {dayName}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-rose-100 dark:border-rose-950/60">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-600 dark:text-rose-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
                >
                  {editingAlarm ? 'حفظ التعديلات' : 'تفعيل المنبه'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
