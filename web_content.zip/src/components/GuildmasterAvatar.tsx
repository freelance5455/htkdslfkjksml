import React, { useState, useEffect } from 'react';
import { useGame } from '../context/GameContext';

interface GuildmasterAvatarProps {
  ventureId: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  overrideUrl?: string;
  forceVector?: boolean;
}

/**
 * Character portrait avatars for all Kingdom Guildmasters and Overseers.
 * Supports custom uploaded .jpg portraits with graceful fallback to
 * stylized fantasy RPG vector character portraits.
 */
export function GuildmasterAvatar({
  ventureId,
  className = '',
  size = 'md',
  overrideUrl,
  forceVector = false,
}: GuildmasterAvatarProps) {
  const { guildmasterIcons } = useGame();
  const [imgError, setImgError] = useState(false);

  const sizeClasses = {
    sm: 'w-7 h-7',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  }[size];

  const activeCustom = overrideUrl
    ? { url: overrideUrl }
    : !forceVector && guildmasterIcons && guildmasterIcons[ventureId];

  const imgUrl = activeCustom ? activeCustom.url : null;
  useEffect(() => {
    setImgError(false);
  }, [imgUrl]);

  if (activeCustom && activeCustom.url && !imgError) {
    return (
      <div
        className={`${sizeClasses} ${className} relative overflow-hidden rounded-xl border border-amber-500/40 shadow-md bg-slate-900 shrink-0 flex items-center justify-center`}
      >
        <img
          src={activeCustom.url}
          alt={`${ventureId} Guildmaster Portrait`}
          className="w-full h-full object-cover rounded-xl"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
        />
        {/* Subtle fantasy vignette ring */}
        <div className="absolute inset-0 rounded-xl pointer-events-none ring-1 ring-inset ring-amber-400/25 shadow-[inset_0_0_8px_rgba(0,0,0,0.5)]" />
      </div>
    );
  }

  switch (ventureId) {
    case 'mana_herbs': // Botanist Bramble
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#064e3b" />
          <radialGradient id="bramble-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#059669" />
            <stop offset="100%" stopColor="#022c22" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#bramble-bg)" />

          {/* Leafy Cloak / Shoulders */}
          <path d="M12 64 C12 48 22 42 32 42 C42 42 52 48 52 64 Z" fill="#047857" stroke="#065f46" strokeWidth="1" />
          <path d="M18 52 C26 48 38 48 46 52" stroke="#10b981" strokeWidth="2" strokeLinecap="round" />

          {/* Herbalist Hood */}
          <path d="M18 36 C16 18 24 10 32 10 C40 10 48 18 46 36 C42 40 22 40 18 36 Z" fill="#065f46" />

          {/* Warm Face */}
          <ellipse cx="32" cy="30" rx="11" ry="12" fill="#fed7aa" />

          {/* Wise Friendly Eyes */}
          <ellipse cx="28" cy="28" rx="1.6" ry="1.2" fill="#1e293b" />
          <ellipse cx="36" cy="28" rx="1.6" ry="1.2" fill="#1e293b" />

          {/* Golden Herbalist Monocle on Right Eye */}
          <circle cx="36" cy="28" r="4.2" stroke="#fbbf24" strokeWidth="1.5" fill="#fef3c7" fillOpacity="0.25" />
          <path d="M40 30 Q44 34 43 40" stroke="#f59e0b" strokeWidth="1" fill="none" />

          {/* Graying Beard / Mustache */}
          <path d="M26 34 Q32 37 38 34 Q32 42 26 34 Z" fill="#cbd5e1" />
          <path d="M32 33 L32 35" stroke="#94a3b8" strokeWidth="1" />

          {/* Sprig of Mana Leaves on Hood */}
          <path d="M22 18 C18 12 24 10 26 14 C28 12 32 14 30 18 Z" fill="#34d399" />
          <circle cx="25" cy="14" r="1" fill="#ecfdf5" />
        </svg>
      );

    case 'potion_brewery': // Morwen the Alchemist
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#082f49" />
          <radialGradient id="morwen-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#0284c7" />
            <stop offset="100%" stopColor="#082f49" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#morwen-bg)" />

          {/* Alchemy Leather Coat */}
          <path d="M12 64 C12 48 22 42 32 42 C42 42 52 48 52 64 Z" fill="#1e293b" />
          <path d="M26 44 L32 64 M38 44 L32 64" stroke="#d97706" strokeWidth="1.5" />

          {/* Hair - Dark Raven Waves */}
          <path d="M18 36 C16 20 22 12 32 12 C42 12 48 20 46 36 L48 48 C42 48 44 38 44 36 L20 36 C20 38 22 48 16 48 Z" fill="#0f172a" />

          {/* Face */}
          <ellipse cx="32" cy="30" rx="10" ry="11" fill="#fde68a" />

          {/* Keen Eyes */}
          <circle cx="28" cy="30" r="1.5" fill="#0284c7" />
          <circle cx="36" cy="30" r="1.5" fill="#0284c7" />
          <path d="M26 27 Q29 26 31 27 M33 27 Q35 26 38 27" stroke="#334155" strokeWidth="1" />

          {/* Alchemist Brass Double Goggles resting on Forehead */}
          <rect x="22" y="16" width="9" height="7" rx="3.5" stroke="#f59e0b" strokeWidth="2" fill="#38bdf8" fillOpacity="0.4" />
          <rect x="33" y="16" width="9" height="7" rx="3.5" stroke="#f59e0b" strokeWidth="2" fill="#38bdf8" fillOpacity="0.4" />
          <line x1="31" y1="19.5" x2="33" y2="19.5" stroke="#b45309" strokeWidth="2" />
          <line x1="16" y1="20" x2="22" y2="20" stroke="#78350f" strokeWidth="2" />
          <line x1="42" y1="20" x2="48" y2="20" stroke="#78350f" strokeWidth="2" />

          {/* Mini Bubbling Vial Pinned to Coat */}
          <rect x="18" y="48" width="4" height="9" rx="1" fill="#38bdf8" stroke="#f59e0b" strokeWidth="1" />
          <circle cx="20" cy="53" r="1" fill="#ffffff" />
        </svg>
      );

    case 'dwarven_forge': // Master Smith Thrain
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#451a03" />
          <radialGradient id="thrain-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#451a03" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#thrain-bg)" />

          {/* Sturdy Forge Apron */}
          <path d="M10 64 C10 46 20 40 32 40 C44 40 54 46 54 64 Z" fill="#78350f" />

          {/* Dwarven Face */}
          <ellipse cx="32" cy="26" rx="12" ry="11" fill="#fed7aa" />

          {/* Thick Dwarven Brows & Determined Eyes */}
          <path d="M23 21 Q27 19 30 22 M34 22 Q37 19 41 21" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="27" cy="24" r="1.4" fill="#1e293b" />
          <circle cx="37" cy="24" r="1.4" fill="#1e293b" />

          {/* Magnificent Braided Red Beard */}
          <path
            d="M20 28 C18 36 22 56 32 62 C42 56 46 36 44 28 C42 34 38 36 32 36 C26 36 22 34 20 28 Z"
            fill="#c2410c"
          />
          {/* Mustache Swirl */}
          <path d="M22 30 Q32 35 42 30 Q32 38 22 30 Z" fill="#ea580c" />

          {/* Golden Beard Rings */}
          <rect x="29" y="44" width="6" height="3" rx="1" fill="#facc15" stroke="#b45309" strokeWidth="0.8" />
          <rect x="30" y="52" width="4" height="3" rx="1" fill="#facc15" stroke="#b45309" strokeWidth="0.8" />

          {/* Iron Smithing Circlet */}
          <path d="M19 18 C23 15 41 15 45 18" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
          <circle cx="32" cy="16" r="2" fill="#f59e0b" />
        </svg>
      );

    case 'goblin_vaults': // Gilded Griphook
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#365314" />
          <radialGradient id="griphook-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#84cc16" />
            <stop offset="100%" stopColor="#14532d" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#griphook-bg)" />

          {/* Velvet Banker Robe */}
          <path d="M14 64 C14 48 24 44 32 44 C40 44 50 48 50 64 Z" fill="#312e81" />
          <circle cx="32" cy="50" r="3.5" fill="#facc15" stroke="#b45309" strokeWidth="1" />

          {/* Large Pointed Goblin Ears */}
          <polygon points="22,28 6,24 18,36" fill="#84cc16" stroke="#4d7c0f" strokeWidth="1" />
          <polygon points="42,28 58,24 46,36" fill="#84cc16" stroke="#4d7c0f" strokeWidth="1" />

          {/* Sharp Goblin Face & Long Nose */}
          <ellipse cx="32" cy="30" rx="10" ry="11" fill="#a3e635" />
          <polygon points="32,26 30,36 34,36" fill="#84cc16" />

          {/* Sly Narrow Eyes */}
          <ellipse cx="26" cy="27" rx="2" ry="1.2" fill="#ca8a04" />
          <ellipse cx="38" cy="27" rx="2" ry="1.2" fill="#ca8a04" />

          {/* Gold Banker Monocle on Left Eye */}
          <circle cx="26" cy="27" r="4.2" stroke="#facc15" strokeWidth="1.5" fill="#fef08a" fillOpacity="0.25" />
          <path d="M22 28 Q18 36 24 44" stroke="#eab308" strokeWidth="1" fill="none" />

          {/* Sly Smirk */}
          <path d="M28 39 Q33 42 37 38" stroke="#3f6212" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'griffin_aviary': // Skywarden Zephyr
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#1e1b4b" />
          <radialGradient id="zephyr-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#4338ca" />
            <stop offset="100%" stopColor="#0f172a" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#zephyr-bg)" />

          {/* Skywarden Flight Mantle */}
          <path d="M12 64 C12 48 22 42 32 42 C42 42 52 48 52 64 Z" fill="#1e40af" stroke="#60a5fa" strokeWidth="1" />

          {/* Face */}
          <ellipse cx="32" cy="30" rx="9.5" ry="11" fill="#fed7aa" />

          {/* Sharp Eyes */}
          <circle cx="28" cy="30" r="1.5" fill="#1e3a8a" />
          <circle cx="36" cy="30" r="1.5" fill="#1e3a8a" />
          <path d="M29 38 Q32 39 35 38" stroke="#9a3412" strokeWidth="1.2" strokeLinecap="round" />

          {/* Leather Pilot Helmet & Earflaps */}
          <path d="M20 28 C20 16 25 12 32 12 C39 12 44 16 44 28 L44 38 L40 38 L40 26 L24 26 L24 38 L20 38 Z" fill="#78350f" />

          {/* Royal Wings Crest on Helmet */}
          <path d="M28 14 L20 8 M36 14 L44 8 M32 12 L32 6" stroke="#fbbf24" strokeWidth="2" strokeLinecap="round" />

          {/* Aviator Brass Goggles on Crown */}
          <rect x="23" y="16" width="8" height="6" rx="3" stroke="#f59e0b" strokeWidth="1.5" fill="#93c5fd" fillOpacity="0.5" />
          <rect x="33" y="16" width="8" height="6" rx="3" stroke="#f59e0b" strokeWidth="1.5" fill="#93c5fd" fillOpacity="0.5" />
        </svg>
      );

    case 'arcane_spire': // Archmage Vaelin
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#3b0764" />
          <radialGradient id="vaelin-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#7e22ce" />
            <stop offset="100%" stopColor="#1e1b4b" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#vaelin-bg)" />

          {/* Mystic Robes */}
          <path d="M12 64 C12 46 22 40 32 40 C42 40 52 46 52 64 Z" fill="#581c87" />
          <path d="M24 44 L32 64 L40 44" stroke="#c084fc" strokeWidth="1.5" />

          {/* Archmage Hood */}
          <path d="M18 36 C16 16 23 8 32 8 C41 8 48 16 46 36 Z" fill="#3b0764" stroke="#a855f7" strokeWidth="1" />

          {/* Face */}
          <ellipse cx="32" cy="28" rx="9" ry="10" fill="#fde68a" />

          {/* Glowing Purple/White Arcane Eyes */}
          <circle cx="28" cy="27" r="2" fill="#ffffff" filter="drop-shadow(0 0 3px #d8b4fe)" />
          <circle cx="36" cy="27" r="2" fill="#ffffff" filter="drop-shadow(0 0 3px #d8b4fe)" />

          {/* Long Flowing Wizard Beard */}
          <path d="M23 32 Q32 38 41 32 Q36 58 32 62 Q28 58 23 32 Z" fill="#f8fafc" />

          {/* Floating Arcane Rune on Brow */}
          <polygon points="32,15 34,18 32,21 30,18" fill="#f0abfc" filter="drop-shadow(0 0 3px #e879f9)" />
        </svg>
      );

    case 'dragon_roost': // Dragon Warden Ignis
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#4c0519" />
          <radialGradient id="ignis-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#be123c" />
            <stop offset="100%" stopColor="#4c0519" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#ignis-bg)" />

          {/* Dragon-Scale Pauldron Cloak */}
          <path d="M12 64 C12 46 22 40 32 40 C42 40 52 46 52 64 Z" fill="#881337" />
          <path d="M16 48 L22 54 L28 48 L34 54 L40 48 L46 54" stroke="#f43f5e" strokeWidth="1.5" />

          {/* Face with Warrior Bone Structure */}
          <ellipse cx="32" cy="28" rx="10" ry="11" fill="#fed7aa" />

          {/* Flame-Red Wild Hair */}
          <path d="M18 24 C18 12 24 8 32 8 C40 8 46 12 46 24 L44 14 L38 10 L32 14 L26 10 L20 14 Z" fill="#e11d48" />

          {/* Fierce Amber Dragon-Tamer Eyes */}
          <circle cx="28" cy="27" r="1.6" fill="#f59e0b" filter="drop-shadow(0 0 2px #ef4444)" />
          <circle cx="36" cy="27" r="1.6" fill="#f59e0b" filter="drop-shadow(0 0 2px #ef4444)" />

          {/* Battle Scar over Left Eye */}
          <line x1="26" y1="23" x2="30" y2="31" stroke="#991b1b" strokeWidth="1.2" strokeLinecap="round" />

          {/* Dragon Claw / Tooth Amulet */}
          <polygon points="32,44 35,50 32,54 29,50" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
        </svg>
      );

    case 'astral_observatory': // Stargazer Lyra
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#2e1065" />
          <radialGradient id="lyra-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#6d28d9" />
            <stop offset="100%" stopColor="#0f172a" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#lyra-bg)" />

          {/* Cosmic Starry Veil */}
          <path d="M12 64 C12 46 22 40 32 40 C42 40 52 46 52 64 Z" fill="#4c1d95" />

          {/* Flowing Lavender Astral Hair */}
          <path d="M18 36 C16 18 22 10 32 10 C42 10 48 18 46 36 L48 50 C40 48 42 36 42 32 L22 32 C22 36 24 48 16 50 Z" fill="#c084fc" />

          {/* Graceful Face */}
          <ellipse cx="32" cy="28" rx="9" ry="10" fill="#fef08a" fillOpacity="0.9" />

          {/* Serene Cosmic Eyes */}
          <ellipse cx="28" cy="27" rx="1.6" ry="1.2" fill="#581c87" />
          <ellipse cx="36" cy="27" rx="1.6" ry="1.2" fill="#581c87" />
          <circle cx="28.5" cy="26.5" r="0.6" fill="#ffffff" />
          <circle cx="36.5" cy="26.5" r="0.6" fill="#ffffff" />

          {/* Celestial Crescent Moon Diadem */}
          <path d="M30 16 C32 14 34 14 36 16 C34 18 32 18 30 16 Z" fill="#fef08a" filter="drop-shadow(0 0 3px #a855f7)" />
          <circle cx="32" cy="16" r="1.2" fill="#ffffff" />

          {/* Constellation Star Sparkles */}
          <circle cx="16" cy="22" r="1" fill="#fde047" />
          <circle cx="48" cy="22" r="1" fill="#fde047" />
          <circle cx="20" cy="46" r="0.8" fill="#e9d5ff" />
          <circle cx="44" cy="46" r="0.8" fill="#e9d5ff" />
        </svg>
      );

    case 'titan_citadel': // Lord Vorok
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#042f2e" />
          <radialGradient id="vorok-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#0f766e" />
            <stop offset="100%" stopColor="#042f2e" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#vorok-bg)" />

          {/* Colossal Iron Armor Shoulders & Spikes */}
          <path d="M10 64 L12 44 L20 40 L32 44 L44 40 L52 44 L54 64 Z" fill="#1e293b" stroke="#334155" strokeWidth="1.5" />
          <path d="M8 44 L14 36 L16 44 M56 44 L50 36 L48 44" stroke="#2dd4bf" strokeWidth="2" strokeLinejoin="round" />

          {/* Heavy Steel Full-Plate Helmet */}
          <path
            d="M20 20 L32 10 L44 20 L44 38 L32 44 L20 38 Z"
            fill="#334155"
            stroke="#5eead4"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />

          {/* Glowing Teal Visor Slit */}
          <polygon points="24,28 40,28 38,32 26,32" fill="#2dd4bf" filter="drop-shadow(0 0 5px #2dd4bf)" />
          <line x1="25" y1="30" x2="39" y2="30" stroke="#f0fdfa" strokeWidth="1" />

          {/* Titan Horn Spikes on Crest */}
          <path d="M22 18 L16 10 M42 18 L48 10" stroke="#14b8a6" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );

    case 'celestial_core': // Seraphina Dawnweaver
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className} shrink-0 rounded-xl overflow-hidden shadow-md`}
        >
          <rect width="64" height="64" fill="#78350f" />
          <radialGradient id="seraphina-bg" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#f59e0b" />
            <stop offset="60%" stopColor="#d97706" />
            <stop offset="100%" stopColor="#451a03" />
          </radialGradient>
          <rect width="64" height="64" fill="url(#seraphina-bg)" />

          {/* Divine Solar Halo */}
          <circle cx="32" cy="24" r="18" stroke="#fef08a" strokeWidth="2" strokeDasharray="3 3" opacity="0.8" />
          <circle cx="32" cy="24" r="14" stroke="#fde047" strokeWidth="1.5" />

          {/* Radiant Angelic Wings behind Head */}
          <path d="M12 28 C10 16 18 10 24 16 L22 34 Z M52 28 C54 16 46 10 40 16 L42 34 Z" fill="#fef3c7" opacity="0.9" />

          {/* White & Gold Celestial Robe */}
          <path d="M14 64 C14 46 22 40 32 40 C42 40 50 46 50 64 Z" fill="#ffffff" />
          <path d="M26 44 L32 64 L38 44" stroke="#facc15" strokeWidth="2" />

          {/* Serene Divine Face */}
          <ellipse cx="32" cy="27" rx="9" ry="10" fill="#fef08a" />

          {/* Flowing Radiant Golden Hair */}
          <path d="M22 20 C22 12 27 8 32 8 C37 8 42 12 42 20 L44 38 C40 36 40 28 40 24 L24 24 C24 28 24 36 20 38 Z" fill="#f59e0b" />

          {/* Warm Golden Eyes */}
          <ellipse cx="28" cy="26" rx="1.6" ry="1.2" fill="#78350f" />
          <ellipse cx="36" cy="26" rx="1.6" ry="1.2" fill="#78350f" />

          {/* Sunstone Diadem */}
          <polygon points="32,14 34,17 32,20 30,17" fill="#ffffff" filter="drop-shadow(0 0 4px #fbbf24)" />
        </svg>
      );

    default:
      return (
        <div
          className={`${sizeClasses} ${className} shrink-0 rounded-xl bg-slate-800 flex items-center justify-center text-amber-400 font-cinzel font-bold text-sm shadow-md`}
        >
          GM
        </div>
      );
  }
}
