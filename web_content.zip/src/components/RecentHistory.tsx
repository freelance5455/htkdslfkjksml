import React from 'react';
import { HistoryItem, SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { Clock, Trash2, Download, ExternalLink } from 'lucide-react';

interface RecentHistoryProps {
  history: HistoryItem[];
  currentLang: SupportedLanguage;
  onClearHistory: () => void;
  onSelectHistoryItem: (playUrl: string) => void;
}

export const RecentHistory: React.FC<RecentHistoryProps> = ({
  history,
  currentLang,
  onClearHistory,
  onSelectHistoryItem,
}) => {
  const t = translations[currentLang];

  if (history.length === 0) return null;

  return (
    <section id="history" className="hidden py-12 px-4 sm:px-6 max-w-6xl mx-auto">
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 sm:p-8">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-white text-lg">
              {t.historyTitle} ({history.length})
            </h3>
          </div>
          <button
            onClick={onClearHistory}
            className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-500/20 hover:border-rose-500/40 transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.clearHistory}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {history.map((item) => (
            <div
              key={item.id}
              className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-3 flex gap-3 items-center group hover:border-cyan-500/40 transition"
            >
              <img
                src={item.cover}
                alt={item.title || 'Video'}
                className="w-14 h-18 rounded-xl object-cover bg-slate-900 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white text-xs truncate">
                  {item.authorName}
                </p>
                <p className="text-[11px] text-cyan-400 truncate">
                  @{item.authorUsername}
                </p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">
                  {item.title || 'TikTok Video'}
                </p>
                <a
                  href={item.playUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-1 text-[11px] font-semibold text-cyan-400 hover:text-cyan-300"
                >
                  <Download className="w-3 h-3" />
                  <span>Download</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
