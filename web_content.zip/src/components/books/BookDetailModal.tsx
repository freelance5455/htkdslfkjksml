import React, { useState } from 'react';
import { Book, ReadingStatus, ReadingSession, BookQuote, Collection, BookReview, ReadingRecord } from '../../types';
import { CoverImage } from '../common/CoverImage';
import { StarRating } from '../common/StarRating';
import {
  X,
  BookOpen,
  Heart,
  Edit3,
  Trash2,
  Clock,
  RotateCcw,
  Plus,
  Quote,
  Calendar,
  Layers,
  FileText,
  Bookmark,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

interface BookDetailModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  sessions: ReadingSession[];
  quotes: BookQuote[];
  collections: Collection[];
  onOpenReader: (book: Book) => void;
  onEditBook: (book: Book) => void;
  onDeleteBook: (book: Book) => void;
  onToggleFavorite: (book: Book) => void;
  onChangeStatus: (book: Book, status: ReadingStatus) => void;
  onStartReread: (book: Book) => void;
  onUpdatePagesRead: (book: Book, newPagesRead: number) => void;
  onOpenAddQuoteForBook: (bookId: string) => void;
  onSaveBookReview: (book: Book, review: BookReview | undefined) => void;
  onUpdateBook?: (book: Book) => void;
  existingTags?: string[];
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  isOpen,
  onClose,
  sessions,
  quotes,
  collections,
  onOpenReader,
  onEditBook,
  onDeleteBook,
  onToggleFavorite,
  onChangeStatus,
  onStartReread,
  onUpdatePagesRead,
  onOpenAddQuoteForBook,
  onSaveBookReview,
  onUpdateBook,
  existingTags = [],
}) => {
  if (!isOpen || !book) return null;

  const [activeTab, setActiveTab] = useState<'info' | 'review' | 'quotes' | 'sessions' | 'rereads'>('info');
  const [quickPagesInput, setQuickPagesInput] = useState<string>(String(book.pagesRead));
  const [isUpdatingPages, setIsUpdatingPages] = useState(false);

  // Review Form State (Section 45: Mi Reseña)
  const [isEditingReview, setIsEditingReview] = useState(false);
  const [reviewTitle, setReviewTitle] = useState(book.review?.title || '');
  const [reviewText, setReviewText] = useState(book.review?.text || '');
  const [reviewRating, setReviewRating] = useState<number>(book.review?.rating || book.rating || 0);

  const bookSessions = sessions.filter((s) => s.bookId === book.id);
  const bookQuotes = quotes.filter((q) => q.bookId === book.id);

  const statuses: ReadingStatus[] = ['POR LEER', 'LEYENDO', 'TERMINADO', 'ABANDONADO', 'RELECTURA'];
  const bookCollections = collections.filter((c) => book.collections?.includes(c.id));

  const pagesLeft = book.totalPages > 0 ? Math.max(0, book.totalPages - book.pagesRead) : 0;

  // Requirement 5: Calculate total reading time from recorded reading sessions
  const totalMinutesFromSessions = bookSessions.reduce(
    (acc, s) => acc + (s.durationMinutes || 0),
    0
  );
  const effectiveTotalMins =
    totalMinutesFromSessions > 0 ? totalMinutesFromSessions : (book.totalReadingMinutes || 0);

  // Requirement 1: RELECTURAS - Registros de lectura independientes
  const rawRecords: ReadingRecord[] = book.readingRecords && book.readingRecords.length > 0
    ? book.readingRecords
    : (book.rereadCount && book.rereadCount > 0)
    ? [
        {
          id: 'rec-1',
          recordNumber: 1,
          status: 'TERMINADO',
          dateStarted: book.dateStarted || '2026-01-10T10:00:00Z',
          dateFinished: book.dateFinished || '2026-02-15T18:00:00Z',
          progress: 100,
          pagesRead: book.totalPages || 400,
          totalReadingMinutes: 900, // 15 horas
          sessions: bookSessions.slice(0, Math.max(1, Math.floor(bookSessions.length / 2))),
          highlights: book.highlights || [],
          annotations: book.annotations || [],
          quotes: bookQuotes,
          rating: book.rating,
        },
        {
          id: 'rec-2',
          recordNumber: 2,
          status: 'RELECTURA',
          dateStarted: '2026-10-01T14:00:00Z',
          progress: book.progress || 30,
          pagesRead: book.pagesRead || Math.round((book.totalPages || 400) * 0.3),
          totalReadingMinutes: 120, // 2 horas
          sessions: bookSessions.slice(Math.max(1, Math.floor(bookSessions.length / 2))),
          highlights: [],
          annotations: [],
          quotes: [],
        },
      ]
    : [
        {
          id: 'rec-1',
          recordNumber: 1,
          status: book.status,
          dateStarted: book.dateStarted || new Date().toISOString(),
          dateFinished: book.dateFinished,
          progress: book.progress,
          pagesRead: book.pagesRead,
          totalReadingMinutes: effectiveTotalMins,
          sessions: bookSessions,
          highlights: book.highlights || [],
          annotations: book.annotations || [],
          quotes: bookQuotes,
          rating: book.rating,
        },
      ];

  const totalReadings = Math.max(rawRecords.length, (book.rereadCount || 0) + 1);
  const [selectedRecordId, setSelectedRecordId] = useState<string>(
    book.activeReadingRecordId || rawRecords[rawRecords.length - 1]?.id || 'rec-1'
  );
  const selectedRecord = rawRecords.find((r) => r.id === selectedRecordId) || rawRecords[0];
  const readingHours = Math.floor(effectiveTotalMins / 60);
  const readingMinsRemainder = effectiveTotalMins % 60;
  const formattedTotalReadingTime =
    readingHours > 0
      ? `${readingHours} h ${readingMinsRemainder} min`
      : `${readingMinsRemainder} min`;

  const remainingEstMinutes = pagesLeft * 2;
  const remainingHours = Math.floor(remainingEstMinutes / 60);
  const remainingMins = remainingEstMinutes % 60;

  // Requirement 5: Fecha de inicio de lectura
  const firstSession = bookSessions.length > 0
    ? [...bookSessions].sort((a, b) => a.date.localeCompare(b.date))[0]
    : null;
  const rawStartDate = book.dateStarted || firstSession?.date;
  const formattedStartDate = rawStartDate
    ? new Intl.DateTimeFormat('es-ES', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }).format(new Date(rawStartDate.includes('T') ? rawStartDate : `${rawStartDate}T00:00:00`))
    : 'Sin iniciar';

  // Tag editing state (Requirement 7)
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');

  const handleAddTagToBook = (rawTag: string) => {
    const clean = rawTag.trim().replace(/^#/, '');
    if (!clean) return;
    const currentTags = book.tags || [];
    if (!currentTags.some((t) => t.toLowerCase() === clean.toLowerCase())) {
      const updatedTags = [...currentTags, clean];
      onUpdateBook?.({ ...book, tags: updatedTags });
    }
    setNewTagInput('');
    setIsAddingTag(false);
  };

  const handleRemoveTagFromBook = (tagToRemove: string) => {
    const currentTags = book.tags || [];
    const updatedTags = currentTags.filter((t) => t !== tagToRemove);
    onUpdateBook?.({ ...book, tags: updatedTags });
  };

  const handleSaveQuickPages = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(quickPagesInput, 10);
    if (!isNaN(val) && val >= 0) {
      const finalVal = book.totalPages > 0 ? Math.min(val, book.totalPages) : val;
      onUpdatePagesRead(book, finalVal);
      setIsUpdatingPages(false);
    }
  };

  const handleSaveReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewText.trim()) return;

    const newReview: BookReview = {
      title: reviewTitle.trim() || undefined,
      text: reviewText.trim(),
      rating: reviewRating,
      createdAt: book.review?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSaveBookReview(book, newReview);
    setIsEditingReview(false);
  };

  const handleDeleteReview = () => {
    onSaveBookReview(book, undefined);
    setReviewTitle('');
    setReviewText('');
    setIsEditingReview(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl overflow-y-auto">
      <div className="w-full max-w-3xl glass-panel rounded-3xl p-5 sm:p-8 border border-white/15 shadow-2xl my-auto animate-fadeIn max-h-[92vh] overflow-y-auto flex flex-col justify-between">
        {/* Top Header Actions */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleFavorite(book)}
              className={`p-2 rounded-xl border transition-all ${
                book.favorite
                  ? 'bg-white/20 border-white/40 text-white'
                  : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
              }`}
              title={book.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos'}
            >
              <Heart className={`w-4 h-4 ${book.favorite ? 'fill-white text-white' : ''}`} />
            </button>

            <button
              onClick={() => onEditBook(book)}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white transition-all"
              title="Editar todos los datos"
            >
              <Edit3 className="w-4 h-4" />
            </button>

            <button
              onClick={() => onDeleteBook(book)}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/15 border border-white/10 text-zinc-400 hover:text-white transition-all"
              title="Eliminar definitivamente"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Book Main Header */}
        <div className="py-6 flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <div className="w-36 sm:w-44 shrink-0 shadow-2xl relative">
            <CoverImage
              url={book.coverUrl}
              title={book.title}
              author={book.author}
              className="rounded-xl border border-white/15"
            />
          </div>

          <div className="flex-1 w-full space-y-3 text-center sm:text-left">
            <div>
              {book.saga && (
                <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider block">
                  {book.saga} {book.sagaIndex ? `#${book.sagaIndex}` : ''}
                </span>
              )}
              {/* Requirement 1: En el detalle del libro mostrar 'Lecturas: 2' */}
              <div className="flex items-center justify-center sm:justify-start gap-2 mt-0.5">
                <button
                  type="button"
                  onClick={() => setActiveTab('rereads')}
                  className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-xs font-bold text-cyan-300 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                  title="Consultar cada registro de lectura por separado"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Lecturas: {totalReadings}</span>
                </button>
                {book.status === 'RELECTURA' && (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-xs font-bold text-amber-300 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    Relectura en curso
                  </span>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne'] mt-1">
                {book.title}
              </h2>
              <p className="text-sm sm:text-base text-zinc-400 font-medium">{book.author}</p>
            </div>

            {/* Category / Genre Pills (Screen 5 in IMG_0576) */}
            {book.genres && book.genres.length > 0 && (
              <div className="flex items-center justify-center sm:justify-start gap-1.5 flex-wrap">
                {book.genres.map((g) => (
                  <span
                    key={g}
                    className="px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 text-xs text-zinc-300 font-medium"
                  >
                    {g}
                  </span>
                ))}
              </div>
            )}

            {/* 4 Metadata Columns: Editorial | Páginas | Inicio | Tiempo total (Requirement 5) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 py-2 border-y border-white/[0.06] text-center sm:text-left">
              <div>
                <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Editorial</span>
                <span className="text-xs text-white font-medium truncate block mt-0.5">
                  {book.publisher || 'Editorial'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Páginas</span>
                <span className="text-xs text-white font-medium truncate block mt-0.5">
                  {book.totalPages || '?'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Inicio lectura</span>
                <span className="text-xs text-white font-medium truncate block mt-0.5">
                  {formattedStartDate}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Tiempo total</span>
                <span className="text-xs text-white font-mono font-medium truncate block mt-0.5">
                  {formattedTotalReadingTime}
                </span>
              </div>
            </div>

            {/* Rating Stars (Screen 5 in IMG_0576) */}
            <div className="flex items-center justify-center sm:justify-start gap-2 pt-0.5">
              <span className="text-xs font-bold text-white font-mono">{book.rating || 4.5}</span>
              <StarRating rating={book.rating || 4.5} size="sm" />
              <span className="text-[11px] text-zinc-500">(1,240)</span>
            </div>

            {/* Attached EPUB / PDF Badge if imported */}
            {book.fileAttachment && (
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-zinc-300">
                <FileText className="w-3.5 h-3.5 text-zinc-300" />
                <span className="font-semibold uppercase text-white">{book.fileAttachment.type}</span>
                <span className="truncate max-w-[200px]">{book.fileAttachment.name}</span>
                <span className="text-zinc-500 font-mono text-[10px]">
                  ({Math.round(book.fileAttachment.size / 1024)} KB)
                </span>
              </div>
            )}

            {/* Reading Status Selector Tabs */}
            <div className="pt-1">
              <span className="text-[11px] text-zinc-400 block mb-1.5 font-medium">Estado del libro</span>
              <div className="flex items-center justify-center sm:justify-start gap-1 flex-wrap">
                {statuses.map((s) => (
                  <button
                    key={s}
                    onClick={() => onChangeStatus(book, s)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                      book.status === s
                        ? 'bg-white/15 border-white/30 text-white shadow-sm'
                        : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Reading Progress Block (Screen 5 in IMG_0576) */}
            <div className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] space-y-2 mt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white tabular-nums">
                  ✓ {book.status === 'TERMINADO' ? 'Terminado' : 'Leyendo'}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white tabular-nums">{book.progress}%</span>
                  <span className="text-zinc-500">·</span>
                  <span className="text-zinc-400">
                    Tiempo restante: {remainingHours > 0 ? `${remainingHours} h ${remainingMins} min` : `${remainingEstMinutes} min`}
                  </span>
                  <button
                    onClick={() => {
                      setQuickPagesInput(String(book.pagesRead));
                      setIsUpdatingPages(!isUpdatingPages);
                    }}
                    className="text-zinc-300 hover:text-white text-[11px] font-medium ml-1 underline"
                  >
                    Actualizar
                  </button>
                </div>
              </div>

              {isUpdatingPages && (
                <form onSubmit={handleSaveQuickPages} className="flex items-center gap-2 pt-1 animate-fadeIn">
                  <input
                    type="number"
                    value={quickPagesInput}
                    onChange={(e) => setQuickPagesInput(e.target.value)}
                    max={book.totalPages || 9999}
                    min="0"
                    placeholder="Páginas leídas"
                    className="w-24 bg-zinc-900 border border-white/30 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                    autoFocus
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 rounded-lg bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-sm"
                  >
                    Guardar
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsUpdatingPages(false)}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    Cancelar
                  </button>
                </form>
              )}

              <div className="w-full h-1.5 rounded-full bg-white/[0.08] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-zinc-300 to-white rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(255,255,255,0.35)]"
                  style={{ width: `${Math.min(100, book.progress)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1">
                <span>{book.pagesRead} de {book.totalPages || '?'} páginas</span>
                <span>Restante: {pagesLeft} págs</span>
              </div>
            </div>

            {/* Main Action Bar (Screen 5 in IMG_0576: Continuar leyendo + options) */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                onClick={() => onOpenReader(book)}
                className="flex-1 py-3 px-6 rounded-2xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>Continuar leyendo</span>
              </button>

              {(book.status === 'TERMINADO' || totalReadings > 1) && (
                <button
                  onClick={() => onStartReread(book)}
                  className="px-4 py-3 rounded-2xl bg-white/[0.06] hover:bg-white/15 text-white border border-white/10 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-[0.98]"
                  title="Iniciar un nuevo registro independiente de relectura sin borrar el anterior"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Iniciar relectura</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Tab Selector: Información | Notas | Subrayados | Frases | Más (Screen 5 en IMG_0576) */}
        <div className="border-t border-white/10 pt-4">
          <div className="flex items-center gap-1 pb-3 overflow-x-auto text-xs no-scrollbar">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'info' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Información
            </button>

            {/* MI RESEÑA / NOTAS */}
            <button
              onClick={() => setActiveTab('review')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'review' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-zinc-300" />
              <span>Notas & Reseña</span>
            </button>


            <button
              onClick={() => setActiveTab('quotes')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'quotes' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Frases & Citas ({bookQuotes.length})
            </button>

            <button
              onClick={() => setActiveTab('sessions')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'sessions' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Historial Sesiones ({bookSessions.length})
            </button>

            <button
              onClick={() => setActiveTab('rereads')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                activeTab === 'rereads' ? 'bg-white/15 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Lecturas ({totalReadings})
            </button>
          </div>

          {/* TAB 1: FICHA & SINOPSIS */}
          {activeTab === 'info' && (
            <div className="space-y-4 text-xs animate-fadeIn">
              {book.description && (
                <div>
                  <h4 className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] mb-1.5">
                    Sinopsis
                  </h4>
                  <p className="text-zinc-300/90 leading-relaxed text-sm font-normal selectable-text bg-white/[0.02] p-4 rounded-2xl border border-white/[0.04]">
                    {book.description}
                  </p>
                </div>
              )}

              {/* Metadata Grid (Requirement 5) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {book.publisher && (
                  <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] text-zinc-500 uppercase font-bold block">Editorial</span>
                    <span className="text-xs text-white font-medium mt-0.5 block">{book.publisher}</span>
                  </div>
                )}
                <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.06]">
                  <span className="text-[10px] text-zinc-500 uppercase font-bold block">Inicio de lectura</span>
                  <span className="text-xs text-white font-medium mt-0.5 block">{formattedStartDate}</span>
                </div>
                <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.06]">
                  <span className="text-[10px] text-zinc-500 uppercase font-bold block">Tiempo total leído</span>
                  <span className="text-xs text-white font-mono font-medium mt-0.5 block">{formattedTotalReadingTime}</span>
                </div>
                {book.totalPages > 0 && (
                  <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] text-zinc-500 uppercase font-bold block">Total Páginas</span>
                    <span className="text-xs text-white font-medium mt-0.5 block">{book.totalPages} págs</span>
                  </div>
                )}
                {book.publishedDate && (
                  <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] text-zinc-500 uppercase font-bold block">Publicación</span>
                    <span className="text-xs text-white font-medium mt-0.5 block">{book.publishedDate}</span>
                  </div>
                )}
              </div>

              {/* Genres, Tags, Collections */}
              <div className="space-y-3 pt-1">
                {book.genres && book.genres.length > 0 && (
                  <div>
                    <span className="text-[11px] text-zinc-400 font-medium mr-2">Géneros:</span>
                    <span className="text-white/90 font-medium">{book.genres.join(' · ')}</span>
                  </div>
                )}

                {/* Requirement 7: Etiquetas con sugerencias previas y confirmación de usuario */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-zinc-400 font-medium">Etiquetas:</span>
                    <button
                      type="button"
                      onClick={() => setIsAddingTag(!isAddingTag)}
                      className="text-xs text-zinc-300 hover:text-white flex items-center gap-1 font-medium underline"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{isAddingTag ? 'Cerrar' : 'Añadir etiqueta'}</span>
                    </button>
                  </div>

                  {/* Active tags chips */}
                  <div className="flex flex-wrap items-center gap-1.5 min-h-[28px]">
                    {book.tags && book.tags.length > 0 ? (
                      book.tags.map((t) => (
                        <span
                          key={t}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] font-medium text-white shadow-sm"
                        >
                          <span>#{t}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveTagFromBook(t)}
                            className="text-zinc-400 hover:text-white p-0.5 rounded-full"
                            title="Eliminar etiqueta"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))
                    ) : (
                      <span className="text-zinc-500 italic text-[11px]">Sin etiquetas asignadas</span>
                    )}
                  </div>

                  {/* Add Tag Box if toggled */}
                  {isAddingTag && (
                    <div className="glass-panel-subtle rounded-2xl p-3 border border-white/15 space-y-2 animate-fadeIn">
                      <div className="flex items-center gap-1.5">
                        <div className="relative flex-1">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">#</span>
                          <input
                            type="text"
                            value={newTagInput}
                            onChange={(e) => setNewTagInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleAddTagToBook(newTagInput);
                              }
                            }}
                            placeholder="Nueva etiqueta..."
                            className="w-full bg-zinc-900 border border-white/20 rounded-xl pl-6 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-white/40"
                            autoFocus
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleAddTagToBook(newTagInput)}
                          className="px-3 py-1.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs"
                        >
                          Añadir
                        </button>
                      </div>

                      {/* Suggestions from previously used tags */}
                      {existingTags && existingTags.length > 0 && (
                        <div className="pt-2 border-t border-white/[0.06]">
                          <span className="text-[10px] text-zinc-400 block mb-1 font-medium">
                            Sugerencias de etiquetas utilizadas anteriormente:
                          </span>
                          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                            {existingTags
                              .filter((sug) => !book.tags?.some((t) => t.toLowerCase() === sug.toLowerCase()))
                              .map((sug) => (
                                <button
                                  key={sug}
                                  type="button"
                                  onClick={() => handleAddTagToBook(sug)}
                                  className="px-2 py-0.5 rounded-lg bg-white/[0.05] hover:bg-white/20 text-zinc-300 hover:text-white border border-white/10 text-[10.5px] transition-all flex items-center gap-1"
                                >
                                  <Plus className="w-2.5 h-2.5 opacity-60" />
                                  <span>#{sug}</span>
                                </button>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {bookCollections.length > 0 && (
                  <div>
                    <span className="text-[11px] text-zinc-400 font-medium mr-2">Colecciones:</span>
                    <span className="text-zinc-300 font-medium">
                      {bookCollections.map((c) => c.name).join(', ')}
                    </span>
                  </div>
                )}
              </div>

              {/* Requirement 6: LÍNEA DEL TIEMPO DE LECTURA */}
              <div className="pt-3 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Línea del tiempo de lectura</span>
                  </h4>
                  <span className="text-[11px] text-zinc-400 font-mono">
                    {bookSessions.length} {bookSessions.length === 1 ? 'sesión' : 'sesiones'}
                  </span>
                </div>

                {bookSessions.length === 0 ? (
                  <div className="glass-panel-subtle rounded-2xl p-5 border border-white/[0.06] text-center text-zinc-400 text-xs">
                    Aún no hay sesiones registradas. Al leer en el lector digital se creará automáticamente tu línea del tiempo de lectura.
                  </div>
                ) : (
                  <div className="relative pl-6 space-y-3.5 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-white/15">
                    {[...bookSessions]
                      .sort((a, b) => b.date.localeCompare(a.date))
                      .map((s) => {
                        const sessionPercent = book.totalPages > 0
                          ? Math.min(100, Math.round((s.endPage / book.totalPages) * 100))
                          : null;
                        return (
                          <div key={s.id} className="relative group">
                            {/* Dot node */}
                            <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-white border-2 border-zinc-950 shadow-sm ring-2 ring-white/20" />
                            <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.08] hover:border-white/20 transition-all space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-white font-medium text-xs">
                                  {new Intl.DateTimeFormat('es-ES', {
                                    weekday: 'short',
                                    day: 'numeric',
                                    month: 'short',
                                    year: 'numeric',
                                  }).format(new Date(s.date.includes('T') ? s.date : `${s.date}T00:00:00`))}
                                </span>
                                <span className="text-xs font-mono font-semibold text-white bg-white/10 px-2 py-0.5 rounded-lg border border-white/10">
                                  {s.durationMinutes} min
                                </span>
                              </div>
                              <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-0.5">
                                <span>
                                  Avanzó +{s.pagesRead} págs (p. {s.startPage} → {s.endPage})
                                </span>
                                {sessionPercent !== null && (
                                  <span className="text-zinc-300 font-medium">
                                    {sessionPercent}% alcanzado
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: MI RESEÑA (Section 45) */}
          {activeTab === 'review' && (
            <div className="space-y-4 animate-fadeIn text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm">Mi Reseña del Libro</h4>
                  <p className="text-[11px] text-zinc-400">
                    Tu opinión personal y valoración integral de esta obra
                  </p>
                </div>

                {!isEditingReview && book.review && (
                  <button
                    onClick={() => {
                      setReviewTitle(book.review?.title || '');
                      setReviewText(book.review?.text || '');
                      setReviewRating(book.review?.rating || book.rating || 0);
                      setIsEditingReview(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/10 text-white font-semibold flex items-center gap-1.5"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Editar reseña</span>
                  </button>
                )}
              </div>

              {isEditingReview || !book.review ? (
                <form onSubmit={handleSaveReview} className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] space-y-3">
                  <div>
                    <label className="text-zinc-300 font-semibold block mb-1">Título de tu reseña (opcional)</label>
                    <input
                      type="text"
                      value={reviewTitle}
                      onChange={(e) => setReviewTitle(e.target.value)}
                      placeholder="Ej. Una aventura inolvidable..."
                      className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/30"
                    />
                  </div>

                  <div>
                    <label className="text-zinc-300 font-semibold block mb-1">Valoración para esta reseña</label>
                    <div className="pt-1">
                      <StarRating rating={reviewRating} interactive onRatingChange={setReviewRating} size="md" showNumber />
                    </div>
                  </div>

                  <div>
                    <label className="text-zinc-300 font-semibold block mb-1">Tu reseña y conclusiones *</label>
                    <textarea
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      placeholder="Escribe aquí tu análisis, reflexiones, puntos fuertes o débiles del libro..."
                      rows={5}
                      required
                      className="w-full bg-zinc-900 border border-white/15 rounded-xl p-3 text-white placeholder-zinc-500 focus:outline-none focus:border-white/30 leading-relaxed font-serif text-sm"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    {book.review ? (
                      <button
                        type="button"
                        onClick={handleDeleteReview}
                        className="text-zinc-400 hover:text-white font-medium"
                      >
                        Eliminar reseña
                      </button>
                    ) : <div />}

                    <div className="flex items-center gap-2">
                      {book.review && (
                        <button
                          type="button"
                          onClick={() => setIsEditingReview(false)}
                          className="px-3 py-1.5 text-zinc-400 hover:text-white"
                        >
                          Cancelar
                        </button>
                      )}
                      <button
                        type="submit"
                        className="px-5 py-2 bg-white hover:bg-zinc-200 text-zinc-950 font-bold rounded-xl shadow transition-all"
                      >
                        Guardar reseña
                      </button>
                    </div>
                  </div>
                </form>
              ) : (
                <div className="glass-panel-subtle rounded-2xl p-5 border border-white/[0.08] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      {book.review.title && (
                        <h4 className="text-base font-bold text-white tracking-tight">{book.review.title}</h4>
                      )}
                      <span className="text-[11px] text-zinc-500">
                        Publicada el {new Date(book.review.createdAt).toLocaleDateString('es-ES', { month: 'long', day: 'numeric', year: 'numeric' })}
                      </span>
                    </div>
                    {book.review.rating && book.review.rating > 0 && (
                      <StarRating rating={book.review.rating} size="sm" showNumber />
                    )}
                  </div>

                  <p className="text-sm font-serif leading-relaxed text-zinc-200 selectable-text whitespace-pre-line pt-2 border-t border-white/[0.06]">
                    {book.review.text}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FRASES DE ESTE LIBRO */}
          {activeTab === 'quotes' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400">Frases guardadas ({bookQuotes.length})</span>
                <button
                  onClick={() => onOpenAddQuoteForBook(book.id)}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white border border-white/20 text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir frase</span>
                </button>
              </div>

              {bookQuotes.length === 0 ? (
                <div className="text-center py-8 text-zinc-500 text-xs">
                  No hay frases guardadas todavía para este libro.
                </div>
              ) : (
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {bookQuotes.map((q) => (
                    <div
                      key={q.id}
                      className="glass-panel-subtle rounded-xl p-3 border border-white/[0.08] relative overflow-hidden"
                    >
                      <div
                        className="absolute top-0 left-0 bottom-0 w-1"
                        style={{ backgroundColor: q.color || '#ffffff' }}
                      />
                      <div className="pl-2 space-y-1.5">
                        <blockquote className="text-xs font-serif italic text-white/90">
                          "{q.text}"
                        </blockquote>
                        <div className="flex items-center justify-between text-[11px] text-zinc-400">
                          {q.page && <span>Pág. {q.page}</span>}
                          {q.customStickerUrl ? (
                            <div className="flex items-center gap-2">
                              <img src={q.customStickerUrl} alt="" className="w-12 h-12 rounded-xl object-contain drop-shadow" />
                              <span className="text-zinc-300 font-medium">{q.reaction}</span>
                            </div>
                          ) : q.reaction ? (
                            <span className="text-zinc-300 font-medium">{q.reaction}</span>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SESIONES DE ESTE LIBRO (Requirement 6: Línea del tiempo vertical) */}
          {activeTab === 'sessions' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400 font-medium block">
                  Línea del tiempo de lecturas dedicadas ({bookSessions.length})
                </span>
                <span className="text-xs font-mono text-white font-semibold">
                  Total: {formattedTotalReadingTime}
                </span>
              </div>

              {bookSessions.length === 0 ? (
                <div className="text-center py-8 text-zinc-500 text-xs glass-panel-subtle rounded-2xl p-5 border border-white/[0.06]">
                  Aún no hay sesiones registradas. Inicia el lector digital para registrar tiempo.
                </div>
              ) : (
                <div className="relative pl-6 space-y-3 max-h-72 overflow-y-auto pr-1 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-white/15">
                  {[...bookSessions]
                    .sort((a, b) => b.date.localeCompare(a.date))
                    .map((s) => {
                      const sessionPercent = book.totalPages > 0
                        ? Math.min(100, Math.round((s.endPage / book.totalPages) * 100))
                        : null;
                      return (
                        <div key={s.id} className="relative group">
                          {/* Dot node */}
                          <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-white border-2 border-zinc-950 shadow-sm ring-2 ring-white/20" />
                          <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.08] hover:border-white/20 transition-all space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-white font-medium text-xs">
                                {new Intl.DateTimeFormat('es-ES', {
                                  weekday: 'short',
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                }).format(new Date(s.date.includes('T') ? s.date : `${s.date}T00:00:00`))}
                              </span>
                              <span className="text-xs font-mono font-semibold text-white bg-white/10 px-2 py-0.5 rounded-lg border border-white/10">
                                {s.durationMinutes} min
                              </span>
                            </div>
                            <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-0.5">
                              <span>
                                Avanzó +{s.pagesRead} págs (p. {s.startPage} → {s.endPage})
                              </span>
                              {sessionPercent !== null && (
                                <span className="text-zinc-300 font-medium">
                                  {sessionPercent}% acumulado
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: REGISTROS DE LECTURA INDEPENDIENTES (Requirement 1: RELECTURAS) */}
          {activeTab === 'rereads' && (
            <div className="space-y-4 animate-fadeIn text-xs">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-white/10">
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                    <RotateCcw className="w-4 h-4 text-cyan-400" />
                    <span>Registros de Lectura ({totalReadings})</span>
                  </h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Cada lectura conserva independientemente sus estadísticas, progreso, fechas y anotaciones.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onStartReread(book)}
                  className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow flex items-center gap-1.5 transition-all shrink-0 active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Iniciar nueva relectura</span>
                </button>
              </div>

              {/* Selector de registros de lectura */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
                {rawRecords.map((rec) => {
                  const isSelected = rec.id === selectedRecord.id;
                  const isReread = rec.recordNumber > 1 || rec.status === 'RELECTURA';
                  return (
                    <button
                      key={rec.id}
                      type="button"
                      onClick={() => setSelectedRecordId(rec.id)}
                      className={`px-3.5 py-2 rounded-2xl border text-left transition-all shrink-0 ${
                        isSelected
                          ? 'bg-cyan-500/15 border-cyan-400/80 text-white shadow-md ring-1 ring-cyan-400/30'
                          : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs">
                          {isReread ? `Lectura ${rec.recordNumber} (Relectura)` : `Lectura ${rec.recordNumber} (Inicial)`}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold ${
                            rec.status === 'TERMINADO'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}
                        >
                          {rec.status === 'TERMINADO' ? 'Terminada' : `${rec.progress}%`}
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-400 block mt-0.5 font-mono">
                        {Math.floor((rec.totalReadingMinutes || 0) / 60)}h {(rec.totalReadingMinutes || 0) % 60}m · {rec.pagesRead} págs
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Detalle del Registro Seleccionado */}
              <div className="glass-panel-subtle rounded-2xl p-4 sm:p-5 border border-white/10 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/[0.06]">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                      Registro de {selectedRecord.recordNumber > 1 ? `Relectura #${selectedRecord.recordNumber - 1}` : 'Primera Lectura'}
                    </span>
                    <h5 className="text-base font-bold text-white tracking-tight mt-0.5">
                      Lectura {selectedRecord.recordNumber}: {selectedRecord.status === 'TERMINADO' ? 'Completada' : 'En Curso'}
                    </h5>
                  </div>
                  <span className="text-base font-mono font-bold text-white bg-white/10 px-3 py-1 rounded-xl border border-white/10">
                    {selectedRecord.progress}%
                  </span>
                </div>

                {/* 4 Metric Boxes for this specific reading record */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="glass-panel rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">Inicio</span>
                    <span className="text-xs text-white font-medium mt-0.5 block">
                      {new Date(selectedRecord.dateStarted).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>

                  <div className="glass-panel rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">Finalización</span>
                    <span className="text-xs text-white font-medium mt-0.5 block">
                      {selectedRecord.dateFinished
                        ? new Date(selectedRecord.dateFinished).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })
                        : 'En curso'}
                    </span>
                  </div>

                  <div className="glass-panel rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">Páginas leídas</span>
                    <span className="text-xs text-white font-mono font-bold mt-0.5 block">
                      {selectedRecord.pagesRead} de {book.totalPages || '?'}
                    </span>
                  </div>

                  <div className="glass-panel rounded-xl p-3 border border-white/[0.06]">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">Tiempo total</span>
                    <span className="text-xs text-white font-mono font-bold mt-0.5 block">
                      {Math.floor((selectedRecord.totalReadingMinutes || 0) / 60)}h {(selectedRecord.totalReadingMinutes || 0) % 60}m
                    </span>
                  </div>
                </div>

                {/* Progress bar for this record */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-zinc-400">
                    <span>Progreso de esta lectura</span>
                    <span className="font-mono text-white font-bold">{selectedRecord.progress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-white transition-all duration-500"
                      style={{ width: `${selectedRecord.progress}%` }}
                    />
                  </div>
                </div>

                {/* Independent Annotations & Quotes in this record */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                      Subrayados & Notas de este registro
                    </span>
                    <span className="text-sm font-bold text-white block">
                      {(selectedRecord.highlights?.length || 0) + (selectedRecord.annotations?.length || 0)} elementos
                    </span>
                    <p className="text-[11px] text-zinc-400">
                      Conservados de forma totalmente independiente del resto de lecturas.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                      Sesiones de lectura de este registro
                    </span>
                    <span className="text-sm font-bold text-white block">
                      {selectedRecord.sessions?.length || 0} sesiones
                    </span>
                    <p className="text-[11px] text-zinc-400">
                      El historial y las estadísticas de cada lectura nunca se sobrescriben.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
