import React, { useState, useRef } from 'react';
import { Book, ReadingStatus, Collection, BookChapter } from '../../types';
import { StarRating } from '../common/StarRating';
import { processEpubFile, processPdfFile, paginateContent } from '../../services/bookFileProcessor';
import { X, Upload, FileText, CheckCircle2, AlertCircle, BookOpen, Tag as TagIcon, Plus } from 'lucide-react';

interface BookFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (book: Book) => void;
  initialBook?: Book | null;
  collections: Collection[];
  initialMode?: 'manual' | 'import';
  existingTags?: string[];
  existingGenres?: string[];
  onAddNewCustomGenre?: (genre: string) => void;
}

export const BookFormModal: React.FC<BookFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialBook,
  collections,
  initialMode = 'manual',
  existingTags = [],
  existingGenres = [],
  onAddNewCustomGenre,
}) => {
  if (!isOpen) return null;

  const isEditing = Boolean(initialBook);

  const [activeTab, setActiveTab] = useState<'manual' | 'import'>(
    isEditing ? 'manual' : initialMode
  );

  const [title, setTitle] = useState(initialBook?.title || '');
  const [author, setAuthor] = useState(initialBook?.author || '');
  const [coverUrl, setCoverUrl] = useState(initialBook?.coverUrl || '');
  const [genres, setGenres] = useState<string[]>(initialBook?.genres || []);
  const [newGenreInput, setNewGenreInput] = useState('');
  const [tags, setTags] = useState<string[]>(initialBook?.tags || []);
  const [newTagInput, setNewTagInput] = useState('');
  const [saga, setSaga] = useState(initialBook?.saga || '');
  const [sagaIndex, setSagaIndex] = useState<number | ''>(initialBook?.sagaIndex ?? '');
  const [publisher, setPublisher] = useState(initialBook?.publisher || '');
  const [publishedDate, setPublishedDate] = useState(initialBook?.publishedDate || '');
  const [totalPages, setTotalPages] = useState<number | ''>(initialBook?.totalPages ?? '');
  const [pagesRead, setPagesRead] = useState<number | ''>(initialBook?.pagesRead ?? 0);
  const [description, setDescription] = useState(initialBook?.description || '');
  const [rating, setRating] = useState<number>(initialBook?.rating || 0);
  const [status, setStatus] = useState<ReadingStatus>(initialBook?.status || 'POR LEER');
  const [favorite, setFavorite] = useState(initialBook?.favorite || false);
  const [selectedCollections, setSelectedCollections] = useState<string[]>(initialBook?.collections || []);
  const [sampleContent, setSampleContent] = useState(initialBook?.sampleContent || '');
  const [chapters, setChapters] = useState<BookChapter[]>(initialBook?.chapters || []);
  const [fileAttachment, setFileAttachment] = useState<Book['fileAttachment']>(initialBook?.fileAttachment);

  // Import Status
  const [importNotice, setImportNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [importedFileName, setImportedFileName] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Image Upload handler (Base64 data URL for offline persistence in IndexedDB)
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Tag helper functions
  // Genre management (Requirement 2: sugerir géneros anteriores, crear manualmente, guardar)
  const handleAddGenre = (rawGenre: string) => {
    const clean = rawGenre.trim();
    if (!clean) return;
    if (!genres.some((g) => g.toLowerCase() === clean.toLowerCase())) {
      setGenres([...genres, clean]);
      if (onAddNewCustomGenre) {
        onAddNewCustomGenre(clean);
      }
    }
    setNewGenreInput('');
  };

  const handleRemoveGenre = (genreToRemove: string) => {
    setGenres(genres.filter((g) => g.toLowerCase() !== genreToRemove.toLowerCase()));
  };

  const suggestedGenres = (existingGenres || []).filter(
    (eg) => !genres.some((g) => g.toLowerCase() === eg.toLowerCase())
  );

  const handleAddTag = (rawTag: string) => {
    const clean = rawTag.trim().replace(/^#/, '');
    if (!clean) return;
    if (!tags.some((t) => t.toLowerCase() === clean.toLowerCase())) {
      setTags([...tags, clean]);
    }
    setNewTagInput('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  // Book File Import handler (.epub, .pdf, .txt, .json)
  const processImportedFile = async (file: File) => {
    setImportedFileName(file.name);
    setImportNotice(null);

    const ext = file.name.slice(file.name.lastIndexOf('.')).toLowerCase();
    const baseName = file.name
      .replace(/\.[^/.]+$/, '')
      .replace(/[-_]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    try {
      if (ext === '.epub') {
        const res = await processEpubFile(file);
        setTitle(res.title);
        setAuthor(res.author);
        setTotalPages(res.totalPages);
        setPagesRead(0);
        setStatus('POR LEER');
        setSampleContent(res.sampleContent);
        setChapters(res.chapters);
        setFileAttachment(res.fileAttachment);
        if (res.coverUrl) setCoverUrl(res.coverUrl);
        if (res.description) setDescription(res.description);
        setImportNotice({
          type: 'success',
          message: `EPUB procesado con éxito: "${res.title}" (${res.totalPages} páginas reales, ${res.chapters.length} capítulos). Progreso inicial: 0%.`,
        });
      } else if (ext === '.pdf') {
        const res = await processPdfFile(file);
        setTitle(res.title);
        setAuthor(res.author);
        setTotalPages(res.totalPages);
        setPagesRead(0);
        setStatus('POR LEER');
        setSampleContent(res.sampleContent);
        setChapters(res.chapters);
        setFileAttachment(res.fileAttachment);
        if (res.description) setDescription(res.description);
        setImportNotice({
          type: 'success',
          message: `PDF procesado con éxito: "${res.title}" (${res.totalPages} páginas detectadas). Progreso inicial: 0%.`,
        });
      } else if (ext === '.txt') {
        const text = await file.text();
        setTitle(baseName);
        if (!author) setAuthor('Autor Desconocido');
        const pages = paginateContent(text);
        const totalP = Math.max(1, pages.length);
        setTotalPages(totalP);
        setPagesRead(0);
        setStatus('POR LEER');
        setSampleContent(pages.join('\n\n---PAGE---\n\n'));
        setImportNotice({
          type: 'success',
          message: `Archivo de texto importado (${totalP} páginas paginadas). Progreso inicial: 0%.`,
        });
      } else if (ext === '.json') {
        const text = await file.text();
        const data = JSON.parse(text);
        if (data.title) setTitle(data.title);
        else setTitle(baseName);
        if (data.author) setAuthor(data.author);
        if (data.totalPages) setTotalPages(Number(data.totalPages));
        if (data.coverUrl) setCoverUrl(data.coverUrl);
        if (data.description) setDescription(data.description);
        if (data.sampleContent) setSampleContent(data.sampleContent);
        if (Array.isArray(data.genres)) {
          const merged = Array.from(new Set([...genres, ...data.genres.map((g: string) => String(g).trim()).filter(Boolean)]));
          setGenres(merged);
          merged.forEach((g) => onAddNewCustomGenre?.(g));
        }
        if (Array.isArray(data.tags)) setTags(data.tags);
        if (data.saga) setSaga(data.saga);
        if (data.publisher) setPublisher(data.publisher);
        if (data.status) setStatus(data.status);
        if (data.pagesRead !== undefined) setPagesRead(Number(data.pagesRead));
        else setPagesRead(0);
        if (data.rating) setRating(Number(data.rating));
        if (Array.isArray(data.chapters)) setChapters(data.chapters);

        setImportNotice({
          type: 'success',
          message: `Libro importado con éxito: "${data.title || baseName}". Puedes revisar los datos y guardar.`,
        });
      } else {
        setTitle(baseName);
        setImportNotice({
          type: 'success',
          message: `Archivo "${file.name}" cargado. Revisa y completa los detalles del libro.`,
        });
      }
    } catch (err: any) {
      console.error('Error importing book file:', err);
      setImportNotice({
        type: 'error',
        message: 'No se pudo leer el archivo seleccionado. Verifica el formato e intenta nuevamente.',
      });
    }
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processImportedFile(e.dataTransfer.files[0]);
    }
  };

  const handleToggleCollection = (colId: string) => {
    if (selectedCollections.includes(colId)) {
      setSelectedCollections(selectedCollections.filter((id) => id !== colId));
    } else {
      setSelectedCollections([...selectedCollections, colId]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !author.trim()) return;

    const parsedTotalPages = totalPages === '' ? 0 : Number(totalPages);
    const parsedPagesRead = pagesRead === '' ? 0 : Number(pagesRead);

    // Calculate progress (CRITICAL: never 100% by default unless status is TERMINADO or pagesRead == totalPages)
    let calculatedProgress = 0;
    if (status === 'TERMINADO') {
      calculatedProgress = 100;
    } else if (parsedTotalPages > 0 && parsedPagesRead > 0) {
      calculatedProgress = Math.min(100, Math.round((parsedPagesRead / parsedTotalPages) * 100));
    } else {
      calculatedProgress = 0;
    }

    let finalGenres = [...genres];
    if (newGenreInput.trim()) {
      const extraGenre = newGenreInput.trim();
      if (!finalGenres.some((g) => g.toLowerCase() === extraGenre.toLowerCase())) {
        finalGenres.push(extraGenre);
        onAddNewCustomGenre?.(extraGenre);
      }
    }
    finalGenres.forEach((g) => onAddNewCustomGenre?.(g));

    const savedBook: Book = {
      id: initialBook?.id || 'book-' + Date.now(),
      title: title.trim(),
      author: author.trim(),
      coverUrl: coverUrl.trim() || undefined,
      genres: finalGenres,
      tags,
      saga: saga.trim() || undefined,
      sagaIndex: sagaIndex === '' ? undefined : Number(sagaIndex),
      publisher: publisher.trim() || undefined,
      publishedDate: publishedDate.trim() || undefined,
      totalPages: parsedTotalPages,
      pagesRead: parsedPagesRead,
      progress: calculatedProgress,
      description: description.trim() || undefined,
      rating,
      status,
      favorite,
      collections: selectedCollections,
      dateAdded: initialBook?.dateAdded || new Date().toISOString(),
      dateStarted: initialBook?.dateStarted || (status === 'LEYENDO' ? new Date().toISOString() : undefined),
      dateFinished: initialBook?.dateFinished || (status === 'TERMINADO' ? new Date().toISOString() : undefined),
      totalReadingMinutes: initialBook?.totalReadingMinutes || 0,
      rereadCount: initialBook?.rereadCount || 0,
      rereadHistory: initialBook?.rereadHistory || [],
      isSample: false,
      sampleContent: sampleContent.trim() || undefined,
      chapters: chapters.length > 0 ? chapters : undefined,
      fileAttachment,
    };

    onSave(savedBook);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl overflow-y-auto">
      <div className="w-full max-w-2xl glass-panel rounded-3xl p-5 sm:p-7 border border-white/15 shadow-2xl my-auto animate-fadeIn max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-zinc-300" />
            <h3 className="text-base sm:text-lg font-bold text-white tracking-tight font-['Syne']">
              {isEditing ? 'Editar Libro' : 'Agregar o Importar Libro'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch: Manual vs Importar */}
        {!isEditing && (
          <div className="flex items-center gap-2 p-1 bg-white/[0.04] border border-white/10 rounded-2xl mb-5">
            <button
              type="button"
              onClick={() => setActiveTab('manual')}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'manual'
                  ? 'bg-white/15 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Formulario Manual
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('import')}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'import'
                  ? 'bg-white/15 border border-white/20 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5 text-zinc-300" />
              <span>Importar Archivo (.epub, .pdf, .txt, .json)</span>
            </button>
          </div>
        )}

        {/* Import Tab Dropzone */}
        {activeTab === 'import' && !isEditing && (
          <div className="space-y-4 mb-6">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleFileDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                isDragOver
                  ? 'border-white/50 bg-white/[0.08]'
                  : 'border-white/20 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/40'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".epub,.pdf,.txt,.json,.fb2"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    processImportedFile(e.target.files[0]);
                  }
                }}
                className="sr-only"
              />
              <div className="w-12 h-12 rounded-2xl bg-white/[0.06] border border-white/10 flex items-center justify-center mx-auto mb-3 text-zinc-300">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-white">
                Haz clic o arrastra aquí tu libro importado
              </p>
              <p className="text-xs text-zinc-400 mt-1">
                Formatos compatibles: <strong className="text-zinc-300">.epub, .pdf, .txt, .json</strong>
              </p>
              {importedFileName && (
                <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-mono text-zinc-200 border border-white/15">
                  <FileText className="w-3.5 h-3.5" />
                  <span>{importedFileName}</span>
                </div>
              )}
            </div>

            {importNotice && (
              <div
                className="p-3 rounded-xl border border-white/20 bg-white/[0.05] text-xs text-zinc-200 flex items-center gap-2"
              >
                {importNotice.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-white" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-white" />
                )}
                <span>{importNotice.message}</span>
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Main Info Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Título del libro *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ej. Cien Años de Soledad"
                required
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Autor o autores *</label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Ej. Gabriel García Márquez"
                required
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
          </div>

          {/* Cover: URL or File Upload */}
          <div className="glass-panel-subtle rounded-xl p-3 border border-white/[0.08] space-y-2">
            <label className="text-zinc-300 font-semibold block">Portada del libro</label>
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <input
                type="url"
                value={coverUrl}
                onChange={(e) => setCoverUrl(e.target.value)}
                placeholder="URL de imagen (https://...)"
                className="flex-1 w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 text-xs"
              />
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <span className="text-[11px] text-zinc-400">o</span>
                <label className="px-3 py-2 rounded-xl bg-white/[0.06] hover:bg-white/10 text-white cursor-pointer border border-white/10 flex items-center gap-1.5 transition-all text-xs font-medium">
                  <Upload className="w-3.5 h-3.5 text-zinc-300" />
                  <span>Subir imagen</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="sr-only"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Saga & Index */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="text-zinc-300 font-semibold block mb-1">Saga (opcional)</label>
              <input
                type="text"
                value={saga}
                onChange={(e) => setSaga(e.target.value)}
                placeholder="Ej. Crónicas de Narnia"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Nº en saga</label>
              <input
                type="number"
                value={sagaIndex}
                onChange={(e) => setSagaIndex(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Ej. 1"
                min="1"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
          </div>

          {/* Publisher, Date & Total Pages */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Editorial</label>
              <input
                type="text"
                value={publisher}
                onChange={(e) => setPublisher(e.target.value)}
                placeholder="Ej. Planeta"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Fecha publicación</label>
              <input
                type="text"
                value={publishedDate}
                onChange={(e) => setPublishedDate(e.target.value)}
                placeholder="AAAA o AAAA-MM-DD"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Número de páginas</label>
              <input
                type="number"
                value={totalPages}
                onChange={(e) => setTotalPages(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Ej. 420"
                min="0"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
          </div>

          {/* Status, Pages Read & Rating */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Estado de lectura</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ReadingStatus)}
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              >
                <option value="POR LEER">Por leer</option>
                <option value="LEYENDO">Leyendo actualmente</option>
                <option value="TERMINADO">Terminado</option>
                <option value="ABANDONADO">Abandonado</option>
              </select>
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Páginas leídas</label>
              <input
                type="number"
                value={pagesRead}
                onChange={(e) => setPagesRead(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0"
                min="0"
                className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Calificación (0 a 5)</label>
              <div className="pt-1">
                <StarRating rating={rating} interactive onRatingChange={setRating} size="sm" />
              </div>
            </div>
          </div>

          {/* Genres & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Géneros del libro</label>

              {/* Current book genres chips */}
              <div className="flex flex-wrap items-center gap-1.5 mb-2 min-h-[28px]">
                {genres.map((g) => (
                  <span
                    key={g}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] font-medium text-white shadow-sm"
                  >
                    <span>{g}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveGenre(g)}
                      className="text-zinc-400 hover:text-white p-0.5 rounded-full"
                      title="Eliminar género"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                {genres.length === 0 && (
                  <span className="text-[11px] text-zinc-500 italic">Sin géneros asignados</span>
                )}
              </div>

              {/* Input to create/add genre manually */}
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={newGenreInput}
                  onChange={(e) => setNewGenreInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddGenre(newGenreInput);
                    }
                  }}
                  placeholder="Crear o escribir género..."
                  className="flex-1 bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
                />
                <button
                  type="button"
                  onClick={() => handleAddGenre(newGenreInput)}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir</span>
                </button>
              </div>

              {/* Suggested previously used genres */}
              {suggestedGenres.length > 0 && (
                <div className="mt-2 space-y-1">
                  <span className="text-[10px] text-zinc-400 uppercase font-semibold tracking-wider block">
                    Géneros anteriores sugeridos:
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5 max-h-20 overflow-y-auto pr-1">
                    {suggestedGenres.slice(0, 10).map((sg) => (
                      <button
                        key={sg}
                        type="button"
                        onClick={() => handleAddGenre(sg)}
                        className="px-2 py-0.5 rounded-md bg-white/[0.04] hover:bg-white/15 text-zinc-300 hover:text-white border border-white/10 text-[10.5px] transition-all flex items-center gap-1"
                        title={`Añadir género sugerido "${sg}"`}
                      >
                        <Plus className="w-2.5 h-2.5 text-zinc-400" />
                        <span>{sg}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Etiquetas del libro</label>
              
              {/* Existing tags chips */}
              <div className="flex flex-wrap items-center gap-1.5 mb-2 min-h-[28px]">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] font-medium text-white shadow-sm"
                  >
                    <span>#{t}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(t)}
                      className="text-zinc-400 hover:text-white p-0.5 rounded-full"
                      title="Eliminar etiqueta"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                {tags.length === 0 && (
                  <span className="text-[11px] text-zinc-500 italic">Sin etiquetas añadidas aún</span>
                )}
              </div>

              {/* Add new tag input */}
              <div className="flex items-center gap-1.5">
                <div className="relative flex-1">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400 text-xs">#</span>
                  <input
                    type="text"
                    value={newTagInput}
                    onChange={(e) => setNewTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddTag(newTagInput);
                      }
                    }}
                    placeholder="Escribe una etiqueta..."
                    className="w-full bg-zinc-900/90 border border-white/15 rounded-xl pl-6 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleAddTag(newTagInput)}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/20 text-white text-xs font-semibold border border-white/15 flex items-center gap-1 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir</span>
                </button>
              </div>

              {/* Suggestions from previously used tags (Requirement 7) */}
              {existingTags && existingTags.length > 0 && (
                <div className="mt-2.5 pt-2 border-t border-white/[0.06]">
                  <span className="text-[10px] text-zinc-400 block mb-1 font-medium">
                    Sugerencias utilizadas anteriormente (toca para añadir):
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                    {existingTags
                      .filter((sug) => !tags.some((t) => t.toLowerCase() === sug.toLowerCase()))
                      .map((sug) => (
                        <button
                          key={sug}
                          type="button"
                          onClick={() => handleAddTag(sug)}
                          className="px-2 py-0.5 rounded-lg bg-white/[0.04] hover:bg-white/15 text-zinc-300 hover:text-white border border-white/10 text-[10.5px] transition-all flex items-center gap-1"
                        >
                          <Plus className="w-2.5 h-2.5 opacity-60" />
                          <span>#{sug}</span>
                        </button>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Collections */}
          {collections.length > 0 && (
            <div>
              <label className="text-zinc-300 font-semibold block mb-1.5">Añadir a colecciones</label>
              <div className="flex flex-wrap gap-2">
                {collections.map((c) => {
                  const isChecked = selectedCollections.includes(c.id);
                  return (
                    <button
                      type="button"
                      key={c.id}
                      onClick={() => handleToggleCollection(c.id)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${
                        isChecked
                          ? 'bg-white/20 border-white/40 text-white font-semibold'
                          : 'bg-white/[0.04] border-white/10 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '}
                      {c.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Sinopsis o descripción</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Breve resumen del libro..."
              className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 resize-none"
            />
          </div>

          {/* Sample / Reader Content */}
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">
              Texto o fragmento para el lector (opcional)
            </label>
            <textarea
              rows={3}
              value={sampleContent}
              onChange={(e) => setSampleContent(e.target.value)}
              placeholder="Pega el texto del libro o un fragmento para leerlo en el lector..."
              className="w-full bg-zinc-900/90 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 font-mono text-xs resize-none"
            />
          </div>

          {/* Favorite Toggle */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="book-fav"
              checked={favorite}
              onChange={(e) => setFavorite(e.target.checked)}
              className="rounded bg-zinc-900 border-white/20 text-white focus:ring-white/20 accent-white"
            />
            <label htmlFor="book-fav" className="text-zinc-300 cursor-pointer select-none">
              Marcar como favorito en mi biblioteca
            </label>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-zinc-300 font-semibold transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold shadow-lg active:scale-95 transition-all"
            >
              {isEditing ? 'Guardar Cambios' : 'Guardar Libro'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
