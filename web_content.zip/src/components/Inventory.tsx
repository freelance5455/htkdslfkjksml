import { useEffect, useState } from "react";
import type { Game, InvState } from "../game/Game";
import { ITEMS, HOT, BAG, Slot } from "../game/items";
import { iconURL } from "../game/itemIcons";

function SlotBox({
  slot, active, picked, onTap, size = "md", keyNum,
}: {
  slot: Slot | null;
  active?: boolean;
  picked?: boolean;
  onTap: () => void;
  size?: "sm" | "md" | "lg";
  keyNum?: number;
}) {
  const dim = size === "sm" ? "h-9 w-9 sm:h-11 sm:w-11" : size === "lg" ? "h-12 w-12 sm:h-14 sm:w-14" : "h-10 w-10 sm:h-12 sm:w-12";
  return (
    <button
      onPointerDown={(e) => { e.stopPropagation(); onTap(); }}
      className={`relative ${dim} shrink-0 rounded-[4px] border-2 transition-transform active:scale-95 ${
        picked
          ? "border-amber-300 bg-amber-500/30"
          : active
            ? "border-fuchsia-300 bg-fuchsia-500/30 shadow-[0_0_10px_rgba(220,120,255,0.6)]"
            : "border-white/15 bg-black/45"
      }`}
      style={{ boxShadow: active ? undefined : "inset 0 0 0 1px rgba(0,0,0,0.6)" }}
    >
      {slot && (
        <img
          src={iconURL(slot.id)}
          alt={ITEMS[slot.id].name}
          draggable={false}
          className="absolute inset-[3px] h-[calc(100%-6px)] w-[calc(100%-6px)]"
          style={{ imageRendering: "pixelated" }}
        />
      )}
      {slot && slot.n > 1 && (
        <span className="absolute bottom-0 right-0.5 text-[11px] leading-none text-white" style={{ textShadow: "1px 1px 0 #000, -1px 0 0 #000" }}>
          {slot.n}
        </span>
      )}
      {keyNum !== undefined && (
        <span className="absolute left-0.5 top-0 hidden text-[9px] leading-none text-white/50 sm:block">{keyNum}</span>
      )}
    </button>
  );
}

export function Hotbar({ game, inv, onOpenInventory }: { game: Game | null; inv: InvState | null; onOpenInventory: () => void }) {
  const [label, setLabel] = useState<string | null>(null);
  const sel = inv?.selected ?? 0;
  const cur = inv?.slots[sel] ?? null;
  useEffect(() => {
    if (!cur) { setLabel(null); return; }
    const d = ITEMS[cur.id];
    setLabel(d.kind === "food" ? `${d.name} · toque de novo para usar` : d.name);
    const t = setTimeout(() => setLabel(null), 2200);
    return () => clearTimeout(t);
  }, [sel, cur?.id]);

  if (!inv) return null;
  return (
    <div className="pointer-events-none absolute bottom-2 left-1/2 z-30 flex -translate-x-1/2 flex-col items-center gap-1 sm:bottom-3 coarse:sm:left-[41%]">
      {label && <div className="pixel-panel px-2 py-0.5 text-[11px] text-white/90">{label}</div>}
      <div className="pixel-panel pointer-events-auto flex items-center gap-1 p-1">
        {inv.slots.slice(0, HOT).map((s, i) => (
          <SlotBox key={i} slot={s} active={i === sel} size="sm" keyNum={i + 1} onTap={() => game?.selectSlot(i)} />
        ))}
        <button
          onPointerDown={(e) => { e.stopPropagation(); onOpenInventory(); }}
          className="pixel-btn ml-0.5 h-9 w-9 shrink-0 bg-amber-700/80 text-lg sm:h-11 sm:w-11"
          aria-label="Inventário"
        >
          🎒
        </button>
      </div>
    </div>
  );
}

export function InventoryPanel({ game, inv, hp, maxHp, onClose }: { game: Game; inv: InvState; hp: number; maxHp: number; onClose: () => void }) {
  const [picked, setPicked] = useState<number | null>(null);
  const [moving, setMoving] = useState(false);
  const s = picked !== null ? inv.slots[picked] : null;
  const def = s ? ITEMS[s.id] : null;
  const panos = inv.slots.reduce((a, x) => a + (x && x.id === "pano" ? x.n : 0), 0);
  const used = inv.slots.filter(Boolean).length;

  useEffect(() => {
    if (picked !== null && !inv.slots[picked]) { setPicked(null); setMoving(false); }
  }, [inv, picked]);

  const tap = (i: number) => {
    if (moving && picked !== null) {
      game.moveItem(picked, i);
      setMoving(false);
      setPicked(null);
      return;
    }
    if (picked === i) { setPicked(null); return; }
    setPicked(inv.slots[i] ? i : null);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-2" onClick={onClose} style={{ touchAction: "pan-y" }}>
      <div
        className="pixel-panel flex max-h-full w-full max-w-2xl flex-col gap-3 overflow-y-auto p-3 text-white sm:flex-row sm:p-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base uppercase tracking-widest text-fuchsia-300 sm:text-lg">🎒 Inventário</h2>
            <span className="text-[11px] text-white/60">{used}/{HOT + BAG}</span>
            <button onClick={onClose} className="pixel-btn bg-rose-600 px-3 py-1 text-sm sm:hidden">✕</button>
          </div>
          <div className="text-[11px] uppercase tracking-wider text-white/60">Mochila · 20 espaços</div>
          <div className="grid grid-cols-5 gap-1.5 self-start">
            {inv.slots.slice(HOT, HOT + BAG).map((sl, k) => {
              const i = HOT + k;
              return <SlotBox key={i} slot={sl} size="lg" picked={picked === i} onTap={() => tap(i)} />;
            })}
          </div>
          <div className="mt-1 text-[11px] uppercase tracking-wider text-white/60">Barra rápida · 8 espaços</div>
          <div className="flex flex-wrap gap-1.5">
            {inv.slots.slice(0, HOT).map((sl, i) => (
              <SlotBox key={i} slot={sl} size="md" keyNum={i + 1} active={i === inv.selected} picked={picked === i} onTap={() => tap(i)} />
            ))}
          </div>
        </div>

        <div className="flex min-w-0 flex-1 flex-col gap-3">
          <div className="hidden justify-end sm:flex">
            <button onClick={onClose} className="pixel-btn bg-rose-600 px-3 py-1 text-sm">✕</button>
          </div>
          <div className="flex items-center gap-2 rounded bg-black/30 p-2">
            <span>❤️</span>
            <div className="h-3 flex-1 bg-black/60">
              <div className="h-3" style={{ width: `${(hp / maxHp) * 100}%`, background: "linear-gradient(to bottom,#ff6b7a,#d8354a 45%,#9a1a2e)" }} />
            </div>
            <span className="text-xs">{Math.ceil(hp)}/{maxHp}</span>
          </div>

          <div className="min-h-[124px] rounded bg-black/30 p-3">
            {def && s ? (
              <>
                <div className="mb-1 flex items-center gap-2">
                  <img src={iconURL(s.id)} alt="" className="h-10 w-10" style={{ imageRendering: "pixelated" }} />
                  <div>
                    <div className="text-sm text-amber-200">{def.name} {s.n > 1 && <span className="text-white/60">×{s.n}</span>}</div>
                    <div className="text-[10px] uppercase tracking-wider text-fuchsia-300">
                      {def.kind === "weapon" ? `Arma · Dano ${def.damage}` : def.kind === "food" ? `Cura · +${def.heal} ❤` : "Material"}
                    </div>
                  </div>
                </div>
                <p className="mb-2 text-xs leading-relaxed text-white/80">{def.desc}</p>
                {moving ? (
                  <div className="text-xs text-amber-300">Toque no espaço de destino...</div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {def.kind === "food" && (
                      <button onClick={() => game.useSlot(picked!)} className="pixel-btn bg-emerald-600 px-3 py-1.5 text-xs">Usar</button>
                    )}
                    {def.kind === "weapon" && (
                      <button
                        onClick={() => { if (picked! < HOT) game.selectSlot(picked!, false); else game.useSlot(picked!); setPicked(null); }}
                        className="pixel-btn bg-fuchsia-600 px-3 py-1.5 text-xs"
                      >
                        Equipar
                      </button>
                    )}
                    <button onClick={() => setMoving(true)} className="pixel-btn bg-sky-700 px-3 py-1.5 text-xs">Mover</button>
                    <button onClick={() => { game.dropSlot(picked!); setPicked(null); }} className="pixel-btn bg-slate-600 px-3 py-1.5 text-xs">Descartar</button>
                  </div>
                )}
              </>
            ) : (
              <p className="text-xs leading-relaxed text-white/60">
                Toque em um item para ver detalhes. Use <b className="text-white">Mover</b> para trocar itens entre a mochila e a barra rápida.
                Derrote zumbis para conseguir materiais e comida.
              </p>
            )}
          </div>

          <div className="rounded bg-black/30 p-3">
            <div className="mb-2 text-[11px] uppercase tracking-wider text-white/60">Criação</div>
            <div className="flex items-center gap-2">
              <img src={iconURL("atadura")} alt="" className="h-9 w-9" style={{ imageRendering: "pixelated" }} />
              <div className="flex-1 text-xs">
                <div className="text-amber-200">Atadura</div>
                <div className="flex items-center gap-1 text-white/60">
                  2× <img src={iconURL("pano")} alt="" className="h-4 w-4" style={{ imageRendering: "pixelated" }} /> Pano Velho ({panos}/2)
                </div>
              </div>
              <button
                disabled={panos < 2}
                onClick={() => game.craftBandage()}
                className="pixel-btn bg-amber-600 px-3 py-1.5 text-xs disabled:opacity-40"
              >
                Criar
              </button>
            </div>
          </div>
          <div className="text-[10px] leading-relaxed text-white/50">
            ⌨️ 1–8 selecionar · Q usar item · F / clique atacar · I inventário
          </div>
        </div>
      </div>
    </div>
  );
}
