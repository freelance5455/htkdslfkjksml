import React, { useState, useEffect, useRef } from 'react';
import { Post, Comment, UserProfile } from '../types';
import { 
  db, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  query, 
  orderBy, 
  limit, 
  doc, 
  updateDoc, 
  deleteDoc,
  increment,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { compressImageFile } from '../imageUtils';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Send, 
  Sparkles, 
  Check, 
  Plus, 
  X, 
  Trash2,
  Camera,
  Image as ImageIcon,
  Loader2
} from 'lucide-react';

interface PostsViewProps {
  currentUser: UserProfile;
}

// Subcomponent for each Post's real comments
const PostCommentsSection: React.FC<{
  postId: string;
  currentUser: UserProfile;
  onCommentAdded: () => void;
  onCommentDeleted: () => void;
}> = ({ postId, currentUser, onCommentAdded, onCommentDeleted }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Real-time listener for comments of this post
  useEffect(() => {
    const commentsRef = collection(db, 'posts', postId, 'comments');
    const q = query(commentsRef, orderBy('createdAt', 'asc'));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: Comment[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, postId, ...docSnap.data() } as Comment);
      });
      setComments(list);
      setLoading(false);
    }, (err) => {
      console.warn('Error loading comments:', err);
      setLoading(false);
    });

    return () => unsub();
  }, [postId]);

  // Add real comment to Firestore
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || submitting) return;

    setSubmitting(true);
    const commentData: Omit<Comment, 'id'> = {
      postId,
      authorId: currentUser.uid,
      authorName: currentUser.displayName,
      authorAvatar: currentUser.photoURL || '',
      content: newCommentText.trim(),
      createdAt: new Date().toISOString()
    };

    try {
      const commentsCol = collection(db, 'posts', postId, 'comments');
      await addDoc(commentsCol, commentData);

      // Increment commentsCount on the post
      const postRef = doc(db, 'posts', postId);
      await updateDoc(postRef, {
        commentsCount: increment(1)
      });

      setNewCommentText('');
      onCommentAdded();
    } catch (err) {
      console.error('Failed to add comment:', err);
      // Fallback local addition if offline
      setComments((prev) => [
        ...prev,
        { id: `c_${Date.now()}`, ...commentData }
      ]);
      setNewCommentText('');
    } finally {
      setSubmitting(false);
    }
  };

  // Delete comment from Firestore (مسح التعليق)
  const handleDeleteComment = async (commentId: string) => {
    try {
      const commentRef = doc(db, 'posts', postId, 'comments', commentId);
      await deleteDoc(commentRef);

      // Decrement commentsCount on the post
      const postRef = doc(db, 'posts', postId);
      await updateDoc(postRef, {
        commentsCount: increment(-1)
      });

      setComments((prev) => prev.filter((c) => c.id !== commentId));
      onCommentDeleted();
    } catch (err) {
      console.error('Failed to delete comment:', err);
      setComments((prev) => prev.filter((c) => c.id !== commentId));
    }
  };

  return (
    <div className="mt-3 pt-3 border-t border-pink-100 space-y-3 animate-in fade-in">
      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold px-1">
        <span>التعليقات ({comments.length})</span>
      </div>

      {/* Real Comments List */}
      <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
        {loading ? (
          <div className="py-3 flex justify-center items-center text-xs text-slate-400 gap-1.5">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-pink-500" />
            <span>جاري تحميل التعليقات...</span>
          </div>
        ) : comments.length === 0 ? (
          <p className="text-center py-2 text-[11px] text-slate-400">
            لا توجد تعليقات بعد، كن أول من يعلق! 🌸
          </p>
        ) : (
          comments.map((comment) => {
            const isMyComment = comment.authorId === currentUser.uid;
            return (
              <div 
                key={comment.id}
                className="flex items-start justify-between gap-2 p-2 rounded-2xl bg-pink-50/50 border border-pink-100/60"
              >
                <div className="flex items-start gap-2 flex-1">
                  <img
                    src={comment.authorAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${comment.authorId}`}
                    alt={comment.authorName}
                    className="w-6 h-6 rounded-full object-cover border border-pink-200 shrink-0 mt-0.5"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-900">
                        {comment.authorName}
                      </span>
                      <span className="text-[9px] text-slate-400">
                        {new Date(comment.createdAt).toLocaleTimeString('ar-EG', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 mt-0.5 whitespace-pre-line font-['Cairo']">
                      {comment.content}
                    </p>
                  </div>
                </div>

                {/* Delete comment button (مسح التعليق) */}
                {isMyComment && (
                  <button
                    onClick={() => handleDeleteComment(comment.id)}
                    className="p-1 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors cursor-pointer shrink-0"
                    title="مسح التعليق"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Comment Input Box */}
      <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-1">
        <input
          type="text"
          value={newCommentText}
          onChange={(e) => setNewCommentText(e.target.value)}
          placeholder="اكتب تعليقك هنا..."
          className="flex-1 bg-white border border-pink-200 focus:border-pink-500 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none shadow-sm"
        />
        <button
          type="submit"
          disabled={!newCommentText.trim() || submitting}
          className="w-8 h-8 rounded-xl bg-pink-600 hover:bg-pink-700 disabled:opacity-40 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer shadow-sm shrink-0"
          title="إرسال التعليق"
        >
          {submitting ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Send className="w-3.5 h-3.5" />
          )}
        </button>
      </form>
    </div>
  );
};

export const PostsView: React.FC<PostsViewProps> = ({ currentUser }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedStudioImage, setSelectedStudioImage] = useState<string | null>(null);
  const [postCaption, setPostCaption] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [activeCommentsPostId, setActiveCommentsPostId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Hidden real file picker input connecting directly to phone gallery / studio
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Sync 100% REAL posts only from Firestore (No fake posts)
  useEffect(() => {
    const postsCol = collection(db, 'posts');
    const q = query(postsCol, orderBy('createdAt', 'desc'), limit(50));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: Post[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Post);
      });
      setPosts(list);
    }, (error) => {
      console.error('Error loading posts:', error);
      showToast('تعذر تحميل المنشورات، تحقق من اتصالك');
    });

    return () => unsub();
  }, []);

  // Open device studio / gallery directly
  const handleOpenStudio = () => {
    if (galleryInputRef.current) {
      galleryInputRef.current.value = '';
      galleryInputRef.current.click();
    }
  };

  // When user selects a photo from the studio/gallery
  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 900, 0.75);
      setSelectedStudioImage(compressed);
      setShowUploadModal(true);
    } catch (err) {
      console.error('Image processing failed:', err);
      showToast('تعذر معالجة الصورة، اختر صورة أخرى');
    }
  };

  // Publish real post with studio photo to Firestore
  const handlePublishPost = async () => {
    if (!selectedStudioImage && !postCaption.trim()) return;

    setIsSubmitting(true);
    const newPostData: Omit<Post, 'id'> = {
      authorId: currentUser.uid,
      authorName: currentUser.displayName,
      authorAvatar: currentUser.photoURL || '',
      authorBadge: currentUser.badge || 'عضو مميز 🌸',
      content: postCaption.trim(),
      mediaUrl: selectedStudioImage || undefined,
      likesCount: 0,
      commentsCount: 0,
      createdAt: new Date().toISOString()
    };

    try {
      await addDoc(collection(db, 'posts'), newPostData);
      showToast('تم نشر المنشور بنجاح 🌸');
      setSelectedStudioImage(null);
      setPostCaption('');
      setShowUploadModal(false);
      if (galleryInputRef.current) {
        galleryInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Publish failed:', err);
      showToast('تعذر نشر المنشور، حاول مرة أخرى');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Real Delete Post (مسح المنشور بالكامل)
  const handleDeletePost = async (postId: string) => {
    try {
      await deleteDoc(doc(db, 'posts', postId));
      showToast('تم مسح المنشور بنجاح ✓');
    } catch (err) {
      console.error('Delete failed:', err);
      showToast('تعذر مسح المنشور');
    }
  };

  // Like toggle: stored per user in Firestore (likedBy), so it survives reloads
  const handleLike = async (postId: string) => {
    const post = posts.find((p) => p.id === postId);
    if (!post) return;
    const isAlreadyLiked = (post.likedBy || []).includes(currentUser.uid);
    try {
      await updateDoc(doc(db, 'posts', postId), {
        likedBy: isAlreadyLiked ? arrayRemove(currentUser.uid) : arrayUnion(currentUser.uid),
        likesCount: increment(isAlreadyLiked ? -1 : 1)
      });
    } catch (err) {
      console.error('Like failed:', err);
      showToast('تعذر تسجيل الإعجاب');
    }
  };

  return (
    <div className="space-y-4 pb-28 max-w-xl mx-auto select-none px-3 sm:px-0">
      
      {/* Hidden real file input connected directly to device gallery/studio */}
      <input
        type="file"
        ref={galleryInputRef}
        onChange={handleImageSelect}
        accept="image/*"
        className="hidden"
      />

      {/* Floating toast notification */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full bg-slate-900/90 text-white font-bold text-xs shadow-2xl backdrop-blur-md flex items-center gap-2 border border-pink-500/30 animate-in fade-in slide-in-from-top-2">
          <Sparkles className="w-4 h-4 text-pink-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Card: Title on right, and Small Circular Plus Button on left (No Text inside button) */}
      <div className="rounded-3xl bg-white border border-pink-100/90 p-4 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900 font-['Cairo']">
            المنشورات
          </h2>
          <p className="text-[11px] text-slate-500 font-medium mt-0.5">
            شارك لحظاتك وصورك مع الأصدقاء
          </p>
        </div>

        {/* Small circular Plus (+) button without any text - Opens studio directly */}
        <button
          type="button"
          onClick={handleOpenStudio}
          className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-600 to-rose-500 hover:from-pink-700 hover:to-rose-600 active:scale-90 text-white flex items-center justify-center shadow-lg shadow-pink-500/25 transition-all cursor-pointer group"
          title="فتح الاستوديو لاختيار صورة"
        >
          <Plus className="w-5 h-5 stroke-[2.8] group-hover:rotate-90 transition-transform" />
        </button>
      </div>

      {/* ========================================================
          MODAL: STUDIO PHOTO PREVIEW & PUBLISH
      ======================================================== */}
      {showUploadModal && selectedStudioImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-white border border-pink-100 shadow-2xl overflow-hidden flex flex-col">
            
            {/* Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2 text-pink-600">
                <ImageIcon className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-sm font-['Cairo']">
                  الصورة المختارة من الاستوديو
                </h3>
              </div>
              <button
                onClick={() => {
                  setShowUploadModal(false);
                  setSelectedStudioImage(null);
                }}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 space-y-3">
              {/* Image Preview */}
              <div className="relative rounded-2xl overflow-hidden border-2 border-pink-200 max-h-72 bg-slate-900 flex items-center justify-center">
                <img
                  src={selectedStudioImage}
                  alt="الصورة من الاستوديو"
                  className="w-full max-h-72 object-contain"
                />
              </div>

              {/* Optional Caption */}
              <div>
                <textarea
                  rows={2}
                  value={postCaption}
                  onChange={(e) => setPostCaption(e.target.value)}
                  placeholder="اكتب تعليقاً أو وصفاً لصورتك (اختياري)..."
                  className="w-full bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl p-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none resize-none font-['Cairo']"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowUploadModal(false);
                    setSelectedStudioImage(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handlePublishPost}
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer flex items-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>جاري النشر...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>نشر الآن</span>
                    </>
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 100% Real Posts Feed */}
      {posts.length === 0 ? (
        <div className="p-10 rounded-3xl bg-white border border-pink-100/80 text-center flex flex-col items-center justify-center shadow-sm">
          {/* Small circular Plus Button */}
          <button
            type="button"
            onClick={handleOpenStudio}
            className="w-12 h-12 rounded-full bg-pink-50 hover:bg-pink-100 text-pink-600 flex items-center justify-center cursor-pointer transition-transform hover:scale-110 mb-3 shadow-inner border border-pink-200/80"
            title="فتح الاستوديو"
          >
            <Plus className="w-6 h-6 stroke-[2.8]" />
          </button>
          <p className="text-sm font-bold text-slate-800 font-['Cairo']">
            لا توجد منشورات حتى الآن
          </p>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            اضغط على علامة الزائد (+) أعلاه لاختيار صورة حقيقية من استوديو هاتفك ومشاركتها فوراً
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => {
            const isLiked = (post.likedBy || []).includes(currentUser.uid);
            const isMyPost = post.authorId === currentUser.uid;
            const isCommentsOpen = activeCommentsPostId === post.id;

            return (
              <div
                key={post.id}
                className="rounded-3xl bg-white border border-pink-100/90 p-4 sm:p-5 shadow-sm hover:border-pink-200 transition-all"
              >
                {/* Post Author Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.authorAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${post.authorId}`}
                      alt={post.authorName}
                      className="w-10 h-10 rounded-full object-cover border border-pink-200"
                    />
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                        {post.authorName}
                      </h4>
                      <span className="text-[10px] text-slate-400">
                        {new Date(post.createdAt).toLocaleDateString('ar-EG', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                  </div>

                  {/* Real Delete Post Button (مسح المنشور) */}
                  {isMyPost && (
                    <button
                      onClick={() => handleDeletePost(post.id)}
                      className="p-2 text-slate-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition-colors cursor-pointer"
                      title="مسح المنشور"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Post Content / Caption */}
                {post.content && (
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line mb-3 font-['Cairo']">
                    {post.content}
                  </p>
                )}

                {/* Real Photo from Studio */}
                {post.mediaUrl && (
                  <div className="mb-3 overflow-hidden rounded-2xl border border-pink-100 bg-slate-900 max-h-[450px] flex items-center justify-center">
                    <img
                      src={post.mediaUrl}
                      alt="صورة المنشور"
                      className="w-full max-h-[450px] object-cover"
                    />
                  </div>
                )}

                {/* Interaction Actions Bar */}
                <div className="flex items-center justify-between pt-2.5 border-t border-slate-100 text-xs text-slate-500">
                  {/* Like Button */}
                  <button
                    onClick={() => handleLike(post.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                      isLiked
                        ? 'text-pink-600 bg-pink-50 font-bold'
                        : 'hover:text-pink-600 hover:bg-slate-50'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-pink-600 text-pink-600' : ''}`} />
                    <span>{post.likesCount}</span>
                  </button>

                  {/* Comment Button (Toggles Real Comments Drawer) */}
                  <button
                    onClick={() => setActiveCommentsPostId(isCommentsOpen ? null : post.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                      isCommentsOpen
                        ? 'text-purple-700 bg-purple-50 font-bold'
                        : 'hover:text-purple-600 hover:bg-slate-50'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4 text-purple-600" />
                    <span>التعليقات ({post.commentsCount || 0})</span>
                  </button>

                  {/* Share button */}
                  <button
                    onClick={() => {
                      if (navigator.clipboard) {
                        navigator.clipboard.writeText(window.location.href);
                        showToast('تم نسخ رابط المنشور بنجاح ✓');
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-amber-600 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-amber-500" />
                    <span>مشاركة</span>
                  </button>
                </div>

                {/* REAL Comments Section with Real Delete (التعليقات ومسح) */}
                {isCommentsOpen && (
                  <PostCommentsSection
                    postId={post.id}
                    currentUser={currentUser}
                    onCommentAdded={() => {
                      setPosts((prev) =>
                        prev.map((p) =>
                          p.id === post.id
                            ? { ...p, commentsCount: (p.commentsCount || 0) + 1 }
                            : p
                        )
                      );
                    }}
                    onCommentDeleted={() => {
                      setPosts((prev) =>
                        prev.map((p) =>
                          p.id === post.id
                            ? { ...p, commentsCount: Math.max(0, (p.commentsCount || 0) - 1) }
                            : p
                        )
                      );
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
