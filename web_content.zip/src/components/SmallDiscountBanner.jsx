import React, { useState, useEffect } from 'react';
import { getCurrentLang, t } from '../lib/i18n';

export default function SmallDiscountBanner({ onNavigate }) {
  const [dismissed, setDismissed] = useState(() => {
    try {
      return sessionStorage.getItem('calsen_banner_dismissed') === 'true';
    } catch (e) {
      return false;
    }
  });
  const [lang, setLang] = useState(() => getCurrentLang());

  useEffect(() => {
    const handler = (e) => setLang(e.detail || getCurrentLang());
    window.addEventListener('calsen-lang-change', handler);
    return () => window.removeEventListener('calsen-lang-change', handler);
  }, []);

  if (dismissed) return null;

  const isAr = lang === 'العربية';

  const handleDismiss = (e) => {
    e.stopPropagation();
    try {
      sessionStorage.setItem('calsen_banner_dismissed', 'true');
    } catch (err) {}
    setDismissed(true);
  };

  const handleClaim = () => {
    if (onNavigate) {
      onNavigate('paywall');
    }
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed bottom-[82px] left-3 right-3 sm:left-auto sm:right-auto sm:w-[420px] sm:left-1/2 sm:-translate-x-1/2 z-40"
      style={{
        pointerEvents: 'auto',
        animation: 'rise .35s ease-out backwards',
      }}
    >
      <div
        onClick={handleClaim}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') handleClaim();
        }}
        className="group relative flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-2xl bg-[#170E10]/95 hover:bg-[#201417]/95 border border-[#FF6A1A]/40 shadow-[0_8px_25px_rgba(255,106,26,0.22)] backdrop-blur-xl transition-all cursor-pointer"
      >
        {/* Glow accent */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-[#FF6A1A]/10 via-[#F2570F]/5 to-transparent pointer-events-none" />

        {/* Left: Flame / Badge & Offer text */}
        <div className="relative flex items-center gap-2.5 min-w-0">
          <div className="flex-none flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-br from-[#FF7A24] to-[#F2570F] text-white shadow-[0_2px_8px_rgba(242,87,15,0.4)]">
            <span className="text-sm">🔥</span>
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-[#FF6A1A]/20 text-[#FF9248] border border-[#FF6A1A]/30">
                {isAr ? 'خصم 80%' : '80% OFF'}
              </span>
              <span className="text-[12px] font-extrabold text-white truncate">
                {isAr ? 'عرض حصري لفترة محدودة' : 'Limited Time Offer'}
              </span>
            </div>
            <span className="text-[11px] font-medium text-white/60 truncate mt-0.5">
              {isAr ? 'كالسن برو بـ 1.66$ شهرياً فقط' : 'CalSen Pro for just $1.66/month'}
            </span>
          </div>
        </div>

        {/* Right: CTA & Dismiss */}
        <div className="relative flex items-center gap-1.5 flex-none">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleClaim();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#FF7A24] to-[#F2570F] text-white text-[11.5px] font-bold shadow-[0_4px_12px_rgba(242,87,15,0.35)] hover:brightness-110 active:scale-95 transition-all cursor-pointer"
          >
            <span>{isAr ? 'احصل عليه' : 'Claim'}</span>
            <svg
              className={`w-3 h-3 ${isAr ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5l7 7-7 7" />
            </svg>
          </button>

          <button
            onClick={handleDismiss}
            aria-label={isAr ? 'إغلاق الإشعار' : 'Close offer'}
            className="w-7 h-7 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors cursor-pointer"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
