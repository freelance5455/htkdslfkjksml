import { useEffect, useRef, useState, type ReactNode } from "react";
import { Settings } from "lucide-react";
import { BASE_MAX, BASE_MIN, fromBase, toBase } from "@/lib/radix";

const STORAGE_KEY = "radix-counter-v2";
const LEGACY_KEY = "radix-counter-v1";
const DEFAULT_COLOR = "#fffdf8";

type Item = {
  id: string;
  name: string;
  value: number;
  base: number;
  step: number;
  color: string;
};

function seedItems(): Item[] {
  return ["A", "B", "C", "D", "E"].map((name, index) => ({
    id: `seed-${index}`,
    name,
    value: 0,
    base: 6,
    step: 1,
    color: DEFAULT_COLOR,
  }));
}

function nextName(items: Item[]): string {
  const used = new Set(items.map((item) => item.name));
  for (let i = 0; i < 26; i += 1) {
    const letter = String.fromCharCode(65 + i);
    if (!used.has(letter)) return letter;
  }
  let n = 1;
  while (used.has(`对象${n}`)) n += 1;
  return `对象${n}`;
}

function cleanColor(value: unknown): string {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value : DEFAULT_COLOR;
}

function cleanItem(row: Partial<Item>, fallbackBase: number): Item | null {
  if (typeof row.id !== "string" || typeof row.name !== "string") return null;
  if (typeof row.value !== "number" || !Number.isFinite(row.value)) return null;
  const name = row.name.trim().slice(0, 16);
  if (!name) return null;
  const base = Number.isInteger(row.base) ? (row.base as number) : fallbackBase;
  if (base < BASE_MIN || base > BASE_MAX) return null;
  const step = Number.isInteger(row.step) && (row.step as number) >= 1 ? (row.step as number) : 1;
  return {
    id: row.id,
    name,
    value: Math.trunc(row.value),
    base,
    step,
    color: cleanColor(row.color),
  };
}

function readItems(): Item[] | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) ?? localStorage.getItem(LEGACY_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as { base?: number; items?: Partial<Item>[] };
    if (!Array.isArray(data.items)) return null;
    const fallback = Number.isInteger(data.base) ? (data.base as number) : 6;
    const items = data.items.flatMap((item) => {
      const row = cleanItem(item ?? {}, fallback);
      return row ? [row] : [];
    });
    return items;
  } catch {
    return null;
  }
}

function textOn(color: string): string {
  const hex = color.slice(1);
  const r = Number.parseInt(hex.slice(0, 2), 16);
  const g = Number.parseInt(hex.slice(2, 4), 16);
  const b = Number.parseInt(hex.slice(4, 6), 16);
  return r * 299 + g * 587 + b * 114 > 150000 ? "#211c16" : "#fff7f3";
}

export function RadixCounter() {
  const [items, setItems] = useState<Item[]>(seedItems);
  const [hydrated, setHydrated] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    const saved = readItems();
    if (saved) setItems(saved);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ items }));
  }, [items, hydrated]);

  const editing = items.find((item) => item.id === editingId) ?? null;

  function stepItem(id: string, direction: number) {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, value: item.value + direction * item.step } : item,
      ),
    );
  }

  function addItem() {
    const name = draftName.trim().slice(0, 16) || nextName(items);
    setItems((prev) => [
      ...prev,
      { id: crypto.randomUUID(), name, value: 0, base: 6, step: 1, color: DEFAULT_COLOR },
    ]);
    setDraftName("");
  }

  return (
    <main className="mx-auto min-h-screen w-full max-w-lg px-4 py-6">
      <a
        href="/radix-counter.html"
        download="index.html"
        className="mb-4 inline-block text-xl font-semibold text-save underline"
      >
        下载 index.html
      </a>
      <h1 className="mb-6 text-2xl font-semibold tracking-tight">进制计数器</h1>

      <ul className="flex flex-col gap-2">
        {items.map((item) => (
          <li key={item.id}>
            <CounterRow
              item={item}
              onStep={(direction) => stepItem(item.id, direction)}
              onOpen={() => setEditingId(item.id)}
            />
          </li>
        ))}
      </ul>

      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          addItem();
        }}
      >
        <input
          value={draftName}
          onChange={(event) => setDraftName(event.target.value.slice(0, 16))}
          placeholder="新对象"
          aria-label="新对象名称"
          className="h-12 min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 outline-none placeholder:text-muted focus:border-accent"
        />
        <button type="submit" className="h-12 shrink-0 rounded-xl bg-ink px-4 font-medium text-surface">
          添加
        </button>
      </form>

      {editing ? (
        <ItemSettings
          item={editing}
          onClose={() => setEditingId(null)}
          onSave={(next) => {
            setItems((prev) => prev.map((item) => (item.id === editing.id ? { ...item, ...next } : item)));
            setEditingId(null);
          }}
          onDelete={() => {
            setItems((prev) => prev.filter((item) => item.id !== editing.id));
            setEditingId(null);
          }}
        />
      ) : null}
    </main>
  );
}

function CounterRow({
  item,
  onStep,
  onOpen,
}: {
  item: Item;
  onStep: (direction: number) => void;
  onOpen: () => void;
}) {
  const written = toBase(item.value, item.base);
  const ink = textOn(item.color);

  return (
    <article
      className="flex items-center gap-2 rounded-card border border-line px-3 py-2"
      style={{ backgroundColor: item.color, color: ink }}
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-lg font-semibold">{item.name}</p>
        <p className="text-xs opacity-70">{item.base}进制</p>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        <StepButton label={`${item.name} 减 ${item.step}`} onStep={() => onStep(-1)}>
          −
        </StepButton>
        <span key={written} className="digit-in inline-block min-w-8 text-center font-mono text-2xl tabular-nums">
          {written}
        </span>
        <StepButton label={`${item.name} 加 ${item.step}`} onStep={() => onStep(1)} tone="accent">
          +
        </StepButton>
        <button
          type="button"
          aria-label={`${item.name} 设置`}
          onClick={onOpen}
          className="inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink"
        >
          <Settings className="size-5" />
        </button>
      </div>
    </article>
  );
}

function ItemSettings({
  item,
  onClose,
  onSave,
  onDelete,
}: {
  item: Item;
  onClose: () => void;
  onSave: (next: Pick<Item, "name" | "base" | "color" | "value" | "step">) => void;
  onDelete: () => void;
}) {
  const [name, setName] = useState(item.name);
  const [base, setBase] = useState(String(item.base));
  const [color, setColor] = useState(item.color);
  const [initial, setInitial] = useState(toBase(item.value, item.base));
  const [step, setStep] = useState(String(item.step));
  const [error, setError] = useState("");

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  function save() {
    const radix = Number(base);
    if (!Number.isInteger(radix) || radix < BASE_MIN || radix > BASE_MAX) {
      setError(`进制请填 ${BASE_MIN} 到 ${BASE_MAX} 的整数`);
      return;
    }
    const value = fromBase(initial, radix);
    if (value === null) {
      setError("初始数值里有这个进制用不了的数码");
      return;
    }
    const inc = Number(step);
    if (!Number.isInteger(inc) || inc < 1) {
      setError("增量请填大于 0 的整数");
      return;
    }
    onSave({
      name: name.trim().slice(0, 16) || "未命名",
      base: radix,
      color: cleanColor(color),
      value,
      step: inc,
    });
  }

  return (
    <div className="fixed inset-0 z-20 flex items-end justify-center bg-ink/40 p-4 sm:items-center" onClick={onClose}>
      <form
        role="dialog"
        aria-modal="true"
        aria-label={`${item.name} 设置`}
        className="w-full max-w-md rounded-card bg-surface-2 p-5 shadow-sm"
        onClick={(event) => event.stopPropagation()}
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
      >
        <h2 className="text-lg font-semibold">设置</h2>
        <div className="mt-4 flex flex-col gap-3">
          <Field label="名称">
            <input
              value={name}
              aria-label="名称"
              onChange={(event) => setName(event.target.value.slice(0, 16))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-accent"
            />
          </Field>
          <Field label="进制">
            <input
              inputMode="numeric"
              aria-label="进制"
              value={base}
              onChange={(event) => setBase(event.target.value.replace(/[^\d]/g, "").slice(0, 2))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
            />
          </Field>
          <Field label="颜色">
            <input
              type="color"
              aria-label="颜色"
              value={color}
              onChange={(event) => setColor(event.target.value)}
              className="h-12 w-full cursor-pointer rounded-xl border border-line bg-surface"
            />
          </Field>
          <Field label="初始数值">
            <input
              aria-label="初始数值"
              value={initial}
              onChange={(event) => setInitial(event.target.value.toUpperCase().slice(0, 16))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
            />
          </Field>
          <Field label="增量">
            <input
              inputMode="numeric"
              aria-label="增量"
              value={step}
              onChange={(event) => setStep(event.target.value.replace(/[^\d]/g, "").slice(0, 6))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
            />
          </Field>
        </div>
        {error ? <p className="mt-3 text-sm text-accent">{error}</p> : null}
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="submit" className="h-12 rounded-xl bg-ink font-medium text-surface">
            保存
          </button>
          <button type="button" onClick={onDelete} className="h-12 rounded-xl border border-line font-medium">
            删除
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm text-muted">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function StepButton({
  label,
  onStep,
  children,
  tone = "ghost",
}: {
  label: string;
  onStep: () => void;
  children: ReactNode;
  tone?: "ghost" | "accent";
}) {
  const onStepRef = useRef(onStep);
  onStepRef.current = onStep;
  const delayRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const repeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  function stop() {
    if (delayRef.current) clearTimeout(delayRef.current);
    if (repeatRef.current) clearInterval(repeatRef.current);
    delayRef.current = null;
    repeatRef.current = null;
  }

  useEffect(() => stop, []);

  const toneClass =
    tone === "accent" ? "bg-accent text-accent-ink" : "border border-line bg-surface text-ink";

  return (
    <button
      type="button"
      aria-label={label}
      className={`inline-flex size-11 select-none items-center justify-center rounded-xl text-2xl leading-none touch-manipulation ${toneClass}`}
      onContextMenu={(event) => event.preventDefault()}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        onStepRef.current();
        try {
          event.currentTarget.setPointerCapture(event.pointerId);
        } catch {
          /* pointer capture is optional */
        }
        stop();
        delayRef.current = setTimeout(() => {
          repeatRef.current = setInterval(() => onStepRef.current(), 70);
        }, 360);
      }}
      onPointerUp={stop}
      onPointerCancel={stop}
    >
      {children}
    </button>
  );
}
