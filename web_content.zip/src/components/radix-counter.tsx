import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { Check, ChevronLeft, EllipsisVertical, Pencil, Plus } from "lucide-react";
import { stepSipBy } from "@/lib/drink";

const STORAGE_KEY = "drink-counter-v1";
const LEGACY_KEYS = ["radix-counter-v2", "radix-counter-v1"];
const DEFAULT_COLOR = "#fffdf8";
const SIP_MIN = 1;
const SIP_MAX = 99;

type Item = {
  id: string;
  name: string;
  sips: number;
  position: number;
  cups: number;
  credited: boolean;
  step: number;
  color: string;
};

type ThemeId = "system" | "light" | "dark";
type PaletteId = "paper" | "wine" | "sea" | "forest" | "dusk" | "sand" | "slate" | "ink";
type Page = "home" | "settings" | "about" | "order";
type Picker = "theme" | "palette" | null;

const THEMES: { id: ThemeId; label: string }[] = [
  { id: "system", label: "系统默认" },
  { id: "light", label: "浅色模式" },
  { id: "dark", label: "深色模式" },
];

const PALETTES: { id: PaletteId; label: string }[] = [
  { id: "paper", label: "暖纸" },
  { id: "wine", label: "酒红" },
  { id: "sea", label: "海蓝" },
  { id: "forest", label: "森绿" },
  { id: "dusk", label: "暮紫" },
  { id: "sand", label: "沙金" },
  { id: "slate", label: "雾灰" },
  { id: "ink", label: "松烟" },
];

type Prefs = { theme: ThemeId; palette: PaletteId };

function seedItems(): Item[] {
  return ["A", "B", "C", "D", "E"].map((name, index) => ({
    id: `seed-${index}`,
    name,
    sips: 6,
    position: 0,
    cups: 0,
    credited: false,
    step: 1,
    color: DEFAULT_COLOR,
  }));
}

function nextName(items: Item[]): string {
  const used = new Set(items.map((item) => item.name));
  for (let i = 0; i < 26; i += 1) {
    const letter = String.fromCharCode(65 + i);
    if (!used.has(letter)) return letter;
  }
  let n = 1;
  while (used.has(`对象${n}`)) n += 1;
  return `对象${n}`;
}

function cleanColor(value: unknown): string {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value.toLowerCase() : DEFAULT_COLOR;
}

function cleanItem(row: Partial<Item> & { base?: number; value?: number }, fallbackSips: number): Item | null {
  if (typeof row.id !== "string" || typeof row.name !== "string") return null;
  const name = row.name.trim().slice(0, 16);
  if (!name) return null;
  const rawSips = Number.isInteger(row.sips) ? row.sips : Number.isInteger(row.base) ? row.base : fallbackSips;
  const sips = Math.min(SIP_MAX, Math.max(SIP_MIN, rawSips ?? 6));
  const step = Number.isInteger(row.step) && (row.step as number) >= 1 ? Math.min(100, row.step as number) : 1;
  const position = Number.isInteger(row.position)
    ? Math.min(sips, Math.max(0, row.position as number))
    : 0;
  const cups = Number.isInteger(row.cups) && (row.cups as number) >= 0 ? (row.cups as number) : 0;
  const credited = typeof row.credited === "boolean" ? row.credited : position === sips && position > 0;
  return { id: row.id, name, sips, position, cups, credited, step, color: cleanColor(row.color) };
}

function readSaved(): { items: Item[]; prefs: Prefs } | null {
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    if (current) {
      const data = JSON.parse(current) as { items?: unknown[]; theme?: string; palette?: string };
      if (!Array.isArray(data.items)) return null;
      return {
        items: data.items.flatMap((item) => {
          const row = cleanItem((item ?? {}) as Partial<Item>, 6);
          return row ? [row] : [];
        }),
        prefs: {
          theme: THEMES.some((theme) => theme.id === data.theme) ? (data.theme as ThemeId) : "system",
          palette: PALETTES.some((palette) => palette.id === data.palette) ? (data.palette as PaletteId) : "paper",
        },
      };
    }
    for (const key of LEGACY_KEYS) {
      const legacy = localStorage.getItem(key);
      if (!legacy) continue;
      const data = JSON.parse(legacy) as { base?: number; items?: Partial<Item>[] };
      if (!Array.isArray(data.items)) continue;
      const fallback = Number.isInteger(data.base) ? (data.base as number) : 6;
      return {
        items: data.items.flatMap((item) => {
          const row = cleanItem(item ?? {}, fallback);
          return row ? [row] : [];
        }),
        prefs: { theme: "system", palette: "paper" },
      };
    }
    return null;
  } catch {
    return null;
  }
}

function textOn(color: string): string {
  const hex = color.slice(1);
  const y =
    Number.parseInt(hex.slice(0, 2), 16) * 299 +
    Number.parseInt(hex.slice(2, 4), 16) * 587 +
    Number.parseInt(hex.slice(4, 6), 16) * 114;
  return y > 150000 ? "#211c16" : "#fff7f3";
}

function blankItem(items: Item[]): Item {
  return {
    id: crypto.randomUUID(),
    name: nextName(items),
    sips: 6,
    position: 0,
    cups: 0,
    credited: false,
    step: 1,
    color: DEFAULT_COLOR,
  };
}

export function RadixCounter() {
  const [items, setItems] = useState<Item[]>(seedItems);
  const [prefs, setPrefs] = useState<Prefs>({ theme: "system", palette: "paper" });
  const [hydrated, setHydrated] = useState(false);
  const [page, setPage] = useState<Page>("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const [picker, setPicker] = useState<Picker>(null);
  const [editing, setEditing] = useState<{ item: Item; creating: boolean } | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);

  useEffect(() => {
    const saved = readSaved();
    if (saved) {
      if (saved.items.length) setItems(saved.items);
      setPrefs(saved.prefs);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ items, theme: prefs.theme, palette: prefs.palette }));
  }, [items, prefs, hydrated]);

  useEffect(() => {
    document.documentElement.dataset.theme = prefs.theme;
    document.documentElement.dataset.palette = prefs.palette;
  }, [prefs]);

  function stepItem(id: string, direction: 1 | -1) {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const next = stepSipBy(
          { position: item.position, cups: item.cups, sips: item.sips, credited: item.credited },
          direction,
          item.step,
        );
        return { ...item, position: next.position, cups: next.cups, credited: next.credited };
      }),
    );
  }

  function moveItem(index: number, delta: number) {
    setItems((prev) => {
      const to = index + delta;
      if (to < 0 || to >= prev.length) return prev;
      const next = prev.slice();
      const [row] = next.splice(index, 1);
      next.splice(to, 0, row);
      return next;
    });
  }

  function beginReorder(event: ReactPointerEvent<HTMLElement>, id: string) {
    if ((event.target as HTMLElement).closest("button, a, input")) return;
    const pointerId = event.pointerId;
    const startY = event.clientY;
    let active = false;
    const timer = window.setTimeout(() => {
      active = true;
      setDragId(id);
    }, 420);

    const finish = () => {
      window.clearTimeout(timer);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      if (active) setDragId(null);
    };

    const move = (e: PointerEvent) => {
      if (e.pointerId !== pointerId) return;
      if (!active) {
        if (Math.abs(e.clientY - startY) > 8) finish();
        return;
      }
      e.preventDefault();
      const nodes = [...document.querySelectorAll<HTMLElement>("[data-row-id]")].filter(
        (node) => node.dataset.rowId !== id,
      );
      let to = 0;
      for (const node of nodes) {
        const rect = node.getBoundingClientRect();
        if (e.clientY > rect.top + rect.height / 2) to += 1;
      }
      setItems((prev) => {
        const from = prev.findIndex((item) => item.id === id);
        if (from < 0 || from === to) return prev;
        const next = prev.slice();
        const [row] = next.splice(from, 1);
        next.splice(to, 0, row);
        return next;
      });
    };

    const up = (e: PointerEvent) => {
      if (e.pointerId !== pointerId) return;
      finish();
    };

    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  const themeLabel = THEMES.find((theme) => theme.id === prefs.theme)?.label ?? "系统默认";
  const paletteLabel = PALETTES.find((palette) => palette.id === prefs.palette)?.label ?? "暖纸";

  return (
    <div className={page === "home" ? "flex h-dvh flex-col" : "min-h-screen"}>
      <header className="sticky top-0 z-30 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex w-full max-w-lg items-center gap-2">
          {page === "home" ? (
            <h1 className="min-w-0 flex-1 text-base font-semibold leading-tight">何以解忧，唯有一醉解千愁</h1>
          ) : (
            <>
              <button
                type="button"
                aria-label="返回"
                onClick={() => {
                  setPicker(null);
                  setPage("home");
                }}
                className="inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink"
              >
                <ChevronLeft className="size-5" />
              </button>
              <h1 className="min-w-0 flex-1 text-lg font-semibold">
                {page === "settings" ? "设置" : page === "order" ? "自定义顺序" : "关于"}
              </h1>
            </>
          )}
          {page === "home" ? (
            <div className="relative">
              <button
                type="button"
                aria-label="菜单"
                aria-expanded={menuOpen}
                onClick={() => setMenuOpen((open) => !open)}
                className="inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink"
              >
                <EllipsisVertical className="size-5" />
              </button>
              {menuOpen ? (
                <div className="absolute right-0 z-40 mt-2 w-44 overflow-hidden rounded-xl border border-line bg-surface-2 shadow-sm">
                  <button
                    type="button"
                    className="block w-full px-4 py-3 text-left"
                    onClick={() => {
                      setMenuOpen(false);
                      setPage("settings");
                    }}
                  >
                    设置
                  </button>
                  <button
                    type="button"
                    className="block w-full border-t border-line px-4 py-3 text-left"
                    onClick={() => {
                      setMenuOpen(false);
                      setPage("order");
                    }}
                  >
                    自定义顺序
                  </button>
                  <button
                    type="button"
                    className="block w-full border-t border-line px-4 py-3 text-left"
                    onClick={() => {
                      setItems((prev) =>
                        prev.map((item) => ({ ...item, position: 0, cups: 0, credited: false })),
                      );
                      setMenuOpen(false);
                    }}
                  >
                    全部清零
                  </button>
                  <button
                    type="button"
                    className="block w-full border-t border-line px-4 py-3 text-left"
                    onClick={() => {
                      setMenuOpen(false);
                      setPage("about");
                    }}
                  >
                    关于
                  </button>
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      </header>

      {menuOpen ? (
        <button
          type="button"
          aria-label="关闭菜单"
          className="fixed inset-0 z-20 cursor-default"
          onClick={() => setMenuOpen(false)}
        />
      ) : null}

      {page === "home" ? (
        <main className="mx-auto flex min-h-0 w-full max-w-lg flex-1 flex-col px-4 pb-24 pt-3">
          <ul
            className={`grid min-h-0 flex-1 gap-2 overflow-y-auto ${dragId ? "touch-none" : ""}`}
            style={{
              gridAutoRows: `calc((100% - ${Math.max(Math.min(items.length, 7), 1) - 1} * 0.5rem) / ${Math.max(Math.min(items.length, 7), 1)})`,
            }}
          >
            {items.map((item) => (
              <li key={item.id} className="h-full min-h-0" data-row-id={item.id} onPointerDown={(event) => beginReorder(event, item.id)}>
                <CounterRow
                  item={item}
                  dragging={dragId === item.id}
                  onStep={(direction) => stepItem(item.id, direction)}
                  onOpen={() => setEditing({ item, creating: false })}
                />
              </li>
            ))}
          </ul>
          <button
            type="button"
            aria-label="添加"
            onClick={() => setEditing({ item: blankItem(items), creating: true })}
            className="fixed bottom-6 right-5 z-20 inline-flex size-14 items-center justify-center rounded-full bg-accent text-accent-ink shadow-sm"
          >
            <Plus className="size-7" />
          </button>
        </main>
      ) : null}

      {page === "order" ? (
        <main className="mx-auto w-full max-w-lg px-4 py-3">
          <ul className="flex flex-col gap-2">
            {items.map((item, index) => (
              <li key={item.id} className="flex items-center gap-2 rounded-card border border-line bg-surface-2 px-3 py-3">
                <p className="min-w-0 flex-1 break-words text-lg font-semibold">{item.name}</p>
                <button
                  type="button"
                  aria-label={`${item.name} 上移`}
                  disabled={index === 0}
                  onClick={() => moveItem(index, -1)}
                  className="h-11 rounded-xl border border-line bg-surface px-3 disabled:opacity-35"
                >
                  上移
                </button>
                <button
                  type="button"
                  aria-label={`${item.name} 下移`}
                  disabled={index === items.length - 1}
                  onClick={() => moveItem(index, 1)}
                  className="h-11 rounded-xl border border-line bg-surface px-3 disabled:opacity-35"
                >
                  下移
                </button>
              </li>
            ))}
          </ul>
        </main>
      ) : null}

      {page === "settings" ? (
        <main className="mx-auto w-full max-w-lg px-4">
          <button type="button" className="block w-full border-b border-line py-4 text-left" onClick={() => setPicker("theme")}>
            <span className="block text-base">主题</span>
            <span className="mt-0.5 block text-sm text-muted">{themeLabel}</span>
          </button>
          <button type="button" className="block w-full border-b border-line py-4 text-left" onClick={() => setPicker("palette")}>
            <span className="block text-base">色彩</span>
            <span className="mt-0.5 block text-sm text-muted">{paletteLabel}</span>
          </button>
        </main>
      ) : null}

      {page === "about" ? (
        <main className="mx-auto flex min-h-[calc(100vh-4.5rem)] w-full max-w-lg flex-col px-6 pb-8">
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <p className="about-quote">美酒虽好，切勿贪杯</p>
            <p className="about-app">解忧群专用App</p>
            <p className="about-version mt-3">版本号：0.777</p>
          </div>
          <ul className="space-y-2 text-sm">
            <li>创作者：rody</li>
            <li>
              <a href="mailto:rody777@163.com" className="underline">
                联系我
              </a>
            </li>
            <li>感谢解忧群 高哥、雷哥、森哥、伟哥、胖娃、木腔的友情支持</li>
            <li>永远支持单依纯！</li>
          </ul>
        </main>
      ) : null}

      {picker ? (
        <ChoiceMenu
          title={picker === "theme" ? "主题" : "色彩"}
          options={picker === "theme" ? THEMES : PALETTES}
          current={picker === "theme" ? prefs.theme : prefs.palette}
          onClose={() => setPicker(null)}
          onPick={(id) => {
            setPrefs((prev) => (picker === "theme" ? { ...prev, theme: id as ThemeId } : { ...prev, palette: id as PaletteId }));
            setPicker(null);
          }}
        />
      ) : null}

      {editing ? (
        <ItemSettings
          item={editing.item}
          creating={editing.creating}
          onClose={() => setEditing(null)}
          onDelete={() => {
            if (!editing.creating) {
              const id = editing.item.id;
              setItems((prev) => prev.filter((item) => item.id !== id));
            }
            setEditing(null);
          }}
          onSave={(next, unify) => {
            setItems((prev) => {
              const applySips = (item: Item) => {
                if (!unify) return item;
                const position = Math.min(item.position, next.sips);
                return { ...item, sips: next.sips, position, credited: position === next.sips && position > 0 };
              };
              if (editing.creating) return [...prev.map(applySips), next];
              return prev.map((item) => (item.id === editing.item.id ? next : applySips(item)));
            });
            setEditing(null);
          }}
        />
      ) : null}
    </div>
  );
}

function CounterRow({
  item,
  dragging,
  onStep,
  onOpen,
}: {
  item: Item;
  dragging: boolean;
  onStep: (direction: 1 | -1) => void;
  onOpen: () => void;
}) {
  const custom = item.color !== DEFAULT_COLOR;
  const ink = custom ? textOn(item.color) : undefined;

  return (
    <article
      className={`flex h-full w-full flex-col justify-center gap-2 rounded-card border border-line px-3 py-3 ${custom ? "" : "bg-surface-2 text-ink"} ${dragging ? "relative z-10 scale-[1.02] shadow-sm" : ""}`}
      style={custom ? { backgroundColor: item.color, color: ink } : undefined}
      onContextMenu={(event) => event.preventDefault()}
    >
      <p className="text-lg font-semibold leading-snug break-words">{item.name}</p>
      <div className="flex items-center gap-2">
        <p className="shrink-0 text-xs opacity-70">{item.sips}口一杯</p>
        <p className="min-w-16 flex-1 text-center font-semibold leading-none tabular-nums">
          {item.cups}杯
        </p>
        <div className="flex shrink-0 items-center gap-1">
        <StepButton label={`${item.name} 减一口`} onStep={() => onStep(-1)}>
          −
        </StepButton>
        <span key={item.position} className="digit-in inline-block min-w-6 text-center font-mono text-2xl tabular-nums">
          {item.position}
        </span>
        <StepButton label={`${item.name} 加一口`} onStep={() => onStep(1)} tone="accent">
          +
        </StepButton>
        <button
          type="button"
          aria-label={`${item.name} 设置`}
          onClick={onOpen}
          onPointerDown={(event) => event.stopPropagation()}
          className="inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink"
        >
          <Pencil className="size-5" />
        </button>
        </div>
      </div>
    </article>
  );
}

function ItemSettings({
  item,
  creating,
  onClose,
  onSave,
  onDelete,
}: {
  item: Item;
  creating: boolean;
  onClose: () => void;
  onSave: (next: Item, unify: boolean) => void;
  onDelete: () => void;
}) {
  const [name, setName] = useState(item.name);
  const [sips, setSips] = useState(String(item.sips));
  const [color, setColor] = useState(item.color);
  const [initial, setInitial] = useState(String(item.position));
  const [step, setStep] = useState(String(item.step));
  const [unify, setUnify] = useState(false);
  const [error, setError] = useState("");
  const origin = useRef(item);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  function save() {
    const perCup = Number(sips);
    if (!Number.isInteger(perCup) || perCup < SIP_MIN || perCup > SIP_MAX) {
      setError(`一杯酒喝几口请填 ${SIP_MIN} 到 ${SIP_MAX} 的整数`);
      return;
    }
    const position = Number(initial);
    if (!Number.isInteger(position) || position < 0 || position > perCup) {
      setError("初始数值要在 0 和一杯酒喝几口之间");
      return;
    }
    const inc = Number(step);
    if (!Number.isInteger(inc) || inc < 1) {
      setError("增量请填大于 0 的整数");
      return;
    }
    const previous = origin.current;
    const positionChanged = creating || position !== previous.position;
    const cups = positionChanged ? (position === perCup ? 1 : 0) : previous.cups;
    const credited =
      positionChanged || perCup !== previous.sips ? position === perCup && position > 0 : previous.credited;
    onSave(
      {
        ...previous,
        name: name.trim().slice(0, 16) || "未命名",
        sips: perCup,
        position,
        cups,
        credited,
        step: Math.min(100, inc),
        color: cleanColor(color),
      },
      unify,
    );
  }

  return (
    <div className="scrim fixed inset-0 z-40 flex items-end justify-center p-4 sm:items-center" onClick={onClose}>
      <form
        role="dialog"
        aria-modal="true"
        aria-label={creating ? "添加" : `${item.name} 设置`}
        className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-card bg-surface-2 p-5 shadow-sm"
        onClick={(event) => event.stopPropagation()}
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
      >
        <h2 className="text-lg font-semibold">{creating ? "添加" : "设置"}</h2>
        <div className="mt-4 flex flex-col gap-3">
          <Field label="名称">
            <input
              value={name}
              aria-label="名称"
              onChange={(event) => setName(event.target.value.slice(0, 16))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-accent"
            />
          </Field>
          <Field label="一杯酒喝几口">
            <div className="flex items-center gap-3">
              <input
                inputMode="numeric"
                aria-label="一杯酒喝几口"
                value={sips}
                onChange={(event) => setSips(event.target.value.replace(/[^\d]/g, "").slice(0, 2))}
                className="h-12 w-24 rounded-xl border border-line bg-surface px-3 text-center font-mono text-lg outline-none focus:border-accent"
              />
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={unify}
                  onChange={(event) => setUnify(event.target.checked)}
                  className="size-5 accent-accent"
                />
                统一标准
              </label>
            </div>
          </Field>
          <Field label="颜色">
            <input
              type="color"
              aria-label="颜色"
              value={color}
              onChange={(event) => setColor(event.target.value)}
              className="h-12 w-full cursor-pointer rounded-xl border border-line bg-surface"
            />
          </Field>
          <Field label="初始数值">
            <input
              inputMode="numeric"
              aria-label="初始数值"
              value={initial}
              onChange={(event) => setInitial(event.target.value.replace(/[^\d]/g, "").slice(0, 2))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
            />
          </Field>
          <Field label="增量">
            <input
              inputMode="numeric"
              aria-label="增量"
              value={step}
              onChange={(event) => setStep(event.target.value.replace(/[^\d]/g, "").slice(0, 3))}
              className="h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
            />
          </Field>
        </div>
        {error ? <p className="mt-3 text-sm text-accent">{error}</p> : null}
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button type="submit" className="h-12 rounded-xl bg-ink font-medium text-surface">
            保存
          </button>
          <button type="button" onClick={onDelete} className="h-12 rounded-xl border border-line font-medium">
            删除
          </button>
        </div>
      </form>
    </div>
  );
}

function ChoiceMenu({
  title,
  options,
  current,
  onPick,
  onClose,
}: {
  title: string;
  options: { id: string; label: string }[];
  current: string;
  onPick: (id: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="scrim fixed inset-0 z-40 flex items-center justify-center p-6" onClick={onClose}>
      <div
        role="dialog"
        aria-label={title}
        className="max-h-[80vh] w-full max-w-sm overflow-y-auto rounded-card border border-line bg-surface-2 p-2 shadow-sm"
        onClick={(event) => event.stopPropagation()}
      >
        <p className="px-3 py-2 text-sm text-muted">{title}</p>
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => onPick(option.id)}
            className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-left hover:bg-surface"
          >
            <span>{option.label}</span>
            {option.id === current ? <Check className="size-4 text-accent" /> : null}
          </button>
        ))}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <span className="text-sm text-muted">{label}</span>
      <div className="mt-1">{children}</div>
    </div>
  );
}

function StepButton({
  label,
  onStep,
  children,
  tone = "ghost",
}: {
  label: string;
  onStep: () => void;
  children: ReactNode;
  tone?: "ghost" | "accent";
}) {
  const onStepRef = useRef(onStep);
  onStepRef.current = onStep;
  const delayRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const repeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  function stop() {
    if (delayRef.current) clearTimeout(delayRef.current);
    if (repeatRef.current) clearInterval(repeatRef.current);
    delayRef.current = null;
    repeatRef.current = null;
  }

  useEffect(() => stop, []);

  const toneClass = tone === "accent" ? "bg-accent text-accent-ink" : "border border-line bg-surface text-ink";

  return (
    <button
      type="button"
      aria-label={label}
      className={`inline-flex size-11 select-none items-center justify-center rounded-xl text-2xl leading-none touch-manipulation ${toneClass}`}
      onContextMenu={(event) => event.preventDefault()}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.stopPropagation();
        onStepRef.current();
        try {
          event.currentTarget.setPointerCapture(event.pointerId);
        } catch {
          /* optional */
        }
        stop();
        delayRef.current = setTimeout(() => {
          repeatRef.current = setInterval(() => onStepRef.current(), 70);
        }, 360);
      }}
      onPointerUp={stop}
      onPointerCancel={stop}
    >
      {children}
    </button>
  );
}
