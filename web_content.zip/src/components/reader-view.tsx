import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  List,
  LoaderCircle,
  Moon,
  Pause,
  Play,
  Sun,
  Volume2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { splitSentences, type Sentence } from "@/lib/epub/sentences";
import type { BookRecord } from "@/lib/epub/types";
import { useLibrary } from "@/lib/library";
import {
  listVoices,
  TtsEngine,
  ttsSupported,
  voiceLabel,
  type ReaderStatus,
  type VoiceOption,
} from "@/lib/tts";
import { cn } from "@/lib/utils";

type ReaderViewProps = {
  bookId: string;
};

export function ReaderView({ bookId }: ReaderViewProps) {
  const { getBook, hydrate, progress, settings, saveProgress, saveSettings, hydrated } =
    useLibrary();
  const [book, setBook] = useState<BookRecord | null | undefined>(undefined);
  const [status, setStatus] = useState<ReaderStatus>("idle");
  const [chapter, setChapter] = useState(0);
  const [activeIds, setActiveIds] = useState<number[]>([]);
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [tocOpen, setTocOpen] = useState(false);
  const engineRef = useRef<TtsEngine | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const night = settings.night;
  const rate = settings.rate;
  const voiceURI = settings.voiceURI;

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;
    void getBook(bookId).then((loaded) => {
      if (!cancelled) setBook(loaded);
    });
    return () => {
      cancelled = true;
    };
  }, [bookId, getBook, hydrated]);

  useEffect(() => {
    if (!book) return;
    const saved = progress[book.id];
    const engine = new TtsEngine({
      onState: setStatus,
      onPosition: (pos) => {
        setChapter(pos.chapter);
        setActiveIds(pos.sentenceIds);
        saveProgress(book.id, pos.chapter, pos.chunk);
      },
      onFinished: () => {
        toast.success("Has terminado el libro");
      },
      onError: (message) => {
        toast.error(message);
      },
    });
    engine.setRate(rate);
    engine.setVoice(voiceURI);
    engine.load(book.chapters, saved?.chapter ?? 0, saved?.chunk ?? 0);
    engineRef.current = engine;
    const pos = engine.getPosition();
    setChapter(pos.chapter);
    setActiveIds(pos.sentenceIds);

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // Reload only when the book identity changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [book?.id]);

  useEffect(() => {
    engineRef.current?.setRate(rate);
  }, [rate]);

  useEffect(() => {
    engineRef.current?.setVoice(voiceURI);
  }, [voiceURI]);

  useEffect(() => {
    function collect() {
      const all = listVoices();
      const spanish = all.filter((v) => v.isSpanish);
      setVoices(spanish.length > 0 ? spanish : all);
    }
    collect();
    if (typeof window === "undefined") return;
    window.speechSynthesis?.addEventListener("voiceschanged", collect);
    return () => {
      window.speechSynthesis?.removeEventListener("voiceschanged", collect);
    };
  }, []);

  const sentences = useMemo<Sentence[]>(() => {
    const text = book?.chapters[chapter]?.text ?? "";
    return splitSentences(text);
  }, [book, chapter]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [chapter]);

  useEffect(() => {
    const id = activeIds[0];
    if (id === undefined) return;
    const node = document.getElementById(`s-${id}`);
    const root = scrollRef.current;
    if (!node || !root) return;
    const nodeRect = node.getBoundingClientRect();
    const rootRect = root.getBoundingClientRect();
    const visible =
      nodeRect.top >= rootRect.top + 48 && nodeRect.bottom <= rootRect.bottom - 48;
    if (!visible) {
      node.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [activeIds, chapter]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
      if (event.code === "Space") {
        event.preventDefault();
        togglePlay();
      } else if (event.key === "ArrowLeft") {
        void engineRef.current?.prevChapter();
      } else if (event.key === "ArrowRight") {
        void engineRef.current?.nextChapter();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function togglePlay() {
    const engine = engineRef.current;
    if (!engine) return;
    if (!ttsSupported()) {
      toast.error("Este navegador no puede leer en voz alta");
      return;
    }
    if (status === "playing") engine.pause();
    else if (status === "paused") void engine.resume();
    else void engine.play();
  }

  if (book === undefined) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-bg text-muted">
        <LoaderCircle className="size-6 animate-spin" />
      </main>
    );
  }

  if (book === null) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-4 px-6 text-center">
        <h1 className="font-display text-2xl font-medium">Libro no encontrado</h1>
        <p className="text-sm text-muted">
          Puede que se haya borrado de esta biblioteca.
        </p>
        <Button asChild>
          <Link to="/">Volver a Folio</Link>
        </Button>
      </main>
    );
  }

  const current = book.chapters[chapter];
  const chapterCount = book.chapters.length;
  const progressRatio =
    chapterCount === 0
      ? 0
      : (chapter + (sentences.length ? (activeIds[0] ?? 0) / sentences.length : 0)) /
        chapterCount;

  return (
    <div
      className={cn(
        "flex min-h-dvh flex-col bg-bg text-fg",
        night && "theme-night",
      )}
    >
      <header className="sticky top-0 z-20 border-b border-border/70 bg-bg/90 px-3 py-2 backdrop-blur-sm sm:px-5">
        <div className="mx-auto flex max-w-3xl items-center gap-1">
          <Button variant="ghost" size="icon" asChild aria-label="Volver a la biblioteca">
            <Link to="/">
              <ArrowLeft className="size-5" />
            </Link>
          </Button>
          <div className="min-w-0 flex-1 px-1">
            <p className="truncate font-display text-sm font-medium tracking-tight">
              {book.title}
            </p>
            <p className="truncate text-xs text-muted tabular-nums">
              Capítulo {chapter + 1} de {chapterCount}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            aria-label={night ? "Usar papel claro" : "Usar noche"}
            onClick={() => saveSettings({ night: !night })}
          >
            <span className="relative size-5">
              <Sun
                className={cn(
                  "absolute inset-0 size-5 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out",
                  night ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]",
                )}
              />
              <Moon
                className={cn(
                  "absolute inset-0 size-5 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out",
                  night ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-0",
                )}
              />
            </span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Capítulos"
            onClick={() => setTocOpen(true)}
          >
            <List className="size-5" />
          </Button>
        </div>
        <div className="mx-auto mt-2 h-0.5 max-w-3xl overflow-hidden rounded-full bg-bg-subtle">
          <div
            className="h-full bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]"
            style={{ width: `${Math.min(100, Math.max(2, progressRatio * 100))}%` }}
          />
        </div>
      </header>

      <div
        ref={scrollRef}
        className="mx-auto w-full max-w-2xl flex-1 overflow-y-auto px-5 py-8 sm:px-8"
      >
        <h2 className="font-display text-2xl font-medium tracking-tight text-fg sm:text-3xl">
          {current?.title}
        </h2>
        <p className="mt-6 font-display text-[1.0625rem] leading-[1.7] text-fg sm:text-lg sm:leading-[1.75]">
          {sentences.map((sentence) => {
            const active = activeIds.includes(sentence.id);
            return (
              <span key={sentence.id}>
                <span
                  id={`s-${sentence.id}`}
                  className={cn(
                    "transition-colors duration-[var(--motion-quick)]",
                    active && "sentence-active",
                  )}
                >
                  {sentence.text}
                </span>{" "}
              </span>
            );
          })}
        </p>
      </div>

      <PlayerDock
        status={status}
        voices={voices}
        voiceURI={voiceURI}
        rate={rate}
        onVoice={(uri) => saveSettings({ voiceURI: uri })}
        onRate={(value) => saveSettings({ rate: value })}
        onPrev={() => void engineRef.current?.prevChapter()}
        onNext={() => void engineRef.current?.nextChapter()}
        onToggle={togglePlay}
        ttsOk={ttsSupported()}
      />

      {tocOpen && (
        <ChapterDrawer
          title={book.title}
          chapters={book.chapters.map((c) => c.title)}
          current={chapter}
          onClose={() => setTocOpen(false)}
          onSelect={(index) => {
            void engineRef.current?.jumpToChapter(index);
            setTocOpen(false);
          }}
        />
      )}
    </div>
  );
}

function PlayerDock({
  status,
  voices,
  voiceURI,
  rate,
  onVoice,
  onRate,
  onPrev,
  onNext,
  onToggle,
  ttsOk,
}: {
  status: ReaderStatus;
  voices: VoiceOption[];
  voiceURI: string | null;
  rate: number;
  onVoice: (uri: string | null) => void;
  onRate: (rate: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onToggle: () => void;
  ttsOk: boolean;
}) {
  const playing = status === "playing";
  return (
    <div className="sticky bottom-0 z-20 border-t border-border/70 bg-bg/95 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-sm">
      <div className="mx-auto flex max-w-2xl flex-col gap-2">
        <div className="flex items-center gap-3">
          <Volume2 className="size-4 shrink-0 text-muted" />
          <label className="sr-only" htmlFor="folio-voice">
            Voz
          </label>
          <select
            id="folio-voice"
            className="h-11 min-w-0 flex-1 rounded-md bg-bg-elevated px-3 font-sans text-sm text-fg shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            value={voiceURI ?? ""}
            onChange={(event) => onVoice(event.target.value || null)}
          >
            <option value="">Voz del sistema</option>
            {voices.map((voice) => (
              <option key={voice.uri} value={voice.uri}>
                {voiceLabel(voice)}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-3">
          <span className="w-10 shrink-0 text-xs text-muted tabular-nums">
            {rate.toFixed(1)}×
          </span>
          <Slider
            min={0.6}
            max={1.6}
            step={0.1}
            value={[rate]}
            onValueChange={(values) => onRate(values[0] ?? 1)}
            aria-label="Velocidad de lectura"
          />
        </div>
        <div className="flex items-center justify-center gap-6 pt-1">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Capítulo anterior"
            onClick={onPrev}
          >
            <ChevronLeft className="size-6" />
          </Button>
          <Button
            size="play"
            aria-label={playing ? "Pausar" : "Reproducir"}
            onClick={onToggle}
            disabled={!ttsOk}
            className="relative"
          >
            <Pause
              className={cn(
                "absolute size-7 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out",
                playing ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]",
              )}
            />
            <Play
              className={cn(
                "size-7 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out",
                playing ? "scale-[0.25] opacity-0 blur-[4px]" : "ml-0.5 scale-100 opacity-100 blur-0",
              )}
            />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Capítulo siguiente"
            onClick={onNext}
          >
            <ChevronRight className="size-6" />
          </Button>
        </div>
        {!ttsOk && (
          <p className="text-center text-xs text-muted">
            La lectura en voz alta no está disponible en este navegador.
          </p>
        )}
      </div>
    </div>
  );
}

function ChapterDrawer({
  title,
  chapters,
  current,
  onClose,
  onSelect,
}: {
  title: string;
  chapters: string[];
  current: number;
  onClose: () => void;
  onSelect: (index: number) => void;
}) {
  return (
    <div className="fixed inset-0 z-40">
      <button
        type="button"
        className="absolute inset-0 bg-fg/40"
        aria-label="Cerrar capítulos"
        onClick={onClose}
      />
      <div className="absolute inset-x-0 bottom-0 max-h-[80vh] overflow-hidden rounded-t-2xl bg-bg-elevated pb-[env(safe-area-inset-bottom)] shadow-[var(--shadow-border)]">
        <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-border" />
        <div className="px-5 pb-3 pt-4">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
            Capítulos
          </p>
          <h2 className="mt-1 truncate font-display text-lg font-medium tracking-tight">
            {title}
          </h2>
        </div>
        <ul className="max-h-[60vh] overflow-y-auto px-2 pb-4">
          {chapters.map((name, index) => (
            <li key={`${index}-${name}`}>
              <button
                type="button"
                onClick={() => onSelect(index)}
                className={cn(
                  "flex w-full items-baseline gap-3 rounded-md px-3 py-3 text-left transition-colors duration-[var(--motion-quick)]",
                  index === current
                    ? "bg-bg-subtle text-fg"
                    : "text-fg hover:bg-bg",
                )}
              >
                <span className="w-8 shrink-0 font-sans text-xs tabular-nums text-muted">
                  {index + 1}
                </span>
                <span className="font-display text-sm leading-snug">{name}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
