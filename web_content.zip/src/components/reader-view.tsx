import { useEffect, useRef } from "react";
import { ChevronLeft, Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { findBook, selectBooks, useVault, type ReaderTheme } from "@/lib/vault-store";
import { cn, readingMinutes } from "@/lib/utils";

const THEMES: { id: ReaderTheme; label: string }[] = [
  { id: "paper", label: "Бумага" },
  { id: "sepia", label: "Сепия" },
  { id: "night", label: "Ночь" },
];

export function ReaderView({ bookId }: { bookId: string }) {
  const customBooks = useVault((s) => s.customBooks);
  const book = findBook(selectBooks({ customBooks }), bookId);
  const closeBook = useVault((s) => s.closeBook);
  const setProgress = useVault((s) => s.setProgress);
  const removeBook = useVault((s) => s.removeBook);
  const settings = useVault((s) => s.settings);
  const setSettings = useVault((s) => s.setSettings);
  const saved = useVault((s) => s.progress[bookId]?.percent ?? 0);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scroller.current;
    if (!el || !book) return;
    const start = useVault.getState().progress[bookId]?.percent ?? 0;
    if (start > 0) {
      requestAnimationFrame(() => {
        const max = el.scrollHeight - el.clientHeight;
        if (max > 0) el.scrollTop = (start / 100) * max;
      });
    }
    let ticking = false;
    function onScroll() {
      const node = scroller.current;
      if (!node || ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const max = node.scrollHeight - node.clientHeight;
        const pct = max <= 0 ? 100 : (node.scrollTop / max) * 100;
        useVault.getState().setProgress(bookId, pct);
      });
    }
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [book, bookId]);

  if (!book) {
    return (
      <div className="shelf-grain flex h-full flex-col items-center justify-center gap-4 text-cream">
        <p>Книга не найдена.</p>
        <Button onClick={closeBook}>На полку</Button>
      </div>
    );
  }

  const theme = settings.readerTheme;
  const paras = book.text.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);

  return (
    <div
      className={cn(
        "flex h-full flex-col",
        theme === "paper" && "paper-grain text-ink",
        theme === "sepia" && "bg-sepia text-sepia-ink",
        theme === "night" && "bg-night text-night-fg",
      )}
    >
      <header
        className={cn(
          "shrink-0 border-b pt-safe backdrop-blur-md",
          theme === "paper" && "border-ink/8 bg-paper/90",
          theme === "sepia" && "border-sepia-ink/10 bg-sepia/90",
          theme === "night" && "border-cream/8 bg-night/90",
        )}
      >
        <div className="flex items-center gap-1 px-1 py-1">
          <Button
            variant="quiet"
            size="icon"
            aria-label="На полку"
            onClick={closeBook}
            className={cn(theme === "night" && "text-cream hover:bg-cream/8")}
          >
            <ChevronLeft className="size-5" />
          </Button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-sm tracking-tight">{book.title}</p>
            <p className="truncate text-xs text-current/50">
              {book.author} · {readingMinutes(book.text)} мин
            </p>
          </div>
          <div className="flex items-center">
            <Button
              variant="quiet"
              size="icon-sm"
              aria-label="Мельче"
              className={cn(theme === "night" && "text-cream hover:bg-cream/8")}
              onClick={() => setSettings({ fontSize: Math.max(16, settings.fontSize - 2) })}
            >
              <Minus className="size-4" />
            </Button>
            <span className="w-7 text-center text-xs tabular-nums text-current/55">{settings.fontSize}</span>
            <Button
              variant="quiet"
              size="icon-sm"
              aria-label="Крупнее"
              className={cn(theme === "night" && "text-cream hover:bg-cream/8")}
              onClick={() => setSettings({ fontSize: Math.min(28, settings.fontSize + 2) })}
            >
              <Plus className="size-4" />
            </Button>
          </div>
        </div>
        <div className="h-0.5 bg-current/10">
          <div className="h-full bg-sage transition-[width] duration-150" style={{ width: `${saved}%` }} />
        </div>
      </header>

      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <article className="px-5 pb-28 pt-8">
          <p className="text-xs uppercase tracking-[0.2em] text-current/45">{book.author}</p>
          <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">{book.title}</h1>
          <p className="mt-3 text-sm text-current/50">{book.years}</p>
          <div className="mt-6 mb-8 h-px bg-current/12" />

          <div
            className={cn("font-reading leading-[1.7]", book.kind === "verse" && "whitespace-pre-line")}
            style={{ fontSize: `${settings.fontSize}px` }}
          >
            {paras.map((p, i) => (
              <p key={i} className={cn(i > 0 && "mt-5", book.kind === "prose" && "indent-6")}>
                {p}
              </p>
            ))}
          </div>

          <div className="mt-14 flex flex-col items-center gap-4 border-t border-current/10 pt-8">
            <p className="font-display text-lg tracking-tight">Конец</p>
            <Button
              variant={theme === "night" ? "primary" : "paper"}
              onClick={() => {
                setProgress(bookId, 100);
                closeBook();
              }}
            >
              На полку
            </Button>
            {book.custom && (
              <Button
                variant="quiet"
                className="text-danger"
                onClick={() => {
                  if (confirm("Удалить этот текст с полки?")) removeBook(book.id);
                }}
              >
                <Trash2 className="size-4" />
                Удалить
              </Button>
            )}
          </div>
        </article>
      </div>

      <div
        className={cn(
          "pointer-events-none shrink-0 flex justify-center pb-safe pt-3",
          theme === "paper" && "bg-paper",
          theme === "sepia" && "bg-sepia",
          theme === "night" && "bg-night",
        )}
      >
        <div
          className={cn(
            "pointer-events-auto mb-2 flex gap-1 rounded-full p-1 shadow-lift",
            theme === "night" ? "bg-ink-2" : "bg-ink text-cream",
          )}
        >
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSettings({ readerTheme: t.id })}
              className={cn(
                "h-9 min-w-16 rounded-full px-3 text-xs font-medium tracking-wide transition-colors duration-150",
                settings.readerTheme === t.id ? "bg-sage text-ink" : "text-cream/70",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
