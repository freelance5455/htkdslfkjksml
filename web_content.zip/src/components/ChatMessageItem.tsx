import React, { useState, useEffect } from 'react';
import {
  Copy,
  Check,
  RotateCcw,
  Volume2,
  VolumeX,
  Trash2,
  Edit3,
  Bot,
  User,
  AlertCircle,
  Clock,
  Sparkles,
  Zap,
  History,
  ChevronLeft,
  ChevronRight,
  Plus,
} from 'lucide-react';
import { ChatMessage, ChatSettings } from '../types/index.ts';
import { MarkdownView } from './MarkdownView.tsx';

interface ChatMessageItemProps {
  message: ChatMessage;
  settings: ChatSettings;
  isStreaming?: boolean;
  onRegenerate?: () => void;
  onDelete: () => void;
  onEditUser?: (newContent: string, shouldRegenerate: boolean) => void;
  onEditModelMessage?: (messageId: string, newContent: string, mode: 'overwrite' | 'new_alternative') => void;
  onSwitchModelAndRetry?: (model: string) => void;
  onSwitchAlternative?: (messageId: string, altIndex: number) => void;
  onOpenHistoryModal?: (message: ChatMessage) => void;
  onRegenerateSwipe?: (messageId: string) => void;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({
  message,
  settings,
  isStreaming,
  onRegenerate,
  onDelete,
  onEditUser,
  onEditModelMessage,
  onSwitchModelAndRetry,
  onSwitchAlternative,
  onOpenHistoryModal,
  onRegenerateSwipe,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const isUser = message.role === 'user';

  // Synchronize edit content when message.content changes from outside
  useEffect(() => {
    if (!isEditing) {
      setEditContent(message.content);
    }
  }, [message.content, isEditing]);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleSpeak = () => {
    if (!('speechSynthesis' in window)) {
      alert('Peramban Anda tidak mendukung Text-to-Speech.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message.content);
    utterance.lang = 'id-ID';
    utterance.rate = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const is503Overload =
    message.isError &&
    (message.content.includes('503') ||
      message.content.includes('high demand') ||
      message.content.includes('UNAVAILABLE') ||
      message.content.includes('lonjakan'));

  const isOpenRouterError =
    message.isError &&
    (message.content.includes('OpenRouter') ||
      message.content.includes('Provider returned error') ||
      message.content.includes('penyedia'));

  const bubbleOpacity = typeof settings.bubbleOpacity === 'number' ? settings.bubbleOpacity : 0.85;
  const bubbleBlur = typeof settings.bubbleBlur === 'number' ? settings.bubbleBlur : 0;

  // Alternatives management (JanitorAI style)
  const alternatives =
    message.alternatives && message.alternatives.length > 0
      ? message.alternatives
      : message.content
      ? [message.content]
      : [];
  const currentAltIndex = message.activeAlternativeIndex ?? Math.max(0, alternatives.length - 1);
  const totalAlternatives = alternatives.length;
  const isLastAlternative = currentAltIndex >= totalAlternatives - 1;

  return (
    <div
      className={`w-full ${
        settings.chatWidth === 'standard' ? 'max-w-4xl' : 'max-w-6xl xl:max-w-7xl'
      } mx-auto px-3 sm:px-6 py-2 flex ${
        isUser ? 'justify-end' : 'justify-start'
      } group transition-all duration-200`}
    >
      {isUser ? (
        /* ================= USER CHAT BUBBLE ================= */
        <div
          className={`flex flex-col items-end transition-all duration-200 ${
            isEditing
              ? 'w-full max-w-full sm:max-w-[85%]'
              : 'w-fit max-w-[92%] sm:max-w-[80%]'
          }`}
        >
          <div
            className={`relative rounded-2xl rounded-tr-xs px-4 py-3 border shadow-md transition-all duration-200 ${
              isEditing ? 'w-full ring-2 ring-indigo-500/40' : 'w-full'
            }`}
            style={{
              backgroundColor: `rgba(30, 41, 59, ${bubbleOpacity})`,
              borderColor: `rgba(71, 85, 105, ${Math.min(bubbleOpacity + 0.15, 0.6)})`,
              backdropFilter: bubbleBlur > 0 ? `blur(${bubbleBlur}px)` : undefined,
              WebkitBackdropFilter: bubbleBlur > 0 ? `blur(${bubbleBlur}px)` : undefined,
            }}
          >
            {/* User Header: Name, Avatar Photo, Timestamp */}
            <div className="flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-slate-700/40">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                <div className="w-5 h-5 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 overflow-hidden shrink-0">
                  {settings.userAvatar &&
                  (settings.userAvatar.startsWith('data:') || settings.userAvatar.startsWith('http')) ? (
                    <img
                      src={settings.userAvatar}
                      alt={settings.userName || 'User'}
                      className="w-full h-full object-cover"
                    />
                  ) : settings.userAvatar ? (
                    <span className="text-[10px] leading-none">{settings.userAvatar}</span>
                  ) : (
                    <User className="w-3 h-3 text-slate-300" />
                  )}
                </div>
                <span>{settings.userName || 'Anda'}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                {formatTime(message.timestamp)}
              </span>
            </div>

            {/* Multimodal Image attachments */}
            {message.images && message.images.length > 0 && (
              <div className="flex flex-wrap gap-2 my-2">
                {message.images.map((img) => (
                  <div
                    key={img.id}
                    onClick={() => setSelectedImage(img.data)}
                    className="relative rounded-lg overflow-hidden border border-slate-700/80 cursor-pointer group/img max-w-[200px] max-h-[160px] bg-slate-950"
                  >
                    <img
                      src={img.data}
                      alt={img.name || 'Lampiran'}
                      className="w-full h-full object-cover group-hover/img:scale-105 transition duration-200"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 flex items-center justify-center text-[11px] text-white transition">
                      Lihat Penuh
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Editing mode or standard user message */}
            {isEditing ? (
              <div className="mt-2 space-y-3 w-full">
                <div className="flex items-center justify-between text-xs text-indigo-300 font-medium">
                  <span className="flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                    Edit Pesan Anda
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {editContent.length} karakter
                  </span>
                </div>
                <textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  rows={4}
                  autoFocus
                  className="w-full min-h-[120px] bg-slate-950/95 border border-indigo-500/80 focus:border-indigo-400 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 leading-relaxed font-sans resize-y shadow-inner"
                  placeholder="Edit pesan Anda..."
                />
                <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (editContent.trim() && onEditUser) {
                        onEditUser(editContent.trim(), false);
                        setIsEditing(false);
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition cursor-pointer border border-slate-700"
                    title="Simpan perubahan teks pesan saja tanpa membuat ulang respon bot"
                  >
                    Simpan Teks Saja
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (editContent.trim() && onEditUser) {
                        onEditUser(editContent.trim(), true);
                        setIsEditing(false);
                      }
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition cursor-pointer shadow-sm shadow-indigo-600/30 flex items-center gap-1.5"
                    title="Simpan pesan dan minta bot membuat respon baru dari sini"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Simpan &amp; Buat Respon Baru</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditContent(message.content);
                      setIsEditing(false);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs text-slate-400 hover:text-slate-200 transition cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-slate-100 leading-relaxed break-words whitespace-pre-wrap select-text text-[15px]">
                {message.content}
              </div>
            )}
          </div>

          {/* Action Toolbar for User Bubble */}
          {!isEditing && (
            <div className="flex items-center gap-1 mt-1 opacity-60 group-hover:opacity-100 transition pr-1">
              <button
                onClick={handleCopy}
                title="Salin pesan"
                className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
              {onEditUser && (
                <button
                  onClick={() => {
                    setEditContent(message.content);
                    setIsEditing(true);
                  }}
                  title="Edit pesan ini"
                  className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                >
                  <Edit3 className="w-3 h-3" />
                </button>
              )}
              <button
                onClick={onDelete}
                title="Hapus pesan"
                className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-rose-400 transition cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* ================= AI MODEL CHAT BUBBLE ================= */
        <div
          className={`flex flex-col items-start transition-all duration-200 ${
            isEditing
              ? 'w-full max-w-full sm:max-w-[92%]'
              : 'w-full max-w-[96%] sm:max-w-[88%]'
          }`}
        >
          <div
            className={`relative rounded-2xl rounded-tl-xs px-4 sm:px-5 py-3.5 border shadow-md transition-all duration-200 w-full ${
              message.isError
                ? 'border-rose-800/70'
                : isEditing
                ? 'border-indigo-500/80 ring-2 ring-indigo-500/30'
                : ''
            }`}
            style={{
              backgroundColor: message.isError
                ? `rgba(76, 5, 25, ${Math.min(bubbleOpacity, 0.85)})`
                : `rgba(15, 23, 42, ${bubbleOpacity})`,
              borderColor: message.isError
                ? undefined
                : isEditing
                ? undefined
                : `rgba(51, 65, 85, ${Math.min(bubbleOpacity + 0.15, 0.6)})`,
              backdropFilter: bubbleBlur > 0 ? `blur(${bubbleBlur}px)` : undefined,
              WebkitBackdropFilter: bubbleBlur > 0 ? `blur(${bubbleBlur}px)` : undefined,
            }}
          >
            {/* Bot Header: Avatar Photo, Bot Name, Metrics, Timestamp */}
            <div className="flex items-center justify-between gap-3 mb-2 pb-1.5 border-b border-slate-800/60">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-indigo-600 to-sky-500 border border-indigo-400/30 flex items-center justify-center text-white text-xs shadow-xs overflow-hidden shrink-0">
                  {settings.botAvatar &&
                  (settings.botAvatar.startsWith('data:') || settings.botAvatar.startsWith('http')) ? (
                    <img
                      src={settings.botAvatar}
                      alt={settings.botName || 'Bot'}
                      className="w-full h-full object-cover"
                    />
                  ) : settings.botAvatar ? (
                    <span className="leading-none text-xs">{settings.botAvatar}</span>
                  ) : (
                    <Bot className="w-3.5 h-3.5" />
                  )}
                </div>
                <span className="font-semibold text-xs sm:text-sm text-white">
                  {settings.botName || 'Nexus AI'}
                </span>
                {totalAlternatives > 1 && (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Versi {currentAltIndex + 1}/{totalAlternatives}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                {!message.isError && (
                  <>
                    {message.durationMs && <span>{(message.durationMs / 1000).toFixed(1)}s</span>}
                    {message.outputTokens ? (
                      <span className="hidden sm:inline">
                        • <span className="text-sky-400">📥 {message.inputTokens || 0}</span> |{' '}
                        <span className="text-indigo-400">📤 {message.outputTokens}</span>
                      </span>
                    ) : message.tokensEstimate ? (
                      <span className="hidden sm:inline">• ~{message.tokensEstimate} tok</span>
                    ) : null}
                  </>
                )}
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {formatTime(message.timestamp)}
                </span>
              </div>
            </div>

            {/* Content: Error or Markdown or Editing */}
            {message.isError ? (
              <div className="mt-1 p-3.5 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs sm:text-sm space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-bold text-rose-200 text-xs sm:text-sm">
                      {is503Overload
                        ? '⚠️ Server Google Mengalami Lonjakan Trafik (Error 503)'
                        : 'Gagal Mendapatkan Tanggapan AI'}
                    </p>
                    <p className="mt-1 text-rose-300/90 text-xs leading-relaxed">
                      {is503Overload
                        ? 'Model yang Anda gunakan saat ini sedang mengalami antrean padat di server Google Gemini (Spikes in demand). Lonjakan ini bersifat sementara.'
                        : message.content}
                    </p>
                  </div>
                </div>

                {/* Action Recovery Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1 pl-6">
                  {onRegenerate && (
                    <button
                      onClick={onRegenerate}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-900/80 hover:bg-rose-900 border border-rose-700 text-xs text-rose-100 font-medium transition cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Coba Lagi Sekarang</span>
                    </button>
                  )}

                  {is503Overload && onSwitchModelAndRetry && (
                    <button
                      onClick={() => onSwitchModelAndRetry('gemini-3.1-flash-lite')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs text-white font-medium shadow-md shadow-indigo-600/30 transition cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-300" />
                      <span>Ganti ke Gemini 3.1 Flash Lite &amp; Coba Lagi</span>
                    </button>
                  )}

                  {isOpenRouterError && onSwitchModelAndRetry && (
                    <button
                      onClick={() => onSwitchModelAndRetry('gemini-3.1-flash-lite')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs text-white font-medium shadow-md shadow-indigo-600/30 transition cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                      <span>Beralih ke Google Gemini Bawaan &amp; Coba Lagi</span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="mt-1 w-full">
                {isEditing ? (
                  /* Spacious & Non-Shrinking Bot Editor */
                  <div className="space-y-3 w-full animate-in fade-in duration-150">
                    <div className="flex items-center justify-between text-xs text-indigo-300 font-medium pb-1 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                        Edit Tanggapan Bot (Versi {currentAltIndex + 1})
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {editContent.length} karakter
                      </span>
                    </div>

                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      rows={8}
                      autoFocus
                      className="w-full min-h-[160px] sm:min-h-[220px] bg-slate-950/95 border border-indigo-500/80 focus:border-indigo-400 rounded-xl p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 leading-relaxed font-sans resize-y shadow-inner"
                      placeholder="Ubah atau lengkapi kalimat respon bot..."
                    />

                    {/* JanitorAI Dual-Save Buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (editContent.trim() && onEditModelMessage) {
                              onEditModelMessage(message.id, editContent.trim(), 'overwrite');
                              setIsEditing(false);
                            }
                          }}
                          className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition cursor-pointer shadow-sm shadow-indigo-600/30 flex items-center gap-1"
                          title="Simpan dan timpa teks pada versi aktif saat ini"
                        >
                          <Check className="w-3 h-3" />
                          <span>Simpan Perubahan</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (editContent.trim() && onEditModelMessage) {
                              onEditModelMessage(message.id, editContent.trim(), 'new_alternative');
                              setIsEditing(false);
                            }
                          }}
                          className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-indigo-300 hover:text-indigo-200 transition cursor-pointer border border-slate-700 flex items-center gap-1"
                          title="Simpan sebagai versi baru tanpa menghapus respon asli (JanitorAI style)"
                        >
                          <Plus className="w-3 h-3 text-indigo-400" />
                          <span>Simpan sebagai Versi Baru (+)</span>
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setEditContent(message.content);
                          setIsEditing(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs text-slate-400 hover:text-slate-200 transition cursor-pointer"
                      >
                        Batal
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <MarkdownView content={message.content} fontSize={settings.fontSize} />
                    {isStreaming && (
                      <span className="inline-block w-2 h-4 ml-1 bg-indigo-400 animate-pulse align-middle" />
                    )}

                    {/* JanitorAI Swipes Navigation Bar (Always available for Bot responses) */}
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
                      {/* Left: Quick Label & Riwayat Respon Modal Trigger */}
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onOpenHistoryModal && onOpenHistoryModal(message)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-indigo-950/60 hover:text-indigo-200 hover:border-indigo-500/50 border border-slate-700/80 text-[11px] font-semibold text-slate-300 transition cursor-pointer group/hist shadow-xs"
                          title="Buka daftar lengkap riwayat respon bot (JanitorAI)"
                        >
                          <History className="w-3.5 h-3.5 text-indigo-400 group-hover/hist:rotate-45 transition" />
                          <span>Riwayat Respon ({totalAlternatives})</span>
                        </button>
                      </div>

                      {/* Right: JanitorAI Swipe Controls (< 1/3 >) */}
                      <div className="flex items-center gap-1.5 bg-slate-950/80 px-2 py-1 rounded-xl border border-slate-800 shadow-xs">
                        <button
                          type="button"
                          title="Respon Sebelumnya (<)"
                          onClick={() => {
                            if (currentAltIndex > 0 && onSwitchAlternative) {
                              onSwitchAlternative(message.id, currentAltIndex - 1);
                            }
                          }}
                          disabled={currentAltIndex <= 0 || isStreaming}
                          className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-25 disabled:hover:bg-slate-800 text-white flex items-center justify-center transition cursor-pointer"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onOpenHistoryModal && onOpenHistoryModal(message)}
                          title="Klik untuk membuka semua riwayat respon"
                          className="px-2 py-0.5 rounded hover:bg-slate-800/60 font-mono text-xs font-bold text-indigo-300 cursor-pointer transition"
                        >
                          {currentAltIndex + 1} / {totalAlternatives}
                        </button>

                        <button
                          type="button"
                          title={
                            isLastAlternative
                              ? 'Buat Respon Baru / Swipe (+)'
                              : 'Respon Berikutnya (>)'
                          }
                          onClick={() => {
                            if (!isLastAlternative && onSwitchAlternative) {
                              onSwitchAlternative(message.id, currentAltIndex + 1);
                            } else if (isLastAlternative && onRegenerateSwipe) {
                              onRegenerateSwipe(message.id);
                            }
                          }}
                          disabled={isStreaming}
                          className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-25 text-white flex items-center justify-center transition cursor-pointer relative"
                        >
                          {isLastAlternative ? (
                            <Plus className="w-3.5 h-3.5 text-indigo-300" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Action Toolbar for AI Bubble */}
          {!isEditing && (
            <div className="flex items-center gap-1 mt-1 opacity-60 group-hover:opacity-100 transition pl-1">
              <button
                onClick={handleCopy}
                title="Salin isi pesan"
                className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>

              <button
                onClick={handleToggleSpeak}
                title={isSpeaking ? 'Hentikan Suara' : 'Bacakan dengan Suara'}
                className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition cursor-pointer"
              >
                {isSpeaking ? (
                  <VolumeX className="w-3 h-3 text-indigo-400 animate-pulse" />
                ) : (
                  <Volume2 className="w-3 h-3" />
                )}
              </button>

              {onEditModelMessage && (
                <button
                  onClick={() => {
                    setEditContent(message.content);
                    setIsEditing(true);
                  }}
                  title="Edit tanggapan bot ini"
                  className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                >
                  <Edit3 className="w-3 h-3" />
                </button>
              )}

              {/* Quick Regenerate / Swipe New Alternative */}
              {onRegenerateSwipe && (
                <button
                  onClick={() => onRegenerateSwipe(message.id)}
                  title="Buat respon alternatif baru (Swipe)"
                  disabled={isStreaming}
                  className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-indigo-300 transition cursor-pointer disabled:opacity-30"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              )}

              <button
                onClick={onDelete}
                title="Hapus pesan ini"
                className="p-1 rounded hover:bg-slate-800/80 text-slate-400 hover:text-rose-400 transition cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Image Modal Preview */}
      {selectedImage && (
        <div
          onClick={() => setSelectedImage(null)}
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 cursor-zoom-out"
        >
          <img
            src={selectedImage}
            alt="Pratinjau Gambar"
            className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
