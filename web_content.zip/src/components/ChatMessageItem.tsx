import React, { useState, useEffect } from 'react';
import { ChatMessage, VoiceSettings } from '../types.js';
import { Logo } from './Logo.js';
import ReactMarkdown from 'react-markdown';
import {
  Copy,
  Check,
  RotateCw,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ThumbsUp,
  ThumbsDown,
  User,
  Share2,
} from 'lucide-react';

interface ChatMessageItemProps {
  message: ChatMessage;
  onRegenerate?: () => void;
  onFeedback?: (messageId: string, feedback: 'like' | 'dislike' | null) => void;
  voiceSettings?: VoiceSettings;
  isStreaming?: boolean;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({
  message,
  onRegenerate,
  onFeedback,
  voiceSettings,
  isStreaming = false,
}) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [feedbackState, setFeedbackState] = useState<'like' | 'dislike' | null>(message.feedback || null);

  // Speech synthesis state
  const [speechPlaying, setSpeechPlaying] = useState(false);
  const [speechPaused, setSpeechPaused] = useState(false);

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      if (speechPlaying && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [speechPlaying]);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFeedback = (type: 'like' | 'dislike') => {
    const nextVal = feedbackState === type ? null : type;
    setFeedbackState(nextVal);
    onFeedback?.(message.id, nextVal);
  };

  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported on this browser.');
      return;
    }

    const synth = window.speechSynthesis;

    if (speechPlaying) {
      if (speechPaused) {
        synth.resume();
        setSpeechPaused(false);
      } else {
        synth.pause();
        setSpeechPaused(true);
      }
      return;
    }

    // Cancel existing
    synth.cancel();

    // Strip markdown formatting for cleaner speech
    const cleanText = message.content
      .replace(/```[\s\S]*?```/g, 'Code block omitted.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[#*_~>]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = voiceSettings?.rate ?? 1.0;
    utterance.pitch = voiceSettings?.pitch ?? 1.0;

    if (voiceSettings?.voiceURI) {
      const voices = synth.getVoices();
      const matched = voices.find(v => v.voiceURI === voiceSettings.voiceURI);
      if (matched) utterance.voice = matched;
    }

    utterance.onstart = () => {
      setSpeechPlaying(true);
      setSpeechPaused(false);
    };

    utterance.onend = () => {
      setSpeechPlaying(false);
      setSpeechPaused(false);
    };

    utterance.onerror = () => {
      setSpeechPlaying(false);
      setSpeechPaused(false);
    };

    synth.speak(utterance);
  };

  const handleStopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeechPlaying(false);
    setSpeechPaused(false);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'AI Pocket Chat Message',
          text: message.content,
        });
      } catch (err) {
        // user cancelled or share unsupported
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div
      className={`w-full py-4 px-3 sm:px-5 transition-colors ${
        isUser
          ? 'bg-transparent'
          : 'bg-slate-100/50 dark:bg-slate-900/40 border-y border-slate-200/50 dark:border-slate-800/40'
      }`}
    >
      <div className="max-w-4xl mx-auto flex gap-3.5 sm:gap-4.5">
        {/* Avatar */}
        <div className="shrink-0 mt-0.5">
          {isUser ? (
            <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-semibold text-xs shadow-xs">
              <User className="w-4 h-4" />
            </div>
          ) : (
            <Logo size="xs" showText={false} />
          )}
        </div>

        {/* Message Content & Actions */}
        <div className="flex-1 min-w-0 space-y-2">
          {/* Header Role & Timestamp */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              {isUser ? 'You' : 'AI Pocket Chat'}
            </span>
            <span className="text-[10px] text-slate-400">
              {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>

          {/* Markdown Content */}
          <div className="text-sm text-slate-800 dark:text-slate-100 leading-relaxed break-words space-y-2 prose dark:prose-invert prose-slate max-w-none prose-p:my-1.5 prose-pre:my-2 prose-pre:bg-slate-900 prose-pre:text-slate-100 prose-pre:rounded-xl prose-pre:p-3 prose-pre:text-xs">
            <ReactMarkdown>{message.content}</ReactMarkdown>
            {isStreaming && (
              <span className="inline-block w-2 h-4 bg-indigo-500 animate-pulse ml-0.5 align-middle" />
            )}
          </div>

          {/* Action Toolbar for AI Messages */}
          {!isUser && !isStreaming && (
            <div className="flex items-center flex-wrap gap-1 pt-2 text-xs text-slate-400 dark:text-slate-400">
              {/* Copy */}
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition"
                title="Copy response"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px]">{copied ? 'Copied' : 'Copy'}</span>
              </button>

              {/* Read Aloud / Play / Pause */}
              <button
                onClick={handleToggleSpeech}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg transition ${
                  speechPlaying
                    ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-medium'
                    : 'hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
                title={speechPlaying ? (speechPaused ? 'Resume' : 'Pause') : 'Read aloud'}
              >
                {speechPlaying ? (
                  speechPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5" />
                )}
                <span className="text-[11px]">
                  {speechPlaying ? (speechPaused ? 'Resume' : 'Pause') : 'Listen'}
                </span>
              </button>

              {speechPlaying && (
                <button
                  onClick={handleStopSpeech}
                  className="p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-950 text-rose-500 transition"
                  title="Stop reading"
                >
                  <VolumeX className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Regenerate */}
              {onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition"
                  title="Regenerate answer"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span className="text-[11px]">Regenerate</span>
                </button>
              )}

              {/* Like / Dislike */}
              <div className="flex items-center gap-0.5 border-l border-slate-200 dark:border-slate-800 pl-2 ml-1">
                <button
                  onClick={() => handleFeedback('like')}
                  className={`p-1 rounded-lg transition ${
                    feedbackState === 'like'
                      ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950'
                      : 'hover:bg-slate-200 dark:hover:bg-slate-800'
                  }`}
                  title="Good response"
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleFeedback('dislike')}
                  className={`p-1 rounded-lg transition ${
                    feedbackState === 'dislike'
                      ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950'
                      : 'hover:bg-slate-200 dark:hover:bg-slate-800'
                  }`}
                  title="Poor response"
                >
                  <ThumbsDown className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Share */}
              <button
                onClick={handleShare}
                className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition"
                title="Share message"
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
