import React, { useState } from 'react';
import { AlertCircle, Check, Copy, RefreshCw, Wand2 } from 'lucide-react';
import type { ChatMessage, RefineMode } from '../types/chat';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ChatMessageItemProps {
  message: ChatMessage;
  isLastAssistant: boolean;
  isStreaming: boolean;
  isRefining: boolean;
  onRefine: (messageId: string, mode: RefineMode) => void;
  onRegenerate: () => void;
}

function formatTime(ts: number): string {
  try {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export function ChatMessageItem({
  message,
  isLastAssistant,
  isStreaming,
  isRefining,
  onRefine,
  onRegenerate,
}: ChatMessageItemProps) {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard?.writeText(message.text).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    });
  };

  const modelLabel =
    message.model === 'gemini-3.1-flash-lite' ? 'Fast' : 'Balanced';

  return (
    <div className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* Avatar */}
      <div
        className={`grid h-8 w-8 shrink-0 place-items-center rounded-[11px] font-display text-[11px] font-extrabold tracking-wide ${
          isUser
            ? 'bg-[#394d83] text-white'
            : 'bg-gradient-to-br from-[#6678ff] to-[#42d8c6] text-white'
        }`}
      >
        {isUser ? 'YOU' : 'CB'}
      </div>

      {/* Message Content */}
      <div className={`flex max-w-[min(760px,calc(100%-46px))] flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        {/* Clean unboxed metadata */}
        <div className="mb-1 flex items-center gap-1.5 px-0.5 text-xs text-slate-500 dark:text-[#9aa8c0] tabular-nums">
          <span className="font-medium text-slate-700 dark:text-slate-300">
            {isUser ? 'You' : 'CB AI'}
          </span>
          <span aria-hidden="true">·</span>
          <span>{formatTime(message.at)}</span>
          {!isUser && message.model && (
            <>
              <span aria-hidden="true">·</span>
              <span>{modelLabel}</span>
            </>
          )}
        </div>

        {/* Bubble */}
        <div
          className={`w-full rounded-2xl border px-4 py-3 text-[15px] leading-relaxed ${
            isUser
              ? 'rounded-tr-sm border-[#c5d4ff] bg-[#e1e9ff] text-[#172033] dark:border-[#3b548b] dark:bg-[#293b69] dark:text-[#edf2ff]'
              : message.isError
              ? 'rounded-tl-sm border-rose-300 bg-rose-50 text-rose-900 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-200'
              : 'rounded-tl-sm border-slate-200 bg-white text-slate-800 dark:border-[#293449] dark:bg-[#141a27] dark:text-[#edf2ff]'
          }`}
        >
          {/* Image Attachments */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="mb-2.5 flex flex-wrap gap-2">
              {message.attachments.map((att) => (
                <img
                  key={att.id}
                  src={att.previewUrl}
                  alt={att.name}
                  referrerPolicy="no-referrer"
                  className="max-h-56 max-w-full rounded-xl border border-slate-200/70 object-cover dark:border-[#293449]"
                />
              ))}
            </div>
          )}

          {message.isError && (
            <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-rose-700 dark:text-rose-300">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>Connection issue</span>
            </div>
          )}

          {isUser ? (
            <div className="whitespace-pre-wrap break-words">{message.text}</div>
          ) : message.text ? (
            <MarkdownRenderer content={message.text} />
          ) : (
            <div className="py-1 text-sm text-slate-500 dark:text-[#9aa8c0]">
              CB AI is thinking…
            </div>
          )}
        </div>

        {/* Assistant Toolbar */}
        {!isUser && message.text && !isStreaming && (
          <div className="mt-1.5 flex flex-wrap items-center gap-1 px-0.5">
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-200/70 hover:text-slate-900 dark:text-[#9aa8c0] dark:hover:bg-[#1b2333] dark:hover:text-white whitespace-nowrap shrink-0"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            {!message.isError && (
              <>
                <span className="mx-0.5 text-xs text-slate-300 dark:text-slate-700" aria-hidden="true">
                  |
                </span>
                {(
                  [
                    { mode: 'simplify', label: 'Simplify' },
                    { mode: 'shorter', label: 'Shorter' },
                    { mode: 'hinglish', label: 'Hinglish' },
                    { mode: 'steps', label: 'Steps' },
                  ] as const
                ).map((item) => (
                  <button
                    key={item.mode}
                    type="button"
                    disabled={isRefining}
                    onClick={() => onRefine(message.id, item.mode)}
                    className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-200/70 hover:text-slate-900 disabled:opacity-50 dark:text-[#9aa8c0] dark:hover:bg-[#1b2333] dark:hover:text-white whitespace-nowrap shrink-0"
                  >
                    <Wand2 className="h-3 w-3 opacity-75" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </>
            )}

            {isLastAssistant && (
              <button
                type="button"
                disabled={isRefining}
                onClick={onRegenerate}
                className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-200/70 hover:text-slate-900 disabled:opacity-50 dark:text-[#9aa8c0] dark:hover:bg-[#1b2333] dark:hover:text-white whitespace-nowrap shrink-0"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Retry</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
