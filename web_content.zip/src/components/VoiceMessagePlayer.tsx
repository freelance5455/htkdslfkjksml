import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, RotateCcw } from 'lucide-react';
import { formatAudioDuration } from '../utils/audioHelper';

interface VoiceMessagePlayerProps {
  audioUrl?: string;
  durationSeconds?: number;
  senderName?: string;
}

export const VoiceMessagePlayer: React.FC<VoiceMessagePlayerProps> = ({
  audioUrl,
  durationSeconds = 6,
  senderName
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(durationSeconds);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio();
    if (audioUrl) {
      audio.src = audioUrl;
    }
    audio.preload = 'metadata';
    audio.volume = volume;

    audio.onloadedmetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(Math.round(audio.duration));
      }
    };

    audio.ontimeupdate = () => {
      setCurrentTime(audio.currentTime);
    };

    audio.onended = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.onerror = (e) => {
      console.warn('Audio playback notice:', e);
      setIsPlaying(false);
    };

    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, [audioUrl]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = playbackRate;
      audioRef.current.volume = isMuted ? 0 : volume;
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.warn('Playback error:', err);
          setIsPlaying(false);
        });
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    setIsMuted(newVol === 0);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      setIsMuted(false);
      audioRef.current.volume = volume > 0 ? volume : 0.85;
      if (volume === 0) setVolume(0.85);
    } else {
      setIsMuted(true);
      audioRef.current.volume = 0;
    }
  };

  const cyclePlaybackRate = () => {
    const rates = [1.0, 1.25, 1.5, 2.0];
    const nextIdx = (rates.indexOf(playbackRate) + 1) % rates.length;
    const nextRate = rates[nextIdx];
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  // Simulated visual waveform bars
  const totalBars = 24;
  const progressRatio = duration > 0 ? currentTime / duration : 0;
  const activeBarIndex = Math.floor(progressRatio * totalBars);

  return (
    <div className="bg-slate-900 text-white rounded-lg p-3 my-1.5 max-w-md w-full border border-slate-800 shadow-sm">
      <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
        <span className="font-medium text-slate-300">Voice Note</span>
        <span className="font-mono tabular-nums">
          {formatAudioDuration(currentTime)} / {formatAudioDuration(duration)}
        </span>
      </div>

      <div className="flex items-center gap-2.5">
        {/* Play/Pause Button */}
        <button
          type="button"
          onClick={togglePlay}
          aria-label={isPlaying ? 'Pause voice message' : 'Play voice message'}
          className="w-9 h-9 rounded-md bg-red-600 hover:bg-red-500 active:scale-95 text-white flex items-center justify-center transition-all shrink-0 cursor-pointer"
        >
          {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
        </button>

        {/* Waveform Scrubber Display */}
        <div className="flex-1 flex flex-col justify-center">
          <div className="relative flex items-center h-6 gap-0.5 cursor-pointer">
            {Array.from({ length: totalBars }).map((_, idx) => {
              // Wave height pattern
              const heightMultiplier = Math.sin((idx / totalBars) * Math.PI) * 0.8 + 0.2;
              const heightPx = Math.max(4, Math.floor(heightMultiplier * 20));
              const isPassed = idx <= activeBarIndex;

              return (
                <div
                  key={idx}
                  style={{ height: `${heightPx}px` }}
                  className={`flex-1 rounded-full transition-colors ${
                    isPassed ? 'bg-red-500' : 'bg-slate-700'
                  }`}
                />
              );
            })}

            {/* Invisible Range Input for precise scrubbing */}
            <input
              type="range"
              min={0}
              max={duration || 1}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="absolute inset-0 w-full opacity-0 cursor-pointer"
              aria-label="Seek voice message position"
            />
          </div>
        </div>

        {/* Playback Speed Button */}
        <button
          type="button"
          onClick={cyclePlaybackRate}
          className="text-slate-400 hover:text-white px-1.5 py-1 text-xs font-mono rounded bg-slate-800/80 transition-colors shrink-0 cursor-pointer"
          title="Playback speed"
        >
          {playbackRate}x
        </button>

        {/* Volume Controls */}
        <div className="relative flex items-center">
          <button
            type="button"
            onClick={toggleMute}
            onMouseEnter={() => setShowVolumeSlider(true)}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>

          {/* Volume Slider Popover */}
          <div
            className={`absolute right-0 bottom-full mb-1 p-2 bg-slate-800 rounded shadow-lg border border-slate-700 flex items-center gap-2 z-20 ${
              showVolumeSlider ? 'block' : 'hidden md:group-hover:block'
            }`}
            onMouseLeave={() => setShowVolumeSlider(false)}
          >
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-16 h-1 accent-red-500 cursor-pointer"
              aria-label="Adjust voice playback volume"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
