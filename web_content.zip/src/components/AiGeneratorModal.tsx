import React, { useState } from 'react';
import { StudyModule } from '../types/index.ts';
import { Sparkles, X, Loader2, BookOpen, AlertCircle } from 'lucide-react';

interface AiGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'om' | 'en';
  onModuleGenerated: (module: StudyModule) => void;
}

const PRESET_TOPICS = [
  {
    subject: 'Afaan Oromoo',
    topic: 'Gosoota Himaa (Hima Salphaa, Hima Dachaa, fi Hima Xaxamaa)',
    label: 'Gosoota Himaa (Sentence Types)',
  },
  {
    subject: 'Afaan Oromoo',
    topic: 'Mammaksa Oromoo fi Hiika Qolaa Isaanii',
    label: 'Mammaksa & Hiika Qolaa (Proverbs)',
  },
  {
    subject: 'Afaan Oromoo',
    topic: 'Seera Qubeeffannoo fi Dubbachiiftuu Dheeraa/Gabaabaa',
    label: 'Qubeeffannoo (Orthography)',
  },
  {
    subject: 'Biology',
    topic: 'Plant and Animal Tissues in Grade 9 Biology',
    label: 'Tishuuwwan Biqiltootaa fi Bineensotaa (Tissues)',
  },
  {
    subject: 'Chemistry',
    topic: 'Periodic Table Groups and Electron Configuration for Grade 9',
    label: 'Gabatee Waayitaawaa (Periodic Table)',
  },
  {
    subject: 'Physics',
    topic: 'Motion, Velocity, and Acceleration for Grade 9',
    label: 'Saffisa fi Ariitii (Motion & Velocity)',
  },
];

export const AiGeneratorModal: React.FC<AiGeneratorModalProps> = ({
  isOpen,
  onClose,
  language,
  onModuleGenerated,
}) => {
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('Afaan Oromoo');
  const [prefLang, setPrefLang] = useState<'Afaan Oromoo' | 'English' | 'Bilingual'>('Afaan Oromoo');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) return;

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/generate-study-material', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          topic: topic.trim(),
          language: prefLang,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Error ${response.status}: Failed to generate`);
      }

      const data = await response.json();

      const newModule: StudyModule = {
        id: `ai-${Date.now()}`,
        title: data.title || topic,
        titleEn: data.title || topic,
        subject: data.subject || subject,
        subjectEn: data.subject || subject,
        grade: 'Kutaa 9ffaa (Grade 9)',
        category: (subject.includes('Afaan') ? 'Afaan Oromoo' : 'Saayinsii') as any,
        estimatedMinutes: 10,
        topicSummary: data.topicSummary || '',
        topicSummaryEn: data.topicSummary || '',
        sections: data.sections || [],
        keyTerms: data.keyTerms || [],
        questions: data.questions || [],
        examTip: data.examTip || '',
        examTipEn: data.examTip || '',
        isAiGenerated: true,
      };

      onModuleGenerated(newModule);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        err.message ||
          'Wanti tokko dogoggoreera. Maaloo intarneetii fi qindaa\'ina kee ilaali.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPreset = (preset: { subject: string; topic: string }) => {
    setSubject(preset.subject);
    setTopic(preset.topic);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
              <Sparkles className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {language === 'om' ? 'Qabxii fi Gaaffilee AI Maddisiisi' : 'Generate Notes & 5 MCQs with AI'}
              </h2>
              <p className="text-xs text-slate-500">
                Grade 9 Ethiopian Curriculum Generator
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{errorMessage}</p>
          </div>
        )}

        <form onSubmit={handleGenerate} className="space-y-4">
          {/* Subject Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {language === 'om' ? 'Gosa Barnootaa (Subject)' : 'Subject'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['Afaan Oromoo', 'Biology', 'Chemistry', 'Physics', 'Mathematics', 'English'].map(
                (sub) => (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSubject(sub)}
                    className={`py-2 px-2.5 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      subject === sub
                        ? 'bg-amber-400 text-slate-950 border-amber-500 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {sub}
                  </button>
                )
              )}
            </div>
          </div>

          {/* Language preference */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {language === 'om' ? 'Afaan Qabxii (Language)' : 'Output Language'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Afaan Oromoo', 'English', 'Bilingual'] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setPrefLang(l)}
                  className={`py-1.5 px-2 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                    prefLang === l
                      ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          {/* Topic Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {language === 'om'
                ? 'Mata-duree Qorannoo Kutaa 9ffaa (Topic)'
                : 'Enter Grade 9 Topic / Chapter'}
            </label>
            <textarea
              rows={2}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder={
                language === 'om'
                  ? 'Fkn: Gosoota dhamjechaa, Mammaksa Oromoo, Seelii biqiltootaa...'
                  : 'e.g. Oromo proverbs, Morphemes, Cell organelles, Atomic number...'
              }
              className="w-full p-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40 focus:border-amber-500"
              required
            />
          </div>

          {/* Preset Quick Topic Chips */}
          <div>
            <p className="text-[11px] font-semibold text-slate-500 mb-2">
              {language === 'om' ? 'Mata-dureewwan Filatamoo (Quick Suggestions):' : 'Popular Curriculum Topics:'}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_TOPICS.map((pt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectPreset(pt)}
                  className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md border border-slate-200 transition-colors cursor-pointer"
                >
                  {pt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button (min 44px) */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || !topic.trim()}
              className="w-full min-h-[48px] px-4 py-3 text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-900" />
                  <span>
                    {language === 'om'
                      ? 'AI Qabxii fi Gaaffilee 5 Qopheessaa Jira...'
                      : 'Generating Study Notes & 5 MCQs...'}
                  </span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {language === 'om'
                      ? 'Qabxii fi Gaaffilee 5 Maddisiisi'
                      : 'Generate Study Notes & 5 Questions'}
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
