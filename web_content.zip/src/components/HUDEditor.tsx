import React, { useState, useRef } from 'react';
import {
  HUDLayoutConfig,
  HUDElementConfig,
  HUDManager,
  HUD_PRESETS,
  HUDPresetId,
  JoystickMode,
  CrosshairStyle,
} from '../game/hud/HUDConfig';
import { CrosshairView } from './CrosshairView';
import { sound } from '../audio/SoundEngine';
import {
  Save,
  RotateCcw,
  Sliders,
  Eye,
  EyeOff,
  Crosshair,
  Compass,
  Flame,
  Zap,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Layers,
  Sparkles,
  Play,
} from 'lucide-react';

interface HUDEditorProps {
  onClose: () => void;
  onSave: (config: HUDLayoutConfig) => void;
  onResume?: () => void;
  isPaused?: boolean;
}

export const HUDEditor: React.FC<HUDEditorProps> = ({
  onClose,
  onSave,
  onResume,
  isPaused = false,
}) => {
  const [config, setConfig] = useState<HUDLayoutConfig>(() => HUDManager.load());
  const [selectedId, setSelectedId] = useState<string>('fire');
  const [activeTab, setActiveTab] = useState<'parts' | 'properties' | 'crosshair' | 'presets'>('properties');

  const containerRef = useRef<HTMLDivElement | null>(null);
  const partsScrollRef = useRef<HTMLDivElement | null>(null);

  // Direct DOM dragging refs to eliminate all re-renders and jitter
  const dragTargetRef = useRef<HTMLElement | null>(null);
  const dragElementIdRef = useRef<string | null>(null);
  const dragStartPosRef = useRef<{ startX: number; startY: number; elemStartX: number; elemStartY: number }>({
    startX: 0,
    startY: 0,
    elemStartX: 0,
    elemStartY: 0,
  });

  const selectedElem: HUDElementConfig | undefined = config.elements[selectedId];

  // Smooth pointer drag handlers
  const handleElementPointerDown = (id: string, e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    sound.playUIClick();
    setSelectedId(id);

    if (!containerRef.current) return;
    const target = e.currentTarget;
    dragTargetRef.current = target;
    dragElementIdRef.current = id;

    const elem = config.elements[id];
    if (!elem) return;

    dragStartPosRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      elemStartX: elem.x,
      elemStartY: elem.y,
    };

    target.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragTargetRef.current || !dragElementIdRef.current || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const deltaX = e.clientX - dragStartPosRef.current.startX;
    const deltaY = e.clientY - dragStartPosRef.current.startY;

    // Convert pixel delta to percentage of container
    const deltaXPct = (deltaX / rect.width) * 100;
    const deltaYPct = (deltaY / rect.height) * 100;

    let newX = THREE_CLAMP(dragStartPosRef.current.elemStartX + deltaXPct, 5, 95);
    let newY = THREE_CLAMP(dragStartPosRef.current.elemStartY + deltaYPct, 5, 95);

    newX = Math.round(newX * 10) / 10;
    newY = Math.round(newY * 10) / 10;

    // Directly update DOM style for instant 120Hz tracking without React re-render jitter
    dragTargetRef.current.style.left = `${newX}%`;
    dragTargetRef.current.style.top = `${newY}%`;
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!dragTargetRef.current || !dragElementIdRef.current || !containerRef.current) return;

    const id = dragElementIdRef.current;
    const rect = containerRef.current.getBoundingClientRect();
    const deltaX = e.clientX - dragStartPosRef.current.startX;
    const deltaY = e.clientY - dragStartPosRef.current.startY;

    const deltaXPct = (deltaX / rect.width) * 100;
    const deltaYPct = (deltaY / rect.height) * 100;

    let finalX = THREE_CLAMP(dragStartPosRef.current.elemStartX + deltaXPct, 5, 95);
    let finalY = THREE_CLAMP(dragStartPosRef.current.elemStartY + deltaYPct, 5, 95);

    finalX = Math.round(finalX * 10) / 10;
    finalY = Math.round(finalY * 10) / 10;

    // Release pointer capture
    try {
      dragTargetRef.current.releasePointerCapture(e.pointerId);
    } catch {
      // Ignore
    }

    dragTargetRef.current = null;
    dragElementIdRef.current = null;

    // Commit final position once to React state
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [id]: {
          ...prev.elements[id],
          x: finalX,
          y: finalY,
        },
      },
    }));
  };

  const handleSelect = (id: string) => {
    sound.playUIClick();
    setSelectedId(id);
    setActiveTab('properties');
  };

  const handleScaleChange = (val: number) => {
    if (!selectedElem) return;
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: { ...prev.elements[selectedId], scale: val },
      },
    }));
  };

  const handleOpacityChange = (val: number) => {
    if (!selectedElem) return;
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: { ...prev.elements[selectedId], opacity: val },
      },
    }));
  };

  const handlePositionXChange = (val: number) => {
    if (!selectedElem) return;
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: { ...prev.elements[selectedId], x: val },
      },
    }));
  };

  const handlePositionYChange = (val: number) => {
    if (!selectedElem) return;
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: { ...prev.elements[selectedId], y: val },
      },
    }));
  };

  const handleToggleVisibility = () => {
    if (!selectedElem) return;
    sound.playUIClick();
    setConfig(prev => ({
      ...prev,
      elements: {
        ...prev.elements,
        [selectedId]: { ...prev.elements[selectedId], visible: !prev.elements[selectedId].visible },
      },
    }));
  };

  const handleJoystickModeChange = (mode: JoystickMode) => {
    sound.playUIClick();
    setConfig(prev => ({ ...prev, joystickMode: mode }));
  };

  const handleApplyPreset = (presetId: HUDPresetId) => {
    sound.playUIClick();
    const p = HUD_PRESETS[presetId];
    if (p) {
      setConfig(JSON.parse(JSON.stringify(p)));
    }
  };

  const handleSave = () => {
    sound.playBuySound();
    HUDManager.save(config);
    onSave(config);
    onClose();
  };

  const handleSaveAndResume = () => {
    sound.playBuySound();
    HUDManager.save(config);
    onSave(config);
    if (onResume) {
      onResume();
    } else {
      onClose();
    }
  };

  const handleReset = () => {
    sound.playUIClick();
    const def = HUDManager.reset('default');
    setConfig(def);
  };

  const scrollParts = (offset: number) => {
    if (partsScrollRef.current) {
      partsScrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <div
      ref={containerRef}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-between select-none overflow-hidden touch-none"
    >
      {/* --- TOP TOOLBAR HEADER --- */}
      <div className="flex flex-wrap justify-between items-center px-4 sm:px-6 py-2.5 bg-zinc-950/95 border-b border-zinc-800 z-30 gap-2">
        <div className="flex items-center gap-3">
          {/* Prominent Back Button */}
          <button
            onClick={() => {
              sound.playUIClick();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 shadow-md font-teko text-xl tracking-wider uppercase font-semibold cursor-pointer active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-red-500" />
            <span>BACK</span>
          </button>

          <div className="h-6 w-[1px] bg-zinc-800 hidden sm:block" />

          {/* Tabs */}
          <div className="flex gap-1 overflow-x-auto py-0.5">
            {[
              { id: 'properties', label: 'PROPERTIES', icon: Sliders },
              { id: 'parts', label: 'ALL PARTS', icon: Layers },
              { id: 'crosshair', label: 'CROSSHAIR STYLE', icon: Crosshair },
              { id: 'presets', label: 'PRESETS', icon: Sparkles },
            ].map(t => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    sound.playUIClick();
                    setActiveTab(t.id as any);
                  }}
                  className={`px-3 py-1 rounded-lg font-mono-tech text-xs tracking-wider uppercase cursor-pointer transition-all flex items-center gap-1.5 shrink-0 ${
                    activeTab === t.id
                      ? 'bg-red-600 text-white shadow-md'
                      : 'bg-zinc-900 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="px-2.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 flex items-center gap-1 font-mono-tech text-xs tracking-wider cursor-pointer"
            title="Reset to default layout"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">RESET</span>
          </button>

          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-md cursor-pointer active:scale-95 transition-all"
          >
            <Save className="w-4 h-4 text-emerald-400" />
            <span>SAVE HUD</span>
          </button>

          {isPaused && onResume && (
            <button
              onClick={handleSaveAndResume}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/40 cursor-pointer active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>SAVE & RESUME</span>
            </button>
          )}
        </div>
      </div>

      {/* --- SCROLLABLE HUD PARTS STRIP --- */}
      <div className="w-full bg-zinc-950/90 border-b border-zinc-800 px-3 py-1.5 flex items-center gap-2 z-25 overflow-hidden">
        <span className="font-mono-tech text-[10px] text-zinc-400 uppercase tracking-widest shrink-0 hidden sm:inline">
          HUD CONTROLS:
        </span>

        <button
          onClick={() => scrollParts(-220)}
          className="p-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white shrink-0 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div
          ref={partsScrollRef}
          className="flex-1 flex gap-1.5 overflow-x-auto scroll-smooth py-1 px-1 no-scrollbar touch-pan-x"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {Object.values(config.elements).map(elem => {
            const isSelected = selectedId === elem.id;
            return (
              <button
                key={elem.id}
                onClick={() => handleSelect(elem.id)}
                className={`px-3 py-1 rounded-xl border text-left shrink-0 transition-all cursor-pointer flex items-center gap-2 ${
                  isSelected
                    ? 'bg-red-950/80 border-red-500 text-white shadow-md'
                    : elem.visible
                    ? 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                    : 'bg-zinc-900/40 border-zinc-800/60 text-zinc-500 line-through'
                }`}
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    elem.visible ? (isSelected ? 'bg-red-400 animate-ping' : 'bg-emerald-400') : 'bg-zinc-600'
                  }`}
                />
                <span className="font-mono-tech text-xs whitespace-nowrap font-medium">{elem.name}</span>
                <span className="font-mono-tech text-[9px] text-zinc-500">
                  {Math.round(elem.scale * 100)}%
                </span>
              </button>
            );
          })}
        </div>

        <button
          onClick={() => scrollParts(220)}
          className="p-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white shrink-0 cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* --- CENTER CANVAS: STABLE, GLITCH-FREE DIRECT-DRAG HUD BUTTONS --- */}
      <div className="relative flex-1 w-full h-full overflow-hidden">
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:32px_32px] pointer-events-none" />

        {/* Center Crosshair Reference (Requirement 2: Fixed dead center, NOT movable or resizable) */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-15 pointer-events-none flex flex-col items-center justify-center">
          <CrosshairView
            config={config.crosshair}
            isAiming={false}
            isMoving={false}
            isFiring={false}
          />
          <span className="text-[9px] font-mono-tech text-zinc-500 mt-1 px-1 py-0.5 rounded bg-black/40">
            CENTER FIXED
          </span>
        </div>

        {/* Render Editable HUD Elements with zero-jitter direct pointer handlers */}
        {Object.values(config.elements).map(elem => {
          const isSelected = selectedId === elem.id;

          return (
            <div
              key={elem.id}
              onPointerDown={e => handleElementPointerDown(elem.id, e)}
              className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing select-none flex flex-col items-center justify-center p-1 rounded-2xl will-change-transform ${
                isSelected
                  ? 'ring-3 ring-red-500 bg-red-500/25 shadow-2xl shadow-red-500/50 z-30'
                  : 'hover:ring-1 hover:ring-zinc-400 bg-zinc-900/60 z-20'
              } ${!elem.visible ? 'opacity-25 border border-dashed border-zinc-600' : ''}`}
              style={{
                left: `${elem.x}%`,
                top: `${elem.y}%`,
                transform: `translate(-50%, -50%) scale(${elem.scale})`,
                opacity: elem.opacity,
              }}
            >
              {/* Element Label Badge */}
              <div className="absolute -top-6 whitespace-nowrap px-1.5 py-0.5 rounded bg-zinc-950/90 border border-zinc-800 text-[10px] font-mono-tech text-zinc-300 pointer-events-none">
                {elem.name}
              </div>

              {elem.id === 'joystick' && (
                <div className="w-28 h-28 rounded-full border-2 border-zinc-500 bg-zinc-950/50 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-zinc-700 border border-zinc-400 flex items-center justify-center">
                    <Compass className="w-6 h-6 text-white" />
                  </div>
                </div>
              )}

              {elem.id === 'fire' && (
                <div className="w-18 h-18 rounded-full bg-gradient-to-br from-red-600 to-red-800 border-2 border-red-400 flex items-center justify-center text-white shadow-lg">
                  <Crosshair className="w-8 h-8" />
                </div>
              )}

              {elem.id === 'ads' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-zinc-200">
                  <Crosshair className="w-6 h-6" />
                </div>
              )}

              {elem.id === 'reload' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-amber-500/60 flex items-center justify-center text-amber-400">
                  <RotateCcw className="w-6 h-6" />
                </div>
              )}

              {elem.id === 'jump' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-zinc-200">
                  <ArrowLeft className="w-6 h-6 -rotate-90" />
                </div>
              )}

              {elem.id === 'crouch' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-zinc-200">
                  <ArrowLeft className="w-6 h-6 rotate-90" />
                </div>
              )}

              {elem.id === 'slide' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-cyan-500/60 flex items-center justify-center text-cyan-300">
                  <Zap className="w-6 h-6" />
                </div>
              )}

              {elem.id === 'sprint' && (
                <div className="w-12 h-12 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center text-zinc-200">
                  <Zap className="w-5 h-5" />
                </div>
              )}

              {elem.id === 'melee' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-red-500/60 flex items-center justify-center text-red-400">
                  <Flame className="w-6 h-6" />
                </div>
              )}

              {elem.id === 'grenade' && (
                <div className="w-14 h-14 rounded-full bg-zinc-800 border-2 border-emerald-500/60 flex items-center justify-center text-emerald-400 font-teko text-sm font-bold">
                  <Flame className="w-5 h-5" />
                </div>
              )}

              {elem.id === 'switch_weapon' && (
                <div className="w-36 h-12 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-between px-3">
                  <span className="font-teko text-lg text-white font-bold">AR-16</span>
                  <span className="font-mono-tech text-xs text-amber-400 font-bold">30/180</span>
                </div>
              )}

              {elem.id === 'health_bar' && (
                <div className="w-48 h-8 rounded-xl bg-zinc-950 border border-zinc-800 p-1 flex flex-col justify-center gap-1">
                  <div className="w-full h-2 bg-red-600 rounded-full" />
                  <div className="w-1/2 h-1.5 bg-cyan-400 rounded-full" />
                </div>
              )}

              {elem.id === 'wave_counter' && (
                <div className="w-32 h-10 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-center font-teko text-xl text-red-500 font-bold">
                  WAVE 1 // 12 REMAIN
                </div>
              )}

              {elem.id === 'radar' && (
                <div className="w-16 h-16 rounded-full bg-zinc-950 border-2 border-emerald-500 flex items-center justify-center text-[9px] font-mono-tech text-emerald-400">
                  RADAR
                </div>
              )}

              {elem.id === 'flashlight' && (
                <div className="w-12 h-12 rounded-full bg-zinc-800 border border-zinc-600 flex items-center justify-center text-amber-300">
                  FLASHLIGHT
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* --- BOTTOM DRAWER PANEL (SCROLLABLE ON ALL SCREENS) --- */}
      <div
        className="w-full bg-zinc-950/95 border-t border-zinc-800 p-3 sm:p-4 z-30 max-h-[42vh] overflow-y-auto"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        {/* --- 1. PROPERTIES OF SELECTED ELEMENT --- */}
        {activeTab === 'properties' && selectedElem && (
          <div className="max-w-5xl mx-auto flex flex-col gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-850 pb-2">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-red-500" />
                <h3 className="text-xl font-teko font-bold text-white leading-none">{selectedElem.name}</h3>
                <span className="text-[10px] font-mono-tech text-zinc-400">
                  (X: {selectedElem.x}%, Y: {selectedElem.y}%)
                </span>
              </div>

              <div className="flex items-center gap-2">
                {selectedElem.id === 'joystick' && (
                  <button
                    onClick={() => handleJoystickModeChange(config.joystickMode === 'dynamic' ? 'fixed' : 'dynamic')}
                    className="px-3 py-1 rounded-lg border border-zinc-700 bg-zinc-900 font-mono-tech text-xs text-amber-300 cursor-pointer"
                  >
                    {config.joystickMode === 'dynamic' ? 'MODE: DYNAMIC / FLOATING' : 'MODE: FIXED CORNER'}
                  </button>
                )}

                <button
                  onClick={handleToggleVisibility}
                  className={`px-2.5 py-1 rounded-lg border flex items-center gap-1 font-mono-tech text-xs cursor-pointer ${
                    selectedElem.visible
                      ? 'bg-zinc-900 border-zinc-700 text-emerald-400'
                      : 'bg-red-950 border-red-700 text-red-400'
                  }`}
                >
                  {selectedElem.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{selectedElem.visible ? 'VISIBLE' : 'HIDDEN'}</span>
                </button>
              </div>
            </div>

            {/* Precision Position & Scale Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between font-mono-tech text-xs text-zinc-400">
                  <span>SCALE / SIZE</span>
                  <span className="text-red-400 font-bold">{Math.round(selectedElem.scale * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="1.8"
                  step="0.05"
                  value={selectedElem.scale}
                  onChange={e => handleScaleChange(parseFloat(e.target.value))}
                  className="accent-red-500 cursor-pointer"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between font-mono-tech text-xs text-zinc-400">
                  <span>OPACITY / TRANSPARENCY</span>
                  <span className="text-red-400 font-bold">{Math.round(selectedElem.opacity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="1.0"
                  step="0.05"
                  value={selectedElem.opacity}
                  onChange={e => handleOpacityChange(parseFloat(e.target.value))}
                  className="accent-red-500 cursor-pointer"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between font-mono-tech text-xs text-zinc-400">
                  <span>HORIZONTAL (X%)</span>
                  <span className="text-cyan-400 font-bold">{selectedElem.x}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="95"
                  step="0.5"
                  value={selectedElem.x}
                  onChange={e => handlePositionXChange(parseFloat(e.target.value))}
                  className="accent-cyan-500 cursor-pointer"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between font-mono-tech text-xs text-zinc-400">
                  <span>VERTICAL (Y%)</span>
                  <span className="text-cyan-400 font-bold">{selectedElem.y}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="95"
                  step="0.5"
                  value={selectedElem.y}
                  onChange={e => handlePositionYChange(parseFloat(e.target.value))}
                  className="accent-cyan-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* --- 2. ALL PARTS OVERVIEW LIST --- */}
        {activeTab === 'parts' && (
          <div className="max-w-5xl mx-auto flex flex-col gap-2">
            <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider">
              TAP ANY CONTROL TO SELECT AND POSITION:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
              {Object.values(config.elements).map(elem => (
                <button
                  key={elem.id}
                  onClick={() => handleSelect(elem.id)}
                  className={`p-2 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between ${
                    selectedId === elem.id
                      ? 'bg-red-950/80 border-red-500 shadow-md'
                      : 'bg-zinc-900/70 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <span className="font-teko text-lg text-white font-bold leading-tight">{elem.name}</span>
                  <div className="flex justify-between font-mono-tech text-[10px] text-zinc-400 mt-1">
                    <span>{elem.x}%, {elem.y}%</span>
                    <span className={elem.visible ? 'text-emerald-400' : 'text-red-400'}>
                      {elem.visible ? 'SHOW' : 'HIDE'}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* --- 3. CROSSHAIR STYLE SELECTOR --- */}
        {activeTab === 'crosshair' && (
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row gap-6 items-center justify-between">
            <div className="flex flex-col gap-1.5">
              <span className="font-mono-tech text-xs text-zinc-400 uppercase">
                CENTER FIXED CROSSHAIR STYLE
              </span>
              <div className="flex gap-2 flex-wrap">
                {[
                  { id: 'classic', label: 'Classic' },
                  { id: 'dot', label: 'Dot' },
                  { id: 'tactical', label: 'Tactical' },
                  { id: 'precision', label: 'Precision' },
                  { id: 'dynamic', label: 'Dynamic' },
                  { id: 'minimal', label: 'Minimal' },
                  { id: 'custom', label: 'Custom' },
                ].map(s => (
                  <button
                    key={s.id}
                    onClick={() => {
                      sound.playUIClick();
                      setConfig(prev => ({ ...prev, crosshair: { ...prev.crosshair, style: s.id as CrosshairStyle } }));
                    }}
                    className={`px-3 py-1.5 rounded-lg border font-mono-tech text-xs cursor-pointer transition-all ${
                      config.crosshair.style === s.id
                        ? 'bg-red-600 border-red-400 text-white shadow-md'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => {
                  sound.playUIClick();
                  setConfig(prev => ({
                    ...prev,
                    crosshair: { ...prev.crosshair, dynamicSpread: !prev.crosshair.dynamicSpread },
                  }));
                }}
                className={`px-3 py-1.5 rounded-xl border font-mono-tech text-xs cursor-pointer transition-all ${
                  config.crosshair.dynamicSpread
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                    : 'bg-zinc-900 border-zinc-700 text-zinc-400'
                }`}
              >
                {config.crosshair.dynamicSpread ? 'DYNAMIC SPREAD: ON' : 'DYNAMIC SPREAD: OFF'}
              </button>
            </div>
          </div>
        )}

        {/* --- 4. PRESETS TAB --- */}
        {activeTab === 'presets' && (
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row gap-4 items-center justify-between">
            <span className="font-mono-tech text-xs text-zinc-400 uppercase">LOAD PRESET HUD LAYOUT</span>
            <div className="flex gap-2 flex-wrap">
              {[
                { id: 'default', label: 'Default (2-Finger)' },
                { id: 'classic', label: 'Classic Fixed' },
                { id: 'four_finger', label: 'Four-Finger Claw' },
                { id: 'five_finger', label: 'Five-Finger Pro' },
                { id: 'minimal', label: 'Minimal Clean' },
              ].map(p => (
                <button
                  key={p.id}
                  onClick={() => handleApplyPreset(p.id as HUDPresetId)}
                  className={`px-4 py-2 rounded-xl border font-teko text-lg tracking-wider uppercase font-semibold cursor-pointer transition-all ${
                    config.preset === p.id
                      ? 'bg-red-600 border-red-400 text-white shadow-lg'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* --- FLOATING BOTTOM ACTION BAR --- */}
      <div className="w-full bg-black/95 px-4 py-2 border-t border-zinc-800 flex justify-between items-center z-30">
        <button
          onClick={() => {
            sound.playUIClick();
            onClose();
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 font-teko text-xl tracking-wider uppercase font-bold cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4 text-red-500" />
          <span>BACK TO SETTINGS</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/40 cursor-pointer active:scale-95"
          >
            <Save className="w-4 h-4 text-white" />
            <span>SAVE HUD</span>
          </button>

          {isPaused && onResume && (
            <button
              onClick={handleSaveAndResume}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-600/40 cursor-pointer active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>SAVE & RESUME</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

function THREE_CLAMP(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}
