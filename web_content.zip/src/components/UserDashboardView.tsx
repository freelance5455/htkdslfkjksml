import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useUserData } from '../context/UserDataContext';
import { useLanguage } from '../context/LanguageContext';
import { sarfRules } from '../data/sarfRules';
import { nahwRules } from '../data/nahwRules';
import {
  Bookmark,
  CheckCircle2,
  Clock,
  FileEdit,
  Trash2,
  Trophy,
  LogIn,
  BookOpen,
  ArrowRight
} from 'lucide-react';

interface UserDashboardViewProps {
  onSelectRule: (ruleId: string, category: 'sarf' | 'nahw') => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({ onSelectRule }) => {
  const { user, signInWithGoogle } = useAuth();
  const { bookmarks, notes, progressMap, quizRecords, toggleBookmark, saveNote } = useUserData();
  const { language, isRtl } = useLanguage();
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState<string>('');

  const allRules = [...sarfRules, ...nahwRules];
  const totalRules = allRules.length;

  const masteredCount = Object.values(progressMap).filter((p) => p.status === 'mastered').length;
  const studyingCount = Object.values(progressMap).filter((p) => p.status === 'studying').length;
  const progressPercent = Math.round((masteredCount / totalRules) * 100);

  const startEditNote = (ruleId: string, currentText: string) => {
    setEditingNoteId(ruleId);
    setEditingText(currentText);
  };

  const handleUpdateNote = async (ruleId: string, ruleType: 'sarf' | 'nahw') => {
    await saveNote(ruleId, ruleType, editingText);
    setEditingNoteId(null);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Profile / Hero Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-emerald-950 to-stone-900 text-white p-6 sm:p-8 rounded-3xl border border-amber-500/20 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-16 h-16 rounded-2xl ring-4 ring-emerald-500 shadow-md object-cover"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-emerald-700 flex items-center justify-center font-bold text-2xl text-amber-200 ring-4 ring-emerald-500 shadow-md">
                {(user?.displayName || user?.email || 'ط')[0].toUpperCase()}
              </div>
            )}
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-amber-200">
                {user ? user.displayName || user.email : language === 'pashto' ? 'مېلمه طالب علم' : language === 'urdu' ? 'مہمان طالب علم' : 'Guest Scholar'}
              </h2>
              <p className="text-xs sm:text-sm text-stone-300">
                {user ? user.email : language === 'pashto' ? 'د دایمي خوندي کولو لپاره ګوګل سره داخل شئ' : language === 'urdu' ? 'کلاؤڈ محفوظیت کے لیے گوگل سائن ان کریں' : 'Sign in to permanently persist progress & notes'}
              </p>
            </div>
          </div>

          {!user && (
            <button
              onClick={signInWithGoogle}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all hover:scale-102"
            >
              <LogIn className="w-4 h-4 text-amber-300" />
              <span>
                {language === 'pashto' ? 'ګوګل سره داخل شئ' : language === 'urdu' ? 'گوگل سائن ان' : 'Sign in with Google'}
              </span>
            </button>
          )}
        </div>

        {/* Progress Metric Bar */}
        <div className="mt-6 pt-6 border-t border-stone-800 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="bg-stone-800/60 p-3 rounded-2xl border border-stone-700/60">
            <span className="text-xs text-stone-400 block mb-0.5">
              {language === 'pashto' ? 'پرمختګ' : language === 'urdu' ? 'مجموعی ترقی' : 'Mastery'}
            </span>
            <span className="text-xl font-extrabold text-emerald-400">{progressPercent}%</span>
          </div>
          <div className="bg-stone-800/60 p-3 rounded-2xl border border-stone-700/60">
            <span className="text-xs text-stone-400 block mb-0.5">
              {language === 'pashto' ? 'زده شوې قاعدې' : language === 'urdu' ? 'مکمل قواعد' : 'Mastered'}
            </span>
            <span className="text-xl font-extrabold text-emerald-400">{masteredCount} / {totalRules}</span>
          </div>
          <div className="bg-stone-800/60 p-3 rounded-2xl border border-stone-700/60">
            <span className="text-xs text-stone-400 block mb-0.5">
              {language === 'pashto' ? 'تر لوست لاندې' : language === 'urdu' ? 'زیرِ مطالعہ' : 'In Study'}
            </span>
            <span className="text-xl font-extrabold text-amber-400">{studyingCount}</span>
          </div>
          <div className="bg-stone-800/60 p-3 rounded-2xl border border-stone-700/60">
            <span className="text-xs text-stone-400 block mb-0.5">
              {language === 'pashto' ? 'خوندي شوي (نښه شوي)' : language === 'urdu' ? 'محفوظ علامات' : 'Bookmarks'}
            </span>
            <span className="text-xl font-extrabold text-amber-300">{bookmarks.length}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bookmarks Section */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="font-bold text-stone-900 flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-amber-500" />
              <span>
                {language === 'pashto' ? 'خوندي شوي درسونه او قاعدې' : language === 'urdu' ? 'محفوظ شدہ اسباق' : 'Bookmarked Rules'}
              </span>
            </h3>
            <span className="text-xs text-stone-500 font-semibold">{bookmarks.length}</span>
          </div>

          {bookmarks.length === 0 ? (
            <p className="text-xs sm:text-sm text-stone-400 py-6 text-center italic">
              {language === 'pashto'
                ? 'تر اوسه کومه قاعده نه ده نښه شوې.'
                : language === 'urdu'
                ? 'ابھی تک کوئی قاعدہ محفوظ نہیں کیا گیا۔'
                : 'No bookmarked rules yet. Click the bookmark icon on any rule card.'}
            </p>
          ) : (
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {bookmarks.map((bm) => (
                <div
                  key={bm.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-stone-50 border border-stone-200 hover:border-emerald-300 transition-colors"
                >
                  <div
                    onClick={() => onSelectRule(bm.ruleId, bm.ruleType)}
                    className="flex-1 cursor-pointer"
                  >
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-800 mr-2 rtl:mr-0 rtl:ml-2">
                      {bm.ruleType === 'sarf' ? 'صرف' : 'نحو'}
                    </span>
                    <span className="text-xs sm:text-sm font-semibold text-stone-800 hover:text-emerald-700">
                      {bm.ruleTitle}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleBookmark(bm.ruleId, bm.ruleType, bm.ruleTitle)}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-rose-500 transition-colors"
                    title="Remove Bookmark"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Study Notes Section */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="font-bold text-stone-900 flex items-center gap-2">
              <FileEdit className="w-5 h-5 text-emerald-600" />
              <span>
                {language === 'pashto' ? 'شخصي علمي یادښتونه' : language === 'urdu' ? 'ذاتی علمی نوٹس' : 'Personal Study Notes'}
              </span>
            </h3>
            <span className="text-xs text-stone-500 font-semibold">{Object.keys(notes).length}</span>
          </div>

          {Object.keys(notes).length === 0 ? (
            <p className="text-xs sm:text-sm text-stone-400 py-6 text-center italic">
              {language === 'pashto'
                ? 'تر اوسه هیڅ شخصي یادښت نه دی ثبت شوی.'
                : language === 'urdu'
                ? 'ابھی تک کوئی نوٹ نہیں لکھا گیا۔'
                : 'No notes yet. Click the edit note icon on any rule card to jot down ideas.'}
            </p>
          ) : (
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {Object.entries(notes).map(([ruleId, note]) => {
                const targetRule = allRules.find((r) => r.id === ruleId);
                const isEditing = editingNoteId === ruleId;
                return (
                  <div
                    key={ruleId}
                    className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-900">
                        {targetRule?.arabicTitle || ruleId}
                      </span>
                      <button
                        onClick={() => startEditNote(ruleId, note.noteText)}
                        className="text-[11px] text-stone-500 hover:text-emerald-700 font-medium"
                      >
                        {isEditing ? 'بندول' : 'سمول'}
                      </button>
                    </div>

                    {isEditing ? (
                      <div className="space-y-2">
                        <textarea
                          value={editingText}
                          onChange={(e) => setEditingText(e.target.value)}
                          rows={2}
                          className="w-full text-xs p-2 rounded-lg border border-stone-300 bg-white"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleUpdateNote(ruleId, note.ruleType)}
                            className="px-3 py-1 rounded bg-emerald-700 text-white text-xs font-bold"
                          >
                            خوندي کړئ
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-stone-700 whitespace-pre-wrap bg-white p-2.5 rounded-lg border border-stone-100">
                        {note.noteText}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Quiz History Section */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h3 className="font-bold text-stone-900 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-600" />
            <span>
              {language === 'pashto' ? 'د ازموینو تاریخچه او ثبت شوي ریکارډونه' : language === 'urdu' ? 'آزمائشوں کی تاریخ اور ریکارڈ' : 'Quiz Assessment Records'}
            </span>
          </h3>
          <span className="text-xs text-stone-500 font-semibold">{quizRecords.length}</span>
        </div>

        {quizRecords.length === 0 ? (
          <p className="text-xs sm:text-sm text-stone-400 py-4 text-center italic">
            {language === 'pashto' ? 'تر اوسه کومه ازموینه نه ده بشپړه شوې.' : language === 'urdu' ? 'ابھی تک کوئی آزمائش مکمل نہیں کی گئی۔' : 'No quizzes completed yet.'}
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {quizRecords.slice(0, 6).map((rec) => {
              const perc = Math.round((rec.score / rec.total) * 100);
              return (
                <div
                  key={rec.id}
                  className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between"
                >
                  <div>
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 block w-fit mb-1">
                      {rec.category === 'sarf' ? 'علم الصرف' : rec.category === 'nahw' ? 'علم النحو' : 'ګډ (Mixed)'}
                    </span>
                    <span className="text-xs text-stone-500">
                      {new Date(rec.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="text-right rtl:text-left">
                    <span className="text-lg font-extrabold text-stone-900">
                      {rec.score}/{rec.total}
                    </span>
                    <span className="block text-[11px] font-bold text-emerald-600">
                      {perc}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
