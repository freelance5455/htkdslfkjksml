import React, { useState, useEffect } from 'react';
import { X, User, Heart, BookOpen, Music, Radio, Shield, Flame, Bell, Check, Plus, Trash2, Award, Calendar, Sparkles, Lock, Coins, TrendingUp, Share2, Bookmark, BookmarkCheck, Play, Fingerprint, Scan, ShieldCheck, Key, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { offlineCache, UserProfileState, SowingRecord } from '../lib/offlineCache';
import { FEATURED_TRACKS, SERMONS_ARCHIVE, DAILY_DEVOTIONALS } from '../data/spiritualData';
import { Track, Playlist, TrackBookmark } from '../types';
import { DailyPropheticPush } from './DailyPropheticPush';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface UserProfileModalProps {
  onClose: () => void;
  onSelectTrack: (track: Track, initialTimestamp?: number) => void;
  onOpenCustomPlaylistModal: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  onClose,
  onSelectTrack,
  onOpenCustomPlaylistModal,
}) => {
  const [profile, setProfile] = useState<UserProfileState>(offlineCache.getProfile());
  const [activeTab, setActiveTab] = useState<'favorites' | 'playlists' | 'seedBadges' | 'devotionalHistory' | 'spiritualJourney' | 'bookmarks' | 'settings' | 'biometrics'>('seedBadges');
  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState<string>(profile.name);

  // WebAuthn Biometric Security States
  const [hasPlatformAuth, setHasPlatformAuth] = useState<boolean>(false);
  const [isBiometricEnrolled, setIsBiometricEnrolled] = useState<boolean>(() => {
    return localStorage.getItem('juhnkrix_biometric_active') === 'true';
  });
  const [biometricCredentialId, setBiometricCredentialId] = useState<string | null>(() => {
    return localStorage.getItem('juhnkrix_biometric_cred_id');
  });
  const [isEnrollingBiometric, setIsEnrollingBiometric] = useState<boolean>(false);
  const [isTestingBiometric, setIsTestingBiometric] = useState<boolean>(false);
  const [biometricTestResult, setBiometricTestResult] = useState<string | null>(null);
  const [biometricWalletLock, setBiometricWalletLock] = useState<boolean>(() => {
    return localStorage.getItem('jmc_require_biometric') === 'true';
  });

  const jmcBalance = parseFloat(localStorage.getItem('jm_crypto_balance_v2') || '2.4500');

  useEffect(() => {
    webAuthnBiometric.isPlatformAuthenticatorAvailable().then(avail => {
      setHasPlatformAuth(avail);
    });
  }, []);

  const handleEnrollBiometrics = async () => {
    setIsEnrollingBiometric(true);
    setBiometricTestResult(null);
    try {
      const res = await webAuthnBiometric.registerWebAuthnBiometric(profile.name, profile.name);
      if (res.success) {
        setIsBiometricEnrolled(true);
        setBiometricCredentialId(res.credentialId);
        localStorage.setItem('juhnkrix_biometric_active', 'true');
        localStorage.setItem('juhnkrix_biometric_cred_id', res.credentialId);
        if ('vibrate' in navigator) {
          try { navigator.vibrate([40, 60, 40]); } catch (e) {}
        }
        setBiometricTestResult(`✓ Successfully enrolled device biometrics via ${res.method === 'webauthn_hardware' ? 'WebAuthn Hardware Authenticator' : 'Secure Biometric Enclave'}! Credential ID: ${res.credentialId.slice(0, 16)}...`);
      }
    } catch (err: any) {
      setBiometricTestResult(`Enrollment notice: ${err.message || 'Complete'}`);
    } finally {
      setIsEnrollingBiometric(false);
    }
  };

  const handleTestBiometrics = async () => {
    setIsTestingBiometric(true);
    setBiometricTestResult(null);
    try {
      const res = await webAuthnBiometric.verifyBiometric('Wallet Security Verification', 'fingerprint');
      if (res.success) {
        if ('vibrate' in navigator) {
          try { navigator.vibrate([50, 40, 50]); } catch (e) {}
        }
        setBiometricTestResult(`✓ WebAuthn Biometric Verification PASSED! Auth Token: ${res.authToken.slice(0, 24)}... (Access Granted)`);
      } else {
        setBiometricTestResult(`Verification cancelled or failed.`);
      }
    } catch (err: any) {
      setBiometricTestResult(`Verification notice: ${err.message || 'Complete'}`);
    } finally {
      setIsTestingBiometric(false);
    }
  };

  const handleToggleWalletLock = () => {
    const next = !biometricWalletLock;
    setBiometricWalletLock(next);
    localStorage.setItem('jmc_require_biometric', next ? 'true' : 'false');
    if ('vibrate' in navigator) {
      try { navigator.vibrate([30, 40]); } catch (e) {}
    }
  };

  // Quick Seed Log Form State
  const [sowAmountInput, setSowAmountInput] = useState<string>('50');
  const [sowCategoryInput, setSowCategoryInput] = useState<'Tithe' | 'Prophetic Seed' | 'Gospel Music Ministry' | 'First Fruit' | 'Altar Offering'>('Prophetic Seed');
  const [sowPlatformInput, setSowPlatformInput] = useState<string>('Opay Mobile Bank');
  const [logSuccessMsg, setLogSuccessMsg] = useState<string>('');
  const [sharingPlaylist, setSharingPlaylist] = useState<Playlist | null>(null);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);

  const formatBookmarkTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleResumeBookmark = (bm: TrackBookmark) => {
    const found = FEATURED_TRACKS.find((t) => t.id === bm.trackId);
    const trackToPlay: Track = found
      ? { ...found, timestampBookmark: bm.timestamp }
      : {
          id: bm.trackId,
          title: bm.trackTitle,
          artist: bm.artist,
          category: (bm.category as any) || 'Anointed Worship',
          duration: bm.duration,
          albumArt: bm.albumArt,
          description: 'Bookmarked Sanctuary Session',
          scriptureRef: 'Psalm 150',
          plays: 777,
          synthPreset: '528hz',
          timestampBookmark: bm.timestamp,
        };
    onSelectTrack(trackToPlay, bm.timestamp);
    onClose();
  };

  const handleDeleteBookmark = (bmId: string) => {
    offlineCache.removeBookmark(bmId);
    setProfile(offlineCache.getProfile());
  };

  const handleExportCSV = () => {
    if (!history.length) return;
    const headers = ['ID', 'Date', 'Amount (USD)', 'Platform', 'Category'];
    const rows = history.map(r => [r.id, r.date, r.amountUSD, `"${r.platform}"`, `"${r.category}"`]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `juhnkrix_sowing_history_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleSaveName = () => {
    const updated = offlineCache.saveProfile({ name: nameInput });
    setProfile(updated);
    setIsEditingName(false);
  };

  const handleToggleNotify = () => {
    const val = offlineCache.toggleLiveNotification();
    setProfile(offlineCache.getProfile());
  };

  const handleTierChange = (tier: 'Believer' | 'Prophet Inner Circle' | 'Anointed Partner') => {
    const updated = offlineCache.saveProfile({ membershipTier: tier });
    setProfile(updated);
  };

  const handleDeletePlaylist = (id: string) => {
    offlineCache.deleteCustomPlaylist(id);
    setProfile(offlineCache.getProfile());
  };

  const handleLogSeedOffering = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(sowAmountInput) || 20;
    offlineCache.addSowingRecord({
      amountUSD: amount,
      category: sowCategoryInput,
      platform: sowPlatformInput,
    });
    setProfile(offlineCache.getProfile());
    setLogSuccessMsg(`Seed offering of $${amount} recorded! Level & Badges updated.`);
    setTimeout(() => setLogSuccessMsg(''), 4000);
  };

  const favoritedTracks = FEATURED_TRACKS.filter(t => profile.favoriteTrackIds.includes(t.id));
  const favoritedSermons = SERMONS_ARCHIVE.filter(s => profile.favoriteSermonIds.includes(s.id));
  const favoritedDevotionals = DAILY_DEVOTIONALS.filter(d => profile.favoriteDevotionalIds.includes(d.id));

  // --- Spiritual Seed Level & Badge Calculations ---
  const history = profile.sowingHistory || [];
  const totalSownUSD = history.reduce((acc, curr) => acc + curr.amountUSD, 0);
  const totalSowingCount = history.length;

  let currentLevelName = 'Faithful Seedling';
  let currentBadgeIcon = '🌿';
  let currentLevelNum = 1;
  let nextMilestoneUSD = 50;
  let nextBadgeName = 'Cheerful Giver';

  if (totalSownUSD >= 500 || totalSowingCount >= 12) {
    currentLevelName = 'Kingdom Builder';
    currentBadgeIcon = '👑';
    currentLevelNum = 5;
    nextMilestoneUSD = 1000;
    nextBadgeName = 'Master Altar Builder';
  } else if (totalSownUSD >= 325 || totalSowingCount >= 8) {
    currentLevelName = 'Prophetic Partner';
    currentBadgeIcon = '✨';
    currentLevelNum = 4;
    nextMilestoneUSD = 500;
    nextBadgeName = 'Kingdom Builder';
  } else if (totalSownUSD >= 200 || totalSowingCount >= 5) {
    currentLevelName = 'Kingdom Pillar';
    currentBadgeIcon = '🏛️';
    currentLevelNum = 3;
    nextMilestoneUSD = 325;
    nextBadgeName = 'Prophetic Partner';
  } else if (totalSownUSD >= 50 || totalSowingCount >= 3) {
    currentLevelName = 'Cheerful Giver';
    currentBadgeIcon = '💖';
    currentLevelNum = 2;
    nextMilestoneUSD = 200;
    nextBadgeName = 'Kingdom Pillar';
  }

  const progressPercent = Math.min(100, Math.round((totalSownUSD / nextMilestoneUSD) * 100));

  const BADGES = [
    {
      id: 'badge-seedling',
      title: 'Faithful Seedling',
      icon: '🌿',
      levelReq: 'Level 1',
      requirement: 'Sow 1+ Seed Offering into Gospel Soil',
      isUnlocked: totalSowingCount >= 1 || totalSownUSD >= 10,
      description: 'Planted initial seeds with a sincere and humble heart for gospel advancement.'
    },
    {
      id: 'badge-cheerful',
      title: 'Cheerful Giver',
      icon: '💖',
      levelReq: 'Level 2',
      requirement: 'Sow 3+ Offerings or $50+ Cumulative',
      isUnlocked: totalSowingCount >= 3 || totalSownUSD >= 50,
      description: 'Sows joyfully without hesitation (2 Corinthians 9:7). Honored by the Lord.'
    },
    {
      id: 'badge-pillar',
      title: 'Kingdom Pillar',
      icon: '🏛️',
      levelReq: 'Level 3',
      requirement: 'Sow 5+ Offerings or $200+ Cumulative',
      isUnlocked: totalSowingCount >= 5 || totalSownUSD >= 200,
      description: 'A steadfast pillar supporting gospel music streams, devotionals, and prayer altars.'
    },
    {
      id: 'badge-partner',
      title: 'Prophetic Partner',
      icon: '✨',
      levelReq: 'Level 4',
      requirement: 'Sow 8+ Offerings or $325+ Cumulative',
      isUnlocked: totalSowingCount >= 8 || totalSownUSD >= 325,
      description: 'Direct covenant partnership with Prophet JUHNKRIX SYNVAGORD for global broadcasts.'
    },
    {
      id: 'badge-builder',
      title: 'Kingdom Builder',
      icon: '👑',
      levelReq: 'Level 5',
      requirement: 'Sow 12+ Offerings or $500+ Cumulative',
      isUnlocked: totalSowingCount >= 12 || totalSownUSD >= 500,
      description: 'Exceptional pillar of faith building physical and spiritual altars across nations.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-3xl text-amber-100 flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-6 border-b border-amber-500/20">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-16 h-16 rounded-full object-cover border-2 border-amber-400 shadow-xl"
              />
              <span className="absolute -bottom-1 -right-1 p-1 bg-amber-500 rounded-full text-slate-950">
                <Shield className="w-3.5 h-3.5" />
              </span>
            </div>

            <div>
              {isEditingName ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="bg-slate-950 text-amber-100 border border-amber-400 px-3 py-1 rounded-xl text-sm focus:outline-none"
                  />
                  <button
                    onClick={handleSaveName}
                    className="px-3 py-1 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
                    {profile.name}
                  </h2>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="text-xs text-amber-400/80 hover:text-amber-300 underline"
                  >
                    Edit
                  </button>
                </div>
              )}
              <p className="text-xs text-slate-400">{profile.email}</p>
              <div className="flex items-center space-x-2 mt-1">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  <Award className="w-3 h-3 text-amber-400" />
                  <span>{profile.membershipTier}</span>
                </div>

                <div className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  <span>{currentBadgeIcon}</span>
                  <span>{currentLevelName} (Lvl {currentLevelNum})</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 transition-colors border border-amber-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-6">
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-amber-500/15 text-center">
            <span className="text-xs text-slate-400 flex items-center justify-center space-x-1">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Devotional Streak</span>
            </span>
            <p className="text-2xl font-bold font-serif text-amber-200 mt-1">
              {profile.activeStreakDays} Days
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-amber-500/15 text-center">
            <span className="text-xs text-slate-400 flex items-center justify-center space-x-1">
              <Radio className="w-3.5 h-3.5 text-amber-400" />
              <span>Soaking Hours</span>
            </span>
            <p className="text-2xl font-bold font-serif text-amber-200 mt-1">
              {profile.totalSoakingHours} hrs
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-amber-500/15 text-center">
            <span className="text-xs text-slate-400 flex items-center justify-center space-x-1">
              <Heart className="w-3.5 h-3.5 text-rose-400" />
              <span>Saved Tracks</span>
            </span>
            <p className="text-2xl font-bold font-serif text-amber-200 mt-1">
              {profile.favoriteTrackIds.length}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-amber-500/15 text-center">
            <span className="text-xs text-slate-400 flex items-center justify-center space-x-1">
              <Music className="w-3.5 h-3.5 text-amber-400" />
              <span>Custom Playlists</span>
            </span>
            <p className="text-2xl font-bold font-serif text-amber-200 mt-1">
              {profile.customPlaylists.length}
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 border-b border-amber-500/15 pb-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('seedBadges')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'seedBadges'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Spiritual Seed & Badges</span>
          </button>

          <button
            onClick={() => setActiveTab('favorites')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'favorites'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Saved Favorites</span>
          </button>

          <button
            onClick={() => setActiveTab('playlists')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'playlists'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Custom Playlists</span>
          </button>

          <button
            onClick={() => setActiveTab('devotionalHistory')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'devotionalHistory'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Devotional History</span>
          </button>

          <button
            onClick={() => setActiveTab('spiritualJourney')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'spiritualJourney'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Spiritual Journey</span>
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'bookmarks'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Bookmarks</span>
            {(profile.bookmarks?.length || 0) > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-amber-500/30 text-amber-300 border border-amber-400/40">
                {profile.bookmarks.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'settings'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Account Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('biometrics')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 ${
              activeTab === 'biometrics'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 font-extrabold shadow-sm'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Fingerprint className="w-3.5 h-3.5 text-amber-400" />
            <span>🔐 Biometric Wallet Security (WebAuthn)</span>
            {isBiometricEnrolled && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>
        </div>

        {/* Tab Content */}
        <div className="py-6 max-h-[50vh] overflow-y-auto space-y-4">
          {activeTab === 'seedBadges' && (
            <div className="space-y-6 animate-fadeIn">
              {/* Spiritual Seed Level Hero Card */}
              <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/40 shadow-xl space-y-4 relative overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-3xl shadow-lg shrink-0">
                      {currentBadgeIcon}
                    </div>
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400 font-mono">
                        SPIRITUAL SEED LEVEL {currentLevelNum} OF 5
                      </span>
                      <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
                        <span>{currentLevelName}</span>
                        <Sparkles className="w-4 h-4 text-amber-400" />
                      </h3>
                      <p className="text-xs text-slate-300">
                        Cumulative Sown: <span className="text-amber-300 font-extrabold">${totalSownUSD} USD</span> • {totalSowingCount} Seed Offerings
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/80 px-4 py-3 rounded-2xl border border-amber-500/20 text-right min-w-[140px] shrink-0">
                    <span className="text-[10px] text-slate-400 font-semibold block">NEXT LEVEL TARGET</span>
                    <p className="text-sm font-bold font-serif text-amber-300">${nextMilestoneUSD} USD</p>
                    <span className="text-[10px] text-emerald-400 font-mono">{nextBadgeName}</span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5 pt-2 border-t border-amber-500/20">
                  <div className="flex items-center justify-between text-xs font-bold text-amber-200">
                    <span>Level Growth Progress</span>
                    <span>{progressPercent}% (${totalSownUSD} / ${nextMilestoneUSD})</span>
                  </div>
                  <div className="w-full h-3 bg-slate-950 rounded-full border border-amber-500/30 overflow-hidden p-0.5">
                    <div
                      style={{ width: `${progressPercent}%` }}
                      className="h-full rounded-full bg-gradient-to-r from-amber-500 via-emerald-400 to-teal-300 transition-all duration-700 shadow-md"
                    />
                  </div>
                </div>
              </div>

              {/* Gratitude Streak & Prayer Journal Faithfulness Badge */}
              <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/50 p-5 rounded-3xl border border-amber-500/30 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center space-x-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-2xl shadow-md shrink-0">
                    🔥
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-base font-bold font-serif text-amber-100">Prayer Journal Gratitude Streak</h4>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold">
                        Badge of Faithfulness Unlocked
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">
                      You have maintained a consecutive prayer and thanksgiving streak of <span className="text-amber-300 font-bold">7 Days</span> at the golden altar.
                    </p>
                  </div>
                </div>
                <div className="bg-slate-950/80 px-4 py-2.5 rounded-2xl border border-amber-500/30 text-center shrink-0">
                  <span className="text-[10px] font-mono text-amber-400 block uppercase">Faithfulness Badge</span>
                  <span className="text-lg font-bold text-amber-100">🛡️ Intercessor</span>
                </div>
              </div>

              {/* Badges Showcase Grid */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>Spiritual Badges & Kingdom Rewards</span>
                  </h4>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Unlocked {BADGES.filter(b => b.isUnlocked).length} of {BADGES.length} Badges
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {BADGES.map((badge) => (
                    <div
                      key={badge.id}
                      className={`p-4 rounded-2xl border transition-all flex items-start space-x-3 ${
                        badge.isUnlocked
                          ? 'bg-slate-950/80 border-amber-400/40 shadow-lg shadow-amber-500/5'
                          : 'bg-slate-950/40 border-slate-800/80 opacity-60'
                      }`}
                    >
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-2xl shrink-0 ${
                        badge.isUnlocked ? 'bg-amber-500/20 border border-amber-400/30' : 'bg-slate-900 border border-slate-800'
                      }`}>
                        {badge.icon}
                      </div>

                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <h5 className="text-xs font-bold text-amber-100 flex items-center space-x-1.5">
                            <span>{badge.title}</span>
                            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                              {badge.levelReq}
                            </span>
                          </h5>
                          {badge.isUnlocked ? (
                            <span className="flex items-center space-x-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 shrink-0">
                              <Check className="w-3 h-3" />
                              <span>Unlocked</span>
                            </span>
                          ) : (
                            <span className="flex items-center space-x-1 text-[10px] text-slate-500 bg-slate-900 px-2 py-0.5 rounded-full shrink-0">
                              <Lock className="w-3 h-3" />
                              <span>Locked</span>
                            </span>
                          )}
                        </div>

                        <p className="text-[10px] text-slate-400 leading-tight">{badge.description}</p>
                        <div className="text-[9px] font-mono text-amber-400/80 pt-1">
                          Req: {badge.requirement}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Log Seed Offering Quick Action */}
              <div className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>Record / Log a Seed Offering</span>
                  </h4>
                  <span className="text-[10px] text-slate-400 hidden sm:inline">Updates Level & unlocks badges instantly</span>
                </div>

                {logSuccessMsg && (
                  <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center space-x-2 animate-fadeIn">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{logSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleLogSeedOffering} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 font-semibold block mb-1">Amount ($ USD)</label>
                    <input
                      type="number"
                      min="1"
                      value={sowAmountInput}
                      onChange={(e) => setSowAmountInput(e.target.value)}
                      className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-amber-400"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-semibold block mb-1">Category</label>
                    <select
                      value={sowCategoryInput}
                      onChange={(e) => setSowCategoryInput(e.target.value as any)}
                      className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="Prophetic Seed">Prophetic Seed</option>
                      <option value="Tithe">Tithe</option>
                      <option value="Gospel Music Ministry">Gospel Music Ministry</option>
                      <option value="First Fruit">First Fruit</option>
                      <option value="Altar Offering">Altar Offering</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-semibold block mb-1">Payment Platform</label>
                    <select
                      value={sowPlatformInput}
                      onChange={(e) => setSowPlatformInput(e.target.value)}
                      className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="Opay Mobile Bank">Opay Mobile Bank</option>
                      <option value="Moniepoint MFB">Moniepoint MFB</option>
                      <option value="MiniPay (Opera Web3)">MiniPay (Opera Web3)</option>
                      <option value="PalmPay">PalmPay</option>
                      <option value="Stripe Global Card">Stripe Global Card</option>
                      <option value="PayPal Remittance">PayPal Remittance</option>
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Log Seed Record</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Sowing History Table */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <TrendingUp className="w-4 h-4 text-amber-400" />
                    <span>Spiritual Sowing History Log</span>
                  </h4>
                  <button
                    onClick={handleExportCSV}
                    disabled={history.length === 0}
                    className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/30 text-[10px] font-bold flex items-center space-x-1 transition-all disabled:opacity-50"
                  >
                    <span>📥 Export CSV</span>
                  </button>
                </div>

                {history.length === 0 ? (
                  <p className="text-xs text-slate-500 italic p-3">No sowing history logged yet.</p>
                ) : (
                  <div className="space-y-2">
                    {history.map((record) => (
                      <div
                        key={record.id}
                        className="p-3 rounded-xl bg-slate-950/70 border border-amber-500/15 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm shrink-0">
                            🌱
                          </div>
                          <div>
                            <h5 className="font-bold text-amber-100">{record.category}</h5>
                            <p className="text-[10px] text-slate-400">{record.platform} • {record.date}</p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="font-mono font-bold text-emerald-400 text-sm">+${record.amountUSD} USD</span>
                          <span className="block text-[9px] text-amber-400/80 font-mono">Recorded</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'favorites' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
                  Favorited Worship Tracks
                </h4>
                {favoritedTracks.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No favorited tracks yet.</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {favoritedTracks.map((trk) => (
                      <div
                        key={trk.id}
                        onClick={() => {
                          onSelectTrack(trk);
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/20 hover:border-amber-400 flex items-center space-x-3 cursor-pointer transition-all"
                      >
                        <img
                          src={trk.albumArt}
                          alt={trk.title}
                          className="w-10 h-10 rounded-xl object-cover"
                        />
                        <div className="min-w-0 flex-1">
                          <h5 className="text-xs font-bold text-amber-100 truncate">{trk.title}</h5>
                          <p className="text-[10px] text-slate-400">{trk.category}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
                  Favorited Sermons
                </h4>
                {favoritedSermons.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No favorited sermons yet.</p>
                ) : (
                  <div className="space-y-2">
                    {favoritedSermons.map((srm) => (
                      <div key={srm.id} className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/20 flex items-center justify-between">
                        <div>
                          <h5 className="text-xs font-bold text-amber-100">{srm.title}</h5>
                          <p className="text-[10px] text-slate-400">{srm.duration} • {srm.category}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'playlists' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Your Divine Playlists
                </h4>
                <button
                  onClick={() => {
                    onClose();
                    onOpenCustomPlaylistModal();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center space-x-1 shadow-md"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Playlist</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {profile.customPlaylists.map((pl) => (
                  <div
                    key={pl.id}
                    className="p-4 rounded-2xl bg-slate-950/70 border border-amber-500/20 flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={pl.coverImage}
                        alt={pl.title}
                        className="w-12 h-12 rounded-xl object-cover border border-amber-500/30"
                      />
                      <div>
                        <h5 className="text-xs font-bold text-amber-100">{pl.title}</h5>
                        <p className="text-[10px] text-amber-400/80">{pl.themeCategory}</p>
                        <p className="text-[10px] text-slate-400">{pl.trackIds.length} tracks</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-amber-500/10">
                      <button
                        onClick={() => setSharingPlaylist(pl)}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/30 text-xs font-bold flex items-center space-x-1 transition-all"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share & QR Code</span>
                      </button>

                      <button
                        onClick={() => handleDeletePlaylist(pl.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 text-xs"
                        title="Delete Playlist"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Share & QR Code Modal */}
              {sharingPlaylist && (
                <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
                  <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-6 shadow-2xl relative animate-fadeIn">
                    <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
                      <div className="flex items-center space-x-2">
                        <Share2 className="w-5 h-5 text-amber-400" />
                        <h4 className="text-base font-bold font-serif text-amber-100">Share Custom Playlist</h4>
                      </div>
                      <button
                        onClick={() => {
                          setSharingPlaylist(null);
                          setCopySuccess(false);
                        }}
                        className="p-1.5 rounded-full bg-slate-950 text-slate-400 hover:text-amber-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="text-center space-y-3">
                      <h5 className="text-sm font-bold text-amber-200 font-serif">{sharingPlaylist.title}</h5>
                      <p className="text-xs text-slate-400">{sharingPlaylist.description}</p>
                      
                      {/* QR Code Graphic */}
                      <div className="bg-white p-4 rounded-2xl inline-block shadow-lg mx-auto border-4 border-amber-500/30">
                        <svg width="150" height="150" viewBox="0 0 150 150" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect width="150" height="150" fill="white"/>
                          {/* Corner positioning squares */}
                          <rect x="10" y="10" width="40" height="40" fill="black"/>
                          <rect x="18" y="18" width="24" height="24" fill="white"/>
                          <rect x="24" y="24" width="12" height="12" fill="black"/>

                          <rect x="100" y="10" width="40" height="40" fill="black"/>
                          <rect x="108" y="18" width="24" height="24" fill="white"/>
                          <rect x="114" y="24" width="12" height="12" fill="black"/>

                          <rect x="10" y="100" width="40" height="40" fill="black"/>
                          <rect x="18" y="108" width="24" height="24" fill="white"/>
                          <rect x="24" y="114" width="12" height="12" fill="black"/>

                          {/* Data blocks / matrix pattern */}
                          <rect x="60" y="15" width="8" height="8" fill="black"/>
                          <rect x="75" y="10" width="12" height="12" fill="black"/>
                          <rect x="55" y="30" width="10" height="10" fill="black"/>
                          <rect x="70" y="35" width="8" height="8" fill="black"/>
                          <rect x="85" y="25" width="10" height="10" fill="black"/>

                          <rect x="15" y="60" width="10" height="10" fill="black"/>
                          <rect x="30" y="70" width="8" height="8" fill="black"/>
                          <rect x="45" y="55" width="12" height="12" fill="black"/>
                          <rect x="15" y="85" width="8" height="8" fill="black"/>
                          <rect x="35" y="80" width="10" height="10" fill="black"/>

                          <rect x="60" y="60" width="30" height="30" fill="black"/>
                          <rect x="68" y="68" width="14" height="14" fill="white"/>
                          <rect x="72" y="72" width="6" height="6" fill="amber"/>

                          <rect x="105" y="65" width="10" height="10" fill="black"/>
                          <rect x="125" y="55" width="12" height="12" fill="black"/>
                          <rect x="135" y="75" width="8" height="8" fill="black"/>
                          <rect x="115" y="85" width="10" height="10" fill="black"/>

                          <rect x="60" y="110" width="10" height="10" fill="black"/>
                          <rect x="75" y="105" width="12" height="12" fill="black"/>
                          <rect x="90" y="115" width="8" height="8" fill="black"/>
                          <rect x="65" y="130" width="12" height="12" fill="black"/>
                          <rect x="85" y="130" width="14" height="14" fill="black"/>
                          <rect x="110" y="110" width="12" height="12" fill="black"/>
                          <rect x="125" y="125" width="15" height="15" fill="black"/>
                        </svg>
                      </div>
                      <p className="text-[10px] text-slate-400">Scan QR code with mobile camera to open playlist</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-amber-400 block">Unique Sharing Link</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          readOnly
                          value={`${window.location.origin}/#playlist-${sharingPlaylist.id}`}
                          className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono focus:outline-none"
                        />
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(`${window.location.origin}/#playlist-${sharingPlaylist.id}`);
                            setCopySuccess(true);
                            setTimeout(() => setCopySuccess(false), 2500);
                          }}
                          className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0"
                        >
                          {copySuccess ? 'Copied!' : 'Copy Link'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'devotionalHistory' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 flex items-center space-x-3">
                <Check className="w-5 h-5 text-amber-400" />
                <div>
                  <h5 className="text-xs font-bold text-amber-200">Streak Active!</h5>
                  <p className="text-[11px] text-slate-300">
                    You have completed {profile.completedDevotionalDates.length} daily devotionals in this season.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                {DAILY_DEVOTIONALS.map((dev) => {
                  const isCompleted = profile.completedDevotionalDates.includes(dev.date);
                  return (
                    <div
                      key={dev.id}
                      className="p-3.5 rounded-2xl bg-slate-950/70 border border-amber-500/20 flex items-center justify-between"
                    >
                      <div>
                        <span className="text-[10px] text-amber-400 font-mono">{dev.date}</span>
                        <h5 className="text-xs font-bold text-amber-100">{dev.title}</h5>
                        <p className="text-[10px] text-slate-400">{dev.scripture}</p>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                        isCompleted
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
                          : 'bg-slate-900 text-slate-500 border-slate-800'
                      }`}>
                        {isCompleted ? 'Completed' : 'Pending'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'spiritualJourney' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Spiritual Journey Time Analysis (This Week)
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Tracking hours spent in Worship, Prayer, and Listening to Sermons across the week.
                  </p>
                </div>
                <div className="flex items-center space-x-3 text-[10px] font-semibold">
                  <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" /><span>Worship</span></span>
                  <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" /><span>Prayer</span></span>
                  <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" /><span>Sermons</span></span>
                </div>
              </div>

              {/* Bar Chart Container */}
              <div className="bg-slate-950/80 p-6 rounded-3xl border border-amber-500/20 space-y-6">
                <div className="grid grid-cols-7 gap-3 items-end h-56 pt-6 pb-2 px-2 border-b border-amber-500/10">
                  {[
                    { day: 'Mon', worship: 1.5, prayer: 0.8, sermons: 1.0 },
                    { day: 'Tue', worship: 2.0, prayer: 1.0, sermons: 1.5 },
                    { day: 'Wed', worship: 1.8, prayer: 1.5, sermons: 2.0 },
                    { day: 'Thu', worship: 2.5, prayer: 1.2, sermons: 1.8 },
                    { day: 'Fri', worship: 3.0, prayer: 2.0, sermons: 2.5 },
                    { day: 'Sat', worship: 3.5, prayer: 2.5, sermons: 2.2 },
                    { day: 'Sun', worship: 4.5, prayer: 3.0, sermons: 3.0 },
                  ].map((col, idx) => {
                    const maxVal = 5.0;
                    return (
                      <div key={idx} className="flex flex-col items-center space-y-2 h-full justify-end group">
                        <div className="w-full flex items-end justify-center space-x-1 h-44 bg-slate-900/50 rounded-xl p-1 relative">
                          <div
                            style={{ height: `${(col.worship / maxVal) * 100}%` }}
                            className="w-2 bg-gradient-to-t from-amber-600 to-amber-400 rounded-t-sm transition-all duration-500 group-hover:brightness-125 relative"
                            title={`Worship: ${col.worship} hrs`}
                          />
                          <div
                            style={{ height: `${(col.prayer / maxVal) * 100}%` }}
                            className="w-2 bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-sm transition-all duration-500 group-hover:brightness-125 relative"
                            title={`Prayer: ${col.prayer} hrs`}
                          />
                          <div
                            style={{ height: `${(col.sermons / maxVal) * 100}%` }}
                            className="w-2 bg-gradient-to-t from-sky-600 to-sky-400 rounded-t-sm transition-all duration-500 group-hover:brightness-125 relative"
                            title={`Sermons: ${col.sermons} hrs`}
                          />
                        </div>
                        <span className="text-[11px] font-mono text-slate-300 font-bold">{col.day}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="grid grid-cols-3 gap-4 pt-2">
                  <div className="p-3 rounded-2xl bg-slate-900/80 border border-amber-500/10 text-center">
                    <span className="text-[10px] text-amber-400 font-semibold uppercase">Total Worship</span>
                    <p className="text-lg font-extrabold font-serif text-amber-100 mt-0.5">18.8 hrs</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-900/80 border border-emerald-500/10 text-center">
                    <span className="text-[10px] text-emerald-400 font-semibold uppercase">Total Prayer</span>
                    <p className="text-lg font-extrabold font-serif text-emerald-100 mt-0.5">12.0 hrs</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-900/80 border border-sky-500/10 text-center">
                    <span className="text-[10px] text-sky-400 font-semibold uppercase">Total Sermons</span>
                    <p className="text-lg font-extrabold font-serif text-sky-100 mt-0.5">14.0 hrs</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'bookmarks' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Bookmark className="w-4 h-4 text-amber-400" />
                    <span>Saved Audio & Sermon Timestamp Bookmarks</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Resume listening exactly where you left off during deep soaking and preaching sessions.
                  </p>
                </div>
                <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full self-start sm:self-auto">
                  {(profile.bookmarks || []).length} Saved Bookmarks
                </span>
              </div>

              {(!profile.bookmarks || profile.bookmarks.length === 0) ? (
                <div className="p-8 rounded-3xl bg-slate-950/60 border border-amber-500/20 text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto text-amber-400">
                    <Bookmark className="w-6 h-6" />
                  </div>
                  <h5 className="text-sm font-bold font-serif text-amber-200">No Saved Bookmarks Yet</h5>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                    While listening to any track, song, or sermon, tap the <span className="text-amber-300 font-semibold">"Bookmark"</span> button in the player bar to save your exact timestamp for instant resumption anytime.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {profile.bookmarks.map((bm) => {
                    const percent = bm.duration > 0 ? Math.min(100, Math.round((bm.timestamp / bm.duration) * 100)) : 0;
                    return (
                      <div
                        key={bm.id}
                        className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/20 hover:border-amber-400/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                      >
                        <div className="flex items-center space-x-3.5 min-w-0 flex-1">
                          <div className="relative shrink-0">
                            <img
                              src={bm.albumArt}
                              alt={bm.trackTitle}
                              className="w-14 h-14 rounded-2xl object-cover border border-amber-500/30 shadow-md group-hover:scale-105 transition-transform"
                            />
                            <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 p-0.5 rounded-full shadow">
                              <BookmarkCheck className="w-3 h-3" />
                            </div>
                          </div>

                          <div className="min-w-0 flex-1 space-y-1">
                            <div className="flex items-center space-x-2">
                              <h5 className="text-xs font-bold text-amber-100 truncate">{bm.trackTitle}</h5>
                              {bm.category && (
                                <span className="px-2 py-0.2 rounded-full text-[9px] font-medium bg-amber-500/10 text-amber-300 border border-amber-500/20 shrink-0">
                                  {bm.category}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-400 truncate">{bm.artist}</p>

                            {/* Timestamp Progress & Info */}
                            <div className="space-y-1 pt-1">
                              <div className="flex items-center justify-between text-[10px] font-mono text-amber-300">
                                <span className="font-bold flex items-center space-x-1">
                                  <span>Resume at: {formatBookmarkTime(bm.timestamp)}</span>
                                  <span className="text-slate-500">/ {formatBookmarkTime(bm.duration)}</span>
                                </span>
                                <span className="text-slate-400">{percent}% finished</span>
                              </div>
                              <div className="w-full h-1.5 bg-slate-900 rounded-full border border-amber-500/20 overflow-hidden">
                                <div
                                  style={{ width: `${percent}%` }}
                                  className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full"
                                />
                              </div>
                            </div>

                            {bm.note && (
                              <p className="text-[10px] text-slate-400 italic">"{bm.note}"</p>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
                          <button
                            onClick={() => handleResumeBookmark(bm)}
                            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md transition-all active:scale-95"
                          >
                            <Play className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                            <span>Resume Playback</span>
                          </button>

                          <button
                            onClick={() => handleDeleteBookmark(bm.id)}
                            className="p-2 rounded-xl bg-slate-900 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-500/40 transition-colors"
                            title="Delete Bookmark"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-amber-500/20 space-y-4">
                <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Live Broadcast Notifications
                </h5>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-amber-100">
                      Notify when Prophet JUHNKRIX goes live
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Receive real-time notifications for anointed broadcasts and emergency soaking sessions.
                    </p>
                  </div>
                  <button
                    onClick={handleToggleNotify}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                      profile.liveNotificationEnabled ? 'bg-amber-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-slate-950 transition-transform ${
                        profile.liveNotificationEnabled ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Daily Prophetic Push Notification Component */}
              <DailyPropheticPush />

              <div className="p-4 rounded-2xl bg-slate-950/70 border border-amber-500/20 space-y-3">
                <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Spiritual Membership Tier
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['Believer', 'Prophet Inner Circle', 'Anointed Partner'] as const).map((tier) => (
                    <button
                      key={tier}
                      onClick={() => handleTierChange(tier)}
                      className={`p-3 rounded-2xl border text-xs font-bold text-center transition-all ${
                        profile.membershipTier === tier
                          ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                          : 'bg-slate-900 text-slate-400 border-amber-500/10 hover:text-amber-200'
                      }`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'biometrics' && (
            <div className="space-y-6 animate-fadeIn">
              {/* Header Hero Banner */}
              <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/40 shadow-xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center space-x-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
                      <Fingerprint className="w-6 h-6 text-amber-300" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold font-serif text-amber-100 flex items-center space-x-2">
                        <span>WebAuthn Biometric Wallet Protection</span>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold ${
                          isBiometricEnrolled
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                        }`}>
                          {isBiometricEnrolled ? '● ACTIVE (ENROLLED)' : '○ NOT ENROLLED'}
                        </span>
                      </h4>
                      <p className="text-xs text-slate-300 mt-0.5">
                        Secure your JM-CRYPTO wallet balances and account access using device hardware biometrics (Fingerprint / Touch ID / Face ID).
                      </p>
                    </div>
                  </div>

                  <div className="text-right sm:text-right bg-slate-950/90 p-3 rounded-2xl border border-amber-500/20 shrink-0">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Secured Balance</span>
                    <span className="text-lg font-black text-amber-300 font-mono">{jmcBalance.toFixed(4)} JMC</span>
                    <span className="text-[10px] text-emerald-400 block font-mono">≈ ${(jmcBalance * 35000).toLocaleString()} USD</span>
                  </div>
                </div>

                {biometricTestResult && (
                  <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/40 text-amber-200 text-xs flex items-center space-x-2.5 animate-fadeIn">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-mono">{biometricTestResult}</span>
                  </div>
                )}
              </div>

              {/* WebAuthn Credentials & Platform Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">Platform Authenticator</span>
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>{hasPlatformAuth ? 'Touch ID / Face ID Available' : 'Hardware Platform Biometrics Ready'}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    WebAuthn FIDO2 platform authenticator directly interacts with the device secure element.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">Biometric Credential ID</span>
                  <div className="font-mono text-xs text-amber-300 truncate">
                    {biometricCredentialId || 'No credential registered yet'}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Decentralized public-key cryptosystem stored safely on your physical device.
                  </p>
                </div>
              </div>

              {/* Action Controls */}
              <div className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/20 space-y-4">
                <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Biometric Operations
                </h5>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    onClick={handleEnrollBiometrics}
                    disabled={isEnrollingBiometric}
                    className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-md transition-all disabled:opacity-60"
                  >
                    <Fingerprint className="w-4 h-4 text-slate-950" />
                    <span>{isEnrollingBiometric ? 'Scanning Sensor...' : 'Enroll Device Biometrics (Fingerprint / Face)'}</span>
                  </button>

                  <button
                    onClick={handleTestBiometrics}
                    disabled={isTestingBiometric || !isBiometricEnrolled}
                    className="py-3 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center space-x-2 transition-all disabled:opacity-40"
                  >
                    <Scan className="w-4 h-4 text-amber-400" />
                    <span>{isTestingBiometric ? 'Verifying...' : 'Test Biometric Auth'}</span>
                  </button>
                </div>

                {/* Require Biometric for Wallet Operations Toggle */}
                <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/15 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-amber-200 block">Require Biometrics for JM-CRYPTO Outflows</span>
                    <span className="text-[11px] text-slate-400 block">Enforce fingerprint or face scan confirmation before executing withdrawals or transfers.</span>
                  </div>
                  <button
                    onClick={handleToggleWalletLock}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ml-4 ${
                      biometricWalletLock ? 'bg-emerald-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-slate-950 transition-transform ${
                        biometricWalletLock ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
