import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Account, AuditHistoryLog, AppSettings } from '../types';
import {
  User,
  Camera,
  X,
  Check,
  History,
  Shield,
  Save,
  Trash2,
  Eye,
  EyeOff,
  Search,
  ChevronRight,
  ArrowLeft,
  Calendar,
  AlertCircle,
  FolderPlus,
  Cloud,
  RefreshCw,
  Copy,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';
import { toBanglaDigits } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';
import { cloudSyncService } from '../utils/cloudSync';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  accounts?: Account[];
  auditLogs?: AuditHistoryLog[];
  appSettings: AppSettings;
  onSaveProfile: (profile: UserProfile) => void;
  onSaveOpeningBalances?: (updatedAccounts: Account[]) => void;
  onClearHistory?: () => void;
  initialTab?: 'profile' | 'history' | 'cloud_sync' | null;
  onOpenManageCategories?: () => void;
}

type ActivePopup = 'profile' | 'history' | 'cloud_sync' | null;

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  accounts = [],
  auditLogs = [],
  appSettings,
  onSaveProfile,
  onSaveOpeningBalances,
  onClearHistory,
  initialTab = null,
  onOpenManageCategories,
}) => {
  const safeAuditLogs = Array.isArray(auditLogs) ? auditLogs : [];

  // Active sub-popup modal state
  const [activePopup, setActivePopup] = useState<ActivePopup>(initialTab || null);

  // Profile form state
  const [firstName, setFirstName] = useState(userProfile?.firstName || '');
  const [lastName, setLastName] = useState(userProfile?.lastName || '');
  const [avatarUrl, setAvatarUrl] = useState(userProfile?.avatarUrl || '');
  const [password, setPassword] = useState(userProfile?.profilePassword || '');
  const [showPassword, setShowPassword] = useState(false);
  const [profileSuccessMsg, setProfileSuccessMsg] = useState('');

  // Cloud sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedId, setCopiedId] = useState(false);
  const [registerNewId, setRegisterNewId] = useState(userProfile?.userId || '');
  const [registerNewPassword, setRegisterNewPassword] = useState(userProfile?.cloudPassword || '');
  const [showCloudPassword, setShowCloudPassword] = useState(false);

  // Audit history state
  const [historySearch, setHistorySearch] = useState('');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'EDIT' | 'DELETE'>('all');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchronize state when modal opens or props change
  useEffect(() => {
    if (isOpen) {
      setActivePopup(initialTab || null);
      setFirstName(userProfile?.firstName || '');
      setLastName(userProfile?.lastName || '');
      setAvatarUrl(userProfile?.avatarUrl || '');
      setPassword(userProfile?.profilePassword || '');
      setProfileSuccessMsg('');
    }
  }, [isOpen, initialTab, userProfile]);

  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  if (!isOpen) return null;

  // Handle Photo Upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      alert(isEn ? 'Image size must be less than 3MB' : 'ছবি ৩ মেগাবাইটের কম হতে হবে');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setAvatarUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Save Profile Handler
  const handleSaveProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...userProfile,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      avatarUrl: avatarUrl.trim(),
      profilePassword: password.trim(),
      isProfileCompleted: true,
    };
    onSaveProfile(updated);
    setProfileSuccessMsg(isEn ? 'Profile updated successfully!' : 'প্রোফাইল সফলভাবে সংরক্ষিত হয়েছে!');
    setTimeout(() => setProfileSuccessMsg(''), 3000);
  };

  const handleCopyUserId = () => {
    if (userProfile?.userId) {
      navigator.clipboard.writeText(userProfile.userId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleManualSyncNow = async () => {
    if (!userProfile?.userId || !userProfile?.cloudPassword) {
      setSyncStatusMsg({
        type: 'error',
        text: isEn
          ? 'Please register or link a Cloud User ID first'
          : 'প্রথমে একটি ক্লাউড ইউজার আইডি ও পাসওয়ার্ড লিংক করুন',
      });
      return;
    }

    setIsSyncing(true);
    setSyncStatusMsg(null);
    try {
      const res = await cloudSyncService.pushSync(userProfile);
      if (res.success) {
        setSyncStatusMsg({
          type: 'success',
          text: isEn
            ? 'Synced successfully with cloud!'
            : 'ক্লাউডের সাথে সকল হিসাব সফলভাবে সিঙ্ক সম্পন্ন হয়েছে!',
        });
        const updated: UserProfile = {
          ...userProfile,
          lastSyncedAt: res.lastSyncedAt || new Date().toISOString(),
          isCloudSynced: true,
        };
        onSaveProfile(updated);
      } else {
        setSyncStatusMsg({
          type: 'error',
          text: res.error || (isEn ? 'Sync failed' : 'সিঙ্ক ব্যর্থ হয়েছে'),
        });
      }
    } catch (err: any) {
      setSyncStatusMsg({
        type: 'error',
        text: err?.message || 'Error syncing',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSaveCloudCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerNewId.trim() || !registerNewPassword.trim()) {
      setSyncStatusMsg({
        type: 'error',
        text: isEn ? 'User ID and Password are required' : 'ইউজার আইডি এবং পাসওয়ার্ড আবশ্যক',
      });
      return;
    }
    setIsSyncing(true);
    setSyncStatusMsg(null);
    try {
      const updatedProfile: UserProfile = {
        ...userProfile,
        userId: registerNewId.trim(),
        cloudPassword: registerNewPassword.trim(),
        isCloudSynced: true,
      };
      const res = await cloudSyncService.register(
        registerNewId.trim(),
        registerNewPassword.trim(),
        updatedProfile
      );
      if (res.success) {
        onSaveProfile(res.profile || updatedProfile);
        setSyncStatusMsg({
          type: 'success',
          text: isEn
            ? 'Cloud User ID registered and data synced!'
            : 'ক্লাউড ইউজার আইডি সফলভাবে নিবন্ধিত এবং সকল হিসাব সিঙ্ক হয়েছে!',
        });
      } else {
        setSyncStatusMsg({
          type: 'error',
          text: res.error || 'Failed',
        });
      }
    } catch (err: any) {
      setSyncStatusMsg({
        type: 'error',
        text: err?.message || 'Error',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  // Filtered Audit Logs
  const filteredLogs = safeAuditLogs.filter((log) => {
    const matchesFilter = historyFilter === 'all' || log.action === historyFilter;
    const query = historySearch.toLowerCase().trim();
    const matchesQuery =
      !query ||
      (log.summaryBangla && log.summaryBangla.toLowerCase().includes(query)) ||
      (log.summaryEnglish && log.summaryEnglish.toLowerCase().includes(query)) ||
      (log.userNote && log.userNote.toLowerCase().includes(query)) ||
      (log.dateTimeFormatted && log.dateTimeFormatted.toLowerCase().includes(query));
    return matchesFilter && matchesQuery;
  });

  const fullName =
    `${firstName} ${lastName}`.trim() ||
    (userProfile?.firstName
      ? `${userProfile.firstName} ${userProfile.lastName || ''}`.trim()
      : isEn
      ? 'User'
      : 'ব্যবহারকারী');

  // Common Modal Container Style
  const modalContainerClasses = `w-full max-w-lg ${
    isLight
      ? 'bg-white border-sky-200 text-sky-950'
      : 'bg-slate-850 border-slate-700 text-slate-100'
  } border rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
      } p-3 sm:p-4 animate-in fade-in duration-200`}
      id="user-profile-modal-backdrop"
    >
      {/* =========================================================================
          VIEW 1: MAIN PROFILE POPUP MENU (যখন কোনো সাব-পপআপ সিলেক্ট করা নেই)
          ========================================================================= */}
      {activePopup === null && (
        <div className={modalContainerClasses} id="user-profile-main-menu-popup">
          {/* Header: Replaced "User Profile" with Active Profile (Avatar, Name, Active Badge & Close button) */}
          <div
            className={`flex items-center justify-between px-5 sm:px-6 py-4 border-b ${
              isLight
                ? 'border-sky-100 bg-sky-50/80 text-sky-950'
                : 'border-slate-700/80 bg-slate-800/90 text-slate-100'
            }`}
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="relative shrink-0">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt="User"
                    className="w-12 h-12 rounded-2xl object-cover border-2 shadow-xs"
                    style={{ borderColor: dualAccent.primary.hex }}
                  />
                ) : (
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-xs"
                    style={{ backgroundColor: dualAccent.primary.hex }}
                  >
                    <User className="w-6 h-6" />
                  </div>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <h2 className="text-base sm:text-lg font-black tracking-tight truncate leading-tight">
                  {fullName}
                </h2>
                <div className="flex flex-wrap items-center gap-1.5 mt-1">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 inline-flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    {userProfile?.isProfileCompleted !== false
                      ? isEn
                        ? 'Profile Active'
                        : 'প্রোফাইল সক্রিয়'
                      : isEn
                      ? 'New Profile'
                      : 'নতুন প্রোফাইল'}
                  </span>
                  {userProfile?.userId && (
                    <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30 inline-flex items-center gap-1">
                      <Cloud className="w-3 h-3" />
                      <span>ID: {userProfile.userId}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className={`p-2 rounded-full ${
                isLight
                  ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              } transition cursor-pointer shrink-0 ml-2`}
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Vertical List of Buttons */}
          <div className="p-4 sm:p-6 space-y-2.5 overflow-y-auto flex-1">
            <div className="space-y-2.5">
              {/* Button 1: আমার প্রোফাইল */}
              <button
                type="button"
                onClick={() => setActivePopup('profile')}
                className={`w-full p-3.5 sm:p-4 rounded-2xl border flex items-center justify-between transition cursor-pointer ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-slate-800 shadow-2xs'
                    : 'bg-slate-800/80 border-slate-700 hover:border-slate-600 hover:bg-slate-800 text-slate-100'
                }`}
                id="btn-popup-profile-info"
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                    style={{ backgroundColor: dualAccent.primary.hex }}
                  >
                    <User className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold tracking-tight">
                    {isEn ? 'Personal Information' : 'ব্যক্তিগত তথ্য'}
                  </span>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>

              {/* Button: ক্লাউড আইডি ও মাল্টি-ডিভাইস সিঙ্ক */}
              <button
                type="button"
                onClick={() => setActivePopup('cloud_sync')}
                className={`w-full p-3.5 sm:p-4 rounded-2xl border flex items-center justify-between transition cursor-pointer ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 text-slate-800 shadow-2xs'
                    : 'bg-slate-800/80 border-slate-700 hover:border-sky-500/40 hover:bg-slate-800 text-slate-100'
                }`}
                id="btn-popup-cloud-sync"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 shadow-xs">
                    <Cloud className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold tracking-tight">
                      {isEn ? 'Cloud ID & Multi-Device Sync' : 'ক্লাউড আইডি ও মাল্টি-ডিভাইস সিঙ্ক'}
                    </div>
                    <div className="text-[11px] text-slate-400 font-normal">
                      {userProfile?.userId
                        ? isEn
                          ? `ID: ${userProfile.userId} • Active`
                          : `আইডি: ${userProfile.userId} • সিঙ্ক সক্রিয়`
                        : isEn
                        ? 'Set up ID for multi-device'
                        : 'একাধিক মোবাইলে ব্যবহারের জন্য সেটআপ করুন'}
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>

              {/* Button 2: ম্যানেজ ক্যাটাগরি (ক্যাটাগরি পরিচালনা) */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenManageCategories) onOpenManageCategories();
                }}
                className={`w-full p-3.5 sm:p-4 rounded-2xl border flex items-center justify-between transition cursor-pointer ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-amber-300 hover:bg-amber-50/40 text-slate-800 shadow-2xs'
                    : 'bg-slate-800/80 border-slate-700 hover:border-amber-500/40 hover:bg-slate-800 text-slate-100'
                }`}
                id="btn-popup-manage-categories"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-600 flex items-center justify-center shrink-0 shadow-xs">
                    <FolderPlus className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold tracking-tight">
                    {isEn ? 'Manage Categories' : 'ক্যাটাগরি পরিচালনা'}
                  </span>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>

              {/* Button 4: অডিট হিস্ট্রি */}
              <button
                type="button"
                onClick={() => setActivePopup('history')}
                className={`w-full p-3.5 sm:p-4 rounded-2xl border flex items-center justify-between transition cursor-pointer ${
                  isLight
                    ? 'bg-white border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/40 text-slate-800 shadow-2xs'
                    : 'bg-slate-800/80 border-slate-700 hover:border-slate-600 hover:bg-slate-800 text-slate-100'
                }`}
                id="btn-popup-audit-history"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-600 flex items-center justify-center shrink-0 shadow-xs">
                    <History className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold tracking-tight">
                    {isEn ? 'Audit History' : 'অডিট হিস্ট্রি'}
                  </span>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 2: 👤 আমার প্রোফাইল পপ আপ (PROFILE INFO POPUP MODAL)
          ========================================================================= */}
      {activePopup === 'profile' && (
        <div className={modalContainerClasses} id="popup-profile-info-modal">
          {/* Header */}
          <div
            className={`flex items-center justify-between px-5 py-4 border-b ${
              isLight
                ? 'border-sky-100 bg-sky-50/80 text-sky-950'
                : 'border-slate-700/80 bg-slate-800/90 text-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setActivePopup(null)}
                className={`p-1.5 rounded-xl ${
                  isLight
                    ? 'text-slate-600 hover:text-slate-900 hover:bg-white'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700'
                } transition cursor-pointer`}
                title={isEn ? 'Back' : 'ফিরে যান'}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div
                className="p-2 rounded-xl text-white shadow-xs flex items-center justify-center"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <User className="w-4 h-4" />
              </div>
              <h2 className="text-base sm:text-lg font-bold">
                {isEn ? 'Personal Information' : 'ব্যক্তিগত তথ্য'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className={`p-2 rounded-full ${
                isLight
                  ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              } transition cursor-pointer`}
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form Body */}
          <form onSubmit={handleSaveProfileSubmit} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
            {profileSuccessMsg && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 shrink-0" />
                <span>{profileSuccessMsg}</span>
              </div>
            )}

            {/* Profile Photo / Logo */}
            <div className="flex flex-col items-center justify-center gap-2 py-2">
              <div className="relative group">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 shadow-lg overflow-hidden flex items-center justify-center cursor-pointer transition transform hover:scale-105 ${
                    isLight
                      ? 'border-sky-100 bg-sky-50 text-sky-800 hover:border-sky-300'
                      : 'border-slate-700 bg-slate-800 text-slate-300 hover:border-slate-500'
                  }`}
                  style={{ borderColor: avatarUrl ? dualAccent.primary.hex : undefined }}
                >
                  {avatarUrl ? (
                    <img
                      src={avatarUrl}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center p-2 text-center">
                      <User className="w-8 h-8 sm:w-10 sm:h-10 mb-1 opacity-70" />
                      <span className="text-[10px] font-bold opacity-80">
                        {isEn ? 'Upload Photo' : 'ছবি যোগ করুন'}
                      </span>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-0 right-0 p-2 rounded-full text-white shadow-lg cursor-pointer transform hover:scale-110 transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                  title={isEn ? 'Upload Photo' : 'ছবি আপলোড করুন'}
                >
                  <Camera className="w-4 h-4" />
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  {isEn ? 'Profile Photo / Logo' : 'প্রোফাইলের ছবি বা লোগো'}
                </span>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={() => setAvatarUrl('')}
                    className="text-[11px] text-rose-500 hover:underline cursor-pointer"
                  >
                    {isEn ? 'Remove' : 'মুছুন'}
                  </button>
                )}
              </div>
            </div>

            {/* First & Last Name */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold mb-1.5 opacity-90">
                  {isEn ? 'First Name' : 'নামের প্রথম অংশ'}
                </label>
                <input
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder={isEn ? 'e.g. Onu' : 'যেমন: অনু'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  } outline-hidden focus:ring-2`}
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1.5 opacity-90">
                  {isEn ? 'Last Name' : 'নামের শেষ অংশ'}
                </label>
                <input
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder={isEn ? 'e.g. Sultan' : 'যেমন: সুলতান'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  } outline-hidden focus:ring-2`}
                />
              </div>
            </div>

            {/* Security PIN */}
            <div
              className={`p-3.5 rounded-2xl border ${
                isLight ? 'bg-sky-50/50 border-sky-100' : 'bg-slate-800/80 border-slate-700'
              } space-y-2`}
            >
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-amber-500" />
                  <span>{isEn ? 'Security PIN' : 'হিসাব পরিবর্তন/ডিলিট পিন'}</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-xs text-sky-500 flex items-center gap-1 cursor-pointer"
                >
                  {showPassword ? (
                    <EyeOff className="w-3.5 h-3.5" />
                  ) : (
                    <Eye className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {showPassword ? (isEn ? 'Hide' : 'লুকান') : isEn ? 'Show' : 'দেখান'}
                  </span>
                </button>
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isEn ? 'Enter PIN (e.g. 4 digits)' : 'এন্টার পিন (যেমন ৪ সংখ্যা)'}
                className={`w-full px-3 py-2 rounded-xl border text-sm font-mono tracking-widest ${
                  isLight
                    ? 'bg-white border-slate-200 text-slate-900'
                    : 'bg-slate-800 border-slate-700 text-slate-100'
                } outline-hidden focus:ring-2`}
              />
              <p className="text-[11px] text-slate-400">
                {isEn
                  ? 'Optional PIN to protect modifying or deleting saved transactions.'
                  : 'পুরাতন কোনো হিসাব এডিট অথবা ডিলিট সুরক্ষিত রাখতে পিন সেট করতে পারেন (ঐচ্ছিক)।'}
              </p>
            </div>

            {/* Save Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 px-6 rounded-2xl text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition cursor-pointer"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <Save className="w-4 h-4" />
                <span>{isEn ? 'Save Profile' : 'প্রোফাইল সংরক্ষণ করুন'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          VIEW: ☁️ ক্লাউড আইডি ও মাল্টি-ডিভাইস সিঙ্ক পপ আপ (CLOUD SYNC MODAL)
          ========================================================================= */}
      {activePopup === 'cloud_sync' && (
        <div className={modalContainerClasses} id="popup-cloud-sync-modal">
          {/* Header */}
          <div
            className={`flex items-center justify-between px-5 py-4 border-b ${
              isLight
                ? 'border-sky-100 bg-sky-50/80 text-sky-950'
                : 'border-slate-700/80 bg-slate-800/90 text-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setActivePopup(null)}
                className={`p-1.5 rounded-xl ${
                  isLight
                    ? 'text-slate-600 hover:text-slate-900 hover:bg-white'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700'
                } transition cursor-pointer`}
                title={isEn ? 'Back' : 'ফিরে যান'}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div
                className="p-2 rounded-xl text-white shadow-xs flex items-center justify-center"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <Cloud className="w-4 h-4" />
              </div>
              <h2 className="text-base sm:text-lg font-bold">
                {isEn ? 'Cloud ID & Multi-Device Sync' : 'ক্লাউড আইডি ও মাল্টি-ডিভাইস সিঙ্ক'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className={`p-2 rounded-full ${
                isLight
                  ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              } transition cursor-pointer`}
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh]">
            {/* Status Notifications */}
            {syncStatusMsg && (
              <div
                className={`p-3.5 rounded-2xl border text-xs font-bold flex items-center gap-2 ${
                  syncStatusMsg.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-500'
                }`}
              >
                {syncStatusMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{syncStatusMsg.text}</span>
              </div>
            )}

            {/* If user already has a User ID linked */}
            {userProfile?.userId ? (
              <>
                {/* Active ID Card */}
                <div
                  className={`p-4 rounded-2xl border ${
                    isLight
                      ? 'bg-sky-50/70 border-sky-200'
                      : 'bg-slate-800/80 border-slate-700'
                  } space-y-3`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                      {isEn ? 'Your Unique Cloud User ID' : 'আপনার নিবন্ধিত ইউজার আইডি'}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 inline-flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      {isEn ? 'Cloud Linked' : 'ক্লাউড সংযুক্ত'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    <span className="font-mono font-black text-base sm:text-lg text-slate-800 dark:text-slate-100">
                      {userProfile.userId}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyUserId}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition cursor-pointer"
                      title={isEn ? 'Copy User ID' : 'আইডি কপি করুন'}
                    >
                      {copiedId ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">{isEn ? 'Copied' : 'কপি হয়েছে'}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>{isEn ? 'Copy' : 'কপি করুন'}</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-[11px] text-slate-400 flex items-center justify-between">
                    <span>{isEn ? 'Last Cloud Sync:' : 'সর্বশেষ সিঙ্ক:'}</span>
                    <span className="font-medium text-slate-600 dark:text-slate-300">
                      {userProfile.lastSyncedAt
                        ? new Date(userProfile.lastSyncedAt).toLocaleString()
                        : isEn
                        ? 'Recently'
                        : 'সম্প্রতি'}
                    </span>
                  </div>
                </div>

                {/* Instant Manual Sync Button */}
                <button
                  type="button"
                  onClick={handleManualSyncNow}
                  disabled={isSyncing}
                  className="w-full py-3.5 px-4 rounded-2xl text-white font-extrabold text-sm shadow-md flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer disabled:opacity-50"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>
                    {isSyncing
                      ? isEn
                        ? 'Synchronizing...'
                        : 'সিঙ্ক হচ্ছে...'
                      : isEn
                      ? 'Sync Now (Push to Cloud)'
                      : 'এখনই সিঙ্ক করুন (সকল হিসাব ক্লাউডে পাঠান)'}
                  </span>
                </button>

                {/* Multi-Device Instructions Guide */}
                <div
                  className={`p-4 rounded-2xl border ${
                    isLight
                      ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                      : 'bg-amber-950/20 border-amber-800/40 text-amber-200'
                  } space-y-2 text-xs`}
                >
                  <div className="font-black flex items-center gap-2 text-sm">
                    <Smartphone className="w-4 h-4 text-amber-600" />
                    <span>{isEn ? 'How to sync on a new phone?' : 'মোবাইল পরিবর্তন বা অন্য ফোনে কীভাবে ব্যবহার করবেন?'}</span>
                  </div>
                  <ol className="list-decimal pl-4 space-y-1.5 opacity-90 leading-relaxed">
                    <li>
                      {isEn
                        ? 'Open or install Onu Finance on your new device.'
                        : 'নতুন মোবাইলে Onu Finance অ্যাপটি ইন্সটল বা ওপেন করুন।'}
                    </li>
                    <li>
                      {isEn
                        ? 'On the initial welcome screen, select "Sync Existing ID".'
                        : 'প্রথম স্ক্রিনে "পূর্বের আইডি সিঙ্ক" ট্যাব নির্বাচন করুন।'}
                    </li>
                    <li>
                      {isEn
                        ? `Enter your User ID (${userProfile.userId}) and your password.`
                        : `আপনার এই ইউজার আইডি (${userProfile.userId}) ও পাসওয়ার্ড দিন।`}
                    </li>
                    <li>
                      {isEn
                        ? 'Click "Restore & Sync All Data". All accounts, transactions, and categories will automatically appear!'
                        : '"পূর্বের সকল হিসাব সিঙ্ক করুন" বাটনে চাপলেই আগের সব লেনদেন ও হিসাব নিমিষেই চলে আসবে!'}
                    </li>
                  </ol>
                </div>
              </>
            ) : (
              /* If no User ID yet: Registration form */
              <form onSubmit={handleSaveCloudCredentials} className="space-y-4">
                <div className="text-xs text-slate-500 leading-relaxed">
                  {isEn
                    ? 'You have not linked a Cloud User ID yet. Create one now to enable multi-device synchronization and effortless data restore when changing phones.'
                    : 'আপনার এখনো ক্লাউড ইউজার আইডি তৈরি করা নেই। একাধিক ডিভাইসে ও মোবাইল পরিবর্তনের পর হিসাব রিস্টোর করতে এখনই একটি ইউজার আইডি ও পাসওয়ার্ড নির্ধারণ করুন।'}
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1 opacity-90">
                    {isEn ? 'Desired User ID *' : 'কাঙ্ক্ষিত ইউজার আইডি *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={registerNewId}
                    onChange={(e) =>
                      setRegisterNewId(e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ''))
                    }
                    placeholder="e.g. onu_2026"
                    className={`w-full px-3 py-2.5 rounded-xl border text-sm font-mono font-bold ${
                      isLight
                        ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                        : 'bg-slate-800 border-slate-700 text-slate-100'
                    } outline-hidden focus:ring-2`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1 opacity-90">
                    {isEn ? 'Sync Password *' : 'সিঙ্ক পাসওয়ার্ড *'}
                  </label>
                  <div className="relative">
                    <input
                      type={showCloudPassword ? 'text' : 'password'}
                      required
                      value={registerNewPassword}
                      onChange={(e) => setRegisterNewPassword(e.target.value)}
                      placeholder={isEn ? 'Min 4 characters' : 'কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড'}
                      className={`w-full px-3 py-2.5 pr-10 rounded-xl border text-sm font-mono ${
                        isLight
                          ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                          : 'bg-slate-800 border-slate-700 text-slate-100'
                      } outline-hidden focus:ring-2`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowCloudPassword(!showCloudPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showCloudPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSyncing}
                  className="w-full py-3.5 px-4 rounded-2xl text-white font-extrabold text-sm shadow-md flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer disabled:opacity-50"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  <Cloud className="w-4 h-4" />
                  <span>
                    {isSyncing
                      ? isEn
                        ? 'Creating & Syncing...'
                        : 'আইডি তৈরি ও সিঙ্ক হচ্ছে...'
                      : isEn
                      ? 'Register User ID & Sync All Data'
                      : 'ইউজার আইডি নিবন্ধন ও সকল হিসাব সিঙ্ক করুন'}
                  </span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 3: 📜 অডিট হিস্ট্রি পপ আপ (AUDIT HISTORY POPUP MODAL)
          ========================================================================= */}
      {activePopup === 'history' && (
        <div className={modalContainerClasses} id="popup-audit-history-modal">
          {/* Header */}
          <div
            className={`flex items-center justify-between px-5 py-4 border-b ${
              isLight
                ? 'border-indigo-100 bg-indigo-50/80 text-sky-950'
                : 'border-slate-700/80 bg-slate-800/90 text-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setActivePopup(null)}
                className={`p-1.5 rounded-xl ${
                  isLight
                    ? 'text-slate-600 hover:text-slate-900 hover:bg-white'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700'
                } transition cursor-pointer`}
                title={isEn ? 'Back' : 'ফিরে যান'}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-600 shadow-xs flex items-center justify-center">
                <History className="w-4 h-4" />
              </div>
              <h2 className="text-base sm:text-lg font-bold">
                {isEn ? 'Audit History' : 'অডিট হিস্ট্রি'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className={`p-2 rounded-full ${
                isLight
                  ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              } transition cursor-pointer`}
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Search, Filter & History Body */}
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-3.5">
            {/* Search Input & Clear History */}
            <div className="flex items-center gap-2">
              <div
                className={`relative flex-1 rounded-xl border flex items-center px-3 py-2 ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 focus-within:bg-white'
                    : 'bg-slate-800 border-slate-700 text-slate-100'
                }`}
              >
                <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  placeholder={isEn ? 'Search history...' : 'হিস্ট্রি খুঁজুন...'}
                  className="w-full bg-transparent text-xs outline-hidden"
                />
                {historySearch && (
                  <button
                    type="button"
                    onClick={() => setHistorySearch('')}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {onClearHistory && safeAuditLogs.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (
                      confirm(
                        isEn
                          ? 'Are you sure you want to clear all audit history logs?'
                          : 'আপনি কি নিশ্চিত সমস্ত অডিট হিস্ট্রি লগ মুছে ফেলতে চান?'
                      )
                    ) {
                      onClearHistory();
                    }
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-bold text-rose-500 hover:bg-rose-500/10 border border-rose-500/20 transition cursor-pointer flex items-center gap-1.5 shrink-0"
                  title={isEn ? 'Clear History' : 'হিস্ট্রি মুছুন'}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isEn ? 'Clear' : 'মুছুন'}</span>
                </button>
              )}
            </div>

            {/* Filter Chips */}
            <div className="flex items-center gap-2 text-xs font-bold">
              <button
                type="button"
                onClick={() => setHistoryFilter('all')}
                className={`px-3 py-1.5 rounded-xl border transition cursor-pointer ${
                  historyFilter === 'all'
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : isLight
                    ? 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    : 'bg-slate-800 border-slate-700 text-slate-300'
                }`}
              >
                {isEn ? 'All' : 'সবগুলো'} (
                {appSettings.useBanglaDigits
                  ? toBanglaDigits(safeAuditLogs.length)
                  : safeAuditLogs.length}
                )
              </button>

              <button
                type="button"
                onClick={() => setHistoryFilter('EDIT')}
                className={`px-3 py-1.5 rounded-xl border transition cursor-pointer ${
                  historyFilter === 'EDIT'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                    : isLight
                    ? 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    : 'bg-slate-800 border-slate-700 text-slate-300'
                }`}
              >
                {isEn ? 'Edited' : 'এডিট করা হিসাব'}
              </button>

              <button
                type="button"
                onClick={() => setHistoryFilter('DELETE')}
                className={`px-3 py-1.5 rounded-xl border transition cursor-pointer ${
                  historyFilter === 'DELETE'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                    : isLight
                    ? 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    : 'bg-slate-800 border-slate-700 text-slate-300'
                }`}
              >
                {isEn ? 'Deleted' : 'ডিলিট করা হিসাব'}
              </button>
            </div>

            {/* Log Entries List */}
            <div className="space-y-2.5 pt-1">
              {filteredLogs.length === 0 ? (
                <div
                  className={`p-6 rounded-2xl border text-center ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-500'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400'
                  }`}
                >
                  <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  <p className="text-xs font-semibold">
                    {isEn ? 'No audit history records found.' : 'কোনো হিস্ট্রি রেকর্ড পাওয়া যায়নি।'}
                  </p>
                </div>
              ) : (
                filteredLogs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const isDelete = log.action === 'DELETE';

                  return (
                    <div
                      key={log.id}
                      className={`p-3.5 rounded-2xl border transition ${
                        isLight
                          ? 'bg-white border-slate-200 shadow-2xs'
                          : 'bg-slate-800/80 border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md uppercase ${
                              isDelete
                                ? 'bg-rose-500/15 text-rose-600 border border-rose-500/30'
                                : 'bg-amber-500/15 text-amber-600 border border-amber-500/30'
                            }`}
                          >
                            {isDelete
                              ? isEn
                                ? 'DELETED'
                                : 'ডিলিট'
                              : isEn
                              ? 'EDITED'
                              : 'এডিট'}
                          </span>

                          <div className="flex items-center gap-1 text-[11px] text-slate-400">
                            <Calendar className="w-3 h-3" />
                            <span>{log.dateTimeFormatted}</span>
                          </div>
                        </div>

                        {(log.previousSnapshot || log.newSnapshot) && (
                          <button
                            type="button"
                            onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                            className="text-[11px] font-bold text-sky-500 hover:underline cursor-pointer"
                          >
                            {isExpanded
                              ? isEn
                                ? 'Hide Details'
                                : 'সংক্ষেপ করুন'
                              : isEn
                              ? 'View Details'
                              : 'বিস্তারিত'}
                          </button>
                        )}
                      </div>

                      <p className="text-xs font-bold mt-2 text-slate-800 dark:text-slate-100">
                        {isEn ? log.summaryEnglish : log.summaryBangla}
                      </p>

                      {log.userNote && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 italic">
                          {log.userNote}
                        </p>
                      )}

                      {/* Detailed Snapshot Diff */}
                      {isExpanded && (log.previousSnapshot || log.newSnapshot) && (
                        <div
                          className={`mt-2.5 p-2.5 rounded-xl border text-[11px] space-y-1.5 ${
                            isLight
                              ? 'bg-slate-50 border-slate-200 text-slate-700'
                              : 'bg-slate-900/80 border-slate-700 text-slate-300'
                          }`}
                        >
                          {log.previousSnapshot && (
                            <div>
                              <span className="font-bold text-rose-500">
                                {isEn ? 'Previous: ' : 'পূর্ববর্তী: '}
                              </span>
                              <span>
                                {typeof log.previousSnapshot.amount === 'number'
                                  ? `৳${log.previousSnapshot.amount} `
                                  : ''}
                                {log.previousSnapshot.note || log.previousSnapshot.categoryNameBangla || ''}
                              </span>
                            </div>
                          )}

                          {log.newSnapshot && (
                            <div>
                              <span className="font-bold text-emerald-500">
                                {isEn ? 'Updated: ' : 'নতুন: '}
                              </span>
                              <span>
                                {typeof log.newSnapshot.amount === 'number'
                                  ? `৳${log.newSnapshot.amount} `
                                  : ''}
                                {log.newSnapshot.note || log.newSnapshot.categoryNameBangla || ''}
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
