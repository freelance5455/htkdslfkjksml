import React, { useState, useEffect } from 'react';
import {
  X,
  User as UserIcon,
  Mail,
  Shield,
  ShieldCheck,
  LogOut,
  Check,
  CheckCircle2,
  Bookmark,
  Calendar,
  Edit2,
  LogIn,
  UserPlus,
  Bell,
  Sun,
  Moon,
  ExternalLink,
  Lock,
  Sparkles
} from 'lucide-react';
import { updateProfile, User } from 'firebase/auth';
import { userSignOut, updateUserProfileInFirestore } from '../lib/firebase';

export interface UserProfileModalProps {
  user: User | null;
  isOpen: boolean;
  onClose: () => void;
  savedJobsCount: number;
  onOpenSavedJobs: () => void;
  onSignOut: () => void;
  isAdmin?: boolean;
  onOpenAdminPanel?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
  onOpenAlerts?: () => void;
  onOpenAuth?: (tab?: 'signin' | 'register') => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  isOpen,
  onClose,
  savedJobsCount,
  onOpenSavedJobs,
  onSignOut,
  isAdmin = false,
  onOpenAdminPanel,
  theme = 'dark',
  onToggleTheme,
  onOpenAlerts,
  onOpenAuth
}) => {
  const [displayName, setDisplayName] = useState<string>(user?.displayName || '');
  const [editName, setEditName] = useState<string>(user?.displayName || '');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Sync internal state when user prop changes
  useEffect(() => {
    if (user?.displayName) {
      setDisplayName(user.displayName);
      setEditName(user.displayName);
    } else {
      setDisplayName('');
      setEditName('');
    }
    setIsEditing(false);
    setError(null);
  }, [user]);

  if (!isOpen) return null;

  const isLight = theme === 'light';

  // Determine provider type safely from real providerData
  const isGoogleUser = user?.providerData.some((p) => p.providerId === 'google.com') ?? false;
  const isPasswordUser = user?.providerData.some((p) => p.providerId === 'password') ?? false;

  const accountTypeLabel = isGoogleUser
    ? 'Google Sign-In'
    : isPasswordUser
    ? 'Email OTP & Password'
    : user
    ? 'Registered Citizen'
    : 'Guest Session';

  // Format creation date safely without inventing data
  const formatMemberSince = (timeStr?: string): string => {
    if (!timeStr) return 'Active Member';
    try {
      const date = new Date(timeStr);
      if (isNaN(date.getTime())) return 'Active Member';
      return date.toLocaleDateString('en-IN', {
        month: 'short',
        year: 'numeric'
      });
    } catch {
      return 'Active Member';
    }
  };

  // Generate 1-2 letter initials
  const getInitials = (): string => {
    const source = displayName.trim() || user?.email || 'Job Aspirant';
    const parts = source.split(/[\s._@]+/).filter(Boolean);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return source.slice(0, 2).toUpperCase();
  };

  // Handle saving updated display name
  const handleSaveProfile = async () => {
    if (!user || !editName.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const trimmed = editName.trim();
      // 1. Update Firebase Auth user profile
      await updateProfile(user, { displayName: trimmed });
      // 2. Update Firestore user document
      await updateUserProfileInFirestore(user.uid, { displayName: trimmed });
      setDisplayName(trimmed);
      setIsEditing(false);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2500);
    } catch (err: any) {
      console.warn('Profile update error:', err);
      setError(err.message || 'Failed to update name.');
    } finally {
      setSaving(false);
    }
  };

  // Handle user logout
  const handleLogout = async () => {
    try {
      await userSignOut();
      onSignOut();
      onClose();
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="user-profile-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="modal-user-profile"
        className={`relative w-full max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 my-auto border transition-colors max-h-[92vh] overflow-y-auto ${
          isLight
            ? 'bg-white border-slate-200 text-slate-900 shadow-slate-300/50'
            : 'bg-slate-900 border-slate-800 text-white shadow-indigo-950/50'
        }`}
      >
        {/* ========================================================================= */}
        {/* 1. PROFILE HEADER */}
        {/* ========================================================================= */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-700/50 dark:border-slate-800">
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Avatar */}
            <div className="relative shrink-0">
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-600 via-indigo-700 to-slate-900 border-2 border-indigo-500/40 flex items-center justify-center text-white text-base font-bold shadow-md shadow-indigo-600/30 overflow-hidden">
                {user ? (
                  user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={displayName || 'User profile'}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span>{getInitials()}</span>
                  )
                ) : (
                  <UserIcon className="w-7 h-7 text-indigo-300" />
                )}
              </div>
              {/* Subtle verification badge on avatar */}
              {user?.emailVerified && (
                <div
                  title="Verified Account"
                  className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-white shadow-sm"
                >
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              )}
            </div>

            {/* User Title & Email */}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h2
                  id="user-profile-title"
                  className={`text-base font-bold tracking-tight truncate leading-tight ${
                    isLight ? 'text-slate-900' : 'text-white'
                  }`}
                >
                  {user ? displayName || user.displayName || 'Job Aspirant' : 'Guest Aspirant'}
                </h2>
                {isAdmin && (
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                    <Shield className="w-3 h-3" />
                    Admin
                  </span>
                )}
              </div>

              <p
                className={`text-xs truncate max-w-[210px] sm:max-w-[240px] mt-0.5 ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
                title={user?.email || undefined}
              >
                {user ? user.email || 'Registered Citizen' : 'Guest Session Active'}
              </p>

              {/* Email Verification Status */}
              {user && (
                <div className="mt-1 flex items-center gap-1">
                  {user.emailVerified ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Verified Email</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span>Unverified Email</span>
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Accessible Close Button */}
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
              isLight
                ? 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            aria-label="Close Profile Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {user ? (
          <>
            {/* ========================================================================= */}
            {/* 2. ACCOUNT INFORMATION */}
            {/* ========================================================================= */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className={`text-[11px] font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Account Information
                </span>
                {success && (
                  <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Updated
                  </span>
                )}
              </div>

              <div
                className={`p-3.5 rounded-2xl border text-xs divide-y ${
                  isLight
                    ? 'bg-slate-50/80 border-slate-200 divide-slate-200/80'
                    : 'bg-slate-950/60 border-slate-800/80 divide-slate-800/80'
                }`}
              >
                {/* Display Name Row (Editable) */}
                <div className="pb-2.5 flex items-center justify-between gap-2">
                  <span className={isLight ? 'text-slate-500 font-medium' : 'text-slate-400 font-medium'}>
                    Display Name
                  </span>

                  {isEditing ? (
                    <div className="flex items-center gap-1.5 max-w-[65%]">
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        placeholder="Your full name"
                        maxLength={50}
                        className={`w-full px-2.5 py-1 border rounded-lg text-xs outline-none focus:ring-2 focus:ring-indigo-500 ${
                          isLight
                            ? 'bg-white border-slate-300 text-slate-900'
                            : 'bg-slate-900 border-slate-700 text-white'
                        }`}
                      />
                      <button
                        onClick={handleSaveProfile}
                        disabled={saving || !editName.trim()}
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors disabled:opacity-50"
                        title="Save Changes"
                        aria-label="Save display name"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setIsEditing(false);
                          setEditName(displayName);
                          setError(null);
                        }}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isLight ? 'text-slate-600 hover:bg-slate-200' : 'text-slate-400 hover:bg-slate-800'
                        }`}
                        title="Cancel"
                        aria-label="Cancel editing"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className={`font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                        {displayName || 'Not Set'}
                      </span>
                      <button
                        onClick={() => {
                          setEditName(displayName);
                          setIsEditing(true);
                        }}
                        className="text-slate-400 hover:text-indigo-400 p-0.5 rounded transition-colors"
                        title="Edit Display Name"
                        aria-label="Edit display name"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Email Address Row */}
                <div className="py-2.5 flex items-center justify-between gap-2">
                  <span className={isLight ? 'text-slate-500 font-medium' : 'text-slate-400 font-medium'}>
                    Email Address
                  </span>
                  <span className={`font-semibold truncate max-w-[200px] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    {user.email || '—'}
                  </span>
                </div>

                {/* Account Type Row */}
                <div className="py-2.5 flex items-center justify-between gap-2">
                  <span className={isLight ? 'text-slate-500 font-medium' : 'text-slate-400 font-medium'}>
                    Account Type
                  </span>
                  <span
                    className={`font-semibold ${
                      isLight ? 'text-slate-700' : 'text-slate-300'
                    }`}
                  >
                    {accountTypeLabel}
                  </span>
                </div>

                {/* Member Since Row */}
                <div className="pt-2.5 flex items-center justify-between gap-2">
                  <span className={`flex items-center gap-1.5 ${isLight ? 'text-slate-500 font-medium' : 'text-slate-400 font-medium'}`}>
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    Member Since
                  </span>
                  <span className={`font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    {formatMemberSince(user.metadata.creationTime)}
                  </span>
                </div>
              </div>

              {error && (
                <p className="text-[11px] text-rose-400 font-medium px-1">
                  {error}
                </p>
              )}
            </div>

            {/* ========================================================================= */}
            {/* 3. PERSONAL ACTIVITY SHORTCUTS */}
            {/* ========================================================================= */}
            <div className="space-y-1.5">
              <span className={`text-[11px] font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Personal Activity & Shortcuts
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {/* Saved Vacancies Shortcut */}
                <button
                  id="btn-profile-saved-jobs"
                  onClick={() => {
                    onClose();
                    onOpenSavedJobs();
                  }}
                  className={`p-3 border rounded-2xl flex items-center gap-3 transition-all text-left group hover:scale-[1.01] active:scale-[0.99] ${
                    isLight
                      ? 'bg-slate-50 hover:bg-slate-100/90 border-slate-200'
                      : 'bg-slate-800/50 hover:bg-slate-800/80 border-slate-700/60'
                  }`}
                >
                  <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center shrink-0 group-hover:bg-amber-500/25 transition-colors">
                    <Bookmark className="w-4 h-4 fill-current" />
                  </div>
                  <div className="min-w-0">
                    <span className={`font-bold block truncate ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {savedJobsCount} Saved
                    </span>
                    <span className="text-[10px] text-slate-400 font-normal truncate block">
                      Bookmarked Jobs
                    </span>
                  </div>
                </button>

                {/* Job Alerts / Notifications Shortcut */}
                {onOpenAlerts ? (
                  <button
                    id="btn-profile-job-alerts"
                    onClick={() => {
                      onClose();
                      onOpenAlerts();
                    }}
                    className={`p-3 border rounded-2xl flex items-center gap-3 transition-all text-left group hover:scale-[1.01] active:scale-[0.99] ${
                      isLight
                        ? 'bg-slate-50 hover:bg-slate-100/90 border-slate-200'
                        : 'bg-slate-800/50 hover:bg-slate-800/80 border-slate-700/60'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center shrink-0 group-hover:bg-indigo-500/25 transition-colors">
                      <Bell className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className={`font-bold block truncate ${isLight ? 'text-slate-900' : 'text-white'}`}>
                        Job Alerts
                      </span>
                      <span className="text-[10px] text-slate-400 font-normal truncate block">
                        Preferences
                      </span>
                    </div>
                  </button>
                ) : (
                  <div
                    className={`p-3 border rounded-2xl flex items-center gap-3 ${
                      isLight
                        ? 'bg-slate-50 border-slate-200'
                        : 'bg-slate-800/50 border-slate-700/60'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className={`font-bold block truncate ${isLight ? 'text-slate-900' : 'text-white'}`}>
                        Active Aspirant
                      </span>
                      <span className="text-[10px] text-slate-400 font-normal truncate block">
                        Verified Status
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ========================================================================= */}
            {/* 4. ACCOUNT SETTINGS & PREFERENCES */}
            {/* ========================================================================= */}
            <div className="space-y-1.5">
              <span className={`text-[11px] font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Settings & Session
              </span>

              <div className="space-y-2">
                {/* Theme Preference Toggle */}
                {onToggleTheme && (
                  <div
                    className={`p-2.5 sm:p-3 rounded-2xl border flex items-center justify-between text-xs ${
                      isLight
                        ? 'bg-slate-50 border-slate-200'
                        : 'bg-slate-950/60 border-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
                        {isLight ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-indigo-400" />}
                      </div>
                      <div>
                        <span className={`font-semibold block ${isLight ? 'text-slate-900' : 'text-white'}`}>
                          Display Theme
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {isLight ? 'Light Theme Active' : 'Dark Navy Theme Active'}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={onToggleTheme}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all active:scale-95 ${
                        isLight
                          ? 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
                          : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                      }`}
                    >
                      {isLight ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
                      <span>Switch to {isLight ? 'Dark' : 'Light'}</span>
                    </button>
                  </div>
                )}

                {/* Admin Portal Action (Only for Authorized Admins) */}
                {isAdmin && onOpenAdminPanel && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenAdminPanel();
                    }}
                    className="w-full p-3 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white rounded-2xl flex items-center justify-between transition-all shadow-md shadow-indigo-600/20 active:scale-[0.99]"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-white/20 text-white flex items-center justify-center shrink-0">
                        <Shield className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <span className="font-bold block text-xs text-white">Administrator Portal</span>
                        <span className="text-[10px] text-indigo-200 font-normal">Manage vacancies & updates</span>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-indigo-200 mr-1" />
                  </button>
                )}

                {/* Sign Out Button */}
                <button
                  id="btn-user-signout"
                  onClick={handleLogout}
                  className="w-full py-2.5 px-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 text-rose-400 dark:text-rose-300 font-semibold text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out of India Job Hub</span>
                </button>
              </div>
            </div>
          </>
        ) : (
          /* ========================================================================= */
          /* GUEST ACCOUNT VIEW */
          /* ========================================================================= */
          <div className="space-y-3.5">
            <div
              className={`p-3.5 rounded-2xl border text-xs ${
                isLight
                  ? 'bg-slate-50 border-slate-200 text-slate-700'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-300'
              }`}
            >
              <p className="leading-relaxed">
                You are currently browsing verified job openings as a guest. Sign in or register with email OTP to sync bookmarked posts, receive personalized alert digests, and customize notifications.
              </p>
            </div>

            {/* Guest Action: Register or Sign in */}
            {onOpenAuth && (
              <div className="grid grid-cols-2 gap-2">
                <button
                  id="btn-profile-register"
                  onClick={() => {
                    onClose();
                    onOpenAuth('register');
                  }}
                  className="py-2.5 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-600/20 active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register (OTP)</span>
                </button>

                <button
                  id="btn-profile-signin"
                  onClick={() => {
                    onClose();
                    onOpenAuth('signin');
                  }}
                  className="py-2.5 px-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
              </div>
            )}

            {/* Guest Saved Jobs shortcut */}
            <button
              onClick={() => {
                onClose();
                onOpenSavedJobs();
              }}
              className={`w-full p-3 border rounded-2xl flex items-center justify-between transition-all text-left ${
                isLight
                  ? 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                  : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/15 text-amber-500 flex items-center justify-center shrink-0">
                  <Bookmark className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <span className={`font-bold block text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    {savedJobsCount} Saved Vacancies
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    View postings saved in current browser session
                  </span>
                </div>
              </div>
            </button>

            {/* Theme Toggle for Guest */}
            {onToggleTheme && (
              <div
                className={`p-2.5 rounded-2xl border flex items-center justify-between text-xs ${
                  isLight
                    ? 'bg-slate-50 border-slate-200'
                    : 'bg-slate-950/60 border-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-2">
                  {isLight ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-indigo-400" />}
                  <span className={`font-medium ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
                    {isLight ? 'Light Theme' : 'Dark Navy Theme'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={onToggleTheme}
                  className={`px-2.5 py-1 rounded-xl text-xs font-semibold border ${
                    isLight ? 'bg-white border-slate-300 text-slate-700' : 'bg-slate-800 border-slate-700 text-slate-200'
                  }`}
                >
                  Switch
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 5. FOOTER & UNOBTRUSIVE DISCLAIMER */}
        {/* ========================================================================= */}
        <div className="pt-2 border-t border-slate-700/40 dark:border-slate-800/60">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center leading-relaxed">
            India Job Hub is an independent employment portal for central and state government job alerts. Official applications must be completed on respective recruitment websites.
          </p>
        </div>
      </div>
    </div>
  );
};
