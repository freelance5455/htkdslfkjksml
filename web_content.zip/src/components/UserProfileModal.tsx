import React, { useState } from 'react';
import { 
  X, 
  User, 
  Settings, 
  Cloud, 
  HardDrive, 
  LogOut, 
  Save, 
  Sparkles, 
  Check, 
  Sliders, 
  Globe2, 
  Mic, 
  Zap,
  Box,
  Sun,
  Moon
} from 'lucide-react';
import { UserProfile, CloudStorageProvider, Language, PersonaId, VoiceSettings } from '../types/tts';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { VOICE_PERSONAS } from '../constants/personas';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  token: string | null;
  onUpdateUser: (updatedUser: UserProfile) => void;
  onLogout: () => void;
  onOpenCloudSettings: () => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  token,
  onUpdateUser,
  onLogout,
  onOpenCloudSettings,
  darkMode,
  onToggleDarkMode,
}) => {
  const [name, setName] = useState(user.name);
  const [preferredLang, setPreferredLang] = useState(user.preferredLanguage);
  const [preferredPersona, setPreferredPersona] = useState(user.preferredPersona);
  const [playbackSpeed, setPlaybackSpeed] = useState(user.playbackSpeed);
  const [preferredCloud, setPreferredCloud] = useState<CloudStorageProvider>(user.preferredCloudStorage);
  const [autoCloudUpload, setAutoCloudUpload] = useState(user.autoCloudUpload);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const updates: Partial<UserProfile> = {
        name,
        preferredLanguage: preferredLang,
        preferredPersona,
        playbackSpeed,
        preferredCloudStorage: preferredCloud,
        autoCloudUpload,
      };

      if (token) {
        const response = await fetch('/api/user/profile', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify(updates),
        });
        const data = await response.json();
        if (data.success && data.user) {
          onUpdateUser(data.user);
        } else {
          onUpdateUser({ ...user, ...updates });
        }
      } else {
        onUpdateUser({ ...user, ...updates });
      }

      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
    } catch (e) {
      onUpdateUser({ ...user, name, preferredLanguage: preferredLang, preferredPersona, playbackSpeed, preferredCloudStorage: preferredCloud, autoCloudUpload });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-md animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative space-y-5 animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-11 h-11 rounded-2xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-0.5 object-cover"
            />
            <div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-white">
                {user.name}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono">
                {user.email}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Name input */}
        <div>
          <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
            Display Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-white"
          />
        </div>

        {/* Preferred Voice Settings */}
        <div className="p-4 bg-zinc-50 dark:bg-zinc-950/60 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-violet-500" />
            Default Voice &amp; Playback Preferences
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">
                Default Language
              </label>
              <select
                value={preferredLang}
                onChange={(e) => setPreferredLang(e.target.value)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg text-zinc-900 dark:text-white"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.flag} {l.name} ({l.nativeName})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">
                Default Persona
              </label>
              <select
                value={preferredPersona}
                onChange={(e) => setPreferredPersona(e.target.value as PersonaId)}
                className="w-full mt-1 px-2.5 py-1.5 text-xs bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg text-zinc-900 dark:text-white"
              >
                {VOICE_PERSONAS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
              <span>Default Playback Speed</span>
              <span className="font-mono text-violet-500 font-bold">{playbackSpeed.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.05"
              value={playbackSpeed}
              onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
              className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
            />
          </div>

          {onToggleDarkMode && typeof darkMode === 'boolean' && (
            <div className="pt-1">
              <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 block mb-1.5">
                Appearance & Theme
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (darkMode) onToggleDarkMode();
                  }}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                    !darkMode
                      ? 'border-violet-500 bg-violet-50 text-violet-700 ring-1 ring-violet-500'
                      : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span>Light Mode</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!darkMode) onToggleDarkMode();
                  }}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                    darkMode
                      ? 'border-violet-500 bg-violet-950/40 text-violet-300 ring-1 ring-violet-500'
                      : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 text-violet-400" />
                  <span>Dark Mode</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Cloud Storage Preferences */}
        <div className="p-4 bg-zinc-50 dark:bg-zinc-950/60 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Cloud className="w-3.5 h-3.5 text-cyan-500" />
              Cloud Storage Integration
            </h4>
            <button
              onClick={() => {
                onClose();
                onOpenCloudSettings();
              }}
              className="text-[11px] font-semibold text-violet-600 dark:text-violet-400 hover:underline"
            >
              Manage Services →
            </button>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 block mb-1">
              Primary Cloud Storage Destination
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPreferredCloud('google-drive')}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  preferredCloud === 'google-drive'
                    ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 ring-1 ring-violet-500'
                    : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                <HardDrive className="w-4 h-4 text-emerald-500" />
                <span>Google Drive</span>
              </button>

              <button
                type="button"
                onClick={() => setPreferredCloud('dropbox')}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  preferredCloud === 'dropbox'
                    ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 ring-1 ring-violet-500'
                    : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                <Box className="w-4 h-4 text-blue-500" />
                <span>Dropbox</span>
              </button>

              <button
                type="button"
                onClick={() => setPreferredCloud('onedrive')}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  preferredCloud === 'onedrive'
                    ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 ring-1 ring-violet-500'
                    : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                <Cloud className="w-4 h-4 text-sky-500" />
                <span>OneDrive</span>
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-xs text-zinc-700 dark:text-zinc-300">
              Auto-save audio files to cloud after synthesis
            </span>
            <input
              type="checkbox"
              checked={autoCloudUpload}
              onChange={(e) => setAutoCloudUpload(e.target.checked)}
              className="w-4 h-4 accent-violet-600 cursor-pointer rounded"
            />
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Always Signed In</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onLogout}
              className="px-2.5 py-2 text-xs font-semibold text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl transition-all flex items-center gap-1.5"
              title="Refresh session without losing your data"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>

            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-5 py-2.5 text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow-md shadow-violet-600/30 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Preferences Saved!</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
