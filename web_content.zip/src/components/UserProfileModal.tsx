import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  User,
  ShoppingBag,
  Heart,
  Globe,
  HelpCircle,
  Shield,
  FileText,
  LogOut,
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';

export const UserProfileModal: React.FC = () => {
  const {
    userProfile,
    updateUserProfile,
    orders,
    logoutUser,
    setActiveTab,
    language,
    setLanguage,
    showToast
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(userProfile.name);
  const [phone, setPhone] = useState(userProfile.phone);
  const [targetExam, setTargetExam] = useState(userProfile.targetExam);
  const [state, setState] = useState(userProfile.state);
  const [selectedSubTab, setSelectedSubTab] = useState<'profile' | 'orders' | 'support' | 'terms'>('profile');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ name, phone, targetExam, state });
    setIsEditing(false);
    showToast('Profile details updated successfully!', 'success');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 sm:py-8">
      {/* Profile Header Banner */}
      <div className="bg-[#0B192C] text-white rounded-2xl p-6 sm:p-8 mb-6 border border-[#1E3E62] shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center font-black text-2xl shadow-md">
            {userProfile.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">
                {userProfile.name}
              </h1>
              {userProfile.isAdmin && (
                <span className="text-[10px] font-bold text-amber-950 bg-amber-400 px-2 py-0.5 rounded-full">
                  ADMIN
                </span>
              )}
            </div>
            <p className="text-xs text-amber-300 font-semibold mt-0.5">
              Target: {userProfile.targetExam}
            </p>
            <p className="text-[11px] text-slate-400">
              Student Member since {userProfile.joinedDate}
            </p>
          </div>
        </div>

        {/* Study Streak Badge */}
        <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <div className="text-left text-xs">
            <span className="text-slate-400 block font-semibold text-[10px]">Study Streak</span>
            <span className="font-extrabold text-white text-sm">
              {userProfile.studyStreakDays} Days Active 🔥
            </span>
          </div>
        </div>
      </div>

      {/* Profile Navigation Tabs */}
      <div className="border-b border-slate-200 mb-6">
        <nav className="flex items-center gap-4 sm:gap-6 overflow-x-auto text-xs sm:text-sm">
          {[
            { id: 'profile', label: 'My Profile & Exam Target', icon: User },
            { id: 'orders', label: `My Orders & Invoices (${orders.length})`, icon: ShoppingBag },
            { id: 'support', label: 'Help & WhatsApp Support', icon: HelpCircle },
            { id: 'terms', label: 'Legal & Privacy Policy', icon: Shield },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = selectedSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedSubTab(tab.id as any)}
                className={`py-3 font-bold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
                  isActive
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-500' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab 1: Profile & Exam Target */}
      {selectedSubTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          <div className="md:col-span-8 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider">
                Personal Student Information
              </h3>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs font-bold text-amber-700 hover:text-amber-900"
              >
                {isEditing ? 'Cancel Edit' : 'Edit Details'}
              </button>
            </div>

            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number (+91)</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Govt Exam</label>
                  <input
                    type="text"
                    value={targetExam}
                    onChange={(e) => setTargetExam(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Home State</label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                  >
                    <option value="Assam">Assam</option>
                    <option value="West Bengal">West Bengal</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Other">Other State</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-5 py-2.5 rounded-xl transition-colors"
                >
                  Save Profile Changes
                </button>
              </form>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Registered Email</span>
                    <span className="font-semibold text-slate-800">{userProfile.email}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Mobile Number</span>
                    <span className="font-semibold text-slate-800">{userProfile.phone}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">State</span>
                    <span className="font-semibold text-slate-800">{userProfile.state}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <Award className="w-4 h-4 text-amber-500" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Primary Exam Target</span>
                    <span className="font-bold text-amber-800">{userProfile.targetExam}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Preferences & Logout */}
          <div className="md:col-span-4 space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3 text-xs">
              <h3 className="font-bold text-[#0B192C] uppercase tracking-wider text-[11px]">
                App Language Preference
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { code: 'en', label: 'English' },
                  { code: 'as', label: 'অসমীয়া' },
                  { code: 'hi', label: 'हिंदी' },
                  { code: 'bn', label: 'বাংলা' }
                ].map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLanguage(l.code as any);
                      showToast(`Language set to ${l.label}`, 'info');
                    }}
                    className={`p-2 rounded-xl border font-bold text-center transition-colors ${
                      language === l.code
                        ? 'bg-[#0B192C] text-amber-400 border-[#0B192C]'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={logoutUser}
              className="w-full bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs p-3 rounded-xl border border-red-200 flex items-center justify-center gap-2 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out of NEXA Account</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Orders & Invoices */}
      {selectedSubTab === 'orders' && (
        <div className="space-y-4">
          {orders.map((ord) => (
            <div
              key={ord.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-2 text-xs">
                <div>
                  <span className="font-mono font-bold text-slate-900">
                    Order #{ord.orderNumber}
                  </span>
                  <span className="text-slate-400 ml-2">• {ord.createdAt}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    {ord.paymentStatus}
                  </span>
                  <span className="font-black text-[#0B192C] text-sm">
                    ₹{ord.total}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                {ord.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs text-slate-700">
                    <span className="font-semibold">{item.title}</span>
                    <span className="font-medium">{item.price === 0 ? 'FREE' : `₹${item.price}`}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">Transaction ID: {ord.transactionId}</span>
                <button
                  onClick={() => {
                    setActiveTab('my-books');
                  }}
                  className="font-bold text-amber-700 hover:text-amber-900"
                >
                  Access Ebooks in My Books →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Help & Support */}
      {selectedSubTab === 'support' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-2xl space-y-4 text-xs">
          <h3 className="font-black text-sm text-[#0B192C]">Student Helpline & Technical Support</h3>
          <p className="text-slate-600 leading-relaxed">
            Have questions regarding syllabus updates, download access, or offline HTML study packages? Our support desk is operational 6 days a week.
          </p>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <p><strong>WhatsApp Support:</strong> +91 98640 12345 (9:00 AM - 7:00 PM IST)</p>
            <p><strong>Official Email:</strong> support@nexaexambooks.com</p>
            <p><strong>Editorial Office:</strong> Lachit Nagar, Guwahati, Assam 781007</p>
          </div>
        </div>
      )}

      {/* Tab 4: Terms & Legal */}
      {selectedSubTab === 'terms' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-2xl space-y-4 text-xs text-slate-700">
          <h3 className="font-black text-sm text-[#0B192C]">Official Recruitment Disclaimer & Privacy Policy</h3>
          <p>
            NEXA EXAM BOOKS is an independent educational publisher providing exam preparation materials and practice questions for competitive examinations. We are not officially affiliated with the State Level Recruitment Commission (SLRC), SLPRB Assam, Staff Selection Commission (SSC), or Railway Recruitment Boards (RRB).
          </p>
          <p>
            Official recruitment dates, syllabi, and application links are directly retrieved from certified gazette websites to provide authentic guidance to aspirants. All purchases grant permanent personal study access.
          </p>
        </div>
      )}
    </div>
  );
};
