import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { hartHost } from '../services/hartHostService';
import { SmartImage } from './SmartImage';
import { X, Camera, User, CheckCircle, Shield, Copy, LogOut, Save, Hash } from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, profile, updateUserProfile, signOutUser, isOwner } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.displayName || user?.displayName || '');
  const [userTag, setUserTag] = useState(profile?.userTag || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [photoPreview, setPhotoPreview] = useState(profile?.photoUrl || user?.photoURL || '');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    if (profile?.displayName || user?.displayName) {
      setDisplayName(profile?.displayName || user?.displayName || '');
    }
    if (profile?.userTag) {
      setUserTag(profile.userTag);
    }
    if (profile?.bio) {
      setBio(profile.bio);
    }
    if (profile?.photoUrl || user?.photoURL) {
      setPhotoPreview(profile?.photoUrl || user?.photoURL || '');
    }
  }, [profile, user]);

  if (!isOpen || !user) return null;

  const handleCopyId = () => {
    const idToCopy = profile?.uniqueId || user.uid;
    navigator.clipboard.writeText(idToCopy);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatarFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSuccessMsg(false);

    try {
      let finalPhotoUrl = photoPreview;

      if (avatarFile) {
        // Compress avatar from phone studio and upload via Hart Host
        const optimized = await hartHost.optimizeImage(avatarFile, 400, 0.85);
        finalPhotoUrl = await hartHost.uploadMedia(optimized, 'avatars', `avatar_${user.uid}`);
      }

      await updateUserProfile({
        displayName: displayName.trim(),
        userTag: userTag.trim().replace(/^@/, '').toLowerCase().replace(/[^a-z0-9_]/g, '_'),
        bio: bio.trim(),
        photoUrl: finalPhotoUrl
      });

      setSuccessMsg(true);
      setTimeout(() => {
        setSuccessMsg(false);
        onClose();
      }, 1500);
    } catch (err) {
      console.error('Failed to update profile:', err);
      alert('حدث خطأ أثناء تحديث الملف الشخصي');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative max-h-[92vh] overflow-y-auto no-scrollbar">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-white mb-4">الملف الشخصي والحساب</h2>

        <form onSubmit={handleSave} className="space-y-4">
          
          {/* Avatar Uploader from Phone Gallery */}
          <div className="flex flex-col items-center justify-center mb-2">
            <div className="relative group cursor-pointer">
              <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-purple-500/50 shadow-xl bg-[#171f33] flex items-center justify-center">
                {photoPreview ? (
                  <SmartImage
                    src={photoPreview}
                    alt="Avatar"
                    className="w-full h-full object-cover"
                    containerClassName="w-full h-full"
                    showFallbackText={false}
                  />
                ) : (
                  <User className="w-10 h-10 text-gray-500" />
                )}
              </div>

              <label className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold transition-opacity cursor-pointer">
                <Camera className="w-5 h-5 mb-0.5" />
                <span>تغيير الصورة</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarSelect}
                  className="hidden"
                />
              </label>
            </div>
            
            <span className="text-[11px] text-gray-400 mt-2">
              اضغط على الصورة لرفعها مباشرة من استوديو هاتفك
            </span>

            {/* Role Badge */}
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-purple-900/40 text-purple-300 border border-purple-500/30">
              <Shield className="w-3.5 h-3.5 text-pink-400" />
              <span>
                {isOwner
                  ? 'مالك مانهوا هارت (Owner)'
                  : profile?.role === 'team_leader'
                  ? 'قائد فريق ترجمة'
                  : profile?.role === 'publisher'
                  ? 'ناشر معتمد'
                  : 'قارئ مانهوا'}
              </span>
            </div>
          </div>

          {/* PERMANENT UNIQUE ID BOX (CRITICAL REQUIREMENT 1) */}
          <div className="bg-[#151b2d] p-3.5 rounded-2xl border border-purple-500/30">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-gray-300 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-purple-400" />
                <span>معرّف الحساب الفريد (User ID)</span>
              </span>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800/40">
                ثابت ودائم
              </span>
            </div>

            <div className="flex items-center justify-between gap-2 bg-[#0c101d] px-3 py-2 rounded-xl border border-white/5">
              <span className="font-mono font-black text-sm text-purple-300 tracking-wider dir-ltr select-all">
                {profile?.uniqueId || user.uid.substring(0, 9).toUpperCase()}
              </span>

              <button
                type="button"
                onClick={handleCopyId}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600/30 hover:bg-purple-600/60 border border-purple-500/40 text-purple-200 rounded-lg text-xs font-bold transition-all active:scale-95"
              >
                {copiedId ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-purple-300" />
                    <span>نسخ المعرّف</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[10px] text-gray-400 mt-2 leading-relaxed">
              هذا المعرّف مخصص لحسابك فقط ولا يتكرر؛ يمكنك نسخه ومشاركته مع قادة الفرق لدعوتك للانضمام لطواقم الترجمة والنشر.
            </p>
          </div>

          {/* Display Name & UserTag */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1">اسم العرض *</label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1">اسم المستخدم (@Tag)</label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-xs text-gray-500 font-bold">@</span>
                <input
                  type="text"
                  value={userTag}
                  onChange={(e) => setUserTag(e.target.value.replace(/^@/, ''))}
                  placeholder="username"
                  className="w-full bg-[#151b2d] border border-white/10 rounded-xl pl-8 pr-4 py-2 text-xs text-white outline-none focus:border-purple-500 dir-ltr text-right"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">البريد الإلكتروني</label>
            <input
              type="text"
              disabled
              value={user.email || ''}
              className="w-full bg-[#0d121f] border border-white/5 rounded-xl px-4 py-2.5 text-xs text-gray-400 cursor-not-allowed dir-ltr text-right"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-300 mb-1">نبذة عنك (Bio)</label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="اكتب نبذة قصيرة عن اهتماماتك بالمانهوا والترجمة..."
              className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
            />
          </div>

          {successMsg && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>تم تحديث وحفظ بياناتك بنجاح!</span>
            </div>
          )}

          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={signOutUser}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-red-400 hover:text-red-300 bg-red-950/30 hover:bg-red-950/60 rounded-xl border border-red-500/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>تسجيل الخروج</span>
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'جاري الحفظ...' : 'حفظ التعديلات'}</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
