import React from 'react';
import {
  X,
  BookOpen,
  Star,
  Bookmark,
  Download,
  Share2,
  Droplet,
  HelpCircle,
  Award,
  ChevronRight,
  Sparkles,
  Smartphone
} from 'lucide-react';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedClass: '11' | '12';
  onChangeClass: (c: '11' | '12') => void;
  onOpenPremium: () => void;
  onOpenTheme: () => void;
  onOpenShare: () => void;
  onOpenBookmarks: () => void;
  onOpenDownloads: () => void;
  bookmarkCount: number;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  selectedClass,
  onChangeClass,
  onOpenPremium,
  onOpenTheme,
  onOpenShare,
  onOpenBookmarks,
  onOpenDownloads,
  bookmarkCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Container */}
      <div className="relative w-80 max-w-[85vw] bg-white h-full shadow-2xl flex flex-col z-10 overflow-y-auto">
        {/* Drawer Header with Teal Gradient */}
        <div className="bg-gradient-to-br from-[#00838f] to-[#006064] text-white p-5 space-y-3 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-sm border border-white/20 flex items-center justify-center shadow-inner">
            <span className="text-2xl">🧬</span>
          </div>

          <div>
            <h2 className="text-base font-bold tracking-tight font-devanagari">
              जीव विज्ञान साथी (NCERT)
            </h2>
            <p className="text-xs text-teal-100 font-medium">
              कक्षा {selectedClass} हिंदी माध्यम अध्ययन पोर्टल
            </p>
          </div>

          {/* Class Switcher inside drawer */}
          <div className="flex items-center gap-1 bg-black/25 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => onChangeClass('11')}
              className={`flex-1 py-1 rounded-lg transition-colors ${
                selectedClass === '11' ? 'bg-white text-teal-900 shadow-xs' : 'text-teal-100 hover:text-white'
              }`}
            >
              कक्षा 11वीं
            </button>
            <button
              onClick={() => onChangeClass('12')}
              className={`flex-1 py-1 rounded-lg transition-colors ${
                selectedClass === '12' ? 'bg-white text-teal-900 shadow-xs' : 'text-teal-100 hover:text-white'
              }`}
            >
              कक्षा 12वीं
            </button>
          </div>
        </div>

        {/* Drawer Menu List */}
        <div className="py-2 flex-1 text-sm font-devanagari text-slate-700">
          <button
            onClick={() => {
              onClose();
              onOpenPremium();
            }}
            className="w-full px-5 py-3 flex items-center justify-between text-amber-700 bg-amber-50/70 hover:bg-amber-100/70 border-y border-amber-200 transition-colors font-bold"
          >
            <div className="flex items-center gap-3">
              <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
              <span>प्रीमियम अनलॉक करें (No Ads)</span>
            </div>
            <Sparkles className="w-4 h-4 text-amber-500" />
          </button>

          <div className="px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
            मुख्य सामग्री
          </div>

          <button
            onClick={() => {
              onClose();
            }}
            className="w-full px-5 py-2.5 flex items-center gap-3.5 hover:bg-slate-50 transition-colors text-slate-800 font-medium"
          >
            <BookOpen className="w-5 h-5 text-teal-600" />
            <span>कक्षा {selectedClass} संपूर्ण नोट्स (1-19)</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenBookmarks();
            }}
            className="w-full px-5 py-2.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-800 font-medium"
          >
            <div className="flex items-center gap-3.5">
              <Bookmark className="w-5 h-5 text-amber-500" />
              <span>सहेजे गए बुकमार्क</span>
            </div>
            {bookmarkCount > 0 && (
              <span className="text-xs font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                {bookmarkCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenDownloads();
            }}
            className="w-full px-5 py-2.5 flex items-center gap-3.5 hover:bg-slate-50 transition-colors text-slate-800 font-medium"
          >
            <Smartphone className="w-5 h-5 text-indigo-600" />
            <span>Android APK व सोर्स कोड (ZIP)</span>
          </button>

          <div className="my-2 border-t border-slate-100" />

          <div className="px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
            सेटिंग्स व सहूलियत
          </div>

          <button
            onClick={() => {
              onClose();
              onOpenTheme();
            }}
            className="w-full px-5 py-2.5 flex items-center gap-3.5 hover:bg-slate-50 transition-colors text-slate-800 font-medium"
          >
            <Droplet className="w-5 h-5 text-sky-600" />
            <span>रीडिंग थीम (दिन / आई-केयर / नाइट)</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenShare();
            }}
            className="w-full px-5 py-2.5 flex items-center gap-3.5 hover:bg-slate-50 transition-colors text-slate-800 font-medium"
          >
            <Share2 className="w-5 h-5 text-emerald-600" />
            <span>मित्रों के साथ शेयर करें</span>
          </button>
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 text-[11px] text-slate-500 flex items-center justify-between">
          <span>संस्करण 3.2.0 (Hindi Edition)</span>
          <span className="text-teal-700 font-bold">NCERT 2026-27</span>
        </div>
      </div>
    </div>
  );
};
