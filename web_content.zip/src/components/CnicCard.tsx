import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Sparkles,
  FileSpreadsheet,
  Trash2,
  Copy,
  Check,
  Search,
  MapPin,
  User,
  ShieldCheck,
} from 'lucide-react';
import { CNICRecord, Language, SIMSlot } from '../types';
import {
  cleanCNIC,
  isValidCNIC,
  formatCNIC,
  getProvinceFromCNIC,
  getGenderFromCNIC,
  generateSampleCNIC,
} from '../utils/cnic';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface CnicCardProps {
  records: CNICRecord[];
  selectedIndex: number;
  onSelectRecord: (index: number) => void;
  onAddRecord: (record: CNICRecord) => void;
  onDeleteRecord: (id: string) => void;
  selectedSim: SIMSlot;
  operator: string;
  language: Language;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const CnicCard: React.FC<CnicCardProps> = ({
  records,
  selectedIndex,
  onSelectRecord,
  onAddRecord,
  onDeleteRecord,
  selectedSim,
  operator,
  language,
  onShowToast,
}) => {
  const tr = t[language];
  const [inputVal, setInputVal] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showBulkModal, setShowBulkModal] = useState<boolean>(false);
  const [bulkInput, setBulkInput] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const cleanVal = cleanCNIC(inputVal);
  const isInputValid = isValidCNIC(inputVal);
  const province = cleanVal.length > 0 ? getProvinceFromCNIC(cleanVal) : null;
  const gender = cleanVal.length === 13 ? getGenderFromCNIC(cleanVal) : null;

  const handleAdd = () => {
    if (!isInputValid) {
      sounds.playError();
      onShowToast(tr.invalidCnicAlert, 'warning');
      return;
    }

    if (records.some((r) => r.cnic === cleanVal)) {
      sounds.playError();
      onShowToast(tr.duplicateCnicAlert, 'warning');
      return;
    }

    const newRecord: CNICRecord = {
      id: `cnic-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      cnic: cleanVal,
      sim: `${selectedSim} (${operator})`,
      time: new Date().toLocaleTimeString(),
      status: 'Added',
      province: province ? province.en : undefined,
      gender: gender ? gender.en : undefined,
    };

    onAddRecord(newRecord);
    setInputVal('');
    sounds.playSuccess();
    onShowToast(language === 'ur' ? 'CNIC ریکارڈ کامیابی سے شامل ہو گیا' : 'CNIC added to records', 'success');
  };

  const handleGenerateSample = () => {
    const sample = generateSampleCNIC();
    setInputVal(sample);
    sounds.playClick();
  };

  const handleBulkSubmit = () => {
    const rawTokens = bulkInput.split(/[\n,\s]+/);
    const validTokens = Array.from(new Set(rawTokens.map(cleanCNIC).filter((c) => /^\d{13}$/.test(c))));

    if (validTokens.length === 0) {
      onShowToast(language === 'ur' ? 'کوئی درست 13 ہندسوں کا CNIC نہیں ملا' : 'No valid 13-digit CNICs found in bulk input', 'warning');
      return;
    }

    let addedCount = 0;
    validTokens.forEach((c) => {
      if (!records.some((r) => r.cnic === c)) {
        const prov = getProvinceFromCNIC(c);
        const gen = getGenderFromCNIC(c);
        onAddRecord({
          id: `cnic-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          cnic: c,
          sim: `${selectedSim} (${operator})`,
          time: new Date().toLocaleTimeString(),
          status: 'Added',
          province: prov.en,
          gender: gen.en,
        });
        addedCount++;
      }
    });

    setBulkInput('');
    setShowBulkModal(false);
    sounds.playSuccess();
    onShowToast(
      language === 'ur'
        ? `${addedCount} نئے CNIC ریکارڈز شامل ہو گئے`
        : `Successfully imported ${addedCount} CNIC records`,
      'success'
    );
  };

  const filteredRecords = records.filter((r) =>
    r.cnic.includes(cleanCNIC(searchQuery)) ||
    (r.province && r.province.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.cnicEntry}
          </h3>
        </div>
        <button
          type="button"
          onClick={() => {
            setShowBulkModal(!showBulkModal);
            sounds.playClick();
          }}
          className="text-xs text-cyan-300 hover:text-white flex items-center gap-1 bg-[#0c223c] px-2.5 py-1 rounded-lg border border-[#208fc0]/50 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-cyan-400" />
          <span>{tr.bulkBtn}</span>
        </button>
      </div>

      {/* Input box */}
      <div className="space-y-2">
        <div className="relative">
          <input
            id="cnic"
            type="text"
            maxLength={13}
            inputMode="numeric"
            value={inputVal}
            onChange={(e) => setInputVal(cleanCNIC(e.target.value))}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleAdd();
            }}
            placeholder={tr.cnicPlaceholder}
            className="w-full p-3.5 pr-20 bg-[#09182b] text-white border border-[#208fc0] rounded-xl text-base tracking-widest font-mono placeholder:tracking-normal placeholder:font-sans placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 transition-all"
          />
          <div className="absolute right-3 top-3.5 text-xs font-mono text-cyan-300/80 bg-[#0f2845] px-2 py-0.5 rounded border border-[#208fc0]/40">
            {cleanVal.length}/13
          </div>
        </div>

        {/* Live CNIC Decoder helper */}
        {cleanVal.length > 0 && (
          <div className="p-2.5 bg-[#0a182c] border border-[#20608c]/60 rounded-xl text-xs space-y-1">
            <div className="flex items-center justify-between font-mono text-cyan-300">
              <span className="text-slate-400">Formatted:</span>
              <span className="font-bold">{formatCNIC(cleanVal)}</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1 text-slate-400">
                <MapPin className="w-3 h-3 text-cyan-400" />
                Region:
              </span>
              <span className="text-cyan-200">
                {language === 'ur' ? province?.ur : province?.en}
              </span>
            </div>
            {gender && (
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1 text-slate-400">
                  <User className="w-3 h-3 text-cyan-400" />
                  Gender:
                </span>
                <span className="text-cyan-200">
                  {language === 'ur' ? gender.ur : gender.en}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
          <button
            type="button"
            onClick={handleAdd}
            className="sm:col-span-2 w-full p-3 border-0 rounded-xl bg-gradient-to-r from-[#087a58] to-[#12c995] text-white font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(18,201,149,0.25)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{tr.addCnicBtn}</span>
          </button>

          <button
            type="button"
            onClick={handleGenerateSample}
            className="w-full p-3 border border-[#208fc0]/60 rounded-xl bg-[#0b2440] hover:bg-[#113256] text-cyan-200 font-semibold text-xs tracking-wide transition-all cursor-pointer flex items-center justify-center gap-1.5"
            title="Generate a sample 13-digit Pakistani CNIC for instant testing"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{tr.demoCnicBtn}</span>
          </button>
        </div>

        {/* Privacy Notice */}
        <div className="flex items-center gap-1.5 text-xs text-[#9cb9d5] pt-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{tr.cnicNotice}</span>
        </div>
      </div>

      {/* Bulk Import Modal / Box */}
      {showBulkModal && (
        <div className="mt-4 p-3.5 bg-[#091526] border border-[#208fc0] rounded-xl animate-in fade-in">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-cyan-300">
              {language === 'ur' ? 'ایک سے زیادہ CNIC پیسٹ کریں (کوما یا نئی سطر سے الگ کریں):' : 'Paste Multiple 13-digit CNICs (separated by line or comma):'}
            </span>
            <button
              onClick={() => setShowBulkModal(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
          <textarea
            rows={3}
            value={bulkInput}
            onChange={(e) => setBulkInput(e.target.value)}
            placeholder="3520112345671, 4210198765432, 1730198765431"
            className="w-full p-2.5 bg-[#060f1c] text-white border border-[#1f4a73] rounded-lg text-xs font-mono focus:outline-none focus:ring-1 focus:ring-cyan-400"
          />
          <div className="flex justify-end gap-2 mt-2">
            <button
              onClick={() => setShowBulkModal(false)}
              className="px-3 py-1 rounded bg-[#102237] text-slate-300 text-xs hover:bg-[#162e4a]"
            >
              Cancel
            </button>
            <button
              onClick={handleBulkSubmit}
              className="px-4 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow"
            >
              Import CNICs
            </button>
          </div>
        </div>
      )}

      {/* CNIC Records Section */}
      <div className="mt-5 pt-3 border-t border-[#1f4973]">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-sm sm:text-base font-bold text-[#41eaff] m-0">
            {tr.cnicRecords}
          </h3>
          <span className="text-xs text-cyan-300/80 font-mono">
            {records.length} {language === 'ur' ? 'ریکارڈز' : 'Entries'}
          </span>
        </div>

        {/* Search filter if there are records */}
        {records.length > 2 && (
          <div className="relative mb-2.5">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={tr.searchPlaceholder}
              className="w-full pl-8 pr-3 py-2 bg-[#09182b] text-white border border-[#1b436a] rounded-lg text-xs font-mono focus:outline-none focus:border-cyan-400"
            />
            <Search className="w-3.5 h-3.5 text-cyan-500 absolute left-2.5 top-2.5" />
          </div>
        )}

        {/* Records List matching: background:#07111f;border:1px solid #244968;border-radius:10px;padding:10px;min-height:65px;max-height:210px;overflow:auto */}
        <div
          id="cnicList"
          className="bg-[#07111f] border border-[#244968] rounded-xl p-2 min-h-[75px] max-h-[220px] overflow-y-auto space-y-1.5"
        >
          {filteredRecords.length === 0 ? (
            <div className="flex items-center justify-center h-16 text-slate-400 text-xs text-center font-mono">
              {records.length === 0 ? tr.noRecords : 'No matching CNIC found'}
            </div>
          ) : (
            filteredRecords.map((r, i) => {
              const isSelected = records[selectedIndex]?.id === r.id;
              const originalIndex = records.findIndex((item) => item.id === r.id);

              return (
                <div
                  key={r.id}
                  onClick={() => {
                    onSelectRecord(originalIndex);
                    sounds.playClick();
                  }}
                  className={`item p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between text-xs ${
                    isSelected
                      ? 'bg-[#103254] border-cyan-400 shadow-[0_0_12px_rgba(0,220,255,0.2)] text-white'
                      : 'bg-[#091729] border-[#1d3c5c] text-slate-200 hover:bg-[#0d223a]'
                  }`}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <span className="text-cyan-400 font-mono font-bold shrink-0">
                      {originalIndex + 1}.
                    </span>
                    <div className="overflow-hidden">
                      <div className="font-mono font-bold text-cyan-200 tracking-wider">
                        {formatCNIC(r.cnic)}
                      </div>
                      <div className="text-[11px] text-[#9cb9d5] flex items-center gap-1.5 truncate">
                        <span>{r.sim}</span>
                        <span>·</span>
                        <span>{r.province || 'PK'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        r.status === 'Demo'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                      }`}
                    >
                      {r.status}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigator.clipboard.writeText(r.cnic);
                        setCopiedId(r.id);
                        sounds.playClick();
                        setTimeout(() => setCopiedId(null), 1500);
                      }}
                      className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
                      title="Copy CNIC"
                    >
                      {copiedId === r.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteRecord(r.id);
                        sounds.playClick();
                      }}
                      className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
