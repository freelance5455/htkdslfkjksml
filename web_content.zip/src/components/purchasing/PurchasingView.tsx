// Supermarket Purchasing Orders & Goods Receiving View
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import { PurchaseOrder } from '../../types';
import {
  Truck,
  Plus,
  CheckCircle2,
  Clock,
  Package,
  X,
  AlertCircle,
  FileText,
} from 'lucide-react';

export const PurchasingView: React.FC = () => {
  const { currentBranch, can, currentUser } = useAuth();
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(dbStore.getPurchaseOrders());
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [orderItems, setOrderItems] = useState<{ productId: string; quantity: number; unitCost: number }[]>([]);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  const suppliers = dbStore.getSuppliers();
  const products = dbStore.getProducts();
  const settings = dbStore.getSettings();

  const handleAddItem = () => {
    const firstProd = products[0];
    if (firstProd) {
      setOrderItems([
        ...orderItems,
        { productId: firstProd.id, quantity: 10, unitCost: firstProd.costPrice },
      ]);
    }
  };

  const handleCreatePO = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!currentUser) return;
    if (orderItems.length === 0) {
      setError('Please add at least one product line to order.');
      return;
    }

    try {
      dbStore.createPurchaseOrder(
        selectedSupplierId || suppliers[0].id,
        currentBranch.id,
        orderItems,
        currentUser.id,
        currentUser.name,
        notes
      );
      setPurchaseOrders(dbStore.getPurchaseOrders());
      setIsCreateOpen(false);
      setOrderItems([]);
      setNotes('');
    } catch (err: any) {
      setError(err.message || 'Failed to create purchase order');
    }
  };

  const handleReceivePO = (poId: string) => {
    if (!currentUser) return;
    try {
      dbStore.receivePurchaseOrder(poId, currentUser.id, currentUser.name);
      setPurchaseOrders(dbStore.getPurchaseOrders());
    } catch (err: any) {
      alert(err.message || 'Failed to receive goods');
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">Purchasing & Vendor Goods Receiving</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Generate formal supplier purchase orders and verify incoming consignments directly into stock.
          </p>
        </div>

        {can('PURCHASE_CREATE') && (
          <button
            onClick={() => {
              setSelectedSupplierId(suppliers[0]?.id || '');
              setOrderItems([
                { productId: products[0]?.id || '', quantity: 20, unitCost: products[0]?.costPrice || 50 },
              ]);
              setIsCreateOpen(true);
            }}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm shadow-emerald-900/30 transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Purchase Order
          </button>
        )}
      </div>

      {/* Purchase Orders Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                <th className="py-3 px-4">PO Number</th>
                <th className="py-3 px-4">Supplier</th>
                <th className="py-3 px-4 text-center">Items Count</th>
                <th className="py-3 px-4 text-right">Total Order Value</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Created Date</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {purchaseOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 text-xs">
                    No purchase orders recorded yet. Click "New Purchase Order" to create one.
                  </td>
                </tr>
              ) : (
                purchaseOrders.map((po) => {
                  const supp = suppliers.find((s) => s.id === po.supplierId);
                  const isReceived = po.status === 'RECEIVED';
                  return (
                    <tr key={po.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400">{po.orderNumber}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">{supp?.name || 'Supplier'}</div>
                        <div className="text-[10px] text-slate-500">{supp?.phone}</div>
                      </td>
                      <td className="py-3 px-4 text-center font-mono">{po.items.length} items</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                        {settings.currency} {po.totalAmount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            isReceived
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {po.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {new Date(po.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {!isReceived && can('PURCHASE_RECEIVE') && (
                          <button
                            onClick={() => handleReceivePO(po.id)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold"
                          >
                            Receive Goods
                          </button>
                        )}
                        {isReceived && (
                          <span className="text-[11px] text-emerald-400 font-semibold flex items-center justify-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Stock Ingested
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New PO Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold text-slate-100">Create Supplier Purchase Order</h2>
              </div>
              <button
                onClick={() => setIsCreateOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreatePO} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              {error && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Target Supplier</label>
                <select
                  value={selectedSupplierId}
                  onChange={(e) => setSelectedSupplierId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              {/* Order Lines */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300">Order Product Lines</label>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Line
                  </button>
                </div>

                <div className="space-y-2">
                  {orderItems.map((line, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                      <select
                        value={line.productId}
                        onChange={(e) => {
                          const prod = products.find((p) => p.id === e.target.value);
                          const updated = [...orderItems];
                          updated[idx].productId = e.target.value;
                          if (prod) updated[idx].unitCost = prod.costPrice;
                          setOrderItems(updated);
                        }}
                        className="flex-1 bg-slate-900 border border-slate-700 text-xs rounded px-2 py-1 text-slate-200"
                      >
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))}
                      </select>

                      <div className="w-20">
                        <input
                          type="number"
                          min="1"
                          value={line.quantity}
                          onChange={(e) => {
                            const updated = [...orderItems];
                            updated[idx].quantity = parseInt(e.target.value, 10) || 1;
                            setOrderItems(updated);
                          }}
                          placeholder="Qty"
                          className="w-full bg-slate-900 border border-slate-700 text-xs rounded px-2 py-1 text-white font-mono"
                        />
                      </div>

                      <div className="w-24">
                        <input
                          type="number"
                          step="0.01"
                          value={line.unitCost}
                          onChange={(e) => {
                            const updated = [...orderItems];
                            updated[idx].unitCost = parseFloat(e.target.value) || 0;
                            setOrderItems(updated);
                          }}
                          placeholder="Cost"
                          className="w-full bg-slate-900 border border-slate-700 text-xs rounded px-2 py-1 text-white font-mono"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => setOrderItems(orderItems.filter((_, i) => i !== idx))}
                        className="text-slate-500 hover:text-rose-400 p-1"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Notes / Instructions</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g., Deliver to Main Warehouse receiving bay 2"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-sm shadow-emerald-900/30"
                >
                  Confirm Purchase Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
