import { Check, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { REST_PRESETS } from "@/lib/defaults";
import type { LiveExercise } from "@/lib/types";
import { cn } from "@/lib/utils";

export function LiveExerciseCard({
  exercise,
  onCompleteSet,
  onUndoSet,
  onPatch,
}: {
  exercise: LiveExercise;
  onCompleteSet: () => void;
  onUndoSet: () => void;
  onPatch: (patch: Partial<Pick<LiveExercise, "load" | "reps" | "restSec">>) => void;
}) {
  const done = exercise.completedSets >= exercise.sets;
  const pct = exercise.sets > 0 ? exercise.completedSets / exercise.sets : 0;

  return (
    <Card className={cn("p-4 transition-colors", done && "border-success/40 bg-success/5")}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-display text-base font-semibold leading-snug">
            {exercise.name}
          </h3>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {exercise.sets} × {exercise.reps}
            {exercise.load ? ` · ${exercise.load}` : ""}
          </p>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full px-2.5 py-1 text-xs font-medium tabular-nums",
            done ? "bg-success/15 text-success" : "bg-primary/15 text-primary",
          )}
        >
          {exercise.completedSets}/{exercise.sets} séries
        </span>
      </div>

      {exercise.notes ? (
        <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
          {exercise.notes}
        </p>
      ) : null}

      <div className="mt-3 flex gap-1">
        {Array.from({ length: exercise.sets }).map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-1.5 flex-1 rounded-full",
              i < exercise.completedSets ? "bg-primary" : "bg-muted",
            )}
            style={{ opacity: i < exercise.completedSets ? 0.4 + pct * 0.6 : 1 }}
          />
        ))}
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <label className="space-y-1">
          <span className="text-[11px] text-muted-foreground">Carga</span>
          <Input
            value={exercise.load}
            onChange={(e) => onPatch({ load: e.target.value })}
            placeholder="kg / mochila"
          />
        </label>
        <label className="space-y-1">
          <span className="text-[11px] text-muted-foreground">Descanso (s)</span>
          <Input
            type="number"
            min={0}
            step={5}
            value={exercise.restSec}
            onChange={(e) =>
              onPatch({ restSec: Math.max(0, Number(e.target.value) || 0) })
            }
          />
        </label>
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {REST_PRESETS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => onPatch({ restSec: s })}
            className={cn(
              "h-8 rounded-full px-2.5 text-[11px] font-medium",
              exercise.restSec === s
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground",
            )}
          >
            {s}s
          </button>
        ))}
      </div>

      <div className="mt-3 flex gap-2">
        <Button
          className="flex-1"
          disabled={done}
          onClick={() => {
            onCompleteSet();
            toast.success("Série concluída");
          }}
        >
          <Check /> {done ? "Exercício concluído" : "Concluir série"}
        </Button>
        {exercise.completedSets > 0 ? (
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={onUndoSet}
            aria-label="Desfazer série"
          >
            <Undo2 />
          </Button>
        ) : null}
      </div>
    </Card>
  );
}
