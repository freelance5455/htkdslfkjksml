/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNetwork, DistributionMode } from '../context/NetworkContext';
import { 
  SlidersHorizontal, 
  Sparkles, 
  PieChart, 
  ShieldCheck, 
  Cpu, 
  ArrowRight, 
  Copy, 
  Check, 
  RefreshCw,
  Terminal,
  Server
} from 'lucide-react';
import { RouterBrand } from '../types/network';

export const SmartDistributionTab: React.FC = () => {
  const { 
    distributionMode, 
    setDistributionMode, 
    ispBandwidthLimitMbps, 
    setIspBandwidthLimit, 
    devices, 
    router,
    updateRouterConfig,
    simulateRouterReboot
  } = useNetwork();

  const [copied, setCopied] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState<RouterBrand>(router.brand);

  const activeDevices = devices.filter(d => d.isOnline && !d.isPaused);
  const totalActiveDemandDl = activeDevices.reduce((sum, d) => sum + d.currentDlMbps, 0);

  // Group active bandwidth by tier
  const tierCritical = activeDevices.filter(d => d.priorityTier === 'critical').reduce((s, d) => s + d.currentDlMbps, 0);
  const tierHigh = activeDevices.filter(d => d.priorityTier === 'high').reduce((s, d) => s + d.currentDlMbps, 0);
  const tierMedium = activeDevices.filter(d => d.priorityTier === 'medium').reduce((s, d) => s + d.currentDlMbps, 0);
  const tierLow = activeDevices.filter(d => d.priorityTier === 'low').reduce((s, d) => s + d.currentDlMbps, 0);

  const headroom = Math.max(0, ispBandwidthLimitMbps - totalActiveDemandDl);

  const modes: { id: DistributionMode; title: string; desc: string; icon: string }[] = [
    {
      id: 'dynamic_fair',
      title: 'Dynamic Fair Share (Recommended)',
      desc: 'Automatic proportional queueing. Scales bandwidth dynamically so downloads never freeze other streams.',
      icon: '⚖️',
    },
    {
      id: 'gaming_first',
      title: 'Gaming & Low-Latency Priority',
      desc: 'Allocates guaranteed zero-bufferbloat bandwidth to gaming consoles & PC. Background IoT throttled.',
      icon: '🎮',
    },
    {
      id: 'work_focus',
      title: 'Work & Video Calls Focus',
      desc: 'Prioritizes Zoom, Teams, Meet, and VPN tunnels above entertainment streaming and bulk downloads.',
      icon: '💼',
    },
    {
      id: 'equal_split',
      title: 'Equal Bandwidth Division',
      desc: 'Divides the ISP pipe evenly among all online devices, enforcing strict per-device ceilings.',
      icon: '📊',
    },
  ];

  const handleCopyScript = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const routerScript = selectedBrand === 'openwrt' 
    ? `# OpenWrt Cake SQM Configuration for ${ispBandwidthLimitMbps} Mbps ISP Plan
uci set sqm.eth1=queue
uci set sqm.eth1.interface='eth1'
uci set sqm.eth1.download='${Math.round(ispBandwidthLimitMbps * 920)}'
uci set sqm.eth1.upload='${Math.round(ispBandwidthLimitMbps * 180)}'
uci set sqm.eth1.qdisc='cake'
uci set sqm.eth1.script='piece_of_cake.qos'
uci set sqm.eth1.enabled='1'
uci commit sqm
/etc/init.d/sqm restart`
    : selectedBrand === 'mikrotik'
    ? `# MikroTik RouterOS Simple Queue Script
/queue simple
add max-limit=${ispBandwidthLimitMbps}M/${Math.round(ispBandwidthLimitMbps/5)}M name=ISP_Wan_Cake target=192.168.1.0/24 queue=fq_codel-default/fq_codel-default
add name=VIP_Gaming priority=1 target=192.168.1.105/32 max-limit=100M/50M
add name=Guest_Throttle priority=8 target=192.168.1.160/32 max-limit=15M/5M`
    : `# AsusWRT-Merlin Adaptive QoS / TC
nvram set qos_enable=1
nvram set qos_type=1
nvram set qos_ibw=${Math.round(ispBandwidthLimitMbps * 1024)}
nvram set qos_obw=50000
nvram commit
service restart_qos`;

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Header */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800/80 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
              <span>Smart Bandwidth Distribution</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Automated QoS traffic shaping & router queue management
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-cyan-400">
              {totalActiveDemandDl.toFixed(1)} / {ispBandwidthLimitMbps}
            </span>
            <span className="text-[10px] text-slate-500 block">Mbps Total Pipe</span>
          </div>
        </div>

        {/* Dynamic Allocation Stacked Progress Bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-medium">
            <span>Real-time Pipe Allocation</span>
            <span className="font-mono text-cyan-300">
              {Math.min(100, Math.round((totalActiveDemandDl / ispBandwidthLimitMbps) * 100))}% utilized
            </span>
          </div>

          <div className="w-full h-3.5 bg-slate-950 rounded-full overflow-hidden flex border border-slate-800 p-0.5">
            <div 
              style={{ width: `${(tierCritical / ispBandwidthLimitMbps) * 100}%` }} 
              className="bg-purple-500 h-full rounded-l-full transition-all duration-300" 
              title={`Critical: ${tierCritical.toFixed(1)} Mbps`}
            />
            <div 
              style={{ width: `${(tierHigh / ispBandwidthLimitMbps) * 100}%` }} 
              className="bg-cyan-500 h-full transition-all duration-300" 
              title={`High: ${tierHigh.toFixed(1)} Mbps`}
            />
            <div 
              style={{ width: `${(tierMedium / ispBandwidthLimitMbps) * 100}%` }} 
              className="bg-blue-500 h-full transition-all duration-300" 
              title={`Medium: ${tierMedium.toFixed(1)} Mbps`}
            />
            <div 
              style={{ width: `${(tierLow / ispBandwidthLimitMbps) * 100}%` }} 
              className="bg-slate-600 h-full transition-all duration-300" 
              title={`Low/IoT: ${tierLow.toFixed(1)} Mbps`}
            />
            <div 
              style={{ width: `${(headroom / ispBandwidthLimitMbps) * 100}%` }} 
              className="bg-transparent h-full" 
              title={`Headroom: ${headroom.toFixed(1)} Mbps`}
            />
          </div>

          {/* Legend */}
          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 flex-wrap gap-1">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-500" />
              <span>Critical ({tierCritical.toFixed(0)}M)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-500" />
              <span>High ({tierHigh.toFixed(0)}M)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <span>General ({tierMedium.toFixed(0)}M)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-slate-600" />
              <span>IoT ({tierLow.toFixed(0)}M)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-slate-800 border border-slate-600" />
              <span>Free Buffer ({headroom.toFixed(0)}M)</span>
            </div>
          </div>
        </div>
      </div>

      {/* ISP Plan Limit Selector */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-4">
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-bold text-white uppercase tracking-wider">
            Total ISP Subscription Bandwidth
          </label>
          <span className="text-xs font-mono font-bold text-cyan-400">
            {ispBandwidthLimitMbps} Mbps
          </span>
        </div>

        <div className="grid grid-cols-4 gap-2 text-xs">
          {[100, 300, 500, 1000].map(speed => (
            <button
              key={speed}
              onClick={() => setIspBandwidthLimit(speed)}
              className={`py-2 rounded-xl border text-center font-bold transition ${
                ispBandwidthLimitMbps === speed
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {speed >= 1000 ? '1 Gbps' : `${speed}M`}
            </button>
          ))}
        </div>
      </div>

      {/* Distribution Mode Selection */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-300 px-1 uppercase tracking-wider">
          Active Allocation Strategy
        </h3>

        {modes.map(mode => {
          const isSelected = distributionMode === mode.id;

          return (
            <div
              key={mode.id}
              onClick={() => setDistributionMode(mode.id)}
              className={`cursor-pointer p-3.5 rounded-2xl border transition-all ${
                isSelected
                  ? 'bg-cyan-950/20 border-cyan-500/40 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <span className="text-lg">{mode.icon}</span>
                  <div>
                    <h4 className="text-xs font-bold text-white">{mode.title}</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                      {mode.desc}
                    </p>
                  </div>
                </div>

                <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                  isSelected ? 'border-cyan-400 bg-cyan-500' : 'border-slate-600'
                }`}>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Router QoS Synchronization & Script Generator */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Router Firmware QoS Sync
            </h3>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
            Status: {router.connectedStatus}
          </span>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Select your router model to export traffic control rules directly for SQM Cake or Adaptive QoS.
        </p>

        {/* Router Brand Selector */}
        <div className="grid grid-cols-3 gap-1.5 text-xs">
          {[
            { id: 'openwrt' as RouterBrand, label: 'OpenWrt' },
            { id: 'asuswrt' as RouterBrand, label: 'AsusWRT' },
            { id: 'mikrotik' as RouterBrand, label: 'MikroTik' },
          ].map(b => (
            <button
              key={b.id}
              onClick={() => {
                setSelectedBrand(b.id);
                updateRouterConfig({ brand: b.id });
              }}
              className={`py-1.5 rounded-xl border text-center font-medium transition ${
                selectedBrand === b.id
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {b.label}
            </button>
          ))}
        </div>

        {/* Script preview */}
        <div className="relative">
          <pre className="p-3 rounded-xl bg-black/90 border border-slate-800 text-[10px] font-mono text-cyan-300 overflow-x-auto whitespace-pre leading-relaxed">
            {routerScript}
          </pre>
          <button
            onClick={handleCopyScript}
            className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Simulated Sync / Reboot Action */}
        <div className="pt-1 flex gap-2">
          <button
            onClick={() => simulateRouterReboot()}
            className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Apply & Sync to Router ({router.ip})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
