import {
  Cake,
  CheckCircle2,
  Clock,
  HeartPulse,
  MessageSquare,
  Moon,
  Sparkles,
  Utensils,
  Wind,
} from 'lucide-react';
import type { AgeAnalytics, LifetimeStatItem } from '../utils/ageCalculations';
import { formatInteger, padTwo } from '../utils/ageCalculations';
import { PlanetIcon } from './PlanetIcon';

interface AgeDashboardProps {
  analytics: AgeAnalytics;
  mode: 'live' | 'custom';
}

function renderLifetimeIcon(id: LifetimeStatItem['id']) {
  const iconClass = 'h-4 w-4 text-slate-400 shrink-0';
  switch (id) {
    case 'heartbeats':
      return <HeartPulse className={iconClass} aria-hidden="true" />;
    case 'breaths':
      return <Wind className={iconClass} aria-hidden="true" />;
    case 'sleep':
      return <Moon className={iconClass} aria-hidden="true" />;
    case 'meals':
      return <Utensils className={iconClass} aria-hidden="true" />;
    case 'words':
      return <MessageSquare className={iconClass} aria-hidden="true" />;
    case 'moons':
      return <Sparkles className={iconClass} aria-hidden="true" />;
  }
}

export function AgeDashboard({ analytics, mode }: AgeDashboardProps) {
  const {
    breakdown,
    nextBirthday,
    milestones,
    planets,
    birthDetails,
    lifetimeStats,
    referenceDate,
  } = analytics;

  const metricStrip = [
    { label: 'Total Months', value: formatInteger(breakdown.totalMonths), live: false },
    { label: 'Total Weeks', value: formatInteger(breakdown.totalWeeks), live: false },
    { label: 'Total Days', value: formatInteger(breakdown.totalDays), live: false },
    { label: 'Total Hours', value: formatInteger(breakdown.totalHours), live: false },
    { label: 'Total Minutes', value: formatInteger(breakdown.totalMinutes), live: false },
    { label: 'Total Seconds', value: formatInteger(breakdown.totalSeconds), live: true },
  ];

  const detailRows = [
    { label: 'Day Born', value: birthDetails.dayBorn },
    { label: 'Zodiac Sign', value: `${birthDetails.zodiacSymbol} ${birthDetails.zodiacName}` },
    { label: 'Chinese Zodiac', value: birthDetails.chineseZodiac },
    { label: 'Birthstone', value: birthDetails.birthstone },
    { label: 'Season Born', value: birthDetails.season },
    {
      label: 'Birth Year Type',
      value: birthDetails.isLeapYear ? 'Leap Year (366 days)' : 'Standard Year (365 days)',
    },
  ];

  const referenceLabel =
    mode === 'live'
      ? 'Live ticking clock'
      : `Calculated as of ${referenceDate.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })}`;

  return (
    <div className="space-y-6">
      {/* 1. Dominant Focal Anchor: Exact Age Card */}
      <section
        id="overview"
        aria-labelledby="exact-age-heading"
        className="scroll-mt-20 rounded-2xl border border-white/[0.09] bg-gradient-to-b from-indigo-500/[0.11] via-[#0F1420] to-[#0F1420] p-5 sm:p-7"
      >
        <div className="flex flex-wrap items-center justify-between gap-2 pb-5 border-b border-white/[0.07]">
          <h2 id="exact-age-heading" className="text-xs font-semibold tracking-wide text-slate-300">
            Your Exact Age
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-medium text-cyan-300">{breakdown.generation}</span>
            <span aria-hidden="true">·</span>
            <span>{birthDetails.formattedBirthDate}</span>
            <span aria-hidden="true">·</span>
            <span>{referenceLabel}</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 py-7 text-center">
          <div>
            <div className="font-display text-4xl sm:text-5xl lg:text-[56px] font-extrabold leading-none grad-num font-mono-tabular">
              {breakdown.years}
            </div>
            <div className="mt-2.5 text-xs font-semibold tracking-wide text-slate-400">
              Years
            </div>
          </div>
          <div>
            <div className="font-display text-4xl sm:text-5xl lg:text-[56px] font-extrabold leading-none grad-num font-mono-tabular">
              {breakdown.months}
            </div>
            <div className="mt-2.5 text-xs font-semibold tracking-wide text-slate-400">
              Months
            </div>
          </div>
          <div>
            <div className="font-display text-4xl sm:text-5xl lg:text-[56px] font-extrabold leading-none grad-num font-mono-tabular">
              {breakdown.days}
            </div>
            <div className="mt-2.5 text-xs font-semibold tracking-wide text-slate-400">
              Days
            </div>
          </div>
        </div>

        <p className="text-center text-sm text-indigo-100/90 pb-6">
          {breakdown.isBirthdayToday ? (
            <span className="inline-flex items-center gap-2 font-semibold text-cyan-300">
              <Cake className="h-4 w-4" aria-hidden="true" />
              <span>Happy Birthday! Today marks another full solar orbit.</span>
            </span>
          ) : (
            <span>
              You are{' '}
              <strong className="font-mono-tabular font-semibold text-white">
                {formatInteger(breakdown.totalDays)}
              </strong>{' '}
              days old — {mode === 'live' ? 'and counting every second.' : 'on the selected date.'}
            </span>
          )}
        </p>

        {/* Clean hairline-divided breakdown strip (no cards-within-cards) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 border-t border-white/[0.08] pt-5 gap-y-5 gap-x-4">
          {metricStrip.map((item) => (
            <div key={item.label} className="space-y-1">
              <div className="text-xs font-medium text-slate-400">{item.label}</div>
              <div
                className={`text-lg sm:text-xl font-bold font-mono-tabular ${
                  item.live ? 'text-cyan-300' : 'text-slate-100'
                }`}
              >
                {item.value}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Next Birthday Countdown & Birth Details Split */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
        <section
          id="countdown"
          aria-labelledby="countdown-heading"
          className="scroll-mt-20 flex flex-col justify-between rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6"
        >
          <div>
            <div className="flex items-center justify-between gap-2 pb-4 border-b border-white/[0.07]">
              <h2 id="countdown-heading" className="text-xs font-semibold tracking-wide text-slate-300">
                Next Birthday Countdown
              </h2>
              <span className="text-xs font-medium text-indigo-300 font-mono-tabular">
                {nextBirthday.formattedDate}
              </span>
            </div>

            <div className="mt-4 text-base font-bold text-white">
              {nextBirthday.days === 0 && breakdown.isBirthdayToday
                ? 'Your birthday is today!'
                : `${formatInteger(nextBirthday.daysLeftHeadline)} day${
                    nextBirthday.daysLeftHeadline === 1 ? '' : 's'
                  } to go`}
            </div>

            <div className="mt-4 grid grid-cols-4 divide-x divide-white/[0.08] rounded-xl border border-white/[0.08] bg-white/[0.02] py-3.5 text-center">
              <div className="px-1">
                <div className="text-xl sm:text-2xl font-bold text-white font-mono-tabular">
                  {nextBirthday.days}
                </div>
                <div className="mt-1 text-[11px] font-medium text-slate-400">Days</div>
              </div>
              <div className="px-1">
                <div className="text-xl sm:text-2xl font-bold text-white font-mono-tabular">
                  {padTwo(nextBirthday.hours)}
                </div>
                <div className="mt-1 text-[11px] font-medium text-slate-400">Hours</div>
              </div>
              <div className="px-1">
                <div className="text-xl sm:text-2xl font-bold text-white font-mono-tabular">
                  {padTwo(nextBirthday.minutes)}
                </div>
                <div className="mt-1 text-[11px] font-medium text-slate-400">Mins</div>
              </div>
              <div className="px-1">
                <div className="text-xl sm:text-2xl font-bold text-cyan-300 font-mono-tabular">
                  {padTwo(nextBirthday.seconds)}
                </div>
                <div className="mt-1 text-[11px] font-medium text-slate-400">Secs</div>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <div
              className="h-2 w-full overflow-hidden rounded-full bg-white/[0.08]"
              role="progressbar"
              aria-valuenow={Math.round(nextBirthday.yearProgressPct)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Year progress toward next birthday"
            >
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-[width] duration-300"
                style={{ width: `${nextBirthday.yearProgressPct.toFixed(2)}%` }}
              />
            </div>
            <div className="mt-2.5 flex items-center justify-between text-xs font-medium text-slate-400">
              <span>Turning {nextBirthday.turningAge}</span>
              <span className="font-mono-tabular">
                {nextBirthday.yearProgressPct.toFixed(1)}% completed
              </span>
            </div>
          </div>
        </section>

        <section
          id="astrology"
          aria-labelledby="astrology-heading"
          className="scroll-mt-20 rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6"
        >
          <div className="pb-4 border-b border-white/[0.07]">
            <h2 id="astrology-heading" className="text-xs font-semibold tracking-wide text-slate-300">
              Astrology &amp; Birth Details
            </h2>
          </div>

          <dl className="divide-y divide-white/[0.07] text-sm">
            {detailRows.map((row) => (
              <div key={row.label} className="flex items-center justify-between gap-4 py-3">
                <dt className="text-slate-400">{row.label}</dt>
                <dd className="font-semibold text-slate-100 text-right">{row.value}</dd>
              </div>
            ))}
          </dl>
        </section>
      </div>

      {/* 3. Life Milestones */}
      <section
        id="milestones"
        aria-labelledby="milestones-heading"
        className="scroll-mt-20 rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6"
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/[0.07]">
          <h2 id="milestones-heading" className="text-xs font-semibold tracking-wide text-slate-300">
            Life Milestones
          </h2>
          <span className="text-xs text-slate-400">
            {milestones.filter((m) => m.achieved).length} of {milestones.length} reached
          </span>
        </div>

        <ul className="divide-y divide-white/[0.07]">
          {milestones.map((m) => (
            <li
              key={m.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 py-3.5"
            >
              <div>
                <div className="text-sm font-semibold text-slate-100">{m.title}</div>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="font-mono-tabular">{m.formattedDate}</span>
                  <span aria-hidden="true">·</span>
                  <span>{m.relativeLabel}</span>
                </div>
              </div>

              <div
                className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap shrink-0 ${
                  m.achieved ? 'text-emerald-300' : 'text-indigo-300'
                }`}
              >
                {m.achieved ? (
                  <>
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Achieved</span>
                  </>
                ) : (
                  <>
                    <Clock className="h-4 w-4" aria-hidden="true" />
                    <span>Upcoming</span>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* 4. Age on Other Planets */}
      <section
        id="planets"
        aria-labelledby="planets-heading"
        className="scroll-mt-20 rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6"
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/[0.07]">
          <h2 id="planets-heading" className="text-xs font-semibold tracking-wide text-slate-300">
            Age on Other Planets
          </h2>
          <span className="text-xs text-slate-400">Solar orbital equivalents</span>
        </div>

        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-4">
          {planets.map((planet) => (
            <div
              key={planet.key}
              className="flex items-center gap-3.5 rounded-xl bg-white/[0.025] p-3.5"
            >
              <PlanetIcon planet={planet.key} className="h-8 w-8 shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-medium text-slate-400">{planet.name}</div>
                <div className="text-lg font-bold text-cyan-300 font-mono-tabular">
                  {planet.ageYears}y
                </div>
                <div className="text-[11px] text-slate-500 font-mono-tabular truncate">
                  Next in {formatInteger(planet.nextBirthdayDays)}d
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Lifetime Statistics */}
      <section
        id="lifetime"
        aria-labelledby="lifetime-heading"
        className="scroll-mt-20 rounded-2xl border border-white/[0.08] bg-[#0F1420]/90 p-5 sm:p-6"
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/[0.07]">
          <h2 id="lifetime-heading" className="text-xs font-semibold tracking-wide text-slate-300">
            Lifetime Statistics (Approx.)
          </h2>
          <span className="text-xs text-slate-400">Physiological &amp; lunar estimates</span>
        </div>

        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-4">
          {lifetimeStats.map((stat) => (
            <div key={stat.id} className="rounded-xl bg-white/[0.025] p-4 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-slate-400">{stat.label}</span>
                {renderLifetimeIcon(stat.id)}
              </div>
              <div className="text-lg sm:text-xl font-bold text-slate-100 font-mono-tabular">
                {formatInteger(stat.value)}
              </div>
              <div className="text-[11px] text-slate-500">{stat.unitHint}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
