import React, { useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, FileArchive, Upload } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { type BackupValidationResult, validateBackupJson } from '../db/indexedDb';
import { toCsvString } from '../engine/calculations';
import { createZipArchive } from '../engine/zipBuilder';
import { ConfirmDialog } from './ConfirmDialog';
import { downloadTextFile } from './ReportsView';

export const BackupRestoreView: React.FC = () => {
  const { snapshot, exportBackupPackage, restoreBackupPackage, notify } = useApp();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [validation, setValidation] = useState<BackupValidationResult | null>(null);
  const [confirmRestore, setConfirmRestore] = useState(false);

  const handleJsonBackup = async () => {
    const pkg = await exportBackupPackage();
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    downloadTextFile(
      `saif-ullah-backup-${stamp}.json`,
      JSON.stringify(pkg, null, 2),
      'application/json'
    );
    notify('Full JSON backup downloaded');
  };

  const handleZipBackup = async () => {
    const pkg = await exportBackupPackage();
    const loanCsv = toCsvString(
      [
        { key: 'date', label: 'Date' },
        { key: 'personId', label: 'Person ID' },
        { key: 'type', label: 'Type' },
        { key: 'amount', label: 'Amount' },
        { key: 'paymentMethod', label: 'Method' },
        { key: 'transactionRef', label: 'Ref' },
        { key: 'remarks', label: 'Remarks' },
      ],
      pkg.data.loanTransactions as unknown as Record<string, unknown>[]
    );
    const commCsv = toCsvString(
      [
        { key: 'date', label: 'Date' },
        { key: 'committeeId', label: 'Committee ID' },
        { key: 'personName', label: 'Person' },
        { key: 'type', label: 'Type' },
        { key: 'amount', label: 'Amount' },
        { key: 'paymentMethod', label: 'Method' },
        { key: 'paymentRef', label: 'Ref' },
        { key: 'remarks', label: 'Remarks' },
      ],
      pkg.data.committeeTransactions as unknown as Record<string, unknown>[]
    );
    const zipBytes = createZipArchive([
      { name: 'backup.json', content: JSON.stringify(pkg, null, 2) },
      { name: 'loan-transactions.csv', content: loanCsv },
      { name: 'committee-transactions.csv', content: commCsv },
      {
        name: 'README.txt',
        content: `Saif Ullah — Loan & Committee Manager Backup\nExported: ${pkg.exportedAt}\nSchema Version: ${pkg.schemaVersion}\n\nTo restore, upload backup.json inside Backup & Restore.\n`,
      },
    ]);
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const blob = new Blob([zipBytes.buffer as ArrayBuffer], { type: 'application/zip' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `saif-ullah-backup-bundle-${stamp}.zip`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    notify('Full ZIP backup bundle downloaded');
  };

  const handleExportAllCsv = () => {
    const csv = toCsvString(
      [
        { key: 'date', label: 'Date' },
        { key: 'type', label: 'Type' },
        { key: 'amount', label: 'Amount' },
        { key: 'description', label: 'Description' },
        { key: 'remarks', label: 'Remarks' },
      ],
      snapshot.loanTransactions as unknown as Record<string, unknown>[]
    );
    downloadTextFile('loan-ledger-export.csv', csv, 'text/csv;charset=utf-8');
    notify('Loan CSV exported');
  };

  const handleFilePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const res = validateBackupJson(text);
    setValidation(res);
    if (!res.valid) {
      notify(res.error || 'Invalid backup file', 'error');
    }
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Export Section */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Backup &amp; Export
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Export your entire IndexedDB database (loans, committees, custom modules, fields, formulas, mappings, dashboard cards, reports, and settings).
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={handleJsonBackup}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>Full JSON Backup</span>
          </button>
          <button
            type="button"
            onClick={handleZipBackup}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <FileArchive className="w-4 h-4" aria-hidden="true" />
            <span>Download ZIP Bundle</span>
          </button>
          <button
            type="button"
            onClick={handleExportAllCsv}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-slate-800 border border-slate-300 bg-white hover:bg-slate-50 cursor-pointer"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>Export Loans CSV</span>
          </button>
        </div>

        <div className="text-xs text-slate-500 pt-2 border-t border-slate-100">
          Current Database Summary: {snapshot.loanPersons.length} loan people ·{' '}
          {snapshot.loanTransactions.length} loan tx · {snapshot.committees.length} committees ·{' '}
          {snapshot.modules.length} custom modules · {snapshot.customRecords.length} custom records
        </div>
      </div>

      {/* Restore Section */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Restore from Backup
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Select a previously exported <code className="font-mono">.json</code> backup file. The structure and schema version will be validated before anything is overwritten.
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".json,application/json"
          onChange={handleFilePick}
          className="hidden"
          aria-label="Choose backup JSON file"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-sm font-semibold text-slate-800 cursor-pointer"
        >
          <Upload className="w-4 h-4" aria-hidden="true" />
          <span>Select Backup JSON File</span>
        </button>

        {validation && !validation.valid && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 flex items-start gap-3 text-sm text-red-800">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <div className="font-bold">Backup Validation Failed</div>
              <div className="text-xs mt-1">{validation.error}</div>
            </div>
          </div>
        )}

        {validation && validation.valid && validation.stats && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" aria-hidden="true" />
              <span>Backup Validated — Ready to Restore</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-700 font-mono-num">
              <div>Exported: {new Date(validation.stats.exportedAt).toLocaleString()}</div>
              <div>Schema v{validation.stats.schemaVersion}</div>
              <div>Loan People: {validation.stats.loanPersons}</div>
              <div>Loan Tx: {validation.stats.loanTransactions}</div>
              <div>Committees: {validation.stats.committees}</div>
              <div>Committee Tx: {validation.stats.committeeTransactions}</div>
              <div>Modules: {validation.stats.modules}</div>
              <div>Custom Records: {validation.stats.customRecords}</div>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmRestore(true)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
              >
                Proceed with Restore
              </button>
              <button
                type="button"
                onClick={() => setValidation(null)}
                className="px-4 py-2 rounded-lg text-xs font-medium text-slate-700 border border-slate-300 bg-white cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={confirmRestore}
        title="Overwrite Current Database?"
        message="Restoring this backup will replace all current IndexedDB records and settings with the validated backup contents. Make sure you have downloaded a current backup first if needed."
        destructive
        confirmLabel="Yes, Restore Backup"
        onConfirm={async () => {
          if (validation?.parsed) {
            await restoreBackupPackage(validation.parsed);
            setValidation(null);
            notify('Backup restored successfully');
          }
          setConfirmRestore(false);
        }}
        onCancel={() => setConfirmRestore(false)}
      />
    </div>
  );
};
