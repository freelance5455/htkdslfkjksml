import React, { useState } from 'react';
import { X, Truck, Check, AlertCircle } from 'lucide-react';
import { Product, MainInventoryItem, VanInventoryItem } from '../db/indexedDB';
import { sound } from '../utils/sound';

interface VanLoadModalProps {
  products: Product[];
  groups: string[];
  mainInventory: Map<string, number>;
  vanInventory: Map<string, number>;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (productId: string, qty: number) => Promise<void>;
}

export const VanLoadModal: React.FC<VanLoadModalProps> = ({
  products,
  groups,
  mainInventory,
  vanInventory,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [selectedGroup, setSelectedGroup] = useState('الكل');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredProducts = products.filter((p) => {
    const matchGroup = selectedGroup === 'الكل' || p.group === selectedGroup;
    const warehouseQty = mainInventory.get(p.id) || 0;
    return matchGroup && warehouseQty > 0;
  });

  const activeProductId = selectedProductId || filteredProducts[0]?.id || '';
  const warehouseQty = mainInventory.get(activeProductId) || 0;
  const currentVanQty = vanInventory.get(activeProductId) || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!activeProductId) {
      setError('لا توجد بضاعة متاحة في المخزن لهذا الاختيار');
      sound.playError();
      return;
    }
    if (qty <= 0) {
      setError('يرجى تحديد كمية صحيحة');
      return;
    }
    if (qty > warehouseQty) {
      setError(`الكمية المطلوبة (${qty}) أكبر من رصيد المخزن المتاح (${warehouseQty})`);
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      await onConfirm(activeProductId, qty);
      sound.playSuccess();
      onClose();
    } catch {
      setError('تعذر تحميل السيارة');
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-right flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">تحميل بضاعة للسيارة</h3>
              <p className="text-xs text-slate-400">نقل رصيد من المخزن الرئيسي إلى السيارة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
          {/* Group filter chips */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">تصفية بالمجموعة</label>
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {['الكل', ...groups].map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => {
                    setSelectedGroup(g);
                    setSelectedProductId('');
                  }}
                  className={`text-xs px-2.5 py-1 rounded-xl whitespace-nowrap transition active:scale-95 ${
                    selectedGroup === g
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Product selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">اختر الصنف المراد تحميله *</label>
            {filteredProducts.length > 0 ? (
              <select
                value={activeProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                {filteredProducts.map((p) => {
                  const mQty = mainInventory.get(p.id) || 0;
                  return (
                    <option key={p.id} value={p.id}>
                      {p.name} — متاح بالمخزن: {mQty}
                    </option>
                  );
                })}
              </select>
            ) : (
              <div className="p-3 bg-slate-800/60 rounded-xl text-xs text-amber-400 border border-amber-500/20 text-center">
                لا يوجد رصيد متاح في المخزن لهذه المجموعة حالياً
              </div>
            )}
          </div>

          {/* Stock comparison badge */}
          {activeProductId && (
            <div className="grid grid-cols-2 gap-2 p-3 bg-slate-800/40 rounded-2xl border border-slate-750">
              <div className="text-center">
                <span className="text-[10px] text-slate-400 block">المخزن الرئيسي</span>
                <span className="text-base font-black text-sky-400 font-mono">{warehouseQty}</span>
              </div>
              <div className="text-center">
                <span className="text-[10px] text-slate-400 block">حمولة السيارة الحالية</span>
                <span className="text-base font-black text-emerald-400 font-mono">{currentVanQty}</span>
              </div>
            </div>
          )}

          {/* Qty Input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">الكمية المراد تحميلها للسيارة *</label>
            <input
              type="number"
              min="1"
              max={warehouseQty}
              value={qty}
              onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full font-mono text-sm font-bold bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={loading || !activeProductId || warehouseQty <= 0}
              className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg shadow-amber-950"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'جاري التحميل…' : 'اعتماد التحميل ونقل الرصيد'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
