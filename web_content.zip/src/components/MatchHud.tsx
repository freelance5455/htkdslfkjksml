import React, { useEffect, useRef, useState } from 'react';
import { Camera, Pause, Play, RotateCcw, Volume2, VolumeX, LogOut } from 'lucide-react';
import { TRANSLATIONS } from '../i18n/translations';
import {
  CameraPreset,
  Club,
  Language,
  MatchStats,
  TouchMode,
} from '../types/game';
import { ClubCrest } from './ClubCrest';
import { LiveHudSnapshot, MatchInputState } from './MatchCanvas';

interface MatchHudProps {
  homeClub: Club;
  awayClub: Club;
  hud: LiveHudSnapshot;
  matchStats: MatchStats | null;
  paused: boolean;
  cameraPreset: CameraPreset;
  language: Language;
  touchMode: TouchMode;
  muted: boolean;
  caption: string;
  inputRef: React.MutableRefObject<MatchInputState>;
  onTogglePause: () => void;
  onChangeCamera: (preset: CameraPreset) => void;
  onToggleMute: () => void;
  onRestart: () => void;
  onExit: () => void;
}

export const MatchHud: React.FC<MatchHudProps> = ({
  homeClub,
  awayClub,
  hud,
  matchStats,
  paused,
  cameraPreset,
  language,
  touchMode,
  muted,
  caption,
  inputRef,
  onTogglePause,
  onChangeCamera,
  onToggleMute,
  onRestart,
  onExit,
}) => {
  const t = TRANSLATIONS[language];
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const joyTouchId = useRef<number | null>(null);
  const joyOrigin = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const check = () => {
      const coarse = window.matchMedia('(pointer: coarse)').matches;
      setIsTouchDevice(coarse || 'ontouchstart' in window || window.innerWidth < 900);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const showTouchControls = touchMode === 'on' || (touchMode === 'auto' && isTouchDevice);

  // Desktop Keyboard Controls
  useEffect(() => {
    const held = new Set<string>();

    const syncMove = () => {
      let mx = 0;
      let mz = 0;
      if (held.has('KeyA') || held.has('ArrowLeft')) mx -= 1;
      if (held.has('KeyD') || held.has('ArrowRight')) mx += 1;
      if (held.has('KeyW') || held.has('ArrowUp')) mz -= 1;
      if (held.has('KeyS') || held.has('ArrowDown')) mz += 1;
      inputRef.current.moveX = mx;
      inputRef.current.moveZ = mz;
      inputRef.current.sprint = held.has('KeyI') || held.has('ShiftLeft') || held.has('ShiftRight');
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape' || e.code === 'KeyP') {
        e.preventDefault();
        onTogglePause();
        return;
      }
      const isControl = [
        'KeyW', 'KeyA', 'KeyS', 'KeyD',
        'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
        'KeyJ', 'KeyK', 'KeyL', 'KeyI', 'ShiftLeft', 'ShiftRight', 'Space',
      ].includes(e.code);

      if (!isControl) return;
      e.preventDefault();

      if (!held.has(e.code)) {
        if (e.code === 'KeyJ') inputRef.current.passJustPressed = true;
        if (e.code === 'KeyK' || e.code === 'Space') inputRef.current.shootJustPressed = true;
        if (e.code === 'KeyL') inputRef.current.crossJustPressed = true;
      }
      held.add(e.code);
      syncMove();
    };

    const onKeyUp = (e: KeyboardEvent) => {
      held.delete(e.code);
      syncMove();
    };

    const onBlur = () => {
      held.clear();
      inputRef.current.moveX = 0;
      inputRef.current.moveZ = 0;
      inputRef.current.sprint = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [inputRef, onTogglePause]);

  // Touch Virtual Joystick Handlers
  const handleJoyStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (joyTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    if (!touch) return;
    joyTouchId.current = touch.identifier;
    const rect = e.currentTarget.getBoundingClientRect();
    joyOrigin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    updateJoyFromTouch(touch.clientX, touch.clientY);
  };

  const handleJoyMove = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joyTouchId.current) {
        updateJoyFromTouch(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoyEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joyTouchId.current) {
        joyTouchId.current = null;
        setKnobOffset({ x: 0, y: 0 });
        inputRef.current.moveX = 0;
        inputRef.current.moveZ = 0;
        break;
      }
    }
  };

  const updateJoyFromTouch = (cx: number, cy: number) => {
    const maxR = 44;
    const dx = cx - joyOrigin.current.x;
    const dy = cy - joyOrigin.current.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, maxR);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * clamped;
    const ky = Math.sin(angle) * clamped;
    setKnobOffset({ x: kx, y: ky });
    inputRef.current.moveX = kx / maxR;
    inputRef.current.moveZ = ky / maxR;
  };

  const cycleCamera = () => {
    const order: CameraPreset[] = ['tv', 'tele', 'endToEnd'];
    const next = order[(order.indexOf(cameraPreset) + 1) % order.length];
    onChangeCamera(next);
  };

  const formattedClock = `${String(hud.matchMinute).padStart(2, '0')}:00`;
  const addedLabel =
    (hud.half === 1 && hud.matchMinute >= 45) || (hud.half === 2 && hud.matchMinute >= 90)
      ? `+${hud.addedMinutes}'`
      : '';

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 sm:p-5 select-none">
      {/* TOP BAR: Broadcast Scoreboard + Utility Controls */}
      <div className="flex items-start justify-between gap-3">
        {/* Broadcast Scorebug (Solid dark surface — zero backdrop-filter over WebGL) */}
        <div className="pointer-events-auto flex items-center bg-[#070B14]/92 border border-slate-700/70 rounded-lg shadow-xl overflow-hidden">
          <div className="w-2 self-stretch" style={{ backgroundColor: homeClub.primaryColor }} />
          <div className="flex items-center gap-2 px-3 py-1.5">
            <span className="font-display font-bold text-base sm:text-lg tracking-wider text-white">
              {homeClub.abbr}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 border-x border-slate-700/70 font-mono-num text-lg sm:text-xl font-bold text-amber-400">
            <span>{hud.homeScore}</span>
            <span className="text-slate-500 text-sm">-</span>
            <span>{hud.awayScore}</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5">
            <span className="font-display font-bold text-base sm:text-lg tracking-wider text-white">
              {awayClub.abbr}
            </span>
          </div>
          <div className="w-2 self-stretch" style={{ backgroundColor: awayClub.primaryColor }} />

          <div className="flex items-center gap-2 bg-[#0D1426] px-3 py-1.5 border-l border-slate-700/70">
            <span className="text-xs font-semibold text-slate-400">{hud.half}ºT</span>
            <span className="font-mono-num text-sm sm:text-base font-bold text-emerald-400">
              {formattedClock}
            </span>
            {addedLabel && (
              <span className="font-mono-num text-xs font-bold text-amber-400">{addedLabel}</span>
            )}
          </div>
        </div>

        {/* Live Commentary Caption Strip (Hidden on narrow overlap) */}
        {caption && (
          <div className="hidden lg:flex items-center max-w-md px-3.5 py-1.5 bg-[#070B14]/90 border border-slate-700/70 rounded-lg text-xs text-slate-200 truncate">
            <span className="text-amber-400 font-semibold mr-2">LIVE</span>
            <span className="truncate">{caption}</span>
          </div>
        )}

        {/* Top-Right Match Actions */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={cycleCamera}
            title={t.cameraAngle}
            className="h-10 px-3 flex items-center gap-1.5 bg-[#070B14]/90 hover:bg-slate-800 text-slate-200 border border-slate-700/70 rounded-lg text-xs font-semibold transition-transform active:scale-95"
          >
            <Camera className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline whitespace-nowrap">
              {cameraPreset === 'tv' ? t.camTv : cameraPreset === 'tele' ? t.camTele : t.camEnd}
            </span>
          </button>
          <button
            onClick={onToggleMute}
            aria-label="Audio"
            className="w-10 h-10 flex items-center justify-center bg-[#070B14]/90 hover:bg-slate-800 text-slate-200 border border-slate-700/70 rounded-lg transition-transform active:scale-95"
          >
            {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          <button
            onClick={onTogglePause}
            aria-label="Pause"
            className="w-10 h-10 flex items-center justify-center bg-[#070B14]/90 hover:bg-slate-800 text-slate-200 border border-slate-700/70 rounded-lg transition-transform active:scale-95"
          >
            <Pause className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </div>

      {/* CENTER OVERLAYS: Goal Celebration / Halftime */}
      <div className="flex flex-col items-center justify-center">
        {hud.phase === 'goal' && hud.goalTeam && (
          <div className="bg-[#070B14]/95 border-2 border-amber-400 rounded-xl px-8 py-5 text-center shadow-2xl transform transition-all">
            <div className="font-display font-extrabold italic text-4xl sm:text-6xl tracking-tight text-amber-400">
              {t.goalTitle}
            </div>
            <div className="mt-2 flex items-center justify-center gap-3 text-white font-display text-xl sm:text-2xl font-bold">
              <span>{hud.goalTeam === 'home' ? homeClub.name : awayClub.name}</span>
              <span className="text-slate-500">·</span>
              <span className="text-amber-300">{hud.goalScorer}</span>
            </div>
          </div>
        )}

        {hud.phase === 'halftime' && (
          <div className="bg-[#070B14]/95 border border-slate-600 rounded-xl px-7 py-4 text-center shadow-2xl">
            <div className="font-display font-bold text-2xl sm:text-3xl text-amber-400 uppercase tracking-wider">
              {t.halftime}
            </div>
            <div className="font-mono-num text-xl font-bold text-white mt-1">
              {homeClub.abbr} {hud.homeScore} - {hud.awayScore} {awayClub.abbr}
            </div>
          </div>
        )}
      </div>

      {/* BOTTOM ROW: Active Player Stamina, Tactical Minimap & Touch/Desktop Controls */}
      <div className="flex items-end justify-between gap-3">
        {/* Left Zone: Virtual Joystick (Mobile) OR Active Player + Keyboard Hint (Desktop) */}
        <div className="flex flex-col items-start gap-2">
          {/* Active Player Stamina Pill-free Bar */}
          <div className="bg-[#070B14]/90 border border-slate-700/70 rounded-lg px-3 py-2 min-w-[175px]">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-white truncate max-w-[115px]">
                {hud.activePlayerName}
              </span>
              <span className="font-mono-num text-amber-400 font-bold">
                {hud.activePlayerPos} · {hud.activePlayerOvr}
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${
                  hud.activePlayerStamina > 50
                    ? 'bg-emerald-400'
                    : hud.activePlayerStamina > 25
                    ? 'bg-amber-400'
                    : 'bg-rose-500'
                }`}
                style={{ width: `${hud.activePlayerStamina}%` }}
              />
            </div>
          </div>

          {showTouchControls && (
            <div
              onTouchStart={handleJoyStart}
              onTouchMove={handleJoyMove}
              onTouchEnd={handleJoyEnd}
              onTouchCancel={handleJoyEnd}
              className="pointer-events-auto relative w-28 h-28 rounded-full bg-slate-900/75 border-2 border-slate-600/80 flex items-center justify-center touch-none"
            >
              <div
                className="w-12 h-12 rounded-full bg-amber-400/90 border-2 border-white shadow-lg"
                style={{
                  transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
                }}
              />
            </div>
          )}
        </div>

        {/* Center: Tactical Minimap Radar + Desktop Controls Hint */}
        <div className="hidden sm:flex flex-col items-center gap-1.5">
          <div className="relative w-44 h-28 bg-[#0c3b20]/90 border border-slate-500/80 rounded-md overflow-hidden shadow-lg">
            {/* Pitch markings on radar */}
            <div className="absolute inset-y-0 left-1/2 w-px bg-white/30" />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full border border-white/30" />
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3.5 h-12 border-r border-y border-white/30" />
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-12 border-l border-y border-white/30" />

            {hud.radarPlayers.map((rp, idx) => (
              <div
                key={idx}
                className={`absolute w-2 h-2 -ml-1 -mt-1 rounded-full ${
                  rp.active ? 'ring-2 ring-amber-300 scale-125' : ''
                }`}
                style={{
                  left: `${Math.min(98, Math.max(2, rp.x * 100))}%`,
                  top: `${Math.min(96, Math.max(4, rp.z * 100))}%`,
                  backgroundColor: rp.team === 'home' ? homeClub.primaryColor : awayClub.primaryColor,
                  border: '1px solid rgba(255,255,255,0.8)',
                }}
              />
            ))}
            <div
              className="absolute w-2 h-2 -ml-1 -mt-1 rounded-full bg-amber-300 border border-black"
              style={{
                left: `${Math.min(98, Math.max(2, hud.radarBall.x * 100))}%`,
                top: `${Math.min(96, Math.max(4, hud.radarBall.z * 100))}%`,
              }}
            />
          </div>
          {!showTouchControls && (
            <div className="px-3 py-1 bg-[#070B14]/88 border border-slate-700/70 rounded text-[11px] text-slate-300 whitespace-nowrap">
              {t.controlsDesktop}
            </div>
          )}
        </div>

        {/* Right Zone: Touch Action Buttons [A] [B] [X] [C] */}
        {showTouchControls ? (
          <div className="pointer-events-auto grid grid-cols-2 gap-2.5 touch-none">
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                inputRef.current.crossJustPressed = true;
              }}
              className="w-14 h-14 rounded-full bg-sky-600/90 active:scale-90 border-2 border-sky-300 text-white font-display font-bold text-xs flex flex-col items-center justify-center shadow-lg"
            >
              <span className="text-sm leading-none">X</span>
              <span className="text-[9px] mt-0.5">{t.crossShort}</span>
            </button>
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                inputRef.current.sprint = true;
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                inputRef.current.sprint = false;
              }}
              onTouchCancel={() => {
                inputRef.current.sprint = false;
              }}
              className="w-14 h-14 rounded-full bg-amber-500/90 active:scale-90 border-2 border-amber-200 text-slate-950 font-display font-bold text-xs flex flex-col items-center justify-center shadow-lg"
            >
              <span className="text-sm leading-none">C</span>
              <span className="text-[9px] mt-0.5">{t.sprintShort}</span>
            </button>
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                inputRef.current.passJustPressed = true;
              }}
              className="w-14 h-14 rounded-full bg-emerald-600/90 active:scale-90 border-2 border-emerald-300 text-white font-display font-bold text-xs flex flex-col items-center justify-center shadow-lg"
            >
              <span className="text-sm leading-none">A</span>
              <span className="text-[9px] mt-0.5">{hud.hasBall ? t.passShort : t.switchShort}</span>
            </button>
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                inputRef.current.shootJustPressed = true;
              }}
              className="w-14 h-14 rounded-full bg-rose-600/90 active:scale-90 border-2 border-rose-300 text-white font-display font-bold text-xs flex flex-col items-center justify-center shadow-lg"
            >
              <span className="text-sm leading-none">B</span>
              <span className="text-[9px] mt-0.5">{hud.hasBall ? t.shootShort : t.tackleShort}</span>
            </button>
          </div>
        ) : (
          <div className="w-24" />
        )}
      </div>

      {/* PAUSE MODAL */}
      {paused && !matchStats && (
        <div className="pointer-events-auto fixed inset-0 bg-black/75 flex items-center justify-center p-4 z-40">
          <div className="w-full max-w-md bg-[#0D1426] border border-slate-700 rounded-xl p-6 shadow-2xl">
            <h2 className="font-display font-extrabold text-3xl text-white tracking-wide text-center">
              {t.paused}
            </h2>
            <div className="mt-5 flex flex-col gap-2.5">
              <button
                onClick={onTogglePause}
                className="w-full py-3 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <Play className="w-4 h-4" />
                {t.resume}
              </button>
              <button
                onClick={cycleCamera}
                className="w-full py-2.5 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-sm flex items-center justify-center gap-2 border border-slate-700"
              >
                <Camera className="w-4 h-4 text-amber-400" />
                {t.cameraAngle}: {cameraPreset === 'tv' ? t.camTv : cameraPreset === 'tele' ? t.camTele : t.camEnd}
              </button>
              <button
                onClick={onRestart}
                className="w-full py-2.5 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-sm flex items-center justify-center gap-2 border border-slate-700"
              >
                <RotateCcw className="w-4 h-4 text-sky-400" />
                {t.restartMatch}
              </button>
              <button
                onClick={onExit}
                className="w-full py-2.5 px-4 rounded-lg bg-rose-950/70 hover:bg-rose-900 text-rose-200 font-semibold text-sm flex items-center justify-center gap-2 border border-rose-800/70"
              >
                <LogOut className="w-4 h-4" />
                {t.exitToMenu}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL-TIME MATCH SUMMARY MODAL */}
      {matchStats && (
        <div className="pointer-events-auto fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-40">
          <div className="w-full max-w-lg bg-[#0D1426] border border-amber-400/50 rounded-xl p-6 shadow-2xl">
            <div className="text-center text-xs font-semibold text-amber-400 tracking-wider uppercase">
              {t.fulltime}
            </div>

            <div className="mt-4 flex items-center justify-between gap-4 bg-[#070B14] border border-slate-800 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <ClubCrest club={homeClub} size={46} />
                <div>
                  <div className="font-display font-bold text-lg text-white">{homeClub.name}</div>
                  <div className="text-xs text-slate-400">{homeClub.abbr}</div>
                </div>
              </div>
              <div className="font-mono-num text-3xl sm:text-4xl font-extrabold text-amber-400">
                {matchStats.homeScore} - {matchStats.awayScore}
              </div>
              <div className="flex items-center gap-3 text-right">
                <div>
                  <div className="font-display font-bold text-lg text-white">{awayClub.name}</div>
                  <div className="text-xs text-slate-400">{awayClub.abbr}</div>
                </div>
                <ClubCrest club={awayClub} size={46} />
              </div>
            </div>

            {/* Stats Table */}
            <div className="mt-4 space-y-2.5 text-sm">
              {[
                [t.possession, `${matchStats.homePossession}%`, `${matchStats.awayPossession}%`],
                [t.shots, String(matchStats.homeShots), String(matchStats.awayShots)],
                [t.onTarget, String(matchStats.homeOnTarget), String(matchStats.awayOnTarget)],
                [t.passes, String(matchStats.homePasses), String(matchStats.awayPasses)],
              ].map(([label, hv, av]) => (
                <div key={label} className="flex items-center justify-between px-3 py-2 bg-slate-900/70 rounded-lg">
                  <span className="font-mono-num font-bold text-white w-14">{hv}</span>
                  <span className="text-xs text-slate-400 font-medium">{label}</span>
                  <span className="font-mono-num font-bold text-white w-14 text-right">{av}</span>
                </div>
              ))}
            </div>

            {matchStats.scorers.length > 0 && (
              <div className="mt-4 text-xs text-slate-300 bg-slate-900/50 rounded-lg p-3 max-h-24 overflow-y-auto">
                {matchStats.scorers.map((s, idx) => (
                  <div key={idx} className="flex justify-between py-0.5">
                    <span>
                      {s.team === 'home' ? homeClub.abbr : awayClub.abbr} · {s.playerName}
                    </span>
                    <span className="font-mono-num text-amber-400">{s.minute}&apos;</span>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-5 grid grid-cols-2 gap-3">
              <button
                onClick={onRestart}
                className="py-2.5 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm border border-slate-700"
              >
                {t.playAgain}
              </button>
              <button
                onClick={onExit}
                className="py-2.5 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm"
              >
                {t.backHub}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
