import React, { useState, useMemo } from 'react';
import {
  X,
  Scale,
  Banknote,
  RotateCcw,
  Copy,
  Check,
  Plus,
  Minus,
  Sun,
  Moon,
  Sparkles,
  Calculator,
  Palette,
} from 'lucide-react';
import { AppSettings, ThemeMode, ThemeAccent } from '../types';
import { toBanglaDigits, formatCurrency } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';

interface BazarCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  appSettings: AppSettings;
  onUpdateSettings?: (newSettings: AppSettings) => void;
}

type CalculatorMode = 'bazar' | 'note_counter';

// Note denominations in Bangladeshi Taka
const DENOMINATIONS = [
  { value: 1000, labelBn: '১০০০ টাকা', labelEn: '1000 Taka' },
  { value: 500, labelBn: '৫০০ টাকা', labelEn: '500 Taka' },
  { value: 200, labelBn: '২০০ টাকা', labelEn: '200 Taka' },
  { value: 100, labelBn: '১০০ টাকা', labelEn: '100 Taka' },
  { value: 50, labelBn: '৫০ টাকা', labelEn: '50 Taka' },
  { value: 20, labelBn: '২০ টাকা', labelEn: '20 Taka' },
  { value: 10, labelBn: '১০ টাকা', labelEn: '10 Taka' },
  { value: 5, labelBn: '৫ টাকা', labelEn: '5 Taka' },
  { value: 2, labelBn: '২ টাকা', labelEn: '2 Taka' },
  { value: 1, labelBn: '১ টাকা', labelEn: '1 Taka' },
];

export const BazarCalculatorModal: React.FC<BazarCalculatorModalProps> = ({
  isOpen,
  onClose,
  appSettings,
  onUpdateSettings,
}) => {
  const isEn = appSettings.language === 'en';
  const isOled = appSettings.themeMode === 'oled';
  const isLight = appSettings.themeMode === 'light';
  const isDark = appSettings.themeMode === 'dark';
  const useBangla = appSettings.useBanglaDigits;
  const accent: ThemeAccent = appSettings.themeAccent || 'emerald';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const [mode, setMode] = useState<CalculatorMode>('bazar');

  // --- STATE FOR BAZAR CALCULATOR ---
  // Section 1: Gram to Price
  const [gramKgPrice, setGramKgPrice] = useState<string>('');
  const [gramAmount, setGramAmount] = useState<string>('');

  // Section 2: Price to Gram
  const [priceKgPrice, setPriceKgPrice] = useState<string>('');
  const [targetTaka, setTargetTaka] = useState<string>('');

  // Currently focused input in Bazar Calculator (for custom numpad)
  type ActiveField = 'gramKgPrice' | 'gramAmount' | 'priceKgPrice' | 'targetTaka';
  const [activeField, setActiveField] = useState<ActiveField>('gramKgPrice');

  // --- STATE FOR NOTE COUNTER ---
  const [noteCounts, setNoteCounts] = useState<Record<number, number>>({
    1000: 0,
    500: 0,
    200: 0,
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    2: 0,
    1: 0,
  });

  const [copiedNoteSummary, setCopiedNoteSummary] = useState(false);

  // --- CALCULATIONS FOR BAZAR CALCULATOR ---
  // 1. Gram -> Price: (PricePerKg / 1000) * grams
  const computedPrice = useMemo(() => {
    const kgPrice = parseFloat(gramKgPrice);
    const grams = parseFloat(gramAmount);
    if (!kgPrice || !grams || kgPrice <= 0 || grams <= 0) return 0;
    return (kgPrice / 1000) * grams;
  }, [gramKgPrice, gramAmount]);

  // 2. Price -> Gram: (Taka / PricePerKg) * 1000
  const computedGrams = useMemo(() => {
    const kgPrice = parseFloat(priceKgPrice);
    const taka = parseFloat(targetTaka);
    if (!kgPrice || !taka || kgPrice <= 0 || taka <= 0) return 0;
    return (taka / kgPrice) * 1000;
  }, [priceKgPrice, targetTaka]);

  // --- CALCULATIONS FOR NOTE COUNTER ---
  const noteStats = useMemo(() => {
    let totalAmount = 0;
    let totalNotes = 0;

    DENOMINATIONS.forEach((d) => {
      const count = noteCounts[d.value] || 0;
      totalNotes += count;
      totalAmount += count * d.value;
    });

    return { totalAmount, totalNotes };
  }, [noteCounts]);

  // Handle On-Screen Numpad Key Press for Bazar Calculator
  const handleKeypadPress = (val: string) => {
    let currentVal = '';
    if (activeField === 'gramKgPrice') currentVal = gramKgPrice;
    else if (activeField === 'gramAmount') currentVal = gramAmount;
    else if (activeField === 'priceKgPrice') currentVal = priceKgPrice;
    else if (activeField === 'targetTaka') currentVal = targetTaka;

    if (val === 'C') {
      // Clear current field
      if (activeField === 'gramKgPrice') setGramKgPrice('');
      else if (activeField === 'gramAmount') setGramAmount('');
      else if (activeField === 'priceKgPrice') setPriceKgPrice('');
      else if (activeField === 'targetTaka') setTargetTaka('');
      return;
    }

    if (val === '.') {
      if (currentVal.includes('.')) return;
      if (currentVal === '') currentVal = '0';
    }

    // Limit maximum length to 8 digits
    if (currentVal.length >= 8) return;

    const newVal = currentVal + val;

    if (activeField === 'gramKgPrice') setGramKgPrice(newVal);
    else if (activeField === 'gramAmount') setGramAmount(newVal);
    else if (activeField === 'priceKgPrice') setPriceKgPrice(newVal);
    else if (activeField === 'targetTaka') setTargetTaka(newVal);
  };

  // Move to next input field
  const handleNextField = () => {
    const order: ActiveField[] = ['gramKgPrice', 'gramAmount', 'priceKgPrice', 'targetTaka'];
    const idx = order.indexOf(activeField);
    const nextIdx = (idx + 1) % order.length;
    setActiveField(order[nextIdx]);
  };

  // Reset Bazar Calculator
  const handleResetBazar = () => {
    setGramKgPrice('');
    setGramAmount('');
    setPriceKgPrice('');
    setTargetTaka('');
  };

  // Note Counter update
  const handleUpdateNoteCount = (denom: number, val: number | string) => {
    const num = typeof val === 'string' ? parseInt(val.replace(/\D/g, ''), 10) || 0 : val;
    setNoteCounts((prev) => ({
      ...prev,
      [denom]: Math.max(0, num),
    }));
  };

  const handleResetNotes = () => {
    setNoteCounts({
      1000: 0,
      500: 0,
      200: 0,
      100: 0,
      50: 0,
      20: 0,
      10: 0,
      5: 0,
      2: 0,
      1: 0,
    });
  };

  const handleCopyNoteSummary = async () => {
    let summary = isEn
      ? `💵 Onu Finance - Cash Note Counter\n`
      : `💵 Onu Finance - নোট গনক বিবরণী\n`;
    summary += `---------------------------------\n`;

    DENOMINATIONS.forEach((d) => {
      const count = noteCounts[d.value] || 0;
      if (count > 0) {
        summary += `${isEn ? d.labelEn : d.labelBn}: ${count} টি = ৳${(count * d.value).toLocaleString()}\n`;
      }
    });

    summary += `---------------------------------\n`;
    summary += `${isEn ? 'Total Cash' : 'সর্বমোট টাকা'}: ৳${noteStats.totalAmount.toLocaleString()} (${noteStats.totalNotes} টি নোট)\n`;

    try {
      await navigator.clipboard.writeText(summary);
      setCopiedNoteSummary(true);
      setTimeout(() => setCopiedNoteSummary(false), 2500);
    } catch {
      // ignore
    }
  };

  // Helper for displaying numbers
  const displayNum = (num: number | string, decimals = 2) => {
    if (num === '' || num === 0) {
      return useBangla ? '০' : '0';
    }
    const n = typeof num === 'string' ? parseFloat(num) : num;
    if (isNaN(n)) return useBangla ? '০' : '0';

    const formatted = Number.isInteger(n) ? n.toString() : n.toFixed(decimals).replace(/\.?0+$/, '');
    return useBangla ? toBanglaDigits(formatted) : formatted;
  };

  // Cycle through Theme Modes (Light -> Dark -> OLED -> Light)
  const handleCycleThemeMode = () => {
    if (!onUpdateSettings) return;
    const modes: ThemeMode[] = ['light', 'dark', 'oled'];
    const nextIdx = (modes.indexOf(appSettings.themeMode) + 1) % modes.length;
    onUpdateSettings({ ...appSettings, themeMode: modes[nextIdx] });
  };

  // Cycle through Accent Colors
  const handleCycleThemeAccent = () => {
    if (!onUpdateSettings) return;
    const accents: ThemeAccent[] = [
      'green',
      'teal',
      'cyan',
      'blue',
      'navy',
      'purple',
      'magenta',
      'red',
      'orange',
      'yellow',
    ];
    const nextIdx = (accents.indexOf(accent) + 1) % accents.length;
    onUpdateSettings({ ...appSettings, themeAccent: accents[nextIdx] });
  };

  // --- THEME COLOR SPECIFICATION MAP ---
  const themeTokens = useMemo(() => {
    // Mode-specific container & card backgrounds
    const modalBg = isOled
      ? 'bg-black border-zinc-800 text-white shadow-2xl'
      : isLight
      ? 'bg-white border-sky-200 text-slate-900 shadow-2xl'
      : 'bg-slate-900 border-slate-700 text-slate-100 shadow-2xl';

    const cardFrameBg = isOled
      ? 'bg-zinc-950 border-zinc-800 text-white'
      : isLight
      ? 'bg-white border-slate-200 text-slate-900'
      : 'bg-slate-800 border-slate-700 text-slate-100';

    const subHeaderBg = isOled
      ? 'bg-zinc-900 text-zinc-200 divide-zinc-800'
      : isLight
      ? 'bg-slate-100 text-slate-800 divide-slate-200'
      : 'bg-slate-850 text-slate-200 divide-slate-700';

    const modalFooterBg = isOled
      ? 'bg-zinc-950 border-zinc-900 text-zinc-400'
      : isLight
      ? 'bg-slate-100 border-slate-200 text-slate-700'
      : 'bg-slate-950 border-slate-800 text-slate-300';

    // Accent mappings
    switch (accent) {
      case 'indigo':
      case 'navy':
      case 'blue':
      case 'cyan':
        return {
          modalBg,
          cardFrameBg,
          subHeaderBg,
          modalFooterBg,
          headerBg: isOled ? 'bg-indigo-950' : isDark ? 'bg-indigo-800' : 'bg-indigo-700',
          headerSubBg: isOled ? 'bg-indigo-950/90' : isDark ? 'bg-indigo-900/90' : 'bg-indigo-800/90',
          headerSubBorder: 'border-indigo-500/30',
          titlePill: isOled
            ? 'border-indigo-500/80 bg-zinc-900 text-indigo-300'
            : isLight
            ? 'border-indigo-600 bg-indigo-50 text-indigo-800'
            : 'border-indigo-500 bg-indigo-950/60 text-indigo-300',
          bannerBg: 'bg-indigo-600 text-white',
          tableBorder: 'border-indigo-600 dark:border-indigo-500',
          tableSubTotalColHeader: isOled
            ? 'bg-indigo-950/60 text-indigo-200'
            : isDark
            ? 'bg-indigo-900/50 text-indigo-200'
            : 'bg-indigo-100/70 text-indigo-900',
          activeCellRing: 'ring-2 ring-indigo-500 ring-inset',
          activeCellBg: isOled ? 'bg-indigo-950/40' : isDark ? 'bg-indigo-950/30' : 'bg-indigo-50/80',
          activeText: isLight ? 'text-indigo-700' : 'text-indigo-400',
          computedCellBg: isOled ? 'bg-zinc-900' : isDark ? 'bg-indigo-950/60' : 'bg-indigo-50/70',
          computedCellText: isLight ? 'text-indigo-700' : 'text-indigo-300',
          keypadNumberBtn: 'bg-indigo-700 hover:bg-indigo-600 active:scale-95 text-white',
          keypadEqualsBtn: 'bg-indigo-500 hover:bg-indigo-400 active:scale-95 text-white',
          summaryBoxBorder: 'border-indigo-600 dark:border-indigo-500',
          summaryBoxBg: isOled ? 'bg-zinc-950' : isDark ? 'bg-indigo-950/40' : 'bg-indigo-50/80',
          summaryBoxText: isLight ? 'text-indigo-700' : 'text-indigo-300',
          copyBtn: 'bg-indigo-600 hover:bg-indigo-500 text-white',
          tabActiveText: 'text-indigo-900',
          badgeBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/30',
        };

      case 'purple':
      case 'magenta':
        return {
          modalBg,
          cardFrameBg,
          subHeaderBg,
          modalFooterBg,
          headerBg: isOled ? 'bg-purple-950' : isDark ? 'bg-purple-800' : 'bg-purple-700',
          headerSubBg: isOled ? 'bg-purple-950/90' : isDark ? 'bg-purple-900/90' : 'bg-purple-800/90',
          headerSubBorder: 'border-purple-500/30',
          titlePill: isOled
            ? 'border-purple-500/80 bg-zinc-900 text-purple-300'
            : isLight
            ? 'border-purple-600 bg-purple-50 text-purple-800'
            : 'border-purple-500 bg-purple-950/60 text-purple-300',
          bannerBg: 'bg-purple-600 text-white',
          tableBorder: 'border-purple-600 dark:border-purple-500',
          tableSubTotalColHeader: isOled
            ? 'bg-purple-950/60 text-purple-200'
            : isDark
            ? 'bg-purple-900/50 text-purple-200'
            : 'bg-purple-100/70 text-purple-900',
          activeCellRing: 'ring-2 ring-purple-500 ring-inset',
          activeCellBg: isOled ? 'bg-purple-950/40' : isDark ? 'bg-purple-950/30' : 'bg-purple-50/80',
          activeText: isLight ? 'text-purple-700' : 'text-purple-400',
          computedCellBg: isOled ? 'bg-zinc-900' : isDark ? 'bg-purple-950/60' : 'bg-purple-50/70',
          computedCellText: isLight ? 'text-purple-700' : 'text-purple-300',
          keypadNumberBtn: 'bg-purple-700 hover:bg-purple-600 active:scale-95 text-white',
          keypadEqualsBtn: 'bg-purple-500 hover:bg-purple-400 active:scale-95 text-white',
          summaryBoxBorder: 'border-purple-600 dark:border-purple-500',
          summaryBoxBg: isOled ? 'bg-zinc-950' : isDark ? 'bg-purple-950/40' : 'bg-purple-50/80',
          summaryBoxText: isLight ? 'text-purple-700' : 'text-purple-300',
          copyBtn: 'bg-purple-600 hover:bg-purple-500 text-white',
          tabActiveText: 'text-purple-900',
          badgeBg: 'bg-purple-500/20 text-purple-300 border-purple-400/30',
        };

      case 'amber':
      case 'orange':
      case 'yellow':
      case 'red':
        return {
          modalBg,
          cardFrameBg,
          subHeaderBg,
          modalFooterBg,
          headerBg: isOled ? 'bg-amber-950' : isDark ? 'bg-amber-700' : 'bg-amber-600',
          headerSubBg: isOled ? 'bg-amber-950/90' : isDark ? 'bg-amber-800/90' : 'bg-amber-700/90',
          headerSubBorder: 'border-amber-500/30',
          titlePill: isOled
            ? 'border-amber-500/80 bg-zinc-900 text-amber-300'
            : isLight
            ? 'border-amber-600 bg-amber-50 text-amber-800'
            : 'border-amber-500 bg-amber-950/60 text-amber-300',
          bannerBg: 'bg-amber-600 text-white',
          tableBorder: 'border-amber-600 dark:border-amber-500',
          tableSubTotalColHeader: isOled
            ? 'bg-amber-950/60 text-amber-200'
            : isDark
            ? 'bg-amber-900/50 text-amber-200'
            : 'bg-amber-100/70 text-amber-900',
          activeCellRing: 'ring-2 ring-amber-500 ring-inset',
          activeCellBg: isOled ? 'bg-amber-950/40' : isDark ? 'bg-amber-950/30' : 'bg-amber-50/80',
          activeText: isLight ? 'text-amber-700' : 'text-amber-400',
          computedCellBg: isOled ? 'bg-zinc-900' : isDark ? 'bg-amber-950/60' : 'bg-amber-50/70',
          computedCellText: isLight ? 'text-amber-700' : 'text-amber-300',
          keypadNumberBtn: 'bg-amber-600 hover:bg-amber-500 active:scale-95 text-white',
          keypadEqualsBtn: 'bg-amber-500 hover:bg-amber-400 active:scale-95 text-white',
          summaryBoxBorder: 'border-amber-600 dark:border-amber-500',
          summaryBoxBg: isOled ? 'bg-zinc-950' : isDark ? 'bg-amber-950/40' : 'bg-amber-50/80',
          summaryBoxText: isLight ? 'text-amber-700' : 'text-amber-300',
          copyBtn: 'bg-amber-600 hover:bg-amber-500 text-white',
          tabActiveText: 'text-amber-950',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-400/30',
        };

      case 'emerald':
      case 'green':
      case 'teal':
      default:
        return {
          modalBg,
          cardFrameBg,
          subHeaderBg,
          modalFooterBg,
          headerBg: isOled ? 'bg-emerald-950' : isDark ? 'bg-emerald-800' : 'bg-emerald-700',
          headerSubBg: isOled ? 'bg-emerald-950/90' : isDark ? 'bg-emerald-900/90' : 'bg-emerald-800/90',
          headerSubBorder: 'border-emerald-500/30',
          titlePill: isOled
            ? 'border-emerald-500/80 bg-zinc-900 text-emerald-300'
            : isLight
            ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
            : 'border-emerald-500 bg-emerald-950/60 text-emerald-300',
          bannerBg: 'bg-emerald-600 text-white',
          tableBorder: 'border-emerald-600 dark:border-emerald-500',
          tableSubTotalColHeader: isOled
            ? 'bg-emerald-950/60 text-emerald-200'
            : isDark
            ? 'bg-emerald-900/50 text-emerald-200'
            : 'bg-emerald-100/70 text-emerald-900',
          activeCellRing: 'ring-2 ring-emerald-500 ring-inset',
          activeCellBg: isOled ? 'bg-emerald-950/40' : isDark ? 'bg-emerald-950/30' : 'bg-emerald-50/80',
          activeText: isLight ? 'text-emerald-700' : 'text-emerald-400',
          computedCellBg: isOled ? 'bg-zinc-900' : isDark ? 'bg-emerald-950/60' : 'bg-emerald-50/70',
          computedCellText: isLight ? 'text-emerald-700' : 'text-emerald-300',
          keypadNumberBtn: 'bg-emerald-700 hover:bg-emerald-600 active:scale-95 text-white',
          keypadEqualsBtn: 'bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white',
          summaryBoxBorder: 'border-emerald-600 dark:border-emerald-500',
          summaryBoxBg: isOled ? 'bg-zinc-950' : isDark ? 'bg-emerald-950/40' : 'bg-emerald-50/80',
          summaryBoxText: isLight ? 'text-emerald-700' : 'text-emerald-300',
          copyBtn: 'bg-emerald-600 hover:bg-emerald-500 text-white',
          tabActiveText: 'text-emerald-900',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30',
        };
    }
  }, [accent, isLight, isDark, isOled]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`w-full max-w-md max-h-[96vh] flex flex-col rounded-3xl border overflow-hidden ${themeTokens.modalBg}`}
      >
        {/* Top Header */}
        <div
          className="p-3.5 sm:p-4 text-white flex items-center justify-between shrink-0 shadow-md"
          style={{ background: dualAccent.primaryGradient }}
        >
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-white/15 text-white">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-wide leading-tight">
                {mode === 'bazar'
                  ? isEn
                    ? 'Bazar Calculator'
                    : 'বাজার ক্যালকুলেটর'
                  : isEn
                  ? 'Note Counter'
                  : 'নোট গনক'}
              </h2>
              <p className="text-[10px] text-white/80 font-medium">
                {mode === 'bazar'
                  ? isEn
                    ? 'Calculate price by grams or grams by price'
                    : 'গ্রাম অনুযায়ী দাম ও দাম অনুযায়ী গ্রাম হিসাব'
                  : isEn
                  ? 'Calculate cash denominations and total'
                  : 'টাকার নোটের পরিমাণ ও সর্বমোট নগদ গণনা'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Quick Theme Mode Toggle Button */}
            {onUpdateSettings && (
              <button
                type="button"
                onClick={handleCycleThemeMode}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95 flex items-center gap-1 text-[11px] font-semibold"
                title={
                  isEn
                    ? `Theme: ${appSettings.themeMode} (Tap to change)`
                    : `থিম: ${appSettings.themeMode} (পরিবর্তন করতে ট্যাপ করুন)`
                }
              >
                {isLight && <Sun className="w-3.5 h-3.5 text-amber-300" />}
                {isDark && <Moon className="w-3.5 h-3.5 text-indigo-300" />}
                {isOled && <Sparkles className="w-3.5 h-3.5 text-emerald-300" />}
                <span className="hidden sm:inline uppercase text-[9px] tracking-wider font-bold">
                  {appSettings.themeMode}
                </span>
              </button>
            )}

            {/* Quick Accent Color Toggle Button */}
            {onUpdateSettings && (
              <button
                type="button"
                onClick={handleCycleThemeAccent}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
                title={
                  isEn
                    ? `Accent: ${accent} (Tap to cycle color)`
                    : `কালার অ্যাকসেন্ট: ${accent} (পরিবর্তন করুন)`
                }
              >
                <Palette className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95 ml-0.5"
              title={isEn ? 'Close' : 'বন্ধ করুন'}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode Switcher Tabs (ক্যালকুলেটর সুইচ করার অপশন) */}
        <div className={`p-2 ${themeTokens.headerSubBg} shrink-0 border-b ${themeTokens.headerSubBorder}`}>
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-black/25 border border-white/15">
            <button
              type="button"
              onClick={() => setMode('bazar')}
              className={`py-2 px-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                mode === 'bazar'
                  ? isLight
                    ? `bg-white ${themeTokens.tabActiveText} shadow-md scale-[1.01]`
                    : isOled
                    ? 'bg-zinc-900 text-white shadow-md scale-[1.01] border border-zinc-700'
                    : 'bg-slate-800 text-white shadow-md scale-[1.01] border border-slate-700'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <Scale className="w-4 h-4" />
              <span>{isEn ? 'Bazar Calculator' : 'বাজার ক্যালকুলেটর'}</span>
            </button>

            <button
              type="button"
              onClick={() => setMode('note_counter')}
              className={`py-2 px-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                mode === 'note_counter'
                  ? isLight
                    ? `bg-white ${themeTokens.tabActiveText} shadow-md scale-[1.01]`
                    : isOled
                    ? 'bg-zinc-900 text-white shadow-md scale-[1.01] border border-zinc-700'
                    : 'bg-slate-800 text-white shadow-md scale-[1.01] border border-slate-700'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              <Banknote className="w-4 h-4" />
              <span>{isEn ? 'Note Counter' : 'নোট গনক'}</span>
            </button>
          </div>
        </div>

        {/* Scrollable Main Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
          {/* ========================================================= */}
          {/* TAB 1: BAZAR CALCULATOR */}
          {/* ========================================================= */}
          {mode === 'bazar' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              {/* Header Title Pill */}
              <div className="text-center">
                <div
                  className={`inline-block px-5 py-1.5 rounded-full border-2 font-black text-sm tracking-wide shadow-xs ${themeTokens.titlePill}`}
                >
                  {isEn ? 'Bazar Calculator' : 'বাজার ক্যালকুলেটর'}
                </div>
              </div>

              {/* CARD 1: গ্রাম অনুযায়ী দাম নির্ণয় করুন (Gram to Price) */}
              <div
                className={`rounded-2xl border-2 overflow-hidden shadow-sm ${themeTokens.cardFrameBg}`}
                style={{ borderColor: dualAccent.primary.hex }}
              >
                <div
                  className="text-center py-1.5 px-3 font-extrabold text-xs tracking-wide text-white"
                  style={{ background: dualAccent.primaryGradient }}
                >
                  {isEn ? 'Calculate Price by Grams' : 'গ্রাম অনুযায়ী দাম নির্ণয় করুন'}
                </div>

                <div className={`grid grid-cols-3 divide-x ${themeTokens.subHeaderBg}`}>
                  <div className="p-2 text-center text-[11px] font-bold">
                    {isEn ? '1 KG Price' : '১ কেজির দাম'}
                  </div>
                  <div className="p-2 text-center text-[11px] font-bold">
                    {isEn ? 'Grams to Buy' : 'কত গ্রাম কিনব'}
                  </div>
                  <div className={`p-2 text-center text-[11px] font-bold ${themeTokens.tableSubTotalColHeader}`}>
                    {isEn ? 'Total Price' : 'মোট দাম'}
                  </div>
                </div>

                <div
                  className={`grid grid-cols-3 divide-x ${
                    isOled
                      ? 'divide-zinc-800 bg-black text-white'
                      : isLight
                      ? 'divide-slate-200 bg-white text-slate-900'
                      : 'divide-slate-700 bg-slate-900 text-slate-100'
                  }`}
                >
                  {/* 1 KG Price Input */}
                  <div
                    onClick={() => setActiveField('gramKgPrice')}
                    className={`p-2.5 text-center cursor-pointer transition ${
                      activeField === 'gramKgPrice'
                        ? `${themeTokens.activeCellBg} ${themeTokens.activeCellRing} font-black`
                        : isOled
                        ? 'hover:bg-zinc-900'
                        : isLight
                        ? 'hover:bg-slate-50'
                        : 'hover:bg-slate-800'
                    }`}
                  >
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder={useBangla ? '০' : '0'}
                      value={useBangla ? toBanglaDigits(gramKgPrice) : gramKgPrice}
                      onFocus={() => setActiveField('gramKgPrice')}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/[^\d.]/g, '');
                        setGramKgPrice(raw);
                      }}
                      className={`w-full text-center text-sm font-bold bg-transparent outline-hidden ${themeTokens.activeText}`}
                    />
                    <span className="text-[9px] opacity-60 block mt-0.5">৳ (টাকা)</span>
                  </div>

                  {/* Grams Input */}
                  <div
                    onClick={() => setActiveField('gramAmount')}
                    className={`p-2.5 text-center cursor-pointer transition ${
                      activeField === 'gramAmount'
                        ? `${themeTokens.activeCellBg} ${themeTokens.activeCellRing} font-black`
                        : isOled
                        ? 'hover:bg-zinc-900'
                        : isLight
                        ? 'hover:bg-slate-50'
                        : 'hover:bg-slate-800'
                    }`}
                  >
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder={useBangla ? '০' : '0'}
                      value={useBangla ? toBanglaDigits(gramAmount) : gramAmount}
                      onFocus={() => setActiveField('gramAmount')}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/[^\d.]/g, '');
                        setGramAmount(raw);
                      }}
                      className={`w-full text-center text-sm font-bold bg-transparent outline-hidden ${themeTokens.activeText}`}
                    />
                    <span className="text-[9px] opacity-60 block mt-0.5">gm (গ্রাম)</span>
                  </div>

                  {/* Computed Price Output */}
                  <div className={`p-2.5 text-center flex flex-col justify-center ${themeTokens.computedCellBg}`}>
                    <span className={`text-sm font-black ${themeTokens.computedCellText}`}>
                      {displayNum(computedPrice)}
                    </span>
                    <span className={`text-[9px] font-bold mt-0.5 ${themeTokens.activeText}`}>
                      {appSettings.currencySymbol}
                    </span>
                  </div>
                </div>
              </div>

              {/* CARD 2: দাম অনুযায়ী গ্রাম নির্ণয় করুন (Price to Gram) */}
              <div
                className={`rounded-2xl border-2 overflow-hidden shadow-sm ${themeTokens.cardFrameBg}`}
                style={{ borderColor: dualAccent.primary.hex }}
              >
                <div
                  className="text-center py-1.5 px-3 font-extrabold text-xs tracking-wide text-white"
                  style={{ background: dualAccent.primaryGradient }}
                >
                  {isEn ? 'Calculate Grams by Price' : 'দাম অনুযায়ী গ্রাম নির্ণয় করুন'}
                </div>

                <div className={`grid grid-cols-3 divide-x ${themeTokens.subHeaderBg}`}>
                  <div className="p-2 text-center text-[11px] font-bold">
                    {isEn ? '1 KG Price' : '১ কেজির দাম'}
                  </div>
                  <div className="p-2 text-center text-[11px] font-bold">
                    {isEn ? 'Taka to Spend' : 'কত টাকার কিনব'}
                  </div>
                  <div className={`p-2 text-center text-[11px] font-bold ${themeTokens.tableSubTotalColHeader}`}>
                    {isEn ? 'Total Grams' : 'মোট গ্রাম'}
                  </div>
                </div>

                <div
                  className={`grid grid-cols-3 divide-x ${
                    isOled
                      ? 'divide-zinc-800 bg-black text-white'
                      : isLight
                      ? 'divide-slate-200 bg-white text-slate-900'
                      : 'divide-slate-700 bg-slate-900 text-slate-100'
                  }`}
                >
                  {/* 1 KG Price Input */}
                  <div
                    onClick={() => setActiveField('priceKgPrice')}
                    className={`p-2.5 text-center cursor-pointer transition ${
                      activeField === 'priceKgPrice'
                        ? `${themeTokens.activeCellBg} ${themeTokens.activeCellRing} font-black`
                        : isOled
                        ? 'hover:bg-zinc-900'
                        : isLight
                        ? 'hover:bg-slate-50'
                        : 'hover:bg-slate-800'
                    }`}
                  >
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder={useBangla ? '০' : '0'}
                      value={useBangla ? toBanglaDigits(priceKgPrice) : priceKgPrice}
                      onFocus={() => setActiveField('priceKgPrice')}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/[^\d.]/g, '');
                        setPriceKgPrice(raw);
                      }}
                      className={`w-full text-center text-sm font-bold bg-transparent outline-hidden ${themeTokens.activeText}`}
                    />
                    <span className="text-[9px] opacity-60 block mt-0.5">৳ (টাকা)</span>
                  </div>

                  {/* Taka Input */}
                  <div
                    onClick={() => setActiveField('targetTaka')}
                    className={`p-2.5 text-center cursor-pointer transition ${
                      activeField === 'targetTaka'
                        ? `${themeTokens.activeCellBg} ${themeTokens.activeCellRing} font-black`
                        : isOled
                        ? 'hover:bg-zinc-900'
                        : isLight
                        ? 'hover:bg-slate-50'
                        : 'hover:bg-slate-800'
                    }`}
                  >
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder={useBangla ? '০' : '0'}
                      value={useBangla ? toBanglaDigits(targetTaka) : targetTaka}
                      onFocus={() => setActiveField('targetTaka')}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/[^\d.]/g, '');
                        setTargetTaka(raw);
                      }}
                      className={`w-full text-center text-sm font-bold bg-transparent outline-hidden ${themeTokens.activeText}`}
                    />
                    <span className="text-[9px] opacity-60 block mt-0.5">৳ (বাজেট)</span>
                  </div>

                  {/* Computed Grams Output */}
                  <div className={`p-2.5 text-center flex flex-col justify-center ${themeTokens.computedCellBg}`}>
                    <span className={`text-sm font-black ${themeTokens.computedCellText}`}>
                      {displayNum(computedGrams)}
                    </span>
                    <span className={`text-[9px] font-bold mt-0.5 ${themeTokens.activeText}`}>
                      {isEn ? 'Grams' : 'গ্রাম'}
                    </span>
                  </div>
                </div>
              </div>

              {/* ACTIVE FIELD INDICATOR & QUICK ACTIONS */}
              <div className="flex items-center justify-between text-xs px-1">
                <span className="text-[11px] opacity-75 font-semibold">
                  {isEn ? 'Active field: ' : 'নির্বাচিত ঘর: '}
                  <strong className={themeTokens.activeText}>
                    {activeField === 'gramKgPrice' && (isEn ? 'Gram Section: 1 KG Price' : 'গ্রাম সেকশন: ১ কেজির দাম')}
                    {activeField === 'gramAmount' && (isEn ? 'Gram Section: Grams' : 'গ্রাম সেকশন: কত গ্রাম')}
                    {activeField === 'priceKgPrice' && (isEn ? 'Price Section: 1 KG Price' : 'দাম সেকশন: ১ কেজির দাম')}
                    {activeField === 'targetTaka' && (isEn ? 'Price Section: Taka' : 'দাম সেকশন: কত টাকার')}
                  </strong>
                </span>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleResetBazar}
                    className="flex items-center gap-1 text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>{isEn ? 'Clear' : 'মুছুন'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleNextField}
                    className={`text-[11px] font-bold underline ${themeTokens.activeText}`}
                  >
                    {isEn ? 'Next' : 'পরের ঘর'}
                  </button>
                </div>
              </div>

              {/* BENGALI ON-SCREEN NUMPAD */}
              <div className="grid grid-cols-3 gap-2 pt-1 select-none">
                {/* Row 1: ৭, ৮, ৯ */}
                <button
                  type="button"
                  onClick={() => handleKeypadPress('7')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৭' : '7'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('8')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৮' : '8'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('9')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৯' : '9'}
                </button>

                {/* Row 2: ৪, ৫, ৬ */}
                <button
                  type="button"
                  onClick={() => handleKeypadPress('4')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৪' : '4'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('5')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৫' : '5'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('6')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৬' : '6'}
                </button>

                {/* Row 3: ১, ২, ৩ */}
                <button
                  type="button"
                  onClick={() => handleKeypadPress('1')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '১' : '1'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('2')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '২' : '2'}
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('3')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '৩' : '3'}
                </button>

                {/* Row 4: C (Red), ০ (Themed), = (Themed Vibrant) */}
                <button
                  type="button"
                  onClick={() => handleKeypadPress('C')}
                  className="py-3 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-black text-xl shadow-xs transition"
                >
                  C
                </button>
                <button
                  type="button"
                  onClick={() => handleKeypadPress('0')}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {useBangla ? '০' : '0'}
                </button>
                <button
                  type="button"
                  onClick={handleNextField}
                  className="py-3 rounded-xl hover:opacity-90 active:scale-95 text-white font-black text-xl shadow-xs transition flex items-center justify-center"
                  style={{ backgroundColor: dualAccent.secondary.hex }}
                >
                  =
                </button>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: NOTE COUNTER / নোট গনক */}
          {/* ========================================================= */}
          {mode === 'note_counter' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* Header Title Pill */}
              <div className="text-center">
                <div
                  className={`inline-block px-5 py-1.5 rounded-full border-2 font-black text-sm tracking-wide shadow-xs ${themeTokens.titlePill}`}
                >
                  {isEn ? 'Note Counter (Cash Calculator)' : 'নোট গনক'}
                </div>
              </div>

              {/* Table Sub-Header */}
              <div
                className={`grid grid-cols-2 p-2 rounded-xl border-2 ${themeTokens.tableBorder} text-center font-black text-xs ${themeTokens.titlePill}`}
              >
                <div>{isEn ? 'Note Amount' : 'নোটের পরিমাণ'}</div>
                <div>{isEn ? 'Count / Total' : 'নোট সংখ্যা'}</div>
              </div>

              {/* Denomination Rows (১০০০, ৫০০, ২০০, ১০০, ৫০, ২০, ১০, ৫, ২, ১ টাকা) */}
              <div className="space-y-1.5">
                {DENOMINATIONS.map((d) => {
                  const count = noteCounts[d.value] || 0;
                  const rowTotal = count * d.value;

                  return (
                    <div key={d.value} className="grid grid-cols-2 gap-2 items-center">
                      {/* Left: Denomination Card */}
                      <div
                        className={`p-2.5 rounded-xl border-2 text-center font-bold text-xs sm:text-sm shadow-2xs ${
                          isOled
                            ? 'bg-zinc-950 border-zinc-800 text-zinc-100'
                            : isLight
                            ? 'bg-white border-slate-300 text-slate-800'
                            : 'bg-slate-800 border-slate-700 text-slate-200'
                        }`}
                      >
                        {isEn ? d.labelEn : d.labelBn}
                      </div>

                      {/* Right: Interactive Count Box & Subtotal */}
                      <div
                        className={`flex items-center gap-1.5 p-1 rounded-xl border ${
                          isOled
                            ? 'bg-black border-zinc-800 text-white'
                            : isLight
                            ? 'bg-slate-50 border-slate-200 text-slate-900'
                            : 'bg-slate-900 border-slate-700 text-slate-100'
                        }`}
                      >
                        {/* Minus */}
                        <button
                          type="button"
                          onClick={() => handleUpdateNoteCount(d.value, Math.max(0, count - 1))}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center active:scale-95 shadow-2xs shrink-0 ${
                            isOled
                              ? 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700'
                              : isLight
                              ? 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                          }`}
                        >
                          <Minus className="w-3 h-3" />
                        </button>

                        {/* Numeric Input */}
                        <div className="flex-1 text-center min-w-0">
                          <input
                            type="text"
                            inputMode="numeric"
                            value={count === 0 ? '0' : useBangla ? toBanglaDigits(count) : count}
                            onChange={(e) => handleUpdateNoteCount(d.value, e.target.value)}
                            className={`w-full text-center font-black text-sm bg-transparent outline-hidden ${themeTokens.activeText}`}
                          />
                          {count > 0 && (
                            <span className="text-[9px] opacity-60 block truncate leading-none">
                              = {formatCurrency(rowTotal, useBangla, appSettings.currencySymbol)}
                            </span>
                          )}
                        </div>

                        {/* Plus */}
                        <button
                          type="button"
                          onClick={() => handleUpdateNoteCount(d.value, count + 1)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center active:scale-95 shadow-2xs shrink-0 text-white font-bold"
                          style={{ backgroundColor: dualAccent.primary.hex }}
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Grand Total Display */}
              <div
                className={`mt-4 p-3.5 rounded-2xl border-2 ${themeTokens.summaryBoxBg} text-center shadow-md space-y-1`}
                style={{ borderColor: dualAccent.primary.hex }}
              >
                <div className="flex items-center justify-between text-xs px-2 opacity-80 font-bold">
                  <span>{isEn ? 'Total Notes Count:' : 'মোট নোট সংখ্যা:'}</span>
                  <span className="font-extrabold" style={{ color: dualAccent.primary.hex }}>
                    {useBangla ? toBanglaDigits(noteStats.totalNotes) : noteStats.totalNotes} {isEn ? 'pcs' : 'টি'}
                  </span>
                </div>

                <div className="pt-1 flex items-baseline justify-center gap-2">
                  <span className="text-sm font-black opacity-90">
                    {isEn ? 'Grand Total =' : 'সর্বমোট ='}
                  </span>
                  <span className="text-xl sm:text-2xl font-black" style={{ color: dualAccent.primary.hex }}>
                    {formatCurrency(noteStats.totalAmount, useBangla, appSettings.currencySymbol)}
                  </span>
                </div>
              </div>

              {/* Action Buttons for Note Counter */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleResetNotes}
                  className="py-2 px-3 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Reset All' : 'সব রিসেট'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyNoteSummary}
                  className="py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm text-white"
                  style={dualAccent.primaryButtonStyle}
                >
                  {copiedNoteSummary ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>{isEn ? 'Copied!' : 'কপি হয়েছে!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{isEn ? 'Copy Total' : 'হিসাব কপি'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div
          className={`p-3 border-t flex items-center justify-between shrink-0 text-xs ${themeTokens.modalFooterBg}`}
        >
          <span className="text-[10px] opacity-75 font-medium">
            {isEn ? 'Bazar & Cash Calculator' : 'Onu Finance - বাজার ও নগদ গণনা'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-1.5 rounded-xl border font-bold text-xs transition ${
              isOled
                ? 'bg-zinc-900 border-zinc-800 text-white hover:bg-zinc-800'
                : isLight
                ? 'bg-white border-slate-300 text-slate-800 hover:bg-slate-100'
                : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700'
            }`}
          >
            {isEn ? 'Done' : 'সম্পন্ন'}
          </button>
        </div>
      </div>
    </div>
  );
};
