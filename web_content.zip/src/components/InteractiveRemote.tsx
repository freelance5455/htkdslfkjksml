import React, { useState, useRef } from 'react';
import { 
  Power, Volume2, VolumeX, ChevronUp, ChevronDown, ChevronLeft, ChevronRight,
  RotateCcw, Home, Menu, LogOut, Info, Tv, Radio, Wifi, Bluetooth,
  Play, Pause, FastForward, Rewind, Layers, Hash, MousePointer, ShieldAlert
} from 'lucide-react';
import { RemoteDevice, RemoteKey, IrPatternResult } from '../types/remote';
import { IrEncoder } from '../services/irEncoder';
import { BRAND_COMMAND_MAP } from '../data/defaultIrDatabase';

interface Props {
  currentDevice: RemoteDevice;
  onSignalEmitted: (signal: IrPatternResult, key: RemoteKey, description: string) => void;
  onDeviceChange?: (device: RemoteDevice) => void;
  devices: RemoteDevice[];
}

export const InteractiveRemote: React.FC<Props> = ({
  currentDevice,
  onSignalEmitted,
  onDeviceChange,
  devices,
}) => {
  const [activeTab, setActiveTab] = useState<'main' | 'numpad' | 'satellite' | 'touchpad'>('main');
  const [lastPressedKey, setLastPressedKey] = useState<RemoteKey | null>(null);
  const [touchCoords, setTouchCoords] = useState<{ x: number; y: number } | null>(null);
  const repeatTimerRef = useRef<any>(null);

  const triggerHaptic = () => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(20);
      } catch (e) {
        // Ignore vibration errors
      }
    }
  };

  const handleKeyPress = (key: RemoteKey) => {
    triggerHaptic();
    setLastPressedKey(key);

    const brand = currentDevice.brand;
    const mapping = (BRAND_COMMAND_MAP[brand] && BRAND_COMMAND_MAP[brand][key]) || 
                    BRAND_COMMAND_MAP['Sunplus'][key] || { hex: 0x12 };

    let signal: IrPatternResult;
    let desc = '';

    if (currentDevice.connectionType === 'WIFI') {
      // Simulate Wi-Fi command & also generate IR fallback
      signal = IrEncoder.encode(currentDevice.irProtocol || 'NEC', currentDevice.customAddress || 0x00FF, mapping.hex);
      desc = `[Wi-Fi IP: ${currentDevice.ipAddress}] أمر الشبكة: ${mapping.wifiCmd || key} (تم توليد نبضات IR كبديل)`;
    } else if (currentDevice.connectionType === 'BLUETOOTH') {
      signal = IrEncoder.encode(currentDevice.irProtocol || 'NEC', currentDevice.customAddress || 0x00FF, mapping.hex);
      desc = `[Bluetooth HID] رمز التقرير: 0x${(mapping.btHid || 0x0041).toString(16).toUpperCase()} (تم توليد نبضات IR كبديل)`;
    } else {
      // IR Mode
      signal = IrEncoder.encode(
        currentDevice.irProtocol || 'SUNPLUS',
        currentDevice.customAddress || 0x00FF,
        mapping.hex
      );
      desc = `[IR Blaster ${signal.frequencyHz / 1000}kHz] كود الزر: 0x${mapping.hex.toString(16).toUpperCase()}`;
    }

    onSignalEmitted(signal, key, desc);
  };

  const handleMouseDown = (key: RemoteKey) => {
    handleKeyPress(key);
    // Support long press repeat for Volume and Channel
    if (key === 'VOL_UP' || key === 'VOL_DOWN' || key === 'CH_UP' || key === 'CH_DOWN') {
      repeatTimerRef.current = setInterval(() => {
        handleKeyPress(key);
      }, 150);
    }
  };

  const handleMouseUp = () => {
    if (repeatTimerRef.current) {
      clearInterval(repeatTimerRef.current);
      repeatTimerRef.current = null;
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Phone / Remote Chassis */}
      <div className="w-full max-w-[340px] bg-slate-900 border-2 border-slate-700/80 rounded-[42px] p-4 shadow-2xl relative overflow-hidden backdrop-blur-xl">
        {/* Subtle top phone speaker / notch */}
        <div className="w-24 h-1.5 bg-slate-800 rounded-full mx-auto mb-3"></div>

        {/* Device Header Bar */}
        <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800/80 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                currentDevice.connectionType === 'IR' ? 'bg-amber-400 animate-pulse' :
                currentDevice.connectionType === 'WIFI' ? 'bg-emerald-400' : 'bg-blue-400'
              }`}></span>
              <span className="text-[11px] font-semibold text-slate-300">
                {currentDevice.connectionType === 'IR' ? 'الأشعة تحت الحمراء IR' :
                 currentDevice.connectionType === 'WIFI' ? `واي فاي (${currentDevice.ipAddress || 'LAN'})` : 'بلوتوث HID'}
              </span>
            </div>

            <div className="flex items-center gap-1 text-[11px] font-mono text-cyan-400">
              {currentDevice.irProtocol || 'SUNPLUS'}
            </div>
          </div>

          {/* Device dropdown */}
          <select
            value={currentDevice.id}
            onChange={(e) => {
              const dev = devices.find((d) => d.id === e.target.value);
              if (dev && onDeviceChange) onDeviceChange(dev);
            }}
            className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-lg p-2 font-medium focus:ring-1 focus:ring-cyan-500 outline-none"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.brand}) - {d.connectionType}
              </option>
            ))}
          </select>
        </div>

        {/* Top Control Bar: Power, Mute, Source */}
        <div className="flex items-center justify-between gap-3 mb-4 px-2">
          <button
            onMouseDown={() => handleMouseDown('POWER')}
            onMouseUp={handleMouseUp}
            className="w-12 h-12 rounded-full bg-red-600/20 hover:bg-red-600/30 active:scale-95 border border-red-500/40 text-red-400 flex items-center justify-center transition-all shadow-md group"
            title="تشغيل / إطفاء (Power)"
          >
            <Power className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </button>

          <button
            onClick={() => handleKeyPress('MUTE')}
            className="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 text-slate-300 flex items-center justify-center transition-all"
            title="كتم الصوت (Mute)"
          >
            <VolumeX className="w-4 h-4" />
          </button>

          <button
            onClick={() => handleKeyPress('SOURCE')}
            className="px-3.5 h-10 rounded-full bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 text-cyan-400 text-xs font-semibold flex items-center gap-1 transition-all"
            title="تغيير المصدر / المدخل (Source / Input)"
          >
            <Tv className="w-3.5 h-3.5" />
            <span>مدخل</span>
          </button>
        </div>

        {/* Navigation Tabs (Main, Numpad, Satellite, Touchpad) */}
        <div className="grid grid-cols-4 gap-1 bg-slate-950/70 p-1 rounded-xl mb-4 border border-slate-800">
          <button
            onClick={() => setActiveTab('main')}
            className={`py-1.5 text-[11px] font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'main' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3 h-3" />
            <span>الرئيسي</span>
          </button>
          <button
            onClick={() => setActiveTab('satellite')}
            className={`py-1.5 text-[11px] font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'satellite' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3 h-3" />
            <span>صن بلص</span>
          </button>
          <button
            onClick={() => setActiveTab('numpad')}
            className={`py-1.5 text-[11px] font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'numpad' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Hash className="w-3 h-3" />
            <span>الأرقام</span>
          </button>
          <button
            onClick={() => setActiveTab('touchpad')}
            className={`py-1.5 text-[11px] font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'touchpad' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <MousePointer className="w-3 h-3" />
            <span>اللمس</span>
          </button>
        </div>

        {/* Tab 1: Main D-Pad & Volume / Channel Pods */}
        {activeTab === 'main' && (
          <div className="space-y-4">
            {/* Sunplus Receiver 4-Color Buttons */}
            <div className="grid grid-cols-4 gap-2 px-1">
              <button
                onClick={() => handleKeyPress('RED')}
                className="py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-md text-[10px] font-bold shadow-sm transition-all active:scale-90"
              >
                أحمر
              </button>
              <button
                onClick={() => handleKeyPress('GREEN')}
                className="py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-[10px] font-bold shadow-sm transition-all active:scale-90"
              >
                أخضر
              </button>
              <button
                onClick={() => handleKeyPress('YELLOW')}
                className="py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-md text-[10px] font-bold shadow-sm transition-all active:scale-90"
              >
                أصفر
              </button>
              <button
                onClick={() => handleKeyPress('BLUE')}
                className="py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-[10px] font-bold shadow-sm transition-all active:scale-90"
              >
                أزرق
              </button>
            </div>

            {/* D-Pad + Vol + Ch in balanced cluster */}
            <div className="flex items-center justify-between gap-2 px-1">
              {/* Volume Rocker */}
              <div className="flex flex-col bg-slate-950 border border-slate-800 rounded-2xl p-1.5 w-14 items-center shadow-inner">
                <button
                  onMouseDown={() => handleMouseDown('VOL_UP')}
                  onMouseUp={handleMouseUp}
                  className="w-11 h-12 flex flex-col items-center justify-center text-slate-200 hover:text-white active:bg-slate-800 rounded-xl transition-all"
                  title="رفع الصوت (ضغط مطول للتكرار)"
                >
                  <ChevronUp className="w-5 h-5 text-cyan-400" />
                  <span className="text-[9px] font-bold">VOL+</span>
                </button>
                <div className="w-6 h-[1px] bg-slate-800 my-1"></div>
                <button
                  onMouseDown={() => handleMouseDown('VOL_DOWN')}
                  onMouseUp={handleMouseUp}
                  className="w-11 h-12 flex flex-col items-center justify-center text-slate-200 hover:text-white active:bg-slate-800 rounded-xl transition-all"
                  title="خفض الصوت (ضغط مطول للتكرار)"
                >
                  <span className="text-[9px] font-bold">VOL-</span>
                  <ChevronDown className="w-5 h-5 text-cyan-400" />
                </button>
              </div>

              {/* Circular D-Pad Wheel */}
              <div className="relative w-44 h-44 rounded-full bg-slate-950 border-2 border-slate-800 shadow-xl flex items-center justify-center">
                {/* UP */}
                <button
                  onClick={() => handleKeyPress('UP')}
                  className="absolute top-1 w-12 h-10 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-90 transition-all"
                >
                  <ChevronUp className="w-6 h-6" />
                </button>
                {/* DOWN */}
                <button
                  onClick={() => handleKeyPress('DOWN')}
                  className="absolute bottom-1 w-12 h-10 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-90 transition-all"
                >
                  <ChevronDown className="w-6 h-6" />
                </button>
                {/* LEFT */}
                <button
                  onClick={() => handleKeyPress('LEFT')}
                  className="absolute left-1 w-10 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-90 transition-all"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                {/* RIGHT */}
                <button
                  onClick={() => handleKeyPress('RIGHT')}
                  className="absolute right-1 w-10 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-90 transition-all"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>

                {/* Center OK Button */}
                <button
                  onClick={() => handleKeyPress('OK')}
                  className="w-16 h-16 rounded-full bg-gradient-to-tr from-cyan-600 to-cyan-400 text-slate-950 font-black text-sm shadow-lg active:scale-90 flex items-center justify-center transition-transform hover:brightness-110"
                >
                  OK
                </button>
              </div>

              {/* Channel Rocker */}
              <div className="flex flex-col bg-slate-950 border border-slate-800 rounded-2xl p-1.5 w-14 items-center shadow-inner">
                <button
                  onMouseDown={() => handleMouseDown('CH_UP')}
                  onMouseUp={handleMouseUp}
                  className="w-11 h-12 flex flex-col items-center justify-center text-slate-200 hover:text-white active:bg-slate-800 rounded-xl transition-all"
                  title="القناة التالية (CH +)"
                >
                  <ChevronUp className="w-5 h-5 text-emerald-400" />
                  <span className="text-[9px] font-bold">CH+</span>
                </button>
                <div className="w-6 h-[1px] bg-slate-800 my-1"></div>
                <button
                  onMouseDown={() => handleMouseDown('CH_DOWN')}
                  onMouseUp={handleMouseUp}
                  className="w-11 h-12 flex flex-col items-center justify-center text-slate-200 hover:text-white active:bg-slate-800 rounded-xl transition-all"
                  title="القناة السابقة (CH -)"
                >
                  <span className="text-[9px] font-bold">CH-</span>
                  <ChevronDown className="w-5 h-5 text-emerald-400" />
                </button>
              </div>
            </div>

            {/* Back, Home, Menu, Exit Row */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              <button
                onClick={() => handleKeyPress('BACK')}
                className="py-2.5 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-slate-300 flex flex-col items-center justify-center text-[10px] gap-1 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                <span>رجوع</span>
              </button>
              <button
                onClick={() => handleKeyPress('HOME')}
                className="py-2.5 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-slate-300 flex flex-col items-center justify-center text-[10px] gap-1 transition-all"
              >
                <Home className="w-3.5 h-3.5 text-emerald-400" />
                <span>الرئيسية</span>
              </button>
              <button
                onClick={() => handleKeyPress('MENU')}
                className="py-2.5 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-slate-300 flex flex-col items-center justify-center text-[10px] gap-1 transition-all"
              >
                <Menu className="w-3.5 h-3.5 text-amber-400" />
                <span>القائمة</span>
              </button>
              <button
                onClick={() => handleKeyPress('EXIT')}
                className="py-2.5 bg-slate-800/80 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-slate-300 flex flex-col items-center justify-center text-[10px] gap-1 transition-all"
              >
                <LogOut className="w-3.5 h-3.5 text-red-400" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Numbers Pad */}
        {activeTab === 'numpad' && (
          <div className="grid grid-cols-3 gap-2.5 py-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleKeyPress(`NUM_${num}` as RemoteKey)}
                className="h-12 bg-slate-800/90 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-lg font-bold text-white shadow-sm transition-all"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleKeyPress('RECALL')}
              className="h-12 bg-slate-800/60 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-xs font-semibold text-cyan-400 transition-all"
            >
              Recall
            </button>
            <button
              onClick={() => handleKeyPress('NUM_0')}
              className="h-12 bg-slate-800/90 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-lg font-bold text-white shadow-sm transition-all"
            >
              0
            </button>
            <button
              onClick={() => handleKeyPress('FAV')}
              className="h-12 bg-slate-800/60 hover:bg-slate-700 active:scale-95 border border-slate-700 rounded-xl text-xs font-semibold text-amber-400 transition-all"
            >
              المفضلة
            </button>
          </div>
        )}

        {/* Tab 3: Sunplus Satellite Receiver Special Tools */}
        {activeTab === 'satellite' && (
          <div className="space-y-3 py-1">
            <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 text-xs text-slate-300">
              <span className="text-cyan-400 font-bold block mb-1">أزرار ريسيفر Sunplus المتقدمة</span>
              أكواد مخصصة للتحكم بالترددات، الصوتيات، والأقمار الصناعية (DVB-S2)
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleKeyPress('EPG')}
                className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 text-xs font-medium text-white flex items-center justify-between"
              >
                <span>دليل البرامج (EPG)</span>
                <span className="font-mono text-[10px] text-cyan-400">0x04</span>
              </button>
              <button
                onClick={() => handleKeyPress('SAT')}
                className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 text-xs font-medium text-white flex items-center justify-between"
              >
                <span>الأقمار (SAT)</span>
                <span className="font-mono text-[10px] text-cyan-400">0x05</span>
              </button>
              <button
                onClick={() => handleKeyPress('AUDIO')}
                className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 text-xs font-medium text-white flex items-center justify-between"
              >
                <span>الصوتيات (Audio)</span>
                <span className="font-mono text-[10px] text-cyan-400">0x01</span>
              </button>
              <button
                onClick={() => handleKeyPress('SUBTITLE')}
                className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 text-xs font-medium text-white flex items-center justify-between"
              >
                <span>الترجمة (Subtitle)</span>
                <span className="font-mono text-[10px] text-cyan-400">0x09</span>
              </button>
            </div>

            {/* Media control mini row */}
            <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
              <button onClick={() => handleKeyPress('REWIND')} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300">
                <Rewind className="w-4 h-4" />
              </button>
              <button onClick={() => handleKeyPress('PLAY')} className="p-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg">
                <Play className="w-4 h-4" />
              </button>
              <button onClick={() => handleKeyPress('PAUSE')} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300">
                <Pause className="w-4 h-4" />
              </button>
              <button onClick={() => handleKeyPress('FAST_FORWARD')} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300">
                <FastForward className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Touchpad / Mouse Trackpad */}
        {activeTab === 'touchpad' && (
          <div className="space-y-3 py-1">
            <div
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                setTouchCoords({ x: Math.round(e.clientX - rect.left), y: Math.round(e.clientY - rect.top) });
              }}
              onMouseLeave={() => setTouchCoords(null)}
              onClick={() => handleKeyPress('OK')}
              className="h-48 bg-slate-950 rounded-2xl border-2 border-dashed border-slate-800 hover:border-cyan-500/50 flex flex-col items-center justify-center cursor-crosshair relative select-none transition-colors"
            >
              <MousePointer className="w-8 h-8 text-cyan-400 mb-2 opacity-80" />
              <span className="text-xs text-slate-400 font-medium">لوحة اللمس (Touchpad) للشاشات الذكية</span>
              <span className="text-[10px] text-slate-500 mt-1">حرك المؤشر واضغط للنقر (Mouse Click)</span>
              {touchCoords && (
                <div className="absolute bottom-2 left-2 text-[10px] font-mono text-cyan-400 bg-slate-900/90 px-2 py-0.5 rounded">
                  X: {touchCoords.x}, Y: {touchCoords.y}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => handleKeyPress('BACK')}
                className="flex-1 py-2 bg-slate-800 rounded-xl text-xs text-slate-300 font-semibold"
              >
                رجوع
              </button>
              <button
                onClick={() => handleKeyPress('OK')}
                className="flex-1 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold"
              >
                نقرة موافق (Click)
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
