import {useEffect,useRef} from 'react';
import type {TimelineItem} from '../core/types';
import {activeEffectIds,computeFilter} from '../engine/renderEngine';
type Props={item:TimelineItem|null;url:string|null;width:number;height:number;playing:boolean;timeMs:number};
export function NivexCanvasPreview({item,url,width,height,playing,timeMs}:Props){
 const canvasRef=useRef<HTMLCanvasElement|null>(null),mediaRef=useRef<HTMLImageElement|HTMLVideoElement|null>(null);
 useEffect(()=>{
  if(!item||!url||item.kind==='audio'){mediaRef.current=null;return;}
  const el=item.mime?.startsWith('image/')?new Image():document.createElement('video');
  el.src=url;if(el instanceof HTMLVideoElement){el.muted=true;el.playsInline=true;el.loop=true;el.onloadeddata=()=>playing&&el.play().catch(()=>{});}mediaRef.current=el;
  const draw=()=>{const c=canvasRef.current,ctx=c?.getContext('2d');if(!c||!ctx||!mediaRef.current)return;c.width=Math.max(1,width);c.height=Math.max(1,height);const src=mediaRef.current;const sw=src instanceof HTMLVideoElement?src.videoWidth:src.naturalWidth,sh=src instanceof HTMLVideoElement?src.videoHeight:src.naturalHeight;if(!sw||!sh)return;const scale=Math.min(c.width/sw,c.height/sh),dw=sw*scale,dh=sh*scale,x=(c.width-dw)/2,y=(c.height-dh)/2;ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#05070b';ctx.fillRect(0,0,c.width,c.height);const ids=activeEffectIds(item.effects);ctx.save();ctx.filter=computeFilter(item.effects)||'none';ctx.globalAlpha=item.transform.opacity;ctx.translate(c.width*item.transform.x/100,c.height*item.transform.y/100);ctx.rotate(item.transform.rotation*Math.PI/180);ctx.scale(item.transform.scaleX,item.transform.scaleY);ctx.drawImage(src,x,y,dw,dh);ctx.restore();
  if(ids.includes('rgb-split')){ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.20;ctx.drawImage(src,x-3,y,dw,dh);ctx.drawImage(src,x+3,y,dw,dh);ctx.restore();}
  if(ids.includes('glow')||ids.includes('prism-bloom')||ids.includes('night-bloom')){ctx.save();ctx.globalAlpha=.11;ctx.globalCompositeOperation='screen';ctx.filter='blur(18px) saturate(1.5)';ctx.drawImage(src,x,y,dw,dh);ctx.restore();}
  if(ids.includes('glitch')||ids.includes('pixel-surge')){const slices=7,seed=Math.floor(timeMs/85);ctx.save();ctx.globalAlpha=.15;for(let i=0;i<slices;i++){const yy=y+(i/slices)*dh,h=dh/slices,shift=((seed*(i+3)*17)%13)-6;ctx.drawImage(src,x+shift,yy,dw,h,x,yy,dw,h);}ctx.restore();}
  if(ids.includes('vhs')){ctx.save();ctx.globalAlpha=.12;ctx.fillStyle='#fff';for(let sy=0;sy<c.height;sy+=5)ctx.fillRect(0,sy,c.width,1);ctx.restore();}
  if(item.text){ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='700 7% Inter,system-ui,sans-serif';ctx.fillStyle=item.color||'#fff';ctx.shadowColor='rgba(20,220,255,.45)';ctx.shadowBlur=18;ctx.fillText(item.text,c.width/2+c.width*item.transform.x/100,c.height/2+c.height*item.transform.y/100);ctx.restore();}
 };
 if(el instanceof HTMLImageElement){el.onload=draw;if(el.complete)draw();}let raf=0;const loop=()=>{draw();raf=requestAnimationFrame(loop)};raf=requestAnimationFrame(loop);return()=>cancelAnimationFrame(raf);
 },[item?.id,item?.assetId,url,width,height,playing,timeMs,item?.transform.x,item?.transform.y,item?.transform.scaleX,item?.transform.scaleY,item?.transform.rotation,item?.transform.opacity]);
 return <canvas ref={canvasRef} className="nivex-canvas" aria-label="Preview NIVEX"/>;
}
