import React, { useState, useRef, useEffect } from 'react';
import { Category, TransactionType, AppSettings, Account, AccountType } from '../types';
import { CategoryIcon } from './CategoryIcon';
import {
  X,
  Plus,
  FolderPlus,
  Trash2,
  Building2,
  Wallet,
  Smartphone,
  TrendingDown,
  TrendingUp,
  ArrowRightLeft,
  CreditCard,
  Check,
  Landmark,
  Banknote,
  ArrowDownLeft,
  ArrowUpRight,
  ChevronDown,
  Pencil,
} from 'lucide-react';
import { getDualAccentInfo } from '../utils/theme';
import { formatCurrency } from '../utils/formatters';

interface ManageCategoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  accounts?: Account[];
  onAddCategory: (newCat: Omit<Category, 'id'>) => void;
  onUpdateCategory?: (updatedCat: Category) => void;
  onDeleteCategory: (id: string) => void;
  onAddAccount?: (newAcc: Omit<Account, 'id'>) => void;
  onUpdateAccount?: (updatedAcc: Account) => void;
  onDeleteAccount?: (id: string) => void;
  appSettings?: AppSettings;
  initialTab?: 'income' | 'expense' | 'accounts';
}

const ACCOUNT_TYPE_OPTIONS: {
  type: AccountType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  colorClass: string;
}[] = [
  { type: 'cash', label: 'Cash wallet', icon: Banknote, colorClass: 'text-emerald-500' },
  { type: 'mobile_banking', label: 'Mobile wallet', icon: Smartphone, colorClass: 'text-indigo-500' },
  { type: 'card', label: 'Card wallet', icon: CreditCard, colorClass: 'text-amber-500' },
  { type: 'bank', label: 'Bank wallet', icon: Landmark, colorClass: 'text-blue-500' },
  { type: 'receivable', label: 'Receivables', icon: ArrowDownLeft, colorClass: 'text-cyan-500' },
  { type: 'payable', label: 'Payables', icon: ArrowUpRight, colorClass: 'text-rose-500' },
];

const AVAILABLE_ICONS = [
  'Briefcase',
  'Laptop',
  'Store',
  'TrendingUp',
  'Home',
  'Gift',
  'PlusCircle',
  'ShoppingBag',
  'Building',
  'Zap',
  'GraduationCap',
  'HeartPulse',
  'Bus',
  'Film',
  'Shirt',
  'CreditCard',
  'Car',
  'Coffee',
  'Smile',
  'Utensils',
];

const AVAILABLE_COLORS = [
  '#10B981',
  '#06B6D4',
  '#3B82F6',
  '#8B5CF6',
  '#EC4899',
  '#F59E0B',
  '#EF4444',
  '#F97316',
  '#14B8A6',
  '#A855F7',
];

export const ManageCategoriesModal: React.FC<ManageCategoriesModalProps> = ({
  isOpen,
  onClose,
  categories,
  accounts = [],
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onAddAccount,
  onUpdateAccount,
  onDeleteAccount,
  appSettings,
  initialTab = 'income',
}) => {
  const [activeTab, setActiveTab] = useState<'income' | 'expense' | 'accounts'>(initialTab);

  // Category Form State
  const [nameBangla, setNameBangla] = useState('');
  const [nameEnglish, setNameEnglish] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('PlusCircle');
  const [selectedColor, setSelectedColor] = useState('#10B981');

  // Account Form State
  const [accNameBangla, setAccNameBangla] = useState('');
  const [accNameEnglish, setAccNameEnglish] = useState('');
  const [accType, setAccType] = useState<AccountType>('mobile_banking');
  const [accOpeningBalance, setAccOpeningBalance] = useState<string>('0');
  const [accNumber, setAccNumber] = useState('');
  const [accInstitution, setAccInstitution] = useState('');
  const [accColor, setAccColor] = useState('#3B82F6');
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
  const typeDropdownRef = useRef<HTMLDivElement>(null);

  // Editing Category State
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editCatNameBangla, setEditCatNameBangla] = useState('');
  const [editCatNameEnglish, setEditCatNameEnglish] = useState('');
  const [editCatIcon, setEditCatIcon] = useState('PlusCircle');
  const [editCatColor, setEditCatColor] = useState('#10B981');
  const [editCatError, setEditCatError] = useState('');

  // Editing Account State
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [editAccNameBangla, setEditAccNameBangla] = useState('');
  const [editAccNameEnglish, setEditAccNameEnglish] = useState('');
  const [editAccType, setEditAccType] = useState<AccountType>('cash');
  const [editAccOpeningBalance, setEditAccOpeningBalance] = useState<string>('0');
  const [editAccNumber, setEditAccNumber] = useState('');
  const [editAccInstitution, setEditAccInstitution] = useState('');
  const [editAccColor, setEditAccColor] = useState('#3B82F6');
  const [isEditTypeDropdownOpen, setIsEditTypeDropdownOpen] = useState(false);
  const editTypeDropdownRef = useRef<HTMLDivElement>(null);
  const [editAccError, setEditAccError] = useState('');

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (typeDropdownRef.current && !typeDropdownRef.current.contains(event.target as Node)) {
        setIsTypeDropdownOpen(false);
      }
      if (editTypeDropdownRef.current && !editTypeDropdownRef.current.contains(event.target as Node)) {
        setIsEditTypeDropdownOpen(false);
      }
    };
    if (isTypeDropdownOpen || isEditTypeDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isTypeDropdownOpen, isEditTypeDropdownOpen]);

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const isLight = appSettings?.themeMode === 'light';
  const isEn = appSettings?.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  const handleStartEditCategory = (cat: Category) => {
    setEditingCategory(cat);
    setEditCatNameBangla(cat.nameBangla);
    setEditCatNameEnglish(cat.nameEnglish || '');
    setEditCatIcon(cat.icon);
    setEditCatColor(cat.color);
    setEditCatError('');
  };

  const handleSaveEditedCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editCatNameBangla.trim() && !editCatNameEnglish.trim()) {
      setEditCatError(isEn ? 'Category name is required' : 'ক্যাটাগরির নাম আবশ্যক');
      return;
    }
    if (!editingCategory) return;

    const finalBangla = editCatNameBangla.trim() || editCatNameEnglish.trim();
    const finalEnglish = editCatNameEnglish.trim() || editCatNameBangla.trim();

    const updated: Category = {
      ...editingCategory,
      nameBangla: finalBangla,
      nameEnglish: finalEnglish,
      icon: editCatIcon,
      color: editCatColor,
    };

    if (onUpdateCategory) {
      onUpdateCategory(updated);
    }
    setSuccessMsg(isEn ? 'Category updated successfully!' : 'ক্যাটাগরি সফলভাবে আপডেট করা হয়েছে!');
    setTimeout(() => setSuccessMsg(''), 2500);
    setEditingCategory(null);
  };

  const handleStartEditAccount = (acc: Account) => {
    setEditingAccount(acc);
    setEditAccNameBangla(acc.nameBangla);
    setEditAccNameEnglish(acc.nameEnglish || '');
    setEditAccType(acc.type);
    setEditAccOpeningBalance(acc.openingBalance !== undefined ? String(acc.openingBalance) : '0');
    setEditAccNumber(acc.accountNumber || '');
    setEditAccInstitution(acc.institutionName || '');
    setEditAccColor(acc.color || '#3B82F6');
    setIsEditTypeDropdownOpen(false);
    setEditAccError('');
  };

  const handleSaveEditedAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editAccNameBangla.trim() && !editAccNameEnglish.trim()) {
      setEditAccError(isEn ? 'Account name is required' : 'অ্যাকাউন্টের নাম আবশ্যক');
      return;
    }
    if (!editingAccount) return;

    const finalBangla = editAccNameBangla.trim() || editAccNameEnglish.trim();
    const finalEnglish = editAccNameEnglish.trim() || editAccNameBangla.trim();
    const opBal = parseFloat(editAccOpeningBalance) || 0;

    const updated: Account = {
      ...editingAccount,
      nameBangla: finalBangla,
      nameEnglish: finalEnglish,
      type: editAccType,
      openingBalance: opBal,
      accountNumber: editAccNumber.trim() || undefined,
      institutionName: editAccInstitution.trim() || undefined,
      color: editAccColor,
    };

    if (onUpdateAccount) {
      onUpdateAccount(updated);
    }
    setSuccessMsg(isEn ? 'Account updated successfully!' : 'অ্যাকাউন্ট সফলভাবে আপডেট করা হয়েছে!');
    setTimeout(() => setSuccessMsg(''), 2500);
    setEditingAccount(null);
  };

  if (!isOpen) return null;

  const currentCategories = categories.filter((c) => c.type === activeTab);

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBangla.trim() && !nameEnglish.trim()) {
      setError(isEn ? 'Category name is required' : 'ক্যাটাগরির নাম আবশ্যক');
      return;
    }

    const finalBangla = nameBangla.trim() || nameEnglish.trim();
    const finalEnglish = nameEnglish.trim() || nameBangla.trim();

    onAddCategory({
      nameBangla: finalBangla,
      nameEnglish: finalEnglish,
      type: activeTab as 'income' | 'expense',
      icon: selectedIcon,
      color: selectedColor,
      isCustom: true,
    });

    setNameBangla('');
    setNameEnglish('');
    setError('');
    setSuccessMsg(isEn ? 'Category added!' : 'ক্যাটাগরি যোগ হয়েছে!');
    setTimeout(() => setSuccessMsg(''), 2500);
  };

  const handleAddAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accNameBangla.trim() && !accNameEnglish.trim()) {
      setError(isEn ? 'Account name is required' : 'অ্যাকাউন্টের নাম আবশ্যক');
      return;
    }

    if (!onAddAccount) return;

    const finalBangla = accNameBangla.trim() || accNameEnglish.trim();
    const finalEnglish = accNameEnglish.trim() || accNameBangla.trim();

    onAddAccount({
      nameBangla: finalBangla,
      nameEnglish: finalEnglish,
      type: accType,
      openingBalance: parseFloat(accOpeningBalance) || 0,
      accountNumber: accNumber.trim(),
      institutionName: accInstitution.trim(),
      color: accColor,
      isCustom: true,
    });

    setAccNameBangla('');
    setAccNameEnglish('');
    setAccOpeningBalance('0');
    setAccNumber('');
    setAccInstitution('');
    setError('');
    setSuccessMsg(isEn ? 'New account created successfully!' : 'নতুন অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!');
    setTimeout(() => setSuccessMsg(''), 2500);
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
      } p-4 animate-in fade-in duration-200`}
    >
      <div
        className={`w-full max-w-xl ${
          isLight
            ? 'bg-white border-slate-200 text-slate-900'
            : 'bg-slate-800 border-slate-700 text-slate-100'
        } border rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            isLight
              ? 'border-slate-200 bg-slate-50/90 text-slate-900'
              : 'border-slate-700 bg-slate-800/90 text-slate-100'
          }`}
        >
          <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
            <FolderPlus className="w-5 h-5" style={{ color: dualAccent.primary.hex }} />
            <span>{isEn ? 'Manage Categories & Accounts' : 'ক্যাটাগরি ও অ্যাকাউন্টস ম্যানেজমেন্ট'}</span>
          </h2>
          <button
            onClick={onClose}
            className={`p-2 rounded-full cursor-pointer ${
              isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-700'
            } transition`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5">
          {/* Tabs (Income, Expense, Accounts) */}
          <div
            className={`grid grid-cols-3 gap-1.5 p-1.5 ${
              isLight ? 'bg-slate-100/80 border-slate-200' : 'bg-slate-900 border-slate-700'
            } rounded-2xl border`}
          >
            <button
              onClick={() => {
                setActiveTab('income');
                setError('');
              }}
              style={
                activeTab === 'income'
                  ? { backgroundColor: dualAccent.primary.hex, color: '#fff' }
                  : undefined
              }
              className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'income'
                  ? 'shadow-md'
                  : isLight
                  ? 'text-slate-700 hover:text-slate-900'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{isEn ? 'Income' : 'আয়ের খাত'}</span>
              <span className="text-[10px] opacity-75">
                ({categories.filter((c) => c.type === 'income').length})
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('expense');
                setError('');
              }}
              style={
                activeTab === 'expense'
                  ? { backgroundColor: dualAccent.secondary.hex, color: '#fff' }
                  : undefined
              }
              className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'expense'
                  ? 'shadow-md'
                  : isLight
                  ? 'text-slate-700 hover:text-slate-900'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{isEn ? 'Expense' : 'খরচের খাত'}</span>
              <span className="text-[10px] opacity-75">
                ({categories.filter((c) => c.type === 'expense').length})
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('accounts');
                setError('');
              }}
              style={
                activeTab === 'accounts'
                  ? { backgroundColor: '#4F46E5', color: '#fff' }
                  : undefined
              }
              className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'accounts'
                  ? 'shadow-md'
                  : isLight
                  ? 'text-slate-700 hover:text-slate-900'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>{isEn ? 'Accounts' : 'অ্যাকাউন্টস'}</span>
              <span className="text-[10px] opacity-75">({accounts.length})</span>
            </button>
          </div>

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* TAB 3: ACCOUNTS MANAGEMENT (CREATE & VIEW ACCOUNTS) */}
          {activeTab === 'accounts' ? (
            <div className="space-y-6">
              {/* Create New Account Form */}
              <form
                onSubmit={handleAddAccountSubmit}
                className={`p-4 ${
                  isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-900 border-slate-700'
                } border rounded-2xl space-y-3`}
              >
                <h3
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isLight ? 'text-slate-900' : 'text-slate-300'
                  } flex items-center gap-1.5`}
                >
                  <Plus className="w-4 h-4 text-indigo-500" />
                  <span>{isEn ? 'Create New Account' : 'নতুন অ্যাকাউন্ট তৈরি করুন'}</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    placeholder={isEn ? 'Account Name (Bengali) *' : 'অ্যাকাউন্টের নাম (বাংলায়) *'}
                    value={accNameBangla}
                    onChange={(e) => {
                      setAccNameBangla(e.target.value);
                      setError('');
                    }}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
                        : 'bg-slate-800 border-slate-700 text-white'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                  <input
                    type="text"
                    placeholder={isEn ? 'Account Name (English)' : 'Name (English - optional)'}
                    value={accNameEnglish}
                    onChange={(e) => {
                      setAccNameEnglish(e.target.value);
                      setError('');
                    }}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
                        : 'bg-slate-800 border-slate-700 text-white'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                </div>

                {/* Account Type & Initial Balance */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Account Type' : 'অ্যাকাউন্টের ধরণ'}
                    </label>
                    <div ref={typeDropdownRef} className="relative">
                      <button
                        type="button"
                        onClick={() => setIsTypeDropdownOpen(!isTypeDropdownOpen)}
                        className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-between transition ${
                          isLight
                            ? 'bg-white border-slate-200 text-slate-900 hover:bg-slate-50'
                            : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-750'
                        } outline-hidden cursor-pointer`}
                      >
                        <span className="flex items-center gap-2 truncate">
                          {React.createElement(
                            (ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === accType) || ACCOUNT_TYPE_OPTIONS[0]).icon,
                            {
                              className: `w-4 h-4 shrink-0 ${(ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === accType) || ACCOUNT_TYPE_OPTIONS[0]).colorClass}`,
                            }
                          )}
                          <span className="font-semibold">
                            {(ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === accType) || ACCOUNT_TYPE_OPTIONS[0]).label}
                          </span>
                        </span>
                        <ChevronDown
                          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${
                            isTypeDropdownOpen ? 'rotate-180' : ''
                          }`}
                        />
                      </button>

                      {/* Dropdown Options Menu */}
                      {isTypeDropdownOpen && (
                        <div
                          className={`absolute z-40 top-full left-0 right-0 mt-1 rounded-xl border shadow-xl overflow-hidden py-1 ${
                            isLight
                              ? 'bg-white border-slate-200 shadow-slate-900/10'
                              : 'bg-slate-800 border-slate-700 shadow-black/50'
                          }`}
                        >
                          {ACCOUNT_TYPE_OPTIONS.map((opt) => {
                            const Icon = opt.icon;
                            const isSelected = accType === opt.type;
                            return (
                              <button
                                key={opt.type}
                                type="button"
                                onClick={() => {
                                  setAccType(opt.type);
                                  setIsTypeDropdownOpen(false);
                                }}
                                className={`w-full px-3 py-2 flex items-center justify-between text-xs font-medium transition-colors cursor-pointer ${
                                  isSelected
                                    ? isLight
                                      ? 'bg-slate-100 text-slate-900 font-bold'
                                      : 'bg-slate-700 text-white font-bold'
                                    : isLight
                                    ? 'text-slate-700 hover:bg-slate-50'
                                    : 'text-slate-300 hover:bg-slate-700/60'
                                }`}
                              >
                                <span className="flex items-center gap-2.5">
                                  <Icon className={`w-4 h-4 shrink-0 ${opt.colorClass}`} />
                                  <span>{opt.label}</span>
                                </span>
                                {isSelected && (
                                  <Check className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Opening Balance (৳)' : 'প্রারম্ভিক ব্যালেন্স (৳)'}
                    </label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={accOpeningBalance}
                      onChange={(e) => setAccOpeningBalance(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-bold ${
                        isLight
                          ? 'bg-white border-slate-200 text-slate-900'
                          : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden`}
                    />
                  </div>
                </div>

                {/* Account Number / Details (Optional) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    placeholder={isEn ? 'A/C Number or Mobile No (Optional)' : 'অ্যাকাউন্ট নং বা মোবাইল নং (ঐচ্ছিক)'}
                    value={accNumber}
                    onChange={(e) => setAccNumber(e.target.value)}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900'
                        : 'bg-slate-800 border-slate-700 text-white'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                  <input
                    type="text"
                    placeholder={isEn ? 'Institution (e.g. City Bank, bKash)' : 'ব্যাংক বা প্রতিষ্ঠানের নাম'}
                    value={accInstitution}
                    onChange={(e) => setAccInstitution(e.target.value)}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900'
                        : 'bg-slate-800 border-slate-700 text-white'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                </div>

                {/* Color */}
                <div>
                  <label className="block text-[10px] font-semibold uppercase mb-1 text-slate-400">
                    {isEn ? 'Choose Color' : 'রং পছন্দ করুন'}
                  </label>
                  <div className="flex items-center gap-2">
                    {AVAILABLE_COLORS.map((color) => (
                      <button
                        type="button"
                        key={color}
                        onClick={() => setAccColor(color)}
                        className={`w-6 h-6 rounded-full transition transform cursor-pointer ${
                          accColor === color ? 'scale-125 ring-2 ring-indigo-400' : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>

                {error && <p className="text-xs text-rose-500 font-semibold">{error}</p>}

                <button
                  type="submit"
                  className="w-full py-2.5 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md active:scale-98 cursor-pointer"
                  style={{ backgroundColor: '#4F46E5' }}
                >
                  <Plus className="w-4 h-4" />
                  <span>{isEn ? 'Create Account' : 'অ্যাকাউন্ট তৈরি করুন'}</span>
                </button>
              </form>

              {/* Existing Accounts List */}
              <div className="space-y-2">
                <h3
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isLight ? 'text-slate-900' : 'text-slate-300'
                  }`}
                >
                  {isEn ? `Current Accounts (${accounts.length})` : `বর্তমান অ্যাকাউন্ট তালিকা (${accounts.length})`}
                </h3>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {accounts.map((account) => {
                    const isLiability = account.type === 'payable';
                    return (
                      <div
                        key={account.id}
                        className={`flex items-center justify-between p-3 ${
                          isLight ? 'bg-slate-50/80 border-slate-200' : 'bg-slate-900 border-slate-700'
                        } border rounded-2xl`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="p-2 rounded-xl flex items-center justify-center"
                            style={{
                              backgroundColor: `${account.color || '#3B82F6'}20`,
                              color: account.color || '#3B82F6',
                            }}
                          >
                            {account.type === 'bank' ? (
                              <Landmark className="w-4 h-4" />
                            ) : account.type === 'mobile_banking' ? (
                              <Smartphone className="w-4 h-4" />
                            ) : account.type === 'card' ? (
                              <CreditCard className="w-4 h-4" />
                            ) : account.type === 'receivable' ? (
                              <ArrowDownLeft className="w-4 h-4" />
                            ) : account.type === 'payable' ? (
                              <ArrowUpRight className="w-4 h-4" />
                            ) : (
                              <Banknote className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p
                                className={`text-xs font-bold ${
                                  isLight ? 'text-slate-900' : 'text-gray-100'
                                }`}
                              >
                                {isEn ? account.nameEnglish : account.nameBangla}
                              </p>
                              <span
                                className={`text-[9px] px-1.5 py-0.2 rounded-md font-extrabold ${
                                  isLiability
                                    ? 'bg-rose-500/10 text-rose-500 border border-rose-500/20'
                                    : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                                }`}
                              >
                                {isLiability ? (isEn ? 'Debt' : 'দেনা') : isEn ? 'Asset' : 'সম্পদ'}
                              </span>
                            </div>
                            <p
                              className={`text-[10px] ${
                                isLight ? 'text-slate-500' : 'text-gray-400'
                              }`}
                            >
                              {account.accountNumber || account.institutionName || (isEn ? 'Standard Account' : 'সাধারণ হিসাব')}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <div className="text-right mr-1">
                            <span className="text-[10px] text-slate-400 block">
                              {isEn ? 'Current' : 'ব্যালেন্স'}
                            </span>
                            <span
                              className={`text-xs font-extrabold ${
                                isLiability ? 'text-rose-500' : 'text-emerald-600'
                              }`}
                            >
                              {formatCurrency(
                                account.currentBalance ?? account.openingBalance,
                                appSettings?.useBanglaDigits ?? false,
                                appSettings?.currencySymbol
                              )}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleStartEditAccount(account)}
                            className={`p-1.5 rounded-lg border transition cursor-pointer ${
                              isLight
                                ? 'border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                                : 'border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800'
                            }`}
                            title={isEn ? 'Edit Account' : 'অ্যাকাউন্ট সম্পাদনা'}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>

                          {account.isCustom && onDeleteAccount ? (
                            <button
                              onClick={() => onDeleteAccount(account.id)}
                              className="p-1.5 text-gray-400 hover:text-rose-500 hover:bg-rose-100 rounded-lg transition cursor-pointer"
                              title={isEn ? 'Delete' : 'মুছে ফেলুন'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-md border ${
                                isLight
                                  ? 'text-slate-700 bg-slate-100 border-slate-200'
                                  : 'text-gray-500 bg-gray-900 border-gray-800'
                              }`}
                            >
                              {isEn ? 'Default' : 'ডিফল্ট'}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* TAB 1 & 2: CATEGORIES (INCOME / EXPENSE) */
            <>
              {/* Add New Category Form */}
              <form
                onSubmit={handleAddCategory}
                className={`p-4 ${
                  isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-900 border-slate-700'
                } border rounded-2xl space-y-3`}
              >
                <h3
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isLight ? 'text-slate-900' : 'text-slate-300'
                  }`}
                >
                  {isEn
                    ? `Add New ${activeTab === 'income' ? 'Income' : 'Expense'} Category`
                    : `নতুন ${activeTab === 'income' ? 'আয়ের' : 'খরচের'} খাত যোগ করুন`}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    placeholder={isEn ? 'Name (Bengali)' : 'নাম (বাংলায়) *'}
                    value={nameBangla}
                    onChange={(e) => {
                      setNameBangla(e.target.value);
                      setError('');
                    }}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500'
                        : 'bg-slate-800 border-slate-700 text-white focus:border-indigo-400'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                  <input
                    type="text"
                    placeholder={isEn ? 'Name (English) *' : 'Name (English - optional)'}
                    value={nameEnglish}
                    onChange={(e) => {
                      setNameEnglish(e.target.value);
                      setError('');
                    }}
                    className={`w-full px-3 py-2 ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500'
                        : 'bg-slate-800 border-slate-700 text-white focus:border-indigo-400'
                    } border rounded-xl text-xs focus:outline-none`}
                  />
                </div>

                {/* Icon Picker */}
                <div>
                  <label
                    className={`block text-[10px] font-semibold uppercase mb-1 ${
                      isLight ? 'text-slate-600' : 'text-gray-400'
                    }`}
                  >
                    {isEn ? 'Choose Icon' : 'আইকন পছন্দ করুন'}
                  </label>
                  <div
                    className={`flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1.5 ${
                      isLight ? 'bg-white border-slate-200' : 'bg-gray-900/50 border-gray-800'
                    } rounded-xl border`}
                  >
                    {AVAILABLE_ICONS.map((iconName) => (
                      <button
                        type="button"
                        key={iconName}
                        onClick={() => setSelectedIcon(iconName)}
                        className={`p-1.5 rounded-lg border transition cursor-pointer ${
                          selectedIcon === iconName
                            ? 'font-bold'
                            : isLight
                            ? 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                            : 'border-transparent text-gray-400 hover:text-white'
                        }`}
                        style={
                          selectedIcon === iconName
                            ? {
                                borderColor: dualAccent.primary.hex,
                                backgroundColor: `${dualAccent.primary.hex}25`,
                                color: dualAccent.primary.hex,
                              }
                            : undefined
                        }
                      >
                        <CategoryIcon name={iconName} className="w-4 h-4" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Picker */}
                <div>
                  <label
                    className={`block text-[10px] font-semibold uppercase mb-1 ${
                      isLight ? 'text-slate-600' : 'text-gray-400'
                    }`}
                  >
                    {isEn ? 'Choose Color' : 'রং নির্বাচন করুন'}
                  </label>
                  <div className="flex items-center gap-2">
                    {AVAILABLE_COLORS.map((color) => (
                      <button
                        type="button"
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`w-6 h-6 rounded-full transition transform cursor-pointer ${
                          selectedColor === color
                            ? 'scale-125 ring-2 ring-indigo-400'
                            : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>

                {error && <p className="text-xs text-rose-500 font-semibold">{error}</p>}

                <button
                  type="submit"
                  className="w-full py-2.5 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-md active:scale-98 cursor-pointer"
                  style={dualAccent.primaryButtonStyle}
                >
                  <Plus className="w-3.5 h-3.5" />{' '}
                  {isEn ? 'Add Category' : 'ক্যাটাগরি যোগ করুন'}
                </button>
              </form>

              {/* List of Existing Categories */}
              <div className="space-y-2">
                <h3
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isLight ? 'text-slate-900' : 'text-slate-300'
                  }`}
                >
                  {isEn
                    ? `Current Categories (${currentCategories.length})`
                    : `বর্তমান ক্যাটাগরি তালিকা (${currentCategories.length})`}
                </h3>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {currentCategories.map((cat) => (
                    <div
                      key={cat.id}
                      className={`flex items-center justify-between p-3 ${
                        isLight ? 'bg-slate-50/80 border-slate-200' : 'bg-slate-900 border-slate-700'
                      } border rounded-2xl`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="p-2 rounded-xl flex items-center justify-center"
                          style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                        >
                          <CategoryIcon name={cat.icon} className="w-4 h-4" />
                        </div>
                        <div>
                          <p
                            className={`text-xs font-bold ${
                              isLight ? 'text-slate-900' : 'text-gray-100'
                            }`}
                          >
                            {isEn ? cat.nameEnglish : cat.nameBangla}
                          </p>
                          <p
                            className={`text-[10px] ${
                              isLight ? 'text-slate-500' : 'text-gray-500'
                            }`}
                          >
                            {isEn ? cat.nameBangla : cat.nameEnglish}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleStartEditCategory(cat)}
                          className={`p-1.5 rounded-lg border transition cursor-pointer ${
                            isLight
                              ? 'border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                              : 'border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800'
                          }`}
                          title={isEn ? 'Edit Category' : 'ক্যাটাগরি সম্পাদনা'}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>

                        {cat.isCustom ? (
                          <button
                            onClick={() => onDeleteCategory(cat.id)}
                            className="p-1.5 text-gray-400 hover:text-rose-500 hover:bg-rose-100 rounded-lg transition cursor-pointer"
                            title={isEn ? 'Delete' : 'মুছে ফেলুন'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-md border ${
                              isLight
                                ? 'text-slate-700 bg-slate-100 border-slate-200'
                                : 'text-gray-500 bg-gray-900 border-gray-800'
                            }`}
                          >
                            {isEn ? 'Default' : 'ডিফল্ট'}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* EDIT CATEGORY MODAL OVERLAY */}
        {editingCategory && (
          <div className="fixed inset-0 z-70 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
            <div
              className={`w-full max-w-md rounded-3xl border shadow-2xl p-5 ${
                isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-700 text-white'
              } max-h-[90vh] overflow-y-auto space-y-4`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div
                    className="p-2.5 rounded-2xl flex items-center justify-center shadow-xs"
                    style={{ backgroundColor: `${editCatColor}20`, color: editCatColor }}
                  >
                    <CategoryIcon name={editCatIcon} className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold flex items-center gap-1.5">
                      <Pencil className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                      <span>{isEn ? 'Edit Category' : 'ক্যাটাগরি সম্পাদনা'}</span>
                    </h3>
                    <p className="text-[10px] text-slate-400">
                      {isEn
                        ? `${editingCategory.type === 'income' ? 'Income' : 'Expense'} Category`
                        : `${editingCategory.type === 'income' ? 'আয়ের' : 'খরচের'} খাত`}
                      {!editingCategory.isCustom && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold border border-slate-200 dark:border-slate-700">
                          {isEn ? 'Default' : 'ডিফল্ট'}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveEditedCategory} className="space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Name (Bengali) *' : 'নাম (বাংলায়) *'}
                    </label>
                    <input
                      type="text"
                      value={editCatNameBangla}
                      onChange={(e) => {
                        setEditCatNameBangla(e.target.value);
                        setEditCatError('');
                      }}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Name (English)' : 'নাম (ইংরেজিতে)'}
                    </label>
                    <input
                      type="text"
                      value={editCatNameEnglish}
                      onChange={(e) => setEditCatNameEnglish(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                </div>

                {/* Icon picker */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {isEn ? 'Choose Icon' : 'আইকন পরিবর্তন করুন'}
                  </label>
                  <div
                    className={`flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 rounded-xl border ${
                      isLight ? 'bg-slate-50/30 border-slate-200' : 'bg-slate-800/50 border-slate-700'
                    }`}
                  >
                    {AVAILABLE_ICONS.map((iconName) => (
                      <button
                        type="button"
                        key={iconName}
                        onClick={() => setEditCatIcon(iconName)}
                        className={`p-1.5 rounded-lg border transition cursor-pointer ${
                          editCatIcon === iconName
                            ? 'font-bold'
                            : isLight
                            ? 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                            : 'border-transparent text-gray-400 hover:text-white'
                        }`}
                        style={
                          editCatIcon === iconName
                            ? {
                                borderColor: editCatColor,
                                backgroundColor: `${editCatColor}25`,
                                color: editCatColor,
                              }
                            : undefined
                        }
                      >
                        <CategoryIcon name={iconName} className="w-4 h-4" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color picker */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {isEn ? 'Choose Color' : 'রং পরিবর্তন করুন'}
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {AVAILABLE_COLORS.map((color) => (
                      <button
                        type="button"
                        key={color}
                        onClick={() => setEditCatColor(color)}
                        className={`w-6 h-6 rounded-full transition transform cursor-pointer ${
                          editCatColor === color ? 'scale-125 ring-2 ring-indigo-400 shadow-md' : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>

                {editCatError && <p className="text-xs text-rose-500 font-semibold">{editCatError}</p>}

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingCategory(null)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      isLight
                        ? 'border-slate-200 text-slate-600 hover:bg-slate-100'
                        : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {isEn ? 'Cancel' : 'বাতিল'}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl text-xs font-bold text-white shadow-md transition cursor-pointer active:scale-98"
                    style={dualAccent.primaryButtonStyle}
                  >
                    {isEn ? 'Save Changes' : 'পরিবর্তন সংরক্ষণ করুন'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* EDIT ACCOUNT MODAL OVERLAY */}
        {editingAccount && (
          <div className="fixed inset-0 z-70 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
            <div
              className={`w-full max-w-md rounded-3xl border shadow-2xl p-5 ${
                isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-700 text-white'
              } max-h-[90vh] overflow-y-auto space-y-4`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div
                    className="p-2.5 rounded-2xl flex items-center justify-center shadow-xs"
                    style={{ backgroundColor: `${editAccColor}20`, color: editAccColor }}
                  >
                    {editAccType === 'bank' ? (
                      <Landmark className="w-5 h-5" />
                    ) : editAccType === 'mobile_banking' ? (
                      <Smartphone className="w-5 h-5" />
                    ) : editAccType === 'card' ? (
                      <CreditCard className="w-5 h-5" />
                    ) : editAccType === 'receivable' ? (
                      <ArrowDownLeft className="w-5 h-5" />
                    ) : editAccType === 'payable' ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <Banknote className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold flex items-center gap-1.5">
                      <Pencil className="w-3.5 h-3.5 text-indigo-500" />
                      <span>{isEn ? 'Edit Account' : 'অ্যাকাউন্ট সম্পাদনা'}</span>
                    </h3>
                    <p className="text-[10px] text-slate-400">
                      {isEn ? 'Manage Account Details & Balance' : 'অ্যাকাউন্টের বিবরণ ও ব্যালেন্স পরিবর্তন'}
                      {!editingAccount.isCustom && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold border border-slate-200 dark:border-slate-700">
                          {isEn ? 'Default' : 'ডিফল্ট'}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingAccount(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveEditedAccount} className="space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Account Name (Bengali) *' : 'অ্যাকাউন্টের নাম (বাংলায়) *'}
                    </label>
                    <input
                      type="text"
                      value={editAccNameBangla}
                      onChange={(e) => {
                        setEditAccNameBangla(e.target.value);
                        setEditAccError('');
                      }}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Account Name (English)' : 'নাম (ইংরেজিতে)'}
                    </label>
                    <input
                      type="text"
                      value={editAccNameEnglish}
                      onChange={(e) => setEditAccNameEnglish(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                </div>

                {/* Account Type dropdown & Opening Balance */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Account Type' : 'অ্যাকাউন্টের ধরণ'}
                    </label>
                    <div ref={editTypeDropdownRef} className="relative">
                      <button
                        type="button"
                        onClick={() => setIsEditTypeDropdownOpen(!isEditTypeDropdownOpen)}
                        className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-between transition ${
                          isLight
                            ? 'bg-white border-slate-200 text-slate-900 hover:bg-slate-50'
                            : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-750'
                        } outline-hidden cursor-pointer`}
                      >
                        <span className="flex items-center gap-2 truncate">
                          {React.createElement(
                            (ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === editAccType) || ACCOUNT_TYPE_OPTIONS[0]).icon,
                            {
                              className: `w-4 h-4 shrink-0 ${(ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === editAccType) || ACCOUNT_TYPE_OPTIONS[0]).colorClass}`,
                            }
                          )}
                          <span className="font-semibold">
                            {(ACCOUNT_TYPE_OPTIONS.find((opt) => opt.type === editAccType) || ACCOUNT_TYPE_OPTIONS[0]).label}
                          </span>
                        </span>
                        <ChevronDown
                          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${
                            isEditTypeDropdownOpen ? 'rotate-180' : ''
                          }`}
                        />
                      </button>

                      {isEditTypeDropdownOpen && (
                        <div
                          className={`absolute z-50 top-full left-0 right-0 mt-1 rounded-xl border shadow-xl overflow-hidden py-1 ${
                            isLight
                              ? 'bg-white border-slate-200 shadow-slate-900/10'
                              : 'bg-slate-800 border-slate-700 shadow-black/50'
                          }`}
                        >
                          {ACCOUNT_TYPE_OPTIONS.map((opt) => {
                            const Icon = opt.icon;
                            const isSelected = editAccType === opt.type;
                            return (
                              <button
                                key={opt.type}
                                type="button"
                                onClick={() => {
                                  setEditAccType(opt.type);
                                  setIsEditTypeDropdownOpen(false);
                                }}
                                className={`w-full px-3 py-2 flex items-center justify-between text-xs font-medium transition-colors cursor-pointer ${
                                  isSelected
                                    ? isLight
                                      ? 'bg-slate-100 text-slate-900 font-bold'
                                      : 'bg-slate-700 text-white font-bold'
                                    : isLight
                                    ? 'text-slate-700 hover:bg-slate-50'
                                    : 'text-slate-300 hover:bg-slate-700/60'
                                }`}
                              >
                                <span className="flex items-center gap-2.5">
                                  <Icon className={`w-4 h-4 shrink-0 ${opt.colorClass}`} />
                                  <span>{opt.label}</span>
                                </span>
                                {isSelected && (
                                  <Check className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Opening Balance (৳)' : 'প্রারম্ভিক ব্যালেন্স (৳)'}
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={editAccOpeningBalance}
                      onChange={(e) => setEditAccOpeningBalance(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-bold ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                </div>

                {/* Account Number & Institution */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'A/C Number or Mobile No' : 'অ্যাকাউন্ট নং বা মোবাইল নং'}
                    </label>
                    <input
                      type="text"
                      value={editAccNumber}
                      onChange={(e) => setEditAccNumber(e.target.value)}
                      placeholder={isEn ? 'Optional' : 'ঐচ্ছিক'}
                      className={`w-full px-3 py-2 rounded-xl border text-xs ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">
                      {isEn ? 'Institution / Bank' : 'ব্যাংক বা প্রতিষ্ঠানের নাম'}
                    </label>
                    <input
                      type="text"
                      value={editAccInstitution}
                      onChange={(e) => setEditAccInstitution(e.target.value)}
                      placeholder={isEn ? 'Optional' : 'ঐচ্ছিক'}
                      className={`w-full px-3 py-2 rounded-xl border text-xs ${
                        isLight ? 'bg-slate-50/50 border-slate-200 text-slate-900 focus:bg-white' : 'bg-slate-800 border-slate-700 text-white'
                      } outline-hidden focus:border-indigo-500`}
                    />
                  </div>
                </div>

                {/* Color picker */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-1">
                    {isEn ? 'Choose Color' : 'রং পরিবর্তন করুন'}
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {AVAILABLE_COLORS.map((color) => (
                      <button
                        type="button"
                        key={color}
                        onClick={() => setEditAccColor(color)}
                        className={`w-6 h-6 rounded-full transition transform cursor-pointer ${
                          editAccColor === color ? 'scale-125 ring-2 ring-indigo-400 shadow-md' : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>

                {editAccError && <p className="text-xs text-rose-500 font-semibold">{editAccError}</p>}

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingAccount(null)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      isLight
                        ? 'border-slate-200 text-slate-600 hover:bg-slate-100'
                        : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {isEn ? 'Cancel' : 'বাতিল'}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl text-xs font-bold text-white shadow-md transition cursor-pointer active:scale-98"
                    style={{ backgroundColor: '#4F46E5' }}
                  >
                    {isEn ? 'Save Changes' : 'পরিবর্তন সংরক্ষণ করুন'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
