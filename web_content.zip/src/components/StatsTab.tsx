import { useGame } from '../context/GameContext';
import { formatNumber, formatTime } from '../utils/formatters';
import { BarChart3, TrendingUp, Sparkles, Zap, Award } from 'lucide-react';
import { VentureIcon } from './VentureIcon';

export function StatsTab() {
  const {
    gold,
    lifetimeGold,
    archons,
    lifetimeArchons,
    archonBoostPercent,
    totalRealmProfitPerSec,
    effectiveProfitPerSec,
    tapsPerSec,
    tapProfitPerSec,
    totalClicks,
    ascensionsCount,
    ventures,
    ventureStates,
    getVentureProfit,
    getVentureCycleTime,
    numberFormat,
  } = useGame();

  const totalLevels = Object.values(ventureStates).reduce((sum, v) => sum + v.count, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-amber-900/30 bg-slate-900/80 p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>Kingdom Grand Ledger</span>
          </div>
          <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-slate-100">
            Sovereign Economic Analytics
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Detailed ledger logs, revenue rates, and production shares across all 10 kingdom ventures.
          </p>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Current Gold</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-amber-300 mt-1 tabular-nums">
            {formatNumber(gold, numberFormat)}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Lifetime Gold Earned</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-amber-100 mt-1 tabular-nums">
            {formatNumber(lifetimeGold, numberFormat)}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Realm Revenue Rate</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-emerald-400 mt-1 tabular-nums">
            {formatNumber(effectiveProfitPerSec, numberFormat)} /s
          </div>
          {tapsPerSec > 0 && (
            <div className="text-[11px] text-amber-300 font-medium mt-1 truncate">
              Active: +{tapsPerSec} taps/s (+{formatNumber(tapProfitPerSec, numberFormat)}/s)
            </div>
          )}
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Active Archon Boost</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-violet-300 mt-1 tabular-nums">
            +{formatNumber(archons * archonBoostPercent, numberFormat)}%
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Total Workshops Owned</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-slate-200 mt-1 tabular-nums">
            {totalLevels}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Arcane Orb Taps</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-cyan-300 mt-1 tabular-nums">
            {totalClicks}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Times Ascended</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-amber-300 mt-1 tabular-nums">
            {ascensionsCount}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-xs text-slate-400">Lifetime Archons</div>
          <div className="font-cinzel text-lg sm:text-xl font-bold text-violet-300 mt-1 tabular-nums">
            {formatNumber(lifetimeArchons, numberFormat)}
          </div>
        </div>
      </div>

      {/* Venture Breakdown Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-cinzel text-base font-bold text-slate-100 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span>Venture Production Breakdown</span>
          </h3>
          <span className="text-xs text-slate-400">10 Crown Ventures</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Venture</th>
                <th className="py-3 px-4 text-center">Units</th>
                <th className="py-3 px-4 text-center">Cycle Duration</th>
                <th className="py-3 px-4 text-right">Yield per Run</th>
                <th className="py-3 px-4 text-right">Income / Sec</th>
                <th className="py-3 px-4 text-right">Realm Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {ventures.map((v) => {
                const state = ventureStates[v.id];
                const count = state?.count || 0;
                const profit = getVentureProfit(v.id);
                const cycleTime = getVentureCycleTime(v.id);
                const perSec = (state?.isRunning || state?.managerHired) && count > 0 ? profit / cycleTime : 0;
                const share =
                  totalRealmProfitPerSec > 0 ? (perSec / totalRealmProfitPerSec) * 100 : 0;

                return (
                  <tr key={v.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-100 flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-md overflow-hidden shrink-0 flex items-center justify-center">
                        <VentureIcon ventureId={v.id} size="sm" className="w-full h-full" />
                      </div>
                      <span>{v.name}</span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-amber-300">
                      {count}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-slate-400">
                      {formatTime(cycleTime)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                      +{formatNumber(profit, numberFormat)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400 font-medium">
                      +{formatNumber(perSec, numberFormat)}/s
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-400">
                      {share.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
