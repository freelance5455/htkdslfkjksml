import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  CheckCircle2, 
  X, 
  ShieldCheck, 
  Vibrate, 
  BellRing, 
  Wifi, 
  Sparkles, 
  Terminal, 
  Layers, 
  Check, 
  Play
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { ThemeMode } from '../types/market';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  theme,
}) => {
  if (!isOpen) return null;

  const isLight = theme === 'light';
  const { isInstallable, isInstalled, isAndroid, install, triggerHaptic } = usePWAInstall();
  const [hapticTested, setHapticTested] = useState(false);
  const [activeTab, setActiveTab] = useState<'install' | 'permissions' | 'twa'>('install');

  const handleTestHaptic = () => {
    triggerHaptic([80, 50, 150]);
    setHapticTested(true);
    setTimeout(() => setHapticTested(false), 2000);
  };

  const handleInstallClick = async () => {
    triggerHaptic(25);
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'
      }`}>
        
        {/* Header */}
        <div className={`p-6 border-b flex items-center justify-between ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-[1px] shadow-lg shadow-emerald-500/20">
              <div className="w-full h-full rounded-[15px] bg-slate-950 flex items-center justify-center text-emerald-400">
                <Smartphone className="w-6 h-6" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className={`text-xl font-bold font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  TRADING FLOW ALERTS &bull; Android Native App
                </h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  APK / WebAPK
                </span>
              </div>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Application autonome haute performance avec accélération matérielle et retour haptique
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              isLight ? 'hover:bg-slate-200 text-slate-600' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className={`flex border-b px-6 gap-2 ${isLight ? 'border-slate-200 bg-white' : 'border-slate-800 bg-slate-900'}`}>
          <button
            onClick={() => setActiveTab('install')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'install'
                ? 'border-emerald-500 text-emerald-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Installation Android</span>
          </button>

          <button
            onClick={() => setActiveTab('permissions')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'permissions'
                ? 'border-emerald-500 text-emerald-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Permissions Android OS</span>
          </button>

          <button
            onClick={() => setActiveTab('twa')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'twa'
                ? 'border-emerald-500 text-emerald-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Package APK & Spécifications</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          
          {/* TAB 1: INSTALL */}
          {activeTab === 'install' && (
            <div className="space-y-5">
              
              {/* Install Hero Box */}
              <div className={`p-5 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${
                isInstalled 
                  ? 'bg-emerald-500/10 border-emerald-500/30' 
                  : isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-700'
              }`}>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-slate-950 p-2 border border-slate-700 shadow-md flex items-center justify-center shrink-0">
                    <img src="/icon.svg" alt="App Icon" className="w-10 h-10 object-contain" />
                  </div>
                  <div>
                    <h3 className={`font-bold text-base ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {isInstalled ? 'Application Déjà Installée' : 'Installer sur votre Appareil Android'}
                    </h3>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {isInstalled 
                        ? 'Trading Flow Alerts fonctionne en mode autonome plein écran avec accès direct sur votre écran d\'accueil.'
                        : 'Crée un WebAPK natif sur votre smartphone Android avec icône adaptative et notifications en tâche de fond.'}
                    </p>
                  </div>
                </div>

                {!isInstalled && (
                  <button
                    onClick={handleInstallClick}
                    className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer shrink-0"
                  >
                    <Download className="w-4 h-4" />
                    <span>Installer l'App</span>
                  </button>
                )}
              </div>

              {/* Step-by-Step Android Guide */}
              <div className={`p-4 rounded-xl border space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700'
              }`}>
                <h4 className={`font-bold text-xs uppercase font-mono tracking-wider ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                  Procédure Manuelle via Chrome Android
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className={`p-3 rounded-xl border ${isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center mb-2 font-mono">
                      1
                    </div>
                    <p className="font-semibold text-xs mb-1">Menu Navigateur</p>
                    <p className={isLight ? 'text-slate-500' : 'text-slate-400'}>
                      Touchez les <strong>trois points verticaux (⋮)</strong> en haut à droite de Google Chrome.
                    </p>
                  </div>

                  <div className={`p-3 rounded-xl border ${isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center mb-2 font-mono">
                      2
                    </div>
                    <p className="font-semibold text-xs mb-1">Installer l'application</p>
                    <p className={isLight ? 'text-slate-500' : 'text-slate-400'}>
                      Sélectionnez <strong>« Installer l'application »</strong> ou « Ajouter à l'écran d'accueil ».
                    </p>
                  </div>

                  <div className={`p-3 rounded-xl border ${isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center mb-2 font-mono">
                      3
                    </div>
                    <p className="font-semibold text-xs mb-1">WebAPK Généré</p>
                    <p className={isLight ? 'text-slate-500' : 'text-slate-400'}>
                      Android compile et installe le package dans votre tiroir d'applications comme une vraie app native !
                    </p>
                  </div>
                </div>
              </div>

              {/* Haptic Feedback Tester */}
              <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${
                isLight ? 'bg-amber-50/60 border-amber-200' : 'bg-amber-950/20 border-amber-500/30'
              }`}>
                <div className="flex items-center gap-3">
                  <Vibrate className="w-5 h-5 text-amber-500" />
                  <div>
                    <h4 className={`font-bold text-xs ${isLight ? 'text-amber-950' : 'text-amber-200'}`}>
                      Retour Haptique Android (Vibration Moteur)
                    </h4>
                    <p className={`text-[11px] ${isLight ? 'text-amber-800' : 'text-amber-300/80'}`}>
                      Vibre lors des franchissements de seuil d'alerte et des clics tactiles.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleTestHaptic}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow transition-all cursor-pointer shrink-0"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{hapticTested ? 'Vibration !' : 'Tester'}</span>
                </button>
              </div>

            </div>
          )}

          {/* TAB 2: PERMISSIONS */}
          {activeTab === 'permissions' && (
            <div className="space-y-4">
              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                L'application Android Trading Flow Alerts utilise des permissions minimales conformes aux standards de sécurité Google Play :
              </p>

              <div className="space-y-3">
                <div className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700'
                }`}>
                  <BellRing className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      android.permission.POST_NOTIFICATIONS (Android 13+)
                    </p>
                    <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      Permet d'afficher les alertes de franchissement de prix sur l'écran de verrouillage et le volet de notifications Android.
                    </p>
                  </div>
                </div>

                <div className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700'
                }`}>
                  <Vibrate className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      android.permission.VIBRATE
                    </p>
                    <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      Synchronise le vibreur de l'appareil avec le carillon sonore lors d'un signal de marché critique.
                    </p>
                  </div>
                </div>

                <div className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700'
                }`}>
                  <Wifi className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                  <div>
                    <p className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      android.permission.ACCESS_NETWORK_STATE
                    </p>
                    <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      Surveille la connectivité 4G/5G/Wi-Fi et réarme automatiquement les WebSockets et cotations dès le retour du réseau.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TWA / APK SPECIFICATIONS */}
          {activeTab === 'twa' && (
            <div className="space-y-4">
              <div className={`p-4 rounded-xl border font-mono text-xs space-y-2 ${
                isLight ? 'bg-slate-100 text-slate-800 border-slate-300' : 'bg-slate-950 text-slate-300 border-slate-800'
              }`}>
                <div className="flex justify-between pb-1 border-b border-slate-700/50">
                  <span className="text-slate-500">Package ID:</span>
                  <span className="text-emerald-400 font-bold">com.tradingflow.alerts</span>
                </div>
                <div className="flex justify-between pb-1 border-b border-slate-700/50">
                  <span className="text-slate-500">Architecture:</span>
                  <span className="text-sky-400">WebAPK / TWA (Trusted Web Activity)</span>
                </div>
                <div className="flex justify-between pb-1 border-b border-slate-700/50">
                  <span className="text-slate-500">Target SDK:</span>
                  <span className="text-amber-400">API Level 35 (Android 15)</span>
                </div>
                <div className="flex justify-between pb-1 border-b border-slate-700/50">
                  <span className="text-slate-500">Minimum SDK:</span>
                  <span>API Level 24 (Android 7.0 Nougat)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Digital Asset Links:</span>
                  <span className="text-emerald-400">/.well-known/assetlinks.json (Actif)</span>
                </div>
              </div>

              <div className={`p-4 rounded-xl border text-xs space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200 text-slate-600' : 'bg-slate-800/40 border-slate-700 text-slate-300'
              }`}>
                <h5 className="font-bold text-slate-200">Génération APK autonome (Option Bubblewrap / Capacitor)</h5>
                <p>
                  Pour exporter un fichier <code>.apk</code> ou <code>.aab</code> signé prêt pour le Google Play Store Console, l'application est configurée avec le manifeste PWA standard et la vérification AssetLinks Google Play.
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className={`p-4 border-t flex items-center justify-between text-xs ${
          isLight ? 'bg-slate-50 border-slate-200 text-slate-500' : 'bg-slate-950 border-slate-800 text-slate-400'
        }`}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-mono">Google Play & Android 14/15 Ready</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-all cursor-pointer"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
