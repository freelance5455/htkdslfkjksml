import React, { useState } from 'react';
import { Download, Smartphone, CheckCircle, ExternalLink, X, ShieldCheck, Sparkles, Copy, Check } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { sound } from '../utils/sound';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'direct' | 'bubblewrap' | 'manifest'>('direct');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    sound.playTap();
    if (isInstallable) {
      await install();
    }
  };

  const bubblewrapCommand = `npx @bubblewrap/cli init --manifest=https://${window.location.host}/manifest.webmanifest\nnpx @bubblewrap/cli build`;

  const handleCopy = () => {
    navigator.clipboard.writeText(bubblewrapCommand);
    setCopied(true);
    sound.playTap();
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadApkConfig = () => {
    sound.playTap();
    const configData = {
      appId: 'com.nutriquest.teengame',
      appName: 'NutriQuest: Teen Food Groups Quest',
      version: '1.2.0',
      versionCode: 12,
      packageType: 'Android WebAPK / TWA',
      targetSdkVersion: 34,
      minSdkVersion: 24,
      permissions: ['INTERNET', 'VIBRATE'],
      features: ['5_FOOD_GROUPS_QUIZ', 'PLATE_BLITZ_SORTING', 'REWARDS_XP_STREAK', 'OFFLINE_PWA'],
      manifestUrl: `https://${window.location.host}/manifest.webmanifest`,
      generatedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(configData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nutriquest-android-apk-config.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-emerald-500/30 p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-display text-white flex items-center gap-2">
                Android APK Installation
                <span className="text-xs font-sans px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </h3>
              <p className="text-xs text-slate-400">Install directly as a standalone Android app</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex gap-2 mt-4 p-1 rounded-xl bg-slate-800/60 border border-slate-700/50 text-xs font-semibold">
          <button
            onClick={() => {
              sound.playTap();
              setActiveTab('direct');
            }}
            className={`flex-1 py-2 rounded-lg transition ${
              activeTab === 'direct' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            1-Click Direct (WebAPK)
          </button>
          <button
            onClick={() => {
              sound.playTap();
              setActiveTab('bubblewrap');
            }}
            className={`flex-1 py-2 rounded-lg transition ${
              activeTab === 'bubblewrap' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Google CLI Build
          </button>
          <button
            onClick={() => {
              sound.playTap();
              setActiveTab('manifest');
            }}
            className={`flex-1 py-2 rounded-lg transition ${
              activeTab === 'manifest' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            APK Config
          </button>
        </div>

        {/* Content based on tab */}
        {activeTab === 'direct' && (
          <div className="mt-5 space-y-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 to-slate-900 border border-emerald-500/20">
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-emerald-300">Google Android WebAPK Engine</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Android automatically generates a signed native APK package when you install NutriQuest. It appears in your Android App Drawer, supports full-screen landscape/portrait, haptics, and works 100% offline!
                  </p>
                </div>
              </div>

              {isInstalled ? (
                <div className="mt-4 flex items-center justify-center gap-2 p-3 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-sm font-semibold">
                  <CheckCircle className="w-5 h-5" />
                  NutriQuest is Already Installed on this Device!
                </div>
              ) : isInstallable ? (
                <button
                  onClick={handleInstallClick}
                  className="mt-4 w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 transition active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  Install NutriQuest Android App Now
                </button>
              ) : (
                <div className="mt-4 p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300 space-y-2">
                  <p className="font-semibold text-white">Manual Android Step (3 seconds):</p>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/30 text-emerald-300 flex items-center justify-center text-xs font-bold">1</span>
                    <span>Tap the <strong>Chrome menu (⋮)</strong> at the top right of your phone</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/30 text-emerald-300 flex items-center justify-center text-xs font-bold">2</span>
                    <span>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/30 text-emerald-300 flex items-center justify-center text-xs font-bold">3</span>
                    <span>Android will generate the native APK and add the NutriQuest icon to your screen!</span>
                  </div>
                </div>
              )}
            </div>

            <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 text-xs text-slate-400 space-y-1.5">
              <div className="flex items-center gap-2 text-slate-200 font-medium">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Features Included in Android APK:
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-300 pl-1">
                <li>Offline nutrition gameplay with sound & Android vibration haptics</li>
                <li>Zero lag, hardware-accelerated animations</li>
                <li>Dedicated safe home screen icon with maskable adaptive design</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'bubblewrap' && (
          <div className="mt-5 space-y-4 text-xs">
            <p className="text-slate-300 leading-relaxed">
              Want to compile an unsigned or signed <strong>.apk</strong> / <strong>.aab</strong> file for the Google Play Store? Google’s official <strong>Bubblewrap CLI</strong> packages this PWA into an Android Studio project in seconds:
            </p>

            <div className="relative p-3 rounded-xl bg-slate-950 font-mono text-emerald-400 border border-slate-800">
              <pre className="whitespace-pre-wrap select-all">{bubblewrapCommand}</pre>
              <button
                onClick={handleCopy}
                className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                title="Copy Command"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-300 space-y-1">
              <p className="font-semibold text-white">Prerequisites:</p>
              <p>• Node.js 18+ and JDK 17</p>
              <p>• Android SDK / Command Line Tools</p>
            </div>
          </div>
        )}

        {activeTab === 'manifest' && (
          <div className="mt-5 space-y-4 text-xs">
            <p className="text-slate-300">
              Download the Android APK configuration specification to import directly into Capacitor, Cordova, or Android Studio:
            </p>

            <button
              onClick={downloadApkConfig}
              className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold flex items-center justify-center gap-2 transition"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              Download APK Metadata (.json)
            </button>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1 font-mono text-slate-400 text-[11px]">
              <div><strong>Package:</strong> com.nutriquest.teengame</div>
              <div><strong>Orientation:</strong> portrait</div>
              <div><strong>Theme Color:</strong> #10b981 (Emerald)</div>
              <div><strong>Category:</strong> Games / Education / Health</div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
          >
            Got it, Back to Game
          </button>
        </div>
      </div>
    </div>
  );
};
