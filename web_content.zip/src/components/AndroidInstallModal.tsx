import React from 'react';
import { X, Smartphone, Globe, Terminal, Download, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable?: boolean;
  isInstalled?: boolean;
  onInstallPWA?: () => void;
  onDownloadZip?: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  onInstallPWA,
  onDownloadZip,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#17072d] border border-[#d4af37]/40 w-full max-w-lg rounded-2xl shadow-2xl flex flex-col max-h-[88vh] overflow-hidden">
        {/* Header */}
        <div className="p-3.5 border-b border-[#d4af37]/25 flex items-center justify-between bg-[#1f0b3c]">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-[#fae48c]" />
            <h3 className="royal-heading font-bold gold-gradient-text text-base">
              App Download & Install
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#140626] border border-[#d4af37]/30 text-[#bda8d9] hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs text-[#dcd0ec] leading-relaxed">
          {/* Status if already installed */}
          {isInstalled && (
            <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Handsome AI is running in standalone native app mode!</span>
            </div>
          )}

          {/* Quick Direct Actions */}
          <div className="space-y-2">
            {isInstallable && onInstallPWA && (
              <button
                onClick={onInstallPWA}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#fae48c] via-[#d4af37] to-[#8d6f1a] text-[#120422] font-bold text-sm tracking-wide shadow-[0_3px_15px_rgba(212,175,55,0.35)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <Smartphone className="w-4 h-4" />
                <span>Install Handsome AI to Phone Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {onDownloadZip && (
              <button
                onClick={onDownloadZip}
                className="w-full py-2.5 px-4 rounded-xl bg-[#250f44] border border-[#d4af37]/40 text-[#fae48c] font-semibold text-xs hover:bg-[#301358] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Download App Source Bundle (.zip)</span>
              </button>
            )}
          </div>

          {/* Method 1: Progressive Web App (PWA) on Mobile */}
          <div className="bg-[#200b3d] border border-[#d4af37]/30 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-[#fae48c]">
              <Globe className="w-4 h-4 text-[#fae48c]" />
              <span>Option 1: Add to Home Screen (Android Chrome / Edge)</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-[12px] text-[#e8def5] pl-1">
              <li>Open this app on your phone browser.</li>
              <li>Tap the <strong>three dots (⋮)</strong> menu in the upper-right corner.</li>
              <li>Select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.</li>
              <li>Tap <strong>Add / Install</strong>. A golden <strong>Handsome AI</strong> icon will appear in your mobile app drawer!</li>
            </ol>
          </div>

          {/* iOS Safari Guide */}
          <div className="bg-[#1b0833] border border-[#d4af37]/20 rounded-xl p-3 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-bold text-[#fae48c]">
              <span>Option 2: iPhone / iPad (Safari)</span>
            </div>
            <p className="text-[11.5px] text-[#baa4d2]">
              1. Tap the <strong>Share</strong> button at the bottom of Safari.<br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.
            </p>
          </div>

          {/* Method 3: Termux On-Device Execution */}
          <div className="bg-[#200b3d] border border-[#d4af37]/30 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-[#fae48c]">
              <Terminal className="w-4 h-4 text-[#fae48c]" />
              <span>Option 3: Run Locally on Android via Termux</span>
            </div>
            <p className="text-[11.5px] text-[#baa4d2]">
              Run the full-stack server natively right on your Android phone:
            </p>
            <div className="bg-[#120524] p-2.5 rounded-lg border border-[#d4af37]/20 font-mono text-[11px] text-[#fae48c] space-y-1 overflow-x-auto">
              <p className="text-[#a591bf]"># 1. In Termux, install Node.js</p>
              <p>pkg update &amp;&amp; pkg install nodejs</p>
              <p className="text-[#a591bf] pt-1"># 2. Extract zip &amp; launch</p>
              <p>npm install &amp;&amp; npm run dev</p>
            </div>
            <p className="text-[11px] text-[#baa4d2]">
              Then open <code className="text-[#fae48c] bg-[#120524] px-1 py-0.5 rounded">http://localhost:3000</code> in mobile Chrome.
            </p>
          </div>

          {/* Highlights */}
          <div className="bg-[#140526] border border-[#d4af37]/20 rounded-xl p-3 space-y-1 text-[11px]">
            <div className="flex items-center gap-1.5 font-bold text-[#fae48c]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>PWA Mobile Features</span>
            </div>
            <p className="text-[#bba8d1]">
              Features standalone full-screen view (no browser search bar), royal purple theme status bar, instant touch navigation dock, and local offline persistence for saved creations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
