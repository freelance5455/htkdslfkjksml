import { useEffect, useState } from 'react';
import { Check, Copy, Download, Smartphone, X } from 'lucide-react';

interface AndroidInstallModalProps {
  open: boolean;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onInstallPrompt: () => Promise<boolean>;
  onClose: () => void;
}

export function AndroidInstallModal({
  open,
  isInstallable,
  isInstalled,
  isIOS,
  onInstallPrompt,
  onClose,
}: AndroidInstallModalProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  async function handleCopyUrl() {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard fallback ignored when unavailable
    }
  }

  async function handleDirectInstall() {
    const accepted = await onInstallPrompt();
    if (accepted) {
      onClose();
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="android-install-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-[#dce6e0] bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#eaf2ed] text-[#123b32]">
              <Smartphone className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h3 id="android-install-title" className="text-base font-bold text-[#16221c]">
                Android ایپ انسٹال اور APK گائیڈ
              </h3>
              <p className="mt-0.5 text-xs text-[#64736b]">
                موبائل ہوم اسکرین پر انسٹال کریں یا APK پیکج بنائیں
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="بند کریں"
            className="flex h-9 w-9 items-center justify-center rounded-lg text-[#64736b] transition-colors hover:bg-[#f2f6f4] hover:text-[#16221c]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-sm text-[#2c3b33]">
          {isInstalled ? (
            <div className="rounded-xl border border-[#b9dec9] bg-[#eef8f2] px-4 py-3 text-xs font-medium text-[#123b32]">
              یہ ایپ پہلے ہی آپ کی ڈیوائس پر بطور اسٹینڈ الون ایپ انسٹال ہے۔
            </div>
          ) : isInstallable ? (
            <div className="rounded-xl border border-[#cde0d5] bg-[#f4f8f5] p-4">
              <div className="font-semibold text-[#123b32]">1. براہِ راست Android پر انسٹال کریں (تجویز کردہ)</div>
              <p className="mt-1 text-xs leading-6 text-[#526259]">
                بغیر APK فائل ڈاؤن لوڈ کیے ایپ کو فوری طور پر اپنے فون پر انسٹال کریں۔ یہ آف لائن بھی کام کرتی ہے۔
              </p>
              <button
                type="button"
                onClick={handleDirectInstall}
                className="mt-3 inline-flex min-h-[40px] items-center justify-center gap-2 rounded-xl bg-[#123b32] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1d6b52]"
              >
                <Download className="h-4 w-4" aria-hidden="true" />
                <span>فون پر انسٹال کریں</span>
              </button>
            </div>
          ) : isIOS ? (
            <div className="rounded-xl border border-[#dfe7e2] bg-[#fafcfb] p-4">
              <div className="font-semibold text-[#16221c]">1. iPhone / iPad پر انسٹال کریں</div>
              <p className="mt-1 text-xs leading-6 text-[#526259]">
                Safari ٹول بار میں <strong>Share</strong> بٹن دبائیں، پھر نیچے سکرول کر کے{' '}
                <strong>Add to Home Screen</strong> منتخب کریں۔
              </p>
            </div>
          ) : (
            <div className="rounded-xl border border-[#dfe7e2] bg-[#fafcfb] p-4">
              <div className="font-semibold text-[#16221c]">1. Android Chrome میں ایپ انسٹال کریں</div>
              <p className="mt-1 text-xs leading-6 text-[#526259]">
                Android فون پر Chrome براؤزر میں یہ صفحہ کھولیں، اوپر دائیں مینیو (⋮) پر کلک کریں اور{' '}
                <strong>Install app</strong> یا <strong>Add to Home screen</strong> منتخب کریں۔
              </p>
            </div>
          )}

          <div className="rounded-xl border border-[#dfe7e2] bg-[#fafcfb] p-4">
            <div className="font-semibold text-[#16221c]">2. APK فائل کیسے حاصل کریں؟</div>
            <p className="mt-1 text-xs leading-6 text-[#526259]">
              براؤزر سے براہِ راست APK کمپائل نہیں ہو سکتا کیونکہ APK بنانے کے لیے Android SDK سائننگ درکار ہوتی ہے۔ یہ ایپ مکمل PWA معیار (Manifest اور Service Worker) کے ساتھ تیار ہے، اس لیے آپ نیچے دیے گئے لنک کو <strong>pwabuilder.com</strong> پر پیسٹ کر کے مفت سائنڈ <strong>Android .apk</strong> پیکج ڈاؤن لوڈ کر سکتے ہیں۔
            </p>
            {appUrl && (
              <div className="mt-3 flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  dir="ltr"
                  aria-label="ایپ کا لنک"
                  className="font-num min-h-[38px] flex-1 rounded-lg border border-[#d1ddd6] bg-white px-3 text-xs text-[#16221c]"
                />
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-[#eaf2ed] px-3 py-1.5 text-xs font-semibold text-[#123b32] transition-colors hover:bg-[#dce9e1] whitespace-nowrap shrink-0"
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>کاپی ہوگیا</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>لنک کاپی کریں</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] rounded-xl border border-[#d6e0da] bg-white px-4 py-2 text-sm font-semibold text-[#16221c] transition-colors hover:bg-[#f4f7f5]"
          >
            بند کریں
          </button>
        </div>
      </div>
    </div>
  );
}
