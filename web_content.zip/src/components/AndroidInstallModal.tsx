import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  CheckCircle2, 
  X, 
  Maximize, 
  Minimize, 
  Vibrate, 
  WifiOff, 
  ShieldCheck, 
  Layers, 
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';
import { triggerVibration } from '../utils/audioFeedback';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [installing, setInstalling] = useState<boolean>(false);
  const [installSuccess, setInstallSuccess] = useState<boolean>(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstalling(true);
    triggerVibration(true, 'tap');
    const result = await install();
    setInstalling(false);
    if (result) {
      setInstallSuccess(true);
      triggerVibration(true, 'complete');
      setTimeout(() => {
        onClose();
      }, 2500);
    }
  };

  const toggleFullscreen = () => {
    triggerVibration(true, 'tap');
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const testVibration = () => {
    triggerVibration(true, 'complete');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-lg bg-[#042017] border border-emerald-600/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-[#F8FAF8]"
        dir="rtl"
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-[#031d14] via-[#083a2a] to-[#031d14] p-5 border-b border-emerald-700/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5 shadow-lg flex items-center justify-center">
              <img 
                src="/pwa-192x192.png" 
                alt="حصن المسلم" 
                className="w-full h-full rounded-[14px] object-cover"
                onError={(e) => {
                  // Fallback if image not ready
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <Smartphone className="w-6 h-6 text-[#042017] hidden only:block" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-lg font-bold text-amber-300 font-cairo">
                  تطبيق حصن المسلم للأندرويد
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                  Android App
                </span>
              </div>
              <p className="text-xs text-emerald-200/80">
                تشغيل كتطبيق مستقل على هاتفك المحمول
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              triggerVibration(true, 'light');
              onClose();
            }}
            className="p-2 text-emerald-300/70 hover:text-white hover:bg-emerald-800/40 rounded-full transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="p-5 overflow-y-auto space-y-4 custom-scrollbar text-sm">
          {/* Status banner */}
          {isInstalled || installSuccess ? (
            <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-3">
              <CheckCircle2 className="w-7 h-7 text-emerald-400 shrink-0" />
              <div>
                <p className="font-bold text-emerald-200 text-sm">
                  التطبيق مثبت على هاتفك بنجاح!
                </p>
                <p className="text-xs text-emerald-300/80 mt-0.5">
                  يعمل الآن بملء الشاشة مع حفظ البيانات بدون إنترنت.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-gradient-to-br from-[#073223] to-[#042319] border border-amber-500/30 rounded-2xl">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center shrink-0 text-amber-400">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-white text-sm">
                    تحويل إلى تطبيق هاتف كامل (Android WebAPK)
                  </h4>
                  <p className="text-xs text-emerald-100/80 mt-1 leading-relaxed">
                    تمت تهيئة المشروع كـ <strong>تطبيق أندرويد متكامل (PWA / WebAPK)</strong>. عند تثبيته على هاتفك، سيعمل بدون شريط المتصفح، مع أيقونة خاصة على شاشتك الرئيسية، ويعمل دون الحاجة إلى اتصال بالإنترنت.
                  </p>
                </div>
              </div>

              {/* Direct Install Button if supported */}
              {isInstallable && (
                <div className="mt-4 pt-3 border-t border-emerald-800/60">
                  <button
                    onClick={handleInstallClick}
                    disabled={installing}
                    className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold rounded-xl shadow-lg shadow-amber-600/20 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-98 disabled:opacity-50"
                  >
                    <Download className="w-5 h-5" />
                    <span>{installing ? 'جارٍ التثبيت...' : 'تثبيت التطبيق على هاتف أندرويد الآن'}</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Quick Android Features */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3 bg-[#031d14] border border-emerald-800/40 rounded-xl flex items-center gap-2.5">
              <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">يعمل بدون إنترنت</p>
                <p className="text-[10px] text-emerald-300/70">حفظ كامل للأذكار والأصوات</p>
              </div>
            </div>

            <div className="p-3 bg-[#031d14] border border-emerald-800/40 rounded-xl flex items-center gap-2.5">
              <Vibrate className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">اهتزاز فيزيائي (Haptics)</p>
                <p className="text-[10px] text-emerald-300/70">تفاعل لمسي حقيقي للسبحة</p>
              </div>
            </div>

            <div className="p-3 bg-[#031d14] border border-emerald-800/40 rounded-xl flex items-center gap-2.5">
              <Layers className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">مزامنة سحابية</p>
                <p className="text-[10px] text-emerald-300/70">Firebase لحفظ أذكارك</p>
              </div>
            </div>

            <div className="p-3 bg-[#031d14] border border-emerald-800/40 rounded-xl flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">صدقة جارية</p>
                <p className="text-[10px] text-emerald-300/70">عن الحاجة هدي رحمها الله</p>
              </div>
            </div>
          </div>

          {/* Step-by-Step Installation Guide for Android Devices */}
          <div className="bg-[#021811] border border-emerald-800/50 rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              طريقة التثبيت السريعة على هاتف أندرويد (Google Chrome أو Samsung):
            </h4>
            <div className="space-y-2.5 text-xs text-emerald-100/90 pr-1">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-800/70 text-amber-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  1
                </span>
                <p>
                  افتح رابط التطبيق في متصفح <strong>Google Chrome</strong> على هاتفك الأندرويد.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-800/70 text-amber-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  2
                </span>
                <p>
                  اضغط على زر القائمة <strong>النقاط الثلاث (⋮)</strong> في أعلى يمين المتصفح.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-800/70 text-amber-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  3
                </span>
                <p>
                  اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.
                </p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-800/70 text-amber-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  4
                </span>
                <p>
                  سيظهر التطبيق فوراً على شاشة هاتفك مثل أي تطبيق تم تنزيله من Google Play بأيقونة مستقلة وتجربة أندرويد كاملة.
                </p>
              </div>
            </div>
          </div>

          {/* Interactive controls: Fullscreen & Vibration Test */}
          <div className="p-3.5 bg-[#031d14] border border-emerald-800/40 rounded-2xl space-y-2">
            <p className="text-xs font-bold text-emerald-200">أدوات تحسين تجربة الهاتف:</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={toggleFullscreen}
                className="py-2 px-3 bg-emerald-900/60 hover:bg-emerald-800/80 border border-emerald-700/40 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer text-emerald-100 transition-colors"
              >
                {isFullscreen ? <Minimize className="w-4 h-4 text-amber-400" /> : <Maximize className="w-4 h-4 text-amber-400" />}
                <span>{isFullscreen ? 'الخروج من ملء الشاشة' : 'وضع ملء الشاشة'}</span>
              </button>

              <button
                onClick={testVibration}
                className="py-2 px-3 bg-emerald-900/60 hover:bg-emerald-800/80 border border-emerald-700/40 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer text-emerald-100 transition-colors"
              >
                <Vibrate className="w-4 h-4 text-emerald-400" />
                <span>اختبار اهتزاز الهاتف</span>
              </button>
            </div>
          </div>

          {/* Native Android APK Building Info via Capacitor */}
          <div className="p-3 bg-[#021811]/70 border border-emerald-900/60 rounded-xl text-[11px] text-emerald-300/80 space-y-1">
            <p className="font-semibold text-emerald-200 flex items-center gap-1">
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              ترغب في ملف APK للتثبيت المباشر عبر Android Studio؟
            </p>
            <p className="leading-relaxed">
              تم تضمين ملف إعدادات <code>capacitor.config.json</code> وتهيئة PWA بنجاح. يمكنك بناء ملف <code>.apk</code> أو <code>.aab</code> بضغطة زر عبر أمر:
              <code className="block mt-1 p-1.5 bg-black/60 rounded border border-emerald-900 text-amber-300 font-mono text-[10px] text-left" dir="ltr">
                npx cap add android && npx cap open android
              </code>
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#031d14] border-t border-emerald-800/50 flex items-center justify-between">
          <p className="text-[11px] text-emerald-300/70">
            حصن المسلم • إصدار الأندرويد والهاتف
          </p>
          <button
            onClick={() => {
              triggerVibration(true, 'light');
              onClose();
            }}
            className="py-2 px-5 bg-emerald-800/80 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer transition-colors"
          >
            حسناً، فهمت
          </button>
        </div>
      </div>
    </div>
  );
};
