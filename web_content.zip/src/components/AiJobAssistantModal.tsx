import React, { useState, useRef, useEffect } from 'react';
import { JobPosting } from '../types/job';
import {
  UserConversationContext,
  processConversationalQuery,
  getDaysRemaining
} from '../lib/conversationalAi';
import {
  Bot,
  Send,
  X,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Calendar,
  MapPin,
  Award,
  GraduationCap,
  Building2,
  DollarSign,
  Users,
  RotateCcw,
  Clock,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface AiJobAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  jobs: JobPosting[];
  onSelectJob: (job: JobPosting) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  matchedJobs?: JobPosting[];
  suggestedFollowUps?: string[];
  timestamp: string;
  isDisclaimer?: boolean;
}

const DEFAULT_SUGGESTED_PROMPTS = [
  'Find government jobs for me',
  'Show jobs closing soon',
  'Am I eligible for this job?',
  'Find graduate jobs',
  'Help me prepare for an interview',
  'Jobs in West Bengal',
  'How to prepare a resume?'
];

export const AiJobAssistantModal: React.FC<AiJobAssistantModalProps> = ({
  isOpen,
  onClose,
  jobs,
  onSelectJob
}) => {
  const [inputQuery, setInputQuery] = useState('');
  const [context, setContext] = useState<UserConversationContext>({});
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome',
      sender: 'assistant',
      text: "Hi! 👋 Welcome to India Job Hub.\nI'm your conversational AI Job Assistant. I can help you find suitable jobs, explain eligibility, deadlines, qualifications, application procedures, or offer general interview & exam guidance.\n\nWhat are you looking for today?",
      suggestedFollowUps: [
        'Find government jobs for me',
        'Show jobs closing soon',
        'Find graduate jobs',
        'West Bengal vacancies'
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isDisclaimer: false
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [activeSuggestedPrompts, setActiveSuggestedPrompts] = useState<string[]>(DEFAULT_SUGGESTED_PROMPTS);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll when messages or typing status updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Clear conversation & reset context
  const handleResetChat = () => {
    setContext({});
    setActiveSuggestedPrompts(DEFAULT_SUGGESTED_PROMPTS);
    setMessages([
      {
        id: `welcome_${Date.now()}`,
        sender: 'assistant',
        text: "Conversation reset! 👋 How can I help you right now?\nFeel free to say hello, ask for vacancies by qualification or location, or inquire about eligibility and interview preparation.",
        suggestedFollowUps: DEFAULT_SUGGESTED_PROMPTS.slice(0, 4),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isDisclaimer: false
      }
    ]);
  };

  // Main message sender: hybrid backend Gemini + local conversational AI engine
  const handleSend = async (textToSend?: string) => {
    const rawText = textToSend || inputQuery;
    const text = rawText.trim();
    if (!text || isTyping) return;

    const userMessageId = `user_${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMessageId,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    // Build chat history for conversational context
    const chatHistory = messages
      .filter((m) => m.id !== 'welcome')
      .slice(-8)
      .map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('assistant' as const),
        content: m.text
      }));

    let botResponseText = '';
    let botMatchedJobs: JobPosting[] = [];
    let botFollowUps: string[] = [];
    let botDisclaimer = false;

    const FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE =
      "Sorry! 😅 I'm having a little trouble connecting to my AI service right now. Please try again in a moment. Your jobs and other India Job Hub features are still available.";

    try {
      // 1. Attempt server-side Gemini conversational API
      // Allow up to 25s for server to complete up to 3 retries with exponential backoff
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 25000);

      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: chatHistory,
          context,
          availableJobs: jobs
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();

        // Check if service unavailable (e.g. after all 3 retries failed on 503/429/500)
        if (data && data.isServiceUnavailable) {
          botResponseText = data.responseText || FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE;
          botFollowUps = data.suggestedFollowUps || ['Try again in a moment', 'Find government jobs', 'Show jobs closing soon'];
          botDisclaimer = false;
        } else if (data && data.success && data.responseText) {
          botResponseText = data.responseText;
          botFollowUps = data.suggestedFollowUps || [];
          botDisclaimer = Boolean(data.isDisclaimer);

          // Resolve matched jobs by ID
          if (Array.isArray(data.matchedJobIds) && data.matchedJobIds.length > 0) {
            botMatchedJobs = jobs.filter((j) => data.matchedJobIds.includes(j.id));
          }
        } else if (data && data.fallbackToLocal) {
          // GEMINI_API_KEY not configured: gracefully use conversational engine
          const result = processConversationalQuery(text, context, jobs);
          botResponseText = result.responseText;
          botMatchedJobs = result.matchedJobs || [];
          botFollowUps = result.suggestedFollowUps || [];
          botDisclaimer = Boolean(result.isDisclaimer);
          setContext(result.updatedContext);
        }
      } else {
        // Server returned non-200 (e.g. 404 on static Firebase Hosting or 503 from proxy)
        // Gracefully use local conversational AI engine grounded in real database jobs
        const result = processConversationalQuery(text, context, jobs);
        botResponseText = result.responseText || FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE;
        botMatchedJobs = result.matchedJobs || [];
        botFollowUps = result.suggestedFollowUps || [];
        botDisclaimer = Boolean(result.isDisclaimer);
        setContext(result.updatedContext);
      }
    } catch {
      // Network failure, timeout, or abort — gracefully fallback to conversational engine
      try {
        const result = processConversationalQuery(text, context, jobs);
        botResponseText = result.responseText || FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE;
        botMatchedJobs = result.matchedJobs || [];
        botFollowUps = result.suggestedFollowUps || [];
        botDisclaimer = Boolean(result.isDisclaimer);
        setContext(result.updatedContext);
      } catch {
        botResponseText = FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE;
        botFollowUps = ['Try again in a moment', 'Find government jobs', 'Show jobs closing soon'];
        botDisclaimer = false;
      }
    }

    // Fallback safety to guarantee response is never blank or empty
    if (!botResponseText) {
      botResponseText = FRIENDLY_SERVICE_UNAVAILABLE_MESSAGE;
      botFollowUps = ['Try again in a moment', 'Find government jobs', 'Show jobs closing soon'];
    }

    // Update active suggested prompts
    if (botFollowUps.length > 0) {
      setActiveSuggestedPrompts(botFollowUps);
    }

    const assistantMsg: ChatMessage = {
      id: `assistant_${Date.now()}`,
      sender: 'assistant',
      text: botResponseText,
      matchedJobs: botMatchedJobs,
      suggestedFollowUps: botFollowUps,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isDisclaimer: botDisclaimer || (botMatchedJobs && botMatchedJobs.length > 0)
    };

    setMessages((prev) => [...prev, assistantMsg]);
    setIsTyping(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-2 sm:p-4">
      <div
        id="modal-ai-job-assistant"
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col h-[90vh] max-h-[740px] overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-3.5 sm:p-4 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-indigo-700 border border-indigo-400/30 flex items-center justify-center text-white shadow-lg shadow-indigo-600/25 shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  AI Job Assistant
                </h2>
                <span className="px-2 py-0.5 text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Conversational & Live
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Natural Chat • Verified Vacancies • Eligibility Guidance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Reset Chat Button */}
            <button
              id="btn-reset-ai-chat"
              onClick={handleResetChat}
              title="Reset Conversation"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center gap-1 text-xs"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline text-[11px]">Reset</span>
            </button>

            {/* Close Modal Button */}
            <button
              id="btn-close-ai-assistant"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* User Context Pill (if recognized qualification, location, or sector) */}
        {(context.qualification || context.location || context.sector || context.age) && (
          <div className="px-4 py-1.5 bg-indigo-950/40 border-b border-indigo-800/40 flex items-center gap-2 text-[11px] text-indigo-300 overflow-x-auto scrollbar-none shrink-0">
            <span className="font-semibold text-slate-400">Current Context:</span>
            {context.qualification && (
              <span className="px-2 py-0.5 bg-indigo-900/60 border border-indigo-700/60 rounded-full">
                🎓 {context.qualification}
              </span>
            )}
            {context.location && (
              <span className="px-2 py-0.5 bg-indigo-900/60 border border-indigo-700/60 rounded-full">
                📍 {context.location}
              </span>
            )}
            {context.sector && (
              <span className="px-2 py-0.5 bg-indigo-900/60 border border-indigo-700/60 rounded-full">
                🏛️ {context.sector}
              </span>
            )}
            {context.age && (
              <span className="px-2 py-0.5 bg-indigo-900/60 border border-indigo-700/60 rounded-full">
                🎂 Age {context.age}
              </span>
            )}
          </div>
        )}

        {/* Chat Messages Body */}
        <div className="flex-1 p-3.5 sm:p-4 overflow-y-auto space-y-4 text-xs">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[82%] p-3.5 rounded-2xl ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-br-none shadow-md shadow-indigo-900/20'
                    : 'bg-slate-800/90 border border-slate-700/80 text-slate-200 rounded-bl-none shadow-sm'
                }`}
              >
                {/* Assistant avatar indicator */}
                {msg.sender === 'assistant' && (
                  <div className="flex items-center gap-1.5 mb-1.5 text-[10px] text-indigo-400 font-semibold">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>AI Job Assistant</span>
                  </div>
                )}

                {/* Message Text with formatting */}
                <div className="leading-relaxed whitespace-pre-wrap font-normal">
                  {msg.text}
                </div>

                {/* Render matched real jobs if any */}
                {msg.matchedJobs && msg.matchedJobs.length > 0 && (
                  <div className="mt-3 space-y-2 pt-2.5 border-t border-slate-700/70">
                    <div className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                      <span>Verified Openings ({msg.matchedJobs.length})</span>
                      <span className="text-[10px] text-slate-400 font-normal">Click to view & apply</span>
                    </div>

                    <div className="space-y-2">
                      {msg.matchedJobs.map((job) => {
                        const daysRemaining = getDaysRemaining(job);
                        const isClosingSoon = daysRemaining >= 0 && daysRemaining <= 14;

                        return (
                          <div
                            key={job.id}
                            id={`job-match-${job.id}`}
                            onClick={() => {
                              onClose();
                              onSelectJob(job);
                            }}
                            className="bg-slate-900/95 hover:bg-slate-950 p-3 rounded-xl border border-slate-700/90 hover:border-indigo-500/60 cursor-pointer transition-all flex flex-col gap-2 group shadow-sm"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <span className="font-bold text-white text-xs group-hover:text-indigo-300 transition-colors line-clamp-1">
                                  📌 {job.title}
                                </span>
                                <div className="text-[11px] text-slate-400 truncate flex items-center gap-1.5 mt-0.5">
                                  <Building2 className="w-3 h-3 text-slate-500 shrink-0" />
                                  <span>{job.organization}</span>
                                  <span>•</span>
                                  <span className={`font-semibold ${job.sector === 'Government' ? 'text-emerald-400' : 'text-blue-400'}`}>
                                    {job.sector}
                                  </span>
                                </div>
                              </div>

                              {isClosingSoon && (
                                <span className="px-1.5 py-0.5 text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded shrink-0 flex items-center gap-1">
                                  <Clock className="w-2.5 h-2.5" />
                                  {daysRemaining}d left
                                </span>
                              )}
                            </div>

                            {/* Structured Details Grid */}
                            <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px] text-slate-300 pt-1 border-t border-slate-800/80">
                              <div className="flex items-center gap-1 text-slate-400 truncate">
                                <MapPin className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                <span className="truncate">{job.district ? `${job.district}, ` : ''}{job.state}</span>
                              </div>
                              <div className="flex items-center gap-1 text-slate-400 truncate">
                                <GraduationCap className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                <span className="truncate">{job.qualification}</span>
                              </div>
                              <div className="flex items-center gap-1 text-slate-400 truncate">
                                <DollarSign className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                <span className="truncate text-emerald-300 font-medium">{job.salary || 'As per norms'}</span>
                              </div>
                              <div className="flex items-center gap-1 text-slate-400 truncate">
                                <Users className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                                <span>{job.vacancies} Vacancies</span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[10px] pt-1 text-slate-400">
                              <span className="text-amber-400/90 font-medium">
                                📅 Last Date: {job.closingDate || job.lastDate || 'Check Notification'}
                              </span>
                              <span className="text-indigo-400 font-semibold group-hover:text-indigo-300 flex items-center gap-0.5">
                                <span>View Details</span>
                                <ChevronRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Official Notification Gazette Disclaimer */}
                {msg.isDisclaimer && (
                  <p className="text-[10px] text-slate-400/90 mt-2.5 pt-2 border-t border-slate-700/50 italic flex items-start gap-1">
                    <span className="text-amber-400 not-italic shrink-0">⚠️</span>
                    <span>
                      Official recruitment notification / gazette is the supreme legal authority regarding eligibility, age relaxation, syllabus, and reservation criteria.
                    </span>
                  </p>
                )}
              </div>

              <span className="text-[9px] text-slate-500 px-1 mt-1 font-mono">
                {msg.timestamp}
              </span>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-slate-800/70 border border-slate-700/50 w-36 text-slate-400 text-xs">
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:150ms]" />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:300ms]" />
              </div>
              <span className="text-[11px] text-slate-400">Thinking...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Dynamic Suggested Prompt Chips */}
        <div className="px-3 py-2 bg-slate-900/95 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Suggested:</span>
          </span>
          {activeSuggestedPrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => handleSend(prompt)}
              disabled={isTyping}
              className="whitespace-nowrap px-2.5 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-750 border border-slate-700/90 hover:border-indigo-500/50 text-[11px] text-slate-300 hover:text-white font-medium transition-all shrink-0 active:scale-95 disabled:opacity-50"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 shrink-0">
          <input
            id="input-ai-query"
            ref={inputRef}
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            placeholder="Ask anything (e.g. 'Hi', 'job chai', 'amar jonno kon job ache', 'eligibility?')..."
            className="flex-1 px-3.5 py-2.5 bg-slate-800/90 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
            disabled={isTyping}
          />
          <button
            id="btn-ai-send"
            onClick={() => handleSend()}
            disabled={!inputQuery.trim() || isTyping}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold transition-all shrink-0 flex items-center justify-center shadow-md shadow-indigo-600/20 active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
