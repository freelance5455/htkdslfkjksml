import React from 'react';
import { X, Upload, Shield } from 'lucide-react';
import { MinistryContentUploader } from './MinistryContentUploader';

interface GlobalUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalUploadModal: React.FC<GlobalUploadModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 relative">
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-amber-500/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-slate-950 shadow-lg">
              <Upload className="w-5 h-5 font-bold" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-serif text-amber-100">
                Global Ministry Content Upload Center
              </h2>
              <p className="text-xs text-amber-300/80">
                Authorized Session for Prophet JUHNKRIX SYNVAGORD • IndexedDB Offline Vault
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-all border border-amber-500/20"
            title="Close Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div id="upload-action" className="space-y-6">
          <MinistryContentUploader />
        </div>
      </div>
    </div>
  );
};
