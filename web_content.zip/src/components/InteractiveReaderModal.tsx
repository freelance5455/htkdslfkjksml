import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  BookOpen,
  Download,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Type,
  List,
  CheckCircle,
  HelpCircle,
  Share2
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

export const InteractiveReaderModal: React.FC = () => {
  const { readerEbook, setReaderEbook, showToast } = useApp();

  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [theme, setTheme] = useState<'day' | 'sepia' | 'night'>('day');
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [revealedAnswers, setRevealedAnswers] = useState<Record<number, boolean>>({});
  const [showTocSidebar, setShowTocSidebar] = useState(false);

  if (!readerEbook) return null;

  const currentChapter = readerEbook.tableOfContents[activeChapterIndex] || readerEbook.tableOfContents[0];
  const totalChapters = readerEbook.tableOfContents.length;
  const progressPercent = Math.round(((activeChapterIndex + 1) / totalChapters) * 100);

  const toggleRevealAnswer = (idx: number) => {
    setRevealedAnswers((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  const themeClasses = {
    day: 'bg-white text-slate-900 border-slate-200',
    sepia: 'bg-[#FBF0D9] text-[#433422] border-[#E8D7B8]',
    night: 'bg-[#0F172A] text-slate-100 border-slate-800'
  };

  const contentBgClasses = {
    day: 'bg-[#F8FAFC]',
    sepia: 'bg-[#F4E8CE]',
    night: 'bg-[#1E293B]'
  };

  const fontSizeClasses = {
    sm: 'text-xs sm:text-sm leading-relaxed',
    md: 'text-sm sm:text-base leading-relaxed',
    lg: 'text-base sm:text-lg leading-loose'
  };

  const handleDownloadOffline = () => {
    downloadEbookAsHtml(readerEbook, true);
    showToast(`Saved offline HTML ebook for "${readerEbook.title.substring(0, 24)}..."`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/90 backdrop-blur-md">
      {/* Reader Top Bar */}
      <header className="bg-[#0B192C] text-white px-3 sm:px-6 py-3 flex items-center justify-between border-b border-[#1E3E62] shrink-0">
        <div className="flex items-center gap-2 sm:gap-4 overflow-hidden">
          <button
            onClick={() => setReaderEbook(null)}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Exit Reader"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="overflow-hidden">
            <h2 className="text-xs sm:text-sm font-bold text-white truncate max-w-xs sm:max-w-md">
              {readerEbook.title}
            </h2>
            <p className="text-[10px] text-amber-400 truncate">
              {readerEbook.targetExam} • {readerEbook.language}
            </p>
          </div>
        </div>

        {/* Reader Controls */}
        <div className="flex items-center gap-1.5 sm:gap-3">
          {/* Theme toggles */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
            <button
              onClick={() => setTheme('day')}
              className={`p-1.5 rounded text-xs transition-colors ${
                theme === 'day' ? 'bg-white text-slate-900 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Day Mode"
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setTheme('sepia')}
              className={`p-1.5 rounded text-xs transition-colors ${
                theme === 'sepia' ? 'bg-[#EAD9B8] text-[#433422] font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Sepia Eye-Care"
            >
              <span className="text-[10px] font-bold">Aa</span>
            </button>
            <button
              onClick={() => setTheme('night')}
              className={`p-1.5 rounded text-xs transition-colors ${
                theme === 'night' ? 'bg-slate-900 text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Night Mode"
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Font Size controls */}
          <div className="flex items-center bg-slate-800/80 rounded-lg px-2 py-1 border border-slate-700 text-xs">
            <button
              onClick={() => setFontSize('sm')}
              className={`px-1.5 py-0.5 text-[11px] rounded ${fontSize === 'sm' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
            >
              A-
            </button>
            <button
              onClick={() => setFontSize('md')}
              className={`px-1.5 py-0.5 text-xs rounded ${fontSize === 'md' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
            >
              A
            </button>
            <button
              onClick={() => setFontSize('lg')}
              className={`px-1.5 py-0.5 text-sm rounded ${fontSize === 'lg' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
            >
              A+
            </button>
          </div>

          {/* TOC sidebar toggle */}
          <button
            onClick={() => setShowTocSidebar(!showTocSidebar)}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Chapters"
          >
            <List className="w-5 h-5 text-amber-400" />
          </button>

          {/* Download HTML Button */}
          <button
            onClick={handleDownloadOffline}
            className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 px-3 py-1.5 rounded-lg transition-colors shadow-xs"
            title="Download full offline HTML study file"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Save Offline HTML</span>
          </button>

          <button
            onClick={() => setReaderEbook(null)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Progress Line */}
      <div className="w-full bg-slate-800 h-1">
        <div
          className="bg-amber-400 h-1 transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Main Reader Content Area with optional TOC sidebar */}
      <div className="flex-1 flex overflow-hidden">
        {/* Table of Contents Drawer/Sidebar */}
        {showTocSidebar && (
          <aside className="w-72 sm:w-80 bg-[#0B192C] text-slate-200 border-r border-[#1E3E62] flex flex-col shrink-0 z-20">
            <div className="p-3 border-b border-[#1E3E62] flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Chapters & Syllabus ({totalChapters})
              </span>
              <button
                onClick={() => setShowTocSidebar(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto divide-y divide-slate-800 text-xs">
              {readerEbook.tableOfContents.map((ch, idx) => (
                <button
                  key={ch.chapterNumber}
                  onClick={() => {
                    setActiveChapterIndex(idx);
                    setShowTocSidebar(false);
                  }}
                  className={`w-full text-left p-3 flex items-start gap-2.5 hover:bg-slate-800/80 transition-colors ${
                    activeChapterIndex === idx ? 'bg-slate-800 font-bold text-amber-400' : 'text-slate-300'
                  }`}
                >
                  <span className="w-5 h-5 rounded bg-slate-700 text-slate-300 flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                    {ch.chapterNumber}
                  </span>
                  <div className="flex-1">
                    <p className="line-clamp-2">{ch.title}</p>
                    <span className="text-[10px] text-slate-500">pp. {ch.pages}</span>
                  </div>
                </button>
              ))}
            </div>
          </aside>
        )}

        {/* Ebook Page Canvas */}
        <main className={`flex-1 overflow-y-auto p-4 sm:p-8 flex justify-center ${themeClasses[theme]}`}>
          <div className="w-full max-w-3xl space-y-6">
            {/* Chapter Header */}
            <div className={`p-4 sm:p-6 rounded-2xl border ${contentBgClasses[theme]} border-slate-300/40`}>
              <div className="flex items-center justify-between text-xs font-bold text-amber-600 mb-2">
                <span>CHAPTER {currentChapter.chapterNumber} OF {totalChapters}</span>
                <span>Pages {currentChapter.pages}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black mb-2">
                {currentChapter.title}
              </h1>
              <p className="text-xs text-slate-500">
                Target: {readerEbook.targetExam} • {readerEbook.publisher}
              </p>
            </div>

            {/* Reading Content */}
            <article className={`space-y-4 ${fontSizeClasses[fontSize]}`}>
              <div className="p-4 rounded-xl border border-amber-300/50 bg-amber-500/10">
                <h3 className="font-bold text-amber-700 text-sm mb-1">
                  Key Concept Spotlight
                </h3>
                <p className="text-xs leading-relaxed">
                  {readerEbook.sampleContent.text}
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-base font-bold text-amber-600">
                  Comprehensive Examination Notes & Solutions
                </h3>
                <p>
                  To secure selection in {readerEbook.targetExam}, students should follow a structured daily revision routine. Memory recall techniques such as flashcards and formula sheets yield high dividends in quantitative aptitude and factual general knowledge.
                </p>
                <p>
                  Special emphasis should be laid on past 5 years question trends. In previous cycles, questions on local heritage, geography of the Brahmaputra valley, and constitutional amendments were directly tested across all shifts.
                </p>
              </div>

              {/* Formula Table */}
              <div className="overflow-x-auto my-4">
                <table className="w-full border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-200/50 dark:bg-slate-800">
                      <th className="border border-slate-300 dark:border-slate-700 p-2 text-left font-bold">Topic / Rule</th>
                      <th className="border border-slate-300 dark:border-slate-700 p-2 text-left font-bold">Standard Formula</th>
                      <th className="border border-slate-300 dark:border-slate-700 p-2 text-left font-bold">Exam Short-Trick</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-slate-300 dark:border-slate-700 p-2 font-medium">Speed, Time, Distance</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">Distance = Speed × Time</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">km/h to m/s: multiply by 5/18</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 dark:border-slate-700 p-2 font-medium">Work & Time</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">1/A + 1/B = 1/Total</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">Total Work = LCM of days</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 dark:border-slate-700 p-2 font-medium">Compound Interest</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">A = P(1 + r/100)^n</td>
                      <td className="border border-slate-300 dark:border-slate-700 p-2">2-year difference CI - SI = P(r/100)^2</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Interactive Practice Questions */}
              <div className="mt-6 pt-4 border-t border-slate-300/40 space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-amber-500" />
                  Self-Evaluation Practice Questions
                </h3>
                {readerEbook.sampleContent.sampleQuestions.map((q, idx) => {
                  const isRevealed = !!revealedAnswers[idx];
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl border ${contentBgClasses[theme]} border-slate-300/40 space-y-2`}
                    >
                      <p className="font-bold text-xs sm:text-sm">
                        Q{idx + 1}. {q.q}
                      </p>
                      {isRevealed ? (
                        <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-lg space-y-1 animate-in fade-in">
                          <p className="text-xs font-bold text-emerald-600">
                            ✓ Correct Answer: {q.a}
                          </p>
                          <p className="text-[11px] opacity-80">
                            {q.explanation}
                          </p>
                        </div>
                      ) : (
                        <button
                          onClick={() => toggleRevealAnswer(idx)}
                          className="text-xs font-bold text-amber-600 hover:text-amber-700 underline"
                        >
                          Reveal Answer & Solution Explanation
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </article>

            {/* Bottom Chapter Pagination Controls */}
            <div className="pt-6 pb-12 border-t border-slate-300/40 flex items-center justify-between">
              <button
                disabled={activeChapterIndex === 0}
                onClick={() => {
                  setActiveChapterIndex((prev) => Math.max(0, prev - 1));
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                  activeChapterIndex === 0
                    ? 'opacity-40 cursor-not-allowed bg-slate-200 text-slate-500'
                    : 'bg-slate-800 text-white hover:bg-slate-700'
                }`}
              >
                <ChevronLeft className="w-4 h-4" /> Previous Chapter
              </button>

              <span className="text-xs font-bold opacity-70">
                {activeChapterIndex + 1} / {totalChapters}
              </span>

              <button
                disabled={activeChapterIndex === totalChapters - 1}
                onClick={() => {
                  setActiveChapterIndex((prev) => Math.min(totalChapters - 1, prev + 1));
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                  activeChapterIndex === totalChapters - 1
                    ? 'opacity-40 cursor-not-allowed bg-slate-200 text-slate-500'
                    : 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                }`}
              >
                Next Chapter <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};
