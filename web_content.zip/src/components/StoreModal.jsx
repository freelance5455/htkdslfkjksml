import React, { useState } from 'react';
import { Bird, Check, Columns3, X } from 'lucide-react';
import { getAssetSrc } from '../utils/gameAssets';
import { sound } from '../utils/sound';
export const BIRD_SKINS = [
    {
        id: 'sky-blue',
        previewSrc: 'assets/flapora/FLAPORA_bird_blue.webp',
        gameSrc: 'assets/flapora/bird_sheet.webp',
        isSpriteSheet: true,
        trailColor: 'rgba(186, 230, 253, 0.92)',
        nameAr: 'العصفور السماوي',
        nameEn: 'Sky Bluebird',
        tagAr: 'الأساسي',
        tagEn: 'Classic',
        cardBgClass: 'from-sky-100 to-cyan-200',
    },
    {
        id: 'pink-dove',
        previewSrc: 'assets/flapora/FLAPORA_bird_pink.webp',
        gameSrc: 'assets/flapora/bird2_sheet.webp',
        isSpriteSheet: true,
        trailColor: 'rgba(244, 114, 182, 0.92)',
        nameAr: 'Farawla',
        nameEn: 'Farawla',
        tagAr: 'جديد',
        tagEn: 'New',
        cardBgClass: 'from-pink-100 to-rose-200',
    },
];
export const PIPE_SKINS = [
    {
        id: 'emerald-vine',
        src: 'assets/flapora/FLAPORA_pipe.webp',
        nameAr: 'العمود الزمردي',
        nameEn: 'Emerald Vine',
        tagAr: 'الأساسي',
        tagEn: 'Classic',
        cardBgClass: 'from-emerald-100 to-lime-200',
    },
    {
        id: 'royal-gold',
        src: 'assets/flapora/FLAPORA_pipe_gold.webp',
        nameAr: 'العمود الذهبي',
        nameEn: 'Royal Gold',
        tagAr: 'فاخر',
        tagEn: 'Luxury',
        cardBgClass: 'from-amber-100 to-yellow-200',
    },
    {
        id: 'frost-crystal',
        src: 'assets/flapora/FLAPORA_pipe_ice.webp',
        nameAr: 'العمود الجليدي',
        nameEn: 'Frost Crystal',
        tagAr: 'جليدي',
        tagEn: 'Frost',
        cardBgClass: 'from-sky-100 to-blue-200',
    },
    {
        id: 'obsidian-magma',
        src: 'assets/flapora/FLAPORA_pipe_lava.webp',
        nameAr: 'عمود الحمم',
        nameEn: 'Obsidian Magma',
        tagAr: 'بركاني',
        tagEn: 'Magma',
        cardBgClass: 'from-slate-200 to-orange-200',
    },
    {
        id: 'sakura-blossom',
        src: 'assets/flapora/FLAPORA_pipe_sakura.webp',
        nameAr: 'عمود الساكورا',
        nameEn: 'Sakura Blossom',
        tagAr: 'ربيعي',
        tagEn: 'Sakura',
        cardBgClass: 'from-pink-100 to-rose-200',
    },
    {
        id: 'amethyst-gem',
        src: 'assets/flapora/FLAPORA_pipe_amethyst.webp',
        nameAr: 'عمود الأميثيست',
        nameEn: 'Amethyst Gem',
        tagAr: 'كريستال',
        tagEn: 'Crystal',
        cardBgClass: 'from-purple-100 to-violet-200',
    },
    {
        id: 'candy-cane',
        src: 'assets/flapora/FLAPORA_pipe_candy.webp',
        nameAr: 'عمود الحلوى',
        nameEn: 'Candy Cane',
        tagAr: 'مرح',
        tagEn: 'Sweet',
        cardBgClass: 'from-red-100 to-amber-100',
    },
    {
        id: 'cyber-neon',
        src: 'assets/flapora/FLAPORA_pipe_neon.webp',
        nameAr: 'العمود النيون',
        nameEn: 'Cyber Neon',
        tagAr: 'مستقبلي',
        tagEn: 'Cyber',
        cardBgClass: 'from-slate-200 to-cyan-200',
    },
    {
        id: 'temple-marble',
        src: 'assets/flapora/FLAPORA_pipe_stone.webp',
        nameAr: 'العمود الرخامي',
        nameEn: 'Temple Marble',
        tagAr: 'أثري',
        tagEn: 'Ancient',
        cardBgClass: 'from-stone-100 to-teal-100',
    },
    {
        id: 'rainbow-prism',
        src: 'assets/flapora/FLAPORA_pipe_rainbow.webp',
        nameAr: 'عمود قوس قزح',
        nameEn: 'Rainbow Prism',
        tagAr: 'أسطوري',
        tagEn: 'Prism',
        cardBgClass: 'from-rose-100 via-amber-100 to-sky-200',
    },
];
export const StoreModal = ({ open, language, selectedBirdId, selectedPipeId, onSelectBird, onSelectPipe, onClose, }) => {
    const [activeTab, setActiveTab] = useState('birds');
    if (!open)
        return null;
    const isAr = language === 'ar';
    const equippedBird = BIRD_SKINS.find((b) => b.id === selectedBirdId) ?? BIRD_SKINS[0];
    const equippedPipe = PIPE_SKINS.find((p) => p.id === selectedPipeId) ?? PIPE_SKINS[0];
    return (<div className="absolute inset-0 z-30 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3.5" onClick={(e) => {
            if (e.target === e.currentTarget) {
                sound.playClick();
                onClose();
            }
        }}>
      <div dir={isAr ? 'rtl' : 'ltr'} role="dialog" aria-modal="true" aria-label={isAr ? 'المتجر' : 'Store'} className={`relative w-full max-w-[350px] pt-5 ${isAr ? 'font-arabic' : ''}`}>
        {/* Overlapping Top Ribbon Banner */}
        <div className="absolute top-0 inset-x-0 flex justify-center z-10 pointer-events-none">
          <div className="px-8 py-2 rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-600 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-display font-bold text-xl tracking-wide drop-shadow-[0_2px_0_rgba(69,26,3,0.9)]">
            {isAr ? 'المتجر' : 'Sky Store'}
          </div>
        </div>

        {/* Close Button */}
        <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} aria-label={isAr ? 'إغلاق' : 'Close'} className={`absolute top-2 ${isAr ? 'left-1' : 'right-1'} z-20 w-11 h-11 rounded-full bg-gradient-to-b from-rose-400 to-rose-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_3px_0_#451A03] text-white flex items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-300`}>
          <X className="w-5 h-5 stroke-[3]"/>
        </button>

        {/* Cartoon Wood & Cream Parchment Frame */}
        <div className="rounded-[28px] bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 border-[3px] border-amber-950 p-2 shadow-[0_10px_0_#451A03,0_24px_50px_rgba(0,0,0,0.55)]">
          <div className="rounded-[20px] bg-gradient-to-b from-amber-50 to-amber-100 border-2 border-amber-800/30 px-3 pt-7 pb-3.5 text-amber-950 flex flex-col gap-2.5 max-h-[84dvh]">
            {/* Current Equipped Loadout Strip */}
            <div className="rounded-2xl bg-white/85 border-2 border-amber-900/15 px-2.5 py-2 grid grid-cols-2 gap-2 shadow-xs">
              <div className="flex items-center justify-center gap-1.5 rounded-xl bg-sky-100/90 border border-sky-300 px-2.5 py-1 min-w-0">
                <img src={getAssetSrc(equippedBird.previewSrc)} alt={isAr ? equippedBird.nameAr : equippedBird.nameEn} referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-6 h-6 object-contain shrink-0"/>
                <span className="text-[11px] font-extrabold text-sky-950 truncate">
                  {isAr ? equippedBird.nameAr : equippedBird.nameEn}
                </span>
              </div>
              <div className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-100/90 border border-emerald-300 px-2.5 py-1 min-w-0">
                <img src={getAssetSrc(equippedPipe.src)} alt={isAr ? equippedPipe.nameAr : equippedPipe.nameEn} referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-4 h-6 object-contain shrink-0"/>
                <span className="text-[11px] font-extrabold text-emerald-950 truncate">
                  {isAr ? equippedPipe.nameAr : equippedPipe.nameEn}
                </span>
              </div>
            </div>

            {/* Category Tabs: Birds & Pillars */}
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-amber-900/10 border border-amber-900/15">
              <button type="button" onClick={() => {
            sound.playClick();
            setActiveTab('birds');
        }} className={`min-h-[42px] rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${activeTab === 'birds'
            ? 'bg-gradient-to-b from-sky-400 to-blue-600 text-white border-2 border-amber-950 shadow-[0_2px_0_#451A03]'
            : 'text-amber-900 hover:bg-white/60'}`}>
                <Bird className="w-4 h-4 shrink-0"/>
                <span>{isAr ? 'أشكال الطائر' : 'Bird Skins'}</span>
              </button>

              <button type="button" onClick={() => {
            sound.playClick();
            setActiveTab('pipes');
        }} className={`min-h-[42px] rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${activeTab === 'pipes'
            ? 'bg-gradient-to-b from-emerald-400 to-emerald-600 text-white border-2 border-amber-950 shadow-[0_2px_0_#451A03]'
            : 'text-amber-900 hover:bg-white/60'}`}>
                <Columns3 className="w-4 h-4 shrink-0"/>
                <span>{isAr ? 'أشكال الأعمدة' : 'Pillar Skins'}</span>
              </button>
            </div>

            {/* Organized 2-Column Skin Catalog Grid */}
            <div className="max-h-[45dvh] overflow-y-auto px-0.5 py-0.5">
              {activeTab === 'birds' ? (<div className="grid grid-cols-2 gap-2.5">
                  {BIRD_SKINS.map((bird) => {
                const isSelected = bird.id === selectedBirdId;
                const name = isAr ? bird.nameAr : bird.nameEn;
                const tag = isAr ? bird.tagAr : bird.tagEn;
                return (<button key={bird.id} type="button" aria-pressed={isSelected} onClick={() => {
                        sound.playClick();
                        onSelectBird(bird.id);
                    }} className={`group relative rounded-2xl p-2.5 text-center flex flex-col items-center gap-1.5 cursor-pointer transition-all duration-150 focus-visible:outline-2 focus-visible:outline-yellow-300 ${isSelected
                        ? 'bg-white ring-[3px] ring-emerald-400 border-2 border-amber-950 shadow-[0_5px_0_#065F46]'
                        : 'bg-white/85 border-2 border-amber-900/20 hover:bg-white hover:border-amber-700 hover:scale-[1.02] active:scale-[0.98] shadow-xs'}`}>
                        {/* Top Corner Tag / Selected Badge */}
                        <div className="w-full flex items-center justify-between gap-1">
                          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-900/15">
                            {tag}
                          </span>
                          {isSelected && (<span className="w-6 h-6 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 border-2 border-amber-950 text-white flex items-center justify-center shadow-xs">
                              <Check className="w-3.5 h-3.5 stroke-[3]"/>
                            </span>)}
                        </div>

                        {/* Bird Preview Frame */}
                        <div className={`w-full aspect-[4/3] rounded-xl bg-gradient-to-b ${bird.cardBgClass} border border-amber-900/15 flex items-center justify-center p-2 overflow-hidden`}>
                          <img src={getAssetSrc(bird.previewSrc)} alt={name} referrerPolicy="no-referrer" loading="eager" decoding="sync" fetchPriority="high" className="w-16 h-16 object-contain drop-shadow-[0_4px_5px_rgba(15,23,42,0.25)] transition-transform duration-200 group-hover:scale-110 select-none"/>
                        </div>

                        <div className="text-xs font-extrabold text-amber-950 truncate w-full">
                          {name}
                        </div>

                        <div className={`w-full py-1 rounded-xl text-[11px] font-extrabold ${isSelected
                        ? 'bg-emerald-500 text-white border border-emerald-900/40'
                        : 'bg-amber-200/75 text-amber-950 group-hover:bg-amber-300'}`}>
                          {isSelected
                        ? isAr
                            ? 'مفعّل الآن'
                            : 'Equipped'
                        : isAr
                            ? 'اختيار'
                            : 'Equip'}
                        </div>
                      </button>);
            })}
                </div>) : (<div className="grid grid-cols-2 gap-2.5">
                  {PIPE_SKINS.map((pipe) => {
                const isSelected = pipe.id === selectedPipeId;
                const name = isAr ? pipe.nameAr : pipe.nameEn;
                const tag = isAr ? pipe.tagAr : pipe.tagEn;
                return (<button key={pipe.id} type="button" aria-pressed={isSelected} onClick={() => {
                        sound.playClick();
                        onSelectPipe(pipe.id);
                    }} className={`group relative rounded-2xl p-2.5 text-center flex flex-col items-center gap-1.5 cursor-pointer transition-all duration-150 focus-visible:outline-2 focus-visible:outline-yellow-300 ${isSelected
                        ? 'bg-white ring-[3px] ring-emerald-400 border-2 border-amber-950 shadow-[0_5px_0_#065F46]'
                        : 'bg-white/85 border-2 border-amber-900/20 hover:bg-white hover:border-amber-700 hover:scale-[1.02] active:scale-[0.98] shadow-xs'}`}>
                        <div className="w-full flex items-center justify-between gap-1">
                          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-900/15">
                            {tag}
                          </span>
                          {isSelected && (<span className="w-6 h-6 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 border-2 border-amber-950 text-white flex items-center justify-center shadow-xs">
                              <Check className="w-3.5 h-3.5 stroke-[3]"/>
                            </span>)}
                        </div>

                        {/* Pillar Preview Frame */}
                        <div className={`w-full aspect-[4/3] rounded-xl bg-gradient-to-b ${pipe.cardBgClass} border border-amber-900/15 flex items-center justify-center p-1.5 overflow-hidden`}>
                          <img src={getAssetSrc(pipe.src)} alt={name} referrerPolicy="no-referrer" loading="eager" decoding="sync" className="h-20 w-auto object-contain drop-shadow-[0_4px_5px_rgba(15,23,42,0.3)] transition-transform duration-200 group-hover:scale-110 select-none"/>
                        </div>

                        <div className="text-xs font-extrabold text-amber-950 truncate w-full">
                          {name}
                        </div>

                        <div className={`w-full py-1 rounded-xl text-[11px] font-extrabold ${isSelected
                        ? 'bg-emerald-500 text-white border border-emerald-900/40'
                        : 'bg-amber-200/75 text-amber-950 group-hover:bg-amber-300'}`}>
                          {isSelected
                        ? isAr
                            ? 'مفعّل الآن'
                            : 'Equipped'
                        : isAr
                            ? 'اختيار'
                            : 'Equip'}
                        </div>
                      </button>);
            })}
                </div>)}
            </div>

            {/* Done Button */}
            <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} className="w-full min-h-[44px] rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-extrabold text-base tracking-wide cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_2px_0_#451A03]">
              {isAr ? 'تم' : 'Done'}
            </button>
          </div>
        </div>
      </div>
    </div>);
};
