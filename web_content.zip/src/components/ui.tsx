import {
  useEffect,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from "react";
import { Search, X, type LucideIcon } from "lucide-react";
import { cn } from "../utils/cn";
import { useApp } from "../lib/store";
import { colorFromName, initials } from "../lib/types";

/* ---------------- Button ---------------- */

type BtnVariant = "primary" | "gold" | "secondary" | "ghost" | "danger" | "outline";
interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: BtnVariant;
  size?: "sm" | "md" | "lg";
  icon?: LucideIcon;
  block?: boolean;
}

export function Btn({
  variant = "primary",
  size = "md",
  icon: Icon,
  block,
  className,
  children,
  ...rest
}: BtnProps) {
  const variants: Record<BtnVariant, string> = {
    primary:
      "bg-brand-700 text-white shadow-sm hover:bg-brand-800 active:bg-brand-900 dark:bg-brand-600 dark:hover:bg-brand-500",
    gold: "bg-gold-500 text-brand-950 shadow-sm hover:bg-gold-400 active:bg-gold-600 font-bold",
    secondary:
      "bg-brand-50 text-brand-800 hover:bg-brand-100 active:bg-brand-200 dark:bg-white/10 dark:text-brand-100 dark:hover:bg-white/15",
    ghost:
      "text-slate-600 hover:bg-slate-100 active:bg-slate-200 dark:text-slate-300 dark:hover:bg-white/10",
    danger: "bg-rose-600 text-white shadow-sm hover:bg-rose-700 active:bg-rose-800",
    outline:
      "border border-slate-200 text-slate-700 hover:bg-slate-50 active:bg-slate-100 dark:border-white/15 dark:text-slate-200 dark:hover:bg-white/5",
  };
  const sizes = {
    sm: "h-9 px-3 text-[13px] rounded-lg gap-1.5",
    md: "h-11 px-4 text-sm rounded-xl gap-2",
    lg: "h-13 px-6 text-[15px] rounded-xl gap-2.5",
  };
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center font-semibold transition-all duration-150 active:scale-[0.97] disabled:opacity-45 disabled:pointer-events-none select-none cursor-pointer",
        variants[variant],
        sizes[size],
        block && "w-full",
        className
      )}
      {...rest}
    >
      {Icon && <Icon className={cn(size === "sm" ? "size-4" : "size-[18px]")} strokeWidth={2.2} />}
      {children}
    </button>
  );
}

export function IconBtn({
  icon: Icon,
  label,
  className,
  ...rest
}: { icon: LucideIcon; label: string } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      aria-label={label}
      title={label}
      className={cn(
        "inline-flex size-10 shrink-0 items-center justify-center rounded-xl text-slate-500 transition-all hover:bg-slate-100 active:scale-95 dark:text-slate-400 dark:hover:bg-white/10 cursor-pointer",
        className
      )}
      {...rest}
    >
      <Icon className="size-5" strokeWidth={2} />
    </button>
  );
}

/* ---------------- Card ---------------- */

export function Card({
  className,
  children,
  onClick,
}: {
  className?: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-2xl border border-slate-200/80 bg-white shadow-card dark:border-white/8 dark:bg-[#101c33]",
        onClick && "cursor-pointer transition-transform active:scale-[0.99] hover:border-brand-300 dark:hover:border-brand-700",
        className
      )}
    >
      {children}
    </div>
  );
}

/* ---------------- Sheet (bottom sheet on mobile / dialog on desktop) ---------------- */

export function Sheet({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-brand-950/60 backdrop-blur-[3px] animate-fade-in" onClick={onClose} />
      <div
        className={cn(
          "relative flex max-h-[92dvh] w-full flex-col overflow-hidden bg-white shadow-pop dark:bg-[#0e1a30] dark:border dark:border-white/10",
          "rounded-t-3xl sm:rounded-3xl animate-sheet-up sm:animate-pop-in",
          wide ? "sm:max-w-2xl" : "sm:max-w-md"
        )}
        role="dialog"
        aria-modal="true"
      >
        <div className="mx-auto mt-2.5 h-1 w-10 shrink-0 rounded-full bg-slate-200 dark:bg-white/15 sm:hidden" />
        {title && (
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-4 dark:border-white/8">
            <h3 className="text-[15px] font-bold text-slate-900 dark:text-white">{title}</h3>
            <IconBtn icon={X} label="Close" onClick={onClose} className="-me-2 size-9" />
          </div>
        )}
        <div className="overflow-y-auto px-5 pb-8 pt-4 no-scrollbar">{children}</div>
      </div>
    </div>
  );
}

/* ---------------- Forms ---------------- */

export function Field({
  label,
  error,
  children,
  hint,
}: {
  label: ReactNode;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-semibold text-slate-600 dark:text-slate-300">
        {label}
      </span>
      {children}
      {error ? (
        <span className="mt-1 block text-xs font-semibold text-rose-600 animate-pop-in">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-xs text-slate-400">{hint}</span>
      ) : null}
    </label>
  );
}

export function TextInput({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-900 outline-none transition-all placeholder:text-slate-400 placeholder:font-normal",
        "focus:border-brand-500 focus:ring-4 focus:ring-brand-500/15",
        "dark:border-white/12 dark:bg-white/5 dark:text-white dark:focus:border-brand-400",
        className
      )}
      {...rest}
    />
  );
}

export function Select({ className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        "h-11 w-full appearance-none rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-900 outline-none transition-all cursor-pointer",
        "focus:border-brand-500 focus:ring-4 focus:ring-brand-500/15",
        "dark:border-white/12 dark:bg-[#0e1a30] dark:text-white",
        className
      )}
      {...rest}
    >
      {children}
    </select>
  );
}

export function SearchInput({
  className,
  ...rest
}: InputHTMLAttributes<HTMLInputElement>) {
  const { rtl } = useApp();
  return (
    <div className={cn("relative", className)}>
      <Search
        className={cn(
          "pointer-events-none absolute top-1/2 size-[18px] -translate-y-1/2 text-slate-400",
          rtl ? "right-3.5" : "left-3.5"
        )}
      />
      <input
        className={cn(
          "h-11 w-full rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-900 outline-none transition-all placeholder:text-slate-400 placeholder:font-normal",
          rtl ? "pr-10 pl-3.5" : "pl-10 pr-3.5",
          "focus:border-brand-500 focus:ring-4 focus:ring-brand-500/15",
          "dark:border-white/12 dark:bg-white/5 dark:text-white dark:focus:border-brand-400"
        )}
        {...rest}
      />
    </div>
  );
}

/* ---------------- Badges, chips, avatar ---------------- */

type BadgeTone = "green" | "red" | "slate" | "gold" | "blue";
export function Badge({ tone = "slate", children, className }: { tone?: BadgeTone; children: ReactNode; className?: string }) {
  const tones: Record<BadgeTone, string> = {
    green: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
    red: "bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300",
    slate: "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300",
    gold: "bg-gold-100 text-gold-700 dark:bg-gold-500/15 dark:text-gold-300",
    blue: "bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold whitespace-nowrap", tones[tone], className)}>
      {children}
    </span>
  );
}

export function Avatar({ name, size = "md", className }: { name: string; size?: "sm" | "md" | "lg"; className?: string }) {
  const sizes = { sm: "size-9 text-xs", md: "size-11 text-sm", lg: "size-16 text-xl" };
  return (
    <div
      className={cn("flex shrink-0 items-center justify-center rounded-full font-extrabold text-white", sizes[size], className)}
      style={{ backgroundColor: colorFromName(name) }}
    >
      {initials(name)}
    </div>
  );
}

export function Chip({
  active,
  onClick,
  children,
  className,
}: {
  active?: boolean;
  onClick?: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[13px] font-semibold transition-all active:scale-95 cursor-pointer whitespace-nowrap",
        active
          ? "border-brand-700 bg-brand-700 text-white dark:border-brand-500 dark:bg-brand-600"
          : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 dark:border-white/12 dark:bg-white/5 dark:text-slate-300",
        className
      )}
    >
      {children}
    </button>
  );
}

/* ---------------- Progress ring ---------------- */

export function ProgressRing({
  value,
  size = 56,
  stroke = 5,
  className,
}: {
  value: number;
  size?: number;
  stroke?: number;
  className?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value));
  const tone = v >= 85 ? "#10B981" : v >= 75 ? "#D9A62E" : v >= 60 ? "#F59E0B" : "#F43F5E";
  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} stroke="currentColor" className="text-slate-200 dark:text-white/10" />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={tone} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (c * v) / 100}
          style={{ transition: "stroke-dashoffset .8s cubic-bezier(.32,.72,0,1)" }}
        />
      </svg>
      <span className="absolute text-[13px] font-extrabold tnum text-slate-800 dark:text-white" style={{ fontSize: size / 4.2 }}>
        {v}%
      </span>
    </div>
  );
}

/* ---------------- Stat card ---------------- */

export function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  tone = "blue",
}: {
  icon: LucideIcon;
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: "blue" | "green" | "red" | "gold";
}) {
  const tones = {
    blue: "bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300",
    green: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300",
    red: "bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300",
    gold: "bg-gold-100 text-gold-700 dark:bg-gold-500/15 dark:text-gold-400",
  };
  return (
    <Card className="p-4">
      <div className="flex items-center gap-3">
        <div className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", tones[tone])}>
          <Icon className="size-[22px]" strokeWidth={2} />
        </div>
        <div className="min-w-0">
          <div className="truncate text-[12px] font-semibold text-slate-500 dark:text-slate-400">{label}</div>
          <div className="truncate text-[22px] font-extrabold leading-7 tnum text-slate-900 dark:text-white">{value}</div>
        </div>
      </div>
      {sub && <div className="mt-2 text-[11px] font-semibold text-slate-400 dark:text-slate-500">{sub}</div>}
    </Card>
  );
}

/* ---------------- Empty state ---------------- */

export function EmptyState({
  icon: Icon,
  title,
  msg,
  action,
}: {
  icon: LucideIcon;
  title: string;
  msg: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center animate-pop-in">
      <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/8 dark:text-slate-500">
        <Icon className="size-8" strokeWidth={1.6} />
      </div>
      <h3 className="text-[15px] font-bold text-slate-800 dark:text-slate-100">{title}</h3>
      <p className="mt-1 max-w-70 text-[13px] leading-6 text-slate-500 dark:text-slate-400">{msg}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/* ---------------- Section heading ---------------- */

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-3 mt-7 flex items-center justify-between gap-3 first:mt-0">
      <h2 className="text-[15px] font-extrabold text-slate-900 dark:text-white">{children}</h2>
      {action}
    </div>
  );
}

/* ---------------- Segmented control ---------------- */

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { value: T; label: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("inline-flex w-full items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-white/8", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "flex h-9 flex-1 items-center justify-center gap-1.5 rounded-[10px] text-[13px] font-bold transition-all cursor-pointer",
            value === o.value
              ? "bg-white text-brand-800 shadow-sm dark:bg-white/15 dark:text-white"
              : "text-slate-500 hover:text-slate-700 dark:text-slate-400"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ---------------- Progress bar ---------------- */

export function Bar({ value, tone, className }: { value: number; tone?: string; className?: string }) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10", className)}>
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${v}%`, backgroundColor: tone ?? (v >= 75 ? "#10B981" : v >= 50 ? "#D9A62E" : "#F43F5E") }}
      />
    </div>
  );
}
