import {
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
} from "react";
import { createPortal } from "react-dom";
import { cn } from "../utils/cn";

import {
  Menu,
  Plus,
  ArrowUp,
  Square,
  Settings2,
  Folder,
  FolderPlus,
  FolderOpen,
  File,
  FilePlus2,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  X,
  Trash2,
  Pencil,
  Move,
  Type,
  Eye,
  EyeOff,
  Search,
  Terminal,
  MessageSquare,
  Code2,
  Copy,
  Check,
  Sun,
  Moon,
  Monitor,
  KeyRound,
  ShieldCheck,
  HardDrive,
  History,
  MoreHorizontal,
  Bot,
  Save,
  RotateCcw,
  TriangleAlert,
  SlidersHorizontal,
  Link,
  Download,
  GitBranch,
  LockKeyhole,
  Globe,
  ArrowUpRight,
  Paperclip,
  Mic,
  Pin,
  PanelLeftClose,
  PanelRight,
  FileDiff,
  CircleHelp,
  ArrowRight,
  Zap,
  LoaderCircle,
  Upload,
  Circle,
  Keyboard,
  CheckCheck,
  ExternalLink,
  Layers,
  CircleDot,
  Undo2,
  Play,
  Smartphone,
  LayoutDashboard,
  Sparkles,
  Maximize2,
  Rocket,
  BookOpen,
  PanelLeft,
  CircleCheck,
} from "lucide-react";

const icons: Record<string, typeof Menu> = {
  menu: Menu,
  plus: Plus,
  send: ArrowUp,
  stop: Square,
  settings: Settings2,
  folder: Folder,
  folderPlus: FolderPlus,
  folderOpen: FolderOpen,
  file: File,
  filePlus: FilePlus2,
  chevronRight: ChevronRight,
  chevronLeft: ChevronLeft,
  chevronDown: ChevronDown,
  close: X,
  trash: Trash2,
  pencil: Pencil,
  move: Move,
  text: Type,
  eye: Eye,
  eyeOff: EyeOff,
  search: Search,
  terminal: Terminal,
  chat: MessageSquare,
  code: Code2,
  copy: Copy,
  check: Check,
  sun: Sun,
  moon: Moon,
  monitor: Monitor,
  key: KeyRound,
  shield: ShieldCheck,
  storage: HardDrive,
  history: History,
  dots: MoreHorizontal,
  bot: Bot,
  save: Save,
  refresh: RotateCcw,
  alert: TriangleAlert,
  sliders: SlidersHorizontal,
  link: Link,
  download: Download,
  branch: GitBranch,
  lock: LockKeyhole,
  globe: Globe,
  arrowUpRight: ArrowUpRight,
  attach: Paperclip,
  mic: Mic,
  pin: Pin,
  panelLeft: PanelLeftClose,
  panelRight: PanelRight,
  changes: FileDiff,
  help: CircleHelp,
  arrowRight: ArrowRight,
  zap: Zap,
  loading: LoaderCircle,
  upload: Upload,
  circle: Circle,
  keyboard: Keyboard,
  doubleCheck: CheckCheck,
  external: ExternalLink,
  layers: Layers,
  circleDot: CircleDot,
  undo: Undo2,
  play: Play,
  phone: Smartphone,
  dashboard: LayoutDashboard,
  sparkles: Sparkles,
  expand: Maximize2,
  rocket: Rocket,
  book: BookOpen,
  sidebar: PanelLeft,
  success: CircleCheck,
};

export function Icon({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  const Component = icons[name] ?? Circle;
  return (
    <Component
      aria-hidden="true"
      strokeWidth={1.65}
      className={cn("h-5 w-5 shrink-0", className)}
    />
  );
}

export function BrandMark({ className }: { className?: string }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={cn("h-9 w-9 shrink-0", className)}
    >
      <defs>
        <linearGradient
          id={`mark-${id}`}
          x1="7"
          y1="0"
          x2="42"
          y2="50"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#e98cbb" />
          <stop offset=".48" stopColor="#b671da" />
          <stop offset="1" stopColor="#8f68d9" />
        </linearGradient>
        <linearGradient
          id={`edge-${id}`}
          x1="10"
          x2="40"
          y2="48"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="white" stopOpacity=".8" />
          <stop offset="1" stopColor="white" stopOpacity=".08" />
        </linearGradient>
      </defs>
      <rect
        x="3"
        y="5"
        width="42"
        height="40"
        rx="13"
        fill="#885cbb"
        opacity=".18"
      />
      <rect
        x="3"
        y="2"
        width="42"
        height="41"
        rx="13"
        fill={`url(#mark-${id})`}
      />
      <rect
        x="3.7"
        y="2.7"
        width="40.6"
        height="39.6"
        rx="12.3"
        stroke={`url(#edge-${id})`}
        strokeWidth="1.4"
      />
      <path
        d="m17 16-6 7 6 7m14-14 6 7-6 7m-5-17-4 20"
        stroke="#74479d"
        strokeOpacity=".3"
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        transform="translate(0 1.5)"
      />
      <path
        d="m17 16-6 7 6 7m14-14 6 7-6 7m-5-17-4 20"
        stroke="white"
        strokeWidth="2.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* ------------------------------ buttons ------------------------------ */

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger" | "outline";
  size?: "sm" | "md" | "lg";
  block?: boolean;
  icon?: string;
};

export function Button({
  variant = "secondary",
  size = "md",
  block,
  icon,
  className,
  children,
  ...rest
}: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "tap inline-flex items-center justify-center gap-2 rounded-xl font-medium disabled:opacity-40",
        size === "sm" && "h-8 px-3 text-[13px]",
        size === "md" && "h-10 px-4 text-sm",
        size === "lg" && "h-12 px-5 text-[15px]",
        variant === "primary" &&
          "primary-button bg-accent text-accentfg hover:bg-accent2 active:bg-accent2",
        variant === "secondary" &&
          "tactile-control bg-surface text-fg border border-line hover:bg-surface2 active:bg-surface3",
        variant === "outline" &&
          "border border-line2 text-fg hover:bg-surface2 active:bg-surface2",
        variant === "ghost" && "text-fg hover:bg-surface2 active:bg-surface2",
        variant === "danger" &&
          "bg-dangersoft text-danger border border-danger/25",
        block && "w-full",
        className,
      )}
    >
      {icon ? (
        <Icon
          name={icon}
          className={size === "sm" ? "h-4 w-4" : "h-[18px] w-[18px]"}
        />
      ) : null}
      {children}
    </button>
  );
}

export function IconButton({
  name,
  label,
  className,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { name: string; label?: string }) {
  return (
    <button
      {...rest}
      aria-label={label ?? name}
      className={cn(
        "tap grid h-10 w-10 place-items-center rounded-xl text-muted hover:text-fg hover:bg-surface2 active:bg-surface2 disabled:opacity-35",
        className,
      )}
    >
      <Icon name={name} />
    </button>
  );
}

/* ------------------------------ switch ------------------------------- */

export function Switch({
  checked,
  onChange,
  disabled,
  label = "Toggle setting",
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-label={label}
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-[22px] w-[38px] shrink-0 rounded-full border transition-colors duration-150 disabled:opacity-40",
        checked ? "border-accent bg-accent" : "border-line2 bg-surface3",
      )}
    >
      <span
        className={cn(
          "absolute top-1/2 block h-4 w-4 -translate-y-1/2 rounded-full transition-all duration-150",
          checked ? "left-[19px] bg-white" : "left-[3px] bg-muted",
        )}
      />
    </button>
  );
}

/* ------------------------------ inputs ------------------------------- */

export function Field({
  label,
  hint,
  className,
  trailing,
  ...rest
}: InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  hint?: string;
  trailing?: ReactNode;
}) {
  const generatedId = useId();
  const id = rest.id ?? generatedId;
  return (
    <div className="block">
      <label
        htmlFor={id}
        className="mb-1.5 block text-[12px] font-medium uppercase tracking-wide text-muted"
      >
        {label}
      </label>
      <div className="relative flex items-center">
        <input
          {...rest}
          id={id}
          aria-describedby={hint ? `${id}-hint` : undefined}
          className={cn(
            "h-11 w-full rounded-xl border border-line bg-surface2 px-3 text-[15px] outline-none placeholder:text-muted/60 focus:border-accent",
            trailing && "pr-12",
            className,
          )}
        />
        {trailing ? (
          <span className="absolute right-1.5">{trailing}</span>
        ) : null}
      </div>
      {hint ? (
        <span
          id={`${id}-hint`}
          className="mt-1 block text-[12px] leading-snug text-muted"
        >
          {hint}
        </span>
      ) : null}
    </div>
  );
}

export function TextArea({
  label,
  className,
  ...rest
}: TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string }) {
  return (
    <label className="block">
      {label ? (
        <span className="mb-1.5 block text-[12px] font-medium uppercase tracking-wide text-muted">
          {label}
        </span>
      ) : null}
      <textarea
        {...rest}
        className={cn(
          "w-full resize-none rounded-xl border border-line bg-surface2 p-3 font-mono text-[13px] leading-relaxed outline-none focus:border-accent",
          className,
        )}
      />
    </label>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string; icon?: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-xl border border-line bg-surface2 p-1">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "tap flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg text-[13px] font-medium",
            value === o.value ? "bg-accent text-accentfg" : "text-muted",
          )}
        >
          {o.icon ? <Icon name={o.icon} className="h-4 w-4" /> : null}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Row({
  title,
  sub,
  icon,
  right,
  onClick,
  danger,
  className,
}: {
  title: ReactNode;
  sub?: ReactNode;
  icon?: string;
  right?: ReactNode;
  onClick?: () => void;
  danger?: boolean;
  className?: string;
}) {
  const Comp = onClick ? "button" : "div";
  return (
    <Comp
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-surface2 active:bg-surface2",
        className,
      )}
    >
      {icon ? (
        <span
          className={cn(
            "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-surface2",
            danger && "text-danger",
          )}
        >
          <Icon name={icon} className="h-[18px] w-[18px]" />
        </span>
      ) : null}
      <span className="min-w-0 flex-1">
        <span
          className={cn(
            "block truncate text-[15px] leading-tight",
            danger && "text-danger",
          )}
        >
          {title}
        </span>
        {sub ? (
          <span className="mt-0.5 block truncate text-[12.5px] leading-snug text-muted">
            {sub}
          </span>
        ) : null}
      </span>
      {right}
    </Comp>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="px-4 pb-1.5 pt-5 text-[11.5px] font-semibold uppercase tracking-[0.08em] text-muted">
      {children}
    </div>
  );
}

export function Card({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border border-line bg-surface",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Divider() {
  return <div className="ml-4 h-px bg-line" />;
}

/* ---------------------------- bottom sheet --------------------------- */

const modalStack: symbol[] = [];
function useModalFocus(open: boolean, close: () => void) {
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(close);
  closeRef.current = close;
  useEffect(() => {
    if (!open) return;
    const token = Symbol("modal");
    modalStack.push(token);
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const previous = document.activeElement as HTMLElement | null;
    const frame = requestAnimationFrame(() => {
      if (panel.current && !panel.current.contains(document.activeElement)) {
        (
          panel.current.querySelector<HTMLElement>(
            "input, textarea, select, button",
          ) ?? panel.current
        ).focus();
      }
    });
    const keydown = (event: KeyboardEvent) => {
      if (modalStack[modalStack.length - 1] !== token) return;
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        closeRef.current();
      }
      if (event.key === "Tab" && panel.current) {
        const elements = [
          ...panel.current.querySelectorAll<HTMLElement>(
            'button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex="0"]',
          ),
        ].filter((el) => el.offsetParent !== null);
        const first = elements[0],
          last = elements[elements.length - 1];
        if (!first) {
          event.preventDefault();
          panel.current.focus();
        } else if (
          event.shiftKey &&
          (document.activeElement === first ||
            !panel.current.contains(document.activeElement))
        ) {
          event.preventDefault();
          last.focus();
        } else if (
          !event.shiftKey &&
          (document.activeElement === last ||
            !panel.current.contains(document.activeElement))
        ) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", keydown, true);
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener("keydown", keydown, true);
      const index = modalStack.indexOf(token);
      if (index >= 0) modalStack.splice(index, 1);
      if (!modalStack.length) root?.removeAttribute("inert");
      if (previous?.isConnected) previous.focus();
    };
  }, [open]);
  return panel;
}

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  maxWidth = "sm:max-w-[520px]",
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  subtitle?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  maxWidth?: string;
}) {
  const panel = useModalFocus(open, onClose);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-40 flex flex-col justify-end sm:items-center sm:justify-center sm:p-6">
      <button
        aria-label="Dismiss"
        onClick={onClose}
        className="anim-fade absolute inset-0 bg-black/55"
      />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === "string" ? title : "Choose an option"}
        tabIndex={-1}
        className={cn(
          "anim-sheet relative flex max-h-[88dvh] w-full flex-col rounded-t-[24px] border border-line bg-bg sm:rounded-[20px]",
          maxWidth,
        )}
      >
        <div className="flex items-start gap-3 px-4 pb-2 pt-3">
          <div className="mx-auto absolute left-1/2 top-2 h-1 w-9 -translate-x-1/2 rounded-full bg-line2" />
          <div className="min-w-0 flex-1 pt-2">
            {title ? (
              <div className="truncate text-[16px] font-semibold">{title}</div>
            ) : null}
            {subtitle ? (
              <div className="mt-0.5 truncate text-[12.5px] text-muted">
                {subtitle}
              </div>
            ) : null}
          </div>
          <IconButton
            name="close"
            label="Close"
            onClick={onClose}
            className="-mr-2"
          />
        </div>
        <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto pb-2">
          {children}
        </div>
        {footer ? (
          <div className="border-t border-line bg-surface p-3 pb-[max(12px,env(safe-area-inset-bottom))]">
            {footer}
          </div>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}

export function Dialog({
  open,
  title,
  body,
  confirmLabel = "Allow",
  cancelLabel = "Don't allow",
  onConfirm,
  onCancel,
  danger,
  icon,
}: {
  open: boolean;
  title: string;
  body: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  danger?: boolean;
  icon?: string;
}) {
  const panel = useModalFocus(open, onCancel);
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 grid place-items-center p-6">
      <button
        aria-label="Dismiss"
        onClick={onCancel}
        className="anim-fade absolute inset-0 bg-black/60"
      />
      <div
        ref={panel}
        role="alertdialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        className="anim-fade relative w-full max-w-[380px] rounded-2xl border border-line bg-surface p-5"
      >
        {icon ? (
          <div className="mb-3 grid h-11 w-11 place-items-center rounded-full bg-accentsoft text-accent">
            <Icon name={icon} />
          </div>
        ) : null}
        <h3 className="text-[17px] font-semibold leading-snug">{title}</h3>
        <div className="mt-2 text-[13.5px] leading-relaxed text-muted">
          {body}
        </div>
        <div className="mt-5 flex gap-2">
          <Button variant="ghost" block onClick={onCancel}>
            {cancelLabel}
          </Button>
          <Button
            variant={danger ? "danger" : "primary"}
            block
            onClick={onConfirm}
          >
            {confirmLabel}
          </Button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

/* ------------------------------ long press --------------------------- */

export function useLongPress(onLong: () => void, ms = 420) {
  const timer = useRef<number | null>(null);
  const [fired, setFired] = useState(false);

  const clear = () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = null;
  };

  return {
    fired,
    handlers: {
      onPointerDown: () => {
        setFired(false);
        clear();
        timer.current = window.setTimeout(() => {
          setFired(true);
          onLong();
        }, ms);
      },
      onPointerUp: () => clear(),
      onPointerLeave: () => clear(),
      onPointerCancel: () => clear(),
      onContextMenu: (e: React.MouseEvent) => {
        e.preventDefault();
        clear();
      },
    },
  };
}

export function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <span key={i} className="thinking-dot" />
      ))}
    </span>
  );
}
