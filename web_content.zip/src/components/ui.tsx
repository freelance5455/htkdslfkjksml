"use client";
import type { ReactNode, ButtonHTMLAttributes } from "react";

const paths: Record<string, string> = {
  back: "M15 19l-7-7 7-7",
  forward: "M9 5l7 7-7 7",
  reload: "M4 4v5h5M20 20v-5h-5M4.6 15A8 8 0 0019.4 9M19.4 15A8 8 0 004.6 9",
  close: "M6 6l12 12M18 6L6 18",
  home: "M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z",
  star: "M12 3l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 18l-5.9 3 1.2-6.5L2.5 9.9 9.1 9z",
  plus: "M12 5v14M5 12h14",
  menu: "M4 6h16M4 12h16M4 18h16",
  sparkles: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9zM5 15l.7 1.6L7.3 17.3l-1.6.7L5 19.6l-.7-1.6-1.6-.7 1.6-.7z",
  history: "M3 12a9 9 0 109-9 9 9 0 00-7 3.3M3 4v5h5M12 7v5l3 2",
  download: "M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2",
  settings: "M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z",
  lock: "M6 11V8a6 6 0 0112 0v3M5 11h14v10H5z",
  unlock: "M6 11V8a6 6 0 0111.3-2.8M5 11h14v10H5z",
  shield: "M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z",
  mic: "M12 15a3 3 0 003-3V6a3 3 0 00-6 0v6a3 3 0 003 3zM19 11a7 7 0 01-14 0M12 18v3",
  send: "M22 2L11 13M22 2l-7 20-4-9-9-4z",
  speaker: "M11 5L6 9H2v6h4l5 4zM15.5 8.5a5 5 0 010 7M19 5a9 9 0 010 14",
  trash: "M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6",
  search: "M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3",
  incognito: "M3 12h18M6 12l1.5-6h9L18 12M8 19a3 3 0 100-6 3 3 0 000 6zM16 19a3 3 0 100-6 3 3 0 000 6zM11 16h2",
  tabs: "M4 7h16v12H4zM8 4h12v12",
  globe: "M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18",
  sun: "M12 17a5 5 0 100-10 5 5 0 000 10zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
  moon: "M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z",
  copy: "M8 8h12v12H8zM4 16V4h12",
  external: "M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3",
  chevron: "M6 9l6 6 6-6",
  check: "M5 13l4 4L19 7",
  stop: "M6 6h12v12H6z",
  translate: "M3 5h12M9 3v2M5 8c2 4 5 7 9 9M13 8c-1 4-4 7-8 9M14 21l5-11 5 11M16 17h6",
  code: "M16 18l6-6-6-6M8 6l-6 6 6 6",
  doc: "M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9zM14 3v6h6M8 13h8M8 17h8",
  user: "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z",
  puzzle: "M10 3a2 2 0 014 0v2h4v4h2a2 2 0 010 4h-2v4h-4v2a2 2 0 01-4 0v-2H6v-4H4a2 2 0 010-4h2V5h4z",
  find: "M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3M8 11h6",
  up: "M12 19V5M5 12l7-7 7 7",
  pin: "M12 17v5M8 3h8l-1 7 3 3H6l3-3z",
};

export function Icon({ name, size = 18, className = "" }: { name: keyof typeof paths | string; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      <path d={paths[name] || ""} />
    </svg>
  );
}

export function IconButton({
  icon,
  label,
  active,
  className = "",
  size = 18,
  ...rest
}: { icon: string; label: string; active?: boolean; size?: number } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition
        hover:bg-black/5 active:scale-95 disabled:opacity-30 disabled:hover:bg-transparent dark:hover:bg-white/10
        ${active ? "accent-text bg-black/5 dark:bg-white/10" : "text-slate-600 dark:text-slate-300"} ${className}`}
      {...rest}
    >
      <Icon name={icon} size={size} />
    </button>
  );
}

export function Favicon({ src, title, size = 16 }: { src?: string; title?: string; size?: number }) {
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt="" width={size} height={size} className="rounded-sm" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />;
  }
  return (
    <span className="inline-flex items-center justify-center rounded-sm bg-slate-300 text-[9px] font-bold text-slate-700 dark:bg-slate-600 dark:text-slate-100" style={{ width: size, height: size }}>
      {(title || "?").slice(0, 1).toUpperCase()}
    </span>
  );
}

/** Лёгкий рендер Markdown без зависимостей */
export function Markdown({ text }: { text: string }) {
  return <div className="md text-[13.5px] leading-relaxed" dangerouslySetInnerHTML={{ __html: renderMd(text) }} />;
}

function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function inline(s: string) {
  return esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
    .replace(/_([^_\n]+)_/g, "<em>$1</em>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" data-nova-link="1">$1</a>')
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" data-nova-link="1">$2</a>');
}

export function renderMd(src: string): string {
  const lines = src.replace(/\r/g, "").split("\n");
  let html = "";
  let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("```")) {
      const lang = l.slice(3).trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]);
      i++;
      html += `<pre><code class="lang-${esc(lang)}">${esc(buf.join("\n"))}</code></pre>`;
      continue;
    }
    const h = l.match(/^(#{1,3})\s+(.*)/);
    if (h) {
      html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;
      i++;
      continue;
    }
    if (/^\s*[-*•]\s+/.test(l)) {
      html += "<ul>";
      while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) html += `<li>${inline(lines[i++].replace(/^\s*[-*•]\s+/, ""))}</li>`;
      html += "</ul>";
      continue;
    }
    if (/^\s*\d+[.)]\s+/.test(l)) {
      html += "<ol>";
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) html += `<li>${inline(lines[i++].replace(/^\s*\d+[.)]\s+/, ""))}</li>`;
      html += "</ol>";
      continue;
    }
    if (l.startsWith(">")) {
      html += `<blockquote>${inline(l.replace(/^>\s?/, ""))}</blockquote>`;
      i++;
      continue;
    }
    if (l.trim() === "") {
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() !== "" && !/^(```|#{1,3}\s|\s*[-*•]\s|\s*\d+[.)]\s|>)/.test(lines[i])) para.push(lines[i++]);
    html += `<p>${inline(para.join(" "))}</p>`;
  }
  return html;
}

export function Panel({ title, onClose, children, actions }: { title: string; onClose: () => void; children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-12 items-center gap-2 border-b border-black/5 px-3 dark:border-white/10">
        <div className="flex-1 truncate text-sm font-semibold">{title}</div>
        {actions}
        <IconButton icon="close" label="Закрыть" onClick={onClose} />
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto scrollbar-thin">{children}</div>
    </div>
  );
}
