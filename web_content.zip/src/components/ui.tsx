import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn("reveal", visible && "is-visible", className)}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  );
}

export function SectionIntro({
  label,
  title,
  copy,
  aside,
  className,
  id,
}: {
  label: string;
  title: ReactNode;
  copy?: ReactNode;
  aside?: ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <div id={id} className={cn("scroll-mt-28", className)}>
      <Reveal>
        <span className="inline-flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.24em] text-moss-400">
          <span className="h-px w-6 bg-volt" />
          {label}
        </span>
        <div className="mt-4 flex flex-col justify-between gap-6 md:flex-row md:items-end md:gap-10">
          <h2 className="max-w-2xl text-balance text-[clamp(2rem,4.6vw,3.7rem)] font-semibold leading-[0.95] tracking-[-0.035em] text-bone">
            {title}
          </h2>
          {copy && <div className="max-w-sm text-[13.5px] leading-relaxed text-moss-300 md:pb-1">{copy}</div>}
        </div>
        {aside && <div className="mt-5">{aside}</div>}
      </Reveal>
    </div>
  );
}

export function Marquee({
  items,
  className,
  slow = false,
  accent = false,
}: {
  items: string[];
  className?: string;
  slow?: boolean;
  accent?: boolean;
}) {
  const track = [...items, ...items, ...items, ...items];
  return (
    <div
      className={cn(
        "relative flex w-full overflow-hidden border-y",
        accent ? "border-ink-950/10 bg-volt text-ink-950" : "border-white/8 bg-ink-900 text-moss-300",
        className,
      )}
    >
      <div className={cn("flex w-max shrink-0 items-center", slow ? "animate-marquee-slow" : "animate-marquee")}>
        {track.map((item, index) => (
          <span key={`${item}-${index}`} className="flex items-center whitespace-nowrap">
            <span className="px-5 py-3 font-mono text-[10px] font-medium uppercase tracking-[0.22em] sm:px-7 sm:text-[11px]">
              {item}
            </span>
            <span className={cn("text-[9px]", accent ? "text-ink-950/50" : "text-volt/70")}>✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

export function Stat({ value, label, suffix }: { value: string; label: string; suffix?: string }) {
  return (
    <div>
      <p className="flex items-baseline gap-1 font-mono text-2xl font-semibold tracking-tight text-bone sm:text-[28px]">
        {value}
        {suffix && <span className="text-[10px] font-normal uppercase tracking-[0.14em] text-moss-400">{suffix}</span>}
      </p>
      <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.16em] text-moss-500">{label}</p>
    </div>
  );
}

export function Pill({ children, tone = "default" }: { children: ReactNode; tone?: "default" | "volt" | "ghost" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[9px] font-medium uppercase tracking-[0.18em]",
        tone === "volt" && "bg-volt text-ink-950",
        tone === "default" && "border border-white/12 bg-white/5 text-moss-300",
        tone === "ghost" && "border border-volt/25 bg-volt/8 text-volt",
      )}
    >
      {children}
    </span>
  );
}
