import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* Icons                                                               */
/* ------------------------------------------------------------------ */

export type IconName =
  | "play"
  | "pause"
  | "sound"
  | "mute"
  | "settings"
  | "close"
  | "trophy"
  | "heart"
  | "shield"
  | "ammo"
  | "grenade"
  | "car"
  | "jump"
  | "crouch"
  | "reload"
  | "swap"
  | "target"
  | "camera"
  | "use"
  | "arrow"
  | "star"
  | "keyboard"
  | "touch"
  | "check"
  | "skull"
  | "clock"
  | "users"
  | "crosshair"
  | "flag"
  | "bolt"
  | "info"
  | "crown"
  | "rotate"
  | "chevron"
  | "expand"
  | "server";

const paths: Record<IconName, ReactNode> = {
  play: <path d="M8 5.5v13l11-6.5-11-6.5Z" fill="currentColor" stroke="none" />,
  pause: (
    <>
      <rect x="7" y="5" width="3.6" height="14" rx="1.4" fill="currentColor" stroke="none" />
      <rect x="13.4" y="5" width="3.6" height="14" rx="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  sound: (
    <>
      <path d="M4 10v4h3l4 3.5v-11L7 10H4Z" fill="currentColor" stroke="none" />
      <path d="M15 9a4 4 0 0 1 0 6M17.5 6.5a7.5 7.5 0 0 1 0 11" />
    </>
  ),
  mute: (
    <>
      <path d="M4 10v4h3l4 3.5v-11L7 10H4Z" fill="currentColor" stroke="none" />
      <path d="m15 9 5 6M20 9l-5 6" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.09A1.7 1.7 0 0 0 15 4.6a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9v.09A1.7 1.7 0 0 0 20.96 10H21a2 2 0 1 1 0 4h-.09A1.7 1.7 0 0 0 19.4 15Z" />
    </>
  ),
  close: <path d="m6 6 12 12M18 6 6 18" />,
  trophy: (
    <>
      <path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" />
      <path d="M8 5H5v2a3 3 0 0 0 3 3M16 5h3v2a3 3 0 0 1-3 3M12 13v4M8 20h8M9 20v-3h6v3" />
    </>
  ),
  heart: <path d="M12 20s-7-4.35-7-9.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 7 3.5C19 15.65 12 20 12 20Z" fill="currentColor" stroke="none" />,
  shield: <path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6l-7-3Z" />,
  ammo: (
    <>
      <rect x="5" y="8" width="14" height="12" rx="2" />
      <path d="M8 8V5h8v3M9 13h6M9 16h6" />
    </>
  ),
  grenade: (
    <>
      <circle cx="12" cy="14" r="6" />
      <path d="M9 8V5h6v3M15 5l3-2M12 8V6" />
    </>
  ),
  car: (
    <>
      <path d="M4 16v-3l2-5h12l2 5v3" />
      <path d="M3 16h18v3H3zM6 19v2M18 19v2" />
      <circle cx="7.5" cy="16" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="16" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  jump: <path d="M12 20V5M6 11l6-6 6 6" />,
  crouch: <path d="M12 4v10M6 10l6 6 6-6M5 20h14" />,
  reload: (
    <>
      <path d="M20 12a8 8 0 1 1-2.34-5.66" />
      <path d="M20 4v5h-5" />
    </>
  ),
  swap: <path d="M4 8h13l-3-3M20 16H7l3 3" />,
  target: (
    <>
      <circle cx="12" cy="12" r="7" />
      <circle cx="12" cy="12" r="2.5" />
      <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
    </>
  ),
  camera: (
    <>
      <path d="M4 8h3l1.5-2h7L17 8h3v11H4V8Z" />
      <circle cx="12" cy="13" r="3.2" />
    </>
  ),
  use: <path d="M9 11V5a2 2 0 1 1 4 0v6M13 11V4a2 2 0 1 1 4 0v8M17 12V7a2 2 0 1 1 4 0v8a6 6 0 0 1-6 6h-2a7 7 0 0 1-7-7v-3a2 2 0 1 1 4 0" />,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  star: <path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z" fill="currentColor" stroke="none" />,
  keyboard: (
    <>
      <rect x="3" y="6" width="18" height="12" rx="2" />
      <path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10" />
    </>
  ),
  touch: (
    <>
      <rect x="7" y="3" width="10" height="18" rx="2.5" />
      <path d="M11 18h2" />
    </>
  ),
  check: <path d="m5 12 4.5 4.5L19 7" />,
  skull: (
    <>
      <path d="M5 11a7 7 0 1 1 14 0v3l-2 1v3H7v-3l-2-1v-3Z" />
      <circle cx="9.5" cy="11" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="14.5" cy="11" r="1.4" fill="currentColor" stroke="none" />
      <path d="M10 18v-2M14 18v-2" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3" />
      <path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5" />
    </>
  ),
  crosshair: (
    <>
      <circle cx="12" cy="12" r="7.5" />
      <path d="M12 2v5M12 17v5M2 12h5M17 12h5" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  flag: <path d="M6 21V4M6 4h11l-2 4 2 4H6" />,
  bolt: <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" fill="currentColor" stroke="none" />,
  info: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5M12 8h.01" />
    </>
  ),
  crown: <path d="m3 7 4 4 5-7 5 7 4-4-2 12H5L3 7Z" />,
  rotate: (
    <>
      <path d="M4 12a8 8 0 0 1 13.7-5.6L20 8" />
      <path d="M20 4v4h-4M20 12a8 8 0 0 1-13.7 5.6L4 16" />
      <path d="M4 20v-4h4" />
    </>
  ),
  chevron: <path d="m9 6 6 6-6 6" />,
  expand: <path d="M4 9V4h5M20 15v5h-5M20 9V4h-5M4 15v5h5" />,
  server: (
    <>
      <rect x="3" y="4" width="18" height="7" rx="2" />
      <rect x="3" y="13" width="18" height="7" rx="2" />
      <path d="M7 7.5h.01M7 16.5h.01M11 7.5h6M11 16.5h6" />
    </>
  ),
};

export function Icon({ name, className }: { name: IconName; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" className={cn("h-5 w-5", className)} aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Brand                                                               */
/* ------------------------------------------------------------------ */

export function FoxMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn("h-10 w-10", className)} aria-hidden="true">
      <path d="M10 8 22 18h20L54 8l-2 24c0 13-9 22-20 22S12 45 12 32L10 8Z" fill="#f28b3c" stroke="#241a35" strokeWidth="3.5" strokeLinejoin="round" />
      <path d="M17 15 22 24h20l5-9-3 17H20L17 15Z" fill="#ffd9a0" />
      <path d="M20 33c0-4 3-7 7-7s7 3 7 7-3 8-7 8-7-4-7-8ZM30 33c0-4 3-7 7-7s7 3 7 7-3 8-7 8-7-4-7-8Z" fill="#241a35" />
      <circle cx="25" cy="31" r="2.4" fill="#fff" />
      <circle cx="35" cy="31" r="2.4" fill="#fff" />
      <path d="M27 43h10l-5 6-5-6Z" fill="#241a35" />
      <path d="M32 49v5M26 54h12" stroke="#241a35" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function StarBurst({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 200" className={cn("h-full w-full", className)} aria-hidden="true">
      <path
        d="M100 2 118 52 160 18 148 68 198 62 160 96 196 132 146 128 158 180 118 148 100 198 82 148 42 180 54 128 4 132 40 96 2 62 52 68 40 18 82 52Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative grid h-11 w-11 place-items-center rounded-2xl border-[3px] border-ink bg-sun shadow-[0_4px_0_0_#241a35]">
        <FoxMark className="h-8 w-8" />
      </div>
      <div className="leading-none">
        <div className={cn("font-display font-black tracking-tight text-cream", compact ? "text-xl" : "text-2xl")}>ТОЛОК</div>
        <div className="mt-1 text-[9px] font-bold uppercase tracking-[0.32em] text-cream/50">Sand Fort Arena</div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Primitives                                                          */
/* ------------------------------------------------------------------ */

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-3xl border-[3px] border-ink bg-panel/95 shadow-[0_6px_0_0_#241a35]", className)}>{children}</div>;
}

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger" | "teal";

export function ChunkyButton({
  children,
  onClick,
  variant = "primary",
  className,
  icon,
  disabled,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: ButtonVariant;
  className?: string;
  icon?: IconName;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const styles: Record<ButtonVariant, string> = {
    primary: "bg-sun text-ink border-ink shadow-[0_5px_0_0_#241a35] hover:bg-[#ffc65c] active:shadow-[0_2px_0_0_#241a35] active:translate-y-[3px]",
    secondary: "bg-cream text-ink border-ink shadow-[0_5px_0_0_#241a35] hover:bg-white active:shadow-[0_2px_0_0_#241a35] active:translate-y-[3px]",
    teal: "bg-teal text-ink border-ink shadow-[0_5px_0_0_#241a35] hover:bg-[#5ce6d8] active:shadow-[0_2px_0_0_#241a35] active:translate-y-[3px]",
    danger: "bg-coral text-white border-ink shadow-[0_5px_0_0_#241a35] hover:bg-[#ff8266] active:shadow-[0_2px_0_0_#241a35] active:translate-y-[3px]",
    ghost: "bg-white/5 text-cream border-cream/20 hover:bg-white/10",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "inline-flex select-none items-center justify-center gap-2 rounded-2xl border-[3px] px-5 py-3 font-display text-sm font-extrabold uppercase tracking-wide transition-all duration-100 disabled:cursor-not-allowed disabled:opacity-40",
        styles[variant],
        className
      )}
    >
      {icon && <Icon name={icon} className="h-5 w-5" />}
      {children}
    </button>
  );
}

export function IconButton({
  icon,
  onClick,
  label,
  active,
  className,
}: {
  icon: IconName;
  onClick?: () => void;
  label: string;
  active?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn(
        "grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink text-ink shadow-[0_3px_0_0_#241a35] transition-all active:translate-y-[2px] active:shadow-[0_1px_0_0_#241a35]",
        active ? "bg-teal" : "bg-cream hover:bg-white",
        className
      )}
    >
      <Icon name={icon} className="h-5 w-5" />
    </button>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 rounded-2xl border-2 border-cream/10 bg-white/5 px-3 py-2.5 text-left transition-colors hover:bg-white/10"
      aria-pressed={checked}
    >
      <span className="text-xs font-bold text-cream/80">{label}</span>
      <span className={cn("relative h-6 w-11 shrink-0 rounded-full border-2 border-ink transition-colors", checked ? "bg-teal" : "bg-white/15")}>
        <span className={cn("absolute top-0.5 h-4 w-4 rounded-full border-2 border-ink bg-cream transition-all", checked ? "left-[22px]" : "left-0.5")} />
      </span>
    </button>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  display?: string;
}) {
  return (
    <label className="block rounded-2xl border-2 border-cream/10 bg-white/5 px-3 py-2.5">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-xs font-bold text-cream/80">{label}</span>
        <span className="rounded-md bg-ink/60 px-1.5 py-0.5 font-mono text-[10px] font-bold text-sun">{display ?? value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="tolok-range w-full"
      />
    </label>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex gap-1 rounded-xl border-2 border-cream/10 bg-ink/50 p-1", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-lg px-2 py-1.5 text-[10px] font-extrabold uppercase tracking-wide transition-colors",
            value === o.value ? "bg-sun text-ink" : "text-cream/60 hover:bg-white/10 hover:text-cream"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Modal({
  children,
  onClose,
  className,
  wide,
}: {
  children: ReactNode;
  onClose: () => void;
  className?: string;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-ink/75 p-3 backdrop-blur-sm sm:p-6" onPointerDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={cn("relative my-auto w-full rounded-[28px] border-[3px] border-ink bg-panel shadow-[0_10px_0_0_#241a35]", wide ? "max-w-4xl" : "max-w-lg", className)}>
        <button
          type="button"
          onClick={onClose}
          aria-label="Закрыть"
          className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-xl border-2 border-ink bg-cream text-ink shadow-[0_3px_0_0_#241a35] transition-transform active:translate-y-[2px]"
        >
          <Icon name="close" className="h-4 w-4" />
        </button>
        {children}
      </div>
    </div>
  );
}

export function SectionTitle({ icon, children, right }: { icon?: IconName; children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        {icon && (
          <span className="grid h-7 w-7 place-items-center rounded-lg border-2 border-ink bg-sun text-ink">
            <Icon name={icon} className="h-4 w-4" />
          </span>
        )}
        <h3 className="font-display text-xs font-extrabold uppercase tracking-[0.18em] text-cream">{children}</h3>
      </div>
      {right}
    </div>
  );
}

export function KeyCap({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <kbd className={cn("inline-flex min-w-6 items-center justify-center rounded-md border-2 border-ink bg-cream px-1.5 py-0.5 font-mono text-[10px] font-bold text-ink shadow-[0_2px_0_0_#241a35]", className)}>
      {children}
    </kbd>
  );
}

export function TeamBadge({ team, className }: { team: "sun" | "tide" | "none"; className?: string }) {
  const label = team === "sun" ? "SUN" : team === "tide" ? "TIDE" : "SOLO";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md border-2 border-ink px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider text-ink",
        team === "sun" ? "bg-sun" : team === "tide" ? "bg-teal" : "bg-grape",
        className
      )}
    >
      {label}
    </span>
  );
}
