import { useEffect, useId, useRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from "react";
import { Check, ChevronDown, Info, X, AlertTriangle } from "lucide-react";
import { cn } from "@/utils/cn";
import { useStudio } from "@/store/StudioContext";

type ButtonVariant = "primary" | "ghost" | "quiet" | "danger" | "mint";

export function Button({
  variant = "ghost",
  className,
  children,
  loading,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; loading?: boolean }) {
  const map: Record<ButtonVariant, string> = {
    primary: "btn-primary",
    ghost: "btn-ghost",
    quiet: "btn-quiet",
    danger: "btn-danger",
    mint: "btn-mint",
  };
  return (
    <button
      {...props}
      disabled={props.disabled || loading}
      className={cn("btn", map[variant], className)}
    >
      {loading ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" /> : null}
      {children}
    </button>
  );
}

export function Field({
  label,
  hint,
  error,
  children,
  className,
  required,
}: {
  label?: string;
  hint?: string;
  error?: string;
  children: ReactNode;
  className?: string;
  required?: boolean;
}) {
  return (
    <div className={className}>
      {label ? (
        <label className="label flex items-center justify-between gap-2">
          <span>
            {label} {required ? <span className="text-[#e49c76]">*</span> : null}
          </span>
        </label>
      ) : null}
      {children}
      {error ? <p className="mt-1.5 text-[11px] leading-5 text-red-300">{error}</p> : null}
      {!error && hint ? <p className="mt-1.5 text-[11px] leading-5 text-[#76767f]">{hint}</p> : null}
    </div>
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn("field", className)} />;
}

export function Toggle({
  checked,
  onChange,
  label,
  hint,
  disabled,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  hint?: string;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4 py-2">
      <div>
        <label htmlFor={id} className="cursor-pointer text-[13px] font-medium text-[#e9e9ee]">
          {label}
        </label>
        {hint ? <p className="mt-0.5 text-[11px] leading-5 text-[#797981]">{hint}</p> : null}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        data-on={checked}
        className={cn("switch mt-0.5", disabled && "opacity-40")}
        onClick={() => onChange(!checked)}
      >
        <span />
      </button>
    </div>
  );
}

export function RangeField({
  label,
  value,
  min,
  max,
  step = 1,
  unit,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
  format?: (value: number) => string;
}) {
  const percent = ((value - min) / Math.max(0.0001, max - min)) * 100;
  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="text-[12px] font-medium text-[#b9b9c2]">{label}</span>
        <span className="rounded-md border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[11px] tabular-nums text-[#efe4c4]">
          {format ? format(value) : `${value}${unit ?? ""}`}
        </span>
      </div>
      <input
        type="range"
        aria-label={label}
        className="range w-full"
        value={value}
        min={min}
        max={max}
        step={step}
        style={{ "--fill": `${percent}%` } as React.CSSProperties}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </div>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  size = "md",
  className,
}: {
  options: { value: T; label: ReactNode; disabled?: boolean }[];
  value: T;
  onChange: (value: T) => void;
  size?: "sm" | "md";
  className?: string;
}) {
  return (
    <div className={cn("inline-flex w-full gap-1 rounded-xl border border-white/10 bg-[#0a0a0d] p-1", className)}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          disabled={option.disabled}
          onClick={() => onChange(option.value)}
          className={cn(
            "flex-1 rounded-lg px-2 font-medium transition disabled:opacity-40",
            size === "sm" ? "py-1.5 text-[11px]" : "py-2 text-[12px]",
            value === option.value
              ? "bg-white/[0.09] text-white shadow-sm ring-1 ring-white/10"
              : "text-[#8c8c96] hover:text-white",
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0b0b0e] p-1.5">
        <input
          type="color"
          aria-label={label}
          value={/^#[0-9a-f]{6}$/i.test(value) ? value : "#ffffff"}
          onChange={(event) => onChange(event.target.value)}
          className="h-8 w-9 cursor-pointer rounded-lg border border-white/10 bg-transparent"
        />
        <input
          className="min-w-0 flex-1 bg-transparent px-1 text-[11px] uppercase tracking-wide text-[#c9c9d1] outline-none"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          dir="ltr"
          aria-label={`${label} — قيمة اللون`}
        />
      </div>
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handler);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0" onClick={onClose} aria-hidden="true" />
      <div
        className={cn(
          "relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-white/10 bg-[#101014] shadow-2xl sm:rounded-3xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-lg",
        )}
      >
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-white/[0.07] bg-[#101014]/95 px-5 py-4 backdrop-blur">
          <div>
            <h3 className="font-display text-[18px] font-bold text-white">{title}</h3>
            {description ? <p className="mt-1 text-[12px] leading-5 text-[#8f8f99]">{description}</p> : null}
          </div>
          <button type="button" onClick={onClose} aria-label="إغلاق" className="rounded-lg p-1.5 text-[#8c8c96] transition hover:bg-white/5 hover:text-white">
            <X size={18} />
          </button>
        </div>
        <div className="px-5 py-5">{children}</div>
        {footer ? <div className="sticky bottom-0 border-t border-white/[0.07] bg-[#101014]/95 px-5 py-4 backdrop-blur">{footer}</div> : null}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "تأكيد",
  cancelLabel = "إلغاء",
  danger,
  onConfirm,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
  children?: ReactNode;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      footer={
        <div className="flex flex-wrap justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            {cancelLabel}
          </Button>
          <Button type="button" variant={danger ? "danger" : "primary"} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </div>
      }
    >
      {children ?? <p className="text-[13px] leading-7 text-[#a6a6b0]">لن يمكن التراجع عن هذا الإجراء بعد تنفيذه.</p>}
    </Modal>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  description,
  actions,
  icon,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div className="flex items-start gap-3">
        {icon ? <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#d9b65a]/20 bg-[#d9b65a]/[0.08] text-[#e7cf94]">{icon}</div> : null}
        <div>
          {eyebrow ? <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#a1874c]">{eyebrow}</p> : null}
          <h1 className="font-display text-[24px] font-bold leading-tight text-white sm:text-[28px]">{title}</h1>
          {description ? <p className="mt-1.5 max-w-2xl text-[12px] leading-6 text-[#8f8f99] sm:text-[13px]">{description}</p> : null}
        </div>
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-white/10 bg-white/[0.015] px-6 py-12 text-center">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] text-[#d9b65a]">{icon}</div>
      <h3 className="font-display text-[16px] font-bold text-white">{title}</h3>
      <p className="mt-2 max-w-sm text-[12px] leading-6 text-[#888892]">{description}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  );
}

export function InlineNotice({
  kind = "info",
  title,
  children,
}: {
  kind?: "info" | "warning" | "error" | "success";
  title: string;
  children?: ReactNode;
}) {
  const palette = {
    info: "border-sky-400/20 bg-sky-400/[0.06] text-sky-200",
    warning: "border-[#d9b65a]/25 bg-[#d9b65a]/[0.07] text-[#f0dfb4]",
    error: "border-red-400/25 bg-red-400/[0.07] text-red-200",
    success: "border-emerald-400/25 bg-emerald-400/[0.07] text-emerald-200",
  };
  const Icon = kind === "warning" ? AlertTriangle : kind === "success" ? Check : kind === "error" ? AlertTriangle : Info;
  return (
    <div className={cn("flex gap-2.5 rounded-xl border px-3.5 py-3 text-[12px] leading-6", palette[kind])}>
      <Icon size={15} className="mt-1 shrink-0" />
      <div>
        <p className="font-semibold">{title}</p>
        {children ? <div className="mt-0.5 text-[11px] opacity-80">{children}</div> : null}
      </div>
    </div>
  );
}

export function Toaster() {
  const { toasts, dismissToast } = useStudio();
  const styles = {
    success: "border-emerald-400/25 bg-[#0f1a15] text-emerald-100",
    error: "border-red-400/30 bg-[#1e1011] text-red-100",
    warning: "border-[#d9b65a]/30 bg-[#1c1810] text-[#f3e4bd]",
    info: "border-white/15 bg-[#15151b] text-[#e8e8ee]",
  };
  return (
    <div className="pointer-events-none fixed bottom-20 left-1/2 z-[100] flex w-[calc(100%-2rem)] max-w-md -translate-x-1/2 flex-col gap-2 lg:bottom-6" aria-live="polite">
      {toasts.map((toast) => (
        <div key={toast.id} className={cn("pointer-events-auto flex items-start gap-2.5 rounded-xl border px-4 py-3 text-[12px] leading-6 shadow-2xl backdrop-blur animate-in", styles[toast.kind])}>
          {toast.kind === "success" ? <Check size={15} className="mt-1 shrink-0" /> : toast.kind === "error" || toast.kind === "warning" ? <AlertTriangle size={15} className="mt-1 shrink-0" /> : <Info size={15} className="mt-1 shrink-0" />}
          <p className="flex-1">{toast.text}</p>
          <button onClick={() => dismissToast(toast.id)} className="mt-0.5 opacity-60 hover:opacity-100" aria-label="إغلاق التنبيه">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}

export function Select({
  className,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="relative">
      <select {...props} className={cn("field appearance-none pl-8", className)}>
        {children}
      </select>
      <ChevronDown size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#7c7c86]" />
    </div>
  );
}

export function useClickOutside<T extends HTMLElement>(onOutside: () => void) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const handler = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) onOutside();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [onOutside]);
  return ref;
}

export function Textarea({
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn("field min-h-[72px] resize-y leading-7", className)} />;
}
