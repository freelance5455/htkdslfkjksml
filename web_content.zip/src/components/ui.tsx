import { clsx, type ClassValue } from "clsx";
import { X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="var(--color-fg)" />
      <circle cx="16" cy="16" r="9" fill="none" stroke="var(--color-bg)" strokeWidth="3" />
      <circle cx="16" cy="16" r="3.5" fill="var(--color-primary)" />
    </svg>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-muted">{label}</span>
      {children}
    </label>
  );
}

export function Segment<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string }[];
  onChange: (value: T) => void;
}) {
  return (
    <div
      className="grid rounded-lg bg-surface-2 p-1"
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((option) => (
        <button
          key={option.id}
          type="button"
          aria-pressed={value === option.id}
          className={cn(
            "h-11 rounded-md text-sm",
            value === option.id ? "bg-surface font-medium text-fg" : "text-muted",
          )}
          onClick={() => onChange(option.id)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <button type="button" className="absolute inset-0 bg-fg/40" aria-label="닫기" onClick={onClose} />
      <div className="sheet-panel relative z-10 flex w-full max-w-lg flex-col overflow-hidden rounded-t-xl bg-surface sm:rounded-xl">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <h2 className="text-base font-semibold">{title}</h2>
          <button type="button" className="grid size-11 place-items-center text-muted" onClick={onClose} aria-label="닫기">
            <X className="size-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-4 py-4">{children}</div>
      </div>
    </div>
  );
}

export function PnlText({ value, children }: { value: number; children: ReactNode }) {
  return <span className={cn("tabular-nums", value > 0 ? "text-up" : value < 0 ? "text-down" : "text-muted")}>{children}</span>;
}
