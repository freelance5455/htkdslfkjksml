import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Page({
  title,
  subtitle,
  children,
  back,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  back?: boolean;
}) {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 pt-4">
      {back && (
        <button
          type="button"
          onClick={() => history.back()}
          className="mb-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald"
        >
          رجوع
        </button>
      )}
      <header className="mb-4">
        <h1 className="text-2xl font-bold leading-tight text-emerald-deep">{title}</h1>
        {subtitle && <p className="mt-1 text-sm leading-relaxed text-muted">{subtitle}</p>}
      </header>
      {children}
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-2xl border border-line bg-card p-4 shadow-[var(--shadow)]", className)}>
      {children}
    </section>
  );
}

const tones = {
  primary: "bg-btn text-btn-fg",
  ghost: "border border-line bg-card text-ink",
  gold: "bg-gold text-on-gold",
  danger: "border border-danger bg-transparent text-danger",
};

export function Btn({
  tone = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: keyof typeof tones }) {
  return (
    <button
      {...props}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold",
        tones[tone],
        className,
      )}
    />
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-ink">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-ivory-2 px-3 text-sm text-ink outline-none";

export function Empty({ text }: { text: string }) {
  return <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">{text}</p>;
}

export function Chip({ children, active }: { children: ReactNode; active?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex min-h-8 items-center rounded-full px-3 text-xs font-semibold",
        active ? "bg-emerald-soft text-emerald" : "bg-gold-soft text-ink",
      )}
    >
      {children}
    </span>
  );
}
