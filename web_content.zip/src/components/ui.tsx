import type { ButtonHTMLAttributes, ReactNode } from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const VARIANTS = {
  primary: "bg-primary text-primary-fg",
  quiet: "bg-surface-2 text-fg",
  ghost: "bg-transparent text-fg",
  ok: "bg-ok text-ok-fg",
} as const;

export function buttonClass(variant: keyof typeof VARIANTS = "primary", className?: string) {
  return cn(
    "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-4 text-center text-sm font-semibold transition-colors",
    VARIANTS[variant],
    "disabled:opacity-50",
    className,
  );
}

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof VARIANTS }) {
  return <button type={type} className={buttonClass(variant, className)} {...props} />;
}

export function PageHeader({
  kicker,
  title,
  subtitle,
  id,
}: {
  kicker?: string;
  title: string;
  subtitle?: string;
  id?: string;
}) {
  return (
    <header id={id}>
      {kicker ? <p className="text-xs font-semibold tracking-widest text-primary uppercase">{kicker}</p> : null}
      <h1 className="font-display text-3xl font-semibold">{title}</h1>
      {subtitle ? <p className="mt-1 max-w-prose text-muted">{subtitle}</p> : null}
    </header>
  );
}

export function Panel({
  title,
  action,
  children,
  id,
  className,
}: {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  id?: string;
  className?: string;
}) {
  return (
    <section id={id} className={cn("panel", className)}>
      {title ? (
        <header className="mb-3 flex items-start justify-between gap-3">
          <h2 className="font-display text-lg font-semibold">{title}</h2>
          {action}
        </header>
      ) : null}
      {children}
    </section>
  );
}

export function Field({
  label,
  hint,
  error,
  children,
}: {
  label: string;
  hint?: string;
  error?: string | null;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-semibold">{label}</span>
      {children}
      {error ? (
        <span role="alert" className="mt-1 block text-sm text-primary">
          {error}
        </span>
      ) : hint ? (
        <span className="mt-1 block text-sm text-faint">{hint}</span>
      ) : null}
    </label>
  );
}

export function MetricRow({
  label,
  value,
  source,
  unavailable = false,
}: {
  label: string;
  value?: string | null;
  source?: string;
  unavailable?: boolean;
}) {
  return (
    <div className="border-b border-line py-3 last:border-b-0">
      <div className="flex items-baseline justify-between gap-3">
        <dt className="text-sm text-muted">{label}</dt>
        <dd className="max-w-[60%] text-right text-sm font-semibold text-pretty tabular-nums">
          {unavailable ? "Not available in this version." : value}
        </dd>
      </div>
      {source ? <p className="mt-1 text-xs text-faint">{source}</p> : null}
    </div>
  );
}

export function Notice({ tone = "neutral", children }: { tone?: "neutral" | "ok" | "warn"; children: ReactNode }) {
  return (
    <p
      role={tone === "warn" ? "alert" : "status"}
      className={cn("text-sm", tone === "ok" ? "text-ok" : tone === "warn" ? "text-primary" : "text-muted")}
    >
      {children}
    </p>
  );
}
