"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { copyText } from "@/lib/client/api";

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-block h-4 w-4 animate-spin rounded-full border-2 border-white/25 border-t-white ${className}`}
      aria-hidden
    />
  );
}

export function Pill({ children, tone = "default" }: { children: React.ReactNode; tone?: "default" | "brand" | "warn" | "good" }) {
  const tones: Record<string, string> = {
    default: "border-white/10 bg-white/5 text-[color:var(--muted)]",
    brand: "border-violet-400/30 bg-violet-500/15 text-violet-200",
    warn: "border-amber-400/30 bg-amber-500/15 text-amber-200",
    good: "border-emerald-400/30 bg-emerald-500/15 text-emerald-200",
  };
  return <span className={`chip ${tones[tone]}`}>{children}</span>;
}

export function Toast({ message, tone = "good", onDone }: { message: string; tone?: "good" | "bad"; onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2400);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div
      role="status"
      className={`fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-full px-4 py-2 text-sm font-medium shadow-xl backdrop-blur md:bottom-8 ${
        tone === "good" ? "bg-emerald-500/90 text-emerald-950" : "bg-rose-500/90 text-white"
      }`}
    >
      {message}
    </div>
  );
}

export function useToast() {
  const [toast, setToast] = useState<{ message: string; tone: "good" | "bad" } | null>(null);
  const show = useCallback((message: string, tone: "good" | "bad" = "good") => setToast({ message, tone }), []);
  const node = toast ? <Toast message={toast.message} tone={toast.tone} onDone={() => setToast(null)} /> : null;
  return { show, node };
}

export function CopyButton({
  value,
  label = "Copy",
  onCopied,
  className = "btn btn-ghost btn-sm",
}: {
  value: string;
  label?: string;
  onCopied?: () => void;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      className={className}
      onClick={async () => {
        const done = await copyText(value);
        setCopied(done);
        if (done) onCopied?.();
        setTimeout(() => setCopied(false), 1400);
      }}
      aria-label={label}
    >
      {copied ? "✓ Copied" : `⧉ ${label}`}
    </button>
  );
}

export function EmptyState({ emoji, title, body }: { emoji: string; title: string; body: string }) {
  return (
    <div className="card flex flex-col items-center gap-2 p-8 text-center">
      <span className="text-3xl">{emoji}</span>
      <p className="font-semibold">{title}</p>
      <p className="max-w-sm text-sm text-[color:var(--muted)]">{body}</p>
    </div>
  );
}

/** Guards against duplicate submits across double clicks and rapid keypresses. */
export function useSingleFlight() {
  const running = useRef(false);
  const [busy, setBusy] = useState(false);
  const start = useCallback(() => {
    if (running.current) return false;
    running.current = true;
    setBusy(true);
    return true;
  }, []);
  const stop = useCallback(() => {
    running.current = false;
    setBusy(false);
  }, []);
  return { busy, start, stop };
}
