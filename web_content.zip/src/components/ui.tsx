import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import { cn } from "../utils/cn";

/* ---------- icons ---------- */

const PATHS: Record<string, ReactNode> = {
  play: <path d="M7 5.5v13l11-6.5z" fill="currentColor" stroke="none" />,
  pause: (
    <>
      <rect x="6.5" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" />
      <rect x="13.5" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" />
    </>
  ),
  film: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" />
    </>
  ),
  sparkles: (
    <>
      <path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z" />
      <path d="M18.5 15.5l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z" />
    </>
  ),
  chip: (
    <>
      <rect x="6" y="6" width="12" height="12" rx="2" />
      <path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3" />
    </>
  ),
  book: (
    <>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z" />
      <path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5" />
    </>
  ),
  flask: (
    <>
      <path d="M10 2v6.5L4.5 18a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 8.5V2" />
      <path d="M8 2h8M7.5 14h9" />
    </>
  ),
  doc: (
    <>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6M9 13h6M9 17h6" />
    </>
  ),
  download: (
    <>
      <path d="M12 3v12M7 10l5 5 5-5" />
      <path d="M4 19h16" />
    </>
  ),
  trash: (
    <>
      <path d="M4 7h16M10 11v6M14 11v6" />
      <path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13M9 7V4h6v3" />
    </>
  ),
  x: <path d="M6 6l12 12M18 6L6 18" />,
  check: <path d="M4.5 12.5l5 5 10-11" />,
  alert: (
    <>
      <path d="M12 3L2.5 20h19z" />
      <path d="M12 9.5v4.5M12 17.2v.1" />
    </>
  ),
  wifi: (
    <>
      <path d="M2.5 9.5a15 15 0 0 1 19 0M5.5 13a10.5 10.5 0 0 1 13 0M8.5 16.5a6 6 0 0 1 7 0" />
      <circle cx="12" cy="19.5" r="1" fill="currentColor" />
    </>
  ),
  wifioff: (
    <>
      <path d="M3 3l18 18M8.5 16.5a6 6 0 0 1 5-1.1M5.5 13a10.5 10.5 0 0 1 4-2.3M2.5 9.5A15 15 0 0 1 8 6.4M12 3c3.5 0 6.9 1.2 9.5 3.5M15 10.3A10.5 10.5 0 0 1 18.5 13" />
      <circle cx="12" cy="19.5" r="1" fill="currentColor" />
    </>
  ),
  cc: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="M10.5 10.2a2.4 2.4 0 1 0 0 3.6M17 10.2a2.4 2.4 0 1 0 0 3.6" />
    </>
  ),
  upload: (
    <>
      <path d="M12 15V3M7 8l5-5 5 5" />
      <path d="M4 19h16" />
    </>
  ),
  save: (
    <>
      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
      <path d="M17 21v-8H7v8M7 3v5h8" />
    </>
  ),
  refresh: (
    <>
      <path d="M20 11a8 8 0 1 0-2.3 6.3" />
      <path d="M20 4v7h-7" />
    </>
  ),
  folder: (
    <>
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3.5 2" />
    </>
  ),
  drive: (
    <>
      <rect x="3" y="13" width="18" height="7" rx="2" />
      <path d="M5 13L8 4h8l3 9M17 16.5h.1M13 16.5h.1" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2.5l7.5 3v6c0 4.7-3.2 8.1-7.5 10-4.3-1.9-7.5-5.3-7.5-10v-6z" />
      <path d="M8.8 12l2.3 2.3 4.2-4.5" />
    </>
  ),
  expand: (
    <>
      <path d="M9 4H4v5M15 4h5v5M9 20H4v-5M15 20h5v-5" />
    </>
  ),
  wand: (
    <>
      <path d="M4 20L15.5 8.5M13 4l.8 2.2L16 7l-2.2.8L13 10l-.8-2.2L10 7l2.2-.8zM19 11l.6 1.6L21.2 13l-1.6.6L19 15.2l-.6-1.6L16.8 13l1.6-.4z" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.8 2.6 4 5.7 4 9s-1.2 6.4-4 9c-2.8-2.6-4-5.7-4-9s1.2-6.4 4-9z" />
    </>
  ),
};

export type IconName = keyof typeof PATHS;

export function Icon({ name, className }: { name: string; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("h-5 w-5 shrink-0", className)}
      aria-hidden
    >
      {PATHS[name] ?? PATHS.doc}
    </svg>
  );
}

/* ---------- primitives ---------- */

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "solid" | "outline" | "ghost" | "danger" | "jade";
  size?: "sm" | "md" | "lg";
};

export function Btn({ variant = "solid", size = "md", className, ...props }: BtnProps) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-all active:scale-[0.97] disabled:pointer-events-none disabled:opacity-40",
        size === "sm" && "px-2.5 py-1.5 text-xs",
        size === "md" && "px-3.5 py-2 text-sm",
        size === "lg" && "px-5 py-3 text-base",
        variant === "solid" && "bg-brass-500 text-ink-950 hover:bg-brass-400",
        variant === "jade" && "bg-jade-500 text-ink-950 hover:bg-jade-400",
        variant === "outline" &&
          "border border-ink-600 bg-ink-850 text-mist-100 hover:border-mist-500 hover:bg-ink-800",
        variant === "ghost" && "text-mist-300 hover:bg-ink-800 hover:text-mist-100",
        variant === "danger" &&
          "border border-rust-500/40 bg-rust-500/10 text-rust-400 hover:bg-rust-500/20",
        className
      )}
      {...props}
    />
  );
}

export function Card({
  className,
  children,
  onClick,
}: {
  className?: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-xl border border-ink-700 bg-ink-900",
        onClick && "cursor-pointer transition-colors hover:border-ink-600",
        className
      )}
    >
      {children}
    </div>
  );
}

export function Bar({
  value,
  active,
  tone = "brass",
  className,
}: {
  value: number; // 0..1
  active?: boolean;
  tone?: "brass" | "jade" | "rust";
  className?: string;
}) {
  return (
    <div className={cn("h-2 overflow-hidden rounded-full bg-ink-700", className)}>
      <div
        className={cn(
          "h-full rounded-full transition-[width] duration-300",
          tone === "brass" && "bg-brass-500",
          tone === "jade" && "bg-jade-400",
          tone === "rust" && "bg-rust-500",
          active && "bar-active"
        )}
        style={{ width: `${Math.round(Math.max(0, Math.min(1, value)) * 100)}%` }}
      />
    </div>
  );
}

export function Chip({
  tone = "mist",
  children,
  className,
}: {
  tone?: "mist" | "brass" | "jade" | "rust" | "moss";
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wide uppercase",
        tone === "mist" && "bg-ink-700 text-mist-300",
        tone === "brass" && "bg-brass-500/15 text-brass-400",
        tone === "jade" && "bg-jade-500/15 text-jade-300",
        tone === "rust" && "bg-rust-500/15 text-rust-400",
        tone === "moss" && "bg-moss-500/15 text-moss-400",
        className
      )}
    >
      {children}
    </span>
  );
}

export function Seg<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { v: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex rounded-lg border border-ink-600 bg-ink-900 p-0.5", className)}>
      {options.map((o) => (
        <button
          key={o.v}
          onClick={() => onChange(o.v)}
          className={cn(
            "flex-1 rounded-md px-2 py-1.5 text-xs font-semibold transition-colors",
            value === o.v
              ? "bg-ink-700 text-brass-400"
              : "text-mist-400 hover:text-mist-200"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h2 className="font-display text-sm font-semibold tracking-wide text-mist-300 uppercase">
        {children}
      </h2>
      {right}
    </div>
  );
}

export function Empty({
  icon,
  title,
  sub,
  children,
}: {
  icon: string;
  title: string;
  sub?: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-ink-600 bg-ink-900/50 px-6 py-12 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-ink-800 text-brass-400">
        <Icon name={icon} className="h-6 w-6" />
      </div>
      <div>
        <p className="font-display text-base font-semibold text-mist-100">{title}</p>
        {sub && <p className="mt-1 max-w-xs text-xs leading-relaxed text-mist-500">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

/* ---------- toasts ---------- */

interface Toast {
  id: number;
  msg: string;
  tone: "ok" | "warn" | "err";
}

const ToastCtx = createContext<(msg: string, tone?: Toast["tone"]) => void>(() => {});

export function useToast() {
  return useContext(ToastCtx);
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(1);
  const push = useCallback((msg: string, tone: Toast["tone"] = "ok") => {
    const id = idRef.current++;
    setToasts((t) => [...t.slice(-3), { id, msg, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-2 z-50 flex flex-col items-center gap-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "rise pointer-events-auto flex max-w-md items-start gap-2 rounded-lg border px-3 py-2 text-xs font-medium shadow-xl backdrop-blur",
              t.tone === "ok" && "border-moss-500/40 bg-ink-850/95 text-moss-400",
              t.tone === "warn" && "border-brass-500/40 bg-ink-850/95 text-brass-400",
              t.tone === "err" && "border-rust-500/50 bg-ink-850/95 text-rust-400"
            )}
          >
            <Icon name={t.tone === "ok" ? "check" : "alert"} className="mt-0.5 h-4 w-4" />
            <span className="text-mist-100">{t.msg}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useOnline(): boolean {
  const [online, setOnline] = useState(() =>
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return online;
}
