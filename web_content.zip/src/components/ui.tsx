import type { ReactNode } from "react";
import { cn } from "../utils/cn";

/** Centered, padded, full-height column — the equivalent of `CenterScreen`. */
export function CenterScreen({
  children,
  className,
  animate = true,
}: {
  children: ReactNode;
  className?: string;
  animate?: boolean;
}) {
  return (
    <section
      className={cn(
        "flex min-h-dvh w-full flex-col items-center justify-center px-6 py-10 text-center",
        animate && "animate-fade-up",
        className,
      )}
    >
      {children}
    </section>
  );
}

/** Big pill-shaped pink call-to-action — the equivalent of `PinkButton`. */
export function PinkButton({
  children,
  onClick,
  className,
}: {
  children: ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-14 w-full cursor-pointer rounded-full bg-[#FF3EA5] text-base font-bold tracking-wide text-white",
        "shadow-[0_10px_34px_-8px_rgba(255,62,165,0.85)] transition duration-200",
        "hover:brightness-110 active:scale-[0.96]",
        "focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#FF8BD7]",
        className,
      )}
    >
      {children}
    </button>
  );
}

/** Glassy quiz answer card — the equivalent of `AnswerButton`. */
export function AnswerButton({
  text,
  onClick,
  selected,
  disabled,
}: {
  text: string;
  onClick: () => void;
  selected?: boolean;
  disabled?: boolean;
}) {
  // Answers are written as "🌆 Long drive" → split the emoji from the label.
  const [emoji, ...rest] = text.split(" ");
  const label = rest.join(" ");

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex w-full cursor-pointer items-center gap-4 rounded-[18px] border px-5 py-4 text-left transition duration-200",
        "text-base font-medium text-white backdrop-blur-sm",
        selected
          ? "scale-[1.02] border-[#FF67C3] bg-[#FF3EA5]/30 shadow-[0_0_28px_-4px_rgba(255,62,165,0.7)]"
          : "border-white/10 bg-white/[0.07] hover:border-[#FF67C3]/50 hover:bg-white/[0.12] active:scale-[0.97]",
        disabled && !selected && "opacity-60",
      )}
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/10 text-xl">
        {emoji}
      </span>
      <span>{label}</span>
    </button>
  );
}
