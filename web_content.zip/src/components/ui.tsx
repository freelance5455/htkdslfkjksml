import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";
import { IconClose } from "./Icons";

/* ------------------------------------------------------------------ Reveal */
export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setSeen(true);
            io.disconnect();
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -6% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [seen]);
  return (
    <div
      ref={ref}
      className={cn("reveal", seen && "in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* --------------------------------------------------------------- Segmented */
export interface SegOption<T extends string> {
  value: T;
  label: string;
  icon?: ReactNode;
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  size = "md",
  accent = "gold",
}: {
  options: SegOption<T>[];
  value: T;
  onChange: (v: T) => void;
  size?: "sm" | "md";
  accent?: "gold" | "jade";
}) {
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  const n = options.length;
  return (
    <div
      className={cn(
        "relative grid rounded-xl border border-line/80 bg-ink2/70 p-1",
        size === "sm" ? "text-[11px]" : "text-xs",
      )}
      style={{ gridTemplateColumns: `repeat(${n}, minmax(0,1fr))` }}
    >
      <span
        className={cn(
          "pointer-events-none absolute inset-y-1 rounded-lg transition-all duration-300",
          accent === "gold"
            ? "bg-gradient-to-b from-gold2/95 to-gold/90 shadow-[0_4px_14px_rgba(232,176,75,0.32)]"
            : "bg-gradient-to-b from-jade/90 to-jade/70 shadow-[0_4px_14px_rgba(75,182,160,0.3)]",
        )}
        style={{
          insetInlineStart: `calc(${(idx * 100) / n}% + 4px)`,
          width: `calc(${100 / n}% - 8px)`,
        }}
      />
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={cn(
              "press relative z-10 flex items-center justify-center gap-1.5 rounded-lg font-medium",
              size === "sm" ? "py-1.5" : "py-2",
              active ? "text-ink" : "text-mist hover:text-chalk",
            )}
          >
            {o.icon}
            <span className={cn(active && "font-bold")}>{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ Slider */
export function Slider({
  value,
  min,
  max,
  step = 1,
  onChange,
  label,
  hint,
  accent = "#e8b04b",
}: {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  label: ReactNode;
  hint?: ReactNode;
  accent?: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <span className="text-[13px] font-medium text-chalk/90">{label}</span>
        <span className="font-display text-[15px] leading-none text-gold2">
          {hint ?? value}
        </span>
      </div>
      <input
        className="slider"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        dir="rtl"
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ ["--pct" as string]: `${pct}%`, ["--fill-a" as string]: accent }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ Switch */
export function Switch({
  checked,
  onChange,
  label,
  note,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: ReactNode;
  note?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="press flex w-full items-center justify-between gap-4 rounded-xl px-1 py-2 text-start"
    >
      <span className="min-w-0">
        <span className="block text-[13px] font-medium text-chalk/90">{label}</span>
        {note && <span className="mt-0.5 block text-[11px] leading-5 text-mist">{note}</span>}
      </span>
      <span
        className={cn(
          "relative h-[26px] w-[46px] shrink-0 rounded-full border transition-colors duration-300",
          checked ? "border-gold/60 bg-gold/25" : "border-line bg-ink2",
        )}
      >
        <span
          className={cn(
            "absolute top-[2px] h-[20px] w-[20px] rounded-full transition-all duration-300",
            checked
              ? "bg-gradient-to-b from-gold2 to-gold shadow-[0_2px_8px_rgba(232,176,75,.5)]"
              : "bg-line",
          )}
          style={{ insetInlineStart: checked ? 2 : 24 }}
        />
      </span>
    </button>
  );
}

/* -------------------------------------------------------------------- Sheet */
export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const [mounted, setMounted] = useState(open);
  const [shown, setShown] = useState(false);

  useLayoutEffect(() => {
    if (open) {
      setMounted(true);
      const id = requestAnimationFrame(() => setShown(true));
      return () => cancelAnimationFrame(id);
    }
    setShown(false);
    const t = setTimeout(() => setMounted(false), 280);
    return () => clearTimeout(t);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!mounted) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div
        onClick={onClose}
        className={cn(
          "absolute inset-0 bg-ink/80 backdrop-blur-[3px] transition-opacity duration-300",
          shown ? "opacity-100" : "opacity-0",
        )}
      />
      <div
        className={cn(
          "relative flex max-h-[92dvh] w-full max-w-[560px] flex-col overflow-hidden rounded-t-3xl border-t border-line bg-panel shadow-[0_-24px_60px_rgba(0,0,0,.6)] transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]",
          shown ? "translate-y-0" : "translate-y-full",
        )}
      >
        <div className="flex items-start gap-3 px-5 pb-2 pt-3">
          <div className="min-w-0 flex-1">
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line" />
            <h2 className="font-display text-[22px] leading-tight text-chalk">{title}</h2>
            {subtitle && <p className="mt-0.5 text-[11.5px] text-mist">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="بستن"
            className="press mt-4 grid h-9 w-9 place-items-center rounded-full border border-line bg-ink2 text-mist hover:text-chalk"
          >
            <IconClose size={18} />
          </button>
        </div>
        <div className="thin-scroll flex-1 overflow-y-auto overscroll-contain px-5 pb-4">
          {children}
        </div>
        {footer && <div className="border-t border-line/70 bg-ink2/60 px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Button */
export function Btn({
  children,
  onClick,
  variant = "primary",
  className,
  type = "button",
  disabled,
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline" | "danger" | "jade";
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  title?: string;
}) {
  const styles: Record<string, string> = {
    primary:
      "bg-gradient-to-b from-gold2 to-gold text-ink shadow-[0_8px_24px_rgba(232,176,75,.28)] hover:shadow-[0_10px_30px_rgba(232,176,75,.42)] border border-gold2/40",
    jade: "bg-gradient-to-b from-jade to-jade/75 text-ink border border-jade/40 shadow-[0_8px_24px_rgba(75,182,160,.24)]",
    outline: "border border-line bg-panel2/60 text-chalk hover:border-gold/50 hover:text-gold2",
    ghost: "text-mist hover:text-chalk hover:bg-panel2/60 border border-transparent",
    danger: "border border-ember/40 bg-ember/12 text-ember hover:bg-ember/22",
  };
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "press inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-[13px] font-bold disabled:pointer-events-none disabled:opacity-40",
        styles[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

/* -------------------------------------------------------------------- Chip */
export function Chip({
  children,
  tone = "mist",
  className,
}: {
  children: ReactNode;
  tone?: "mist" | "gold" | "jade" | "ember";
  className?: string;
}) {
  const tones: Record<string, string> = {
    mist: "border-line bg-ink2/70 text-mist",
    gold: "border-gold/35 bg-gold/10 text-gold2",
    jade: "border-jade/35 bg-jade/10 text-jade",
    ember: "border-ember/35 bg-ember/10 text-ember",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-[3px] text-[10.5px] font-medium",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
