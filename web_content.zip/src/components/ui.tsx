import { useEffect, type ReactNode } from "react";
import { Check, Coins, Star, X } from "lucide-react";
import { cn } from "@/utils/cn";

export function Logo({ onClick, compact = false }: { onClick?: () => void; compact?: boolean }) {
  return (
    <button
      onClick={onClick}
      className="group flex items-center gap-2.5 text-left"
      aria-label="Stack Ball home"
    >
      <span className="relative flex h-10 w-10 items-center justify-center rounded-[13px] bg-gradient-to-br from-violet-400 via-[#7c5cff] to-[#3d1fb8] shadow-[0_10px_28px_-10px_rgba(124,92,255,0.95)] transition-transform duration-300 group-hover:scale-105">
        <svg viewBox="0 0 40 40" className="h-7 w-7" fill="none" aria-hidden>
          <ellipse cx="20" cy="27" rx="13" ry="4.8" fill="rgba(255,255,255,0.22)" />
          <ellipse cx="20" cy="27" rx="13" ry="4.8" stroke="rgba(255,255,255,0.55)" strokeWidth="1.2" />
          <ellipse cx="20" cy="22" rx="10.4" ry="3.9" fill="rgba(255,255,255,0.17)" />
          <ellipse cx="20" cy="22" rx="10.4" ry="3.9" stroke="rgba(255,255,255,0.42)" strokeWidth="1.1" />
          <ellipse cx="20" cy="17.4" rx="7.6" ry="2.9" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
          <circle cx="20" cy="10.5" r="5.1" fill="url(#ballLogo)" />
          <circle cx="18.3" cy="8.9" r="1.55" fill="white" fillOpacity="0.85" />
          <defs>
            <radialGradient id="ballLogo" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(18 8.5) rotate(52) scale(9)">
              <stop stopColor="#ffffff" />
              <stop offset="0.42" stopColor="#d5c8ff" />
              <stop offset="1" stopColor="#6a3cff" />
            </radialGradient>
          </defs>
        </svg>
        <span className="pointer-events-none absolute inset-0 rounded-[13px] ring-1 ring-inset ring-white/25" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[19px] font-extrabold tracking-tight text-white">
            STACK<span className="text-gradient">BALL</span>
          </span>
          <span className="mt-1 text-[8.5px] font-bold tracking-[0.32em] text-white/35">NEON DESCENT</span>
        </span>
      )}
    </button>
  );
}

export function CoinPill({ coins, className }: { coins: number; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-amber-200/25 bg-amber-300/10 px-3 py-1.5 text-[13px] font-extrabold text-amber-200 tabular",
        className,
      )}
      title="Coins"
    >
      <span className="flex h-4.5 w-4.5 items-center justify-center rounded-full bg-gradient-to-br from-amber-100 to-amber-400 text-amber-900 shadow-[0_0_12px_rgba(255,206,92,0.5)]">
        <Coins size={11} strokeWidth={2.6} />
      </span>
      {coins.toLocaleString("en-US")}
    </span>
  );
}

export function Stars({
  count,
  size = 14,
  className,
}: {
  count: number;
  size?: number;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-0.5", className)} aria-label={`${count} of 3 stars`}>
      {[1, 2, 3].map((i) => (
        <Star
          key={i}
          size={size}
          strokeWidth={2}
          className={i <= count ? "fill-amber-300 text-amber-300" : "text-white/20"}
          style={i <= count ? { filter: "drop-shadow(0 0 6px rgba(255,201,77,.55))" } : undefined}
        />
      ))}
    </span>
  );
}

export function ProgressBar({
  value,
  accent = "#8b6bff",
  height = 7,
  className,
}: {
  value: number;
  accent?: string;
  height?: number;
  className?: string;
}) {
  return (
    <div
      className={cn("w-full overflow-hidden rounded-full bg-white/8", className)}
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full rounded-full transition-[width] duration-500 ease-out"
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: `linear-gradient(90deg, ${accent}, ${accent}bb 60%, #38e8ff)`,
          boxShadow: `0 0 14px ${accent}90`,
        }}
      />
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      data-on={checked}
      className="switch"
      onClick={(e) => {
        e.stopPropagation();
        onChange(!checked);
      }}
    />
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  width = "max-w-lg",
  hideClose = false,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  subtitle?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  width?: string;
  hideClose?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div className="modal-backdrop absolute inset-0 anim-fade" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === "string" ? title : "Dialog"}
        className={cn(
          "glass-strong anim-pop relative z-10 max-h-[92vh] w-full overflow-hidden rounded-t-[26px] shadow-[0_40px_120px_-20px_rgba(0,0,0,0.9)] sm:rounded-[26px]",
          width,
        )}
      >
        <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-[radial-gradient(ellipse_at_top,rgba(124,92,255,.22),transparent_70%)]" />
        {(title || !hideClose) && (
          <div className="relative flex items-start justify-between gap-4 px-5 pb-3 pt-5 sm:px-7 sm:pt-6">
            <div>
              {title && <h2 className="font-display text-xl font-bold text-white sm:text-2xl">{title}</h2>}
              {subtitle && <p className="mt-1 text-[13px] leading-relaxed text-white/50">{subtitle}</p>}
            </div>
            {!hideClose && (
              <button
                onClick={onClose}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/60 transition hover:bg-white/10 hover:text-white"
                aria-label="Close dialog"
              >
                <X size={17} />
              </button>
            )}
          </div>
        )}
        <div className="relative max-h-[calc(92vh-120px)] overflow-y-auto px-5 pb-5 smooth-scroll sm:px-7 sm:pb-6 scroll-thin">
          {children}
        </div>
        {footer && <div className="relative border-t border-white/8 bg-black/20 px-5 py-4 sm:px-7">{footer}</div>}
      </div>
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  desc,
  action,
}: {
  eyebrow?: string;
  title: ReactNode;
  desc?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && (
          <div className="mb-2 flex items-center gap-2 text-[10.5px] font-extrabold uppercase tracking-[0.24em] text-violet-300/80">
            <span className="h-1 w-1 rounded-full bg-cyan-300 shadow-[0_0_8px_#38e8ff]" />
            {eyebrow}
          </div>
        )}
        <h2 className="font-display text-[26px] font-bold leading-tight text-white sm:text-[32px]">{title}</h2>
        {desc && <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-white/45">{desc}</p>}
      </div>
      {action}
    </div>
  );
}

export function Avatar({
  initials,
  tint,
  size = 36,
  ring = false,
}: {
  initials: string;
  tint: string;
  size?: number;
  ring?: boolean;
}) {
  return (
    <span
      className={cn(
        "relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full font-display font-bold text-white",
        ring && "ring-2 ring-white/25 ring-offset-2 ring-offset-[#0c0f1b]",
      )}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.33,
        background: `radial-gradient(circle at 30% 25%, ${tint}ee, ${tint}55 55%, #151827 100%)`,
        boxShadow: `inset 0 1px 0 rgba(255,255,255,.25), 0 4px 14px -6px ${tint}aa`,
      }}
    >
      {initials}
    </span>
  );
}

export function Toast({ message, tone = "ok" }: { message: string; tone?: "ok" | "warn" | "gold" }) {
  const color =
    tone === "warn" ? "text-coral" : tone === "gold" ? "text-amber-200" : "text-cyan-200";
  return (
    <div className="anim-pop fixed bottom-6 left-1/2 z-[100] -translate-x-1/2 px-4">
      <div className="glass-strong flex items-center gap-2.5 rounded-full px-4 py-2.5 shadow-[0_20px_60px_-20px_rgba(0,0,0,.9)]">
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br from-violet-400 to-cyan-400 text-black">
          <Check size={12} strokeWidth={3.5} />
        </span>
        <span className={cn("text-[12.5px] font-semibold", color)}>{message}</span>
      </div>
    </div>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="inline-flex min-w-6 items-center justify-center rounded-md border border-white/15 bg-white/8 px-1.5 py-0.5 font-sans text-[10px] font-bold text-white/70">
      {children}
    </kbd>
  );
}
