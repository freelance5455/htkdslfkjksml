import { X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Button({
  variant = "ghost",
  size = "md",
  className,
  ...p
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "outline" | "danger" | "soft"; size?: "sm" | "md" | "lg" }) {
  return (
    <button
      {...p}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none select-none",
        size === "sm" && "px-3 py-1.5 text-xs",
        size === "md" && "px-4 py-2 text-sm",
        size === "lg" && "px-6 py-3 text-base",
        variant === "primary" && "grad-bg text-white shadow-lg shadow-accent/20 hover:brightness-110",
        variant === "ghost" && "text-zinc-300 hover:bg-white/5",
        variant === "soft" && "bg-white/[0.06] text-zinc-100 hover:bg-white/10",
        variant === "outline" && "border border-white/10 text-zinc-200 hover:bg-white/5",
        variant === "danger" && "bg-red-500/10 text-red-400 hover:bg-red-500/20",
        className
      )}
    />
  );
}

export function IconBtn({ active, className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      {...p}
      className={cn(
        "grid h-9 w-9 place-items-center rounded-xl text-zinc-300 transition hover:bg-white/10 active:scale-95 disabled:opacity-30 disabled:pointer-events-none",
        active && "bg-accent/20 text-white",
        className
      )}
    />
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">{label}</span>
        {hint && <span className="text-[11px] text-zinc-500">{hint}</span>}
      </div>
      {children}
    </label>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 0.01,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <span className="text-xs text-zinc-400">{label}</span>
        <span className="font-mono text-[11px] text-zinc-500">{format ? format(value) : Math.round(value * 100) / 100}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </div>
  );
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-zinc-400">{label}</span>
      <div className="flex items-center gap-2">
        <span className="font-mono text-[11px] uppercase text-zinc-500">{value}</span>
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-8 w-10" />
      </div>
    </div>
  );
}

export function Select<T extends string | number>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; disabled?: boolean }[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => {
        const o = options.find((o) => String(o.value) === e.target.value)!;
        onChange(o.value);
      }}
      className="w-full rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-accent"
    >
      {options.map((o) => (
        <option key={String(o.value)} value={o.value} disabled={o.disabled}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function Segmented<T extends string | number>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode; disabled?: boolean; title?: string }[];
}) {
  return (
    <div className="flex rounded-xl bg-ink-700 p-1">
      {options.map((o) => (
        <button
          key={String(o.value)}
          title={o.title}
          disabled={o.disabled}
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-lg px-2 py-1.5 text-xs font-medium transition disabled:opacity-30",
            value === o.value ? "grad-bg text-white shadow" : "text-zinc-400 hover:text-white"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="flex w-full items-center justify-between py-1">
      <span className="text-xs text-zinc-400">{label}</span>
      <span className={cn("relative h-5 w-9 rounded-full transition", value ? "grad-bg" : "bg-ink-500")}>
        <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all", value ? "left-[18px]" : "left-0.5")} />
      </span>
    </button>
  );
}

export function TextInput(p: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...p}
      className={cn("w-full rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-accent", p.className)}
    />
  );
}

export function Section({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="border-b border-white/5 px-4 py-4">
      <div className="mb-3 flex items-center justify-between">
        <h4 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">{title}</h4>
        {right}
      </div>
      <div className="space-y-3.5">{children}</div>
    </section>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={cn("anim-pop max-h-[92vh] w-full overflow-y-auto rounded-2xl border border-white/10 bg-ink-800 shadow-2xl", wide ? "max-w-2xl" : "max-w-md")}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/5 bg-ink-800 px-5 py-4">
          <h3 className="font-semibold">{title}</h3>
          <IconBtn onClick={onClose}>
            <X size={18} />
          </IconBtn>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function Toast({ msg }: { msg: string | null }) {
  if (!msg) return null;
  return (
    <div className="anim-pop fixed bottom-20 left-1/2 z-[60] -translate-x-1/2 rounded-full border border-white/10 bg-ink-600 px-4 py-2 text-sm text-white shadow-xl">
      {msg}
    </div>
  );
}
