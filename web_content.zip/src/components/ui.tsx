import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, X, Star, type LucideIcon } from "lucide-react";
import { AVATAR_GRADIENTS } from "../data/mockData";

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

/* ---------------- Buttons ---------------- */

type BtnVariant = "primary" | "secondary" | "ghost" | "outline" | "danger" | "dark";
type BtnSize = "sm" | "md" | "lg";

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  className = "",
  disabled,
  icon: Icon,
  iconRight: IconRight,
  type = "button",
  fullWidth,
}: {
  children?: React.ReactNode;
  onClick?: () => void;
  variant?: BtnVariant;
  size?: BtnSize;
  className?: string;
  disabled?: boolean;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  type?: "button" | "submit";
  fullWidth?: boolean;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 font-display font-semibold rounded-2xl transition-all active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none select-none";
  const sizes: Record<BtnSize, string> = {
    sm: "text-sm px-4 py-2.5",
    md: "text-[15px] px-5 py-3.5",
    lg: "text-base px-6 py-4",
  };
  const variants: Record<BtnVariant, string> = {
    primary:
      "bg-saffron text-white shadow-lg shadow-saffron/30 hover:bg-saffron-dark",
    secondary:
      "bg-ink text-offwhite dark:bg-offwhite dark:text-ink hover:opacity-90",
    outline:
      "border-2 border-ink/15 dark:border-white/15 text-ink dark:text-offwhite hover:border-saffron/60 bg-transparent",
    ghost: "text-ink dark:text-offwhite hover:bg-ink/5 dark:hover:bg-white/10",
    danger: "bg-red-500 text-white hover:bg-red-600",
    dark: "bg-navy text-white hover:bg-navy/90",
  };
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cx(base, sizes[size], variants[variant], fullWidth && "w-full", className)}
    >
      {Icon && <Icon size={18} strokeWidth={2.4} />}
      {children}
      {IconRight && <IconRight size={18} strokeWidth={2.4} />}
    </motion.button>
  );
}

/* ---------------- Cards ---------------- */

export function Card({
  children,
  className = "",
  onClick,
  interactive,
}: {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  interactive?: boolean;
}) {
  const Comp: any = interactive || onClick ? motion.div : "div";
  const extra = interactive || onClick ? { whileTap: { scale: 0.98 }, whileHover: { y: -2 } } : {};
  return (
    <Comp
      onClick={onClick}
      {...extra}
      className={cx(
        "rounded-[22px] bg-white dark:bg-ink-soft border border-ink/5 dark:border-white/8 shram-card-shadow",
        (onClick || interactive) && "cursor-pointer",
        className
      )}
    >
      {children}
    </Comp>
  );
}

/* ---------------- Badge / Chip ---------------- */

export function Badge({
  children,
  tone = "neutral",
  className = "",
  size = "md",
}: {
  children: React.ReactNode;
  tone?: "neutral" | "success" | "warning" | "info" | "saffron" | "dark";
  className?: string;
  size?: "sm" | "md";
}) {
  const tones: Record<string, string> = {
    neutral: "bg-ink/5 text-ink dark:bg-white/10 dark:text-offwhite",
    success: "bg-lime/20 text-lime-dark dark:bg-lime/15 dark:text-lime",
    warning: "bg-amber-100 text-amber-700 dark:bg-amber-400/15 dark:text-amber-300",
    info: "bg-cyan/15 text-cyan-dark dark:bg-cyan/15 dark:text-cyan",
    saffron: "bg-saffron/12 text-saffron-dark dark:text-saffron-light",
    dark: "bg-ink text-offwhite dark:bg-white dark:text-ink",
  };
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded-full font-semibold",
        size === "sm" ? "text-[11px] px-2.5 py-1" : "text-xs px-3 py-1.5",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function Chip({
  children,
  active,
  onClick,
  className = "",
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "whitespace-nowrap rounded-full border px-4 py-2 text-sm font-semibold transition-all active:scale-95",
        active
          ? "bg-ink text-offwhite border-ink dark:bg-offwhite dark:text-ink dark:border-offwhite"
          : "border-ink/12 text-ink/70 dark:border-white/15 dark:text-offwhite/70 hover:border-ink/30",
        className
      )}
    >
      {children}
    </button>
  );
}

/* ---------------- Avatar ---------------- */

export function Avatar({
  initials,
  color = "saffron",
  size = "md",
  verified,
  className = "",
}: {
  initials: string;
  color?: string;
  size?: "sm" | "md" | "lg" | "xl";
  verified?: boolean;
  className?: string;
}) {
  const sizes = { sm: "h-9 w-9 text-xs", md: "h-12 w-12 text-sm", lg: "h-20 w-20 text-xl", xl: "h-28 w-28 text-3xl" };
  const grad = AVATAR_GRADIENTS[color] || AVATAR_GRADIENTS.saffron;
  return (
    <div className={cx("relative inline-flex shrink-0", className)}>
      <div
        className={cx(
          "flex items-center justify-center rounded-full bg-gradient-to-br font-display font-bold text-white",
          grad,
          sizes[size]
        )}
      >
        {initials}
      </div>
      {verified && (
        <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-lime text-[9px] text-ink ring-2 ring-white dark:ring-ink-soft">
          ✓
        </span>
      )}
    </div>
  );
}

/* ---------------- Progress Ring (SHRAM Score) ---------------- */

export function ScoreRing({
  value,
  size = 160,
  stroke = 14,
  label = "SHRAM SCORE",
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
}) {
  const [animated, setAnimated] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setAnimated(value), 120);
    return () => clearTimeout(t);
  }, [value]);
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (animated / 100) * c;
  const tier = value >= 90 ? "Excellent" : value >= 75 ? "Good" : value >= 50 ? "Fair" : "Building";
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="currentColor" strokeWidth={stroke} fill="none" className="text-ink/8 dark:text-white/10" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#scoreGrad)"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
        />
        <defs>
          <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ff6a1a" />
            <stop offset="100%" stopColor="#a4f02a" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-display text-4xl font-extrabold tabular-nums">{Math.round(animated)}</span>
        <span className="text-[10px] font-bold tracking-wider text-ink/50 dark:text-white/50">{label}</span>
        <span className="mt-1 text-xs font-semibold text-lime-dark dark:text-lime">{tier}</span>
      </div>
    </div>
  );
}

/* ---------------- Status / Timeline ---------------- */

export interface TimelineStep {
  label: string;
  state: "done" | "active" | "pending";
}

export function StatusTimeline({ steps }: { steps: TimelineStep[] }) {
  return (
    <div className="flex flex-col">
      {steps.map((step, i) => (
        <div key={step.label} className="flex gap-3">
          <div className="flex flex-col items-center">
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: i * 0.08 }}
              className={cx(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                step.state === "done" && "bg-lime text-ink",
                step.state === "active" && "bg-saffron text-white animate-pulse-soft",
                step.state === "pending" && "bg-ink/8 text-ink/30 dark:bg-white/10 dark:text-white/30"
              )}
            >
              {step.state === "done" ? "✓" : i + 1}
            </motion.div>
            {i < steps.length - 1 && (
              <div
                className={cx(
                  "my-0.5 w-0.5 flex-1",
                  step.state === "done" ? "bg-lime" : "bg-ink/10 dark:bg-white/10"
                )}
                style={{ minHeight: 28 }}
              />
            )}
          </div>
          <div className="pb-7">
            <p
              className={cx(
                "font-display text-[15px] font-semibold",
                step.state === "pending" && "text-ink/35 dark:text-white/35"
              )}
            >
              {step.label}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Bottom Sheet ---------------- */

export function BottomSheet({
  open,
  onClose,
  children,
  title,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-ink/50 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 300 }}
            className="fixed bottom-0 left-1/2 z-50 w-full max-w-[480px] -translate-x-1/2 rounded-t-[28px] bg-white dark:bg-ink-soft px-5 pb-8 pt-3 shram-card-shadow max-h-[85vh] overflow-y-auto no-scrollbar"
          >
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-ink/15 dark:bg-white/20" />
            {title && (
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-display text-lg font-bold">{title}</h3>
                <button onClick={onClose} className="rounded-full p-1.5 hover:bg-ink/5 dark:hover:bg-white/10">
                  <X size={20} />
                </button>
              </div>
            )}
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ---------------- Modal ---------------- */

export function Modal({
  open,
  onClose,
  children,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-ink/60 backdrop-blur-sm"
          />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 24, stiffness: 320 }}
              className="w-full max-w-sm rounded-[26px] bg-white dark:bg-ink-soft p-6 shram-card-shadow"
            >
              {children}
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ---------------- Toasts ---------------- */

export function ToastStack({
  toasts,
  onDismiss,
}: {
  toasts: { id: string; kind: "success" | "error" | "info"; message: string }[];
  onDismiss: (id: string) => void;
}) {
  return (
    <div className="pointer-events-none fixed top-4 left-1/2 z-[100] flex w-full max-w-[440px] -translate-x-1/2 flex-col gap-2 px-4">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -24, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.95 }}
            onClick={() => onDismiss(t.id)}
            className={cx(
              "pointer-events-auto flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur-md",
              t.kind === "success" && "bg-ink text-lime dark:bg-white dark:text-lime-dark",
              t.kind === "error" && "bg-red-500 text-white",
              t.kind === "info" && "bg-navy text-cyan"
            )}
          >
            {t.kind === "success" ? "✓" : t.kind === "error" ? "!" : "ℹ"} {t.message}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

/* ---------------- Header / TopBar ---------------- */

export function TopBar({
  title,
  onBack,
  right,
  transparent,
}: {
  title?: string;
  onBack?: () => void;
  right?: React.ReactNode;
  transparent?: boolean;
}) {
  return (
    <div
      className={cx(
        "sticky top-0 z-30 flex items-center gap-3 px-5 py-4",
        !transparent && "bg-offwhite/85 dark:bg-ink/85 backdrop-blur-md border-b border-ink/5 dark:border-white/5"
      )}
    >
      {onBack && (
        <button
          onClick={onBack}
          className="flex h-9 w-9 items-center justify-center rounded-full bg-ink/5 dark:bg-white/10 active:scale-90 transition-transform"
        >
          <ChevronLeft size={20} />
        </button>
      )}
      {title && <h1 className="font-display text-lg font-bold flex-1 truncate">{title}</h1>}
      {right}
    </div>
  );
}

/* ---------------- Star Rating ---------------- */

export function StarRating({
  value,
  onChange,
  size = 28,
  readOnly,
}: {
  value: number;
  onChange?: (v: number) => void;
  size?: number;
  readOnly?: boolean;
}) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          disabled={readOnly}
          onClick={() => onChange?.(i)}
          className={cx("transition-transform", !readOnly && "active:scale-90")}
        >
          <Star
            size={size}
            className={i <= value ? "fill-saffron text-saffron" : "fill-transparent text-ink/20 dark:text-white/20"}
          />
        </button>
      ))}
    </div>
  );
}

/* ---------------- Search Bar ---------------- */

export function SearchBar({
  value,
  onChange,
  placeholder = "Search",
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <div className={cx("flex items-center gap-2.5 rounded-2xl bg-ink/5 dark:bg-white/8 px-4 py-3.5", className)}>
      <span className="text-ink/40 dark:text-white/40">⌕</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="flex-1 bg-transparent text-[15px] outline-none placeholder:text-ink/40 dark:placeholder:text-white/40"
      />
    </div>
  );
}

/* ---------------- Empty State ---------------- */

export function EmptyState({
  icon = "🔍",
  title,
  description,
  action,
}: {
  icon?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-8 py-16 text-center">
      <div className="text-5xl">{icon}</div>
      <h3 className="font-display text-lg font-bold">{title}</h3>
      {description && <p className="text-sm text-ink/55 dark:text-white/55 max-w-xs">{description}</p>}
      {action}
    </div>
  );
}

/* ---------------- Demo Mode Badge ---------------- */

export function DemoBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1.5 rounded-full border border-saffron/30 bg-saffron/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-saffron-dark dark:text-saffron-light",
        className
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-saffron animate-pulse-soft" /> Demo Mode
    </span>
  );
}

/* ---------------- Section Header ---------------- */

export function SectionHeader({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string;
  title: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-end justify-between mb-3">
      <div>
        {eyebrow && <p className="text-[11px] font-bold uppercase tracking-wider text-saffron-dark dark:text-saffron-light mb-1">{eyebrow}</p>}
        <h2 className="font-display text-xl font-bold">{title}</h2>
      </div>
      {action}
    </div>
  );
}
