import {
  createContext, useCallback, useContext, useEffect, useId, useMemo, useState,
  type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, CheckCircle2, Info, Loader2, X, XCircle } from 'lucide-react';
import { cn } from '../lib/utils';

/* ----------------------------- buttons ----------------------------- */

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

export function Button({
  variant = 'primary', loading, className, children, ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; loading?: boolean }) {
  return (
    <button
      {...props}
      disabled={props.disabled || loading}
      className={cn(variant === 'primary' && 'btn-primary', variant === 'secondary' && 'btn-secondary', variant === 'ghost' && 'btn-ghost', variant === 'danger' && 'btn-danger', className)}
    >
      {loading && <Loader2 size={16} className="animate-spin" />}
      {children}
    </button>
  );
}

export function IconButton({ label, className, children, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      {...props}
      aria-label={label}
      title={label}
      className={cn('grid h-9 w-9 place-items-center rounded-lg text-muted transition hover:bg-elevated hover:text-ink', className)}
    >
      {children}
    </button>
  );
}

/* ------------------------------ cards ------------------------------ */

export function Card({ className, children, ...rest }: { className?: string; children: ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...rest} className={cn('card p-5', className)}>
      {children}
    </div>
  );
}

export function SectionHeading({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h2 className="font-display text-lg font-bold tracking-tight text-ink">{title}</h2>
        {subtitle && <p className="mt-0.5 text-sm text-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

/* ------------------------------ inputs ----------------------------- */

export function Field({ label, hint, error, required, children }: { label?: string; hint?: string; error?: string; required?: boolean; children: ReactNode }) {
  return (
    <label className="block">
      {label && (
        <span className="label">
          {label} {required && <span className="text-bad">*</span>}
        </span>
      )}
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-muted">{hint}</span>}
      {error && <span className="mt-1 block text-xs font-medium text-bad">{error}</span>}
    </label>
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn('field', className)} />;
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn('field min-h-[96px] resize-y', className)} />;
}

export function Select({ className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...props} className={cn('field appearance-none bg-[length:14px] bg-[right_12px_center] bg-no-repeat pr-9', className)}
      style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2391a2be' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")" }}
    >
      {children}
    </select>
  );
}

export function Checkbox({ label, checked, onChange, disabled }: { label: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <label className={cn('flex cursor-pointer items-center gap-2.5 text-sm text-ink', disabled && 'cursor-not-allowed opacity-60')}>
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-line bg-elevated text-brand focus:ring-brand/40"
      />
      {label}
    </label>
  );
}

/* ------------------------------ badges ----------------------------- */

export function Badge({ children, tone = 'neutral', className }: { children: ReactNode; tone?: 'neutral' | 'brand' | 'ok' | 'warn' | 'bad'; className?: string }) {
  const tones = {
    neutral: 'border-line bg-elevated/70 text-muted',
    brand: 'border-brand/30 bg-brand/10 text-brand',
    ok: 'border-ok/30 bg-ok/10 text-ok',
    warn: 'border-warn/30 bg-warn/10 text-warn',
    bad: 'border-bad/30 bg-bad/10 text-bad',
  };
  return <span className={cn('inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold', tones[tone], className)}>{children}</span>;
}

/* ----------------------------- progress ---------------------------- */

export function ProgressBar({ value, tone = 'brand', className, height = 'h-2' }: { value: number; tone?: 'brand' | 'ok' | 'warn' | 'bad'; className?: string; height?: string }) {
  const colors = { brand: 'bg-brand', ok: 'bg-ok', warn: 'bg-warn', bad: 'bg-bad' };
  return (
    <div className={cn('w-full overflow-hidden rounded-full bg-line/60', height, className)}>
      <div className={cn('h-full rounded-full transition-all duration-500', colors[tone])} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Ring({ value, size = 96, stroke = 8, label, sub }: { value: number; size?: number; stroke?: number; label?: string; sub?: string }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.max(0, Math.min(100, value)) / 100) * circumference;
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} strokeWidth={stroke} className="stroke-line/60" fill="none" />
        <circle
          cx={size / 2} cy={size / 2} r={radius} strokeWidth={stroke} fill="none" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          className="stroke-brand transition-all duration-700"
        />
      </svg>
      <div className="absolute text-center">
        <div className="font-display text-xl font-bold text-ink">{label ?? `${Math.round(value)}%`}</div>
        {sub && <div className="text-[10px] uppercase tracking-wide text-muted">{sub}</div>}
      </div>
    </div>
  );
}

/* ------------------------------ modal ------------------------------ */

export function Modal({ open, onClose, title, description, children, footer, size = 'md' }: {
  open: boolean; onClose: () => void; title: string; description?: string; children: ReactNode; footer?: ReactNode; size?: 'sm' | 'md' | 'lg';
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open, onClose]);

  if (!open) return null;
  const widths = { sm: 'max-w-md', md: 'max-w-xl', lg: 'max-w-3xl' };
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0" onClick={onClose} aria-hidden />
      <div className={cn('relative z-10 w-full animate-fade-up rounded-t-3xl border border-line bg-surface p-5 shadow-2xl sm:rounded-2xl', widths[size])}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-bold text-ink">{title}</h3>
            {description && <p className="mt-1 text-sm text-muted">{description}</p>}
          </div>
          <IconButton label="Close" onClick={onClose}><X size={18} /></IconButton>
        </div>
        <div className="max-h-[70vh] overflow-y-auto pr-1">{children}</div>
        {footer && <div className="mt-5 flex flex-wrap justify-end gap-2">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

/* ----------------------------- feedback ---------------------------- */

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-10 text-sm text-muted">
      <Loader2 size={18} className="animate-spin text-brand" />
      {label ?? 'Loading…'}
    </div>
  );
}

export function EmptyState({ icon, title, description, action }: { icon?: ReactNode; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-line bg-elevated/30 px-6 py-14 text-center">
      {icon && <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand">{icon}</div>}
      <h3 className="font-display text-base font-bold text-ink">{title}</h3>
      {description && <p className="mt-1.5 max-w-md text-sm text-muted">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Banner({ tone = 'info', title, children, action }: { tone?: 'info' | 'warn' | 'bad' | 'ok'; title?: string; children?: ReactNode; action?: ReactNode }) {
  const icons = { info: Info, warn: AlertTriangle, bad: XCircle, ok: CheckCircle2 };
  const tones = {
    info: 'border-brand/30 bg-brand/10 text-brand',
    warn: 'border-warn/30 bg-warn/10 text-warn',
    bad: 'border-bad/30 bg-bad/10 text-bad',
    ok: 'border-ok/30 bg-ok/10 text-ok',
  };
  const Icon = icons[tone];
  return (
    <div className={cn('flex items-start gap-3 rounded-xl border p-3.5 text-sm', tones[tone])}>
      <Icon size={17} className="mt-0.5 shrink-0" />
      <div className="flex-1 text-ink/90">
        {title && <div className="font-semibold text-ink">{title}</div>}
        {children && <div className={cn('text-sm', title && 'mt-0.5')}>{children}</div>}
      </div>
      {action}
    </div>
  );
}

export function SetupCard({ message }: { message?: string }) {
  return (
    <Banner tone="warn" title="AI features need an API key">
      <p>
        {message || 'Add OPENAI_API_KEY to this project under Settings → Secrets, then reload. The tutor, document analysis and AI question generation stay disabled until a key is present; everything else works without it.'}
      </p>
    </Banner>
  );
}

/* ------------------------------ tabs ------------------------------- */

export function Tabs<T extends string>({ tabs, value, onChange, className }: { tabs: { value: T; label: string; count?: number }[]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div className={cn('inline-flex flex-wrap gap-1 rounded-xl border border-line bg-elevated/50 p-1', className)} role="tablist">
      {tabs.map((tab) => (
        <button
          key={tab.value}
          role="tab"
          aria-selected={value === tab.value}
          onClick={() => onChange(tab.value)}
          className={cn(
            'rounded-lg px-3 py-1.5 text-sm font-medium transition',
            value === tab.value ? 'bg-brand text-white shadow' : 'text-muted hover:text-ink',
          )}
        >
          {tab.label}
          {typeof tab.count === 'number' && <span className="ml-1.5 opacity-80">{tab.count}</span>}
        </button>
      ))}
    </div>
  );
}

/* ----------------------------- toasts ------------------------------ */

type Toast = { id: number; message: string; tone: 'info' | 'ok' | 'bad' | 'warn' };
const ToastContext = createContext<{ push: (message: string, tone?: Toast['tone']) => void } | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((message: string, tone: Toast['tone'] = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);
  const value = useMemo(() => ({ push }), [push]);
  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(92vw,22rem)] flex-col gap-2">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={cn(
              'pointer-events-auto animate-fade-up rounded-xl border p-3.5 text-sm shadow-xl backdrop-blur',
              toast.tone === 'ok' && 'border-ok/40 bg-ok/15 text-ink',
              toast.tone === 'bad' && 'border-bad/40 bg-bad/15 text-ink',
              toast.tone === 'warn' && 'border-warn/40 bg-warn/15 text-ink',
              toast.tone === 'info' && 'border-line bg-elevated text-ink',
            )}
          >
            {toast.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) return { push: () => undefined };
  return ctx;
}

/* --------------------------- misc pieces --------------------------- */

export function StatCard({ label, value, hint, icon, tone = 'brand', onClick }: { label: string; value: ReactNode; hint?: string; icon?: ReactNode; tone?: 'brand' | 'ok' | 'warn' | 'bad'; onClick?: () => void }) {
  const tones = { brand: 'bg-brand/10 text-brand', ok: 'bg-ok/10 text-ok', warn: 'bg-warn/10 text-warn', bad: 'bg-bad/10 text-bad' };
  return (
    <div
      className={cn('card flex items-start justify-between gap-3 p-4', onClick && 'card-hover cursor-pointer')}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => { if (e.key === 'Enter') onClick(); } : undefined}
    >
      <div>
        <div className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</div>
        <div className="mt-1.5 font-display text-2xl font-bold text-ink">{value}</div>
        {hint && <div className="mt-0.5 text-xs text-muted">{hint}</div>}
      </div>
      {icon && <div className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl', tones[tone])}>{icon}</div>}
    </div>
  );
}

export function ConfirmDialog({ open, title, body, confirmLabel = 'Confirm', onConfirm, onCancel, danger }: {
  open: boolean; title: string; body: string; confirmLabel?: string; onConfirm: () => void; onCancel: () => void; danger?: boolean;
}) {
  const id = useId();
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={title}
      footer={
        <>
          <Button variant="secondary" onClick={onCancel}>Cancel</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} id={id}>{confirmLabel}</Button>
        </>
      }
    >
      <p className="text-sm text-muted">{body}</p>
    </Modal>
  );
}
