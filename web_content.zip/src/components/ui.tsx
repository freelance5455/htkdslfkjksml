import type { ReactNode } from "react";

export const btnGold =
  "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gold px-5 text-sm font-medium text-ink transition-colors duration-200 hover:bg-gold-2";

export const btnGhost =
  "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold";

export const btnQuiet =
  "inline-flex h-11 items-center justify-center rounded-full px-3 text-sm text-muted transition-colors duration-200 hover:text-fg";

export function Choice({
  selected,
  locked,
  correct,
  wrong,
  children,
  onClick,
}: {
  selected: boolean;
  locked: boolean;
  correct?: boolean;
  wrong?: boolean;
  children: ReactNode;
  onClick: () => void;
}) {
  const tone = correct
    ? "border-gold bg-surface-2 text-fg"
    : wrong
      ? "border-line bg-bg text-faint"
      : selected
        ? "border-gold text-fg"
        : "border-line text-fg hover:border-gold";
  return (
    <button
      type="button"
      disabled={locked && !selected}
      onClick={onClick}
      className={`w-full rounded-2xl border px-4 py-3 text-left text-base transition-colors duration-200 disabled:cursor-default ${tone}`}
    >
      {children}
    </button>
  );
}
