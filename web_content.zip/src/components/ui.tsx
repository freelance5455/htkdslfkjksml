"use client";

import Link from "next/link";
import {
  Accessibility,
  Activity,
  Ambulance,
  Bandage,
  Baby,
  BadgeCheck,
  Bed,
  Clock,
  ClipboardPlus,
  Droplets,
  HeartHandshake,
  HeartPulse,
  Inbox,
  Loader2,
  Pill,
  Star,
  Stethoscope,
  Syringe,
  Thermometer,
  UserRound,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ButtonHTMLAttributes, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { useI18n } from "@/components/providers";
import type { L10n } from "@/lib/types";
import { cn, initials } from "@/lib/utils";

/* ---------------------------- Buttons ---------------------------- */

export type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "whatsapp";
export type ButtonSize = "sm" | "md" | "lg";

export function buttonClass(variant: ButtonVariant = "primary", size: ButtonSize = "md", extra?: string) {
  return cn(
    "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60 active:scale-[0.98]",
    size === "sm" && "px-3 py-1.5 text-xs",
    size === "md" && "px-4 py-2.5 text-sm",
    size === "lg" && "px-6 py-3.5 text-base",
    variant === "primary" && "bg-gradient-to-r from-teal-500 to-sky-500 text-white shadow-md shadow-teal-500/20 hover:shadow-lg hover:brightness-105",
    variant === "secondary" && "bg-teal-50 text-teal-700 hover:bg-teal-100",
    variant === "outline" && "bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50",
    variant === "ghost" && "text-slate-600 hover:bg-slate-100",
    variant === "danger" && "bg-rose-50 text-rose-700 ring-1 ring-rose-200 hover:bg-rose-100",
    variant === "whatsapp" && "bg-emerald-500 text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-600",
    extra,
  );
}

export function Button({
  variant,
  size,
  loading,
  className,
  children,
  disabled,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; size?: ButtonSize; loading?: boolean }) {
  return (
    <button type="button" className={buttonClass(variant, size, className)} disabled={disabled || loading} {...rest}>
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}

/* ---------------------------- Layout primitives ---------------------------- */

export function Card({ className, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("rounded-2xl bg-white p-5 shadow-sm ring-1 ring-sky-100/80 sm:p-6", className)} {...rest}>
      {children}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600 sm:text-base">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function SectionTitle({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-center justify-between gap-3">
      <h2 className="text-lg font-semibold text-slate-900 sm:text-xl">{title}</h2>
      {action}
    </div>
  );
}

const TONES = {
  sky: "bg-sky-50 text-sky-700 ring-sky-200",
  teal: "bg-teal-50 text-teal-700 ring-teal-200",
  green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  amber: "bg-amber-50 text-amber-800 ring-amber-200",
  red: "bg-rose-50 text-rose-700 ring-rose-200",
  slate: "bg-slate-100 text-slate-600 ring-slate-200",
} as const;

export function Badge({
  tone = "slate",
  className,
  children,
}: {
  tone?: keyof typeof TONES;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ring-1", TONES[tone], className)}>
      {children}
    </span>
  );
}

const STATUS_TONE = { pending: "amber", confirmed: "sky", completed: "green", cancelled: "red" } as const;

export function StatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  const tone = STATUS_TONE[status as keyof typeof STATUS_TONE] ?? "slate";
  return <Badge tone={tone}>{t(`status.${status}`)}</Badge>;
}

export function VerificationBadge({ status }: { status: string }) {
  const { t } = useI18n();
  if (status === "verified")
    return (
      <Badge tone="green">
        <BadgeCheck className="h-3.5 w-3.5" />
        {t("pro.verified")}
      </Badge>
    );
  if (status === "rejected") return <Badge tone="red">{t("pro.rejected")}</Badge>;
  return (
    <Badge tone="amber">
      <Clock className="h-3.5 w-3.5" />
      {t("pro.pending")}
    </Badge>
  );
}

/* ---------------------------- Forms ---------------------------- */

export const inputClass =
  "block w-full rounded-xl border border-slate-200 bg-white ps-3.5 pe-3.5 py-2.5 text-sm text-slate-900 shadow-sm placeholder:text-slate-400 transition focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/15 disabled:bg-slate-50 disabled:text-slate-500";

export function Field({
  label,
  htmlFor,
  hint,
  error,
  children,
  className,
}: {
  label?: string;
  htmlFor?: string;
  hint?: string;
  error?: string | null;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      {label && (
        <label htmlFor={htmlFor} className="block text-sm font-medium text-slate-700">
          {label}
        </label>
      )}
      {children}
      {hint && !error && <p className="text-xs text-slate-500">{hint}</p>}
      {error && <p className="text-xs font-medium text-rose-600">{error}</p>}
    </div>
  );
}

export function Input({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(inputClass, className)} {...rest} />;
}

export function Textarea({ className, rows = 4, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea rows={rows} className={cn(inputClass, "resize-y", className)} {...rest} />;
}

export function Select({ className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select className={cn(inputClass, "pe-9", className)} {...rest}>
      {children}
    </select>
  );
}

export function Checkbox({ checked, onChange, label, id }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; id?: string }) {
  return (
    <label htmlFor={id} className="flex cursor-pointer items-start gap-3 text-sm text-slate-700">
      <input
        id={id}
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
      />
      <span className="leading-relaxed">{label}</span>
    </label>
  );
}

export function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "shrink-0 rounded-full px-3.5 py-1.5 text-sm font-medium ring-1 transition",
        active ? "bg-teal-600 text-white ring-teal-600 shadow-sm" : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50",
      )}
    >
      {children}
    </button>
  );
}

export function Tabs<T extends string>({
  items,
  value,
  onChange,
  className,
}: {
  items: Array<{ value: T; label: string; icon?: LucideIcon; count?: number }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div role="tablist" className={cn("flex gap-1 overflow-x-auto rounded-2xl bg-slate-100/80 p-1", className)}>
      {items.map((item) => {
        const active = item.value === value;
        const Icon = item.icon;
        return (
          <button
            key={item.value}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(item.value)}
            className={cn(
              "flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition",
              active ? "bg-white text-teal-700 shadow-sm" : "text-slate-600 hover:text-slate-900",
            )}
          >
            {Icon && <Icon className="h-4 w-4" />}
            {item.label}
            {item.count !== undefined && (
              <span className="rounded-full bg-slate-200/80 px-2 text-xs text-slate-700">{item.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------- Feedback ---------------------------- */

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-5 w-5 animate-spin text-teal-600", className)} aria-hidden />;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-xl bg-slate-200/70", className)} />;
}

export function CardSkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-sky-100/80">
      <Skeleton className="mb-4 h-10 w-10 rounded-xl" />
      <Skeleton className="mb-3 h-5 w-3/4" />
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} className={cn("mb-2 h-3.5", i === lines - 1 ? "w-1/2" : "w-full")} />
      ))}
    </div>
  );
}

export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
}: {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-sky-200 bg-sky-50/40 px-6 py-12 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-sky-500 shadow-sm">
        <Icon className="h-7 w-7" />
      </div>
      <p className="font-semibold text-slate-800">{title}</p>
      {description && <p className="mt-1 max-w-md text-sm text-slate-600">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  const { t } = useI18n();
  return (
    <div className="rounded-2xl bg-rose-50 p-6 text-center ring-1 ring-rose-100">
      <p className="text-sm font-medium text-rose-800">{message}</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="mt-3 text-sm font-semibold text-rose-700 underline">
          {t("common.retry")}
        </button>
      )}
    </div>
  );
}

export function Alert({ tone = "info", children }: { tone?: "info" | "warning" | "success" | "danger"; children: ReactNode }) {
  const cls = {
    info: "bg-sky-50 text-sky-900 ring-sky-100",
    warning: "bg-amber-50 text-amber-900 ring-amber-100",
    success: "bg-emerald-50 text-emerald-900 ring-emerald-100",
    danger: "bg-rose-50 text-rose-900 ring-rose-100",
  }[tone];
  return <div className={cn("rounded-2xl px-4 py-3 text-sm leading-relaxed ring-1", cls)}>{children}</div>;
}

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label="Close" onClick={onClose} className="animate-fade-in absolute inset-0 bg-slate-900/40 backdrop-blur-sm" />
      <div
        className={cn(
          "animate-sheet-up relative flex max-h-[92vh] w-full flex-col rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-lg",
        )}
      >
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-full p-1.5 text-slate-500 hover:bg-slate-100">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-3 border-t border-slate-100 px-6 py-4">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------------------------- Display helpers ---------------------------- */

export function Stars({ value, size = 16, className }: { value: number; size?: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-0.5", className)} aria-label={`${value}/5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          width={size}
          height={size}
          className={cn(i <= Math.round(value) ? "fill-amber-400 text-amber-400" : "text-slate-300")}
        />
      ))}
    </span>
  );
}

export function Avatar({ src, name, className }: { src?: string; name: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (src && !failed) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={name}
        onError={() => setFailed(true)}
        className={cn("h-16 w-16 rounded-2xl object-cover ring-2 ring-white shadow", className)}
      />
    );
  }
  return (
    <div className={cn("flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-400 to-sky-500 text-lg font-bold text-white shadow", className)}>
      {initials(name) || <UserRound className="h-6 w-6" />}
    </div>
  );
}

const ICONS: Record<string, LucideIcon> = {
  stethoscope: Stethoscope,
  bandage: Bandage,
  syringe: Syringe,
  activity: Activity,
  "heart-pulse": HeartPulse,
  baby: Baby,
  accessibility: Accessibility,
  droplets: Droplets,
  "heart-handshake": HeartHandshake,
  "clipboard-plus": ClipboardPlus,
  bed: Bed,
  pill: Pill,
  thermometer: Thermometer,
  ambulance: Ambulance,
  "user-round": UserRound,
};

export function ServiceIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICONS[name] ?? Stethoscope;
  return <Icon className={className} />;
}

export const SERVICE_ICON_OPTIONS = Object.keys(ICONS);

export function LocalizedFields({
  label,
  value,
  onChange,
  multiline = false,
  rows = 3,
  hint,
}: {
  label: string;
  value: L10n;
  onChange: (v: L10n) => void;
  multiline?: boolean;
  rows?: number;
  hint?: string;
}) {
  const langs: Array<{ key: keyof L10n; label: string; dir: "ltr" | "rtl" }> = [
    { key: "fr", label: "Français", dir: "ltr" },
    { key: "en", label: "English", dir: "ltr" },
    { key: "ar", label: "العربية", dir: "rtl" },
  ];
  return (
    <div className="space-y-3">
      <div>
        <p className="text-sm font-semibold text-slate-800">{label}</p>
        {hint && <p className="text-xs text-slate-500">{hint}</p>}
      </div>
      {langs.map((l) => (
        <Field key={l.key} label={l.label} htmlFor={`${label}-${l.key}`}>
          {multiline ? (
            <Textarea
              id={`${label}-${l.key}`}
              dir={l.dir}
              rows={rows}
              value={value[l.key]}
              onChange={(e) => onChange({ ...value, [l.key]: e.target.value })}
            />
          ) : (
            <Input
              id={`${label}-${l.key}`}
              dir={l.dir}
              value={value[l.key]}
              onChange={(e) => onChange({ ...value, [l.key]: e.target.value })}
            />
          )}
        </Field>
      ))}
    </div>
  );
}

export function LoginPrompt({ message, next }: { message: string; next?: string }) {
  const { t } = useI18n();
  const q = next ? `?next=${encodeURIComponent(next)}` : "";
  return (
    <Card className="text-center">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-teal-600">
        <UserRound className="h-7 w-7" />
      </div>
      <p className="mx-auto max-w-md text-slate-600">{message}</p>
      <div className="mt-5 flex flex-wrap justify-center gap-3">
        <Link href={`/login${q}`} className={buttonClass("primary")}>
          {t("nav.login")}
        </Link>
        <Link href="/register" className={buttonClass("outline")}>
          {t("nav.register")}
        </Link>
      </div>
    </Card>
  );
}
