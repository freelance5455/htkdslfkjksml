import React from 'react';
import { Download, FileText, CheckCircle, Shield, FileCheck } from 'lucide-react';
import { ProjectDocument } from '../types';

interface DocumentPreviewModalProps {
  document: ProjectDocument | null;
  onClose: () => void;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({ document, onClose }) => {
  if (!document) return null;

  const handleDownload = () => {
    // Generate simple text file download
    const content = `PHOENIX FIRE SAFETY EQUIPMENTS PVT. LTD. - DOCUMENT REPOSITORY\n` +
      `----------------------------------------------------------------\n` +
      `Document Title: ${document.title}\n` +
      `Filename: ${document.filename}\n` +
      `Category: ${document.category}\n` +
      `Project Reference: ${document.projectReference}\n` +
      `Uploaded By: ${document.uploadedBy} (${document.uploadedByRole})\n` +
      `Upload Date: ${document.uploadDate}\n` +
      `Access Level: ${document.accessLevel}\n\n` +
      `DOCUMENT SUMMARY / SPECIFICATION:\n` +
      `${document.previewText || 'Certified fire protection documentation on record with Phoenix Fire Safety Equipments Pvt. Ltd.'}\n\n` +
      `Statutory compliance: IS 3844 / NFPA 13 / Tamil Nadu Fire and Rescue Services (TNFRS) standards.\n` +
      `Registered Office: Phoenix Fire Safety Equipments Pvt. Ltd., Chennai, Tamil Nadu.`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = window.document.createElement('a');
    link.href = url;
    link.download = document.filename.endsWith('.pdf') || document.filename.endsWith('.dwg') 
      ? document.filename 
      : `${document.filename}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[95vh] sm:max-h-[90vh]">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3 sm:py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold text-xs uppercase shrink-0">
              {document.fileType}
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-tight">{document.title}</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {document.filename} · {document.fileSize}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold shrink-0"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Preview Viewer Canvas */}
        <div className="p-3 sm:p-6 overflow-y-auto flex-1 bg-slate-100/70">
          <div className="bg-white p-4 sm:p-8 rounded-lg border border-slate-200 shadow-xs max-w-xl mx-auto min-h-[360px] flex flex-col justify-between">
            <div>
              {/* Document Letterhead */}
              <div className="border-b-2 border-red-600 pb-4 mb-6 flex items-start justify-between">
                <div>
                  <h4 className="text-xs font-bold tracking-wider text-red-600 uppercase">
                    Phoenix Fire Safety Equipments Pvt. Ltd.
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Industrial & Commercial Fire Protection Systems · Chennai, Tamil Nadu
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-400">Ref: {document.projectReference}</span>
                  <p className="text-[10px] font-semibold text-slate-700">{document.category}</p>
                </div>
              </div>

              {/* Main Document Content */}
              <div className="space-y-4">
                <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs">
                  <span className="font-semibold text-slate-700">Document Title: </span>
                  <span className="text-slate-900">{document.title}</span>
                </div>

                <div className="text-xs leading-relaxed text-slate-700 space-y-2">
                  <p className="font-semibold text-slate-900">Technical Scope & Verification Summary:</p>
                  <p className="p-3 bg-white border border-slate-100 rounded text-slate-600 italic">
                    "{document.previewText || 'Technical fire safety documentation generated under Phoenix Fire Safety standards.'}"
                  </p>
                </div>

                {document.category === 'Form B NOC' && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded flex items-center gap-3 text-xs text-emerald-900">
                    <Shield className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <p className="font-semibold">Tamil Nadu Fire and Rescue Services (TNFRS) Compliance Verified</p>
                      <p className="text-[11px] text-emerald-700">Inspected under Tamil Nadu Fire Service Rules 1990 & NBC 2016 Part IV.</p>
                    </div>
                  </div>
                )}

                {document.category === 'CAD Drawing' && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded flex items-center gap-3 text-xs text-blue-900">
                    <FileText className="w-5 h-5 text-blue-600 shrink-0" />
                    <div>
                      <p className="font-semibold">AutoCAD DWG Architecture Overlay</p>
                      <p className="text-[11px] text-blue-700">Layered schematic with sensor loop coordinates & riser piping sections.</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Signoff */}
            <div className="pt-6 mt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
              <div>
                <p className="text-[11px]">Uploaded by: <span className="font-medium text-slate-700">{document.uploadedBy}</span></p>
                <p className="text-[10px] text-slate-400">Access: {document.accessLevel}</p>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-700 font-medium text-[11px]">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span>Digitally Archived</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {document.accessLevel === 'Client Shared' ? 'Shared with client via client portal' : 'Internal Phoenix Engineering document'}
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
