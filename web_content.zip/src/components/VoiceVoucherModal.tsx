import React, { useState } from 'react';
import { Mic, MicOff, Sparkles, X, ArrowRight, Volume2 } from 'lucide-react';
import { Ledger, StockItem, VoucherType } from '../types/tally';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface VoiceVoucherModalProps {
  isOpen: boolean;
  ledgers: Ledger[];
  stockItems: StockItem[];
  onClose: () => void;
  onDraftCreated: (draft: {
    type: VoucherType;
    amount?: number;
    partyName?: string;
    narration: string;
  }) => void;
}

export const VoiceVoucherModal: React.FC<VoiceVoucherModalProps> = ({
  isOpen,
  ledgers,
  stockItems,
  onClose,
  onDraftCreated,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');

  if (!isOpen) return null;

  const samplePrompts = [
    'Received 35000 from Sharma Retail Mart into HDFC Bank',
    'Paid 18000 for Office Rent from HDFC Current Bank',
    'Withdrew 10000 cash from SBI Bank for office cash',
    'Sold 4 Barcode Scanners to Metro Mega Stores',
    'Paid 25000 to Bharat Hardware via bank transfer',
  ];

  const handleStartListening = () => {
    triggerHaptic('medium');
    soundManager.playKeyClick();

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      try {
        const SpeechRecognition =
          (window as unknown as { SpeechRecognition: any }).SpeechRecognition ||
          (window as unknown as { webkitSpeechRecognition: any }).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-IN';

        setIsListening(true);

        recognition.onresult = (event: any) => {
          const text = event.results[0][0].transcript;
          setTranscript(text);
          setIsListening(false);
          parseAndSubmit(text);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
      } catch {
        // Fallback
        setIsListening(false);
      }
    } else {
      // Simulate speech input for browser contexts without speech recognition
      setIsListening(true);
      setTimeout(() => {
        setIsListening(false);
        const sample = samplePrompts[Math.floor(Math.random() * samplePrompts.length)];
        setTranscript(sample);
        parseAndSubmit(sample);
      }, 1200);
    }
  };

  const parseAndSubmit = (text: string) => {
    triggerHaptic('success');
    soundManager.playAcceptChime();

    const lower = text.toLowerCase();
    let type: VoucherType = 'payment';

    if (lower.includes('sold') || lower.includes('sale') || lower.includes('invoice')) {
      type = 'sales';
    } else if (lower.includes('bought') || lower.includes('purchase')) {
      type = 'purchase';
    } else if (lower.includes('received') || lower.includes('receipt') || lower.includes('from customer')) {
      type = 'receipt';
    } else if (lower.includes('cash withdrawn') || lower.includes('contra') || lower.includes('deposited')) {
      type = 'contra';
    } else if (lower.includes('paid') || lower.includes('payment') || lower.includes('rent') || lower.includes('salary')) {
      type = 'payment';
    }

    // Extract amount
    const numbers = text.match(/\d+(\.\d+)?/g);
    const amount = numbers ? parseFloat(numbers[0]) : 5000;

    // Detect party name
    let partyName: string | undefined = undefined;
    for (const led of ledgers) {
      if (lower.includes(led.name.toLowerCase().split(' ')[0])) {
        partyName = led.name;
        break;
      }
    }

    onDraftCreated({
      type,
      amount,
      partyName,
      narration: `Voice Voucher: "${text}"`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 text-slate-800 dark:text-slate-100 flex flex-col">
        {/* Header */}
        <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Mic className="w-4 h-4 text-emerald-300" />
            <span className="text-xs font-bold uppercase tracking-wider">
              Quick Voice Voucher Dictation
            </span>
          </div>
          <button onClick={onClose} className="p-1 rounded text-emerald-200 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Listening Area */}
        <div className="p-6 text-center space-y-4">
          <div className="relative inline-block">
            <button
              onClick={handleStartListening}
              className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse ring-8 ring-rose-200 dark:ring-rose-950'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
              }`}
            >
              <Mic className="w-8 h-8" />
            </button>
          </div>

          <div>
            <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
              {isListening ? 'Listening... Speak naturally' : 'Tap Microphone to Speak'}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Speak voucher type, party name & amount in English or Hindi
            </p>
          </div>

          {transcript && (
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs italic text-slate-600 dark:text-slate-300">
              "{transcript}"
            </div>
          )}

          {/* Preset Sample Dictations */}
          <div className="text-left pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
            <div className="text-[10px] uppercase font-bold text-slate-400">
              Or tap a sample to test:
            </div>
            <div className="space-y-1">
              {samplePrompts.slice(0, 3).map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setTranscript(prompt);
                    parseAndSubmit(prompt);
                  }}
                  className="w-full text-left p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-slate-700/60 text-[11px] text-slate-700 dark:text-slate-300 transition-colors"
                >
                  "{prompt}"
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
