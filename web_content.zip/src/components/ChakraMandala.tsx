import React from 'react';
import { SessionState } from '../types';

interface ChakraMandalaProps {
  sessionState: SessionState;
  latestTranscript: string;
  isAudioActive: boolean;
}

export const ChakraMandala: React.FC<ChakraMandalaProps> = ({
  sessionState,
  latestTranscript,
  isAudioActive,
}) => {
  const isSpeaking = sessionState === 'SPEAKING' || isAudioActive;
  const isListening = sessionState === 'LISTENING';

  const speechText =
    latestTranscript ||
    (sessionState === 'CONNECTING'
      ? 'Connecting with you...'
      : 'Hello! I am AI.P. Tap the mic to begin.');

  const zodiacSymbols = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];

  return (
    <div className="relative flex flex-col items-center justify-center w-full max-w-sm mx-auto select-none">
      {/* Speech Bubble floating above mandala */}
      <div className="relative z-10 w-full flex justify-center px-4 mb-2 min-h-[48px]">
        <div className="relative max-w-[280px] px-4 py-2 rounded-2xl glass-panel border border-purple-500/30 text-xs text-purple-100 shadow-xl backdrop-blur-xl animate-fade-in text-center">
          <p className="leading-snug font-medium line-clamp-2">{speechText}</p>
          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-[#0d1224] border-r border-b border-purple-500/30 transform rotate-45" />
        </div>
      </div>

      {/* Main Rotating Chakra / Astrology Mandala */}
      <div className="relative flex items-center justify-center w-56 h-56 sm:w-64 sm:h-64 my-1">
        {/* Deep ambient cosmic glow */}
        <div
          className={`absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600/30 via-pink-600/25 to-cyan-500/30 blur-2xl transition-all duration-700 pointer-events-none ${
            isSpeaking
              ? 'scale-125 opacity-100'
              : isListening
              ? 'scale-110 opacity-80'
              : 'scale-95 opacity-50'
          }`}
        />

        {/* Outer Rotating Zodiac Ring (Clockwise) */}
        <div className="absolute inset-0 rounded-full animate-spin-slow pointer-events-none flex items-center justify-center">
          {/* Subtle outer circular boundary */}
          <div className="absolute inset-0 rounded-full border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.3)]" />

          {/* 12 Zodiac signs distributed evenly */}
          {zodiacSymbols.map((symbol, idx) => {
            const angle = (idx * 360) / 12;
            const rad = (angle * Math.PI) / 180;
            // Radius ~ 45% of container
            const x = Math.sin(rad) * 45;
            const y = -Math.cos(rad) * 45;

            return (
              <span
                key={idx}
                className="absolute text-xs sm:text-sm font-serif text-cyan-300/80 drop-shadow-[0_0_6px_rgba(6,182,212,0.8)]"
                style={{
                  transform: `translate(${x * 2.4}px, ${y * 2.4}px) rotate(${angle}deg)`,
                }}
              >
                {symbol}
              </span>
            );
          })}
        </div>

        {/* Middle Sacred Geometry / Chakra Star Petals (Counter-Clockwise) */}
        <div className="absolute inset-4 rounded-full border border-cyan-400/40 border-dashed animate-spin-reverse-slow pointer-events-none flex items-center justify-center">
          {/* Detailed SVG Sacred Chakra Geometry */}
          <svg
            className="w-full h-full p-2 text-purple-400/60"
            viewBox="0 0 200 200"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Concentric rings */}
            <circle cx="100" cy="100" r="90" stroke="currentColor" strokeWidth="0.8" strokeDasharray="4 3" opacity="0.6" />
            <circle cx="100" cy="100" r="72" stroke="#ec4899" strokeWidth="0.8" opacity="0.5" />
            <circle cx="100" cy="100" r="54" stroke="#06b6d4" strokeWidth="1" strokeDasharray="3 3" opacity="0.7" />

            {/* Hexagram / Star of David Sacred Interlocking Triangles */}
            <polygon
              points="100,28 162,136 38,136"
              stroke="#a855f7"
              strokeWidth="1"
              opacity="0.65"
            />
            <polygon
              points="100,172 162,64 38,64"
              stroke="#06b6d4"
              strokeWidth="1"
              opacity="0.65"
            />

            {/* 8-fold radial rays */}
            {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
              <line
                key={deg}
                x1="100"
                y1="28"
                x2="100"
                y2="48"
                stroke="#ec4899"
                strokeWidth="1.2"
                transform={`rotate(${deg} 100 100)`}
                opacity="0.8"
              />
            ))}

            {/* 12 small celestial dots */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
              <circle
                key={deg}
                cx="100"
                cy="18"
                r="1.5"
                fill="#06b6d4"
                transform={`rotate(${deg} 100 100)`}
              />
            ))}
          </svg>
        </div>

        {/* Inner Glowing Energy Core / Bindu */}
        <div
          className={`relative w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl ${
            isSpeaking
              ? 'bg-gradient-to-tr from-pink-600 via-purple-700 to-cyan-500 shadow-[0_0_35px_rgba(236,72,153,0.8)] scale-105'
              : isListening
              ? 'bg-gradient-to-tr from-cyan-600 via-purple-800 to-indigo-600 shadow-[0_0_30px_rgba(6,182,212,0.8)] scale-100'
              : 'bg-gradient-to-tr from-purple-900/80 via-[#0d1224] to-cyan-950/80 shadow-[0_0_20px_rgba(139,92,246,0.4)] border border-purple-500/40'
          }`}
        >
          {/* Inner Chakra glyph */}
          <div className="relative flex items-center justify-center">
            {/* Pulsing core light */}
            <div
              className={`w-8 h-8 rounded-full bg-white/20 blur-sm ${
                isSpeaking ? 'animate-ping' : isListening ? 'animate-pulse' : ''
              }`}
            />
            {/* Center Sanskrit/Sacred symbol */}
            <span className="absolute text-lg sm:text-xl font-bold bg-gradient-to-r from-cyan-200 via-white to-pink-200 bg-clip-text text-transparent drop-shadow-[0_0_8px_rgba(255,255,255,0.9)]">
              ॐ
            </span>
          </div>

          {/* Rotating fine micro-ring */}
          <div className="absolute inset-1 rounded-full border border-white/20 border-dotted animate-spin-slow pointer-events-none" />
        </div>
      </div>

      {/* Subtitle / Focus Label */}
      <div className="text-center mt-2 z-10">
        <h2 className="text-sm font-bold text-white tracking-wider flex items-center justify-center space-x-1.5">
          <span className="text-purple-400">✧</span>
          <span>Astrological Intelligence</span>
          <span className="text-cyan-400">✧</span>
        </h2>
        <p className="text-[10px] text-slate-400 font-medium tracking-widest mt-0.5 uppercase">
          Zodiac Resonance • Real Vision
        </p>
      </div>
    </div>
  );
};
