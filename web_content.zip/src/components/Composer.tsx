import React, { useRef } from 'react';
import { ArrowUp, ImagePlus, Square, X } from 'lucide-react';
import type { Attachment, GeminiModelId } from '../types/chat';

interface ComposerProps {
  value: string;
  onChange: (val: string) => void;
  attachments: Attachment[];
  onAddAttachments: (files: FileList | File[]) => void;
  onRemoveAttachment: (id: string) => void;
  model: GeminiModelId;
  onChangeModel: (model: GeminiModelId) => void;
  busy: boolean;
  onSend: () => void;
  onStop: () => void;
}

export function Composer({
  value,
  onChange,
  attachments,
  onAddAttachments,
  onRemoveAttachment,
  model,
  onChangeModel,
  busy,
  onSend,
  onStop,
}: ComposerProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const adjustHeight = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 168)}px`;
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!busy && (value.trim() || attachments.length > 0)) {
        onSend();
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.files;
    if (items && items.length > 0) {
      const images = Array.from(items).filter((f) => f.type.startsWith('image/'));
      if (images.length > 0) {
        onAddAttachments(images);
      }
    }
  };

  const canSend = !busy && (value.trim().length > 0 || attachments.length > 0);

  return (
    <div className="border-t border-slate-200 bg-[#f8faff] px-3 pt-3 pb-[max(14px,env(safe-area-inset-bottom))] dark:border-[#293449] dark:bg-[#0f1420] sm:px-5">
      <div className="mx-auto max-w-[850px]">
        <div className="rounded-2xl border border-slate-300 bg-white p-2.5 shadow-sm transition-colors focus-within:border-[#6478ff] dark:border-[#39465f] dark:bg-[#141a27] dark:shadow-lg dark:shadow-black/20">
          {/* Attachment Previews */}
          {attachments.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-2 px-1.5 pt-1">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="group relative overflow-hidden rounded-xl border border-slate-200 bg-slate-50 dark:border-[#293449] dark:bg-[#0d1320]"
                >
                  <img
                    src={att.previewUrl}
                    alt={att.name}
                    referrerPolicy="no-referrer"
                    className="h-16 w-16 object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => onRemoveAttachment(att.id)}
                    aria-label={`Remove ${att.name}`}
                    className="absolute top-1 right-1 grid h-5 w-5 place-items-center rounded-md bg-slate-900/80 text-white hover:bg-rose-600"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={value}
            onChange={(e) => {
              onChange(e.target.value);
              adjustHeight();
            }}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder="Message CB AI… (Enter to send, Shift+Enter for new line)"
            className="max-h-[168px] min-h-[44px] w-full resize-none border-0 bg-transparent px-2 py-1.5 text-[15px] leading-relaxed text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-[#edf2ff] dark:placeholder:text-[#7a89a4]"
          />

          {/* Bottom Controls */}
          <div className="mt-1.5 flex items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2 min-w-0">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    onAddAttachments(e.target.files);
                    e.target.value = '';
                  }
                }}
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={busy}
                title="Attach image for analysis"
                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-2.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#232d42] whitespace-nowrap shrink-0"
              >
                <ImagePlus className="h-4 w-4" />
                <span className="hidden sm:inline">Image</span>
              </button>

              {/* Segmented Speed Switcher */}
              <div
                role="group"
                aria-label="Response speed"
                className="flex items-center rounded-xl border border-slate-200 bg-slate-100 p-0.5 dark:border-[#293449] dark:bg-[#0d1320]"
              >
                <button
                  type="button"
                  onClick={() => onChangeModel('gemini-4-hydrogen')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    model === 'gemini-4-hydrogen'
                      ? 'bg-white text-slate-950 shadow-xs dark:bg-[#222e45] dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-[#9aa8c0] dark:hover:text-white'
                  }`}
                >
                  Balanced
                </button>
                <button
                  type="button"
                  onClick={() => onChangeModel('gemini-3.1-flash-lite')}
                  className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    model === 'gemini-3.1-flash-lite'
                      ? 'bg-white text-slate-950 shadow-xs dark:bg-[#222e45] dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-[#9aa8c0] dark:hover:text-white'
                  }`}
                >
                  Fast
                </button>
              </div>
            </div>

            {busy ? (
              <button
                type="button"
                onClick={onStop}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-rose-600 px-3.5 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onSend}
                disabled={!canSend}
                className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#6478ff] px-4 text-xs font-semibold text-white transition-all hover:bg-[#5367dd] disabled:cursor-not-allowed disabled:opacity-45 whitespace-nowrap shrink-0"
              >
                <span>Send</span>
                <ArrowUp className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        <p className="mt-2 hidden text-center text-[11px] text-slate-500 dark:text-[#7f90ae] sm:block">
          CB AI can make mistakes. Check important information before relying on it.
        </p>
      </div>
    </div>
  );
}
