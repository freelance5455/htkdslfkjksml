import { useEffect, useRef, useState } from "react";
import { useStore } from "../lib/store";
import { Icon, Sheet } from "./ui";
import { cn } from "../utils/cn";
import { pathOf } from "../lib/fs";
import type { AgentMode } from "../lib/types";

export default function Composer({
  busy,
  onSend,
  onStop,
  onOpenModel,
  onWorkspace,
}: {
  busy: boolean;
  onSend: (text: string, attachments: string[]) => void;
  onStop: () => void;
  onOpenModel: () => void;
  onWorkspace: () => void;
}) {
  const { s, set, provider, session } = useStore();
  const text = s.composerDrafts[session.id] ?? "";
  const [attachments, setAttachments] = useState<string[]>([]);
  const [attachOpen, setAttachOpen] = useState(false);
  const [modeOpen, setModeOpen] = useState(false);
  const [keyboard, setKeyboard] = useState(false);
  const [query, setQuery] = useState("");
  const ta = useRef<HTMLTextAreaElement>(null);
  const update = (value: string) =>
    set((state) => ({
      composerDrafts: { ...state.composerDrafts, [session.id]: value },
    }));
  useEffect(() => {
    if (!ta.current) return;
    ta.current.style.height = "auto";
    ta.current.style.height = `${Math.min(ta.current.scrollHeight, 180)}px`;
  }, [text]);
  useEffect(() => {
    setAttachments([]);
    setQuery("");
  }, [session.id]);

  const submit = () => {
    if (!text.trim() || busy) return;
    onSend(text.trim(), attachments);
    update("");
    setAttachments([]);
  };
  const insert = (value: string) => {
    const el = ta.current;
    if (!el) return;
    const start = el.selectionStart;
    update(text.slice(0, start) + value + text.slice(el.selectionEnd));
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + value.length, start + value.length);
    });
  };
  const modes: { id: AgentMode; icon: string; name: string; desc: string }[] = [
    {
      id: "agent",
      icon: "bot",
      name: "Agent",
      desc: "Build and change files, with your permission.",
    },
    {
      id: "plan",
      icon: "layers",
      name: "Plan",
      desc: "Work out the approach. No files are changed.",
    },
    {
      id: "ask",
      icon: "chat",
      name: "Ask",
      desc: "Understand your code. Read-only, always.",
    },
  ];
  const mode = modes.find((item) => item.id === s.agentMode)!;
  const files = Object.values(s.fs.nodes).filter(
    (node) =>
      node.type === "file" &&
      !node.binary &&
      pathOf(s.fs, node.id).toLowerCase().includes(query.toLowerCase()),
  );
  const slash = text.startsWith("/") && !text.includes(" ");
  const ready = s.liveApi && !!(provider.apiKey || provider.allowNoKey);

  return (
    <div className="relative w-full">
      {slash && (
        <div className="anim-msg absolute inset-x-0 bottom-full z-10 mb-2 rounded-xl border border-line2 bg-surface p-2 shadow-xl">
          {modes
            .filter((item) => `/${item.id}`.startsWith(text))
            .map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  set({ agentMode: item.id });
                  update("");
                  ta.current?.focus();
                }}
                className="flex w-full items-center gap-3 rounded-lg p-2.5 text-left hover:bg-surface2"
              >
                <Icon name={item.icon} className="h-4 w-4 text-accent" />
                <span className="text-xs">
                  /{item.id}
                  <span className="ml-3 text-muted">{item.desc}</span>
                </span>
              </button>
            ))}
        </div>
      )}
      <div className="composer-shell overflow-hidden">
        <div className="flex items-center gap-2 px-4 pb-0 pt-3.5">
          <button
            onClick={onWorkspace}
            className="flex max-w-[65%] items-center gap-1.5 rounded-md px-1 py-1 text-[11px] text-muted hover:bg-surface2 hover:text-fg"
          >
            <Icon name="folder" className="h-3.5 w-3.5 text-accent" />
            <span className="truncate font-mono">{s.workspacePath}</span>
            <Icon name="chevronDown" className="h-3 w-3" />
          </button>
          <span className="ml-auto text-[9px] uppercase tracking-[.09em] text-muted">
            {s.agentMode === "agent" ? "Permission-based" : "Read only"}
          </span>
        </div>
        {attachments.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1.5 px-4">
            {attachments.map((path) => (
              <span
                key={path}
                className="flex min-w-0 items-center gap-1.5 rounded-md bg-accentsoft px-2 py-1 text-[10px] text-accent"
              >
                <Icon name="file" className="h-3 w-3" />
                <span className="max-w-[180px] truncate font-mono">{path}</span>
                <button
                  aria-label={`Remove ${path}`}
                  onClick={() =>
                    setAttachments((items) =>
                      items.filter((item) => item !== path),
                    )
                  }
                >
                  <Icon name="close" className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        )}
        <textarea
          id="prompt-input"
          aria-label="Message TopeCode"
          ref={ta}
          value={text}
          rows={2}
          onChange={(e) => update(e.target.value)}
          onKeyDown={(e) => {
            if (e.nativeEvent.isComposing) return;
            if (
              e.key === "Enter" &&
              !e.shiftKey &&
              (window.innerWidth >= 768 || e.ctrlKey || e.metaKey)
            ) {
              e.preventDefault();
              submit();
            }
            if (e.key === "Tab") {
              e.preventDefault();
              insert("  ");
            }
          }}
          placeholder="Tell TopeCode what you want to build..."
          className="composer-input no-scrollbar block w-full resize-none bg-transparent px-5 pb-2 pt-3 text-[14px] leading-6 text-fg outline-none placeholder:text-muted/70"
        />
        {keyboard && (
          <div className="flex gap-1 border-t border-line px-3 py-2">
            {["Tab", "/", "@", "{ }", "[ ]", "( )", "`"].map((key) => (
              <button
                key={key}
                onPointerDown={(e) => e.preventDefault()}
                onClick={() =>
                  key === "@"
                    ? setAttachOpen(true)
                    : insert(key === "Tab" ? "  " : key)
                }
                className="h-7 flex-1 rounded bg-surface2 font-mono text-[11px] text-muted hover:bg-surface3"
              >
                {key}
              </button>
            ))}
          </div>
        )}
        <div className="flex items-center gap-1 px-3 pb-3 pt-1.5 sm:gap-2">
          <button
            aria-label="Choose agent mode"
            onClick={() => setModeOpen(true)}
            className="tap flex h-8 items-center gap-1.5 rounded-lg bg-accentsoft px-2.5 text-[11px] font-medium text-accent"
          >
            <Icon name={mode.icon} className="h-3.5 w-3.5" />
            {mode.name}
            <Icon name="chevronDown" className="h-3 w-3" />
          </button>
          <button
            aria-label="Select model"
            onClick={onOpenModel}
            className="tap flex h-8 min-w-0 items-center gap-1.5 rounded-lg px-1.5 text-[11px] text-muted hover:bg-surface2"
          >
            <span className="hidden h-3.5 w-3.5 items-center justify-center rounded-sm bg-surface3 text-[9px] font-semibold sm:inline-flex">
              {provider.name[0]}
            </span>
            <span className="max-w-[100px] truncate sm:max-w-[190px]">
              {s.activeModel}
            </span>
            <Icon name="chevronDown" className="h-3 w-3" />
          </button>
          <div className="ml-auto flex shrink-0 items-center gap-0.5 sm:gap-1">
            <button
              aria-label="Attach file context"
              title="Attach file context"
              disabled={!s.permissions.read}
              onClick={() => setAttachOpen(true)}
              className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-surface2 disabled:opacity-30"
            >
              <Icon name="attach" className="h-[17px] w-[17px]" />
            </button>
            <button
              aria-label="Toggle coding keyboard"
              title="Coding keyboard"
              aria-pressed={keyboard}
              onClick={() => setKeyboard(!keyboard)}
              className={cn(
                "hidden h-8 w-8 place-items-center rounded-lg hover:bg-surface2 min-[380px]:grid",
                keyboard ? "text-accent" : "text-muted",
              )}
            >
              <Icon name="keyboard" className="h-[17px] w-[17px]" />
            </button>
            <button
              onClick={busy ? onStop : submit}
              disabled={!busy && !text.trim()}
              aria-label={busy ? "Stop response" : "Send message"}
              className="primary-button tap ml-1 grid h-[34px] w-[34px] place-items-center rounded-[10px] text-white disabled:opacity-40"
            >
              <Icon
                name={busy ? "stop" : "send"}
                className="h-[18px] w-[18px]"
              />
            </button>
          </div>
        </div>
      </div>
      <div className="mt-2.5 flex items-center justify-between gap-3 px-1 text-[10px] text-muted">
        <span className="flex items-center gap-1.5">
          <span
            className={cn("h-1 w-1 rounded-full", ready ? "bg-ok" : "bg-muted")}
          />
          {ready
            ? `${provider.name} / ${provider.allowNoKey && !provider.apiKey ? "local endpoint" : "your API key"}`
            : "Connect your model to start building"}
        </span>
        <span className="hidden sm:block">
          Enter to send <span className="mx-1 opacity-30">/</span> Shift + Enter
          for a new line
        </span>
        <span className="sm:hidden">/ for commands</span>
      </div>
      <Sheet
        open={attachOpen}
        onClose={() => setAttachOpen(false)}
        title="Add file context"
        subtitle="Selected file contents are included with your next prompt."
        footer={
          <button
            onClick={() => setAttachOpen(false)}
            className="h-11 w-full rounded-xl bg-accent text-sm font-medium text-white"
          >
            Attach {attachments.length || "selected"}{" "}
            {attachments.length === 1 ? "file" : "files"}
          </button>
        }
      >
        <div className="px-4 pb-2">
          <input
            aria-label="Search context files"
            autoFocus
            placeholder="Search files..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-10 w-full rounded-lg border border-line bg-surface2 px-3 text-sm outline-none focus:border-accent"
          />
        </div>
        <div className="max-h-[45dvh] overflow-auto px-2 pb-2">
          {files.map((node) => {
            const path = pathOf(s.fs, node.id);
            const selected = attachments.includes(path);
            return (
              <button
                key={node.id}
                onClick={() =>
                  setAttachments((items) =>
                    selected
                      ? items.filter((item) => item !== path)
                      : [...items, path],
                  )
                }
                className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left hover:bg-surface2"
              >
                <Icon name="file" className="h-4 w-4 text-muted" />
                <span className="min-w-0 flex-1 truncate font-mono text-xs">
                  {path}
                </span>
                <span
                  className={cn(
                    "grid h-[18px] w-[18px] place-items-center rounded border",
                    selected
                      ? "border-accent bg-accent text-white"
                      : "border-line2",
                  )}
                >
                  {selected && <Icon name="check" className="h-3 w-3" />}
                </span>
              </button>
            );
          })}
          {!files.length && (
            <p className="p-6 text-center text-sm text-muted">
              No text files found.
            </p>
          )}
        </div>
      </Sheet>
      <Sheet
        open={modeOpen}
        onClose={() => setModeOpen(false)}
        title="How should TopeCode help?"
        subtitle="Switch modes without leaving your conversation."
      >
        <div className="space-y-1 px-3 pb-4">
          {modes.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                set({ agentMode: item.id });
                setModeOpen(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-surface2"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-accentsoft text-accent">
                <Icon name={item.icon} className="h-4 w-4" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-medium">{item.name}</span>
                <span className="mt-1 block text-xs text-muted">
                  {item.desc}
                </span>
              </span>
              {s.agentMode === item.id && (
                <Icon name="check" className="h-4 w-4 text-accent" />
              )}
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}
