import { useState } from "react";
import { Check, Copy } from "lucide-react";
import type { ReactNode } from "react";

function inline(text: string, key: string): ReactNode[] {
  const pattern = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let index = 0;
  for (const match of text.matchAll(pattern)) {
    const start = match.index ?? 0;
    if (start > last) nodes.push(text.slice(last, start));
    const token = match[0];
    const id = `${key}-${index}`;
    if (token.startsWith("**")) {
      nodes.push(
        <strong key={id} className="font-semibold text-fg">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("`")) {
      nodes.push(
        <code key={id} className="rounded-sm bg-bg px-1 py-0.5 font-mono text-[0.92em] text-primary">
          {token.slice(1, -1)}
        </code>,
      );
    } else {
      const link = /^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/.exec(token);
      if (link) {
        nodes.push(
          <a
            key={id}
            href={link[2]}
            target="_blank"
            rel="noreferrer noopener"
            className="text-primary underline decoration-line underline-offset-2"
          >
            {link[1]}
          </a>,
        );
      }
    }
    last = start + token.length;
    index += 1;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

function blocks(text: string, key: string) {
  const lines = text.split("\n");
  const nodes: ReactNode[] = [];
  let buffer: string[] = [];
  let list: string[] = [];
  const flushParagraph = () => {
    if (!buffer.length) return;
    const value = buffer.join("\n").trim();
    buffer = [];
    if (!value) return;
    nodes.push(
      <p key={`${key}-p-${nodes.length}`} className="text-pretty whitespace-pre-wrap">
        {inline(value, `${key}-p-${nodes.length}`)}
      </p>,
    );
  };
  const flushList = () => {
    if (!list.length) return;
    const items = list;
    list = [];
    nodes.push(
      <ul key={`${key}-l-${nodes.length}`} className="list-disc space-y-1 pl-5">
        {items.map((item, itemIndex) => (
          <li key={itemIndex}>{inline(item, `${key}-li-${nodes.length}-${itemIndex}`)}</li>
        ))}
      </ul>,
    );
  };
  for (const line of lines) {
    const item = /^(?:[-*]|\d+\.)\s+(.+)$/.exec(line);
    if (item) {
      flushParagraph();
      list.push(item[1] ?? "");
      continue;
    }
    flushList();
    if (!line.trim()) {
      flushParagraph();
      continue;
    }
    buffer.push(line);
  }
  flushList();
  flushParagraph();
  return nodes;
}

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="overflow-hidden rounded-md border border-line bg-bg">
      <div className="flex justify-end border-b border-line px-2 py-1">
        <button
          type="button"
          className="press inline-flex h-8 items-center gap-1 rounded-sm px-2 text-xs text-muted hover:text-fg"
          onClick={() => {
            void navigator.clipboard.writeText(code).then(() => {
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1200);
            });
          }}
        >
          {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 font-mono text-sm leading-relaxed text-fg">
        <code>{code.replace(/\n$/, "")}</code>
      </pre>
    </div>
  );
}

export function Markdown({ text }: { text: string }) {
  const parts = text.split("```");
  return (
    <div className="space-y-3 leading-normal">
      {parts.map((part, index) => {
        if (index % 2 === 1) {
          const breakAt = part.indexOf("\n");
          const code = breakAt === -1 ? part : part.slice(breakAt + 1);
          return <CodeBlock key={index} code={code} />;
        }
        if (!part.trim()) return null;
        return <div key={index} className="space-y-3">{blocks(part, `b${index}`)}</div>;
      })}
    </div>
  );
}
