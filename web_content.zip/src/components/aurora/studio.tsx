import { useEffect, useRef, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import * as Switch from "@radix-ui/react-switch";
import { Download, Globe, ImageIcon, MapPinOff, Send, Shredder, X } from "lucide-react";
import { previewPathPrefix } from "@/lib/preview-path-prefix";
import type { AuroraResponse, ChatTurn, Citation } from "@/lib/aurora/types";
import { cn } from "@/lib/cn";
import { Markdown } from "./markdown";

type Mode = "talk" | "picture";

type Bubble = {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  image?: string;
  pending?: boolean;
  error?: boolean;
};

type InstallPrompt = Event & { prompt: () => Promise<void> };

const TALK_STARTS = [
  "Rewrite this so it sounds like me: ",
  "Explain how a neural net learns, without the lecture.",
  "Draft a one-page story about a city that forgets names.",
];

const PICTURE_STARTS = [
  "Neon violet letter A fractured by a red slash, black void, no words",
  "A glass lighthouse in violet fog, square, no text",
  "Editorial still life of a paper crane on black, violet rim light",
];

function endpoint() {
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
  return `${prefix ?? ""}/api/aurora`;
}

function uid() {
  return crypto.randomUUID();
}

function noise(length: number) {
  const size = Math.max(8, Math.min(length, 128));
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function stripMetadata(dataUrl: string) {
  const image = new Image();
  image.decoding = "async";
  image.src = dataUrl;
  await image.decode();
  const canvas = document.createElement("canvas");
  canvas.width = image.naturalWidth;
  canvas.height = image.naturalHeight;
  const context = canvas.getContext("2d");
  if (!context) return dataUrl;
  context.drawImage(image, 0, 0);
  return canvas.toDataURL("image/png");
}

function Toggle({
  checked,
  onChange,
  label,
  detail,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  detail: string;
}) {
  return (
    <label className="flex items-center justify-between gap-3 rounded-md border border-line bg-bg px-3 py-2">
      <span>
        <span className="block text-sm font-medium text-fg">{label}</span>
        <span className="block text-xs text-faint">{detail}</span>
      </span>
      <Switch.Root
        checked={checked}
        onCheckedChange={onChange}
        className="relative h-7 w-12 shrink-0 rounded-full border border-line bg-elevated transition-colors data-[state=checked]:border-primary data-[state=checked]:bg-primary-deep"
      >
        <Switch.Thumb className="block size-5 translate-x-1 rounded-full bg-muted transition-transform data-[state=checked]:translate-x-6 data-[state=checked]:bg-fg" />
      </Switch.Root>
    </label>
  );
}

export function Studio() {
  const [mode, setMode] = useState<Mode>("talk");
  const [web, setWeb] = useState(false);
  const [deep, setDeep] = useState(false);
  const [notes, setNotes] = useState("");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<Bubble[]>([]);
  const [busy, setBusy] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [shredOpen, setShredOpen] = useState(false);
  const [cleared, setCleared] = useState(false);
  const [installEvent, setInstallEvent] = useState<InstallPrompt | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const field = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as InstallPrompt);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTo({ top: node.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  function grow(node: HTMLTextAreaElement) {
    node.style.height = "0px";
    node.style.height = `${Math.min(node.scrollHeight, 160)}px`;
  }

  async function shred() {
    setMessages((current) =>
      current.map((message) => ({
        ...message,
        content: noise(message.content.length),
        image: undefined,
        citations: [],
      })),
    );
    setNotes(noise(notes.length || 12));
    setDraft("");
    await new Promise((resolve) => window.setTimeout(resolve, 40));
    setMessages([]);
    setNotes("");
    setCleared(true);
    setShredOpen(false);
    for (const storage of [localStorage, sessionStorage]) {
      const keys = Object.keys(storage).filter((key) => key.startsWith("aurora"));
      for (const key of keys) storage.removeItem(key);
    }
    window.setTimeout(() => setCleared(false), 1600);
  }

  async function send(text: string) {
    const prompt = text.trim();
    if (!prompt || busy) return;
    setCleared(false);
    setDraft("");
    if (field.current) field.current.style.height = "";
    const userBubble: Bubble = { id: uid(), role: "user", content: prompt };
    const pending: Bubble = {
      id: uid(),
      role: "assistant",
      content: mode === "picture" ? "Making the picture" : "Working",
      pending: true,
    };
    const history: ChatTurn[] = [...messages, userBubble]
      .filter((message) => !message.pending && !message.error && message.content.trim())
      .map((message) => ({ role: message.role, content: message.content }));
    setMessages((current) => [...current, userBubble, pending]);
    setBusy(true);
    try {
      const response = await fetch(endpoint(), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          mode === "picture"
            ? { kind: "image", prompt }
            : { kind: "chat", messages: history, notes, web, deep },
        ),
      });
      const data = (await response.json()) as AuroraResponse;
      if (!data.ok) {
        setMessages((current) =>
          current.map((message) =>
            message.id === pending.id
              ? { ...message, pending: false, error: true, content: data.error }
              : message,
          ),
        );
        return;
      }
      if (data.kind === "image") {
        const clean = await stripMetadata(data.image);
        setMessages((current) =>
          current.map((message) =>
            message.id === pending.id
              ? { ...message, pending: false, content: "Picture, metadata stripped.", image: clean }
              : message,
          ),
        );
        return;
      }
      setMessages((current) =>
        current.map((message) =>
          message.id === pending.id
            ? { ...message, pending: false, content: data.text, citations: data.citations }
            : message,
        ),
      );
    } catch {
      setMessages((current) =>
        current.map((message) =>
          message.id === pending.id
            ? { ...message, pending: false, error: true, content: "The connection dropped. Try again." }
            : message,
        ),
      );
    } finally {
      setBusy(false);
    }
  }

  const starters = mode === "picture" ? PICTURE_STARTS : TALK_STARTS;

  return (
    <main className="flex h-dvh flex-col bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-line px-4 py-3 md:hidden">
        <img src="/aurora-logo.png" alt="" className="size-11 rounded-md object-cover" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg leading-none font-semibold tracking-tight">Aurora</p>
          <p className="mt-1 flex items-center gap-1 text-xs text-faint">
            <MapPinOff className="size-3.5" aria-hidden="true" />
            Anonymous · location blocked
          </p>
        </div>
        <button
          type="button"
          className="press grid size-11 place-items-center rounded-md border border-line text-muted"
          onClick={() => setInstallOpen(true)}
          aria-label="Install Aurora"
        >
          <Download className="size-5" />
        </button>
        <button
          type="button"
          className="press grid size-11 place-items-center rounded-md border border-line text-muted"
          onClick={() => setShredOpen(true)}
          aria-label="Shred this visit"
        >
          <Shredder className="size-5" />
        </button>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-80 shrink-0 flex-col gap-4 border-r border-line bg-surface p-4 md:flex">
          <div className="rise flex items-center gap-3">
            <img src="/aurora-logo.png" alt="" className="size-14 rounded-lg object-cover" />
            <div>
              <h1 className="font-display text-2xl leading-none font-semibold tracking-tight">Aurora</h1>
              <p className="mt-1 text-sm text-muted">Direct. Anonymous. Yours for this visit.</p>
            </div>
          </div>
          <ul className="space-y-1 text-sm text-muted">
            <li>No account, no sign-in.</li>
            <li className="flex items-center gap-2">
              <MapPinOff className="size-4 text-primary" aria-hidden="true" />
              Location is blocked. No VPN, no Tor.
            </li>
            <li>Replies stay in this tab until you shred them.</li>
          </ul>
          <ModeSwitch mode={mode} onChange={setMode} />
          {mode === "talk" ? (
            <div className="space-y-2">
              <Toggle checked={web} onChange={setWeb} label="Look online" detail="Search the live web for this send" />
              <Toggle checked={deep} onChange={setDeep} label="Deep" detail="Slower, more careful reply" />
            </div>
          ) : (
            <p className="text-sm text-muted">Pictures are remade in the browser so the file has no metadata.</p>
          )}
          <label className="flex min-h-0 flex-1 flex-col gap-2">
            <span className="text-sm font-medium">Session notes</span>
            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value.slice(0, 800))}
              placeholder="Pin facts for this visit only. Shred wipes them."
              className="min-h-28 flex-1 resize-none rounded-md border border-line bg-bg p-3 text-sm text-fg outline-none placeholder:text-faint focus:border-primary"
            />
          </label>
          <div className="flex gap-2">
            <button
              type="button"
              className="press inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md border border-line text-sm font-medium"
              onClick={() => setInstallOpen(true)}
            >
              <Download className="size-4" />
              Install
            </button>
            <button
              type="button"
              className="press inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md border border-danger/50 text-sm font-medium text-danger"
              onClick={() => setShredOpen(true)}
            >
              <Shredder className="size-4" />
              Shred
            </button>
          </div>
        </aside>

        <section className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 md:hidden">
            <ModeSwitch mode={mode} onChange={setMode} />
            {mode === "talk" ? (
              <div className="flex gap-2">
                <Chip on={web} label="Online" onClick={() => setWeb((value) => !value)} icon />
                <Chip on={deep} label="Deep" onClick={() => setDeep((value) => !value)} />
              </div>
            ) : null}
          </div>

          <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 py-5">
            {messages.length === 0 ? (
              <div className="mx-auto flex min-h-full max-w-xl flex-col items-center justify-center text-center">
                <div className="rise relative">
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 -z-10 scale-150 rounded-full bg-primary/25 blur-3xl"
                  />
                  <img src="/aurora-logo.png" alt="Aurora" className="size-36 rounded-xl object-cover sm:size-44" />
                </div>
                <h2 className="rise rise-2 font-display mt-6 text-3xl font-semibold tracking-tight">Aurora</h2>
                <p className="rise rise-3 mt-2 max-w-sm text-pretty text-muted">
                  Talk or make a picture. Nothing is tied to a name, and location never leaves a blocked API.
                </p>
                <div className="mt-6 flex w-full flex-col gap-2">
                  {starters.map((starter) => (
                    <button
                      key={starter}
                      type="button"
                      className="press rounded-lg border border-line bg-surface px-4 py-3 text-left text-sm text-fg hover:border-primary"
                      onClick={() => {
                        setDraft(starter);
                        field.current?.focus();
                      }}
                    >
                      {starter}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <ol className="mx-auto flex max-w-3xl flex-col gap-4">
                {messages.map((message) => (
                  <li
                    key={message.id}
                    className={cn("flex", message.role === "user" ? "justify-end" : "justify-start")}
                  >
                    <article
                      className={cn(
                        "max-w-[min(100%,40rem)] rounded-xl px-4 py-3",
                        message.role === "user"
                          ? "bg-primary-deep text-fg"
                          : "border border-line bg-surface",
                        message.error && "border-danger/60 text-danger",
                      )}
                    >
                      {message.pending ? (
                        <p className="flex items-center gap-2 text-sm text-muted">
                          {message.content}
                          <span className="inline-flex gap-1" aria-hidden="true">
                            <span className="dot size-1.5 rounded-full bg-primary" />
                            <span className="dot size-1.5 rounded-full bg-primary" />
                            <span className="dot size-1.5 rounded-full bg-primary" />
                          </span>
                        </p>
                      ) : message.role === "assistant" && !message.error ? (
                        <Markdown text={message.content} />
                      ) : (
                        <p className="whitespace-pre-wrap text-pretty">{message.content}</p>
                      )}
                      {message.image ? (
                        <figure className="mt-3">
                          <img
                            src={message.image}
                            alt="Generated by Aurora"
                            className="max-h-[28rem] w-full rounded-md object-contain"
                          />
                          <a
                            href={message.image}
                            download="aurora.png"
                            className="press mt-2 inline-flex h-11 items-center rounded-md border border-line px-3 text-sm"
                          >
                            Save without metadata
                          </a>
                        </figure>
                      ) : null}
                      {message.citations && message.citations.length > 0 ? (
                        <ul className="mt-3 space-y-1 border-t border-line pt-2 text-sm">
                          {message.citations.map((citation) => (
                            <li key={citation.url}>
                              <a
                                href={citation.url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="text-primary underline decoration-line underline-offset-2"
                              >
                                {citation.title}
                              </a>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </article>
                  </li>
                ))}
              </ol>
            )}
          </div>

          {mode === "talk" ? (
            <div className="px-4 md:hidden">
              <label className="mb-2 block">
                <span className="text-xs text-faint">Session notes</span>
                <textarea
                  value={notes}
                  onChange={(event) => setNotes(event.target.value.slice(0, 800))}
                  placeholder="Pinned for this visit only"
                  rows={2}
                  className="mt-1 w-full resize-none rounded-md border border-line bg-surface p-3 text-sm outline-none placeholder:text-faint focus:border-primary"
                />
              </label>
            </div>
          ) : null}

          <form
            className="border-t border-line p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]"
            onSubmit={(event) => {
              event.preventDefault();
              void send(draft);
            }}
          >
            <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-lg border border-line bg-surface p-2">
              <label className="sr-only" htmlFor="aurora-draft">
                {mode === "picture" ? "Describe a picture" : "Message Aurora"}
              </label>
              <textarea
                id="aurora-draft"
                ref={field}
                value={draft}
                rows={1}
                placeholder={mode === "picture" ? "Describe a picture" : "Message Aurora"}
                className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2.5 text-base outline-none placeholder:text-faint"
                onChange={(event) => {
                  setDraft(event.target.value.slice(0, mode === "picture" ? 2000 : 4000));
                  grow(event.target);
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void send(draft);
                  }
                }}
              />
              <button
                type="submit"
                disabled={busy || !draft.trim()}
                className="press grid size-11 shrink-0 place-items-center rounded-md bg-primary-deep text-fg disabled:opacity-40"
                aria-label="Send"
              >
                {mode === "picture" ? <ImageIcon className="size-5" /> : <Send className="size-5" />}
              </button>
            </div>
            <p className="mx-auto mt-2 max-w-3xl text-center text-xs text-faint">
              {cleared ? "Shredded. This visit is empty." : "Not stored. Shred overwrites the thread in this tab."}
            </p>
          </form>
        </section>
      </div>

      <Dialog.Root open={installOpen} onOpenChange={setInstallOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-bg/80" />
          <Dialog.Content className="fixed top-1/2 left-1/2 w-[min(100%-2rem,28rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-line bg-elevated p-5">
            <div className="flex items-start justify-between gap-3">
              <Dialog.Title className="font-display text-xl font-semibold">Install Aurora</Dialog.Title>
              <Dialog.Close className="press grid size-11 place-items-center rounded-md border border-line" aria-label="Close">
                <X className="size-5" />
              </Dialog.Close>
            </div>
            <Dialog.Description className="mt-2 text-sm text-muted">
              Add Aurora to your home screen. It opens full screen, still with no account and with location blocked.
              A separate sideload file is not offered — the installed site is the app.
            </Dialog.Description>
            {installEvent ? (
              <button
                type="button"
                className="press mt-4 inline-flex h-11 w-full items-center justify-center rounded-md bg-primary-deep font-medium"
                onClick={() => {
                  void installEvent.prompt();
                  setInstallEvent(null);
                  setInstallOpen(false);
                }}
              >
                Install now
              </button>
            ) : (
              <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm text-muted">
                <li>Android Chrome: menu, then Install app or Add to Home screen.</li>
                <li>iPhone Safari: Share, then Add to Home Screen.</li>
                <li>Desktop: use the install icon in the address bar when the browser offers it.</li>
              </ol>
            )}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={shredOpen} onOpenChange={setShredOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-bg/80" />
          <Dialog.Content className="fixed top-1/2 left-1/2 w-[min(100%-2rem,26rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-line bg-elevated p-5">
            <Dialog.Title className="font-display text-xl font-semibold">Shred this visit?</Dialog.Title>
            <Dialog.Description className="mt-2 text-sm text-muted">
              Messages, pictures, and notes are overwritten with random data, then dropped. Aurora does not keep a
              copy on an account, because there isn’t one.
            </Dialog.Description>
            <div className="mt-5 flex gap-2">
              <Dialog.Close className="press inline-flex h-11 flex-1 items-center justify-center rounded-md border border-line">
                Keep
              </Dialog.Close>
              <button
                type="button"
                className="press inline-flex h-11 flex-1 items-center justify-center rounded-md bg-danger font-medium text-bg"
                onClick={() => void shred()}
              >
                Shred now
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </main>
  );
}

function ModeSwitch({ mode, onChange }: { mode: Mode; onChange: (mode: Mode) => void }) {
  return (
    <div className="grid h-11 grid-cols-2 rounded-lg border border-line bg-bg p-1">
      {(["talk", "picture"] as const).map((item) => (
        <button
          key={item}
          type="button"
          className={cn(
            "press rounded-md text-sm font-medium",
            mode === item ? "bg-primary-deep text-fg" : "text-muted",
          )}
          onClick={() => onChange(item)}
        >
          {item === "talk" ? "Talk" : "Picture"}
        </button>
      ))}
    </div>
  );
}

function Chip({
  on,
  label,
  onClick,
  icon,
}: {
  on: boolean;
  label: string;
  onClick: () => void;
  icon?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "press inline-flex h-11 items-center gap-1 rounded-md border px-3 text-sm",
        on ? "border-primary bg-primary-deep text-fg" : "border-line text-muted",
      )}
      aria-pressed={on}
    >
      {icon ? <Globe className="size-4" /> : null}
      {label}
    </button>
  );
}
