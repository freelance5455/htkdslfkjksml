import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
  slotId: string; // e.g. '3882999054' or '1065264026'
  client?: string; // 'ca-app-pub-9247061906860945'
  format?: 'auto' | 'fluid' | 'rectangle';
  className?: string;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  slotId,
  client = 'ca-app-pub-9247061906860945',
  format = 'auto',
  className = '',
}) => {
  const adRef = useRef<HTMLModElement | null>(null);
  const pushedRef = useRef<boolean>(false);

  useEffect(() => {
    if (pushedRef.current) return;
    try {
      if (typeof window !== 'undefined') {
        // @ts-expect-error - adsbygoogle is defined globally by Google AdSense
        (window.adsbygoogle = window.adsbygoogle || []).push({});
        pushedRef.current = true;
      }
    } catch {
      // Adblocker or ads script not loaded yet
    }
  }, []);

  return (
    <div className={`w-full max-w-3xl mx-auto my-6 px-2 text-center overflow-hidden ${className}`}>
      <div className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider mb-1.5 flex items-center justify-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
        <span>Sponsored Advertisement</span>
      </div>
      
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5 min-h-[100px] flex items-center justify-center relative overflow-hidden backdrop-blur-sm">
        <ins
          ref={adRef}
          className="adsbygoogle block w-full text-center"
          style={{ display: 'block', minHeight: '90px' }}
          data-ad-client={client}
          data-ad-slot={slotId}
          data-ad-format={format}
          data-full-width-responsive="true"
        />

        {/* Fallback visual indicator if ad is loading or awaiting AdSense crawler */}
        <div className="absolute inset-0 -z-10 flex flex-col items-center justify-center p-4 text-center pointer-events-none opacity-40">
          <span className="text-xs text-slate-400 font-mono">Google Ad Unit: {slotId}</span>
          <span className="text-[10px] text-cyan-400">ID: {client}</span>
        </div>
      </div>
    </div>
  );
};
