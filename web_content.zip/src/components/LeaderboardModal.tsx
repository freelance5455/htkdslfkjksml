import React, { useEffect, useState } from 'react';
import { LeaderboardEntry, PlayerProfile } from '../types';
import { fetchGlobalLeaderboard, signInWithGoogle } from '../firebase';
import { X, Trophy, Flame, UserCheck, LogIn, RefreshCw } from 'lucide-react';

interface LeaderboardModalProps {
  profile: PlayerProfile;
  highScore: number;
  onClose: () => void;
  onProfileUpdated: (updated: PlayerProfile) => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  profile,
  highScore,
  onClose,
  onProfileUpdated,
}) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSigningIn, setIsSigningIn] = useState(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await fetchGlobalLeaderboard(profile.name);
      setEntries(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [profile.name]);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    try {
      const res = await signInWithGoogle();
      if (res.profile) {
        onProfileUpdated(res.profile);
        loadData();
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col max-h-[92vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-400" />
            <h2 className="text-lg font-black text-white">GLOBAL LEADERBOARD</h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={loadData}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Guest Prompt Banner if not Google User */}
        {!profile.isGoogleUser && (
          <div className="my-3 flex flex-col gap-2 rounded-2xl bg-indigo-950/60 p-3 border border-indigo-500/30">
            <div className="flex items-start gap-2 text-left">
              <LogIn className="h-4 w-4 text-indigo-400 mt-0.5 shrink-0" />
              <div className="flex flex-col text-[11px] text-slate-300 leading-tight">
                <span className="font-bold text-white">Playing as Guest</span>
                <span>Sign in with Google to submit your high scores to the global leaderboard!</span>
              </div>
            </div>
            <button
              onClick={handleSignIn}
              disabled={isSigningIn}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-xl bg-white text-slate-900 font-bold text-xs shadow-md active:scale-95 transition-all"
            >
              {/* Google G logo */}
              <svg className="h-3.5 w-3.5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.665-5.17 3.665-9.12z" />
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.13C3.26 21.41 7.36 24 12 24z" />
                <path fill="#FBBC05" d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.58H1.24C.45 8.15 0 9.92 0 12s.45 3.85 1.24 5.42l4.04-3.13z" />
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.59 1.24 6.58l4.04 3.13c.95-2.83 3.6-4.96 6.72-4.96z" />
              </svg>
              <span>{isSigningIn ? 'Signing In...' : 'Sign In with Google'}</span>
            </button>
          </div>
        )}

        {/* Leaderboard Table */}
        <div className="flex flex-col gap-2 overflow-y-auto no-scrollbar py-2">
          {isLoading ? (
            <div className="flex h-40 items-center justify-center text-xs text-slate-500">
              Loading rankings...
            </div>
          ) : entries.length === 0 ? (
            <div className="flex h-40 items-center justify-center text-xs text-slate-500">
              No scores recorded yet. Be the first!
            </div>
          ) : (
            entries.map((entry) => {
              const isTop1 = entry.rank === 1;
              const isTop2 = entry.rank === 2;
              const isTop3 = entry.rank === 3;

              return (
                <div
                  key={`${entry.id}-${entry.rank}`}
                  className={`flex items-center justify-between rounded-2xl p-2.5 border transition-all ${
                    entry.isCurrentPlayer
                      ? 'bg-indigo-950/60 border-indigo-500/60 shadow-[0_0_12px_rgba(99,102,241,0.2)]'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  {/* Rank + Avatar + Name */}
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`flex h-7 w-7 items-center justify-center rounded-xl font-mono text-xs font-black ${
                        isTop1
                          ? 'bg-amber-400 text-slate-950 shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                          : isTop2
                          ? 'bg-slate-300 text-slate-950'
                          : isTop3
                          ? 'bg-amber-700 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {entry.rank}
                    </div>

                    <span className="text-xl">{entry.avatar}</span>

                    <div className="flex flex-col text-left">
                      <span className="text-xs font-bold text-white max-w-[120px] truncate flex items-center gap-1">
                        {entry.playerName}
                        {entry.isCurrentPlayer && (
                          <span className="text-[9px] font-bold text-indigo-400 bg-indigo-500/20 px-1 rounded">
                            YOU
                          </span>
                        )}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {entry.maxCombo}x streak · {entry.date}
                      </span>
                    </div>
                  </div>

                  {/* Score */}
                  <div className="flex items-center gap-1">
                    <span className="font-mono text-base font-black text-amber-300 tabular-nums">
                      {entry.score}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Current Player Rank Footer */}
        <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 text-slate-400">
            <UserCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span>Your Best:</span>
          </div>
          <span className="font-mono font-black text-amber-300 text-sm">{highScore} pts</span>
        </div>
      </div>
    </div>
  );
};
