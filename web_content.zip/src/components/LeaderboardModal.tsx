import React from 'react';
import { X, Trophy, RefreshCw } from 'lucide-react';
import { getHighScores } from '../utils/storage.ts';

interface LeaderboardModalProps {
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ onClose }) => {
  const scores = getHighScores();

  return (
    <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-40 flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-gradient-to-b from-[#180026] via-[#100018] to-black border-4 border-amber-500 rounded-3xl p-5 text-white shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-500/30 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <div>
              <h2 className="text-lg font-black font-press-start text-amber-300">HALL OF FAME</h2>
              <p className="text-xs text-rose-400 font-cairo">أبطال سباق شامسو - الجزائر 🇩🇿</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-gray-800 hover:bg-gray-700 rounded-full text-gray-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scores Table */}
        <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-1 font-mono text-xs">
          {scores.map((entry, index) => {
            const isTop3 = index < 3;
            const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;

            return (
              <div
                key={entry.id || index}
                className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                  isTop3
                    ? 'bg-amber-500/10 border-amber-500/50 text-amber-200'
                    : 'bg-white/5 border-white/10 text-gray-300'
                }`}
              >
                {/* Rank & Name */}
                <div className="flex items-center gap-3">
                  <span className="w-6 text-center text-sm font-bold">{medal}</span>
                  <div className="flex flex-col">
                    <span className="font-bold text-white font-press-start text-[11px] tracking-tight">
                      {entry.name}
                    </span>
                    <span className="text-[10px] text-gray-400 font-cairo">
                      {entry.carName} · {entry.distanceKm} KM
                    </span>
                  </div>
                </div>

                {/* Score */}
                <div className="text-right">
                  <span className="text-base font-black text-amber-400 font-press-start">
                    {entry.score}
                  </span>
                  <span className="text-[9px] text-gray-500 block">{entry.date}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-amber-500/30 flex items-center justify-between text-[11px] text-gray-400 font-cairo">
          <span>يتم حفظ السجلات محلياً في جهازك</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
