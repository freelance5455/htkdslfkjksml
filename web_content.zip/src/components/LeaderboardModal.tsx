/**
 * SPR - Sahil Powerful Run
 * Leaderboard & Hall of Champions Modal
 * With Strict Offline 24-Hour Champion Tribute Reward Cooldown
 */

import React, { useState } from 'react';
import { X, Trophy, Flame, Home, Lock, Sparkles, CheckCircle2 } from 'lucide-react';
import { saveManager } from '../game/storage/SaveManager';
import { soundManager } from '../game/audio/SoundManager';
import { useRewardCooldown } from '../hooks/useRewardCooldown';

interface Props {
  onClose: () => void;
  onRewardClaimed?: () => void;
}

export const LeaderboardModal: React.FC<Props> = ({ onClose, onRewardClaimed }) => {
  const saveData = saveManager.getSaveData();
  const playerHigh = saveData.highScore;
  const playerDist = saveData.highestDistance;

  const { isAvailable, countdown, claim } = useRewardCooldown('leaderboard', 'TRIBUTE');
  const [justClaimed, setJustClaimed] = useState<boolean>(false);

  const tributeCoins = 1000;
  const tributeDiamonds = 2;

  const handleClaimTribute = () => {
    if (!isAvailable) return;

    soundManager.playPowerupSound();
    saveManager.addCoins(tributeCoins);
    saveManager.addDiamonds(tributeDiamonds);
    claim(); // Record offline 24-hour cooldown
    setJustClaimed(true);

    if (onRewardClaimed) onRewardClaimed();
  };

  // Curated global champion runs with dynamic insertion of the player's personal best
  const leaderboardData = [
    { rank: 1, name: 'Sahil - Cosmic Sovereign', score: 142850, distance: 4890, badge: '🥇' },
    { rank: 2, name: 'Sahil - Dragon Warlord', score: 118400, distance: 3950, badge: '🥈' },
    { rank: 3, name: 'Sahil - Solar Knight', score: 96200, distance: 3240, badge: '🥉' },
    { rank: 4, name: 'Sahil - Void Reaper', score: 78500, distance: 2680, badge: '4' },
    { rank: 5, name: 'Sahil - Shadow Ninja', score: 54100, distance: 1890, badge: '5' },
    { rank: 6, name: 'Sahil - Fire Berserker', score: 38700, distance: 1350, badge: '6' },
  ];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-cyan-500/40 rounded-3xl shadow-[0_0_50px_rgba(6,182,212,0.25)] p-5 sm:p-6 flex flex-col gap-3.5 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-400 flex items-center justify-center shadow-lg text-slate-950">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-wider text-white uppercase font-display">
                HALL OF CHAMPIONS
              </h2>
              <p className="text-xs text-slate-400">Global Endless Runner Leaderboard</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="leaderboard-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-4 h-4" />
              <span>HOME</span>
            </button>

            <button
              id="leaderboard-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Player's Current Standing Card */}
        <div className="bg-slate-900/90 border border-amber-500/50 p-3.5 rounded-2xl flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400 font-bold">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-amber-400 font-bold uppercase tracking-wider font-display">YOUR RECORD</div>
              <div className="text-base font-black text-white font-display">
                {playerHigh > 0 ? `${playerHigh.toLocaleString()} PTS` : 'NO RUNS YET'}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-medium">MAX DISTANCE</div>
            <div className="text-sm font-bold text-cyan-300 font-mono">{playerDist} METERS</div>
          </div>
        </div>

        {/* 24-Hour Daily Champion Tribute Section */}
        <div className="p-3 bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-slate-900 border border-cyan-500/40 rounded-2xl flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-cyan-300 font-bold uppercase font-display">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Daily Champion Tribute</span>
            </div>
            <span className="text-[11px] text-amber-300 font-bold">
              +1,000 🪙 &amp; +2 💎
            </span>
          </div>

          {justClaimed && (
            <div className="py-1.5 bg-emerald-950/90 border border-emerald-400/60 rounded-xl text-center text-xs text-emerald-300 font-bold animate-bounce flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Tribute Claimed! +1,000 Coins &amp; +2 Diamonds added!</span>
            </div>
          )}

          {!isAvailable ? (
            <button
              disabled
              className="w-full py-2.5 bg-slate-800/90 border border-slate-700 text-slate-300 font-mono font-black text-xs sm:text-sm tracking-wider rounded-xl flex items-center justify-center gap-2 cursor-not-allowed shadow-inner"
            >
              <Lock className="w-4 h-4 text-amber-400" />
              <span>NEXT TRIBUTE IN {countdown}</span>
            </button>
          ) : (
            <button
              id="leaderboard-btn-tribute"
              onClick={handleClaimTribute}
              className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl transition shadow-[0_0_20px_rgba(6,182,212,0.4)] active:scale-95 cursor-pointer font-display flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>CLAIM DAILY CHAMPION TRIBUTE (+1,000 🪙 +2 💎)</span>
            </button>
          )}
        </div>

        {/* Leaderboard Table List */}
        <div className="flex flex-col gap-2 max-h-52 overflow-y-auto pr-1">
          {leaderboardData.map((entry) => (
            <div
              key={entry.rank}
              className="flex items-center justify-between p-2.5 bg-slate-950/70 border border-slate-800/80 rounded-xl hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3">
                <span className="w-6 text-center text-sm font-bold text-slate-400">
                  {entry.badge}
                </span>
                <div>
                  <div className="text-xs font-bold text-white font-display">{entry.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{entry.distance}m reached</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-black text-amber-400 font-display">
                  {entry.score.toLocaleString()} PTS
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
