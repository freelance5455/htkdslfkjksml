import React from 'react';
import { X, Trophy, Medal } from 'lucide-react';
import { GLOBAL_LEADERBOARD } from '../game/storeData';

interface LeaderboardModalProps {
  playerHighScore: number;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  playerHighScore,
  onClose
}) => {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-2xl h-[85vh] max-h-[700px] shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center text-xl">
              🏆
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">لوحة الصدارة العالمية</h2>
              <div className="text-xs text-slate-400">أقوى الأرقام القياسية لأبطال الهروب من جميع الدول</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Your personal high score highlight banner */}
        <div className="bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 border-b border-amber-500/30 p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black">
              أنت
            </div>
            <div>
              <div className="text-xs font-bold text-amber-300">ترتيبك الشخصي: #14 عالمياً</div>
              <div className="text-xs text-slate-400">سجل أعلى هروب لتحطيم أرقام الصدارة!</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-bold">أعلى رقم لك</div>
            <div className="text-base font-black text-white tabular-nums">
              {playerHighScore.toLocaleString('ar-EG')} نقطة
            </div>
          </div>
        </div>

        {/* Leaderboard Table List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {GLOBAL_LEADERBOARD.map((entry) => {
            const isTop3 = entry.rank <= 3;

            return (
              <div
                key={entry.rank}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  entry.rank === 1
                    ? 'bg-amber-950/40 border-amber-500/60'
                    : entry.rank === 2
                    ? 'bg-slate-800/80 border-slate-500'
                    : entry.rank === 3
                    ? 'bg-amber-950/20 border-amber-700/50'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank badge */}
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm ${
                      entry.rank === 1
                        ? 'bg-amber-400 text-slate-950'
                        : entry.rank === 2
                        ? 'bg-slate-300 text-slate-950'
                        : entry.rank === 3
                        ? 'bg-amber-700 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isTop3 ? <Medal className="w-4 h-4" /> : `#${entry.rank}`}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5 font-extrabold text-white text-sm">
                      <span>{entry.flag}</span>
                      <span>{entry.name}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-medium">
                      {entry.country} · {entry.date}
                    </div>
                  </div>
                </div>

                <div className="text-left font-black text-base text-amber-400 tabular-nums">
                  {entry.score.toLocaleString('ar-EG')}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
