import React, { useState } from 'react';
import { Voice, VoiceCategory } from '../types/voice';
import {
  Mic2,
  Volume2,
  VolumeX,
  Search,
  Check,
  Sparkles,
  Fingerprint,
  Zap,
} from 'lucide-react';
import { speakWithWebSpeech } from '../utils/audioSynthesizer';

interface VoiceCatalogProps {
  voices: Voice[];
  selectedVoice: Voice;
  onSelectVoice: (voice: Voice) => void;
  onOpenCloneModal: () => void;
}

const CATEGORIES: { id: VoiceCategory; label: string; icon?: string }[] = [
  { id: 'all', label: 'All Voices' },
  { id: 'elevenlabs', label: '⚡ ElevenLabs' },
  { id: 'cartesia', label: '🌊 Cartesia' },
  { id: 'cloned', label: '🧬 My Cloned' },
  { id: 'hindi', label: '🇮🇳 Hindi / Indian' },
  { id: 'english', label: '🇺🇸/🇬🇧 English' },
  { id: 'global', label: '🌍 Global' },
  { id: 'conversational', label: '💬 Conversational' },
  { id: 'narration', label: '📖 Narration' },
  { id: 'character', label: '🎭 Character' },
];

export const VoiceCatalog: React.FC<VoiceCatalogProps> = ({
  voices,
  selectedVoice,
  onSelectVoice,
  onOpenCloneModal,
}) => {
  const [activeCategory, setActiveCategory] = useState<VoiceCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewingVoiceId, setPreviewingVoiceId] = useState<string | null>(null);

  const elevenLabsCount = voices.filter((v) => v.provider === 'ElevenLabs').length;
  const cartesiaCount = voices.filter((v) => v.provider === 'Cartesia').length;
  const clonedCount = voices.filter((v) => v.isCloned).length;

  const filteredVoices = voices.filter((v) => {
    let matchesCategory = false;
    if (activeCategory === 'all') {
      matchesCategory = true;
    } else if (activeCategory === 'elevenlabs') {
      matchesCategory = v.provider === 'ElevenLabs' || v.category === 'elevenlabs';
    } else if (activeCategory === 'cartesia') {
      matchesCategory = v.provider === 'Cartesia';
    } else if (activeCategory === 'cloned') {
      matchesCategory = Boolean(v.isCloned);
    } else if (activeCategory === 'hindi') {
      matchesCategory =
        v.category === 'hindi' ||
        v.language.toLowerCase().includes('hindi') ||
        v.accent.toLowerCase().includes('hindi') ||
        v.tag.toLowerCase().includes('hindi');
    } else if (activeCategory === 'english') {
      matchesCategory =
        v.category === 'english' ||
        v.accent.toLowerCase().includes('us') ||
        v.accent.toLowerCase().includes('british') ||
        v.accent.toLowerCase().includes('american') ||
        v.accent.toLowerCase().includes('australian');
    } else {
      matchesCategory = v.category === activeCategory;
    }

    const matchesSearch =
      searchQuery.trim() === ''
        ? true
        : v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.accent.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.language.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (v.provider && v.provider.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  const handlePreviewSample = (e: React.MouseEvent, voice: Voice) => {
    e.stopPropagation();

    if (previewingVoiceId === voice.id) {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setPreviewingVoiceId(null);
      return;
    }

    setPreviewingVoiceId(voice.id);
    speakWithWebSpeech(
      voice.samplePhrase,
      voice,
      1.0,
      1.0,
      () => {},
      () => {
        setPreviewingVoiceId(null);
      }
    );
  };

  return (
    <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4 shadow-xl h-[640px] border border-gray-800">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-gray-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-950/80 border border-indigo-700/50 flex items-center justify-center text-indigo-400">
            <Mic2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-gray-100 flex items-center gap-2">
              Voice Catalog
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-0.5">
                <Zap className="w-2.5 h-2.5 fill-amber-400" /> ElevenLabs + Cartesia
              </span>
            </h2>
            <p className="text-[11px] text-gray-400">
              {elevenLabsCount} ElevenLabs • {cartesiaCount} Cartesia • {clonedCount} Cloned
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCloneModal}
            className="px-2.5 py-1 text-xs bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-medium rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer"
          >
            <Fingerprint className="w-3.5 h-3.5" />
            <span>Clone</span>
          </button>
          <span className="text-xs bg-indigo-950/90 text-indigo-300 border border-indigo-800/60 px-2.5 py-0.5 rounded-full font-mono font-medium">
            {voices.length} Voices
          </span>
        </div>
      </div>

      {/* Category Filter Horizontal Scroll */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-xs">
        {CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat.id;
          let countBadge = 0;
          if (cat.id === 'elevenlabs') countBadge = elevenLabsCount;
          else if (cat.id === 'cartesia') countBadge = cartesiaCount;
          else if (cat.id === 'cloned') countBadge = clonedCount;

          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-gray-900/80 hover:bg-gray-800 text-gray-300 border border-gray-800'
              }`}
            >
              <span>{cat.label}</span>
              {countBadge > 0 && (
                <span
                  className={`ml-1 px-1.5 py-0.2 text-[10px] rounded-full font-mono ${
                    isActive ? 'bg-indigo-800 text-white' : 'bg-gray-800 text-indigo-300'
                  }`}
                >
                  {countBadge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search voice by name, Rachel, Adam, Hindi, British..."
          className="w-full bg-gray-900/90 border border-gray-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-indigo-500/80 transition"
        />
      </div>

      {/* Voice Selection List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-2 pr-1">
        {filteredVoices.length === 0 ? (
          <div className="h-44 flex flex-col items-center justify-center text-center p-4 text-gray-500 text-xs">
            {activeCategory === 'cloned' ? (
              <>
                <Fingerprint className="w-8 h-8 text-indigo-400/50 mb-2" />
                <p className="text-gray-300 font-medium mb-1">No custom cloned voices yet</p>
                <p className="text-gray-500 mb-3 text-[11px]">
                  Record your voice via mic or upload an audio file to clone instantly!
                </p>
                <button
                  onClick={onOpenCloneModal}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Create Cloned Voice
                </button>
              </>
            ) : (
              <p>No voices matching &quot;{searchQuery}&quot;</p>
            )}
          </div>
        ) : (
          filteredVoices.map((voice) => {
            const isSelected = selectedVoice.id === voice.id;
            const isPreviewing = previewingVoiceId === voice.id;
            const isElevenLabs = voice.provider === 'ElevenLabs';

            return (
              <div
                key={voice.id}
                onClick={() => onSelectVoice(voice)}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 text-left ${
                  isSelected
                    ? 'bg-indigo-950/40 border-indigo-500/80 shadow-md shadow-indigo-900/20 ring-1 ring-indigo-500/30'
                    : 'bg-gray-900/50 hover:bg-gray-900 border-gray-800/80 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${voice.avatarBg} flex items-center justify-center text-white font-bold text-xs shadow-sm shrink-0`}
                  >
                    {voice.avatarLetter}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-bold text-gray-100 truncate">
                        {voice.name}
                      </span>

                      {/* Provider Badge */}
                      {isElevenLabs ? (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium flex items-center gap-0.5">
                          <Zap className="w-2.5 h-2.5 fill-amber-400" /> ElevenLabs
                        </span>
                      ) : voice.isCloned ? (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-violet-600/30 text-violet-300 border border-violet-500/40 flex items-center gap-1">
                          <Sparkles className="w-2.5 h-2.5 text-violet-400" /> Cloned
                        </span>
                      ) : (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/50 font-mono">
                          Cartesia
                        </span>
                      )}

                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-950/90 text-indigo-300 border border-indigo-800/60 font-mono">
                        {voice.tag}
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-400 truncate mt-0.5">
                      {voice.accent} • {voice.gender}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Quick Preview Button */}
                  <button
                    onClick={(e) => handlePreviewSample(e, voice)}
                    className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
                      isPreviewing
                        ? 'bg-indigo-600 text-white border-indigo-500 animate-pulse'
                        : 'bg-gray-800/70 hover:bg-gray-800 text-gray-300 hover:text-white border-gray-700'
                    }`}
                    title="Preview Voice Sample"
                  >
                    {isPreviewing ? (
                      <VolumeX className="w-3.5 h-3.5" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Selected Indicator */}
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                      isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'border border-gray-700 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Selected Voice Info Banner at bottom */}
      <div className="mt-auto bg-indigo-950/40 border border-indigo-800/40 rounded-xl p-3 flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-9 h-9 rounded-full bg-gradient-to-tr ${selectedVoice.avatarBg} flex items-center justify-center text-white font-bold text-xs shadow-md shrink-0 ring-2 ring-indigo-500/50`}
          >
            {selectedVoice.avatarLetter}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-gray-100 truncate">
                {selectedVoice.name}
              </span>
              {selectedVoice.provider === 'ElevenLabs' && (
                <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded border border-amber-500/30 font-medium">
                  ⚡ ElevenLabs Official
                </span>
              )}
              <span className="text-[10px] px-1.5 py-0.2 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                {selectedVoice.tag}
              </span>
            </div>
            <p className="text-[11px] text-gray-400 truncate mt-0.5">
              {selectedVoice.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
