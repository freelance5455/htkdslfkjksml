import React, { useId } from 'react';
import { WallpaperId } from '../types/system';

interface WallpaperBackdropProps {
  wallpaperId: WallpaperId;
  className?: string;
}

/**
 * Pure static, zero-CPU vector & gradient wallpaper renderer with per-instance
 * scoped SVG IDs (fixing gradient ID collisions when previews and backdrop mount together).
 */
export const WallpaperBackdrop: React.FC<WallpaperBackdropProps> = React.memo(
  ({ wallpaperId, className = 'w-full h-full' }) => {
    const uid = useId().replace(/:/g, '');

    const renderWaveSvg = (
      bgStart: string,
      bgMid: string,
      bgEnd: string,
      wave1: string,
      wave2: string,
      wave3: string,
      rimStroke: string,
      extra?: React.ReactNode
    ) => (
      <svg
        viewBox="0 0 1600 900"
        preserveAspectRatio="xMidYMid slice"
        className={className}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id={`bg-${uid}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={bgStart} />
            <stop offset="52%" stopColor={bgMid} />
            <stop offset="100%" stopColor={bgEnd} />
          </linearGradient>
          <linearGradient id={`w1-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor={wave1} stopOpacity="0.85" />
            <stop offset="50%" stopColor={wave2} stopOpacity="0.6" />
            <stop offset="100%" stopColor={wave1} stopOpacity="0.85" />
          </linearGradient>
          <linearGradient id={`w2-${uid}`} x1="0" y1="1" x2="1" y2="0">
            <stop offset="0%" stopColor={wave2} stopOpacity="0.7" />
            <stop offset="100%" stopColor={wave3} stopOpacity="0.5" />
          </linearGradient>
        </defs>

        <rect width="1600" height="900" fill={`url(#bg-${uid})`} />

        <path
          d="M0 470 C 320 330, 560 610, 920 440 C 1220 300, 1420 430, 1600 370 L 1600 900 L 0 900 Z"
          fill={`url(#w1-${uid})`}
        />

        <path
          d="M0 570 C 280 680, 590 420, 940 560 C 1230 675, 1440 500, 1600 540 L 1600 900 L 0 900 Z"
          fill={`url(#w2-${uid})`}
        />

        <path
          d="M0 710 C 340 590, 690 770, 1080 650 C 1320 580, 1480 660, 1600 630 L 1600 900 L 0 900 Z"
          fill={wave3}
          fillOpacity="0.72"
        />
        <path
          d="M0 470 C 320 330, 560 610, 920 440 C 1220 300, 1420 430, 1600 370"
          fill="none"
          stroke={rimStroke}
          strokeWidth="2.5"
          strokeOpacity="0.65"
        />
        <path
          d="M0 570 C 280 680, 590 420, 940 560 C 1230 675, 1440 500, 1600 540"
          fill="none"
          stroke={rimStroke}
          strokeWidth="1.8"
          strokeOpacity="0.45"
        />

        {extra}
      </svg>
    );

    switch (wallpaperId) {
      case 'blue-wavy-symbols':
        return renderWaveSvg(
          '#030d24',
          '#08245c',
          '#04112e',
          '#0e3a8a',
          '#1d4ed8',
          '#071b44',
          '#60a5fa',
          <g fill="none" stroke="#93c5fd" strokeWidth="3.2" strokeLinecap="square">
            <rect x="170" y="210" width="38" height="38" opacity="0.28" transform="rotate(14 189 229)" />
            <rect x="760" y="160" width="28" height="28" opacity="0.22" transform="rotate(-18 774 174)" />
            <rect x="1310" y="290" width="44" height="44" opacity="0.3" transform="rotate(22 1332 312)" />
            <rect x="440" y="610" width="32" height="32" opacity="0.22" transform="rotate(-10 456 626)" />

            <polygon points="360,260 386,306 334,306" opacity="0.3" transform="rotate(-12 360 288)" />
            <polygon points="1030,210 1054,252 1006,252" opacity="0.26" transform="rotate(16 1030 236)" />
            <polygon points="1450,510 1478,558 1422,558" opacity="0.24" transform="rotate(-22 1450 540)" />
            <polygon points="880,690 906,734 854,734" opacity="0.22" transform="rotate(10 880 718)" />

            <circle cx="570" cy="240" r="21" opacity="0.26" />
            <circle cx="1175" cy="430" r="24" opacity="0.3" />
            <circle cx="230" cy="540" r="18" opacity="0.24" />
            <circle cx="660" cy="510" r="15" opacity="0.2" />
            <circle cx="1290" cy="690" r="22" opacity="0.24" />
          </g>
        );

      case 'red-horns':
        return renderWaveSvg(
          '#190306',
          '#4b0812',
          '#150205',
          '#7f1d1d',
          '#b91c1c',
          '#2d060b',
          '#fb7185',
          <g>
            <defs>
              <linearGradient id={`horn-l-${uid}`} x1="0" y1="1" x2="0.6" y2="0">
                <stop offset="0%" stopColor="#450a0a" />
                <stop offset="65%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#fecdd3" />
              </linearGradient>
              <linearGradient id={`horn-r-${uid}`} x1="1" y1="1" x2="0.4" y2="0">
                <stop offset="0%" stopColor="#450a0a" />
                <stop offset="65%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#fecdd3" />
              </linearGradient>
            </defs>
            <path
              d="M 190 900 C 160 720, 210 540, 390 360 C 460 290, 520 200, 500 130 C 455 215, 360 285, 250 385 C 110 515, 65 690, 85 900 Z"
              fill={`url(#horn-l-${uid})`}
              fillOpacity="0.88"
            />
            <path
              d="M 1410 900 C 1440 720, 1390 540, 1210 360 C 1140 290, 1080 200, 1100 130 C 1145 215, 1240 285, 1350 385 C 1490 515, 1535 690, 1515 900 Z"
              fill={`url(#horn-r-${uid})`}
              fillOpacity="0.88"
            />
            <path
              d="M 275 840 C 260 690, 300 540, 445 385"
              fill="none"
              stroke="#fda4af"
              strokeWidth="2.5"
              strokeOpacity="0.45"
            />
            <path
              d="M 1325 840 C 1340 690, 1300 540, 1155 385"
              fill="none"
              stroke="#fda4af"
              strokeWidth="2.5"
              strokeOpacity="0.45"
            />
          </g>
        );

      case 'green-wave':
        return renderWaveSvg(
          '#03150d',
          '#064e3b',
          '#02120a',
          '#047857',
          '#10b981',
          '#062c1e',
          '#6ee7b7'
        );

      case 'pink-wave':
        return renderWaveSvg(
          '#1c0414',
          '#6b1046',
          '#160310',
          '#9d174d',
          '#ec4899',
          '#380923',
          '#f9a8d4'
        );

      case 'yellow-wave':
        return renderWaveSvg(
          '#1a1202',
          '#5c4106',
          '#140e02',
          '#a16207',
          '#eab308',
          '#332404',
          '#fde047'
        );

      case 'brown-wave':
        return renderWaveSvg(
          '#140c06',
          '#3d2312',
          '#100904',
          '#6b3c1e',
          '#9a5b2e',
          '#26150a',
          '#d69e6e'
        );

      case 'spiked-loops':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`sp-bg-${uid}`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#050816" />
                <stop offset="50%" stopColor="#0f1738" />
                <stop offset="100%" stopColor="#060b1d" />
              </linearGradient>
              <linearGradient id={`sp-wave-${uid}`} x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.85" />
                <stop offset="50%" stopColor="#818cf8" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.85" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#sp-bg-${uid})`} />

            <path
              d="M0 640 L 140 500 L 230 590 L 370 390 L 470 540 L 630 330 L 760 520 L 920 350 L 1060 530 L 1220 370 L 1360 540 L 1490 430 L 1600 540 L 1600 900 L 0 900 Z"
              fill="#0c1b42"
              fillOpacity="0.82"
            />
            <path
              d="M0 640 L 140 500 L 230 590 L 370 390 L 470 540 L 630 330 L 760 520 L 920 350 L 1060 530 L 1220 370 L 1360 540 L 1490 430 L 1600 540"
              fill="none"
              stroke={`url(#sp-wave-${uid})`}
              strokeWidth="2.8"
            />

            <g fill="none" stroke={`url(#sp-wave-${uid})`} strokeOpacity="0.72">
              <path
                d="M-60 520 C 160 250, 360 760, 520 450 C 660 180, 420 180, 560 460 C 700 740, 920 200, 1080 480 C 1220 720, 1020 720, 1150 470 C 1280 220, 1460 660, 1660 440"
                strokeWidth="3.2"
              />
              <path
                d="M-40 560 C 180 300, 390 790, 540 490 C 680 220, 450 220, 590 500 C 730 780, 950 240, 1110 520 C 1250 760, 1050 760, 1180 510 C 1310 260, 1490 700, 1660 480"
                strokeWidth="1.8"
                strokeOpacity="0.45"
              />
            </g>

            <g transform="translate(800 450)" fill="none" stroke="#7dd3fc" strokeOpacity="0.28">
              <ellipse rx="320" ry="95" transform="rotate(0)" strokeWidth="1.6" />
              <ellipse rx="320" ry="95" transform="rotate(30)" strokeWidth="1.6" />
              <ellipse rx="320" ry="95" transform="rotate(60)" strokeWidth="1.6" />
              <ellipse rx="320" ry="95" transform="rotate(90)" strokeWidth="1.6" />
              <ellipse rx="320" ry="95" transform="rotate(120)" strokeWidth="1.6" />
              <ellipse rx="320" ry="95" transform="rotate(150)" strokeWidth="1.6" />
            </g>

            <path
              d="M0 760 L 180 650 L 310 730 L 490 610 L 650 740 L 820 590 L 990 730 L 1180 620 L 1350 740 L 1510 660 L 1600 720 L 1600 900 L 0 900 Z"
              fill="#070e24"
              fillOpacity="0.9"
            />
          </svg>
        );

      case 'abyssal-prism':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`ab-bg-${uid}`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#03111c" />
                <stop offset="55%" stopColor="#072840" />
                <stop offset="100%" stopColor="#020b14" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#ab-bg-${uid})`} />
            <polygon points="0,900 480,320 920,900" fill="#0c4a6e" fillOpacity="0.45" />
            <polygon points="420,900 980,220 1540,900" fill="#0369a1" fillOpacity="0.35" />
            <polygon points="880,900 1320,380 1600,720 1600,900" fill="#0284c7" fillOpacity="0.28" />
            <polyline
              points="0,680 480,320 980,220 1320,380 1600,260"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              strokeOpacity="0.55"
            />
          </svg>
        );

      case 'arctic-aurora':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`au-bg-${uid}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#030a18" />
                <stop offset="65%" stopColor="#0a203b" />
                <stop offset="100%" stopColor="#040b16" />
              </linearGradient>
              <linearGradient id={`au-curtain-${uid}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0" />
                <stop offset="45%" stopColor="#2dd4bf" stopOpacity="0.42" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0.06" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#au-bg-${uid})`} />
            <path
              d="M0 240 C 380 120, 620 420, 1020 260 C 1280 160, 1460 280, 1600 220 L 1600 680 C 1320 560, 980 720, 640 580 C 320 450, 160 620, 0 540 Z"
              fill={`url(#au-curtain-${uid})`}
            />
            <path
              d="M0 720 C 420 620, 820 770, 1240 660 C 1420 615, 1520 650, 1600 635 L 1600 900 L 0 900 Z"
              fill="#040c18"
            />
          </svg>
        );

      case 'cyber-grid':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`cg-bg-${uid}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#030616" />
                <stop offset="56%" stopColor="#0b1a46" />
                <stop offset="100%" stopColor="#040714" />
              </linearGradient>
              <linearGradient id={`cg-sun-${uid}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#93c5fd" />
                <stop offset="55%" stopColor="#2563eb" />
                <stop offset="100%" stopColor="#1e1b4b" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#cg-bg-${uid})`} />
            <circle cx="800" cy="480" r="190" fill={`url(#cg-sun-${uid})`} fillOpacity="0.45" />
            <rect x="0" y="510" width="1600" height="390" fill="#04091b" fillOpacity="0.92" />
            <g stroke="#38bdf8" strokeOpacity="0.34" strokeWidth="1.5">
              <line x1="0" y1="510" x2="1600" y2="510" strokeOpacity="0.7" />
              <line x1="0" y1="548" x2="1600" y2="548" />
              <line x1="0" y1="600" x2="1600" y2="600" />
              <line x1="0" y1="670" x2="1600" y2="670" />
              <line x1="0" y1="765" x2="1600" y2="765" />
              <line x1="800" y1="510" x2="800" y2="900" />
              <line x1="720" y1="510" x2="460" y2="900" />
              <line x1="880" y1="510" x2="1140" y2="900" />
              <line x1="640" y1="510" x2="80" y2="900" />
              <line x1="960" y1="510" x2="1520" y2="900" />
              <line x1="560" y1="510" x2="-300" y2="900" />
              <line x1="1040" y1="510" x2="1900" y2="900" />
            </g>
          </svg>
        );

      case 'obsidian-starfield':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <radialGradient id={`os-neb-${uid}`} cx="55%" cy="42%" r="58%">
                <stop offset="0%" stopColor="#1d4ed8" stopOpacity="0.38" />
                <stop offset="48%" stopColor="#0f172a" stopOpacity="0.65" />
                <stop offset="100%" stopColor="#02040a" />
              </radialGradient>
            </defs>
            <rect width="1600" height="900" fill="#02040a" />
            <rect width="1600" height="900" fill={`url(#os-neb-${uid})`} />
            <g fill="#bae6fd" opacity="0.72">
              <circle cx="180" cy="180" r="2" />
              <circle cx="340" cy="290" r="1.4" />
              <circle cx="520" cy="140" r="2.2" />
              <circle cx="710" cy="240" r="1.6" />
              <circle cx="940" cy="160" r="2.1" />
              <circle cx="1180" cy="260" r="1.5" />
              <circle cx="1390" cy="170" r="2.2" />
              <circle cx="290" cy="610" r="1.8" />
              <circle cx="640" cy="540" r="2.0" />
              <circle cx="1040" cy="620" r="1.8" />
              <circle cx="1320" cy="560" r="2.1" />
            </g>
            <g stroke="#38bdf8" strokeOpacity="0.24" strokeWidth="1.2" fill="none">
              <polyline points="180,180 340,290 520,140 710,240" />
              <polyline points="940,160 1180,260 1390,170" />
            </g>
          </svg>
        );

      case 'violet-vortex':
        return renderWaveSvg(
          '#0d051c',
          '#3b0764',
          '#0b0417',
          '#5b21b6',
          '#7c3aed',
          '#1e0938',
          '#c4b5fd',
          <g transform="translate(800 420)" fill="none" stroke="#a78bfa" strokeOpacity="0.32">
            <circle r="140" strokeWidth="1.8" />
            <circle r="240" strokeWidth="1.4" strokeDasharray="14 10" />
            <circle r="350" strokeWidth="1.2" />
            <circle r="470" strokeWidth="1.0" strokeDasharray="6 14" />
          </g>
        );

      case 'crimson-eclipse':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <radialGradient id={`ce-glow-${uid}`} cx="50%" cy="48%" r="42%">
                <stop offset="0%" stopColor="#fecdd3" stopOpacity="0.85" />
                <stop offset="28%" stopColor="#dc2626" stopOpacity="0.65" />
                <stop offset="68%" stopColor="#450a0a" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#090204" stopOpacity="0" />
              </radialGradient>
            </defs>
            <rect width="1600" height="900" fill="#090204" />
            <circle cx="800" cy="430" r="360" fill={`url(#ce-glow-${uid})`} />
            <circle cx="800" cy="430" r="145" fill="#070203" stroke="#fb7185" strokeWidth="2.5" strokeOpacity="0.8" />
            <path
              d="M0 700 C 400 620, 1200 620, 1600 700 L 1600 900 L 0 900 Z"
              fill="#140307"
              fillOpacity="0.92"
            />
          </svg>
        );

      case 'teal-circuit':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`tc-bg-${uid}`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#031317" />
                <stop offset="55%" stopColor="#082830" />
                <stop offset="100%" stopColor="#020e12" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#tc-bg-${uid})`} />
            <g fill="none" stroke="#2dd4bf" strokeWidth="2" strokeOpacity="0.34">
              <polyline points="0,240 280,240 360,320 690,320 750,260 1120,260" />
              <polyline points="1600,610 1260,610 1180,530 820,530 760,590 420,590 340,670 0,670" />
              <polyline points="220,900 220,760 310,670" />
              <polyline points="1360,0 1360,180 1240,300 920,300" />
            </g>
            <g fill="#5eead4" opacity="0.55">
              <circle cx="360" cy="320" r="5" />
              <circle cx="690" cy="320" r="5" />
              <circle cx="1120" cy="260" r="6" />
              <circle cx="820" cy="530" r="5" />
              <circle cx="420" cy="590" r="5" />
              <circle cx="920" cy="300" r="6" />
            </g>
          </svg>
        );

      case 'midnight-crystal':
        return (
          <svg
            viewBox="0 0 1600 900"
            preserveAspectRatio="xMidYMid slice"
            className={className}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`mc-bg-${uid}`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#030918" />
                <stop offset="55%" stopColor="#0a1e42" />
                <stop offset="100%" stopColor="#030816" />
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill={`url(#mc-bg-${uid})`} />
            <g stroke="#7dd3fc" strokeOpacity="0.28" strokeWidth="1.2">
              <polygon points="180,900 360,420 560,900" fill="#1e3a8a" fillOpacity="0.32" />
              <polygon points="480,900 760,240 1040,900" fill="#1d4ed8" fillOpacity="0.26" />
              <polygon points="920,900 1220,360 1480,900" fill="#0284c7" fillOpacity="0.24" />
              <polygon points="760,240 1040,900 1220,360" fill="#0f172a" fillOpacity="0.35" />
            </g>
          </svg>
        );

      case 'monochrome-horizon':
      default:
        return renderWaveSvg(
          '#07090f',
          '#111827',
          '#05070c',
          '#1e293b',
          '#334155',
          '#0b111e',
          '#38bdf8'
        );
    }
  }
);
WallpaperBackdrop.displayName = 'WallpaperBackdrop';
