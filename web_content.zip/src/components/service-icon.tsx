import { BookOpen, HeartHandshake, Monitor, PawPrint, Sparkles, Wrench } from "lucide-react";
import type { ServiceIcon } from "@/lib/catalog";

const icons = {
  limpeza: Sparkles,
  reparo: Wrench,
  aula: BookOpen,
  pet: PawPrint,
  companhia: HeartHandshake,
  info: Monitor,
};

export function ServiceGlyph({ icon, className }: { icon: ServiceIcon; className?: string }) {
  const Icon = icons[icon];
  return <Icon className={className} strokeWidth={1.75} aria-hidden="true" />;
}
