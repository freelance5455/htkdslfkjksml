import React, { useEffect, useState } from 'react';

interface WaveformVisualizerProps {
  isPlaying: boolean;
  preset?: string;
  barCount?: number;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({
  isPlaying,
  preset = '528hz',
  barCount = 20,
}) => {
  const [heights, setHeights] = useState<number[]>(Array(barCount).fill(15));

  useEffect(() => {
    let interval: number;
    if (isPlaying) {
      interval = window.setInterval(() => {
        setHeights(
          Array.from({ length: barCount }, () => {
            const min = 8;
            const max = 36;
            return Math.floor(Math.random() * (max - min + 1)) + min;
          })
        );
      }, 120);
    } else {
      setHeights(Array(barCount).fill(6));
    }
    return () => clearInterval(interval);
  }, [isPlaying, barCount]);

  const getPresetColor = () => {
    switch (preset) {
      case '432hz':
        return 'bg-purple-400';
      case 'angelic':
        return 'bg-sky-300';
      case 'warfare':
        return 'bg-rose-400';
      case 'soaking':
        return 'bg-amber-300';
      default:
        return 'bg-amber-400';
    }
  };

  return (
    <div className="flex items-center space-x-1 h-10 px-2 py-1 bg-slate-950/40 rounded-xl border border-amber-500/10 overflow-hidden">
      {heights.map((h, i) => (
        <div
          key={i}
          style={{ height: `${h}px` }}
          className={`w-1 rounded-full transition-all duration-150 ${getPresetColor()} ${
            isPlaying ? 'opacity-90' : 'opacity-30'
          }`}
        />
      ))}
    </div>
  );
};
