const maxOf = (areas) => Math.max(1, ...areas.map((row) => row.total));

export default function AreaBars({ areas }) {
  const max = maxOf(areas);

  if (!areas.length) {
    return <p className="text-sm text-muted-foreground">No reports in this view yet.</p>;
  }

  return (
    <ul className="space-y-3.5">
      {areas.map((row) => {
        const clearedPct = Math.round((row.resolved / Math.max(1, row.total)) * 100);
        return (
          <li key={row.area}>
            <div className="flex items-baseline justify-between gap-3 text-[12px]">
              <span className="font-medium text-foreground">{row.area}</span>
              <span className="tabular-nums text-muted-foreground">
                {row.total} total · {clearedPct}% cleared
              </span>
            </div>
            <div className="mt-2 flex h-2 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full bg-[#16653f]"
                style={{ width: `${(row.resolved / max) * 100}%` }}
              />
              <div
                className="h-full bg-[#c9a05f]"
                style={{ width: `${(row.open / max) * 100}%` }}
              />
            </div>
          </li>
        );
      })}
    </ul>
  );
}