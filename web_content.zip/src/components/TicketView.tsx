"use client";

/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { QRCodeSVG } from "qrcode.react";
import { COUNTRIES } from "@/lib/data";
import { useLang } from "@/lib/i18n";

export type TicketData = {
  ref: string;
  name: string;
  visitDate: string;
  tickets: number;
  total: number;
  attraction: {
    slug: string;
    nameEn: string;
    nameAr: string;
    cityEn: string;
    cityAr: string;
    countryCode: string;
    image: string;
  };
};

export default function TicketView({ data }: { data: TicketData }) {
  const { lang, t } = useLang();
  const a = data.attraction;
  const country = COUNTRIES[a.countryCode];
  const dateLabel = new Date(`${data.visitDate}T12:00:00`).toLocaleDateString(lang === "ar" ? "ar" : "en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="mx-auto max-w-xl px-4 py-10">
      <div className="mb-6 text-center">
        <div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-3xl">✅</div>
        <h1 className="text-2xl font-extrabold text-slate-900">{t("bookingConfirmed")}</h1>
      </div>

      <div className="overflow-hidden rounded-3xl bg-white shadow-xl ring-1 ring-slate-200 print:shadow-none">
        <div className="relative h-40">
          <img src={a.image} alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-4 text-white">
            <div className="text-xs opacity-90">
              {country?.flag} {lang === "ar" ? a.cityAr : a.cityEn} · {country?.[lang]}
            </div>
            <div className="text-lg font-bold">{lang === "ar" ? a.nameAr : a.nameEn}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 p-6 text-sm">
          <div>
            <div className="text-slate-500">{t("guest")}</div>
            <div className="font-semibold">{data.name}</div>
          </div>
          <div>
            <div className="text-slate-500">{t("tickets")}</div>
            <div className="font-semibold">{data.tickets}</div>
          </div>
          <div className="col-span-2">
            <div className="text-slate-500">{t("date")}</div>
            <div className="font-semibold">{dateLabel}</div>
          </div>
          <div>
            <div className="text-slate-500">{t("total")}</div>
            <div className="text-lg font-extrabold text-indigo-700">€{data.total}</div>
          </div>
        </div>

        <div className="relative border-t-2 border-dashed border-slate-200 p-6 text-center">
          <span className="absolute -start-3 -top-3 h-6 w-6 rounded-full bg-slate-100" />
          <span className="absolute -end-3 -top-3 h-6 w-6 rounded-full bg-slate-100" />
          <div className="mx-auto w-fit rounded-2xl bg-white p-3 ring-1 ring-slate-200">
            <QRCodeSVG value={`EUROTIX:${data.ref}`} size={150} />
          </div>
          <p className="mt-3 text-xs text-slate-500">{t("showQr")}</p>
          <div className="mt-1 text-xs text-slate-500">{t("bookingRef")}</div>
          <div className="font-mono text-2xl font-extrabold tracking-widest text-slate-900" dir="ltr">
            {data.ref}
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap justify-center gap-3 print:hidden">
        <button onClick={() => window.print()} className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-700">
          🖨 {t("print")}
        </button>
        <Link href="/" className="rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-500">
          {t("explore")}
        </Link>
      </div>
    </div>
  );
}
