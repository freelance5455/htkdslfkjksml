import { useEffect, useRef, useState, type ReactNode } from "react";
import { GripVertical } from "lucide-react";
import { cn } from "@/lib/cn";
import { moveItem } from "@/lib/planner/id";

type Props<T> = {
  items: T[];
  getId: (item: T) => string;
  onReorder: (items: T[]) => void;
  render: (item: T, grip: ReactNode) => ReactNode;
  className?: string;
};

/**
 * Pointer drag from the grip, plus arrow keys.
 * Listeners sit on window so a reorder re-render cannot drop the gesture.
 */
export function SortableList<T>({ items, getId, onReorder, render, className }: Props<T>) {
  const [dragId, setDragId] = useState<string | null>(null);
  const itemsRef = useRef(items);
  const onReorderRef = useRef(onReorder);
  const cleanupRef = useRef<(() => void) | null>(null);
  itemsRef.current = items;
  onReorderRef.current = onReorder;

  useEffect(() => () => cleanupRef.current?.(), []);

  return (
    <ul className={cn("grid gap-2", className)}>
      {items.map((item, index) => {
        const id = getId(item);
        const grip = (
          <button
            type="button"
            aria-label="Reorder"
            className="grid size-11 shrink-0 cursor-grab touch-none place-items-center rounded-lg text-muted hover:bg-paper hover:text-ink active:cursor-grabbing focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
            onKeyDown={(event) => {
              if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
              event.preventDefault();
              const dir = event.key === "ArrowUp" ? -1 : 1;
              onReorder(moveItem(itemsRef.current, index, index + dir));
            }}
            onPointerDown={(event) => {
              if (event.button !== 0) return;
              event.preventDefault();
              const startY = event.clientY;
              const origin = itemsRef.current.slice();
              const from = index;
              let last = from;
              const row = (event.currentTarget.closest("li")?.getBoundingClientRect().height ?? 56) + 8;
              setDragId(id);
              const move = (ev: PointerEvent) => {
                const steps = Math.round((ev.clientY - startY) / row);
                const target = Math.max(0, Math.min(origin.length - 1, from + steps));
                if (target === last) return;
                last = target;
                const copy = origin.slice();
                const [picked] = copy.splice(from, 1);
                if (picked === undefined) return;
                copy.splice(target, 0, picked);
                onReorderRef.current(copy);
              };
              const end = () => {
                setDragId(null);
                window.removeEventListener("pointermove", move);
                window.removeEventListener("pointerup", end);
                window.removeEventListener("pointercancel", end);
                cleanupRef.current = null;
              };
              cleanupRef.current = end;
              window.addEventListener("pointermove", move);
              window.addEventListener("pointerup", end);
              window.addEventListener("pointercancel", end);
            }}
          >
            <GripVertical className="size-4" strokeWidth={1.6} />
          </button>
        );
        return (
          <li key={id} className={cn(dragId === id && "relative z-10 opacity-80")}>
            {render(item, grip)}
          </li>
        );
      })}
    </ul>
  );
}
