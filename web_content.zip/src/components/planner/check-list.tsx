import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { AddRow } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { uid } from "@/lib/planner/id";
import type { CheckItem } from "@/lib/planner/types";
import { cn } from "@/lib/cn";

export function CheckList({
  items,
  onChange,
  placeholder,
}: {
  items: CheckItem[];
  onChange: (items: CheckItem[]) => void;
  placeholder: string;
}) {
  function update(id: string, patch: Partial<CheckItem>) {
    onChange(items.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }

  function remove(id: string) {
    const prev = items;
    onChange(items.filter((item) => item.id !== id));
    toast("Removed", { action: { label: "Undo", onClick: () => onChange(prev) } });
  }

  return (
    <div>
      {items.length > 0 ? (
        <SortableList
          items={items}
          getId={(item) => item.id}
          onReorder={onChange}
          render={(item, grip) => (
            <div className="flex items-center gap-1 rounded-lg border border-line bg-card pr-1">
              {grip}
              <label className="grid size-11 shrink-0 place-items-center">
                <input
                  type="checkbox"
                  checked={item.done}
                  onChange={() => update(item.id, { done: !item.done })}
                  aria-label={item.text ? `Mark “${item.text}”` : "Mark item"}
                  className="size-5 accent-accent"
                />
              </label>
              <input
                value={item.text}
                onChange={(event) => update(item.id, { text: event.target.value })}
                aria-label="Item"
                className={cn(
                  "h-11 min-w-0 flex-1 bg-transparent text-base outline-none",
                  item.done && "text-muted line-through",
                )}
              />
              <button
                type="button"
                aria-label="Remove item"
                onClick={() => remove(item.id)}
                className="grid size-11 shrink-0 place-items-center rounded-lg text-muted hover:text-ink"
              >
                <Trash2 className="size-4" strokeWidth={1.6} />
              </button>
            </div>
          )}
        />
      ) : null}
      <AddRow
        placeholder={placeholder}
        onAdd={(text) => onChange([...items, { id: uid(), text, done: false }])}
      />
    </div>
  );
}
