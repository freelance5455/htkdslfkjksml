/** Geometric five-petal mark. A motif, not an illustration. */
export function Bloom({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      {[0, 72, 144, 216, 288].map((deg) => (
        <ellipse
          key={deg}
          cx="16"
          cy="7.6"
          rx="2.3"
          ry="5"
          stroke="currentColor"
          strokeWidth="1.2"
          transform={`rotate(${deg} 16 16)`}
        />
      ))}
      <circle cx="16" cy="16" r="1.8" fill="currentColor" />
    </svg>
  );
}
