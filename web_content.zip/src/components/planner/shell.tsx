import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { format } from "date-fns";
import {
  Calendar,
  CalendarDays,
  CalendarRange,
  Images,
  ListChecks,
  Menu,
  NotebookPen,
  Repeat,
  SlidersHorizontal,
  StickyNote,
  SunMedium,
  Target,
} from "lucide-react";
import { Toaster } from "sonner";
import { Bloom } from "@/components/planner/bloom";
import { Modal } from "@/components/ui/modal";
import { cn } from "@/lib/cn";
import { parseDay } from "@/lib/planner/dates";
import { useTodayKey } from "@/lib/planner/hooks";
import { usePlanner } from "@/lib/planner/store";
import { applyTheme } from "@/lib/planner/theme";
import { SECTIONS, type SectionId } from "@/lib/planner/types";

const ICONS: Record<SectionId | "studio", typeof SunMedium> = {
  today: SunMedium,
  week: CalendarDays,
  month: Calendar,
  year: CalendarRange,
  goals: Target,
  habits: Repeat,
  tasks: ListChecks,
  notes: StickyNote,
  notebook: NotebookPen,
  vision: Images,
  studio: SlidersHorizontal,
};

const DOCK: SectionId[] = ["today", "week", "tasks", "vision"];
const MORE = new Set(["/month", "/year", "/goals", "/habits", "/notes", "/notebook", "/studio"]);

function activePath(href: string, path: string) {
  return href === "/" ? path === "/" : path === href;
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const name = usePlanner((s) => s.name);
  const tabs = usePlanner((s) => s.theme.tabs);
  const today = useTodayKey();
  const [more, setMore] = useState(false);

  useEffect(() => {
    let unsubscribe = () => {};
    void Promise.resolve(usePlanner.persist.rehydrate()).then(() => {
      applyTheme(usePlanner.getState().theme);
      unsubscribe = usePlanner.subscribe((state, prev) => {
        if (state.theme !== prev.theme) applyTheme(state.theme);
      });
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
    setMore(false);
  }, [path]);

  const moreActive = MORE.has(path);
  const dateLabel = today ? format(parseDay(today), "EEEE d MMMM") : "";

  return (
    <div className="relative min-h-dvh bg-paper text-ink">
      <div className="floral-layer pointer-events-none fixed inset-0 z-0" aria-hidden="true" />
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-6xl">
        <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-3 py-6 md:flex">
          <div className="mb-6 flex items-center gap-3 px-3">
            <span className="text-accent">
              <Bloom size={32} />
            </span>
            <div className="min-w-0">
              <p className="truncate font-display text-2xl leading-none font-medium text-ink">
                {name.trim() || "Solenne"}
              </p>
              <p className="mt-1 truncate text-sm text-muted">{name.trim() ? "Solenne" : "A quiet planner"}</p>
            </div>
          </div>
          <nav aria-label="Sections" className="grid content-start gap-1">
            {SECTIONS.map((section, index) => {
              const prev = SECTIONS[index - 1];
              const showGroup = !prev || prev.group !== section.group;
              const Icon = ICONS[section.id];
              const on = activePath(section.href, path);
              return (
                <div key={section.id}>
                  {showGroup ? (
                    <p
                      className={cn(
                        "mb-1 px-3 text-xs font-medium tracking-wide text-muted",
                        index > 0 && "mt-4",
                      )}
                    >
                      {section.group}
                    </p>
                  ) : null}
                  <Link
                    to={section.href}
                    className={cn(
                      "flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium",
                      on ? "bg-blush text-ink" : "text-ink hover:bg-blush",
                    )}
                  >
                    <span className="size-2 shrink-0 rounded-full" style={{ background: tabs[section.id] }} />
                    <Icon className="size-4 text-muted" strokeWidth={1.6} />
                    {section.label}
                  </Link>
                </div>
              );
            })}
          </nav>
          <Link
            to="/studio"
            className={cn(
              "mt-auto flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium",
              path === "/studio" ? "bg-blush" : "hover:bg-blush",
            )}
          >
            <SlidersHorizontal className="size-4" strokeWidth={1.6} />
            Studio
          </Link>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="pt-safe sticky top-0 z-20 border-b border-line bg-paper md:hidden">
            <div className="flex h-14 items-center justify-between px-4">
              <div className="flex min-w-0 items-center gap-2">
                <span className="text-accent">
                  <Bloom size={26} />
                </span>
                <div className="min-w-0">
                  <p className="truncate font-display text-xl leading-none font-medium">
                    {name.trim() || "Solenne"}
                  </p>
                  {dateLabel ? <p className="truncate text-xs text-muted">{dateLabel}</p> : null}
                </div>
              </div>
              <Link
                to="/studio"
                aria-label="Studio"
                className="grid size-11 place-items-center rounded-full hover:bg-blush"
              >
                <SlidersHorizontal className="size-5" strokeWidth={1.6} />
              </Link>
            </div>
          </header>
          <main className="mx-auto w-full max-w-3xl flex-1 px-4 pt-5 pb-dock md:px-8 md:pt-8 md:pb-16">
            {children}
          </main>
        </div>
      </div>

      <nav
        aria-label="Primary"
        className="dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper md:hidden"
      >
        <div className="mx-auto flex max-w-lg">
          {DOCK.map((id) => {
            const section = SECTIONS.find((item) => item.id === id);
            if (!section) return null;
            const Icon = ICONS[id];
            const on = activePath(section.href, path);
            return (
              <Link
                key={id}
                to={section.href}
                className={cn(
                  "flex h-16 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                  on ? "text-ink" : "text-muted",
                )}
              >
                <span
                  className="mb-0.5 h-0.5 w-4 rounded-full"
                  style={{ background: on ? tabs[id] : "transparent" }}
                />
                <Icon className="size-5" strokeWidth={1.6} />
                {section.label}
              </Link>
            );
          })}
          <button
            type="button"
            aria-expanded={more}
            onClick={() => setMore(true)}
            className={cn(
              "flex h-16 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium",
              moreActive ? "text-ink" : "text-muted",
            )}
          >
            <span
              className="mb-0.5 h-0.5 w-4 rounded-full"
              style={{ background: moreActive ? "var(--color-accent)" : "transparent" }}
            />
            <Menu className="size-5" strokeWidth={1.6} />
            More
          </button>
        </div>
      </nav>

      <Modal open={more} onOpenChange={setMore} title="Sections" description="The rest of the planner.">
        <nav className="grid gap-1">
          {SECTIONS.filter((section) => !DOCK.includes(section.id)).map((section) => {
            const Icon = ICONS[section.id];
            const on = activePath(section.href, path);
            return (
              <Link
                key={section.id}
                to={section.href}
                className={cn("flex h-12 items-center gap-3 rounded-lg px-2 text-base", on && "bg-blush")}
              >
                <span className="size-2.5 rounded-full" style={{ background: tabs[section.id] }} />
                <Icon className="size-4 text-muted" strokeWidth={1.6} />
                {section.label}
              </Link>
            );
          })}
          <Link
            to="/studio"
            className={cn(
              "flex h-12 items-center gap-3 rounded-lg px-2 text-base",
              path === "/studio" && "bg-blush",
            )}
          >
            <SlidersHorizontal className="size-4" strokeWidth={1.6} />
            Studio
          </Link>
        </nav>
      </Modal>
      <Toaster position="top-center" />
    </div>
  );
}
