import { useState, type FormEvent, type ReactNode } from "react";
import { cn } from "@/lib/cn";
import { usePlanner } from "@/lib/planner/store";
import type { SectionId } from "@/lib/planner/types";

export const fieldClass =
  "h-11 w-full min-w-0 rounded-lg border border-line bg-card px-3 text-base text-ink outline-none placeholder:text-muted focus-visible:border-accent";

export const areaClass =
  "min-h-28 w-full min-w-0 resize-none rounded-lg border border-line bg-card px-3 py-3 text-base leading-normal text-ink outline-none placeholder:text-muted focus-visible:border-accent";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-3xl border border-line bg-card p-4", className)}>{children}</section>;
}

export function SectionMark({ section }: { section?: SectionId }) {
  const color = usePlanner((s) => (section ? s.theme.tabs[section] : s.theme.accent));
  return <span className="mb-3 block h-1 w-8 rounded-full" style={{ background: color }} />;
}

export function PageHeader({
  section,
  title,
  lede,
  action,
}: {
  section?: SectionId;
  title: string;
  lede?: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <SectionMark section={section} />
        <h1 className="font-display text-4xl font-medium tracking-tight text-balance text-ink">{title}</h1>
        {lede ? <p className="mt-2 max-w-prose text-pretty text-base text-muted">{lede}</p> : null}
      </div>
      {action}
    </header>
  );
}

export function CardTitle({ children, aside }: { children: ReactNode; aside?: ReactNode }) {
  return (
    <div className="mb-3 flex items-baseline justify-between gap-3">
      <h2 className="text-base font-medium text-ink">{children}</h2>
      {aside}
    </div>
  );
}

export function AddRow({
  placeholder,
  label = "Add",
  onAdd,
}: {
  placeholder: string;
  label?: string;
  onAdd: (text: string) => void;
}) {
  const [text, setText] = useState("");
  function submit(event: FormEvent) {
    event.preventDefault();
    const next = text.trim();
    if (!next) return;
    onAdd(next);
    setText("");
  }
  return (
    <form className="mt-3 flex gap-2" onSubmit={submit}>
      <input
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder={placeholder}
        aria-label={placeholder}
        autoComplete="off"
        className={fieldClass}
      />
      <button
        type="submit"
        className="h-11 shrink-0 rounded-full bg-blush px-4 text-sm font-medium text-ink hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
      >
        {label}
      </button>
    </form>
  );
}

export function IconButton({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="grid size-11 place-items-center rounded-full text-ink hover:bg-blush focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
    >
      {children}
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  label,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  label: string;
}) {
  return (
    <div role="group" aria-label={label} className="grid grid-flow-col gap-1 rounded-full bg-paper p-1">
      {options.map((option) => {
        const on = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            aria-pressed={on}
            onClick={() => onChange(option.value)}
            className={cn(
              "h-11 rounded-full px-3 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
              on ? "bg-card text-ink shadow-soft" : "text-muted",
            )}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

export function EmptyCopy({ title, body }: { title: string; body: string }) {
  return (
    <div className="py-2">
      <p className="font-display text-2xl font-medium text-balance text-ink">{title}</p>
      <p className="mt-1 text-pretty text-base text-muted">{body}</p>
    </div>
  );
}

export function ColorDot({
  value,
  onChange,
  label,
}: {
  value: string;
  onChange: (value: string) => void;
  label: string;
}) {
  return (
    <input
      type="color"
      aria-label={label}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="color-dot"
    />
  );
}
