import { useState } from "react";
import { toast } from "sonner";
import { Pin } from "lucide-react";
import { Card, EmptyCopy, PageHeader, areaClass, fieldClass } from "@/components/planner/primitives";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import { cn } from "@/lib/cn";

export function NotesView() {
  const notes = usePlanner((s) => s.notes);
  const addNote = usePlanner((s) => s.addNote);
  const updateNote = usePlanner((s) => s.updateNote);
  const deleteNote = usePlanner((s) => s.deleteNote);
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();
  const shown = notes
    .filter((note) => !q || note.title.toLowerCase().includes(q) || note.body.toLowerCase().includes(q))
    .slice()
    .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updated - a.updated);

  return (
    <div>
      <PageHeader section="notes" title="Notes" lede="Loose thoughts, kept." />
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search notes"
        aria-label="Search notes"
        className={cn(fieldClass, "mb-4")}
      />
      {shown.length === 0 ? (
        <EmptyCopy title={q ? "Nothing under that name" : "A blank margin"} body="Write the thing before it leaves." />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {shown.map((note) => (
            <Card key={note.id}>
              <div className="mb-2 flex items-center gap-1">
                <input
                  value={note.title}
                  aria-label="Note title"
                  onChange={(event) => updateNote(note.id, { title: event.target.value, updated: Date.now() })}
                  placeholder="Title"
                  className="h-11 min-w-0 flex-1 bg-transparent font-display text-xl outline-none"
                />
                <button
                  type="button"
                  aria-pressed={note.pinned}
                  aria-label={note.pinned ? "Unpin note" : "Pin note"}
                  onClick={() => updateNote(note.id, { pinned: !note.pinned, updated: Date.now() })}
                  className={cn("grid size-11 place-items-center rounded-full", note.pinned ? "text-accent" : "text-muted")}
                >
                  <Pin className="size-4" strokeWidth={1.6} fill={note.pinned ? "currentColor" : "none"} />
                </button>
              </div>
              <textarea
                value={note.body}
                aria-label="Note"
                onChange={(event) => updateNote(note.id, { body: event.target.value, updated: Date.now() })}
                placeholder="Write freely."
                className={areaClass}
              />
              <button
                type="button"
                className="mt-2 h-11 text-sm text-muted"
                onClick={() => {
                  const prev = notes;
                  deleteNote(note.id);
                  toast("Note removed", {
                    action: { label: "Undo", onClick: () => usePlanner.setState({ notes: prev }) },
                  });
                }}
              >
                Remove
              </button>
            </Card>
          ))}
        </div>
      )}
      <button
        type="button"
        className="mt-4 h-11 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg"
        onClick={() => addNote({ id: uid(), title: "", body: "", pinned: false, updated: Date.now() })}
      >
        New note
      </button>
    </div>
  );
}
