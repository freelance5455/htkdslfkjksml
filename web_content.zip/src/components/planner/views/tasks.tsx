import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ColorDot, EmptyCopy, PageHeader, fieldClass } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import type { Priority } from "@/lib/planner/types";
import { cn } from "@/lib/cn";

const NEXT: Record<Priority, Priority> = { low: "medium", medium: "high", high: "low" };
const LABEL: Record<Priority, string> = { low: "Low", medium: "Medium", high: "High" };

export function TasksView() {
  const lists = usePlanner((s) => s.lists);
  const tasks = usePlanner((s) => s.tasks);
  const addList = usePlanner((s) => s.addList);
  const updateList = usePlanner((s) => s.updateList);
  const deleteList = usePlanner((s) => s.deleteList);
  const addTask = usePlanner((s) => s.addTask);
  const updateTask = usePlanner((s) => s.updateTask);
  const setTasks = usePlanner((s) => s.setTasks);
  const accent = usePlanner((s) => s.theme.accent);
  const [listId, setListId] = useState(lists[0]?.id ?? "");

  useEffect(() => {
    if (!lists.some((list) => list.id === listId)) setListId(lists[0]?.id ?? "");
  }, [lists, listId]);

  const current = lists.find((list) => list.id === listId);
  const mine = tasks.filter((task) => task.listId === listId);

  return (
    <div>
      <PageHeader section="tasks" title="Tasks" lede="What to do, without the noise." />
      {lists.length > 0 ? (
        <div className="mb-4 flex gap-2 overflow-x-auto">
          {lists.map((list) => (
            <button
              key={list.id}
              type="button"
              aria-pressed={list.id === listId}
              onClick={() => setListId(list.id)}
              className={cn(
                "flex h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium",
                list.id === listId ? "bg-blush text-ink" : "border border-line text-muted",
              )}
            >
              <span className="size-2 rounded-full" style={{ background: list.color }} />
              {list.name}
            </button>
          ))}
        </div>
      ) : (
        <EmptyCopy title="No lists yet" body="Make a list for today, home, or anything that keeps spilling." />
      )}

      {current ? (
        <div className="mb-4 flex items-center gap-2">
          <ColorDot
            label="List color"
            value={current.color}
            onChange={(color) => updateList(current.id, { color })}
          />
          <input
            value={current.name}
            aria-label="List name"
            onChange={(event) => updateList(current.id, { name: event.target.value })}
            className="h-11 min-w-0 flex-1 bg-transparent font-display text-2xl outline-none"
          />
          <button
            type="button"
            className="h-11 px-2 text-sm text-muted"
            onClick={() => {
              const prevLists = lists;
              const prevTasks = tasks;
              deleteList(current.id);
              toast("List removed", {
                action: {
                  label: "Undo",
                  onClick: () => usePlanner.setState({ lists: prevLists, tasks: prevTasks }),
                },
              });
            }}
          >
            Remove
          </button>
        </div>
      ) : null}

      {current && mine.length === 0 ? <p className="mb-3 text-sm text-muted">This list is clear.</p> : null}

      {current ? (
        <SortableList
          items={mine}
          getId={(task) => task.id}
          onReorder={(next) => {
            const rest = tasks.filter((task) => task.listId !== listId);
            setTasks([...rest, ...next]);
          }}
          render={(task, grip) => (
            <div className="rounded-3xl border border-line bg-card p-3">
              <div className="flex items-center gap-1">
                {grip}
                <label className="grid size-11 place-items-center">
                  <input
                    type="checkbox"
                    checked={task.done}
                    aria-label={task.text || "Task"}
                    onChange={() => updateTask(task.id, { done: !task.done })}
                    className="size-5 accent-accent"
                  />
                </label>
                <input
                  value={task.text}
                  aria-label="Task"
                  onChange={(event) => updateTask(task.id, { text: event.target.value })}
                  className={cn(
                    "h-11 min-w-0 flex-1 bg-transparent text-base outline-none",
                    task.done && "text-muted line-through",
                  )}
                />
                <button
                  type="button"
                  className="h-11 px-2 text-sm text-muted"
                  onClick={() => {
                    const prev = tasks;
                    setTasks(tasks.filter((item) => item.id !== task.id));
                    toast("Task removed", { action: { label: "Undo", onClick: () => setTasks(prev) } });
                  }}
                >
                  Remove
                </button>
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-2 pl-11">
                <button
                  type="button"
                  onClick={() => updateTask(task.id, { priority: NEXT[task.priority] })}
                  className="h-10 rounded-full bg-paper px-3 text-sm"
                >
                  {LABEL[task.priority]}
                </button>
                <input
                  type="date"
                  value={task.due}
                  aria-label="Due date"
                  onChange={(event) => updateTask(task.id, { due: event.target.value })}
                  className="h-10 min-w-0 rounded-lg border border-line bg-paper px-2 text-sm"
                />
              </div>
            </div>
          )}
        />
      ) : null}

      {current ? (
        <form
          className="mt-4 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            const text = String(data.get("text") ?? "").trim();
            if (!text) return;
            addTask({ id: uid(), listId: current.id, text, done: false, priority: "medium", due: "" });
            event.currentTarget.reset();
          }}
        >
          <input name="text" placeholder="Add a task" aria-label="Add a task" className={fieldClass} />
          <button type="submit" className="h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg">
            Add
          </button>
        </form>
      ) : null}

      <form
        className="mt-6 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          const name = String(data.get("name") ?? "").trim();
          if (!name) return;
          const id = uid();
          addList({ id, name, color: accent });
          setListId(id);
          event.currentTarget.reset();
        }}
      >
        <input name="name" placeholder="New list" aria-label="New list" className={fieldClass} />
        <button type="submit" className="h-11 shrink-0 rounded-full bg-blush px-4 text-sm font-medium">
          List
        </button>
      </form>
    </div>
  );
}
