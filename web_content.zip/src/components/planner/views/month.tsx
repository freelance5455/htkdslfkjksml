import { useEffect, useState } from "react";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { AddRow, Card, CardTitle, ColorDot, IconButton, PageHeader } from "@/components/planner/primitives";
import { dayKey, monthCells, monthKey, parseDay, parseMonth, sameMonth, shiftMonth } from "@/lib/planner/dates";
import { useTodayKey } from "@/lib/planner/hooks";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import { MONTH_TONES, inkOn, monthTone } from "@/lib/planner/theme";
import { cn } from "@/lib/cn";

export function MonthView({ initialKey }: { initialKey?: string }) {
  const today = useTodayKey();
  const [cursor, setCursor] = useState<string | null>(initialKey ?? null);

  useEffect(() => {
    if (initialKey) setCursor(initialKey);
  }, [initialKey]);

  const active = cursor ?? (today ? today.slice(0, 7) : null);
  if (!active || !today) return <PageHeader section="month" title="Month" lede="Opening the month." />;
  return <MonthPage monthId={active} today={today} onMonth={setCursor} />;
}

function MonthPage({
  monthId,
  today,
  onMonth,
}: {
  monthId: string;
  today: string;
  onMonth: (key: string) => void;
}) {
  const month = usePlanner((s) => s.months[monthId]);
  const patchMonth = usePlanner((s) => s.patchMonth);
  const anchor = parseMonth(monthId);
  const cells = monthCells(anchor);
  const [selected, setSelected] = useState(today.slice(0, 7) === monthId ? today : dayKey(anchor));
  const color = monthTone(monthId, month?.color);
  const events = month?.events ?? [];
  const intention = month?.intention ?? "";
  const selectedEvents = events.filter((event) => event.date === selected);

  useEffect(() => {
    setSelected(today.slice(0, 7) === monthId ? today : `${monthId}-01`);
  }, [monthId, today]);

  return (
    <div>
      <PageHeader
        section="month"
        title={format(anchor, "MMMM")}
        lede={format(anchor, "yyyy")}
        action={
          <div className="flex">
            <IconButton label="Previous month" onClick={() => onMonth(shiftMonth(monthId, -1))}>
              <ChevronLeft className="size-5" strokeWidth={1.6} />
            </IconButton>
            <IconButton label="Next month" onClick={() => onMonth(shiftMonth(monthId, 1))}>
              <ChevronRight className="size-5" strokeWidth={1.6} />
            </IconButton>
          </div>
        }
      />

      <div className="grid gap-3">
        <Card>
          <CardTitle>Intention</CardTitle>
          <textarea
            value={intention}
            onChange={(event) => patchMonth(monthId, (m) => ({ ...m, intention: event.target.value }))}
            placeholder="What should this month feel like when it is over?"
            rows={3}
            className="min-h-20 w-full resize-none bg-transparent font-display text-xl outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
          />
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted">Month color</span>
            {MONTH_TONES.map((tone) => (
              <button
                key={tone}
                type="button"
                aria-label={`Use ${tone}`}
                onClick={() => patchMonth(monthId, (m) => ({ ...m, color: tone }))}
                className={cn(
                  "size-11 rounded-full border",
                  color === tone ? "border-ink" : "border-transparent",
                )}
              >
                <span className="mx-auto block size-5 rounded-full" style={{ background: tone }} />
              </button>
            ))}
            <ColorDot
              label="Custom month color"
              value={color}
              onChange={(next) => patchMonth(monthId, (m) => ({ ...m, color: next }))}
            />
          </div>
        </Card>

        <Card className="px-2">
          <div className="grid grid-cols-7 text-center text-xs text-muted">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((label) => (
              <span key={label} className="py-2">
                {label}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-7">
            {cells.map((day) => {
              const key = dayKey(day);
              const inMonth = sameMonth(day, anchor);
              const marked = events.some((event) => event.date === key);
              const on = key === selected;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelected(key)}
                  className={cn(
                    "flex h-12 flex-col items-center justify-center rounded-lg text-sm tabular-nums",
                    !inMonth && "text-muted opacity-50",
                    on && "bg-blush",
                    key === today && "font-medium text-accent",
                  )}
                >
                  {format(day, "d")}
                  <span className={cn("mt-0.5 size-1 rounded-full", marked ? "bg-accent" : "bg-transparent")} />
                </button>
              );
            })}
          </div>
        </Card>

        <Card>
          <div
            className="mb-3 inline-flex rounded-full px-3 py-1 text-sm"
            style={{ background: color, color: inkOn(color) }}
          >
            {format(parseDay(selected), "EEEE d MMMM")}
          </div>
          {selectedEvents.length === 0 ? (
            <p className="text-sm text-muted">Nothing written on this day.</p>
          ) : (
            <ul className="grid gap-2">
              {selectedEvents.map((event) => (
                <li key={event.id} className="flex items-center gap-2">
                  <input
                    value={event.title}
                    aria-label="Event"
                    onChange={(e) =>
                      patchMonth(monthId, (m) => ({
                        ...m,
                        events: m.events.map((item) =>
                          item.id === event.id ? { ...item, title: e.target.value } : item,
                        ),
                      }))
                    }
                    className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-card px-3 text-base outline-none"
                  />
                  <button
                    type="button"
                    className="h-11 px-2 text-sm text-muted"
                    onClick={() => {
                      const prev = events;
                      patchMonth(monthId, (m) => ({
                        ...m,
                        events: m.events.filter((item) => item.id !== event.id),
                      }));
                      toast("Removed", {
                        action: {
                          label: "Undo",
                          onClick: () => patchMonth(monthId, (m) => ({ ...m, events: prev })),
                        },
                      });
                    }}
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          )}
          <AddRow
            placeholder="Add to this day"
            onAdd={(title) =>
              patchMonth(monthId, (m) => ({
                ...m,
                events: [...m.events, { id: uid(), date: selected, title }],
              }))
            }
          />
        </Card>
      </div>
    </div>
  );
}
