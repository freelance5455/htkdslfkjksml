import { useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Card, CardTitle, ColorDot, PageHeader, Segmented, fieldClass } from "@/components/planner/primitives";
import { parseBackup } from "@/lib/planner/backup";
import { snapshot, usePlanner } from "@/lib/planner/store";
import { FLORAL_OPTIONS, PALETTES } from "@/lib/planner/theme";
import { SECTIONS, type PaletteId } from "@/lib/planner/types";
import { cn } from "@/lib/cn";

const PRESETS = Object.entries(PALETTES) as [Exclude<PaletteId, "custom">, (typeof PALETTES)["petal"]][];

export function StudioView() {
  const name = usePlanner((s) => s.name);
  const theme = usePlanner((s) => s.theme);
  const setName = usePlanner((s) => s.setName);
  const applyPalette = usePlanner((s) => s.applyPalette);
  const setPaper = usePlanner((s) => s.setPaper);
  const setAccent = usePlanner((s) => s.setAccent);
  const setTheme = usePlanner((s) => s.setTheme);
  const setTabColor = usePlanner((s) => s.setTabColor);
  const unifyTabs = usePlanner((s) => s.unifyTabs);
  const varyTabs = usePlanner((s) => s.varyTabs);
  const clearContent = usePlanner((s) => s.clearContent);
  const restoreSamples = usePlanner((s) => s.restoreSamples);
  const replaceData = usePlanner((s) => s.replaceData);
  const fileRef = useRef<HTMLInputElement>(null);
  const [confirm, setConfirm] = useState<null | "clear" | "samples">(null);

  function download() {
    const blob = new Blob([JSON.stringify({ solenne: 1, ...snapshot() }, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "solenne-backup.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHeader title="Studio" lede="Paper, color, and how Solenne feels." />
      <div className="grid gap-3">
        <Card>
          <CardTitle>Your name</CardTitle>
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="What should we call you?"
            aria-label="Your name"
            autoComplete="given-name"
            className={fieldClass}
          />
          <p className="mt-3 font-display text-2xl text-ink">
            {name.trim() ? `Hello, ${name.trim()}.` : "Hello."}
          </p>
        </Card>

        <Card>
          <CardTitle>Paper</CardTitle>
          <div className="grid gap-2 sm:grid-cols-2">
            {PRESETS.map(([id, palette]) => (
              <button
                key={id}
                type="button"
                aria-pressed={theme.paletteId === id}
                onClick={() => applyPalette(id)}
                className={cn(
                  "flex h-auto items-center gap-3 rounded-2xl border px-3 py-3 text-left",
                  theme.paletteId === id ? "border-accent bg-blush" : "border-line",
                )}
              >
                <span className="flex shrink-0">
                  <span className="size-8 rounded-full border border-line" style={{ background: palette.colors.paper }} />
                  <span className="-ml-2 size-8 rounded-full border border-line" style={{ background: palette.colors.accent }} />
                  <span className="-ml-2 size-8 rounded-full border border-line" style={{ background: palette.colors.sage }} />
                </span>
                <span>
                  <span className="block text-sm font-medium">{palette.name}</span>
                  <span className="block text-sm text-muted">{palette.hint}</span>
                </span>
              </button>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-2 text-sm">
              <ColorDot label="Background color" value={theme.paper} onChange={setPaper} />
              Background
            </label>
            <label className="flex items-center gap-2 text-sm">
              <ColorDot label="Accent color" value={theme.accent} onChange={setAccent} />
              Accent
            </label>
          </div>
        </Card>

        <Card>
          <CardTitle>Florals</CardTitle>
          <Segmented
            label="Floral intensity"
            value={theme.floral}
            options={FLORAL_OPTIONS}
            onChange={(floral) => setTheme({ floral })}
          />
          <p className="mt-3 text-sm text-muted">A whisper of botanical linework behind the pages.</p>
        </Card>

        <Card>
          <CardTitle>Section colors</CardTitle>
          <p className="mb-3 text-sm text-muted">These mark each part of the planner, including every month you color yourself.</p>
          <div className="mb-3 flex flex-wrap gap-2">
            <Button variant="quiet" onClick={varyTabs}>
              Vary the tabs
            </Button>
            <Button variant="ghost" onClick={unifyTabs}>
              One accent
            </Button>
          </div>
          <ul className="grid gap-2 sm:grid-cols-2">
            {SECTIONS.map((section) => (
              <li key={section.id} className="flex items-center gap-3 rounded-lg border border-line px-2">
                <ColorDot
                  label={`${section.label} color`}
                  value={theme.tabs[section.id]}
                  onChange={(color) => setTabColor(section.id, color)}
                />
                <span className="text-sm font-medium">{section.label}</span>
                <span className="ml-auto h-1 w-8 rounded-full" style={{ background: theme.tabs[section.id] }} />
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardTitle>On this device</CardTitle>
          <p className="mb-3 text-sm text-pretty text-muted">
            Everything stays in this browser. Download a backup if you want a copy, or restore one later.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button variant="primary" onClick={download}>
              Download backup
            </Button>
            <Button variant="quiet" onClick={() => fileRef.current?.click()}>
              Restore backup
            </Button>
            <Button variant="ghost" onClick={() => setConfirm("samples")}>
              Sample pages
            </Button>
            <Button variant="danger" onClick={() => setConfirm("clear")}>
              Clear planner
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="sr-only"
            aria-label="Backup file"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              const data = parseBackup(await file.text());
              if (!data) {
                toast("That file is not a Solenne backup.");
                return;
              }
              replaceData(data);
              toast("Backup restored.");
            }}
          />
        </Card>
      </div>

      <Modal
        open={confirm !== null}
        onOpenChange={(open) => {
          if (!open) setConfirm(null);
        }}
        title={confirm === "clear" ? "Clear the planner?" : "Restore sample pages?"}
        description={
          confirm === "clear"
            ? "Days, goals, habits, tasks, notes, notebooks, and the vision board on this device will be erased. Your name and colors stay."
            : "This replaces your pages with the sample set. Your name and colors stay."
        }
      >
        <div className="flex flex-wrap gap-2">
          <Button variant="ghost" onClick={() => setConfirm(null)}>
            Keep my pages
          </Button>
          <Button
            variant={confirm === "clear" ? "danger" : "primary"}
            onClick={() => {
              if (confirm === "clear") clearContent();
              if (confirm === "samples") restoreSamples();
              setConfirm(null);
            }}
          >
            {confirm === "clear" ? "Clear everything" : "Restore samples"}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
