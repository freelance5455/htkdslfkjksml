import { useState } from "react";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { ColorDot, EmptyCopy, IconButton, PageHeader, fieldClass } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { dayKey, parseDay, shiftDay, streakEnding, weekDays } from "@/lib/planner/dates";
import { useTodayKey } from "@/lib/planner/hooks";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import { cn } from "@/lib/cn";

export function HabitsView() {
  const today = useTodayKey();
  const habits = usePlanner((s) => s.habits);
  const addHabit = usePlanner((s) => s.addHabit);
  const updateHabit = usePlanner((s) => s.updateHabit);
  const toggleHabit = usePlanner((s) => s.toggleHabit);
  const setHabits = usePlanner((s) => s.setHabits);
  const accent = usePlanner((s) => s.theme.accent);
  const [cursor, setCursor] = useState<string | null>(null);
  if (!today) return <PageHeader section="habits" title="Habits" lede="Opening the week." />;
  const anchor = cursor ?? today;
  const days = weekDays(parseDay(anchor));
  const weekStart = dayKey(days[0] ?? parseDay(anchor));
  const thisWeek = dayKey(weekDays(parseDay(today))[0] ?? parseDay(today));

  return (
    <div>
      <PageHeader
        section="habits"
        title="Habits"
        lede="Small repeats, kept honestly."
        action={
          <div className="flex">
            <IconButton label="Previous week" onClick={() => setCursor(shiftDay(weekStart, -7))}>
              <ChevronLeft className="size-5" strokeWidth={1.6} />
            </IconButton>
            <IconButton label="Next week" onClick={() => setCursor(shiftDay(weekStart, 7))}>
              <ChevronRight className="size-5" strokeWidth={1.6} />
            </IconButton>
          </div>
        }
      />
      {weekStart !== thisWeek ? (
        <button type="button" className="mb-4 text-sm font-medium text-accent" onClick={() => setCursor(null)}>
          This week
        </button>
      ) : null}
      <p className="mb-4 text-sm text-muted">
        {format(days[0] ?? parseDay(anchor), "d MMM")} – {format(days[6] ?? parseDay(anchor), "d MMM")}
      </p>

      {habits.length === 0 ? (
        <EmptyCopy title="No habits yet" body="Start with one you can keep on a tired day." />
      ) : (
        <SortableList
          items={habits}
          getId={(habit) => habit.id}
          onReorder={setHabits}
          render={(habit, grip) => {
            const streak = streakEnding(habit.checks, parseDay(today));
            return (
              <div className="rounded-3xl border border-line bg-card p-3">
                <div className="flex items-center gap-1">
                  {grip}
                  <ColorDot
                    label={`${habit.name} color`}
                    value={habit.color}
                    onChange={(color) => updateHabit(habit.id, { color })}
                  />
                  <input
                    value={habit.name}
                    aria-label="Habit name"
                    onChange={(event) => updateHabit(habit.id, { name: event.target.value })}
                    className="h-11 min-w-0 flex-1 bg-transparent text-base outline-none"
                  />
                  <span className="shrink-0 text-sm tabular-nums text-muted">{streak}d</span>
                  <button
                    type="button"
                    className="h-11 px-2 text-sm text-muted"
                    onClick={() => {
                      const prev = habits;
                      setHabits(habits.filter((item) => item.id !== habit.id));
                      toast("Habit removed", { action: { label: "Undo", onClick: () => setHabits(prev) } });
                    }}
                  >
                    Remove
                  </button>
                </div>
                <div className="mt-1 grid grid-cols-7 gap-1">
                  {days.map((day) => {
                    const key = dayKey(day);
                    const on = !!habit.checks[key];
                    return (
                      <button
                        key={key}
                        type="button"
                        aria-pressed={on}
                        aria-label={`${habit.name} ${format(day, "EEEE d")}`}
                        onClick={() => toggleHabit(habit.id, key)}
                        className="flex h-14 flex-col items-center justify-center gap-1 rounded-lg"
                      >
                        <span className={cn("text-xs", key === today ? "text-ink" : "text-muted")}>
                          {format(day, "EEEEE")}
                        </span>
                        <span
                          className="size-4 rounded-full border-2"
                          style={{ borderColor: habit.color, background: on ? habit.color : "transparent" }}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          }}
        />
      )}

      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          const name = String(data.get("name") ?? "").trim();
          if (!name) return;
          addHabit({ id: uid(), name, color: accent, checks: {} });
          event.currentTarget.reset();
        }}
      >
        <input name="name" placeholder="New habit" aria-label="New habit" className={fieldClass} />
        <button type="submit" className="h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg">
          Add
        </button>
      </form>
    </div>
  );
}
