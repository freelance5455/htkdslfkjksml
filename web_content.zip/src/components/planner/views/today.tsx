import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { CheckList } from "@/components/planner/check-list";
import { AddRow, Card, CardTitle, IconButton, SectionMark } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { dayKey, parseDay, shiftDay, streakEnding } from "@/lib/planner/dates";
import { greetingFor, useDayPart, useTodayKey } from "@/lib/planner/hooks";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import { MOODS } from "@/lib/planner/theme";
import { cn } from "@/lib/cn";

export function TodayView() {
  const today = useTodayKey();
  const [cursor, setCursor] = useState<string | null>(null);
  const active = cursor ?? today;
  if (!active || !today) return <TodaySkeleton />;
  return <TodayPage date={active} today={today} onDate={setCursor} />;
}

function TodaySkeleton() {
  return (
    <div>
      <SectionMark section="today" />
      <h1 className="font-display text-4xl font-medium text-ink">Today</h1>
      <p className="mt-2 text-muted">Opening your page.</p>
    </div>
  );
}

function TodayPage({
  date,
  today,
  onDate,
}: {
  date: string;
  today: string;
  onDate: (key: string | null) => void;
}) {
  const name = usePlanner((s) => s.name);
  const samplesOn = usePlanner((s) => s.samplesOn);
  const dismissSamples = usePlanner((s) => s.dismissSamples);
  const day = usePlanner((s) => s.days[date]);
  const patchDay = usePlanner((s) => s.patchDay);
  const habits = usePlanner((s) => s.habits);
  const tasks = usePlanner((s) => s.tasks);
  const lists = usePlanner((s) => s.lists);
  const toggleHabit = usePlanner((s) => s.toggleHabit);
  const updateTask = usePlanner((s) => s.updateTask);
  const part = useDayPart();

  const log = {
    intention: day?.intention ?? "",
    gratitude: [day?.gratitude?.[0] ?? "", day?.gratitude?.[1] ?? "", day?.gratitude?.[2] ?? ""] as [
      string,
      string,
      string,
    ],
    priorities: day?.priorities ?? [],
    schedule: day?.schedule ?? [],
    mood: day?.mood ?? null,
    water: day?.water ?? 0,
    journal: day?.journal ?? "",
    affirmation: day?.affirmation ?? "",
  };

  const todayList = lists.find((list) => list.id === "list-today") ?? lists[0];
  const due = tasks.filter((task) => todayList && task.listId === todayList.id && !task.done);
  const when = parseDay(date);

  return (
    <div>
      {samplesOn ? (
        <div className="mb-5 flex items-start justify-between gap-3 rounded-3xl bg-blush px-4 py-3">
          <p className="text-sm text-pretty text-ink">
            Sample pages are open so you can look around. Edit them freely, or clear everything in Studio.
          </p>
          <button type="button" className="h-11 shrink-0 px-1 text-sm font-medium" onClick={dismissSamples}>
            Dismiss
          </button>
        </div>
      ) : null}

      <div className="mb-6 flex items-end justify-between gap-2">
        <div className="min-w-0">
          <SectionMark section="today" />
          <h1 className="font-display text-4xl font-medium tracking-tight text-balance text-ink">
            {format(when, "EEEE")}
          </h1>
          <p className="mt-2 text-base text-muted">
            {greetingFor(part, name)}
            <span> · </span>
            <span className="tabular-nums">{format(when, "d MMMM")}</span>
          </p>
        </div>
        <div className="flex shrink-0 items-center">
          <IconButton label="Previous day" onClick={() => onDate(shiftDay(date, -1))}>
            <ChevronLeft className="size-5" strokeWidth={1.6} />
          </IconButton>
          <IconButton label="Next day" onClick={() => onDate(shiftDay(date, 1))}>
            <ChevronRight className="size-5" strokeWidth={1.6} />
          </IconButton>
        </div>
      </div>
      {date !== today ? (
        <button type="button" className="mb-4 text-sm font-medium text-accent" onClick={() => onDate(null)}>
          Back to today
        </button>
      ) : null}

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="grid content-start gap-3">
          <Card>
            <CardTitle>Intention</CardTitle>
            <textarea
              value={log.intention}
              onChange={(event) => patchDay(date, (d) => ({ ...d, intention: event.target.value }))}
              placeholder="One sentence for how you want to move through this day."
              rows={3}
              className="min-h-20 w-full resize-none bg-transparent text-base leading-normal outline-none placeholder:text-muted"
            />
          </Card>

          <Card>
            <CardTitle
              aside={
                log.priorities.length > 3 ? (
                  <span className="text-sm text-muted">Three is usually enough.</span>
                ) : null
              }
            >
              Priorities
            </CardTitle>
            <CheckList
              items={log.priorities}
              placeholder="A priority"
              onChange={(priorities) => patchDay(date, (d) => ({ ...d, priorities }))}
            />
          </Card>

          <Card>
            <CardTitle>Schedule</CardTitle>
            {log.schedule.length > 0 ? (
              <SortableList
                items={log.schedule}
                getId={(item) => item.id}
                onReorder={(schedule) => patchDay(date, (d) => ({ ...d, schedule }))}
                render={(block, grip) => (
                  <div className="flex items-center gap-1 rounded-lg border border-line bg-card pr-1">
                    {grip}
                    <input
                      value={block.time}
                      onChange={(event) =>
                        patchDay(date, (d) => ({
                          ...d,
                          schedule: d.schedule.map((item) =>
                            item.id === block.id ? { ...item, time: event.target.value } : item,
                          ),
                        }))
                      }
                      aria-label="Time"
                      className="h-11 w-16 shrink-0 bg-transparent text-center text-sm tabular-nums outline-none"
                    />
                    <label className="grid size-11 shrink-0 place-items-center">
                      <input
                        type="checkbox"
                        checked={block.done}
                        aria-label="Mark block"
                        onChange={() =>
                          patchDay(date, (d) => ({
                            ...d,
                            schedule: d.schedule.map((item) =>
                              item.id === block.id ? { ...item, done: !item.done } : item,
                            ),
                          }))
                        }
                        className="size-5 accent-accent"
                      />
                    </label>
                    <input
                      value={block.text}
                      onChange={(event) =>
                        patchDay(date, (d) => ({
                          ...d,
                          schedule: d.schedule.map((item) =>
                            item.id === block.id ? { ...item, text: event.target.value } : item,
                          ),
                        }))
                      }
                      aria-label="Plan"
                      className={cn(
                        "h-11 min-w-0 flex-1 bg-transparent text-base outline-none",
                        block.done && "text-muted line-through",
                      )}
                    />
                    <button
                      type="button"
                      aria-label="Remove block"
                      className="grid size-11 place-items-center text-muted"
                      onClick={() => {
                        const prev = log.schedule;
                        patchDay(date, (d) => ({
                          ...d,
                          schedule: d.schedule.filter((item) => item.id !== block.id),
                        }));
                        toast("Removed", {
                          action: {
                            label: "Undo",
                            onClick: () => patchDay(date, (d) => ({ ...d, schedule: prev })),
                          },
                        });
                      }}
                    >
                      <Trash2 className="size-4" strokeWidth={1.6} />
                    </button>
                  </div>
                )}
              />
            ) : (
              <p className="text-sm text-muted">A loose shape for the hours, not a packed grid.</p>
            )}
            <AddRow
              placeholder="What happens"
              onAdd={(text) =>
                patchDay(date, (d) => ({
                  ...d,
                  schedule: [...d.schedule, { id: uid(), time: "09:00", text, done: false }],
                }))
              }
            />
          </Card>

          <Card>
            <CardTitle>Journal</CardTitle>
            <textarea
              value={log.journal}
              onChange={(event) => patchDay(date, (d) => ({ ...d, journal: event.target.value }))}
              placeholder="What is asking for your attention?"
              rows={6}
              className="min-h-32 w-full resize-y bg-transparent font-display text-lg leading-normal outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
            />
          </Card>
        </div>

        <div className="grid content-start gap-3">
          <Card>
            <CardTitle aside={<Link to="/habits" className="text-sm text-muted hover:text-ink">All habits</Link>}>
              Habits
            </CardTitle>
            {habits.length === 0 ? (
              <p className="text-sm text-muted">No habits yet.</p>
            ) : (
              <ul className="grid gap-1">
                {habits.map((habit) => {
                  const on = !!habit.checks[date];
                  const streak = streakEnding(habit.checks, parseDay(today));
                  return (
                    <li key={habit.id} className="flex items-center gap-2">
                      <button
                        type="button"
                        aria-pressed={on}
                        onClick={() => toggleHabit(habit.id, date)}
                        className="grid size-11 place-items-center"
                      >
                        <span
                          className="size-5 rounded-full border-2"
                          style={{
                            borderColor: habit.color,
                            background: on ? habit.color : "transparent",
                          }}
                        />
                      </button>
                      <span className={cn("min-w-0 flex-1 truncate text-base", on && "text-muted line-through")}>
                        {habit.name}
                      </span>
                      <span className="text-sm tabular-nums text-muted">{streak}d</span>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          {todayList && due.length > 0 ? (
            <Card>
              <CardTitle aside={<Link to="/tasks" className="text-sm text-muted hover:text-ink">{todayList.name}</Link>}>
                To do
              </CardTitle>
              <ul className="grid gap-1">
                {due.map((task) => (
                  <li key={task.id} className="flex items-center gap-2">
                    <label className="grid size-11 place-items-center">
                      <input
                        type="checkbox"
                        checked={task.done}
                        aria-label={task.text}
                        onChange={() => updateTask(task.id, { done: !task.done })}
                        className="size-5 accent-accent"
                      />
                    </label>
                    <span className="min-w-0 flex-1 text-base">{task.text}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}

          <Card>
            <CardTitle>Gratitude</CardTitle>
            <div className="grid gap-2">
              {log.gratitude.map((line, index) => (
                <input
                  key={index}
                  value={line}
                  aria-label={`Gratitude ${index + 1}`}
                  placeholder={index === 0 ? "Something small and true" : "And another"}
                  onChange={(event) =>
                    patchDay(date, (d) => {
                      const gratitude: [string, string, string] = [...d.gratitude] as [string, string, string];
                      gratitude[index] = event.target.value;
                      return { ...d, gratitude };
                    })
                  }
                  className="h-11 w-full bg-transparent text-base outline-none placeholder:text-muted"
                />
              ))}
            </div>
          </Card>

          <Card>
            <CardTitle>Mood</CardTitle>
            <div className="grid grid-cols-5 gap-1">
              {MOODS.map((mood, index) => {
                const on = log.mood === index;
                return (
                  <button
                    key={mood.label}
                    type="button"
                    aria-pressed={on}
                    aria-label={mood.hint}
                    onClick={() => patchDay(date, (d) => ({ ...d, mood: d.mood === index ? null : index }))}
                    className={cn(
                      "flex h-14 flex-col items-center justify-center rounded-lg text-xs font-medium",
                      on ? "bg-blush text-ink" : "text-muted hover:bg-paper",
                    )}
                  >
                    <span className={cn("mb-1 size-2 rounded-full", on ? "bg-accent" : "bg-line")} />
                    {mood.label}
                  </button>
                );
              })}
            </div>
          </Card>

          <Card>
            <CardTitle aside={<span className="tabular-nums text-sm text-muted">{log.water}/8</span>}>
              Water
            </CardTitle>
            <div className="grid grid-cols-8 gap-1">
              {Array.from({ length: 8 }, (_, i) => {
                const n = i + 1;
                const on = log.water >= n;
                return (
                  <button
                    key={n}
                    type="button"
                    aria-label={`${n} glasses`}
                    aria-pressed={on}
                    onClick={() => patchDay(date, (d) => ({ ...d, water: d.water === n ? n - 1 : n }))}
                    className="grid h-11 place-items-center"
                  >
                    <span className={cn("size-4 rounded-full border", on ? "border-sage bg-sage" : "border-line")} />
                  </button>
                );
              })}
            </div>
          </Card>

          <Card>
            <CardTitle>A line to return to</CardTitle>
            <input
              value={log.affirmation}
              onChange={(event) => patchDay(date, (d) => ({ ...d, affirmation: event.target.value }))}
              placeholder="Short enough to remember."
              className="h-11 w-full bg-transparent font-display text-xl outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
