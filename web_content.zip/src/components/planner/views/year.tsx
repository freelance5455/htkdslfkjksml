import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardTitle, IconButton, PageHeader } from "@/components/planner/primitives";
import { monthKey, parseMonth } from "@/lib/planner/dates";
import { useTodayKey } from "@/lib/planner/hooks";
import { usePlanner } from "@/lib/planner/store";
import { inkOn, monthTone } from "@/lib/planner/theme";
import { cn } from "@/lib/cn";

export function YearView() {
  const today = useTodayKey();
  const [cursor, setCursor] = useState<string | null>(null);
  const active = cursor ?? (today ? today.slice(0, 4) : null);
  if (!active || !today) return <PageHeader section="year" title="Year" lede="Opening the year." />;
  return <YearPage yearId={active} today={today} onYear={setCursor} />;
}

function YearPage({
  yearId,
  today,
  onYear,
}: {
  yearId: string;
  today: string;
  onYear: (key: string | null) => void;
}) {
  const year = usePlanner((s) => s.years[yearId]);
  const months = usePlanner((s) => s.months);
  const patchYear = usePlanner((s) => s.patchYear);
  const word = year?.word ?? "";
  const note = year?.note ?? "";
  const quarters = year?.quarters ?? [
    { q: 1 as const, intention: "" },
    { q: 2 as const, intention: "" },
    { q: 3 as const, intention: "" },
    { q: 4 as const, intention: "" },
  ];
  const currentYear = today.slice(0, 4);

  return (
    <div>
      <PageHeader
        section="year"
        title={yearId}
        lede="A word to steer by, and a door for each month."
        action={
          <div className="flex">
            <IconButton label="Previous year" onClick={() => onYear(String(Number(yearId) - 1))}>
              <ChevronLeft className="size-5" strokeWidth={1.6} />
            </IconButton>
            <IconButton label="Next year" onClick={() => onYear(String(Number(yearId) + 1))}>
              <ChevronRight className="size-5" strokeWidth={1.6} />
            </IconButton>
          </div>
        }
      />
      {yearId !== currentYear ? (
        <button type="button" className="mb-4 text-sm font-medium text-accent" onClick={() => onYear(null)}>
          This year
        </button>
      ) : null}

      <div className="grid gap-3">
        <Card>
          <CardTitle>Word of the year</CardTitle>
          <input
            value={word}
            onChange={(event) => patchYear(yearId, (y) => ({ ...y, word: event.target.value }))}
            placeholder="One word"
            className="h-14 w-full bg-transparent font-display text-4xl outline-none placeholder:text-muted"
          />
          <textarea
            value={note}
            onChange={(event) => patchYear(yearId, (y) => ({ ...y, note: event.target.value }))}
            placeholder="A short letter to the year ahead."
            rows={4}
            className="mt-2 min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
          />
        </Card>

        <div className="grid gap-3 sm:grid-cols-2">
          {quarters.map((quarter, index) => (
            <Card key={quarter.q}>
              <CardTitle>{`Quarter ${quarter.q}`}</CardTitle>
              <textarea
                value={quarter.intention}
                onChange={(event) =>
                  patchYear(yearId, (y) => ({
                    ...y,
                    quarters: y.quarters.map((item, i) =>
                      i === index ? { ...item, intention: event.target.value } : item,
                    ),
                  }))
                }
                placeholder="What this season is for."
                rows={3}
                className="min-h-20 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
              />
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {Array.from({ length: 12 }, (_, index) => {
            const key = monthKey(new Date(Number(yearId), index, 1));
            const log = months[key];
            const tone = monthTone(key, log?.color);
            const fg = inkOn(tone);
            const current = today.slice(0, 7) === key;
            return (
              <Link
                key={key}
                to="/month"
                search={{ m: key }}
                className={cn("flex min-h-28 flex-col justify-between rounded-3xl p-4", current && "ring-2 ring-ink")}
                style={{ background: tone, color: fg }}
              >
                <span className="text-sm font-medium">{format(parseMonth(key), "MMMM")}</span>
                <span className="font-display text-lg leading-snug text-balance">
                  {log?.intention?.trim() || "Open month"}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
