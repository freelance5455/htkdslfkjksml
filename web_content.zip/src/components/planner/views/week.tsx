import { useState } from "react";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { CheckList } from "@/components/planner/check-list";
import { Card, CardTitle, IconButton, PageHeader } from "@/components/planner/primitives";
import { dayKey, parseDay, shiftDay, weekDays } from "@/lib/planner/dates";
import { useTodayKey } from "@/lib/planner/hooks";
import { usePlanner } from "@/lib/planner/store";
import { cn } from "@/lib/cn";

export function WeekView() {
  const today = useTodayKey();
  const [cursor, setCursor] = useState<string | null>(null);
  const active = cursor ?? today;
  if (!active || !today) {
    return <PageHeader section="week" title="Week" lede="Opening the week." />;
  }
  return <WeekPage anchor={active} today={today} onAnchor={setCursor} />;
}

function WeekPage({
  anchor,
  today,
  onAnchor,
}: {
  anchor: string;
  today: string;
  onAnchor: (key: string | null) => void;
}) {
  const days = weekDays(parseDay(anchor));
  const weekId = dayKey(days[0] ?? parseDay(anchor));
  const week = usePlanner((s) => s.weeks[weekId]);
  const patchWeek = usePlanner((s) => s.patchWeek);
  const habits = usePlanner((s) => s.habits);
  const toggleHabit = usePlanner((s) => s.toggleHabit);
  const log = {
    focus: week?.focus ?? "",
    priorities: week?.priorities ?? [],
    dayNotes: week?.dayNotes ?? {},
    worked: week?.worked ?? "",
    carry: week?.carry ?? "",
  };
  const start = days[0] ?? parseDay(anchor);
  const end = days[6] ?? start;
  const thisWeek = dayKey(weekDays(parseDay(today))[0] ?? parseDay(today));

  return (
    <div>
      <PageHeader
        section="week"
        title={`${format(start, "d MMM")} – ${format(end, "d MMM")}`}
        lede="What you are protecting this week."
        action={
          <div className="flex">
            <IconButton label="Previous week" onClick={() => onAnchor(shiftDay(weekId, -7))}>
              <ChevronLeft className="size-5" strokeWidth={1.6} />
            </IconButton>
            <IconButton label="Next week" onClick={() => onAnchor(shiftDay(weekId, 7))}>
              <ChevronRight className="size-5" strokeWidth={1.6} />
            </IconButton>
          </div>
        }
      />
      {weekId !== thisWeek ? (
        <button type="button" className="mb-4 text-sm font-medium text-accent" onClick={() => onAnchor(null)}>
          This week
        </button>
      ) : null}

      <div className="grid gap-3">
        <Card>
          <CardTitle>Focus</CardTitle>
          <textarea
            value={log.focus}
            onChange={(event) => patchWeek(weekId, (w) => ({ ...w, focus: event.target.value }))}
            placeholder="If the week only did one thing well, what would it be?"
            rows={3}
            className="min-h-20 w-full resize-none bg-transparent font-display text-xl leading-snug outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
          />
        </Card>

        <Card>
          <CardTitle>Priorities</CardTitle>
          <CheckList
            items={log.priorities}
            placeholder="A weekly priority"
            onChange={(priorities) => patchWeek(weekId, (w) => ({ ...w, priorities }))}
          />
        </Card>

        {habits.length > 0 ? (
          <Card>
            <CardTitle>Habits</CardTitle>
            <div className="habit-grid mb-2 items-center text-center text-xs text-muted">
              <span />
              {days.map((d) => (
                <span key={dayKey(d)} className={cn(dayKey(d) === today && "text-ink")}>
                  {format(d, "EEEEE")}
                </span>
              ))}
            </div>
            <ul className="grid gap-2">
              {habits.map((habit) => (
                <li key={habit.id} className="habit-grid items-center">
                  <span className="truncate text-sm">{habit.name}</span>
                  {days.map((d) => {
                    const key = dayKey(d);
                    const on = !!habit.checks[key];
                    return (
                      <button
                        key={key}
                        type="button"
                        aria-label={`${habit.name} on ${format(d, "EEEE")}`}
                        aria-pressed={on}
                        onClick={() => toggleHabit(habit.id, key)}
                        className="grid h-11 w-full min-w-0 place-items-center"
                      >
                        <span
                          className="size-4 rounded-full border-2"
                          style={{ borderColor: habit.color, background: on ? habit.color : "transparent" }}
                        />
                      </button>
                    );
                  })}
                </li>
              ))}
            </ul>
          </Card>
        ) : null}

        <Card>
          <CardTitle>Days</CardTitle>
          <div className="grid gap-3">
            {days.map((d) => {
              const key = dayKey(d);
              return (
                <label key={key} className="grid gap-1">
                  <span className={cn("text-sm font-medium", key === today ? "text-accent" : "text-muted")}>
                    {format(d, "EEEE d")}
                  </span>
                  <input
                    value={log.dayNotes[key] ?? ""}
                    onChange={(event) =>
                      patchWeek(weekId, (w) => ({
                        ...w,
                        dayNotes: { ...w.dayNotes, [key]: event.target.value },
                      }))
                    }
                    placeholder="A note for this day"
                    className="h-11 w-full rounded-lg border border-line bg-card px-3 text-base outline-none placeholder:text-muted focus-visible:border-accent"
                  />
                </label>
              );
            })}
          </div>
        </Card>

        <div className="grid gap-3 md:grid-cols-2">
          <Card>
            <CardTitle>What worked</CardTitle>
            <textarea
              value={log.worked}
              onChange={(event) => patchWeek(weekId, (w) => ({ ...w, worked: event.target.value }))}
              placeholder="Keep it specific."
              rows={4}
              className="min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
            />
          </Card>
          <Card>
            <CardTitle>Carry forward</CardTitle>
            <textarea
              value={log.carry}
              onChange={(event) => patchWeek(weekId, (w) => ({ ...w, carry: event.target.value }))}
              placeholder="What still wants a place next week?"
              rows={4}
              className="min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
