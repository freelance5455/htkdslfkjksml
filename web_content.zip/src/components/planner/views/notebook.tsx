import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ColorDot, EmptyCopy, PageHeader, Segmented, fieldClass } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import type { PageStyle } from "@/lib/planner/types";
import { cn } from "@/lib/cn";

const STYLES: { value: PageStyle; label: string }[] = [
  { value: "dotted", label: "Dotted" },
  { value: "lined", label: "Lined" },
  { value: "grid", label: "Grid" },
];

export function NotebookView() {
  const notebooks = usePlanner((s) => s.notebooks);
  const pages = usePlanner((s) => s.pages);
  const addNotebook = usePlanner((s) => s.addNotebook);
  const updateNotebook = usePlanner((s) => s.updateNotebook);
  const deleteNotebook = usePlanner((s) => s.deleteNotebook);
  const addPage = usePlanner((s) => s.addPage);
  const updatePage = usePlanner((s) => s.updatePage);
  const deletePage = usePlanner((s) => s.deletePage);
  const setPages = usePlanner((s) => s.setPages);
  const accent = usePlanner((s) => s.theme.accent);
  const [bookId, setBookId] = useState(notebooks[0]?.id ?? "");
  const [pageId, setPageId] = useState<string | null>(null);

  useEffect(() => {
    if (!notebooks.some((book) => book.id === bookId)) setBookId(notebooks[0]?.id ?? "");
  }, [notebooks, bookId]);

  const book = notebooks.find((item) => item.id === bookId);
  const bookPages = pages.filter((page) => page.notebookId === bookId);
  const page = bookPages.find((item) => item.id === pageId) ?? bookPages[0];

  return (
    <div>
      <PageHeader section="notebook" title="Notebook" lede="Pages with room to think." />
      {notebooks.length === 0 ? (
        <EmptyCopy title="No notebooks yet" body="Start one for field notes, letters, or a single idea." />
      ) : (
        <div className="grid gap-4 md:grid-cols-[14rem_1fr]">
          <div className="grid content-start gap-3">
            <div className="flex gap-2 overflow-x-auto md:grid md:overflow-visible">
              {notebooks.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={item.id === bookId}
                  onClick={() => {
                    setBookId(item.id);
                    setPageId(null);
                  }}
                  className={cn(
                    "flex h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium md:w-full md:justify-start",
                    item.id === bookId ? "bg-blush text-ink" : "border border-line text-muted",
                  )}
                >
                  <span className="size-2 rounded-full" style={{ background: item.color }} />
                  <span className="truncate">{item.title}</span>
                </button>
              ))}
            </div>
            {book ? (
              <div className="hidden items-center gap-2 md:flex">
                <ColorDot label="Cover color" value={book.color} onChange={(color) => updateNotebook(book.id, { color })} />
                <button
                  type="button"
                  className="h-11 text-sm text-muted"
                  onClick={() => {
                    const prevBooks = notebooks;
                    const prevPages = pages;
                    deleteNotebook(book.id);
                    toast("Notebook removed", {
                      action: {
                        label: "Undo",
                        onClick: () => usePlanner.setState({ notebooks: prevBooks, pages: prevPages }),
                      },
                    });
                  }}
                >
                  Remove notebook
                </button>
              </div>
            ) : null}
            {bookPages.length > 0 ? (
              <SortableList
                items={bookPages}
                getId={(item) => item.id}
                onReorder={(next) => {
                  const rest = pages.filter((item) => item.notebookId !== bookId);
                  setPages([...rest, ...next]);
                }}
                render={(item, grip) => (
                  <div className={cn("flex items-center rounded-lg", page?.id === item.id && "bg-blush")}>
                    {grip}
                    <button
                      type="button"
                      onClick={() => setPageId(item.id)}
                      className="h-11 min-w-0 flex-1 truncate px-1 text-left text-sm"
                    >
                      {item.title || "Untitled"}
                    </button>
                  </div>
                )}
              />
            ) : null}
            {book ? (
              <button
                type="button"
                className="h-11 rounded-full bg-blush px-4 text-sm font-medium"
                onClick={() => {
                  const id = uid();
                  addPage({
                    id,
                    notebookId: book.id,
                    title: "New page",
                    style: "dotted",
                    content: "",
                    updated: Date.now(),
                  });
                  setPageId(id);
                }}
              >
                New page
              </button>
            ) : null}
          </div>

          {book && page ? (
            <div className="grid gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <input
                  value={page.title}
                  aria-label="Page title"
                  onChange={(event) => updatePage(page.id, { title: event.target.value, updated: Date.now() })}
                  className="h-11 min-w-0 flex-1 bg-transparent font-display text-2xl outline-none"
                />
                <button
                  type="button"
                  className="h-11 text-sm text-muted"
                  onClick={() => {
                    const prev = pages;
                    deletePage(page.id);
                    setPageId(null);
                    toast("Page removed", {
                      action: { label: "Undo", onClick: () => usePlanner.setState({ pages: prev }) },
                    });
                  }}
                >
                  Remove page
                </button>
              </div>
              <Segmented
                label="Page style"
                value={page.style}
                options={STYLES}
                onChange={(style) => updatePage(page.id, { style })}
              />
              <textarea
                value={page.content}
                aria-label="Page"
                onChange={(event) => updatePage(page.id, { content: event.target.value, updated: Date.now() })}
                placeholder="The page is yours."
                className={cn(
                  "sheet w-full resize-none rounded-3xl border border-line bg-card px-4 py-4 font-display text-lg text-ink outline-none placeholder:text-muted",
                  page.style === "dotted" && "paper-dotted",
                  page.style === "lined" && "paper-lined",
                  page.style === "grid" && "paper-grid",
                )}
              />
            </div>
          ) : book ? (
            <EmptyCopy title="No pages" body="Add a page and choose dotted, lined, or grid." />
          ) : null}
        </div>
      )}

      <form
        className="mt-6 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          const title = String(data.get("title") ?? "").trim();
          if (!title) return;
          const id = uid();
          addNotebook({ id, title, color: accent });
          addPage({
            id: uid(),
            notebookId: id,
            title: "First page",
            style: "dotted",
            content: "",
            updated: Date.now(),
          });
          setBookId(id);
          setPageId(null);
          event.currentTarget.reset();
        }}
      >
        <input name="title" placeholder="New notebook" aria-label="New notebook" className={fieldClass} />
        <button type="submit" className="h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg">
          Create
        </button>
      </form>
    </div>
  );
}
