import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Card, EmptyCopy, PageHeader } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import { VISION_SWATCHES, inkOn, safeHttpUrl } from "@/lib/planner/theme";
import { cn } from "@/lib/cn";

const AREAS = ["Sanctuary", "Craft", "Body", "Kin", "Wander", "Inner"];

export function VisionView() {
  const dream = usePlanner((s) => s.dream);
  const visions = usePlanner((s) => s.visions);
  const setDream = usePlanner((s) => s.setDream);
  const addVision = usePlanner((s) => s.addVision);
  const updateVision = usePlanner((s) => s.updateVision);
  const setVisions = usePlanner((s) => s.setVisions);

  return (
    <div>
      <PageHeader section="vision" title="Vision" lede="The life you are building toward." />
      <Card className="mb-4">
        <label className="grid gap-2">
          <span className="text-sm font-medium">Dream life</span>
          <textarea
            value={dream}
            onChange={(event) => setDream(event.target.value)}
            placeholder="Write the life in a few plain sentences."
            rows={4}
            className="min-h-28 w-full resize-none bg-transparent font-display text-2xl leading-snug outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
          />
        </label>
      </Card>

      {visions.length === 0 ? (
        <EmptyCopy title="An open board" body="Add a card for a place, a feeling, or a way of living." />
      ) : (
        <SortableList
          className="gap-3 sm:grid-cols-2"
          items={visions}
          getId={(card) => card.id}
          onReorder={setVisions}
          render={(card, grip) => <VisionTile card={card} grip={grip} all={visions} />}
        />
      )}

      <button
        type="button"
        className="mt-4 h-11 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg"
        onClick={() =>
          addVision({
            id: uid(),
            title: "",
            caption: "",
            area: "Inner",
            tone: VISION_SWATCHES[visions.length % VISION_SWATCHES.length] ?? "#f3e4e1",
            imageUrl: "",
          })
        }
      >
        Add a card
      </button>
    </div>
  );
}

function VisionTile({
  card,
  grip,
  all,
}: {
  card: ReturnType<typeof usePlanner.getState>["visions"][number];
  grip: ReactNode;
  all: ReturnType<typeof usePlanner.getState>["visions"];
}) {
  const updateVision = usePlanner((s) => s.updateVision);
  const setVisions = usePlanner((s) => s.setVisions);
  const fg = inkOn(card.tone);
  const src = safeHttpUrl(card.imageUrl);
  const [broken, setBroken] = useState(false);

  return (
    <article className="overflow-hidden rounded-3xl" style={{ background: card.tone, color: fg }}>
      {src && !broken ? (
        <img
          src={src}
          alt=""
          className="h-36 w-full object-cover"
          onError={() => setBroken(true)}
        />
      ) : null}
      <div className="p-4">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex flex-wrap gap-1">
            {AREAS.map((area) => (
              <button
                key={area}
                type="button"
                aria-pressed={card.area === area}
                onClick={() => updateVision(card.id, { area })}
                className={cn(
                  "h-8 rounded-full px-2 text-xs",
                  card.area === area ? "bg-card/70" : "opacity-70",
                )}
              >
                {area}
              </button>
            ))}
          </div>
          <span className="text-current">{grip}</span>
        </div>
        <input
          value={card.title}
          aria-label="Dream title"
          placeholder="A title"
          onChange={(event) => updateVision(card.id, { title: event.target.value })}
          className="h-11 w-full bg-transparent font-display text-2xl outline-none placeholder:opacity-60"
        />
        <textarea
          value={card.caption}
          aria-label="Caption"
          placeholder="What it feels like."
          rows={3}
          onChange={(event) => updateVision(card.id, { caption: event.target.value })}
          className="min-h-20 w-full resize-none bg-transparent text-base outline-none placeholder:opacity-60"
        />
        <input
          value={card.imageUrl}
          aria-label="Image link"
          placeholder="Image link, optional"
          onChange={(event) => {
            setBroken(false);
            updateVision(card.id, { imageUrl: event.target.value });
          }}
          className="mt-2 h-11 w-full bg-transparent text-sm outline-none placeholder:opacity-60"
        />
        <div className="mt-3 flex items-center justify-between gap-2">
          <div className="flex flex-wrap gap-1">
            {VISION_SWATCHES.map((tone) => (
              <button
                key={tone}
                type="button"
                aria-label={`Tone ${tone}`}
                onClick={() => updateVision(card.id, { tone })}
                className="grid size-8 place-items-center rounded-full"
              >
                <span
                  className={cn("size-4 rounded-full border", card.tone === tone && "border-current")}
                  style={{ background: tone }}
                />
              </button>
            ))}
            <input
              type="color"
              aria-label="Custom tone"
              value={/^#[0-9a-fA-F]{6}$/.test(card.tone) ? card.tone : "#f3e4e1"}
              onChange={(event) => updateVision(card.id, { tone: event.target.value })}
              className="color-dot"
            />
          </div>
          <button
            type="button"
            className="h-11 text-sm"
            onClick={() => {
              const prev = all;
              setVisions(all.filter((item) => item.id !== card.id));
              toast("Card removed", { action: { label: "Undo", onClick: () => setVisions(prev) } });
            }}
          >
            Remove
          </button>
        </div>
      </div>
    </article>
  );
}
