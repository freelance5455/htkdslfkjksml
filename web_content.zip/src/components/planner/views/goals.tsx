import { toast } from "sonner";
import { CheckList } from "@/components/planner/check-list";
import { Card, EmptyCopy, PageHeader, fieldClass } from "@/components/planner/primitives";
import { SortableList } from "@/components/planner/sortable";
import { uid } from "@/lib/planner/id";
import { usePlanner } from "@/lib/planner/store";
import type { GoalStatus } from "@/lib/planner/types";
import { cn } from "@/lib/cn";

const STATUSES: { value: GoalStatus; label: string }[] = [
  { value: "active", label: "Active" },
  { value: "paused", label: "Paused" },
  { value: "done", label: "Done" },
];

export function GoalsView() {
  const goals = usePlanner((s) => s.goals);
  const addGoal = usePlanner((s) => s.addGoal);
  const updateGoal = usePlanner((s) => s.updateGoal);
  const setGoals = usePlanner((s) => s.setGoals);

  return (
    <div>
      <PageHeader section="goals" title="Goals" lede="The few outcomes that matter." />
      {goals.length === 0 ? (
        <EmptyCopy title="Nothing named yet" body="A goal with a reason is easier to keep." />
      ) : (
        <SortableList
          items={goals}
          getId={(goal) => goal.id}
          onReorder={setGoals}
          className="gap-3"
          render={(goal, grip) => (
            <Card>
              <div className="mb-3 flex items-start gap-1">
                {grip}
                <div className="min-w-0 flex-1">
                  <input
                    value={goal.title}
                    aria-label="Goal title"
                    onChange={(event) => updateGoal(goal.id, { title: event.target.value })}
                    placeholder="Name the goal"
                    className="h-11 w-full bg-transparent font-display text-2xl outline-none placeholder:text-muted"
                  />
                  <input
                    value={goal.area}
                    aria-label="Area"
                    onChange={(event) => updateGoal(goal.id, { area: event.target.value })}
                    placeholder="Area — craft, home, body"
                    className="h-10 w-full bg-transparent text-sm text-muted outline-none placeholder:text-muted"
                  />
                </div>
                <button
                  type="button"
                  className="h-11 px-2 text-sm text-muted"
                  onClick={() => {
                    const prev = goals;
                    setGoals(goals.filter((item) => item.id !== goal.id));
                    toast("Goal removed", { action: { label: "Undo", onClick: () => setGoals(prev) } });
                  }}
                >
                  Remove
                </button>
              </div>
              <textarea
                value={goal.why}
                aria-label="Why this goal"
                onChange={(event) => updateGoal(goal.id, { why: event.target.value })}
                placeholder="Why it matters."
                rows={2}
                className="mb-3 min-h-16 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
              />
              <label className="mb-3 grid gap-2">
                <span className="flex items-center justify-between text-sm text-muted">
                  Progress
                  <span className="tabular-nums text-ink">{goal.progress}%</span>
                </span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={goal.progress}
                  aria-label="Progress"
                  onChange={(event) => updateGoal(goal.id, { progress: Number(event.target.value) })}
                  className="slider"
                />
              </label>
              <div className="mb-3 flex flex-wrap gap-2">
                {STATUSES.map((status) => (
                  <button
                    key={status.value}
                    type="button"
                    aria-pressed={goal.status === status.value}
                    onClick={() => updateGoal(goal.id, { status: status.value })}
                    className={cn(
                      "h-10 rounded-full px-3 text-sm font-medium",
                      goal.status === status.value ? "bg-blush text-ink" : "text-muted",
                    )}
                  >
                    {status.label}
                  </button>
                ))}
                <input
                  type="date"
                  value={goal.deadline}
                  aria-label="Deadline"
                  onChange={(event) => updateGoal(goal.id, { deadline: event.target.value })}
                  className="h-10 min-w-0 rounded-lg border border-line bg-card px-2 text-sm"
                />
              </div>
              <p className="mb-2 text-sm font-medium">Milestones</p>
              <CheckList
                items={goal.milestones}
                placeholder="A milestone"
                onChange={(milestones) => updateGoal(goal.id, { milestones })}
              />
            </Card>
          )}
        />
      )}
      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          const title = String(data.get("title") ?? "").trim();
          if (!title) return;
          addGoal({
            id: uid(),
            title,
            area: "",
            why: "",
            progress: 0,
            deadline: "",
            status: "active",
            milestones: [],
          });
          event.currentTarget.reset();
        }}
      >
        <input name="title" placeholder="New goal" aria-label="New goal" className={fieldClass} />
        <button
          type="submit"
          className="h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg"
        >
          Add
        </button>
      </form>
    </div>
  );
}
