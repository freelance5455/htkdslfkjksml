import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatMessage } from '../types.ts';
import { PlayerHead } from './PlayerHead.tsx';
import {
  X,
  Send,
  Edit2,
  Check,
  MessageSquare,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose }) => {
  // Load saved profile from localStorage
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('helden_chat_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.name?.trim()) return parsed;
      }
      const rawName = localStorage.getItem('helden_chat_username');
      const rawPlatform = localStorage.getItem('helden_chat_platform') as 'java' | 'bedrock' | null;
      if (rawName && rawName.trim()) {
        const isBedrock = rawPlatform === 'bedrock' || rawName.startsWith('.');
        const clean = isBedrock ? (rawName.startsWith('.') ? rawName : '.' + rawName) : rawName;
        return { name: clean, platform: isBedrock ? 'bedrock' : 'java' };
      }
      return null;
    } catch {
      return null;
    }
  });

  // Edit / setup profile mode
  const [isEditingProfile, setIsEditingProfile] = useState(!profile?.name);
  const [inputName, setInputName] = useState(() => {
    if (profile?.name) return profile.name;
    try {
      return localStorage.getItem('helden_chat_username') || '';
    } catch {
      return '';
    }
  });
  const [platform, setPlatform] = useState<'java' | 'bedrock'>(() => {
    if (profile?.platform) return profile.platform;
    try {
      return (localStorage.getItem('helden_chat_platform') as 'java' | 'bedrock') || 'java';
    } catch {
      return 'java';
    }
  });

  // Chat message state
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const savedMsgs = sessionStorage.getItem('helden_chat_msgs');
      return savedMsgs ? JSON.parse(savedMsgs) : [];
    } catch {
      return [];
    }
  });
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [sendSuccess, setSendSuccess] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync profile setup fields when opening
  useEffect(() => {
    if (isOpen) {
      if (!profile) {
        setIsEditingProfile(true);
      }
    }
  }, [isOpen, profile]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (isOpen && !isEditingProfile) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isEditingProfile]);

  if (!isOpen) return null;

  // Handle Bedrock / Java platform toggle with automatic dot prefix
  const handlePlatformChange = (newPlatform: 'java' | 'bedrock') => {
    setPlatform(newPlatform);
    if (newPlatform === 'bedrock') {
      // Bedrock: automatically prepend dot if not already present
      if (inputName && !inputName.startsWith('.')) {
        setInputName('.' + inputName);
      }
    } else {
      // Java: strip leading dot if user had one
      if (inputName.startsWith('.')) {
        setInputName(inputName.replace(/^\.+/, ''));
      }
    }
  };

  // Handle typing name: keep dot if bedrock
  const handleNameInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value;
    if (platform === 'bedrock') {
      // Ensure leading dot for Bedrock
      if (val.length > 0 && !val.startsWith('.')) {
        val = '.' + val;
      }
    }
    setInputName(val);
  };

  // Save profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    let finalName = inputName.trim();
    if (!finalName) return;

    if (platform === 'bedrock' && !finalName.startsWith('.')) {
      finalName = '.' + finalName;
    } else if (platform === 'java' && finalName.startsWith('.')) {
      finalName = finalName.replace(/^\.+/, '');
    }

    const newProfile: UserProfile = {
      name: finalName,
      platform,
    };

    setProfile(newProfile);
    setInputName(finalName);
    try {
      localStorage.setItem('helden_chat_profile', JSON.stringify(newProfile));
      localStorage.setItem('helden_chat_username', finalName);
      localStorage.setItem('helden_chat_platform', platform);
    } catch {
      // ignore
    }
    setIsEditingProfile(false);
  };

  // Send message to ServerTap / Minecraft server
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !profile || isSending) return;

    const textToSend = message.trim();
    setIsSending(true);
    setSendError(null);
    setSendSuccess(false);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: profile.name,
          message: textToSend,
          platform: profile.platform,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Fehler beim Senden (${res.status})`);
      }

      const newMsg: ChatMessage = {
        id: Date.now().toString(),
        sender: profile.name,
        text: textToSend,
        timestamp: Date.now(),
        platform: profile.platform,
      };

      const updated = [...messages, newMsg];
      setMessages(updated);
      try {
        sessionStorage.setItem('helden_chat_msgs', JSON.stringify(updated));
      } catch {
        // ignore
      }

      setMessage('');
      setSendSuccess(true);
      setTimeout(() => setSendSuccess(false), 2000);
    } catch (err: any) {
      setSendError(err.message || 'Verbindung zum Server fehlgeschlagen');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-2xl bg-zinc-900 border border-zinc-800 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-900/90 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Minecraft Server Chat</span>
              </h3>
              <p className="text-[11px] text-zinc-400">
                Nachrichten direkt an den Server senden
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content: Mode 1 - Profile Setup */}
        {isEditingProfile ? (
          <form onSubmit={handleSaveProfile} className="p-5 space-y-5 overflow-y-auto">
            <div className="text-center space-y-1">
              <h4 className="text-sm font-semibold text-zinc-100">
                Wer bist du auf dem Server?
              </h4>
              <p className="text-xs text-zinc-400">
                Wähle deinen Minecraft-Namen und deine Edition.
              </p>
            </div>

            {/* Live Head Preview */}
            <div className="flex flex-col items-center justify-center py-2">
              <PlayerHead
                identifier={inputName.trim() || (platform === 'bedrock' ? '.Steve' : 'Steve')}
                size="lg"
                className="w-16 h-16 shadow-lg ring-2 ring-emerald-500/40 rounded-xl"
              />
              <span className="text-xs font-mono text-zinc-300 mt-2">
                {inputName.trim() || 'Spielername'}
              </span>
            </div>

            {/* Edition Switcher: Java vs Bedrock */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                Minecraft Edition
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-950 border border-zinc-800">
                <button
                  type="button"
                  onClick={() => handlePlatformChange('java')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                    platform === 'java'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Java Edition
                </button>
                <button
                  type="button"
                  onClick={() => handlePlatformChange('bedrock')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                    platform === 'bedrock'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Bedrock Edition
                </button>
              </div>
              <p className="text-[11px] text-zinc-500">
                {platform === 'bedrock'
                  ? '✓ Bedrock aktiv: Ein Punkt (.) wird automatisch vor deinen Namen gesetzt.'
                  : '✓ Java aktiv: Name ohne führenden Punkt.'}
              </p>
            </div>

            {/* Name Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                Minecraft Name
              </label>
              <input
                type="text"
                value={inputName}
                onChange={handleNameInputChange}
                placeholder={platform === 'bedrock' ? '.DeinName' : 'DeinName'}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2">
              {profile && (
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800"
                >
                  Abbrechen
                </button>
              )}
              <button
                type="submit"
                disabled={!inputName.trim()}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-50 shadow-sm"
              >
                <Check className="w-4 h-4" />
                <span>Fertig</span>
              </button>
            </div>
          </form>
        ) : (
          /* Content: Mode 2 - Active Chat Room */
          <div className="flex flex-col flex-1 min-h-[360px] max-h-[500px]">
            {/* Active User Bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-950/60 border-b border-zinc-800/80 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <PlayerHead
                  identifier={profile!.name}
                  size="sm"
                  className="w-7 h-7 rounded-md"
                />
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs font-semibold text-zinc-200 truncate font-mono">
                    {profile!.name}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                      profile!.platform === 'bedrock'
                        ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                        : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                    }`}
                  >
                    {profile!.platform === 'bedrock' ? 'Bedrock' : 'Java'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setInputName(profile!.name);
                  setPlatform(profile!.platform);
                  setIsEditingProfile(true);
                }}
                title="Namen oder Edition ändern"
                className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-emerald-300 px-2 py-1 rounded-md hover:bg-zinc-800 transition-colors"
              >
                <Edit2 className="w-3 h-3" />
                <span>Ändern</span>
              </button>
            </div>

            {/* Chat Messages List */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-zinc-950/30 text-xs">
              <div className="p-2.5 rounded-xl bg-zinc-800/40 border border-zinc-700/40 text-zinc-400 text-center text-[11px] space-y-0.5">
                <span className="text-emerald-400 font-semibold flex items-center justify-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  Live-Verbindung zum Minecraft Server
                </span>
                <p>Nachrichten erscheinen direkt im Ingame-Chat für alle Spieler.</p>
              </div>

              {messages.length === 0 ? (
                <div className="text-center py-8 text-zinc-500 space-y-1">
                  <p>Noch keine Nachrichten gesendet.</p>
                  <p className="text-[11px]">Schreibe den Online-Spielern etwas!</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className="flex flex-col items-end gap-1"
                  >
                    <div className="flex items-baseline gap-1.5 text-[10px] text-zinc-500 mr-1">
                      <span className="font-semibold text-zinc-300">{msg.sender}</span>
                      <span>·</span>
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="max-w-[85%] px-3.5 py-2 rounded-2xl bg-emerald-600/90 text-white rounded-tr-xs shadow-sm text-xs leading-relaxed break-words">
                      {msg.text}
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Send Error / Success notification */}
            {sendError && (
              <div className="px-4 py-1.5 bg-red-950/60 border-t border-red-500/30 text-red-300 text-[11px] flex items-center gap-1.5 shrink-0">
                <AlertCircle className="w-3 h-3 text-red-400 shrink-0" />
                <span className="truncate">{sendError}</span>
              </div>
            )}
            {sendSuccess && (
              <div className="px-4 py-1 bg-emerald-950/60 border-t border-emerald-500/30 text-emerald-300 text-[11px] flex items-center gap-1.5 shrink-0">
                <Check className="w-3 h-3 text-emerald-400" />
                <span>Nachricht an Minecraft-Server gesendet!</span>
              </div>
            )}

            {/* Message Input Box */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 border-t border-zinc-800 bg-zinc-900/90 flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Nachricht an den Server schreiben..."
                disabled={isSending}
                className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!message.trim() || isSending}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all disabled:opacity-50 shadow-sm active:scale-95 shrink-0"
                title="Nachricht senden"
              >
                <Send className={`w-4 h-4 ${isSending ? 'animate-pulse' : ''}`} />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
