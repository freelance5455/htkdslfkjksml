import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  ExternalLink,
  MessageSquare,
  Pin,
  Plus,
  RefreshCw,
  Send,
  StickyNote,
  Trash2,
} from 'lucide-react';
import {
  ConfirmDialogState,
  FIELD_LIMITS,
  NOTE_CATEGORIES,
  NoteCategory,
  OpsNote,
} from '../types/ops';
import {
  ChatMessage,
  ChatSpace,
  listChatMessages,
  listChatSpaces,
  sendChatMessage,
  WorkspaceApiError,
} from '../lib/workspaceApi';
import {
  createOpsNote,
  deleteOpsNote,
  updateOpsNote,
} from '../lib/firestoreOps';
import { FIREBASE_PROJECT_ID } from '../lib/firebase';
import { WorkspaceTokenGate } from './WorkspaceTokenGate';

interface ChatKeepViewProps {
  ownerId: string;
  accessToken: string | null;
  isLoggingIn: boolean;
  notes: OpsNote[];
  onReconnectWorkspace: () => void;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export const ChatKeepView: React.FC<ChatKeepViewProps> = ({
  ownerId,
  accessToken,
  isLoggingIn,
  notes,
  onReconnectWorkspace,
  onRequestConfirm,
  onNotify,
}) => {
  // Google Chat state
  const [spaces, setSpaces] = useState<ChatSpace[]>([]);
  const [selectedSpace, setSelectedSpace] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingChat, setLoadingChat] = useState(false);
  const [chatError, setChatError] = useState<{ message: string; isConfigMissing: boolean } | null>(
    null
  );
  const [chatInput, setChatInput] = useState('');

  // Operational Notes / Keep Board state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteCategory, setNoteCategory] = useState<NoteCategory>('Restock');
  const [noteContent, setNoteContent] = useState('');
  const [checklistText, setChecklistText] = useState('');
  const [savingNote, setSavingNote] = useState(false);

  const loadChatSpaces = useCallback(async () => {
    if (!accessToken) return;
    setLoadingChat(true);
    setChatError(null);
    try {
      const list = await listChatSpaces(accessToken);
      setSpaces(list);
      if (list[0]?.name) {
        setSelectedSpace(list[0].name);
        const msgs = await listChatMessages(accessToken, list[0].name);
        setMessages(msgs);
      } else {
        setMessages([]);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gagal terhubung ke Google Chat.';
      const is404or403 =
        err instanceof WorkspaceApiError && (err.status === 404 || err.status === 403);
      setChatError({ message: msg, isConfigMissing: is404or403 });
    } finally {
      setLoadingChat(false);
    }
  }, [accessToken]);

  useEffect(() => {
    loadChatSpaces();
  }, [loadChatSpaces]);

  const handleSelectSpace = async (spaceName: string) => {
    if (!accessToken) return;
    setSelectedSpace(spaceName);
    setLoadingChat(true);
    try {
      const msgs = await listChatMessages(accessToken, spaceName);
      setMessages(msgs);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Gagal memuat pesan ruang chat.', 'error');
    } finally {
      setLoadingChat(false);
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !selectedSpace || !chatInput.trim()) return;
    const text = chatInput.trim();
    const spaceLabel =
      spaces.find((s) => s.name === selectedSpace)?.displayName || selectedSpace;
    onRequestConfirm({
      open: true,
      title: `Kirim Pesan ke Google Chat "${spaceLabel}"?`,
      description: 'Pesan akan dikirim atas nama akun Google Anda ke ruang Google Chat tim.',
      confirmLabel: 'Kirim Pesan',
      details: [`Ruang: ${spaceLabel}`, `Isi pesan: ${text}`],
      onConfirm: async () => {
        await sendChatMessage(accessToken, selectedSpace, text);
        setChatInput('');
        const msgs = await listChatMessages(accessToken, selectedSpace);
        setMessages(msgs);
        onNotify('Pesan terkirim ke Google Chat.', 'success');
      },
    });
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim()) return;
    setSavingNote(true);
    try {
      const checklist = checklistText
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);
      await createOpsNote(ownerId, {
        title: noteTitle,
        content: noteContent,
        category: noteCategory,
        pinned: false,
        checklist,
      });
      setNoteTitle('');
      setNoteContent('');
      setChecklistText('');
      onNotify('Memo operasional berhasil disimpan.', 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Gagal menyimpan memo.', 'error');
    } finally {
      setSavingNote(false);
    }
  };

  const handleTogglePin = async (note: OpsNote) => {
    await updateOpsNote(note.id, { pinned: !note.pinned });
  };

  const handleDeleteNote = (note: OpsNote) => {
    onRequestConfirm({
      open: true,
      title: `Hapus Memo "${note.title}"?`,
      description: 'Catatan dan checklist di dalamnya akan dihapus permanen.',
      confirmLabel: 'Hapus Memo',
      variant: 'danger',
      onConfirm: async () => {
        await deleteOpsNote(note.id);
        onNotify('Memo operasional dihapus.', 'success');
      },
    });
  };

  const sortedNotes = [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned));

  return (
    <div className="space-y-6">
      <div className="pb-5 border-b border-stone-200">
        <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
          Google Chat & Memo Operasional (Keep)
        </h1>
        <p className="text-sm text-stone-600 mt-1">
          Koordinasi cepat bersama tim gudang, host live, dan kreator melalui ruang Google Chat serta papan memo & checklist harian.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Google Chat Column */}
        <section className="lg:col-span-6 bg-white border border-stone-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <MessageSquare className="w-4 h-4 text-orange-600" />
              <h2 className="text-base font-semibold text-stone-900">Ruang Tim Google Chat</h2>
            </div>
            {accessToken && (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={loadChatSpaces}
                disabled={loadingChat}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-700 border border-stone-300 rounded-lg hover:bg-stone-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingChat ? 'animate-spin' : ''}`} />
                Muat Ruang
              </motion.button>
            )}
          </div>

          <div className="p-5 space-y-4">
            {!accessToken ? (
              <WorkspaceTokenGate
                serviceName="Google Chat"
                onReconnect={onReconnectWorkspace}
                isLoggingIn={isLoggingIn}
              />
            ) : chatError ? (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div className="text-xs text-stone-800 space-y-1.5">
                    <p className="font-semibold text-amber-900">
                      Prasyarat Konfigurasi Google Chat API
                    </p>
                    <p className="font-mono text-[11px] text-amber-800 break-words">
                      {chatError.message}
                    </p>
                    <p className="text-stone-700 leading-relaxed">
                      Google Chat API memerlukan akun <strong>Google Workspace Business/Enterprise</strong> (akun @gmail.com personal tidak didukung) serta konfigurasi aplikasi Chat satu kali di Google Cloud Console.
                    </p>
                    <a
                      href={`https://console.cloud.google.com/apis/api/chat.googleapis.com/hangouts-chat?project=${FIREBASE_PROJECT_ID}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 font-semibold text-orange-700 hover:underline pt-1"
                    >
                      Buka Konfigurasi Google Chat di Cloud Console
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            ) : spaces.length === 0 ? (
              <div className="py-6 text-center text-sm text-stone-600">
                Belum ada ruang Google Chat yang ditemukan pada akun Anda.
              </div>
            ) : (
              <>
                <select
                  value={selectedSpace}
                  onChange={(e) => handleSelectSpace(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white"
                >
                  {spaces.map((s) => (
                    <option key={s.name} value={s.name}>
                      {s.displayName || s.name}
                    </option>
                  ))}
                </select>

                <div className="border border-stone-200 rounded-lg bg-stone-50 p-3 space-y-2.5 max-h-72 overflow-y-auto">
                  {messages.length === 0 ? (
                    <p className="text-xs text-stone-500 text-center py-4">
                      Belum ada pesan di ruang ini.
                    </p>
                  ) : (
                    messages.map((m) => (
                      <div key={m.name} className="bg-white border border-stone-200 rounded-lg p-3">
                        <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
                          <span className="font-semibold text-stone-800">
                            {m.sender?.displayName || 'Anggota Tim'}
                          </span>
                          <span className="font-mono">
                            {m.createTime
                              ? new Date(m.createTime).toLocaleTimeString('id-ID', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })
                              : ''}
                          </span>
                        </div>
                        <p className="text-sm text-stone-800 whitespace-pre-wrap">{m.text}</p>
                      </div>
                    ))
                  )}
                </div>

                <form onSubmit={handleSendChat} className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Kirim eskalasi atau info pengiriman ke ruang tim..."
                    className="flex-1 px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 whitespace-nowrap shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Kirim
                  </motion.button>
                </form>
              </>
            )}
          </div>
        </section>

        {/* Operational Memo / Keep Board Column */}
        <section className="lg:col-span-6 bg-white border border-stone-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <StickyNote className="w-4 h-4 text-orange-600" />
              <h2 className="text-base font-semibold text-stone-900">
                Papan Memo & Checklist (Keep Board)
              </h2>
            </div>
            <a
              href="https://keep.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs font-medium text-orange-700 hover:underline"
            >
              Buka Google Keep
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="px-5 py-3 bg-stone-50 border-b border-stone-200 text-xs text-stone-600">
            Memo tersinkronisasi real-time via Firestore untuk akun Anda. (API resmi Google Keep hanya tersedia bagi akun Enterprise Workspace dengan Domain-Wide Delegation).
          </div>

          <form onSubmit={handleCreateNote} className="p-5 border-b border-stone-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                required
                maxLength={FIELD_LIMITS.noteTitleMax}
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                placeholder="Judul memo..."
                className="sm:col-span-2 px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
              />
              <select
                value={noteCategory}
                onChange={(e) => setNoteCategory(e.target.value as NoteCategory)}
                className="px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white"
              >
                {NOTE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <textarea
              rows={2}
              maxLength={FIELD_LIMITS.noteContentMax}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="Catatan singkat operasional (kendala kurir, rencana promo, info supplier)..."
              className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
            />
            <textarea
              rows={2}
              value={checklistText}
              onChange={(e) => setChecklistText(e.target.value)}
              placeholder="Checklist (opsional, pisahkan tiap item dengan baris baru)"
              className="w-full px-3 py-2 text-xs font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
            />
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              type="submit"
              disabled={savingNote}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:opacity-60"
            >
              <Plus className="w-3.5 h-3.5" />
              {savingNote ? 'Menyimpan...' : 'Simpan Memo'}
            </motion.button>
          </form>

          {sortedNotes.length === 0 ? (
            <div className="p-8 text-center text-sm text-stone-600">
              Belum ada memo operasional. Buat catatan cepat pertama Anda di atas.
            </div>
          ) : (
            <div className="divide-y divide-stone-100">
              {sortedNotes.map((note) => (
                <div key={note.id} className="p-5 hover:bg-orange-50/30 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs text-stone-500">
                        <span className="font-semibold text-stone-700">{note.category}</span>
                        {note.pinned && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-medium text-orange-700">Disematkan</span>
                          </>
                        )}
                      </div>
                      <h3 className="text-sm font-semibold text-stone-900 mt-0.5">{note.title}</h3>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleTogglePin(note)}
                        title={note.pinned ? 'Lepas sematan' : 'Sematkan memo'}
                        className={`p-1.5 rounded-md transition-colors ${
                          note.pinned
                            ? 'text-orange-700 bg-orange-50'
                            : 'text-stone-400 hover:text-stone-700'
                        }`}
                      >
                        <Pin className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteNote(note)}
                        title="Hapus memo"
                        className="p-1.5 text-stone-400 hover:text-red-700 rounded-md"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  {note.content && (
                    <p className="text-sm text-stone-600 mt-1.5 whitespace-pre-wrap">
                      {note.content}
                    </p>
                  )}
                  {note.checklist && note.checklist.length > 0 && (
                    <ul className="mt-2.5 space-y-1 text-xs text-stone-700">
                      {note.checklist.map((item, idx) => (
                        <li key={idx}>• {item}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
