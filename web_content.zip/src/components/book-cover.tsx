import { COVER_CLASS, type Book } from "@/lib/library";
import { cn } from "@/lib/utils";

export function BookCover({ book, compact = false }: { book: Book; compact?: boolean }) {
  return (
    <div
      className={cn(
        "relative flex aspect-book flex-col justify-between overflow-hidden p-4 sm:p-5",
        COVER_CLASS[book.cover],
        compact && "h-full min-h-28 aspect-auto p-3",
      )}
    >
      <div className="absolute inset-y-0 left-0 w-1.5 bg-cream/10" />
      <p className="text-[0.65rem] uppercase tracking-[0.16em] text-cream/55">{book.author}</p>
      <div>
        <p
          className={cn(
            "font-display leading-[1.15] tracking-tight text-balance",
            compact ? "text-base" : "text-lg sm:text-xl",
          )}
        >
          {book.title}
        </p>
        <p className="mt-3 text-[0.65rem] tabular-nums tracking-[0.14em] text-cream/45">{book.years}</p>
      </div>
    </div>
  );
}
