import { coverFor, initials } from "@/lib/covers";
import { cn } from "@/lib/utils";

type BookCoverProps = {
  id: string;
  title: string;
  className?: string;
};

export function BookCover({ id, title, className }: BookCoverProps) {
  const palette = coverFor(id);
  return (
    <div
      className={cn(
        "relative isolate overflow-hidden rounded-md",
        className,
      )}
      style={{ background: palette.bg, color: palette.fg }}
      aria-hidden="true"
    >
      <div
        className="absolute inset-y-0 left-0 w-1.5 opacity-80"
        style={{ background: palette.rule }}
      />
      <div className="absolute inset-0 opacity-[0.07] [background-image:repeating-linear-gradient(90deg,transparent,transparent_11px,currentColor_11px,currentColor_12px)]" />
      <div className="relative flex h-full flex-col justify-between p-3 pl-4">
        <span className="font-display text-2xl font-medium tracking-tight">
          {initials(title)}
        </span>
        <span className="line-clamp-3 font-display text-xs leading-snug tracking-tight">
          {title}
        </span>
      </div>
    </div>
  );
}
