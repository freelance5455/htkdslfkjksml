import React from 'react';
import { useApp } from '../context/AppContext';
import {
  User,
  Shield,
  Bell,
  Sparkles,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Smartphone,
  Maximize2,
  Download,
  RotateCcw,
  Star,
  CheckCircle2,
  Sliders,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const ProfileSettingsScreen: React.FC = () => {
  const {
    profile,
    updateProfile,
    isMobileFrameView,
    setIsMobileFrameView,
    setActiveScreen,
    tasks,
    habits,
    transactions,
    memories,
  } = useApp();

  const handleExportData = () => {
    sound.playClick();
    const data = {
      profile,
      tasks,
      habits,
      transactions,
      memories,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hibuddy_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetData = () => {
    if (confirm('Reset HiBuddy to starter defaults? This clears your local changes.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-4">
      {/* 1. Profile Header Card */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex items-center gap-4">
        <div className="relative">
          <img
            src={profile.avatarUrl}
            alt={profile.name}
            className="w-16 h-16 rounded-full object-cover ring-2 ring-indigo-500/30 shadow-md"
            referrerPolicy="no-referrer"
          />
          <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-indigo-600 text-white shadow-xs">
            <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
              {profile.name}
            </h3>
            <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-100 dark:bg-indigo-900/60 px-2 py-0.5 rounded-full shrink-0">
              PRO
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
            {profile.email}
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-[10px] text-slate-400 font-mono">Member since 2026</span>
          </div>
        </div>
      </div>

      {/* 2. HiBuddy Pro Subscription Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white shadow-xl shadow-indigo-950/20 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
              <Star className="w-4 h-4 fill-amber-300" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-200">
                HiBuddy Pro Plan
              </h4>
              <p className="text-[11px] text-slate-300">Unlimited AI scheduling & voice assist</p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full">
            Active
          </span>
        </div>

        <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-[11px] text-slate-300">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Smart Auto-Scheduler</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Real-time Voice Copilot</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Encrypted Memory Bank</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Full Budget Analytics</span>
          </div>
        </div>
      </div>

      {/* 3. Appearance & View Layout */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          Appearance & View Mode
        </h4>

        {/* Theme mode selection */}
        <div className="flex items-center justify-between py-1">
          <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
            Interface Theme
          </span>
          <div className="flex rounded-xl bg-slate-100 dark:bg-slate-700 p-1 text-xs">
            {(['light', 'dark', 'system'] as const).map((t) => (
              <button
                key={t}
                onClick={() => {
                  sound.playClick();
                  updateProfile({ theme: t });
                }}
                className={`px-3 py-1 rounded-lg capitalize font-medium transition-colors ${
                  profile.theme === t
                    ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Frame Toggle */}
        <div className="flex items-center justify-between py-1 border-t border-slate-100 dark:border-slate-700/60">
          <div>
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 block">
              Device Frame View
            </span>
            <span className="text-[10px] text-slate-400">
              Display inside modern smartphone mockup
            </span>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              const next = !isMobileFrameView;
              setIsMobileFrameView(next);
              localStorage.setItem('hibuddy_frame_view', JSON.stringify(next));
            }}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              isMobileFrameView
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 text-indigo-700 dark:text-indigo-300'
                : 'bg-slate-50 dark:bg-slate-750 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
            }`}
          >
            {isMobileFrameView ? (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span>Phone Frame</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Responsive</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 4. AI Copilot Personalization */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-violet-500" />
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            AI Assistant Preferences
          </h4>
        </div>

        {/* Tone */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
            Assistant Personality Tone
          </label>
          <div className="grid grid-cols-3 gap-1.5 text-xs">
            {[
              { id: 'friendly', label: 'Friendly & Warm' },
              { id: 'concise', label: 'Direct & Crisp' },
              { id: 'deep', label: 'Deep Mentor' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  sound.playClick();
                  updateProfile({ aiTone: item.id as any });
                }}
                className={`py-2 px-2 text-center rounded-xl border transition-colors ${
                  profile.aiTone === item.id
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 font-semibold'
                    : 'bg-slate-50 dark:bg-slate-750 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Read Aloud Toggle */}
        <div className="flex items-center justify-between py-1 border-t border-slate-100 dark:border-slate-700/60">
          <div>
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 block">
              Read Responses Aloud
            </span>
            <span className="text-[10px] text-slate-400">
              Speak Buddy's messages automatically via speech synthesis
            </span>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              updateProfile({ voiceOutputEnabled: !profile.voiceOutputEnabled });
            }}
            className={`p-2 rounded-xl border transition-colors ${
              profile.voiceOutputEnabled
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-400 border-slate-200 dark:border-slate-600'
            }`}
          >
            {profile.voiceOutputEnabled ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Sound Effects */}
        <div className="flex items-center justify-between py-1 border-t border-slate-100 dark:border-slate-700/60">
          <div>
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 block">
              Subtle Audio Haptics
            </span>
            <span className="text-[10px] text-slate-400">
              Soft harmonic chimes on task check-off and streak updates
            </span>
          </div>
          <button
            onClick={() => {
              const next = !profile.soundEnabled;
              updateProfile({ soundEnabled: next });
              if (next) sound.playClick();
            }}
            className={`p-2 rounded-xl border transition-colors ${
              profile.soundEnabled
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-400 border-slate-200 dark:border-slate-600'
            }`}
          >
            {profile.soundEnabled ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* 5. Data & Privacy Management */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-2.5">
        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          Data & Local Privacy
        </h4>

        <div className="space-y-1.5 pt-1">
          <button
            onClick={handleExportData}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <Download className="w-4 h-4 text-indigo-500" />
              <span>Export All App Data (JSON)</span>
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('onboarding');
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-violet-500" />
              <span>Replay Onboarding Guide</span>
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={handleResetData}
            className="w-full py-2.5 px-3 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/40 border border-rose-200/80 dark:border-rose-900/60 text-xs font-semibold text-rose-600 dark:text-rose-400 flex items-center justify-between transition-colors"
          >
            <span>Reset Demo to Defaults</span>
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="text-center pt-2 pb-4">
        <p className="text-[11px] text-slate-400">
          HiBuddy v2.4 · Your life. Your goals. Your buddy.
        </p>
      </div>
    </div>
  );
};
