import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Lock, Mail, Key, User, Sparkles, ShieldCheck, ArrowRight, Zap } from 'lucide-react';
import { playLevelUpSound, playErrorSound } from '../utils/soundEffects';

interface AuthGateProps {
  onAuthenticated: (user: UserProfile) => void;
}

export const AuthGate: React.FC<AuthGateProps> = ({ onAuthenticated }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleFounderQuickFill = () => {
    setEmail('am282773159@gmail.com');
    setPassword('282011##');
    setName('المؤسس السري');
    setIsRegister(false);
    setErrorMsg('');
  };

  const handleGuestQuickStart = () => {
    const guestUser: UserProfile = {
      id: 'guest-' + Date.now().toString(36),
      email: 'guest@waqti.app',
      name: 'بطل الإنجاز ⚡',
      role: 'user',
      avatar: '🦅',
      title: 'شعلة النشاط',
      frame: 'none',
      theme: 'theme-midnight',
      coins: 250,
      xp: 50,
      level: 1,
      streak: 1,
      lastActiveDate: new Date().toISOString().split('T')[0],
      inventory: ['theme-midnight', 'title-energy-flame', 'avatar-falcon'],
      createdAt: new Date().toISOString()
    };
    playLevelUpSound();
    onAuthenticated(guestUser);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email || !password || (isRegister && !name)) {
      setErrorMsg('يرجى ملء جميع الحقول المطلوبة');
      playErrorSound();
      return;
    }

    setLoading(true);

    try {
      const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'حدث خطأ أثناء المصادقة');
      }

      playLevelUpSound();
      onAuthenticated(data.user);
    } catch (err: any) {
      // Offline fallback: if network fails or founder credentials used
      if (email.trim().toLowerCase() === 'am282773159@gmail.com' && password === '282011##') {
        const founderUser: UserProfile = {
          id: 'usr-founder-waqti-01',
          email: 'am282773159@gmail.com',
          name: 'المؤسس (Founder)',
          role: 'founder',
          avatar: '👑',
          title: 'صانع المستحيل',
          frame: 'frame-royal',
          theme: 'theme-royal',
          coins: 5000,
          xp: 3500,
          level: 15,
          streak: 12,
          lastActiveDate: new Date().toISOString().split('T')[0],
          inventory: [
            'title-impossible-maker',
            'title-focus-legend',
            'frame-royal-gold',
            'frame-volcanic-flame',
            'avatar-crown',
            'avatar-dragon',
            'theme-midnight',
            'theme-royal',
            'theme-cyberpunk'
          ],
          createdAt: new Date().toISOString()
        };
        playLevelUpSound();
        onAuthenticated(founderUser);
        return;
      }

      setErrorMsg(err.message || 'فشل الاتصال بالخادم السحابي');
      playErrorSound();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-indigo-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-indigo-950/50">
        
        {/* Glow orb */}
        <div className="absolute -top-12 -left-12 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-40 h-40 bg-pink-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Brand Header */}
        <div className="text-center mb-6 relative">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 shadow-lg shadow-indigo-500/30 mb-3 border border-indigo-400/30">
            <Sparkles className="w-8 h-8 text-white animate-pulse" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-indigo-200 to-purple-300 bg-clip-text text-transparent">
            منصة وقتي
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">
            تطبيق الإنتاجية والجيمفيكيشن الأكثر تطوراً للمنجزين
          </p>

          <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold">
            <Lock className="w-3.5 h-3.5 text-indigo-400" />
            <span>بوابة التسجيل الآمنة (Auth Gate)</span>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex bg-slate-950/60 p-1 rounded-2xl border border-slate-800/80 mb-5">
          <button
            type="button"
            onClick={() => { setIsRegister(false); setErrorMsg(''); }}
            className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all duration-200 ${
              !isRegister
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            type="button"
            onClick={() => { setIsRegister(true); setErrorMsg(''); }}
            className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all duration-200 ${
              isRegister
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            حساب جديد
          </button>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs leading-relaxed text-center font-medium">
            ⚠️ {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 text-right">
                اسم المستخدم / اللقب
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: أحمد صانع الإنجاز"
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 pl-10 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-right"
                />
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 text-right">
              البريد الإلكتروني
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                dir="ltr"
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 pl-10 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-left font-mono"
              />
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 text-right">
              كلمة المرور
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                dir="ltr"
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 pl-10 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-left font-mono"
              />
              <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 cursor-pointer"
          >
            {loading ? (
              <span className="inline-block animate-spin">⏳ جاري التحقق...</span>
            ) : (
              <>
                <span>{isRegister ? 'إنشاء الحساب وبدء الإنجاز' : 'تسجيل الدخول إلى حسابي'}</span>
                <ArrowRight className="w-4 h-4 rotate-180" />
              </>
            )}
          </button>
        </form>

        {/* Quick Guest Start */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 space-y-2.5">
          <button
            type="button"
            onClick={handleGuestQuickStart}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>دخول تجريبي سريع كبطل منجز ⚡</span>
          </button>
        </div>

        {/* Hybrid sync badge */}
        <div className="mt-5 text-center">
          <span className="text-[10px] text-slate-500 inline-flex items-center gap-1 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
            نظام المزامنة السحابية الهجين (Firebase/Local Hybrid) جاهز
          </span>
        </div>

      </div>
    </div>
  );
};
