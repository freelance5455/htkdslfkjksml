import { Image as ImageIcon, Loader2, Music, Wand2 } from "lucide-react";
import { useEffect, useState } from "react";
import { stillFor } from "../lib/preview";
import { createProject } from "../lib/projects";
import { TEMPLATES, getTemplate } from "../lib/templates";
import type { Aspect, Project, SavedDesign } from "../lib/types";
import { pickFile } from "../lib/util";
import { Button, Field, Modal, Segmented, Select, TextInput } from "./ui";

export interface NewDlgState {
  templateId?: string;
  audioFile?: File | null;
  bgFile?: File | null;
  design?: SavedDesign | null;
}

export function NewProjectDialog({ state, onClose, onCreated }: { state: NewDlgState | null; onClose: () => void; onCreated: (p: Project) => void }) {
  const [name, setName] = useState("");
  const [tid, setTid] = useState("circular-1");
  const [aspect, setAspect] = useState<Aspect>("16:9");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [bgFile, setBgFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [thumb, setThumb] = useState<string | null>(null);

  useEffect(() => {
    if (!state) return;
    const t = getTemplate(state.templateId ?? state.design?.templateId ?? "circular-1");
    setTid(t?.id ?? "circular-1");
    setAudioFile(state.audioFile ?? null);
    setBgFile(state.bgFile ?? null);
    setName(state.audioFile ? state.audioFile.name.replace(/\.[^.]+$/, "") : state.design?.name ?? t?.name ?? "Untitled");
    setAspect("16:9");
    setErr("");
    setBusy(false);
  }, [state]);

  useEffect(() => {
    const t = getTemplate(tid);
    if (!state || !t) return;
    setThumb(null);
    stillFor(t).then(setThumb);
  }, [tid, state]);

  if (!state) return null;

  const create = async () => {
    setBusy(true);
    setErr("");
    try {
      const p = await createProject({ name: name.trim() || "Untitled", template: getTemplate(tid) ?? null, aspect, audioFile, bgFile, design: state.design });
      onCreated(p);
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="New project" wide>
      <div className="grid gap-5 sm:grid-cols-[220px_1fr]">
        <div>
          <div className="aspect-video overflow-hidden rounded-xl bg-ink-700">{thumb && <img src={thumb} className="h-full w-full object-cover" alt="" />}</div>
          <p className="mt-2 text-xs text-zinc-500">{state.design ? `Using saved design “${state.design.name}”` : getTemplate(tid)?.description}</p>
        </div>
        <div className="space-y-4">
          <Field label="Project name">
            <TextInput value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </Field>
          {!state.design && (
            <Field label="Template">
              <Select value={tid} onChange={setTid} options={TEMPLATES.map((t) => ({ value: t.id, label: `${t.category} · ${t.name}` }))} />
            </Field>
          )}
          <Field label="Canvas">
            <Segmented
              value={aspect}
              onChange={setAspect}
              options={[
                { value: "16:9", label: "16:9" },
                { value: "9:16", label: "9:16" },
                { value: "1:1", label: "1:1" },
                { value: "4:5", label: "4:5" },
              ]}
            />
          </Field>
          <div className="grid gap-2 sm:grid-cols-2">
            <Button variant="outline" onClick={async () => setAudioFile((await pickFile("audio/*,.mp3,.wav,.m4a,.aac,.flac,.ogg")) ?? audioFile)}>
              <Music size={16} />
              <span className="truncate">{audioFile ? audioFile.name : "Import audio"}</span>
            </Button>
            <Button variant="outline" onClick={async () => setBgFile((await pickFile("image/*,video/*")) ?? bgFile)}>
              <ImageIcon size={16} />
              <span className="truncate">{bgFile ? bgFile.name : "Import background"}</span>
            </Button>
          </div>
          {!audioFile && <p className="text-xs text-zinc-500">No audio selected — the editor will use the built-in synthesized demo track. You can import a song later.</p>}
          {err && <p className="rounded-lg bg-red-500/10 p-3 text-xs text-red-400">{err}</p>}
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" onClick={create} disabled={busy}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
              {busy ? "Importing…" : "Create & open editor"}
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
