import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileCode2, Layout, Gamepad2, FileText, Layers, Sparkles } from "lucide-react";
import type { StudioApi } from "@/hooks/useStudio";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  studio: StudioApi;
}

const TEMPLATES = [
  {
    id: "web",
    label: "HTML + CSS + JS",
    desc: "بنية كاملة: index.html + css + js",
    icon: Layers,
  },
  {
    id: "html",
    label: "صفحة HTML بسيطة",
    desc: "ملف HTML واحد جاهز",
    icon: FileCode2,
  },
  {
    id: "landing",
    label: "صفحة هبوط",
    desc: "تصميم تسويقي متجاوب",
    icon: Layout,
  },
  {
    id: "canvas",
    label: "لعبة Canvas",
    desc: "لعبة تفاعلية بلوحة رسم",
    icon: Gamepad2,
  },
  {
    id: "blank",
    label: "مشروع فارغ",
    desc: "ابدأ من الصفر",
    icon: FileText,
  },
] as const;

export function NewProjectDialog({ open, onOpenChange, studio }: Props) {
  const { createProject } = studio;
  const [selected, setSelected] = useState<string>("web");
  const [projectName, setProjectName] = useState("");

  const handleCreate = async () => {
    await createProject(selected, projectName);
    setProjectName("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-sky-500" />
            مشروع جديد
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-2">
          <Label>اسم المشروع (اختياري)</Label>
          <Input
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            placeholder="مثال: my-app"
          />
        </div>

        <div className="flex flex-col gap-2">
          <Label>القالب</Label>
          {TEMPLATES.map((t) => {
            const Icon = t.icon;
            const active = selected === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelected(t.id)}
                className={cn(
                  "flex items-center gap-3 rounded-lg border p-3 text-start transition-colors",
                  active
                    ? "border-sky-500 bg-sky-50 dark:bg-sky-950/50"
                    : "border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-900"
                )}
              >
                <div
                  className={cn(
                    "rounded-md p-2",
                    active
                      ? "bg-sky-600 text-white"
                      : "bg-slate-100 text-sky-600 dark:bg-slate-800 dark:text-sky-400"
                  )}
                >
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold">{t.label}</p>
                  <p className="text-[11px] text-muted-foreground">{t.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button onClick={handleCreate} className="bg-sky-600 hover:bg-sky-700">
            إنشاء المشروع
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}