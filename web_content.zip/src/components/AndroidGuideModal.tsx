import React, { useState } from 'react';
import { X, Smartphone, Download, Layers, ShieldCheck, Copy, Check, Terminal } from 'lucide-react';

interface AndroidGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidGuideModal: React.FC<AndroidGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'pwa' | 'capacitor' | 'webview'>('capacitor');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const capacitorCommands = `# 1. Install Capacitor CLI and Android platform
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor project
npx cap init "Blame Voice Assistant" com.blame.voice --web-dir dist

# 3. Build web app production bundle
npm run build

# 4. Add the Android platform
npx cap add android

# 5. Open project in Android Studio to build APK
npx cap open android`;

  const androidPermissionsXml = `<!-- Add to android/app/src/main/AndroidManifest.xml -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />`;

  const webViewKotlinSnippet = `// Android Studio WebView Microphone Permission Setup
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Grant microphone access to the app
                request.grant(request.resources)
            }
        }
        webView.loadUrl("https://YOUR_APP_URL")
    }
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">Android Testing & Packaging Guide</h2>
              <p className="text-xs text-slate-500">Run as PWA or export as a native Android APK</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200/60 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 px-6 bg-white gap-2 pt-2">
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'capacitor'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Capacitor APK (Recommended)
          </button>
          <button
            onClick={() => setActiveTab('pwa')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'pwa'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            PWA / Home Screen
          </button>
          <button
            onClick={() => setActiveTab('webview')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'webview'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Native Android WebView
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-700 leading-relaxed">
          {activeTab === 'capacitor' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-2xl flex items-start gap-3">
                <Layers className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div className="text-xs text-indigo-950">
                  <p className="font-semibold text-indigo-900 mb-0.5">Full Native Android APK with Capacitor</p>
                  Capacitor wraps this Vite/React web application into a genuine native Android APK with full microphone hardware access, push notifications, and background voice support.
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-slate-500" /> Step 1: Terminal Commands
                  </span>
                  <button
                    onClick={() => copyText(capacitorCommands, 'cap')}
                    className="inline-flex items-center gap-1 text-[11px] text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedKey === 'cap' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'cap' ? 'Copied' : 'Copy commands'}
                  </button>
                </div>
                <pre className="bg-slate-900 text-slate-100 p-3.5 rounded-xl text-xs font-mono overflow-x-auto">
                  {capacitorCommands}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Step 2: Grant Android Microphone Permissions
                  </span>
                  <button
                    onClick={() => copyText(androidPermissionsXml, 'perm')}
                    className="inline-flex items-center gap-1 text-[11px] text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedKey === 'perm' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'perm' ? 'Copied' : 'Copy XML'}
                  </button>
                </div>
                <pre className="bg-slate-900 text-slate-100 p-3.5 rounded-xl text-xs font-mono overflow-x-auto">
                  {androidPermissionsXml}
                </pre>
              </div>

              <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <strong>Step 3: Generate APK file:</strong> In Android Studio, go to <code>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</code>. The APK will be saved at <code>android/app/build/outputs/apk/debug/app-debug.apk</code> ready to install on your Android device!
              </div>
            </div>
          )}

          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-50/70 border border-emerald-100 rounded-2xl flex items-start gap-3">
                <Download className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-950">
                  <p className="font-semibold text-emerald-900 mb-0.5">Instant Android Test via Chrome PWA</p>
                  No compilation or Android Studio required. You can test the full voice assistant on your Android phone immediately.
                </div>
              </div>

              <ol className="list-decimal list-inside space-y-2.5 text-xs text-slate-700">
                <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <strong>Open URL on Android:</strong> Open Google Chrome on your Android smartphone and navigate to this app's URL.
                </li>
                <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <strong>Add to Home Screen:</strong> Tap Chrome's menu (three dots <code>⋮</code>) and select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.
                </li>
                <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <strong>Grant Microphone Permission:</strong> When prompted, tap <strong>"Allow"</strong> for microphone access. Blame will now run as a standalone, full-screen Android app!
                </li>
              </ol>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                <strong>Play Store TWA (Bubblewrap):</strong> To publish the PWA directly to Google Play Store as an APK, you can use Google's official Bubblewrap CLI: <code>npx @bubblewrap/cli init --manifest=YOUR_APP_URL/manifest.webmanifest</code>.
              </div>
            </div>
          )}

          {activeTab === 'webview' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                If embedding this assistant into an existing Android application using Android Studio WebView, make sure to override <code>WebChromeClient.onPermissionRequest</code> so Android grants the WebView microphone permissions:
              </p>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-800">MainActivity.kt</span>
                  <button
                    onClick={() => copyText(webViewKotlinSnippet, 'kt')}
                    className="inline-flex items-center gap-1 text-[11px] text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedKey === 'kt' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'kt' ? 'Copied' : 'Copy code'}
                  </button>
                </div>
                <pre className="bg-slate-900 text-slate-100 p-3.5 rounded-xl text-xs font-mono overflow-x-auto">
                  {webViewKotlinSnippet}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};
