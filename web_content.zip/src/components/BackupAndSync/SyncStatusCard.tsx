import React, { useState } from 'react';
import { AppSettings, BackupSyncConfig } from '../../types';
import { storage } from '../../utils/storage';
import {
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  HardDrive,
  Calendar,
  ShieldCheck,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface SyncStatusCardProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  isSyncing: boolean;
  onManualSync: () => void;
  statusMessage?: string;
}

export const SyncStatusCard: React.FC<SyncStatusCardProps> = ({
  appSettings,
  onUpdateSettings,
  isSyncing,
  onManualSync,
  statusMessage,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const syncConfig: BackupSyncConfig = appSettings.backupSyncConfig || {
    connected: appSettings.googleDriveConnected || false,
    provider: 'google_drive',
    accountEmail: '',
    folderName: 'TakaTracker_Backups',
    syncInterval: '1h',
    isAutoSyncActive: true,
    lastSyncStatus: 'idle',
  };

  // Get current local dataset counts to compute backup payload size
  const transactions = storage.getTransactions();
  const shoppingItems = storage.getShoppingItems();
  const budgets = storage.getBudgets();

  // Approximate payload size in KB
  const estimatedSizeKb = (
    (JSON.stringify(transactions).length +
      JSON.stringify(shoppingItems).length +
      JSON.stringify(budgets).length) /
    1024
  ).toFixed(1);

  const innerCardBg = isLight ? 'bg-sky-50/70 border-sky-200/80' : 'bg-slate-900/60 border-slate-800';
  const headingText = isLight ? 'text-sky-950' : 'text-slate-100';
  const subText = isLight ? 'text-sky-800/80' : 'text-slate-400';

  const lastSyncTimeDisplay =
    appSettings.googleDriveLastSynced ||
    syncConfig.lastSyncedAt ||
    (syncConfig.connected ? (isEn ? 'Recent' : 'সম্প্রতি') : (isEn ? 'Never' : 'কখনও নয়'));

  return (
    <div className={`p-4 sm:p-5 rounded-2xl border ${innerCardBg} space-y-4 transition-all`}>
      {/* Header of Sync Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div
            className="p-2 rounded-xl"
            style={{
              backgroundColor: `${dualAccent.primary.hex}20`,
              color: dualAccent.primary.hex,
            }}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
          </div>
          <div>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText} flex items-center gap-1.5`}>
              <span>{isEn ? 'Sync Status & Cloud State' : 'সিঙ্ক স্ট্যাটাস (Sync Status)'}</span>
            </h3>
            <p className={`text-[11px] ${subText}`}>
              {isEn
                ? 'Monitor synchronization progress and cloud backup integrity'
                : 'ক্লাউড ব্যাকআপ সিঙ্ক্রোনাইজেশনের অগ্রগতি ও তথ্যের স্থিতি দেখুন'}
            </p>
          </div>
        </div>

        {/* Sync Now Action Button */}
        <button
          type="button"
          onClick={onManualSync}
          disabled={isSyncing}
          style={{ backgroundColor: dualAccent.secondary.hex }}
          className="w-full sm:w-auto px-4 py-2 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 disabled:opacity-50 active:scale-98 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>
            {isSyncing
              ? isEn
                ? 'Syncing Now...'
                : 'সিঙ্ক হচ্ছে...'
              : isEn
              ? 'Sync Now'
              : 'এখনই সিঙ্ক করুন'}
          </span>
        </button>
      </div>

      {/* Main Status Display Banner - Cloud Connection Card */}
      <div
        className={`p-3.5 sm:p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
          isLight ? 'bg-white border-sky-200' : 'bg-slate-800/80 border-slate-700'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold border shrink-0 ${
              syncConfig.connected
                ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-500 border-amber-500/30'
            }`}
          >
            {syncConfig.connected ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          </div>
          <div className="min-w-0">
            <p className={`text-xs font-bold ${headingText} flex items-center gap-1.5 flex-wrap`}>
              <span>{isEn ? 'Cloud Connection:' : 'ক্লাউড সংযোগ:'}</span>
              {syncConfig.connected ? (
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  {isEn ? 'Connected & Operational' : 'সংযুক্ত ও সক্রিয়'}
                </span>
              ) : (
                <span className="text-amber-600 dark:text-amber-400 font-bold">
                  {isEn ? 'No Drive Connected' : 'ড্রাইভ যুক্ত করা নেই'}
                </span>
              )}
            </p>
            <p className={`text-[11px] ${subText} flex items-center gap-1.5 mt-0.5`}>
              <Calendar className="w-3 h-3 text-indigo-400 shrink-0" />
              <span>
                {isEn ? 'Last Cloud Sync: ' : 'সর্বশেষ ক্লাউড সিঙ্ক: '}
                <strong className={isLight ? 'text-sky-950' : 'text-slate-200'}>
                  {lastSyncTimeDisplay}
                </strong>
              </span>
            </p>
          </div>
        </div>

        {/* Cloud Connection Badges: Backup Size & Encryption side by side */}
        <div className="flex items-center gap-2 flex-nowrap shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-sky-800 dark:text-sky-200 bg-sky-500/10 px-2.5 sm:px-3 py-1.5 rounded-xl border border-sky-500/20 whitespace-nowrap">
            <HardDrive className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>{isEn ? 'Backup Size:' : 'ব্যাকআপ সাইজ:'}</span>
            <span className="font-black text-indigo-600 dark:text-indigo-400">~{estimatedSizeKb} KB</span>
          </div>

          <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1.5 rounded-xl border border-emerald-500/20 whitespace-nowrap shrink-0">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            <span>{isEn ? 'Encrypted' : 'এনক্রিপ্টেড'}</span>
          </div>
        </div>
      </div>

      {/* Live sync message feedback */}
      {statusMessage && (
        <div
          className={`p-3 rounded-xl border text-xs font-semibold flex items-center gap-2 ${
            isLight
              ? 'bg-sky-100 text-sky-950 border-sky-300'
              : 'bg-cyan-950/40 text-cyan-200 border-cyan-800/60'
          }`}
        >
          <FileCheck className="w-4 h-4 shrink-0 text-cyan-500" />
          <span>{statusMessage}</span>
        </div>
      )}
    </div>
  );
};
