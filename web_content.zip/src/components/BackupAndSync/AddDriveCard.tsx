import React, { useState } from 'react';
import { AppSettings, BackupSyncConfig, CloudDriveProvider } from '../../types';
import {
  Cloud,
  CheckCircle2,
  AlertCircle,
  Link2,
  Unlink,
  ShieldCheck,
  Mail,
  Folder,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface AddDriveCardProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onTriggerSync?: () => void;
}

export const AddDriveCard: React.FC<AddDriveCardProps> = ({
  appSettings,
  onUpdateSettings,
  onTriggerSync,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const syncConfig: BackupSyncConfig = appSettings.backupSyncConfig || {
    connected: appSettings.googleDriveConnected || false,
    provider: 'google_drive',
    accountEmail: '',
    folderName: 'TakaTracker_Backups',
    syncInterval: '1h',
    isAutoSyncActive: true,
    lastSyncStatus: 'idle',
  };

  const [selectedProvider, setSelectedProvider] = useState<CloudDriveProvider | null>(null);
  const [emailInput, setEmailInput] = useState(syncConfig.accountEmail || '');
  const [folderInput, setFolderInput] = useState(syncConfig.folderName || 'TakaTracker_Backups');
  const [isConnecting, setIsConnecting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const providers: { id: CloudDriveProvider; name: string; iconLabel: string; color: string }[] = [
    { id: 'google_drive', name: 'Google Drive', iconLabel: 'G', color: '#4285F4' },
    { id: 'onedrive', name: 'Microsoft OneDrive', iconLabel: 'M', color: '#0078D4' },
    { id: 'dropbox', name: 'Dropbox', iconLabel: 'D', color: '#0061FF' },
    { id: 'custom', name: isEn ? 'Custom WebDAV' : 'কাস্টম ক্লাউড', iconLabel: 'C', color: '#10B981' },
  ];

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProvider) {
      setErrorMsg(isEn ? 'Please select a cloud storage provider first.' : 'দয়া করে প্রথমে একটি ক্লাউড স্টোরেজ সিলেক্ট করুন।');
      return;
    }
    setErrorMsg('');
    setSuccessMsg('');

    const targetEmail = emailInput.trim() || (selectedProvider === 'google_drive' ? 'myaccount@gmail.com' : 'user@cloud.com');

    setIsConnecting(true);
    setTimeout(() => {
      setIsConnecting(false);
      const updatedConfig: BackupSyncConfig = {
        ...syncConfig,
        connected: true,
        provider: selectedProvider,
        accountEmail: targetEmail,
        folderName: folderInput.trim() || 'TakaTracker_Backups',
        lastSyncStatus: 'success',
        lastStatusMessage: isEn ? 'Drive linked successfully' : 'ড্রাইভ সফলভাবে যুক্ত হয়েছে',
      };

      onUpdateSettings({
        ...appSettings,
        googleDriveConnected: true,
        backupSyncConfig: updatedConfig,
      });

      setSuccessMsg(
        isEn
          ? `${selectedProvider === 'google_drive' ? 'Google Drive' : selectedProvider} account (${targetEmail}) connected successfully!`
          : `${selectedProvider === 'google_drive' ? 'গুগল ড্রাইভ' : selectedProvider} অ্যাকাউন্ট (${targetEmail}) সফলভাবে যুক্ত করা হয়েছে!`
      );

      if (onTriggerSync) {
        onTriggerSync();
      }
    }, 900);
  };

  const handleDisconnect = () => {
    const updatedConfig: BackupSyncConfig = {
      ...syncConfig,
      connected: false,
      accountEmail: '',
      lastSyncStatus: 'idle',
      lastStatusMessage: isEn ? 'Disconnected' : 'বিচ্ছিন্ন করা হয়েছে',
    };

    onUpdateSettings({
      ...appSettings,
      googleDriveConnected: false,
      backupSyncConfig: updatedConfig,
    });

    setSelectedProvider(null);
    setEmailInput('');
    setSuccessMsg(isEn ? 'Drive account disconnected.' : 'ড্রাইভ অ্যাকাউন্ট বিচ্ছিন্ন করা হয়েছে।');
    setErrorMsg('');
  };

  const innerCardBg = isLight ? 'bg-sky-50/70 border-sky-200/80' : 'bg-slate-900/60 border-slate-800';
  const headingText = isLight ? 'text-sky-950' : 'text-slate-100';
  const subText = isLight ? 'text-sky-800/80' : 'text-slate-400';

  return (
    <div className={`p-4 sm:p-5 rounded-2xl border ${innerCardBg} space-y-4 transition-all`}>
      {/* Header of Add Drive */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="p-2 rounded-xl"
            style={{
              backgroundColor: `${dualAccent.primary.hex}20`,
              color: dualAccent.primary.hex,
            }}
          >
            <Cloud className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText} flex items-center gap-1.5`}>
              <span>{isEn ? 'Add Drive & Account' : 'ড্রাইভ যুক্ত করুন (Add Drive)'}</span>
            </h3>
            <p className={`text-[11px] ${subText}`}>
              {isEn
                ? 'Link your cloud storage to enable automated encrypted backups'
                : 'এনক্রিপ্টেড অটো ব্যাকআপ সক্রিয় রাখতে আপনার ক্লাউড ড্রাইভ যুক্ত করুন'}
            </p>
          </div>
        </div>

        {/* Connection Pill */}
        <div>
          {syncConfig.connected ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
              <CheckCircle2 className="w-3 h-3" />
              <span>{isEn ? 'Linked' : 'সংযুক্ত'}</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
              <AlertCircle className="w-3 h-3" />
              <span>{isEn ? 'Not Linked' : 'যুক্ত নয়'}</span>
            </span>
          )}
        </div>
      </div>

      {/* If Already Connected View */}
      {syncConfig.connected ? (
        <div className="space-y-3 pt-1">
          <div
            className={`p-3.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
              isLight ? 'bg-white border-sky-200' : 'bg-slate-800/80 border-slate-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-500 font-black flex items-center justify-center text-sm border border-blue-500/30">
                {syncConfig.provider === 'google_drive'
                  ? 'G'
                  : syncConfig.provider === 'onedrive'
                  ? 'M'
                  : 'C'}
              </div>
              <div>
                <p className={`text-xs font-bold ${headingText} flex items-center gap-1.5`}>
                  <span>
                    {syncConfig.provider === 'google_drive'
                      ? 'Google Drive'
                      : syncConfig.provider === 'onedrive'
                      ? 'Microsoft OneDrive'
                      : syncConfig.provider === 'dropbox'
                      ? 'Dropbox'
                      : 'Cloud Storage'}
                  </span>
                  <span className="text-[10px] text-emerald-500 font-semibold flex items-center gap-0.5">
                    <ShieldCheck className="w-3 h-3" /> E2EE
                  </span>
                </p>
                <p className={`text-[11px] font-medium ${subText} flex items-center gap-1`}>
                  <Mail className="w-3 h-3" />
                  <span>{syncConfig.accountEmail || 'Connected Account'}</span>
                </p>
                <p className={`text-[10px] ${subText} flex items-center gap-1 mt-0.5`}>
                  <Folder className="w-3 h-3 text-amber-500" />
                  <span>/{syncConfig.folderName || 'TakaTracker_Backups'}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={handleDisconnect}
                className="text-xs font-bold px-3 py-1.5 rounded-xl text-rose-500 hover:text-rose-600 hover:bg-rose-500/10 transition border border-rose-500/20 flex items-center gap-1 cursor-pointer"
              >
                <Unlink className="w-3.5 h-3.5" />
                <span>{isEn ? 'Disconnect' : 'বিচ্ছিন্ন করুন'}</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Connect Form View */
        <form onSubmit={handleConnect} className="space-y-3.5">
          {/* Provider Selection */}
          <div>
            <label className={`block text-[11px] font-bold mb-1.5 ${headingText}`}>
              {isEn ? 'Select Cloud Storage Provider:' : 'ক্লাউড স্টোরেজ নির্বাচন করুন:'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {providers.map((p) => {
                const isSelected = selectedProvider === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedProvider((prev) => (prev === p.id ? null : p.id))}
                    className={`py-2 px-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                      isSelected
                        ? isLight
                          ? 'bg-white border-blue-500 text-blue-700 shadow-xs ring-2 ring-blue-500/20'
                          : 'bg-slate-800 border-blue-400 text-white shadow-xs ring-2 ring-blue-400/20'
                        : isLight
                        ? 'bg-white/60 border-sky-200 text-slate-700 hover:bg-white'
                        : 'bg-slate-900/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-lg flex items-center justify-center text-[10px] font-black text-white shrink-0"
                      style={{ backgroundColor: p.color }}
                    >
                      {p.iconLabel}
                    </span>
                    <span className="truncate">{p.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Account Email, Folder Name & Connect Button - Shown ONLY after selecting a provider */}
          {selectedProvider && (
            <div className="space-y-3.5 pt-1 animate-in fade-in slide-in-from-top-1 duration-200">
              {/* Account Email Input & Folder Name Input */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={`block text-[11px] font-bold mb-1 ${headingText}`}>
                    {isEn ? 'Account Email / ID:' : 'ড্রাইভ অ্যাকাউন্ট ইমেইল:'}
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder={selectedProvider === 'google_drive' ? 'example@gmail.com' : 'user@cloud.com'}
                      className={`w-full pl-8 pr-3 py-2 border rounded-xl text-xs font-medium focus:outline-none ${
                        isLight
                          ? 'bg-white border-sky-200 text-sky-950 focus:border-indigo-500'
                          : 'bg-slate-900 border-slate-700 text-white focus:border-indigo-500'
                      }`}
                    />
                    <Mail className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  </div>
                </div>

                {/* Folder Name Input */}
                <div>
                  <label className={`block text-[11px] font-bold mb-1 ${headingText}`}>
                    {isEn ? 'Destination Folder Name:' : 'ড্রাইভ ফোল্ডারের নাম:'}
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={folderInput}
                      onChange={(e) => setFolderInput(e.target.value)}
                      placeholder="TakaTracker_Backups"
                      className={`w-full pl-8 pr-3 py-2 border rounded-xl text-xs font-medium focus:outline-none ${
                        isLight
                          ? 'bg-white border-sky-200 text-sky-950 focus:border-indigo-500'
                          : 'bg-slate-900 border-slate-700 text-white focus:border-indigo-500'
                      }`}
                    />
                    <Folder className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  </div>
                </div>
              </div>

              {/* Quick preset hint */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-0.5">
                <span className={subText}>{isEn ? 'Quick presets:' : 'দ্রুত সংযোগ:'}</span>
                <button
                  type="button"
                  onClick={() => setEmailInput('excelbdtech@gmail.com')}
                  className={`px-2 py-0.5 rounded-lg border text-[10px] font-semibold transition ${
                    isLight ? 'bg-white border-sky-200 text-sky-800' : 'bg-slate-800 border-slate-700 text-slate-300'
                  }`}
                >
                  excelbdtech@gmail.com
                </button>
              </div>

              {/* Submit Link Button */}
              <button
                type="submit"
                disabled={isConnecting}
                style={dualAccent.primaryButtonStyle}
                className="w-full py-2.5 text-white font-bold rounded-xl text-xs transition shadow-sm active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <Link2 className="w-4 h-4" />
                <span>
                  {isConnecting
                    ? isEn
                      ? 'Connecting Drive...'
                      : 'ড্রাইভ যুক্ত করা হচ্ছে...'
                    : isEn
                    ? `Connect & Authorize ${selectedProvider === 'google_drive' ? 'Google Drive' : selectedProvider}`
                    : `${selectedProvider === 'google_drive' ? 'গুগল ড্রাইভ' : selectedProvider} যুক্ত করুন`}
                </span>
              </button>
            </div>
          )}
        </form>
      )}

      {/* Messages */}
      {successMsg && (
        <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </p>
      )}
      {errorMsg && (
        <p className="text-xs font-semibold text-rose-500 flex items-center gap-1.5 p-2 rounded-xl bg-rose-500/10 border border-rose-500/20">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </p>
      )}
    </div>
  );
};
