import React, { useState } from 'react';
import { AppSettings, BackupSyncConfig } from '../../types';
import { AddDriveCard } from './AddDriveCard';
import { SyncStatusCard } from './SyncStatusCard';
import { SyncTimerCard } from './SyncTimerCard';
import {
  Cloud,
  FolderSync,
  RefreshCw,
  PlusCircle,
  Activity,
  Clock,
  CheckCircle2,
  Layers,
  Maximize2,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface BackupAndSyncSectionProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  isSyncingDrive: boolean;
  syncStatusMsg: string;
  onTriggerSync: () => void;
  onOpenInPopup?: () => void;
  isPopupView?: boolean;
}

export type BackupSyncTab = 'all' | 'add_drive' | 'sync_status' | 'sync_timer';

export const BackupAndSyncSection: React.FC<BackupAndSyncSectionProps> = ({
  appSettings,
  onUpdateSettings,
  isSyncingDrive,
  syncStatusMsg,
  onTriggerSync,
  onOpenInPopup,
  isPopupView = false,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const [activeTab, setActiveTab] = useState<BackupSyncTab>('all');

  const cardBg = isLight
    ? 'bg-white/95 border-sky-200 shadow-sm'
    : 'bg-slate-800/90 border-slate-700/70 shadow-md';
  const headingText = isLight ? 'text-sky-950' : 'text-slate-100';
  const subText = isLight ? 'text-sky-800/80' : 'text-slate-400';

  const isConnected =
    appSettings.backupSyncConfig?.connected || appSettings.googleDriveConnected;

  return (
    <div
      className={`${isPopupView ? '' : `${cardBg} border rounded-3xl p-5`} space-y-4 transition-all`}
      id="backup-and-sync-section"
    >
      {/* Section Header */}
      {!isPopupView ? (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div
              className="p-2.5 rounded-2xl shadow-sm"
              style={{
                backgroundColor: `${dualAccent.primary.hex}20`,
                color: dualAccent.primary.hex,
              }}
            >
              <FolderSync className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className={`text-base font-black tracking-tight ${headingText}`}>
                  {isEn ? 'Cloud & Sync' : 'ক্লাউড ও সিঙ্ক (Cloud & Sync)'}
                </h2>
                {isConnected ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{isEn ? 'Connected' : 'সংযুক্ত'}</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                    {isEn ? 'Drive Not Linked' : 'ড্রাইভ যুক্ত নয়'}
                  </span>
                )}
              </div>
              <p className={`text-[11px] ${subText}`}>
                {isEn
                  ? 'Manage cloud storage accounts, view sync health, and configure sync timers'
                  : 'ক্লাউড ড্রাইভ যুক্ত করুন, সিঙ্ক স্ট্যাটাস দেখুন এবং ব্যাকআপ টাইমার শিডিউল নির্ধারণ করুন'}
              </p>
            </div>
          </div>

          {/* Action Buttons in Header */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {onOpenInPopup && (
              <button
                type="button"
                onClick={onOpenInPopup}
                className={`px-3 py-2 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  isLight
                    ? 'bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-900'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                }`}
                title={isEn ? 'Open in Popup Modal' : 'পপআপে খুলুন'}
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{isEn ? 'Open Popup' : 'পপআপ ভিউ'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onTriggerSync}
              disabled={isSyncingDrive}
              style={{ backgroundColor: dualAccent.secondary.hex }}
              className="w-full sm:w-auto px-4 py-2 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-1.5 disabled:opacity-50 active:scale-95 cursor-pointer shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingDrive ? 'animate-spin' : ''}`} />
              <span>
                {isSyncingDrive
                  ? isEn
                    ? 'Syncing...'
                    : 'সিঙ্ক হচ্ছে...'
                  : isEn
                  ? 'Sync Now'
                  : 'এখনই সিঙ্ক করুন'}
              </span>
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between pb-1 border-b border-black/5 dark:border-white/5">
          <div className="flex items-center gap-2">
            {isConnected ? (
              <span className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{isEn ? 'Google Drive Connected' : 'গুগল ড্রাইভ সংযুক্ত'}</span>
              </span>
            ) : (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                {isEn ? 'Drive Not Linked' : 'ড্রাইভ যুক্ত নয়'}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onTriggerSync}
            disabled={isSyncingDrive}
            style={{ backgroundColor: dualAccent.secondary.hex }}
            className="px-4 py-1.5 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-1.5 disabled:opacity-50 active:scale-95 cursor-pointer shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingDrive ? 'animate-spin' : ''}`} />
            <span>
              {isSyncingDrive
                ? isEn
                  ? 'Syncing...'
                  : 'সিঙ্ক হচ্ছে...'
                : isEn
                ? 'Sync Now'
                : 'এখনই সিঙ্ক করুন'}
            </span>
          </button>
        </div>
      )}

      {/* Sub-Navigation Tabs: All | Add Drive | Sync Status | Sync Timer */}
      <div
        className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-2xl border transition-colors"
        style={{
          backgroundColor: isLight
            ? `color-mix(in srgb, ${dualAccent.primary.hex} 10%, #ffffff)`
            : `color-mix(in srgb, ${dualAccent.primary.hex} 12%, #0f172a)`,
          borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 25%, transparent)`,
        }}
      >
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          id="backup-tab-all"
          style={
            activeTab === 'all'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2 px-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'all'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-3.5 h-3.5" style={{ color: activeTab === 'all' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'Overview (All)' : 'সকল অপশন (All)'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('add_drive')}
          id="backup-tab-add-drive"
          style={
            activeTab === 'add_drive'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2 px-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'add_drive'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <PlusCircle className={`w-3.5 h-3.5 ${activeTab === 'add_drive' ? 'text-white' : ''}`} style={{ color: activeTab === 'add_drive' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'Add Drive' : 'Add Drive'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sync_status')}
          id="backup-tab-sync-status"
          style={
            activeTab === 'sync_status'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2 px-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'sync_status'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Activity className={`w-3.5 h-3.5 ${activeTab === 'sync_status' ? 'text-white' : ''}`} style={{ color: activeTab === 'sync_status' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'Sync Status' : 'Sync Status'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sync_timer')}
          id="backup-tab-sync-timer"
          style={
            activeTab === 'sync_timer'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2 px-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'sync_timer'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Clock className={`w-3.5 h-3.5 ${activeTab === 'sync_timer' ? 'text-white' : ''}`} style={{ color: activeTab === 'sync_timer' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'Sync Timer' : 'Sync Timer'}</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="space-y-4">
        {/* Add Drive Panel */}
        {(activeTab === 'all' || activeTab === 'add_drive') && (
          <AddDriveCard
            appSettings={appSettings}
            onUpdateSettings={onUpdateSettings}
            onTriggerSync={onTriggerSync}
          />
        )}

        {/* Sync Status Panel */}
        {(activeTab === 'all' || activeTab === 'sync_status') && (
          <SyncStatusCard
            appSettings={appSettings}
            onUpdateSettings={onUpdateSettings}
            isSyncing={isSyncingDrive}
            onManualSync={onTriggerSync}
            statusMessage={syncStatusMsg}
          />
        )}

        {/* Sync Timer Panel */}
        {(activeTab === 'all' || activeTab === 'sync_timer') && (
          <SyncTimerCard
            appSettings={appSettings}
            onUpdateSettings={onUpdateSettings}
          />
        )}
      </div>
    </div>
  );
};
