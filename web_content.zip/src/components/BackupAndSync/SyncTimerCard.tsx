import React, { useState, useEffect, useRef } from 'react';
import { AppSettings, BackupSyncConfig, SyncTimerInterval } from '../../types';
import {
  Clock,
  Zap,
  Wifi,
  ChevronDown,
  Check,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface SyncTimerCardProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
}

export const SyncTimerCard: React.FC<SyncTimerCardProps> = ({
  appSettings,
  onUpdateSettings,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const syncConfig: BackupSyncConfig = appSettings.backupSyncConfig || {
    connected: appSettings.googleDriveConnected || false,
    provider: 'google_drive',
    accountEmail: '',
    folderName: 'TakaTracker_Backups',
    syncInterval: '1h',
    isAutoSyncActive: true,
    lastSyncStatus: 'idle',
    wifiOnly: false,
  };

  const [activeInterval, setActiveInterval] = useState<SyncTimerInterval>(
    syncConfig.syncInterval || '1h'
  );
  const [isAutoSync, setIsAutoSync] = useState<boolean>(
    syncConfig.isAutoSyncActive !== undefined ? syncConfig.isAutoSyncActive : true
  );
  const [wifiOnly, setWifiOnly] = useState<boolean>(syncConfig.wifiOnly || false);
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleIntervalChange = (interval: SyncTimerInterval) => {
    setActiveInterval(interval);
    const updated: BackupSyncConfig = {
      ...syncConfig,
      syncInterval: interval,
      isAutoSyncActive: interval !== 'manual',
    };
    onUpdateSettings({
      ...appSettings,
      backupSyncConfig: updated,
    });
  };

  const handleAutoSyncToggle = (checked: boolean) => {
    setIsAutoSync(checked);
    const updated: BackupSyncConfig = {
      ...syncConfig,
      isAutoSyncActive: checked,
    };
    onUpdateSettings({
      ...appSettings,
      backupSyncConfig: updated,
    });
  };

  const handleWifiToggle = (checked: boolean) => {
    setWifiOnly(checked);
    const updated: BackupSyncConfig = {
      ...syncConfig,
      wifiOnly: checked,
    };
    onUpdateSettings({
      ...appSettings,
      backupSyncConfig: updated,
    });
  };

  const intervals: {
    id: SyncTimerInterval;
    label: string;
    desc: string;
    badge?: string;
  }[] = [
    {
      id: 'realtime',
      label: isEn ? 'Real-time (Instant)' : 'রিয়েলটাইম (তাৎক্ষণিক)',
      desc: isEn
        ? 'Sync immediately whenever data is updated'
        : 'প্রতিটি লেনদেন এন্ট্রি বা পরিবর্তনের সাথে সাথে সিঙ্ক',
      badge: 'Live',
    },
    {
      id: '15m',
      label: isEn ? 'Every 15 Minutes' : 'প্রতি ১৫ মিনিট পর',
      desc: isEn ? 'High frequency periodic sync' : 'স্বল্প সময়ে ঘন ঘন ক্লাউড ব্যাকআপ',
    },
    {
      id: '1h',
      label: isEn ? 'Every 1 Hour' : 'প্রতি ১ ঘণ্টা পর (ডিফল্ট)',
      desc: isEn ? 'Balanced background synchronization' : 'নিয়মিত নির্ভরযোগ্য অটোমেটিক সিঙ্ক',
      badge: 'Recommended',
    },
    {
      id: '6h',
      label: isEn ? 'Every 6 Hours' : 'প্রতি ৬ ঘণ্টা পর',
      desc: isEn ? 'Conserves device battery and bandwidth' : 'ব্যাটারি ও ইন্টারনেট ডাটা সাশ্রয়ী',
    },
    {
      id: 'daily',
      label: isEn ? 'Daily (Once a day)' : 'দৈনিক একবার',
      desc: isEn ? 'Runs nightly automated backup' : 'প্রতিদিন রাতে একবার ফুল ব্যাকআপ',
    },
    {
      id: 'manual',
      label: isEn ? 'Manual Only' : 'শুধুমাত্র ম্যানুয়াল',
      desc: isEn ? 'Only syncs when Sync Now button is pressed' : 'বাটন চাপলেই কেবল সিঙ্ক হবে',
    },
  ];

  const innerCardBg = isLight ? 'bg-sky-50/70 border-sky-200/80' : 'bg-slate-900/60 border-slate-800';
  const headingText = isLight ? 'text-sky-950' : 'text-slate-100';
  const subText = isLight ? 'text-sky-800/80' : 'text-slate-400';

  const selectedIntervalItem =
    intervals.find((item) => item.id === activeInterval) || intervals[2];

  return (
    <div className={`p-4 sm:p-5 rounded-2xl border ${innerCardBg} space-y-4 transition-all`}>
      {/* Header of Sync Timer */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="p-2 rounded-xl"
            style={{
              backgroundColor: `${dualAccent.primary.hex}20`,
              color: dualAccent.primary.hex,
            }}
          >
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText} flex items-center gap-1.5`}>
              <span>{isEn ? 'Sync Timer & Interval' : 'সিঙ্ক টাইমার (Sync Timer)'}</span>
            </h3>
            <p className={`text-[11px] ${subText}`}>
              {isEn
                ? 'Configure automated background synchronization intervals'
                : 'স্বয়ংক্রিয় ক্লাউড সিঙ্কের সময়সীমা ও শিডিউল নির্ধারণ করুন'}
            </p>
          </div>
        </div>

        {/* Master Auto-Sync Toggle Switch */}
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <span className={`text-[11px] font-bold ${headingText}`}>
            {isAutoSync ? (isEn ? 'Auto-Sync ON' : 'অটো-সিঙ্ক চালু') : (isEn ? 'Auto-Sync OFF' : 'বন্ধ')}
          </span>
          <div className="relative">
            <input
              type="checkbox"
              checked={isAutoSync}
              onChange={(e) => handleAutoSyncToggle(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-400 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
          </div>
        </label>
      </div>

      {/* Sync Interval Dropdown Selector */}
      <div className="space-y-2 relative" ref={dropdownRef} id="sync-frequency-dropdown-container">
        <label
          htmlFor="sync-frequency-trigger-btn"
          className={`block text-[11px] font-bold ${headingText}`}
        >
          {isEn ? 'Choose Synchronization Frequency:' : 'সিঙ্ক করার ফ্রিকোয়েন্সি নির্বাচন করুন:'}
        </label>

        {/* Dropdown Trigger Box */}
        <button
          type="button"
          id="sync-frequency-trigger-btn"
          aria-haspopup="listbox"
          aria-expanded={isDropdownOpen}
          onClick={() => setIsDropdownOpen((prev) => !prev)}
          className={`w-full p-3 rounded-xl border text-left transition flex items-center justify-between gap-3 cursor-pointer shadow-xs ${
            isDropdownOpen
              ? isLight
                ? 'bg-white border-indigo-500 ring-2 ring-indigo-500/20'
                : 'bg-slate-800 border-indigo-400 ring-2 ring-indigo-400/20'
              : isLight
              ? 'bg-white/90 hover:bg-white border-sky-200 text-sky-950'
              : 'bg-slate-900/90 hover:bg-slate-850 border-slate-700 text-slate-100'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                selectedIntervalItem.id === 'realtime'
                  ? 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                  : 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20'
              }`}
            >
              {selectedIntervalItem.id === 'realtime' ? (
                <Zap className="w-4 h-4" />
              ) : (
                <Clock className="w-4 h-4" />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                  {selectedIntervalItem.label}
                </span>
                {selectedIntervalItem.badge && (
                  <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-500 border border-indigo-500/30 shrink-0">
                    {selectedIntervalItem.badge}
                  </span>
                )}
              </div>
              <p className={`text-[10px] ${subText} truncate mt-0.5`}>
                {selectedIntervalItem.desc}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 text-slate-400">
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-200 ${
                isDropdownOpen ? 'rotate-180 text-indigo-500' : ''
              }`}
            />
          </div>
        </button>

        {/* Dropdown Menu Options */}
        {isDropdownOpen && (
          <div
            className={`absolute z-30 top-full left-0 right-0 mt-1.5 p-1.5 rounded-2xl border shadow-xl backdrop-blur-md transition-all max-h-72 overflow-y-auto space-y-1 ${
              isLight
                ? 'bg-white/95 border-sky-200 shadow-sky-900/10'
                : 'bg-slate-900/95 border-slate-700 shadow-black/40'
            }`}
            role="listbox"
            id="sync-frequency-options-list"
          >
            {intervals.map((item) => {
              const isSelected = activeInterval === item.id;
              return (
                <button
                  key={item.id}
                  id={`sync-option-${item.id}`}
                  type="button"
                  role="option"
                  aria-selected={isSelected}
                  onClick={() => {
                    handleIntervalChange(item.id);
                    setIsDropdownOpen(false);
                  }}
                  className={`w-full p-2.5 rounded-xl text-left transition flex items-center justify-between gap-2.5 cursor-pointer ${
                    isSelected
                      ? isLight
                        ? 'bg-indigo-50 border border-indigo-200/80 text-indigo-950 font-semibold'
                        : 'bg-indigo-950/60 border border-indigo-500/30 text-indigo-100 font-semibold'
                      : isLight
                      ? 'hover:bg-slate-100/90 text-slate-700 border border-transparent'
                      : 'hover:bg-slate-800/80 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold truncate">{item.label}</span>
                      {item.badge && (
                        <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-indigo-500/15 text-indigo-500 border border-indigo-500/30">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    <p className={`text-[10px] ${subText} truncate`}>{item.desc}</p>
                  </div>

                  <div className="shrink-0 ml-2">
                    {isSelected ? (
                      <div className="w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    ) : (
                      <div className="w-5 h-5 rounded-full border border-slate-300 dark:border-slate-600" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Advanced Sync Options: Wi-Fi Only & History */}
      <div className={`p-3 rounded-xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 space-y-2.5`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-sky-500" />
            <div>
              <p className={`text-xs font-bold ${headingText}`}>
                {isEn ? 'Sync on Wi-Fi Only' : 'শুধুমাত্র ওয়াইফাই (Wi-Fi) তে সিঙ্ক'}
              </p>
              <p className={`text-[10px] ${subText}`}>
                {isEn
                  ? 'Avoid using mobile cellular data for cloud synchronization'
                  : 'মোবাইল ডাটা খরচ বাঁচাতে কেবল ওয়াইফাই সংযুক্ত থাকলে ব্যাকআপ হবে'}
              </p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={wifiOnly}
            onChange={(e) => handleWifiToggle(e.target.checked)}
            className="w-4 h-4 accent-indigo-500 rounded cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
