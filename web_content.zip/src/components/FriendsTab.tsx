import React, { useEffect, useState } from 'react';
import {
  addDoc,
  arrayUnion,
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Ban,
  Check,
  Flag,
  MessageCircle,
  Phone,
  Search,
  UserPlus,
  Video,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { deterministicPairId } from '../lib/mediaUtils';
import type { FriendRequestItem, FriendshipItem, LanguageCode, UserProfile } from '../types';

interface FriendsTabProps {
  profile: UserProfile;
  language: LanguageCode;
  onlineUids: string[];
  onStartChat: (peer: UserProfile) => void;
  onStartCall: (peer: UserProfile, callType: 'voice' | 'video') => void;
}

export const FriendsTab: React.FC<FriendsTabProps> = ({
  profile,
  language,
  onlineUids,
  onStartChat,
  onStartCall,
}) => {
  const t = TRANSLATIONS[language];
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<FriendRequestItem[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<FriendRequestItem[]>([]);
  const [friendships, setFriendships] = useState<FriendshipItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        setUsers(snap.docs.map((d) => d.data() as UserProfile).filter((u) => u.uid !== profile.uid));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );

    const unsubIn = onSnapshot(
      query(collection(db, 'friendRequests'), where('toUid', '==', profile.uid)),
      (snap) => {
        setIncomingRequests(
          snap.docs
            .map((d) => ({ id: d.id, ...(d.data() as Omit<FriendRequestItem, 'id'>) }))
            .filter((r) => r.status === 'pending')
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendRequests')
    );

    const unsubOut = onSnapshot(
      query(collection(db, 'friendRequests'), where('fromUid', '==', profile.uid)),
      (snap) => {
        setOutgoingRequests(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<FriendRequestItem, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendRequests')
    );

    const unsubFriendsA = onSnapshot(
      query(collection(db, 'friendships'), where('userA', '==', profile.uid)),
      (snap) => {
        const listA = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<FriendshipItem, 'id'>) }));
        setFriendships((prev) => {
          const onlyB = prev.filter((f) => f.userB === profile.uid);
          return [...listA, ...onlyB];
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendships')
    );

    const unsubFriendsB = onSnapshot(
      query(collection(db, 'friendships'), where('userB', '==', profile.uid)),
      (snap) => {
        const listB = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<FriendshipItem, 'id'>) }));
        setFriendships((prev) => {
          const onlyA = prev.filter((f) => f.userA === profile.uid);
          return [...onlyA, ...listB];
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendships')
    );

    return () => {
      unsubUsers();
      unsubIn();
      unsubOut();
      unsubFriendsA();
      unsubFriendsB();
    };
  }, [profile.uid]);

  const friendUidSet = new Set(
    friendships.map((f) => (f.userA === profile.uid ? f.userB : f.userA))
  );

  const handleSendRequest = async (peer: UserProfile) => {
    const reqId = `${profile.uid}__${peer.uid}`;
    try {
      await setDoc(doc(db, 'friendRequests', reqId), {
        fromUid: profile.uid,
        fromName: profile.fullName,
        fromPhoto: profile.photoUrl || '',
        fromCourse: profile.course || '',
        toUid: peer.uid,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'notifications'), {
        recipientUid: peer.uid,
        actorUid: profile.uid,
        type: 'friend_request',
        title: 'New Friend Request',
        body: `${profile.fullName} wants to connect with you.`,
        read: false,
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `friendRequests/${reqId}`);
    }
  };

  const handleRespondRequest = async (req: FriendRequestItem, accept: boolean) => {
    try {
      await updateDoc(doc(db, 'friendRequests', req.id), {
        status: accept ? 'accepted' : 'rejected',
        updatedAt: serverTimestamp(),
      });
      if (accept) {
        const pairId = deterministicPairId(req.fromUid, req.toUid);
        const [userA, userB] = req.fromUid < req.toUid ? [req.fromUid, req.toUid] : [req.toUid, req.fromUid];
        await setDoc(doc(db, 'friendships', pairId), {
          userA,
          userB,
          createdAt: serverTimestamp(),
        });
        await addDoc(collection(db, 'notifications'), {
          recipientUid: req.fromUid,
          actorUid: profile.uid,
          type: 'friend_request',
          title: 'Friend Request Accepted',
          body: `${profile.fullName} accepted your friend request.`,
          read: false,
          createdAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `friendRequests/${req.id}`);
    }
  };

  const handleBlockUser = async (peerUid: string) => {
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        blockedUids: arrayUnion(peerUid),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`);
    }
  };

  const handleReportUser = async (peerUid: string) => {
    try {
      await addDoc(collection(db, 'reports'), {
        reporterUid: profile.uid,
        targetType: 'user',
        targetId: peerUid,
        reason: 'User reported via Friends directory',
        status: 'open',
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'reports');
    }
  };

  const filteredUsers = users.filter((u) => {
    if (profile.blockedUids?.includes(u.uid)) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      u.fullName.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      (u.college || '').toLowerCase().includes(q) ||
      (u.course || '').toLowerCase().includes(q)
    );
  });

  const friendsList = filteredUsers.filter((u) => friendUidSet.has(u.uid));
  const suggestionsList = filteredUsers.filter((u) => !friendUidSet.has(u.uid));

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.friends.searchPlaceholder}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      {/* Incoming Friend Requests */}
      {incomingRequests.length > 0 && (
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h2 className="font-display font-semibold text-base">
            {t.friends.requests} ({incomingRequests.length})
          </h2>
          <div className="space-y-3">
            {incomingRequests.map((req) => (
              <div
                key={req.id}
                className="flex flex-wrap items-center justify-between gap-3 py-2 border-b last:border-b-0 border-slate-100 dark:border-slate-800"
              >
                <div>
                  <p className="font-semibold text-sm">{req.fromName || 'Learner'}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {req.fromCourse || 'TEVETA Learner'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRespondRequest(req, true)}
                    className="min-h-[40px] px-4 py-1.5 rounded-xl bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{t.friends.accept}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRespondRequest(req, false)}
                    className="min-h-[40px] px-4 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>{t.friends.reject}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Approved Friends */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-semibold text-base">{t.friends.myFriends}</h2>
          <span className="text-xs text-slate-500 tabular-nums">{friendsList.length} connected</span>
        </div>

        {friendsList.length === 0 ? (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            No friends added yet. Send a request below to unlock private chats and calls.
          </p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {friendsList.map((peer) => {
              const isOnline = onlineUids.includes(peer.uid);
              return (
                <div
                  key={peer.uid}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold text-sm shrink-0 overflow-hidden">
                      {peer.photoUrl ? (
                        <img src={peer.photoUrl} alt={peer.fullName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        peer.fullName.slice(0, 2).toUpperCase()
                      )}
                      {isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{peer.fullName}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {peer.course || peer.college || `@${peer.username}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onStartChat(peer)}
                      title="Message"
                      className="min-h-[40px] min-w-[40px] rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 flex items-center justify-center cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onStartCall(peer, 'voice')}
                      title="Voice Call"
                      className="min-h-[40px] min-w-[40px] rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center cursor-pointer"
                    >
                      <Phone className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onStartCall(peer, 'video')}
                      title="Video Call"
                      className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center cursor-pointer"
                    >
                      <Video className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Suggestions & Directory */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <h2 className="font-display font-semibold text-base">{t.friends.suggestions}</h2>
        {suggestionsList.length === 0 ? (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            No other learners found matching your search.
          </p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {suggestionsList.map((peer) => {
              const requested = outgoingRequests.some(
                (r) => r.toUid === peer.uid && r.status === 'pending'
              );
              return (
                <div
                  key={peer.uid}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-11 h-11 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-sm shrink-0 overflow-hidden">
                      {peer.photoUrl ? (
                        <img src={peer.photoUrl} alt={peer.fullName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        peer.fullName.slice(0, 2).toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{peer.fullName}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {peer.college || 'Malawi TEVETA'} · {peer.course || peer.role}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      disabled={requested}
                      onClick={() => handleSendRequest(peer)}
                      className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                        requested
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                          : 'bg-blue-700 hover:bg-blue-800 text-white'
                      }`}
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>{requested ? t.friends.pending : t.friends.addFriend}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleBlockUser(peer.uid)}
                      title="Block user"
                      className="min-h-[38px] min-w-[38px] rounded-xl text-slate-400 hover:text-red-600 flex items-center justify-center"
                    >
                      <Ban className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleReportUser(peer.uid)}
                      title="Report user"
                      className="min-h-[38px] min-w-[38px] rounded-xl text-slate-400 hover:text-amber-600 flex items-center justify-center"
                    >
                      <Flag className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
