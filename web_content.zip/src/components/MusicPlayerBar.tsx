/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Repeat,
  Shuffle,
  Maximize2,
  Waves,
  BarChart3,
  CircleDot,
  Radio,
  Grid3X3,
} from 'lucide-react';
import { Track, VisualizerMode } from '../types';

interface MusicPlayerBarProps {
  currentTrack: Track;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
  currentTime: number;
  duration: number;
  onSeek: (seconds: number) => void;
  volume: number;
  onVolumeChange: (vol: number) => void;
  isLooping: boolean;
  onToggleLoop: () => void;
  isShuffling: boolean;
  onToggleShuffle: () => void;
  visualizerMode: VisualizerMode;
  onVisualizerModeChange: (mode: VisualizerMode) => void;
  onToggleFullScreen: () => void;
  isFullScreen: boolean;
}

export const MusicPlayerBar: React.FC<MusicPlayerBarProps> = ({
  currentTrack,
  isPlaying,
  onPlayPause,
  onNext,
  onPrev,
  currentTime,
  duration,
  onSeek,
  volume,
  onVolumeChange,
  isLooping,
  onToggleLoop,
  isShuffling,
  onToggleShuffle,
  visualizerMode,
  onVisualizerModeChange,
  onToggleFullScreen,
  isFullScreen,
}) => {
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const percent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const visualizerModes: { id: VisualizerMode; label: string; icon: React.ReactNode }[] = [
    { id: 'waveform', label: 'Waveform', icon: <Waves className="w-3.5 h-3.5" /> },
    { id: 'spectrum', label: 'Spectrum', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'circular', label: 'Circular', icon: <CircleDot className="w-3.5 h-3.5" /> },
    { id: 'lasers', label: 'Lasers', icon: <Radio className="w-3.5 h-3.5" /> },
    { id: 'matrix', label: 'Matrix', icon: <Grid3X3 className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="p-4 rounded-3xl bg-[#090a12]/95 border border-cyan-500/30 shadow-[0_10px_35px_rgba(0,0,0,0.9)] backdrop-blur-md">
      
      {/* Visualizer Mode Selector Pills */}
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="text-[10px] font-bold tracking-widest text-cyan-400 font-dj uppercase">
          VISUALIZER MODE
        </span>
        <div className="flex items-center gap-1.5 flex-wrap">
          {visualizerModes.map((item) => {
            const isSelected = visualizerMode === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onVisualizerModeChange(item.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold font-dj uppercase transition-all ${
                  isSelected
                    ? 'bg-cyan-500 text-black shadow-[0_0_12px_#00f0ff]'
                    : 'bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Progress Bar with Timestamp */}
      <div className="mb-3">
        <div className="relative flex items-center group">
          <input
            type="range"
            min="0"
            max={duration || 100}
            step="0.5"
            value={currentTime}
            onChange={(e) => onSeek(parseFloat(e.target.value))}
            className="w-full dj-slider cursor-pointer"
          />
        </div>
        <div className="flex justify-between items-center text-[10px] font-mono text-zinc-400 mt-1 px-1">
          <span>{formatTime(currentTime)}</span>
          <span className="text-[10px] text-cyan-400 font-semibold">{currentTrack.genre}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      {/* Main Transport & Track Details */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Track Info & Artwork */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-cyan-400/50 shadow-[0_0_10px_rgba(0,240,255,0.4)] shrink-0">
            <img
              src={currentTrack.coverUrl}
              alt={currentTrack.title}
              className={`w-full h-full object-cover ${isPlaying ? 'scale-105' : ''} transition-transform`}
            />
          </div>
          <div className="min-w-0">
            <h4 className="text-[13px] font-bold text-white truncate font-dj tracking-wide">
              {currentTrack.title}
            </h4>
            <p className="text-[11px] text-cyan-300/80 truncate font-medium">
              {currentTrack.artist}
            </p>
          </div>
        </div>

        {/* Player Transport Controls */}
        <div className="flex items-center gap-3">
          {/* Shuffle Toggle */}
          <button
            onClick={onToggleShuffle}
            className={`p-2 rounded-xl transition-colors ${
              isShuffling ? 'text-purple-400 bg-purple-950/40 border border-purple-500/50' : 'text-zinc-400 hover:text-white'
            }`}
            title="Toggle Shuffle"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          {/* Previous */}
          <button
            onClick={onPrev}
            className="p-2.5 rounded-full bg-zinc-800 text-zinc-200 hover:text-white hover:bg-zinc-700 active:scale-95 transition-all"
            title="Previous Track"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          {/* Play / Pause Primary Button */}
          <button
            onClick={onPlayPause}
            className={`p-4 rounded-full transition-all duration-200 active:scale-95 cursor-pointer ${
              isPlaying
                ? 'bg-gradient-to-r from-cyan-400 to-purple-500 text-black shadow-[0_0_25px_#00f0ff]'
                : 'bg-cyan-400 text-black shadow-[0_0_15px_#00f0ff] hover:scale-105'
            }`}
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 fill-black" />
            ) : (
              <Play className="w-6 h-6 fill-black ml-0.5" />
            )}
          </button>

          {/* Next */}
          <button
            onClick={onNext}
            className="p-2.5 rounded-full bg-zinc-800 text-zinc-200 hover:text-white hover:bg-zinc-700 active:scale-95 transition-all"
            title="Next Track"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          {/* Repeat Toggle */}
          <button
            onClick={onToggleLoop}
            className={`p-2 rounded-xl transition-colors ${
              isLooping ? 'text-cyan-400 bg-cyan-950/40 border border-cyan-500/50' : 'text-zinc-400 hover:text-white'
            }`}
            title="Toggle Repeat"
          >
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        {/* Volume & Fullscreen Controls */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <button
            onClick={() => onVolumeChange(volume > 0 ? 0 : 0.85)}
            className="text-zinc-400 hover:text-white transition-colors"
          >
            {volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
          <div className="w-24">
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
          </div>
          <button
            onClick={onToggleFullScreen}
            className={`p-2 rounded-xl transition-all ${
              isFullScreen
                ? 'bg-purple-600 text-white shadow-[0_0_12px_#b026ff]'
                : 'bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700'
            }`}
            title="Toggle Full Stage Visualizer"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
