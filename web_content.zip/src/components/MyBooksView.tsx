import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Ebook } from '../types';
import {
  BookMarked,
  BookOpen,
  Download,
  Clock,
  Heart,
  CheckCircle2,
  Trash2,
  ArrowRight,
  ExternalLink,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

export const MyBooksView: React.FC = () => {
  const {
    ebooks,
    purchasedBookIds,
    wishlist,
    toggleWishlist,
    setReaderEbook,
    setSelectedEbook,
    setActiveTab,
    showToast
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'purchased' | 'downloads' | 'history' | 'wishlist'>('purchased');
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({});

  // Get list of purchased / unlocked books
  const purchasedBooks = ebooks.filter((b) => purchasedBookIds.includes(b.id) || b.isFree);

  // Wishlist books
  const wishlistedBooks = ebooks.filter((b) => wishlist.includes(b.id));

  // Trigger file download with progress simulation
  const handleDownload = (ebook: Ebook) => {
    if (!ebook.hasPdfUploaded) {
      showToast('PDF not uploaded yet by the publisher.', 'error');
      return;
    }

    setDownloadProgress((prev) => ({ ...prev, [ebook.id]: 20 }));

    setTimeout(() => {
      setDownloadProgress((prev) => ({ ...prev, [ebook.id]: 65 }));
      setTimeout(() => {
        setDownloadProgress((prev) => {
          const next = { ...prev };
          delete next[ebook.id];
          return next;
        });
        downloadEbookAsHtml(ebook, true);
        showToast(`Downloaded "${ebook.title.substring(0, 24)}..." as standalone study file.`, 'success');
      }, 500);
    }, 400);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Banner */}
      <div className="bg-[#0B192C] text-white rounded-2xl p-6 sm:p-8 mb-6 border border-[#1E3E62] shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-xl">
          <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-0.5 rounded border border-amber-400/20 uppercase tracking-wider">
            Student Personal Library
          </span>
          <h1 className="text-xl sm:text-3xl font-black mt-2 text-white">
            My Study Materials & Ebooks
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Access all your purchased guides, previous year papers, and free study downloads anytime, anywhere.
          </p>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none transform translate-x-4 translate-y-4">
          <BookMarked className="w-56 h-56 text-amber-400" />
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="border-b border-slate-200 mb-6">
        <nav className="flex items-center gap-3 sm:gap-6 overflow-x-auto text-xs sm:text-sm">
          {[
            { id: 'purchased', label: `Purchased (${purchasedBooks.length})`, icon: BookOpen },
            { id: 'downloads', label: 'Downloads & Offline', icon: Download },
            { id: 'history', label: 'Reading History', icon: Clock },
            { id: 'wishlist', label: `Wishlist (${wishlistedBooks.length})`, icon: Heart },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`py-3 font-bold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
                  isActive
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-500' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab 1: Purchased Ebooks */}
      {activeSubTab === 'purchased' && (
        <div>
          {purchasedBooks.length === 0 ? (
            <div className="py-16 text-center bg-white border border-slate-200 rounded-2xl p-6">
              <BookMarked className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">
                You haven't unlocked any paid ebooks yet
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Discover our curated books for Assam Police, ADRE, Railway NTPC, and SSC exams.
              </p>
              <button
                onClick={() => setActiveTab('home')}
                className="mt-4 bg-[#0B192C] text-amber-400 font-bold text-xs px-5 py-2.5 rounded-xl transition-all"
              >
                Explore Exam Catalog
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {purchasedBooks.map((book) => {
                const isDownloading = downloadProgress[book.id] !== undefined;
                return (
                  <div
                    key={book.id}
                    className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-xs hover:border-amber-400 transition-colors"
                  >
                    <div className="flex gap-3">
                      {/* 3D Spine Cover */}
                      <div
                        onClick={() => setReaderEbook(book)}
                        className={`w-16 h-24 rounded-md bg-gradient-to-tr ${book.coverGradient} text-white p-2 flex flex-col justify-between shrink-0 shadow-sm cursor-pointer hover:scale-105 transition-transform`}
                      >
                        <span className="text-[7px] font-black uppercase text-amber-300 truncate">
                          {book.targetExam}
                        </span>
                        <span className="text-[9px] font-extrabold line-clamp-2">
                          {book.title}
                        </span>
                        <span className="text-[7px] bg-black/40 px-1 rounded text-center">
                          {book.format}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.2 rounded">
                            UNLOCKED
                          </span>
                          <span className="text-[10px] font-semibold text-slate-500">
                            {book.language}
                          </span>
                        </div>
                        <h3
                          onClick={() => setReaderEbook(book)}
                          className="text-xs sm:text-sm font-bold text-slate-900 hover:text-blue-900 cursor-pointer line-clamp-2 mt-1"
                        >
                          {book.title}
                        </h3>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                          {book.publisher} • {book.pageCount} Pages
                        </p>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1">
                          <Clock className="w-3 h-3" />
                          <span>Updated: {book.lastUpdated}</span>
                        </div>
                      </div>
                    </div>

                    {/* Download Progress Bar if active */}
                    {isDownloading && (
                      <div className="mt-3">
                        <div className="flex justify-between text-[10px] font-semibold text-slate-500 mb-1">
                          <span>Downloading package...</span>
                          <span>{downloadProgress[book.id]}%</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-amber-500 h-full transition-all duration-300"
                            style={{ width: `${downloadProgress[book.id]}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Bottom Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setReaderEbook(book)}
                        className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-3 rounded-xl transition-colors shadow-xs"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Read Online</span>
                      </button>

                      <button
                        disabled={isDownloading}
                        onClick={() => handleDownload(book)}
                        className={`flex items-center justify-center gap-1.5 border border-slate-200 hover:border-amber-400 text-slate-800 font-bold text-xs py-2 px-3 rounded-xl transition-colors ${
                          isDownloading ? 'opacity-50 cursor-wait' : 'hover:bg-amber-50'
                        }`}
                      >
                        <Download className="w-3.5 h-3.5 text-amber-600" />
                        <span>Save HTML</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Downloads & Offline */}
      {activeSubTab === 'downloads' && (
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="text-xs text-blue-900 space-y-1">
              <p className="font-bold">Offline Study File Support</p>
              <p className="text-[11px] leading-relaxed">
                Downloaded offline HTML files can be opened in any mobile or desktop web browser without needing active internet access. They are self-contained and also support printing or saving as PDF directly!
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-200 border border-slate-200 rounded-2xl bg-white overflow-hidden">
            {purchasedBooks.map((b) => (
              <div key={b.id} className="p-4 flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-14 rounded bg-gradient-to-tr ${b.coverGradient} text-white flex items-center justify-center text-[8px] font-bold text-center p-1 shrink-0`}>
                    {b.format}
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900">{b.title}</h4>
                    <p className="text-[11px] text-slate-500">{b.targetExam} • {b.fileSize} • {b.pageCount} Pages</p>
                  </div>
                </div>

                <button
                  onClick={() => handleDownload(b)}
                  className="flex items-center gap-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 px-3 py-1.5 rounded-lg transition-colors shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Reading History */}
      {activeSubTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center space-y-3">
          <Clock className="w-10 h-10 text-amber-500 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">
            Study Streak: 14 Days Active
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            You have logged over 38 study hours this month across ADRE Grade III Complete Guide and Assam Police SI cracker.
          </p>
          <div className="pt-2">
            <button
              onClick={() => {
                if (purchasedBooks[0]) setReaderEbook(purchasedBooks[0]);
              }}
              className="bg-[#0B192C] text-amber-400 font-bold text-xs px-5 py-2.5 rounded-xl hover:bg-slate-800 transition-colors"
            >
              Resume Last Read Chapter
            </button>
          </div>
        </div>
      )}

      {/* Tab 4: Wishlist */}
      {activeSubTab === 'wishlist' && (
        <div>
          {wishlistedBooks.length === 0 ? (
            <div className="py-16 text-center bg-white border border-slate-200 rounded-2xl p-6">
              <Heart className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">Your Wishlist is Empty</h3>
              <p className="text-xs text-slate-500 mt-1">
                Save exam books you want to review or purchase later.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {wishlistedBooks.map((b) => (
                <div key={b.id} className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-xs">
                  <div
                    onClick={() => setSelectedEbook(b)}
                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                  >
                    <div className={`w-12 h-16 rounded bg-gradient-to-tr ${b.coverGradient} text-white flex items-center justify-center text-[7px] font-bold text-center p-1 shrink-0`}>
                      {b.targetExam}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 truncate">{b.title}</h4>
                      <p className="text-[11px] text-slate-500">₹{b.price} • {b.language}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleWishlist(b.id)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Remove from wishlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
