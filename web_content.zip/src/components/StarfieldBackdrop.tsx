import React from 'react';

/**
 * Pure GPU-composited dark space starfield backdrop for Profile Selection.
 * Uses pre-rendered SVG star layers animated with CSS translate3d so floating
 * stars run smoothly on the compositor thread with zero JS main-thread overhead.
 */
export const StarfieldBackdrop: React.FC = React.memo(() => {
  return (
    <div className="absolute inset-0 overflow-hidden bg-[#020308] pointer-events-none" aria-hidden="true">
      {/* Deep midnight cosmos gradient */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 50% 35%, rgba(16, 36, 78, 0.34) 0%, rgba(5, 9, 20, 0.85) 55%, #020307 100%)',
        }}
      />

      {/* Far star layer (slow drift) */}
      <svg
        viewBox="0 0 1600 900"
        preserveAspectRatio="xMidYMid slice"
        className="absolute -inset-8 w-[calc(100%+64px)] h-[calc(100%+64px)] star-layer-slow opacity-70"
      >
        <g fill="#dbeafe">
          <circle cx="95" cy="110" r="1.1" />
          <circle cx="240" cy="70" r="1.4" />
          <circle cx="410" cy="190" r="0.9" />
          <circle cx="560" cy="85" r="1.3" />
          <circle cx="720" cy="210" r="1.0" />
          <circle cx="890" cy="120" r="1.5" />
          <circle cx="1040" cy="60" r="1.0" />
          <circle cx="1220" cy="175" r="1.2" />
          <circle cx="1390" cy="95" r="1.4" />
          <circle cx="1510" cy="240" r="1.0" />
          <circle cx="150" cy="340" r="1.2" />
          <circle cx="330" cy="430" r="0.9" />
          <circle cx="520" cy="360" r="1.4" />
          <circle cx="670" cy="480" r="1.1" />
          <circle cx="860" cy="390" r="0.9" />
          <circle cx="1010" cy="460" r="1.5" />
          <circle cx="1180" cy="340" r="1.0" />
          <circle cx="1350" cy="440" r="1.3" />
          <circle cx="1490" cy="510" r="0.9" />
          <circle cx="120" cy="620" r="1.3" />
          <circle cx="280" cy="740" r="1.0" />
          <circle cx="470" cy="670" r="1.4" />
          <circle cx="640" cy="790" r="1.1" />
          <circle cx="820" cy="650" r="1.3" />
          <circle cx="990" cy="760" r="0.9" />
          <circle cx="1160" cy="690" r="1.4" />
          <circle cx="1320" cy="810" r="1.1" />
          <circle cx="1480" cy="720" r="1.3" />
        </g>
      </svg>

      {/* Mid glowing stars + cross sparkles (gentle twinkle & parallax) */}
      <svg
        viewBox="0 0 1600 900"
        preserveAspectRatio="xMidYMid slice"
        className="absolute -inset-8 w-[calc(100%+64px)] h-[calc(100%+64px)] star-layer-mid"
      >
        <g fill="#7dd3fc">
          <circle cx="180" cy="210" r="1.8" />
          <circle cx="485" cy="140" r="1.6" />
          <circle cx="790" cy="285" r="2.0" />
          <circle cx="1120" cy="195" r="1.7" />
          <circle cx="1420" cy="310" r="1.9" />
          <circle cx="265" cy="540" r="1.7" />
          <circle cx="615" cy="610" r="2.1" />
          <circle cx="945" cy="560" r="1.6" />
          <circle cx="1275" cy="600" r="1.9" />
          <circle cx="390" cy="810" r="1.8" />
          <circle cx="1070" cy="830" r="1.7" />
        </g>

        {/* Crisp 4-point celestial star glints */}
        <g fill="#e0f2fe" opacity="0.85">
          <path d="M310 140 L313 151 L324 154 L313 157 L310 168 L307 157 L296 154 L307 151 Z" />
          <path d="M1260 230 L1263 242 L1275 245 L1263 248 L1260 260 L1257 248 L1245 245 L1257 242 Z" />
          <path d="M740 720 L743 731 L754 734 L743 737 L740 748 L737 737 L726 734 L737 731 Z" />
          <path d="M1430 670 L1432 679 L1441 681 L1432 683 L1430 692 L1428 683 L1419 681 L1428 679 Z" />
        </g>
      </svg>

      {/* Vignette for clean focus */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/75" />
    </div>
  );
});
StarfieldBackdrop.displayName = 'StarfieldBackdrop';
