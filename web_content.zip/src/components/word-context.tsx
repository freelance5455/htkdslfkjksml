import { createContext, useContext, useState, type ReactNode } from "react";
import { WordSheet, type WordPayload } from "@/components/word-sheet";

const Ctx = createContext<(p: WordPayload) => void>(() => {});

export function useWord() {
  return useContext(Ctx);
}

export function WordProvider({ children }: { children: ReactNode }) {
  const [payload, setPayload] = useState<WordPayload | null>(null);
  return (
    <Ctx.Provider value={setPayload}>
      {children}
      <WordSheet payload={payload} onClose={() => setPayload(null)} />
    </Ctx.Provider>
  );
}
