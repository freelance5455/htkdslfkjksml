import React from 'react';
import { Power, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { soundService } from '../utils/sound';

interface TactilePowerButtonProps {
  isOn: boolean;
  onToggle: () => void;
  activeColor?: string;
  glowColor?: string;
  brightness?: number; // 10 to 100
  sublabel?: string;
  disabled?: boolean;
  isOled?: boolean;
}

export const TactilePowerButton: React.FC<TactilePowerButtonProps> = ({
  isOn,
  onToggle,
  activeColor = '#00F0FF',
  glowColor = 'rgba(0, 240, 255, 0.7)',
  brightness = 100,
  sublabel,
  disabled = false,
  isOled = true,
}) => {
  const handleClick = () => {
    if (disabled) return;
    if (isOn) {
      soundService.playSwitchOff();
    } else {
      soundService.playSwitchOn();
    }
    onToggle();
  };

  const glowOpacity = Math.max(0.35, brightness / 100);

  return (
    <div className="relative flex flex-col items-center justify-center py-6 select-none">
      {/* Background radial glow halo when ON */}
      {isOn && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: glowOpacity, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          transition={{ duration: 0.2 }}
          className="absolute -inset-14 rounded-full blur-3xl pointer-events-none"
          style={{
            background: `radial-gradient(circle, ${activeColor} 0%, ${glowColor} 35%, transparent 70%)`,
          }}
        />
      )}

      {/* Outer Tactical Bezel / Machined CNC housing */}
      <div
        className={`relative p-3.5 rounded-full transition-all duration-300 ${
          isOled
            ? 'bg-black border border-neutral-900 shadow-[0_16px_40px_rgba(0,0,0,0.95)]'
            : 'bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 shadow-[0_14px_36px_rgba(0,0,0,0.7)]'
        }`}
      >
        {/* Inner bezel with CNC machined ridge lines */}
        <div
          className={`p-3.5 rounded-full border transition-all ${
            isOled
              ? 'bg-black border-neutral-900'
              : 'bg-slate-950 border-slate-800 shadow-[inset_0_4px_12px_rgba(0,0,0,0.9)]'
          }`}
        >
          {/* Main button element */}
          <motion.button
            whileTap={{ scale: 0.93 }}
            onClick={handleClick}
            disabled={disabled}
            aria-label={isOn ? 'Vypnout svítilnu' : 'Zapnout svítilnu'}
            className={`relative flex items-center justify-center w-36 h-36 sm:w-44 sm:h-44 rounded-full cursor-pointer transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
              isOn
                ? 'shadow-[0_0_55px_var(--glow-color),inset_0_2px_4px_rgba(255,255,255,0.7)]'
                : isOled
                ? 'bg-black border border-neutral-800 hover:border-neutral-700 shadow-[0_8px_20px_rgba(0,0,0,0.9)]'
                : 'bg-gradient-to-b from-slate-800 via-slate-850 to-slate-900 border border-slate-700/60 shadow-[0_8px_20px_rgba(0,0,0,0.6)] hover:border-slate-600'
            }`}
            style={
              isOn
                ? ({
                    backgroundColor: activeColor,
                    '--glow-color': glowColor,
                  } as React.CSSProperties)
                : {}
            }
          >
            {/* Concentric grooved tactile rings */}
            <div
              className={`absolute inset-2.5 rounded-full border pointer-events-none transition-colors ${
                isOn ? 'border-black/30' : 'border-neutral-800/40'
              }`}
            />
            <div
              className={`absolute inset-5 rounded-full border pointer-events-none transition-colors ${
                isOn ? 'border-black/20' : 'border-neutral-800/20'
              }`}
            />

            {/* Power icon and status label */}
            <div className="flex flex-col items-center justify-center gap-2">
              <Power
                className={`w-14 h-14 sm:w-16 sm:h-16 transition-all duration-200 ${
                  isOn
                    ? 'text-black drop-shadow-[0_2px_4px_rgba(255,255,255,0.3)] stroke-[2.75]'
                    : isOled
                    ? 'text-neutral-500 group-hover:text-neutral-300 stroke-[2.2]'
                    : 'text-slate-400 group-hover:text-slate-200 stroke-[2.2]'
                }`}
              />
              <span
                className={`text-[11px] sm:text-xs font-bold tracking-widest uppercase tabular-nums transition-colors ${
                  isOn
                    ? 'text-black font-extrabold'
                    : isOled
                    ? 'text-neutral-500'
                    : 'text-slate-500'
                }`}
              >
                {isOn ? 'ZAPNUTO' : 'VYPNUTO'}
              </span>
            </div>
          </motion.button>
        </div>
      </div>

      {/* Sublabel indicator */}
      {sublabel && (
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-400 text-center font-medium max-w-xs px-2">
          <span>{sublabel}</span>
        </div>
      )}
    </div>
  );
};
