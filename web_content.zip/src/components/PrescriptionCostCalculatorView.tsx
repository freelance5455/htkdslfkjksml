import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Camera,
  Upload,
  Plus,
  Trash2,
  Receipt,
  Trophy,
  ExternalLink,
  Loader2,
  AlertCircle,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  Info,
  CheckCircle2,
  ArrowRight,
  Pill,
  Layers,
  X,
  FileText,
  Globe,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PreferredLanguage } from '../types';
import { identifyMedicineFromImage } from '../services/medicineOcr';
import { ReadAloudButton } from './ReadAloudButton';

type Language = PreferredLanguage;

interface PrescriptionCostCalculatorViewProps {
  onBack?: () => void;
  language?: Language;
  onLanguageChange?: (lang: Language) => void;
}

export interface PrescriptionMedicineItem {
  id: string;
  name: string;
  strength: string;
  quantity: number;
  packSize?: string;
}

export interface PlatformLivePrice {
  platformId: '1mg' | 'pharmeasy' | 'apollo' | 'netmeds' | 'medplus' | 'amazon' | 'flipkart';
  platformName: string;
  logoBg: string;
  badgeColor: string;
  price: number | null; // unit price for 1 qty
  mrp: number | null;
  discountPercent: number | null;
  inStock: boolean;
  officialUrl: string;
}

export interface MedicineFetchResult {
  medicineItem: PrescriptionMedicineItem;
  platforms: PlatformLivePrice[];
}

export interface PlatformTotalSummary {
  platformId: string;
  platformName: string;
  logoBg: string;
  totalCost: number | null; // null if any medicine is unavailable on this platform
  availableCount: number;
  totalCount: number;
  officialUrl: string;
}

export interface MixedCartItem {
  medicineName: string;
  strength: string;
  quantity: number;
  recommendedPlatform: string;
  logoBg: string;
  unitPrice: number;
  totalPrice: number;
  officialUrl: string;
}

// Language config list
const LANGUAGE_OPTIONS: { id: Language; label: string; flag: string }[] = [
  { id: 'English', label: 'English', flag: '🇬🇧' },
  { id: 'Hindi', label: 'हिन्दी', flag: '🇮🇳' },
  { id: 'Marathi', label: 'मराठी', flag: '🇮🇳' },
];

export const PrescriptionCostCalculatorView: React.FC<PrescriptionCostCalculatorViewProps> = ({
  language = 'English',
  onLanguageChange,
}) => {
  // Persistent Language State with localStorage memory
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('preferred_language');
      if (saved === 'English' || saved === 'Hindi' || saved === 'Marathi') {
        return saved as Language;
      }
    } catch {}
    return language;
  });

  const handleSelectLanguage = (newLang: Language) => {
    setCurrentLang(newLang);
    try {
      localStorage.setItem('preferred_language', newLang);
    } catch {}
    if (onLanguageChange) {
      onLanguageChange(newLang);
    }
  };

  // Mode selection: 'scan' | 'manual'
  const [activeTab, setActiveTab] = useState<'scan' | 'manual'>('manual');

  // Medicine list state
  const [medicineList, setMedicineList] = useState<PrescriptionMedicineItem[]>([
    { id: '1', name: 'Dolo 650', strength: '650 mg', quantity: 1, packSize: 'Strip of 15' },
    { id: '2', name: 'Pan 40', strength: '40 mg', quantity: 1, packSize: 'Strip of 15' },
  ]);

  // Scan & Camera States
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isOcrProcessing, setIsOcrProcessing] = useState<boolean>(false);
  const [ocrStatusText, setOcrStatusText] = useState<string>('');
  const [scanError, setScanError] = useState<string | null>(null);

  // Comparison & Calculation States
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [hasCalculated, setHasCalculated] = useState<boolean>(false);
  const [liveResults, setLiveResults] = useState<MedicineFetchResult[]>([]);

  // Translation Dictionary
  const t = {
    title: {
      English: 'Prescription Cost Calculator',
      Hindi: 'प्रिस्क्रिप्शन लागत कैलकुलेटर',
      Marathi: 'प्रिस्क्रिप्शन खर्च कॅल्क्युलेटर',
    },
    subtitle: {
      English:
        'Estimate total prescription bill & compare live prices across official pharmacy platforms',
      Hindi:
        'कुल दवा बिल का अनुमान लगाएं और आधिकारिक फार्मेसी प्लेटफॉर्मों पर कीमतों की तुलना करें',
      Marathi:
        'एकूण औषध बिलाचा अंदाज घ्या आणि अधिकृत फार्मसी प्लॅटफॉर्मवर किमतींची तुलना करा',
    },
    toolBadge: {
      English: 'Material Design 3 Medical Prescription Tool',
      Hindi: 'मटीरियल डिज़ाइन 3 मेडिकल प्रिस्क्रिप्शन टूल',
      Marathi: 'मटेरियल डिझाइन ३ मेडिकल प्रिस्क्रिप्शन टूल',
    },
    tabScan: {
      English: '📷 Scan Prescription',
      Hindi: '📷 प्रिस्क्रिप्शन स्कैन करें',
      Marathi: '📷 प्रिस्क्रिप्शन स्कॅन करा',
    },
    tabManual: {
      English: '✍️ Add Medicines Manually',
      Hindi: '✍️ दवाइयां मैन्युअल रूप से जोड़ें',
      Marathi: '✍️ औषधे मॅन्युअली जोडा',
    },
    scanTitle: {
      English: 'Scan Prescription Photo',
      Hindi: 'प्रिस्क्रिप्शन फोटो स्कैन करें',
      Marathi: 'प्रिस्क्रिप्शन फोटो स्कॅन करा',
    },
    scanSubtitle: {
      English:
        'Use camera capture or upload prescription file to detect medicine names automatically.',
      Hindi:
        'स्वचालित रूप से दवाओं के नाम पहचानने के लिए कैमरा कैप्चर का उपयोग करें या फ़ाइल अपलोड करें।',
      Marathi:
        'औषधांची नावे आपोआप ओळखण्यासाठी कॅमेरा किंवा गॅलरीमधून फोटो अपलोड करा.',
    },
    btnCapture: {
      English: 'Capture Prescription Photo',
      Hindi: 'प्रिस्क्रिप्शन फोटो खींचें',
      Marathi: 'प्रिस्क्रिप्शन फोटो घ्या',
    },
    btnRetake: {
      English: 'Retake Prescription Photo',
      Hindi: 'फिर से फोटो खींचें',
      Marathi: 'पुन्हा फोटो घ्या',
    },
    cameraPrompt: {
      English: 'Click below to open camera or upload prescription from gallery.',
      Hindi:
        'कैमरा खोलने या गैलरी से प्रिस्क्रिप्शन अपलोड करने के लिए नीचे क्लिक करें।',
      Marathi:
        'कॅमेरा उघडण्यासाठी किंवा गॅलरीमधून प्रिस्क्रिप्शन अपलोड करण्यासाठी खाली क्लिक करा.',
    },
    btnUseCamera: {
      English: 'Use Camera',
      Hindi: 'कैमरा इस्तेमाल करें',
      Marathi: 'कॅमेरा वापरा',
    },
    btnUploadGallery: {
      English: 'Upload from Gallery',
      Hindi: 'गैलरी से अपलोड करें',
      Marathi: 'गॅलरीमधून अपलोड करा',
    },
    statusScanning: {
      English: 'Scanning prescription & detecting medicines...',
      Hindi: 'प्रिस्क्रिप्शन स्कैन कर दवाइयों की पहचान की जा रही है...',
      Marathi: 'प्रिस्क्रिप्शन स्कॅन करून औषधे ओळखली जात आहेत...',
    },
    errCamera: {
      English:
        'Camera access failed or permission was denied. Please upload prescription image from your gallery.',
      Hindi:
        'कैमरा एक्सेस विफल या अनुमति अस्वीकृत। कृपया अपनी गैलरी से प्रिस्क्रिप्शन छवि अपलोड करें।',
      Marathi:
        'कॅमेरा ॲक्सेस अयशस्वी किंवा परवानगी नाकारली. कृपया तुमच्या गॅलरीमधून फोटो अपलोड करा.',
    },
    errScan: {
      English:
        'Prescription medicine could not be identified clearly. You can also type the medicines manually below.',
      Hindi:
        'प्रिस्क्रिप्शन दवा स्पष्ट रूप से नहीं पहचानी जा सकी। आप नीचे मैन्युअल रूप से दवाएं दर्ज कर सकते हैं।',
      Marathi:
        'प्रिस्क्रिप्शन औषध स्पष्टपणे ओळखता आले नाही. तुम्ही खाली मॅन्युअली औषधे टाईप करू शकता.',
    },
    manualTitle: {
      English: 'Prescription Medicines List',
      Hindi: 'प्रिस्क्रिप्शन दवाओं की सूची',
      Marathi: 'प्रिस्क्रिप्शन औषधांची यादी',
    },
    manualSubtitle: {
      English:
        'Add or review medicines, strengths, and quantities before calculating live costs.',
      Hindi:
        'लाइव लागत की गणना करने से पहले दवाओं, खुराक और मात्रा की समीक्षा करें या जोड़ें।',
      Marathi:
        'थेट खर्चाची गणना करण्यापूर्वी औषधे, ताकद आणि प्रमाण तपासा किंवा जोडा.',
    },
    lblMedName: {
      English: 'Medicine Name',
      Hindi: 'दवा का नाम',
      Marathi: 'औषधाचे नाव',
    },
    lblStrength: {
      English: 'Strength',
      Hindi: 'खुराक / क्षमता',
      Marathi: 'ताकद / डोस',
    },
    lblQuantity: {
      English: 'Quantity',
      Hindi: 'मात्रा',
      Marathi: 'प्रमाण',
    },
    lblPackSize: {
      English: 'Pack Size (Opt)',
      Hindi: 'पैक आकार (ऐच्छिक)',
      Marathi: 'पॅक आकार (पर्यायी)',
    },
    phMedName: {
      English: 'e.g. Dolo 650, Pan 40',
      Hindi: 'उदा. डोलो 650, पैन 40',
      Marathi: 'उदा. डोलो ६५०, पॅन ४०',
    },
    phStrength: {
      English: 'e.g. 650 mg',
      Hindi: 'उदा. 650 mg',
      Marathi: 'उदा. ६५० mg',
    },
    phPackSize: {
      English: 'e.g. Strip of 15',
      Hindi: 'उदा. 15 गोलियों की स्ट्रिप',
      Marathi: 'उदा. १५ गोळ्यांची स्ट्रिप',
    },
    addMedBtn: {
      English: 'Add Another Medicine',
      Hindi: 'एक और दवा जोड़ें',
      Marathi: 'अजून एक औषध जोडा',
    },
    compareBtn: {
      English: 'Compare Prescription Cost',
      Hindi: 'प्रिस्क्रिप्शन लागत की तुलना करें',
      Marathi: 'प्रिस्क्रिप्शन खर्चाची तुलना करा',
    },
    comparingLoading: {
      English: 'Fetching Verified Platform Prices...',
      Hindi: 'सत्यापित प्लेटफॉर्म कीमतें प्राप्त की जा रही हैं...',
      Marathi: 'सत्यापित प्लॅटफॉर्म किमती मिळवत आहे...',
    },
    summaryTitle: {
      English: 'Prescription Summary',
      Hindi: 'प्रिस्क्रिप्शन सारांश',
      Marathi: 'प्रिस्क्रिप्शन सारांश',
    },
    totalMeds: {
      English: 'Total Medicines',
      Hindi: 'कुल दवाइयां',
      Marathi: 'एकूण औषधे',
    },
    itemsCount: (count: number) => {
      const msgs = {
        English: `${count} Items`,
        Hindi: `${count} दवाइयां`,
        Marathi: `${count} औषधे`,
      };
      return msgs[currentLang];
    },
    estTotalCost: {
      English: 'Estimated Total Cost',
      Hindi: 'अनुमानित कुल लागत',
      Marathi: 'अंदाजे एकूण खर्च',
    },
    cheapestPlatformLabel: {
      English: 'Cheapest Platform',
      Hindi: 'सबसे सस्ता प्लेटफॉर्म',
      Marathi: 'सर्व्यात स्वस्त प्लॅटफॉर्म',
    },
    priceUnavailable: {
      English: 'Price currently unavailable.',
      Hindi: 'कीमत वर्तमान में अनुपलब्ध है।',
      Marathi: 'किंमत सध्या उपलब्ध नाही.',
    },
    cheapestPlatformTitle: {
      English: '🏆 Cheapest Single Platform',
      Hindi: '🏆 सबसे सस्ता एकल प्लेटफॉर्म',
      Marathi: '🏆 सर्वात स्वस्त सिंगल प्लॅटफॉर्म',
    },
    totalCostLabel: {
      English: 'Total Cost',
      Hindi: 'कुल लागत',
      Marathi: 'एकूण खर्च',
    },
    savedAmount: (savings: string) => {
      const msgs = {
        English: `Saved ₹${savings} compared with highest single platform!`,
        Hindi: `उच्चतम एकल प्लेटफॉर्म की तुलना में ₹${savings} की बचत!`,
        Marathi: `सर्वोच्च सिंगल प्लॅटफॉर्मच्या तुलनेत ₹${savings} बचत झाली!`,
      };
      return msgs[currentLang];
    },
    viewOnPlatform: (plat: string) => {
      const msgs = {
        English: `View on ${plat}`,
        Hindi: `${plat} पर देखें`,
        Marathi: `${plat} वर पहा`,
      };
      return msgs[currentLang];
    },
    mixedCartTitle: {
      English: '⚡ Mixed Cart Optimization',
      Hindi: '⚡ मिक्स्ड कार्ट अनुकूलन (Mixed Cart Analysis)',
      Marathi: '⚡ मिक्स्ड कार्ट विश्लेषण (Mixed Cart Analysis)',
    },
    mixedCartBadge: {
      English: 'Smart Multi-Store Recommendation',
      Hindi: 'स्मार्ट मल्टी-स्टोर अनुशंसा',
      Marathi: 'स्मार्ट मल्टी-स्टोअर शिफारस',
    },
    mixedCartSubtitle: {
      English:
        'Buy individual medicines from the lowest-priced platform for maximum savings',
      Hindi:
        'अधिकतम बचत के लिए अलग-अलग दवाइयां सबसे कम कीमत वाले प्लेटफॉर्म से खरीदें',
      Marathi:
        'जास्तीत जास्त बचतीसाठी वेगवेगळी औषधे सर्वात कमी किमतीच्या प्लॅटफॉर्मवरून खरेदी करा',
    },
    recommendedPlatform: {
      English: 'Recommended Platform:',
      Hindi: 'अनुशंसित प्लेटफॉर्म:',
      Marathi: 'शिफारस केलेला प्लॅटफॉर्म:',
    },
    btnView: {
      English: 'View',
      Hindi: 'देखें',
      Marathi: 'पहा',
    },
    totalMixedCartCost: (cost: string) => {
      const msgs = {
        English: `Total Mixed Cart Cost: ₹${cost}`,
        Hindi: `कुल मिक्स्ड कार्ट लागत: ₹${cost}`,
        Marathi: `एकूण मिक्स्ड कार्ट खर्च: ₹${cost}`,
      };
      return msgs[currentLang];
    },
    extraSavingsNotice: (savings: string) => {
      const msgs = {
        English: `Saves an extra ₹${savings} compared with single store purchase!`,
        Hindi: `एकल स्टोर खरीदारी की तुलना में ₹${savings} अतिरिक्त बचत!`,
        Marathi: `सिंगल स्टोअर खरेदीच्या तुलनेत अतिरिक्त ₹${savings} बचत!`,
      };
      return msgs[currentLang];
    },
    officialComparisonTitle: {
      English: 'Official Platform Prescription Cost Comparison',
      Hindi: 'आधिकारिक प्लेटफॉर्म प्रिस्क्रिप्शन लागत तुलना',
      Marathi: 'अधिकृत प्लॅटफॉर्म प्रिस्क्रिप्शन खर्च तुलना',
    },
    badgeCheapestTotal: {
      English: '🏆 Cheapest Total',
      Hindi: '🏆 सबसे सस्ता कुल',
      Marathi: '🏆 सर्वात स्वस्त एकूण',
    },
    officialPharmacyPortal: {
      English: 'Official Pharmacy Portal',
      Hindi: 'आधिकारिक फार्मेसी पोर्टल',
      Marathi: 'अधिकृत फार्मसी पोर्टल',
    },
    verifiedLivePricing: {
      English: 'Verified Live Pricing',
      Hindi: 'सत्यापित लाइव मूल्य',
      Marathi: 'सत्यापित थेट किमती',
    },
    buyNotice: {
      English:
        'Tap any platform button to open official pharmacy pages directly. No payments or sales are processed inside this app.',
      Hindi:
        'सीधे आधिकारिक फ़ार्मेसी पृष्ठों को खोलने के लिए किसी भी प्लेटफ़ॉर्म बटन पर टैप करें। इस ऐप के भीतर कोई भुगतान या बिक्री नहीं की जाती है।',
      Marathi:
        'थेट अधिकृत फार्मसी पृष्ठे उघडण्यासाठी कोणत्याही प्लॅटफॉर्म बटणावर टॅप करा. या अॅपमध्ये कोणतेही पेमेंट किंवा विक्री प्रक्रिया केली जात नाही.',
    },
    alertEmpty: {
      English: 'Please enter or scan at least one valid medicine name.',
      Hindi: 'कृपया कम से कम एक मान्य दवा का नाम दर्ज या स्कैन करें।',
      Marathi: 'कृपया किमान एक वैध औषधाचे नाव प्रविष्ट किंवा स्कॅन करा.',
    },
    alertError: {
      English: 'An error occurred while comparing platform prices. Please try again.',
      Hindi: 'प्लेटफ़ॉर्म कीमतों की तुलना करते समय एक त्रुटि हुई। कृपया पुनः प्रयास करें।',
      Marathi: 'प्लॅटफॉर्म किमतींची तुलना करताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.',
    },
    ocrSuccessMsg: (medName: string) => {
      const msgs = {
        English: `Prescription Scanned Successfully!\nDetected Medicine: ${medName}`,
        Hindi: `प्रिस्क्रिप्शन सफलतापूर्वक स्कैन किया गया!\nपहचानी गई दवा: ${medName}`,
        Marathi: `प्रिस्क्रिप्शन यशस्वीरित्या स्कॅन केले!\nओळखलेले औषध: ${medName}`,
      };
      return msgs[currentLang];
    },
  };

  // Refs for Camera & Upload
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Clean up camera stream on unmount
  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const startCamera = async () => {
    setCameraError(null);
    setScanError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      setIsCameraActive(true);

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err) {
      console.error('Camera access error:', err);
      setCameraError(t.errCamera[currentLang]);
      setIsCameraActive(false);
    }
  };

  const takeCameraSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      stopCameraStream();
      handleProcessPrescriptionImage(dataUrl);
    }
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
      alert('Please select a valid image file (JPG, JPEG, or PNG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        handleProcessPrescriptionImage(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  // Process Prescription Image with existing Prescription Scanner
  const handleProcessPrescriptionImage = async (dataUrl: string) => {
    setCapturedImage(dataUrl);
    setIsOcrProcessing(true);
    setScanError(null);
    setOcrStatusText(t.statusScanning[currentLang]);

    try {
      const result = await identifyMedicineFromImage(dataUrl, (pct, status) => {
        setOcrStatusText(status);
      });

      setIsOcrProcessing(false);

      if (result.success && result.medicine) {
        const newMed: PrescriptionMedicineItem = {
          id: Date.now().toString(),
          name: result.medicine.medicineName,
          strength: result.medicine.strength || 'Standard',
          quantity: 1,
          packSize: 'Standard Pack',
        };

        setMedicineList((prev) => {
          const exists = prev.some(
            (m) => m.name.toLowerCase() === newMed.name.toLowerCase()
          );
          if (exists) return prev;
          return [...prev, newMed];
        });

        alert(t.ocrSuccessMsg(result.medicine.medicineName));
      } else {
        setScanError(result.errorMessage || t.errScan[currentLang]);
      }
    } catch (err) {
      console.error('OCR processing error:', err);
      setIsOcrProcessing(false);
      setScanError(t.errScan[currentLang]);
    }
  };

  // Manual List Management
  const handleAddMedicineRow = () => {
    setMedicineList((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        name: '',
        strength: '',
        quantity: 1,
        packSize: '',
      },
    ]);
  };

  const handleUpdateMedicine = (
    id: string,
    field: keyof PrescriptionMedicineItem,
    value: string | number
  ) => {
    setMedicineList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleRemoveMedicine = (id: string) => {
    setMedicineList((prev) => prev.filter((item) => item.id !== id));
  };

  // Compare Prescription Cost across all official platforms
  const handleComparePrescriptionCost = async () => {
    const validMedicines = medicineList.filter((m) => m.name.trim().length > 0);
    if (validMedicines.length === 0) {
      alert(t.alertEmpty[currentLang]);
      return;
    }

    setIsCalculating(true);
    setHasCalculated(false);

    try {
      const results: MedicineFetchResult[] = await Promise.all(
        validMedicines.map(async (med) => {
          try {
            const res = await fetch(
              `/api/medicine-price?query=${encodeURIComponent(med.name.trim())}`
            );
            if (res.ok) {
              const data = await res.json();
              return {
                medicineItem: med,
                platforms: data.platforms || [],
              };
            }
          } catch (err) {
            console.error(`Failed to fetch price for ${med.name}:`, err);
          }

          return {
            medicineItem: med,
            platforms: [
              {
                platformId: '1mg',
                platformName: 'Tata 1mg',
                logoBg: 'bg-orange-500 text-white',
                badgeColor: 'border-orange-200 bg-orange-50 text-orange-800',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.1mg.com/search/all?name=${encodeURIComponent(med.name)}`,
              },
              {
                platformId: 'pharmeasy',
                platformName: 'PharmEasy',
                logoBg: 'bg-emerald-600 text-white',
                badgeColor: 'border-emerald-200 bg-emerald-50 text-emerald-800',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://pharmeasy.in/search/all?name=${encodeURIComponent(med.name)}`,
              },
              {
                platformId: 'apollo',
                platformName: 'Apollo 24|7',
                logoBg: 'bg-blue-600 text-white',
                badgeColor: 'border-blue-200 bg-blue-50 text-blue-800',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.apollo247.com/specialties/search?q=${encodeURIComponent(med.name)}`,
              },
              {
                platformId: 'netmeds',
                platformName: 'Netmeds',
                logoBg: 'bg-teal-600 text-white',
                badgeColor: 'border-teal-200 bg-teal-50 text-teal-800',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.netmeds.com/catalogsearch/result?q=${encodeURIComponent(med.name)}`,
              },
              {
                platformId: 'medplus',
                platformName: 'MedPlus Mart',
                logoBg: 'bg-red-600 text-white',
                badgeColor: 'border-red-200 bg-red-50 text-red-800',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.medplusmart.com/searchResult.mart?searchData=${encodeURIComponent(med.name)}`,
              },
              {
                platformId: 'amazon',
                platformName: 'Amazon Pharmacy',
                logoBg: 'bg-amber-500 text-slate-900',
                badgeColor: 'border-amber-200 bg-amber-50 text-amber-900',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.amazon.in/s?k=${encodeURIComponent(med.name + ' medicine')}`,
              },
              {
                platformId: 'flipkart',
                platformName: 'Flipkart Health+',
                logoBg: 'bg-blue-500 text-white',
                badgeColor: 'border-blue-200 bg-blue-50 text-blue-900',
                price: null,
                mrp: null,
                discountPercent: null,
                inStock: false,
                officialUrl: `https://www.flipkart.com/search?q=${encodeURIComponent(med.name + ' medicine')}`,
              },
            ],
          };
        })
      );

      setLiveResults(results);
      setHasCalculated(true);
    } catch (err) {
      console.error('Calculation error:', err);
      alert(t.alertError[currentLang]);
    } finally {
      setIsCalculating(false);
    }
  };

  // Compute Platform Total Costs across all medicines
  const platformTotals = useMemo<PlatformTotalSummary[]>(() => {
    if (liveResults.length === 0) return [];

    const platformsList: { id: string; name: string; bg: string }[] = [
      { id: '1mg', name: 'Tata 1mg', bg: 'bg-orange-500 text-white' },
      { id: 'pharmeasy', name: 'PharmEasy', bg: 'bg-emerald-600 text-white' },
      { id: 'apollo', name: 'Apollo 24|7', bg: 'bg-blue-600 text-white' },
      { id: 'netmeds', name: 'Netmeds', bg: 'bg-teal-600 text-white' },
      { id: 'medplus', name: 'MedPlus Mart', bg: 'bg-red-600 text-white' },
      { id: 'amazon', name: 'Amazon Pharmacy', bg: 'bg-amber-500 text-slate-900' },
      { id: 'flipkart', name: 'Flipkart Health+', bg: 'bg-blue-500 text-white' },
    ];

    return platformsList.map((plat) => {
      let total = 0;
      let allAvailable = true;
      let availableCount = 0;
      let sampleUrl = '';

      for (const res of liveResults) {
        const platInfo = res.platforms.find((p) => p.platformId === plat.id);
        if (platInfo && platInfo.price !== null && platInfo.price > 0) {
          total += platInfo.price * res.medicineItem.quantity;
          availableCount++;
          if (!sampleUrl) sampleUrl = platInfo.officialUrl;
        } else {
          allAvailable = false;
        }
      }

      return {
        platformId: plat.id,
        platformName: plat.name,
        logoBg: plat.bg,
        totalCost:
          allAvailable && availableCount > 0
            ? Number(total.toFixed(2))
            : availableCount > 0
            ? Number(total.toFixed(2))
            : null,
        availableCount,
        totalCount: liveResults.length,
        officialUrl: sampleUrl || `https://www.google.com/search?q=${encodeURIComponent(plat.name)}`,
      };
    });
  }, [liveResults]);

  // Determine Cheapest Single Platform
  const cheapestPlatform = useMemo(() => {
    const valid = platformTotals.filter((p) => p.totalCost !== null);
    if (valid.length === 0) return null;

    valid.sort((a, b) => (a.totalCost as number) - (b.totalCost as number));

    const cheapest = valid[0];
    const highest = valid[valid.length - 1];
    const savings =
      highest && highest.totalCost !== null && cheapest.totalCost !== null
        ? highest.totalCost - cheapest.totalCost
        : 0;

    return {
      cheapest,
      highest,
      savings: savings > 0 ? Number(savings.toFixed(2)) : 0,
    };
  }, [platformTotals]);

  // Mixed Cart Analysis
  const mixedCartAnalysis = useMemo(() => {
    if (liveResults.length === 0) return null;

    let mixedTotal = 0;
    let hasCompleteMixed = true;

    const items: MixedCartItem[] = liveResults.map((res) => {
      const validPlats = res.platforms.filter(
        (p) => p.price !== null && p.price > 0
      );

      if (validPlats.length > 0) {
        validPlats.sort((a, b) => (a.price as number) - (b.price as number));
        const best = validPlats[0];
        const itemTotal = (best.price as number) * res.medicineItem.quantity;
        mixedTotal += itemTotal;

        return {
          medicineName: res.medicineItem.name,
          strength: res.medicineItem.strength || 'Standard',
          quantity: res.medicineItem.quantity,
          recommendedPlatform: best.platformName,
          logoBg: best.logoBg,
          unitPrice: best.price as number,
          totalPrice: Number(itemTotal.toFixed(2)),
          officialUrl: best.officialUrl,
        };
      } else {
        hasCompleteMixed = false;
        return {
          medicineName: res.medicineItem.name,
          strength: res.medicineItem.strength || 'Standard',
          quantity: res.medicineItem.quantity,
          recommendedPlatform: 'Official Listing Link',
          logoBg: 'bg-slate-400 text-white',
          unitPrice: 0,
          totalPrice: 0,
          officialUrl: `https://www.1mg.com/search/all?name=${encodeURIComponent(
            res.medicineItem.name
          )}`,
        };
      }
    });

    const cheapestSingleTotal = cheapestPlatform?.cheapest?.totalCost || 0;
    const extraSavings =
      cheapestSingleTotal > 0 && mixedTotal > 0 && cheapestSingleTotal > mixedTotal
        ? cheapestSingleTotal - mixedTotal
        : 0;

    return {
      items,
      totalMixedCost: Number(mixedTotal.toFixed(2)),
      hasCompleteMixed,
      extraSavings: Number(extraSavings.toFixed(2)),
    };
  }, [liveResults, cheapestPlatform]);

  return (
    <div className="space-y-6">
      {/* Header Banner with Language Switcher in Top Right */}
      <div className="bg-gradient-to-br from-teal-700 via-teal-800 to-emerald-900 rounded-3xl p-5 sm:p-6 text-white shadow-xl relative overflow-hidden space-y-4">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-2 text-teal-200 text-xs font-bold uppercase tracking-wider">
            <Receipt className="w-4 h-4 text-emerald-400" />
            <span>{t.toolBadge[currentLang]}</span>
          </div>

          {/* LANGUAGE SWITCHER CONTROL */}
          <div className="flex items-center gap-1.5 bg-black/25 backdrop-blur-md p-1 rounded-2xl border border-white/20 shadow-md">
            <Globe className="w-4 h-4 text-emerald-300 ml-2" />
            {LANGUAGE_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => handleSelectLanguage(opt.id)}
                className={`px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                  currentLang === opt.id
                    ? 'bg-amber-400 text-slate-950 shadow-md scale-105'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <span>{opt.flag}</span>
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1 relative z-10">
          <h1 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
            <span>🧾</span>
            <span>{t.title[currentLang]}</span>
          </h1>
          <p className="text-xs sm:text-sm text-teal-100/90 font-medium max-w-xl leading-relaxed">
            {t.subtitle[currentLang]}
          </p>
        </div>
      </div>

      {/* MODE SELECTION TABS */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-2">
        <button
          type="button"
          onClick={() => setActiveTab('manual')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'manual'
              ? 'bg-teal-600 text-white shadow-sm'
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
        >
          <span>{t.tabManual[currentLang]}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveTab('scan');
            if (!capturedImage) startCamera();
          }}
          className={`flex-1 py-3 px-4 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'scan'
              ? 'bg-teal-600 text-white shadow-sm'
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
        >
          <span>{t.tabScan[currentLang]}</span>
        </button>
      </div>

      {/* OPTION 1 - SCAN PRESCRIPTION AREA */}
      {activeTab === 'scan' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-5"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="space-y-0.5">
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Camera className="w-5 h-5 text-teal-600" />
                <span>{t.scanTitle[currentLang]}</span>
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {t.scanSubtitle[currentLang]}
              </p>
            </div>
          </div>

          {/* WebRTC Camera Viewport or Preview */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 min-h-[260px] flex items-center justify-center text-white">
            {isCameraActive ? (
              <div className="relative w-full h-full flex flex-col items-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-64 object-cover rounded-2xl"
                />
                <button
                  type="button"
                  onClick={takeCameraSnapshot}
                  className="absolute bottom-4 px-6 py-3 bg-amber-400 hover:bg-amber-500 text-slate-950 font-black text-xs rounded-2xl shadow-xl flex items-center gap-2 transition-transform active:scale-95 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>{t.btnCapture[currentLang]}</span>
                </button>
              </div>
            ) : capturedImage ? (
              <div className="relative w-full h-full p-2 flex flex-col items-center">
                <img
                  src={capturedImage}
                  alt="Captured Prescription"
                  className="max-h-64 object-contain rounded-xl border border-slate-700"
                />
                <button
                  type="button"
                  onClick={startCamera}
                  className="mt-3 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-extrabold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{t.btnRetake[currentLang]}</span>
                </button>
              </div>
            ) : (
              <div className="p-8 text-center space-y-3">
                <div className="w-16 h-16 bg-slate-800 rounded-3xl flex items-center justify-center mx-auto text-teal-400">
                  <FileText className="w-8 h-8" />
                </div>
                <p className="text-xs text-slate-300 font-semibold max-w-sm">
                  {t.cameraPrompt[currentLang]}
                </p>
              </div>
            )}
          </div>

          {/* Action Buttons: Camera vs Gallery */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={startCamera}
              className="flex-1 py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>{t.btnUseCamera[currentLang]}</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-xs rounded-xl border border-slate-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Upload className="w-4 h-4 text-teal-600" />
              <span>{t.btnUploadGallery[currentLang]}</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleGalleryUpload}
              className="hidden"
            />
          </div>

          {/* Processing Indicator */}
          {isOcrProcessing && (
            <div className="p-4 bg-teal-50 border border-teal-200 rounded-2xl flex items-center gap-3 text-teal-900 text-xs font-bold">
              <Loader2 className="w-5 h-5 text-teal-600 animate-spin shrink-0" />
              <span>{ocrStatusText}</span>
            </div>
          )}

          {/* Scan Error Notice */}
          {scanError && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-amber-900 text-xs font-semibold">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <span>{scanError}</span>
            </div>
          )}

          {cameraError && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs font-semibold">
              {cameraError}
            </div>
          )}
        </motion.div>
      )}

      {/* OPTION 2 - MANUAL ENTRY & PRESCRIPTION MEDICINES LIST */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-5"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="space-y-0.5">
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <Pill className="w-5 h-5 text-teal-600" />
              <span>{t.manualTitle[currentLang]}</span>
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              {t.manualSubtitle[currentLang]}
            </p>
          </div>

          <button
            type="button"
            onClick={handleAddMedicineRow}
            className="px-3.5 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 font-extrabold text-xs rounded-xl border border-teal-200 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-teal-600" />
            <span>{t.addMedBtn[currentLang]}</span>
          </button>
        </div>

        {/* MEDICINE INPUT ROWS */}
        <div className="space-y-3">
          {medicineList.map((med, index) => (
            <div
              key={med.id}
              className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-3 sm:space-y-0 sm:flex sm:items-center sm:gap-3 transition-all hover:border-teal-300"
            >
              <div className="text-xs font-black text-slate-400 w-6 text-center shrink-0 hidden sm:block">
                #{index + 1}
              </div>

              {/* Medicine Name */}
              <div className="flex-1 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  {t.lblMedName[currentLang]}
                </label>
                <input
                  type="text"
                  value={med.name}
                  onChange={(e) => handleUpdateMedicine(med.id, 'name', e.target.value)}
                  placeholder={t.phMedName[currentLang]}
                  className="w-full bg-white text-slate-900 text-xs font-extrabold px-3 py-2.5 rounded-xl border border-slate-200 focus:border-teal-500 focus:outline-none"
                />
              </div>

              {/* Strength */}
              <div className="w-full sm:w-28 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  {t.lblStrength[currentLang]}
                </label>
                <input
                  type="text"
                  value={med.strength}
                  onChange={(e) => handleUpdateMedicine(med.id, 'strength', e.target.value)}
                  placeholder={t.phStrength[currentLang]}
                  className="w-full bg-white text-slate-900 text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 focus:border-teal-500 focus:outline-none"
                />
              </div>

              {/* Quantity */}
              <div className="w-full sm:w-24 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  {t.lblQuantity[currentLang]}
                </label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={med.quantity}
                  onChange={(e) =>
                    handleUpdateMedicine(med.id, 'quantity', parseInt(e.target.value) || 1)
                  }
                  className="w-full bg-white text-slate-900 text-xs font-extrabold px-3 py-2.5 rounded-xl border border-slate-200 focus:border-teal-500 focus:outline-none"
                />
              </div>

              {/* Pack Size (Optional) */}
              <div className="w-full sm:w-32 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  {t.lblPackSize[currentLang]}
                </label>
                <input
                  type="text"
                  value={med.packSize || ''}
                  onChange={(e) => handleUpdateMedicine(med.id, 'packSize', e.target.value)}
                  placeholder={t.phPackSize[currentLang]}
                  className="w-full bg-white text-slate-900 text-xs font-medium px-3 py-2.5 rounded-xl border border-slate-200 focus:border-teal-500 focus:outline-none"
                />
              </div>

              {/* Remove Action */}
              <div className="flex items-center justify-end pt-2 sm:pt-4">
                <button
                  type="button"
                  onClick={() => handleRemoveMedicine(med.id)}
                  disabled={medicineList.length <= 1}
                  className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors disabled:opacity-30 cursor-pointer"
                  title="Remove medicine"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* COMPARE BUTTON */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleComparePrescriptionCost}
            disabled={isCalculating}
            className="w-full py-4 bg-teal-600 hover:bg-teal-700 text-white font-black text-sm rounded-2xl shadow-lg shadow-teal-600/20 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
          >
            {isCalculating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{t.comparingLoading[currentLang]}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-amber-300" />
                <span>{t.compareBtn[currentLang]}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </motion.div>

      {/* CALCULATED RESULTS AREA */}
      {hasCalculated && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* SUMMARY DASHBOARD CARD */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 uppercase tracking-wider text-slate-500 text-xs flex items-center gap-2">
                <Receipt className="w-4 h-4 text-teal-600" />
                <span>{t.summaryTitle[currentLang]}</span>
              </h3>
              <ReadAloudButton
                id="prescription-cost-read-aloud"
                text={(() => {
                  const count = medicineList.filter((m) => m.name.trim().length > 0).length;
                  const parts: string[] = [];
                  parts.push(`Prescription calculation for ${count} medicines`);
                  if (cheapestPlatform?.cheapest?.totalCost) {
                    parts.push(`Estimated lowest total cost is ₹${cheapestPlatform.cheapest.totalCost.toFixed(2)} on ${cheapestPlatform.cheapest.platformName}`);
                  }
                  if (cheapestPlatform && cheapestPlatform.savings > 0) {
                    parts.push(`Total savings up to ₹${cheapestPlatform.savings.toFixed(2)} compared to highest retail price`);
                  }
                  return parts.join('. ');
                })()}
                language={currentLang}
                variant="pill"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  {t.totalMeds[currentLang]}
                </span>
                <span className="text-xl font-black text-slate-900">
                  {t.itemsCount(medicineList.filter((m) => m.name.trim().length > 0).length)}
                </span>
              </div>

              <div className="bg-teal-50 p-4 rounded-2xl border border-teal-200 space-y-1">
                <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
                  {t.estTotalCost[currentLang]}
                </span>
                <span className="text-xl font-black text-teal-950">
                  {cheapestPlatform?.cheapest?.totalCost !== null
                    ? `₹${cheapestPlatform?.cheapest?.totalCost?.toFixed(2)}`
                    : t.priceUnavailable[currentLang]}
                </span>
              </div>

              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-1">
                <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider block">
                  {t.cheapestPlatformLabel[currentLang]}
                </span>
                <span className="text-base font-extrabold text-amber-950 block truncate">
                  {cheapestPlatform?.cheapest?.platformName || 'N/A'}
                </span>
              </div>
            </div>
          </div>

          {/* CHEAPEST PLATFORM HIGHLIGHT CARD */}
          {cheapestPlatform?.cheapest && (
            <motion.div
              initial={{ scale: 0.98 }}
              animate={{ scale: 1 }}
              className="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 p-0.5 rounded-3xl shadow-lg"
            >
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-5 rounded-[22px] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-md">
                    <Trophy className="w-6 h-6 animate-bounce" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-amber-500 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        {t.cheapestPlatformTitle[currentLang]}
                      </span>
                      <span className="text-sm font-black text-amber-950">
                        {cheapestPlatform.cheapest.platformName}
                      </span>
                    </div>
                    <p className="text-lg font-black text-slate-900">
                      {t.totalCostLabel[currentLang]}: ₹{cheapestPlatform.cheapest.totalCost?.toFixed(2)}
                    </p>
                    {cheapestPlatform.savings > 0 && (
                      <p className="text-xs font-extrabold text-emerald-800">
                        {t.savedAmount(cheapestPlatform.savings.toFixed(2))}
                      </p>
                    )}
                  </div>
                </div>

                <a
                  href={cheapestPlatform.cheapest.officialUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-5 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer border border-amber-600/30 whitespace-nowrap"
                >
                  <span>{t.viewOnPlatform(cheapestPlatform.cheapest.platformName)}</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          )}

          {/* MIXED CART ANALYSIS CARD */}
          {mixedCartAnalysis && (
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-4">
              <div className="border-b border-slate-100 pb-3 space-y-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                    <Layers className="w-5 h-5 text-teal-600" />
                    <span>{t.mixedCartTitle[currentLang]}</span>
                  </h3>
                  <span className="px-3 py-1 bg-teal-100 text-teal-800 font-extrabold text-xs rounded-full">
                    {t.mixedCartBadge[currentLang]}
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium">
                  {t.mixedCartSubtitle[currentLang]}
                </p>
              </div>

              {/* MIXED CART MEDICINE BREAKDOWN TABLE */}
              <div className="space-y-3">
                {mixedCartAnalysis.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-xs text-slate-900">
                          {item.medicineName} ({item.strength})
                        </span>
                        <span className="text-[11px] font-bold text-slate-500">
                          x{item.quantity}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 font-medium flex items-center gap-1.5">
                        <span>{t.recommendedPlatform[currentLang]}</span>
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${item.logoBg}`}>
                          {item.recommendedPlatform}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60">
                      {item.totalPrice > 0 ? (
                        <span className="text-sm font-black text-slate-900">
                          ₹{item.totalPrice.toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-xs font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md">
                          {t.priceUnavailable[currentLang]}
                        </span>
                      )}

                      <a
                        href={item.officialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[11px] rounded-xl flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap"
                      >
                        <span>{t.btnView[currentLang]}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}

                {/* MIXED CART TOTAL SAVINGS BANNER */}
                <div className="p-4 bg-teal-50 rounded-2xl border border-teal-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <span className="text-xs font-black text-teal-900">
                      {t.totalMixedCartCost(mixedCartAnalysis.totalMixedCost.toFixed(2))}
                    </span>
                    {mixedCartAnalysis.extraSavings > 0 && (
                      <p className="text-xs font-bold text-emerald-700">
                        {t.extraSavingsNotice(mixedCartAnalysis.extraSavings.toFixed(2))}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ALL PLATFORMS TOTAL ESTIMATED COST LIST */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-4">
            <h3 className="text-base font-black text-slate-900 border-b border-slate-100 pb-3">
              {t.officialComparisonTitle[currentLang]}
            </h3>

            <div className="space-y-3">
              {platformTotals.map((plat) => {
                const isCheapest =
                  cheapestPlatform?.cheapest?.platformId === plat.platformId;

                return (
                  <div
                    key={plat.platformId}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                      isCheapest
                        ? 'bg-amber-50/60 border-amber-300 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl ${plat.logoBg} font-black text-[11px] flex items-center justify-center p-2 text-center shadow-xs shrink-0`}
                      >
                        {plat.platformName}
                      </div>

                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-slate-900">
                            {plat.platformName}
                          </span>
                          {isCheapest && (
                            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full">
                              {t.badgeCheapestTotal[currentLang]}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                          {t.officialPharmacyPortal[currentLang]}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between w-full sm:w-auto gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      {plat.totalCost !== null ? (
                        <div className="text-right">
                          <span className="text-lg font-black text-slate-900 block">
                            ₹{plat.totalCost.toFixed(2)}
                          </span>
                          <span className="text-[10px] font-bold text-emerald-700">
                            {t.verifiedLivePricing[currentLang]}
                          </span>
                        </div>
                      ) : (
                        <div className="text-right">
                          <span className="text-xs font-extrabold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200 inline-block">
                            {t.priceUnavailable[currentLang]}
                          </span>
                        </div>
                      )}

                      <a
                        href={plat.officialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shadow-xs active:scale-95"
                      >
                        <span>{t.viewOnPlatform(plat.platformName)}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Disclaimer */}
            <div className="pt-2">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-500 leading-relaxed font-medium">
                <Info className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <p>{t.buyNotice[currentLang]}</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

