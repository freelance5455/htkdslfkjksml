import React, { useState, useRef } from 'react';
import {
  Bell,
  Volume2,
  Clock,
  Music,
  Play,
  Square,
  Sparkles,
  Upload,
  Check,
  RotateCcw,
  Plus,
  ShieldCheck,
  AlertCircle,
  X,
  Smartphone,
  Eye,
  Power,
  CheckCircle2,
} from 'lucide-react';
import { SalawatReminderSettings, SalawatSoundType, AppTheme } from '../types';

interface SalawatReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SalawatReminderSettings;
  onUpdateSettings: (newSettings: Partial<SalawatReminderSettings>) => void;
  theme: AppTheme;
  secondsUntilNext: number;
  isPlayingPreview: boolean;
  onPreviewSound: (soundType: SalawatSoundType, customUrl?: string) => void;
  onStopPreview: () => void;
  onTestReminder: () => void;
  onIncrementCount: () => void;
  onResetCount: () => void;
  onRequestNotificationPermission: () => Promise<boolean>;
}

const INTERVAL_PRESETS = [
  { label: 'دقيقة (تجربة)', value: 1 },
  { label: '5 دقائق', value: 5 },
  { label: '10 دقائق', value: 10 },
  { label: '15 دقيقة', value: 15 },
  { label: '20 دقيقة', value: 20 },
  { label: '30 دقيقة', value: 30 },
  { label: '45 دقيقة', value: 45 },
  { label: 'ساعة كاملة', value: 60 },
];

export const SalawatReminderModal: React.FC<SalawatReminderModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  theme,
  secondsUntilNext,
  isPlayingPreview,
  onPreviewSound,
  onStopPreview,
  onTestReminder,
  onIncrementCount,
  onResetCount,
  onRequestNotificationPermission,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [notificationStatus, setNotificationStatus] = useState<string>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  if (!isOpen) return null;

  const isDark = theme === 'dark';

  // Format countdown
  const formatCountdown = (totalSec: number) => {
    if (totalSec <= 0) return 'في انتظار الموعد...';
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    if (mins > 0) {
      return `${mins} دقيقة و ${secs} ثانية`;
    }
    return `${secs} ثانية`;
  };

  // Handle custom audio file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      alert('يرجى اختيار ملف صوتي مدعوم (MP3, WAV, M4A, OGG)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onUpdateSettings({
          soundType: 'custom',
          customAudioDataUrl: dataUrl,
          customAudioName: file.name,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRequestPermission = async () => {
    const granted = await onRequestNotificationPermission();
    setNotificationStatus(granted ? 'granted' : 'denied');
  };

  const soundOptions: {
    type: SalawatSoundType;
    title: string;
    description: string;
    badge?: string;
  }[] = [
    {
      type: 'uploaded',
      title: 'الصوت المرفق: اللهم صل على سيدنا محمد وعلى آله وصحبه وسلم',
      description: 'تسجيل خاشع وندي للصيغة الشريفة الكاملة',
      badge: 'الصوت المرفق',
    },
    {
      type: 'mishary',
      title: 'بصوت الشيخ مشاري راشد العفاسي',
      description: 'اللهم صل على سيدنا محمد (نغمة هادئة بدون إيقاع)',
    },
    {
      type: 'chime',
      title: 'نغمة تنبيه هادئة ولطيفة (Chime)',
      description: 'رنين ناعم ينبهك بالصلاة على النبي ﷺ بهدوء',
    },
    {
      type: 'speech',
      title: 'نطق صوتي فصيح (Voice)',
      description: 'قراءة صوتية باللغة العربية الفصحى عبر النظام',
    },
    {
      type: 'custom',
      title: settings.customAudioName ? `ملفك المخصص: ${settings.customAudioName}` : 'رفع ملف صوتي من جهازك',
      description: settings.customAudioDataUrl ? 'ملف صوتي تم حفظه على جهازك' : 'اختر أي ملف صوتي MP3 ترغب به',
    },
  ];

  return (
    <div
      id="salawat-reminder-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="salawat-reminder-modal-content"
        className={`relative w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden my-auto transition-colors ${
          isDark
            ? 'bg-slate-900 border-slate-700/80 text-slate-100 shadow-emerald-950/40'
            : theme === 'parchment'
            ? 'bg-[#fbf7ee] border-amber-300/80 text-amber-950 shadow-amber-900/10'
            : 'bg-white border-slate-200 text-slate-900 shadow-emerald-900/10'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header decoration */}
        <div className="relative px-5 pt-6 pb-4 border-b border-slate-200/70 dark:border-slate-800 bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-emerald-500/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600/15 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0 shadow-sm">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
                  <span>التذكير بالصلاة على النبي</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-normal">ﷺ</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  «مَنْ صَلَّى عَلَيَّ صَلَاةً صَلَّى اللَّهُ عَلَيْهِ بِهَا عَشْرًا»
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal body */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Main Toggle Switch */}
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between gap-4 transition-all ${
              settings.enabled
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-950 dark:text-emerald-100'
                : 'bg-slate-100/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  settings.enabled
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                }`}
              >
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg">تفعيل التذكير الدوري</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  {settings.enabled
                    ? `تنبيه صوتي وبصري كل ${settings.intervalMinutes} دقيقة`
                    : 'التذكير متوقف حالياً'}
                </p>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.enabled}
                onChange={(e) => onUpdateSettings({ enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-13 h-7 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Live Countdown if enabled */}
          {settings.enabled && (
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs sm:text-sm">
              <span className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-medium">
                <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-spin-slow" />
                الموعد القادم للتذكير:
              </span>
              <span className="font-bold text-emerald-700 dark:text-emerald-400 text-sm sm:text-base">
                {formatCountdown(secondsUntilNext)}
              </span>
            </div>
          )}

          {/* Interval Duration Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>تحديد مدة التذكير (بالدقائق)</span>
              </label>
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full">
                كل {settings.intervalMinutes} دقيقة
              </span>
            </div>

            {/* Quick preset chips */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {INTERVAL_PRESETS.map((preset) => {
                const isSelected = settings.intervalMinutes === preset.value;
                return (
                  <button
                    key={preset.value}
                    onClick={() => onUpdateSettings({ intervalMinutes: preset.value })}
                    className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-medium border text-center transition-all ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 scale-[1.02]'
                        : 'border-slate-200 dark:border-slate-700/80 hover:border-emerald-400 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>

            {/* Custom Minutes Input */}
            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs text-slate-500 dark:text-slate-400">أو إدخال مدة مخصصة:</span>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="720"
                  value={settings.intervalMinutes}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val) && val > 0) {
                      onUpdateSettings({ intervalMinutes: val });
                    }
                  }}
                  className="w-20 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-center font-bold text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <span className="text-xs text-slate-500 dark:text-slate-400">دقيقة</span>
              </div>
            </div>
          </div>

          {/* Sound Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold flex items-center gap-2">
                <Music className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>صوت التذكير</span>
              </label>

              {isPlayingPreview && (
                <button
                  onClick={onStopPreview}
                  className="flex items-center gap-1 text-xs text-rose-500 hover:text-rose-600 font-medium px-2 py-0.5 rounded-lg bg-rose-500/10"
                >
                  <Square className="w-3 h-3 fill-current" />
                  إيقاف الاستماع
                </button>
              )}
            </div>

            <div className="space-y-2">
              {soundOptions.map((opt) => {
                const isSelected = settings.soundType === opt.type;
                return (
                  <div
                    key={opt.type}
                    onClick={() => onUpdateSettings({ soundType: opt.type })}
                    className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-500/10 dark:bg-emerald-950/20'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-emerald-600 bg-emerald-600' : 'border-slate-400'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 text-white" />}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100 truncate">
                            {opt.title}
                          </h4>
                          {opt.badge && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                              {opt.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                          {opt.description}
                        </p>
                      </div>
                    </div>

                    {/* Preview / Action button */}
                    <div className="flex items-center gap-2 shrink-0">
                      {opt.type === 'custom' && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            fileInputRef.current?.click();
                          }}
                          className="p-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
                          title="رفع ملف صوتي جديد"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>رفع</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (isPlayingPreview) {
                            onStopPreview();
                          } else {
                            onPreviewSound(opt.type, settings.customAudioDataUrl);
                          }
                        }}
                        className={`p-2 rounded-xl text-xs font-medium transition-colors flex items-center gap-1 ${
                          isSelected
                            ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                        title="استماع ومعاينة"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span className="hidden sm:inline">معاينة</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Hidden file input for custom audio */}
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          {/* Volume Control */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <label className="font-bold flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>مستوى صوت التنبيه</span>
              </label>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                {Math.round(settings.volume * 100)}%
              </span>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={settings.volume}
                onChange={(e) => onUpdateSettings({ volume: parseFloat(e.target.value) })}
                className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
              />
            </div>
          </div>

          {/* Advanced / Smart Options */}
          <div className="space-y-4 pt-2 border-t border-slate-200/70 dark:border-slate-800">
            {/* Background Mode & Screen Lock Persistence */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                      <span>العمل في الخلفية والشاشة مغلقة</span>
                      <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold">
                        موصى به للأندرويد
                      </span>
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      يُبقي التذكير الصوتي والإشعارات تعمل بدون توقف حتى لو أغلقت شاشة الهاتف
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.backgroundMode ?? true}
                    onChange={(e) => onUpdateSettings({ backgroundMode: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Persistent Sticky Notification */}
              <div className="pt-2 border-t border-emerald-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      إشعار دائم عالي الأولوية (تثبيت التنبيه في شريط الإشعارات)
                    </span>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      يمنع نظام أندرويد من إيقاف التطبيق لتوفير البطارية ويوفر زراً للصلاة بنقرة واحدة
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.persistentNotification ?? true}
                    onChange={(e) => onUpdateSettings({ persistentNotification: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Keep Screen Awake Toggle */}
              <div className="pt-2 border-t border-emerald-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      إبقاء الشاشة مضاءة أثناء القراءة (Wake Lock)
                    </span>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      يمنع الشاشة من الإغلاق التلقائي أثناء قراءة القرآن الكريم
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.keepScreenAwakeDuringReading ?? false}
                    onChange={(e) => onUpdateSettings({ keepScreenAwakeDuringReading: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>

            {/* Android System Battery Exemption Tip */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                <span>نصيحة هامة لنظام أندرويد لضمان عدم التوقف نهائياً:</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300 pr-5">
                في إعدادات هاتفك للأندرويد: افتح <strong>إعدادات التطبيق (App Info)</strong> ⭢ ثم <strong>البطارية (Battery)</strong> ⭢ واختر <strong>«غير مقيد / Unrestricted»</strong> حتى لا يقوم نظام أندرويد بإغلاق الخدمة لتوفير البطارية.
              </p>
            </div>

            {/* Pause during Quran recitation */}
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={settings.pauseDuringQuranRecitation}
                onChange={(e) => onUpdateSettings({ pauseDuringQuranRecitation: e.target.checked })}
                className="mt-1 w-4 h-4 rounded text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
              />
              <div>
                <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  عدم التنبيه أثناء الاستماع لتلاوة القرآن
                </span>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  يؤجل التنبيه تلقائياً حتى تتوقف التلاوة احتراماً لسماع آيات الله
                </p>
              </div>
            </label>

            {/* System Notifications */}
            <div className="flex items-start justify-between gap-3">
              <label className="flex items-start gap-3 cursor-pointer select-none flex-1">
                <input
                  type="checkbox"
                  checked={settings.showNotification}
                  onChange={(e) => onUpdateSettings({ showNotification: e.target.checked })}
                  className="mt-1 w-4 h-4 rounded text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                    إشعارات المتصفح والنظام
                  </span>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    ظهور إشعار الصلاة على النبي على شاشة القفل وفي شريط التنبيهات
                  </p>
                </div>
              </label>

              {notificationStatus !== 'granted' ? (
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="shrink-0 text-xs px-2.5 py-1 rounded-lg border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/10 font-bold transition-colors"
                >
                  منح الإذن الآن
                </button>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  الإذن مفعّل
                </span>
              )}
            </div>
          </div>

          {/* Salawat Counter / سبحة الصلوات */}
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
              isDark
                ? 'bg-slate-800/60 border-slate-700'
                : 'bg-emerald-50/60 border-emerald-200/70'
            }`}
          >
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                سبحة الصلوات على النبي ﷺ
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-2xl sm:text-3xl font-bold text-emerald-600 dark:text-emerald-400">
                  {settings.count || 0}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">صلاة مسجلة</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onIncrementCount}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1 shadow-sm active:scale-95 transition-all"
                title="إضافة صلاة (+1)"
              >
                <Plus className="w-4 h-4" />
                <span>صلاة (+1)</span>
              </button>

              <button
                type="button"
                onClick={onResetCount}
                className="p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="تصفير العداد"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 sm:p-5 border-t border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/50">
          <button
            type="button"
            onClick={onTestReminder}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/10 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>تجربة التنبيه الآن</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-colors"
          >
            حفظ وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
