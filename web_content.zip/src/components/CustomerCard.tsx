import React, { useState } from 'react';
import { Phone, MessageCircle, Calendar, RefreshCw, Edit, Trash2, MapPin, Clock, AlertTriangle, Bell, Check } from 'lucide-react';
import { Customer, Folder } from '../types';
import { computeCustomerReminder, getReminderBadge } from '../utils/dateUtils';
import { alarmAudio } from '../utils/audioAlarm';

interface CustomerCardProps {
  customer: Customer;
  folder?: Folder;
  onEdit: (customer: Customer) => void;
  onDelete: (customer: Customer) => void;
  onRenewDealDate: (customer: Customer) => void;
}

export const CustomerCard: React.FC<CustomerCardProps> = ({
  customer,
  folder,
  onEdit,
  onDelete,
  onRenewDealDate,
}) => {
  const [justRenewed, setJustRenewed] = useState(false);
  const info = computeCustomerReminder(customer);
  const badge = getReminderBadge(info);

  const cleanPhone = customer.phone ? customer.phone.replace(/[^0-9+]/g, '') : '';
  const waPhone = cleanPhone.startsWith('91') || cleanPhone.startsWith('+91')
    ? cleanPhone.replace('+', '')
    : `91${cleanPhone}`;

  const defaultWaMessage = encodeURIComponent(
    `नमस्ते ${customer.name} जी! आपकी पिछली गैस सिलेंडर डिलीवरी/डील को 25 दिन हो चुके हैं। क्या आपको नए गैस सिलेंडर की आवश्यकता है? कृपया सूचित करें।`
  );

  const handleRenewClick = () => {
    alarmAudio.playChime();
    setJustRenewed(true);
    onRenewDealDate(customer);
    setTimeout(() => setJustRenewed(false), 2000);
  };

  return (
    <div
      className={`rounded-2xl border p-4 sm:p-5 shadow-xs transition-all ${badge.bgLightClass} ${badge.borderClass} relative`}
    >
      {/* Top Header: Name and Status Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
              {customer.name}
            </h3>
            {folder && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-800">
                <MapPin className="w-3 h-3 text-orange-600" />
                {folder.name}
              </span>
            )}
          </div>
        </div>

        {/* 26th-Day Status Badge */}
        <div className="self-start sm:self-auto">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs shadow-xs ${badge.badgeClass}`}
          >
            {badge.text}
          </span>
        </div>
      </div>

      {/* Customer Info: Phone & Address */}
      <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-slate-700">
        <div className="flex items-center gap-2 font-medium">
          <Phone className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold text-slate-900 tracking-wide">
            {customer.phone || 'मोबाइल नंबर नहीं दिया'}
          </span>
        </div>

        <div className="flex items-start gap-2">
          <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <span className="text-xs sm:text-sm text-slate-600 line-clamp-2">
            {customer.address || 'पता दर्ज नहीं'}
          </span>
        </div>
      </div>

      {/* Notes if provided */}
      {customer.notes && (
        <div className="mt-2 text-xs bg-slate-100/90 text-slate-700 px-2.5 py-1.5 rounded-lg border border-slate-200">
          <strong className="text-slate-800">टिप्पणी:</strong> {customer.notes}
        </div>
      )}

      {/* Dates Section: Deal Date vs 26th Day Reminder */}
      <div className="mt-3.5 pt-3 border-t border-slate-200/80 grid grid-cols-2 gap-2 text-xs">
        <div className="bg-white/80 p-2 rounded-xl border border-slate-200">
          <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>डील / पुष्टि तारीख:</span>
          </div>
          <div className="mt-0.5 font-bold text-slate-800 text-xs sm:text-sm">
            {info.formattedDealDate}
          </div>
        </div>

        <div
          className={`p-2 rounded-xl border ${
            info.status === 'today'
              ? 'bg-amber-100/80 border-amber-300'
              : info.status === 'overdue'
              ? 'bg-rose-100/80 border-rose-300'
              : 'bg-white/80 border-slate-200'
          }`}
        >
          <div className="text-[11px] text-slate-600 font-medium flex items-center gap-1">
            {info.status === 'today' ? (
              <Bell className="w-3.5 h-3.5 text-amber-700" />
            ) : info.status === 'overdue' ? (
              <AlertTriangle className="w-3.5 h-3.5 text-rose-700" />
            ) : (
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
            )}
            <span>26वां दिन रिमाइंडर:</span>
          </div>
          <div
            className={`mt-0.5 font-extrabold text-xs sm:text-sm ${
              info.status === 'today'
                ? 'text-amber-900'
                : info.status === 'overdue'
                ? 'text-rose-900'
                : 'text-emerald-800'
            }`}
          >
            {info.formattedReminderDate}
          </div>
          <div className="text-[10px] text-slate-500 font-medium">सुबह 9:00 बजे</div>
        </div>
      </div>

      {/* Bottom Large Action Buttons: Call, WhatsApp, Renew Today, Edit, Delete */}
      <div className="mt-4 pt-2.5 flex items-center justify-between gap-2 flex-wrap">
        {/* Contact actions */}
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          {/* Direct Call Button */}
          {cleanPhone ? (
            <a
              href={`tel:${cleanPhone}`}
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-xs transition active:scale-95 text-center"
            >
              <Phone className="w-4 h-4" />
              <span>कॉल करें</span>
            </a>
          ) : (
            <button
              disabled
              className="flex-1 py-2 px-3 rounded-xl bg-slate-200 text-slate-400 font-bold text-xs cursor-not-allowed"
            >
              नंबर नहीं
            </button>
          )}

          {/* Direct WhatsApp Button */}
          {cleanPhone ? (
            <a
              href={`https://wa.me/${waPhone}?text=${defaultWaMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-green-500 hover:bg-green-600 text-white font-bold text-xs sm:text-sm shadow-xs transition active:scale-95 text-center"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>
          ) : null}
        </div>

        {/* Quick Renew Button & Record Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Renew Deal to Today (Sets deal date to today, recalculating 25 days) */}
          <button
            onClick={handleRenewClick}
            title="आज नया सिलेंडर दिया (डील तारीख आज करें)"
            className={`inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer shadow-xs ${
              justRenewed
                ? 'bg-emerald-600 text-white'
                : 'bg-orange-600 hover:bg-orange-700 text-white'
            }`}
          >
            {justRenewed ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>तारीख आज की गई!</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>आज नई डील</span>
              </>
            )}
          </button>

          {/* Edit */}
          <button
            onClick={() => onEdit(customer)}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition active:scale-95 cursor-pointer"
            title="रिकॉर्ड बदलें"
          >
            <Edit className="w-4 h-4" />
          </button>

          {/* Delete */}
          <button
            onClick={() => onDelete(customer)}
            className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition active:scale-95 cursor-pointer"
            title="ग्राहक हटाएं"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
