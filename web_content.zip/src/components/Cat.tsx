import type { AccessoryItem, FurStyle } from "../data/catalog";

export type Mood = "normal" | "happy" | "sleep";

interface CatProps {
  mood: Mood;
  hat?: AccessoryItem | null;
  bow?: AccessoryItem | null;
  collar?: AccessoryItem | null;
  fur?: FurStyle;
  eyeColor?: string;
  eating?: boolean;
  excited?: boolean;
}

export const DEFAULT_FUR: FurStyle = {
  id: "pelaje-0-0",
  name: "Negro Ónix Liso",
  desc: "",
  hex: "#262632",
  hex2: "#434355",
  pattern: "liso",
};

const OUTLINE = "#101019";
const INNER_EAR = "#f9a8d4";

function Eyes({ mood, color }: { mood: Mood; color: string }) {
  if (mood === "sleep") {
    return (
      <g stroke="#0b0b12" strokeWidth="4.5" strokeLinecap="round" fill="none" opacity="0.85">
        <path d="M114 118 Q131 128 148 118" />
        <path d="M172 118 Q189 128 206 118" />
      </g>
    );
  }
  if (mood === "happy") {
    return (
      <g stroke="#0b0b12" strokeWidth="5" strokeLinecap="round" fill="none" opacity="0.85">
        <path d="M113 122 Q131 104 149 122" />
        <path d="M171 122 Q189 104 207 122" />
      </g>
    );
  }
  return (
    <g className="cat-eyes">
      {[131, 189].map((cx) => (
        <g key={cx}>
          <ellipse cx={cx} cy={117} rx="12.5" ry="15.5" fill={color} />
          <ellipse cx={cx} cy={121} rx="12.5" ry="11" fill="#000000" opacity="0.22" />
          <ellipse cx={cx} cy={117} rx="5" ry="10.5" fill="#07130d" />
          <circle cx={cx - 3.5} cy={110} r="3.4" fill="#ffffff" />
          <circle cx={cx + 3.5} cy={123} r="1.7" fill="#ffffff" opacity="0.8" />
        </g>
      ))}
    </g>
  );
}

/* ---------- Pattern overlays (head + body share geometry helpers) ---------- */
function PatternMarks({ fur, area }: { fur: FurStyle; area: "head" | "body" }) {
  const c = fur.hex2;
  if (area === "head") {
    switch (fur.pattern) {
      case "rayas":
        return <g stroke={c} strokeWidth="5" strokeLinecap="round" opacity="0.55"><path d="M138 66 v12 M160 60 v14 M182 66 v12" /></g>;
      case "manchas":
        return <g fill={c} opacity="0.5"><circle cx="118" cy="86" r="9" /><circle cx="204" cy="76" r="7" /><circle cx="196" cy="150" r="6" /></g>;
      case "carey":
        return <g fill={c} opacity="0.55"><path d="M104 92 q14 -22 34 -12 q-6 20 -34 12Z" /><path d="M196 62 q20 4 16 26 q-18 -2 -16 -26Z" /></g>;
      case "estrellas":
        return <g fill="#ffffff" opacity="0.75"><path d="M118 78 l2 4.4 4.8.6 -3.6 3.3 1 4.7 -4.2 -2.4 -4.2 2.4 1 -4.7 -3.6 -3.3 4.8 -.6Z" /><path d="M198 96 l1.6 3.5 3.8.5 -2.9 2.6.8 3.8 -3.3 -1.9 -3.3 1.9.8 -3.8 -2.9 -2.6 3.8 -.5Z" /></g>;
      case "corazones":
        return <g fill="#f9a8d4" opacity="0.8"><path d="M120 92 c-6 -7 -16 1 -8 9 l8 6 8 -6 c8 -8 -2 -16 -8 -9Z" /><path d="M202 84 c-4.4 -5 -11.6.8 -5.8 6.6 l5.8 4.4 5.8 -4.4 c5.8 -5.8 -1.4 -11.6 -5.8 -6.6Z" /></g>;
      case "marmol":
        return <g stroke="#ffffff" strokeWidth="3" fill="none" opacity="0.35" strokeLinecap="round"><path d="M110 84 q14 -10 26 0 q12 10 24 0" /><path d="M120 158 q16 8 32 0" /></g>;
      default:
        return null;
    }
  }
  switch (fur.pattern) {
    case "rayas":
      return <g stroke={c} strokeWidth="6" strokeLinecap="round" opacity="0.5"><path d="M96 208 v20 M92 240 v18 M224 208 v20 M228 240 v18" /></g>;
    case "manchas":
      return <g fill={c} opacity="0.45"><circle cx="106" cy="222" r="12" /><circle cx="216" cy="238" r="10" /><circle cx="128" cy="262" r="8" /></g>;
    case "carey":
      return <g fill={c} opacity="0.5"><path d="M92 214 q20 -14 34 2 q-8 18 -34 -2Z" /><path d="M196 258 q22 -6 30 12 q-16 12 -30 -12Z" /></g>;
    case "estrellas":
      return <g fill="#ffffff" opacity="0.7"><path d="M108 226 l2.2 4.8 5.2.6 -3.9 3.6 1.1 5.1 -4.6 -2.6 -4.6 2.6 1.1 -5.1 -3.9 -3.6 5.2 -.6Z" /><path d="M208 214 l1.8 3.9 4.2.5 -3.2 2.9.9 4.1 -3.7 -2.1 -3.7 2.1.9 -4.1 -3.2 -2.9 4.2 -.5Z" /></g>;
    case "corazones":
      return <g fill="#f9a8d4" opacity="0.75"><path d="M112 240 c-6 -7 -16 1 -8 9 l8 6 8 -6 c8 -8 -2 -16 -8 -9Z" /><path d="M206 252 c-4.4 -5 -11.6.8 -5.8 6.6 l5.8 4.4 5.8 -4.4 c5.8 -5.8 -1.4 -11.6 -5.8 -6.6Z" /></g>;
    case "marmol":
      return <g stroke="#ffffff" strokeWidth="3.5" fill="none" opacity="0.3" strokeLinecap="round"><path d="M96 224 q20 -12 40 0 q20 12 40 0 q20 -12 44 2" /></g>;
    default:
      return null;
  }
}

/* ---------- Hats: 10 formas modulares ---------- */
function HatShape({ item }: { item: AccessoryItem }) {
  const p = item.primary;
  const s = item.secondary;
  return (
    <g transform="translate(160 54)">
      {item.style === "bruja" && (
        <g>
          <path d="M-36 6 C-24 -34 -8 -58 16 -88 C24 -60 30 -28 38 6 Z" fill={p} stroke="rgba(0,0,0,0.35)" strokeWidth="2.5" />
          <circle cx="16" cy="-88" r="6" fill={s} />
          <path d="M-34 8 L36 8 L31 -8 L-30 -8 Z" fill={s} />
          <ellipse cx="0" cy="10" rx="57" ry="11" fill={p} stroke="rgba(0,0,0,0.4)" strokeWidth="2.5" />
        </g>
      )}
      {item.style === "corona" && (
        <g>
          <path d="M-42 10 L-42 -18 L-24 -3 L-12 -28 L0 -5 L12 -28 L24 -3 L42 -18 L42 10 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.5" strokeLinejoin="round" />
          <rect x="-42" y="8" width="84" height="9" rx="4" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="2" />
          <circle cx="-21" cy="-4" r="4.2" fill="#f472b6" /><circle cx="0" cy="-11" r="4.6" fill="#6ee7b7" /><circle cx="21" cy="-4" r="4.2" fill="#c4b5fd" />
        </g>
      )}
      {item.style === "gorro" && (
        <g>
          <path d="M-48 8 A48 42 0 0 1 48 8 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.5" />
          <circle cx="0" cy="-46" r="10" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="2" />
          <rect x="-48" y="2" width="96" height="14" rx="7" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="2" />
          <path d="M0 -26 l3.4 7 7.6.9 -5.6 5.2 1.5 7.5 -6.9 -3.8 -6.9 3.8 1.5 -7.5 -5.6 -5.2 7.6 -.9 Z" fill="#f5c451" stroke="rgba(0,0,0,0.3)" strokeWidth="1.2" />
        </g>
      )}
      {item.style === "diadema" && (
        <g>
          <path d="M-54 8 A56 50 0 0 1 54 8" fill="none" stroke={p} strokeWidth="7" strokeLinecap="round" />
          <g transform="translate(46 -22)"><path d="M4 -10 A11 11 0 1 0 4 10 A8.6 8.6 0 1 1 4 -10 Z" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="1.2" /></g>
          <path d="M-38 -30 l1.8 3.8 4.2.5 -3.1 2.8.9 4.1 -3.7 -2.1 -3.7 2.1.9 -4.1 -3.1 -2.8 4.2 -.5 Z" fill={s} />
        </g>
      )}
      {item.style === "copa" && (
        <g>
          <rect x="-30" y="-52" width="60" height="56" rx="5" fill={p} stroke="rgba(0,0,0,0.35)" strokeWidth="2.5" />
          <rect x="-30" y="-14" width="60" height="13" fill={s} />
          <ellipse cx="0" cy="6" rx="58" ry="10" fill={p} stroke="rgba(0,0,0,0.4)" strokeWidth="2.5" />
          <ellipse cx="0" cy="-52" rx="30" ry="6" fill={s} opacity="0.7" />
        </g>
      )}
      {item.style === "boina" && (
        <g transform="rotate(-8)">
          <ellipse cx="0" cy="-6" rx="52" ry="17" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.5" />
          <rect x="-3" y="-28" width="6" height="10" rx="3" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="1.5" />
          <circle cx="26" cy="-8" r="4" fill={s} />
        </g>
      )}
      {item.style === "gorra" && (
        <g>
          <path d="M-46 6 A46 38 0 0 1 46 6 Z" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.5" />
          <path d="M-46 6 Q0 20 66 8 Q30 -6 -46 6Z" fill={s} stroke="rgba(0,0,0,0.3)" strokeWidth="2.2" />
          <circle cx="0" cy="-32" r="5" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="1.5" />
        </g>
      )}
      {item.style === "flores" && (
        <g>
          <path d="M-52 4 A54 48 0 0 1 52 4" fill="none" stroke="#4d7c0f" strokeWidth="5" strokeLinecap="round" />
          {[-40, -20, 0, 20, 40].map((x, i) => (
            <g key={x} transform={`translate(${x} ${-26 - Math.abs(20 - i * 10) + (i === 2 ? -6 : 0)})`}>
              {[0, 72, 144, 216, 288].map((a) => (
                <circle key={a} cx={Math.cos((a * Math.PI) / 180) * 6} cy={Math.sin((a * Math.PI) / 180) * 6} r="5" fill={i % 2 ? s : p} stroke="rgba(0,0,0,0.2)" strokeWidth="1" />
              ))}
              <circle r="3.4" fill="#f5c451" />
            </g>
          ))}
        </g>
      )}
      {item.style === "halo" && (
        <g>
          <ellipse cx="0" cy="-34" rx="34" ry="9" fill="none" stroke={p} strokeWidth="6" opacity="0.95" />
          <ellipse cx="0" cy="-34" rx="34" ry="9" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.5" />
        </g>
      )}
      {item.style === "conejo" && (
        <g>
          <g transform="translate(-24 -18) rotate(-10)">
            <ellipse cx="0" cy="-26" rx="11" ry="30" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.2" />
            <ellipse cx="0" cy="-24" rx="5.5" ry="20" fill={s} />
          </g>
          <g transform="translate(24 -18) rotate(10)">
            <ellipse cx="0" cy="-26" rx="11" ry="30" fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2.2" />
            <ellipse cx="0" cy="-24" rx="5.5" ry="20" fill={s} />
          </g>
        </g>
      )}
    </g>
  );
}

/* ---------- Bows: 10 estilos modulares ---------- */
function BowShape({ item }: { item: AccessoryItem }) {
  const p = item.primary;
  const s = item.secondary;
  const scale = item.style === "grande" ? 1.35 : item.style === "mini" ? 0.68 : 1;
  const tail = item.style === "lazo" ? 26 : 12;
  const wing = item.style === "mariposa";
  const one = (sign: number) => (
    <g key={sign}>
      <path d={wing ? `M${4 * sign} 0 L${36 * sign} -20 Q${42 * sign} 2 ${34 * sign} 18 Z` : `M${4 * sign} 0 L${31 * sign} -16 Q${38 * sign} 0 ${31 * sign} 16 Z`} fill={p} stroke="rgba(0,0,0,0.3)" strokeWidth="2" strokeLinejoin="round" />
      <path d={`M${10 * sign} 6 L${16 * sign} ${tail + 12} L${8 * sign} ${tail + 7} L${3 * sign} ${tail + 13} L0 8 Z`} fill={p} stroke="rgba(0,0,0,0.22)" strokeWidth="1.5" strokeLinejoin="round" />
    </g>
  );
  return (
    <g transform={`translate(219 50) rotate(18) scale(${scale})`}>
      {one(-1)}
      {one(1)}
      {item.style === "doble" && <g transform="translate(0 -13) scale(0.72)">{one(-1)}{one(1)}</g>}
      {item.style === "pompon" && <circle cx="0" cy="0" r="11" fill={s} stroke="rgba(0,0,0,0.25)" strokeWidth="2" />}
      {item.style !== "pompon" && item.style !== "estrella" && item.style !== "corazon" && item.style !== "flor" && (
        <circle cx="0" cy="0" r="8" fill={s} stroke="rgba(0,0,0,0.28)" strokeWidth="2" />
      )}
      {item.style === "estrella" && <path d="M0 -10 l2.9 6.2 6.8.8 -5 4.6 1.3 6.7 -6 -3.4 -6 3.4 1.3 -6.7 -5 -4.6 6.8 -.8Z" fill={s} stroke="rgba(0,0,0,0.3)" strokeWidth="1.4" strokeLinejoin="round" />}
      {item.style === "corazon" && <path d="M0 9 C-11 1 -8.5 -9 0 -4.5 C8.5 -9 11 1 0 9Z" fill={s} stroke="rgba(0,0,0,0.28)" strokeWidth="1.4" strokeLinejoin="round" />}
      {item.style === "flor" && (
        <g>
          {[0, 72, 144, 216, 288].map((a) => (
            <circle key={a} cx={Math.cos((a * Math.PI) / 180) * 6} cy={Math.sin((a * Math.PI) / 180) * 6} r="5" fill={s} stroke="rgba(0,0,0,0.22)" strokeWidth="1" />
          ))}
          <circle r="3.2" fill="#f5c451" />
        </g>
      )}
      <circle cx="-2" cy="-2" r="2" fill="#ffffff" opacity="0.7" />
    </g>
  );
}

/* ---------- Collar charms: 10 dijes ---------- */
export function CharmShape({ charm, color }: { charm: string; color: string }) {
  switch (charm) {
    case "bell":
      return (<g><circle r="9.5" fill="#f5c451" stroke="#a16207" strokeWidth="2" /><rect x="-9.5" y="-3.5" width="19" height="4" fill="#a16207" opacity="0.6" /><circle cx="0" cy="4" r="2.1" fill="#713f12" /></g>);
    case "bellSilver":
      return (<g><circle r="9.5" fill="#e5e7eb" stroke="#9ca3af" strokeWidth="2" /><rect x="-9.5" y="-3.5" width="19" height="4" fill="#9ca3af" opacity="0.7" /><circle cx="0" cy="4" r="2.1" fill="#6b7280" /></g>);
    case "moon":
      return <path d="M4 -9.5 A10.5 10.5 0 1 0 4 9.5 A8.2 8.2 0 1 1 4 -9.5 Z" fill="#f5c451" stroke="#d97706" strokeWidth="1.2" />;
    case "star":
      return <path d="M0 -10 l2.9 6.2 6.8.8 -5 4.6 1.3 6.7 -6 -3.4 -6 3.4 1.3 -6.7 -5 -4.6 6.8 -.8Z" fill="#fde68a" stroke="#d97706" strokeWidth="1.3" strokeLinejoin="round" />;
    case "heart":
      return <path d="M0 10 C-12 1 -9.5 -10 0 -5 C9.5 -10 12 1 0 10Z" fill="#fda4af" stroke="#e11d63" strokeWidth="1.5" strokeLinejoin="round" />;
    case "fish":
      return (<g><path d="M-11 0 Q0 -8 8 0 Q0 8 -11 0Z" fill="#7dd3fc" stroke="#0284c7" strokeWidth="1.4" /><path d="M8 0 L14 -5 L14 5Z" fill="#38bdf8" stroke="#0284c7" strokeWidth="1.2" /><circle cx="-5" cy="-1" r="1.6" fill="#082f49" /></g>);
    case "gemPink":
      return <path d="M0 -10 L8 -3 L0 11 L-8 -3Z" fill="#f9a8d4" stroke="#db2777" strokeWidth="1.4" strokeLinejoin="round" />;
    case "gemBlue":
      return <path d="M0 -10 L8 -3 L0 11 L-8 -3Z" fill="#93c5fd" stroke="#2563eb" strokeWidth="1.4" strokeLinejoin="round" />;
    case "flower":
      return (<g>{[0, 72, 144, 216, 288].map((a) => (<circle key={a} cx={Math.cos((a * Math.PI) / 180) * 5.5} cy={Math.sin((a * Math.PI) / 180) * 5.5} r="4.6" fill={color} stroke="rgba(0,0,0,0.2)" strokeWidth="0.8" />))}<circle r="3" fill="#f5c451" /></g>);
    case "paw":
      return (<g fill={color}><ellipse cx="0" cy="3" rx="6" ry="5" /><circle cx="-7" cy="-3" r="2.4" /><circle cx="-2.4" cy="-5.4" r="2.4" /><circle cx="2.4" cy="-5.4" r="2.4" /><circle cx="7" cy="-3" r="2.4" /></g>);
    default:
      return <circle r="6" fill={color} />;
  }
}

function CollarShape({ item }: { item: AccessoryItem }) {
  return (
    <g>
      <path d="M99 166 Q160 203 221 166" fill="none" stroke={item.primary} strokeWidth="11" strokeLinecap="round" />
      <path d="M99 163 Q160 200 221 163" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" opacity="0.25" />
      <g transform="translate(160 196)">
        <CharmShape charm={item.charm ?? "bell"} color={item.primary} />
      </g>
    </g>
  );
}

export default function Cat({ mood, hat, bow, collar, fur = DEFAULT_FUR, eyeColor = "#10b981", eating, excited }: CatProps) {
  const furFill = fur.pattern === "degradado" ? "url(#furGrad)" : fur.hex;
  const points = fur.pattern === "puntas";
  return (
    <svg viewBox="0 0 320 330" xmlns="http://www.w3.org/2000/svg" className="h-auto w-full drop-shadow-[0_10px_24px_rgba(0,0,0,0.45)]" role="img" aria-label="Gatita mágica">
      <defs>
        <linearGradient id="furGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={fur.hex} />
          <stop offset="100%" stopColor={fur.hex2} />
        </linearGradient>
      </defs>

      {/* Tail */}
      <g className={`cat-tail ${excited ? "cat-tail-fast" : ""}`}>
        <path d="M236 268 C 294 262 314 212 297 158" fill="none" stroke={OUTLINE} strokeWidth="30" strokeLinecap="round" />
        <path d="M236 268 C 294 262 314 212 297 158" fill="none" stroke={furFill} strokeWidth="24" strokeLinecap="round" />
        <circle cx="297" cy="158" r="12" fill={points ? fur.hex2 : fur.hex} />
        {fur.pattern === "rayas" && (
          <g stroke={fur.hex2} strokeWidth="5" opacity="0.55" strokeLinecap="round">
            <path d="M292 182 l14 4 M300 208 l13 6" />
          </g>
        )}
      </g>

      {/* Body */}
      <g className="cat-breathe">
        <ellipse cx="93" cy="256" rx="29" ry="42" fill={furFill} stroke={OUTLINE} strokeWidth="2.5" />
        <ellipse cx="227" cy="256" rx="29" ry="42" fill={furFill} stroke={OUTLINE} strokeWidth="2.5" />
        <ellipse cx="160" cy="234" rx="81" ry="66" fill={furFill} stroke={OUTLINE} strokeWidth="2.5" />
        {/* belly */}
        <ellipse cx="160" cy="246" rx="41" ry="47" fill={fur.pattern === "bicolor" ? "#fdfbf7" : fur.hex2} opacity={fur.pattern === "bicolor" ? 0.95 : 0.4} />
        <PatternMarks fur={fur} area="body" />
        {/* Golden crescent moon ON THE CHEST (moved from the forehead) */}
        <g transform="translate(160 226)">
          <circle r="10.5" fill="#f5c451" />
          <circle cx="4.5" cy="-3" r="8.6" fill={fur.pattern === "bicolor" ? "#fdfbf7" : fur.hex} opacity={fur.pattern === "degradado" ? 0 : 1} />
          {fur.pattern === "degradado" && <circle cx="4.5" cy="-3" r="8.6" fill={fur.hex2} />}
          <circle cx="-6" cy="6" r="1.4" fill="#fff7d6" />
        </g>
        {/* Paws */}
        <g>
          <ellipse cx="124" cy="296" rx="21" ry="11" fill={points || fur.pattern === "bicolor" ? (fur.pattern === "bicolor" ? "#fdfbf7" : fur.hex2) : fur.hex} stroke={OUTLINE} strokeWidth="2.5" />
          <ellipse cx="196" cy="296" rx="21" ry="11" fill={points || fur.pattern === "bicolor" ? (fur.pattern === "bicolor" ? "#fdfbf7" : fur.hex2) : fur.hex} stroke={OUTLINE} strokeWidth="2.5" />
          <path d="M118 289 v8 M130 289 v8" stroke={OUTLINE} strokeWidth="2" strokeLinecap="round" opacity="0.6" />
          <path d="M190 289 v8 M202 289 v8" stroke={OUTLINE} strokeWidth="2" strokeLinecap="round" opacity="0.6" />
        </g>
      </g>

      {collar && <CollarShape item={collar} />}

      {/* Head */}
      <g className={eating ? "cat-head-eat" : undefined}>
        <g className="cat-ear cat-ear-l">
          <polygon points="104,86 90,24 148,52" fill={points ? fur.hex2 : fur.hex} stroke={OUTLINE} strokeWidth="2.5" strokeLinejoin="round" />
          <polygon points="107,72 101,38 133,55" fill={INNER_EAR} opacity="0.85" />
        </g>
        <g className="cat-ear cat-ear-r">
          <polygon points="216,86 230,24 172,52" fill={points ? fur.hex2 : fur.hex} stroke={OUTLINE} strokeWidth="2.5" strokeLinejoin="round" />
          <polygon points="213,72 219,38 187,55" fill={INNER_EAR} opacity="0.85" />
        </g>

        <circle cx="160" cy="118" r="63" fill={furFill} stroke={OUTLINE} strokeWidth="2.5" />
        <path d="M136 64 Q146 42 159 57 Q169 40 181 61 Q168 51 160 67 Q149 51 136 64 Z" fill={fur.hex} />
        {fur.pattern === "bicolor" && <ellipse cx="160" cy="146" rx="20" ry="14" fill="#fdfbf7" opacity="0.9" />}
        <PatternMarks fur={fur} area="head" />

        <Eyes mood={mood} color={eyeColor} />

        <ellipse cx="102" cy="143" rx="11" ry="6.5" fill="#f472b6" opacity={mood === "happy" ? 0.75 : 0.45} />
        <ellipse cx="218" cy="143" rx="11" ry="6.5" fill="#f472b6" opacity={mood === "happy" ? 0.75 : 0.45} />

        <path d="M151.5 137 Q160 133 168.5 137 Q166.5 147.5 160 148.5 Q153.5 147.5 151.5 137 Z" fill="#f472b6" />
        {mood === "happy" ? (
          <g>
            <ellipse cx="160" cy="157" rx="7" ry="5.5" fill="#5b1220" />
            <ellipse cx="160" cy="159.5" rx="4.4" ry="2.8" fill="#fb7185" />
          </g>
        ) : (
          <path d="M160 148.5 Q159.5 155.5 151.5 155.5 M160 148.5 Q160.5 155.5 168.5 155.5" fill="none" stroke="#0b0b12" strokeWidth="2.4" strokeLinecap="round" opacity="0.55" />
        )}

        <g stroke="#ffffff" strokeWidth="2" strokeLinecap="round" opacity="0.35">
          <path d="M96 132 L58 124" /><path d="M97 144 L60 146" />
          <path d="M224 132 L262 124" /><path d="M223 144 L260 146" />
        </g>

        {hat && <HatShape item={hat} />}
        {bow && <BowShape item={bow} />}
      </g>
    </svg>
  );
}

/* Small round avatar used in the album and lists */
export function CatAvatar({ fur, eyeColor, size = 56 }: { fur: FurStyle; eyeColor: string; size?: number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden>
      <polygon points="26,38 20,10 48,24" fill={fur.hex} stroke={OUTLINE} strokeWidth="3" strokeLinejoin="round" />
      <polygon points="74,38 80,10 52,24" fill={fur.hex} stroke={OUTLINE} strokeWidth="3" strokeLinejoin="round" />
      <circle cx="50" cy="56" r="34" fill={fur.hex} stroke={OUTLINE} strokeWidth="3" />
      {fur.pattern === "rayas" && <g stroke={fur.hex2} strokeWidth="4" strokeLinecap="round" opacity="0.6"><path d="M40 28 v8 M50 25 v9 M60 28 v8" /></g>}
      {fur.pattern === "manchas" && <g fill={fur.hex2} opacity="0.55"><circle cx="30" cy="44" r="6" /><circle cx="70" cy="38" r="5" /></g>}
      {fur.pattern === "bicolor" && <ellipse cx="50" cy="76" rx="13" ry="9" fill="#fdfbf7" />}
      {fur.pattern === "estrellas" && <path d="M32 36 l1.8 3.9 4.2.5 -3.1 2.9.8 4.2 -3.7 -2.1 -3.7 2.1.8 -4.2 -3.1 -2.9 4.2 -.5Z" fill="#fff" opacity="0.8" />}
      <circle cx="38" cy="56" r="5.4" fill={eyeColor} />
      <circle cx="62" cy="56" r="5.4" fill={eyeColor} />
      <circle cx="38" cy="56" r="2.4" fill="#07130d" />
      <circle cx="62" cy="56" r="2.4" fill="#07130d" />
      <path d="M46 68 Q50 66 54 68 Q53 72 50 72.6 Q47 72 46 68Z" fill="#f472b6" />
      <g transform="translate(50 84) scale(0.55)"><circle r="10.5" fill="#f5c451" /><circle cx="4.5" cy="-3" r="8.6" fill={fur.hex} /></g>
    </svg>
  );
}
