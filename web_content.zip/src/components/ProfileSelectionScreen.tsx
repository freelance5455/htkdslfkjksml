import React, { useState } from 'react';
import { useVideo } from '../context/VideoContext';
import { UserProfile } from '../types/video';
import { AVATAR_PRESETS } from '../services/firebaseProfileService';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Check,
  Shield,
  Film,
  Globe,
  Sparkles,
} from 'lucide-react';

export const ProfileSelectionScreen: React.FC = () => {
  const {
    profiles,
    selectProfile,
    addProfile,
    updateProfile,
    deleteProfile,
    language,
    setLanguage,
    currentProfile,
  } = useVideo();

  const [isManaging, setIsManaging] = useState(false);
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  const [isAddingProfile, setIsAddingProfile] = useState(false);

  // Add profile form state
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileAvatar, setNewProfileAvatar] = useState(AVATAR_PRESETS[3]);
  const [newProfileIsKids, setNewProfileIsKids] = useState(false);

  // Edit profile form state
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editIsKids, setEditIsKids] = useState(false);

  const handleProfileClick = (profile: UserProfile) => {
    if (isManaging) {
      setEditingProfile(profile);
      setEditName(profile.name);
      setEditAvatar(profile.avatar);
      setEditIsKids(profile.isKids);
    } else {
      selectProfile(profile);
    }
  };

  const handleSaveNewProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    await addProfile(newProfileName.trim(), newProfileAvatar, newProfileIsKids);
    setIsAddingProfile(false);
    setNewProfileName('');
    setNewProfileIsKids(false);
  };

  const handleSaveEditedProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProfile || !editName.trim()) return;
    await updateProfile({
      ...editingProfile,
      name: editName.trim(),
      avatar: editAvatar,
      isKids: editIsKids,
    });
    setEditingProfile(null);
  };

  const handleDeleteProfile = async () => {
    if (!editingProfile) return;
    if (profiles.length <= 1) {
      alert('You must have at least one profile.');
      return;
    }
    if (confirm(`Delete profile "${editingProfile.name}" and its saved list & history?`)) {
      await deleteProfile(editingProfile.id);
      setEditingProfile(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#141414] text-white flex flex-col justify-between p-6 sm:p-10 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between max-w-6xl mx-auto w-full">
        {/* Netflix-style Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-sm bg-[#E50914] flex items-center justify-center shadow-lg shadow-red-900/40">
            <Film className="w-5 h-5 text-white" />
          </div>
          <span className="font-extrabold tracking-widest text-2xl text-[#E50914] uppercase drop-shadow-md">
            CINESTREAM
          </span>
        </div>

        {/* Language switch */}
        <button
          onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
          className="flex items-center space-x-1 px-3 py-1.5 rounded bg-zinc-800/80 hover:bg-zinc-700 text-xs font-semibold border border-zinc-700 cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5 text-zinc-400" />
          <span>{language === 'en' ? 'اردو' : 'English'}</span>
        </button>
      </div>

      {/* Main Profiles Center Area */}
      <div className="flex flex-col items-center justify-center my-auto py-12">
        <h1 className="text-3xl sm:text-5xl font-medium tracking-wide mb-8 sm:mb-12 text-center">
          {isManaging
            ? language === 'ur'
              ? 'پروفائلز کا انتظام کریں'
              : 'Manage Profiles:'
            : language === 'ur'
            ? 'کون دیکھ رہا ہے؟'
            : "Who's watching?"}
        </h1>

        {/* Profiles Row */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 max-w-5xl">
          {profiles.map((profile) => (
            <div
              key={profile.id}
              onClick={() => handleProfileClick(profile)}
              className="flex flex-col items-center group cursor-pointer"
            >
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-md overflow-hidden transition-all duration-200 group-hover:ring-4 group-hover:ring-white">
                <img
                  src={profile.avatar}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />

                {/* Kids Tag */}
                {profile.isKids && (
                  <div className="absolute top-2 left-2 bg-amber-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded shadow">
                    KIDS
                  </div>
                )}

                {/* Manage Pencil Overlay */}
                {isManaging && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center group-hover:bg-black/40 transition-colors">
                    <div className="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center bg-black/40">
                      <Pencil className="w-5 h-5 text-white" />
                    </div>
                  </div>
                )}
              </div>

              {/* Profile Name */}
              <span className="mt-3 text-sm sm:text-base font-normal text-zinc-400 group-hover:text-white transition-colors truncate max-w-[140px] text-center">
                {profile.name}
              </span>

              {/* Database indicator */}
              <span className="text-[10px] text-zinc-500 font-mono mt-0.5">
                {profile.isKids ? 'Kids Safe' : 'Standard'}
              </span>
            </div>
          ))}

          {/* Add Profile Button */}
          {!isManaging && profiles.length < 5 && (
            <div
              onClick={() => {
                setNewProfileName('');
                setNewProfileAvatar(AVATAR_PRESETS[3]);
                setNewProfileIsKids(false);
                setIsAddingProfile(true);
              }}
              className="flex flex-col items-center group cursor-pointer"
            >
              <div className="w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-md border-2 border-zinc-700 group-hover:border-white group-hover:bg-zinc-800/40 flex items-center justify-center transition-all duration-200">
                <Plus className="w-12 h-12 text-zinc-500 group-hover:text-white transition-colors" />
              </div>
              <span className="mt-3 text-sm sm:text-base font-normal text-zinc-400 group-hover:text-white transition-colors">
                {language === 'ur' ? 'پروفائل شامل کریں' : 'Add Profile'}
              </span>
              <span className="text-[10px] text-zinc-600 font-mono mt-0.5">Firestore Sync</span>
            </div>
          )}
        </div>

        {/* Manage Profiles / Done Button */}
        <div className="mt-12 sm:mt-16 flex items-center gap-4">
          <button
            onClick={() => setIsManaging(!isManaging)}
            className={`px-6 sm:px-8 py-2 text-xs sm:text-sm font-semibold tracking-widest uppercase transition-all cursor-pointer ${
              isManaging
                ? 'bg-white hover:bg-zinc-200 text-black'
                : 'border border-zinc-600 hover:border-white text-zinc-400 hover:text-white'
            }`}
          >
            {isManaging
              ? language === 'ur'
                ? 'مکمل'
                : 'Done'
              : language === 'ur'
              ? 'پروفائلز کا انتظام'
              : 'Manage Profiles'}
          </button>

          {currentProfile && !isManaging && (
            <button
              onClick={() => selectProfile(currentProfile)}
              className="px-6 sm:px-8 py-2 text-xs sm:text-sm font-semibold tracking-widest uppercase border border-red-600/60 hover:border-red-600 text-red-500 hover:text-white hover:bg-[#E50914] transition-all cursor-pointer"
            >
              {language === 'ur' ? 'جاری رکھیں' : 'Continue to CineStream'}
            </button>
          )}
        </div>
      </div>

      {/* Bottom Info Footnote */}
      <div className="text-center text-xs text-zinc-500 pb-2">
        <span className="text-emerald-400">● Firebase Firestore</span> — Each profile retains isolated My List & Watch History
      </div>

      {/* Modal: Add New Profile */}
      {isAddingProfile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#181818] border border-white/10 rounded-lg max-w-md w-full p-6 text-white space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <h3 className="text-xl font-bold">
                {language === 'ur' ? 'نیا پروفائل شامل کریں' : 'Add Profile'}
              </h3>
              <button
                onClick={() => setIsAddingProfile(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewProfile} className="space-y-5">
              {/* Selected Avatar Preview */}
              <div className="flex items-center space-x-4">
                <img
                  src={newProfileAvatar}
                  alt="New avatar"
                  className="w-20 h-20 rounded-md object-cover ring-2 ring-red-600"
                />
                <div className="flex-1 space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Profile Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex"
                    value={newProfileName}
                    onChange={(e) => setNewProfileName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Avatar Presets Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-zinc-400">Choose Avatar</label>
                <div className="grid grid-cols-6 gap-2">
                  {AVATAR_PRESETS.map((av, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => setNewProfileAvatar(av)}
                      className={`relative aspect-square rounded overflow-hidden border-2 transition-all ${
                        newProfileAvatar === av ? 'border-white scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={av} alt="Preset" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Kids Profile Switch */}
              <label className="flex items-center space-x-3 p-3 bg-zinc-900 rounded border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newProfileIsKids}
                  onChange={(e) => setNewProfileIsKids(e.target.checked)}
                  className="w-4 h-4 accent-red-600 rounded"
                />
                <div>
                  <div className="text-sm font-semibold flex items-center space-x-1.5">
                    <Shield className="w-4 h-4 text-amber-400" />
                    <span>Kid's Profile?</span>
                  </div>
                  <p className="text-xs text-zinc-400">
                    Restricts maturity ratings. Only displays content for ages 13 and below.
                  </p>
                </div>
              </label>

              {/* Actions */}
              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddingProfile(false)}
                  className="px-4 py-2 rounded text-zinc-400 hover:text-white text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded bg-[#E50914] hover:bg-red-700 text-white text-xs font-bold shadow-lg"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Existing Profile */}
      {editingProfile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#181818] border border-white/10 rounded-lg max-w-md w-full p-6 text-white space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <h3 className="text-xl font-bold">
                {language === 'ur' ? 'پروفائل میں ترمیم کریں' : 'Edit Profile'}
              </h3>
              <button
                onClick={() => setEditingProfile(null)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedProfile} className="space-y-5">
              <div className="flex items-center space-x-4">
                <img
                  src={editAvatar}
                  alt="Edit avatar"
                  className="w-20 h-20 rounded-md object-cover ring-2 ring-red-600"
                />
                <div className="flex-1 space-y-1">
                  <label className="text-xs font-semibold text-zinc-300">Name</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Avatar Presets Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-zinc-400">Change Avatar</label>
                <div className="grid grid-cols-6 gap-2">
                  {AVATAR_PRESETS.map((av, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => setEditAvatar(av)}
                      className={`relative aspect-square rounded overflow-hidden border-2 transition-all ${
                        editAvatar === av ? 'border-white scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={av} alt="Preset" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Kids Profile Switch */}
              <label className="flex items-center space-x-3 p-3 bg-zinc-900 rounded border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editIsKids}
                  onChange={(e) => setEditIsKids(e.target.checked)}
                  className="w-4 h-4 accent-red-600 rounded"
                />
                <div>
                  <div className="text-sm font-semibold flex items-center space-x-1.5">
                    <Shield className="w-4 h-4 text-amber-400" />
                    <span>Kid's Profile?</span>
                  </div>
                  <p className="text-xs text-zinc-400">
                    Restricts mature titles. Only displays age appropriate content.
                  </p>
                </div>
              </label>

              {/* Actions & Delete Button */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={handleDeleteProfile}
                  className="text-red-400 hover:text-red-300 text-xs font-semibold flex items-center space-x-1"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete Profile</span>
                </button>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setEditingProfile(null)}
                    className="px-4 py-2 rounded text-zinc-400 hover:text-white text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded bg-white hover:bg-zinc-200 text-black text-xs font-bold"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
