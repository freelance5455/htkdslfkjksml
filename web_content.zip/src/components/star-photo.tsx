import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { initialsOf, portraitTone } from "@/lib/portrait";
import { fetchWikiThumb } from "@/lib/wiki-photo";
import type { VaultStar } from "@/store/vault";

function Portrait({ name, seed, className }: { name: string; seed: string; className?: string }) {
  const tone = portraitTone(seed);
  return (
    <div
      className={cn("flex h-full w-full items-end p-3", className)}
      style={{ background: tone.bg }}
      aria-hidden
    >
      <span
        className="font-display text-3xl font-medium leading-none tracking-tight"
        style={{ color: tone.fg }}
      >
        {initialsOf(name)}
      </span>
    </div>
  );
}

export function StarPhoto({
  star,
  className,
  sizes = "160px",
}: {
  star: Pick<VaultStar, "slug" | "name" | "photo" | "wiki" | "customPhotoUrl">;
  className?: string;
  sizes?: string;
}) {
  const [remote, setRemote] = useState<string | null>(star.photo);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setRemote(star.photo);
    setFailed(false);
    if (star.customPhotoUrl || star.photo) return;
    let alive = true;
    fetchWikiThumb(star.wiki || star.name).then((src) => {
      if (alive && src) setRemote(src);
    });
    return () => {
      alive = false;
    };
  }, [star.customPhotoUrl, star.photo, star.wiki, star.name]);

  const src = star.customPhotoUrl || (!failed ? remote : null);

  if (!src) {
    return <Portrait name={star.name} seed={star.slug} className={className} />;
  }

  return (
    <img
      src={src}
      alt=""
      sizes={sizes}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      className={cn("h-full w-full object-cover", className)}
      onError={() => {
        setFailed(true);
        setRemote(null);
      }}
    />
  );
}
