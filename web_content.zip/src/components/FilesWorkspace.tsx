import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  Download,
  ExternalLink,
  File,
  FileCode,
  FileSpreadsheet,
  FileText,
  Filter,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import { api } from '../services/api.ts';
import type { FileAttachmentEntity, GeneratedDocumentEntity } from '../types.ts';

export const FilesWorkspace: React.FC = () => {
  const [files, setFiles] = useState<FileAttachmentEntity[]>([]);
  const [documents, setDocuments] = useState<GeneratedDocumentEntity[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'files' | 'documents' | 'generate' | 'research'>('files');
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Document Generation form state
  const [docTitle, setDocTitle] = useState('');
  const [docFormat, setDocFormat] = useState<'pdf' | 'md' | 'txt' | 'json'>('pdf');
  const [docContent, setDocContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [genSuccessMessage, setGenSuccessMessage] = useState<string | null>(null);

  // Web Research & Investigation state
  const [researchQuery, setResearchQuery] = useState('');
  const [isResearching, setIsResearching] = useState(false);
  const [researchReport, setResearchReport] = useState<any | null>(null);

  // Load files and documents
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [filesRes, docsRes] = await Promise.all([
        api.getFiles().catch(() => ({ success: false, files: [] })),
        api.getDocuments().catch(() => ({ success: false, documents: [] })),
      ]);
      if (filesRes.success && Array.isArray(filesRes.files)) {
        setFiles(filesRes.files);
      }
      if (docsRes.success && Array.isArray(docsRes.documents)) {
        setDocuments(docsRes.documents);
      }
    } catch (err) {
      console.warn('Failed to load files/docs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!uploaded || uploaded.length === 0) return;

    for (let i = 0; i < uploaded.length; i++) {
      const file = uploaded[i];
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          await api.uploadFile({
            originalName: file.name,
            mimeType: file.type || 'application/octet-stream',
            base64Data,
          });
          loadData();
        } catch (err) {
          console.error('File upload failed:', err);
        }
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const handleDeleteFile = async (id: string) => {
    try {
      await api.deleteFile(id);
      setFiles((prev) => prev.filter((f) => f.id !== id));
    } catch (err) {
      console.error('File delete failed:', err);
    }
  };

  const handleGenerateDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !docContent.trim() || isGenerating) return;
    setIsGenerating(true);
    setGenSuccessMessage(null);
    try {
      const res = await api.generateDocument({
        title: docTitle.trim(),
        format: docFormat,
        content: docContent.trim(),
      });
      if (res.success && res.document) {
        setDocuments((prev) => [res.document, ...prev]);
        setGenSuccessMessage(`Document "${res.document.title}" generated successfully!`);
        setDocTitle('');
        setDocContent('');
      }
    } catch (err: any) {
      console.error('Document generation failed:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRunResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!researchQuery.trim() || isResearching) return;
    setIsResearching(true);
    setResearchReport(null);
    try {
      const res = await api.synthesizeResearch({
        query: researchQuery.trim(),
        maxSources: 6,
      });
      if (res.success && res.report) {
        setResearchReport(res.report);
      }
    } catch (err) {
      console.error('Research query failed:', err);
    } finally {
      setIsResearching(false);
    }
  };

  const filteredFiles = files.filter((f) => {
    const matchesSearch =
      f.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.summary && f.summary.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = categoryFilter === 'ALL' || f.fileCategory === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getFileIcon = (cat: string) => {
    switch (cat) {
      case 'PDF':
      case 'DOCUMENT':
        return <FileText className="w-4 h-4 text-rose-600" />;
      case 'CODE':
        return <FileCode className="w-4 h-4 text-emerald-600" />;
      case 'DATA':
        return <FileSpreadsheet className="w-4 h-4 text-amber-600" />;
      default:
        return <File className="w-4 h-4 text-sky-600" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      {/* Top Header Bar */}
      <div className="px-6 py-4 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-sky-600" />
            Files, Documents & Web Research Hub
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real file parsing, strict path security, PDF synthesis & multi-source web verification
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Subtabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveSubTab('files')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'files'
                  ? 'bg-white text-sky-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Files ({files.length})
            </button>
            <button
              onClick={() => setActiveSubTab('documents')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'documents'
                  ? 'bg-white text-sky-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Documents ({documents.length})
            </button>
            <button
              onClick={() => setActiveSubTab('generate')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'generate'
                  ? 'bg-white text-sky-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + Create Document
            </button>
            <button
              onClick={() => setActiveSubTab('research')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'research'
                  ? 'bg-white text-sky-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Web Research
            </button>
          </div>

          <button
            onClick={loadData}
            disabled={isLoading}
            className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors shadow-2xs disabled:opacity-40"
            title="Refresh list"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* SUBTAB 1: FILES LIST */}
        {activeSubTab === 'files' && (
          <div className="space-y-4 max-w-6xl mx-auto">
            {/* Action & Filter Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search file name or contents..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 focus:outline-none"
                >
                  <option value="ALL">All Types</option>
                  <option value="PDF">PDF</option>
                  <option value="DOCUMENT">Documents</option>
                  <option value="CODE">Code</option>
                  <option value="DATA">Data</option>
                  <option value="TEXT">Text</option>
                </select>

                <label className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-semibold cursor-pointer transition-all shadow-2xs">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload File</span>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                    accept=".pdf,.doc,.docx,.txt,.md,.json,.csv,.py,.ts,.js,.png,.jpg"
                  />
                </label>
              </div>
            </div>

            {/* Files Grid / List */}
            {filteredFiles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredFiles.map((file) => (
                  <div
                    key={file.id}
                    className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                            {getFileIcon(file.fileCategory)}
                          </div>
                          <div className="min-w-0">
                            <h3 className="font-semibold text-xs text-slate-900 truncate" title={file.originalName}>
                              {file.originalName}
                            </h3>
                            <span className="text-[10px] font-mono text-slate-400">
                              {(file.sizeBytes / 1024).toFixed(1)} KB • {new Date(file.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>

                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 uppercase shrink-0">
                          {file.fileCategory}
                        </span>
                      </div>

                      {file.summary && (
                        <p className="text-xs text-slate-600 line-clamp-3 bg-slate-50/70 p-2.5 rounded-xl border border-slate-100 mb-3">
                          {file.summary}
                        </p>
                      )}

                      <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 mb-2">
                        <span>STATUS:</span>
                        <span
                          className={`font-semibold ${
                            file.extractionStatus === 'PARSED'
                              ? 'text-emerald-700'
                              : file.extractionStatus === 'OCR_REQUIRED'
                              ? 'text-amber-700'
                              : 'text-slate-600'
                          }`}
                        >
                          {file.extractionStatus}
                        </span>
                        {file.pageCount && file.pageCount > 0 && <span>• {file.pageCount} pages</span>}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      {file.downloadUrl ? (
                        <a
                          href={file.downloadUrl}
                          download={file.originalName}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-xs font-semibold text-sky-600 hover:text-sky-800 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download</span>
                        </a>
                      ) : (
                        <span className="text-[11px] text-slate-400">Stored</span>
                      )}

                      <button
                        onClick={() => handleDeleteFile(file.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all"
                        title="Delete file"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 shadow-2xs">
                <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <h3 className="font-bold text-sm text-slate-700">No files found</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Upload PDF documents, code snippets, or datasets to analyze and reference directly in JARVIS core loops.
                </p>
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 2: GENERATED DOCUMENTS LIST */}
        {activeSubTab === 'documents' && (
          <div className="space-y-4 max-w-6xl mx-auto">
            {documents.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <div className="p-2 rounded-xl bg-sky-50 border border-sky-100">
                            <FileText className="w-4 h-4 text-sky-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-xs text-slate-900 truncate max-w-[200px]" title={doc.title}>
                              {doc.title}
                            </h3>
                            <span className="text-[10px] font-mono text-slate-400">
                              {(doc.sizeBytes / 1024).toFixed(1)} KB • {new Date(doc.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>

                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-sky-100 text-sky-800 border border-sky-200 uppercase">
                          {doc.format}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 text-xs font-mono text-slate-600 line-clamp-4 mb-3 leading-relaxed">
                        {doc.contentPreview}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] font-mono text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        Valid Document
                      </span>
                      {doc.downloadUrl && (
                        <a
                          href={doc.downloadUrl}
                          download={`${doc.title}.${doc.format}`}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download</span>
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 shadow-2xs">
                <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <h3 className="font-bold text-sm text-slate-700">No generated documents</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Generate downloadable PDFs, Markdown summaries, or structured JSON reports using the &quot;+ Create Document&quot; tab.
                </p>
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 3: CREATE DOCUMENT FORM */}
        {activeSubTab === 'generate' && (
          <div className="max-w-2xl mx-auto bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-1">
              <Plus className="w-4 h-4 text-sky-600" />
              Generate Synthesized Document
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Compile notes, research, or mission reports into compliant PDF-1.4 or Markdown files.
            </p>

            {genSuccessMessage && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{genSuccessMessage}</span>
              </div>
            )}

            <form onSubmit={handleGenerateDoc} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Physics Research Summary or Sprint Plan"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Export Format</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['pdf', 'md', 'txt', 'json'] as const).map((fmt) => (
                    <button
                      type="button"
                      key={fmt}
                      onClick={() => setDocFormat(fmt)}
                      className={`py-2 rounded-xl text-xs font-mono font-bold uppercase transition-all border ${
                        docFormat === fmt
                          ? 'bg-sky-50 border-sky-500 text-sky-800 shadow-2xs'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {fmt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Content / Body Text</label>
                <textarea
                  required
                  rows={8}
                  placeholder="Enter full document notes, formatted bullet points, or code..."
                  value={docContent}
                  onChange={(e) => setDocContent(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200 font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={isGenerating}
                className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-all shadow-2xs disabled:opacity-40 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isGenerating ? 'Generating Document...' : 'Generate & Save Document'}</span>
              </button>
            </form>
          </div>
        )}

        {/* SUBTAB 4: WEB RESEARCH ENGINE */}
        {activeSubTab === 'research' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-1">
                <Search className="w-4 h-4 text-indigo-600" />
                Truthful Web Research & Evidence Synthesizer
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                Conduct multi-source investigations across authoritative web repositories with explicit conflict detection.
              </p>

              <form onSubmit={handleRunResearch} className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="Enter research inquiry (e.g. quantum computing breakthrough or MIT OCW syllabus)..."
                  value={researchQuery}
                  onChange={(e) => setResearchQuery(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200"
                />
                <button
                  type="submit"
                  disabled={isResearching}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-2xs disabled:opacity-40 flex items-center gap-1.5 shrink-0"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isResearching ? 'Synthesizing...' : 'Synthesize Research'}</span>
                </button>
              </form>
            </div>

            {/* Research Results Display */}
            {researchReport && (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase">SYNTHESIZED REPORT</span>
                    <h4 className="text-base font-bold text-slate-900 mt-0.5">{researchReport.topic}</h4>
                  </div>
                  <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
                    Confidence: {(researchReport.synthesisConfidence * 100).toFixed(0)}%
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-800 leading-relaxed whitespace-pre-line">
                  {researchReport.executiveSummary}
                </div>

                {researchReport.keyFindings?.length > 0 && (
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 mb-2">Key Findings:</h5>
                    <ul className="space-y-1.5">
                      {researchReport.keyFindings.map((finding: string, idx: number) => (
                        <li key={idx} className="text-xs text-slate-700 flex items-start gap-2">
                          <span className="text-indigo-600 font-bold">•</span>
                          <span>{finding}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {researchReport.sources?.length > 0 && (
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 mb-2">Verified Sources:</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {researchReport.sources.map((s: any, idx: number) => (
                        <a
                          key={idx}
                          href={s.url}
                          target="_blank"
                          rel="noreferrer"
                          className="p-2.5 rounded-xl border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 transition-all flex items-center justify-between text-xs group"
                        >
                          <div className="min-w-0">
                            <span className="font-semibold text-slate-800 truncate block group-hover:text-sky-700">
                              {s.title}
                            </span>
                            <span className="text-[10px] text-slate-400 truncate block">{s.domain}</span>
                          </div>
                          <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-600 shrink-0 ml-2" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
