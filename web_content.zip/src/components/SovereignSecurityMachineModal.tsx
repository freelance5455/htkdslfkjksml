import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  KeyRound,
  FileCheck,
  Globe,
  Radio,
  Server,
  AlertTriangle,
  CheckCircle2,
  X,
  RefreshCw,
  Terminal,
  Cpu,
  Mail,
  Smartphone,
  Ban,
  Shield,
  Zap,
  Activity
} from 'lucide-react';
import {
  prophetSecurityEngine,
  SovereignCertificate,
  CyberThreatAlert
} from '../lib/prophetSecurityEngine';

interface SovereignSecurityMachineModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SovereignSecurityMachineModal: React.FC<SovereignSecurityMachineModalProps> = ({
  isOpen,
  onClose
}) => {
  const [cert, setCert] = useState<SovereignCertificate>(() => prophetSecurityEngine.getCertificate());
  const [alerts, setAlerts] = useState<CyberThreatAlert[]>(() => prophetSecurityEngine.getThreatAlerts());
  const [activeTab, setActiveTab] = useState<'certificate' | 'alerts' | 'firewall'>('certificate');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  useEffect(() => {
    const unsub = prophetSecurityEngine.subscribe(() => {
      setCert(prophetSecurityEngine.getCertificate());
      setAlerts(prophetSecurityEngine.getThreatAlerts());
    });
    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const handleRunSecurityAudit = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setActionSuccess('✓ Sovereign Genesis Signature Verified! Zero unauthorized modifications detected.');
      setTimeout(() => setActionSuccess(null), 4000);
    }, 700);
  };

  const handleTestPiracyTrap = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const simulatedThreat = prophetSecurityEngine.simulatePirateTamperTest();
      setAlerts(prophetSecurityEngine.getThreatAlerts());
      setIsSimulating(false);
      setActiveTab('alerts');
      setActionSuccess(`🚨 Anti-Piracy Trap Triggered! Threat logged & dispatched to ${simulatedThreat.targetAlertEmail}. Cyber criminal blocked.`);
      setTimeout(() => setActionSuccess(null), 5000);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer transition-all hover:scale-105"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 via-emerald-500/10 to-transparent border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
            <ShieldCheck className="w-8 h-8 text-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 uppercase tracking-widest mb-1">
              <Lock className="w-3 h-3 text-amber-400" />
              <span>Sovereign Security Engine & Machine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-serif text-amber-100">
              ANTI-PIRACY & CLONER SECURITY SHIELD
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Certified Authority: <strong className="text-amber-300">{cert.certifiedEmail}</strong>
            </p>
          </div>
        </div>

        {/* Notification Toast */}
        {actionSuccess && (
          <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 text-xs font-bold flex items-center space-x-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{actionSuccess}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('certificate')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'certificate'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Signed Certificate</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'alerts'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Threat Alerts & Dispatches ({alerts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('firewall')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'firewall'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Ban className="w-3.5 h-3.5" />
            <span>Anti-Cloning Network Rule</span>
          </button>
        </div>

        {/* TAB 1: SIGNED CERTIFICATE */}
        {activeTab === 'certificate' && (
          <div className="space-y-4 font-mono text-xs">
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">Certificate ID:</span>
                <span className="text-slate-200 text-[11px]">{cert.certificateId}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">Certified Owner:</span>
                <span className="text-emerald-400 font-bold">{cert.ownerName}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">Security Dispatch Email:</span>
                <span className="text-amber-200 underline">{cert.certifiedEmail}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">Canonical Domain:</span>
                <span className="text-slate-300">{cert.canonicalDomain}</span>
              </div>
              <div className="flex flex-col space-y-1 border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">SHA-256 Digital Certificate Hash:</span>
                <span className="text-[10px] text-emerald-300 break-all bg-slate-900 p-2 rounded-lg border border-slate-800">
                  {cert.sha256CertificateHash}
                </span>
              </div>
              <div className="flex flex-col space-y-1 border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-bold uppercase">Ed25519 Signed Public Key:</span>
                <span className="text-[10px] text-cyan-300 break-all bg-slate-900 p-2 rounded-lg border border-slate-800">
                  {cert.ed25519SignedPublicKey}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Valid Period: {new Date(cert.issuedAt).toLocaleDateString()} — {new Date(cert.validThrough).toLocaleDateString()}</span>
                <span className="text-emerald-400 font-bold">● Status: Active & Valid</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/60 to-slate-950 border border-amber-500/30 text-[11px] text-amber-200/90 leading-relaxed font-sans">
              🔒 <strong>Prophet JUHNKRIX SYNVAGORD Sovereign Authority:</strong> All modifications to this application are strictly reserved to the Prophet inside the private Owner portal. Any unauthorized attempt by cyber criminals, pirates, or cloners automatically triggers an emergency threat dispatch to <strong className="text-amber-100">{cert.certifiedEmail}</strong> with full device and location telemetry.
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleRunSecurityAudit}
                disabled={isSimulating}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold uppercase flex items-center space-x-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
                <span>Verify Signature Integrity</span>
              </button>

              <button
                onClick={handleTestPiracyTrap}
                disabled={isSimulating}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold uppercase shadow-lg shadow-rose-600/20 cursor-pointer flex items-center space-x-1.5"
                title="Simulate cyber criminal clone detection, telemetry extraction, email dispatch, and auto-block"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Test Anti-Piracy Trap</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: THREAT ALERTS & DISPATCHES */}
        {activeTab === 'alerts' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Automatic threat notifications dispatched to: <strong className="text-amber-300">{cert.certifiedEmail}</strong></span>
              <span className="text-emerald-400 font-mono font-bold">● Live Threat Trap Active</span>
            </div>

            {alerts.length === 0 ? (
              <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-2">
                <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-amber-100">Zero Cyber Threats Detected</h4>
                <p className="text-xs text-slate-400">The decentralized network is healthy. No pirated or cloned instances have attempted unauthorized handshake.</p>
                <button
                  onClick={handleTestPiracyTrap}
                  className="mt-3 px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold cursor-pointer"
                >
                  Run Threat Trap Simulation
                </button>
              </div>
            ) : (
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
                {alerts.map((alert) => (
                  <div
                    key={alert.threatId}
                    className="p-4 rounded-2xl bg-slate-950 border border-rose-500/40 space-y-2.5 shadow-lg"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                          {alert.threatType}
                        </span>
                        <h4 className="text-xs font-bold text-amber-200">{alert.criminalName}</h4>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">{alert.timestamp}</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300 space-y-1">
                      <div>
                        <strong className="text-rose-400">Location:</strong> {alert.location.city}, {alert.location.country} ({alert.location.timezone}) • {alert.location.coordinatesHeuristic}
                      </div>
                      <div>
                        <strong className="text-rose-400">Host / Website:</strong> {alert.website}
                      </div>
                      <div>
                        <strong className="text-rose-400">Device Telemetry:</strong> {alert.deviceDetails.platform} • {alert.deviceDetails.screenResolution} • {alert.deviceDetails.webglRenderer}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        <strong>User Agent:</strong> {alert.deviceDetails.userAgent}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-mono pt-1">
                      <span className="text-emerald-400 flex items-center space-x-1">
                        <Mail className="w-3 h-3" />
                        <span>Dispatched to {alert.targetAlertEmail}</span>
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold">
                        🔒 CYBER CRIMINAL BLOCKED
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ANTI-CLONING NETWORK RULE */}
        {activeTab === 'firewall' && (
          <div className="space-y-4 text-xs font-sans">
            <div className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
              <div className="flex items-center space-x-2 text-amber-300 font-serif font-black text-sm">
                <Ban className="w-4 h-4 text-rose-400" />
                <span>GENESIS ORIGIN TOKEN NETWORK ENFORCEMENT</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-xs">
                Even if cyber criminals create a fake, modified, or cloned version of the JUHNKRIX MUSIKA App and upload it to any third-party app store, <strong className="text-rose-300">it CANNOT connect to the JUHNKRIX MUSIKA network</strong>.
              </p>
              <div className="space-y-2 font-mono text-[11px] pt-1">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-emerald-500/30 flex items-center justify-between">
                  <span className="text-emerald-300">✓ Official Website Download:</span>
                  <strong className="text-slate-100">juhnkrix.musika.pages.dev (Verified Genesis Token)</strong>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-emerald-500/30 flex items-center justify-between">
                  <span className="text-emerald-300">✓ Built-in App Download:</span>
                  <strong className="text-slate-100">Direct Internal Storage (Cryptographic Peer Seed)</strong>
                </div>
                <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 flex items-center justify-between">
                  <span className="text-rose-300">✕ Fake App Store Clones:</span>
                  <strong className="text-rose-400">Auto-Rejected & Severed from P2P Socket Swarm</strong>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 font-mono leading-relaxed">
              Every peer handshake validates the Genesis Origin Token. Cloned binaries fail the cryptographic certificate challenge, extract the cyber criminal's full hardware telemetry, send an alert email to <strong className="text-amber-200">juhnkrix.musika@gmail.com</strong>, and permanently deny network connection.
            </div>
          </div>
        )}

        <div className="flex items-center justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase cursor-pointer shadow-lg transition-all hover:scale-105"
          >
            Close Security Machine
          </button>
        </div>
      </div>
    </div>
  );
};
