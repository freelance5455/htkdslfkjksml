import React from 'react';
import { ShoppingBag, MessageCircle, Sparkles, Check, Download, Disc, Smartphone, Laptop } from 'lucide-react';
import { DJ_SHOP_ITEMS } from '../data/djData';

export const DjShop: React.FC = () => {
  return (
    <section id="shop" className="py-12 px-4 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight flex items-center gap-2">
            <span>🛒 DJ APPS &amp; DROPS SHOP</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Instant delivery via WhatsApp &amp; Google Drive within 5 minutes after Mobile Money payment.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {DJ_SHOP_ITEMS.map((item) => {
          const isWhiteCard = item.id === 'drops';
          const buyUrl = `https://wa.me/256742094651?text=${encodeURIComponent(item.whatsappText)}`;

          return (
            <div
              key={item.id}
              className={`p-4 rounded-2xl flex flex-col justify-between transition-all hover:scale-[1.02] shadow-lg ${
                isWhiteCard
                  ? 'bg-white text-black border-2 border-yellow-400'
                  : 'bg-zinc-900 text-white border border-zinc-800 hover:border-purple-500/50'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-2">
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                      isWhiteCard
                        ? 'bg-black text-yellow-300'
                        : 'bg-purple-950 text-purple-300 border border-purple-800/40'
                    }`}
                  >
                    {item.category}
                  </span>
                  {item.badge && (
                    <span
                      className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                        isWhiteCard ? 'bg-amber-100 text-amber-800' : 'bg-cyan-950 text-cyan-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-sm sm:text-base leading-snug">
                  {item.title}
                </h3>

                <p
                  className={`font-black text-xl my-2 ${
                    isWhiteCard ? 'text-black' : 'text-cyan-400 font-mono'
                  }`}
                >
                  {item.displayPrice}
                </p>

                <p
                  className={`text-[11px] leading-relaxed mb-4 ${
                    isWhiteCard ? 'text-zinc-700' : 'text-zinc-400'
                  }`}
                >
                  {item.desc}
                </p>
              </div>

              <a
                href={buyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className={`block text-center py-2.5 rounded-full text-xs font-black uppercase tracking-wider transition-all shadow-md active:scale-95 ${
                  isWhiteCard
                    ? 'bg-black hover:bg-zinc-800 text-white'
                    : 'bg-white hover:bg-zinc-200 text-black'
                }`}
              >
                BUY ON WHATSAPP
              </a>
            </div>
          );
        })}
      </div>

      {/* Payment info bar */}
      <div className="mt-4 p-3 rounded-xl bg-purple-950/40 border border-purple-900/40 flex flex-wrap items-center justify-between gap-2 text-xs text-purple-200">
        <span className="flex items-center gap-1.5 font-bold">
          <Check className="w-4 h-4 text-emerald-400" />
          Easy Payment: MTN MoMo &amp; Airtel Money (0742094651)
        </span>
        <span className="text-slate-400 text-[11px]">
          Audio drops delivered as 320kbps WAV/MP3 · Apps sent with installation guide
        </span>
      </div>
    </section>
  );
};
