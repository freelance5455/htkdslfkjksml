import React, { useState, useEffect } from 'react';
import { CompanionPhrase, getRandomPhrase } from '../../data/companionPhrases';
import { Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { Volume2, Sparkles, MessageSquare } from 'lucide-react';
import { speakText } from '../../utils/speech';

interface Props {
  language: Language;
  soundEnabled: boolean;
  currentReaction?: 'correct' | 'wrong' | 'levelUp' | 'rankUp' | null;
  onClearReaction?: () => void;
}

export const AnimeCompanion: React.FC<Props> = ({
  language,
  soundEnabled,
  currentReaction,
  onClearReaction
}) => {
  const [currentPhrase, setCurrentPhrase] = useState<CompanionPhrase>(() => getRandomPhrase('greeting'));
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Reaction to external game events (correct answer, level up, wrong answer)
  useEffect(() => {
    if (currentReaction) {
      const phrase = getRandomPhrase(currentReaction);
      setCurrentPhrase(phrase);

      const timer = setTimeout(() => {
        if (onClearReaction) onClearReaction();
      }, 7000);

      return () => clearTimeout(timer);
    }
  }, [currentReaction, onClearReaction]);

  // Click companion for a fresh tip / motivation
  const handleCompanionClick = () => {
    soundManager.playTick(soundEnabled);
    const phrase = getRandomPhrase(Math.random() > 0.5 ? 'advice' : 'greeting');
    setCurrentPhrase(phrase);
  };

  const handleSpeakPhrase = async () => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    const textToSpeak = language === 'ar' ? currentPhrase.ar : language === 'fr' ? currentPhrase.fr : currentPhrase.en;
    await speakText(textToSpeak, language);
    setIsSpeaking(false);
  };

  const displayedText = language === 'ar' ? currentPhrase.ar : language === 'fr' ? currentPhrase.fr : currentPhrase.en;

  return (
    <div className="relative flex flex-col md:flex-row items-center gap-4 bg-gradient-to-r from-purple-950/40 via-slate-950/80 to-slate-900/40 p-4 rounded-2xl border border-purple-500/30 shadow-neon-purple backdrop-blur-md">
      {/* 2D Animated Shadow Companion Avatar */}
      <div 
        onClick={handleCompanionClick}
        className="relative group cursor-pointer flex-shrink-0"
        title="انقر على المرافق لتلقي نصيحة أو عبارة تحفيزية!"
      >
        {/* Shadow Aura Pulsing Background */}
        <div className="absolute -inset-2 bg-gradient-to-r from-purple-600 via-rose-600 to-indigo-600 rounded-full blur-md opacity-40 group-hover:opacity-75 transition duration-500" />

        {/* Anime Character Visual Container */}
        <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-full bg-slate-950 border-2 border-purple-400 overflow-hidden flex items-center justify-center shadow-inner">
          {/* Stylized Shadow Monarch Armor & Neon Eyes SVG */}
          <svg viewBox="0 0 100 100" className="w-full h-full transform scale-110">
            {/* Dark Aura tendrils */}
            <defs>
              <linearGradient id="shadowMonarchGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#1e1035" />
                <stop offset="50%" stopColor="#3b0764" />
                <stop offset="100%" stopColor="#090514" />
              </linearGradient>
              <linearGradient id="neonEyeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#67e8f9" />
                <stop offset="100%" stopColor="#818cf8" />
              </linearGradient>
            </defs>

            {/* Hood / Shadow Armor */}
            <path
              d="M 50,5 C 25,5 15,30 15,55 C 15,80 30,95 50,95 C 70,95 85,80 85,55 C 85,30 75,5 50,5 Z"
              fill="url(#shadowMonarchGrad)"
            />

            {/* Face mask / cowl */}
            <path
              d="M 25,45 Q 50,75 75,45 Q 65,30 50,32 Q 35,30 25,45 Z"
              fill="#06030c"
            />

            {/* Glowing Neon Eyes (reacting to mood) */}
            {currentPhrase.emotion === 'proud' || currentPhrase.emotion === 'radiant' ? (
              <>
                {/* Radiant blazing eyes */}
                <path d="M 32,46 Q 40,42 44,48 Q 38,52 32,46 Z" fill="#f43f5e" className="animate-pulse" />
                <path d="M 68,46 Q 60,42 56,48 Q 62,52 68,46 Z" fill="#f43f5e" className="animate-pulse" />
                {/* Flame streak */}
                <line x1="28" y1="46" x2="18" y2="40" stroke="#f43f5e" strokeWidth="2" strokeLinecap="round" />
                <line x1="72" y1="46" x2="82" y2="40" stroke="#f43f5e" strokeWidth="2" strokeLinecap="round" />
              </>
            ) : currentPhrase.emotion === 'encouraging' ? (
              <>
                <circle cx="38" cy="46" r="4" fill="#38bdf8" />
                <circle cx="62" cy="46" r="4" fill="#38bdf8" />
              </>
            ) : (
              <>
                {/* Sharp hunter gaze */}
                <polygon points="32,45 44,44 42,49 34,48" fill="url(#neonEyeGrad)" />
                <polygon points="68,45 56,44 58,49 66,48" fill="url(#neonEyeGrad)" />
              </>
            )}

            {/* Chest Rune Plate */}
            <polygon points="50,70 42,85 58,85" fill="#7c3aed" opacity="0.8" />
            <circle cx="50" cy="78" r="2.5" fill="#a855f7" />
          </svg>

          {/* Level / Rank Badge on companion */}
          <div className="absolute bottom-1 bg-purple-900/90 text-purple-200 text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-purple-400">
            ظِل الأشعة
          </div>
        </div>
      </div>

      {/* Speech Bubble */}
      <div className="flex-1 text-right">
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-black text-purple-300 font-tech uppercase tracking-wider">
              Kage – ظِل الأشعة المرافق
            </span>
            <span className="text-[10px] text-slate-400 bg-slate-900/70 px-2 py-0.5 rounded-md border border-purple-900/50">
              {currentPhrase.emotion === 'proud' ? 'فخور بك ✨' : currentPhrase.emotion === 'encouraging' ? 'تحفيز مستمر 🛡️' : currentPhrase.emotion === 'radiant' ? 'طاقة قصوى 🔥' : 'مرشدك الشعاعي ⚡'}
            </span>
          </div>

          <button
            onClick={handleSpeakPhrase}
            disabled={isSpeaking}
            title="استمع إلى عبارة المرافق"
            className="p-1.5 text-purple-300 hover:text-white bg-purple-900/40 hover:bg-purple-800/60 rounded-lg transition-colors border border-purple-500/30 active:scale-95 disabled:opacity-50"
          >
            <Volume2 className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs md:text-sm text-slate-100 font-medium leading-relaxed bg-black/40 p-3 rounded-xl border border-purple-900/40 shadow-inner">
          « {displayedText} »
        </p>
      </div>
    </div>
  );
};
