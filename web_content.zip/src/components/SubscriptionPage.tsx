import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  Crown,
  GraduationCap,
  ShieldCheck,
  Sparkles,
  WalletCards,
  Mail,
  Smartphone,
} from 'lucide-react';
import { BillingCycle, SUBSCRIPTION_PLANS, SubscriptionPlan } from '../config/subscription-plans';

interface SubscriptionPageProps {
  onBack: () => void;
}

interface UpiPaymentIntent {
  planId: string;
  planName: string;
  billingCycle: BillingCycle;
  amount: number;
  currency: 'INR';
  paymentReference: string;
  paymentUri: string;
  supportMailto: string;
  paymentMode: 'manual-review';
  subscriptionActivated: false;
  renewsAutomatically: false;
}

const formatINR = (amount: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);

export const SubscriptionPage: React.FC<SubscriptionPageProps> = ({ onBack }) => {
  const [cycle, setCycle] = useState<BillingCycle>('monthly');
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [paymentIntent, setPaymentIntent] = useState<UpiPaymentIntent | null>(null);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  const choosePlan = (plan: SubscriptionPlan) => {
    setSelectedPlan({ ...plan });
    setPaymentIntent(null);
    setPaymentError('');
  };

  const preparePayment = async () => {
    if (!selectedPlan || selectedPlan.id === 'free') return;
    setPaymentLoading(true);
    setPaymentError('');
    setPaymentIntent(null);
    try {
      const response = await fetch('/api/billing/upi-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId: selectedPlan.id, billingCycle: cycle }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result?.error || 'Unable to prepare a payment link.');
      setPaymentIntent(result as UpiPaymentIntent);
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : 'Unable to prepare a payment link. Please try again.');
    } finally {
      setPaymentLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 py-5 md:px-8 md:py-8">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-white hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" /> Back to tutor
        </button>

        <div className="mx-auto mt-5 max-w-3xl text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-200">
            <GraduationCap className="h-6 w-6" />
          </div>
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-indigo-600">MindSparq Plans</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 md:text-5xl">Make every study session count.</h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-6 text-slate-600 md:text-base">
            Start free and choose more learning capacity when you need it. Prices below are proposed launch prices in Indian rupees.
          </p>

          <div className="mt-6 inline-flex rounded-xl border border-slate-200 bg-white p-1 shadow-sm" role="group" aria-label="Billing cycle">
            <button
              onClick={() => setCycle('monthly')}
              aria-pressed={cycle === 'monthly'}
              className={`rounded-lg px-4 py-2 text-sm font-semibold transition ${cycle === 'monthly' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >Monthly</button>
            <button
              onClick={() => setCycle('annual')}
              aria-pressed={cycle === 'annual'}
              className={`rounded-lg px-4 py-2 text-sm font-semibold transition ${cycle === 'annual' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >Annual <span className="ml-1 text-emerald-500">Save ~17%</span></button>
          </div>
        </div>

        <div className="mx-auto mt-8 grid max-w-5xl gap-4 md:grid-cols-3 md:gap-5">
          {SUBSCRIPTION_PLANS.map((plan) => {
            const price = cycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
            const unit = cycle === 'monthly' ? '/month' : '/year';
            return (
              <section
                key={plan.id}
                className={`relative flex flex-col rounded-2xl border bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md md:p-6 ${plan.highlighted ? 'border-indigo-500 ring-2 ring-indigo-100' : 'border-slate-200'}`}
              >
                {plan.highlighted && <div className="absolute -top-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-indigo-600 px-3 py-1 text-[11px] font-bold text-white">MOST POWERFUL</div>}
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-950">{plan.name}</h2>
                  {plan.id === 'pro' ? <Crown className="h-5 w-5 text-amber-500" /> : plan.id === 'plus' ? <Sparkles className="h-5 w-5 text-indigo-500" /> : <GraduationCap className="h-5 w-5 text-slate-400" />}
                </div>
                <p className="mt-1 min-h-10 text-sm text-slate-500">{plan.tagline}</p>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-3xl font-bold tracking-tight text-slate-950">{formatINR(price)}</span>
                  {price > 0 && <span className="text-xs text-slate-500">{unit}</span>}
                </div>
                {cycle === 'annual' && plan.id !== 'free' && <p className="mt-1 text-xs text-slate-500">Equivalent to {formatINR(Math.round(price / 12))}/month, billed annually</p>}
                <button
                  onClick={() => choosePlan(plan)}
                  className={`mt-5 inline-flex min-h-11 w-full items-center justify-center rounded-xl px-4 py-2.5 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-offset-2 ${plan.highlighted ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'border border-slate-200 bg-white text-slate-800 hover:bg-slate-50'}`}
                >
                  {plan.id === 'free' ? 'Continue with Free' : `Choose ${plan.name}`}
                </button>
                <div className="my-5 border-t border-slate-100" />
                <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">What's included</p>
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-2.5 text-sm leading-5 text-slate-600">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
        </div>

        {selectedPlan && (
          <div className="mx-auto mt-6 max-w-3xl rounded-2xl border border-amber-200 bg-amber-50 p-4 md:p-5" role="status" aria-live="polite">
            <div className="flex items-start gap-3">
              {selectedPlan.id === 'free' ? <Check className="mt-0.5 h-5 w-5 shrink-0 text-emerald-700" /> : <WalletCards className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />}
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-slate-900">{selectedPlan.id === 'free' ? 'Free access is ready to use' : `Payment for ${selectedPlan.name}`}</h3>
                <p className="mt-1 text-sm leading-5 text-slate-700">
                  {selectedPlan.id === 'free'
                    ? 'Free access remains available. No account or billing change was made.'
                    : `Prepare a one-time UPI payment of ${formatINR(cycle === 'monthly' ? selectedPlan.monthlyPrice : selectedPlan.annualPrice)} for the ${cycle} ${selectedPlan.name} plan. This manual payment does not renew automatically, and payment alone will not unlock the plan.`}
                </p>
                {selectedPlan.id !== 'free' && (
                  <>
                    <button
                      onClick={preparePayment}
                      disabled={paymentLoading}
                      className="mt-3 inline-flex min-h-10 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      <WalletCards className="h-4 w-4" />
                      {paymentLoading ? 'Preparing payment…' : 'Continue with UPI'}
                    </button>
                    {paymentError && <p className="mt-2 text-sm text-rose-700">{paymentError}</p>}
                    {paymentIntent && (
                      <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4">
                        <p className="text-sm font-semibold text-slate-900">Payment request prepared</p>
                        <p className="mt-1 text-sm text-slate-600">Amount: {formatINR(paymentIntent.amount)} · Reference: <span className="font-mono">{paymentIntent.paymentReference}</span></p>
                        <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                          <a href={paymentIntent.paymentUri} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700">
                            <Smartphone className="h-4 w-4" /> Open UPI app
                          </a>
                          <a href={paymentIntent.supportMailto} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                            <Mail className="h-4 w-4" /> Email payment reference
                          </a>
                        </div>
                        <p className="mt-3 text-xs leading-5 text-slate-600">Your UPI app will show the recipient details for you to confirm before paying; they are not printed on this page. After payment, email the transaction ID/UTR for manual checking. Never share your UPI PIN or OTP.</p>
                        <p className="mt-2 text-xs leading-5 font-medium text-amber-800">Important: this is a one-time payment request, not an automatic subscription. MindSparq cannot verify payment or activate paid access yet. Do not pay unless you are comfortable with manual verification.</p>
                      </div>
                    )}
                  </>
                )}
              </div>
              <button onClick={() => { setSelectedPlan(null); setPaymentIntent(null); setPaymentError(''); }} aria-label="Dismiss payment panel" className="rounded-md p-1 text-slate-500 hover:bg-amber-100">×</button>
            </div>
          </div>
        )}

        <div className="mx-auto mt-6 flex max-w-3xl items-start gap-3 rounded-xl border border-slate-200 bg-white p-4 text-xs leading-5 text-slate-500">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
          <p>Transparent pricing matters. These prices and features are proposals. Direct UPI payments are one-time and manually reviewed; they are not automatically recurring, and this app does not verify or activate paid access. For verified recurring subscriptions, integrate an approved billing provider with server-side webhook verification before launch.</p>
        </div>
      </div>
    </div>
  );
};
