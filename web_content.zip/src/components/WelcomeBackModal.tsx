import React from 'react';
import { TrendingUp, Clock, Check } from 'lucide-react';
import { sound } from '../game/sound';

interface WelcomeBackModalProps {
  offlineEarnings: number;
  elapsedSeconds: number;
  onClaim: () => void;
}

export const WelcomeBackModal: React.FC<WelcomeBackModalProps> = ({
  offlineEarnings,
  elapsedSeconds,
  onClaim
}) => {
  const hours = Math.floor(elapsedSeconds / 3600);
  const minutes = Math.floor((elapsedSeconds % 3600) / 60);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-none p-4 select-none">
      <div className="bg-[#0e0f14] border border-[#27272a] rounded-2xl max-w-sm w-full p-6 text-white text-center shadow-2xl animate-in zoom-in-95 duration-150">
        <div className="w-12 h-12 rounded-xl bg-white text-black flex items-center justify-center mx-auto mb-4 font-mono font-bold text-lg">
          ✈
        </div>

        <h2 className="text-xl font-mono font-bold tracking-tight mb-1">
          WELCOME BACK, CAPTAIN!
        </h2>
        <p className="text-xs text-[#71717a] font-mono mb-6">
          Your airline continued flying while you were away
        </p>

        <div className="bg-[#14151e] border border-[#23242e] rounded-xl p-4 mb-6">
          <div className="flex items-center justify-center gap-1.5 text-xs text-[#a1a1aa] mb-2 font-mono">
            <Clock size={14} />
            <span>
              Away for {hours > 0 ? `${hours}h ` : ''}{minutes}m
            </span>
          </div>

          <div className="text-3xl font-mono font-bold text-white tabular-nums">
            +${offlineEarnings.toLocaleString()}
          </div>
          <span className="text-[11px] font-mono text-[#71717a] block mt-1">
            Revenues gathered from commercial routes
          </span>
        </div>

        <button
          onClick={() => {
            sound.playCash();
            onClaim();
          }}
          className="w-full py-3.5 bg-white text-black hover:bg-[#e4e4e7] font-mono font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Check size={16} />
          <span>COLLECT REVENUES</span>
        </button>
      </div>
    </div>
  );
};
