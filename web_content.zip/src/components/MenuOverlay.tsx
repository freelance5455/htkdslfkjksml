import { useState } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  Play,
  RotateCcw,
  Sun,
  Moon,
  Trophy,
  Globe,
  Users,
  User,
  ShoppingBag,
  Coins,
  Dna,
  Zap,
  Award,
  SlidersHorizontal,
  Crown,
  Compass,
  Plus,
  Sparkles,
  Layers,
  X,
  ShieldCheck,
  UserPlus,
  Settings,
  LogIn,
  LogOut,
  Mail,
} from 'lucide-react';
import { formatPlayerCodeDisplay } from '../game/accountService';
import { Translations } from '../game/i18n';
import { xpRequiredForLevel } from '../game/progression';
import { SKINS } from '../game/skins';
import {
  AccountModalTab,
  ArenaTheme,
  GameConfig,
  GameMode,
  GamePhase,
  HudSnapshot,
  Language,
  MatchRewardSummary,
  PlayerProfile,
  PlayType,
  RoomSummary,
  ShopTab,
} from '../game/types';
import { SkinPreview } from './SkinPreview';

interface MenuOverlayProps {
  phase: GamePhase;
  config: GameConfig;
  profile: PlayerProfile;
  lang: Language;
  t: Translations;
  bestMass: number;
  isNewRecord: boolean;
  lastSummary: HudSnapshot | null;
  lastRewards: MatchRewardSummary | null;
  lastTokensEarned?: number;
  rooms: RoomSummary[];
  connecting: boolean;
  connectionError: string | null;
  passClaimableCount: number;
  eventBadgeCount: number;
  playerCode: string;
  isOwner: boolean;
  firebaseUser: FirebaseUser | null;
  authLoading: boolean;
  authError: string | null;
  onSignInGoogle: (emailHint?: string) => void;
  onSignOut: () => void;
  onClearAuthError: () => void;
  kickedNotice: string | null;
  onDismissKickedNotice: () => void;
  grantNotice: string | null;
  onDismissGrantNotice: () => void;
  onChangeConfig: (partial: Partial<GameConfig>) => void;
  onToggleLanguage: () => void;
  onOpenShop: (tab?: ShopTab) => void;
  onOpenGamePass: () => void;
  onOpenEvent: () => void;
  onOpenCustomizer: () => void;
  onOpenAccount: (tab?: AccountModalTab) => void;
  onOpenOwnerMenu: () => void;
  onStartGame: () => void;
  onResumeGame: () => void;
  onBackToMenu: () => void;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export function MenuOverlay({
  phase,
  config,
  profile,
  lang,
  t,
  bestMass,
  isNewRecord,
  lastSummary,
  lastRewards,
  lastTokensEarned = 0,
  rooms,
  connecting,
  connectionError,
  passClaimableCount,
  eventBadgeCount,
  playerCode,
  isOwner,
  firebaseUser,
  authLoading,
  authError,
  onSignInGoogle,
  onSignOut,
  onClearAuthError,
  kickedNotice,
  onDismissKickedNotice,
  grantNotice,
  onDismissGrantNotice,
  onChangeConfig,
  onToggleLanguage,
  onOpenShop,
  onOpenGamePass,
  onOpenEvent,
  onOpenCustomizer,
  onOpenAccount,
  onOpenOwnerMenu,
  onStartGame,
  onResumeGame,
  onBackToMenu,
}: MenuOverlayProps) {
  const [moreOpen, setMoreOpen] = useState(false);
  const [settingsEmailInput, setSettingsEmailInput] = useState('');

  if (phase === 'PLAYING') return null;

  const neededXp = xpRequiredForLevel(profile.level);
  const xpPercent = Math.min(100, Math.round((profile.xp / neededXp) * 100));

  if (phase === 'PAUSED') {
    return (
      <div className="fixed inset-0 z-20 flex items-center justify-center bg-slate-950/35 p-4 backdrop-blur-sm">
        <div className="w-full max-w-sm rounded-2xl border border-white/50 bg-white/85 p-6 shadow-xl backdrop-blur-xl dark:border-slate-700/60 dark:bg-slate-900/85">
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            {t.pausedTitle}
          </h2>

          <div className="mt-5 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={onResumeGame}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-sky-700 focus-visible:outline-2 focus-visible:outline-sky-500 whitespace-nowrap"
            >
              <Play className="h-4 w-4" />
              <span>{t.resumeGame}</span>
            </button>
            <button
              type="button"
              onClick={onStartGame}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white/70 px-5 py-2.5 text-sm font-semibold text-slate-800 transition-colors hover:bg-white dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <RotateCcw className="h-4 w-4" />
              <span>{t.restartGame}</span>
            </button>
            <button
              type="button"
              onClick={onOpenCustomizer}
              className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white/70 px-5 py-2.5 text-sm font-semibold text-slate-800 transition-colors hover:bg-white dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <SlidersHorizontal className="h-4 w-4 text-sky-600 dark:text-sky-400" />
              <span>{t.customizeControlsBtn}</span>
            </button>
            <button
              type="button"
              onClick={onBackToMenu}
              className="flex min-h-[44px] w-full items-center justify-center rounded-xl px-5 py-2.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100/80 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800/70 dark:hover:text-white whitespace-nowrap"
            >
              {t.backToMenu}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (phase === 'GAME_OVER' && lastSummary) {
    return (
      <div className="fixed inset-0 z-20 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
        <div className="max-h-[92dvh] w-full max-w-md overflow-y-auto overscroll-contain touch-pan-y rounded-2xl border border-white/50 bg-white/88 p-5 shadow-xl backdrop-blur-xl dark:border-slate-700/60 dark:bg-slate-900/88 sm:p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                {t.gameOverTitle}
              </h2>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                {lastSummary.killerName
                  ? `${t.eatenBy} ${lastSummary.killerName}`
                  : t.survivedText}
              </p>
            </div>
            {isNewRecord && (
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400">
                <Trophy className="h-4 w-4" />
                <span>{t.newRecord}</span>
              </div>
            )}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-xl bg-slate-100/80 p-3 dark:bg-slate-800/70">
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.peakMass}</div>
              <div className="font-mono-num mt-1 text-lg font-bold text-slate-900 dark:text-white">
                {lastSummary.peakMass}
              </div>
            </div>
            <div className="rounded-xl bg-slate-100/80 p-3 dark:bg-slate-800/70">
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.eaten}</div>
              <div className="font-mono-num mt-1 text-lg font-bold text-slate-900 dark:text-white">
                {lastSummary.cellsEaten}
              </div>
            </div>
            <div className="rounded-xl bg-slate-100/80 p-3 dark:bg-slate-800/70">
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.timeAlive}</div>
              <div className="font-mono-num mt-1 text-lg font-bold text-slate-900 dark:text-white">
                {formatDuration(lastSummary.elapsedSeconds)}
              </div>
            </div>
            <div className="rounded-xl bg-slate-100/80 p-3 dark:bg-slate-800/70">
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.bestScore}</div>
              <div className="font-mono-num mt-1 text-lg font-bold text-sky-600 dark:text-sky-400">
                {bestMass}
              </div>
            </div>
          </div>

          {/* Match Rewards: Score, Coins, DNA, Event Tokens, and Level Progress */}
          {lastRewards && (
            <div className="mt-4 rounded-xl border border-slate-200/80 bg-white/70 p-3.5 dark:border-slate-800 dark:bg-slate-950/40">
              <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
                <span>{t.rewardsEarnedTitle}</span>
                {lastRewards.leveledUp && (
                  <span className="flex items-center gap-1 text-sky-600 dark:text-sky-400">
                    <Award className="h-3.5 w-3.5" />
                    {t.leveledUpLabel}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-3.5 text-xs">
                <div className="flex items-center gap-1 font-bold text-sky-600 dark:text-sky-400">
                  <span className="font-mono-num">+{lastRewards.scoreGained}</span>
                  <span>{t.score}</span>
                  {lastRewards.boostMultiplier > 1 && (
                    <span className="font-mono-num">({lastRewards.boostMultiplier}x)</span>
                  )}
                </div>
                <div className="flex items-center gap-1 font-bold text-amber-600 dark:text-amber-400">
                  <Coins className="h-3.5 w-3.5" />
                  <span className="font-mono-num">+{lastRewards.coinsEarned}</span>
                  <span>{t.coinsLabel}</span>
                </div>
                <div className="flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                  <Dna className="h-3.5 w-3.5" />
                  <span className="font-mono-num">+{lastRewards.dnaEarned}</span>
                  <span>{t.dnaLabel}</span>
                </div>
                {lastTokensEarned > 0 && (
                  <div className="flex items-center gap-1 font-bold text-cyan-600 dark:text-cyan-400">
                    <Sparkles className="h-3.5 w-3.5" />
                    <span className="font-mono-num">+{lastTokensEarned}</span>
                    <span>{t.earnedTokensLabel}</span>
                  </div>
                )}
              </div>

              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-700 dark:text-slate-200">
                    {t.levelLabel} {profile.level}
                  </span>
                  <span className="font-mono-num text-slate-500 dark:text-slate-400">
                    {profile.xp}/{neededXp} XP
                  </span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                  <div
                    className="h-full rounded-full bg-sky-500 transition-all duration-300"
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="mt-5 grid grid-cols-2 gap-2.5 sm:flex sm:flex-wrap">
            <button
              type="button"
              onClick={onStartGame}
              className="col-span-2 flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-sky-700 focus-visible:outline-2 focus-visible:outline-sky-500 whitespace-nowrap"
            >
              <RotateCcw className="h-4 w-4" />
              <span>{t.playAgain}</span>
            </button>
            <button
              type="button"
              onClick={onOpenGamePass}
              className="relative flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-amber-400/70 bg-amber-500/15 px-3 py-2.5 text-xs font-bold text-amber-800 transition-colors hover:bg-amber-500/25 dark:text-amber-300 whitespace-nowrap"
            >
              <Crown className="h-4 w-4" />
              <span>{t.gamePassBtn}</span>
              {passClaimableCount > 0 && (
                <span className="font-mono-num flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-500 px-1 text-[10px] font-bold text-white">
                  {passClaimableCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={onOpenEvent}
              className="relative flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-sky-400/70 bg-sky-500/15 px-3 py-2.5 text-xs font-bold text-sky-800 transition-colors hover:bg-sky-500/25 dark:text-sky-300 whitespace-nowrap"
            >
              <Compass className="h-4 w-4" />
              <span>{t.eventBtn}</span>
              {eventBadgeCount > 0 && (
                <span className="font-mono-num flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                  {eventBadgeCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => onOpenShop('skins')}
              className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white/80 px-3 py-2.5 text-xs font-semibold text-slate-800 transition-colors hover:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700 whitespace-nowrap"
            >
              <ShoppingBag className="h-4 w-4 text-emerald-500" />
              <span>{t.shopBtn}</span>
            </button>
            <button
              type="button"
              onClick={onBackToMenu}
              className="flex min-h-[44px] items-center justify-center rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              {t.backToMenu}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // MENU PHASE — Airy Corner-Anchored Floating Lobby
  const modes: GameMode[] = ['classic', 'blitz', 'relaxed'];
  const themes: { id: ArenaTheme; label: string; icon: typeof Sun }[] = [
    { id: 'light', label: t.themeLight, icon: Sun },
    { id: 'dark', label: t.themeDark, icon: Moon },
  ];
  const playTypes: { id: PlayType; label: string; icon: typeof User }[] = [
    { id: 'online', label: t.playOnline, icon: Users },
    { id: 'solo', label: t.playSolo, icon: User },
  ];

  const presetRoomLabels: Record<string, string> = {
    global: t.globalRoomName,
    kurdistan: t.kurdistanRoomName,
    blitz: t.blitzRoomName,
  };

  const activeSkin = SKINS.find((s) => s.id === config.skinId);
  const currentRoomLabel =
    config.playType === 'online'
      ? presetRoomLabels[config.roomId] || config.roomId || t.globalRoomName
      : t.playSolo;
  const activeXpBoost =
    profile.boosts.levelBoost3x > 0
      ? `3x (${profile.boosts.levelBoost3x})`
      : profile.boosts.levelBoost2x > 0
      ? `2x (${profile.boosts.levelBoost2x})`
      : null;

  return (
    <>
      <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-2.5 sm:p-5">
        {/* TOP BAR: Left = Pass / Event / Lang + Active Boosts | Right = DNA & Coins */}
        <div className="flex items-start justify-between gap-2">
          {/* Top-Left Cluster */}
          <div className="pointer-events-auto flex flex-col items-start gap-2">
            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Game Pass Tile */}
              <button
                type="button"
                onClick={onOpenGamePass}
                className="relative flex h-12 min-w-[48px] flex-col items-center justify-center gap-0.5 rounded-2xl border border-amber-300/70 bg-gradient-to-b from-amber-400 to-orange-500 px-2.5 text-slate-950 shadow-lg shadow-amber-500/20 transition-transform hover:scale-105 active:scale-95 sm:h-13 sm:min-w-[58px]"
                title={t.gamePassBtn}
              >
                <Crown className="h-4.5 w-4.5" />
                <span className="text-[10px] font-extrabold leading-none whitespace-nowrap">
                  {t.gamePassBtn}
                </span>
                {passClaimableCount > 0 && (
                  <span className="font-mono-num absolute -top-1.5 -right-1.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-white bg-rose-600 px-1 text-[10px] font-extrabold text-white shadow">
                    {passClaimableCount}
                  </span>
                )}
              </button>

              {/* Nexus Maze Event Tile */}
              <button
                type="button"
                onClick={onOpenEvent}
                className="relative flex h-12 min-w-[48px] flex-col items-center justify-center gap-0.5 rounded-2xl border border-sky-300/70 bg-gradient-to-b from-sky-400 to-cyan-600 px-2.5 text-white shadow-lg shadow-sky-500/20 transition-transform hover:scale-105 active:scale-95 sm:h-13 sm:min-w-[58px]"
                title={t.eventBtn}
              >
                <Compass className="h-4.5 w-4.5" />
                <span className="text-[10px] font-extrabold leading-none whitespace-nowrap">
                  {t.eventBtn}
                </span>
                {eventBadgeCount > 0 && (
                  <span className="font-mono-num absolute -top-1.5 -right-1.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-white bg-rose-600 px-1 text-[10px] font-extrabold text-white shadow">
                    {eventBadgeCount}
                  </span>
                )}
              </button>

              {/* Friends Tile */}
              <button
                type="button"
                onClick={() => onOpenAccount('friends')}
                className="flex h-12 min-w-[44px] flex-col items-center justify-center gap-0.5 rounded-2xl border border-indigo-300/70 bg-gradient-to-b from-indigo-500 to-violet-600 px-2.5 text-white shadow-lg shadow-indigo-500/20 transition-transform hover:scale-105 active:scale-95 sm:h-13 sm:min-w-[54px]"
                title={t.friendsBtn}
              >
                <UserPlus className="h-4.5 w-4.5" />
                <span className="text-[10px] font-extrabold leading-none whitespace-nowrap">
                  {t.friendsBtn}
                </span>
              </button>

              {/* Exclusive Owner Menu Tile (visible ONLY to verified owner) */}
              {isOwner && (
                <button
                  type="button"
                  onClick={onOpenOwnerMenu}
                  className="flex h-12 min-w-[44px] flex-col items-center justify-center gap-0.5 rounded-2xl border border-amber-300 bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 px-2.5 text-slate-950 shadow-lg shadow-amber-500/30 transition-transform hover:scale-105 active:scale-95 sm:h-13 sm:min-w-[54px]"
                  title={t.ownerMenuTitle}
                >
                  <ShieldCheck className="h-4.5 w-4.5" />
                  <span className="text-[10px] font-black leading-none whitespace-nowrap">
                    {t.ownerMenuBtn}
                  </span>
                </button>
              )}

              {/* Language Toggle Tile */}
              <button
                type="button"
                onClick={onToggleLanguage}
                className="flex h-12 min-w-[44px] flex-col items-center justify-center gap-0.5 rounded-2xl border border-white/75 bg-white/85 px-2.5 text-slate-800 shadow-md backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/85 dark:text-slate-100 sm:h-13"
                title={lang === 'ckb' ? 'English' : 'کوردی'}
              >
                <Globe className="h-4 w-4 text-sky-600 dark:text-sky-400" />
                <span className="text-[10px] font-bold leading-none whitespace-nowrap">
                  {lang === 'ckb' ? 'EN' : 'کوردی'}
                </span>
              </button>
            </div>

            {/* Active Boosts Strip (compact side icons, opens Shop Boosts) */}
            <div className="hidden flex-col gap-1.5 sm:flex">
              <button
                type="button"
                onClick={() => onOpenShop('boosts')}
                className="group relative flex h-10 items-center gap-1.5 rounded-xl border border-white/75 bg-white/85 px-2.5 text-[11px] font-extrabold text-slate-800 shadow-md backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/85 dark:text-slate-100"
                title={t.tabBoosts}
              >
                <Zap className="h-4 w-4 text-amber-500" />
                <span className="font-mono-num">{activeXpBoost || 'XP'}</span>
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-white">
                  <Plus className="h-2.5 w-2.5 stroke-[3]" />
                </span>
              </button>
              <button
                type="button"
                onClick={() => onOpenShop('boosts')}
                className="group relative flex h-10 items-center gap-1.5 rounded-xl border border-white/75 bg-white/85 px-2.5 text-[11px] font-extrabold text-slate-800 shadow-md backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/85 dark:text-slate-100"
                title={t.tabBoosts}
              >
                <Coins className="h-4 w-4 text-sky-500" />
                <span className="font-mono-num">
                  {profile.boosts.coinBoost2x > 0
                    ? `2x (${profile.boosts.coinBoost2x})`
                    : profile.boosts.startMassBoost > 0
                    ? `+M (${profile.boosts.startMassBoost})`
                    : t.boostsShortLabel}
                </span>
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-white">
                  <Plus className="h-2.5 w-2.5 stroke-[3]" />
                </span>
              </button>
            </div>
          </div>

          {/* Top-Right Cluster: DNA & Coins Counters */}
          <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2.5">
            <button
              type="button"
              onClick={() => onOpenShop('skins')}
              className="flex h-11 items-center gap-1.5 rounded-2xl border border-white/75 bg-white/88 px-2.5 shadow-md backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/88 sm:px-3"
              title={t.dnaLabel}
            >
              <Dna className="h-4 w-4 text-emerald-500" />
              <span className="font-mono-num text-xs font-extrabold text-slate-900 dark:text-white sm:text-sm">
                {profile.dna}
              </span>
              <span className="flex h-5 w-5 items-center justify-center rounded-lg bg-emerald-500 text-white shadow-xs">
                <Plus className="h-3 w-3 stroke-[3]" />
              </span>
            </button>

            <button
              type="button"
              onClick={() => onOpenShop('skins')}
              className="flex h-11 items-center gap-1.5 rounded-2xl border border-white/75 bg-white/88 px-2.5 shadow-md backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/88 sm:px-3"
              title={t.coinsLabel}
            >
              <Coins className="h-4 w-4 text-amber-500" />
              <span className="font-mono-num text-xs font-extrabold text-slate-900 dark:text-white sm:text-sm">
                {profile.coins}
              </span>
              <span className="flex h-5 w-5 items-center justify-center rounded-lg bg-emerald-500 text-white shadow-xs">
                <Plus className="h-3 w-3 stroke-[3]" />
              </span>
            </button>
          </div>
        </div>

        {/* CENTER FOCAL STACK: Brand Title, Skin Picker + Nickname, Play & More */}
        <div className="pointer-events-auto mx-auto flex w-full max-w-[350px] flex-col items-center sm:max-w-[390px]">
          {/* Brand Title */}
          <h1
            dir="ltr"
            className="font-display text-3xl font-black tracking-tight text-slate-900 drop-shadow-[0_2px_10px_rgba(255,255,255,0.85)] dark:text-white dark:drop-shadow-[0_2px_12px_rgba(2,6,23,0.9)] sm:text-4xl"
          >
            {t.brand}
          </h1>
          <p className="mt-0.5 text-[11px] font-bold text-slate-600 drop-shadow-[0_1px_6px_rgba(255,255,255,0.9)] dark:text-slate-300 dark:drop-shadow-none">
            {config.playType === 'online' ? `${t.onlineBadge} · ${currentRoomLabel}` : t.playSolo} ·{' '}
            {t.modes[config.mode].title}
          </p>

          {/* Skin Selector + Nickname Input */}
          <div className="mt-3 flex w-full items-center gap-2.5 sm:mt-4">
            <button
              type="button"
              onClick={() => onOpenShop('skins')}
              title={lang === 'ckb' ? activeSkin?.nameCkb : activeSkin?.nameEn}
              className="relative flex h-13 w-13 shrink-0 items-center justify-center rounded-full border-2 border-white/95 bg-white/90 shadow-lg backdrop-blur-md transition-transform hover:scale-105 active:scale-95 dark:border-slate-700 dark:bg-slate-800/90 sm:h-14 sm:w-14"
            >
              <SkinPreview skinId={config.skinId} size={42} />
              <span className="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white bg-emerald-500 text-white shadow dark:border-slate-900">
                <Plus className="h-3 w-3 stroke-[3]" />
              </span>
            </button>

            <input
              id="nickname-input"
              type="text"
              maxLength={16}
              value={config.nickname}
              onChange={(e) => onChangeConfig({ nickname: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onStartGame();
              }}
              placeholder={t.nicknamePlaceholder}
              aria-label={t.nicknameLabel}
              className="h-12 flex-1 rounded-2xl border border-white/85 bg-white/92 px-4 text-base font-bold text-slate-900 shadow-lg backdrop-blur-md placeholder:font-medium placeholder:text-slate-400 focus:border-sky-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900/92 dark:text-white dark:focus:border-sky-400 sm:h-13 sm:text-sm"
            />
          </div>

          {connectionError && (
            <div className="mt-2.5 w-full rounded-xl border border-rose-300/80 bg-rose-50/95 px-3 py-1.5 text-center text-xs font-semibold text-rose-700 shadow-sm dark:border-rose-800/70 dark:bg-rose-950/90 dark:text-rose-200">
              {connectionError}
            </div>
          )}

          {kickedNotice && (
            <div className="mt-2.5 flex w-full items-center justify-between gap-2 rounded-xl border border-rose-400 bg-rose-50/95 px-3 py-2 text-xs font-bold text-rose-800 shadow-md dark:border-rose-700 dark:bg-rose-950/95 dark:text-rose-200">
              <span>{kickedNotice}</span>
              <button
                type="button"
                onClick={onDismissKickedNotice}
                aria-label={t.closeBtn}
                className="rounded-lg p-1 hover:bg-rose-200/60 dark:hover:bg-rose-900"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {grantNotice && (
            <div className="mt-2.5 flex w-full items-center justify-between gap-2 rounded-xl border border-emerald-400 bg-emerald-50/95 px-3 py-2 text-xs font-bold text-emerald-800 shadow-md dark:border-emerald-700 dark:bg-emerald-950/95 dark:text-emerald-200">
              <span>{grantNotice}</span>
              <button
                type="button"
                onClick={onDismissGrantNotice}
                aria-label={t.closeBtn}
                className="rounded-lg p-1 hover:bg-emerald-200/60 dark:hover:bg-emerald-900"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* Side-by-Side Hero Buttons: Play (Coral-Orange) + More (Sapphire-Blue) */}
          <div className="mt-3 grid w-full grid-cols-2 gap-2.5 sm:mt-3.5 sm:gap-3">
            <button
              type="button"
              disabled={connecting}
              onClick={onStartGame}
              className="flex min-h-[62px] flex-col items-center justify-center gap-1 rounded-2xl border border-orange-300/60 bg-gradient-to-b from-orange-500 to-rose-600 px-3 py-2.5 text-white shadow-xl shadow-orange-500/25 transition-all hover:brightness-105 active:scale-[0.98] disabled:opacity-60 sm:min-h-[76px]"
            >
              <Play className="h-6 w-6 fill-current" />
              <span className="text-sm font-black leading-tight whitespace-nowrap sm:text-base">
                {connecting ? t.connectingText : t.modes[config.mode].title}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              className="flex min-h-[62px] flex-col items-center justify-center gap-1 rounded-2xl border border-sky-300/60 bg-gradient-to-b from-sky-500 to-blue-600 px-3 py-2.5 text-white shadow-xl shadow-blue-600/25 transition-all hover:brightness-105 active:scale-[0.98] sm:min-h-[76px]"
            >
              <Layers className="h-6 w-6" />
              <span className="text-sm font-black leading-tight whitespace-nowrap sm:text-base">
                {t.moreBtn}
              </span>
            </button>
          </div>
        </div>

        {/* BOTTOM BAR: Left = Control Customizer & Rooms | Right = Shop & Profile Card */}
        <div className="flex items-end justify-between gap-2 pb-[max(0px,env(safe-area-inset-bottom))]">
          {/* Bottom-Left Cluster */}
          <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-label={t.settingsBtn}
              title={t.settingsBtn}
              className="flex h-12 items-center gap-1.5 rounded-2xl border border-slate-300/80 bg-gradient-to-b from-slate-700 to-slate-900 px-3 text-xs font-extrabold text-white shadow-lg transition-transform hover:scale-105 active:scale-95 dark:border-slate-600/80"
            >
              <Settings className="h-4.5 w-4.5" />
              <span className="hidden sm:inline">{t.settingsBtn}</span>
            </button>

            <button
              type="button"
              onClick={onOpenCustomizer}
              aria-label={t.customizeControlsBtn}
              title={t.customizeControlsBtn}
              className="flex h-12 w-12 items-center justify-center rounded-2xl border border-cyan-300/70 bg-gradient-to-b from-cyan-400 to-sky-600 text-white shadow-lg transition-transform hover:scale-105 active:scale-95"
            >
              <SlidersHorizontal className="h-5 w-5" />
            </button>

            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-label={t.roomsBtn}
              title={t.roomsBtn}
              className="flex h-12 w-12 items-center justify-center rounded-2xl border border-blue-300/70 bg-gradient-to-b from-blue-500 to-indigo-600 text-white shadow-lg transition-transform hover:scale-105 active:scale-95"
            >
              <Users className="h-5 w-5" />
            </button>
          </div>

          {/* Bottom-Right Cluster: Shop + Sleek Profile Card */}
          <div className="pointer-events-auto flex items-end gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => onOpenShop('skins')}
              className="flex h-12 items-center gap-1.5 rounded-2xl border border-emerald-300/70 bg-gradient-to-b from-emerald-500 to-green-600 px-3 text-xs font-black text-white shadow-lg shadow-emerald-600/25 transition-transform hover:scale-105 active:scale-95 sm:px-4 sm:text-sm whitespace-nowrap"
            >
              <ShoppingBag className="h-4.5 w-4.5" />
              <span>{t.shopBtn}</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenAccount('account')}
              className="flex h-12 items-center gap-2 rounded-2xl border border-white/75 bg-white/88 px-2.5 text-start shadow-lg backdrop-blur-md transition-transform hover:scale-[1.02] active:scale-95 dark:border-slate-700/80 dark:bg-slate-900/90 sm:px-3"
              title={t.accountTitle}
            >
              <div className="flex min-w-[92px] flex-col gap-0.5 sm:min-w-[116px]">
                <div className="flex items-center justify-between gap-1.5 text-[11px]">
                  <span className="font-extrabold text-slate-900 dark:text-white whitespace-nowrap">
                    {t.levelLabel} {profile.level}
                  </span>
                  {bestMass > 0 && (
                    <span className="font-mono-num flex items-center gap-0.5 font-bold text-amber-600 dark:text-amber-400">
                      <Trophy className="h-3 w-3" />
                      {bestMass}
                    </span>
                  )}
                </div>
                <div
                  dir="ltr"
                  className="font-mono-num text-[10px] font-bold text-sky-600 dark:text-sky-400"
                >
                  {formatPlayerCodeDisplay(playerCode)}
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                  <div
                    className="h-full rounded-full bg-sky-500 transition-all duration-300"
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>
              <div className="hidden sm:block">
                <SkinPreview skinId={config.skinId} size={30} />
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* ARENA SETUP & ROOMS DRAWER MODAL (opened via "More" or bottom-left Rooms/Profile) */}
      {moreOpen && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-slate-950/45 p-2 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-white/60 bg-white/92 shadow-2xl backdrop-blur-xl dark:border-slate-700/70 dark:bg-slate-900/94">
            <div className="flex items-center justify-between border-b border-slate-200/70 px-4 py-3.5 dark:border-slate-800 sm:px-6">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400">
                  <Settings className="h-5 w-5" />
                </div>
                <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                  {t.settingsBtn} · {t.lobbySetupTitle}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setMoreOpen(false)}
                aria-label={t.closeBtn}
                className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto overscroll-contain touch-pan-y px-4 py-4 sm:px-6">
              {/* Account & Email Sign-In inside Settings */}
              <div className="mb-4 rounded-2xl border border-sky-200/80 bg-sky-50/75 p-3.5 dark:border-sky-800/60 dark:bg-sky-950/35">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-900 dark:text-white">
                    <Mail className="h-4 w-4 text-sky-600 dark:text-sky-400" />
                    <span>{t.settingsAccountTitle}</span>
                  </div>
                  <span
                    dir="ltr"
                    className="font-mono-num rounded-lg bg-white/80 px-2 py-0.5 text-[11px] font-bold text-sky-700 dark:bg-slate-900/70 dark:text-sky-300"
                  >
                    {formatPlayerCodeDisplay(playerCode)}
                  </span>
                </div>

                {firebaseUser ? (
                  <div className="flex flex-wrap items-center justify-between gap-2.5">
                    <div className="min-w-0 flex-1">
                      <div className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                        {t.signedInAsLabel}
                      </div>
                      <div
                        dir="ltr"
                        className="truncate text-xs font-extrabold text-slate-900 dark:text-white"
                      >
                        {firebaseUser.email}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setMoreOpen(false);
                          onOpenAccount('account');
                        }}
                        className="flex min-h-[38px] items-center rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 whitespace-nowrap"
                      >
                        {t.accountBtn}
                      </button>
                      <button
                        type="button"
                        disabled={authLoading}
                        onClick={onSignOut}
                        className="flex min-h-[38px] items-center gap-1 rounded-xl border border-rose-200 bg-white px-3 py-1.5 text-[11px] font-bold text-rose-600 hover:bg-rose-50 disabled:opacity-50 dark:border-rose-800/70 dark:bg-slate-900 dark:text-rose-400 whitespace-nowrap"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        <span>{t.signOutBtn}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300">
                      {t.guestAccountNote}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <input
                        type="email"
                        dir="ltr"
                        value={settingsEmailInput}
                        onChange={(e) => {
                          setSettingsEmailInput(e.target.value);
                          if (authError) onClearAuthError();
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') onSignInGoogle(settingsEmailInput);
                        }}
                        placeholder={t.emailInputPlaceholder}
                        className="h-10 min-w-[180px] flex-1 rounded-xl border border-slate-200 bg-white px-3 text-base font-medium text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white sm:text-xs"
                      />
                      <button
                        type="button"
                        disabled={authLoading}
                        onClick={() => onSignInGoogle(settingsEmailInput)}
                        className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-extrabold text-white shadow-sm transition-colors hover:bg-sky-700 disabled:opacity-50 whitespace-nowrap"
                      >
                        <LogIn className="h-4 w-4" />
                        <span>{t.signInGoogleBtn}</span>
                      </button>
                    </div>
                    {authError && (
                      <div className="rounded-xl border border-rose-300 bg-rose-50 px-3 py-1.5 text-[11px] font-semibold text-rose-700 dark:border-rose-800 dark:bg-rose-950/70 dark:text-rose-200">
                        {authError}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Play Mode Toggle: Online vs Solo */}
              <div>
                <div className="mb-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {t.playTypeLabel}
                </div>
                <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80">
                  {playTypes.map((pt) => {
                    const Icon = pt.icon;
                    const active = config.playType === pt.id;
                    return (
                      <button
                        key={pt.id}
                        type="button"
                        onClick={() => onChangeConfig({ playType: pt.id })}
                        className={`flex min-h-[44px] items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-bold transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        <Icon className="h-4 w-4 text-sky-600 dark:text-sky-400" />
                        <span>{pt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Online Room Selector */}
              {config.playType === 'online' && (
                <div className="mt-4 rounded-xl border border-slate-200/80 bg-white/60 p-3 dark:border-slate-700/70 dark:bg-slate-800/50">
                  <div className="mb-2 flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                    <span>{t.roomLabel}</span>
                    <span className="font-mono-num text-[11px] font-normal text-slate-500 dark:text-slate-400">
                      {rooms.reduce((sum, r) => sum + r.onlinePlayers, 0)} {t.onlineCountSuffix}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {(rooms.length > 0
                      ? rooms
                      : [
                          { id: 'global', mode: 'classic' as GameMode, onlinePlayers: 0 },
                          { id: 'kurdistan', mode: 'classic' as GameMode, onlinePlayers: 0 },
                          { id: 'blitz', mode: 'blitz' as GameMode, onlinePlayers: 0 },
                        ]
                    ).map((room) => {
                      const selected = config.roomId === room.id;
                      const displayName = presetRoomLabels[room.id] || room.id;
                      return (
                        <button
                          key={room.id}
                          type="button"
                          onClick={() => onChangeConfig({ roomId: room.id, mode: room.mode })}
                          className={`flex min-h-[44px] items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                            selected
                              ? 'border-sky-500 bg-sky-500/15 text-sky-800 dark:border-sky-400 dark:text-sky-200'
                              : 'border-slate-200 bg-white/70 text-slate-700 hover:bg-white dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300'
                          }`}
                        >
                          <span>{displayName}</span>
                          <span className="font-mono-num text-[11px] text-slate-500 dark:text-slate-400">
                            · {room.onlinePlayers}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <input
                    type="text"
                    maxLength={20}
                    value={config.roomId}
                    onChange={(e) => onChangeConfig({ roomId: e.target.value })}
                    placeholder={t.roomPlaceholder}
                    className="mt-2.5 h-11 w-full rounded-xl border border-slate-200/90 bg-white/80 px-3 text-base font-medium text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900/70 dark:text-white sm:h-10 sm:text-xs"
                  />
                </div>
              )}

              {/* Game Mode */}
              <div className="mt-4">
                <div className="mb-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {t.gameMode}
                </div>
                <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80">
                  {modes.map((m) => {
                    const active = config.mode === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => onChangeConfig({ mode: m })}
                        className={`min-h-[48px] rounded-lg px-2 py-1.5 text-center transition-colors ${
                          active
                            ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        <div className="text-xs font-bold whitespace-nowrap">
                          {t.modes[m].title}
                        </div>
                        <div className="mt-0.5 line-clamp-1 text-[10px] text-slate-500 dark:text-slate-400">
                          {t.modes[m].desc}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Arena Theme */}
              <div className="mt-4">
                <div className="mb-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {t.arenaTheme}
                </div>
                <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80">
                  {themes.map((th) => {
                    const Icon = th.icon;
                    const active = config.theme === th.id;
                    return (
                      <button
                        key={th.id}
                        type="button"
                        onClick={() => onChangeConfig({ theme: th.id })}
                        className={`flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        <Icon className="h-3.5 w-3.5" />
                        <span>{th.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Show Mass & Control Customizer */}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-2.5">
                <label className="flex min-h-[42px] cursor-pointer items-center gap-2.5 text-xs font-medium text-slate-600 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={config.showMassOnCells}
                    onChange={(e) => onChangeConfig({ showMassOnCells: e.target.checked })}
                    className="h-5 w-5 rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span>{t.showMassLabel}</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setMoreOpen(false);
                    onOpenCustomizer();
                  }}
                  className="flex min-h-[42px] items-center gap-1.5 rounded-xl border border-slate-200/90 bg-white/75 px-3 py-2 text-xs font-semibold text-slate-700 transition-colors hover:bg-white dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5 text-sky-600 dark:text-sky-400" />
                  <span>{t.customizeControlsBtn}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2.5 border-t border-slate-200/70 bg-white/75 px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] dark:border-slate-800 dark:bg-slate-900/80 sm:px-6">
              <button
                type="button"
                onClick={() => {
                  setMoreOpen(false);
                  onStartGame();
                }}
                disabled={connecting}
                className="flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-orange-500 to-rose-600 px-5 py-2.5 text-sm font-black text-white shadow-md transition-all hover:brightness-105 active:scale-[0.99] disabled:opacity-60 whitespace-nowrap"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>
                  {connecting
                    ? t.connectingText
                    : config.playType === 'online'
                    ? t.joinOnlineGame
                    : t.startGame}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setMoreOpen(false)}
                className="flex min-h-[46px] items-center justify-center rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap"
              >
                {t.closeBtn}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
