import React, { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  X,
  Search,
  Sparkles,
  UploadCloud,
  ChevronRight,
  Layers,
  Clock,
  Info,
  List,
  Grid,
  ChevronDown,
  Check,
  Phone,
  RefreshCw,
} from "lucide-react";
import { MenuCategory, Dish } from "../types";
import { FoodCard } from "./FoodCard";
import { FoodDetailModal } from "./FoodDetailModal";
import { RESTAURANT_INFO } from "../data/restaurantInfo";
import { MenuSkeleton, CategoryRailSkeleton } from "./MenuSkeleton";

interface MenuOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  categories: MenuCategory[];
  initialCategorySlug?: string;
  onOpenImport: () => void;
  onOrderOnline?: (dish?: Dish) => void;
}

export const MenuOverlay: React.FC<MenuOverlayProps> = ({
  isOpen,
  onClose,
  categories,
  initialCategorySlug = "all",
  onOpenImport,
  onOrderOnline,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategorySlug);
  const [currentViewingCategory, setCurrentViewingCategory] = useState<string>(
    initialCategorySlug === "all" ? (categories[0]?.id || "all") : initialCategorySlug
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [activeDietaryFilter, setActiveDietaryFilter] = useState<string>("All");
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [isCategorySheetOpen, setIsCategorySheetOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"detailed" | "compact">("detailed");
  const [isLoading, setIsLoading] = useState(true);

  // Perceived performance: Trigger skeleton loading on menu opening or reconstruction
  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 420);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Perceived performance: Brief skeleton when categories are updated or reconstructed
  useEffect(() => {
    if (isOpen && categories.length > 0) {
      setIsLoading(true);
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [categories]);

  const containerRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);

  // Auto-scroll horizontal rail when active category changes
  useEffect(() => {
    if (railRef.current) {
      const targetId = selectedCategory !== "all" ? selectedCategory : currentViewingCategory;
      const activeBtn = railRef.current.querySelector(`[data-rail-id="${targetId}"]`) as HTMLElement;
      if (activeBtn) {
        activeBtn.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      }
    }
  }, [currentViewingCategory, selectedCategory]);

  // Sync initialCategorySlug when changed
  useEffect(() => {
    if (initialCategorySlug) {
      setSelectedCategory(initialCategorySlug);
      if (initialCategorySlug !== "all") {
        const found = categories.find(
          (c) => c.slug === initialCategorySlug || c.id === initialCategorySlug
        );
        if (found) setCurrentViewingCategory(found.id);
      } else {
        setCurrentViewingCategory(categories[0]?.id || "all");
      }
    }
  }, [initialCategorySlug, categories]);

  // Support Escape key to close menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (isCategorySheetOpen) {
          setIsCategorySheetOpen(false);
        } else if (!selectedDish) {
          onClose();
        }
      }
    };
    if (isOpen) {
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, selectedDish, isCategorySheetOpen, onClose]);

  // Scroll spy to detect which category section is currently in view
  useEffect(() => {
    const scrollContainer = containerRef.current;
    if (!scrollContainer || !isOpen) return;

    const handleScroll = () => {
      if (!scrollContainer) return;
      const containerRect = scrollContainer.getBoundingClientRect();
      const sections = scrollContainer.querySelectorAll<HTMLElement>("[data-category-id]");

      if (sections.length === 0) return;

      let activeId = sections[0].getAttribute("data-category-id") || "all";

      if (scrollContainer.scrollTop < 120) {
        activeId = sections[0].getAttribute("data-category-id") || "all";
      } else {
        sections.forEach((sec) => {
          const rect = sec.getBoundingClientRect();
          if (rect.top - containerRect.top <= 200 && rect.bottom - containerRect.top > 80) {
            const id = sec.getAttribute("data-category-id");
            if (id) activeId = id;
          }
        });
      }

      setCurrentViewingCategory(activeId);
    };

    scrollContainer.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();

    return () => {
      scrollContainer.removeEventListener("scroll", handleScroll);
    };
  }, [isOpen, categories, selectedCategory]);

  // Helper to filter dishes based on search query and dietary filter
  const filterDish = (dish: Dish) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matches =
        dish.name.toLowerCase().includes(q) ||
        dish.description.toLowerCase().includes(q) ||
        dish.price?.toLowerCase().includes(q) ||
        dish.dietaryLabel?.some((l) => l.toLowerCase().includes(q));
      if (!matches) return false;
    }

    if (activeDietaryFilter === "Veg Only") {
      const isNonVeg = dish.dietaryLabel?.some(
        (l) =>
          l.toLowerCase().includes("non-veg") ||
          l.toLowerCase().includes("chicken") ||
          l.toLowerCase().includes("fish") ||
          l.toLowerCase().includes("prawn")
      );
      if (isNonVeg) return false;
    } else if (activeDietaryFilter === "Non-Veg") {
      const isNonVeg = dish.dietaryLabel?.some(
        (l) =>
          l.toLowerCase().includes("non-veg") ||
          l.toLowerCase().includes("chicken") ||
          l.toLowerCase().includes("fish") ||
          l.toLowerCase().includes("prawn")
      );
      if (!isNonVeg) return false;
    } else if (activeDietaryFilter !== "All") {
      const matchesFilter = dish.dietaryLabel?.some(
        (l) => l.toLowerCase() === activeDietaryFilter.toLowerCase()
      );
      if (!matchesFilter) return false;
    }

    return true;
  };

  // Process categories and their filtered dishes
  const processedCategories = useMemo(() => {
    return categories
      .map((cat) => ({
        ...cat,
        filteredDishes: cat.dishes.filter(filterDish),
      }))
      .filter((cat) => cat.filteredDishes.length > 0 || (searchQuery === "" && activeDietaryFilter === "All"));
  }, [categories, searchQuery, activeDietaryFilter]);

  const totalFilteredDishesCount = useMemo(() => {
    return processedCategories.reduce((acc, cat) => acc + cat.filteredDishes.length, 0);
  }, [processedCategories]);

  // Handle clicking a category tab: smooth scroll directly to that category section
  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentViewingCategory(categoryId);
    setIsCategorySheetOpen(false);

    if (categoryId === "all") {
      containerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    const targetEl = document.getElementById(`category-section-${categoryId}`);
    if (targetEl && containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const targetRect = targetEl.getBoundingClientRect();
      const offsetTop = targetRect.top - containerRect.top + containerRef.current.scrollTop - 130;
      containerRef.current.scrollTo({ top: Math.max(0, offsetTop), behavior: "smooth" });
    }
  };

  const currentCategoryObj = useMemo(() => {
    return categories.find((c) => c.id === currentViewingCategory);
  }, [categories, currentViewingCategory]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        ref={containerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="menu-overlay-title"
        initial={{ opacity: 0, y: "100%" }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: "100%" }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="fixed inset-0 z-[90] bg-[#F4F0E7] text-[#17201C] overflow-y-auto flex flex-col scroll-smooth pb-20 sm:pb-8"
      >
        {/* Sticky Editorial Header */}
        <header className="sticky top-0 z-30 bg-[#F4F0E7]/95 backdrop-blur-md border-b border-[#D8D0C2] px-4 sm:px-6 py-3.5 sm:py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 sm:gap-6">
              <div>
                <span className="text-[9px] sm:text-[10px] tracking-[0.25em] uppercase text-[#17201C]/50 font-medium block">
                  VISAKHAPATNAM, INDIA
                </span>
                <h2 id="menu-overlay-title" className="font-serif text-xl sm:text-3xl tracking-tight text-[#17201C] leading-none">
                  KAL O R E E Z
                </h2>
              </div>
              <div className="hidden sm:block h-6 w-px bg-[#D8D0C2]" />
              <div className="hidden sm:flex items-center gap-2 text-xs font-sans text-[#17201C]/70">
                <span className="font-serif italic text-sm">Printed Digital Menu</span>
                <span className="text-[10px] text-[#9BAF82] font-mono">(Text & Pricing Ledger)</span>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">
              {/* Scan Upload for Admin */}
              <button
                type="button"
                onClick={onOpenImport}
                className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-[#D8D0C2] text-[11px] uppercase tracking-wider text-[#17201C]/80 hover:border-[#17201C] hover:bg-white transition-all cursor-pointer"
              >
                <UploadCloud className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Upload Scans</span>
              </button>

              {/* Quick Reconstruct & Skeleton Refresh Trigger */}
              <button
                type="button"
                onClick={() => {
                  setIsLoading(true);
                  setTimeout(() => setIsLoading(false), 550);
                }}
                title="Refresh and simulate menu reconstruction skeleton"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2] bg-[#FDFBF7] text-[10px] tracking-wider uppercase text-[#17201C]/80 hover:text-[#17201C] hover:border-[#17201C] transition-all cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 text-[#9BAF82] ${isLoading ? "animate-spin" : ""}`} />
                <span className="hidden md:inline">Refresh Ledger</span>
              </button>

              {/* View mode toggle */}
              <div className="hidden sm:flex items-center border border-[#D8D0C2] rounded-full p-0.5 bg-[#FDFBF7]">
                <button
                  onClick={() => setViewMode("detailed")}
                  title="Detailed View"
                  className={`p-1.5 rounded-full transition-colors ${
                    viewMode === "detailed" ? "bg-[#17201C] text-[#F4F0E7]" : "text-[#17201C]/60 hover:text-[#17201C]"
                  }`}
                >
                  <Grid className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewMode("compact")}
                  title="Compact View"
                  className={`p-1.5 rounded-full transition-colors ${
                    viewMode === "compact" ? "bg-[#17201C] text-[#F4F0E7]" : "text-[#17201C]/60 hover:text-[#17201C]"
                  }`}
                >
                  <List className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Close Button & Mobile Direct Call */}
              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                title="Direct Call Restaurant Host Desk"
                aria-label="Direct Call Restaurant Host Desk"
                className="sm:hidden w-8 h-8 rounded-full bg-[#9BAF82]/20 border border-[#9BAF82]/60 flex items-center justify-center text-emerald-900 active:scale-95 transition-transform"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-800" />
              </a>

              <button
                type="button"
                onClick={onClose}
                aria-label="Close menu"
                className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-2 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium uppercase tracking-widest hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors cursor-pointer"
              >
                <span>Close</span>
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </header>

        {/* Sticky Category Bar with Scroll Spy, Indicator Dots & Mobile Jump Trigger */}
        <div className="sticky top-[58px] sm:top-[65px] z-20 bg-[#F4F0E7]/95 backdrop-blur-md border-b border-[#D8D0C2] shadow-2xs">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 sm:py-3">
            {isLoading ? (
              <CategoryRailSkeleton />
            ) : (
              /* Scrollable Category Rail */
              <div ref={railRef} className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {/* Mobile Quick Category Selector Dropdown Button */}
              <button
                onClick={() => setIsCategorySheetOpen(true)}
                className="lg:hidden flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium tracking-wide whitespace-nowrap shrink-0 shadow-xs"
              >
                <Layers className="w-3 h-3 text-[#9BAF82]" />
                <span>Jump to Section</span>
                <ChevronDown className="w-3 h-3 text-[#9BAF82]" />
              </button>

              {/* "All Sections" Button */}
              <button
                data-rail-id="all"
                onClick={() => handleCategoryClick("all")}
                className={`group relative flex items-center gap-2 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-medium uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                  selectedCategory === "all"
                    ? "bg-[#17201C] text-[#F4F0E7] border border-[#17201C] shadow-xs"
                    : "bg-[#FDFBF7] text-[#17201C]/75 border border-[#D8D0C2] hover:border-[#17201C] hover:text-[#17201C]"
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full shrink-0 transition-colors ${
                    selectedCategory === "all"
                      ? "bg-[#9BAF82] shadow-[0_0_6px_#9BAF82]"
                      : "bg-transparent group-hover:bg-[#D8D0C2]"
                  }`}
                />
                <span>All Sections</span>
                <span
                  className={`text-[10px] font-mono ${
                    selectedCategory === "all" ? "text-[#9BAF82]" : "text-[#17201C]/40"
                  }`}
                >
                  ({totalFilteredDishesCount})
                </span>
                {selectedCategory === "all" && (
                  <span className="absolute -bottom-1.5 left-3 right-3 h-[2px] bg-[#9BAF82] rounded-full" />
                )}
              </button>

              {/* Individual Category Section Buttons with Dot Indicator */}
              {categories.map((cat) => {
                const isCurrent =
                  currentViewingCategory === cat.id || selectedCategory === cat.id;

                return (
                  <button
                    key={cat.id}
                    data-rail-id={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className={`group relative flex items-center gap-2 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-medium uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                      isCurrent
                        ? "bg-[#17201C] text-[#F4F0E7] border border-[#17201C] shadow-xs"
                        : "bg-[#FDFBF7] text-[#17201C]/75 border border-[#D8D0C2] hover:border-[#17201C] hover:text-[#17201C]"
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full shrink-0 transition-all ${
                        isCurrent
                          ? "bg-[#9BAF82] shadow-[0_0_6px_#9BAF82] scale-110"
                          : "bg-transparent group-hover:bg-[#D8D0C2]"
                      }`}
                    />
                    <span>{cat.name}</span>
                    <span
                      className={`text-[10px] font-mono ${
                        isCurrent ? "text-[#9BAF82]" : "text-[#17201C]/40"
                      }`}
                    >
                      ({cat.dishes.length})
                    </span>
                    {isCurrent && (
                      <span className="absolute -bottom-1.5 left-3 right-3 h-[2px] bg-[#9BAF82] rounded-full" />
                    )}
                  </button>
                );
              })}
            </div>
            )}

            {/* Informative Filter & Search Row */}
            <div className="mt-2.5 pt-2 border-t border-[#D8D0C2]/50 flex flex-col md:flex-row md:items-center justify-between gap-2.5 text-xs">
              {/* Active Section Info on Mobile / Desktop */}
              <div className="flex items-center justify-between md:justify-start gap-2 text-[#17201C]/80">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#9BAF82] shrink-0 animate-pulse" />
                  <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#17201C]/50 font-semibold">
                    Viewing:
                  </span>
                  <span className="font-serif italic text-sm text-[#17201C] truncate max-w-[200px] sm:max-w-none">
                    {currentCategoryObj ? currentCategoryObj.name : "All Categories"}
                  </span>
                </div>

                {/* Mobile View Toggle */}
                <button
                  onClick={() => setViewMode(viewMode === "detailed" ? "compact" : "detailed")}
                  className="sm:hidden text-[10px] tracking-wider uppercase font-semibold px-2 py-0.5 rounded border border-[#D8D0C2] bg-[#FDFBF7]"
                >
                  {viewMode === "detailed" ? "Compact View" : "Detailed View"}
                </button>
              </div>

              {/* Search & Dietary Filters */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Search */}
                <div className="relative flex-1 sm:w-60">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#17201C]/40" />
                  <input
                    type="text"
                    placeholder="Search dishes or price..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-7 py-1.5 rounded-full bg-[#FDFBF7] border border-[#D8D0C2] text-xs font-sans text-[#17201C] placeholder:text-[#17201C]/40 focus:outline-none focus:border-[#9BAF82]"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[#17201C]/40 hover:text-[#17201C]"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Dietary Filter Pills */}
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
                  {["All", "Veg Only", "Non-Veg", "High Protein", "Gluten-Free"].map((label) => (
                    <button
                      key={label}
                      onClick={() => setActiveDietaryFilter(label)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-sans tracking-wide uppercase transition-colors whitespace-nowrap cursor-pointer ${
                        activeDietaryFilter === label
                          ? "bg-[#9BAF82] text-[#17201C] font-semibold shadow-2xs"
                          : "bg-[#FDFBF7] text-[#17201C]/70 hover:text-[#17201C] border border-[#D8D0C2]/70"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 w-full flex-grow flex flex-col">
          {/* Informative Kitchen Ledger Banner */}
          <div className="mb-8 p-4 sm:p-5 rounded-xs bg-[#FDFBF7] border border-[#D8D0C2] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="text-[10px] tracking-[0.25em] uppercase text-[#9BAF82] font-semibold mb-1 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#9BAF82]" />
                <span>KALOREEZ KITCHEN STANDARDS</span>
              </div>
              <h1 className="font-serif text-2xl sm:text-3xl text-[#17201C]">
                The Wholesome Menu
              </h1>
              <p className="text-xs sm:text-sm text-[#17201C]/70 font-sans mt-1 max-w-2xl">
                Oats-thickened soups, 100% whole wheat breads, cold-pressed olive oil & pure ghee preparation. All items prepared fresh to order.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs font-sans text-[#17201C]/70 border-t md:border-t-0 md:border-l border-[#D8D0C2]/60 pt-3 md:pt-0 md:pl-6 shrink-0">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Prep: 15–20 mins</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] border border-emerald-700 inline-flex items-center justify-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-700" />
                </span>
                <span>Pure Veg</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] border border-[#B96D52] inline-flex items-center justify-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#B96D52]" />
                </span>
                <span>Non-Veg</span>
              </div>
            </div>
          </div>

          {/* Render Categories or Skeleton Loading */}
          {isLoading ? (
            <MenuSkeleton viewMode={viewMode} count={viewMode === "compact" ? 8 : 6} />
          ) : totalFilteredDishesCount > 0 ? (
            <div className="space-y-12 sm:space-y-16">
              {processedCategories.map((category) => {
                if (category.filteredDishes.length === 0) return null;
                const isCurrent = currentViewingCategory === category.id;

                return (
                  <section
                    key={category.id}
                    id={`category-section-${category.id}`}
                    data-category-id={category.id}
                    className="scroll-mt-40 transition-all"
                  >
                    {/* Category Title & Note Header */}
                    <div className="border-b border-[#D8D0C2] pb-3 mb-5 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
                      <div className="flex items-baseline gap-2.5">
                        <span
                          className={`w-2 h-2 rounded-full shrink-0 self-center transition-all ${
                            isCurrent ? "bg-[#9BAF82] scale-125" : "bg-[#D8D0C2]"
                          }`}
                        />
                        <h3 className="font-serif text-2xl sm:text-3xl text-[#17201C] tracking-tight">
                          {category.name}
                        </h3>
                        <span className="text-xs font-mono text-[#17201C]/50">
                          ({category.filteredDishes.length}{" "}
                          {category.filteredDishes.length === 1 ? "dish" : "dishes"})
                        </span>
                      </div>

                      {category.description && (
                        <p className="text-xs sm:text-sm text-[#17201C]/70 max-w-lg font-sans">
                          {category.description}
                        </p>
                      )}
                    </div>

                    {/* Dishes Grid or Compact List based on viewMode */}
                    {viewMode === "detailed" ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                        {category.filteredDishes.map((dish) => (
                          <FoodCard
                            key={dish.id}
                            dish={dish}
                            onSelect={(d) => setSelectedDish(d)}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="divide-y divide-[#D8D0C2]/60 bg-[#FDFBF7] border border-[#D8D0C2] rounded-xs overflow-hidden">
                        {category.filteredDishes.map((dish) => {
                          const isNonVeg = dish.dietaryLabel?.some(
                            (l) =>
                              l.toLowerCase().includes("non-veg") ||
                              l.toLowerCase().includes("chicken") ||
                              l.toLowerCase().includes("fish") ||
                              l.toLowerCase().includes("prawn")
                          );

                          return (
                            <div
                              key={dish.id}
                              onClick={() => setSelectedDish(dish)}
                              className="p-3.5 sm:p-4 hover:bg-[#F4F0E7]/60 cursor-pointer transition-colors flex items-start justify-between gap-4"
                            >
                              <div className="flex items-start gap-3">
                                <span
                                  className={`inline-flex items-center justify-center w-3.5 h-3.5 border rounded-[2px] shrink-0 mt-1 ${
                                    isNonVeg ? "border-[#B96D52]" : "border-emerald-700"
                                  }`}
                                >
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      isNonVeg ? "bg-[#B96D52]" : "bg-emerald-700"
                                    }`}
                                  />
                                </span>
                                <div>
                                  <div className="font-serif text-base sm:text-lg text-[#17201C] font-medium leading-snug">
                                    {dish.name}
                                  </div>
                                  <p className="text-xs text-[#17201C]/70 font-sans mt-0.5 line-clamp-1 sm:line-clamp-2">
                                    {dish.description}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right shrink-0">
                                <div className="font-serif text-base text-[#17201C] font-semibold">
                                  {dish.price}
                                </div>
                                <span className="text-[10px] text-[#9BAF82] uppercase tracking-wider font-semibold">
                                  Details →
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </section>
                );
              })}
            </div>
          ) : (
            <div className="my-12 text-center py-12 border border-dashed border-[#D8D0C2] rounded-xs bg-[#FDFBF7]/60">
              <Sparkles className="w-8 h-8 mx-auto mb-3 text-[#9BAF82] stroke-1" />
              <h3 className="font-serif text-2xl text-[#17201C] mb-1">No Matching Dishes</h3>
              <p className="text-xs text-[#17201C]/60 font-sans max-w-sm mx-auto mb-4">
                No items match your active search and dietary filter.
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setActiveDietaryFilter("All");
                  setSelectedCategory("all");
                }}
                className="px-4 py-2 rounded-full border border-[#17201C] text-xs uppercase tracking-wider hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}

          {/* Bottom Footer Note */}
          <div className="mt-14 pt-8 border-t border-[#D8D0C2]/60 text-center text-xs text-[#17201C]/60 font-sans space-y-1">
            <p className="font-serif italic text-sm text-[#17201C]/80">
              Kaloreez Wholesome Eatery · Visakhapatnam
            </p>
            <p>Plot 95, Oota Gadda Road, Daspalla Hills, Pandurangapuram, Vizag</p>
            <p className="text-[11px] text-[#17201C]/50">
              All dishes prepared fresh to order. Please let us know if you have specific food sensitivities.
            </p>
          </div>
        </main>

        {/* Floating Mobile Category Jump Pill (Thumb Accessible on Mobile) */}
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 sm:hidden">
          <button
            type="button"
            onClick={() => setIsCategorySheetOpen(true)}
            className="flex items-center gap-2.5 px-5 py-3 rounded-full bg-[#17201C] text-[#F4F0E7] shadow-2xl border border-[#D8D0C2]/60 active:scale-95 transition-transform"
          >
            <Layers className="w-4 h-4 text-[#9BAF82]" />
            <span className="text-xs font-semibold tracking-wider uppercase">
              Sections ({categories.length})
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#9BAF82]" />
          </button>
        </div>

        {/* Mobile Category Bottom Drawer / Modal */}
        {isCategorySheetOpen && (
          <div className="fixed inset-0 z-[95] flex items-end justify-center">
            <div
              onClick={() => setIsCategorySheetOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />
            <div className="relative z-10 w-full max-h-[80vh] bg-[#FDFBF7] rounded-t-2xl border-t border-[#D8D0C2] overflow-hidden flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-300">
              {/* Drawer Handle & Header */}
              <div className="p-4 border-b border-[#D8D0C2] flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-lg text-[#17201C]">Browse Menu Categories</h4>
                  <p className="text-[11px] text-[#17201C]/60 font-sans">
                    Tap to jump directly to any culinary section
                  </p>
                </div>
                <button
                  onClick={() => setIsCategorySheetOpen(false)}
                  className="w-8 h-8 rounded-full bg-[#EAE4D7] flex items-center justify-center text-[#17201C]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Category List */}
              <div className="overflow-y-auto p-4 divide-y divide-[#D8D0C2]/40">
                <button
                  onClick={() => handleCategoryClick("all")}
                  className={`w-full py-3 px-2 flex items-center justify-between text-left text-sm font-sans ${
                    selectedCategory === "all" ? "text-[#9BAF82] font-semibold" : "text-[#17201C]"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        selectedCategory === "all" ? "bg-[#9BAF82]" : "bg-transparent"
                      }`}
                    />
                    <span>All Menu Sections</span>
                  </div>
                  <span className="text-xs text-[#17201C]/50">({totalFilteredDishesCount})</span>
                </button>

                {categories.map((cat) => {
                  const isCurrent = currentViewingCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={`w-full py-3 px-2 flex items-center justify-between text-left text-sm font-sans ${
                        isCurrent ? "text-[#9BAF82] font-semibold" : "text-[#17201C]"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isCurrent ? "bg-[#9BAF82]" : "bg-transparent"
                          }`}
                        />
                        <span>{cat.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-[#17201C]/50">({cat.dishes.length})</span>
                        {isCurrent && <Check className="w-3.5 h-3.5 text-[#9BAF82]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Dish Detail Modal */}
        {selectedDish && (
          <FoodDetailModal
            dish={selectedDish}
            onClose={() => setSelectedDish(null)}
            onOrderOnline={(d) => {
              setSelectedDish(null);
              onClose();
              if (onOrderOnline) onOrderOnline(d);
            }}
          />
        )}
      </motion.div>
    </AnimatePresence>
  );
};
