import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { EbookCard } from './EbookCard';
import {
  Train,
  ShieldAlert,
  Landmark,
  Award,
  Briefcase,
  Crosshair,
  Filter,
  ArrowUpDown,
  BookOpen,
  RotateCcw,
  Check
} from 'lucide-react';

export const CategoryBrowseView: React.FC = () => {
  const {
    ebooks,
    categories,
    selectedCategory,
    setSelectedCategory
  } = useApp();

  // Filters state
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('All');
  const [selectedLang, setSelectedLang] = useState<string>('All');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'popularity' | 'price-asc' | 'price-desc' | 'rating' | 'newest'>('popularity');
  const [freeOnly, setFreeOnly] = useState(false);

  const currentCategory = categories.find((c) => c.id === selectedCategory) || categories[0];

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'railway': return Train;
      case 'assam-police': return ShieldAlert;
      case 'assam-govt-jobs': return Landmark;
      case 'ssc-central': return Award;
      case 'banking-finance': return Briefcase;
      case 'defence-tech': return Crosshair;
      default: return BookOpen;
    }
  };

  // Filter logic
  let filteredBooks = ebooks.filter((book) => {
    // Category match
    const matchesCategory = !selectedCategory || book.categoryId === selectedCategory;

    // Subcategory match
    const matchesSub =
      selectedSubCategory === 'All' ||
      book.subCategory.toLowerCase() === selectedSubCategory.toLowerCase() ||
      book.targetExam.toLowerCase().includes(selectedSubCategory.toLowerCase());

    // Language match
    const matchesLang =
      selectedLang === 'All' ||
      book.language.toLowerCase().includes(selectedLang.toLowerCase());

    // Price range match
    let matchesPrice = true;
    if (selectedPriceRange === 'free') matchesPrice = book.isFree;
    else if (selectedPriceRange === 'under-150') matchesPrice = book.price < 150 && !book.isFree;
    else if (selectedPriceRange === '150-250') matchesPrice = book.price >= 150 && book.price <= 250;
    else if (selectedPriceRange === 'above-250') matchesPrice = book.price > 250;

    const matchesFree = !freeOnly || book.isFree;

    return matchesCategory && matchesSub && matchesLang && matchesPrice && matchesFree;
  });

  // Sorting
  filteredBooks = [...filteredBooks].sort((a, b) => {
    if (sortBy === 'popularity') return b.ratingCount - a.ratingCount;
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
    return 0;
  });

  const resetFilters = () => {
    setSelectedSubCategory('All');
    setSelectedLang('All');
    setSelectedPriceRange('All');
    setFreeOnly(false);
    setSortBy('popularity');
  };

  const hasActiveFilters =
    selectedSubCategory !== 'All' ||
    selectedLang !== 'All' ||
    selectedPriceRange !== 'All' ||
    freeOnly;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 sm:py-8">
      {/* Category Navigation Pills */}
      <div className="mb-6">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
          Select Competitive Exam Stream:
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {categories.map((cat) => {
            const Icon = getCategoryIcon(cat.id);
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  setSelectedSubCategory('All');
                }}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                  isSelected
                    ? 'bg-[#0B192C] text-white border-[#0B192C] shadow-md ring-2 ring-amber-400'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <Icon className={`w-5 h-5 ${isSelected ? 'text-amber-400' : 'text-slate-600'}`} />
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    isSelected ? 'bg-amber-400 text-slate-950' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {cat.count}
                  </span>
                </div>
                <div className="mt-2.5">
                  <span className="text-xs font-bold leading-tight block">
                    {cat.name}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Category Banner */}
      <div className="bg-gradient-to-r from-[#0B192C] to-[#1E3E62] text-white rounded-2xl p-5 sm:p-6 mb-6 border border-[#1E3E62] shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
              {currentCategory.count} Verified Publications Available
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1">
              {currentCategory.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              {currentCategory.description}
            </p>
          </div>

          {selectedCategory && (
            <button
              onClick={() => setSelectedCategory(null)}
              className="text-xs font-bold text-amber-300 hover:text-white bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              Show All Exam Categories
            </button>
          )}
        </div>

        {/* Sub-categories row */}
        {currentCategory.subCategories.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-700/60 flex items-center gap-1.5 overflow-x-auto text-xs">
            <span className="text-slate-400 font-semibold text-[11px] shrink-0 mr-1">
              Filter by Post / Exam:
            </span>
            <button
              onClick={() => setSelectedSubCategory('All')}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedSubCategory === 'All'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              All Sub-Exams
            </button>
            {currentCategory.subCategories.map((sub) => (
              <button
                key={sub}
                onClick={() => setSelectedSubCategory(sub)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedSubCategory === sub
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Filter and Sort Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 mb-6 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-slate-500 font-bold uppercase tracking-wider mr-1">
            <Filter className="w-3.5 h-3.5" /> Filters:
          </div>

          {/* Language filter */}
          <select
            value={selectedLang}
            onChange={(e) => setSelectedLang(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-semibold text-slate-700 outline-none focus:border-amber-500"
          >
            <option value="All">All Languages</option>
            <option value="Assamese">Assamese (অসমীয়া)</option>
            <option value="English">English</option>
            <option value="Hindi">Hindi (हिंदी)</option>
            <option value="Bengali">Bengali (বাংলা)</option>
          </select>

          {/* Price filter */}
          <select
            value={selectedPriceRange}
            onChange={(e) => setSelectedPriceRange(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-semibold text-slate-700 outline-none focus:border-amber-500"
          >
            <option value="All">All Prices</option>
            <option value="free">100% Free Only</option>
            <option value="under-150">Under ₹150</option>
            <option value="150-250">₹150 - ₹250</option>
            <option value="above-250">Above ₹250</option>
          </select>

          {/* Free checkbox */}
          <label className="flex items-center gap-1.5 cursor-pointer select-none text-slate-700 font-bold bg-emerald-50 border border-emerald-200 px-2.5 py-1.5 rounded-xl">
            <input
              type="checkbox"
              checked={freeOnly}
              onChange={(e) => setFreeOnly(e.target.checked)}
              className="rounded text-emerald-600 focus:ring-emerald-400"
            />
            <span className="text-emerald-800">Free Ebooks</span>
          </label>

          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              className="text-red-600 hover:text-red-800 flex items-center gap-1 font-bold underline ml-1"
            >
              <RotateCcw className="w-3 h-3" /> Reset
            </button>
          )}
        </div>

        {/* Sort by */}
        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-semibold flex items-center gap-1">
            <ArrowUpDown className="w-3 h-3" /> Sort By:
          </span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none focus:border-amber-500"
          >
            <option value="popularity">Most Popular / High Enrolment</option>
            <option value="rating">Highest Rated (★ 4.9+)</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="newest">New Arrivals (2026 Editions)</option>
          </select>
        </div>
      </div>

      {/* Ebooks Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Showing {filteredBooks.length} Ebooks for Preparation
          </span>
        </div>

        {filteredBooks.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <h3 className="text-base font-bold text-slate-800">
              No ebooks match your selected filter criteria
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try selecting "All Languages" or reset price constraints to view available study material.
            </p>
            <button
              onClick={resetFilters}
              className="mt-4 bg-[#0B192C] text-amber-400 font-bold text-xs px-5 py-2 rounded-xl transition-all"
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {filteredBooks.map((ebook) => (
              <EbookCard key={ebook.id} ebook={ebook} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
