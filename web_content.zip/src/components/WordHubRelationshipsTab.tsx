import {
  ArrowUpLeft,
  Bookmark,
  GitCompare,
  Layers,
  Network,
  RotateCcw,
  Volume2,
} from 'lucide-react';
import type { SavedWordNote, SavedWordNoteKind, WordHubData } from '../types';
import { WordHubCollapsibleCard } from './WordHubCollapsibleCard';

interface WordHubRelationshipsTabProps {
  wordEn: string;
  hub: WordHubData | null;
  loading: boolean;
  hideTranslation: boolean;
  savedNoteIds: Set<string>;
  onSpeak: (text: string) => void;
  onExploreWord: (targetWord: string, glossAr?: string) => void;
  onToggleSaveNote: (note: Omit<SavedWordNote, 'savedAt'>) => void;
}

function makeNoteId(parentWord: string, kind: SavedWordNoteKind, text: string): string {
  return `${parentWord.toLowerCase()}::${kind}::${text.toLowerCase().trim()}`;
}

export function WordHubRelationshipsTab({
  wordEn,
  hub,
  loading,
  hideTranslation,
  savedNoteIds,
  onSpeak,
  onExploreWord,
  onToggleSaveNote,
}: WordHubRelationshipsTabProps) {
  if (loading && !hub) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((k) => (
          <div
            key={k}
            className="h-28 animate-pulse rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#131c2e]"
          />
        ))}
      </div>
    );
  }

  const synonyms = hub?.synonyms || [];
  const antonyms = hub?.antonyms || [];
  const wordFamily = hub?.wordFamily || [];
  const relatedWords = hub?.relatedWords || [];
  const hasAny =
    synonyms.length > 0 ||
    antonyms.length > 0 ||
    wordFamily.length > 0 ||
    relatedWords.length > 0;

  if (!hasAny) {
    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e]">
        <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
          لم تتوفر علاقات لغوية إضافية لهذه الكلمة حالياً.
        </p>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          نحن نعرض فقط المرادفات والأضداد والاشتقاقات الموثوقة لغوياً دون اختلاق.
        </p>
      </section>
    );
  }

  return (
    <div className="space-y-4">
      {/* 1. Synonyms */}
      {synonyms.length > 0 && (
        <WordHubCollapsibleCard
          title="المرادفات والفرق الدقيق"
          subtitle="اضغط على أي مرادف لفتح صفحته التعليمية الكاملة"
          count={synonyms.length}
          icon={<GitCompare className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {synonyms.map((syn) => {
              const noteId = makeNoteId(wordEn, 'synonym', syn.word);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div key={syn.word} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => onExploreWord(syn.word, syn.ar)}
                        className="inline-flex items-center gap-1.5 font-en text-base font-extrabold text-indigo-600 hover:underline dark:text-indigo-400"
                        dir="ltr"
                      >
                        <span>{syn.word}</span>
                        <ArrowUpLeft className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                            {syn.ar}
                          </span>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSpeak(syn.word)}
                        aria-label={`نطق ${syn.word}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleSaveNote({
                            id: noteId,
                            parentWord: wordEn,
                            kind: 'synonym',
                            text: syn.word,
                            meaningAr: syn.ar,
                            extra: syn.nuanceAr,
                          })
                        }
                        aria-label={isSaved ? `إزالة ${syn.word} من المحفوظات` : `حفظ المرادف ${syn.word}`}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-colors ${
                          isSaved
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-600 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-300'
                            : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                      </button>
                    </div>
                  </div>

                  {syn.nuanceAr && (
                    <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                      <span className="font-bold text-slate-800 dark:text-slate-100">الفرق الدقيق: </span>
                      {syn.nuanceAr}
                    </p>
                  )}

                  {syn.exampleEn && (
                    <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-3.5 py-2.5 dark:bg-slate-900/60">
                      <div className="min-w-0 flex-1 space-y-0.5">
                        <p dir="ltr" className="text-left font-en text-xs font-semibold text-slate-800 dark:text-slate-200 sm:text-sm">
                          {syn.exampleEn}
                        </p>
                        {!hideTranslation && syn.exampleAr && (
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {syn.exampleAr}
                          </p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onSpeak(syn.exampleEn)}
                        aria-label={`نطق مثال ${syn.word}`}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 2. Antonyms (ONLY displayed if real antonyms exist — never invented!) */}
      {antonyms.length > 0 && (
        <WordHubCollapsibleCard
          title="الأضداد المباشرة"
          subtitle="المعاني المعاكسة الحقيقية مع شرح التباين"
          count={antonyms.length}
          icon={<RotateCcw className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {antonyms.map((ant) => {
              const noteId = makeNoteId(wordEn, 'antonym', ant.word);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div key={ant.word} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => onExploreWord(ant.word, ant.ar)}
                        className="inline-flex items-center gap-1.5 font-en text-base font-extrabold text-rose-600 hover:underline dark:text-rose-400"
                        dir="ltr"
                      >
                        <span>{ant.word}</span>
                        <ArrowUpLeft className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                            {ant.ar}
                          </span>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSpeak(ant.word)}
                        aria-label={`نطق ${ant.word}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleSaveNote({
                            id: noteId,
                            parentWord: wordEn,
                            kind: 'antonym',
                            text: ant.word,
                            meaningAr: ant.ar,
                            extra: ant.contrastAr,
                          })
                        }
                        aria-label={isSaved ? `إزالة ${ant.word} من المحفوظات` : `حفظ الضد ${ant.word}`}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-colors ${
                          isSaved
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-600 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-300'
                            : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                      </button>
                    </div>
                  </div>

                  {ant.contrastAr && (
                    <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                      <span className="font-bold text-slate-800 dark:text-slate-100">وجه التضاد: </span>
                      {ant.contrastAr}
                    </p>
                  )}

                  {ant.exampleEn && (
                    <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-3.5 py-2.5 dark:bg-slate-900/60">
                      <div className="min-w-0 flex-1 space-y-0.5">
                        <p dir="ltr" className="text-left font-en text-xs font-semibold text-slate-800 dark:text-slate-200 sm:text-sm">
                          {ant.exampleEn}
                        </p>
                        {!hideTranslation && ant.exampleAr && (
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {ant.exampleAr}
                          </p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onSpeak(ant.exampleEn)}
                        aria-label={`نطق مثال ${ant.word}`}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 3. Word Family (Real Derivatives Only) */}
      {wordFamily.length > 0 && (
        <WordHubCollapsibleCard
          title="عائلة الكلمة والاشتقاقات"
          subtitle="المشتقات الحقيقية المتداولة فقط حسب نوع الكلمة"
          count={wordFamily.length}
          icon={<Layers className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {wordFamily.map((fam) => {
              const noteId = makeNoteId(wordEn, 'derivative', `${fam.word}-${fam.pos}`);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div
                  key={`${fam.word}-${fam.pos}`}
                  className="flex flex-col justify-between rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-900/50"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                          {fam.pos} · {fam.posAr}
                        </div>
                        <button
                          type="button"
                          onClick={() => onExploreWord(fam.word, fam.ar)}
                          className="mt-0.5 inline-flex items-center gap-1 font-en text-base font-extrabold text-indigo-600 hover:underline dark:text-indigo-400"
                          dir="ltr"
                        >
                          <span>{fam.word}</span>
                          <ArrowUpLeft className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onSpeak(fam.word)}
                          aria-label={`نطق ${fam.word}`}
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
                        >
                          <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onToggleSaveNote({
                              id: noteId,
                              parentWord: wordEn,
                              kind: 'derivative',
                              text: fam.word,
                              meaningAr: `${fam.ar} (${fam.posAr})`,
                              extra: fam.exampleEn,
                            })
                          }
                          aria-label={isSaved ? `إزالة ${fam.word}` : `حفظ ${fam.word}`}
                          className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                            isSaved
                              ? 'text-indigo-600 dark:text-indigo-400'
                              : 'text-slate-400 hover:bg-slate-200/70 dark:hover:bg-slate-800'
                          }`}
                        >
                          <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                        </button>
                      </div>
                    </div>

                    {!hideTranslation && (
                      <p className="mt-1 text-sm font-bold text-slate-800 dark:text-slate-200">
                        {fam.ar}
                      </p>
                    )}
                  </div>

                  {fam.exampleEn && (
                    <p
                      dir="ltr"
                      className="mt-2.5 border-t border-slate-200/70 pt-2 text-left font-en text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300"
                    >
                      {fam.exampleEn}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 4. Related Words */}
      {relatedWords.length > 0 && (
        <WordHubCollapsibleCard
          title="كلمات مرتبطة موضوعياً"
          subtitle="مفردات تنتمي لنفس الحقل الدلالي وتوسّع حصيلتك"
          count={relatedWords.length}
          icon={<Network className="h-4 w-4" aria-hidden="true" />}
          defaultOpen={synonyms.length === 0 && wordFamily.length === 0}
        >
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {relatedWords.map((rel) => {
              const noteId = makeNoteId(wordEn, 'related', rel.word);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div
                  key={rel.word}
                  className="flex items-start justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50/50 p-3 dark:border-slate-800 dark:bg-slate-900/50"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onExploreWord(rel.word, rel.ar)}
                        className="inline-flex items-center gap-1 font-en text-sm font-extrabold text-indigo-600 hover:underline dark:text-indigo-400"
                        dir="ltr"
                      >
                        <span>{rel.word}</span>
                        <ArrowUpLeft className="h-3 w-3" aria-hidden="true" />
                      </button>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                            {rel.ar}
                          </span>
                        </>
                      )}
                    </div>
                    {rel.relationAr && (
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {rel.relationAr}
                      </p>
                    )}
                  </div>

                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onSpeak(rel.word)}
                      aria-label={`نطق ${rel.word}`}
                      className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
                    >
                      <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onToggleSaveNote({
                          id: noteId,
                          parentWord: wordEn,
                          kind: 'related',
                          text: rel.word,
                          meaningAr: rel.ar,
                          extra: rel.relationAr,
                        })
                      }
                      aria-label={isSaved ? `إزالة ${rel.word}` : `حفظ ${rel.word}`}
                      className={`flex h-7 w-7 items-center justify-center rounded-lg transition-colors ${
                        isSaved
                          ? 'text-indigo-600 dark:text-indigo-400'
                          : 'text-slate-400 hover:bg-slate-200/70 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}
    </div>
  );
}
