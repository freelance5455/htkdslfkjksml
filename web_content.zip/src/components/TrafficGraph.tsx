import React, { useMemo } from 'react';
import { ArrowDown, ArrowUp, Activity, Database } from 'lucide-react';
import { TrafficStats, ConnectionStatus } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';

interface TrafficGraphProps {
  stats: TrafficStats;
  history: { down: number; up: number }[];
  status: ConnectionStatus;
  language: Language;
}

export const TrafficGraph: React.FC<TrafficGraphProps> = ({
  stats,
  history,
  status,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const isConnected = status === 'connected';

  // Format bytes / MB
  const formatData = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(2)} ${t.gb}`;
    }
    return `${mb.toFixed(1)} ${t.mb}`;
  };

  // SVG dimensions
  const svgWidth = 300;
  const svgHeight = 70;

  // Generate SVG path for download traffic
  const downloadPath = useMemo(() => {
    if (history.length === 0) return '';
    const maxVal = Math.max(...history.map(h => h.down), 5);
    const step = svgWidth / Math.max(history.length - 1, 1);

    const points = history.map((pt, i) => {
      const x = i * step;
      const y = svgHeight - (pt.down / maxVal) * (svgHeight - 10) - 5;
      return `${x},${y}`;
    });

    return `M 0,${svgHeight} L ${points.join(' L ')} L ${svgWidth},${svgHeight} Z`;
  }, [history]);

  const downloadLine = useMemo(() => {
    if (history.length === 0) return '';
    const maxVal = Math.max(...history.map(h => h.down), 5);
    const step = svgWidth / Math.max(history.length - 1, 1);

    const points = history.map((pt, i) => {
      const x = i * step;
      const y = svgHeight - (pt.down / maxVal) * (svgHeight - 10) - 5;
      return `${x},${y}`;
    });

    return `M ${points.join(' L ')}`;
  }, [history]);

  return (
    <div className="w-full bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
      {/* Title Bar */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            {t.liveTraffic}
          </h3>
        </div>
        <span className="text-xs font-mono text-slate-400">
          {isConnected ? 'Realtime 1s poll' : 'Idle'}
        </span>
      </div>

      {/* Speed Metrics Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Download Speed */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <ArrowDown className="w-3.5 h-3.5 text-emerald-500" />
            <span>{t.downloadSpeed}</span>
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono tabular-nums text-slate-900 dark:text-white">
            {isConnected ? stats.downloadSpeed.toFixed(1) : '0.0'}
            <span className="text-xs font-medium text-slate-400 ml-1">
              {stats.downloadSpeed > 1000 ? t.mbps : t.kbps}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            {t.totalData}: <strong className="text-slate-700 dark:text-slate-300">{formatData(stats.totalDownloaded)}</strong>
          </div>
        </div>

        {/* Upload Speed */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <ArrowUp className="w-3.5 h-3.5 text-indigo-500" />
            <span>{t.uploadSpeed}</span>
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono tabular-nums text-slate-900 dark:text-white">
            {isConnected ? stats.uploadSpeed.toFixed(1) : '0.0'}
            <span className="text-xs font-medium text-slate-400 ml-1">
              {stats.uploadSpeed > 1000 ? t.mbps : t.kbps}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            {t.totalData}: <strong className="text-slate-700 dark:text-slate-300">{formatData(stats.totalUploaded)}</strong>
          </div>
        </div>
      </div>

      {/* SVG Real-time Wave Graph */}
      <div className="w-full h-20 bg-slate-50 dark:bg-slate-950 rounded-xl overflow-hidden relative border border-slate-100 dark:border-slate-800/80 flex items-end">
        {isConnected && downloadPath ? (
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-full preserve-3d"
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id="trafficGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10B981" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#10B981" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            <path d={downloadPath} fill="url(#trafficGradient)" />
            <path d={downloadLine} fill="none" stroke="#10B981" strokeWidth="2" strokeLinecap="round" />
          </svg>
        ) : (
          <div className="w-full h-full flex items-center justify-center text-xs text-slate-400 font-mono">
            {isConnected ? 'Gathering packet flow...' : 'Tunnel inactive · No packets'}
          </div>
        )}
      </div>

      {/* Bottom Summary Bar */}
      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1">
          <Database className="w-3.5 h-3.5 text-slate-400" />
          <span>{t.totalData}: <strong className="text-slate-800 dark:text-slate-200">{formatData(stats.totalDownloaded + stats.totalUploaded)}</strong></span>
        </span>
        <span className="font-mono text-[11px]">
          MTU: 1420 · MSS: 1380
        </span>
      </div>
    </div>
  );
};
