import React from 'react';
import {
  Battery,
  BatteryCharging,
  AlertTriangle,
  Flame,
  RefreshCw,
  ShieldCheck,
  Zap,
  Clock,
} from 'lucide-react';
import { ThermalTier, getThermalTierStyles } from '../utils/thermal';

interface BatteryHeroCardProps {
  batteryTemp: number;
  tier: ThermalTier;
  batteryLevel: number;
  isCharging: boolean;
  chargingType: 'none' | 'slow' | 'fast' | 'wireless';
  lastUpdated: Date;
  isRefreshing: boolean;
  onRefresh: () => void;
}

export const BatteryHeroCard: React.FC<BatteryHeroCardProps> = ({
  batteryTemp,
  tier,
  batteryLevel,
  isCharging,
  lastUpdated,
  isRefreshing,
  onRefresh,
}) => {
  const styles = getThermalTierStyles(tier);

  return (
    <section
      aria-label="Riquadro Principale Temperatura Batteria"
      className={`relative w-full rounded-3xl p-5 sm:p-7 transition-all duration-300 border-2 ${styles.bgClass} ${styles.borderClass} overflow-hidden`}
    >
      {/* Background glow effect for warning / danger */}
      {tier === 'red' && (
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-red-600/20 blur-3xl rounded-full pointer-events-none" />
      )}
      {tier === 'orange' && (
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-amber-500/15 blur-3xl rounded-full pointer-events-none" />
      )}

      {/* Top Bar inside Big Box: Badge + Refresh Button */}
      <div className="flex items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs tracking-wider uppercase font-semibold ${styles.badgeBg}`}
          >
            {tier === 'red' ? (
              <Flame className="w-3.5 h-3.5" />
            ) : tier === 'orange' ? (
              <AlertTriangle className="w-3.5 h-3.5" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5" />
            )}
            {styles.label}
          </span>
          <span className="hidden sm:inline-block text-xs text-neutral-400">
            {styles.sublabel}
          </span>
        </div>

        {/* Tasto Aggiorna principale */}
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          aria-label="Aggiorna temperatura batteria"
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-900/95 hover:bg-neutral-850 active:scale-95 text-white border border-emerald-500/60 hover:border-emerald-400 transition cursor-pointer text-xs font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500 shrink-0"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 text-emerald-400 ${
              isRefreshing ? 'animate-spin' : ''
            }`}
          />
          <span>{isRefreshing ? 'Aggiorno...' : 'AGGIORNA'}</span>
        </button>
      </div>

      {/* Central Temperature Display */}
      <div className="flex flex-col sm:flex-row items-baseline sm:items-center justify-between gap-4 my-2">
        <div>
          <span className="text-xs tracking-wider text-neutral-400 uppercase font-medium block mb-1">
            Temperatura Batteria Reale
          </span>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-6xl sm:text-7xl font-mono font-bold tracking-tight ${styles.textClass}`}
            >
              {batteryTemp.toFixed(1)}
            </span>
            <span className="text-3xl sm:text-4xl font-mono font-semibold text-neutral-400">
              °C
            </span>
            <span className="text-xs text-neutral-500 font-mono ml-1">
              ({((batteryTemp * 9) / 5 + 32).toFixed(1)}°F)
            </span>
          </div>
        </div>

        {/* Live Battery & Charge Level */}
        <div className="flex items-center gap-4 bg-neutral-950/80 border border-neutral-800 rounded-2xl p-3.5 min-w-[200px]">
          <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300">
            {isCharging ? (
              <BatteryCharging className="w-6 h-6 text-emerald-400" />
            ) : (
              <Battery className="w-6 h-6 text-neutral-300" />
            )}
          </div>
          <div>
            <div className="text-xs text-neutral-400 flex items-center gap-1.5">
              <span>Carica Residua</span>
              {isCharging && (
                <span className="inline-flex items-center text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-1.5 py-0.5 rounded">
                  <Zap className="w-2.5 h-2.5 mr-0.5" /> In Carica
                </span>
              )}
            </div>
            <div className="text-xl font-bold font-mono text-neutral-100">
              {Math.round(batteryLevel)}%
            </div>
            <div className="text-[11px] text-neutral-400">
              {isCharging
                ? 'Ricarica attiva (sviluppa calore)'
                : 'Uso a batteria'}
            </div>
          </div>
        </div>
      </div>

      {/* Threshold Progress Bar */}
      <div className="mt-4 pt-3 border-t border-neutral-800/60">
        <div className="flex justify-between items-center text-xs mb-1.5 font-mono">
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            &lt; 37°C Ottimale
          </span>
          <span className="text-amber-400 flex items-center gap-1 font-semibold">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            37°C Soglia Arancione
          </span>
          <span className="text-red-400 flex items-center gap-1 font-semibold">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            39°C Soglia Rossa
          </span>
        </div>

        {/* Visual Range Indicator Bar */}
        <div className="w-full bg-neutral-900 h-2.5 rounded-full overflow-hidden flex relative">
          {/* Safe Zone (up to 37°C, ~60%) */}
          <div className="w-[60%] bg-emerald-600/70 h-full border-r border-black" />
          {/* Warning Zone (37-39°C, ~15%) */}
          <div className="w-[15%] bg-amber-500 h-full border-r border-black" />
          {/* Danger Zone (>39°C, ~25%) */}
          <div className="w-[25%] bg-red-600 h-full" />

          {/* Current Needle Marker */}
          <div
            className="absolute top-0 bottom-0 w-1.5 bg-white shadow-[0_0_8px_white] transition-all duration-300"
            style={{
              left: `${Math.min(
                98,
                Math.max(2, ((batteryTemp - 25) / (45 - 25)) * 100)
              )}%`,
            }}
          />
        </div>
      </div>

      {/* Action Advice & Last Update info */}
      <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <p className={`font-medium ${styles.textClass}`}>
          {styles.actionAdvice}
        </p>
        <div className="flex items-center gap-1.5 text-neutral-400 font-mono text-[11px] shrink-0">
          <Clock className="w-3.5 h-3.5" />
          <span>Ultimo aggiornamento: {lastUpdated.toLocaleTimeString()}</span>
        </div>
      </div>
    </section>
  );
};
