import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Radio, 
  Smartphone, 
  Zap, 
  ArrowRightLeft, 
  CheckCircle2, 
  RefreshCw, 
  ShieldCheck, 
  Sparkles, 
  TrendingUp, 
  DollarSign, 
  HardDrive, 
  Signal,
  Wifi,
  Copy,
  Check
} from 'lucide-react';
import { ImsiWalletBalances, imsiEngine } from '../lib/imsiEngine';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface TelecomNetworkIntegrationProps {
  wallet: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenBiometricAuth?: () => void;
}

interface CarrierBundle {
  id: string;
  carrierName: string;
  mccMnc: string;
  unusedGb: number;
  ratePerGbNgn: number;
  ratePerGbSats: number;
  icon: string;
  color: string;
  userPhone: string;
}

export const TelecomNetworkIntegration: React.FC<TelecomNetworkIntegrationProps> = ({
  wallet,
  onShowToast
}) => {
  const [selectedCarrierId, setSelectedCarrierId] = useState<string>('mtn_ng');
  const [dataGbToConvert, setDataGbToConvert] = useState<string>('5.0');
  const [payoutTarget, setPayoutTarget] = useState<'CRYPTO_BTC' | 'CASH_NGN' | 'CONVERTO_PARITY'>('CRYPTO_BTC');
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [conversionReceipt, setConversionReceipt] = useState<any | null>(null);

  // Available SIMs & Unused Data Bundles
  const carriers: CarrierBundle[] = [
    {
      id: 'mtn_ng',
      carrierName: 'MTN Nigeria (Y’ello Mesh)',
      mccMnc: '621-30',
      unusedGb: 18.5,
      ratePerGbNgn: 450,
      ratePerGbSats: 290,
      icon: '🟡',
      color: '#eab308',
      userPhone: '07071918280'
    },
    {
      id: 'airtel_ng',
      carrierName: 'Airtel Nigeria (4G/5G Core)',
      mccMnc: '621-20',
      unusedGb: 12.0,
      ratePerGbNgn: 420,
      ratePerGbSats: 275,
      icon: '🔴',
      color: '#ef4444',
      userPhone: '08023456789'
    },
    {
      id: 'glo_ng',
      carrierName: 'Globacom Nigeria (Grandmasters)',
      mccMnc: '621-50',
      unusedGb: 25.0,
      ratePerGbNgn: 380,
      ratePerGbSats: 250,
      icon: '🟢',
      color: '#22c55e',
      userPhone: '08051234567'
    },
    {
      id: 'starlink_imsi',
      carrierName: 'Starlink Direct-to-Cell IMSI Relay',
      mccMnc: '621-777',
      unusedGb: 85.0,
      ratePerGbNgn: 650,
      ratePerGbSats: 420,
      icon: '🛰️',
      color: '#06b6d4',
      userPhone: 'IMSI-62130-777-DIRECT'
    }
  ];

  const activeCarrier = carriers.find(c => c.id === selectedCarrierId) || carriers[0];

  // Calculated conversions
  const conversionSummary = useMemo(() => {
    const gb = parseFloat(dataGbToConvert) || 0;
    const cashNgn = gb * activeCarrier.ratePerGbNgn;
    const btcSats = Math.round(gb * activeCarrier.ratePerGbSats);
    const btcFormatted = (btcSats / 100000000).toFixed(8);
    const convertoParity = (cashNgn / 1580).toFixed(2);

    return {
      gb,
      cashNgn,
      btcSats,
      btcFormatted,
      convertoParity
    };
  }, [dataGbToConvert, activeCarrier]);

  // Execute Telecom Data-to-Crypto/Cash Conversion
  const handleExecuteDataConversion = async () => {
    const gb = parseFloat(dataGbToConvert);
    if (isNaN(gb) || gb <= 0) {
      onShowToast?.('⚠️ Please enter a valid GB volume to convert.');
      return;
    }

    if (gb > activeCarrier.unusedGb) {
      onShowToast?.(`⚠️ Exceeds available unused data balance (${activeCarrier.unusedGb} GB on ${activeCarrier.carrierName}).`);
      return;
    }

    setIsConverting(true);
    onShowToast?.(`🔐 Authorizing WebAuthn biometric signature for SS7/Diameter data packet tokenization...`);

    try {
      await webAuthnBiometric.verifyBiometric(
        `Convert ${gb} GB (${activeCarrier.carrierName}) to ${payoutTarget}`,
        'fingerprint'
      );
    } catch {
      // Fallback
    }

    setTimeout(() => {
      const txRef = `TEL-DATA-${Date.now().toString().slice(-8)}`;

      if (payoutTarget === 'CRYPTO_BTC') {
        imsiEngine.depositDirectCredit({
          btcSats: conversionSummary.btcSats,
          cashNgn: 0,
          source: `Telecom Mesh (${activeCarrier.carrierName} ${gb} GB Conversion)`,
          note: `Data-to-Bitcoin Taproot Yield [Ref: ${txRef}]`
        });
      } else if (payoutTarget === 'CASH_NGN') {
        imsiEngine.depositDirectCredit({
          cashNgn: conversionSummary.cashNgn,
          source: `Telecom Mesh (${activeCarrier.carrierName} ${gb} GB Conversion)`,
          note: `Data-to-Cash NIBSS Settlement [Ref: ${txRef}]`
        });
      } else {
        // CONVERTO Parity
        imsiEngine.depositDirectCredit({
          cashNgn: conversionSummary.cashNgn,
          source: `Telecom Mesh CONVERTO Parity (${gb} GB)`,
          note: `Data-to-CONVERTO 1:1 Parity [Ref: ${txRef}]`
        });
      }

      const receipt = {
        txRef,
        carrier: activeCarrier.carrierName,
        phone: activeCarrier.userPhone,
        mccMnc: activeCarrier.mccMnc,
        convertedGb: `${gb} GB`,
        target: payoutTarget,
        yieldGranted: payoutTarget === 'CRYPTO_BTC'
          ? `+${conversionSummary.btcSats.toLocaleString()} Sats (${conversionSummary.btcFormatted} BTC)`
          : `+₦${conversionSummary.cashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })} NGN`,
        timestamp: new Date().toLocaleString()
      };

      setConversionReceipt(receipt);
      setIsConverting(false);
      onShowToast?.(`✓ Converted ${gb} GB on ${activeCarrier.carrierName} into ${receipt.yieldGranted}!`);
    }, 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black uppercase tracking-wider">
            <Radio className="w-4 h-4 text-amber-400" />
            <span>TELECOM NETWORK & MOBILE DATA TOKENIZATION MODULE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black font-serif text-slate-100 tracking-tight">
            Unused Mobile Data to Crypto & Cash Converter
          </h2>
          <p className="text-xs text-slate-400">
            Monetize dormant mobile data bytes across MTN (621-30), Airtel, Glo, and Starlink Direct-to-Cell into real-time Bitcoin Satoshis, Cash Treasury, or CONVERTO reserves.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-900 border border-amber-500/30 px-3.5 py-1.5 rounded-xl text-xs font-bold text-amber-400">
          <Signal className="w-4 h-4 text-emerald-400" />
          <span>IMSI Signaling Online</span>
        </div>
      </div>

      {/* Main Conversion Control Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10">
        {/* Left Column: Carrier Selector (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">
            Select Connected Carrier SIM / IMSI:
          </div>

          <div className="space-y-2.5">
            {carriers.map((carrier) => {
              const isSelected = selectedCarrierId === carrier.id;
              return (
                <div
                  key={carrier.id}
                  onClick={() => setSelectedCarrierId(carrier.id)}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-900 border-amber-400 shadow-md shadow-amber-500/15 ring-1 ring-amber-400/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{carrier.icon}</span>
                    <div>
                      <div className="text-xs font-black text-slate-100">{carrier.carrierName}</div>
                      <div className="text-[10px] text-slate-400">IMSI: {carrier.mccMnc} • {carrier.userPhone}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-black text-emerald-400 block">{carrier.unusedGb} GB Free</span>
                    <span className="text-[10px] text-amber-300 font-mono">₦{carrier.ratePerGbNgn}/GB</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Volume Slider, Payout Rail & Real-Time Summary (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-5">
          {/* Data Volume Input */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400">
              <span>Unused Data Volume to Liquidate:</span>
              <span className="text-emerald-400">Available: {activeCarrier.unusedGb} GB</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 focus-within:border-amber-400 rounded-2xl p-3.5 flex items-center justify-between space-x-3">
              <input
                type="number"
                step="0.5"
                max={activeCarrier.unusedGb}
                value={dataGbToConvert}
                onChange={(e) => setDataGbToConvert(e.target.value)}
                className="w-full bg-transparent text-2xl font-black text-slate-100 font-mono focus:outline-none"
              />
              <span className="text-sm font-black text-amber-300">GIGABYTES (GB)</span>
            </div>
          </div>

          {/* Quick Preset GB Buttons */}
          <div className="flex flex-wrap gap-2">
            {[1, 2, 5, 10, activeCarrier.unusedGb].map((gb) => (
              <button
                key={gb}
                onClick={() => setDataGbToConvert(gb.toString())}
                className="px-3 py-1 rounded-xl bg-slate-950 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-800 text-xs font-mono transition-colors"
              >
                {gb === activeCarrier.unusedGb ? `Max (${gb} GB)` : `${gb} GB`}
              </button>
            ))}
          </div>

          {/* Target Payout Asset Selector */}
          <div className="space-y-1.5">
            <label className="text-xs uppercase font-bold text-slate-400">Target Liquid Asset:</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'CRYPTO_BTC', label: 'Bitcoin (Sats)', icon: '₿' },
                { id: 'CASH_NGN', label: 'Cash Treasury (₦)', icon: '₦' },
                { id: 'CONVERTO_PARITY', label: 'CONVERTO 1:1', icon: '⚡' }
              ].map((target) => (
                <button
                  key={target.id}
                  onClick={() => setPayoutTarget(target.id as any)}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    payoutTarget === target.id
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-black shadow-md shadow-amber-500/10'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-sm mr-1.5">{target.icon}</span>
                  <span className="text-xs">{target.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Real-Time Valuation Output Strip */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider flex items-center justify-between">
              <span>Real-Time Yield Valuation:</span>
              <span className="text-emerald-400 text-xs font-mono">{dataGbToConvert} GB @ {activeCarrier.carrierName}</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Bitcoin Satoshis</span>
                <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                  +{conversionSummary.btcSats.toLocaleString()} Sats
                </span>
                <span className="text-[9px] text-slate-500 font-mono block">{conversionSummary.btcFormatted} BTC</span>
              </div>

              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Nigerian Cash Equivalent</span>
                <span className="text-sm sm:text-base font-black text-emerald-300 font-mono">
                  +₦{conversionSummary.cashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[9px] text-slate-500 block">Instant NIBSS Credit</span>
              </div>
            </div>
          </div>

          {/* Execute Button */}
          <button
            disabled={isConverting}
            onClick={handleExecuteDataConversion}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/20 transition-all hover:scale-101 disabled:opacity-50"
          >
            {isConverting ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                <span>DISPATCHING DIAMETER DATA SETTLEMENT...</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 text-slate-950" />
                <span>CONVERT {dataGbToConvert} GB INTO {payoutTarget.replace('_', ' ')} NOW</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Conversion Receipt Modal */}
      <AnimatePresence>
        {conversionReceipt && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  <h3 className="text-xl font-black text-slate-100 font-serif">
                    Data Packet Tokenization Successful
                  </h3>
                </div>
                <button
                  onClick={() => setConversionReceipt(null)}
                  className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-slate-100 flex items-center justify-center font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Packet Token ID:</span>
                  <span className="text-amber-400 font-bold">{conversionReceipt.txRef}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Carrier Network:</span>
                  <span className="text-slate-200">{conversionReceipt.carrier}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>IMSI Core:</span>
                  <span className="text-cyan-300">{conversionReceipt.mccMnc}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Liquidated Volume:</span>
                  <span className="text-slate-100 font-bold">{conversionReceipt.convertedGb}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Sovereign Yield Credited:</span>
                  <span className="text-emerald-400 font-bold text-sm">{conversionReceipt.yieldGranted}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Timestamp:</span>
                  <span className="text-slate-300">{conversionReceipt.timestamp}</span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setConversionReceipt(null)}
                  className="px-6 py-2.5 bg-amber-500 text-slate-950 font-black text-xs rounded-xl hover:bg-amber-400 transition-all"
                >
                  DISMISS RECEIPT
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
