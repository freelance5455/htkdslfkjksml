import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  CheckCircle2, 
  RefreshCw, 
  Radio, 
  ShieldCheck, 
  Zap, 
  Cpu, 
  Layers, 
  Server, 
  Wifi, 
  Globe, 
  ExternalLink, 
  Copy, 
  Check, 
  Sparkles,
  Database,
  ArrowUpDown,
  Lock
} from 'lucide-react';

export interface ChainNodeStatus {
  id: string;
  name: string;
  network: string;
  type: 'L1' | 'L2' | 'Solana' | 'Bitcoin' | 'TelecomGateway';
  status: 'Synced' | 'Syncing' | 'Revalidating';
  blockHeight: number;
  latencyMs: number;
  peerCount: number;
  tpsOrSpeed: string;
  rpcEndpoint: string;
  lastBlockTime: string;
  merkleRoot: string;
  gasOrTariff: string;
  iconBg: string;
  textColor: string;
}

const INITIAL_NODES: ChainNodeStatus[] = [
  {
    id: 'btc-node',
    name: 'Bitcoin Core Node',
    network: 'Bitcoin Mainnet (v27.0)',
    type: 'Bitcoin',
    status: 'Synced',
    blockHeight: 859420,
    latencyMs: 14,
    peerCount: 42,
    tpsOrSpeed: '7.2 tx/s',
    rpcEndpoint: 'https://btc-node.juhnkrixmusika.pages.dev:8332',
    lastBlockTime: '34s ago',
    merkleRoot: '00000000000000000001a7f83e29910d8b74c5d9472e3a1f94bc4102',
    gasOrTariff: '12 sat/vB',
    iconBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    textColor: 'text-amber-300'
  },
  {
    id: 'eth-node',
    name: 'Ethereum Execution Client',
    network: 'Ethereum Mainnet (Geth v1.14)',
    type: 'L1',
    status: 'Synced',
    blockHeight: 20681452,
    latencyMs: 21,
    peerCount: 68,
    tpsOrSpeed: '18.4 tx/s',
    rpcEndpoint: 'https://eth-mainnet.alchemyapi.io/v2/juhnkrix-vault',
    lastBlockTime: '12s ago',
    merkleRoot: '0x9fa81c3b1297e0998f480371a5c689104faee1398bbdc6',
    gasOrTariff: '14 Gwei',
    iconBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    textColor: 'text-indigo-300'
  },
  {
    id: 'sol-node',
    name: 'Solana RPC Cluster',
    network: 'Solana Mainnet-Beta (Jito v1.18)',
    type: 'Solana',
    status: 'Synced',
    blockHeight: 286419890,
    latencyMs: 9,
    peerCount: 1840,
    tpsOrSpeed: '3,450 tx/s',
    rpcEndpoint: 'https://solana-api.projectserum.com',
    lastBlockTime: '400ms ago',
    merkleRoot: '5Kn4kQ8xTf7gXU67M9Pq8L2VbX4a3W6Z9Y2D1F4H8J0K',
    gasOrTariff: '0.000005 SOL',
    iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    textColor: 'text-emerald-300'
  },
  {
    id: 'base-node',
    name: 'Base L2 OP Rollup',
    network: 'Coinbase Base Mainnet',
    type: 'L2',
    status: 'Synced',
    blockHeight: 18940211,
    latencyMs: 16,
    peerCount: 94,
    tpsOrSpeed: '42.6 tx/s',
    rpcEndpoint: 'https://mainnet.base.org',
    lastBlockTime: '2s ago',
    merkleRoot: '0x38b291c94017f920daec849204bc99a18d998246104',
    gasOrTariff: '0.04 Gwei',
    iconBg: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    textColor: 'text-blue-300'
  },
  {
    id: 'poly-node',
    name: 'Polygon PoS Validator',
    network: 'Polygon Bor Mainnet',
    type: 'L1',
    status: 'Synced',
    blockHeight: 61230812,
    latencyMs: 28,
    peerCount: 112,
    tpsOrSpeed: '64.1 tx/s',
    rpcEndpoint: 'https://polygon-rpc.com',
    lastBlockTime: '2.1s ago',
    merkleRoot: '0x71ba238f9024c0891d4e78a23019fbb8234cae9184',
    gasOrTariff: '32 Gwei',
    iconBg: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    textColor: 'text-purple-300'
  },
  {
    id: 'imsi-gateway',
    name: 'IMSI Telecom Sovereign Gateway',
    network: 'SS7 / Diameter Core Protocol',
    type: 'TelecomGateway',
    status: 'Synced',
    blockHeight: 19212777,
    latencyMs: 1,
    peerCount: 4,
    tpsOrSpeed: 'Instant ₦5 Deductions',
    rpcEndpoint: 'http://142.250.190.46:8080/imsi-core-62130',
    lastBlockTime: 'Instant Realtime',
    merkleRoot: 'IMSI:621307071918280-SOVEREIGN-SEAL-777',
    gasOrTariff: '₦5.00 / SMS / 2.5MB',
    iconBg: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    textColor: 'text-cyan-300'
  }
];

interface CrossChainSyncVisualizerProps {
  onShowToast?: (msg: string) => void;
}

export const CrossChainSyncVisualizer: React.FC<CrossChainSyncVisualizerProps> = ({ onShowToast }) => {
  const [nodes, setNodes] = useState<ChainNodeStatus[]>(INITIAL_NODES);
  const [isResyncing, setIsResyncing] = useState<boolean>(false);
  const [autoHeartbeat, setAutoHeartbeat] = useState<boolean>(true);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string>(new Date().toLocaleTimeString());
  const [selectedNodeDetails, setSelectedNodeDetails] = useState<ChainNodeStatus | null>(null);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  // Auto Heartbeat Sync Cycle every 14 seconds
  useEffect(() => {
    if (!autoHeartbeat) return;

    const interval = setInterval(() => {
      setNodes(prev => prev.map(node => {
        // Random slight block increment & jitter latency simulation
        const blockInc = node.type === 'Solana' ? Math.floor(Math.random() * 4) + 2 : 1;
        const latencyJitter = Math.max(2, node.latencyMs + (Math.floor(Math.random() * 5) - 2));
        return {
          ...node,
          blockHeight: node.blockHeight + blockInc,
          latencyMs: latencyJitter,
          lastBlockTime: 'Just now'
        };
      }));
      setLastSyncTimestamp(new Date().toLocaleTimeString());
    }, 14000);

    return () => clearInterval(interval);
  }, [autoHeartbeat]);

  const handleForceResync = async () => {
    setIsResyncing(true);
    onShowToast?.('🔄 Pinging RPC nodes across Bitcoin, Ethereum, Solana, Base, and IMSI...');

    // Set all nodes to "Syncing"
    setNodes(prev => prev.map(n => ({ ...n, status: 'Syncing' })));

    // Simulate staggered fast responses
    setTimeout(() => {
      setNodes(prev => prev.map((n, idx) => {
        if (idx === 0 || idx === 2 || idx === 5) {
          return { ...n, status: 'Synced', blockHeight: n.blockHeight + 1, lastBlockTime: 'Just now' };
        }
        return n;
      }));
    }, 800);

    setTimeout(() => {
      setNodes(prev => prev.map(n => ({
        ...n,
        status: 'Synced',
        blockHeight: n.blockHeight + 1,
        latencyMs: Math.max(4, n.latencyMs - 2),
        lastBlockTime: 'Just now'
      })));
      setIsResyncing(false);
      setLastSyncTimestamp(new Date().toLocaleTimeString());
      onShowToast?.('✓ All 6 Cross-Chain Blockchain & Telecom Nodes 100% Synced!');
    }, 1600);
  };

  const handleCopyMerkle = (hash: string, label: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(label);
    onShowToast?.(`✓ Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const allSynced = nodes.every(n => n.status === 'Synced');
  const syncingCount = nodes.filter(n => n.status === 'Syncing').length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.12 }}
      className="bg-slate-950 border-2 border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6"
    >
      {/* Background Ambience Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black uppercase tracking-wider">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>CROSS-CHAIN BLOCKCHAIN NODE SYNC MONITOR</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center space-x-2">
            <span>Multi-Chain Node Sync & Cryptographic Finality Status</span>
          </h3>
          <p className="text-xs text-slate-400 max-w-2xl">
            Live telemetry tracking synchronization depth, block confirmation height, RPC latency, and Merkle state proofs across Bitcoin, Ethereum, Solana, Base, Polygon, and IMSI Carrier Gateway.
          </p>
        </div>

        {/* Global Status Badge & Actions */}
        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {/* Master Sync Status Indicator */}
          <div className={`px-4 py-2 rounded-2xl flex items-center space-x-2 border transition-all ${
            allSynced
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 shadow-lg shadow-emerald-500/20'
              : 'bg-amber-950/80 border-amber-500/50 text-amber-300 shadow-lg shadow-amber-500/20'
          }`}>
            <span className="relative flex h-3 w-3">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                allSynced ? 'bg-emerald-400' : 'bg-amber-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-3 w-3 ${
                allSynced ? 'bg-emerald-500' : 'bg-amber-500'
              }`} />
            </span>
            <div className="text-xs font-black uppercase tracking-wider">
              {allSynced ? 'ALL NODES SYNCED' : `SYNCING (${syncingCount} VALIDATING)`}
            </div>
          </div>

          {/* Force Resync Button */}
          <button
            onClick={handleForceResync}
            disabled={isResyncing}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95 disabled:opacity-70"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-950 ${isResyncing ? 'animate-spin' : ''}`} />
            <span>{isResyncing ? 'VALIDATING NODES...' : 'FORCE RESYNC ALL CHAINS'}</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Nodes</div>
            <div className="text-base sm:text-lg font-black text-slate-100">{nodes.length} Chains Live</div>
          </div>
          <Server className="w-5 h-5 text-emerald-400" />
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Avg Latency</div>
            <div className="text-base sm:text-lg font-black text-emerald-400">
              {Math.round(nodes.reduce((acc, n) => acc + n.latencyMs, 0) / nodes.length)} ms
            </div>
          </div>
          <Activity className="w-5 h-5 text-emerald-400 animate-pulse" />
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Peer Mesh</div>
            <div className="text-base sm:text-lg font-black text-cyan-300">
              {nodes.reduce((acc, n) => acc + n.peerCount, 0).toLocaleString()} Peers
            </div>
          </div>
          <Globe className="w-5 h-5 text-cyan-400" />
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Last Heartbeat</div>
            <div className="text-base sm:text-lg font-black text-amber-300 font-mono">{lastSyncTimestamp}</div>
          </div>
          <ShieldCheck className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Nodes Matrix Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
        {nodes.map(node => {
          const isSynced = node.status === 'Synced';

          return (
            <motion.div
              key={node.id}
              whileHover={{ scale: 1.015 }}
              className={`bg-slate-900/80 border rounded-2xl p-5 space-y-4 transition-all shadow-xl ${
                isSynced 
                  ? 'border-slate-800 hover:border-emerald-500/40 hover:bg-slate-900' 
                  : 'border-amber-500/50 bg-amber-950/20'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm border ${node.iconBg}`}>
                    {node.type === 'Bitcoin' ? '₿' : node.type === 'Solana' ? '◎' : node.type === 'TelecomGateway' ? 'IMSI' : 'Ξ'}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-100 leading-tight flex items-center space-x-1.5">
                      <span>{node.name}</span>
                    </h4>
                    <div className="text-[11px] text-slate-400">{node.network}</div>
                  </div>
                </div>

                {/* Status Pill */}
                <div className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center space-x-1.5 border ${
                  isSynced
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${isSynced ? 'bg-emerald-400' : 'bg-amber-400 animate-ping'}`} />
                  <span>{node.status}</span>
                </div>
              </div>

              {/* Node Telemetry Stats */}
              <div className="space-y-2 text-xs border-t border-b border-slate-800/80 py-2.5">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Block Height / Slot:</span>
                  <span className="font-mono font-bold text-slate-200">
                    #{node.blockHeight.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">RPC Latency:</span>
                  <span className="font-mono font-bold text-emerald-400 flex items-center space-x-1">
                    <Activity className="w-3 h-3" />
                    <span>{node.latencyMs} ms</span>
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Network Throughput:</span>
                  <span className="font-bold text-slate-200">{node.tpsOrSpeed}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Base Fee / Tariff:</span>
                  <span className="font-mono text-amber-300 font-bold">{node.gasOrTariff}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Connected Peers:</span>
                  <span className="font-mono text-slate-300">{node.peerCount} Active</span>
                </div>
              </div>

              {/* Bottom Cryptographic Proof Bar */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <div className="flex items-center space-x-1 truncate max-w-[200px]">
                  <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span className="truncate font-mono text-slate-400">{node.merkleRoot}</span>
                </div>
                <button
                  onClick={() => handleCopyMerkle(node.merkleRoot, `${node.name} Merkle Root`)}
                  className="text-slate-400 hover:text-amber-300 p-1 transition-colors"
                  title="Copy Merkle State Root"
                >
                  {copiedHash === `${node.name} Merkle Root` ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};
