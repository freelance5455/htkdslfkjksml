import React, { useState } from 'react';
import {
  Sparkles, Mic, Search, Image as ImageIcon, Volume2,
  Loader2, CheckCircle, AlertCircle, ArrowRight, Play, ExternalLink, Upload
} from 'lucide-react';
import { VideoProject } from '../types/project';

interface AIToolsViewProps {
  project: VideoProject;
  onUpdateProject: (updated: Partial<VideoProject>) => void;
  lang: 'ar' | 'en';
}

export const AIToolsView: React.FC<AIToolsViewProps> = ({
  project,
  onUpdateProject,
  lang
}) => {
  const [activeTab, setActiveTab] = useState<'tts' | 'grounding' | 'image'>('tts');

  // 1. TTS States (gemini-3.8-flash-tts)
  const [ttsText, setTtsText] = useState('مرحباً بكم في Designo! أفضل تطبيق لمونتاج وتقسيم الفيديوهات بالذكاء الاصطناعي.');
  const [ttsVoice, setTtsVoice] = useState<'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr'>('Puck');
  const [ttsStyle, setTtsStyle] = useState('Clear, engaging, and professional Arabic video narrator');
  const [isGeneratingTts, setIsGeneratingTts] = useState(false);
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string | null>(null);
  const [ttsMessage, setTtsMessage] = useState<string | null>(null);

  // 2. Search Grounding States (gemini-3.8-flash with googleSearch)
  const [searchTopic, setSearchTopic] = useState('تيك توك وريلز 2026');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<string | null>(null);
  const [searchSources, setSearchSources] = useState<string[]>([]);

  // 3. Image Understanding States (gemini-4-argon)
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(null);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const [imageAnalysisResult, setImageAnalysisResult] = useState<string | null>(null);

  // Handle TTS Generation
  const handleGenerateTTS = async () => {
    if (!ttsText.trim()) return;
    setIsGeneratingTts(true);
    setTtsMessage(null);

    try {
      const res = await fetch('/api/ai/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: ttsText,
          voice: ttsVoice,
          style: ttsStyle
        })
      });

      const data = await res.json();
      if (data.success && data.audioData) {
        setGeneratedAudioUrl(data.audioData);
        onUpdateProject({ ttsAudioUrl: data.audioData });
        setTtsMessage('تم توليد التعليق الصوتي بنجاح باستخدام نموذج gemini-3.8-flash-tts! 🎉');
      } else if (data.useClientSynthesis) {
        // Fallback with Web Speech API for instant client audio
        const utterance = new SpeechSynthesisUtterance(ttsText);
        utterance.lang = 'ar-SA';
        window.speechSynthesis.speak(utterance);
        setTtsMessage('تم تشغيل التعليق الصوتي الصوتي عبر قارئ المتصفح المحلي');
      } else {
        setTtsMessage('حدث خطأ أثناء توليد الصوت');
      }
    } catch (err: any) {
      setTtsMessage('تعذر الاتصال بخدمة الصوت: ' + err?.message);
    } finally {
      setIsGeneratingTts(false);
    }
  };

  // Handle Search Grounding
  const handleSearchGrounding = async () => {
    setIsSearching(true);
    setSearchResult(null);
    setSearchSources([]);

    try {
      const res = await fetch('/api/ai/grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: `ما هي أكثر المواضيع والأفكار والهاشتاجات الرائجة لفيديوهات قصيرة في موضوع "${searchTopic}"؟`,
          topic: searchTopic
        })
      });

      const data = await res.json();
      if (data.success && data.content) {
        setSearchResult(data.content);
        setSearchSources(data.sources || []);
      }
    } catch (err: any) {
      setSearchResult('تعذر جلب الأفكار الرائجة: ' + err?.message);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle Image Upload & gemini-4-argon analysis
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyzeImage = async () => {
    if (!uploadedImageBase64) return;
    setIsAnalyzingImage(true);
    setImageAnalysisResult(null);

    try {
      const res = await fetch('/api/ai/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: uploadedImageBase64,
          prompt: 'قم بتحليل هذه الصورة أو الشعار: ما هي درجات الألوان الأساسية؟ وما نوع الخط وألوان النصوص التي تناسبها لتصميم فيديو متناسق واحترافي؟ قدم إجابة منسقة وموجزة باللغة العربية.'
        })
      });

      const data = await res.json();
      if (data.success && data.analysis) {
        setImageAnalysisResult(data.analysis);
      } else {
        setImageAnalysisResult('تعذر تحليل الصورة: ' + (data.error || 'خطأ غير معروف'));
      }
    } catch (err: any) {
      setImageAnalysisResult('فشل تحليل الصورة: ' + err?.message);
    } finally {
      setIsAnalyzingImage(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6 pb-28">
      {/* Header */}
      <div className="bg-[#111224] p-5 rounded-2xl border border-purple-900/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/40">
            <Sparkles className="w-6 h-6 text-yellow-300" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              {lang === 'ar' ? 'أدوات الذكاء الاصطناعي المتقدمة' : 'AI Video Studio Tools'}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'ar'
                ? 'توليد صوت احترافي، أفكار رائجة ببيانات Google Search، وتحليل الصور والشعارات'
                : 'TTS voiceover, Google Search grounding for viral hooks, and image analysis'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="grid grid-cols-3 gap-2 bg-[#090a14] p-1.5 rounded-2xl border border-purple-950">
        <button
          onClick={() => setActiveTab('tts')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
            activeTab === 'tts'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Mic className="w-4 h-4" />
          <span>{lang === 'ar' ? 'التعليق الصوتي (TTS)' : 'Voiceover (TTS)'}</span>
        </button>

        <button
          onClick={() => setActiveTab('grounding')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
            activeTab === 'grounding'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>{lang === 'ar' ? 'ترند Google Search' : 'Search Grounding'}</span>
        </button>

        <button
          onClick={() => setActiveTab('image')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
            activeTab === 'image'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>{lang === 'ar' ? 'تحليل الشعار والصور' : 'Image Understanding'}</span>
        </button>
      </div>

      {/* 1. TTS Tab Content (gemini-3.8-flash-tts) */}
      {activeTab === 'tts' && (
        <div className="bg-[#111224] border border-purple-900/40 rounded-2xl p-5 sm:p-6 space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-purple-900/30 pb-3">
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <Mic className="w-4 h-4 text-purple-400" />
                <span>{lang === 'ar' ? 'توليد صوت بشري طبيعي بالفيديو' : 'AI Speech Generator'}</span>
              </h2>
              <span className="text-xs text-purple-300 font-mono">Model: gemini-3.8-flash-tts</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-semibold">
              {lang === 'ar' ? 'النص المراد تحويله إلى صوت:' : 'Narration Script:'}
            </label>
            <textarea
              rows={4}
              value={ttsText}
              onChange={(e) => setTtsText(e.target.value)}
              placeholder="اكتب ما ترغب بأن يقوله المعلق الصوتي في الفيديو..."
              className="w-full px-4 py-3 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white text-sm focus:outline-none focus:border-purple-400 resize-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <span className="text-xs text-slate-300 font-medium">{lang === 'ar' ? 'الشخصية الصوتية:' : 'Voice Persona:'}</span>
              <div className="grid grid-cols-3 gap-1.5">
                {(['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'] as const).map((v) => (
                  <button
                    key={v}
                    onClick={() => setTtsVoice(v)}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition cursor-pointer ${
                      ttsVoice === v
                        ? 'bg-purple-600 border-purple-400 text-white'
                        : 'bg-black/30 border-purple-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-xs text-slate-300 font-medium">{lang === 'ar' ? 'أسلوب الإلقاء:' : 'Voice Style:'}</span>
              <select
                value={ttsStyle}
                onChange={(e) => setTtsStyle(e.target.value)}
                className="w-full px-3 py-2 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-xs text-white focus:outline-none"
              >
                <option value="Clear, engaging, and professional Arabic video narrator">مذيع محترف واضح ومشوق</option>
                <option value="Enthusiastic and fast-paced TikTok creator">حماسي وسريع لمقاطع تيك توك</option>
                <option value="Calm, soulful, and poetic for wisdom quotes">هادئ وشاعري للاقتباسات والحكم</option>
                <option value="Energetic sports commentator">معلق رياضي ناري</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleGenerateTTS}
            disabled={isGeneratingTts || !ttsText.trim()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 transition cursor-pointer"
          >
            {isGeneratingTts ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{lang === 'ar' ? 'جاري توليد الصوت بنموذج gemini-3.8-flash-tts...' : 'Generating Speech...'}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                <span>{lang === 'ar' ? 'توليد الصوت الآن وإضافته للفيديو' : 'Generate & Add Voiceover'}</span>
              </>
            )}
          </button>

          {ttsMessage && (
            <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/50 text-xs text-purple-200 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{ttsMessage}</span>
            </div>
          )}

          {generatedAudioUrl && (
            <div className="p-3 bg-black/40 rounded-xl border border-purple-900/30">
              <audio src={generatedAudioUrl} controls className="w-full h-8" />
            </div>
          )}
        </div>
      )}

      {/* 2. Search Grounding Tab (gemini-3.8-flash with googleSearch) */}
      {activeTab === 'grounding' && (
        <div className="bg-[#111224] border border-purple-900/40 rounded-2xl p-5 sm:p-6 space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-purple-900/30 pb-3">
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <Search className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'استكشاف الأفكار الرائجة مع Google Search' : 'Trending Viral Hooks with Google Search'}</span>
              </h2>
              <span className="text-xs text-emerald-400 font-mono">Model: gemini-3.8-flash (googleSearch tool)</span>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={searchTopic}
              onChange={(e) => setSearchTopic(e.target.value)}
              placeholder="مثال: ترندات الذكاء الاصطناعي، أهداف كرة القدم، عروض التجارة..."
              className="flex-1 px-3 py-2 bg-[#0a0b16] border border-purple-800/50 rounded-xl text-white text-xs focus:outline-none"
            />
            <button
              onClick={handleSearchGrounding}
              disabled={isSearching}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
            >
              {isSearching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
              <span>{lang === 'ar' ? 'بحث' : 'Search'}</span>
            </button>
          </div>

          {searchResult && (
            <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-800/40 space-y-3">
              <div className="text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                {searchResult}
              </div>

              {searchSources.length > 0 && (
                <div className="pt-2 border-t border-purple-900/30 text-[10px] text-slate-400">
                  <span className="font-bold text-purple-300 block mb-1">
                    {lang === 'ar' ? 'المصادر المعتمدة من بحث Google:' : 'Sources grounded via Google Search:'}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {searchSources.map((src, i) => (
                      <a
                        key={i}
                        href={src}
                        target="_blank"
                        rel="noreferrer"
                        className="truncate max-w-[240px] text-emerald-400 hover:underline flex items-center gap-1"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>{src}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 3. Image Understanding Tab (gemini-4-argon) */}
      {activeTab === 'image' && (
        <div className="bg-[#111224] border border-purple-900/40 rounded-2xl p-5 sm:p-6 space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-purple-900/30 pb-3">
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-pink-400" />
                <span>{lang === 'ar' ? 'تحليل الشعار والغلاف واقتراح ألوان الفيديو' : 'Brand & Image Analyzer'}</span>
              </h2>
              <span className="text-xs text-pink-400 font-mono">Model: gemini-4-argon</span>
            </div>
          </div>

          {/* Upload Box */}
          <div className="border-2 border-dashed border-purple-800/50 rounded-2xl p-6 text-center space-y-3 bg-[#0a0b16]">
            {uploadedImageBase64 ? (
              <div className="flex flex-col items-center gap-3">
                <img
                  src={uploadedImageBase64}
                  alt="Uploaded Asset"
                  className="max-h-48 rounded-xl object-contain shadow-lg"
                />
                <button
                  onClick={() => setUploadedImageBase64(null)}
                  className="text-xs text-red-400 hover:underline cursor-pointer"
                >
                  {lang === 'ar' ? 'إزالة الصورة واختيار غيرها' : 'Remove image'}
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center gap-2 cursor-pointer py-4">
                <Upload className="w-8 h-8 text-purple-400" />
                <span className="text-xs font-bold text-purple-200">
                  {lang === 'ar' ? 'انقر لرفع شعار أو غلاف أو صورة لتحليلها' : 'Click to upload logo or photo'}
                </span>
                <span className="text-[10px] text-slate-500">PNG, JPG, WEBP (حتى 10MB)</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {uploadedImageBase64 && (
            <button
              onClick={handleAnalyzeImage}
              disabled={isAnalyzingImage}
              className="w-full py-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              {isAnalyzingImage ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{lang === 'ar' ? 'جاري التحليل بنموذج gemini-4-argon...' : 'Analyzing with gemini-4-argon...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تحليل الصورة واقتراح سمات الفيديو' : 'Analyze & Match Video Style'}</span>
                </>
              )}
            </button>
          )}

          {imageAnalysisResult && (
            <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs text-slate-200 leading-relaxed whitespace-pre-line">
              <span className="font-bold text-pink-300 block mb-2">
                {lang === 'ar' ? 'نتيجة تحليل Gemini 4 Argon:' : 'Analysis Insights:'}
              </span>
              {imageAnalysisResult}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
