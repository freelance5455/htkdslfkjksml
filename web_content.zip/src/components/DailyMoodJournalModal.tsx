import React, { useState, useEffect } from "react";
import { UserMoodOption, EmotionKey, EMOTIONS } from "../types";
import { BookHeart, X, Sparkles, Check, Smile, PenLine, Heart } from "lucide-react";

interface DailyMoodJournalModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMood: UserMoodOption | null;
  currentEmotion: EmotionKey;
  userName: string;
  onSaveJournal: (journalText: string, moodOption: UserMoodOption) => void;
}

const QUICK_TAGS = [
  "কাজের চাপ",
  "পারিবারিক কথা",
  "প্রিয় গান",
  "একাকীত্ব",
  "ছোট্ট আনন্দ",
  "নতুন অর্জন",
  "ভবিষ্যতের ভাবনা",
  "বন্ধুর সাথে আড্ডা",
];

export const DailyMoodJournalModal: React.FC<DailyMoodJournalModalProps> = ({
  isOpen,
  onClose,
  selectedMood,
  currentEmotion,
  userName,
  onSaveJournal,
}) => {
  const [journalText, setJournalText] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [isSavedSuccess, setIsSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setJournalText("");
      setSelectedTag(null);
      setIsSavedSuccess(false);
    }
  }, [isOpen]);

  if (!isOpen || !selectedMood) return null;

  const emotionMeta = EMOTIONS[currentEmotion] || EMOTIONS.empathetic;

  const handleTagClick = (tag: string) => {
    setSelectedTag(tag);
    if (!journalText.includes(tag)) {
      setJournalText((prev) => (prev ? `${prev} #${tag}` : `#${tag}: `));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!journalText.trim()) return;

    onSaveJournal(journalText.trim(), selectedMood);
    setIsSavedSuccess(true);
    setTimeout(() => {
      setIsSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-md transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog */}
      <div className="relative z-10 w-full max-w-lg rounded-3xl border border-amber-500/30 bg-[#0E1424] p-6 shadow-[0_0_50px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in-95 duration-200">
        {/* Decorative Top Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-1 w-24 rounded-full bg-gradient-to-r from-amber-500 to-sky-400" />

        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.25)]">
              <BookHeart className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-semibold text-slate-100 flex items-center gap-2">
                <span>দৈনিক অনুভূতির ডায়েরি</span>
                <span className="rounded-md border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-mono text-amber-300 uppercase">
                  Journal
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                আজকের মেজাজ সম্পর্কে কয়েক লাইন লিখে স্মৃতিতে জমা রাখো
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="বন্ধ করো"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Selected Mood Chip Banner */}
        <div className="mt-4 flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-900/60 p-3">
          <div className="flex items-center gap-2.5">
            <span
              className="h-3 w-3 rounded-full"
              style={{ backgroundColor: emotionMeta.accentHex }}
            />
            <div>
              <span className="text-xs text-slate-400">রিপোর্ট করা মেজাজ: </span>
              <span className="text-xs font-semibold text-amber-200">
                {selectedMood.labelBn}
              </span>
            </div>
          </div>
          <span className="font-mono text-xs tabular-nums text-sky-300">
            স্কোর: {selectedMood.score}/100
          </span>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Quick Guided Tags */}
          <div>
            <label className="text-xs font-medium text-slate-400 flex items-center gap-1.5 mb-2">
              <PenLine className="h-3.5 w-3.5 text-amber-400" />
              <span>আজকের প্রসঙ্গের ট্যাগ (প্রয়োজনে ক্লিক করো):</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleTagClick(tag)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] transition-colors ${
                    selectedTag === tag
                      ? "border-amber-500/60 bg-amber-500/20 text-amber-200 font-semibold"
                      : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>

          {/* Text Area Input */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1.5">
              আজকের দিনটি কেমন কাটল {userName}?
            </label>
            <textarea
              rows={4}
              value={journalText}
              onChange={(e) => setJournalText(e.target.value)}
              placeholder="কী নিয়ে মন খারাপ ছিল, কোন বিষয়টা আনন্দ দিয়েছিল কিংবা মন হালকা করার মতো কথাগুলো লিখে ফেলো..."
              autoFocus
              className="w-full rounded-2xl border border-slate-700/60 bg-transparent backdrop-blur-md p-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400/50 transition-colors resize-none shadow-inner"
            />
            <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
              <span>Thunder ভাই তোর এই কথাগুলো স্মৃতিতে যত্নে রাখবে</span>
              <span className="font-mono tabular-nums">
                {journalText.length} অক্ষর
              </span>
            </div>
          </div>

          {/* Reassurance Footer Quote */}
          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 flex items-start gap-2.5">
            <Sparkles className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs leading-relaxed text-slate-300 italic">
              “মনের কথা লিখে প্রকাশ করলে মনের ভার অর্ধেক কমে যায় ভাই। তোর প্রতিটি কথা আমার কাছে মূল্যবান স্মৃতি।” — Thunder
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 border-t border-slate-800/80 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
            >
              পরে লিখব
            </button>
            <button
              type="submit"
              disabled={!journalText.trim() || isSavedSuccess}
              className="flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors disabled:opacity-50 shadow-[0_0_15px_rgba(245,158,11,0.3)]"
            >
              {isSavedSuccess ? (
                <>
                  <Check className="h-4 w-4 text-emerald-950" />
                  <span>স্মৃতিতে সংরক্ষিত হয়েছে!</span>
                </>
              ) : (
                <>
                  <BookHeart className="h-4 w-4" />
                  <span>স্মৃতিতে সেভ করো</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
