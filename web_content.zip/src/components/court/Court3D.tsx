import { useEffect, useRef, useState } from "react";
import { Film, Image, Pause, Play, RotateCcw } from "lucide-react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { paintCourt } from "@/lib/court/draw";
import { encodeGif, safeName, shareOrDownload } from "@/lib/court/gif";
import { courtMeters } from "@/lib/court/geometry";
import { SEG_SECONDS, sampleFrame } from "@/lib/court/interp";
import { activeSlice, useCourt } from "@/lib/court/store";
import type { CourtMode, Frame, Token } from "@/lib/court/types";
import { Btn } from "@/components/court/ui";

export function Court3D() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const api = useRef({
    togglePlay: () => {},
    reset: () => {},
    exportGif: async () => {},
    exportPng: async () => {},
    step: (dir: number) => {},
  });
  const [playing, setPlaying] = useState(false);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const play = useCourt((state) => state.plays.find((item) => item.id === state.activePlayId) ?? null);
  const frameIndex = useCourt((state) => state.frameIndex);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2400);
    return () => window.clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    let alive = true;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setClearColor(0x16130f, 1);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.05;
      renderer.domElement.className = "h-full w-full touch-none";
      renderer.domElement.setAttribute("aria-label", "زمین سه‌بعدی بسکتبال");
      wrap.appendChild(renderer.domElement);
    } catch {
      setFailed(true);
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 120);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.minDistance = 5;
    controls.rotateSpeed = 0.7;

    scene.add(new THREE.HemisphereLight(0xfff2e0, 0x3a2418, 0.9));
    const sun = new THREE.DirectionalLight(0xfff5ea, 1.2);
    sun.position.set(8, 18, 6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.near = 2;
    sun.shadow.camera.far = 50;
    sun.shadow.camera.left = -18;
    sun.shadow.camera.right = 18;
    sun.shadow.camera.top = 18;
    sun.shadow.camera.bottom = -18;
    sun.shadow.bias = -0.001;
    scene.add(sun);

    const coneGeo = new THREE.ConeGeometry(0.42, 1.15, 20);
    const ballGeo = new THREE.SphereGeometry(0.22, 24, 16);
    const hitGeo = new THREE.CylinderGeometry(0.62, 0.62, 1.45, 12);
    const ringGeo = new THREE.TorusGeometry(0.62, 0.045, 8, 28);
    const homeMat = new THREE.MeshStandardMaterial({ color: 0xe8893a, roughness: 0.48 });
    const awayMat = new THREE.MeshStandardMaterial({ color: 0x4f7c9a, roughness: 0.48 });
    const ballMat = new THREE.MeshStandardMaterial({ color: 0xd4552a, roughness: 0.4 });
    const hitMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xefe6d4 });
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xd4552a, metalness: 0.55, roughness: 0.35 });
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xf7f4ef, roughness: 0.2, transparent: true, opacity: 0.86 });
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x2a241e, metalness: 0.35, roughness: 0.5 });
    const targetMat = new THREE.MeshStandardMaterial({ color: 0xf6efe6, roughness: 0.4 });
    const sharedMats = new Set<THREE.Material>([rimMat, boardMat, poleMat, targetMat]);

    const tokenRoot = new THREE.Group();
    scene.add(tokenRoot);
    const tokens = new Map<string, THREE.Group>();
    let floor: THREE.Mesh | null = null;
    let apron: THREE.Mesh | null = null;
    const hoopRoot = new THREE.Group();
    scene.add(hoopRoot);
    let builtMode: CourtMode | "" = "";
    const refs = {
      playing: false,
      acc: 0,
      exporting: false,
      selectedId: null as string | null,
      dragId: null as string | null,
    };
    const pointer = new THREE.Vector2();
    const raycaster = new THREE.Raycaster();
    const ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const hitPoint = new THREE.Vector3();

    function makeSprite(text: string) {
      const canvas = document.createElement("canvas");
      canvas.width = 128;
      canvas.height = 128;
      const ctx = canvas.getContext("2d");
      if (!ctx) return null;
      ctx.font = "800 72px Vazirmatn, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineWidth = 12;
      ctx.strokeStyle = "#1a120c";
      ctx.strokeText(text, 64, 68);
      ctx.fillStyle = "#f6efe6";
      ctx.fillText(text, 64, 68);
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
      const sprite = new THREE.Sprite(material);
      sprite.scale.set(0.85, 0.85, 1);
      sprite.position.y = 1.45;
      return sprite;
    }

    function createToken(token: Token) {
      const group = new THREE.Group();
      group.userData.tokenId = token.id;
      if (token.kind === "ball") {
        const mesh = new THREE.Mesh(ballGeo, ballMat);
        mesh.position.y = 0.22;
        mesh.castShadow = true;
        group.add(mesh);
      } else {
        const mesh = new THREE.Mesh(coneGeo, token.team === "away" ? awayMat : homeMat);
        mesh.position.y = 0.58;
        mesh.castShadow = true;
        group.add(mesh);
        const sprite = makeSprite(token.label);
        if (sprite) group.add(sprite);
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.name = "ring";
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.04;
        ring.visible = false;
        group.add(ring);
      }
      const hit = new THREE.Mesh(hitGeo, hitMat);
      hit.position.y = 0.7;
      group.add(hit);
      return group;
    }

    function place(frame: Frame, mode: CourtMode) {
      const { length, width } = courtMeters(mode);
      const ids = new Set(frame.tokens.map((token) => token.id));
      for (const [id, group] of tokens) {
        if (!ids.has(id)) {
          tokenRoot.remove(group);
          group.traverse((obj) => {
            if (obj instanceof THREE.Sprite) {
              obj.material.map?.dispose();
              obj.material.dispose();
            }
          });
          tokens.delete(id);
        }
      }
      for (const token of frame.tokens) {
        let group = tokens.get(token.id);
        if (!group) {
          group = createToken(token);
          tokens.set(token.id, group);
          tokenRoot.add(group);
        }
        group.position.set((token.y - 0.5) * width, 0, (token.x - 0.5) * length);
        const ring = group.getObjectByName("ring");
        if (ring) ring.visible = token.id === refs.selectedId;
      }
    }

    function clearGroup(group: THREE.Group) {
      for (const child of [...group.children]) {
        group.remove(child);
        child.traverse((obj) => {
          if (!(obj instanceof THREE.Mesh) && !(obj instanceof THREE.LineSegments)) return;
          obj.geometry.dispose();
          const list = Array.isArray(obj.material) ? obj.material : [obj.material];
          for (const item of list) {
            if (!sharedMats.has(item)) item.dispose();
          }
        });
      }
    }

    function addHoop(x: number, z: number, sign: 1 | -1) {
      const group = new THREE.Group();
      group.position.set(x, 0, z);
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.225, 0.016, 8, 28), rimMat);
      rim.rotation.x = Math.PI / 2;
      rim.position.y = 3.05;
      group.add(rim);
      const board = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.05, 0.06), boardMat);
      board.position.set(0, 3.35, -sign * 0.38);
      group.add(board);
      const target = new THREE.Mesh(new THREE.BoxGeometry(0.59, 0.45, 0.02), targetMat);
      target.position.set(0, 3.22, -sign * 0.33);
      group.add(target);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 3.3, 10), poleMat);
      pole.position.set(0, 1.65, -sign * 0.9);
      pole.castShadow = true;
      group.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.55), poleMat);
      arm.position.set(0, 3.3, -sign * 0.64);
      group.add(arm);
      const positions: number[] = [];
      for (let i = 0; i < 12; i++) {
        const a1 = (i / 12) * Math.PI * 2;
        const a2 = ((i + 1) / 12) * Math.PI * 2;
        positions.push(Math.cos(a1) * 0.225, 0, Math.sin(a1) * 0.225, Math.cos(a1) * 0.1, -0.38, Math.sin(a1) * 0.1);
        positions.push(
          Math.cos(a1) * 0.16,
          -0.22,
          Math.sin(a1) * 0.16,
          Math.cos(a2) * 0.16,
          -0.22,
          Math.sin(a2) * 0.16,
        );
      }
      const netGeo = new THREE.BufferGeometry();
      netGeo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
      const net = new THREE.LineSegments(
        netGeo,
        new THREE.LineBasicMaterial({ color: 0xf6efe6, transparent: true, opacity: 0.75 }),
      );
      net.position.y = 3.05;
      group.add(net);
      hoopRoot.add(group);
    }

    function rebuild(mode: CourtMode) {
      if (floor) {
        scene.remove(floor);
        floor.geometry.dispose();
        const mat = floor.material as THREE.MeshStandardMaterial;
        mat.map?.dispose();
        mat.dispose();
        floor = null;
      }
      if (apron) {
        scene.remove(apron);
        apron.geometry.dispose();
        (apron.material as THREE.Material).dispose();
        apron = null;
      }
      clearGroup(hoopRoot);
      const { length, width } = courtMeters(mode);
      const longEdge = 1024;
      const canvas = document.createElement("canvas");
      if (width >= length) {
        canvas.width = longEdge;
        canvas.height = Math.max(2, Math.round(longEdge * (length / width)));
      } else {
        canvas.height = longEdge;
        canvas.width = Math.max(2, Math.round(longEdge * (width / length)));
      }
      const ctx = canvas.getContext("2d");
      if (ctx) paintCourt(ctx, { x: 0, y: 0, w: canvas.width, h: canvas.height }, mode);
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.anisotropy = 8;
      const plane = new THREE.PlaneGeometry(width, length);
      floor = new THREE.Mesh(
        plane,
        new THREE.MeshStandardMaterial({ map: texture, roughness: 0.82, metalness: 0.02 }),
      );
      floor.rotation.x = -Math.PI / 2;
      floor.receiveShadow = true;
      scene.add(floor);
      apron = new THREE.Mesh(
        new THREE.PlaneGeometry(width + 2.2, length + 2.2),
        new THREE.MeshStandardMaterial({ color: 0x3b2718, roughness: 1 }),
      );
      apron.rotation.x = -Math.PI / 2;
      apron.position.y = -0.03;
      apron.receiveShadow = true;
      scene.add(apron);
      const nearZ = -length / 2 + 1.575;
      addHoop(0, nearZ, 1);
      if (mode === "full") addHoop(0, length / 2 - 1.575, -1);
      controls.maxDistance = mode === "full" ? 46 : 26;
    }

    function frameCamera(mode: CourtMode) {
      const { length } = courtMeters(mode);
      camera.position.set(length * 0.05, Math.max(9, length * 0.78), length * 0.62);
      controls.target.set(0, 0.4, 0);
      controls.update();
    }

    function resize() {
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      if (w < 2 || h < 2) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    }

    function tokenFromHit(object: THREE.Object3D | null) {
      let current = object;
      while (current) {
        if (typeof current.userData.tokenId === "string") return current.userData.tokenId;
        current = current.parent;
      }
      return null;
    }

    function ndc(event: PointerEvent) {
      const bounds = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
    }

    function onDown(event: PointerEvent) {
      ndc(event);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(tokenRoot.children, true);
      const id = hits.map((hit) => tokenFromHit(hit.object)).find(Boolean) ?? null;
      if (!id) return;
      refs.playing = false;
      if (alive) setPlaying(false);
      refs.selectedId = id;
      refs.dragId = id;
      controls.enabled = false;
    }

    function onMove(event: PointerEvent) {
      if (!refs.dragId) return;
      const slice = activeSlice(useCourt.getState());
      if (!slice.play) return;
      ndc(event);
      raycaster.setFromCamera(pointer, camera);
      if (!raycaster.ray.intersectPlane(ground, hitPoint)) return;
      const { length, width } = courtMeters(slice.play.mode);
      const nx = Math.min(0.98, Math.max(0.02, hitPoint.z / length + 0.5));
      const ny = Math.min(0.98, Math.max(0.02, hitPoint.x / width + 0.5));
      useCourt.getState().updateToken(refs.dragId, nx, ny);
    }

    function onUp() {
      refs.dragId = null;
      controls.enabled = true;
    }

    renderer.domElement.addEventListener("pointerdown", onDown, true);
    renderer.domElement.addEventListener("pointermove", onMove);
    renderer.domElement.addEventListener("pointerup", onUp);
    renderer.domElement.addEventListener("pointercancel", onUp);
    const blockMenu = (event: Event) => event.preventDefault();
    renderer.domElement.addEventListener("contextmenu", blockMenu);

    const watch = new ResizeObserver(resize);
    watch.observe(wrap);
    resize();

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!refs.exporting) {
        const slice = activeSlice(useCourt.getState());
        if (slice.play) {
          if (slice.play.mode !== builtMode) {
            builtMode = slice.play.mode;
            rebuild(slice.play.mode);
            frameCamera(slice.play.mode);
          }
          let shown = slice.frame;
          if (refs.playing && slice.play.frames.length > 1) {
            refs.acc += dt;
            const segs = slice.play.frames.length - 1;
            const t = (refs.acc % (segs * SEG_SECONDS)) / SEG_SECONDS;
            shown = sampleFrame(slice.play.frames, t).frame;
          }
          if (shown) place(shown, slice.play.mode);
        }
        controls.update();
        renderer.render(scene, camera);
      }
    };
    raf = requestAnimationFrame(loop);
    if (!activeSlice(useCourt.getState()).play) {
      rebuild("half");
      builtMode = "half";
      frameCamera("half");
    }

    api.current.togglePlay = () => {
      const slice = activeSlice(useCourt.getState());
      if (!slice.play || slice.play.frames.length < 2) {
        if (alive) setToast("برای پخش حداقل دو فریم لازم است");
        return;
      }
      refs.playing = !refs.playing;
      if (refs.playing) refs.acc = 0;
      if (alive) setPlaying(refs.playing);
    };
    api.current.reset = () => {
      const mode = activeSlice(useCourt.getState()).play?.mode ?? "half";
      frameCamera(mode);
    };
    api.current.step = (dir) => {
      refs.playing = false;
      if (alive) setPlaying(false);
      const state = useCourt.getState();
      state.setFrameIndex(state.frameIndex + dir);
    };
    api.current.exportPng = async () => {
      renderer.render(scene, camera);
      const blob = await new Promise<Blob | null>((resolve) => renderer.domElement.toBlob(resolve, "image/png"));
      if (!blob) return;
      const title = activeSlice(useCourt.getState()).play?.title ?? "court";
      const result = await shareOrDownload(blob, `${safeName(title)}-3d.png`);
      if (alive && result !== "abort") setToast("عکس سه‌بعدی ذخیره شد");
    };
    api.current.exportGif = async () => {
      const slice = activeSlice(useCourt.getState());
      if (!slice.play || slice.play.frames.length < 2) {
        if (alive) setToast("برای تصویر متحرک حداقل دو فریم بسازید");
        return;
      }
      refs.playing = false;
      if (alive) {
        setPlaying(false);
        setBusy(true);
      }
      refs.exporting = true;
      try {
        const playNow = slice.play;
        const n = playNow.frames.length;
        let steps = Math.max(4, Math.round(8 * SEG_SECONDS));
        while ((n - 1) * steps + 1 > 60 && steps > 4) steps -= 1;
        const shots: HTMLCanvasElement[] = [];
        const src = renderer.domElement;
        const tw = 480;
        const th = Math.max(2, Math.round(tw * (src.height / Math.max(1, src.width))));
        for (let i = 0; i <= (n - 1) * steps; i++) {
          if (!alive) return;
          const sampled = sampleFrame(playNow.frames, i / steps).frame;
          place(sampled, playNow.mode);
          renderer.render(scene, camera);
          const shot = document.createElement("canvas");
          shot.width = tw;
          shot.height = th;
          shot.getContext("2d")?.drawImage(src, 0, 0, tw, th);
          shots.push(shot);
        }
        const blob = await encodeGif(shots, Math.round((SEG_SECONDS * 1000) / steps));
        const result = await shareOrDownload(blob, `${safeName(playNow.title)}-3d.gif`);
        if (alive && result !== "abort") setToast("تصویر متحرک سه‌بعدی آماده شد");
      } catch {
        if (alive) setToast("ساخت تصویر متحرک ممکن نشد");
      } finally {
        refs.exporting = false;
        if (alive) setBusy(false);
      }
    };

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      watch.disconnect();
      renderer.domElement.removeEventListener("pointerdown", onDown, true);
      renderer.domElement.removeEventListener("pointermove", onMove);
      renderer.domElement.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("pointercancel", onUp);
      renderer.domElement.removeEventListener("contextmenu", blockMenu);
      controls.dispose();
      if (floor) {
        floor.geometry.dispose();
        const mat = floor.material as THREE.MeshStandardMaterial;
        mat.map?.dispose();
        mat.dispose();
      }
      if (apron) {
        apron.geometry.dispose();
        (apron.material as THREE.Material).dispose();
      }
      clearGroup(hoopRoot);
      coneGeo.dispose();
      ballGeo.dispose();
      hitGeo.dispose();
      ringGeo.dispose();
      homeMat.dispose();
      awayMat.dispose();
      ballMat.dispose();
      hitMat.dispose();
      ringMat.dispose();
      rimMat.dispose();
      boardMat.dispose();
      poleMat.dispose();
      targetMat.dispose();
      for (const group of tokens.values()) {
        group.traverse((obj) => {
          if (obj instanceof THREE.Sprite) {
            obj.material.map?.dispose();
            obj.material.dispose();
          }
        });
      }
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div className="relative min-h-0 flex-1">
      <div ref={wrapRef} className="absolute inset-0" />
      {failed ? (
        <p className="absolute inset-0 flex items-center justify-center p-6 text-center text-muted">
          این دستگاه نمای سه‌بعدی را نشان نمی‌دهد.
        </p>
      ) : null}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
        <p className="pointer-events-none max-w-56 rounded-xl bg-surface px-3 py-2 text-xs leading-5 text-muted">
          بچرخانید، زوم کنید، بازیکن را بکشید. {play ? play.title : "تاکتیکی نیست"} · فریم {frameIndex + 1}
        </p>
        <div className="pointer-events-auto flex gap-2">
          <Btn aria-label="فریم قبلی" onClick={() => api.current.step(-1)}>
            قبلی
          </Btn>
          <Btn aria-label="فریم بعدی" onClick={() => api.current.step(1)}>
            بعدی
          </Btn>
        </div>
      </div>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex gap-2 overflow-x-auto p-3">
        <Btn tone="amber" className="pointer-events-auto" onClick={() => api.current.togglePlay()}>
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
          {playing ? "ایست" : "پخش"}
        </Btn>
        <Btn className="pointer-events-auto" aria-label="بازنشانی دوربین" onClick={() => api.current.reset()}>
          <RotateCcw className="size-4" />
          دوربین
        </Btn>
        <Btn className="pointer-events-auto" aria-label="عکس" onClick={() => void api.current.exportPng()}>
          <Image className="size-4" />
          عکس
        </Btn>
        <Btn
          className="pointer-events-auto"
          aria-label="تصویر متحرک"
          disabled={busy}
          onClick={() => void api.current.exportGif()}
        >
          <Film className="size-4" />
          {busy ? "..." : "گیف"}
        </Btn>
      </div>
      {toast ? (
        <p className="pointer-events-none absolute inset-x-3 bottom-20 rounded-xl bg-surface px-3 py-2 text-center text-sm">
          {toast}
        </p>
      ) : null}
    </div>
  );
}
