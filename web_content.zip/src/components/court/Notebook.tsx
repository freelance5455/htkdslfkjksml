import { useEffect, useRef } from "react";
import { Copy, Plus, Trash2 } from "lucide-react";
import { paintScene } from "@/lib/court/draw";
import { useCourt } from "@/lib/court/store";
import { POSITIONS, type Play, type Pos } from "@/lib/court/types";
import { Btn, fieldClass } from "@/components/court/ui";

function formatFa(iso: string) {
  const [year, month, day] = iso.split("-").map(Number);
  if (!year || !month || !day) return iso;
  return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString("fa-IR", { timeZone: "UTC" });
}

function Thumb({ play }: { play: Play }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const width = 320;
    const height = 220;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const frame = play.frames[0];
    if (!frame) return;
    paintScene(ctx, width, height, play.mode, frame, { pad: 10 });
  }, [play]);
  return <canvas ref={ref} className="h-28 w-full rounded-xl bg-bg" aria-hidden="true" />;
}

export function Notebook({ onOpen }: { onOpen: () => void }) {
  const plays = useCourt((state) => state.plays);
  const roster = useCourt((state) => state.roster);
  const notes = useCourt((state) => state.notes);
  const session = useCourt((state) => state.session);

  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <section className="rounded-2xl border border-line bg-surface p-4">
          <h2 className="text-base font-extrabold">اطلاعات جلسه</h2>
          <p className="pt-1 text-sm text-muted">همین‌جا می‌ماند و روی زمین هم دیده می‌شود. ذخیره روی همین دستگاه است.</p>
          <div className="grid gap-3 pt-4 sm:grid-cols-3">
            <label className="block text-sm text-muted">
              حریف
              <input
                className={`${fieldClass} mt-1`}
                value={session.opponent}
                onChange={(event) => useCourt.getState().setSession({ opponent: event.target.value })}
              />
            </label>
            <label className="block text-sm text-muted">
              تاریخ
              <input
                type="date"
                className={`${fieldClass} mt-1`}
                value={session.date}
                onChange={(event) => useCourt.getState().setSession({ date: event.target.value })}
              />
            </label>
            <label className="block text-sm text-muted">
              تمرکز
              <input
                className={`${fieldClass} mt-1`}
                value={session.focus}
                onChange={(event) => useCourt.getState().setSession({ focus: event.target.value })}
              />
            </label>
          </div>
          <p className="pt-3 text-sm text-chalk">{formatFa(session.date)}</p>
          <div className="grid grid-cols-3 gap-2 pt-4">
            <Stat value={plays.length} label="تاکتیک" />
            <Stat value={roster.length} label="بازیکن" />
            <Stat value={notes.length} label="یادداشت" />
          </div>
        </section>

        <section className="rounded-2xl border border-line bg-surface p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-extrabold">تاکتیک‌ها</h2>
            <Btn tone="amber" onClick={() => useCourt.getState().newPlay()}>
              <Plus className="size-4" />
              تازه
            </Btn>
          </div>
          {plays.length === 0 ? (
            <p className="pt-4 text-sm text-muted">دفتر خالی است. یک تاکتیک بسازید و روی زمین بچینید.</p>
          ) : (
            <ul className="flex flex-col gap-3 pt-4">
              {plays.map((play) => (
                <li key={play.id} className="rounded-2xl border border-line bg-surface-2 p-3">
                  <Thumb play={play} />
                  <p className="pt-3 font-semibold">{play.title}</p>
                  <p className="text-sm text-muted">
                    {play.mode === "half" ? "نیمه زمین" : "تمام زمین"} · {play.frames.length} فریم
                  </p>
                  <div className="flex gap-2 overflow-x-auto pt-3">
                    <Btn
                      tone="amber"
                      onClick={() => {
                        useCourt.getState().openPlay(play.id);
                        onOpen();
                      }}
                    >
                      باز کردن
                    </Btn>
                    <Btn aria-label="کپی تاکتیک" onClick={() => useCourt.getState().duplicatePlay(play.id)}>
                      <Copy className="size-4" />
                    </Btn>
                    <Btn aria-label="حذف تاکتیک" onClick={() => useCourt.getState().deletePlay(play.id)}>
                      <Trash2 className="size-4" />
                    </Btn>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-line bg-surface p-4">
          <h2 className="text-base font-extrabold">ترکیب</h2>
          <p className="pt-1 text-sm text-muted">روی زمین دوبعدی، نام بازیکن را بزنید تا مهره‌اش بیاید.</p>
          <ul className="flex flex-col gap-2 pt-4">
            {roster.map((player) => (
              <li key={player.id} className="grid grid-cols-1 gap-2 sm:grid-cols-[4.5rem_1fr_8rem_auto]">
                <input
                  className={fieldClass}
                  aria-label="شماره"
                  value={player.number}
                  onChange={(event) => useCourt.getState().updateRoster(player.id, { number: event.target.value })}
                />
                <input
                  className={fieldClass}
                  aria-label="نام"
                  value={player.name}
                  onChange={(event) => useCourt.getState().updateRoster(player.id, { name: event.target.value })}
                />
                <select
                  className={fieldClass}
                  aria-label="پست"
                  value={player.pos}
                  onChange={(event) =>
                    useCourt.getState().updateRoster(player.id, { pos: event.target.value as Pos })
                  }
                >
                  {POSITIONS.map((pos) => (
                    <option key={pos.id} value={pos.id}>
                      {pos.label}
                    </option>
                  ))}
                </select>
                <Btn aria-label="حذف بازیکن" onClick={() => useCourt.getState().removeRoster(player.id)}>
                  <Trash2 className="size-4" />
                </Btn>
              </li>
            ))}
          </ul>
          <RosterAdd />
        </section>

        <section className="rounded-2xl border border-line bg-surface p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-extrabold">یادداشت مربی</h2>
            <Btn onClick={() => useCourt.getState().addNote()}>
              <Plus className="size-4" />
              یادداشت
            </Btn>
          </div>
          <ul className="flex flex-col gap-3 pt-4">
            {notes.map((note) => (
              <li key={note.id} className="rounded-2xl border border-line bg-surface-2 p-3">
                <input
                  className={fieldClass}
                  aria-label="عنوان یادداشت"
                  value={note.title}
                  onChange={(event) => useCourt.getState().updateNote(note.id, { title: event.target.value })}
                />
                <textarea
                  className="mt-2 min-h-24 w-full rounded-xl border border-line bg-bg px-3 py-2 text-base text-fg outline-none focus:border-amber"
                  aria-label="متن یادداشت"
                  value={note.body}
                  onChange={(event) => useCourt.getState().updateNote(note.id, { body: event.target.value })}
                />
                <div className="pt-2">
                  <Btn aria-label="حذف یادداشت" onClick={() => useCourt.getState().removeNote(note.id)}>
                    <Trash2 className="size-4" />
                    حذف
                  </Btn>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-xl bg-surface-2 px-3 py-3 text-center">
      <p className="text-2xl font-extrabold text-amber">{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}

function RosterAdd() {
  const ref = useRef<HTMLFormElement>(null);
  return (
    <form
      ref={ref}
      className="grid grid-cols-1 gap-2 pt-4 sm:grid-cols-[4.5rem_1fr_8rem_auto]"
      onSubmit={(event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        const number = String(data.get("number") ?? "").trim();
        const name = String(data.get("name") ?? "").trim();
        const pos = String(data.get("pos") ?? "PG") as Pos;
        if (!number || !name) return;
        useCourt.getState().addRoster({ number, name, pos });
        event.currentTarget.reset();
      }}
    >
      <input name="number" className={fieldClass} placeholder="شماره" aria-label="شماره تازه" />
      <input name="name" className={fieldClass} placeholder="نام بازیکن" aria-label="نام تازه" />
      <select name="pos" className={fieldClass} aria-label="پست تازه" defaultValue="PG">
        {POSITIONS.map((pos) => (
          <option key={pos.id} value={pos.id}>
            {pos.label}
          </option>
        ))}
      </select>
      <Btn tone="amber" type="submit">
        افزودن
      </Btn>
    </form>
  );
}
