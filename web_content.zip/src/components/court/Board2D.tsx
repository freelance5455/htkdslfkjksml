import { useEffect, useRef, useState } from "react";
import {
  ArrowUpRight,
  CircleDot,
  Copy,
  Eraser,
  Film,
  Image,
  Move,
  Pause,
  Play,
  Plus,
  Shield,
  Trash2,
  TrendingUp,
  UserPlus,
  Users,
} from "lucide-react";
import { paintScene } from "@/lib/court/draw";
import { encodeGif, renderPlayGifFrames, safeName, shareOrDownload } from "@/lib/court/gif";
import { courtPad, distToSeg, fitCourt, makeMap } from "@/lib/court/geometry";
import { SEG_SECONDS, sampleFrame } from "@/lib/court/interp";
import { activeSlice, useCourt } from "@/lib/court/store";
import type { ArrowKind, Team } from "@/lib/court/types";
import { Btn, fieldClass } from "@/components/court/ui";

type Tool = "move" | ArrowKind | "erase";

const TOOLS: { id: Tool; label: string; icon: typeof Move }[] = [
  { id: "move", label: "جابه‌جایی", icon: Move },
  { id: "pass", label: "پاس", icon: ArrowUpRight },
  { id: "cut", label: "برش", icon: TrendingUp },
  { id: "screen", label: "اسکرین", icon: Shield },
  { id: "dribble", label: "دریبل", icon: CircleDot },
  { id: "erase", label: "پاک", icon: Eraser },
];

export function Board2D() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [tool, setTool] = useState<Tool>("move");
  const [selected, setSelected] = useState<string | null>(null);
  const [draft, setDraft] = useState<{ x1: number; y1: number; x2: number; y2: number; kind: ArrowKind } | null>(
    null,
  );
  const draftRef = useRef<{ x1: number; y1: number; x2: number; y2: number; kind: ArrowKind } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [playT, setPlayT] = useState(0);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [fontsReady, setFontsReady] = useState(false);
  const dragRef = useRef<{ id: string; ox: number; oy: number } | null>(null);

  const play = useCourt((state) => state.plays.find((item) => item.id === state.activePlayId) ?? null);
  const frameIndex = useCourt((state) => state.frameIndex);
  const roster = useCourt((state) => state.roster);
  const session = useCourt((state) => state.session);
  const setFrameIndex = useCourt((state) => state.setFrameIndex);
  const frame = play?.frames[Math.min(frameIndex, Math.max(0, (play?.frames.length ?? 1) - 1))] ?? null;

  useEffect(() => {
    void document.fonts.ready.then(() => setFontsReady(true));
  }, []);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const watch = new ResizeObserver(() => {
      const rect = el.getBoundingClientRect();
      setSize({ w: Math.floor(rect.width), h: Math.floor(rect.height) });
    });
    watch.observe(el);
    return () => watch.disconnect();
  }, []);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const step = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt;
      const current = activeSlice(useCourt.getState()).play;
      const segs = Math.max(1, (current?.frames.length ?? 1) - 1);
      setPlayT((acc % (segs * SEG_SECONDS)) / SEG_SECONDS);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !play || !frame || size.w < 2 || size.h < 2) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(size.w * dpr);
    canvas.height = Math.floor(size.h * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const shown = playing ? sampleFrame(play.frames, playT).frame : frame;
    const alpha = playing ? sampleFrame(play.frames, playT).arrowAlpha : 1;
    paintScene(ctx, canvas.width, canvas.height, play.mode, shown, {
      selectedId: playing ? null : selected,
      draft: playing ? null : draft,
      arrowAlpha: alpha,
    });
  }, [play, frame, size, selected, draft, playing, playT, fontsReady]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2400);
    return () => window.clearTimeout(id);
  }, [toast]);

  function pointer(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const bounds = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - bounds.left) * canvas.width) / bounds.width,
      y: ((event.clientY - bounds.top) * canvas.height) / bounds.height,
    };
  }

  function scene() {
    const canvas = canvasRef.current;
    const slice = activeSlice(useCourt.getState());
    if (!canvas || !slice.play || !slice.frame) return null;
    const rect = fitCourt(canvas.width, canvas.height, slice.play.mode, courtPad(canvas.width, canvas.height));
    return { ...slice, map: makeMap(rect, slice.play.mode), canvas };
  }

  function hitToken(x: number, y: number) {
    const view = scene();
    if (!view?.frame) return null;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const ordered = [...view.frame.tokens].reverse();
    for (const token of ordered) {
      const p = view.map.normToPx(token.x, token.y);
      const visual = (token.kind === "ball" ? 0.3 : 0.58) * view.map.ppm;
      if (Math.hypot(p.x - x, p.y - y) <= Math.max(visual, 22 * dpr)) return token;
    }
    return null;
  }

  function onDown(event: React.PointerEvent<HTMLCanvasElement>) {
    if (playing) setPlaying(false);
    const point = pointer(event);
    const view = scene();
    if (!point || !view?.frame) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    const token = hitToken(point.x, point.y);
    if (tool === "erase") {
      if (token) useCourt.getState().removeToken(token.id);
      else {
        const arrow = [...view.frame.arrows].reverse().find((item) => {
          const a = view.map.normToPx(item.x1, item.y1);
          const b = view.map.normToPx(item.x2, item.y2);
          return distToSeg(point.x, point.y, a.x, a.y, b.x, b.y) < 18 * Math.min(window.devicePixelRatio || 1, 2);
        });
        if (arrow) useCourt.getState().removeArrow(arrow.id);
      }
      return;
    }
    if (tool !== "move") {
      const norm = view.map.pxToNorm(point.x, point.y);
      if (!norm.inside) return;
      const start = token ? { x: token.x, y: token.y } : norm;
      const next = { x1: start.x, y1: start.y, x2: start.x, y2: start.y, kind: tool };
      draftRef.current = next;
      setDraft(next);
      return;
    }
    if (!token) {
      setSelected(null);
      return;
    }
    setSelected(token.id);
    const norm = view.map.pxToNorm(point.x, point.y);
    dragRef.current = { id: token.id, ox: token.x - norm.x, oy: token.y - norm.y };
  }

  function onMove(event: React.PointerEvent<HTMLCanvasElement>) {
    const point = pointer(event);
    const view = scene();
    if (!point || !view) return;
    const current = draftRef.current;
    if (current && tool !== "move" && tool !== "erase") {
      const norm = view.map.pxToNorm(point.x, point.y);
      const token = hitToken(point.x, point.y);
      const next = {
        ...current,
        x2: token ? token.x : norm.x,
        y2: token ? token.y : norm.y,
      };
      draftRef.current = next;
      setDraft(next);
      return;
    }
    const drag = dragRef.current;
    if (!drag) return;
    const norm = view.map.pxToNorm(point.x, point.y);
    useCourt.getState().updateToken(
      drag.id,
      Math.min(0.98, Math.max(0.02, norm.x + drag.ox)),
      Math.min(0.98, Math.max(0.02, norm.y + drag.oy)),
    );
  }

  function onUp() {
    const drawn = draftRef.current;
    if (drawn && Math.hypot(drawn.x2 - drawn.x1, drawn.y2 - drawn.y1) > 0.03) {
      useCourt.getState().addArrow(drawn);
    }
    draftRef.current = null;
    setDraft(null);
    dragRef.current = null;
  }

  async function onGif() {
    if (!play) return;
    if (play.frames.length < 2) {
      setToast("برای تصویر متحرک حداقل دو فریم بسازید");
      return;
    }
    setBusy(true);
    setPlaying(false);
    try {
      const { frames, delay } = renderPlayGifFrames(play);
      const blob = await encodeGif(frames, delay);
      const result = await shareOrDownload(blob, `${safeName(play.title)}.gif`);
      if (result !== "abort") setToast("تصویر متحرک آماده شد");
    } catch {
      setToast("ساخت تصویر متحرک ممکن نشد");
    } finally {
      setBusy(false);
    }
  }

  function onPng() {
    const canvas = canvasRef.current;
    if (!canvas || !play) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const result = await shareOrDownload(blob, `${safeName(play.title)}.png`);
      if (result !== "abort") setToast("عکس ذخیره شد");
    }, "image/png");
  }

  function addPlayer(team: Team, label: string) {
    if (!frame) return;
    if (frame.tokens.some((token) => token.team === team && token.label === label)) {
      setToast("این بازیکن روی زمین است");
      return;
    }
    useCourt.getState().addToken({ kind: "player", team, label });
    setTool("move");
  }

  if (!play || !frame) {
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="text-muted">هنوز تاکتیکی ندارید.</p>
        <Btn tone="amber" onClick={() => useCourt.getState().newPlay()}>
          تاکتیک تازه
        </Btn>
      </div>
    );
  }

  const shownNote = playing ? sampleFrame(play.frames, playT).frame.note : frame.note;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 px-3 pt-3">
        <input
          className={fieldClass}
          value={play.title}
          aria-label="نام تاکتیک"
          onChange={(event) => useCourt.getState().renamePlay(event.target.value)}
        />
        <div className="flex shrink-0 rounded-xl bg-surface-2 p-1">
          <button
            type="button"
            className={`h-11 rounded-lg px-3 text-sm font-semibold ${play.mode === "half" ? "bg-amber text-amber-ink" : "text-muted"}`}
            onClick={() => useCourt.getState().setMode("half")}
          >
            نیمه
          </button>
          <button
            type="button"
            className={`h-11 rounded-lg px-3 text-sm font-semibold ${play.mode === "full" ? "bg-amber text-amber-ink" : "text-muted"}`}
            onClick={() => useCourt.getState().setMode("full")}
          >
            کامل
          </button>
        </div>
      </div>
      <p className="truncate px-3 pt-2 text-xs text-muted">
        {session.opponent} · {session.focus}
      </p>
      <div className="flex gap-2 overflow-x-auto px-3 py-2">
        {TOOLS.map((item) => {
          const Icon = item.icon;
          const on = tool === item.id;
          return (
            <Btn key={item.id} tone={on ? "amber" : "ghost"} aria-pressed={on} onClick={() => setTool(item.id)}>
              <Icon className="size-4" aria-hidden="true" />
              {item.label}
            </Btn>
          );
        })}
        <Btn tone="amber" onClick={() => addPlayer("home", nextLabel(frame, "home"))}>
          <UserPlus className="size-4" aria-hidden="true" />
          خودی
        </Btn>
        <Btn tone="steel" onClick={() => addPlayer("away", nextLabel(frame, "away"))}>
          <Users className="size-4" aria-hidden="true" />
          حریف
        </Btn>
        <Btn
          onClick={() => {
            if (frame.tokens.some((token) => token.kind === "ball")) {
              setToast("توپ روی زمین است");
              return;
            }
            useCourt.getState().addToken({ kind: "ball", label: "" });
          }}
        >
          <CircleDot className="size-4" aria-hidden="true" />
          توپ
        </Btn>
      </div>
      <div className="flex gap-2 overflow-x-auto px-3 pb-2">
        {roster.map((player) => (
          <button
            key={player.id}
            type="button"
            className="h-11 shrink-0 rounded-full bg-surface-2 px-3 text-sm text-fg"
            onClick={() => addPlayer("home", player.number)}
          >
            {player.number} {player.name}
          </button>
        ))}
      </div>
      <div ref={wrapRef} className="relative min-h-0 flex-1">
        <canvas
          ref={canvasRef}
          className="h-full w-full touch-none select-none"
          aria-label="زمین تاکتیک بسکتبال"
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
          onContextMenu={(event) => event.preventDefault()}
        />
        {toast ? (
          <p className="pointer-events-none absolute inset-x-3 bottom-3 rounded-xl bg-surface px-3 py-2 text-center text-sm text-fg">
            {toast}
          </p>
        ) : null}
      </div>
      <label className="px-3 pt-2 text-xs text-muted" htmlFor="frame-note">
        یادداشت فریم {frameIndex + 1}
      </label>
      <div className="px-3 pb-2">
        <input
          id="frame-note"
          className={fieldClass}
          value={playing ? shownNote : frame.note}
          readOnly={playing}
          placeholder="این حرکت را برای بازیکن‌ها بنویسید"
          onChange={(event) => useCourt.getState().setFrameNote(event.target.value)}
        />
      </div>
      <div className="flex gap-2 overflow-x-auto px-3 pb-2">
        <Btn
          tone="amber"
          disabled={play.frames.length < 2}
          aria-label={playing ? "ایست" : "پخش"}
          onClick={() => setPlaying((value) => !value)}
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
          {playing ? "ایست" : "پخش"}
        </Btn>
        <Btn aria-label="فریم تازه" onClick={() => useCourt.getState().addFrame()}>
          <Plus className="size-4" />
          فریم
        </Btn>
        <Btn aria-label="حذف فریم" disabled={play.frames.length < 2} onClick={() => useCourt.getState().deleteFrame()}>
          <Trash2 className="size-4" />
        </Btn>
        <Btn aria-label="حذف مهره" disabled={!selected} onClick={() => selected && useCourt.getState().removeToken(selected)}>
          <Eraser className="size-4" />
        </Btn>
        <Btn aria-label="عکس" onClick={onPng}>
          <Image className="size-4" />
          عکس
        </Btn>
        <Btn aria-label="تصویر متحرک" disabled={busy} onClick={() => void onGif()}>
          <Film className="size-4" />
          {busy ? "..." : "گیف"}
        </Btn>
        <Btn aria-label="تاکتیک تازه" onClick={() => useCourt.getState().newPlay()}>
          <Copy className="size-4" />
          تازه
        </Btn>
      </div>
      <div className="flex gap-2 overflow-x-auto px-3 pb-3">
        {play.frames.map((item, index) => (
          <button
            key={item.id}
            type="button"
            className={`h-11 min-w-11 rounded-xl px-3 text-sm font-semibold ${
              index === frameIndex ? "bg-amber text-amber-ink" : "bg-surface-2 text-fg"
            }`}
            onClick={() => {
              setPlaying(false);
              setFrameIndex(index);
            }}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

function nextLabel(frame: { tokens: { team?: Team; label: string }[] }, team: Team) {
  const used = new Set(frame.tokens.filter((token) => token.team === team).map((token) => token.label));
  for (let n = 1; n <= 15; n++) {
    if (!used.has(String(n))) return String(n);
  }
  return String(used.size + 1);
}
