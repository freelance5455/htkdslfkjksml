import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "ghost" | "amber" | "steel" | "quiet";
};

export function Btn({ tone = "ghost", className, type = "button", ...props }: Props) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex h-11 shrink-0 items-center justify-center gap-1.5 rounded-xl px-3 text-sm font-semibold disabled:opacity-40",
        tone === "ghost" && "bg-surface-2 text-fg",
        tone === "amber" && "bg-amber text-amber-ink",
        tone === "steel" && "bg-steel text-fg",
        tone === "quiet" && "bg-transparent text-muted",
        className,
      )}
      {...props}
    />
  );
}

export const fieldClass =
  "h-11 w-full rounded-xl border border-line bg-surface-2 px-3 text-base text-fg outline-none focus:border-amber";
