import { useEffect, useState } from "react";
import { BookOpen, Box, Square } from "lucide-react";
import { Board2D } from "@/components/court/Board2D";
import { Court3D } from "@/components/court/Court3D";
import { Notebook } from "@/components/court/Notebook";
import { useCourt } from "@/lib/court/store";

type Tab = "board" | "space" | "book";

const TABS: { id: Tab; label: string; icon: typeof Square }[] = [
  { id: "board", label: "دوبعدی", icon: Square },
  { id: "space", label: "سه‌بعدی", icon: Box },
  { id: "book", label: "دفترچه", icon: BookOpen },
];

export function AppShell() {
  const [tab, setTab] = useState<Tab>("board");

  useEffect(() => {
    void useCourt.persist.rehydrate();
  }, []);

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div>
          <p className="text-xs font-semibold tracking-widest text-amber">COURTLINE</p>
          <h1 className="text-xl font-extrabold leading-tight">کورت‌لاین</h1>
        </div>
        <p className="max-w-xs text-sm text-muted">تخته مربی بسکتبال</p>
      </header>
      <main className="flex min-h-0 flex-1 flex-col">
        {tab === "board" ? <Board2D /> : null}
        {tab === "space" ? <Court3D /> : null}
        {tab === "book" ? <Notebook onOpen={() => setTab("board")} /> : null}
      </main>
      <nav className="grid grid-cols-3 gap-2 border-t border-line bg-surface px-3 py-2" aria-label="بخش‌ها">
        {TABS.map((item) => {
          const Icon = item.icon;
          const on = tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              aria-current={on ? "page" : undefined}
              className={`flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-semibold ${
                on ? "bg-amber text-amber-ink" : "text-muted"
              }`}
              onClick={() => setTab(item.id)}
            >
              <Icon className="size-4" aria-hidden="true" />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
