import React, { useState } from 'react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  updateProfile,
} from 'firebase/auth';
import { auth } from '../firebase';
import { playClickTone, playReplyTone } from '../utils/audioEffects';
import { ABLogo } from './ABLogo';
import {
  X,
  Mail,
  Lock,
  User,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  defaultMode?: 'login' | 'signup';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  defaultMode = 'login',
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanEmail = email.trim();
    const cleanPassword = password.trim();

    if (!cleanEmail || !cleanPassword) {
      setError('براہ کرم ای میل اور پاس ورڈ درج کریں۔');
      return;
    }

    if (mode === 'signup') {
      if (cleanPassword.length < 6) {
        setError('پاس ورڈ کم از کم 6 حروف پر مشتمل ہونا چاہیے۔');
        return;
      }
      if (cleanPassword !== confirmPassword.trim()) {
        setError('پاس ورڈ کی تصدیق مماثل نہیں ہے۔');
        return;
      }
    }

    setLoading(true);
    playClickTone();

    try {
      if (mode === 'signup') {
        const userCred = await createUserWithEmailAndPassword(
          auth,
          cleanEmail,
          cleanPassword
        );
        if (displayName.trim() && userCred.user) {
          await updateProfile(userCred.user, {
            displayName: displayName.trim(),
          });
        }
      } else {
        await signInWithEmailAndPassword(auth, cleanEmail, cleanPassword);
      }

      playReplyTone();
      onSuccess?.();
      onClose();
    } catch (err: any) {
      console.error('Auth error:', err);
      let msg = err.message || 'تصدیق میں خرابی پیش آئی۔';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'غلط ای میل یا پاس ورڈ! براہ کرم درست معلومات درج کریں۔';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'یہ ای میل پہلے سے رجسٹرڈ ہے۔ براہ کرم لاگ ان کریں۔';
      } else if (err.code === 'auth/weak-password') {
        msg = 'پاس ورڈ بہت کمزور ہے۔ کم از کم 6 حروف منتخب کریں۔';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'درست ای میل فارمیٹ درج کریں (مثال: user@example.com)۔';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    playClickTone();

    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      playReplyTone();
      onSuccess?.();
      onClose();
    } catch (err: any) {
      console.error('Google Sign In error:', err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'گوگل لاگ ان مکمل نہ ہو سکا۔');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-[#0c1830] border border-[#1e3258] rounded-2xl shadow-2xl p-6 text-white overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            playClickTone();
            onClose();
          }}
          className="absolute right-4 top-4 p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-5">
          <div className="p-1 rounded-full bg-[#081225] border border-[#2a4365] mb-2 shadow">
            <ABLogo size={55} glow={false} />
          </div>
          <h2 className="text-lg font-bold text-[#E2C067] tracking-wider">
            {mode === 'login' ? 'اکاؤنٹ لاگ ان کریں' : 'نیا اکاؤنٹ بنائیں'}
          </h2>
          <p className="text-xs text-gray-400">
            {mode === 'login'
              ? 'Sign in to sync your conversation history'
              : 'Create an account for AB Voice Bot'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1 bg-[#081225] border border-[#1e3258] rounded-xl mb-4 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              playClickTone();
              setMode('login');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-colors cursor-pointer ${
              mode === 'login'
                ? 'bg-[#E2C067] text-[#081225] font-bold shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            لاگ ان (Log In)
          </button>
          <button
            type="button"
            onClick={() => {
              playClickTone();
              setMode('signup');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-colors cursor-pointer ${
              mode === 'signup'
                ? 'bg-[#E2C067] text-[#081225] font-bold shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            سائن اپ (Sign Up)
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-2.5 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="leading-tight">{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="block text-xs text-gray-300 mb-1">
                آپ کا نام (Your Name):
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="مثال: Bilal یا Ali"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
                />
                <User className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs text-gray-300 mb-1">
              ای میل (Email Address):
            </label>
            <div className="relative">
              <input
                type="email"
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
              />
              <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-xs text-gray-300 mb-1">
              پاس ورڈ (Password):
            </label>
            <div className="relative">
              <input
                type="password"
                required
                placeholder="کم از کم 6 حروف"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
              />
              <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {mode === 'signup' && (
            <div>
              <label className="block text-xs text-gray-300 mb-1">
                پاس ورڈ کی تصدیق (Confirm Password):
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  placeholder="دوبارہ پاس ورڈ درج کریں"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
                />
                <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-xs uppercase tracking-wider text-[#081225] bg-gradient-to-r from-[#FFF2B2] via-[#E2C067] to-[#B89230] shadow-[0_4px_15px_rgba(226,192,103,0.3)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span>
              {loading
                ? 'پروسیسنگ...'
                : mode === 'login'
                ? 'لاگ ان کریں (Log In)'
                : 'اکاؤنٹ بنائیں (Sign Up)'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center my-3 text-[11px] text-gray-500">
          <div className="flex-1 h-px bg-[#1e3258]" />
          <span className="px-2">یا (OR)</span>
          <div className="flex-1 h-px bg-[#1e3258]" />
        </div>

        {/* Google Sign In */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-2.5 px-4 rounded-xl border border-[#2a4365] bg-[#081225] hover:bg-[#111e38] text-xs font-semibold text-gray-200 transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.98 0 12c0 2.02.45 3.84 1.25 5.42l4.03-3.15Z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>
      </div>
    </div>
  );
};
