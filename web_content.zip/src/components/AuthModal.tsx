import React, { useState } from 'react';
import { X, ShieldCheck, User as UserIcon, Lock, Mail, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  currentUser: User | null;
  onClose: () => void;
  onLogin: (user: User) => void;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onLogin,
  onLogout
}) => {
  if (!isOpen) return null;

  const [authMode, setAuthMode] = useState<'owner' | 'customer'>('owner');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [error, setError] = useState('');

  const OWNER_EMAIL = 'princeukasha86@gmail.com';

  const handleOwnerQuickLogin = () => {
    const ownerUser: User = {
      id: 'owner-ukasha-01',
      name: 'Prince Ukasha',
      email: OWNER_EMAIL,
      role: 'owner',
      joinedDate: 'October 2026'
    };
    onLogin(ownerUser);
    onClose();
  };

  const handleOwnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedEmail = email.trim().toLowerCase();
    // Allow owner login for princeukasha86@gmail.com or admin credentials
    if (trimmedEmail === OWNER_EMAIL || trimmedEmail === 'admin@baitulukasha.com' || trimmedEmail === 'ukasha') {
      const ownerUser: User = {
        id: 'owner-ukasha-01',
        name: 'Prince Ukasha',
        email: OWNER_EMAIL,
        role: 'owner',
        joinedDate: 'October 2026'
      };
      onLogin(ownerUser);
      onClose();
    } else {
      setError(`Owner authorization is restricted. Only ${OWNER_EMAIL} has image upload & editing privileges.`);
    }
  };

  const handleCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your email.');
      return;
    }

    const customerUser: User = {
      id: `cust-${Date.now()}`,
      name: customerName.trim() || email.split('@')[0],
      email: email.trim().toLowerCase(),
      role: 'customer',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    };

    onLogin(customerUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* If Already Logged In */}
        {currentUser ? (
          <div className="text-center space-y-5 py-2">
            <div className="w-14 h-14 rounded-full bg-amber-100 text-stone-900 flex items-center justify-center mx-auto shadow-2xs">
              {currentUser.role === 'owner' ? (
                <ShieldCheck className="w-7 h-7 text-amber-900" />
              ) : (
                <UserIcon className="w-7 h-7 text-stone-800" />
              )}
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-semibold uppercase tracking-wider mb-2 bg-stone-100 text-stone-800">
                {currentUser.role === 'owner' ? '👑 Verified Store Owner' : 'Customer Account'}
              </div>
              <h3 className="font-serif text-2xl font-semibold text-stone-900">
                {currentUser.name}
              </h3>
              <p className="text-xs text-stone-500 mt-1">{currentUser.email}</p>
            </div>

            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-left text-xs text-stone-600 space-y-1.5">
              <p className="font-semibold text-stone-900">Account Privileges:</p>
              {currentUser.role === 'owner' ? (
                <ul className="list-disc list-inside space-y-1 text-emerald-800">
                  <li>Full permission to upload product images from device</li>
                  <li>Exclusive access to add, edit, and delete products</li>
                  <li>Manage prices and clear sample items</li>
                </ul>
              ) : (
                <ul className="list-disc list-inside space-y-1 text-stone-600">
                  <li>Place orders with Cash on Delivery or Wire</li>
                  <li>Save delivery address and order receipts</li>
                  <li>Save favorite items to wishlist</li>
                </ul>
              )}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="flex-1 py-2.5 bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors border border-stone-300"
              >
                Sign Out
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Continue Browsing
              </button>
            </div>
          </div>
        ) : (
          /* Sign In Form */
          <div>
            <div className="text-center mb-6">
              <span className="text-[11px] uppercase tracking-widest text-stone-500 font-semibold">
                Bait ul Ukasha Portal
              </span>
              <h2 className="font-serif text-2xl font-semibold text-stone-900 mt-1">
                Account Sign In
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                Sign in as the verified store owner to unlock image upload & inventory management.
              </p>
            </div>

            {/* Role Switcher Tabs */}
            <div className="grid grid-cols-2 p-1 bg-stone-100 rounded-lg mb-5 text-xs font-semibold">
              <button
                onClick={() => {
                  setAuthMode('owner');
                  setError('');
                }}
                className={`py-2 rounded-md transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  authMode === 'owner'
                    ? 'bg-white text-stone-950 shadow-2xs font-bold'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <span>👑 Store Owner</span>
              </button>
              <button
                onClick={() => {
                  setAuthMode('customer');
                  setError('');
                }}
                className={`py-2 rounded-md transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  authMode === 'customer'
                    ? 'bg-white text-stone-950 shadow-2xs font-bold'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <span>Customer</span>
              </button>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg font-medium">
                {error}
              </div>
            )}

            {authMode === 'owner' ? (
              <div className="space-y-4">
                {/* 1-Click Verified Owner Quick Access */}
                <div className="p-4 bg-amber-50/80 border border-amber-200/90 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-800" />
                    <span className="text-xs font-bold text-amber-950">
                      Store Owner Quick Access
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    Welcome, <strong>Prince Ukasha</strong>. Authenticate with your owner credentials ({OWNER_EMAIL}) to immediately enable product photo uploading and catalog editing.
                  </p>
                  <button
                    onClick={handleOwnerQuickLogin}
                    className="w-full py-2.5 bg-stone-900 hover:bg-stone-850 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
                  >
                    <span>Sign In as Prince Ukasha (Owner)</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="relative flex items-center justify-center">
                  <span className="bg-white px-2 text-[10px] text-stone-400 uppercase tracking-widest z-10">
                    Or Enter Owner Password
                  </span>
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-stone-200" />
                  </div>
                </div>

                {/* Manual Owner Credentials Form */}
                <form onSubmit={handleOwnerSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Owner Email
                    </label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={email || OWNER_EMAIL}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Passcode / Master Key
                    </label>
                    <div className="relative">
                      <Lock className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        placeholder="Owner key or password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer transition-colors"
                  >
                    Unlock Owner Controls
                  </button>
                </form>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={onClose}
                    className="text-stone-500 hover:text-stone-800 text-xs font-medium cursor-pointer underline decoration-stone-300 hover:decoration-stone-600"
                  >
                    Skip & Browse Store as Guest
                  </button>
                </div>
              </div>
            ) : (
              /* Customer Form */
              <div className="space-y-3">
                <form onSubmit={handleCustomerSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Your Full Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Fatima Ali"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        placeholder="customer@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
                    >
                      Continue as Customer
                    </button>
                    <p className="text-[11px] text-stone-500 text-center mt-2">
                      Customers can shop, checkout with COD, and save order history.
                    </p>
                  </div>
                </form>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={onClose}
                    className="text-stone-500 hover:text-stone-800 text-xs font-medium cursor-pointer underline decoration-stone-300 hover:decoration-stone-600"
                  >
                    Skip & Browse Store as Guest
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
