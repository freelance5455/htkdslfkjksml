import React, { useState } from 'react';
import { X, User, Lock, Mail, Heart, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { UserProfile, LanguageCode } from '../types/index.ts';
import { storageService, supabase, isSupabaseConfigured } from '../lib/supabase.ts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onUserUpdate: (profile: UserProfile | null) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserUpdate,
}) => {
  const { t, i18n } = useTranslation();
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [fullName, setFullName] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    try {
      if (isSupabaseConfigured && supabase) {
        if (tab === 'login') {
          const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
          });
          if (error) throw error;
          if (data.user) {
            const profile: UserProfile = {
              id: data.user.id,
              email: data.user.email,
              fullName: data.user.user_metadata?.full_name || fullName || 'Utilisateur',
              language: (i18n.language.substring(0, 2) as LanguageCode) || 'fr',
              isGuest: false,
              createdAt: data.user.created_at,
            };
            storageService.setUserProfile(profile);
            onUserUpdate(profile);
            onClose();
          }
        } else {
          const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options: {
              data: {
                full_name: fullName,
                language: i18n.language.substring(0, 2),
              },
            },
          });
          if (error) throw error;
          if (data.user) {
            const profile: UserProfile = {
              id: data.user.id,
              email: data.user.email,
              fullName: fullName || 'Utilisateur',
              language: (i18n.language.substring(0, 2) as LanguageCode) || 'fr',
              isGuest: false,
              createdAt: new Date().toISOString(),
            };
            storageService.setUserProfile(profile);
            onUserUpdate(profile);
            onClose();
          }
        }
      } else {
        // Local Account storage fallback
        const profile: UserProfile = {
          id: `usr_${Date.now()}`,
          email,
          fullName: fullName || email.split('@')[0] || 'Membre',
          language: (i18n.language.substring(0, 2) as LanguageCode) || 'fr',
          isGuest: false,
          createdAt: new Date().toISOString(),
        };
        storageService.setUserProfile(profile);
        onUserUpdate(profile);
        onClose();
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Erreur lors de l’authentification.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGuestMode = () => {
    const guestProfile: UserProfile = {
      id: 'guest_user',
      fullName: 'Visiteur Invité',
      language: (i18n.language.substring(0, 2) as LanguageCode) || 'fr',
      isGuest: true,
      createdAt: new Date().toISOString(),
    };
    storageService.setUserProfile(guestProfile);
    onUserUpdate(guestProfile);
    onClose();
  };

  const handleLogout = async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }
    storageService.clearUserProfile();
    onUserUpdate(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-100 dark:border-slate-800 p-6 sm:p-8 space-y-6 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-lg">
                {currentUser ? 'Votre Espace' : t('auth.title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('auth.subtitle')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {currentUser && !currentUser.isGuest ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 space-y-2">
              <div className="text-xs text-slate-400">Connecté en tant que :</div>
              <div className="font-bold text-slate-800 dark:text-slate-100">
                {currentUser.fullName}
              </div>
              <div className="text-xs text-slate-500">{currentUser.email}</div>
            </div>

            <button
              onClick={handleLogout}
              className="w-full py-3 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 font-bold text-sm transition-colors"
            >
              {t('nav.logout')}
            </button>
          </div>
        ) : (
          <>
            {/* Tabs */}
            <div className="flex rounded-2xl bg-slate-100 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setTab('login')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  tab === 'login'
                    ? 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {t('auth.loginTab')}
              </button>
              <button
                type="button"
                onClick={() => setTab('register')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  tab === 'register'
                    ? 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {t('auth.registerTab')}
              </button>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-rose-700 dark:text-rose-300 text-xs font-medium">
                {errorMessage}
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-3.5">
              {tab === 'register' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t('auth.name')}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Ex : Camille"
                      className="w-full text-xs pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-400"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t('auth.email')}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="vous@exemple.com"
                    className="w-full text-xs pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t('auth.password')}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full text-xs pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>
                  {isSubmitting
                    ? 'Chargement...'
                    : tab === 'login'
                    ? t('auth.loginTab')
                    : t('auth.registerTab')}
                </span>
              </button>
            </form>

            <div className="relative my-4 flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-700" />
              </div>
              <span className="relative bg-white dark:bg-slate-900 px-3 text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                ou
              </span>
            </div>

            {/* Guest Mode Option */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleGuestMode}
                className="w-full py-3 px-4 rounded-2xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/40 dark:hover:bg-teal-900/40 text-teal-800 dark:text-teal-200 font-bold text-xs transition-colors flex items-center justify-center gap-2 border border-teal-200/60 dark:border-teal-800"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{t('auth.guestButton')}</span>
              </button>
              <p className="text-[11px] text-center text-slate-400 leading-tight">
                {t('auth.guestNote')}
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
