import React, { useState } from 'react';
import { User, Lock, AlertCircle, ArrowRight, Eye, EyeOff, Sparkles, Check } from 'lucide-react';
import { User as UserType } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onAuthSuccess: (token: string, user: UserType) => void;
  initialMode?: 'login' | 'register';
  canClose?: boolean;
}

const AVATAR_OPTIONS = ['✦', '🧠', '⚡', '🚀', '🐱', '🦊', '🤖', '👑', '🔥', '🎯', '🥑', '👾'];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
  initialMode = 'register',
  canClose = false,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [canSwitchToLogin, setCanSwitchToLogin] = useState(false);

  // Form states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState('✦');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setCanSwitchToLogin(false);

    const cleanName = username.trim();
    if (!cleanName) {
      setError('Пожалуйста, укажите имя или логин');
      return;
    }

    if (cleanName.length < 2) {
      setError('Имя должно содержать не менее 2 символов');
      return;
    }

    if (!password || password.length < 3) {
      setError('Пароль должен быть не менее 3 символов');
      return;
    }

    setLoading(true);

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const payload =
        mode === 'register'
          ? {
              username: cleanName,
              displayName: cleanName,
              password,
              avatar: selectedAvatar,
            }
          : {
              login: cleanName,
              password,
            };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.canLogin) {
          setCanSwitchToLogin(true);
        }
        throw new Error(data.error || 'Произошла ошибка при авторизации');
      }

      // Store token
      localStorage.setItem('sosiska_token', data.token);
      onAuthSuccess(data.token, data.user);
      if (onClose) onClose();
    } catch (err: any) {
      setError(err.message || 'Ошибка подключения к серверу');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          login: 'guest_sosiska',
          password: 'demo1234',
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ошибка демо-входа');
      }
      localStorage.setItem('sosiska_token', data.token);
      onAuthSuccess(data.token, data.user);
      if (onClose) onClose();
    } catch (err: any) {
      setError(err.message || 'Не удалось выполнить демо-вход');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm sm:max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl p-6 sm:p-7 overflow-hidden">
        {/* Glow ambient */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-orange-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Mascot / Title */}
        <div className="text-center mb-5">
          <img
            src="/sosiska-logo.png"
            alt="Sosiska AI"
            className="w-14 h-14 rounded-2xl object-cover border border-orange-500/30 shadow-md mx-auto mb-2.5"
          />
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center justify-center gap-2">
            <span>Sosiska AI</span>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/30">
              Нейросеть
            </span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {mode === 'register' ? 'Быстрая регистрация личного аккаунта' : 'Вход в аккаунт нейросети'}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-neutral-950/80 border border-neutral-800 rounded-xl mb-4">
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError(null);
              setCanSwitchToLogin(false);
            }}
            className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Регистрация
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
              setCanSwitchToLogin(false);
            }}
            className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Вход
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs space-y-1.5">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              <div className="flex-1">{error}</div>
            </div>
            {canSwitchToLogin && (
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className="ml-6 text-[11px] font-semibold text-orange-400 hover:text-orange-300 underline cursor-pointer"
              >
                Нажмите здесь, чтобы войти в аккаунт →
              </button>
            )}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Выберите аватар:
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av}
                    type="button"
                    onClick={() => setSelectedAvatar(av)}
                    className={`w-9 h-9 shrink-0 flex items-center justify-center text-lg rounded-xl transition-all cursor-pointer ${
                      selectedAvatar === av
                        ? 'bg-orange-500/25 border-2 border-orange-500 scale-110 shadow-md'
                        : 'bg-neutral-800/70 hover:bg-neutral-700/70 border border-neutral-700/50'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Username / Name field */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              {mode === 'register' ? 'Ваше имя или логин' : 'Логин или имя'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                autoFocus
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={mode === 'register' ? 'Например: Булат или Иван' : 'Ваш логин'}
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-950/80 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-colors"
              />
            </div>
          </div>

          {/* Password field with show/hide eye toggle */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              Пароль
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Придумайте пароль"
                className="w-full pl-9 pr-10 py-2.5 bg-neutral-950/80 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-500 hover:text-neutral-300 cursor-pointer"
                title={showPassword ? 'Скрыть пароль' : 'Показать пароль'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-semibold text-sm rounded-xl shadow-lg shadow-orange-500/20 focus:outline-none focus:ring-2 focus:ring-orange-500 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'register' ? 'Создать аккаунт' : 'Войти в аккаунт'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Demo Fast Access */}
        <div className="mt-4 pt-3.5 border-t border-neutral-800/80 text-center">
          <button
            type="button"
            onClick={handleDemoLogin}
            disabled={loading}
            className="w-full py-2 px-3 text-xs font-medium text-neutral-400 hover:text-white bg-neutral-950/50 hover:bg-neutral-800/80 border border-neutral-800 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Войти как тестовый гость (без пароля)</span>
          </button>
        </div>

        {canClose && onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 rounded-lg"
          >
            ✕
          </button>
        )}
      </div>
    </div>
  );
};
