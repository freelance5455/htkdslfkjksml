import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User as UserIcon, 
  ShieldCheck, 
  GraduationCap, 
  CheckCircle2, 
  Key 
} from 'lucide-react';
import { UserRole, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onLoginSuccess: (email: string, role: UserRole) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  language,
  onLoginSuccess
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('kasun.p@lankapaperhub.lk');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('STUDENT');
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginSuccess(email, role);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl p-6 shadow-2xl relative space-y-5">
        
        <button onClick={onClose} className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-xl cursor-pointer">
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 mx-auto flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
            <GraduationCap className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-black text-white">LankaPaperHub Account</h3>
          <p className="text-xs text-slate-400">Sign in to upload past papers, save bookmarks & interact with community</p>
        </div>

        {/* Social Quick Login */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              onLoginSuccess('student.google@lankapaperhub.lk', 'STUDENT');
              onClose();
            }}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span>Google Login</span>
          </button>
          <button
            onClick={() => {
              onLoginSuccess('teacher.facebook@lankapaperhub.lk', 'TEACHER');
              onClose();
            }}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span>Facebook Login</span>
          </button>
        </div>

        <div className="relative flex items-center justify-center">
          <div className="w-full border-t border-slate-800"></div>
          <span className="bg-slate-900 px-3 text-[10px] font-bold uppercase text-slate-500 absolute">Or Email</span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {isRegister && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Kasun Perera"
                className="w-full bg-slate-950 text-xs text-white p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.lk"
              className="w-full bg-slate-950 text-xs text-white p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 text-xs text-white p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">Account Role</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full bg-slate-950 text-xs text-amber-300 font-bold p-3 rounded-xl border border-slate-800 focus:outline-none"
            >
              <option value="STUDENT">Student (ශිෂ්‍යයා)</option>
              <option value="TEACHER">Teacher (ගුරුවරයා)</option>
              <option value="ADMIN">Administrator (පරිපාලක)</option>
              <option value="SUPER_ADMIN">Super Administrator</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 cursor-pointer"
          >
            {isRegister ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="text-center pt-2">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-xs text-amber-400 hover:underline font-semibold cursor-pointer"
          >
            {isRegister ? 'Already have an account? Sign In' : 'Need an account? Register'}
          </button>
        </div>

      </div>
    </div>
  );
};
