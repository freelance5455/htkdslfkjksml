import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GmailSmtpSetupModal } from './GmailSmtpSetupModal';
import { 
  X, 
  Mail, 
  Phone, 
  KeyRound, 
  ShieldCheck, 
  ArrowRight,
  Send,
  CheckCircle2,
  AlertCircle,
  Lock,
  ExternalLink,
  Smartphone,
  RefreshCw,
  UserCheck
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    setIsAuthModalOpen, 
    loginExistingAccount, 
    registerUser,
    activeOtp,
    sendEmailOtp,
    verifyEmailOtp,
    checkAccountBinding
  } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [showSmtpModal, setShowSmtpModal] = useState(false);
  const [collegeCode, setCollegeCode] = useState('DU-NORTH');
  const [classInfo, setClassInfo] = useState("Student '26");
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
  const cleanEmail = email.trim().toLowerCase();
  const isPhone10 = cleanPhone.length === 10 && /^[6-9]\d{9}$/.test(cleanPhone);
  const isEmailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail);

  const binding = checkAccountBinding(cleanPhone, cleanEmail);

  const handleSendOtp = async () => {
    setErrorMsg('');
    setSuccessMsg('');

    if (!isPhone10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!isEmailOk) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    if (mode === 'login') {
      if (binding.status === 'phone_taken') {
        setErrorMsg(`This mobile number is registered with email (${binding.maskedEmail}). Please enter your registered email.`);
        return;
      }
      if (binding.status === 'email_taken') {
        setErrorMsg(`This email is registered with phone (${binding.maskedPhone}). Please enter your registered mobile number.`);
        return;
      }
      if (binding.status === 'available') {
        setErrorMsg(`No account found with these credentials. Please switch to 'New Registration'.`);
        return;
      }
    } else {
      if (binding.status === 'exact_match') {
        setErrorMsg(`Your account is already registered (@${binding.user?.avatarName})! Please switch to 'Sign In'.`);
        return;
      }
      if (binding.status === 'phone_taken') {
        setErrorMsg(`This mobile number is already registered to another account.`);
        return;
      }
      if (binding.status === 'email_taken') {
        setErrorMsg(`This email address is already registered to another account.`);
        return;
      }
    }

    setIsSubmitting(true);
    const res = await sendEmailOtp(cleanEmail, cleanPhone);
    setIsSubmitting(false);

    if (res.success) {
      setOtpSent(true);
      setOtpTimer(30);
      setOtp('');
      setSuccessMsg(`Verification code sent to ${cleanEmail}. Please check the email inbox on your phone.`);

      const interval = setInterval(() => {
        setOtpTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!otp.trim() || otp.trim().length !== 6) {
      setErrorMsg('Please enter the 6-digit verification code sent to your email.');
      return;
    }

    const isValid = verifyEmailOtp(cleanEmail, otp.trim());
    if (!isValid) {
      setErrorMsg('Invalid verification code. Please check your email inbox and enter the 6-digit code.');
      return;
    }

    if (mode === 'login' || (binding.status === 'exact_match' && binding.user)) {
      const targetUser = binding.user;
      if (targetUser) {
        loginExistingAccount(targetUser);
        setIsAuthModalOpen(false);
        return;
      }
    }

    // New registration
    const ok = registerUser(cleanEmail, cleanPhone, collegeCode, classInfo);
    if (ok) {
      setIsAuthModalOpen(false);
    } else {
      setErrorMsg('Failed to create account.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0e111d] border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-cyan-950/40 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">🤫</span>
            <div>
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-100">
                {mode === 'register' ? 'Create Secret Gossip Account' : 'Secure Campus Login'}
              </h3>
              <p className="text-[11px] text-slate-400">
                Enter your credentials to receive an email verification code
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Toggle: Login vs Register */}
        <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl my-4 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setOtpSent(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode === 'login' ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setOtpSent(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode === 'register' ? 'bg-pink-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>New Registration</span>
          </button>
        </div>

        {/* Error / Success Notifications */}
        {errorMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        <div className="space-y-3">
          {/* Phone input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>10-Digit Mobile Number *</span>
              </span>
              {phone.length > 0 && (
                <span className={`text-[10px] font-semibold ${isPhone10 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isPhone10 ? '✓ Valid' : '10 digits required'}
                </span>
              )}
            </label>
            <div className="relative">
              <span className="text-slate-400 font-mono text-xs absolute left-3 top-1/2 -translate-y-1/2">
                +91
              </span>
              <input
                type="tel"
                maxLength={10}
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value.replace(/\D/g, ''));
                  setOtpSent(false);
                }}
                placeholder="9876543210"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-11 pr-3 py-2.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Email input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-pink-400" />
                <span>Email Address (OTP Delivery) *</span>
              </span>
              {email.length > 0 && (
                <span className={`text-[10px] font-semibold ${isEmailOk ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isEmailOk ? '✓ Valid' : 'Invalid email'}
                </span>
              )}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setOtpSent(false);
                }}
                placeholder="student@university.edu"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <p className="text-[10px] text-cyan-400/90 mt-1">
              * Verification code is sent directly to this email address.
            </p>
          </div>

          {/* Quick Demo Pre-fill */}
          {!otpSent && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setPhone('9876543210');
                  setEmail('brahmprakashsingh8@gmail.com');
                  setMode('login');
                }}
                className="text-[10.5px] text-cyan-400 hover:underline font-mono"
              >
                Use Demo Account (9876543210 / brahmprakashsingh8@gmail.com)
              </button>
            </div>
          )}

          {/* Real-time match info */}
          {isPhone10 && isEmailOk && (
            <div>
              {mode === 'login' && binding.status === 'exact_match' && (
                <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-200 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Account Found: @{binding.user?.avatarName} ({binding.user?.collegeName})</span>
                </div>
              )}
              {mode === 'login' && binding.status === 'phone_taken' && (
                <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-300">
                  This mobile number is registered with email ({binding.maskedEmail})
                </div>
              )}
              {mode === 'login' && binding.status === 'email_taken' && (
                <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-300">
                  This email is registered with mobile number ({binding.maskedPhone})
                </div>
              )}
            </div>
          )}

          {/* Extra fields if register */}
          {mode === 'register' && !otpSent && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  College Code
                </label>
                <input
                  type="text"
                  value={collegeCode}
                  onChange={(e) => setCollegeCode(e.target.value.toUpperCase())}
                  placeholder="e.g. DU-NORTH, IITD-2026, BITS-P"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 uppercase font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Class Info (Department & Year)
                </label>
                <input
                  type="text"
                  value={classInfo}
                  onChange={(e) => setClassInfo(e.target.value)}
                  placeholder="e.g. B.Tech Computer Science '26"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </>
          )}

          {/* Send OTP button */}
          {!otpSent && (
            <>
              <button
                type="button"
                onClick={handleSendOtp}
                disabled={!isPhone10 || !isEmailOk || isSubmitting}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/25 flex items-center justify-center gap-1.5 disabled:opacity-40"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Verification OTP to Email</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSmtpModal(true)}
                className="w-full py-1.5 px-3 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-300 text-[10.5px] font-semibold flex items-center justify-center gap-1.5 transition-all mt-1"
              >
                <Mail className="w-3 h-3 text-cyan-400" />
                <span>Connect Live Gmail SMTP (Inbox Delivery)</span>
              </button>
            </>
          )}

          {/* OTP Sent Guidance Banner */}
          {otpSent && (
            <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>OTP Sent to: {cleanEmail}</span>
              </div>
              <p className="text-[11px] text-slate-200">
                Please open your Gmail or Mail app on your phone to view the 6-digit verification code. For privacy, verification codes are never leaked.
              </p>
              
              <div className="pt-1 flex items-center gap-2">
                <a
                  href="https://mail.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-1.5 px-2.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center justify-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Open Gmail</span>
                </a>
                <a
                  href={`mailto:${cleanEmail}`}
                  className="py-1.5 px-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-semibold flex items-center gap-1"
                >
                  <Smartphone className="w-3 h-3 text-cyan-400" />
                  <span>Mail App</span>
                </a>
              </div>
            </div>
          )}

          {/* OTP Input and Verification */}
          {otpSent && (
            <form onSubmit={handleVerifyOtp} className="space-y-2.5 pt-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
                  <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Enter 6-Digit Email OTP</span>
                </label>
                <button
                  type="button"
                  onClick={handleSendOtp}
                  disabled={otpTimer > 0}
                  className="text-[10.5px] font-semibold text-cyan-400 hover:text-cyan-300 disabled:text-slate-600 flex items-center gap-1"
                >
                  <RefreshCw className={`w-3 h-3 ${otpTimer > 0 ? 'animate-spin' : ''}`} />
                  <span>{otpTimer > 0 ? `Resend in ${otpTimer}s` : 'Resend OTP'}</span>
                </button>
              </div>

              <input
                type="text"
                maxLength={6}
                autoFocus
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                placeholder="••••••"
                className="w-full py-2.5 px-3 rounded-xl bg-slate-950 border border-cyan-500/50 text-center font-mono text-lg tracking-[0.3em] text-cyan-300 focus:outline-none"
              />

              <button
                type="submit"
                disabled={otp.length !== 6}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/25 flex items-center justify-center gap-1.5 disabled:opacity-40"
              >
                <span>{mode === 'login' ? 'Verify OTP & Sign In' : 'Verify OTP & Register'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              {/* Instant Assistance if Gmail is delayed */}
              <div className="pt-2 px-1 flex items-center justify-between text-[11px] border-t border-slate-800/60 mt-1">
                <span className="text-slate-400">Didn't receive email?</span>
                <button
                  type="button"
                  onClick={() => {
                    const codeToFill = activeOtp?.otp || '123456';
                    setOtp(codeToFill);
                    setSuccessMsg(`Code auto-filled: ${codeToFill}`);
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-semibold underline"
                >
                  Auto-fill Code ({activeOtp?.otp || '123456'})
                </button>
              </div>
            </form>
          )}

          {/* Privacy Note */}
          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[10px] text-slate-400 flex items-start gap-2 mt-2">
            <Lock className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              Real names and emails are never leaked on campus feeds. Cryptographic hash identity is maintained at all times.
            </span>
          </div>

          {/* Powered by saurabh chaudhary Watermark (Center Bottom) */}
          <div className="mt-3 text-center select-none">
            <p 
              style={{ fontFamily: '"Comic Sans MS", "Comic Sans", cursive, sans-serif' }}
              className="text-[11px] text-slate-500/70 tracking-wide font-normal inline-block"
            >
              Powered by saurabh chaudhary
            </p>
          </div>
        </div>
      </div>

      {/* Gmail SMTP Dispatch Setup Modal */}
      <GmailSmtpSetupModal
        isOpen={showSmtpModal}
        onClose={() => setShowSmtpModal(false)}
        defaultEmail={cleanEmail || 'brahmprakashsingh8@gmail.com'}
        onConfigSuccess={(userEmail) => {
          setSuccessMsg(`Gmail SMTP activated for ${userEmail}! OTPs will now be delivered live to Gmail.`);
        }}
      />
    </div>
  );
};

