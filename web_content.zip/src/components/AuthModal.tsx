/**
 * JARVIS Biometric & Voice Authentication Modal
 * WebAuthn Passkeys, Voice Pitch Baseline enrollment, Family/Friends delegation, and Audit Log.
 */

import React, { useState } from 'react';
import { 
  X, ShieldCheck, Fingerprint, Mic, UserCheck, 
  Users, Key, History, AlertTriangle, CheckCircle2 
} from 'lucide-react';
import { authService, UserProfile, SecurityEvent } from '../services/authService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthenticated?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuthenticated }) => {
  const [activeTab, setActiveTab] = useState<'biometrics' | 'users' | 'audit'>('biometrics');
  const [activeUser, setActiveUser] = useState<UserProfile>(() => authService.getActiveUser());
  const [allUsers, setAllUsers] = useState<UserProfile[]>(() => authService.getAllUsers());
  const [auditLogs, setAuditLogs] = useState<SecurityEvent[]>(() => authService.getAuditLogs());
  const [statusMessage, setStatusMessage] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  // New user form state
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'family' | 'friend' | 'guest'>('family');

  if (!isOpen) return null;

  const refresh = () => {
    setActiveUser(authService.getActiveUser());
    setAllUsers(authService.getAllUsers());
    setAuditLogs(authService.getAuditLogs());
  };

  const handleBiometricAuth = async () => {
    setIsVerifying(true);
    setStatusMessage('Querying device authenticator for biometric passkey...');
    const res = await authService.authenticateBiometric();
    setIsVerifying(false);
    setStatusMessage(res.message);
    refresh();
  };

  const handleEnrollPasskey = async () => {
    setIsVerifying(true);
    setStatusMessage('Enrolling hardware biometric credential on this device...');
    const res = await authService.registerBiometricPasskey();
    setIsVerifying(false);
    setStatusMessage(res.message);
    refresh();
  };

  const handleVoiceProfileTest = async () => {
    try {
      setIsVerifying(true);
      setStatusMessage('Listening to microphone for voice baseline frequency analysis...');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const result = await authService.verifyVoiceProfile(stream);
      stream.getTracks().forEach(t => t.stop());
      setIsVerifying(false);
      setStatusMessage(`Voice Pitch Match: ${result.pitchHz} Hz (${result.confidence}% Match to Owner Profile)`);
    } catch (e: any) {
      setIsVerifying(false);
      setStatusMessage('Microphone access denied or audio stream failed.');
    }
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) return;
    authService.addUser(newName.trim(), newEmail.trim(), newRole);
    setNewName('');
    setNewEmail('');
    setStatusMessage(`User ${newName} added with ${newRole.toUpperCase()} permissions.`);
    refresh();
  };

  const handleSwitchUser = (userId: string) => {
    authService.switchUser(userId);
    refresh();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl h-[85vh] bg-gray-950/95 border border-cyan-500/30 rounded-2xl flex flex-col overflow-hidden shadow-[0_0_50px_rgba(0,212,255,0.18)]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-gray-900/80 border-b border-cyan-500/20">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm sm:text-base font-bold font-mono tracking-wider text-cyan-300 uppercase">
                  Biometrics & Access Delegation
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-mono">
                  RBAC Level: {activeUser.role.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-gray-400">
                WebAuthn Passkeys, Owner Voiceprint Baseline & Multi-user permissions
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-gray-800/80 hover:bg-red-950/50 hover:text-red-400 text-gray-400 border border-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-gray-800 bg-gray-950/80 px-4 pt-2 space-x-2">
          <button
            onClick={() => setActiveTab('biometrics')}
            className={`pb-2 px-3 text-xs font-mono border-b-2 transition-all flex items-center space-x-1.5 ${
              activeTab === 'biometrics'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Fingerprint className="w-4 h-4" />
            <span>Biometric & Voice</span>
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`pb-2 px-3 text-xs font-mono border-b-2 transition-all flex items-center space-x-1.5 ${
              activeTab === 'users'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Family & Friend Delegation</span>
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`pb-2 px-3 text-xs font-mono border-b-2 transition-all flex items-center space-x-1.5 ${
              activeTab === 'audit'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Security Audit Log</span>
          </button>
        </div>

        {/* Status Toast */}
        {statusMessage && (
          <div className="bg-cyan-950/60 border-b border-cyan-500/30 px-4 py-2 text-xs text-cyan-300 font-mono flex items-center justify-between">
            <span>{statusMessage}</span>
            <button onClick={() => setStatusMessage('')} className="text-cyan-400 hover:text-cyan-200">
              ✕
            </button>
          </div>
        )}

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'biometrics' && (
            <div className="space-y-4">
              {/* Active Profile Card */}
              <div className="bg-gray-900/70 border border-cyan-500/30 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-cyan-200">{activeUser.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/50 text-cyan-400 font-mono">
                      {activeUser.email}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">
                    Passkey Enrolled: {activeUser.isEnrolledBiometric ? 'YES (Hardware Authenticator)' : 'NO (PIN Fallback)'}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleBiometricAuth}
                    disabled={isVerifying}
                    className="px-3.5 py-2 rounded-xl bg-cyan-500 text-gray-950 font-bold text-xs font-mono hover:bg-cyan-400 transition-all flex items-center space-x-1.5 shadow-lg"
                  >
                    <Fingerprint className="w-4 h-4" />
                    <span>Verify Biometrics</span>
                  </button>
                  <button
                    onClick={handleEnrollPasskey}
                    disabled={isVerifying}
                    className="px-3 py-2 rounded-xl bg-gray-800 text-cyan-300 font-mono text-xs hover:bg-gray-700 transition-colors border border-cyan-500/30"
                  >
                    <span>Enroll Passkey</span>
                  </button>
                </div>
              </div>

              {/* Voice Profile Baseline Card */}
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 font-bold">
                    <Mic className="w-4 h-4" />
                    <span>Owner Voice Baseline Frequency (110 Hz Pitch)</span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono">ENROLLED</span>
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  JARVIS matches acoustic vocal properties against Harmanjit Singh's enrolled pitch profile before granting voice control over sensitive actions.
                </p>
                <button
                  onClick={handleVoiceProfileTest}
                  disabled={isVerifying}
                  className="px-3 py-1.5 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-mono hover:bg-cyan-900/60 transition-colors flex items-center space-x-1.5"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>Test Voice Print Match Now</span>
                </button>
              </div>

              {/* Hardware Device Environment */}
              <div className="bg-gray-900/40 border border-gray-800/80 rounded-xl p-3 text-xs font-mono text-gray-400 space-y-1">
                <div>Device Target: <span className="text-cyan-300">Xiaomi Redmi 12 (4 GB RAM)</span></div>
                <div>WebAuthn API: <span className="text-emerald-400">{authService.isWebAuthnSupported() ? 'Supported' : 'Fallback Mode'}</span></div>
                <div>Storage Encryption: <span className="text-cyan-300">Local Sandbox AES-256 Verified</span></div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">Delegated User Profiles</span>
                {allUsers.map((u) => (
                  <div
                    key={u.id}
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      activeUser.id === u.id
                        ? 'bg-cyan-950/40 border-cyan-500/50'
                        : 'bg-gray-900/40 border-gray-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-gray-200">{u.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded font-mono uppercase bg-gray-800 text-cyan-400">
                          {u.role}
                        </span>
                      </div>
                      <span className="text-[11px] text-gray-400 font-mono">{u.email}</span>
                    </div>

                    <div className="flex items-center space-x-2">
                      {activeUser.id !== u.id && (
                        <button
                          onClick={() => handleSwitchUser(u.id)}
                          className="px-2.5 py-1 text-xs rounded bg-gray-800 text-cyan-300 hover:bg-gray-700 font-mono"
                        >
                          Switch
                        </button>
                      )}
                      {activeUser.id === u.id && (
                        <span className="text-xs font-mono text-emerald-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Active</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Add New User */}
              <form onSubmit={handleAddUser} className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 space-y-3">
                <span className="text-xs font-mono text-cyan-300 font-bold uppercase">Add Delegated User</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="User Name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="bg-gray-950 border border-gray-800 rounded-lg px-2.5 py-1.5 text-xs text-gray-200"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email Address"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="bg-gray-950 border border-gray-800 rounded-lg px-2.5 py-1.5 text-xs text-gray-200"
                  />
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as any)}
                    className="bg-gray-950 border border-gray-800 rounded-lg px-2.5 py-1.5 text-xs text-cyan-300 font-mono"
                  >
                    <option value="family">Family (Standard Access)</option>
                    <option value="friend">Friend (Limited Access)</option>
                    <option value="guest">Guest (Read Only)</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-cyan-500 text-gray-950 font-bold text-xs font-mono hover:bg-cyan-400"
                >
                  Authorize Profile
                </button>
              </form>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="space-y-2">
              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">Access Events</span>
              <div className="space-y-1.5">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-2.5 rounded-lg bg-gray-900/50 border border-gray-800/80 text-xs flex items-center justify-between font-mono"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-cyan-300 font-bold">{log.action}</span>
                        <span className="text-gray-400">by {log.user}</span>
                      </div>
                      <p className="text-[11px] text-gray-500">{log.details}</p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded ${
                          log.status === 'granted'
                            ? 'bg-emerald-950 text-emerald-400'
                            : 'bg-red-950 text-red-400'
                        }`}
                      >
                        {log.status.toUpperCase()}
                      </span>
                      <div className="text-[10px] text-gray-600 mt-1">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
