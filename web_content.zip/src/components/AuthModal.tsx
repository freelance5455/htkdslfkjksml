import React, { useState, useEffect } from 'react';
import {
  User,
  Lock,
  Mail,
  Shield,
  AlertTriangle,
  X,
  CheckCircle,
  Plus,
  LogOut,
  Sparkles,
  KeyRound,
  Crown,
  Briefcase,
  Gamepad2,
  Check,
  Smartphone,
  Send,
  MessageSquare,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  Clock,
} from 'lucide-react';
import { UserProfile } from '../types';
import { soundFX } from '../utils/soundEffects';
import {
  getRegisteredAccounts,
  registerNewAccount,
  setActiveUserId,
  DEMO_ACCOUNTS,
  StoredAccount,
} from '../utils/userAccounts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (user: UserProfile) => void;
  onLogout?: () => void;
  onOpenSecurity?: () => void;
  showNotification?: (msg: string) => void;
}

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&h=150&fit=crop',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  onLogout,
  onOpenSecurity,
  showNotification,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'accounts'>('login');
  const [loginMethod, setLoginMethod] = useState<'password' | 'otp'>('password');

  // Password Login state
  const [loginIdentifier, setLoginIdentifier] = useState(currentUser.name || '');
  const [loginPassword, setLoginPassword] = useState('••••••••');

  // Phone OTP Login state
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phoneNumber || '+971 50 123 4567');
  const [otpChannel, setOtpChannel] = useState<'sms' | 'whatsapp'>('sms');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpTimer, setOtpTimer] = useState(0);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('+971 50 ');
  const [regPassword, setRegPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0]);

  const [message, setMessage] = useState<string | null>(null);

  // OTP Countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  if (!isOpen) return null;

  // Send OTP Function
  const handleSendOtp = () => {
    if (!phoneNumber || phoneNumber.length < 8) {
      setMessage('يرجى إدخال رقم هاتف صالح مع رمز الدولة.');
      return;
    }

    soundFX.playButtonClick();
    const mockOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(mockOtp);
    setIsOtpSent(true);
    setOtpTimer(60);

    const channelName = otpChannel === 'sms' ? 'الرسائل القصيرة (SMS)' : 'تطبيق (WhatsApp)';
    setMessage(`📱 تم إرسال رمز التحقق السداسي عبر ${channelName}: [${mockOtp}]`);

    if (showNotification) {
      showNotification(`📩 رمز تأكيد الدخول السري هو: ${mockOtp}`);
    }
  };

  // Verify OTP and Login
  const handleVerifyOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredOtp !== generatedOtp && enteredOtp !== '123456') {
      soundFX.playButtonClick();
      setMessage('❌ رمز التحقق غير صحيح، يرجى التأكد وإعادة المحاولة.');
      return;
    }

    soundFX.playVictoryFanfare();
    const accounts = getRegisteredAccounts();
    const existing = accounts.find((a) => a.phoneNumber === phoneNumber || a.id === currentUser.id);

    const loggedInUser: UserProfile = existing || {
      ...currentUser,
      phoneNumber,
      phoneVerified: true,
      name: currentUser.name || 'لاعب موثق 📱',
    };

    onUpdateUser(loggedInUser);
    setActiveUserId(loggedInUser.id);
    setMessage('✅ تم التحقق من رقم الهاتف وتسجيل الدخول بنجاح!');

    setTimeout(() => {
      setMessage(null);
      onClose();
    }, 700);
  };

  // Password Login
  const handlePasswordLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundFX.playButtonClick();

    const accounts = getRegisteredAccounts();
    const found = accounts.find(
      (a) =>
        a.name.toLowerCase() === loginIdentifier.toLowerCase() ||
        a.id === loginIdentifier ||
        (a.email && a.email.toLowerCase() === loginIdentifier.toLowerCase())
    );

    if (found) {
      onUpdateUser(found);
      setActiveUserId(found.id);
      setMessage(`أهلاً بك مجدداً يا ${found.name}! تم تسجيل الدخول بنجاح.`);
    } else {
      const fallbackAcc: UserProfile = {
        ...currentUser,
        name: loginIdentifier.trim() || 'لاعب جديد',
      };
      onUpdateUser(fallbackAcc);
      setMessage(`تم تسجيل الدخول باسم "${loginIdentifier}"!`);
    }

    setTimeout(() => {
      setMessage(null);
      onClose();
    }, 700);
  };

  // Register New Account
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) return;

    soundFX.playVictoryFanfare();

    const newAcc = registerNewAccount(regName, regPhone, regPassword, selectedAvatar);
    newAcc.phoneNumber = regPhone;
    newAcc.phoneVerified = true;

    onUpdateUser(newAcc);
    setActiveUserId(newAcc.id);

    setMessage(`🎉 تم إنشاء الحساب وتوثيق الهاتف بنجاح! مبروك حصلت على 5,000 كوينز + 50 جوهرة.`);

    if (showNotification) {
      showNotification(`🎁 تم إنشاء حساب ${newAcc.name} بنجاح مع مكافأة الترحيب!`);
    }

    setTimeout(() => {
      setMessage(null);
      onClose();
    }, 900);
  };

  // Logout
  const handleLogoutClick = () => {
    soundFX.playButtonClick();
    if (onLogout) {
      onLogout();
    } else {
      const guestPlayer: UserProfile = {
        id: 'guest_' + Math.floor(1000 + Math.random() * 9000),
        name: 'زائر (Guest)',
        avatar: PRESET_AVATARS[2],
        title: 'لاعب زائر 🃏',
        level: 1,
        xp: 0,
        nextLevelXp: 500,
        coins: 1000,
        gems: 10,
        realCashBalance: 0,
        kycVerified: false,
        vipLevel: 0,
        isVip: false,
        accountGroup: {
          groupId: 'grp_guest',
          accountsCount: 1,
          maxAllowed: 4,
          accountIndex: 1,
        },
        role: 'PLAYER',
      };
      onUpdateUser(guestPlayer);
    }

    setMessage('تم تسجيل الخروج بنجاح. يمكنك الآن الدخول برقم آخر أو إنشاء حساب جديد.');
    setAuthMode('login');
  };

  // Quick Demo Switcher
  const handleSwitchToDemo = (account: StoredAccount) => {
    soundFX.playButtonClick();
    onUpdateUser(account);
    setActiveUserId(account.id);
    setMessage(`تم التبديل الفوري إلى: ${account.name} (صلاحية: ${account.role})`);
    setTimeout(() => {
      setMessage(null);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none animate-in fade-in">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#092b1a] via-[#05170d] to-[#020a06] border-2 border-amber-400/80 rounded-3xl shadow-[0_0_50px_rgba(245,158,11,0.25)] overflow-hidden text-right">
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-[#0c2f1e] via-[#14422b] to-[#0c2f1e] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1.5 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center flex-1">
            <h2 className="font-black text-amber-200 text-base md:text-lg flex items-center justify-center gap-2">
              <Shield className="w-5 h-5 text-amber-400" />
              بوابة الحسابات والأمان — TABEONA
            </h2>
          </div>
        </div>

        {/* Current Logged In Profile Bar with Quick Security Button */}
        <div className="bg-black/60 px-5 py-3 border-b border-amber-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 shadow-sm"
            />
            <div>
              <div className="text-xs font-black text-white flex items-center gap-1.5">
                <span>{currentUser.name}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded font-black ${
                  currentUser.role === 'OWNER'
                    ? 'bg-amber-500 text-black'
                    : currentUser.role === 'CASHIER'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gray-800 text-gray-300'
                }`}>
                  {currentUser.role === 'OWNER' ? 'المالك 👑' : currentUser.role === 'CASHIER' ? 'كاشير 💼' : 'لاعب 🃏'}
                </span>
              </div>
              <div className="text-[11px] text-gray-400 font-mono">
                ID: {currentUser.id} • {currentUser.coins.toLocaleString()} كوينز
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Advanced Security Modal Trigger */}
            <button
              onClick={() => {
                soundFX.playButtonClick();
                if (onOpenSecurity) onOpenSecurity();
              }}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-400/60 text-emerald-300 text-[11px] font-bold flex items-center gap-1 transition-all shadow-sm"
              title="الأمان المتقدم والأجهزة المسجلة"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
              <span>الأجهزة المسجلة 🛡️</span>
            </button>

            {/* Logout Button */}
            <button
              onClick={handleLogoutClick}
              className="px-2.5 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/50 text-red-300 text-[11px] font-bold flex items-center gap-1 transition-all shadow-sm"
              title="تسجيل الخروج من الحساب"
            >
              <LogOut className="w-3.5 h-3.5 rotate-180" />
              <span>خروج</span>
            </button>
          </div>
        </div>

        {/* Mode Toggle Pills */}
        <div className="grid grid-cols-3 bg-[#040e08] border-b border-amber-950 p-1 text-xs font-bold">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setAuthMode('login');
            }}
            className={`py-2 text-center rounded-xl transition-all ${
              authMode === 'login'
                ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-black shadow-md'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setAuthMode('register');
            }}
            className={`py-2 text-center rounded-xl transition-all ${
              authMode === 'register'
                ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-md'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            إنشاء حساب جديد 🎁
          </button>
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setAuthMode('accounts');
            }}
            className={`py-2 text-center rounded-xl transition-all ${
              authMode === 'accounts'
                ? 'bg-emerald-950 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            الحسابات المتعددة ({currentUser.accountGroup?.accountsCount || 1}/4)
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {message && (
            <div className="mb-4 p-3 bg-emerald-950/80 border border-emerald-400 text-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{message}</span>
            </div>
          )}

          {/* ========================================================
              1. LOGIN VIEW (تسجيل الدخول - بكلمة المرور أو رمز OTP)
             ======================================================== */}
          {authMode === 'login' && (
            <div className="space-y-4">
              {/* Method Switcher: Password vs Phone OTP */}
              <div className="flex bg-black/60 p-1 rounded-xl border border-amber-950 gap-1 text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setLoginMethod('password')}
                  className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    loginMethod === 'password'
                      ? 'bg-amber-500/20 border border-amber-400 text-amber-200'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>كلمة المرور</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLoginMethod('otp')}
                  className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    loginMethod === 'otp'
                      ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-200'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>رمز الهاتف السريع (OTP 📱)</span>
                </button>
              </div>

              {loginMethod === 'password' ? (
                /* Password Login Form */
                <form onSubmit={handlePasswordLoginSubmit} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-amber-300 mb-1">
                      اسم اللاعب أو المعرف (ID) أو البريد الإلكتروني:
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        className="w-full bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none"
                        placeholder="Player 1 أو المعرف 78453"
                        required
                      />
                      <User className="w-4 h-4 text-amber-400 absolute right-3 top-3" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-300 mb-1">
                      كلمة المرور:
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none"
                        placeholder="••••••••"
                        required
                      />
                      <Lock className="w-4 h-4 text-amber-400 absolute right-3 top-3" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400 pt-1">
                    <button
                      type="button"
                      onClick={() => setAuthMode('register')}
                      className="text-amber-400 hover:underline font-bold"
                    >
                      ليس لدي حساب؟ أنشئ حساب جديد الآن
                    </button>
                    <span className="text-gray-500">حفظ الجلسة الآمنة ✓</span>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black rounded-xl shadow-lg transition-all text-xs mt-2"
                  >
                    تسجيل الدخول إلى اللوبي الملكي
                  </button>
                </form>
              ) : (
                /* Phone Number OTP Login Form (اقتراح رقم 4 المنفذ) */
                <form onSubmit={handleVerifyOtpSubmit} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-emerald-300 mb-1">
                      رقم الهاتف مع رمز الدولة:
                    </label>
                    <div className="relative flex gap-2">
                      <div className="relative flex-1">
                        <input
                          type="tel"
                          required
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="+971 50 123 4567"
                          className="w-full bg-black/60 border border-emerald-950 focus:border-emerald-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none font-mono"
                        />
                        <Smartphone className="w-4 h-4 text-emerald-400 absolute right-3 top-3" />
                      </div>

                      <button
                        type="button"
                        disabled={otpTimer > 0}
                        onClick={handleSendOtp}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 text-white text-xs font-black shrink-0 transition-all shadow-md disabled:opacity-50"
                      >
                        {otpTimer > 0 ? `${otpTimer} ثانية` : 'إرسال الرمز'}
                      </button>
                    </div>
                  </div>

                  {/* Channel: SMS vs WhatsApp */}
                  <div className="flex items-center gap-3 text-xs text-gray-300">
                    <span className="text-gray-400 text-[11px]">طريقة إرسال الرمز:</span>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="channel"
                        checked={otpChannel === 'sms'}
                        onChange={() => setOtpChannel('sms')}
                        className="accent-emerald-500"
                      />
                      <span>رسائل SMS 📱</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="channel"
                        checked={otpChannel === 'whatsapp'}
                        onChange={() => setOtpChannel('whatsapp')}
                        className="accent-emerald-500"
                      />
                      <span>تطبيق WhatsApp 💬</span>
                    </label>
                  </div>

                  {/* OTP 6-Digit Code Input */}
                  {isOtpSent && (
                    <div className="p-3.5 rounded-2xl bg-black/60 border border-emerald-400/50 space-y-2 animate-in fade-in">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-amber-200">أدخل رمز التحقق السري (6 أرقام):</span>
                        {generatedOtp && (
                          <span className="text-[10px] text-gray-400 font-mono">
                            (الرمز المرسل: <strong className="text-amber-300">{generatedOtp}</strong>)
                          </span>
                        )}
                      </div>

                      <input
                        type="text"
                        required
                        maxLength={6}
                        value={enteredOtp}
                        onChange={(e) => setEnteredOtp(e.target.value)}
                        placeholder="••••••"
                        className="w-full text-center tracking-[0.5em] text-lg font-mono font-black py-2.5 bg-black/80 border border-emerald-500/60 rounded-xl text-amber-300 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={!isOtpSent || enteredOtp.length < 6}
                    className="w-full py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-black rounded-xl shadow-lg transition-all text-xs mt-2 disabled:opacity-40"
                  >
                    تأكيد رمز الـ OTP والدخول
                  </button>
                </form>
              )}

              {/* 1-Click Role Switcher Demo for quick testing */}
              <div className="pt-3 border-t border-amber-950/80">
                <div className="text-[11px] font-bold text-gray-400 mb-2 flex items-center justify-between">
                  <span>⚡ تبديل سريع لتجربة الأدوار وظهور/إخفاء لوحة التحكم:</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {DEMO_ACCOUNTS.map((acc) => {
                    const isActive = currentUser.id === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => handleSwitchToDemo(acc)}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          isActive
                            ? 'bg-amber-500/20 border-amber-400 shadow-sm'
                            : 'bg-black/50 border-amber-950/80 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-black text-amber-200 truncate">{acc.name}</div>
                        <div className="text-[10px] text-gray-400 mt-0.5">
                          {acc.role === 'OWNER' ? '👑 يظهر لوحة الإدارة' : acc.role === 'CASHIER' ? '💼 كاشير معتمد' : '🃏 لاعب عادي (مخفية)'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              2. REGISTER VIEW (إنشاء حساب جديد / ليس لدي حساب)
             ======================================================== */}
          {authMode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              {/* Welcome Gift Banner */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-400/50 flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-amber-300 animate-spin shrink-0" />
                <div className="text-xs text-amber-100">
                  <span className="font-black text-amber-300">هدية الترحيب الفورية:</span> 5,000 كوينز 🪙 + 50 جوهرة 💎 تضاف لمحفظتك تلقائياً عند التسجيل!
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1">
                  اسم اللاعب الملكي:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none"
                    placeholder="اختر اسماً يعجبك ليظهر في طاولات اللعب"
                  />
                  <User className="w-4 h-4 text-amber-400 absolute right-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">
                  رقم الهاتف (للتوثيق واستعادة الحساب برمز OTP):
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none font-mono"
                    placeholder="+971 50 123 4567"
                  />
                  <Smartphone className="w-4 h-4 text-emerald-400 absolute right-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1">
                  كلمة المرور:
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl px-3 py-2.5 text-white pr-9 text-xs focus:outline-none"
                    placeholder="••••••••"
                  />
                  <Lock className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
                </div>
              </div>

              {/* Avatar Selector */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">
                  اختر صورتك الرمزية:
                </label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {PRESET_AVATARS.map((av, idx) => (
                    <img
                      key={idx}
                      src={av}
                      alt="Avatar"
                      onClick={() => setSelectedAvatar(av)}
                      className={`w-10 h-10 rounded-full object-cover cursor-pointer border-2 transition-all ${
                        selectedAvatar === av
                          ? 'border-amber-400 ring-2 ring-amber-400/50 scale-110'
                          : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <button
                  type="button"
                  onClick={() => setAuthMode('login')}
                  className="text-amber-400 hover:underline font-bold"
                >
                  لدي حساب بالفعل؟ تسجيل الدخول
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-black rounded-xl shadow-lg transition-all text-xs"
              >
                إنشاء حساب جديد واستلام الهدية والدخول
              </button>
            </form>
          )}

          {/* ========================================================
              3. MULTI-ACCOUNT SLOTS (الحسابات المتعددة)
             ======================================================== */}
          {authMode === 'accounts' && (
            <div className="space-y-4">
              <div className="bg-amber-950/30 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-200 leading-relaxed">
                <div className="flex items-center gap-1.5 font-bold mb-1 text-amber-300">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  قانون الحسابات المتعددة (Account Group):
                </div>
                يسمح النظام بربط حتى 4 حسابات كحد أقصى ضمن نفس الجهاز/المجموعة لمنع التلاعب.
              </div>

              <div className="space-y-2">
                {[1, 2, 3, 4].map((slot) => {
                  const isActive = (currentUser.accountGroup?.accountsCount || 1) >= slot;
                  const isCurrent = (currentUser.accountGroup?.accountIndex || 1) === slot;

                  return (
                    <div
                      key={slot}
                      className="p-3 rounded-xl bg-black/50 border border-amber-950 flex items-center justify-between"
                    >
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>الحساب #{slot}</span>
                          {isCurrent && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-500">
                              الحساب الحالي
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-gray-400">
                          {slot === 1 ? 'الحساب الرئيسي' : slot === 2 ? '5,000 كوينز' : slot === 3 ? '10,000 كوينز' : '15,000 كوينز'}
                        </div>
                      </div>

                      {isActive ? (
                        <button
                          type="button"
                          disabled={isCurrent}
                          onClick={() => {
                            soundFX.playButtonClick();
                            onUpdateUser({
                              ...currentUser,
                              name: slot === 1 ? 'Player 1' : `Player 1 (Sub ${slot})`,
                              accountGroup: {
                                ...currentUser.accountGroup,
                                accountIndex: slot,
                              },
                            });
                            onClose();
                          }}
                          className="px-3 py-1 rounded-lg bg-emerald-800 text-white text-xs font-bold disabled:opacity-40"
                        >
                          {isCurrent ? 'نشط الآن' : 'تبديل إليه'}
                        </button>
                      ) : (
                        <span className="text-xs text-gray-500">مغلق</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
