import React, { useState } from 'react';
import { AuthUser } from '../types/game';
import { syncService } from '../services/firebaseSync';
import { X, LogIn, LogOut, ShieldCheck, Check, User, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  authUser: AuthUser | null;
  onAuthSuccess: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  authUser,
  onAuthSuccess,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      await syncService.signInWithGoogle();
      onAuthSuccess();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Google authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    setLoading(true);
    try {
      await syncService.signOut();
      onAuthSuccess();
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#0c0c0c] border border-[#262626] rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202020] bg-[#121212]">
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-white" />
            AUTHENTICATION
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {error && (
            <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-xl text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {authUser && !authUser.isGuest ? (
            /* Authenticated Account Profile */
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-[#141414] border border-[#262626] rounded-xl">
                {authUser.photoURL ? (
                  <img
                    src={authUser.photoURL}
                    alt={authUser.displayName || 'User'}
                    className="w-14 h-14 rounded-full border border-neutral-700 object-cover"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center text-white">
                    <User className="w-6 h-6" />
                  </div>
                )}
                <div>
                  <h3 className="text-base font-bold text-white">
                    {authUser.displayName || 'Google User'}
                  </h3>
                  <p className="text-xs text-neutral-400">{authUser.email}</p>
                  <p className="text-[10px] font-mono text-neutral-500 mt-1 truncate max-w-[200px]">
                    UID: {authUser.uid}
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-[#121212] border border-[#222222] rounded-xl text-xs space-y-2 text-neutral-300">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-4 h-4" />
                  <span>Cloud Synchronization Active</span>
                </div>
                <p className="text-neutral-400 text-[11px] leading-relaxed">
                  Your puzzle progress, stars, best completion times, and settings are securely backed up to Firestore under <code className="text-neutral-300">users/{authUser.uid}/progress/main</code>.
                </p>
              </div>

              <button
                onClick={handleSignOut}
                disabled={loading}
                className="w-full py-3 bg-[#181818] hover:bg-[#222222] border border-[#333333] text-white font-medium rounded-xl text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out of Google Account</span>
              </button>
            </div>
          ) : (
            /* Guest / Sign-In View */
            <div className="space-y-5">
              <div className="text-center space-y-1.5">
                <h3 className="text-base font-bold text-white">
                  Continue with Google
                </h3>
                <p className="text-xs text-neutral-400 leading-relaxed max-w-xs mx-auto">
                  Seamlessly sync your unlocked levels and star ratings between Android and Web browsers.
                </p>
              </div>

              {/* Google Sign In Button */}
              <button
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full py-3.5 px-4 bg-white hover:bg-neutral-200 text-black font-bold rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-3 active:scale-[0.99] cursor-pointer"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{loading ? 'Authenticating...' : 'Continue with Google'}</span>
              </button>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-[#222222]"></div>
                <span className="flex-shrink mx-3 text-[10px] font-mono text-neutral-500 uppercase">
                  or stay offline
                </span>
                <div className="flex-grow border-t border-[#222222]"></div>
              </div>

              <div className="p-3.5 bg-[#141414] border border-[#242424] rounded-xl text-xs space-y-1 text-neutral-400">
                <div className="font-semibold text-white">Guest Mode Active</div>
                <p className="text-[11px]">
                  You can play offline without signing in. When you decide to log in later, your offline guest progress will automatically merge into your Google cloud profile without losing anything.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
