import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, showToast, setCurrentTab } = useApp();

  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [loginMode, setLoginMode] = useState<'otp' | 'uid'>('otp');

  // Form states
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpTimer, setOtpTimer] = useState(0);

  const [loginUid, setLoginUid] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Register form
  const [regIgn, setRegIgn] = useState('');
  const [regUid, setRegUid] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regReferral, setRegReferral] = useState('');
  const [regPass1, setRegPass1] = useState('');
  const [regPass2, setRegPass2] = useState('');

  // Scrim countdown
  const [scrimTime, setScrimTime] = useState(8 * 60 + 21);

  useEffect(() => {
    const timer = setInterval(() => {
      setScrimTime((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpTimer > 0) {
      timer = setInterval(() => {
        setOtpTimer((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [otpTimer]);

  if (!isAuthModalOpen) return null;

  const handleRequestOtp = () => {
    if (!phone) {
      showToast('Enter your registered mobile number first.', 'error');
      return;
    }
    setOtpTimer(45);
    setOtp('849204');
    showToast('6-digit authorization code dispatched to phone: 849204', 'info');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthModalOpen(false);
    showToast('Login Approved! Entering arena hub. Loading squad stats...', 'success');
    setCurrentTab('match-room');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (regPass1 !== regPass2) {
      showToast('Passwords do not match.', 'error');
      return;
    }
    setIsAuthModalOpen(false);
    showToast('Athlete Registered! 10 Free Coins credited. Welcome, Soldier!', 'success');
    setCurrentTab('player-profile');
  };

  const formatScrimTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b0e14]/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#10131a] border border-primary-container/30 rounded-xl p-6 sm:p-8 shadow-2xl my-8">
        {/* Close Button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 right-4 text-on-surface-variant hover:text-on-surface transition-colors p-2 rounded bg-surface-container cursor-pointer z-10"
        >
          <span className="material-symbols-outlined text-2xl">close</span>
        </button>

        {/* Header Telemetry */}
        <div className="mb-6 flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-surface-container-high rounded text-[#00dbe9] font-label text-[11px] uppercase tracking-widest font-bold">
                <span className="h-2 w-2 rounded-full bg-[#00dbe9] animate-pulse"></span>
                Secure Auth Terminal • v3.8.4
              </span>
              <span className="hidden sm:inline text-on-surface-variant font-label text-xs tracking-wider uppercase">
                • Garena Server Sync Active
              </span>
            </div>
            <h1 className="font-headline font-bold text-2xl sm:text-4xl uppercase tracking-tight text-on-surface">
              Command Center <span className="text-primary-container">Access</span>
            </h1>
            <p className="font-body text-sm text-on-surface-variant mt-1 max-w-xl">
              Authenticate your Free Fire UID to access custom room codes, compete in verified cash lobbies, and initiate instant tournament prize withdrawals.
            </p>
          </div>
          <div className="flex items-center gap-3 bg-surface-container-high/80 px-4 py-2.5 rounded backdrop-blur shadow-md">
            <div className="flex flex-col text-right">
              <span className="font-label text-xs uppercase text-on-surface-variant font-bold">
                Active Registered Athletes
              </span>
              <span className="font-headline font-bold text-lg text-secondary-container">24,892 verified</span>
            </div>
            <div className="h-8 w-8 rounded bg-surface-container flex items-center justify-center text-primary-container">
              <span className="material-symbols-outlined text-xl">military_tech</span>
            </div>
          </div>
        </div>

        {/* 2-Column Auth Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT: Auth Forms (7 cols) */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="bg-[#191c22] rounded-lg p-5 sm:p-7 shadow-xl relative">
              {/* Tab Selector */}
              <div className="flex items-center justify-between pb-5">
                <div className="inline-flex p-1 bg-[#0b0e14] rounded-md">
                  <button
                    onClick={() => setAuthTab('login')}
                    className={`px-5 py-2 font-label text-xs sm:text-sm uppercase tracking-wider font-bold rounded transition-all duration-200 cursor-pointer ${
                      authTab === 'login'
                        ? 'bg-[#ff5e00] text-[#531900] shadow-[0_0_15px_rgba(255,94,0,0.45)]'
                        : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-base">login</span>
                      Player Login
                    </span>
                  </button>
                  <button
                    onClick={() => setAuthTab('register')}
                    className={`px-5 py-2 font-label text-xs sm:text-sm uppercase tracking-wider font-bold rounded transition-all duration-200 cursor-pointer ${
                      authTab === 'register'
                        ? 'bg-[#ff5e00] text-[#531900] shadow-[0_0_15px_rgba(255,94,0,0.45)]'
                        : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-base">person_add</span>
                      Create Athlete Account
                    </span>
                  </button>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-on-surface-variant font-label text-xs uppercase font-bold">
                  <span className="h-2 w-2 rounded-full bg-[#00dbe9]"></span>
                  <span>Latency: <strong className="text-[#00dbe9]">14ms</strong></span>
                </div>
              </div>

              {/* LOGIN PANEL */}
              {authTab === 'login' && (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-2 p-1 bg-[#0b0e14] rounded text-xs font-label uppercase">
                    <button
                      onClick={() => setLoginMode('otp')}
                      className={`flex-1 py-1.5 text-center font-bold rounded cursor-pointer ${
                        loginMode === 'otp'
                          ? 'bg-surface-container-high text-primary-container'
                          : 'text-on-surface-variant hover:text-on-surface'
                      }`}
                    >
                      Quick Mobile OTP
                    </button>
                    <button
                      onClick={() => setLoginMode('uid')}
                      className={`flex-1 py-1.5 text-center font-bold rounded cursor-pointer ${
                        loginMode === 'uid'
                          ? 'bg-surface-container-high text-primary-container'
                          : 'text-on-surface-variant hover:text-on-surface'
                      }`}
                    >
                      UID + Passcode
                    </button>
                  </div>

                  {loginMode === 'otp' ? (
                    <form onSubmit={handleLoginSubmit} className="flex flex-col gap-4">
                      <div className="flex flex-col gap-1.5">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold flex items-center justify-between">
                          <span>Registered Phone Number</span>
                          <span className="text-[#00dbe9] text-[11px] lowercase">for automatic SMS sync</span>
                        </label>
                        <div className="flex rounded overflow-hidden bg-[#0b0e14]">
                          <div className="px-3.5 py-3 bg-surface-container flex items-center gap-1.5 text-on-surface font-label text-xs font-bold">
                            <span>🇮🇳 +91</span>
                          </div>
                          <input
                            type="tel"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            placeholder="98765 43210"
                            required
                            className="w-full bg-transparent px-3.5 py-3 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                          />
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between">
                          <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                            6-Digit Security OTP
                          </label>
                          <button
                            type="button"
                            onClick={handleRequestOtp}
                            disabled={otpTimer > 0}
                            className="font-label text-xs uppercase font-bold text-primary hover:text-primary-container transition-colors cursor-pointer disabled:opacity-50"
                          >
                            {otpTimer > 0 ? `Resend in ${otpTimer}s` : 'Request OTP Code'}
                          </button>
                        </div>
                        <input
                          type="text"
                          maxLength={6}
                          value={otp}
                          onChange={(e) => setOtp(e.target.value)}
                          placeholder="• • • • • •"
                          className="w-full tracking-[0.5em] text-center font-headline text-lg font-bold bg-[#0b0e14] rounded px-4 py-2.5 text-on-surface placeholder:text-surface-bright focus:outline-none"
                        />
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <label className="flex items-center gap-2 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            defaultChecked
                            className="accent-primary-container h-4 w-4 rounded bg-[#0b0e14]"
                          />
                          <span className="font-body text-xs text-on-surface-variant">Remember this gaming rig</span>
                        </label>
                        <a href="#forgot" className="font-label text-xs uppercase text-tertiary hover:underline font-bold">
                          Forgot Credentials?
                        </a>
                      </div>

                      <button
                        type="submit"
                        className="mt-2 w-full py-3.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline font-bold text-sm uppercase tracking-wider rounded transition-all duration-150 shadow-[0_0_20px_rgba(255,94,0,0.35)] flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-lg">swords</span>
                        Enter Battle Arena (Login)
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleLoginSubmit} className="flex flex-col gap-4">
                      <div className="flex flex-col gap-1.5">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          Free Fire Official UID
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            value={loginUid}
                            onChange={(e) => setLoginUid(e.target.value)}
                            placeholder="e.g. 84920412"
                            required
                            className="w-full bg-[#0b0e14] rounded px-3.5 py-3 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body pl-10"
                          />
                          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-surface-bright text-lg">
                            badge
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between">
                          <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                            Account Passcode / PIN
                          </label>
                        </div>
                        <div className="relative">
                          <input
                            type={showPassword ? 'text' : 'password'}
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            placeholder="••••••••••••"
                            required
                            className="w-full bg-[#0b0e14] rounded px-3.5 py-3 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body pl-10"
                          />
                          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-surface-bright text-lg">
                            lock
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-lg">
                              {showPassword ? 'visibility_off' : 'visibility'}
                            </span>
                          </button>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="mt-2 w-full py-3.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline font-bold text-sm uppercase tracking-wider rounded transition-all duration-150 shadow-[0_0_20px_rgba(255,94,0,0.35)] flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-lg">sports_esports</span>
                        Authorize Credentials &amp; Enter
                      </button>
                    </form>
                  )}

                  {/* Gamer Social Connect */}
                  <div className="pt-2">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-[1px] flex-1 bg-surface-container-highest"></div>
                      <span className="font-label text-[11px] uppercase tracking-widest text-on-surface-variant font-bold">
                        Instant Scrim Sign-In
                      </span>
                      <div className="h-[1px] flex-1 bg-surface-container-highest"></div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAuthModalOpen(false);
                          showToast('Discord Scrims authentication handshake successful.', 'info');
                          setCurrentTab('match-room');
                        }}
                        className="py-2.5 px-3 rounded bg-surface-container hover:bg-surface-container-high transition-colors flex items-center justify-center gap-2 text-xs font-label uppercase font-bold text-on-surface shadow-sm cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base text-tertiary">forum</span>
                        <span>Discord Scrims</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsAuthModalOpen(false);
                          showToast('Google Play Games verified account link successful.', 'info');
                          setCurrentTab('match-room');
                        }}
                        className="py-2.5 px-3 rounded bg-surface-container hover:bg-surface-container-high transition-colors flex items-center justify-center gap-2 text-xs font-label uppercase font-bold text-on-surface shadow-sm cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-base text-secondary-container">sports_esports</span>
                        <span>Google Play ID</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* REGISTER PANEL */}
              {authTab === 'register' && (
                <div className="flex flex-col gap-4">
                  <div className="bg-surface-container-highest/60 p-3 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-secondary-container text-xl">stars</span>
                      <div className="flex flex-col">
                        <span className="font-label text-xs uppercase font-bold text-on-surface">
                          Welcome Athlete Bonus
                        </span>
                        <span className="font-body text-[11px] text-on-surface-variant">
                          Claim 10 Free Esports Coins on verified sign-up
                        </span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-secondary-container/20 text-secondary-container font-label text-xs font-bold uppercase">
                      10 🪙 FREE
                    </span>
                  </div>

                  <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          In-Game Name (IGN)
                        </label>
                        <input
                          type="text"
                          value={regIgn}
                          onChange={(e) => setRegIgn(e.target.value)}
                          placeholder="e.g. ALPHA_V7"
                          required
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold flex justify-between">
                          <span>Free Fire UID</span>
                          <span className="text-[10px] text-[#00dbe9]">Lvl 40+ Required</span>
                        </label>
                        <input
                          type="text"
                          value={regUid}
                          onChange={(e) => setRegUid(e.target.value)}
                          placeholder="e.g. 84920412"
                          required
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          Mobile (UPI &amp; Pass)
                        </label>
                        <input
                          type="tel"
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="+91 98765 00000"
                          required
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          Referral Code
                        </label>
                        <input
                          type="text"
                          value={regReferral}
                          onChange={(e) => setRegReferral(e.target.value)}
                          placeholder="BOOYAH2025"
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface uppercase placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          Set Password
                        </label>
                        <input
                          type="password"
                          value={regPass1}
                          onChange={(e) => setRegPass1(e.target.value)}
                          placeholder="••••••••••••"
                          required
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-label text-xs uppercase tracking-wider text-on-surface-variant font-bold">
                          Confirm Password
                        </label>
                        <input
                          type="password"
                          value={regPass2}
                          onChange={(e) => setRegPass2(e.target.value)}
                          placeholder="••••••••••••"
                          required
                          className="w-full bg-[#0b0e14] rounded px-3.5 py-2 text-sm text-on-surface placeholder:text-surface-bright focus:outline-none font-body"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="mt-2 w-full py-3.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline font-bold text-sm uppercase tracking-wider rounded transition-all duration-150 shadow-[0_0_20px_rgba(255,94,0,0.35)] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-lg">stars</span>
                      Create Account &amp; Claim 10 Bonus Coins
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT: Live Arena Drops & Protocols (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="bg-[#191c22] rounded-lg p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between pb-3">
                <span className="font-label text-xs uppercase tracking-wider font-bold text-primary flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-primary-container animate-ping"></span>
                  Next Custom Room Drops In
                </span>
                <span className="font-headline font-bold text-sm text-secondary">₹15,000 PRIZE POOL</span>
              </div>
              <div className="flex items-center justify-between bg-[#0b0e14] p-3 rounded mb-3">
                <div className="flex flex-col">
                  <span className="font-headline font-bold text-sm text-on-surface">BERMUDA SQUAD CLASH #114</span>
                  <span className="font-body text-xs text-on-surface-variant">
                    Slots: 44/48 Filled • Map: Bermuda Remastered
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-headline text-lg font-bold text-[#00dbe9]">
                    {formatScrimTimer(scrimTime)}
                  </span>
                  <span className="block font-label text-[10px] uppercase text-on-surface-variant font-bold">
                    MINUTES
                  </span>
                </div>
              </div>
              <p className="font-body text-xs text-on-surface-variant leading-relaxed">
                Login is required to reveal the private Free Fire Room ID and Password 15 minutes before the plane path launches.
              </p>
            </div>

            {/* Protocols */}
            <div className="bg-[#191c22] rounded-lg p-5 shadow-lg flex flex-col gap-3.5">
              <h3 className="font-headline font-bold text-sm uppercase tracking-wider text-on-surface flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00dbe9] text-lg">shield</span>
                Competitive Integrity Protocols
              </h3>
              <div className="flex items-start gap-3 p-2.5 rounded bg-[#0b0e14]">
                <div className="p-2 rounded bg-surface-container text-[#00dbe9]">
                  <span className="material-symbols-outlined text-lg">security_update_good</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label text-xs uppercase font-bold text-on-surface">
                    Anti-Cheat Guard V3.8 Binding
                  </span>
                  <span className="font-body text-xs text-on-surface-variant">
                    Automated UID spectate validation filters modded APKs, emulator macros, and unauthorized headshot configs.
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-2.5 rounded bg-[#0b0e14]">
                <div className="p-2 rounded bg-surface-container text-secondary">
                  <span className="material-symbols-outlined text-lg">account_balance_wallet</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label text-xs uppercase font-bold text-on-surface">
                    Instant UPI &amp; Bank Escrow
                  </span>
                  <span className="font-body text-xs text-on-surface-variant">
                    Match rewards settled within 120 seconds post-Booyah screenshot sync directly to PhonePe, Paytm, or GPay.
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-2.5 rounded bg-[#0b0e14]">
                <div className="p-2 rounded bg-surface-container text-primary">
                  <span className="material-symbols-outlined text-lg">gavel</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label text-xs uppercase font-bold text-on-surface">
                    Live Arbiter &amp; Protest Deck
                  </span>
                  <span className="font-body text-xs text-on-surface-variant">
                    24/7 human arbiters review disputed kill points, teaming allegations, and slot theft tickets.
                  </span>
                </div>
              </div>
            </div>

            {/* Badges */}
            <div className="p-3 bg-surface-container rounded-lg flex items-center justify-between text-on-surface-variant font-label text-[11px] uppercase tracking-wider font-bold">
              <span className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-[#00dbe9]">verified</span>
                SSL 256-Bit Crypt
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-secondary">bolt</span>
                Fast Payout Sync
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-primary">sports</span>
                Ranked Scrims
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
