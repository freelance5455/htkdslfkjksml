import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mail,
  Lock,
  User as UserIcon,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  ArrowLeft,
  KeyRound,
  ExternalLink,
  ShieldCheck,
  UserPlus,
  LogIn
} from 'lucide-react';
import {
  signInUserWithGoogle,
  loginWithEmailPassword,
  sendUserPasswordReset,
  startEmailOtpRegistration,
  verifyEmailOtpAndRegister,
  resendEmailOtpCode
} from '../lib/firebase';
import { User } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
  initialTab?: 'signin' | 'register' | 'forgot';
  messagePrompt?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
  initialTab = 'signin',
  messagePrompt
}) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'register' | 'forgot'>(initialTab);

  // Sync tab with initialTab whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      resetForm();
    }
  }, [isOpen, initialTab]);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // OTP Verification State
  const [registerStep, setRegisterStep] = useState<'form' | 'otp'>('form');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [challengeId, setChallengeId] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState<number>(0);
  const [missingConfigNotice, setMissingConfigNotice] = useState<string | null>(null);
  const [attemptsRemaining, setAttemptsRemaining] = useState<number | null>(null);

  // Common UI State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Refs for 6-digit OTP input boxes
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Cooldown countdown timer for OTP resend
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setInterval(() => {
      setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Clean form reset - cleanses passwords, OTPs, and timers from memory
  const resetForm = (keepCredentials = false) => {
    if (!keepCredentials) {
      setName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
    }
    setOtpDigits(['', '', '', '', '', '']);
    setRegisterStep('form');
    setChallengeId(null);
    setResendCooldown(0);
    setMissingConfigNotice(null);
    setAttemptsRemaining(null);
    setError(null);
    setSuccessMessage(null);
  };

  const handleModalClose = () => {
    resetForm(false);
    onClose();
  };

  const handleTabSwitch = (tab: 'signin' | 'register' | 'forgot') => {
    resetForm(true);
    setActiveTab(tab);
  };

  if (!isOpen) return null;

  // Google Sign-In Flow
  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      const user = await signInUserWithGoogle();
      resetForm();
      onAuthSuccess(user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Google Sign-In failed.');
    } finally {
      setLoading(false);
    }
  };

  // Step 1: Submit Registration Form to start 6-Digit Email OTP verification
  const handleRegisterStart = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const cleanName = name.trim();
      const cleanEmail = email.trim().toLowerCase();

      if (!cleanName) {
        throw new Error('Please enter your full name or username.');
      }
      if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
        throw new Error('Please enter a valid email address.');
      }
      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters long.');
      }
      if (password !== confirmPassword) {
        throw new Error('Passwords do not match. Please verify your confirm password.');
      }

      // Request server to initiate cryptographically secure OTP challenge
      const result = await startEmailOtpRegistration(cleanName, cleanEmail);

      setChallengeId(result.challengeId || null);
      setResendCooldown(result.resendCooldownSeconds || 60);
      if (result.missingConfig && result.missingConfig.length > 0) {
        setMissingConfigNotice(result.missingConfig.join(' '));
      } else {
        setMissingConfigNotice(null);
      }

      setRegisterStep('otp');
      setSuccessMessage(`We've sent a 6-digit verification code to ${cleanEmail}.`);

      // Focus first OTP input
      setTimeout(() => {
        otpInputRefs.current[0]?.focus();
      }, 100);
    } catch (err: any) {
      let msg = err.message || 'Failed to start registration.';
      if (err.code === 'auth/email-already-in-use') {
        msg = 'This email address is already registered. Please sign in instead.';
      }
      setError(msg);
      if (err.missingConfig && err.missingConfig.length > 0) {
        setMissingConfigNotice(err.missingConfig.join(' '));
      }
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Verify OTP code and complete user account creation
  const handleOtpVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const fullOtp = otpDigits.join('').trim();
    if (fullOtp.length !== 6 || !/^\d{6}$/.test(fullOtp)) {
      setError('Please enter the complete 6-digit verification code.');
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      // Submits password ONLY now upon OTP verification
      const user = await verifyEmailOtpAndRegister(
        challengeId || undefined,
        email.trim().toLowerCase(),
        fullOtp,
        password,
        name.trim()
      );

      setSuccessMessage('Email verified successfully! Account created.');

      // Clear password & OTP from state immediately
      setPassword('');
      setConfirmPassword('');
      setOtpDigits(['', '', '', '', '', '']);

      setTimeout(() => {
        resetForm();
        onAuthSuccess(user);
        onClose();
      }, 1000);
    } catch (err: any) {
      if (typeof err.attemptsRemaining === 'number') {
        setAttemptsRemaining(err.attemptsRemaining);
      }
      setError(err.message || 'Invalid verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Step 3: Resend OTP Code
  const handleResendOtp = async () => {
    if (resendCooldown > 0 || loading) return;

    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const result = await resendEmailOtpCode(challengeId || undefined, email);
      setChallengeId(result.challengeId || challengeId);
      setResendCooldown(result.resendCooldownSeconds || 60);
      setOtpDigits(['', '', '', '', '', '']);
      setAttemptsRemaining(null);
      setSuccessMessage(`A fresh 6-digit code has been sent to ${email}.`);
      setTimeout(() => {
        otpInputRefs.current[0]?.focus();
      }, 100);
    } catch (err: any) {
      setError(err.message || 'Failed to resend code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle digit typing & auto-advance
  const handleOtpDigitChange = (index: number, val: string) => {
    // Take only numbers
    const cleaned = val.replace(/\D/g, '');
    if (!cleaned) {
      const updated = [...otpDigits];
      updated[index] = '';
      setOtpDigits(updated);
      return;
    }

    // Handle single digit input
    const single = cleaned.slice(-1);
    const updated = [...otpDigits];
    updated[index] = single;
    setOtpDigits(updated);

    // Auto-advance to next input box
    if (index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  // Handle paste of 6-digit code
  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pasted) return;

    const updated = [...otpDigits];
    for (let i = 0; i < 6; i++) {
      updated[i] = pasted[i] || '';
    }
    setOtpDigits(updated);

    const nextIndex = Math.min(pasted.length, 5);
    otpInputRefs.current[nextIndex]?.focus();
  };

  // Handle backspace navigation between boxes
  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  // Sign In / Forgot Password Submit
  const handleSignInOrForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      if (activeTab === 'signin') {
        if (!email.trim() || !password) {
          throw new Error('Please provide both email and password.');
        }

        const user = await loginWithEmailPassword(email, password);
        resetForm();
        onAuthSuccess(user);
        onClose();
      } else if (activeTab === 'forgot') {
        if (!email.trim() || !email.includes('@')) {
          throw new Error('Please enter the email address linked to your account.');
        }

        await sendUserPasswordReset(email);
        setSuccessMessage(
          'Password reset link has been sent to your email! Follow the instructions in the email to set a new password.'
        );
      }
    } catch (err: any) {
      let msg = err.message || 'Authentication error.';
      if (err.code === 'auth/unverified-email') {
        // Handle unverified user gracefully: offer OTP verification
        msg = 'Your email address is not yet verified. Please enter your name and click register to verify with a 6-digit code.';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'No account found with this email. Please register first.';
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Incorrect email or password. If you signed in with Google, please use the Google button.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please sign in instead.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'Please enter a valid email address.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4">
      <div
        id="modal-citizen-auth"
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-200 max-h-[95vh] overflow-y-auto"
      >
        {/* Header with Official Logo */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/india-job-hub-logo.png"
              alt="India Job Hub Logo"
              width={64}
              height={64}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-contain bg-white p-1 border border-slate-700/70 shadow-lg shrink-0 select-none"
              referrerPolicy="no-referrer"
            />
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>
                  {activeTab === 'signin' && 'Sign In to India Job Hub'}
                  {activeTab === 'register' &&
                    (registerStep === 'otp' ? 'Verify Your Email' : 'Create Aspirant Account')}
                  {activeTab === 'forgot' && 'Reset Your Password'}
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {activeTab === 'register' && registerStep === 'otp'
                  ? 'Enter the 6-digit code sent to your email'
                  : messagePrompt || 'Save jobs, get personalized alerts, and interact with aspirants'}
              </p>
            </div>
          </div>
          <button
            onClick={handleModalClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Tab Switcher: Sign In vs Register with Email OTP */}
        {registerStep !== 'otp' && (
          <div className="grid grid-cols-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800">
            <button
              id="tab-btn-signin"
              type="button"
              onClick={() => handleTabSwitch('signin')}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'signin'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
            <button
              id="tab-btn-register"
              type="button"
              onClick={() => handleTabSwitch('register')}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'register'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Register (Email OTP)</span>
            </button>
          </div>
        )}

        {/* Google Sign-In Primary Button (Only shown on Sign In and registration form step) */}
        {activeTab !== 'forgot' && registerStep !== 'otp' && (
          <div>
            <button
              id="btn-auth-google"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs flex items-center justify-center gap-3 transition-all shadow-sm active:scale-[0.98] disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="relative my-3 text-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-800" />
              </div>
              <span className="relative px-3 bg-slate-900 text-[11px] font-medium text-slate-500 uppercase tracking-wider">
                {activeTab === 'register' ? 'or register with email verification' : 'or sign in with email'}
              </span>
            </div>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <div className="space-y-1.5 flex-1">
              <span>{error}</span>
              {typeof attemptsRemaining === 'number' && attemptsRemaining > 0 && (
                <div className="text-[11px] text-rose-400 font-semibold">
                  Remaining attempts: {attemptsRemaining} / 5
                </div>
              )}
              {activeTab === 'signin' && (error.toLowerCase().includes('register') || error.toLowerCase().includes('no account') || error.toLowerCase().includes('invalid credential')) && (
                <button
                  type="button"
                  onClick={() => handleTabSwitch('register')}
                  className="block text-[11px] text-indigo-400 hover:text-indigo-300 font-bold underline transition-colors"
                >
                  Switch to Register (Email OTP) →
                </button>
              )}
              {activeTab === 'register' && (error.toLowerCase().includes('already registered') || error.toLowerCase().includes('already in use')) && (
                <button
                  type="button"
                  onClick={() => handleTabSwitch('signin')}
                  className="block text-[11px] text-indigo-400 hover:text-indigo-300 font-bold underline transition-colors"
                >
                  Switch to Sign In →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Success message */}
        {successMessage && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-start gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span>{successMessage}</span>
          </div>
        )}


        {missingConfigNotice && (
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-[11px]">
            {missingConfigNotice}
          </div>
        )}

        {/* ========================================================================= */}
        {/* OTP VERIFICATION VIEW (Step 2 of Registration) */}
        {/* ========================================================================= */}
        {activeTab === 'register' && registerStep === 'otp' ? (
          <div className="space-y-4">
            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-[11px] text-slate-400">Verifying address</span>
                <p className="text-xs font-bold text-white truncate max-w-[220px]">{email}</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setRegisterStep('form');
                  setError(null);
                  setSuccessMessage(null);
                }}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 transition-colors"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Edit email</span>
              </button>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-2 text-center">
                Enter 6-Digit Verification Code
              </label>

              {/* 6 Digit Inputs */}
              <div className="flex justify-center gap-2 sm:gap-2.5">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => {
                      otpInputRefs.current[idx] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                    onPaste={handleOtpPaste}
                    className="w-10 h-12 sm:w-12 sm:h-14 text-center font-mono font-bold text-lg sm:text-xl text-white bg-slate-800/90 border border-slate-700 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40 focus:outline-none transition-all shadow-inner"
                    placeholder="•"
                  />
                ))}
              </div>
              <p className="text-[11px] text-slate-500 text-center mt-2">
                Code expires in 10 minutes. Max 5 verification attempts.
              </p>
            </div>

            {/* Verify Button */}
            <button
              id="btn-verify-otp"
              type="button"
              onClick={() => handleOtpVerify()}
              disabled={loading || otpDigits.join('').length !== 6}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{loading ? 'Verifying Code & Creating Account...' : 'Verify OTP & Create Account'}</span>
            </button>

            {/* Resend OTP Row */}
            <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
              <span className="text-slate-400">Didn't receive the email?</span>
              <button
                id="btn-resend-otp"
                type="button"
                onClick={handleResendOtp}
                disabled={resendCooldown > 0 || loading}
                className="text-indigo-400 hover:text-indigo-300 font-bold disabled:text-slate-600 disabled:cursor-not-allowed flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
                <span>
                  {resendCooldown > 0 ? `Resend Code in ${resendCooldown}s` : 'Resend Code'}
                </span>
              </button>
            </div>
          </div>
        ) : (
          /* ========================================================================= */
          /* REGISTRATION / SIGN IN / FORGOT PASSWORD FORM */
          /* ========================================================================= */
          <form
            onSubmit={activeTab === 'register' ? handleRegisterStart : handleSignInOrForgot}
            className="space-y-3"
          >
            {activeTab === 'register' && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Full Name / Username
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="input-auth-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="input-auth-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                />
              </div>
            </div>

            {activeTab !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-semibold text-slate-400">Password</label>
                  {activeTab === 'signin' && (
                    <button
                      type="button"
                      onClick={() => handleTabSwitch('forgot')}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="input-auth-password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>
            )}

            {/* Confirm Password field for Registration */}
            {activeTab === 'register' && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="input-auth-confirm-password"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter your password"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-[10px] text-rose-400 mt-1">Passwords do not match</p>
                )}
              </div>
            )}

            <button
              id="btn-auth-submit"
              type="submit"
              disabled={
                loading ||
                (activeTab === 'register' &&
                  (!name.trim() || !email.trim() || password.length < 6 || password !== confirmPassword))
              }
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-50 mt-2"
            >
              <span>
                {loading
                  ? activeTab === 'register'
                    ? 'Sending OTP...'
                    : 'Processing...'
                  : activeTab === 'signin'
                  ? 'Sign In'
                  : activeTab === 'register'
                  ? 'Send OTP'
                  : 'Send Password Reset Email'}
              </span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}

        {/* Toggle between tabs */}
        <div className="pt-2 border-t border-slate-800/80 text-center text-xs text-slate-400">
          {activeTab === 'signin' ? (
            <p>
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => handleTabSwitch('register')}
                className="text-indigo-400 hover:text-indigo-300 font-bold"
              >
                Register here
              </button>
            </p>
          ) : (
            <p>
              Already registered?{' '}
              <button
                type="button"
                onClick={() => handleTabSwitch('signin')}
                className="text-indigo-400 hover:text-indigo-300 font-bold"
              >
                Sign In
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
