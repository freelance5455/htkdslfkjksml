import React, { useState } from "react";
import {
  X,
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  KeyRound,
  Check,
  Zap,
} from "lucide-react";
import {
  registerWithEmailPassword,
  loginWithEmailPassword,
  signInWithGoogle,
  signInWithApple,
  resetPasswordForEmail,
  authAccountToProfile,
} from "../utils/authService";
import { UserProfile } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: UserProfile;
  onSuccess: (updatedProfile: UserProfile) => void;
  initialMode?: "login" | "register" | "forgot";
  titlePrompt?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onSuccess,
  initialMode = "login",
  titlePrompt,
}) => {
  const [mode, setMode] = useState<"login" | "register" | "forgot">(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetFormState = () => {
    setError(null);
    setSuccessMessage(null);
  };

  const handleEmailPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (mode === "register") {
      if (password !== confirmPassword) {
        setError("Girdiğiniz şifreler birbiriyle eşleşmiyor!");
        return;
      }
      setLoading(true);
      try {
        const res = await registerWithEmailPassword(name, email, password);
        if (res.success && res.user) {
          const newProfile = authAccountToProfile(res.user, currentProfile);
          setSuccessMessage("✓ Hesabınız başarıyla oluşturuldu! Yapay zeka asistanı ve tüm özellikler aktif edildi.");
          setTimeout(() => {
            onSuccess(newProfile);
            onClose();
          }, 800);
        } else {
          setError(res.error || "Kayıt işlemi tamamlanamadı.");
        }
      } catch (err: any) {
        setError(err?.message || "Beklenmeyen bir hata oluştu.");
      } finally {
        setLoading(false);
      }
    } else if (mode === "login") {
      setLoading(true);
      try {
        const res = await loginWithEmailPassword(email, password);
        if (res.success && res.user) {
          const newProfile = authAccountToProfile(res.user, currentProfile);
          setSuccessMessage("✓ Giriş başarılı! Hoş geldiniz.");
          setTimeout(() => {
            onSuccess(newProfile);
            onClose();
          }, 600);
        } else {
          setError(res.error || "Giriş yapılamadı.");
        }
      } catch (err: any) {
        setError(err?.message || "Giriş sırasında hata oluştu.");
      } finally {
        setLoading(false);
      }
    } else if (mode === "forgot") {
      setLoading(true);
      try {
        const res = await resetPasswordForEmail(email);
        if (res.success) {
          setSuccessMessage(
            `✓ Sıfırlama başarılı! Geçici şifreniz: "${res.tempPassword}". Bu şifreyle hemen giriş yapabilirsiniz.`
          );
          setMode("login");
          if (res.tempPassword) setPassword(res.tempPassword);
        } else {
          setError(res.error || "Şifre sıfırlanamadı.");
        }
      } catch (err: any) {
        setError(err?.message || "İşlem sırasında hata oluştu.");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleGoogleAuth = async () => {
    setError(null);
    setLoading(true);
    try {
      const user = await signInWithGoogle(email || "enes02erdm@gmail.com", name || "Enes Erdem");
      const newProfile = authAccountToProfile(user, currentProfile);
      setSuccessMessage("✓ Google ile başarıyla giriş yapıldı! Yapay zeka araçları kilidi açıldı.");
      setTimeout(() => {
        onSuccess(newProfile);
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || "Google ile giriş sırasında hata oluştu.");
    } finally {
      setLoading(false);
    }
  };

  const handleAppleAuth = async () => {
    setError(null);
    setLoading(true);
    try {
      const user = await signInWithApple(email || "apple.user@icloud.com", name || "Apple Kullanıcısı");
      const newProfile = authAccountToProfile(user, currentProfile);
      setSuccessMessage("✓ Sign in with Apple başarıyla tamamlandı! Yapay zeka erişimi aktif.");
      setTimeout(() => {
        onSuccess(newProfile);
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || "Apple ile giriş sırasında hata oluştu.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header Ambient Glow */}
        <div className="absolute top-0 right-0 w-60 h-60 bg-gradient-to-bl from-teal-500/15 via-emerald-500/10 to-transparent rounded-full blur-2xl pointer-events-none" />

        {/* Modal Top Bar */}
        <div className="p-5 sm:p-6 pb-4 flex items-start justify-between border-b border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-600 text-white flex items-center justify-center shadow-md shadow-teal-500/20">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight">
                {mode === "register"
                  ? "Yeni Hesap Oluştur"
                  : mode === "forgot"
                  ? "Şifremi Sıfırla"
                  : "NoteFlow'a Giriş Yap"}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {titlePrompt || "Yapay zeka asistanı ve tüm akıllı araçların kilidini açın."}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-4">
          {/* Notification Alerts */}
          {error && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Social OAuth Providers (Apple & Google Standards) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* Google OAuth Button */}
            <button
              type="button"
              onClick={handleGoogleAuth}
              disabled={loading}
              className="w-full py-2.5 px-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-white text-xs font-bold shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all hover:border-teal-500 active:scale-98 disabled:opacity-50"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Google ile Devam</span>
            </button>

            {/* Apple OAuth Standard Button */}
            <button
              type="button"
              onClick={handleAppleAuth}
              disabled={loading}
              className="w-full py-2.5 px-3 rounded-2xl border border-slate-900 dark:border-slate-700 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 text-xs font-bold shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98 disabled:opacity-50"
            >
              <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 170 170">
                <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.74 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.7-3.04-7.65-7.79-11.86-14.24-7.51-11.53-13.08-24.66-16.71-39.38-3.63-14.73-5.45-28.53-5.45-41.42 0-16.14 3.8-29.58 11.41-40.32 7.6-10.74 17.54-16.2 29.82-16.39 4.8 0 10.37 1.34 16.71 4.02 6.34 2.68 10.38 4.07 12.13 4.18 1.45 0 5.75-1.5 12.89-4.5 7.15-3 13.01-4.32 17.58-3.96 13.62.77 24.52 5.72 32.7 14.86-11.96 7.27-17.84 17.2-17.65 29.8.19 9.87 3.99 18.06 11.38 24.57 7.4 6.51 16.12 10.2 26.17 11.07-2.6 7.82-5.75 16.03-9.47 24.62zm-35.34-106.6c.13-5.11 2.05-10.25 5.76-15.42 3.71-5.17 8.3-8.88 13.78-11.13.39 1.13.58 2.22.58 3.27 0 5.48-2.07 10.9-6.2 16.27-4.13 5.37-9.39 8.87-15.77 10.51-.13-.98-.22-2.14-.22-3.5z" />
              </svg>
              <span>Apple ile Giriş Yap</span>
            </button>
          </div>

          <div className="relative flex items-center justify-center my-3">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-800" />
            </div>
            <span className="relative px-3 bg-white dark:bg-slate-900 text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">
              veya e-posta ile
            </span>
          </div>

          {/* Email / Password Form */}
          <form onSubmit={handleEmailPasswordSubmit} className="space-y-3">
            {mode === "register" && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Adınız ve Soyadınız
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Örn: Enes Erdem"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                E-posta Adresi
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="adiniz@ornek.com"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            {mode !== "forgot" && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    Şifre
                  </label>
                  {mode === "login" && (
                    <button
                      type="button"
                      onClick={() => {
                        resetFormState();
                        setMode("forgot");
                      }}
                      className="text-[11px] font-semibold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                    >
                      Şifremi Unuttum?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="En az 6 karakter"
                    className="w-full pl-9 pr-10 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {mode === "register" && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Şifre Tekrar
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Şifrenizi tekrar yazın"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-black shadow-md shadow-teal-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>İşlem Yapılıyor...</span>
                </>
              ) : mode === "register" ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Kayıt Ol ve AI Kilidini Aç</span>
                </>
              ) : mode === "forgot" ? (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Şifre Sıfırlama İsteği Gönder</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>Giriş Yap & Yapay Zekayı Başlat</span>
                </>
              )}
            </button>
          </form>

          {/* Toggle between Login, Register, Forgot */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            {mode === "login" ? (
              <>
                <span className="text-slate-500 dark:text-slate-400">Henüz hesabınız yok mu?</span>
                <button
                  type="button"
                  onClick={() => {
                    resetFormState();
                    setMode("register");
                  }}
                  className="font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                >
                  Hemen Kayıt Olun
                </button>
              </>
            ) : mode === "register" ? (
              <>
                <span className="text-slate-500 dark:text-slate-400">Zaten hesabınız var mı?</span>
                <button
                  type="button"
                  onClick={() => {
                    resetFormState();
                    setMode("login");
                  }}
                  className="font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                >
                  Giriş Yapın
                </button>
              </>
            ) : (
              <div className="w-full text-center">
                <button
                  type="button"
                  onClick={() => {
                    resetFormState();
                    setMode("login");
                  }}
                  className="font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                >
                  ← Giriş Ekranına Geri Dön
                </button>
              </div>
            )}
          </div>

          {/* Flutter / Firebase Auth Info Box */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
            <span>
              Kimlik doğrulama şifreniz PBKDF2 SHA-256 ve Firebase Auth standardında korunur. Giriş sonunda tüm Gemini yapay zeka araçları ve zihin asistanı anında etkinleşir.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
