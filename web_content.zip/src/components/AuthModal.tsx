import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Mail,
  Lock,
  User,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { authModalOpen, setAuthModalOpen, loginUser, showToast } = useApp();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (!authModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      alert('Please enter your email.');
      return;
    }

    if (mode === 'forgot') {
      showToast(`Password reset link sent to ${email}`, 'info');
      setMode('login');
      return;
    }

    loginUser(email, name || email.split('@')[0]);
    setAuthModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-md"
        onClick={() => setAuthModalOpen(false)}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div className="bg-[#0B192C] text-white p-4 flex items-center justify-between border-b border-[#1E3E62]">
          <div>
            <h3 className="font-extrabold text-sm sm:text-base">
              {mode === 'login' && 'Student Sign In'}
              {mode === 'signup' && 'Create Free Student Account'}
              {mode === 'forgot' && 'Reset Password'}
            </h3>
            <p className="text-[11px] text-amber-300">NEXA EXAM BOOKS</p>
          </div>
          <button
            onClick={() => setAuthModalOpen(false)}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 sm:p-6 space-y-4">
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            {mode === 'signup' && (
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Partha Pratim Nath"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 outline-none focus:border-amber-500 font-medium"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@example.com"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 outline-none focus:border-amber-500 font-medium"
                  required
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-bold text-slate-700">Password</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setMode('forgot')}
                      className="text-amber-700 hover:underline font-bold text-[11px]"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 outline-none focus:border-amber-500 font-medium"
                    required
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full mt-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm py-2.5 rounded-xl shadow-md transition-all"
            >
              {mode === 'login' && 'Sign In to My Account'}
              {mode === 'signup' && 'Register & Access Study Material'}
              {mode === 'forgot' && 'Send Reset Link'}
            </button>
          </form>

          {/* Toggle Modes */}
          <div className="pt-3 border-t border-slate-200 text-center text-xs text-slate-600">
            {mode === 'login' ? (
              <p>
                New student?{' '}
                <button
                  onClick={() => setMode('signup')}
                  className="font-bold text-amber-700 hover:underline"
                >
                  Create an account
                </button>
              </p>
            ) : (
              <p>
                Already have an account?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="font-bold text-amber-700 hover:underline"
                >
                  Sign In
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
