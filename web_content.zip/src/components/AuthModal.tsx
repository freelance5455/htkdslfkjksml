import React, { useState } from 'react';
import { Logo } from './Logo';
import { UserSession } from '../types';
import { AVATARS, DEFAULT_CLASS_KEYS } from '../constants';
import { User, GraduationCap, KeyRound, ArrowRight, ShieldCheck, Sparkles, Check, Copy } from 'lucide-react';

interface AuthModalProps {
  onSuccess: (session: UserSession) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onSuccess }) => {
  const [role, setRole] = useState<'guest' | 'student' | 'teacher'>('student');
  const [isLogin, setIsLogin] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Student state
  const [studentName, setStudentName] = useState('amaan');
  const [studentKey, setStudentKey] = useState('CLASS-101');
  const [studentAvatar, setStudentAvatar] = useState(AVATARS[0]);
  const [studentPassword, setStudentPassword] = useState('');

  // Teacher state
  const [teacherName, setTeacherName] = useState('amaan');
  const [teacherAvatar, setTeacherAvatar] = useState(AVATARS[1]);
  const [generatedKey] = useState(() => `CLASS-${Math.floor(1000 + Math.random() * 9000)}`);
  const [customKey, setCustomKey] = useState('');
  const [useCustomKey, setUseCustomKey] = useState(false);
  const [teacherPassword, setTeacherPassword] = useState('');
  const [copiedKey, setCopiedKey] = useState(false);

  const handleGuestEnter = () => {
    onSuccess({
      role: 'guest',
      name: 'amaan',
      uid: `guest_${Date.now()}`,
    });
  };

  const handleStudentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const name = studentName.trim();
    const key = studentKey.trim().toUpperCase();

    if (!name) {
      setError('Please enter Student Name!');
      return;
    }
    if (!key) {
      setError("Please enter Teacher's Class Key!");
      return;
    }

    // Verify key
    const existingKeys: string[] = JSON.parse(localStorage.getItem('devarena_class_keys') || '[]');
    const allValidKeys = [...DEFAULT_CLASS_KEYS, ...existingKeys];

    if (!allValidKeys.includes(key)) {
      setError(`Class Key "${key}" not found. Try default "CLASS-101" or ask your teacher.`);
      return;
    }

    const session: UserSession = {
      role: 'student',
      name,
      classKey: key,
      photoUrl: studentAvatar,
      uid: `student_${Date.now()}`,
    };

    onSuccess(session);
  };

  const handleTeacherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const name = teacherName.trim();
    if (!name) {
      setError('Please enter Teacher / Sir Name!');
      return;
    }

    const finalKey = (useCustomKey ? customKey.trim().toUpperCase() : generatedKey) || `CLASS-${Math.floor(1000 + Math.random() * 9000)}`;

    // Store key in localStorage for student access
    const existingKeys: string[] = JSON.parse(localStorage.getItem('devarena_class_keys') || '[]');
    if (!existingKeys.includes(finalKey)) {
      existingKeys.push(finalKey);
      localStorage.setItem('devarena_class_keys', JSON.stringify(existingKeys));
    }

    const session: UserSession = {
      role: 'teacher',
      name,
      classKey: finalKey,
      photoUrl: teacherAvatar,
      uid: `teacher_${Date.now()}`,
    };

    onSuccess(session);
  };

  const copyKeyToClipboard = (keyText: string) => {
    navigator.clipboard.writeText(keyText);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="min-h-screen theme-bg-main theme-text-main flex flex-col justify-center items-center px-4 py-8">
      <div className="w-full max-w-md theme-bg-surface border theme-border rounded-2xl p-6 sm:p-8 shadow-2xl theme-text-main">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <Logo size="lg" showName={true} />
          <p className="text-xs theme-text-muted mt-1.5 font-medium">
            Web Coding & Class Assignment Platform
          </p>
        </div>

        {/* Role Tabs */}
        <div className="grid grid-cols-3 gap-1 theme-bg-main p-1 rounded-xl mb-6 text-xs font-medium border theme-border">
          <button
            type="button"
            onClick={() => {
              setRole('student');
              setError(null);
            }}
            className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
              role === 'student'
                ? 'theme-accent font-semibold shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Student</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setRole('teacher');
              setError(null);
            }}
            className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
              role === 'teacher'
                ? 'theme-accent font-semibold shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Teacher (Sir)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setRole('guest');
              setError(null);
            }}
            className={`py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
              role === 'guest'
                ? 'theme-accent font-semibold shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Direct IDE</span>
          </button>
        </div>

        {/* Error notification */}
        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl flex items-center justify-between">
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="text-red-400 hover:text-red-300 font-bold ml-2 text-sm"
            >
              ×
            </button>
          </div>
        )}

        {/* GUEST MODE */}
        {role === 'guest' && (
          <div className="space-y-5 text-center py-2">
            <div className="p-4 rounded-xl bg-[#359efe]/10 border border-[#359efe]/20 text-xs theme-text-muted leading-relaxed">
              Start coding directly and view live previews without an account. Instant access to full web editor, console, and HTML/CSS/JS compiler.
            </div>
            <button
              type="button"
              onClick={handleGuestEnter}
              className="w-full theme-accent hover:theme-accent-hover font-medium py-3 px-4 rounded-xl text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
            >
              <span>Start Coding Directly</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STUDENT MODE */}
        {role === 'student' && (
          <form onSubmit={handleStudentSubmit} className="space-y-4">
            <div className="flex items-center justify-between border-b theme-border pb-2 mb-3">
              <span className="text-xs font-semibold theme-text-main">
                {isLogin ? 'Student Login' : 'Student Sign Up & Enter'}
              </span>
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-[11px] text-[#359efe] hover:underline cursor-pointer"
              >
                {isLogin ? 'Need Sign Up?' : 'Already have account?'}
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium theme-text-muted mb-1.5">
                Student Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 theme-text-muted" />
                <input
                  type="text"
                  required
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="e.g. amaan"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border theme-border theme-bg-main theme-text-main focus:outline-none focus:border-[#359efe]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium theme-text-muted">
                  Class Key (Generated by Teacher)
                </label>
                <span className="text-[10px] text-[#359efe] font-mono">Demo: CLASS-101</span>
              </div>
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 theme-text-muted" />
                <input
                  type="text"
                  required
                  value={studentKey}
                  onChange={(e) => setStudentKey(e.target.value)}
                  placeholder="e.g. CLASS-101"
                  className="w-full pl-9 pr-3 py-2 text-xs font-mono font-semibold rounded-xl border theme-border theme-bg-main theme-text-main uppercase focus:outline-none focus:border-[#359efe]"
                />
              </div>
              <p className="text-[10px] theme-text-muted mt-1 leading-normal">
                Enter the exact Class Key provided by your teacher. Unverified keys will not be permitted.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium theme-text-muted mb-1.5">
                Choose Avatar
              </label>
              <div className="flex items-center space-x-2">
                {AVATARS.slice(0, 5).map((av, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setStudentAvatar(av)}
                    className={`w-9 h-9 rounded-full overflow-hidden border-2 transition-transform cursor-pointer ${
                      studentAvatar === av ? 'border-[#359efe] scale-110' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={av} alt="avatar" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {isLogin && (
              <div>
                <label className="block text-xs font-medium theme-text-muted mb-1.5">
                  Password (optional)
                </label>
                <input
                  type="password"
                  value={studentPassword}
                  onChange={(e) => setStudentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-xl border theme-border theme-bg-main theme-text-main focus:outline-none focus:border-[#359efe]"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full mt-2 theme-accent hover:theme-accent-hover font-medium py-2.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
            >
              <span>{isLogin ? 'Student Login' : 'Student Sign Up & Enter'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}

        {/* TEACHER MODE */}
        {role === 'teacher' && (
          <form onSubmit={handleTeacherSubmit} className="space-y-4">
            <div className="flex items-center justify-between border-b theme-border pb-2 mb-3">
              <span className="text-xs font-semibold theme-text-main">
                {isLogin ? 'Teacher Login' : 'Create Teacher Account & Key'}
              </span>
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-[11px] text-[#359efe] hover:underline cursor-pointer"
              >
                {isLogin ? 'Create Account?' : 'Existing Teacher?'}
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium theme-text-muted mb-1.5">
                Teacher / Sir Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 theme-text-muted" />
                <input
                  type="text"
                  required
                  value={teacherName}
                  onChange={(e) => setTeacherName(e.target.value)}
                  placeholder="e.g. amaan"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border theme-border theme-bg-main theme-text-main focus:outline-none focus:border-[#359efe]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium theme-text-muted">
                  Class Key For Students
                </label>
                <button
                  type="button"
                  onClick={() => setUseCustomKey(!useCustomKey)}
                  className="text-[10px] text-[#359efe] hover:underline cursor-pointer"
                >
                  {useCustomKey ? 'Use Auto Key' : 'Custom Key'}
                </button>
              </div>

              {useCustomKey ? (
                <input
                  type="text"
                  value={customKey}
                  onChange={(e) => setCustomKey(e.target.value)}
                  placeholder="e.g. CLASS-WEB-2026"
                  className="w-full px-3 py-2 text-xs font-mono font-semibold rounded-xl border theme-border theme-bg-main theme-text-main uppercase focus:outline-none focus:border-[#359efe]"
                />
              ) : (
                <div className="flex items-center justify-between p-2.5 rounded-xl border theme-border theme-bg-main font-mono text-xs font-bold text-[#359efe]">
                  <span>{generatedKey}</span>
                  <button
                    type="button"
                    onClick={() => copyKeyToClipboard(generatedKey)}
                    className="flex items-center space-x-1 text-[11px] theme-text-muted hover:theme-text-main cursor-pointer"
                  >
                    {copiedKey ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedKey ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              )}
              <p className="text-[10px] theme-text-muted mt-1 leading-normal">
                Share this key with your students so they can join your classroom assignments.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium theme-text-muted mb-1.5">
                Teacher Photo / Avatar
              </label>
              <div className="flex items-center space-x-2">
                {AVATARS.slice(1, 6).map((av, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setTeacherAvatar(av)}
                    className={`w-9 h-9 rounded-full overflow-hidden border-2 transition-transform cursor-pointer ${
                      teacherAvatar === av ? 'border-[#359efe] scale-110' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={av} alt="avatar" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {isLogin && (
              <div>
                <label className="block text-xs font-medium theme-text-muted mb-1.5">
                  Password (optional)
                </label>
                <input
                  type="password"
                  value={teacherPassword}
                  onChange={(e) => setTeacherPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-xl border theme-border theme-bg-main theme-text-main focus:outline-none focus:border-[#359efe]"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full mt-2 theme-accent hover:theme-accent-hover font-medium py-2.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
            >
              <span>{isLogin ? 'Teacher Login' : 'Create Teacher Account & Key'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>

      <div className="text-center py-4 text-[11px] theme-text-muted font-mono">
        NEXORA Studio v2.0 · Online Code Editor by amaan
      </div>
    </div>
  );
};
