import { useEffect, useState, type FormEvent } from 'react';
import { Award, Check, Copy, ExternalLink, Globe, Lock, Mail, User as UserIcon, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import { FIREBASE_AUTH_PROVIDERS_URL, FIREBASE_AUTH_SETTINGS_URL } from '../firebase';

interface AuthModalProps {
  open: boolean;
  initialMode?: 'signup' | 'signin';
  onClose: () => void;
  onStartPlacement?: () => void;
}

export function AuthModal({
  open,
  initialMode = 'signup',
  onClose,
  onStartPlacement,
}: AuthModalProps) {
  const {
    user,
    signingIn,
    authError,
    authErrorCode,
    authErrorHostname,
    signInWithGoogle,
    signUpWithEmail,
    signInWithEmail,
    clearAuthError,
  } = useAuth();
  const { lang, languages, setLang, t } = useI18n();

  const [mode, setMode] = useState<'signup' | 'signin'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [justRegistered, setJustRegistered] = useState(false);
  const [copiedHost, setCopiedHost] = useState(false);

  useEffect(() => {
    if (open) {
      setMode(initialMode);
      setJustRegistered(false);
      clearAuthError();
    }
  }, [open, initialMode, clearAuthError]);

  if (!open) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (mode === 'signup') {
      const ok = await signUpWithEmail(name, email, password);
      if (ok) {
        setJustRegistered(true);
      }
    } else {
      const ok = await signInWithEmail(email, password);
      if (ok) {
        onClose();
      }
    }
  };

  const handleGoogle = async () => {
    const ok = await signInWithGoogle();
    if (ok) {
      if (mode === 'signup') {
        setJustRegistered(true);
      } else {
        onClose();
      }
    }
  };

  return (
    <div
      data-testid="auth-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-3 backdrop-blur-sm sm:p-4"
      onClick={onClose}
    >
      <div
        className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl border border-[var(--border)] bg-[var(--card)] p-5 shadow-2xl sm:p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <img
              src="/pwa-192x192.png"
              alt="TMN"
              className="h-9 w-9 rounded-xl border border-sky-400/40 object-cover"
            />
            <div>
              <h2 className="text-base font-black text-[var(--ink)]">TMN</h2>
              <p className="text-[11px] font-semibold text-[var(--muted)]">{t.appTagline}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--card2)] text-[var(--muted)] hover:text-[var(--ink)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Post-registration placement test invitation */}
        {justRegistered && user ? (
          <div className="space-y-4 py-2 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400">
              <Award className="h-7 w-7" />
            </div>
            <h3 className="text-lg font-black text-[var(--ink)]">{t.accountSynced}</h3>
            <p className="text-xs leading-relaxed text-[var(--muted)]">{t.placementSubtitle}</p>
            <div className="flex flex-col gap-2.5 pt-2">
              {onStartPlacement && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onStartPlacement();
                  }}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 px-4 py-3 text-sm font-black text-white shadow-lg"
                >
                  <Award className="h-4 w-4" />
                  <span>{t.placementStart}</span>
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="w-full rounded-2xl border border-[var(--border)] bg-[var(--card2)] px-4 py-2.5 text-xs font-bold text-[var(--ink)]"
              >
                {t.skip}
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Sign Up / Sign In tabs */}
            <div className="mb-4 grid grid-cols-2 gap-1.5 rounded-2xl bg-[var(--card2)] p-1">
              <button
                type="button"
                data-testid="auth-tab-signup"
                onClick={() => {
                  setMode('signup');
                  clearAuthError();
                }}
                className={`rounded-xl py-2 text-xs font-extrabold transition ${
                  mode === 'signup'
                    ? 'bg-sky-500 text-slate-950 shadow-sm'
                    : 'text-[var(--muted)] hover:text-[var(--ink)]'
                }`}
              >
                {t.signUp}
              </button>
              <button
                type="button"
                data-testid="auth-tab-signin"
                onClick={() => {
                  setMode('signin');
                  clearAuthError();
                }}
                className={`rounded-xl py-2 text-xs font-extrabold transition ${
                  mode === 'signin'
                    ? 'bg-sky-500 text-slate-950 shadow-sm'
                    : 'text-[var(--muted)] hover:text-[var(--ink)]'
                }`}
              >
                {t.signIn}
              </button>
            </div>

            {/* 10-Language Selector inside Registration */}
            <div className="mb-4 rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-extrabold text-[var(--ink)]">
                <Globe className="h-3.5 w-3.5 text-sky-400" />
                <span>{t.languageLabel}</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                {languages.map((opt) => (
                  <button
                    key={opt.code}
                    type="button"
                    data-testid={`auth-lang-${opt.code}`}
                    data-keep-native="true"
                    onClick={() => setLang(opt.code)}
                    className={`flex items-center justify-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-bold transition ${
                      lang === opt.code
                        ? 'border-sky-400 bg-sky-500/20 text-sky-300'
                        : 'border-[var(--border)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--ink)]'
                    }`}
                  >
                    <span>{opt.flag}</span>
                    <span>{opt.nativeName}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Google Sign-In button */}
            <button
              type="button"
              data-testid="auth-google-btn"
              disabled={signingIn}
              onClick={() => void handleGoogle()}
              className="mb-3 flex w-full items-center justify-center gap-2.5 rounded-2xl border border-[var(--border)] bg-white px-4 py-2.5 text-xs font-extrabold text-slate-900 shadow-sm hover:bg-slate-100 disabled:opacity-60"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
                />
                <path
                  fill="#34A853"
                  d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.565 24 12.255 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 000 10.76l3.98-3.09z"
                />
                <path
                  fill="#EA4335"
                  d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.69 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
                />
              </svg>
              <span>{signingIn ? '...' : t.continueWithGoogle}</span>
            </button>

            {authError && (
              <div
                role="alert"
                data-testid="auth-error-banner"
                className="mb-3 space-y-2.5 rounded-2xl border border-rose-500/40 bg-rose-500/10 p-3 text-xs font-bold leading-relaxed text-rose-200"
              >
                <p>{authError}</p>
                {authErrorCode === 'auth/unauthorized-domain' && authErrorHostname && (
                  <div className="space-y-2 rounded-xl border border-rose-400/25 bg-slate-950/60 p-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <code
                        dir="ltr"
                        className="truncate rounded-lg bg-slate-900 px-2 py-1 font-mono text-[11px] text-sky-300"
                      >
                        {authErrorHostname}
                      </code>
                      <button
                        type="button"
                        data-testid="auth-copy-domain-btn"
                        onClick={() => {
                          void navigator.clipboard?.writeText(authErrorHostname).then(() => {
                            setCopiedHost(true);
                            setTimeout(() => setCopiedHost(false), 2000);
                          });
                        }}
                        className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-sky-500/20 px-2.5 py-1 text-[11px] font-extrabold text-sky-300 hover:bg-sky-500/30"
                      >
                        {copiedHost ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                        <span>{copiedHost ? (lang === 'ar' ? 'تم النسخ' : 'Copied') : (lang === 'ar' ? 'نسخ النطاق' : 'Copy')}</span>
                      </button>
                    </div>
                    <a
                      href={FIREBASE_AUTH_SETTINGS_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-rose-500/25 px-3 py-1.5 text-[11px] font-extrabold text-white transition hover:bg-rose-500/35"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      <span>
                        {lang === 'ar'
                          ? 'فتح إعدادات النطاقات المصرح بها في Firebase'
                          : 'Open Firebase Authorized Domains Settings'}
                      </span>
                    </a>
                  </div>
                )}
                {authErrorCode === 'auth/operation-not-allowed' && (
                  <div
                    data-testid="auth-provider-setup-box"
                    className="space-y-2 rounded-xl border border-amber-400/30 bg-slate-950/60 p-2.5 text-[11px] font-semibold text-slate-200"
                  >
                    <ol className="list-inside list-decimal space-y-1 text-slate-200">
                      <li>
                        {lang === 'ar'
                          ? 'افتح صفحة مزوّدي الدخول في Firebase Console من الزر أدناه.'
                          : 'Open Firebase Console Sign-in Providers using the button below.'}
                      </li>
                      <li>
                        {lang === 'ar'
                          ? 'اضغط على «Email/Password» (أو «Add new provider» ← «Email/Password»).'
                          : 'Click "Email/Password" (or "Add new provider" → "Email/Password").'}
                      </li>
                      <li>
                        {lang === 'ar'
                          ? 'فعّل خيار Enable ثم اضغط Save، وبعدها سيعمل التسجيل بالبريد فوراً.'
                          : 'Toggle Enable ON and click Save, then retry Email/Password sign-up.'}
                      </li>
                    </ol>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <a
                        href={FIREBASE_AUTH_PROVIDERS_URL}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-amber-500/25 px-3 py-1.5 text-[11px] font-extrabold text-amber-100 transition hover:bg-amber-500/35"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>
                          {lang === 'ar'
                            ? 'تفعيل Email/Password في Firebase'
                            : 'Enable Email/Password in Firebase'}
                        </span>
                      </a>
                      <button
                        type="button"
                        disabled={signingIn}
                        onClick={() => void handleGoogle()}
                        className="inline-flex items-center justify-center rounded-lg bg-white px-3 py-1.5 text-[11px] font-extrabold text-slate-900 hover:bg-slate-100 disabled:opacity-50"
                      >
                        {lang === 'ar' ? 'المتابعة بـ Google' : 'Use Google'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="my-3 flex items-center gap-2 text-[11px] font-bold text-[var(--muted)]">
              <div className="h-px flex-1 bg-[var(--border)]" />
              <span>{t.orDivider}</span>
              <div className="h-px flex-1 bg-[var(--border)]" />
            </div>

            {/* Email & Password Form */}
            <form onSubmit={(e) => void handleSubmit(e)} className="space-y-3">
              {mode === 'signup' && (
                <div>
                  <label className="mb-1 block text-[11px] font-bold text-[var(--muted)]">
                    {t.nameLabel}
                  </label>
                  <div className="relative">
                    <UserIcon className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted)]" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={lang === 'ar' ? 'أحمد / Alex' : 'Alex'}
                      className="w-full rounded-xl border border-[var(--border)] bg-[var(--card2)] py-2.5 pe-3 ps-9 text-sm text-[var(--ink)] outline-none focus:border-sky-400"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="mb-1 block text-[11px] font-bold text-[var(--muted)]">
                  {t.emailLabel}
                </label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted)]" />
                  <input
                    type="email"
                    required
                    dir="ltr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full rounded-xl border border-[var(--border)] bg-[var(--card2)] py-2.5 pe-3 ps-9 text-sm text-[var(--ink)] outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-[11px] font-bold text-[var(--muted)]">
                  {t.passwordLabel}
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted)]" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    dir="ltr"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-[var(--border)] bg-[var(--card2)] py-2.5 pe-3 ps-9 text-sm text-[var(--ink)] outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={signingIn}
                className="w-full rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 px-4 py-3 text-sm font-black text-white shadow-lg hover:brightness-110 disabled:opacity-60"
              >
                {signingIn ? '...' : mode === 'signup' ? t.createAccount : t.signIn}
              </button>
            </form>

            {/* Placement Test Direct CTA during registration */}
            {onStartPlacement && (
              <div className="mt-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-emerald-300">{t.placementTitle}</div>
                    <div className="truncate text-[11px] text-[var(--muted)]">{t.placementSubtitle}</div>
                  </div>
                  <button
                    type="button"
                    data-testid="auth-open-placement"
                    onClick={() => {
                      onClose();
                      onStartPlacement();
                    }}
                    className="shrink-0 rounded-xl bg-emerald-500 px-3 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-400"
                  >
                    {t.placementStart}
                  </button>
                </div>
              </div>
            )}

            <div className="mt-3 text-center">
              <button
                type="button"
                onClick={() => {
                  setMode(mode === 'signup' ? 'signin' : 'signup');
                  clearAuthError();
                }}
                className="text-xs font-bold text-sky-400 hover:underline"
              >
                {mode === 'signup' ? t.haveAccount : t.noAccount}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
