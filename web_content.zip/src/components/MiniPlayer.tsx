import React from 'react';
import { Play, Pause, SkipForward, Heart } from 'lucide-react';
import { Song } from '../types';
import { ArtworkImage } from './ArtworkImage';

interface MiniPlayerProps {
  song: Song;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onPlayPause: () => void;
  onSkipNext: () => void;
  onToggleFavorite: (song: Song) => void;
  onExpand: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  song,
  isPlaying,
  currentTime,
  duration,
  onPlayPause,
  onSkipNext,
  onToggleFavorite,
  onExpand,
}) => {
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="relative w-full bg-[#12181F]/95 backdrop-blur-md border-t border-[#273442] shadow-2xl">
      {/* Top progress line */}
      <div className="w-full h-1 bg-[#273442]/60">
        <div
          className="h-full bg-emerald-500 transition-all duration-200"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="flex items-center justify-between px-4 py-2.5 max-w-5xl mx-auto">
        {/* Track info (Clicking expands) */}
        <div
          onClick={onExpand}
          className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer hover:opacity-90 transition-opacity"
        >
          <ArtworkImage
            artworkUrl={song.artworkUrl}
            alt={song.title}
            className="w-11 h-11 rounded-lg"
            iconSize={20}
          />
          <div className="min-w-0">
            <h4 className="text-sm font-semibold text-slate-100 truncate">
              {song.title}
            </h4>
            <p className="text-xs text-slate-400 truncate">{song.artist}</p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(song);
            }}
            className="p-2 text-slate-400 hover:text-emerald-400 transition-colors"
            title={song.isFavorite ? 'Unfavorite' : 'Favorite'}
          >
            <Heart
              size={19}
              className={song.isFavorite ? 'fill-emerald-500 text-emerald-500' : ''}
            />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onPlayPause();
            }}
            className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center hover:bg-emerald-400 active:scale-95 transition-all shadow-md"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} className="ml-0.5" fill="currentColor" />}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onSkipNext();
            }}
            className="p-2 text-slate-400 hover:text-slate-100 transition-colors"
            title="Next Track"
          >
            <SkipForward size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};
