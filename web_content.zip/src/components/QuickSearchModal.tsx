import React, { useState, useEffect, useRef } from 'react';
import { FileItem } from '../types';
import { Search, FileCode, FileText, Image as ImageIcon, X } from 'lucide-react';

interface QuickSearchModalProps {
  isOpen: boolean;
  files: FileItem[];
  onClose: () => void;
  onSelectFile: (id: string) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  files,
  onClose,
  onSelectFile,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const nonFolderFiles = files.filter((f) => !f.isFolder);

  const filtered = nonFolderFiles.filter((f) =>
    f.name.toLowerCase().includes(query.toLowerCase().trim())
  );

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  if (!isOpen) return null;

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (filtered.length > 0 ? (prev + 1) % filtered.length : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (filtered.length > 0 ? (prev - 1 + filtered.length) % filtered.length : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        onSelectFile(filtered[selectedIndex].id);
        onClose();
      }
    }
  };

  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'ico'].includes(ext)) {
      return <ImageIcon className="w-4 h-4 text-emerald-400 shrink-0" />;
    }
    if (ext === 'html') return <FileCode className="w-4 h-4 text-orange-400 shrink-0" />;
    if (ext === 'css') return <FileText className="w-4 h-4 text-blue-400 shrink-0" />;
    return <FileCode className="w-4 h-4 text-[#359efe] shrink-0" />;
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/65 backdrop-blur-xs flex items-start justify-center pt-20 px-4 z-50 select-none font-sans"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#181920] border border-[#2e3142] rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-slate-200 animate-in fade-in zoom-in-95 duration-100"
      >
        {/* Search Input Bar */}
        <div className="h-12 px-3 flex items-center space-x-2.5 border-b border-[#2e3142] bg-[#121318]">
          <Search className="w-4 h-4 text-[#359efe] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a file name to open..."
            className="w-full bg-transparent text-xs font-mono text-white placeholder:text-slate-500 outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 text-slate-500 hover:text-white rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-72 overflow-y-auto p-1.5 space-y-0.5">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching files found.
            </div>
          ) : (
            filtered.map((file, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={file.id}
                  onClick={() => {
                    onSelectFile(file.id);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs font-mono cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#359efe] text-white font-semibold' : 'text-slate-300 hover:bg-[#20222c]'
                  }`}
                >
                  <div className="flex items-center space-x-2 truncate">
                    {getFileIcon(file.name)}
                    <span className="truncate">{file.name}</span>
                  </div>
                  <span
                    className={`text-[10px] uppercase font-mono ${
                      isSelected ? 'text-white/80' : 'text-slate-500'
                    }`}
                  >
                    {file.language || 'file'}
                  </span>
                </div>
              );
            })
          )}
        </div>

        <div className="px-3 py-2 border-t border-[#2e3142] bg-[#121318] text-[10px] text-slate-500 flex items-center justify-between font-mono">
          <span>Navigate with ↑ ↓ · Press Enter to open</span>
          <span>ESC to close</span>
        </div>
      </div>
    </div>
  );
};
