import React, { useState, useEffect } from 'react';
import { RefreshCw, Sparkles, CheckCircle2, XCircle } from 'lucide-react';
import { WordData } from '../types';
import { sound } from '../services/sound';

interface DetectiveTabProps {
  words: WordData[];
  onAddMistake: (word: string, wrongAns: string, correctAns: string, question: string) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
}

export const DetectiveTab: React.FC<DetectiveTabProps> = ({
  words,
  onAddMistake,
  onSetStatus,
}) => {
  const [targetWord, setTargetWord] = useState<WordData | null>(null);
  const [choices, setChoices] = useState<WordData[]>([]);
  const [guessedWord, setGuessedWord] = useState<string | null>(null);

  const initClueGame = () => {
    setGuessedWord(null);
    const target = words[Math.floor(Math.random() * words.length)] || words[0];
    const distractors = words
      .filter((w) => w.word !== target.word)
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);
    const shuffledChoices = [target, ...distractors].sort(() => 0.5 - Math.random());

    setTargetWord(target);
    setChoices(shuffledChoices);
  };

  useEffect(() => {
    initClueGame();
  }, [words]);

  if (!targetWord) return null;

  const handleGuess = (wordName: string) => {
    if (guessedWord !== null) return;
    setGuessedWord(wordName);

    const isCorrect = wordName === targetWord.word;
    if (isCorrect) {
      sound.triggerFloatingXp(25);
      sound.triggerCelebration(50, 40);
      onSetStatus(targetWord.word, 'mastered');
    } else {
      sound.wrong();
      onAddMistake(
        targetWord.word,
        wordName,
        targetWord.word,
        'Word Detective Reverse Clue Challenge'
      );
    }
  };

  const isGuessed = guessedWord !== null;
  const isCorrect = guessedWord === targetWord.word;

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-4 pb-28 max-w-md mx-auto w-full">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-700 to-indigo-800 text-white rounded-3xl p-4 shadow-[0_4px_0_0_#4c1d95] space-y-1">
        <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
          <span className="bg-white/20 px-2.5 py-0.5 rounded-full">Word Detective</span>
          <span className="font-mono text-xs bg-amber-400 text-slate-900 px-2 py-0.5 rounded-lg font-black flex items-center gap-1">
            <Sparkles className="w-3 h-3 fill-current" /> +25 XP
          </span>
        </div>
        <h2 className="text-xl font-black">Guess the Target Word</h2>
        <p className="text-xs text-purple-100 font-bengali">
          নিচের সূত্রগুলো (Hints) দেখে সঠিক ইংরেজি শব্দটি শনাক্ত করুন। এটি সক্রিয় স্মৃতিশক্তি বৃদ্ধি করে।
        </p>
      </div>

      {/* Clue Card */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
          <span className="text-xs font-bold text-slate-400">Word Detective #Clues</span>
          <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950 px-2 py-0.5 rounded-md uppercase">
            {targetWord.pos}
          </span>
        </div>

        {/* 3 Clues */}
        <div className="space-y-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800">
            <span className="font-extrabold text-slate-700 dark:text-slate-300 block mb-0.5">
              Clue 1 (Core Meaning):
            </span>
            <p className="text-slate-600 dark:text-slate-300 italic">
              "{targetWord.simpleDef}"
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 font-bengali">
            <span className="font-extrabold text-emerald-800 dark:text-emerald-300 block mb-0.5">
              Clue 2 (বাংলা অর্থ):
            </span>
            <p className="text-slate-700 dark:text-slate-200 font-bold">
              {targetWord.bengali.split('(')[0]}
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 font-bengali">
            <span className="font-extrabold text-amber-800 dark:text-amber-300 block mb-0.5">
              Clue 3 (স্মৃতি সহায়ক ছন্দ):
            </span>
            <p className="text-slate-700 dark:text-slate-200 text-xs">
              {targetWord.mnemonicBengali}
            </p>
          </div>
        </div>

        {/* Choices Grid */}
        <div className="pt-2">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Identify the word:
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {choices.map((c) => {
              const isThisWord = c.word === targetWord.word;
              const isSelected = guessedWord === c.word;

              let btnStyle = "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white";
              if (isGuessed) {
                if (isThisWord) {
                  btnStyle = "bg-emerald-600 text-white shadow-[0_3px_0_0_#059669]";
                } else if (isSelected) {
                  btnStyle = "bg-rose-600 text-white shadow-[0_3px_0_0_#e11d48]";
                } else {
                  btnStyle = "opacity-40 bg-slate-100 dark:bg-slate-800 text-slate-400";
                }
              }

              return (
                <button
                  key={c.word}
                  disabled={isGuessed}
                  onClick={() => handleGuess(c.word)}
                  className={`p-3 rounded-2xl font-black text-xs sm:text-sm active:scale-95 transition-all text-center ${btnStyle}`}
                >
                  {c.word}
                </button>
              );
            })}
          </div>
        </div>

        {/* Result Message */}
        {isGuessed && (
          <div
            className={`p-3 rounded-2xl text-xs font-bengali font-bold flex items-center gap-2 animate-in fade-in ${
              isCorrect
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200'
            }`}
          >
            {isCorrect ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>সঠিক উত্তর! আপনি +25 XP অর্জন করেছেন।</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>ভুল উত্তর। সঠিক শব্দ ছিল: <strong>{targetWord.word}</strong>। শব্দটি মিস্টেক্স ব্যাংকে যুক্ত হয়েছে।</span>
              </>
            )}
          </div>
        )}

        {/* Next Word Button */}
        <button
          onClick={initClueGame}
          className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-xl shadow-[0_4px_0_0_#6b21a8] flex items-center justify-center gap-1.5 active:translate-y-1 transition-all mt-2"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Next Detective Word
        </button>
      </div>

    </div>
  );
};
