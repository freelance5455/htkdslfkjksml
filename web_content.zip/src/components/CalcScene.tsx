"use client";

import { useRef, type ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import { Environment, Lightformer, Sparkles } from "@react-three/drei";
import * as THREE from "three";

/** Studio lighting: soft key light + purple/blue rim lights + reflection env (offline). */
export function CalcLights({ accent = "#8b5cf6" }: { accent?: string }) {
  return (
    <>
      <ambientLight intensity={0.55} />
      <directionalLight position={[3, 6, 8]} intensity={1.6} />
      <directionalLight position={[-5, -2, 5]} intensity={0.45} color="#93c5fd" />
      <pointLight position={[-6, 2, 3]} intensity={40} distance={20} color={accent} />
      <pointLight position={[6, -2, 3]} intensity={32} distance={20} color="#38bdf8" />
      <Environment frames={1} resolution={256}>
        <Lightformer form="rect" intensity={2.4} color="#ffffff" position={[0, 5, 6]} scale={[10, 3, 1]} />
        <Lightformer form="rect" intensity={3} color={accent} position={[-7, 0, 3]} scale={[4, 10, 1]} />
        <Lightformer form="rect" intensity={3} color="#38bdf8" position={[7, 0, 3]} scale={[4, 10, 1]} />
      </Environment>
      <Sparkles count={60} scale={[14, 12, 6]} position={[0, 0, -3]} size={2.2} speed={0.35} opacity={0.5} color="#a78bfa" />
    </>
  );
}

/** Gentle cinematic sway with an optional spin-in intro. */
export function Sway({
  amount = 0.35,
  intro = false,
  children,
}: {
  amount?: number;
  intro?: boolean;
  children: ReactNode;
}) {
  const ref = useRef<THREE.Group>(null);
  const start = useRef<number | null>(null);
  useFrame(({ clock }) => {
    const g = ref.current;
    if (!g) return;
    const t = clock.elapsedTime;
    if (start.current === null) start.current = t;
    const p = intro ? Math.min(1, (t - start.current) / 2.4) : 1;
    const ease = 1 - Math.pow(1 - p, 3);
    g.rotation.y = Math.sin(t * 0.45) * amount + (1 - ease) * -Math.PI * 1.5;
    g.rotation.x = -0.06 + Math.sin(t * 0.32) * amount * 0.18;
    g.scale.setScalar(0.6 + 0.4 * ease);
  });
  return <group ref={ref}>{children}</group>;
}
