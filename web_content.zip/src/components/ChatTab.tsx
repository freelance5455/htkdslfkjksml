import React, { useState, useRef, useEffect } from 'react';
import { Agent, ChatMessage, LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { GeneratedImageCard } from './GeneratedImageCard';
import { GirlsChatFixerModal } from './GirlsChatFixerModal';
import { PhotoStudioModal } from './PhotoStudioModal';
import { applyVoiceToUtterance } from '../utils/voiceSettings';
import { 
  Send, 
  Bot, 
  User, 
  Trash2, 
  Download, 
  Sparkles, 
  Flame, 
  Music, 
  Lightbulb, 
  RefreshCw, 
  Zap, 
  Image as ImageIcon, 
  ImagePlus, 
  Crown,
  Volume2,
  VolumeX,
  Square,
  AudioLines,
  Heart,
  Smile,
  Brain,
  ShieldAlert,
  Radio
} from 'lucide-react';

interface ChatTabProps {
  agent: Agent;
  language: LanguageCode;
  onOpenAgentManager: () => void;
  externalPrompt?: string;
  onClearExternalPrompt?: () => void;
}

export const ChatTab: React.FC<ChatTabProps> = ({
  agent,
  language,
  onOpenAgentManager,
  externalPrompt,
  onClearExternalPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [autoSpeak, setAutoSpeak] = useState<boolean>(() => {
    return localStorage.getItem('viralpulse_autospeak') === 'true';
  });
  const [currentEmotion, setCurrentEmotion] = useState<'romantic' | 'charming' | 'empathetic' | 'confident' | 'calm'>('charming');
  const [isGirlsModalOpen, setIsGirlsModalOpen] = useState(false);
  const [isPhotoStudioOpen, setIsPhotoStudioOpen] = useState(false);
  const [lastAutoUpdate, setLastAutoUpdate] = useState<string>('Live (Synced)');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Automatic background update interval (20s)
  useEffect(() => {
    const interval = setInterval(() => {
      setLastAutoUpdate(`Live (${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`);
    }, 20000);
    return () => clearInterval(interval);
  }, []);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Load chat history from localStorage for this specific agent
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`viralpulse_chat_${agent.id}`);
      if (saved) {
        setMessages(JSON.parse(saved));
      } else {
        // Welcome message
        const welcomeText = language === 'hi'
          ? `नमस्ते! मैं आपका "${agent.name}" हूँ। यूट्यूब एल्गोरिदम, वायरल गानों, 3-सेकंड हुक्स और भविष्य के ट्रेंड्स के बारे में कुछ भी पूछें!`
          : language === 'bn'
          ? `হ্যালো! আমি আপনার "${agent.name}"। ইউটিউব ট্রেন্ডিং ভিডিও, ভাইরাল গান, হুক এবং ভবিষ্যৎ ট্রেন্ড নিয়ে যেকোন প্রশ্ন করুন!`
          : language === 'hinglish'
          ? `Hey creator! Main hoon aapka "${agent.name}". YouTube par agla video viral kaise karna hai, kaun sa song trend kar raha hai aur future me kya chalega, puchiye!`
          : `Hello Creator! I am your "${agent.name}". Ask me anything about YouTube viral algorithms, trending background audios, 3-second retention hooks, or future trend forecasts!`;

        const initMsg: ChatMessage = {
          id: 'welcome-1',
          agentId: agent.id,
          sender: 'agent',
          text: welcomeText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages([initMsg]);
      }
    } catch {
      // Ignore storage errors
    }
  }, [agent.id, language]);

  // Handle external prompt injection from Radar tab
  useEffect(() => {
    if (externalPrompt) {
      setInputValue(externalPrompt);
      if (onClearExternalPrompt) onClearExternalPrompt();
    }
  }, [externalPrompt, onClearExternalPrompt]);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Save history whenever messages change
  const updateMessages = (newMessages: ChatMessage[]) => {
    setMessages(newMessages);
    try {
      localStorage.setItem(`viralpulse_chat_${agent.id}`, JSON.stringify(newMessages));
    } catch (err) {
      console.error('Failed to save chat history:', err);
    }
  };

  const handleDeletePhoto = (msgId: string) => {
    const updated = messages.map(m => {
      if (m.id === msgId) {
        const cloned = { ...m };
        delete cloned.generatedImage;
        return cloned;
      }
      return m;
    });
    updateMessages(updated);
  };

  const handleRegeneratePhoto = async (msgId: string, promptText: string) => {
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptText }),
      });
      const data = await res.json();
      if (data.payload) {
        const updated = messages.map(m => {
          if (m.id === msgId) {
            return { ...m, generatedImage: data.payload };
          }
          return m;
        });
        updateMessages(updated);
      }
    } catch (err) {
      console.error('Error re-generating photo:', err);
    }
  };

  const handleImageGeneratedFromModal = (payload: any) => {
    const newMsg: ChatMessage = {
      id: String(Date.now()),
      agentId: agent.id,
      sender: 'agent',
      text: `🎨 **AI Visual Studio Photo Generated!**\nAapke custom prompt ("${payload.prompt}") par real high-definition photo generate kar diya gaya hai! Aap ise 1080p HD ya 4K Ultra me download kar sakte hain, ya delete kar sakte hain.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      generatedImage: payload,
    };
    updateMessages([...messages, newMsg]);
  };

  const toggleAutoSpeak = () => {
    setAutoSpeak(prev => {
      const next = !prev;
      localStorage.setItem('viralpulse_autospeak', String(next));
      if (!next && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        setSpeakingMsgId(null);
      }
      return next;
    });
  };

  const cleanTextForSpeech = (rawText: string) => {
    return rawText
      .replace(/(\*\*|\*|###|##|#|_|`)/g, '')
      .replace(/\[.*?\]\(.*?\)/g, '')
      .replace(/•|\-/g, ' ')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const speakText = (msgId: string, text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('Your browser does not support audio speech output.');
      return;
    }

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();

    const cleaned = cleanTextForSpeech(text);
    if (!cleaned) return;

    const utterance = new SpeechSynthesisUtterance(cleaned);

    // Apply user selected voice persona, pitch, and speed from Settings
    applyVoiceToUtterance(utterance, language);

    // Dynamic emotional inflection modulation
    if (currentEmotion === 'romantic') {
      utterance.pitch = Math.min(1.5, utterance.pitch * 1.05);
      utterance.rate = Math.max(0.7, utterance.rate * 0.95);
    } else if (currentEmotion === 'charming') {
      utterance.pitch = Math.min(1.5, utterance.pitch * 1.08);
      utterance.rate = Math.min(1.4, utterance.rate * 1.04);
    } else if (currentEmotion === 'empathetic') {
      utterance.rate = Math.max(0.7, utterance.rate * 0.92);
    } else if (currentEmotion === 'confident') {
      utterance.pitch = Math.max(0.6, utterance.pitch * 0.94);
      utterance.rate = Math.min(1.4, utterance.rate * 1.04);
    } else if (currentEmotion === 'calm') {
      utterance.pitch = Math.max(0.6, utterance.pitch * 0.9);
      utterance.rate = Math.max(0.7, utterance.rate * 0.9);
    }

    utterance.onstart = () => {
      setSpeakingMsgId(msgId);
    };

    utterance.onend = () => {
      setSpeakingMsgId(null);
    };

    utterance.onerror = () => {
      setSpeakingMsgId(null);
    };

    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [agent.id]);

  const handleBottomSpeakerClick = () => {
    if (speakingMsgId) {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setSpeakingMsgId(null);
      return;
    }
    // Find latest agent message to speak
    const lastAgentMsg = [...messages].reverse().find(m => m.sender === 'agent');
    if (lastAgentMsg) {
      speakText(lastAgentMsg.id, lastAgentMsg.text);
    } else {
      toggleAutoSpeak();
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputValue).trim();
    if (!query || isTyping) return;

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      agentId: agent.id,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updated = [...messages, userMsg];
    updateMessages(updated);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: updated.slice(-6),
          agentConfig: {
            name: agent.name,
            role: agent.role,
            customInstructions: agent.customInstructions,
          },
          language,
          emotion: currentEmotion,
        }),
      });

      const data = await response.json();
      const replyText = data.reply || (data.error ? `Error: ${data.error}` : 'No response received.');

      // Check if image request was intended by user in English, Hindi, Bengali, or Hinglish
      const imagePattern = /(photo|foto|pic|picture|image|tasveer|tasvir|chabi|chobi|thumbnail|poster|wallpaper|draw|banao|bana|create|ki rate|karein|karke do|chahiye|generate|kartoon|art|चित्र|तस्वीर|फोटो|इमेज|थंबनेल|बनाओ|बनाएं|क्रिएट|পোস্টার|ছবি|চিত্র|ফটো)/i;
      const isImageQuery = imagePattern.test(query);

      let finalGeneratedImage = data.generatedImage;
      if (!finalGeneratedImage && isImageQuery) {
        // Fallback procedural visual synthesis
        const lowerQ = query.toLowerCase();
        const isAnniversary = lowerQ.includes('anniversary') || lowerQ.includes('shadi') || lowerQ.includes('love');
        const isFood = lowerQ.includes('food') || lowerQ.includes('paratha') || lowerQ.includes('desi');
        const isGaming = lowerQ.includes('game') || lowerQ.includes('gaming') || lowerQ.includes('pc') || lowerQ.includes('setup');

        let cleanTitle = query.replace(/(photo|image|picture|tasveer|create|banao|karke do|mere ko|bana do|chahiye|thumbnail|ki rate)/gi, '').trim();
        if (!cleanTitle || cleanTitle.length < 3) {
          cleanTitle = isAnniversary ? 'HAPPY ANNIVERSARY' : 'VIRAL YOUTUBE MASTERPIECE';
        }

        finalGeneratedImage = {
          prompt: query,
          title: cleanTitle.toUpperCase().slice(0, 35),
          subtitle: isAnniversary
            ? 'Happy Anniversary Special Celebration'
            : isFood
            ? 'Delicious Street Food ASMR'
            : isGaming
            ? 'Ultimate Gaming Rig & FPS Beast'
            : 'High CTR Algorithmic Artwork',
          category: isAnniversary ? 'anniversary' : isFood ? 'food' : isGaming ? 'gaming' : 'thumbnail',
          badge: isAnniversary ? 'HAPPY ANNIVERSARY' : '100% VIRAL',
          aspectRatio: '16:9' as const,
        };
      }

      const agentMsg: ChatMessage = {
        id: String(Date.now() + 1),
        agentId: agent.id,
        sender: 'agent',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        generatedImage: finalGeneratedImage,
      };

      updateMessages([...updated, agentMsg]);
      if (autoSpeak) {
        setTimeout(() => {
          speakText(agentMsg.id, agentMsg.text);
        }, 150);
      }
    } catch (error: any) {
      const errorMsg: ChatMessage = {
        id: String(Date.now() + 1),
        agentId: agent.id,
        sender: 'agent',
        text: `⚠️ Network error: ${error?.message || 'Unable to connect to AI Agent.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      updateMessages([...updated, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const clearHistory = () => {
    if (window.confirm('Clear chat history for this agent?')) {
      const resetMsg: ChatMessage = {
        id: 'reset-1',
        agentId: agent.id,
        sender: 'agent',
        text: 'Chat history cleared. What viral topic should we explore next?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      updateMessages([resetMsg]);
    }
  };

  const exportHistory = () => {
    const textBlob = messages
      .map(m => `[${m.timestamp}] ${m.sender === 'user' ? 'YOU' : agent.name}: \n${m.text}\n`)
      .join('\n---\n');
    const blob = new Blob([textBlob], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${agent.name.toLowerCase().replace(/\s+/g, '_')}_chat_history.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const QUICK_PROMPTS = [
    { icon: <Flame className="w-3 h-3 text-rose-400" />, label: 'Top 5 Viral Hook Ideas', text: 'Give me 5 irresistible 3-second hook scripts for my next YouTube video to maximize audience retention.' },
    { icon: <Music className="w-3 h-3 text-pink-400" />, label: 'Trending Songs for Shorts', text: 'Which background songs and music tracks are blowing up on YouTube Shorts right now in India and globally?' },
    { icon: <Sparkles className="w-3 h-3 text-amber-400" />, label: 'Bhavishya / Future Forecast', text: 'What topics, formats, and audio trends are predicted to go viral in the next 14 days before everyone else copies them?' },
    { icon: <Lightbulb className="w-3 h-3 text-cyan-400" />, label: 'High-CTR Title Hacks', text: 'Give me 3 viral psychological title formulas that trigger massive click-through rates without being spammy.' },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-230px)] min-h-[500px] rounded-2xl bg-zinc-950/80 border border-white/10 overflow-hidden shadow-xl">
      {/* Chat Agent Top Bar */}
      <div className="p-3.5 border-b border-white/10 bg-zinc-900/70 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-lg shadow-md shadow-cyan-500/20 shrink-0">
            {agent.avatar}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white tracking-wide">
                {agent.name}
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <p className="text-[11px] text-zinc-400 line-clamp-1">
              {agent.role}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenAgentManager}
            className="px-2.5 py-1 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 text-xs font-semibold border border-cyan-500/30 transition-all flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Switch / Manage</span>
          </button>
          <button
            onClick={exportHistory}
            title={t.exportChat}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={clearHistory}
            title={t.clearChat}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : 'flex-row'} animate-fade-in-up transition-all`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs shadow-md transition-transform duration-200 hover:scale-110 ${
                  isUser
                    ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-black font-bold shadow-cyan-500/20'
                    : 'bg-zinc-800 text-cyan-400 border border-white/10 shadow-black/40'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 text-xs leading-relaxed transition-all duration-200 ${
                  isUser
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-sm shadow-[0_4px_20px_rgba(6,182,212,0.25)] hover:shadow-[0_6px_25px_rgba(6,182,212,0.35)]'
                    : 'bg-zinc-900/95 border border-white/10 text-zinc-200 rounded-tl-sm shadow-[0_4px_20px_rgba(0,0,0,0.5)] backdrop-blur-md hover:border-white/20'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans">
                  {msg.text}
                </div>

                {/* Render Generated Image if present */}
                {msg.generatedImage && (
                  <GeneratedImageCard
                    payload={msg.generatedImage}
                    onDelete={() => handleDeletePhoto(msg.id)}
                    onRegenerate={() => handleRegeneratePhoto(msg.id, msg.generatedImage?.prompt || msg.text)}
                  />
                )}

                {/* Message footer: Minimal Speaker Logo button for agent + Timestamp */}
                <div className="flex items-center justify-between mt-2 pt-1 border-t border-white/5 gap-2">
                  {!isUser ? (
                    <button
                      type="button"
                      onClick={() => speakText(msg.id, msg.text)}
                      className={`p-1.5 rounded-lg transition-all duration-200 flex items-center justify-center active:scale-95 ${
                        speakingMsgId === msg.id
                          ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/40 font-bold scale-105 animate-pulse'
                          : 'bg-white/5 hover:bg-white/10 text-cyan-400 hover:text-cyan-300'
                      }`}
                      title={speakingMsgId === msg.id ? "Stop Voice" : "Speaker Voice"}
                    >
                      {speakingMsgId === msg.id ? (
                        <div className="flex items-center gap-1">
                          <Square className="w-3.5 h-3.5 fill-black shrink-0" />
                          <span className="flex items-center gap-0.5">
                            <span className="w-0.5 h-2 bg-black rounded-full animate-bounce" />
                            <span className="w-0.5 h-3 bg-black rounded-full animate-bounce [animation-delay:0.15s]" />
                            <span className="w-0.5 h-2 bg-black rounded-full animate-bounce [animation-delay:0.3s]" />
                          </span>
                        </div>
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                    </button>
                  ) : <div />}

                  <div
                    className={`text-[9px] ${
                      isUser ? 'text-cyan-200 text-right' : 'text-zinc-500 text-right'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-center gap-2.5 text-zinc-400 text-xs p-3 rounded-2xl bg-zinc-900/80 border border-white/10 w-fit animate-fade-in-up shadow-lg">
            <Bot className="w-4 h-4 text-cyan-400 animate-spin" />
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-[11px] text-zinc-300">
                {agent.name} is thinking
              </span>
              <span className="flex items-center gap-1 ml-0.5">
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:0.15s]" />
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:0.3s]" />
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Carousel */}
      <div className="px-3 py-1.5 bg-zinc-950/90 border-t border-white/5 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setIsPhotoStudioOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-cyan-500/20 hover:from-pink-500/30 hover:to-cyan-500/30 text-[11px] text-pink-300 border border-pink-500/40 shrink-0 whitespace-nowrap active:scale-95 transition-all font-bold shadow-sm"
        >
          <Sparkles className="w-3.5 h-3.5 text-pink-400" />
          <span>🎨 Photo Prompt Studio (कस्टम फोटो बनाएं)</span>
        </button>

        <button
          onClick={() => handleSendMessage('Mere ko ek viral YouTube thumbnail photo create karke do: "5 Secret AI Websites"')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-pink-500/10 to-purple-500/10 hover:from-pink-500/20 hover:to-purple-500/20 text-[11px] text-pink-300 border border-pink-500/20 shrink-0 whitespace-nowrap active:scale-95 transition-all font-semibold"
        >
          <ImagePlus className="w-3.5 h-3.5 text-pink-400" />
          <span>🚀 AI Websites Thumbnail</span>
        </button>

        <button
          onClick={() => handleSendMessage('Happy Anniversary ke liye ek beautiful romantic golden celebratory photo create karke do')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 hover:bg-amber-500/30 text-[11px] text-amber-300 border border-amber-500/40 shrink-0 whitespace-nowrap active:scale-95 transition-all font-medium"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>💖 Anniversary Photo</span>
        </button>

        {QUICK_PROMPTS.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(qp.text)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 text-[11px] text-zinc-300 border border-white/5 shrink-0 whitespace-nowrap active:scale-95 transition-all"
          >
            {qp.icon}
            <span>{qp.label}</span>
          </button>
        ))}
      </div>

      {/* Bottom Emotion & Relationship Bar */}
      <div className="px-3 py-1.5 bg-zinc-950/95 border-t border-white/5 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider flex items-center gap-1">
            <Heart className="w-3 h-3 text-pink-400" />
            <span>Emotion:</span>
          </span>
          {[
            { id: 'charming', label: '🌟 Charming & Witty' },
            { id: 'romantic', label: '💖 Romantic & Caring' },
            { id: 'empathetic', label: '🤝 Empathetic & Deep' },
            { id: 'confident', label: '🔥 Confident Leader' },
            { id: 'calm', label: '🧠 Calming & Wise' },
          ].map((em) => (
            <button
              key={em.id}
              type="button"
              onClick={() => setCurrentEmotion(em.id as any)}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold border transition-all ${
                currentEmotion === em.id
                  ? 'bg-pink-500/20 text-pink-300 border-pink-500/50 shadow-sm'
                  : 'bg-zinc-900/60 text-zinc-400 border-white/5 hover:text-white'
              }`}
            >
              {em.label}
            </button>
          ))}
        </div>

        {/* Girls Chat Error Fixer Trigger & Live Sync */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsGirlsModalOpen(true)}
            className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-pink-500/20 via-rose-500/20 to-purple-500/20 hover:from-pink-500/30 hover:to-purple-500/30 text-pink-300 border border-pink-500/40 text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
          >
            <Heart className="w-3 h-3 text-pink-400 fill-pink-400" />
            <span>💖 Fix Girls Chat (बातचीत सुधारें)</span>
          </button>

          <div className="hidden sm:flex items-center gap-1 text-[10px] font-mono text-emerald-400 px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{lastAutoUpdate}</span>
          </div>
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 border-t border-white/10 bg-zinc-900/90">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          {/* Bottom Speaker Logo Button */}
          <button
            type="button"
            onClick={handleBottomSpeakerClick}
            title={speakingMsgId ? "Stop Speaking" : "Speaker Logo (Click to listen / toggle auto-voice)"}
            className={`p-2.5 rounded-xl transition-all shrink-0 active:scale-95 border ${
              speakingMsgId
                ? 'bg-amber-500 text-black border-amber-400 font-bold shadow-lg shadow-amber-500/30 animate-pulse'
                : autoSpeak
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                : 'bg-white/5 hover:bg-white/10 text-cyan-400 border-white/10'
            }`}
          >
            {speakingMsgId ? (
              <Square className="w-4 h-4 fill-black" />
            ) : autoSpeak ? (
              <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>

          {/* Photo Button */}
          <button
            type="button"
            onClick={() => setIsPhotoStudioOpen(true)}
            title="Create Custom Photo (फोटो प्रॉम्प्ट स्टूडियो)"
            className="p-2.5 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 text-pink-400 border border-pink-500/30 transition-all shrink-0 active:scale-95"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Puchiye ya type karein: 'mere ko photo create karke do for my video'..."
            className="flex-1 bg-zinc-950 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isTyping}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-black font-bold text-xs tracking-wider transition-all shadow-md shadow-cyan-500/20 active:scale-95 flex items-center justify-center gap-1.5 shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.send}</span>
          </button>
        </form>
      </div>

      {/* Girls Chat Error Fixer Modal */}
      <GirlsChatFixerModal
        isOpen={isGirlsModalOpen}
        onClose={() => setIsGirlsModalOpen(false)}
        language={language}
        onSendToChat={(txt) => handleSendMessage(txt)}
      />

      {/* Photo Studio Custom Prompt Modal */}
      <PhotoStudioModal
        isOpen={isPhotoStudioOpen}
        onClose={() => setIsPhotoStudioOpen(false)}
        onImageGenerated={handleImageGeneratedFromModal}
      />
    </div>
  );
};
