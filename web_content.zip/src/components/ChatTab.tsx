import React, { useState, useRef, useEffect } from 'react';
import { Send, Volume2, ShieldAlert, CheckCircle2, AlertTriangle, Sparkles, ExternalLink } from 'lucide-react';
import { ChatMessage, ActionProposal, SupportedLanguage, UserMemory } from '../types';
import { sendMessageToDost } from '../services/api';
import { Brain } from 'lucide-react';

interface ChatTabProps {
  language: SupportedLanguage;
  onExecuteAction: (action: ActionProposal) => void;
  onNavigateToTab: (tab: string) => void;
  memories?: UserMemory[];
  onSaveMemory?: (fact: string) => void;
}

export const ChatTab: React.FC<ChatTabProps> = ({
  language,
  onExecuteAction,
  onNavigateToTab,
  memories = [],
  onSaveMemory,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'init-1',
      role: 'assistant',
      content:
        language === 'urdu'
          ? 'السلام علیکم! میں ہوں دوست اے آئی، آپ کا ذاتی اینڈرائیڈ اسسٹنٹ۔ فون کے کام، کرپٹو مارکیٹ تجزیہ، پیغامات یا کوئی بھی سوال ہو، میں تیار ہوں۔'
          : language === 'roman_urdu'
          ? 'Salam bhai! Main aap ka DOST AI hoon — aap ka personal Android companion. Phone ke operations, apps, daily signals, crypto market analysis, ya koi bhi sawal ho, hukum karein!'
          : 'Hello! I am DOST AI, your personal native Android assistant. I can help with phone operations, crypto market analysis, messaging, notes, and everyday tasks. What shall we do today?',
      timestamp: Date.now(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isAutoPilot, setIsAutoPilot] = useState<boolean>(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputValue('');
    setIsLoading(true);

    try {
      // Build conversation payload for Gemini
      const historyPayload = newMessages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await sendMessageToDost(historyPayload, language, memories);

      if (res.newMemory && onSaveMemory) {
        onSaveMemory(res.newMemory);
      }

      // If app code was generated, store it in local storage for App Studio
      if (res.appCode && res.appCode.code) {
        try {
          const saved = localStorage.getItem('dost_generated_apps');
          const existing = saved ? JSON.parse(saved) : [];
          const newApp = {
            id: `app-${Date.now()}`,
            title: res.appCode.title || 'DOST AI App',
            description: `Generated for: "${text.slice(0, 30)}..."`,
            type: res.appCode.type || 'html',
            createdAt: Date.now(),
            code: res.appCode.code,
          };
          localStorage.setItem('dost_generated_apps', JSON.stringify([newApp, ...existing]));
        } catch {
          // ignore
        }
      }

      const botMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: res.reply,
        timestamp: Date.now(),
        actionProposal: res.action,
        actionExecuted: false,
        appCode: res.appCode || undefined,
      };

      setMessages((prev) => [...prev, botMsg]);

      // AUTO-PILOT EXECUTION: If action is safe and auto-pilot is on, execute automatically!
      if (isAutoPilot && res.action && !res.action.isSensitive) {
        setTimeout(() => {
          botMsg.actionExecuted = true;
          onExecuteAction(res.action!);
          setMessages((prev) => [...prev]);
        }, 600);
      }
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `Dost AI Error: ${err.message || 'System busy. Please try again.'}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const speakText = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    if (speakingMessageId === id) {
      setSpeakingMessageId(null);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    if (language === 'urdu') {
      utterance.lang = 'ur-PK';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);

    setSpeakingMessageId(id);
    window.speechSynthesis.speak(utterance);
  };

  const samplePrompts =
    language === 'roman_urdu'
      ? [
          '📱 Download APK link aur Install kaise karein',
          'Ek game app banao coding karke',
          'Torch on karo please',
          'Phone vibrate karo',
          'BTC 4H analysis aur EMA batao',
          'Speaker saaf karo water eject tone se',
          'Crypto Profit Calculator app banao',
        ]
      : language === 'urdu'
      ? [
          '📱 اے پی کے ڈاؤنلوڈ لنک اور انسٹال کا طریقہ',
          'ایک گیم ایپ بنائیں کوڈنگ کر کے',
          'ٹارچ آن کریں',
          'فون وائبریٹ کریں',
          'بی ٹی سی کا ٹرینڈ کیا ہے؟',
          'سپیکر صاف کرنے کا ساؤنڈ چلائیں',
        ]
      : [
          '📱 Download APK & Mobile Installation Link',
          'Code a mini retro game app',
          'Turn on flashlight',
          'Vibrate phone',
          'Analyze Bitcoin 4h trend with EMAs',
          'Run speaker water ejection sound',
        ];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100">
      {/* Top Auto-Pilot & Mode Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-900/90 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-bold text-slate-200">DOST AI Ultra Engine</span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
            Failover Ready
          </span>
        </div>

        <button
          onClick={() => setIsAutoPilot(!isAutoPilot)}
          className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 transition-all ${
            isAutoPilot
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-800 text-slate-400 border border-slate-700'
          }`}
          title="When ON, DOST executes safe phone actions automatically without needing manual confirmation"
        >
          <Sparkles className="w-2.5 h-2.5" />
          <span>Auto-Pilot: {isAutoPilot ? 'ON' : 'OFF'}</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-md text-sm ${
                  isUser
                    ? 'bg-cyan-600 text-white rounded-br-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none'
                }`}
              >
                {!isUser && (
                  <div className="flex items-center justify-between gap-2 mb-1 border-b border-slate-800/80 pb-1">
                    <span className="text-[11px] font-bold text-cyan-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-cyan-400" /> DOST AI
                    </span>
                    <button
                      onClick={() => speakText(msg.content, msg.id)}
                      className="text-slate-400 hover:text-cyan-300 p-0.5 rounded transition-colors"
                      title="Read aloud"
                    >
                      <Volume2 className={`w-3.5 h-3.5 ${speakingMessageId === msg.id ? 'text-cyan-400 animate-pulse' : ''}`} />
                    </button>
                  </div>
                )}

                <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>

                {/* Generated App Card */}
                {msg.appCode && (
                  <div className="mt-3 p-3 rounded-2xl bg-gradient-to-r from-cyan-950/60 to-slate-950 border border-cyan-500/40 shadow-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
                          ⚡
                        </div>
                        <div>
                          <span className="text-xs font-bold text-white block">{msg.appCode.title}</span>
                          <span className="text-[10px] text-cyan-300/80 font-mono">Executable HTML5 Application</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigateToTab('app_studio')}
                      className="w-full py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all"
                    >
                      <span>▶ Launch in DOST App Studio</span>
                    </button>
                  </div>
                )}

                {/* Proposed Action Card */}
                {msg.actionProposal && (
                  <div className="mt-3 p-3 rounded-xl bg-slate-950/80 border border-cyan-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                        Android Action Proposal
                      </span>
                      {msg.actionProposal.isSensitive ? (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                          <ShieldAlert className="w-2.5 h-2.5" /> Requires Confirm
                        </span>
                      ) : (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          {isAutoPilot ? '⚡ Auto-Executed' : 'Allowlist Safe'}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-300 mb-2">
                      <span className="text-slate-500">Action:</span> <code className="text-cyan-300">{msg.actionProposal.type}</code>
                      {msg.actionProposal.target && (
                        <> | <span className="text-slate-500">Target:</span> {msg.actionProposal.target}</>
                      )}
                      {msg.actionProposal.recipient && (
                        <> | <span className="text-slate-500">To:</span> {msg.actionProposal.recipient}</>
                      )}
                    </p>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onExecuteAction(msg.actionProposal!);
                          msg.actionExecuted = true;
                          setMessages([...messages]);
                        }}
                        className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                          msg.actionProposal.isSensitive
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                            : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
                        }`}
                      >
                        {msg.actionExecuted ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-950" />
                            Dispatched to Intent
                          </>
                        ) : (
                          <>
                            <ExternalLink className="w-3.5 h-3.5" />
                            {msg.actionProposal.label || 'Execute Android Intent'}
                          </>
                        )}
                      </button>

                      {msg.actionProposal.type === 'analyze_crypto' && (
                        <button
                          onClick={() => onNavigateToTab('crypto')}
                          className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700"
                        >
                          View Chart
                        </button>
                      )}

                      {msg.actionProposal.type === 'create_app' && (
                        <button
                          onClick={() => onNavigateToTab('app_studio')}
                          className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700"
                        >
                          App Studio
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
              <span className="text-[10px] text-slate-600 mt-1 px-1">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 p-3 bg-slate-900/80 rounded-2xl w-fit border border-slate-800">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.2s]" />
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.4s]" />
            <span className="text-xs text-slate-400 ml-1">DOST soch raha hai...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="px-3 py-1.5 bg-slate-950/90 border-t border-slate-900 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {samplePrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-900 text-slate-400 hover:text-cyan-300 hover:bg-slate-800 border border-slate-800 transition-colors"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 bg-slate-900 border-t border-slate-800/80">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={
              language === 'urdu'
                ? 'دوست سے کچھ بھی پوچھیں...'
                : language === 'roman_urdu'
                ? 'Dost se baat karein ya phone task batayein...'
                : 'Type a message or command for DOST...'
            }
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors placeholder:text-slate-600"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 disabled:hover:bg-cyan-500 text-slate-950 font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
