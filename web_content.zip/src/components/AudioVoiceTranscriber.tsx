import React, { useState, useRef } from 'react';
import { Mic, MicOff, Loader2 } from 'lucide-react';

interface AudioVoiceTranscriberProps {
  onTranscribeComplete: (text: string) => void;
  lang?: 'bn' | 'en';
  buttonClassName?: string;
  size?: 'sm' | 'md';
}

export const AudioVoiceTranscriber: React.FC<AudioVoiceTranscriberProps> = ({
  onTranscribeComplete,
  lang = 'bn',
  buttonClassName,
  size = 'md',
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop());

        // Send to backend for gemini-3.5-transcribe
        await sendToTranscribe(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Microphone access error:', err);
      alert(lang === 'bn' ? 'মাইক্রোফোন অ্যাক্সেস করতে সমস্যা হয়েছে।' : 'Microphone permission denied.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const sendToTranscribe = async (audioBlob: Blob) => {
    setIsTranscribing(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const res = await fetch('/api/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64Data,
            mimeType: 'audio/webm',
          }),
        });

        const data = await res.json();
        if (data.success && data.text) {
          onTranscribeComplete(data.text);
        } else {
          console.warn('Transcription empty or failed', data);
        }
        setIsTranscribing(false);
      };
    } catch (e) {
      console.error('Transcription error:', e);
      setIsTranscribing(false);
    }
  };

  return (
    <button
      type="button"
      onClick={isRecording ? stopRecording : startRecording}
      disabled={isTranscribing}
      title={
        isRecording
          ? lang === 'bn' ? 'রেকর্ডিং বন্ধ করুন' : 'Stop recording'
          : lang === 'bn' ? 'ভয়েস দিয়ে বলুন (gemini-3.5-transcribe)' : 'Voice search / input'
      }
      className={
        buttonClassName ||
        `p-2 rounded-xl transition-all flex items-center justify-center cursor-pointer ${
          isRecording
            ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-500/30'
            : isTranscribing
            ? 'bg-amber-100 text-amber-700'
            : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
        }`
      }
    >
      {isTranscribing ? (
        <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
      ) : isRecording ? (
        <MicOff className="w-4 h-4" />
      ) : (
        <Mic className="w-4 h-4" />
      )}
    </button>
  );
};
