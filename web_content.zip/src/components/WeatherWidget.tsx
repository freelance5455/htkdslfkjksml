import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sun,
  CloudSun,
  Cloud,
  CloudDrizzle,
  CloudRain,
  CloudLightning,
  Droplets,
  Wind,
  Compass,
  MapPin,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  CalendarCheck,
  ChevronRight,
  Sprout,
  XCircle,
} from 'lucide-react';
import { DailyForecast, Language, WeatherCondition } from '../types';
import { FIVE_DAY_FORECAST } from '../data/mockData';
import { playKeyTap } from '../utils/audio';

interface WeatherWidgetProps {
  language: Language;
  region?: string;
  onSelectDay?: (forecast: DailyForecast) => void;
}

export default function WeatherWidget({
  language,
  region = 'Morogoro',
}: WeatherWidgetProps) {
  const isSw = language === 'sw';
  const [forecasts] = useState<DailyForecast[]>(FIVE_DAY_FORECAST);
  const [selectedDayId, setSelectedDayId] = useState<string>(FIVE_DAY_FORECAST[0].id);

  const selectedDay =
    forecasts.find((f) => f.id === selectedDayId) || forecasts[0];

  // Helper to render weather icons with appropriate styling
  const renderWeatherIcon = (condition: WeatherCondition, sizeClass = 'w-6 h-6') => {
    switch (condition) {
      case 'sunny':
        return <Sun className={`${sizeClass} text-amber-400 animate-spin-slow`} />;
      case 'partly-cloudy':
        return <CloudSun className={`${sizeClass} text-amber-300`} />;
      case 'cloudy':
        return <Cloud className={`${sizeClass} text-slate-300`} />;
      case 'light-rain':
        return <CloudDrizzle className={`${sizeClass} text-sky-400`} />;
      case 'heavy-rain':
        return <CloudRain className={`${sizeClass} text-blue-400`} />;
      case 'thunderstorm':
        return <CloudLightning className={`${sizeClass} text-amber-300`} />;
      default:
        return <Sun className={`${sizeClass} text-amber-400`} />;
    }
  };

  const getActivityColor = (type: DailyForecast['activityType']) => {
    switch (type) {
      case 'planting':
        return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30';
      case 'spraying':
        return 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30';
      case 'harvesting':
        return 'bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30';
      case 'weeding':
        return 'bg-lime-500/15 text-lime-700 dark:text-lime-300 border-lime-500/30';
      case 'rest':
        return 'bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30';
      default:
        return 'bg-[var(--line)] text-[var(--ink)] border-[var(--line)]';
    }
  };

  return (
    <div
      id="weather-widget"
      className="w-full rounded-3xl p-4 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-3.5 transition-all"
    >
      {/* Top Header: Location, Date & Active Forecast Headline */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--forest)]">
          <MapPin className="w-3.5 h-3.5" />
          <span>{region}, Tanzania</span>
          <span className="text-[10px] opacity-60">· {isSw ? 'Utabiri wa Siku 5' : '5-Day Agro Forecast'}</span>
        </div>
        <div className="flex items-center gap-1 text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded-full">
          <Sparkles className="w-3 h-3" />
          <span>{isSw ? 'Ushauri wa Kilimo' : 'Agronomy AI'}</span>
        </div>
      </div>

      {/* Hero Card for the Selected Day */}
      <div
        className="rounded-2xl p-4 text-[#F7F4E9] shadow-md relative overflow-hidden"
        style={{
          background:
            selectedDay.condition === 'sunny'
              ? 'linear-gradient(135deg, #2B4E3C 0%, #3D6B52 50%, #8A6828 100%)'
              : selectedDay.condition.includes('rain')
              ? 'linear-gradient(135deg, #1C332A 0%, #26473B 60%, #2D4C63 100%)'
              : 'linear-gradient(135deg, #243D32 0%, #2E5343 100%)',
        }}
      >
        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-amber-200 font-semibold flex items-center gap-1.5">
              <span>{isSw ? selectedDay.daySw : selectedDay.dayEn}</span>
              <span className="opacity-60">({selectedDay.dateStr})</span>
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-display text-4xl font-bold">{selectedDay.tempMax}°</span>
              <span className="text-sm opacity-75">/ {selectedDay.tempMin}°C</span>
            </div>
            <div className="text-xs font-medium text-emerald-100/90 mt-1">
              {isSw ? selectedDay.soilMoistureSw : selectedDay.soilMoistureEn}
            </div>
          </div>

          <div className="flex flex-col items-end">
            <div className="p-2 rounded-2xl bg-black/20 backdrop-blur-md mb-1">
              {renderWeatherIcon(selectedDay.condition, 'w-9 h-9')}
            </div>
            <div className="flex items-center gap-1 text-xs text-sky-200 font-semibold bg-black/20 px-2 py-0.5 rounded-full">
              <Droplets className="w-3 h-3" />
              <span>{selectedDay.rainChance}% {isSw ? 'mvua' : 'rain'}</span>
            </div>
          </div>
        </div>

        {/* Action Recommendation Banner */}
        <div className="mt-3.5 pt-3 border-t border-white/15 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-200">
              {isSw ? selectedDay.recommendedActivitySw : selectedDay.recommendedActivityEn}
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px] opacity-85">
            <span className="flex items-center gap-1">
              <Wind className="w-3 h-3" /> {selectedDay.windSpeedKmh} km/h
            </span>
            <span className="flex items-center gap-1">
              <Droplets className="w-3 h-3" /> {selectedDay.humidity}%
            </span>
          </div>
        </div>
      </div>

      {/* 5-Day Horizontal Forecast Strip */}
      <div>
        <div className="text-[11px] font-bold uppercase tracking-wider text-[var(--ink-soft)] mb-2 flex items-center justify-between">
          <span>{isSw ? 'Chagua Siku Kupanga Kazi' : 'Tap Day to Plan Field Work'}</span>
          <span className="text-[10px] font-normal opacity-70">
            {isSw ? 'Bofya kubadilisha' : 'Click day to inspect'}
          </span>
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          {forecasts.map((f) => {
            const isSelected = f.id === selectedDayId;
            return (
              <button
                key={f.id}
                id={`forecast-day-btn-${f.id}`}
                onClick={() => {
                  playKeyTap();
                  setSelectedDayId(f.id);
                }}
                className={`py-2 px-1 rounded-2xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] shadow-md scale-[1.02]'
                    : 'bg-[var(--bg)] text-[var(--ink)] border-[var(--line)] hover:border-[var(--forest)]/50'
                }`}
              >
                <span className="text-[10px] font-bold">
                  {isSw ? f.daySw : f.dayEn}
                </span>

                <div className="my-0.5">
                  {renderWeatherIcon(f.condition, 'w-5 h-5')}
                </div>

                <div className="text-[10px] font-bold font-display">
                  {f.tempMax}°
                </div>

                {/* Rain probability chip */}
                <div
                  className={`text-[9px] font-semibold flex items-center gap-0.5 px-1 rounded-full ${
                    isSelected
                      ? 'bg-black/25 text-sky-200'
                      : f.rainChance > 50
                      ? 'bg-blue-500/15 text-blue-700 dark:text-blue-300'
                      : 'text-[var(--ink-soft)]'
                  }`}
                >
                  <Droplets className="w-2.5 h-2.5" />
                  <span>{f.rainChance}%</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Detailed Agronomic Planting & Spraying Advisory for Selected Day */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedDay.id}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.2 }}
          className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-2.5 text-xs"
        >
          <div className="flex items-center justify-between">
            <div className="font-bold text-[var(--ink)] flex items-center gap-1.5">
              <Sprout className="w-4 h-4 text-[var(--forest)]" />
              <span>
                {isSw
                  ? `Mwongozo wa Kilimo: ${selectedDay.daySw} (${selectedDay.dateStr})`
                  : `Agronomy Guide: ${selectedDay.dayEn} (${selectedDay.dateStr})`}
              </span>
            </div>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getActivityColor(
                selectedDay.activityType
              )}`}
            >
              {isSw ? selectedDay.recommendedActivitySw : selectedDay.recommendedActivityEn}
            </span>
          </div>

          <p className="text-[11px] text-[var(--ink-soft)] leading-relaxed">
            {isSw ? selectedDay.plantingAdviceSw : selectedDay.plantingAdviceEn}
          </p>

          {/* Activity suitability checklist */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="flex items-center gap-1.5 text-[11px]">
              {selectedDay.condition.includes('rain') ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <span className="font-medium text-[var(--ink)]">
                    {isSw ? 'Kupanda Mbegu: Inafaa Sana' : 'Planting: Recommended'}
                  </span>
                </>
              ) : (
                <>
                  <CalendarCheck className="w-3.5 h-3.5 text-[var(--forest)] flex-shrink-0" />
                  <span className="text-[var(--ink-soft)]">
                    {isSw ? 'Kupanda: Umwagiliaji' : 'Planting: Needs Drip'}
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-1.5 text-[11px]">
              {selectedDay.condition === 'heavy-rain' || selectedDay.rainChance > 60 ? (
                <>
                  <XCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
                  <span className="font-medium text-red-600 dark:text-red-400">
                    {isSw ? 'Kupulizia: Usipulizie' : 'Spraying: Do Not Spray'}
                  </span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <span className="font-medium text-[var(--ink)]">
                    {isSw ? 'Kupulizia: Siku Salama' : 'Spraying: Safe Window'}
                  </span>
                </>
              )}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
