import React from 'react';
import { ClassInfo, Language, Student } from '../types';
import { translations } from '../utils/translations';
import {
  GraduationCap,
  Calendar,
  Users,
  CheckCircle2,
  DollarSign,
  BookOpen,
  FileText,
  Award,
  Video,
  MapPin,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Phone,
  MessageCircle
} from 'lucide-react';

interface HomeOverviewViewProps {
  students: Student[];
  classes: ClassInfo[];
  lang: Language;
  onNavigate: (tab: string) => void;
  centerLogoUrl: string;
}

export const HomeOverviewView: React.FC<HomeOverviewViewProps> = ({
  students,
  classes,
  lang,
  onNavigate,
  centerLogoUrl,
}) => {
  const t = translations[lang];

  const activeStudents = students.filter((s) => !s.isGraduated);
  const graduatedStudents = students.filter((s) => s.isGraduated);
  const paidStudents = activeStudents.filter((s) => s.feeStatus === 'paid');
  const unpaidStudents = activeStudents.filter((s) => s.feeStatus === 'unpaid');
  const totalRevenueCollected = paidStudents.reduce((acc, s) => acc + s.feeAmount, 0);

  const quickFeatures = [
    {
      id: 'classes',
      title: t.navClasses,
      desc: lang === 'ps'
        ? 'له Elementary A څخه تر Advanced پورې ټولګي، ټاکلی وخت، د ګرامر او Speaking ساعتونه'
        : lang === 'ur'
        ? 'ایلیمنٹری اے سے ایڈوانسڈ تک کلاسز، مقررہ اوقات اور گرامر و اسپیکنگ گھنٹے'
        : 'Elementary A to Advanced classes, fixed start/end times, and weekly grammar & speaking hours.',
      icon: Calendar,
      color: 'bg-blue-500/10 text-blue-600 border-blue-200'
    },
    {
      id: 'students',
      title: t.navStudents,
      desc: lang === 'ps'
        ? 'د زده کوونکي، د پلار نوم، ټولګي، مقام، بااخلاقه یا سست زده کوونکي او عکس لټون'
        : lang === 'ur'
        ? 'طلباء، والد کا نام، کلاس، پوزیشن، اخلاقی کیفیت اور تصاویر کی فوری تلاش'
        : 'Student profiles with photo upload, father name, class, honors position, and conduct rating.',
      icon: Users,
      color: 'bg-emerald-500/10 text-emerald-600 border-emerald-200'
    },
    {
      id: 'attendance',
      title: t.navAttendance,
      desc: lang === 'ps'
        ? 'د غیر حاضرو زده کوونکو پلارانو ته په واټس‌اپ باندې په یوه کلیک فوري خبرتیا استول'
        : lang === 'ur'
        ? 'غیر حاضر طالب علم کے والد کو ایک کلک سے فوری واٹس ایپ الرٹ ارسال کریں'
        : 'Daily class attendance with instant one-click WhatsApp absence alerts sent to fathers.',
      icon: MessageCircle,
      color: 'bg-green-500/10 text-green-600 border-green-200'
    },
    {
      id: 'fees',
      title: t.navFees,
      desc: lang === 'ps'
        ? 'د هر زده کوونکي د فیس حالت: ✅ ورکړل شوی او ❌ باقي پاتې نښه، او د رسید چاپ'
        : lang === 'ur'
        ? 'فیس کی صورتحال: ادا شدہ پر ✅ اور نادہندہ پر ❌ کا نشان، اور فیس سلپ پرنٹ'
        : 'Fee tracker with correct ✅ mark for paid and wrong ❌ mark for unpaid, plus receipt printing.',
      icon: DollarSign,
      color: 'bg-amber-500/10 text-amber-600 border-amber-200'
    },
    {
      id: 'parchi',
      title: t.navParchi,
      desc: lang === 'ps'
        ? 'د ټولګیو لپاره د معیاري امتحاني پرچو (Parchi) جوړول، چاپ او په ګوګل ډرایو کې ثبت'
        : lang === 'ur'
        ? 'کلاس کے طلباء کے لیے معیاری امتحانی پرچہ (پرچی) تیار کریں اور پرنٹ کریں'
        : 'Generate examination test papers (Parchi) with header, MCQs, and Google Drive cloud saving.',
      icon: FileText,
      color: 'bg-indigo-500/10 text-indigo-600 border-indigo-200'
    },
    {
      id: 'graduates',
      title: t.navGraduates,
      desc: lang === 'ps'
        ? 'د فارغو زده کوونکو د فراغت نېټه او وخت، او د رسمي ستاینلیکونو چاپ'
        : lang === 'ur'
        ? 'فارغ التحصیل طلباء کی فراغت کی تاریخ، وقت اور اسناد کی تفصیلات'
        : 'Alumni graduation records with recorded date & time, honors, and certificate printing.',
      icon: Award,
      color: 'bg-purple-500/10 text-purple-600 border-purple-200'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 text-white p-8 sm:p-12 border border-emerald-700/50 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-3.5 py-1.5 rounded-full text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Trat, Pishin, Balochistan • Official Educational Portal</span>
          </div>

          <div className="flex items-center gap-4 pt-1">
            <img
              src={centerLogoUrl}
              alt="Rahbar English Center"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-2 ring-emerald-400/80 shadow-lg bg-slate-900"
            />
            <div>
              <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white">
                {t.centerName}
              </h1>
              <p className="text-emerald-400 font-bold text-sm sm:text-base mt-0.5">
                {t.centerTagline}
              </p>
            </div>
          </div>

          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
            {lang === 'ps'
              ? 'ښه راغلاست د رهبر انګلیسي مرکز ته په ترات، پشین، بلوچستان. دلته لومړني ټولګي تر پرمختللي پړاو پورې په هرو ۲ میاشتو کې تنویر مومي، او Advanced کورس ۴ میاشتې دی. زموږ د مدیریت سیستم د حاضري واټس‌اپ خبرتیاوې، فیسونه او امتحاني پرچې په تر ټولو ښکلي بڼه تنظیموي.'
              : lang === 'ur'
              ? 'خوش آمدید! رہبر انگلش سینٹر ترات، پشین، بلوچستان۔ یہاں ایلیمنٹری سے ایڈوانسڈ تک ہر ۲ ماہ بعد نئی کلاس کا آغاز ہوتا ہے جبکہ ایڈوانسڈ ڈپلومہ ۴ ماہ پر مشتمل ہے۔ یہ پورٹل روزانہ حاضری، والد کو واٹس ایپ الرٹس، فیس ریکارڈ اور امتحانی پرچوں کی تیاری کو منظم بناتا ہے۔'
              : 'Welcome to Rahbar English Center, located in Trat, Pishin, Balochistan. We provide structured English education from Elementary A to 4-month Advanced diploma (2 months Junior Advanced & 2 months Senior Advanced). Manage attendance with instant WhatsApp alerts to fathers, fee tracking, test paper generation, and student records.'}
          </p>

          {/* Quick Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('students')}
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-5 py-2.5 rounded-2xl text-xs shadow-lg shadow-emerald-900/50 transition"
            >
              <Users className="w-4 h-4" />
              <span>{t.navStudents}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onNavigate('attendance')}
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 font-extrabold px-5 py-2.5 rounded-2xl text-xs transition"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>{t.navAttendance}</span>
            </button>

            <button
              onClick={() => onNavigate('parchi')}
              className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black px-5 py-2.5 rounded-2xl text-xs shadow transition"
            >
              <FileText className="w-4 h-4" />
              <span>{t.navParchi}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Statistics Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigate('students')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              {t.totalStudents}
            </span>
            <span className="text-2xl font-black text-slate-900 mt-0.5 block">
              {activeStudents.length}
            </span>
            <span className="text-[11px] font-bold text-emerald-600">
              Active Enrolled
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('classes')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Batches
            </span>
            <span className="text-2xl font-black text-slate-900 mt-0.5 block">
              {classes.length}
            </span>
            <span className="text-[11px] font-bold text-slate-600">
              Boys & Girls Wings
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('fees')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Fees Paid / Collected
            </span>
            <span className="text-2xl font-black text-emerald-600 mt-0.5 block">
              PKR {totalRevenueCollected.toLocaleString()}
            </span>
            <span className="text-[11px] font-bold text-slate-500">
              ✅ {paidStudents.length} Paid | ❌ {unpaidStudents.length} Unpaid
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('graduates')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              {t.graduatedAlumni}
            </span>
            <span className="text-2xl font-black text-purple-700 mt-0.5 block">
              {graduatedStudents.length}
            </span>
            <span className="text-[11px] font-bold text-purple-600">
              Senior Advanced
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Feature Exploration Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-black text-slate-900">
            {lang === 'ps' ? 'د مرکز مهمې برخې' : lang === 'ur' ? 'سینٹر کے اہم شعبہ جات' : 'Key Modules & Portals'}
          </h3>
          <span className="text-xs text-slate-500 font-medium">Quick Access</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {quickFeatures.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.id}
                onClick={() => onNavigate(feat.id)}
                className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between group"
              >
                <div className="space-y-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${feat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-extrabold text-slate-900 group-hover:text-emerald-700 transition-colors">
                    {feat.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-emerald-700 group-hover:translate-x-1 transition-transform">
                  <span>Open Module</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Center Details & Location Info */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
            <MapPin className="w-4 h-4" />
            <span>Permanent Location & Campus</span>
          </div>
          <h3 className="text-xl font-black text-white">
            Rahbar English Center - Trat, Pishin
          </h3>
          <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
            Main Campus: Trat, District Pishin, Balochistan, Pakistan.<br />
            Featuring separate shifts for Male and Female students with specialized instructors in English Phonetics, Advanced Grammar, and Spoken Fluency.
          </p>
        </div>

        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs text-slate-300 shrink-0">
          <div className="flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Official Helpline: <strong>+92 312 3456789</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Timing: <strong>08:00 AM - 07:00 PM</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>Director: <strong>Sir Habibullah Rahbar</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
