import React, { useState } from 'react';
import { sarfTopics, sarfRules } from '../data/sarfRules';
import { RuleCard } from './RuleCard';
import { useLanguage } from '../context/LanguageContext';
import {
  Layers,
  Search,
  BookOpen,
  Filter,
  CheckCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';

interface SarfViewProps {
  initialRuleId?: string | null;
}

export const SarfView: React.FC<SarfViewProps> = ({ initialRuleId }) => {
  const { language, getText } = useLanguage();
  const [selectedTopicId, setSelectedTopicId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredRules = sarfRules.filter((rule) => {
    // Topic filter
    if (selectedTopicId !== 'all' && rule.topicId !== selectedTopicId) {
      return false;
    }
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const inArabic = rule.arabicTitle.toLowerCase().includes(q);
      const inPs = rule.title.pashto.toLowerCase().includes(q) || rule.summary.pashto.toLowerCase().includes(q);
      const inUr = rule.title.urdu.toLowerCase().includes(q) || rule.summary.urdu.toLowerCase().includes(q);
      const inEn = rule.title.english.toLowerCase().includes(q) || rule.summary.english.toLowerCase().includes(q);
      const inTags = rule.tags.some((t) => t.toLowerCase().includes(q));
      return inArabic || inPs || inUr || inEn || inTags;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-amber-950 text-white p-6 sm:p-8 rounded-3xl border border-amber-500/20 shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-3">
            <Layers className="w-3.5 h-3.5" />
            <span>
              {language === 'pashto'
                ? 'د علم الصرف تفصیلي قواعد'
                : language === 'urdu'
                ? 'علم الصرف کے مکمل قواعد و ضوابط'
                : 'Complete Arabic Morphology (Ilm-e-Sarf)'}
            </span>
          </div>

          <h2 className="font-arabic text-3xl sm:text-4xl font-bold text-amber-200 mb-2">
            عِلْمُ الصَّرْفِ: بِنْيَةُ الْكَلِمَةِ وَأَبْوَابُ التَّصْرِيفِ
          </h2>

          <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
            {language === 'pashto'
              ? 'د عربي ژبې د کلمو جوړښت، د ثلاثي مجرد شپږ واړه ابواب (نصر، ضرب، سمع، فتح، حسب، کرم)، مزید فیه، هفت اقسام، او د تعلیلاتو قوانین په پښتو، اردو او انګلیسي تشریح سره.'
              : language === 'urdu'
              ? 'کلمات کی ساخت، ثلاثی مجرد کے ۶ ابواب، ثلاثی مزید فیہ کے اوزان، ہفت اقسام اور تعلیلات کے تمام سنہری قوانین مکمل مثالوں کے ساتھ۔'
              : 'Explore the internal architecture of Arabic words, triliteral Form I chapters (Nasara, Daraba, Sami\'a, Fataha, Karuma, Hasiba), derived forms, Haft Aqsaam root classes, and morphophonemic rules of Ta\'leel.'}
          </p>
        </div>
      </div>

      {/* Search & Topic Filters */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-5 h-5 text-stone-400 absolute left-4 rtl:left-auto rtl:right-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              language === 'pashto'
                ? 'په صرفي قواعدو، ابوابو، عربي، پښتو، اردو یا انګلیسي کې لټون وکړئ...'
                : language === 'urdu'
                ? 'ابواب، اوزان، عربی، اردو، پشتو یا انگریزی الفاظ میں تلاش کریں...'
                : 'Search rules by Arabic title, Bab, Pashto, Urdu, or English keywords...'
            }
            className="w-full pl-12 pr-4 rtl:pl-4 rtl:pr-12 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-stone-50/60 text-sm font-medium"
          />
        </div>

        {/* Topic Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedTopicId('all')}
            className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              selectedTopicId === 'all'
                ? 'bg-emerald-800 text-amber-200 shadow-xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            {language === 'pashto' ? 'ټول قواعد' : language === 'urdu' ? 'تمام قواعد' : 'All Topics'} ({sarfRules.length})
          </button>

          {sarfTopics.map((topic) => {
            const isSelected = selectedTopicId === topic.id;
            return (
              <button
                key={topic.id}
                onClick={() => setSelectedTopicId(topic.id)}
                className={`px-3.5 py-1.5 rounded-xl font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-emerald-800 text-amber-200 shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                <span className="font-arabic font-bold ml-1 rtl:ml-0 rtl:mr-1">{topic.arabicTitle}</span>
                <span className="text-[11px] opacity-80">({getText(topic.title)})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Rules List */}
      {filteredRules.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200">
          <p className="text-stone-500 text-sm">
            {language === 'pashto'
              ? 'د لټون سره سم هېڅ قاعده ونه موندل شوه.'
              : language === 'urdu'
              ? 'تلاش کے مطابق کوئی قاعدہ نہیں ملا۔'
              : 'No matching rules found.'}
          </p>
        </div>
      ) : (
        <div>
          {filteredRules.map((rule) => (
            <RuleCard key={rule.id} rule={rule} />
          ))}
        </div>
      )}
    </div>
  );
};
