import React, { useState, useMemo } from 'react';
import {
  Download,
  Copy,
  Check,
  Search,
  Filter,
  Eye,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { CnicRecord } from '../types/cnic';

interface ResultsTableProps {
  records: CnicRecord[];
  onDownloadCsv: () => void;
  onInspectRecord: (record: CnicRecord) => void;
  onDeleteRecord: (id: string) => void;
  onClearAll: () => void;
}

export const ResultsTable: React.FC<ResultsTableProps> = ({
  records,
  onDownloadCsv,
  onInspectRecord,
  onDeleteRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'duplicate' | 'invalid'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bulkCopied, setBulkCopied] = useState(false);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      // Filter by status tab
      if (statusFilter === 'valid' && r.statusType !== 'valid') return false;
      if (statusFilter === 'duplicate' && r.statusType !== 'duplicate') return false;
      if (
        statusFilter === 'invalid' &&
        r.statusType !== 'invalid_length' &&
        r.statusType !== 'invalid_region' &&
        r.statusType !== 'invalid_characters'
      ) {
        return false;
      }

      // Filter by search query
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        r.cnicRaw.includes(q) ||
        r.cnicFormatted.toLowerCase().includes(q) ||
        r.status.toLowerCase().includes(q) ||
        r.provinceName.toLowerCase().includes(q) ||
        r.gender.toLowerCase().includes(q)
      );
    });
  }, [records, statusFilter, searchQuery]);

  const handleCopySingle = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleCopyAllValid = () => {
    const validCnics = records
      .filter((r) => r.statusType === 'valid')
      .map((r) => r.cnicRaw)
      .join('\n');

    if (!validCnics) return;
    navigator.clipboard.writeText(validCnics);
    setBulkCopied(true);
    setTimeout(() => setBulkCopied(false), 2000);
  };

  const validCount = records.filter((r) => r.statusType === 'valid').length;
  const duplicateCount = records.filter((r) => r.statusType === 'duplicate').length;
  const invalidCount = records.filter(
    (r) =>
      r.statusType === 'invalid_length' ||
      r.statusType === 'invalid_region' ||
      r.statusType === 'invalid_characters'
  ).length;

  return (
    <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-emerald-900/10">
      {/* Table Header & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Verification Report</h2>
          <div className="text-xs sm:text-sm text-slate-500 font-mono mt-0.5">
            Total: <span className="font-bold text-slate-800">{records.length}</span>
            <span className="mx-1.5 text-slate-300">|</span>
            Valid format: <span className="font-bold text-emerald-700">{validCount}</span>
            {duplicateCount > 0 && (
              <>
                <span className="mx-1.5 text-slate-300">|</span>
                Duplicates: <span className="font-bold text-amber-700">{duplicateCount}</span>
              </>
            )}
            {invalidCount > 0 && (
              <>
                <span className="mx-1.5 text-slate-300">|</span>
                Invalid: <span className="font-bold text-red-700">{invalidCount}</span>
              </>
            )}
          </div>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by CNIC, Province, Gender..."
              className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50"
            />
          </div>

          {validCount > 0 && (
            <button
              onClick={handleCopyAllValid}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 transition-colors flex items-center gap-1.5"
              title="Copy all valid 13-digit CNICs to clipboard"
            >
              {bulkCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{bulkCopied ? 'Copied Valid!' : 'Copy Valid List'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Segmented Filter Buttons */}
      <div className="flex items-center gap-1.5 py-3 overflow-x-auto text-xs border-b border-slate-100">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            statusFilter === 'all'
              ? 'bg-slate-900 text-white'
              : 'bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          All ({records.length})
        </button>

        <button
          onClick={() => setStatusFilter('valid')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            statusFilter === 'valid'
              ? 'bg-emerald-700 text-white'
              : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
          }`}
        >
          Valid Format ({validCount})
        </button>

        <button
          onClick={() => setStatusFilter('duplicate')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            statusFilter === 'duplicate'
              ? 'bg-amber-600 text-white'
              : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
          }`}
        >
          Duplicates ({duplicateCount})
        </button>

        <button
          onClick={() => setStatusFilter('invalid')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            statusFilter === 'invalid'
              ? 'bg-red-700 text-white'
              : 'bg-red-50 text-red-700 hover:bg-red-100'
          }`}
        >
          Invalid ({invalidCount})
        </button>
      </div>

      {/* Results View */}
      {records.length === 0 ? (
        <div className="py-12 text-center text-slate-500">
          <p className="text-base font-medium text-slate-600">Your results will appear here.</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Paste or type CNIC numbers above and click &quot;CHECK CNIC&quot; to inspect format, region, and duplicates.
          </p>
        </div>
      ) : filteredRecords.length === 0 ? (
        <div className="py-10 text-center text-slate-500">
          <p className="text-sm font-medium">No CNICs matching filter &ldquo;{searchQuery}&rdquo;</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setStatusFilter('all');
            }}
            className="mt-2 text-xs font-semibold text-emerald-700 hover:underline"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="mt-3 overflow-x-auto -mx-5 sm:mx-0">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 text-[11px] uppercase tracking-wider bg-slate-50/70">
                <th className="py-2.5 px-3 font-semibold w-10 text-center">#</th>
                <th className="py-2.5 px-3 font-semibold">CNIC Number</th>
                <th className="py-2.5 px-3 font-semibold">Status</th>
                <th className="py-2.5 px-3 font-semibold hidden md:table-cell">Province / Area</th>
                <th className="py-2.5 px-3 font-semibold hidden sm:table-cell">Gender</th>
                <th className="py-2.5 px-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredRecords.map((r, index) => {
                const isCopied = copiedId === r.id;

                let statusBadge = (
                  <span className="text-[#a36b00] font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{r.status}</span>
                  </span>
                );

                if (r.statusType === 'duplicate') {
                  statusBadge = (
                    <span className="text-amber-700 font-bold flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>{r.status}</span>
                    </span>
                  );
                } else if (r.statusType !== 'valid') {
                  statusBadge = (
                    <span className="text-red-700 font-bold flex items-center gap-1.5">
                      <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                      <span>{r.status}</span>
                    </span>
                  );
                }

                return (
                  <tr
                    key={r.id}
                    className="hover:bg-slate-50/80 transition-colors group"
                  >
                    <td className="py-3 px-3 text-slate-400 text-center font-normal">
                      {index + 1}
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 tracking-wide text-sm">
                            {r.cnicFormatted || r.cnicRaw || '—'}
                          </span>
                        </div>
                        {r.cnicFormatted !== r.cnicRaw && r.cnicRaw && (
                          <span className="text-[11px] text-slate-400">
                            Raw: {r.cnicRaw}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      {statusBadge}
                    </td>

                    <td className="py-3 px-3 font-sans text-slate-700 hidden md:table-cell">
                      {r.provinceName !== 'N/A' && r.provinceName !== 'Unknown' ? (
                        <span>{r.provinceName}</span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>

                    <td className="py-3 px-3 font-sans text-slate-700 hidden sm:table-cell">
                      {r.gender !== 'Unknown' ? (
                        <span>{r.gender}</span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>

                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1 font-sans">
                        <button
                          type="button"
                          onClick={() => handleCopySingle(r.cnicFormatted || r.cnicRaw, r.id)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition-colors"
                          title="Copy CNIC"
                        >
                          {isCopied ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>

                        {r.isValid && (
                          <button
                            type="button"
                            onClick={() => onInspectRecord(r)}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors"
                            title="Inspect NADRA breakdown"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onDeleteRecord(r.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                          title="Remove from batch"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Main Download CSV Button (Parity with User's snippet) */}
      <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
        <button
          type="button"
          onClick={onDownloadCsv}
          disabled={records.length === 0}
          className={`w-full sm:w-auto px-5 py-3.5 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 transition-all shadow-sm ${
            records.length === 0
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
              : 'bg-[#087d3e] hover:bg-[#066a32] text-white hover:shadow cursor-pointer active:scale-[0.99]'
          }`}
        >
          <FileSpreadsheet className="w-5 h-5 text-emerald-200" />
          <span>DOWNLOAD EXCEL-COMPATIBLE CSV REPORT</span>
        </button>

        <span className="text-xs text-slate-400 text-center sm:text-right">
          UTF-8 BOM encoded for direct Microsoft Excel & Google Sheets compatibility
        </span>
      </div>
    </div>
  );
};
