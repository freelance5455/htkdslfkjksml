import React, { useRef, useState, useEffect } from 'react';
import { Target, ArrowUp, Layers, RotateCcw, Package, ZoomIn } from 'lucide-react';
import { InputManager } from '../game/input';

interface TouchControlsProps {
  inputManager: InputManager | null;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ inputManager }) => {
  const joystickRef = useRef<HTMLDivElement | null>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const touchIdRef = useRef<number | null>(null);
  const centerRef = useRef({ x: 0, y: 0 });

  // Handle Joystick Touch
  const handleTouchStart = (e: React.TouchEvent) => {
    if (touchIdRef.current !== null || !joystickRef.current) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;

    const rect = joystickRef.current.getBoundingClientRect();
    centerRef.current = {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
    };
    setIsDragging(true);
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        updateJoystick(e.changedTouches[i].clientX, e.changedTouches[i].clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        touchIdRef.current = null;
        setIsDragging(false);
        setKnobPos({ x: 0, y: 0 });
        if (inputManager) {
          inputManager.setVirtualMove(0, 0);
        }
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    const maxRadius = 45;
    const dx = clientX - centerRef.current.x;
    const dy = clientY - centerRef.current.y;
    const dist = Math.hypot(dx, dy);

    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * clampedDist;
    const ky = Math.sin(angle) * clampedDist;

    setKnobPos({ x: kx, y: ky });

    if (inputManager) {
      inputManager.setVirtualMove(kx / maxRadius, ky / maxRadius);
    }
  };

  // Right Side Look Drag Area
  const lookTouchId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number } | null>(null);

  const handleLookStart = (e: React.TouchEvent) => {
    if (lookTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    lookTouchId.current = touch.identifier;
    lastLookPos.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookMove = (e: React.TouchEvent) => {
    if (lookTouchId.current === null || !lastLookPos.current || !inputManager) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchId.current) {
        const dx = touch.clientX - lastLookPos.current.x;
        const dy = touch.clientY - lastLookPos.current.y;
        inputManager.addVirtualLook(dx, dy);
        lastLookPos.current = { x: touch.clientX, y: touch.clientY };
        break;
      }
    }
  };

  const handleLookEnd = (e: React.TouchEvent) => {
    if (lookTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchId.current) {
        lookTouchId.current = null;
        lastLookPos.current = null;
        break;
      }
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-30">
      {/* Touch Look Pan Area (Middle to Right Screen) */}
      <div
        className="absolute top-0 right-0 w-2/3 h-full pointer-events-auto opacity-0"
        onTouchStart={handleLookStart}
        onTouchMove={handleLookMove}
        onTouchEnd={handleLookEnd}
        onTouchCancel={handleLookEnd}
      />

      {/* Left Virtual Joystick */}
      <div
        ref={joystickRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        className="absolute bottom-12 left-10 w-32 h-32 rounded-full border-2 border-white/20 bg-slate-950/40 pointer-events-auto flex items-center justify-center shadow-lg"
      >
        <div
          style={{ transform: `translate(${knobPos.x}px, ${knobPos.y}px)` }}
          className={`w-14 h-14 rounded-full border-2 ${
            isDragging ? 'bg-amber-500 border-amber-300' : 'bg-white/40 border-white/60'
          } shadow-md transition-transform duration-75`}
        />
      </div>

      {/* Right Side Action Buttons */}
      <div className="absolute bottom-28 right-8 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Fire Button (Big Red/Orange Free Fire Style) */}
        <button
          onTouchStart={() => inputManager?.triggerAction('shoot', true)}
          onTouchEnd={() => inputManager?.triggerAction('shoot', false)}
          className="w-18 h-18 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 border-4 border-amber-300 text-white flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.6)] active:scale-90 transition-transform cursor-pointer"
        >
          <Target className="w-9 h-9" />
        </button>

        {/* Action Button Row */}
        <div className="flex items-center gap-3">
          {/* Jump */}
          <button
            onTouchStart={() => inputManager?.triggerAction('jump', true)}
            onTouchEnd={() => inputManager?.triggerAction('jump', false)}
            className="w-12 h-12 rounded-full bg-slate-900/90 border border-slate-700 text-white flex items-center justify-center active:scale-90 transition-transform"
          >
            <ArrowUp className="w-6 h-6" />
          </button>

          {/* ADS / Zoom */}
          <button
            onTouchStart={() => inputManager?.triggerAction('ads', true)}
            onTouchEnd={() => inputManager?.triggerAction('ads', false)}
            className="w-12 h-12 rounded-full bg-slate-900/90 border border-slate-700 text-purple-400 flex items-center justify-center active:scale-90 transition-transform"
          >
            <ZoomIn className="w-6 h-6" />
          </button>

          {/* Gloo Wall */}
          <button
            onTouchStart={() => inputManager?.triggerAction('gloo', true)}
            onTouchEnd={() => inputManager?.triggerAction('gloo', false)}
            className="w-12 h-12 rounded-full bg-cyan-950/90 border border-cyan-400 text-cyan-300 flex items-center justify-center active:scale-90 transition-transform shadow-[0_0_10px_rgba(6,182,212,0.5)]"
          >
            <Layers className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
