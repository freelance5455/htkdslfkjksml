import { useEffect, useRef, useState } from "react";
import { Footprints, Sparkles, Swords } from "lucide-react";
import type { GameEngine } from "@/game/engine";
import type { GamePhase, HudSnapshot } from "@/game/types";

function Joystick({ engineRef, disabled }: { engineRef: React.RefObject<GameEngine | null>; disabled: boolean }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const center = useRef({ x: 0, y: 0 });
  const pointer = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [active, setActive] = useState(false);

  const apply = (clientX: number, clientY: number) => {
    const max = 34;
    let dx = clientX - center.current.x;
    let dy = clientY - center.current.y;
    const len = Math.hypot(dx, dy);
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    setKnob({ x: dx, y: dy });
    engineRef.current?.setTouchVector(dx / max, dy / max);
  };

  const release = () => {
    pointer.current = null;
    setKnob({ x: 0, y: 0 });
    setActive(false);
    engineRef.current?.setTouchVector(0, 0);
  };

  useEffect(() => {
    if (disabled) release();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disabled]);

  return (
    <div
      ref={baseRef}
      role="button"
      aria-label="عصا الحركة"
      tabIndex={-1}
      onPointerDown={(e) => {
        if (disabled) return;
        e.preventDefault();
        const rect = baseRef.current!.getBoundingClientRect();
        center.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        pointer.current = e.pointerId;
        try {
          baseRef.current?.setPointerCapture(e.pointerId);
        } catch {
          /* synthetic or already-released pointer */
        }
        setActive(true);
        apply(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (pointer.current !== e.pointerId) return;
        e.preventDefault();
        apply(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        if (pointer.current === e.pointerId) release();
      }}
      onPointerCancel={(e) => {
        if (pointer.current === e.pointerId) release();
      }}
      onLostPointerCapture={(e) => {
        if (pointer.current === e.pointerId) release();
      }}
      className={`pointer-events-auto relative flex h-[108px] w-[108px] touch-none select-none items-center justify-center rounded-full border transition-colors sm:h-[118px] sm:w-[118px] ${
        active
          ? "border-[#f5dba4]/60 bg-[#102620]/75"
          : "border-[#f0d9a8]/30 bg-[#102620]/50"
      } shadow-[0_12px_30px_-12px_rgba(0,0,0,0.8)] backdrop-blur-md`}
      style={{ WebkitTapHighlightColor: "transparent" }}
    >
      <div className="absolute inset-2.5 rounded-full border border-dashed border-[#f0d9a8]/15" />
      <span className="absolute left-1/2 top-1.5 -translate-x-1/2 text-[7px] text-[#f0d9a8]/50">▲</span>
      <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 text-[7px] text-[#f0d9a8]/50">▼</span>
      <span className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[7px] text-[#f0d9a8]/50">▶</span>
      <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[7px] text-[#f0d9a8]/50">◀</span>
      <div
        className="pointer-events-none h-[46px] w-[46px] rounded-full border border-[#f5dba4]/50 bg-[radial-gradient(circle_at_35%_30%,#f6e3b8,#dcb574_55%,#a97e45)] shadow-[inset_0_1px_0_rgba(255,255,255,0.5),0_6px_14px_-4px_rgba(0,0,0,0.6)]"
        style={{ transform: `translate(${knob.x}px, ${knob.y}px)`, transition: active ? "none" : "transform 160ms ease-out" }}
      >
        <div className="mx-auto mt-2 h-1 w-5 rounded-full bg-[#7d5a30]/40" />
        <div className="mx-auto mt-1 h-1 w-3 rounded-full bg-[#7d5a30]/30" />
      </div>
    </div>
  );
}

function ActionButton({
  label,
  onPress,
  icon,
  className = "",
  hold = false,
  badge,
}: {
  label: string;
  onPress: () => void;
  icon: React.ReactNode;
  className?: string;
  hold?: boolean;
  badge?: string;
}) {
  const timer = useRef<number | null>(null);
  const [pressed, setPressed] = useState(false);

  const stop = () => {
    if (timer.current) {
      window.clearInterval(timer.current);
      timer.current = null;
    }
    setPressed(false);
  };

  useEffect(() => () => stop(), []);

  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        try {
          e.currentTarget.setPointerCapture(e.pointerId);
        } catch {
          /* synthetic or already-released pointer */
        }
        setPressed(true);
        onPress();
        if (hold) {
          stop();
          setPressed(true);
          timer.current = window.setInterval(onPress, 230);
        }
      }}
      onPointerUp={stop}
      onPointerCancel={stop}
      onLostPointerCapture={stop}
      onContextMenu={(e) => e.preventDefault()}
      className={`pointer-events-auto relative flex touch-none select-none flex-col items-center justify-center rounded-full border shadow-[0_14px_30px_-12px_rgba(0,0,0,0.75)] backdrop-blur-md transition-transform duration-100 ${
        pressed ? "scale-90" : "active:scale-95"
      } ${className}`}
      style={{ WebkitTapHighlightColor: "transparent" }}
    >
      {icon}
      <span className="mt-0.5 text-[8px] font-semibold leading-none sm:text-[9px]">{label}</span>
      {badge && (
        <span className="absolute -top-1 -right-1 rounded-full border border-[#f5dba4]/40 bg-[#142e28] px-1.5 py-0.5 text-[7px] font-semibold text-[#f5dba4]">
          {badge}
        </span>
      )}
    </button>
  );
}

export function TouchControls({
  engineRef,
  phase,
  hud,
}: {
  engineRef: React.RefObject<GameEngine | null>;
  phase: GamePhase;
  hud: HudSnapshot;
}) {
  return (
    <div className="touch-controls pointer-events-none absolute inset-x-0 bottom-0 z-30 items-end justify-between px-3 pb-[max(12px,env(safe-area-inset-bottom))] sm:px-4 sm:pb-4">
      <Joystick engineRef={engineRef} disabled={phase !== "playing"} />
      <div className="flex items-end gap-2">
        {hud.prompt && (
          <ActionButton
            label="تفاعل"
            onPress={() => engineRef.current?.interact()}
            icon={<Sparkles className="mb-0.5 h-5 w-5" />}
            className="h-[54px] w-[54px] border-[#a9e7d5]/50 bg-[#1b4b43]/90 text-[#c9f2e6]"
          />
        )}
        <ActionButton
          label="اندفاع"
          onPress={() => engineRef.current?.tryDash()}
          icon={<Footprints className="mb-0.5 h-5 w-5" />}
          className="h-[60px] w-[60px] border-[#f0d9a8]/25 bg-[#153a32]/88 text-[#d8e8dd]"
          badge={hud.dashReady ? "↯" : undefined}
        />
        <ActionButton
          label="هجوم"
          onPress={() => engineRef.current?.tryAttack()}
          icon={<Swords className="mb-0.5 h-6 w-6" />}
          className="h-[78px] w-[78px] border-[#fff2d0]/50 bg-[radial-gradient(circle_at_35%_25%,#f6e3b8,#dcb574_58%,#b98b4a)] text-[#203b31]"
          hold
        />
      </div>
    </div>
  );
}
