import { useRef, useState } from "react";
import { CrosshairIcon, ReloadIcon, ScopeIcon, WindIcon } from "@/components/Icons";
import type { TouchLayout } from "@/data";

interface Props {
  layout: TouchLayout;
  ammo: number;
  reserve: number;
  reloading: boolean;
  aiming: boolean;
  infiniteAmmo: boolean;
  waveIndex: number;
  waveTotal: number;
  waveQuota: number;
  waveHarvested: number;
  waveTime: string;
  onMove: (x: number, y: number) => void;
  onFire: () => void;
  onReload: () => void;
  onToggleAim: () => void;
}

/** Option A — analog thumbstick. */
function Thumbstick({ onMove }: { onMove: (x: number, y: number) => void }) {
  const padRef = useRef<HTMLDivElement>(null);
  const pointerRef = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [held, setHeld] = useState(false);

  const update = (clientX: number, clientY: number) => {
    const pad = padRef.current;
    if (!pad) return;
    const rect = pad.getBoundingClientRect();
    const max = rect.width / 2 - 13;
    let dx = clientX - (rect.left + rect.width / 2);
    let dy = clientY - (rect.top + rect.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / max, -dy / max);
  };

  const release = () => {
    pointerRef.current = null;
    setHeld(false);
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };

  return (
    <div className="flex select-none flex-col items-center gap-1">
      <div
        ref={padRef}
        role="application"
        aria-label="Movement thumbstick"
        onPointerDown={(event) => {
          event.preventDefault();
          pointerRef.current = event.pointerId;
          event.currentTarget.setPointerCapture(event.pointerId);
          setHeld(true);
          update(event.clientX, event.clientY);
        }}
        onPointerMove={(event) => {
          if (pointerRef.current !== event.pointerId) return;
          update(event.clientX, event.clientY);
        }}
        onPointerUp={(event) => {
          if (pointerRef.current !== event.pointerId) return;
          release();
        }}
        onPointerCancel={release}
        onLostPointerCapture={release}
        className={`relative h-[104px] w-[104px] touch-none rounded-full border backdrop-blur-md transition-colors ${
          held ? "border-brass-300/60 bg-bark-950/70" : "border-sand-100/24 bg-bark-950/55"
        }`}
        style={{ WebkitTapHighlightColor: "transparent" }}
      >
        <span className="pointer-events-none absolute inset-[13px] rounded-full border border-dashed border-sand-100/16" />
        <span className="pointer-events-none absolute left-1/2 top-2.5 h-1.5 w-1.5 -translate-x-1/2 rounded-sm border-l border-t border-sand-100/60" />
        <span className="pointer-events-none absolute bottom-2.5 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-sm border-b border-r border-sand-100/60" />
        <span className="pointer-events-none absolute left-2.5 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-sm border-b border-l border-sand-100/60" />
        <span className="pointer-events-none absolute right-2.5 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-sm border-r border-t border-sand-100/60" />
        <span
          className={`pointer-events-none absolute left-1/2 top-1/2 flex h-11 w-11 items-center justify-center rounded-full border shadow-[0_6px_16px_rgba(0,0,0,0.45)] transition-colors ${
            held ? "border-brass-300/70 bg-brass-300/25" : "border-sand-100/30 bg-sand-100/12"
          }`}
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        >
          <span className={`h-2 w-2 rounded-full ${held ? "bg-brass-300" : "bg-sand-200/80"}`} />
        </span>
      </div>
      <span className="eyebrow text-[0.4rem] text-sand-400/80">Walk · Option A</span>
    </div>
  );
}

/** Option B — classic D-pad. */
function DPad({ onMove }: { onMove: (x: number, y: number) => void }) {
  const dirs = useRef<Record<string, boolean>>({});
  const [pressed, setPressed] = useState<string | null>(null);

  const apply = (next: Record<string, boolean>) => {
    dirs.current = next;
    const x = (next.right ? 1 : 0) - (next.left ? 1 : 0);
    const y = (next.up ? 1 : 0) - (next.down ? 1 : 0);
    const len = Math.hypot(x, y) || 1;
    onMove(x / len, y / len);
  };

  const set = (dir: string, active: boolean) => {
    setPressed(active ? dir : null);
    apply({ ...dirs.current, [dir]: active });
  };

  const key = (dir: string, label: string) => (
    <button
      type="button"
      aria-label={`Walk ${dir}`}
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        set(dir, true);
      }}
      onPointerUp={() => set(dir, false)}
      onPointerCancel={() => set(dir, false)}
      onLostPointerCapture={() => set(dir, false)}
      className={`flex h-9 w-9 touch-none items-center justify-center rounded-sm border font-condensed text-[0.72rem] uppercase backdrop-blur-md transition ${
        pressed === dir ? "border-brass-300/70 bg-brass-300/25 text-brass-200" : "border-sand-100/22 bg-bark-950/60 text-sand-200"
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="grid grid-cols-3 grid-rows-2 gap-1">
        <span />
        {key("up", "W")}
        <span />
        {key("left", "A")}
        {key("down", "S")}
        {key("right", "D")}
      </div>
      <span className="eyebrow text-[0.4rem] text-sand-400/80">Walk · Option B</span>
    </div>
  );
}

export default function TouchControls({
  layout,
  ammo,
  reserve,
  reloading,
  aiming,
  infiniteAmmo,
  waveIndex,
  waveTotal,
  waveQuota,
  waveHarvested,
  waveTime,
  onMove,
  onFire,
  onReload,
  onToggleAim,
}: Props) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 px-safe pb-safe md:hidden">
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="flex items-center gap-2 rounded-full border border-sand-100/16 bg-bark-950/65 px-3 py-1.5 backdrop-blur-md">
          <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-brass-300" />
          <span className="font-condensed text-[0.62rem] uppercase tracking-[0.14em] text-sand-100">
            Drive {waveIndex + 1}/{waveTotal}
          </span>
          <span className="num text-[0.58rem] text-brass-300">{waveQuota > 0 ? `${Math.min(waveHarvested, waveQuota)}/${waveQuota}` : "—"}</span>
          <span className="h-2.5 w-px bg-sand-100/20" />
          <span className="num text-[0.56rem] text-sand-200">{waveTime}</span>
        </span>
        <span className="rounded-full border border-brass-300/30 bg-bark-950/60 px-2.5 py-1 backdrop-blur-md">
          <span className="eyebrow text-[0.42rem] text-brass-300">Android · Option {layout}</span>
        </span>
      </div>

      <div className="mb-2 flex items-end justify-between gap-2">
        <div className="pointer-events-auto">{layout === "A" ? <Thumbstick onMove={onMove} /> : <DPad onMove={onMove} />}</div>

        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={onReload}
              aria-label="Reload rifle"
              className="pointer-events-auto flex h-11 w-11 flex-col items-center justify-center gap-0.5 rounded-full border border-sand-100/22 bg-bark-950/65 text-sand-200 backdrop-blur-md active:scale-95 active:bg-sand-100/15"
            >
              <ReloadIcon size={16} className={reloading ? "animate-spin text-brass-300" : ""} />
              <span className="font-condensed text-[0.4rem] uppercase tracking-[0.1em]">{reloading ? "…" : "Reload"}</span>
            </button>
            <button
              onClick={onToggleAim}
              aria-label="Toggle scope"
              className={`pointer-events-auto flex h-12 w-12 flex-col items-center justify-center gap-0.5 rounded-full border backdrop-blur-md transition active:scale-95 ${
                aiming ? "border-brass-300/70 bg-brass-300/20 text-brass-300" : "border-sand-100/22 bg-bark-950/65 text-sand-200"
              }`}
            >
              <ScopeIcon size={18} />
              <span className="font-condensed text-[0.4rem] uppercase tracking-[0.1em]">Steady</span>
            </button>
          </div>
          <button
            onClick={onFire}
            aria-label="Fire rifle"
            className={`pointer-events-auto relative flex h-[74px] w-[74px] flex-col items-center justify-center rounded-full border text-bark-950 shadow-[0_10px_30px_rgba(0,0,0,0.55)] transition active:scale-95 ${
              ammo > 0 || infiniteAmmo
                ? "border-brass-300/80 bg-gradient-to-b from-brass-300 via-brass-400 to-brass-600"
                : "border-clay-500/60 bg-gradient-to-b from-clay-500 to-[#7c4a2c]"
            }`}
          >
            <CrosshairIcon size={25} />
            <span className="mt-0.5 font-condensed text-[0.55rem] font-semibold uppercase tracking-[0.18em]">
              {ammo > 0 || infiniteAmmo ? "Fire" : "Empty"}
            </span>
            {infiniteAmmo && <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full border border-brass-300 bg-bark-950 text-[0.62rem] text-brass-300">∞</span>}
          </button>
        </div>
      </div>

      <div className="pointer-events-auto flex items-center justify-between gap-3 rounded-sm border border-sand-100/14 bg-bark-950/74 px-3 py-2 backdrop-blur-xl">
        <div className="flex items-center gap-2">
          <WindIcon size={13} className="text-brass-300" />
          <span className="eyebrow text-[0.4rem] text-sand-300/80">Wind NW 7</span>
        </div>
        <div className="flex flex-1 items-center justify-end gap-[3px]">
          {Array.from({ length: 8 }).map((_, index) => (
            <span key={index} className={`h-3.5 w-1.5 rounded-[1px] ${infiniteAmmo || index < ammo ? "bg-brass-300" : "bg-sand-100/15"}`} />
          ))}
        </div>
        <div className="text-right">
          <p className="num text-sm leading-none text-sand-100">
            {infiniteAmmo ? "∞" : String(ammo).padStart(2, "0")} <span className="text-[0.6rem] text-sand-400">/ {infiniteAmmo ? "∞" : String(reserve).padStart(2, "0")}</span>
          </p>
          <p className="eyebrow mt-0.5 text-[0.36rem] text-sand-400">{infiniteAmmo ? "Unlimited ammo" : "Mag · Reserve"}</p>
        </div>
      </div>
    </div>
  );
}
