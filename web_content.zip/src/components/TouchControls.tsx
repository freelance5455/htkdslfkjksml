import React, { useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Anchor,
  HeartPulse,
  Sword,
  Wind,
  Zap,
} from 'lucide-react';
import { AbilityId } from '../game/types';

interface TouchControlsProps {
  abilities: AbilityId[];
  flux: number;
  hasPrompt: boolean;
  rotated?: boolean;
  onSetHeld: (code: string, active: boolean) => void;
  onTriggerPogo: () => void;
}

interface ActionBtnProps {
  label: string;
  activeColor?: string;
  locked?: boolean;
  highlight?: boolean;
  className?: string;
  onPressStart: () => void;
  onPressEnd: () => void;
  children: React.ReactNode;
}

const ActionTouchButton: React.FC<ActionBtnProps> = ({
  label,
  activeColor = 'border-cyan-400 bg-cyan-500/25 text-white',
  locked = false,
  highlight = false,
  className = '',
  onPressStart,
  onPressEnd,
  children,
}) => {
  const [pressed, setPressed] = useState(false);
  const pointerIdRef = useRef<number | null>(null);

  const handleDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (pointerIdRef.current !== null) return;
    pointerIdRef.current = e.pointerId;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore if pointer capture is unsupported
    }
    setPressed(true);
    onPressStart();
  };

  const handleUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (pointerIdRef.current !== e.pointerId) return;
    pointerIdRef.current = null;
    setPressed(false);
    onPressEnd();
  };

  return (
    <button
      type="button"
      onPointerDown={handleDown}
      onPointerUp={handleUp}
      onPointerCancel={handleUp}
      onContextMenu={(e) => e.preventDefault()}
      aria-label={label}
      className={`touch-none select-none flex flex-col items-center justify-center rounded-full border transition-transform duration-75 ${
        pressed
          ? `scale-90 ${activeColor}`
          : locked
          ? 'border-slate-800 bg-[#070b14]/55 text-slate-600'
          : highlight
          ? 'border-cyan-400/90 bg-[#0b1526]/85 text-cyan-200'
          : 'border-slate-600/80 bg-[#090d18]/78 text-slate-100'
      } ${className}`}
    >
      {children}
      <span className="mt-0.5 text-[9px] font-bold tracking-wider uppercase leading-none">
        {label}
      </span>
    </button>
  );
};

export const TouchControls: React.FC<TouchControlsProps> = ({
  abilities,
  flux,
  hasPrompt,
  rotated = false,
  onSetHeld,
  onTriggerPogo,
}) => {
  const zoneRef = useRef<HTMLDivElement | null>(null);
  const padPointerRef = useRef<number | null>(null);
  const originRef = useRef<{ x: number; y: number } | null>(null);

  const [padState, setPadState] = useState<{
    active: boolean;
    originX: number;
    originY: number;
    left: boolean;
    right: boolean;
    up: boolean;
    down: boolean;
    knobX: number;
    knobY: number;
  }>({
    active: false,
    originX: 0,
    originY: 0,
    left: false,
    right: false,
    up: false,
    down: false,
    knobX: 0,
    knobY: 0,
  });

  const getLocalCoords = (clientX: number, clientY: number) => {
    const el = zoneRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    if (rotated) {
      return {
        lx: clientY - rect.top,
        ly: rect.right - clientX,
      };
    }
    return {
      lx: clientX - rect.left,
      ly: clientY - rect.top,
    };
  };

  const applyFloatingVector = (clientX: number, clientY: number) => {
    const pos = getLocalCoords(clientX, clientY);
    const origin = originRef.current;
    if (!pos || !origin) return;

    let dx = pos.lx - origin.x;
    let dy = pos.ly - origin.y;

    const maxR = 64; // Wider thumb travel radius for crisp control
    const leashR = 92; // Re-center floating origin gently if thumb sweeps far past rim
    const dist = Math.hypot(dx, dy);

    if (dist > leashR) {
      const pull = (dist - leashR) / dist;
      origin.x += dx * pull;
      origin.y += dy * pull;
      dx = pos.lx - origin.x;
      dy = pos.ly - origin.y;
    }

    const clampedDist = Math.hypot(dx, dy);
    const clampScale = clampedDist > maxR ? maxR / clampedDist : 1;
    const kx = dx * clampScale;
    const ky = dy * clampScale;

    const dead = 12;
    const left = dx < -dead;
    const right = dx > dead;
    const up = dy < -26 && Math.abs(dy) > Math.abs(dx) * 0.65;
    const down = dy > 24 && Math.abs(dy) > Math.abs(dx) * 0.55;

    onSetHeld('KeyA', left);
    onSetHeld('KeyD', right);
    onSetHeld('KeyW', up);
    onSetHeld('KeyS', down);

    setPadState({
      active: true,
      originX: origin.x,
      originY: origin.y,
      left,
      right,
      up,
      down,
      knobX: kx,
      knobY: ky,
    });
  };

  const resetPad = () => {
    padPointerRef.current = null;
    originRef.current = null;
    onSetHeld('KeyA', false);
    onSetHeld('KeyD', false);
    onSetHeld('KeyW', false);
    onSetHeld('KeyS', false);
    setPadState({
      active: false,
      originX: 0,
      originY: 0,
      left: false,
      right: false,
      up: false,
      down: false,
      knobX: 0,
      knobY: 0,
    });
  };

  const handlePadDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (padPointerRef.current !== null) return;
    const pos = getLocalCoords(e.clientX, e.clientY);
    if (!pos) return;
    padPointerRef.current = e.pointerId;
    originRef.current = { x: pos.lx, y: pos.ly };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore
    }
    applyFloatingVector(e.clientX, e.clientY);
  };

  const handlePadMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (padPointerRef.current !== e.pointerId) return;
    e.preventDefault();
    applyFloatingVector(e.clientX, e.clientY);
  };

  const handlePadUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (padPointerRef.current !== e.pointerId) return;
    e.preventDefault();
    resetPad();
  };

  const hasDash = abilities.includes('phase_dash');
  const hasGrapple = abilities.includes('grapple_tether');
  const healReady = flux >= 33 || hasPrompt;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-end justify-between">
      {/* Left Floating Joystick Touch Region */}
      <div
        ref={zoneRef}
        onPointerDown={handlePadDown}
        onPointerMove={handlePadMove}
        onPointerUp={handlePadUp}
        onPointerCancel={handlePadUp}
        onContextMenu={(e) => e.preventDefault()}
        aria-label="Floating movement joystick zone"
        className="pointer-events-auto relative h-[62%] w-[44%] max-w-[380px] touch-none select-none"
      >
        {/* Subtle Resting Anchor Ring when untouched */}
        {!padState.active && (
          <div className="pointer-events-none absolute bottom-4 left-5 flex h-32 w-32 items-center justify-center rounded-full border border-slate-600/55 bg-[#090d18]/45 pl-[env(safe-area-inset-left)]">
            <ArrowUp className="absolute top-2.5 h-3.5 w-3.5 text-slate-500/80" />
            <ArrowDown className="absolute bottom-2.5 h-3.5 w-3.5 text-slate-500/80" />
            <ArrowLeft className="absolute left-2.5 h-3.5 w-3.5 text-slate-500/80" />
            <ArrowRight className="absolute right-2.5 h-3.5 w-3.5 text-slate-500/80" />
            <div className="h-11 w-11 rounded-full border-2 border-cyan-400/55 bg-cyan-500/15" />
          </div>
        )}

        {/* Active Floating Joystick Ring centered at thumb touch point */}
        {padState.active && (
          <div
            className="pointer-events-none absolute flex h-40 w-40 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-cyan-400/60 bg-[#090d18]/75 shadow-[0_0_24px_rgba(34,211,238,0.16)]"
            style={{
              left: `${padState.originX}px`,
              top: `${padState.originY}px`,
            }}
          >
            <ArrowUp
              className={`absolute top-2.5 h-4 w-4 ${
                padState.up ? 'text-cyan-300' : 'text-slate-500'
              }`}
            />
            <ArrowDown
              className={`absolute bottom-2.5 h-4 w-4 ${
                padState.down ? 'text-amber-300' : 'text-slate-500'
              }`}
            />
            <ArrowLeft
              className={`absolute left-2.5 h-4 w-4 ${
                padState.left ? 'text-cyan-300' : 'text-slate-500'
              }`}
            />
            <ArrowRight
              className={`absolute right-2.5 h-4 w-4 ${
                padState.right ? 'text-cyan-300' : 'text-slate-500'
              }`}
            />

            {/* Dynamic Thumb Knob */}
            <div
              className="h-13 w-13 rounded-full border-2 border-cyan-300 bg-cyan-400/35"
              style={{
                transform: `translate3d(${padState.knobX}px, ${padState.knobY}px, 0)`,
              }}
            />
          </div>
        )}
      </div>

      {/* Right Thumb Cluster: Combat + Parkour Actions */}
      <div className="pointer-events-auto mb-3 mr-4 grid grid-cols-3 grid-rows-2 items-center justify-items-center gap-2.5 pr-[env(safe-area-inset-right)] pb-[env(safe-area-inset-bottom)]">
        {/* Top Row: Hook, Pogo, Heal */}
        <ActionTouchButton
          label="Hook"
          locked={!hasGrapple}
          highlight={hasGrapple}
          activeColor="border-sky-300 bg-sky-500/35 text-white"
          className="h-12 w-12"
          onPressStart={() => onSetHeld('KeyC', true)}
          onPressEnd={() => onSetHeld('KeyC', false)}
        >
          <Anchor className="h-4 w-4" />
        </ActionTouchButton>

        <ActionTouchButton
          label="Pogo"
          highlight
          activeColor="border-amber-300 bg-amber-500/35 text-white"
          className="h-12 w-12"
          onPressStart={onTriggerPogo}
          onPressEnd={() => {}}
        >
          <ArrowDown className="h-4 w-4 text-amber-300" />
        </ActionTouchButton>

        <ActionTouchButton
          label={hasPrompt ? 'Rest' : 'Heal'}
          highlight={healReady}
          activeColor="border-emerald-300 bg-emerald-500/35 text-white"
          className="h-12 w-12"
          onPressStart={() => onSetHeld('KeyE', true)}
          onPressEnd={() => onSetHeld('KeyE', false)}
        >
          <HeartPulse className="h-4 w-4" />
        </ActionTouchButton>

        {/* Bottom Row: Dash, Slash, Jump */}
        <ActionTouchButton
          label="Dash"
          locked={!hasDash}
          highlight={hasDash}
          activeColor="border-fuchsia-400 bg-fuchsia-500/35 text-white"
          className="h-13 w-13"
          onPressStart={() => onSetHeld('ShiftLeft', true)}
          onPressEnd={() => onSetHeld('ShiftLeft', false)}
        >
          <Zap className="h-4 w-4" />
        </ActionTouchButton>

        <ActionTouchButton
          label="Slash"
          highlight
          activeColor="border-cyan-300 bg-cyan-400/40 text-white"
          className="h-14 w-14"
          onPressStart={() => onSetHeld('KeyJ', true)}
          onPressEnd={() => onSetHeld('KeyJ', false)}
        >
          <Sword className="h-5 w-5" />
        </ActionTouchButton>

        <ActionTouchButton
          label="Jump"
          highlight
          activeColor="border-white bg-cyan-400/45 text-white"
          className="h-15 w-15"
          onPressStart={() => onSetHeld('Space', true)}
          onPressEnd={() => onSetHeld('Space', false)}
        >
          <Wind className="h-5 w-5" />
        </ActionTouchButton>
      </div>
    </div>
  );
};
