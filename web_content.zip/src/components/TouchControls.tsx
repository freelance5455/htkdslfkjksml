import React, {useRef, useState} from 'react';
import type {TouchInputState} from '../game/types';

interface TouchControlsProps {
  inVehicle: boolean;
  canEnterVehicle: boolean;
  onInput: (partial: Partial<TouchInputState>) => void;
  onToggleVehicle: () => void;
  onSpecial: () => void;
  onAttackTap: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  inVehicle,
  canEnterVehicle,
  onInput,
  onToggleVehicle,
  onSpecial,
  onAttackTap,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const activePointerId = useRef<number | null>(null);
  const camPointerId = useRef<number | null>(null);
  const lastCamPos = useRef<{x: number; y: number}>({x: 0, y: 0});
  const [knob, setKnob] = useState<{x: number; y: number}>({x: 0, y: 0});

  const updateStick = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.42;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setKnob({x: dx, y: dy});
    onInput({
      moveX: dx / maxR,
      moveY: dy / maxR,
    });
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none">
      {/* Right-half camera look swipe zone */}
      <div
        className="pointer-events-auto absolute right-0 top-16 bottom-44 left-1/2 touch-none"
        onPointerDown={(e) => {
          if (camPointerId.current !== null) return;
          camPointerId.current = e.pointerId;
          lastCamPos.current = {x: e.clientX, y: e.clientY};
        }}
        onPointerMove={(e) => {
          if (e.pointerId !== camPointerId.current) return;
          const dx = e.clientX - lastCamPos.current.x;
          const dy = e.clientY - lastCamPos.current.y;
          lastCamPos.current = {x: e.clientX, y: e.clientY};
          onInput({cameraDeltaX: dx * 1.4, cameraDeltaY: dy * 1.4});
        }}
        onPointerUp={(e) => {
          if (e.pointerId === camPointerId.current) camPointerId.current = null;
        }}
        onPointerCancel={(e) => {
          if (e.pointerId === camPointerId.current) camPointerId.current = null;
        }}
      />

      {/* Left Thumb Virtual Analog Joystick */}
      <div
        ref={padRef}
        className="pointer-events-auto absolute bottom-20 left-5 h-32 w-32 rounded-full border border-white/20 bg-slate-950/65 touch-none flex items-center justify-center"
        onPointerDown={(e) => {
          e.stopPropagation();
          activePointerId.current = e.pointerId;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          updateStick(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (e.pointerId !== activePointerId.current) return;
          updateStick(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (e.pointerId !== activePointerId.current) return;
          activePointerId.current = null;
          setKnob({x: 0, y: 0});
          onInput({moveX: 0, moveY: 0});
        }}
        onPointerCancel={(e) => {
          if (e.pointerId !== activePointerId.current) return;
          activePointerId.current = null;
          setKnob({x: 0, y: 0});
          onInput({moveX: 0, moveY: 0});
        }}
      >
        <div
          className="h-12 w-12 rounded-full border border-white/40 bg-emerald-500/80 shadow-lg"
          style={{transform: `translate(${knob.x}px, ${knob.y}px)`}}
        />
      </div>

      {/* Right Thumb Contextual Action Buttons (>=48px touch targets) */}
      <div className="pointer-events-auto absolute bottom-20 right-5 flex flex-col items-end gap-3">
        {(inVehicle || canEnterVehicle) && (
          <button
            type="button"
            onClick={onToggleVehicle}
            className="min-h-[48px] min-w-[112px] rounded-xl border border-amber-400/50 bg-amber-500/90 px-4 text-xs font-bold tracking-wide text-slate-950 active:scale-95"
          >
            {inVehicle ? 'Exit Car' : 'Enter Car'}
          </button>
        )}

        {inVehicle ? (
          <div className="flex items-center gap-3">
            <button
              type="button"
              onPointerDown={() => onInput({handbrake: true})}
              onPointerUp={() => onInput({handbrake: false})}
              onPointerLeave={() => onInput({handbrake: false})}
              className="flex h-14 w-14 items-center justify-center rounded-xl border border-white/20 bg-slate-900/85 text-xs font-bold text-slate-200 active:scale-95"
            >
              Drift
            </button>
            <button
              type="button"
              onPointerDown={() => onInput({brake: true})}
              onPointerUp={() => onInput({brake: false})}
              onPointerLeave={() => onInput({brake: false})}
              className="flex h-16 w-16 items-center justify-center rounded-xl border border-rose-400/40 bg-rose-600/85 text-xs font-bold text-white active:scale-95"
            >
              Brake
            </button>
            <button
              type="button"
              onPointerDown={() => onInput({gas: true})}
              onPointerUp={() => onInput({gas: false})}
              onPointerLeave={() => onInput({gas: false})}
              className="flex h-20 w-16 items-center justify-center rounded-xl border border-emerald-400/50 bg-emerald-600/90 text-xs font-bold text-white active:scale-95"
            >
              Gas
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onSpecial}
              className="flex h-12 w-14 items-center justify-center rounded-xl border border-sky-400/40 bg-slate-900/85 text-xs font-bold text-sky-300 active:scale-95"
            >
              Skill
            </button>
            <button
              type="button"
              onPointerDown={() => onInput({sprint: true})}
              onPointerUp={() => onInput({sprint: false})}
              onPointerLeave={() => onInput({sprint: false})}
              className="flex h-14 w-16 items-center justify-center rounded-xl border border-white/20 bg-slate-900/85 text-xs font-bold text-slate-100 active:scale-95"
            >
              Sprint
            </button>
            <button
              type="button"
              onPointerDown={() => {
                onInput({attack: true});
                onAttackTap();
              }}
              onPointerUp={() => onInput({attack: false})}
              onPointerLeave={() => onInput({attack: false})}
              className="flex h-16 w-16 items-center justify-center rounded-full border border-rose-400/50 bg-rose-600/90 text-xs font-bold text-white active:scale-95"
            >
              Fire
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
