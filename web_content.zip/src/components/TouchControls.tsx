import { useEffect, useState } from "react";
import { input } from "../game/input";

function PadButton({
  label,
  onPress,
  onRelease,
  className = "",
}: {
  label: string;
  onPress: () => void;
  onRelease: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      className={`flex h-16 w-16 items-center justify-center rounded-2xl border border-white/15 bg-slate-900/60 text-2xl text-white/90 backdrop-blur-md active:scale-95 ${className}`}
      onPointerDown={(e) => {
        e.preventDefault();
        onPress();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        onRelease();
      }}
      onPointerCancel={onRelease}
      onPointerLeave={onRelease}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}
    </button>
  );
}

export default function TouchControls() {
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const touch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
    setEnabled(coarse || touch);
  }, []);

  if (!enabled) return null;

  return (
    <div className="absolute inset-0 z-20 select-none">
      <div className="absolute bottom-6 left-4 flex gap-3">
        <PadButton
          label="◀"
          onPress={() => (input.left = true)}
          onRelease={() => (input.left = false)}
        />
        <PadButton
          label="▶"
          onPress={() => (input.right = true)}
          onRelease={() => (input.right = false)}
        />
      </div>
      <div className="absolute bottom-6 right-4 flex gap-3">
        <PadButton
          label="🛑"
          className="!text-xl"
          onPress={() => (input.brake = true)}
          onRelease={() => (input.brake = false)}
        />
        <PadButton
          label="⚡"
          className="!text-xl !text-cyan-300"
          onPress={() => (input.boost = true)}
          onRelease={() => (input.boost = false)}
        />
      </div>
    </div>
  );
}
