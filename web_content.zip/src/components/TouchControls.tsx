import React, { useRef, useState } from 'react';

export interface TouchInputState {
  moveX: number; // -1 .. 1
  attackHeld: boolean;
}

interface TouchControlsProps {
  scale: number;
  dashCd: number;
  dashMaxCd: number;
  skill1Cd: number;
  skill1MaxCd: number;
  skill1Name: string;
  skill2Cd: number;
  skill2MaxCd: number;
  skill2Name: string;
  potionsCount: number;
  onMoveChange: (moveX: number) => void;
  onJumpPress: () => void;
  onDashPress: () => void;
  onAttackDown: () => void;
  onAttackUp: () => void;
  onSkill1Press: () => void;
  onSkill2Press: () => void;
  onPotionPress: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  scale,
  dashCd,
  dashMaxCd,
  skill1Cd,
  skill1MaxCd,
  skill1Name,
  skill2Cd,
  skill2MaxCd,
  skill2Name,
  potionsCount,
  onMoveChange,
  onJumpPress,
  onDashPress,
  onAttackDown,
  onAttackUp,
  onSkill1Press,
  onSkill2Press,
  onPotionPress,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const activePointerId = useRef<number | null>(null);
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const maxRadius = 44;

  const updateStick = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    setKnobOffset({ x: dx, y: dy });
    const normX = Math.abs(dx) < 7 ? 0 : Math.max(-1, Math.min(1, dx / (maxRadius * 0.72)));
    onMoveChange(normX);
  };

  const handleJoystickPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    activePointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    updateStick(e.clientX, e.clientY);
  };

  const handleJoystickPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointerId.current !== e.pointerId) return;
    e.preventDefault();
    updateStick(e.clientX, e.clientY);
  };

  const handleJoystickPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointerId.current !== e.pointerId) return;
    activePointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    onMoveChange(0);
  };

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex items-end justify-between px-3 pb-3 sm:px-6 sm:pb-5 no-select-touch"
      style={{
        transform: `scale(${scale})`,
        transformOrigin: 'bottom center',
      }}
    >
      {/* LEFT VIRTUAL ANALOG JOYSTICK */}
      <div className="pointer-events-auto flex flex-col items-center gap-1">
        <div
          ref={baseRef}
          onPointerDown={handleJoystickPointerDown}
          onPointerMove={handleJoystickPointerMove}
          onPointerUp={handleJoystickPointerUp}
          onPointerCancel={handleJoystickPointerUp}
          className="relative flex h-28 w-28 sm:h-32 sm:w-32 items-center justify-center rounded-full border-2 border-purple-400/45 bg-[#0e0822]/70 shadow-[0_0_25px_rgba(139,92,246,0.35)] backdrop-blur-sm active:border-amber-400/80"
        >
          {/* Directional arrows */}
          <span className="pointer-events-none absolute left-2.5 text-xs font-bold text-purple-300/60">
            ◀
          </span>
          <span className="pointer-events-none absolute right-2.5 text-xs font-bold text-purple-300/60">
            ▶
          </span>
          <div className="pointer-events-none h-12 w-12 rounded-full border border-purple-300/20" />

          {/* Thumb Knob */}
          <div
            style={{
              transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
            }}
            className="pointer-events-none flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-full border-2 border-amber-300/90 bg-gradient-to-br from-purple-600 via-indigo-800 to-slate-900 shadow-[0_0_16px_rgba(251,191,36,0.55)]"
          >
            <span className="text-sm font-bold text-amber-200">∞</span>
          </div>
        </div>
        <span className="text-[10px] font-semibold tracking-wider text-slate-300/70 uppercase">
          Move (A/D)
        </span>
      </div>

      {/* RIGHT ERGONOMIC ACTION & SKILL CLUSTER */}
      <div className="pointer-events-auto relative h-40 w-56 sm:h-44 sm:w-64">
        {/* Quick Heal Potion Button (Top right corner of cluster) */}
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            onPotionPress();
          }}
          disabled={potionsCount <= 0}
          className={`absolute top-0 right-1 flex h-11 w-11 items-center justify-center rounded-full border text-sm font-bold shadow-lg transition active:scale-90 ${
            potionsCount > 0
              ? 'border-pink-400/80 bg-pink-950/85 text-pink-100 shadow-pink-500/30'
              : 'border-slate-700 bg-slate-900/60 text-slate-500 opacity-50'
          }`}
          title="Twilight Potion (H)"
        >
          <span>🧪</span>
          <span className="absolute -top-1 -right-1 rounded-full bg-amber-500 px-1.5 text-[10px] font-extrabold text-slate-950">
            {potionsCount}
          </span>
        </button>

        {/* ULTIMATE SKILL 2 (Top Arc Center) */}
        <CooldownActionButton
          posClass="top-1 left-14 sm:left-16 h-13 w-13 sm:h-14 sm:w-14"
          label="ULT"
          subHint="U"
          title={skill2Name}
          cd={skill2Cd}
          maxCd={skill2MaxCd}
          ringColor="border-amber-300 bg-gradient-to-br from-amber-600/90 via-purple-800/90 to-slate-950 shadow-[0_0_18px_rgba(251,191,36,0.5)]"
          icon="♾️"
          onPress={onSkill2Press}
        />

        {/* ACTIVE SKILL 1 (Mid-Left Arc) */}
        <CooldownActionButton
          posClass="top-12 left-1 sm:top-14 sm:left-2 h-13 w-13 sm:h-14 sm:w-14"
          label="SKILL"
          subHint="K"
          title={skill1Name}
          cd={skill1Cd}
          maxCd={skill1MaxCd}
          ringColor="border-purple-400 bg-gradient-to-br from-purple-700/90 to-indigo-950/90 shadow-[0_0_15px_rgba(168,85,247,0.45)]"
          icon="✦"
          onPress={onSkill1Press}
        />

        {/* DASH BUTTON (Bottom-Left Arc) */}
        <CooldownActionButton
          posClass="bottom-1 left-4 sm:left-6 h-13 w-13 sm:h-14 sm:w-14"
          label="DASH"
          subHint="Shift"
          title="Shadow Dash"
          cd={dashCd}
          maxCd={dashMaxCd}
          ringColor="border-cyan-400/85 bg-gradient-to-br from-cyan-800/85 to-slate-950/90 shadow-[0_0_14px_rgba(34,211,238,0.4)]"
          icon="💨"
          onPress={onDashPress}
        />

        {/* JUMP / DOUBLE JUMP BUTTON (Bottom-Right / Mid-Right) */}
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            onJumpPress();
          }}
          className="absolute right-0 bottom-20 sm:bottom-22 flex h-13 w-13 sm:h-14 sm:w-14 flex-col items-center justify-center rounded-full border-2 border-emerald-400/85 bg-gradient-to-br from-emerald-700/85 to-slate-950/90 text-white shadow-[0_0_14px_rgba(52,211,153,0.4)] transition active:scale-90"
        >
          <span className="text-sm leading-none">⬆</span>
          <span className="text-[9px] font-extrabold tracking-tight text-emerald-200">JUMP</span>
        </button>

        {/* PRIMARY ATTACK / COMBO BUTTON (Large Ergonomic Anchor) */}
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            onAttackDown();
          }}
          onPointerUp={(e) => {
            e.preventDefault();
            onAttackUp();
          }}
          onPointerCancel={() => onAttackUp()}
          className="absolute right-1 bottom-1 flex h-20 w-20 sm:h-22 sm:w-22 flex-col items-center justify-center rounded-full border-2 border-amber-300 bg-gradient-to-br from-rose-600/90 via-purple-800/95 to-slate-950 text-white shadow-[0_0_24px_rgba(244,63,94,0.55)] transition active:scale-92"
        >
          <span className="text-xl leading-none">⚔️</span>
          <span className="mt-0.5 text-[10px] font-extrabold tracking-wider text-amber-200">
            ATTACK
          </span>
          <span className="text-[8px] text-slate-300/75">(J)</span>
        </button>
      </div>
    </div>
  );
};

interface CooldownBtnProps {
  posClass: string;
  label: string;
  subHint: string;
  title: string;
  cd: number;
  maxCd: number;
  ringColor: string;
  icon: string;
  onPress: () => void;
}

const CooldownActionButton: React.FC<CooldownBtnProps> = ({
  posClass,
  label,
  subHint,
  title,
  cd,
  maxCd,
  ringColor,
  icon,
  onPress,
}) => {
  const onCooldown = cd > 0.05;
  const pct = maxCd > 0 ? Math.min(1, cd / maxCd) : 0;

  return (
    <button
      type="button"
      title={`${title} (${subHint})`}
      onPointerDown={(e) => {
        e.preventDefault();
        if (!onCooldown) onPress();
      }}
      className={`absolute ${posClass} flex flex-col items-center justify-center overflow-hidden rounded-full border-2 text-white transition active:scale-90 ${
        onCooldown ? 'border-slate-600 bg-slate-900/85 opacity-80' : ringColor
      }`}
    >
      {onCooldown && (
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 bg-slate-950/75"
          style={{ height: `${pct * 100}%` }}
        />
      )}
      <span className="relative z-10 text-sm leading-none">{icon}</span>
      <span className="relative z-10 text-[9px] font-extrabold tracking-tight text-amber-100">
        {onCooldown ? `${cd.toFixed(1)}s` : label}
      </span>
    </button>
  );
};
