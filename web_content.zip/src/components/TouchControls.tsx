import { useCallback, useRef, useState } from "react";

export type ActionName = "interact" | "inventory" | "relations" | "journal" | "map" | "pause";

export function TouchControls({
  onMove,
  onAction,
}: {
  onMove: (x: number, y: number) => void;
  onAction: (a: ActionName) => void;
}) {
  const baseRef = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const active = useRef<number | null>(null);

  const handle = useCallback(
    (e: React.PointerEvent) => {
      const base = baseRef.current;
      if (!base) return;
      const r = base.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      let dx = e.clientX - cx;
      let dy = e.clientY - cy;
      const max = r.width / 2 - 8;
      const dist = Math.hypot(dx, dy);
      if (dist > max) {
        dx = (dx / dist) * max;
        dy = (dy / dist) * max;
      }
      setKnob({ x: dx, y: dy });
      onMove(dx / max, dy / max);
    },
    [onMove]
  );

  const end = useCallback(() => {
    active.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  }, [onMove]);

  const btn =
    "pointer-events-auto flex items-center justify-center border-2 border-[#4a3a5e] bg-[#241a33]/90 text-[#f7e3a8] active:bg-[#3a2a4d]";

  return (
    <div className="pointer-events-none absolute inset-0 z-30 lg:hidden">
      <div
        ref={baseRef}
        className="pointer-events-auto absolute bottom-6 left-5 h-28 w-28 touch-none rounded-full border-2 border-[#4a3a5e] bg-[#1a1326]/70"
        onPointerDown={(e) => {
          active.current = e.pointerId;
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          handle(e);
        }}
        onPointerMove={(e) => {
          if (active.current === e.pointerId) handle(e);
        }}
        onPointerUp={end}
        onPointerCancel={end}
        onPointerLeave={end}
      >
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#e8c06a] bg-[#3a2a4d]/80"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
      </div>

      <div className="absolute bottom-6 right-4 grid grid-cols-3 gap-2">
        <button className={`${btn} h-11 w-11 text-[10px]`} onClick={() => onAction("relations")}>
          R
        </button>
        <button className={`${btn} h-11 w-11 text-[10px]`} onClick={() => onAction("journal")}>
          J
        </button>
        <button className={`${btn} h-11 w-11 text-[10px]`} onClick={() => onAction("map")}>
          M
        </button>
        <button className={`${btn} h-11 w-11 text-[10px]`} onClick={() => onAction("inventory")}>
          I
        </button>
        <button className={`${btn} h-11 w-11 text-[10px]`} onClick={() => onAction("pause")}>
          ❚❚
        </button>
        <button
          className={`${btn} h-11 w-11 border-[#e8c06a] bg-[#5a4420]/90 text-[12px] font-bold`}
          onClick={() => onAction("interact")}
        >
          E
        </button>
      </div>
    </div>
  );
}
