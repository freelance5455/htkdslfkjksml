import { useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';
import type { Input } from '../game/input';

interface TouchControlsProps {
  input: Input;
  enabled: boolean;
}

const JOY_RADIUS = 56;
const LOOK_SENS = 1.25;

type Handlers = {
  onPointerDown: (e: ReactPointerEvent<HTMLElement>) => void;
  onPointerUp: (e: ReactPointerEvent<HTMLElement>) => void;
  onPointerCancel: (e: ReactPointerEvent<HTMLElement>) => void;
};

/** Press-and-hold button (fire, aim). */
function holdButton(onDown: () => void, onUp: () => void): Handlers {
  return {
    onPointerDown: (e) => {
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      onDown();
    },
    onPointerUp: (e) => {
      e.stopPropagation();
      onUp();
    },
    onPointerCancel: (e) => {
      e.stopPropagation();
      onUp();
    },
  };
}

function TapButton({
  label,
  onTap,
  size,
  className,
  children,
  tone = 'default',
}: {
  label: string;
  onTap: () => void;
  size: number;
  className: string;
  children?: ReactNode;
  tone?: 'default' | 'fire';
}) {
  const base =
    tone === 'fire'
      ? 'bg-gradient-to-b from-amber-300 via-orange-500 to-red-600 shadow-[0_0_28px_rgba(249,115,22,0.6)] ring-2 ring-amber-200/70'
      : 'bg-black/55 ring-1 ring-white/25';
  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(e) => {
        e.stopPropagation();
        onTap();
      }}
      className={`absolute grid touch-none select-none place-items-center rounded-full font-display font-bold tracking-wider text-white active:scale-90 ${base} ${className}`}
      style={{ width: size, height: size, fontSize: size < 60 ? 11 : 15 }}
    >
      {children ?? label}
    </button>
  );
}

/**
 * Touch overlay for phones/tablets. Left half: floating joystick. Right half: drag to look.
 * Buttons on the right: fire, aim, jump, reload, pick up, heal, swap weapon.
 */
export function TouchControls({ input, enabled }: TouchControlsProps) {
  const knobRef = useRef<HTMLDivElement>(null);
  const joyId = useRef<number | null>(null);
  const joyOrigin = useRef({ x: 0, y: 0 });
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const [joy, setJoy] = useState<{ x: number; y: number } | null>(null);

  if (!enabled) return null;

  const moveKnob = (x: number, y: number) => {
    let dx = x - joyOrigin.current.x;
    let dy = y - joyOrigin.current.y;
    const d = Math.hypot(dx, dy);
    if (d > JOY_RADIUS) {
      dx = (dx / d) * JOY_RADIUS;
      dy = (dy / d) * JOY_RADIUS;
    }
    input.setJoy(dx / JOY_RADIUS, -dy / JOY_RADIUS);
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
  };

  const onDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'touch') return;
    const left = e.clientX < window.innerWidth * 0.45;
    if (left && joyId.current === null) {
      joyId.current = e.pointerId;
      joyOrigin.current = { x: e.clientX, y: e.clientY };
      setJoy({ x: e.clientX, y: e.clientY });
      moveKnob(e.clientX, e.clientY);
      e.currentTarget.setPointerCapture(e.pointerId);
    } else if (!left && lookId.current === null) {
      lookId.current = e.pointerId;
      lookLast.current = { x: e.clientX, y: e.clientY };
      e.currentTarget.setPointerCapture(e.pointerId);
    }
  };

  const onMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.pointerId === joyId.current) {
      moveKnob(e.clientX, e.clientY);
    } else if (e.pointerId === lookId.current) {
      const dx = e.clientX - lookLast.current.x;
      const dy = e.clientY - lookLast.current.y;
      lookLast.current = { x: e.clientX, y: e.clientY };
      input.addLook(dx * LOOK_SENS, dy * LOOK_SENS);
    }
  };

  const onUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.pointerId === joyId.current) {
      joyId.current = null;
      input.setJoy(0, 0);
      setJoy(null);
      if (knobRef.current) knobRef.current.style.transform = 'translate(0px, 0px)';
    }
    if (e.pointerId === lookId.current) lookId.current = null;
  };

  const fire = holdButton(
    () => input.setTouchFire(true),
    () => input.setTouchFire(false),
  );
  const aim = holdButton(
    () => input.setTouchAds(true),
    () => input.setTouchAds(false),
  );

  return (
    <div
      className="fixed inset-0 z-[5] touch-none"
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
    >
      {/* Joystick */}
      {joy ? (
        <div
          className="pointer-events-none absolute grid place-items-center rounded-full bg-white/10 ring-2 ring-white/30"
          style={{ left: joy.x - 70, top: joy.y - 70, width: 140, height: 140 }}
        >
          <div ref={knobRef} className="h-14 w-14 rounded-full bg-amber-300/80 shadow-[0_0_18px_rgba(251,191,36,0.6)]" />
        </div>
      ) : (
        <div className="pointer-events-none absolute bottom-7 left-7 grid h-[120px] w-[120px] place-items-center rounded-full bg-white/[0.06] ring-2 ring-white/20">
          <div className="h-12 w-12 rounded-full bg-white/25" />
        </div>
      )}

      {/* Action cluster (bottom-right) */}
      <button
        type="button"
        aria-label="Fire"
        {...fire}
        className="absolute bottom-6 right-6 grid touch-none select-none place-items-center rounded-full bg-gradient-to-b from-amber-300 via-orange-500 to-red-600 font-display text-lg font-black tracking-widest text-white shadow-[0_0_28px_rgba(249,115,22,0.65)] ring-2 ring-amber-200/70 active:scale-95"
        style={{ width: 96, height: 96 }}
      >
        FIRE
      </button>
      <button
        type="button"
        aria-label="Aim"
        {...aim}
        className="absolute bottom-[34px] right-[136px] grid touch-none select-none place-items-center rounded-full bg-black/55 font-display text-xs font-bold tracking-wider text-white ring-1 ring-white/25 active:scale-95"
        style={{ width: 64, height: 64 }}
      >
        AIM
      </button>
      <TapButton label="Jump" size={56} className="bottom-[136px] right-[40px]" onTap={() => input.queue('jump')} />
      <TapButton label="Reload" size={52} className="bottom-[112px] right-[124px]" onTap={() => input.queue('reload')} />
      <TapButton label="Heal" size={52} className="bottom-[126px] right-[196px]" onTap={() => input.queue('heal')} />
      <TapButton label="Pick" size={52} className="bottom-[60px] right-[212px]" onTap={() => input.queue('pick')} />
      <TapButton label="Swap" size={48} className="bottom-[26px] right-[276px]" onTap={() => input.queue('swap')} />
    </div>
  );
}
