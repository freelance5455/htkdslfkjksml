import { useRef, useState } from "react";
import type { Layout } from "@/game/types";
import { cn } from "@/utils/cn";
import { Icon, type IconName } from "./ui";

interface TouchControlsProps {
  layout: Layout;
  grenades: number;
  nearVehicle: boolean;
  inVehicle: boolean;
  crouched: boolean;
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onFire: (down: boolean) => void;
  onJump: () => void;
  onCrouch: () => void;
  onReload: () => void;
  onOpenWeapons: () => void;
  onGrenadeDown: () => void;
  onGrenadeUp: () => void;
  onUse: () => void;
  onAim: (down: boolean) => void;
  onCamera: () => void;
  onPause: () => void;
}

export function TouchControls({
  layout,
  grenades,
  nearVehicle,
  inVehicle,
  crouched,
  onMove,
  onLook,
  onFire,
  onJump,
  onCrouch,
  onReload,
  onOpenWeapons,
  onGrenadeDown,
  onGrenadeUp,
  onUse,
  onAim,
  onCamera,
  onPause,
}: TouchControlsProps) {
  const compact = layout === "compact";
  const joySize = compact ? 104 : 128;
  const knobSize = compact ? 44 : 54;
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const joyPointer = useRef<number | null>(null);
  const joyRef = useRef<HTMLDivElement>(null);
  const lookPointer = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });

  const updateJoy = (clientX: number, clientY: number) => {
    const el = joyRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = rect.width / 2 - 8;
    const len = Math.hypot(dx, dy);
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / max, -dy / max);
  };

  const resetJoy = () => {
    joyPointer.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };

  const btn = compact
    ? { fire: 68, jump: 50, small: 44, tiny: 38, gap: 6, right: 10, bottom: 10 }
    : { fire: 86, jump: 62, small: 54, tiny: 46, gap: 8, right: 14, bottom: 14 };

  const pos = (right: number, bottom: number) => ({ right, bottom });

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none overflow-hidden">
      {/* look area */}
      <div
        className="pointer-events-auto absolute inset-y-0 right-0 w-[58%] touch-none"
        onPointerDown={(e) => {
          if (lookPointer.current !== null) return;
          lookPointer.current = e.pointerId;
          lookLast.current = { x: e.clientX, y: e.clientY };
          try {
            e.currentTarget.setPointerCapture(e.pointerId);
          } catch {
            /* synthetic pointer */
          }
        }}
        onPointerMove={(e) => {
          if (lookPointer.current !== e.pointerId) return;
          const dx = e.clientX - lookLast.current.x;
          const dy = e.clientY - lookLast.current.y;
          lookLast.current = { x: e.clientX, y: e.clientY };
          onLook(dx, dy);
        }}
        onPointerUp={(e) => {
          if (lookPointer.current === e.pointerId) lookPointer.current = null;
        }}
        onPointerCancel={(e) => {
          if (lookPointer.current === e.pointerId) lookPointer.current = null;
        }}
      >
        <div className="pointer-events-none absolute right-3 top-24 hidden text-right text-[8px] font-black uppercase tracking-[0.2em] text-cream/20 min-[500px]:block">
          Свайп — обзор
        </div>
      </div>

      {/* joystick */}
      <div
        ref={joyRef}
        className="pointer-events-auto absolute touch-none rounded-full border-[3px] border-ink/80 bg-ink/35 shadow-[inset_0_0_24px_rgba(0,0,0,0.35)] backdrop-blur-[2px]"
        style={{ width: joySize, height: joySize, left: compact ? 10 : 16, bottom: compact ? 10 : 16 }}
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (joyPointer.current !== null) return;
          joyPointer.current = e.pointerId;
          try {
            e.currentTarget.setPointerCapture(e.pointerId);
          } catch {
            /* synthetic pointer */
          }
          updateJoy(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (joyPointer.current !== e.pointerId) return;
          updateJoy(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (joyPointer.current === e.pointerId) resetJoy();
        }}
        onPointerCancel={(e) => {
          if (joyPointer.current === e.pointerId) resetJoy();
        }}
      >
        <div className="absolute inset-2 rounded-full border-2 border-cream/10" />
        <div className="absolute inset-0 grid place-items-center">
          <div className="relative grid place-items-center rounded-full border-[3px] border-ink bg-cream/90 shadow-[0_4px_0_0_rgba(36,26,53,0.7)]" style={{ width: knobSize, height: knobSize, transform: `translate(${knob.x}px, ${knob.y}px)` }}>
            <div className="grid h-1/2 w-1/2 place-items-center rounded-full border-2 border-ink/20 bg-sun/80">
              <Icon name="crosshair" className="h-4 w-4 text-ink/60" />
            </div>
          </div>
        </div>
        <span className="pointer-events-none absolute -top-4 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase tracking-[0.2em] text-cream/30">Движение</span>
        <span className="pointer-events-none absolute left-1/2 top-1.5 -translate-x-1/2 text-[9px] text-cream/25">▲</span>
        <span className="pointer-events-none absolute bottom-1.5 left-1/2 -translate-x-1/2 text-[9px] text-cream/25">▼</span>
        <span className="pointer-events-none absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] text-cream/25">◀</span>
        <span className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] text-cream/25">▶</span>
      </div>

      {/* action cluster */}
      <div className="absolute inset-0">
        <TouchButton
          icon="crosshair"
          label="Огонь"
          size={btn.fire}
          color="bg-coral"
          textColor="text-white"
          className="absolute rounded-full"
          style={pos(btn.right, btn.bottom)}
          onPress={() => onFire(true)}
          onRelease={() => onFire(false)}
          big
        />
        <TouchButton
          icon="jump"
          label="Прыжок"
          size={btn.jump}
          color="bg-cream"
          className="absolute rounded-full"
          style={pos(btn.right + btn.fire + btn.gap, btn.bottom + 4)}
          onPress={onJump}
        />
        <TouchButton
          icon="crouch"
          label="Присед"
          size={btn.small}
          color={crouched ? "bg-teal" : "bg-panel"}
          textColor={crouched ? "text-ink" : "text-cream"}
          active={crouched}
          className="absolute rounded-full"
          style={pos(btn.right + btn.fire + btn.gap, btn.bottom + btn.jump + btn.gap)}
          onPress={onCrouch}
        />
        <TouchButton
          icon="reload"
          label="Перезарядка"
          size={btn.small}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right, btn.bottom + btn.fire + btn.gap)}
          onPress={onReload}
        />
        <TouchButton
          icon="grenade"
          label={`Граната ${grenades}`}
          size={btn.small}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right + btn.small + btn.gap, btn.bottom + btn.fire + btn.gap)}
          onPress={onGrenadeDown}
          onRelease={onGrenadeUp}
          badge={grenades}
        />
        <TouchButton
          icon="swap"
          label="Оружие"
          size={btn.small}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right + (btn.small + btn.gap) * 2, btn.bottom + btn.fire + btn.gap)}
          onPress={onOpenWeapons}
        />
        <TouchButton
          icon="car"
          label={inVehicle ? "Выйти" : "Машина"}
          size={btn.small}
          color={nearVehicle || inVehicle ? "bg-sun" : "bg-panel"}
          textColor={nearVehicle || inVehicle ? "text-ink" : "text-cream"}
          active={nearVehicle || inVehicle}
          className="absolute rounded-full"
          style={pos(btn.right + btn.fire + btn.gap, btn.bottom + btn.jump + btn.gap + btn.small + btn.gap)}
          onPress={onUse}
        />
        <TouchButton
          icon="use"
          label="Использовать"
          size={btn.tiny}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right + btn.fire + btn.gap + btn.small + btn.gap, btn.bottom + btn.jump + btn.gap + btn.small + btn.gap)}
          onPress={onUse}
        />
        <TouchButton
          icon="target"
          label="Прицел"
          size={btn.tiny}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right + btn.fire + btn.gap + btn.small + btn.gap, btn.bottom + btn.jump + btn.gap + btn.small + btn.gap + btn.tiny + btn.gap)}
          onPress={() => onAim(true)}
          onRelease={() => onAim(false)}
        />
        <TouchButton
          icon="camera"
          label="Камера"
          size={btn.tiny}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right, btn.bottom + btn.fire + btn.gap + btn.small + btn.gap)}
          onPress={onCamera}
        />
        <TouchButton
          icon="pause"
          label="Пауза"
          size={btn.tiny}
          color="bg-panel"
          className="absolute rounded-full"
          style={pos(btn.right + btn.small + btn.gap, btn.bottom + btn.fire + btn.gap + btn.small + btn.gap)}
          onPress={onPause}
        />
      </div>
    </div>
  );
}

function TouchButton({
  icon,
  label,
  size,
  color,
  textColor = "text-cream",
  className,
  style,
  onPress,
  onRelease,
  active,
  badge,
  big,
}: {
  icon: IconName;
  label: string;
  size: number;
  color: string;
  textColor?: string;
  className?: string;
  style: React.CSSProperties;
  onPress: () => void;
  onRelease?: () => void;
  active?: boolean;
  badge?: number;
  big?: boolean;
}) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      type="button"
      aria-label={label}
      className={cn(
        "touch-btn pointer-events-auto grid place-items-center border-[3px] border-ink shadow-[0_4px_0_0_#241a35] transition-transform duration-75",
        color,
        textColor,
        pressed && "translate-y-[3px] scale-95 shadow-[0_1px_0_0_#241a35] brightness-110",
        active && !pressed && "ring-2 ring-sun ring-offset-1 ring-offset-ink",
        className
      )}
      style={{ width: size, height: size, ...style }}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        try {
          e.currentTarget.setPointerCapture(e.pointerId);
        } catch {
          /* synthetic pointer */
        }
        setPressed(true);
        onPress();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setPressed(false);
        onRelease?.();
      }}
      onPointerCancel={() => {
        setPressed(false);
        onRelease?.();
      }}
      onPointerLeave={() => {
        if (pressed) {
          setPressed(false);
          onRelease?.();
        }
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <Icon name={icon} className={big ? "h-8 w-8" : size > 48 ? "h-5 w-5" : "h-4 w-4"} />
      {big && <span className="mt-0.5 font-display text-[8px] font-black uppercase tracking-wider">Огонь</span>}
      {!big && size >= 50 && <span className="mt-0.5 max-w-full truncate px-0.5 text-[6px] font-black uppercase tracking-wide opacity-70">{label}</span>}
      {badge !== undefined && badge >= 0 && (
        <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full border-2 border-ink bg-sun px-0.5 font-mono text-[8px] font-black text-ink">
          {badge}
        </span>
      )}
    </button>
  );
}
