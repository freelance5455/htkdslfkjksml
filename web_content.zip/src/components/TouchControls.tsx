import React, { useCallback } from 'react';
import { Flame, Smartphone } from 'lucide-react';

interface TouchControlsProps {
  onControlChange: (key: 'up' | 'down' | 'left' | 'right' | 'gas' | 'brake' | 'nitro', active: boolean) => void;
  onHorn: () => void;
  onToggleTilt: () => void;
  isTiltEnabled: boolean;
  tiltAngle: number;
  nitro: number;
  isNitroActive: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onControlChange,
  onHorn,
  onToggleTilt,
  isTiltEnabled,
  tiltAngle,
  nitro,
  isNitroActive
}) => {
  const triggerHaptic = useCallback(() => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(15);
      } catch {
        // ignore
      }
    }
  }, []);

  const handleTouchStart = (key: 'up' | 'down' | 'left' | 'right' | 'gas' | 'brake' | 'nitro') => (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    triggerHaptic();
    onControlChange(key, true);
  };

  const handleTouchEnd = (key: 'up' | 'down' | 'left' | 'right' | 'gas' | 'brake' | 'nitro') => (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    onControlChange(key, false);
  };

  return (
    <div 
      dir="ltr"
      className="absolute bottom-0 inset-x-0 p-2 sm:p-4 pointer-events-none z-20 flex flex-col gap-2 select-none font-mono"
    >
      {/* Upper floating actions row (Nitro, Horn, Tilt Toggle) */}
      <div className="flex items-center justify-center gap-4 sm:gap-6 pointer-events-auto pb-1">
        {/* Tilt Phone Steering Toggle */}
        <button
          onClick={(e) => {
            e.preventDefault();
            triggerHaptic();
            onToggleTilt();
          }}
          title="تبديل التحكم بإمالة الهاتف / Phone Tilt Steering"
          className={`h-11 sm:h-12 px-3 sm:px-4 rounded-full border-2 flex items-center gap-1.5 text-xs shadow-lg active:scale-95 transition-all cursor-pointer ${
            isTiltEnabled
              ? 'bg-cyan-500 text-black border-white shadow-cyan-400/50 font-bold'
              : 'bg-black/80 text-gray-300 border-gray-600 hover:text-white'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span className="text-[10px] font-bold font-cairo">
            {isTiltEnabled ? `إمالة: ${Math.round(tiltAngle)}°` : 'إمالة الهاتف'}
          </span>
        </button>

        {/* Circular Nitro Boost Button 🚀 */}
        <button
          onTouchStart={handleTouchStart('nitro')}
          onTouchEnd={handleTouchEnd('nitro')}
          onMouseDown={handleTouchStart('nitro')}
          onMouseUp={handleTouchEnd('nitro')}
          onMouseLeave={handleTouchEnd('nitro')}
          disabled={nitro < 20}
          aria-label="نيترو / Nitro (N)"
          className={`w-13 h-13 sm:w-14 sm:h-14 rounded-full border-3 font-bold flex flex-col items-center justify-center shadow-lg active:scale-90 transition-all cursor-pointer ${
            isNitroActive
              ? 'bg-cyan-400 text-black border-white animate-pulse shadow-cyan-400/60'
              : nitro >= 100
              ? 'bg-gradient-to-b from-cyan-400 to-blue-700 text-white border-cyan-200 shadow-cyan-500/50'
              : nitro >= 20
              ? 'bg-blue-900/90 text-cyan-300 border-cyan-600'
              : 'bg-gray-800 text-gray-500 border-gray-700 opacity-40'
          }`}
        >
          <Flame className="w-5 h-5 sm:w-6 sm:h-6" />
          <span className="text-[7px] font-press-start">NITRO</span>
        </button>

        {/* Circular Klaxon Horn Button 📢 */}
        <button
          onClick={(e) => {
            e.preventDefault();
            triggerHaptic();
            onHorn();
          }}
          aria-label="كلاكسون / Horn (H)"
          className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 active:from-amber-400 active:to-amber-600 border-3 border-amber-300 text-white font-bold flex flex-col items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer"
        >
          <span className="text-xl sm:text-2xl leading-none">📢</span>
          <span className="text-[7px] font-cairo font-bold">بوق</span>
        </button>
      </div>

      {/* Bottom Main Controls Row: Left = Pedals (Gas/Brake), Right = Steering (Left/Right) */}
      <div className="flex items-end justify-between w-full pointer-events-auto px-1 sm:px-3">
        {/* ========================================================
            LEFT SIDE: Gas & Brake Pedals (دواسة البنزين والفرامل)
            Both circular, compact stacked arrangement so it never pushes the right side!
            ======================================================== */}
        <div className="flex items-end gap-2 sm:gap-3 shrink-0">
          {/* Brake Pedal (Circular 🛑) */}
          <button
            onTouchStart={handleTouchStart('brake')}
            onTouchEnd={handleTouchEnd('brake')}
            onMouseDown={handleTouchStart('brake')}
            onMouseUp={handleTouchEnd('brake')}
            onMouseLeave={handleTouchEnd('brake')}
            aria-label="فرامل / Brake"
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-b from-rose-600 via-rose-700 to-rose-950 active:from-rose-500 active:to-rose-800 border-3 sm:border-4 border-rose-400 text-white flex flex-col items-center justify-center shadow-[0_6px_18px_rgba(225,29,72,0.45)] active:scale-90 transition-transform cursor-pointer"
          >
            <span className="text-xl sm:text-2xl leading-none">🛑</span>
            <span className="text-[9px] font-bold font-cairo mt-0.5">فرامل</span>
          </button>

          {/* Gas Pedal (Circular ⛽ - Big, comfortable circle for left thumb) */}
          <button
            onTouchStart={handleTouchStart('gas')}
            onTouchEnd={handleTouchEnd('gas')}
            onMouseDown={handleTouchStart('gas')}
            onMouseUp={handleTouchEnd('gas')}
            onMouseLeave={handleTouchEnd('gas')}
            aria-label="بنزين / Gas"
            className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-gradient-to-b from-emerald-500 via-emerald-600 to-emerald-950 active:from-emerald-400 active:to-emerald-800 border-4 border-emerald-300 text-white flex flex-col items-center justify-center shadow-[0_8px_24px_rgba(16,185,129,0.55)] active:scale-90 transition-transform cursor-pointer"
          >
            <span className="text-2xl sm:text-3xl leading-none">⛽</span>
            <span className="text-[10px] sm:text-xs font-black font-cairo mt-0.5">بنزين</span>
            <span className="text-[8px] text-emerald-200 font-bold">GAS</span>
          </button>
        </div>

        {/* ========================================================
            RIGHT SIDE: Steering Controls (◄ يسار AND ► يمين)
            Both circular, guaranteed visible, distinct side-by-side pair!
            ======================================================== */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* LEFT BUTTON (◄ يسار) */}
          <button
            onTouchStart={handleTouchStart('left')}
            onTouchEnd={handleTouchEnd('left')}
            onMouseDown={handleTouchStart('left')}
            onMouseUp={handleTouchEnd('left')}
            onMouseLeave={handleTouchEnd('left')}
            aria-label="انعطاف يسار / Steer Left"
            className="w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 active:from-amber-400 active:to-amber-500 border-4 border-amber-300 text-white font-black flex flex-col items-center justify-center shadow-[0_8px_22px_rgba(245,158,11,0.55)] active:scale-90 transition-transform cursor-pointer"
          >
            <span className="text-2xl sm:text-3xl leading-none">◄</span>
            <span className="text-[9px] font-cairo font-bold mt-0.5">يسار</span>
          </button>

          {/* RIGHT BUTTON (► يمين) */}
          <button
            onTouchStart={handleTouchStart('right')}
            onTouchEnd={handleTouchEnd('right')}
            onMouseDown={handleTouchStart('right')}
            onMouseUp={handleTouchEnd('right')}
            onMouseLeave={handleTouchEnd('right')}
            aria-label="انعطاف يمين / Steer Right"
            className="w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 active:from-amber-400 active:to-amber-500 border-4 border-amber-300 text-white font-black flex flex-col items-center justify-center shadow-[0_8px_22px_rgba(245,158,11,0.55)] active:scale-90 transition-transform cursor-pointer"
          >
            <span className="text-2xl sm:text-3xl leading-none">►</span>
            <span className="text-[9px] font-cairo font-bold mt-0.5">يمين</span>
          </button>
        </div>
      </div>
    </div>
  );
};
