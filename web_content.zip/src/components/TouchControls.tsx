import React from "react";
import {
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Heart,
  Zap,
  ArrowBigUp,
  Crosshair,
  Sparkles,
} from "lucide-react";
import { UiCustomizationSettings } from "../types";

interface TouchControlsProps {
  isVisible: boolean;
  settings: UiCustomizationSettings;
  equippedToolIcon?: string;
  isSprinting: boolean;
  isJumping: boolean;
  isBareHand?: boolean;
  nearDog?: boolean;
  onDirectionPress: (dir: "up" | "down" | "left" | "right") => void;
  onDirectionRelease: (dir: "up" | "down" | "left" | "right") => void;
  onAction: () => void;
  onHandAction: () => void;
  onSprintToggle: () => void;
  onJump: () => void;
  onPetDog?: () => void;
  onDogSit?: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  isVisible,
  settings,
  equippedToolIcon = "⚡",
  isSprinting,
  isJumping,
  isBareHand = false,
  nearDog = false,
  onDirectionPress,
  onDirectionRelease,
  onAction,
  onHandAction,
  onSprintToggle,
  onJump,
  onPetDog,
  onDogSit,
}) => {
  if (!isVisible || !settings.showDpad) return null;

  // Determine size classes based on user customization (including extra_small for sleek landscape!)
  const dpadSize =
    settings.controllerSize === "extra_small"
      ? "w-24 h-24"
      : settings.controllerSize === "small"
      ? "w-28 h-28"
      : settings.controllerSize === "large"
      ? "w-38 h-38"
      : "w-32 h-32";

  const btnSize =
    settings.controllerSize === "extra_small"
      ? "w-7 h-7 text-[10px]"
      : settings.controllerSize === "small"
      ? "w-8 h-8 text-xs"
      : settings.controllerSize === "large"
      ? "w-11 h-11 text-sm"
      : "w-9 h-9 text-xs";

  const actionBtnSize =
    settings.controllerSize === "extra_small"
      ? "w-12 h-12"
      : settings.controllerSize === "small"
      ? "w-14 h-14"
      : settings.controllerSize === "large"
      ? "w-18 h-18"
      : "w-16 h-16";

  const smallBtnSize =
    settings.controllerSize === "extra_small"
      ? "w-8 h-8"
      : settings.controllerSize === "small"
      ? "w-9 h-9"
      : settings.controllerSize === "large"
      ? "w-12 h-12"
      : "w-10 h-10";

  return (
    <div
      style={{
        opacity: settings.isMinimalMode
          ? Math.min(settings.controllerOpacity, 0.6)
          : settings.controllerOpacity,
      }}
      className="fixed inset-0 pointer-events-none z-30 flex justify-between items-end p-2 select-none"
    >
      {/* LEFT: Ergonomic Landscape Virtual D-Pad */}
      <div
        className={`pointer-events-auto relative ${dpadSize} bg-stone-950/75 backdrop-blur-md rounded-full border-2 border-stone-800/80 shadow-2xl flex items-center justify-center mb-1`}
      >
        {/* UP Button */}
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            onDirectionPress("up");
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            onDirectionRelease("up");
          }}
          onMouseDown={() => onDirectionPress("up")}
          onMouseUp={() => onDirectionRelease("up")}
          className={`absolute top-1 left-1/2 -translate-x-1/2 ${btnSize} bg-stone-800/90 active:bg-amber-600 rounded-xl flex items-center justify-center text-stone-200 cursor-pointer shadow border border-stone-700/60 active:scale-90 transition`}
          title="উপরে যান (Up)"
        >
          <ArrowUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* DOWN Button */}
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            onDirectionPress("down");
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            onDirectionRelease("down");
          }}
          onMouseDown={() => onDirectionPress("down")}
          onMouseUp={() => onDirectionRelease("down")}
          className={`absolute bottom-1 left-1/2 -translate-x-1/2 ${btnSize} bg-stone-800/90 active:bg-amber-600 rounded-xl flex items-center justify-center text-stone-200 cursor-pointer shadow border border-stone-700/60 active:scale-90 transition`}
          title="নিচে যান (Down)"
        >
          <ArrowDown className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* LEFT Button */}
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            onDirectionPress("left");
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            onDirectionRelease("left");
          }}
          onMouseDown={() => onDirectionPress("left")}
          onMouseUp={() => onDirectionRelease("left")}
          className={`absolute left-1 top-1/2 -translate-y-1/2 ${btnSize} bg-stone-800/90 active:bg-amber-600 rounded-xl flex items-center justify-center text-stone-200 cursor-pointer shadow border border-stone-700/60 active:scale-90 transition`}
          title="বামে যান (Left)"
        >
          <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* RIGHT Button */}
        <button
          onTouchStart={(e) => {
            e.preventDefault();
            onDirectionPress("right");
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            onDirectionRelease("right");
          }}
          onMouseDown={() => onDirectionPress("right")}
          onMouseUp={() => onDirectionRelease("right")}
          className={`absolute right-1 top-1/2 -translate-y-1/2 ${btnSize} bg-stone-800/90 active:bg-amber-600 rounded-xl flex items-center justify-center text-stone-200 cursor-pointer shadow border border-stone-700/60 active:scale-90 transition`}
          title="ডানে যান (Right)"
        >
          <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>

        {/* Center Hub */}
        <div className="w-5 h-5 rounded-full bg-stone-900 border border-stone-700 flex items-center justify-center">
          <Crosshair className="w-3 h-3 text-stone-500" />
        </div>
      </div>

      {/* RIGHT: Sprint, Jump, Hand & Main Action Controls */}
      <div className="pointer-events-auto flex flex-col items-end gap-1.5 mb-1">
        {/* Upper Action Row: Pet, Hand (✋), Jump (🦘) & Sprint (⚡) */}
        <div className="flex items-center gap-1.5 flex-wrap justify-end">
          {/* Sit Button (Contextual when near dog - as requested: "when tojo go near the dogs there button appears name sit the dog sits") */}
          {nearDog && (
            <button
              onClick={() => {
                window.dispatchEvent(new CustomEvent("game-dog-sit"));
                if (onDogSit) onDogSit();
              }}
              onTouchStart={(e) => {
                e.preventDefault();
                window.dispatchEvent(new CustomEvent("game-dog-sit"));
                if (onDogSit) onDogSit();
              }}
              className={`${smallBtnSize} rounded-full bg-emerald-600 active:bg-emerald-500 text-white shadow-xl border-2 border-emerald-300 flex flex-col items-center justify-center cursor-pointer transform active:scale-95 transition animate-pulse`}
              title="কুকুরকে বসতে বলুন (Sit command) [T / Sit]"
            >
              <span className="text-xs leading-none">🐕</span>
              <span className="text-[7px] font-black font-mono tracking-tighter uppercase">Sit</span>
            </button>
          )}

          {/* Pet Button (Contextual when near dog) */}
          {nearDog && (
            <button
              onClick={onPetDog}
              className={`${smallBtnSize} rounded-full bg-rose-600 active:bg-rose-500 text-white shadow-lg border-2 border-rose-300 flex flex-col items-center justify-center cursor-pointer transform active:scale-90 transition`}
              title="কালু কুকুরকে আদর করুন"
            >
              <Heart className="w-3.5 h-3.5 fill-rose-200 text-white" />
              <span className="text-[7px] font-bold">আদর</span>
            </button>
          )}

          {/* DEDICATED HAND BUTTON (✋ হাত / Bare Hand) */}
          {settings.showHandButton && (
            <button
              onClick={onHandAction}
              onTouchStart={(e) => {
                e.preventDefault();
                onHandAction();
              }}
              className={`${smallBtnSize} rounded-full flex flex-col items-center justify-center font-bold shadow-lg border-2 cursor-pointer transition transform active:scale-90 ${
                isBareHand
                  ? "bg-amber-500 text-stone-950 border-yellow-200 shadow-yellow-500/40 scale-105 animate-pulse"
                  : "bg-stone-800/90 active:bg-amber-600 text-amber-200 border-amber-500/60"
              }`}
              title="খালি হাত নির্বাচন / কুকুরকে শান্ত করুন ও ফসল তুলুন (Bare Hand / Peace)"
            >
              <span className="text-sm sm:text-base leading-none">✋</span>
              <span className="text-[7px] font-mono leading-none mt-0.5">হাত</span>
            </button>
          )}

          {/* JUMP BUTTON (🦘 লাফ) */}
          {settings.showJumpButton && (
            <button
              onClick={() => {
                window.dispatchEvent(new CustomEvent("game-jump"));
                onJump();
              }}
              onTouchStart={(e) => {
                e.preventDefault();
                window.dispatchEvent(new CustomEvent("game-jump"));
                onJump();
              }}
              className={`${smallBtnSize} rounded-full flex flex-col items-center justify-center font-bold text-xs shadow-lg border-2 cursor-pointer transition transform active:scale-90 ${
                isJumping
                  ? "bg-sky-500 text-white border-sky-300 scale-105"
                  : "bg-stone-800/90 active:bg-sky-600 text-sky-300 border-sky-500/50"
              }`}
              title="লাফ দিন (Jump over obstacles, water, and fences) [Space/J]"
            >
              <ArrowBigUp className="w-4 h-4" />
              <span className="text-[7px] font-mono leading-none mt-0.5">লাফ</span>
            </button>
          )}

          {/* SPRINT BUTTON (⚡ দৌড়) */}
          {settings.showSprintButton && (
            <button
              onClick={() => {
                window.dispatchEvent(new CustomEvent("game-sprint"));
                onSprintToggle();
              }}
              onTouchStart={(e) => {
                e.preventDefault();
                window.dispatchEvent(new CustomEvent("game-sprint"));
                onSprintToggle();
              }}
              className={`${smallBtnSize} rounded-full flex flex-col items-center justify-center font-bold text-xs shadow-lg border-2 cursor-pointer transition transform active:scale-90 ${
                isSprinting
                  ? "bg-amber-500 text-stone-950 border-amber-300 shadow-amber-500/50 scale-105 animate-pulse"
                  : "bg-stone-800/90 active:bg-amber-600 text-amber-300 border-amber-500/50"
              }`}
              title="দ্রুত দৌড়ান (Sprint) [Shift]"
            >
              <Zap className="w-4 h-4" />
              <span className="text-[7px] font-mono leading-none mt-0.5">দৌড়</span>
            </button>
          )}
        </div>

        {/* Lower Row: Main Tool Action Button */}
        <button
          onClick={onAction}
          onTouchStart={(e) => {
            e.preventDefault();
            onAction();
          }}
          className={`${actionBtnSize} rounded-2xl bg-gradient-to-br from-amber-600 to-amber-700 active:from-amber-500 active:to-amber-600 text-white shadow-2xl border-2 border-amber-400 flex flex-col items-center justify-center font-bold cursor-pointer transform active:scale-90 transition`}
          title="অ্যাকশন (বাছাইকৃত টুল বা হাত ব্যবহার করুন)"
        >
          <span className="text-lg sm:text-2xl filter drop-shadow leading-none">
            {equippedToolIcon}
          </span>
          <span className="text-[8px] sm:text-[9px] text-amber-200 font-mono mt-0.5 leading-none">
            অ্যাকশন
          </span>
        </button>
      </div>
    </div>
  );
};
