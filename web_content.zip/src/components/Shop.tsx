import { useEffect, useState } from "react";
import {
  ALL_ITEMS,

  RARITY_TINT,
  SLOT_LABEL,
  UPGRADES,
  WHEEL_ITEMS,
  itemById,
  type Slot,
} from "../lib/catalog";
import { store, upgradeCost, upgradeLevel, useStore, clickReward, stamina, restMs } from "../lib/store";
import { toFa } from "../lib/fa";
import { boop, fanfare } from "../lib/sound";
import { CheckIcon, CoinIcon, CloseIcon, LockIcon } from "./icons";
import { ItemIcon } from "./ItemIcon";

type Tab = Slot | "upgrade";

const TABS: { id: Tab; label: string }[] = [
  { id: "upgrade", label: "ارتقا" },
  { id: "color", label: SLOT_LABEL.color },
  { id: "suit", label: SLOT_LABEL.suit },
  { id: "hat", label: SLOT_LABEL.hat },
  { id: "glasses", label: SLOT_LABEL.glasses },
  { id: "neck", label: SLOT_LABEL.neck },
  { id: "buddy", label: SLOT_LABEL.buddy },
];

function Price({ value, afford }: { value: number; afford: boolean }) {
  return (
    <span
      className={`inline-flex items-center gap-1 text-[11px] font-black tabular-nums ${
        afford ? "text-amber-900" : "text-amber-900/35"
      }`}
    >
      <CoinIcon className="size-3.5" />
      {toFa(value)}
    </span>
  );
}

function ItemCard({ id }: { id: string }) {
  const item = itemById(id)!;
  const owned = useStore((s) => s.owned.includes(id));
  const active = useStore((s) => s.equipped[item.slot] === id);
  const points = useStore((s) => s.points);
  const afford = points >= item.price;

  // wheel-exclusives are visible in their category but can only be unlocked
  // by spinning — never bought
  const wheelLocked = !!item.wheel && !owned;

  const onClick = () => {
    if (wheelLocked) {
      store.setShop(false);
      store.goWheel();
      return;
    }
    if (owned) {
      store.equip(id);
      boop();
    } else {
      const before = store.get().owned.length;
      store.buy(id);
      if (store.get().owned.length > before) fanfare();
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      className={`group relative flex flex-col items-center gap-1 rounded-2xl border p-2 transition duration-200 ${
        active
          ? "border-amber-400 bg-amber-400/25 shadow-[0_0_0_3px_rgba(245,158,11,0.2)]"
          : owned
            ? "tile hover:-translate-y-0.5"
            : wheelLocked
              ? "border-fuchsia-400/60 bg-fuchsia-500/15 hover:-translate-y-0.5"
              : afford
                ? "tile hover:-translate-y-0.5"
                : "border-white/10 bg-white/5 opacity-60"
      }`}
    >
      {/* rarity ribbon for wheel pieces */}
      {item.rarity && (
        <span
          className="absolute top-1 left-1 size-2 rounded-full"
          style={{ background: RARITY_TINT[item.rarity] }}
        />
      )}

      <span className="relative grid size-12 place-items-center">
        <ItemIcon id={id} locked={wheelLocked} className="size-full" />

        {active && (
          <span className="absolute -right-1 -bottom-1 grid size-4.5 place-items-center rounded-full bg-amber-500 text-white ring-2 ring-white">
            <CheckIcon className="size-3" />
          </span>
        )}
        {wheelLocked && (
          <span className="absolute -right-1 -bottom-1 grid size-4.5 place-items-center rounded-full bg-fuchsia-600 text-white ring-2 ring-white">
            <LockIcon className="size-2.5" />
          </span>
        )}
        {!owned && !wheelLocked && (
          <span className="absolute -right-1 -bottom-1 grid size-4 place-items-center rounded-full bg-amber-950/80 text-amber-100">
            <LockIcon className="size-2.5" />
          </span>
        )}
      </span>

      <span className="line-clamp-1 text-[10px] leading-4 font-bold text-amber-950">
        {item.name}
      </span>

      {owned ? (
        <span className="text-[9.5px] font-bold text-amber-700/75">
          {active ? "پوشیده ✓" : item.slot === "color" ? "انتخاب" : "بپوش"}
        </span>
      ) : wheelLocked ? (
        <span className="inline-flex items-center gap-0.5 text-[9.5px] font-black text-fuchsia-700">
          🎡 از گردونه
        </span>
      ) : (
        <Price value={item.price} afford={afford} />
      )}
    </button>
  );
}

function UpgradeRow({ id }: { id: string }) {
  const def = UPGRADES.find((u) => u.id === id)!;
  const lvl = useStore((s) => upgradeLevel(id, s));
  const cost = useStore((s) => upgradeCost(id, s));
  const points = useStore((s) => s.points);
  const maxed = lvl >= def.max;
  const afford = points >= cost;

  return (
    <div className="flex items-center gap-3 rounded-2xl tile p-2.5">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="text-[12.5px] font-black text-amber-950">{def.name}</span>
          <span className="rounded-full bg-amber-900/10 px-1.5 py-px text-[9.5px] font-bold text-amber-900/60">
            {toFa(lvl)}/{toFa(def.max)}
          </span>
        </div>
        <p className="mt-0.5 text-[10.5px] leading-4 text-amber-900/55">{def.desc}</p>
        <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-amber-900/10">
          <div
            className="h-full rounded-full bg-gradient-to-l from-amber-400 to-amber-500 transition-[width] duration-500"
            style={{ width: `${(lvl / def.max) * 100}%` }}
          />
        </div>
      </div>
      <button
        type="button"
        disabled={maxed}
        onClick={() => {
          const before = store.get().upgrades[id] ?? 0;
          store.upgrade(id);
          if ((store.get().upgrades[id] ?? 0) > before) fanfare();
        }}
        className={`shrink-0 rounded-xl px-3 py-2 text-[11px] font-extrabold transition duration-200 ${
          maxed
            ? "bg-amber-900/10 text-amber-900/40"
            : afford
              ? "bg-gradient-to-b from-amber-400 to-amber-500 text-amber-950 shadow-[0_6px_14px_-8px_rgba(180,83,9,0.9)] hover:-translate-y-0.5"
              : "bg-white/8 text-violet-200/40"
        }`}
      >
        {maxed ? "کامل" : <Price value={cost} afford={afford} />}
      </button>
    </div>
  );
}

function Stats() {
  const per = useStore(clickReward);
  const st = useStore(stamina);
  const rest = useStore(restMs);
  const cells = [
    { label: "پوینت هر ۳ کلیک", value: toFa(per) },
    { label: "کار تا خستگی", value: toFa(st) },
    { label: "مدت خواب", value: `${toFa(Math.round(rest / 60000))} دق` },
  ];
  return (
    <div className="grid grid-cols-3 gap-1.5">
      {cells.map((c) => (
        <div key={c.label} className="tile-soft rounded-xl px-2 py-1.5 text-center">
          <div className="text-sm font-black tabular-nums text-amber-950">{c.value}</div>
          <div className="text-[9.5px] font-semibold text-amber-900/50">{c.label}</div>
        </div>
      ))}
    </div>
  );
}

/** Slim banner: how much of the wheel-only set is unlocked. */
function CollectionBar({ slot }: { slot: Slot }) {
  const owned = useStore((s) => s.owned);
  const pool = WHEEL_ITEMS.filter((i) => i.slot === slot);
  if (!pool.length) return null;
  const have = pool.filter((i) => owned.includes(i.id)).length;

  return (
    <button
      type="button"
      onClick={() => {
        store.setShop(false);
        store.goWheel();
      }}
      className="mb-2 flex w-full items-center gap-2 rounded-2xl border border-fuchsia-300/70 bg-gradient-to-l from-fuchsia-500/25 to-amber-400/10 px-3 py-2 text-right transition hover:-translate-y-0.5"
    >
      <span className="text-base">🎡</span>
      <div className="min-w-0 flex-1">
        <div className="text-[10.5px] font-black text-purple-950">
          آیتم‌های ویژه‌ی گردونه — {toFa(have)} از {toFa(pool.length)}
        </div>
        <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/12">
          <div
            className="h-full rounded-full bg-gradient-to-l from-fuchsia-500 to-amber-400 transition-[width] duration-500"
            style={{ width: `${(have / pool.length) * 100}%` }}
          />
        </div>
      </div>
      <span className="shrink-0 text-[9.5px] font-black text-fuchsia-700">بچرخون ›</span>
    </button>
  );
}

export function Shop() {
  const open = useStore((s) => s.shopOpen);
  const points = useStore((s) => s.points);
  const [tab, setTab] = useState<Tab>("upgrade");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") store.setShop(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  if (!open) return null;

  // every slot shows its shop items followed by its wheel-exclusive pieces
  const items =
    tab === "upgrade"
      ? []
      : ALL_ITEMS.filter((i) => i.slot === tab).sort(
          (x, y) => Number(!!x.wheel) - Number(!!y.wheel) || x.price - y.price,
        );

  return (
    <div className="pointer-events-auto fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <div
        className="fade-in absolute inset-0 bg-amber-950/70"
        onClick={() => store.setShop(false)}
      />

      <div className="sheet panel relative m-0 flex max-h-[88dvh] w-full flex-col overflow-hidden rounded-t-3xl sm:m-4 sm:max-w-md sm:rounded-3xl">
        {/* header */}
        <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-white/[0.06] px-4 py-3">
          <div>
            <h2 className="text-[15px] font-black text-amber-950">فروشگاه جیکو</h2>
            <p className="text-[10.5px] font-medium text-amber-900/50">
              با ضربه زدن پوینت بگیر و خرید کن
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-950/85 px-3 py-1.5 text-[12px] font-black tabular-nums text-amber-100">
              <CoinIcon className="size-3.5 text-amber-300" />
              {toFa(points)}
            </span>
            <button
              type="button"
              aria-label="بستن"
              onClick={() => {
                store.setShop(false);
                boop();
              }}
              className="grid size-8 place-items-center rounded-xl bg-white/12 text-violet-100 ring-1 ring-white/15 transition hover:bg-white/20"
            >
              <CloseIcon className="size-4" />
            </button>
          </div>
        </div>

        {/* tabs */}
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto px-3 py-2.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setTab(t.id);
                boop();
              }}
              className={`shrink-0 rounded-full px-3 py-1.5 text-[11.5px] font-bold transition ${
                tab === t.id
                  ? "bg-amber-950/85 text-amber-50"
                  : "bg-white/8 text-violet-200/80 ring-1 ring-white/10 hover:bg-white/16"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* body */}
        <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-3 pt-1 pb-4">
          {tab === "upgrade" ? (
            <div className="flex flex-col gap-2">
              <Stats />
              {UPGRADES.map((u) => (
                <UpgradeRow key={u.id} id={u.id} />
              ))}
            </div>
          ) : (
            <>
              <CollectionBar slot={tab as Slot} />
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                {items.map((i) => (
                  <ItemCard key={i.id} id={i.id} />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
