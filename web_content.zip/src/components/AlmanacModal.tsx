import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { ALL_SPECIES } from '../data/species.ts';
import { ALL_RECIPES } from '../data/recipes.ts';
import { BookOpen, Trophy, Search, CheckCircle2, X } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AlmanacModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AlmanacModal: React.FC<AlmanacModalProps> = ({ isOpen, onClose }) => {
  const { player } = useGame();
  const [almanacTab, setAlmanacTab] = useState<'species' | 'recipes'>('species');
  const [searchTerm, setSearchTerm] = useState<string>('');

  if (!isOpen) return null;

  const totalSpecies = ALL_SPECIES.length;
  const discoveredSpeciesCount = Object.keys(player.speciesMastery).length;
  const speciesProgress = Math.min(100, Math.round((discoveredSpeciesCount / totalSpecies) * 100));

  const totalRecipes = ALL_RECIPES.length;
  const unlockedRecipesCount = player.unlockedRecipes.length;
  const recipeProgress = Math.min(100, Math.round((unlockedRecipesCount / totalRecipes) * 100));

  const milestones = [
    { target: 10, perk: 'Tăng +5% tốc độ sinh trưởng toàn nông trại' },
    { target: 25, perk: 'Tăng +10% giá bán nông sản tại Thương Cảng' },
    { target: 50, perk: 'Tăng +15% tỷ lệ ra sản phẩm Ánh Kim ⭐' },
    { target: 75, perk: 'Giảm -15% thời gian chế biến toàn xưởng' },
    { target: 100, perk: 'Danh hiệu Nông Vương Chí Tôn (+30% Vàng & EXP vĩnh viễn)' },
  ];

  const filteredSpecies = ALL_SPECIES.filter((s) => {
    if (searchTerm && !s.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const filteredRecipes = ALL_RECIPES.filter((r) => {
    if (searchTerm && !r.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in">
      <div className="bg-stone-900 border-2 border-stone-700 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-stone-950 p-4 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl sm:text-3xl">📖</span>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-emerald-400">
                Bách Khoa Toàn Thư Nông Trại
              </h2>
              <p className="text-xs text-stone-400">
                Tra cứu 365+ loài sinh vật & 400+ thành phẩm chế biến • Nhận thưởng mốc sưu tầm
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition"
            aria-label="Đóng Bách Khoa"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Milestone Rewards Progress Bar */}
        <div className="bg-stone-950/80 p-3 border-b border-stone-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-300 font-bold flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              Tiến Độ Sưu Tầm Toàn Diện:
            </span>
            <strong className="text-emerald-400 font-black">
              {speciesProgress}% Loài ({discoveredSpeciesCount}/{totalSpecies}) • {recipeProgress}% Công Thức ({unlockedRecipesCount}/{totalRecipes})
            </strong>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
            {milestones.map((m) => {
              const reached = speciesProgress >= m.target;
              return (
                <div
                  key={m.target}
                  className={`p-2 rounded-xl border text-[10px] space-y-0.5 ${
                    reached
                      ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-200'
                      : 'bg-stone-900 border-stone-800 text-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>Mốc {m.target}%</span>
                    {reached && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                  </div>
                  <p className="text-[9px] line-clamp-2">{m.perk}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tab & Search */}
        <div className="bg-stone-900/90 border-b border-stone-800 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setAlmanacTab('species')}
              className={`px-3 py-1.5 rounded-xl border font-bold transition ${
                almanacTab === 'species'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
            >
              🌱 365+ Giống Loài Sinh Học
            </button>

            <button
              type="button"
              onClick={() => setAlmanacTab('recipes')}
              className={`px-3 py-1.5 rounded-xl border font-bold transition ${
                almanacTab === 'recipes'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
            >
              🥐 400+ Thành Phẩm Chế Biến
            </button>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-stone-500 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Tìm kiếm..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-stone-800 border border-stone-700 rounded-lg pl-8 pr-2.5 py-1 text-stone-200 placeholder-stone-500 text-xs w-48"
            />
          </div>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-4">
          {almanacTab === 'species' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {filteredSpecies.slice(0, 150).map((sp) => {
                const mastery = player.speciesMastery[sp.id] || 0;
                return (
                  <div
                    key={sp.id}
                    className="bg-stone-950 border border-stone-800 rounded-2xl p-3 flex flex-col justify-between space-y-1.5 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-3xl p-1 bg-stone-800 rounded-xl">{sp.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-stone-100 truncate">{sp.name}</h4>
                          <span className="text-[9px] px-1 bg-stone-800 text-amber-400 rounded border border-amber-600/40">
                            Bậc {sp.tier}
                          </span>
                        </div>
                        <div className="text-[10px] text-stone-400">
                          Mở khóa: Cấp {sp.unlockLevel} • {sp.growthTime}s
                        </div>
                      </div>
                    </div>

                    <p className="text-[11px] text-stone-400 line-clamp-2">{sp.description}</p>

                    <div className="flex items-center justify-between pt-1 border-t border-stone-800/80 text-[10px]">
                      <span className="text-emerald-400 font-semibold">
                        Thu hoạch: {mastery} lần
                      </span>
                      <span className="text-amber-400 font-bold">
                        Bán: {sp.baseSellPrice} 🪙
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {filteredRecipes.slice(0, 150).map((rec) => {
                const isUnlocked = player.unlockedRecipes.includes(rec.id);
                return (
                  <div
                    key={rec.id}
                    className={`bg-stone-950 border rounded-2xl p-3 flex flex-col justify-between space-y-1.5 text-xs ${
                      isUnlocked ? 'border-stone-800' : 'border-stone-800/50 opacity-70'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-3xl p-1 bg-stone-800 rounded-xl">{rec.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-stone-100 truncate">{rec.name}</h4>
                          <span className="text-[9px] px-1 bg-stone-800 text-amber-400 rounded border border-amber-600/40">
                            Bậc {rec.tier}
                          </span>
                        </div>
                        <div className="text-[10px] text-stone-400">
                          Dây chuyền: {rec.machineId} • Cấp {rec.unlockLevel}
                        </div>
                      </div>
                    </div>

                    <p className="text-[11px] text-stone-400 line-clamp-2">{rec.description}</p>

                    <div className="flex items-center justify-between pt-1 border-t border-stone-800/80 text-[10px]">
                      <span className={isUnlocked ? 'text-emerald-400 font-bold' : 'text-stone-500'}>
                        {isUnlocked ? '✓ Đã mở khóa' : 'Chưa học'}
                      </span>
                      <span className="text-amber-400 font-bold">+{rec.expPerUnit} EXP</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
