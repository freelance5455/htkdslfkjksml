import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  BookOpen,
  CheckCheck,
  ChevronRight,
  Code2,
  HardDriveDownload,
  RotateCcw,
} from 'lucide-react';
import type { ColorMode, ComicEntry, ReadStatus, TocBookmark } from '../types/comic';

interface ComicDetailViewProps {
  comic: ComicEntry;
  colorMode: ColorMode;
  onBack: () => void;
  onResumeReading: (comic: ComicEntry) => void;
  onReadAtPage: (comic: ComicEntry, pageIndex: number) => void;
  onToggleOffline: (comic: ComicEntry) => void;
  onSetReadStatus: (comic: ComicEntry, status: ReadStatus) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const ComicDetailView: React.FC<ComicDetailViewProps> = ({
  comic,
  colorMode,
  onBack,
  onResumeReading,
  onReadAtPage,
  onToggleOffline,
  onSetReadStatus,
}) => {
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [showRawXml, setShowRawXml] = useState(false);

  useEffect(() => {
    if (!comic.coverBlob) {
      setCoverUrl(null);
      return;
    }
    const url = URL.createObjectURL(comic.coverBlob);
    setCoverUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [comic.coverBlob]);

  const info = comic.comicInfo;
  const chapters: TocBookmark[] = [
    ...(info?.toc || []),
    ...(comic.userBookmarks || []),
  ].sort((a, b) => a.pageIndex - b.pageIndex);

  const hasStarted =
    comic.readStatus === 'completed' ||
    comic.readStatus === 'reading' ||
    comic.currentPage > 0 ||
    comic.scrollProgress > 0.02 ||
    Boolean(comic.lastReadAt);

  const progressPct =
    comic.readStatus === 'completed'
      ? 100
      : comic.pageCount > 1
        ? Math.min(
            100,
            Math.round(
              Math.max(
                ((comic.currentPage + 1) / comic.pageCount) * 100,
                (comic.scrollProgress || 0) * 100,
              ),
            ),
          )
        : Math.round((comic.scrollProgress || 0) * 100);

  const headerSub = [
    info?.series,
    info?.number ? `Issue #${info.number}` : null,
    info?.volume !== undefined ? `Vol. ${info.volume}` : null,
    `${comic.pageCount} pages`,
    comic.format.toUpperCase(),
  ]
    .filter(Boolean)
    .join(' · ');

  const metadataFields: { label: string; value?: string }[] = [
    { label: 'Author / Writer', value: info?.writer },
    { label: 'Series', value: info?.series },
    { label: 'Penciller', value: info?.penciller },
    { label: 'Inker', value: info?.inker },
    { label: 'Colorist', value: info?.colorist },
    { label: 'Letterer', value: info?.letterer },
    { label: 'Cover Artist', value: info?.coverArtist },
    { label: 'Editor', value: info?.editor },
    { label: 'Publisher', value: info?.publisher },
    {
      label: 'Issue / Volume',
      value:
        [
          info?.number ? `#${info.number}` : null,
          info?.volume !== undefined ? `Vol. ${info.volume}` : null,
          info?.count !== undefined ? `of ${info.count}` : null,
        ]
          .filter(Boolean)
          .join(' · ') || undefined,
    },
    {
      label: 'Release Date',
      value:
        [info?.year, info?.month, info?.day]
          .filter((v) => v !== undefined)
          .join('-') || undefined,
    },
    { label: 'Genre', value: info?.genre },
    { label: 'Tags', value: info?.tags },
    { label: 'Story Arc', value: info?.storyArc },
    { label: 'Language', value: info?.languageISO?.toUpperCase() },
    { label: 'Manga Layout', value: info?.manga },
    { label: 'Age Rating', value: info?.ageRating },
    {
      label: 'Archive File',
      value: `${comic.fileName} (${formatBytes(comic.fileSize)})`,
    },
    {
      label: 'Image Formats',
      value: comic.imageFormatsFound.length > 0 ? comic.imageFormatsFound.join(', ') : undefined,
    },
    { label: 'Local Folder', value: comic.folderName },
  ].filter((item) => Boolean(item.value));

  const barBgClass =
    colorMode === 'amoled'
      ? 'bg-black/90 border-zinc-900'
      : 'bg-white/90 dark:bg-zinc-950/90 border-zinc-200/80 dark:border-zinc-800/80';

  const cardSurfaceClass =
    colorMode === 'amoled'
      ? 'bg-zinc-950 border-zinc-900'
      : 'bg-white dark:bg-zinc-900/60 border-zinc-200/80 dark:border-zinc-800';

  return (
    <div className="space-y-8 pb-8">
      {/* Sticky Sub-Header */}
      <div
        className={`sticky top-14 z-20 -mx-4 sm:-mx-6 px-4 sm:px-6 py-2.5 backdrop-blur-md border-b ${barBgClass} flex items-center justify-between gap-3`}
      >
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 min-h-[44px] px-2 -ml-2 rounded-xl text-sm font-medium text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 shrink-0" />
          <span>Library</span>
        </button>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => onToggleOffline(comic)}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-3 rounded-xl text-xs font-medium border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors whitespace-nowrap"
          >
            <HardDriveDownload className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">
              {comic.isOfflineCached ? 'Offline Ready' : 'Cache Offline'}
            </span>
          </button>

          <button
            type="button"
            onClick={() =>
              onSetReadStatus(comic, comic.readStatus === 'completed' ? 'unread' : 'completed')
            }
            className="inline-flex items-center gap-1.5 min-h-[44px] px-3 rounded-xl text-xs font-medium border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors whitespace-nowrap"
          >
            {comic.readStatus === 'completed' ? (
              <>
                <RotateCcw className="w-4 h-4 shrink-0" />
                <span className="hidden sm:inline">Mark Unread</span>
              </>
            ) : (
              <>
                <CheckCheck className="w-4 h-4 shrink-0" />
                <span className="hidden sm:inline">Mark Read</span>
              </>
            )}
          </button>

          {info?.rawXml && (
            <button
              type="button"
              onClick={() => setShowRawXml((v) => !v)}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-3 rounded-xl text-xs font-medium border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors whitespace-nowrap"
              title="Inspect ComicInfo.xml"
            >
              <Code2 className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{showRawXml ? 'Hide XML' : 'XML'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Top Cover & Title Block */}
      <section className="max-w-4xl mx-auto flex flex-col items-center text-center space-y-5 pt-2">
        <div className="w-48 sm:w-56 md:w-60 aspect-[3/4] rounded-2xl overflow-hidden bg-zinc-200 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-lg">
          {coverUrl ? (
            <img
              src={coverUrl}
              alt={`${comic.displayTitle} cover`}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-zinc-500">
              <BookOpen className="w-10 h-10 mb-2" />
              <span className="text-xs font-medium">{comic.displayTitle}</span>
            </div>
          )}
        </div>

        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400 font-mono-nums">
            {headerSub}
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-zinc-900 dark:text-zinc-100 text-balance leading-tight">
            {comic.displayTitle}
          </h1>
          {(info?.writer || info?.penciller) && (
            <p className="text-sm text-zinc-600 dark:text-zinc-300">
              {[
                info.writer ? `By ${info.writer}` : null,
                info.penciller && info.penciller !== info.writer
                  ? `Art by ${info.penciller}`
                  : null,
              ]
                .filter(Boolean)
                .join(' · ')}
            </p>
          )}
        </div>

        {/* Primary Action & Progress */}
        <div className="w-full max-w-xs space-y-2.5">
          <button
            type="button"
            onClick={() => onResumeReading(comic)}
            className="w-full min-h-[48px] px-6 py-3 rounded-xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 transition-opacity hover:opacity-90 shadow-sm"
            style={{ backgroundColor: 'var(--app-accent)' }}
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span>
              {comic.readStatus === 'completed'
                ? 'Read Again'
                : hasStarted
                  ? `Resume · Page ${comic.currentPage + 1}`
                  : 'Start Reading'}
            </span>
          </button>

          {hasStarted && (
            <div className="space-y-1">
              <div className="h-1.5 w-full rounded-full bg-zinc-200 dark:bg-zinc-800 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${Math.max(4, progressPct)}%`,
                    backgroundColor: 'var(--app-accent)',
                  }}
                />
              </div>
              <p className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400">
                {comic.readStatus === 'completed'
                  ? 'Completed'
                  : `${progressPct}% read · Page ${comic.currentPage + 1} of ${comic.pageCount}`}
              </p>
            </div>
          )}
        </div>

        {info?.summary && (
          <p className="max-w-2xl text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed text-left sm:text-center pt-1">
            {info.summary}
          </p>
        )}
      </section>

      {/* Raw XML Inspector (when toggled) */}
      {showRawXml && info?.rawXml && (
        <section className="max-w-4xl mx-auto">
          <pre className="p-4 rounded-2xl bg-zinc-950 text-zinc-200 text-xs font-mono-nums overflow-x-auto max-h-72 border border-zinc-800">
            {info.rawXml}
          </pre>
        </section>
      )}

      {/* ComicInfo Metadata Section */}
      <section className={`max-w-4xl mx-auto p-5 sm:p-6 rounded-2xl border ${cardSurfaceClass}`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
            Comic Information
          </h2>
          <span className="text-xs text-zinc-500 dark:text-zinc-400">
            {info ? 'ComicInfo.xml Metadata' : 'Archive Details'}
          </span>
        </div>

        <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3.5 text-sm">
          {metadataFields.map((field) => (
            <div key={field.label} className="min-w-0">
              <dt className="text-xs text-zinc-500 dark:text-zinc-400">{field.label}</dt>
              <dd className="mt-0.5 text-zinc-900 dark:text-zinc-100 font-medium break-words">
                {field.value}
              </dd>
            </div>
          ))}
        </dl>
      </section>

      {/* Chapters & Table of Contents List Below */}
      <section className="max-w-4xl mx-auto space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
              Chapters &amp; Contents
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {chapters.length > 0
                ? `${chapters.length} chapter${chapters.length === 1 ? '' : 's'} & bookmark${chapters.length === 1 ? '' : 's'} from ComicInfo.xml`
                : 'No chapter markers embedded in ComicInfo.xml'}
            </p>
          </div>
        </div>

        <div
          className={`divide-y divide-zinc-200/70 dark:divide-zinc-800 rounded-2xl border overflow-hidden ${cardSurfaceClass}`}
        >
          {chapters.length > 0 ? (
            chapters.map((chapter, idx) => {
              const isCurrent =
                hasStarted &&
                chapter.pageIndex <= comic.currentPage &&
                (idx === chapters.length - 1 || chapters[idx + 1].pageIndex > comic.currentPage);
              return (
                <button
                  key={`${chapter.pageIndex}-${chapter.title}-${idx}`}
                  type="button"
                  onClick={() => onReadAtPage(comic, chapter.pageIndex)}
                  className="w-full min-h-[60px] px-4 sm:px-5 py-3 flex items-center justify-between gap-4 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <span
                      className="text-xs font-mono-nums w-6 shrink-0 text-zinc-400 dark:text-zinc-500"
                      style={isCurrent ? { color: 'var(--app-accent)' } : undefined}
                    >
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                        {chapter.title}
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                        {chapter.source === 'user'
                          ? 'Saved Bookmark'
                          : chapter.source === 'bookmarks-tag'
                            ? 'ComicInfo Bookmark'
                            : chapter.type || 'Chapter'}
                        {isCurrent ? ' · Currently reading' : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-zinc-500 dark:text-zinc-400">
                    <span className="text-xs font-mono-nums">
                      Page {chapter.pageIndex + 1}
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </button>
              );
            })
          ) : (
            <button
              type="button"
              onClick={() => onReadAtPage(comic, 0)}
              className="w-full min-h-[60px] px-4 sm:px-5 py-3 flex items-center justify-between gap-4 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <Bookmark
                  className="w-4 h-4 shrink-0"
                  style={{ color: 'var(--app-accent)' }}
                />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                    Full Issue — {comic.displayTitle}
                  </p>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5 font-mono-nums">
                    {comic.pageCount} pages · Start from Page 1
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-zinc-400 shrink-0" />
            </button>
          )}
        </div>
      </section>
    </div>
  );
};
