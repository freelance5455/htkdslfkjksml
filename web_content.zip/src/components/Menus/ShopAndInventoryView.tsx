import React, { useEffect, useRef, useState } from 'react';
import { Check, ShoppingBag, Sparkles, Shield } from 'lucide-react';
import { getHeroById, RARITY_META } from '../../data/heroesData';
import { GAME_ITEMS, getItemById } from '../../data/itemsData';
import { drawAnimeHero } from '../../game/animeRenderer';
import { computeEffectiveHeroStats } from '../../game/saveManager';
import { soundEngine } from '../../game/soundEngine';
import { GameItemDef, ItemCategory, SaveData } from '../../types/game';

interface ShopViewProps {
  save: SaveData;
  onBuyItem: (item: GameItemDef) => void;
}

const SHOP_CATEGORIES: { id: 'all' | ItemCategory; label: string }[] = [
  { id: 'all', label: 'All Relics' },
  { id: 'consumable', label: 'Potions' },
  { id: 'weapon', label: 'Weapons' },
  { id: 'armor', label: 'Armor' },
  { id: 'accessory', label: 'Accessories' },
  { id: 'outfit', label: 'Outfits' },
  { id: 'pet', label: 'Pets' },
  { id: 'cosmetic', label: 'Cosmetics' },
];

export const ShopView: React.FC<ShopViewProps> = ({ save, onBuyItem }) => {
  const [filter, setFilter] = useState<'all' | ItemCategory>('all');
  const [confirmItem, setConfirmItem] = useState<GameItemDef | null>(null);
  const [purchaseBanner, setPurchaseBanner] = useState<string>('');

  const visibleItems =
    filter === 'all' ? GAME_ITEMS : GAME_ITEMS.filter((it) => it.category === filter);

  const handleConfirmPurchase = () => {
    if (!confirmItem) return;
    if (save.coins < confirmItem.priceCoins) {
      setConfirmItem(null);
      return;
    }
    onBuyItem(confirmItem);
    soundEngine.playSfx('secretChest');
    setPurchaseBanner(`Acquired ${confirmItem.name}! Added to your Inventory.`);
    setConfirmItem(null);
    setTimeout(() => setPurchaseBanner(''), 3200);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            Astral Merchant • Earned In-Game Coins Only
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Twilight Emporium
          </h2>
        </div>
        <div className="inline-flex items-center gap-2 self-start rounded-2xl border border-amber-400/50 bg-amber-950/50 px-4 py-2 text-sm font-extrabold text-amber-200">
          🪙 Balance: {save.coins} Coins
        </div>
      </div>

      {purchaseBanner && (
        <div className="rounded-2xl border border-emerald-400/60 bg-emerald-950/80 px-4 py-3 text-xs font-extrabold text-emerald-200 shadow-lg">
          ✦ {purchaseBanner}
        </div>
      )}

      {/* Category Filter Pills */}
      <div className="flex flex-wrap gap-2">
        {SHOP_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => {
              soundEngine.playSfx('uiClick');
              setFilter(cat.id);
            }}
            className={`rounded-xl px-3.5 py-2 text-xs font-extrabold transition ${
              filter === cat.id
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md'
                : 'border border-purple-400/25 bg-[#120b28] text-slate-300 hover:border-amber-400/50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleItems.map((item) => {
          const isConsumable = item.category === 'consumable';
          const isOwned = !isConsumable && save.ownedItemIds.includes(item.id);
          const canAfford = save.coins >= item.priceCoins;
          const rMeta = RARITY_META[item.rarity];

          return (
            <div
              key={item.id}
              className={`flex flex-col justify-between rounded-3xl border ${rMeta.border} bg-gradient-to-b from-[#170f36] to-[#0b071b] p-4 shadow-lg`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/15 text-2xl shadow-inner"
                      style={{ backgroundColor: `${item.accentColor}22` }}
                    >
                      {item.iconSymbol}
                    </div>
                    <div>
                      <span
                        className={`inline-block rounded-md border px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${rMeta.badgeBg}`}
                      >
                        {rMeta.label} • {item.category}
                      </span>
                      <h3 className="mt-1 text-sm font-extrabold text-white">{item.name}</h3>
                    </div>
                  </div>
                </div>

                <p className="mt-3 text-xs leading-relaxed text-slate-300">{item.description}</p>
                {isConsumable && (
                  <div className="mt-2 text-[11px] font-bold text-pink-300">
                    Owned in Pouch: {save.potionsCount}
                  </div>
                )}
              </div>

              <div className="mt-4 pt-2">
                {isOwned ? (
                  <div className="flex items-center justify-center gap-1.5 rounded-xl border border-emerald-400/40 bg-emerald-950/40 py-2.5 text-xs font-extrabold text-emerald-300">
                    <Check className="h-4 w-4" /> Owned in Inventory
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={!canAfford}
                    onClick={() => {
                      soundEngine.playSfx('uiClick');
                      setConfirmItem(item);
                    }}
                    className={`flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-extrabold transition ${
                      canAfford
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md hover:brightness-110'
                        : 'cursor-not-allowed border border-slate-800 bg-slate-900 text-slate-500'
                    }`}
                  >
                    <ShoppingBag className="h-3.5 w-3.5" />
                    {canAfford
                      ? `Purchase • ${item.priceCoins} 🪙`
                      : `Need ${item.priceCoins} 🪙`}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* CLEAR PURCHASE CONFIRMATION MODAL */}
      {confirmItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl border border-amber-400/60 bg-gradient-to-b from-[#1e1240] to-[#0c071c] p-6 text-center shadow-2xl">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-amber-300/40 bg-amber-500/15 text-3xl">
              {confirmItem.iconSymbol}
            </div>
            <h3 className="font-fantasy mt-3 text-xl font-extrabold text-white">
              Confirm Purchase
            </h3>
            <p className="mt-1.5 text-xs text-slate-300">
              Acquire <span className="font-bold text-amber-200">{confirmItem.name}</span> for{' '}
              <span className="font-extrabold text-amber-300">{confirmItem.priceCoins} Coins</span>?
            </p>
            <div className="mt-3 rounded-xl bg-slate-950/70 p-2.5 text-xs text-slate-300">
              Remaining Balance:{' '}
              <span className="font-extrabold text-amber-300">
                {save.coins - confirmItem.priceCoins} 🪙
              </span>
            </div>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirmItem(null)}
                className="flex-1 rounded-xl border border-slate-700 bg-slate-900 py-2.5 text-xs font-bold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPurchase}
                className="flex-1 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 py-2.5 text-xs font-extrabold text-slate-950 shadow-lg"
              >
                Confirm Buy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// INVENTORY & LIVE HERO LOADOUT VIEW
// ============================================================================
interface InventoryViewProps {
  save: SaveData;
  onEquipToggle: (item: GameItemDef) => void;
  onGoToShop: () => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  save,
  onEquipToggle,
  onGoToShop,
}) => {
  const hero = getHeroById(save.selectedHeroId);
  const stats = computeEffectiveHeroStats(save, hero.id);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const ownedItems = GAME_ITEMS.filter(
    (it) => it.category !== 'consumable' && save.ownedItemIds.includes(it.id)
  );

  // Live 2D Animated Anime Character Loadout Preview!
  useEffect(() => {
    let raf = 0;
    const start = performance.now();

    const loop = (now: number) => {
      const t = (now - start) / 1000;
      const ctx = previewCanvasRef.current?.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, 220, 180);
        // Subtle glowing pedestal
        const grad = ctx.createRadialGradient(110, 148, 8, 110, 148, 65);
        grad.addColorStop(0, 'rgba(251, 191, 36, 0.35)');
        grad.addColorStop(1, 'rgba(139, 92, 246, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.ellipse(110, 148, 65, 16, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.save();
        ctx.translate(110, 145);
        ctx.scale(1.65, 1.65);
        drawAnimeHero(ctx, {
          x: 0,
          y: 0,
          facing: 1,
          animState: 'idle',
          animTime: t,
          comboStage: 1,
          attackProgress: 0,
          vx: 0,
          vy: 0,
          hero,
          outfit: getItemById(save.equippedOutfitId),
          pet: getItemById(save.equippedPetId),
          cosmetic: getItemById(save.equippedCosmeticId),
          invulnFlash: false,
          graphics: save.settings.graphicsQuality,
        });
        ctx.restore();
      }
      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [
    hero,
    save.equippedCosmeticId,
    save.equippedOutfitId,
    save.equippedPetId,
    save.settings.graphicsQuality,
  ]);

  const isEquipped = (item: GameItemDef) => {
    switch (item.category) {
      case 'weapon':
        return save.equippedWeaponId === item.id;
      case 'armor':
        return save.equippedArmorId === item.id;
      case 'accessory':
        return save.equippedAccessoryId === item.id;
      case 'outfit':
        return save.equippedOutfitId === item.id;
      case 'pet':
        return save.equippedPetId === item.id;
      case 'cosmetic':
        return save.equippedCosmeticId === item.id;
      default:
        return false;
    }
  };

  const slots: { label: string; item: GameItemDef | undefined; emptyHint: string }[] = [
    { label: 'Weapon', item: getItemById(save.equippedWeaponId), emptyHint: 'Default Blade' },
    { label: 'Armor', item: getItemById(save.equippedArmorId), emptyHint: 'Standard Coat' },
    { label: 'Accessory', item: getItemById(save.equippedAccessoryId), emptyHint: 'None' },
    { label: 'Outfit Skin', item: getItemById(save.equippedOutfitId), emptyHint: 'Original Attire' },
    { label: 'Companion Pet', item: getItemById(save.equippedPetId), emptyHint: 'No Pet' },
    { label: 'Cosmetic Aura', item: getItemById(save.equippedCosmeticId), emptyHint: 'No Aura' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Live Animated 2D Anime Hero Preview & Equipped Slots */}
      <div className="lg:col-span-5 rounded-3xl border border-purple-400/35 bg-gradient-to-b from-[#1a103a] to-[#0b071b] p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-extrabold tracking-widest text-amber-300 uppercase">
              Active Fighter Loadout
            </div>
            <h3 className="font-fantasy text-xl font-extrabold text-white">{hero.name}</h3>
          </div>
          <span className="rounded-xl border border-pink-400/40 bg-pink-950/60 px-3 py-1 text-xs font-extrabold text-pink-200">
            🧪 Potions: {save.potionsCount}
          </span>
        </div>

        {/* Live 2D Rigged Anime Character Canvas */}
        <div className="mt-3 flex flex-col items-center justify-center rounded-2xl border border-white/10 bg-[#080514]/90 p-2">
          <canvas ref={previewCanvasRef} width={220} height={180} />
          <span className="text-[10px] text-slate-400">
            Live In-Game 2D Sprite Preview (Outfits, Pets & Auras)
          </span>
        </div>

        {/* Total Combat Stats */}
        <div className="mt-4 grid grid-cols-5 gap-1.5 text-center text-xs">
          <div className="rounded-xl bg-slate-950/75 p-2">
            <div className="text-[10px] text-slate-400">HP</div>
            <div className="font-extrabold text-emerald-300">{stats.maxHp}</div>
          </div>
          <div className="rounded-xl bg-slate-950/75 p-2">
            <div className="text-[10px] text-slate-400">ATK</div>
            <div className="font-extrabold text-rose-300">{stats.attack}</div>
          </div>
          <div className="rounded-xl bg-slate-950/75 p-2">
            <div className="text-[10px] text-slate-400">DEF</div>
            <div className="font-extrabold text-sky-300">{stats.defense}</div>
          </div>
          <div className="rounded-xl bg-slate-950/75 p-2">
            <div className="text-[10px] text-slate-400">CRIT</div>
            <div className="font-extrabold text-amber-300">
              {Math.round(stats.critChance * 100)}%
            </div>
          </div>
          <div className="rounded-xl bg-slate-950/75 p-2">
            <div className="text-[10px] text-slate-400">CDR</div>
            <div className="font-extrabold text-purple-300">
              {Math.round(stats.cooldownReduction * 100)}%
            </div>
          </div>
        </div>

        {/* 6 Active Loadout Slots */}
        <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
          {slots.map((sl) => (
            <div
              key={sl.label}
              className="rounded-xl border border-purple-400/20 bg-slate-950/70 p-2.5"
            >
              <div className="text-[10px] font-bold text-slate-400 uppercase">{sl.label}</div>
              {sl.item ? (
                <div className="mt-0.5 flex items-center justify-between gap-1">
                  <span className="truncate font-extrabold text-amber-200">
                    {sl.item.iconSymbol} {sl.item.name}
                  </span>
                </div>
              ) : (
                <div className="mt-0.5 text-slate-500">{sl.emptyHint}</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Right: Owned Gear, Outfits, Pets & Cosmetics Vault */}
      <div className="lg:col-span-7 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-fantasy text-xl font-extrabold text-white">
            Relic & Cosmetic Vault ({ownedItems.length})
          </h3>
          <button
            type="button"
            onClick={() => {
              soundEngine.playSfx('uiClick');
              onGoToShop();
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-amber-400/50 bg-amber-500/15 px-3.5 py-2 text-xs font-extrabold text-amber-200 hover:bg-amber-500/25"
          >
            <Sparkles className="h-3.5 w-3.5" /> Visit Coin Shop
          </button>
        </div>

        {ownedItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-purple-400/25 bg-[#120b26]/75 p-10 text-center">
            <Shield className="h-10 w-10 text-purple-400/60" />
            <h4 className="font-fantasy mt-3 text-lg font-bold text-white">
              Your Vault Awaits Treasures
            </h4>
            <p className="mt-1 max-w-md text-xs text-slate-300">
              Defeat World Bosses, uncover hidden Secret Chests in each realm, or spend earned Coins
              in the Twilight Emporium to collect Weapons, Armor, Outfits, Companion Pets, and
              Cosmetic Auras!
            </p>
            <button
              type="button"
              onClick={onGoToShop}
              className="mt-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 px-5 py-2.5 text-xs font-extrabold text-slate-950 shadow-md"
            >
              Browse Emporium
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {ownedItems.map((item) => {
              const equipped = isEquipped(item);
              const rMeta = RARITY_META[item.rarity];
              return (
                <div
                  key={item.id}
                  className={`flex flex-col justify-between rounded-2xl border p-4 transition ${
                    equipped
                      ? 'border-amber-400 bg-[#1e1242] shadow-[0_0_20px_rgba(251,191,36,0.2)]'
                      : `${rMeta.border} bg-[#130c29]`
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{item.iconSymbol}</span>
                      <div>
                        <span
                          className={`rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${rMeta.badgeBg}`}
                        >
                          {item.category}
                        </span>
                        <h4 className="mt-0.5 text-sm font-extrabold text-white">{item.name}</h4>
                      </div>
                    </div>
                    <p className="mt-2 text-xs text-slate-300">{item.description}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playSfx('uiClick');
                      onEquipToggle(item);
                    }}
                    className={`mt-3 w-full rounded-xl py-2 text-xs font-extrabold transition ${
                      equipped
                        ? 'border border-emerald-400 bg-emerald-900/40 text-emerald-200 hover:bg-emerald-900/60'
                        : 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 hover:brightness-110'
                    }`}
                  >
                    {equipped ? '✓ Equipped (Tap to Unequip)' : 'Equip'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
