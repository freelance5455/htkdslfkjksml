import React, { useState } from 'react';
import { CheckCircle2, Lock, Sparkles, ArrowUpCircle, Shield, Sword, Zap } from 'lucide-react';
import { getHeroUpgradeCost, HEROES_DATA, RARITY_META } from '../../data/heroesData';
import { computeEffectiveHeroStats } from '../../game/saveManager';
import { soundEngine } from '../../game/soundEngine';
import { HeroDef, SaveData } from '../../types/game';

interface HeroGeneratorViewProps {
  save: SaveData;
  onUnlockHero: (hero: HeroDef) => void;
  onSelectHero: (heroId: string) => void;
  onUpgradeHero: (hero: HeroDef) => void;
}

export const HeroGeneratorView: React.FC<HeroGeneratorViewProps> = ({
  save,
  onUnlockHero,
  onSelectHero,
  onUpgradeHero,
}) => {
  const [focusedId, setFocusedId] = useState<string>(() => {
    const nextLocked = HEROES_DATA.find((h) => !save.unlockedHeroIds.includes(h.id));
    return nextLocked ? nextLocked.id : HEROES_DATA[HEROES_DATA.length - 1].id;
  });
  const [forgingCeremonyHero, setForgingCeremonyHero] = useState<HeroDef | null>(null);
  const [confirmForgeHero, setConfirmForgeHero] = useState<HeroDef | null>(null);

  const focusedHero = HEROES_DATA.find((h) => h.id === focusedId) || HEROES_DATA[0];
  const isUnlocked = save.unlockedHeroIds.includes(focusedHero.id);
  const heroLvl = save.heroLevels[focusedHero.id] || 1;
  const stats = computeEffectiveHeroStats(save, focusedHero.id);
  const rMeta = RARITY_META[focusedHero.rarity];
  const upgradeCost = getHeroUpgradeCost(focusedHero, heroLvl);

  // Check deterministic unlock conditions
  const req = focusedHero.unlockReq;
  const hasCoins = save.coins >= req.coinsCost;
  const hasWorld =
    !req.requiredWorldCleared || save.completedWorlds.includes(req.requiredWorldCleared);
  const hasQuests =
    !req.requiredQuestsCompleted ||
    save.claimedQuestIds.length >= req.requiredQuestsCompleted;
  const hasLevel = !req.requiredPlayerLevel || save.playerLevel >= req.requiredPlayerLevel;
  const hasAchievements =
    !req.requiredAchievements ||
    save.claimedAchievementIds.length >= req.requiredAchievements;

  const canUnlock = !isUnlocked && hasCoins && hasWorld && hasQuests && hasLevel && hasAchievements;

  const handleConfirmForge = () => {
    if (!confirmForgeHero) return;
    const target = confirmForgeHero;
    setConfirmForgeHero(null);
    soundEngine.playSfx('heroUnlock');
    onUnlockHero(target);
    setForgingCeremonyHero(target);
  };

  return (
    <div className="space-y-6">
      {/* HEADER CHAMBER WITH GLOWING INFINITY SYMBOL */}
      <div className="relative overflow-hidden rounded-3xl border border-amber-400/35 bg-gradient-to-br from-[#1b0e3a] via-[#0e1330] to-[#080514] p-5 sm:p-7 shadow-[0_0_40px_rgba(139,92,246,0.22)]">
        <div className="pointer-events-none absolute -top-20 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-purple-600/20 blur-3xl" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-xl text-center lg:text-left">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/10 px-3 py-1 text-[11px] font-extrabold tracking-widest text-amber-300 uppercase">
              <Sparkles className="h-3.5 w-3.5" /> Deterministic Soul Sanctum • Zero Gambling
            </div>
            <h2 className="font-fantasy mt-2 text-2xl sm:text-3xl font-extrabold text-white">
              Infinity <span className="gold-shimmer-text">Hero Generator</span>
            </h2>
            <p className="mt-1.5 text-xs sm:text-sm text-slate-300">
              Channel earned Coins, conquered Boss crests, and completed Quest milestones into the
              Eternal Core to awaken predefined original Heroes. Every unlock is guaranteed and saved
              permanently.
            </p>
          </div>

          {/* Animated Glowing SVG Infinity Emblem */}
          <div className="relative flex flex-col items-center justify-center">
            <div className="relative flex h-28 w-48 items-center justify-center">
              <div className="animate-spin-slow pointer-events-none absolute h-28 w-28 rounded-full border border-dashed border-amber-400/35" />
              <svg
                viewBox="0 0 220 110"
                className="animate-infinity h-24 w-44 overflow-visible"
              >
                <defs>
                  <linearGradient id="infGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#c084fc" />
                    <stop offset="50%" stopColor="#fde047" />
                    <stop offset="100%" stopColor="#38bdf8" />
                  </linearGradient>
                </defs>
                <path
                  d="M 60 55 C 22 15, 22 95, 60 55 C 98 15, 122 95, 160 55 C 198 15, 198 95, 160 55 C 122 15, 98 95, 60 55 Z"
                  fill="none"
                  stroke="url(#infGrad)"
                  strokeWidth="8"
                  strokeLinecap="round"
                />
              </svg>
            </div>
            <span className="text-[11px] font-bold tracking-widest text-amber-200/80 uppercase">
              Unlocked: {save.unlockedHeroIds.length} / {HEROES_DATA.length} Heroes
            </span>
          </div>
        </div>
      </div>

      {/* HERO SELECTOR STRIP + DETAILED GENERATOR INSPECTOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: All 6 Predefined Heroes Collection Selector */}
        <div className="lg:col-span-5 space-y-2.5">
          <h3 className="font-fantasy text-sm font-bold tracking-wider text-slate-300 uppercase">
            Astral Pantheon Roster
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-3">
            {HEROES_DATA.map((h) => {
              const unlocked = save.unlockedHeroIds.includes(h.id);
              const meta = RARITY_META[h.rarity];
              const active = focusedHero.id === h.id;
              return (
                <button
                  key={h.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playSfx('uiClick');
                    setFocusedId(h.id);
                  }}
                  className={`group relative overflow-hidden rounded-2xl border p-2.5 text-left transition ${
                    active
                      ? `${meta.border} bg-[#1c113d] ring-2 ring-amber-400/80 shadow-lg`
                      : 'border-purple-400/20 bg-[#110b26]/85 hover:border-purple-400/50'
                  }`}
                >
                  <div className="relative aspect-square w-full overflow-hidden rounded-xl">
                    <img
                      src={h.portrait}
                      alt={h.name}
                      className={`h-full w-full object-cover transition duration-300 group-hover:scale-105 ${
                        unlocked ? '' : 'brightness-75 saturate-75'
                      }`}
                    />
                    <span
                      className={`absolute top-1.5 left-1.5 rounded-md border px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${meta.badgeBg}`}
                    >
                      {meta.label}
                    </span>
                    {unlocked ? (
                      <span className="absolute right-1.5 bottom-1.5 rounded-md bg-slate-950/85 px-1.5 py-0.5 text-[10px] font-extrabold text-amber-300">
                        Lv.{save.heroLevels[h.id] || 1}
                      </span>
                    ) : (
                      <span className="absolute right-1.5 bottom-1.5 flex items-center gap-1 rounded-md bg-slate-950/90 px-1.5 py-0.5 text-[10px] font-bold text-slate-300">
                        <Lock className="h-3 w-3 text-amber-400" /> {h.unlockReq.coinsCost}🪙
                      </span>
                    )}
                  </div>
                  <div className="mt-2 truncate text-xs font-extrabold text-white">{h.name}</div>
                  <div className="truncate text-[10px] text-slate-400">{h.title}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Focused Hero Resonance Forge & Full Stats */}
        <div
          className={`lg:col-span-7 rounded-3xl border-2 ${rMeta.border} bg-gradient-to-b from-[#181036] to-[#0c081d] p-5 sm:p-6 shadow-xl`}
        >
          <div className="flex flex-col sm:flex-row gap-5">
            <div className="relative mx-auto sm:mx-0 h-44 w-44 shrink-0 overflow-hidden rounded-2xl border-2 border-amber-300/60 shadow-lg">
              <img
                src={focusedHero.portrait}
                alt={focusedHero.name}
                className="h-full w-full object-cover"
              />
              <span
                className={`absolute top-2 left-2 rounded-lg border px-2 py-0.5 text-[10px] font-extrabold uppercase ${rMeta.badgeBg}`}
              >
                {rMeta.label}
              </span>
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-fantasy text-2xl font-extrabold text-white">
                    {focusedHero.name}
                  </h3>
                  <p className="text-xs font-semibold text-amber-300">
                    {focusedHero.title} • {focusedHero.element}
                  </p>
                </div>
                <span className="rounded-xl border border-purple-400/35 bg-purple-950/70 px-3 py-1 text-xs font-extrabold text-purple-200">
                  Level {heroLvl}
                </span>
              </div>

              <p className="mt-2 text-xs leading-relaxed text-slate-300">{focusedHero.lore}</p>
              <div className="mt-2 text-[11px] font-semibold text-cyan-300">
                Fighting Style: {focusedHero.fightingStyle}
              </div>

              {/* Stats Grid */}
              <div className="mt-3 grid grid-cols-3 sm:grid-cols-5 gap-2 text-center">
                <div className="rounded-xl bg-slate-950/70 p-2 border border-white/5">
                  <div className="text-[10px] text-slate-400">HP</div>
                  <div className="text-xs font-extrabold text-emerald-300">{stats.maxHp}</div>
                </div>
                <div className="rounded-xl bg-slate-950/70 p-2 border border-white/5">
                  <div className="text-[10px] text-slate-400">ATK</div>
                  <div className="text-xs font-extrabold text-rose-300">{stats.attack}</div>
                </div>
                <div className="rounded-xl bg-slate-950/70 p-2 border border-white/5">
                  <div className="text-[10px] text-slate-400">DEF</div>
                  <div className="text-xs font-extrabold text-sky-300">{stats.defense}</div>
                </div>
                <div className="rounded-xl bg-slate-950/70 p-2 border border-white/5">
                  <div className="text-[10px] text-slate-400">CRIT</div>
                  <div className="text-xs font-extrabold text-amber-300">
                    {Math.round(stats.critChance * 100)}%
                  </div>
                </div>
                <div className="rounded-xl bg-slate-950/70 p-2 border border-white/5">
                  <div className="text-[10px] text-slate-400">CDR</div>
                  <div className="text-xs font-extrabold text-purple-300">
                    {Math.round(stats.cooldownReduction * 100)}%
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Abilities Showcase */}
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="rounded-2xl border border-purple-400/25 bg-slate-950/60 p-3">
              <div className="flex items-center gap-1.5 font-extrabold text-purple-300">
                <Sword className="h-3.5 w-3.5" /> Skill: {focusedHero.skill1.name}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">{focusedHero.skill1.description}</p>
              <div className="mt-1 text-[10px] text-slate-400">
                Base Cooldown: {focusedHero.skill1.cooldown}s
              </div>
            </div>
            <div className="rounded-2xl border border-amber-400/30 bg-slate-950/60 p-3">
              <div className="flex items-center gap-1.5 font-extrabold text-amber-300">
                <Zap className="h-3.5 w-3.5" /> Ultimate: {focusedHero.skill2.name}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">{focusedHero.skill2.description}</p>
              <div className="mt-1 text-[10px] text-slate-400">
                Base Cooldown: {focusedHero.skill2.cooldown}s
              </div>
            </div>
            <div className="rounded-2xl border border-emerald-400/25 bg-slate-950/60 p-3">
              <div className="flex items-center gap-1.5 font-extrabold text-emerald-300">
                <Shield className="h-3.5 w-3.5" /> Passive: {focusedHero.passiveName}
              </div>
              <p className="mt-1 text-[11px] text-slate-300">{focusedHero.passiveDescription}</p>
            </div>
          </div>

          {/* Unlock Requirements OR Upgrade / Equip Controls */}
          <div className="mt-5 rounded-2xl border border-amber-400/30 bg-[#0d071c]/90 p-4">
            {!isUnlocked ? (
              <div>
                <div className="text-xs font-extrabold tracking-wider text-amber-200 uppercase">
                  Infinity Core Unlock Requirements
                </div>
                <p className="mt-0.5 text-xs text-slate-300">{req.summaryText}</p>

                <div className="mt-3 space-y-1.5 text-xs">
                  <RequirementRow
                    met={hasCoins}
                    label={`Coins Required: ${save.coins} / ${req.coinsCost} 🪙`}
                  />
                  {req.requiredWorldCleared && (
                    <RequirementRow
                      met={hasWorld}
                      label={`Defeat World ${req.requiredWorldCleared} Boss`}
                    />
                  )}
                  {req.requiredQuestsCompleted && (
                    <RequirementRow
                      met={hasQuests}
                      label={`Claim Quests: ${save.claimedQuestIds.length} / ${req.requiredQuestsCompleted}`}
                    />
                  )}
                  {req.requiredPlayerLevel && (
                    <RequirementRow
                      met={hasLevel}
                      label={`Player Level: ${save.playerLevel} / ${req.requiredPlayerLevel}`}
                    />
                  )}
                </div>

                <button
                  type="button"
                  disabled={!canUnlock}
                  onClick={() => {
                    soundEngine.playSfx('uiClick');
                    setConfirmForgeHero(focusedHero);
                  }}
                  className={`mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-extrabold transition ${
                    canUnlock
                      ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-purple-500 text-slate-950 shadow-[0_0_24px_rgba(251,191,36,0.5)] hover:brightness-110'
                      : 'cursor-not-allowed border border-slate-700 bg-slate-900 text-slate-500'
                  }`}
                >
                  <Sparkles className="h-4 w-4" />
                  {canUnlock
                    ? `Forge ${focusedHero.name} (${req.coinsCost} Coins)`
                    : 'Fulfill Requirements to Awaken Hero'}
                </button>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" /> Awakened in your Hero Collection
                </div>
                <div className="flex w-full sm:w-auto gap-2.5">
                  <button
                    type="button"
                    disabled={save.coins < upgradeCost}
                    onClick={() => onUpgradeHero(focusedHero)}
                    className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-extrabold transition ${
                      save.coins >= upgradeCost
                        ? 'border border-amber-400/70 bg-amber-500/20 text-amber-200 hover:bg-amber-500/30'
                        : 'border border-slate-700 bg-slate-900 text-slate-500'
                    }`}
                  >
                    <ArrowUpCircle className="h-4 w-4" /> Upgrade Lv.{heroLvl + 1} ({upgradeCost}🪙)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playSfx('uiClick');
                      onSelectHero(focusedHero.id);
                    }}
                    className={`flex-1 sm:flex-none rounded-xl px-5 py-2.5 text-xs font-extrabold transition ${
                      save.selectedHeroId === focusedHero.id
                        ? 'bg-emerald-600/30 border border-emerald-400 text-emerald-200'
                        : 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md hover:brightness-110'
                    }`}
                  >
                    {save.selectedHeroId === focusedHero.id ? '✓ Active Hero' : 'Deploy Hero'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* CONFIRM FORGE MODAL */}
      {confirmForgeHero && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl border border-amber-400/60 bg-gradient-to-b from-[#1e113f] to-[#0b0618] p-6 text-center shadow-2xl">
            <h3 className="font-fantasy text-xl font-extrabold text-amber-300">
              Awaken {confirmForgeHero.name}?
            </h3>
            <p className="mt-2 text-xs text-slate-300">
              Channel{' '}
              <span className="font-extrabold text-amber-300">
                {confirmForgeHero.unlockReq.coinsCost} Coins
              </span>{' '}
              into the Infinity Core to permanently unlock{' '}
              <span className="font-bold text-white">{confirmForgeHero.name}</span>.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirmForgeHero(null)}
                className="flex-1 rounded-xl border border-slate-700 bg-slate-900 py-2.5 text-xs font-bold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmForge}
                className="flex-1 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 py-2.5 text-xs font-extrabold text-slate-950 shadow-lg"
              >
                Awaken Hero!
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CELEBRATORY HERO AWAKENED CEREMONY MODAL */}
      {forgingCeremonyHero && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 p-4 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl border-2 border-amber-300 bg-gradient-to-b from-[#261252] via-[#130b2e] to-[#090516] p-6 text-center shadow-[0_0_60px_rgba(251,191,36,0.45)]">
            <div className="text-xs font-extrabold tracking-[0.28em] text-amber-300 uppercase">
              ♾️ Infinity Resonance Complete ♾️
            </div>
            <div className="mx-auto mt-4 h-44 w-44 overflow-hidden rounded-3xl border-2 border-amber-300 shadow-[0_0_30px_rgba(192,132,252,0.6)]">
              <img
                src={forgingCeremonyHero.portrait}
                alt={forgingCeremonyHero.name}
                className="h-full w-full object-cover"
              />
            </div>
            <h3 className="font-fantasy mt-4 text-2xl font-extrabold text-white">
              {forgingCeremonyHero.name}
            </h3>
            <p className="text-xs font-bold text-amber-300">
              {forgingCeremonyHero.title} ({RARITY_META[forgingCeremonyHero.rarity].label})
            </p>
            <p className="mt-2 text-xs text-slate-300">
              Saved to your permanent Hero Collection! Ready for combat across all realms.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  onSelectHero(forgingCeremonyHero.id);
                  setForgingCeremonyHero(null);
                }}
                className="flex-1 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 py-3 text-xs font-extrabold text-slate-950 shadow-lg"
              >
                Deploy Now
              </button>
              <button
                type="button"
                onClick={() => setForgingCeremonyHero(null)}
                className="flex-1 rounded-xl border border-purple-400/40 bg-purple-950/70 py-3 text-xs font-bold text-white"
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const RequirementRow: React.FC<{ met: boolean; label: string }> = ({ met, label }) => (
  <div className="flex items-center gap-2">
    <span
      className={`inline-flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold ${
        met ? 'bg-emerald-500/25 text-emerald-300' : 'bg-slate-800 text-slate-500'
      }`}
    >
      {met ? '✓' : '•'}
    </span>
    <span className={met ? 'font-semibold text-emerald-200' : 'text-slate-400'}>{label}</span>
  </div>
);
