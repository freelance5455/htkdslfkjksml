import React from 'react';
import {
  ArrowUpCircle,
  CheckCircle2,
  Compass,
  Lock,
  Play,
  RotateCcw,
  Skull,
  Sparkles,
} from 'lucide-react';
import { getHeroUpgradeCost, HEROES_DATA, RARITY_META } from '../../data/heroesData';
import { WORLDS_DATA } from '../../data/worldsData';
import { computeEffectiveHeroStats } from '../../game/saveManager';
import { soundEngine } from '../../game/soundEngine';
import { HeroDef, SaveData } from '../../types/game';

interface WorldsViewProps {
  save: SaveData;
  onStartWorld: (worldId: number, fromCheckpoint?: boolean) => void;
}

export const WorldsView: React.FC<WorldsViewProps> = ({ save, onStartWorld }) => {
  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            Dimensional Atlas • 6 Playable Realms
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Select a Shadow Realm
          </h2>
        </div>
        <div className="text-xs font-semibold text-slate-300">
          Realms Conquered:{' '}
          <span className="font-extrabold text-amber-300">{save.completedWorlds.length} / 6</span> •
          Secrets Found:{' '}
          <span className="font-extrabold text-purple-300">
            {save.secretsFoundWorlds.length} / 6
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {WORLDS_DATA.map((w) => {
          const isUnlocked = w.id <= save.unlockedWorldMax;
          const isCleared = save.completedWorlds.includes(w.id);
          const stars = save.worldStars[w.id] || 0;
          const secretFound = save.secretsFoundWorlds.includes(w.id);
          const hasCheckpointHere = save.activeCheckpoint?.worldId === w.id;

          return (
            <div
              key={w.id}
              className={`relative flex flex-col justify-between overflow-hidden rounded-3xl border p-5 transition ${
                isUnlocked
                  ? 'border-purple-400/35 bg-gradient-to-b from-[#171033] to-[#0b071b] shadow-xl hover:border-amber-400/60'
                  : 'border-slate-800 bg-[#0b0817]/75 opacity-80'
              }`}
            >
              {/* Colored Realm Banner Header */}
              <div>
                <div
                  className="mb-4 flex items-center justify-between rounded-2xl border border-white/10 p-3.5"
                  style={{
                    background: `linear-gradient(135deg, ${w.skyTop}, ${w.skyBottom})`,
                  }}
                >
                  <div>
                    <div
                      className="text-[10px] font-extrabold tracking-widest uppercase"
                      style={{ color: w.accentColor }}
                    >
                      World {w.id} • Rec. Lv.{w.recommendedLevel}
                    </div>
                    <h3 className="font-fantasy text-lg font-extrabold text-white">{w.name}</h3>
                  </div>

                  {/* Star Rating */}
                  <div className="flex gap-1 text-base">
                    {[1, 2, 3].map((s) => (
                      <span
                        key={s}
                        className={s <= stars ? 'text-amber-400' : 'text-slate-600/60'}
                      >
                        ★
                      </span>
                    ))}
                  </div>
                </div>

                <p className="text-xs leading-relaxed text-slate-300">{w.description}</p>

                {/* Boss & Secret Badges */}
                <div className="mt-3.5 space-y-1.5 rounded-2xl border border-purple-400/15 bg-slate-950/60 p-3 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-rose-300 font-bold">
                      <Skull className="h-3.5 w-3.5" /> Boss: {w.boss.name}
                    </span>
                    <span className="text-[10px] text-slate-400">{w.boss.phases} Phases</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-amber-200 font-semibold">
                      <Compass className="h-3.5 w-3.5 text-amber-400" /> Secret Relic
                    </span>
                    <span
                      className={
                        secretFound
                          ? 'font-extrabold text-emerald-300'
                          : 'text-[11px] text-slate-400'
                      }
                    >
                      {secretFound ? '✓ Discovered' : 'Hidden'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-2">
                {!isUnlocked ? (
                  <div className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900/90 py-3 text-xs font-bold text-slate-400">
                    <Lock className="h-4 w-4 text-amber-400/70" /> Clear World {w.id - 1} to Unlock
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playSfx('uiClick');
                        onStartWorld(w.id, false);
                      }}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 py-3 text-xs font-extrabold text-slate-950 shadow-lg transition hover:brightness-110"
                    >
                      <Play className="h-4 w-4 fill-slate-950" />
                      {isCleared ? `Replay ${w.name}` : `Enter ${w.name}`}
                    </button>

                    {hasCheckpointHere && (
                      <button
                        type="button"
                        onClick={() => {
                          soundEngine.playSfx('uiClick');
                          onStartWorld(w.id, true);
                        }}
                        className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-amber-400/60 bg-amber-950/50 py-2 text-xs font-extrabold text-amber-200 transition hover:bg-amber-900/60"
                      >
                        <RotateCcw className="h-3.5 w-3.5" /> Resume from Saved Checkpoint
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface HeroesViewProps {
  save: SaveData;
  onSelectHero: (heroId: string) => void;
  onUpgradeHero: (hero: HeroDef) => void;
  onGoToGenerator: () => void;
}

export const HeroesView: React.FC<HeroesViewProps> = ({
  save,
  onSelectHero,
  onUpgradeHero,
  onGoToGenerator,
}) => {
  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            5 Hero Rarities • Original Anime Fighters
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Heroes Sanctuary
          </h2>
        </div>
        <button
          type="button"
          onClick={() => {
            soundEngine.playSfx('uiClick');
            onGoToGenerator();
          }}
          className="inline-flex items-center gap-2 self-start rounded-xl border border-amber-400/60 bg-amber-500/15 px-4 py-2 text-xs font-extrabold text-amber-200 transition hover:bg-amber-500/25"
        >
          <Sparkles className="h-4 w-4" /> Open Infinity Hero Generator
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {HEROES_DATA.map((h) => {
          const unlocked = save.unlockedHeroIds.includes(h.id);
          const isSelected = save.selectedHeroId === h.id;
          const lvl = save.heroLevels[h.id] || 1;
          const upgCost = getHeroUpgradeCost(h, lvl);
          const stats = computeEffectiveHeroStats(save, h.id);
          const meta = RARITY_META[h.rarity];

          return (
            <div
              key={h.id}
              className={`flex flex-col justify-between rounded-3xl border-2 ${meta.border} bg-gradient-to-b from-[#181038] to-[#0b071b] p-4 shadow-xl ${meta.glow}`}
            >
              <div>
                {/* Top Portrait & Identity */}
                <div className="flex gap-4">
                  <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-2xl border border-white/15">
                    <img
                      src={h.portrait}
                      alt={h.name}
                      className={`h-full w-full object-cover ${
                        unlocked ? '' : 'brightness-75 grayscale-[30%]'
                      }`}
                    />
                    <span
                      className={`absolute top-1.5 left-1.5 rounded-md border px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${meta.badgeBg}`}
                    >
                      {meta.label}
                    </span>
                    <span className="absolute right-1.5 bottom-1.5 rounded-md bg-slate-950/90 px-1.5 py-0.5 text-[10px] font-extrabold text-amber-300">
                      Lv.{lvl}
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <h3 className="font-fantasy truncate text-lg font-extrabold text-white">
                      {h.name}
                    </h3>
                    <div className="text-xs font-bold text-amber-300">{h.title}</div>
                    <div className="mt-1 text-[11px] text-cyan-300">{h.fightingStyle}</div>

                    {/* Compact Stat Chips */}
                    <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-center text-[11px]">
                      <div className="rounded-lg bg-slate-950/75 py-1">
                        <span className="text-slate-400">HP </span>
                        <span className="font-extrabold text-emerald-300">{stats.maxHp}</span>
                      </div>
                      <div className="rounded-lg bg-slate-950/75 py-1">
                        <span className="text-slate-400">ATK </span>
                        <span className="font-extrabold text-rose-300">{stats.attack}</span>
                      </div>
                      <div className="rounded-lg bg-slate-950/75 py-1">
                        <span className="text-slate-400">DEF </span>
                        <span className="font-extrabold text-sky-300">{stats.defense}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Skills Summary */}
                <div className="mt-3.5 space-y-1.5 rounded-2xl border border-white/5 bg-slate-950/60 p-3 text-[11px]">
                  <div>
                    <span className="font-extrabold text-purple-300">✦ {h.skill1.name}: </span>
                    <span className="text-slate-300">{h.skill1.description}</span>
                  </div>
                  <div>
                    <span className="font-extrabold text-amber-300">♾️ {h.skill2.name}: </span>
                    <span className="text-slate-300">{h.skill2.description}</span>
                  </div>
                  <div>
                    <span className="font-extrabold text-emerald-300">◈ {h.passiveName}: </span>
                    <span className="text-slate-300">{h.passiveDescription}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-4">
                {unlocked ? (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playSfx('uiClick');
                        onSelectHero(h.id);
                      }}
                      className={`flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-extrabold transition ${
                        isSelected
                          ? 'border border-emerald-400 bg-emerald-900/40 text-emerald-200'
                          : 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md hover:brightness-110'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <CheckCircle2 className="h-4 w-4" /> Deployed
                        </>
                      ) : (
                        'Deploy Hero'
                      )}
                    </button>
                    <button
                      type="button"
                      disabled={save.coins < upgCost}
                      onClick={() => onUpgradeHero(h)}
                      className={`flex items-center justify-center gap-1 rounded-xl px-3.5 py-2.5 text-xs font-extrabold transition ${
                        save.coins >= upgCost
                          ? 'border border-amber-400/70 bg-amber-500/20 text-amber-200 hover:bg-amber-500/30'
                          : 'border border-slate-800 bg-slate-900 text-slate-500'
                      }`}
                    >
                      <ArrowUpCircle className="h-4 w-4" /> {upgCost}🪙
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playSfx('uiClick');
                      onGoToGenerator();
                    }}
                    className="flex w-full items-center justify-center gap-2 rounded-xl border border-purple-400/40 bg-purple-950/60 py-2.5 text-xs font-extrabold text-purple-200 transition hover:border-amber-400 hover:text-amber-200"
                  >
                    <Lock className="h-3.5 w-3.5 text-amber-400" /> {h.unlockReq.summaryText}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
