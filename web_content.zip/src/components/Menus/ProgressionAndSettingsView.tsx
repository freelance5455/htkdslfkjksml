import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  Flame,
  Heart,
  RotateCcw,
  Shield,
  Sliders,
  Smartphone,
  Sparkles,
  Sword,
  Timer,
  Volume2,
} from 'lucide-react';
import { ACHIEVEMENTS_DATA, QUESTS_DATA } from '../../data/itemsData';
import { getQuestOrAchievementMetric, xpRequiredForLevel } from '../../game/saveManager';
import { soundEngine } from '../../game/soundEngine';
import {
  AchievementDef,
  GraphicsQuality,
  QuestDef,
  SaveData,
  SkillUpgradesState,
} from '../../types/game';

// ============================================================================
// 1. SKILLS UPGRADE SANCTUARY
// ============================================================================
interface SkillsViewProps {
  save: SaveData;
  onUpgradeSkill: (key: keyof SkillUpgradesState, coinCost: number, useSkillPoint: boolean) => void;
}

const SKILL_NODES: {
  key: keyof SkillUpgradesState;
  name: string;
  desc: string;
  perRank: string;
  icon: React.ReactNode;
  accent: string;
}[] = [
  {
    key: 'attackRank',
    name: 'Blade Ferocity (Attack Power)',
    desc: 'Increases base physical & elemental strike damage across all combos and skills.',
    perRank: '+5 ATK per Rank',
    icon: <Sword className="h-5 w-5 text-rose-400" />,
    accent: 'border-rose-400/40',
  },
  {
    key: 'defenseRank',
    name: 'Astral Aegis (Defense)',
    desc: 'Hardens twilight ward armor, reducing incoming damage from enemies, hazards & bosses.',
    perRank: '+3 DEF per Rank',
    icon: <Shield className="h-5 w-5 text-sky-400" />,
    accent: 'border-sky-400/40',
  },
  {
    key: 'healthRank',
    name: 'Immortal Lifeblood (Max Health)',
    desc: 'Expands maximum HP pool and increases healing received from potions & skills.',
    perRank: '+30 Max HP per Rank',
    icon: <Heart className="h-5 w-5 text-emerald-400" />,
    accent: 'border-emerald-400/40',
  },
  {
    key: 'cooldownRank',
    name: 'Chrono Resonance (Cooldowns)',
    desc: 'Accelerates recovery speed of Active Skills and Ultimate Abilities.',
    perRank: '+3.5% CDR per Rank',
    icon: <Timer className="h-5 w-5 text-cyan-400" />,
    accent: 'border-cyan-400/40',
  },
  {
    key: 'specialRank',
    name: 'Infinity Surge (Special Abilities)',
    desc: 'Amplifies damage multipliers of all Hero Active Skills and Ultimate finishers.',
    perRank: '+12% Skill Power per Rank',
    icon: <Flame className="h-5 w-5 text-amber-400" />,
    accent: 'border-amber-400/40',
  },
];

export const SkillsView: React.FC<SkillsViewProps> = ({ save, onUpgradeSkill }) => {
  const maxRank = 10;

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            Soul Mastery • Permanent Account Upgrades
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Skills & Attributes Sanctuary
          </h2>
        </div>

        <div className="flex flex-wrap gap-2.5 text-xs font-extrabold">
          <span className="rounded-xl border border-purple-400/50 bg-purple-950/70 px-3.5 py-2 text-purple-200">
            ✦ Skill Points: {save.skillPoints}
          </span>
          <span className="rounded-xl border border-amber-400/50 bg-amber-950/60 px-3.5 py-2 text-amber-200">
            🪙 Coins: {save.coins}
          </span>
        </div>
      </div>

      {/* Player Level & XP Bar */}
      <div className="rounded-2xl border border-purple-400/30 bg-[#140d2e]/90 p-4">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-amber-200">Player Level {save.playerLevel}</span>
          <span className="text-purple-300">
            {save.xp} / {xpRequiredForLevel(save.playerLevel)} XP (Next Level grants +1 Skill Point)
          </span>
        </div>
        <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-950">
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-fuchsia-400 to-amber-400 transition-all"
            style={{
              width: `${Math.min(100, (save.xp / xpRequiredForLevel(save.playerLevel)) * 100)}%`,
            }}
          />
        </div>
      </div>

      {/* 5 Skill Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SKILL_NODES.map((node) => {
          const rank = save.skillUpgrades[node.key] || 0;
          const isMax = rank >= maxRank;
          const coinCost = Math.round(110 * Math.pow(1.42, rank));
          const canUseSp = !isMax && save.skillPoints >= 1;
          const canUseCoins = !isMax && save.coins >= coinCost;

          return (
            <div
              key={node.key}
              className={`flex flex-col justify-between rounded-3xl border ${node.accent} bg-gradient-to-b from-[#171036] to-[#0b071b] p-5 shadow-lg`}
            >
              <div>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950/80 border border-white/10">
                      {node.icon}
                    </div>
                    <div>
                      <h3 className="text-sm font-extrabold text-white">{node.name}</h3>
                      <div className="text-xs font-bold text-amber-300">{node.perRank}</div>
                    </div>
                  </div>
                  <span className="rounded-xl bg-slate-950/80 px-3 py-1 text-xs font-extrabold text-purple-200">
                    Rank {rank}/{maxRank}
                  </span>
                </div>

                <p className="mt-3 text-xs text-slate-300">{node.desc}</p>

                {/* Rank pips */}
                <div className="mt-3 flex gap-1">
                  {Array.from({ length: maxRank }).map((_, idx) => (
                    <div
                      key={idx}
                      className={`h-2 flex-1 rounded-full ${
                        idx < rank
                          ? 'bg-gradient-to-r from-amber-400 to-purple-400'
                          : 'bg-slate-800'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {isMax ? (
                  <div className="w-full rounded-xl border border-emerald-400/40 bg-emerald-950/40 py-2.5 text-center text-xs font-extrabold text-emerald-300">
                    ✦ Maximum Mastery Reached
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      disabled={!canUseSp}
                      onClick={() => {
                        soundEngine.playSfx('secretChest');
                        onUpgradeSkill(node.key, 0, true);
                      }}
                      className={`flex-1 rounded-xl py-2.5 text-xs font-extrabold transition ${
                        canUseSp
                          ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md hover:brightness-110'
                          : 'border border-slate-800 bg-slate-900 text-slate-500'
                      }`}
                    >
                      Spend 1 Skill Pt
                    </button>
                    <button
                      type="button"
                      disabled={!canUseCoins}
                      onClick={() => {
                        soundEngine.playSfx('secretChest');
                        onUpgradeSkill(node.key, coinCost, false);
                      }}
                      className={`flex-1 rounded-xl py-2.5 text-xs font-extrabold transition ${
                        canUseCoins
                          ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md hover:brightness-110'
                          : 'border border-slate-800 bg-slate-900 text-slate-500'
                      }`}
                    >
                      Train • {coinCost} 🪙
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================================
// 2. QUESTS TRACKER VIEW
// ============================================================================
interface QuestsViewProps {
  save: SaveData;
  onClaimQuest: (quest: QuestDef) => void;
}

export const QuestsView: React.FC<QuestsViewProps> = ({ save, onClaimQuest }) => {
  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            Royal Commissions • Earn Coins, XP & Skill Points
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Shadow Realm Quests
          </h2>
        </div>
        <div className="text-xs font-bold text-slate-300">
          Completed & Claimed:{' '}
          <span className="font-extrabold text-amber-300">
            {save.claimedQuestIds.length} / {QUESTS_DATA.length}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {QUESTS_DATA.map((q) => {
          const current = getQuestOrAchievementMetric(save, q.metric);
          const pct = Math.min(100, Math.round((current / q.target) * 100));
          const isClaimed = save.claimedQuestIds.includes(q.id);
          const canClaim = !isClaimed && current >= q.target;

          return (
            <div
              key={q.id}
              className={`flex flex-col justify-between rounded-3xl border p-5 transition ${
                canClaim
                  ? 'border-amber-400 bg-gradient-to-b from-[#23144a] to-[#0f0924] shadow-[0_0_24px_rgba(251,191,36,0.25)]'
                  : isClaimed
                  ? 'border-emerald-500/30 bg-[#0e0a20]/75'
                  : 'border-purple-400/25 bg-[#140d2c]'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-fantasy text-base font-extrabold text-white">{q.title}</h3>
                  <span className="shrink-0 rounded-lg bg-slate-950/80 px-2.5 py-1 text-[11px] font-extrabold text-amber-300">
                    +{q.rewardCoins}🪙 • +{q.rewardXp}XP
                    {q.rewardSkillPoints ? ` • +${q.rewardSkillPoints}SP` : ''}
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-slate-300">{q.description}</p>

                {/* Progress Bar */}
                <div className="mt-3">
                  <div className="flex justify-between text-[11px] font-bold">
                    <span className="text-slate-400">Progress</span>
                    <span className="text-purple-200">
                      {Math.min(current, q.target)} / {q.target} ({pct}%)
                    </span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-950">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-amber-400 transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-4">
                {isClaimed ? (
                  <div className="flex items-center justify-center gap-1.5 rounded-xl border border-emerald-400/30 bg-emerald-950/40 py-2 text-xs font-extrabold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" /> Reward Claimed
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={!canClaim}
                    onClick={() => {
                      soundEngine.playSfx('victory');
                      onClaimQuest(q);
                    }}
                    className={`w-full rounded-xl py-2.5 text-xs font-extrabold transition ${
                      canClaim
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-lg hover:brightness-110'
                        : 'border border-slate-800 bg-slate-900 text-slate-500'
                    }`}
                  >
                    {canClaim ? '✦ Claim Quest Reward!' : 'In Progress'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================================
// 3. ACHIEVEMENTS HALL VIEW
// ============================================================================
interface AchievementsViewProps {
  save: SaveData;
  onClaimAchievement: (ach: AchievementDef) => void;
}

export const AchievementsView: React.FC<AchievementsViewProps> = ({
  save,
  onClaimAchievement,
}) => {
  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
        <div>
          <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
            Hall of Legends • Eternal Milestones
          </div>
          <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
            Achievements
          </h2>
        </div>
        <div className="text-xs font-bold text-slate-300">
          Unlocked:{' '}
          <span className="font-extrabold text-amber-300">
            {save.claimedAchievementIds.length} / {ACHIEVEMENTS_DATA.length}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {ACHIEVEMENTS_DATA.map((ach) => {
          const current = getQuestOrAchievementMetric(save, ach.metric);
          const pct = Math.min(100, Math.round((current / ach.target) * 100));
          const isClaimed = save.claimedAchievementIds.includes(ach.id);
          const canClaim = !isClaimed && current >= ach.target;

          return (
            <div
              key={ach.id}
              className={`flex flex-col justify-between rounded-3xl border p-4 transition ${
                canClaim
                  ? 'border-amber-400 bg-gradient-to-b from-[#25154d] to-[#0f0822] shadow-lg'
                  : isClaimed
                  ? 'border-amber-400/35 bg-[#130c2a]'
                  : 'border-purple-400/20 bg-[#100a22]/80'
              }`}
            >
              <div>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-300/30 bg-slate-950/70 text-2xl">
                    {ach.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-white">{ach.title}</h3>
                    <div className="text-[11px] font-bold text-amber-300">
                      +{ach.rewardCoins}🪙 • +{ach.rewardSkillPoints} Skill Pt
                    </div>
                  </div>
                </div>
                <p className="mt-2.5 text-xs text-slate-300">{ach.description}</p>
                <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-950">
                  <div
                    className="h-full bg-amber-400 transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="mt-1 text-right text-[10px] text-slate-400">
                  {Math.min(current, ach.target)} / {ach.target}
                </div>
              </div>

              <div className="mt-3">
                {isClaimed ? (
                  <div className="flex items-center justify-center gap-1 rounded-xl border border-emerald-400/30 bg-emerald-950/40 py-2 text-xs font-extrabold text-emerald-300">
                    <Award className="h-3.5 w-3.5" /> Honored
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={!canClaim}
                    onClick={() => {
                      soundEngine.playSfx('victory');
                      onClaimAchievement(ach);
                    }}
                    className={`w-full rounded-xl py-2 text-xs font-extrabold transition ${
                      canClaim
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md'
                        : 'border border-slate-800 bg-slate-900 text-slate-500'
                    }`}
                  >
                    {canClaim ? 'Claim Trophy!' : 'Locked'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================================
// 4. SETTINGS, PERFORMANCE, OFFLINE SAVE & ANDROID APK INFO
// ============================================================================
interface SettingsViewProps {
  save: SaveData;
  onUpdateSettings: (patch: Partial<SaveData['settings']>) => void;
  onResetSave: () => void;
  onImportSaveJson: (raw: string) => boolean;
}

const GRAPHICS_OPTIONS: { id: GraphicsQuality; label: string; desc: string }[] = [
  {
    id: 'low',
    label: 'Low',
    desc: 'Best battery & 60 FPS on budget Android phones/tablets. Essential sprites only.',
  },
  {
    id: 'medium',
    label: 'Medium',
    desc: 'Balanced 3-layer parallax & clean combat particles.',
  },
  {
    id: 'high',
    label: 'High',
    desc: 'Full parallax worlds, dash afterimages, weapon glow & ambient weather.',
  },
  {
    id: 'maximum',
    label: 'Maximum',
    desc: 'Ultra particle density, screen impact shake & full celestial lighting.',
  },
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  save,
  onUpdateSettings,
  onResetSave,
  onImportSaveJson,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);
  const [backupStatus, setBackupStatus] = useState('');

  const handleExportSave = () => {
    try {
      const blob = new Blob([JSON.stringify(save, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `infinity-shadow-realms-v2-save-lv${save.playerLevel}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setBackupStatus('Offline Save Backup downloaded successfully!');
    } catch {
      setBackupStatus('Could not export file.');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs font-extrabold tracking-widest text-amber-300 uppercase">
          System Configuration • Saved Locally Offline
        </div>
        <h2 className="font-fantasy text-2xl sm:text-3xl font-extrabold text-white">
          Settings & Android Optimization
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Audio Volume Controls */}
        <div className="rounded-3xl border border-purple-400/30 bg-[#140d2d] p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-extrabold text-amber-300">
            <Volume2 className="h-4 w-4" /> Audio & Soundscape
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold">
              <span>Music Volume</span>
              <span className="text-amber-300">
                {Math.round(save.settings.musicVolume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={save.settings.musicVolume}
              onChange={(e) => onUpdateSettings({ musicVolume: parseFloat(e.target.value) })}
              className="mt-2 w-full accent-amber-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold">
              <span>Combat & UI SFX Volume</span>
              <span className="text-purple-300">
                {Math.round(save.settings.sfxVolume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={save.settings.sfxVolume}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                onUpdateSettings({ sfxVolume: val });
                soundEngine.playSfx('uiClick');
              }}
              className="mt-2 w-full accent-purple-400"
            />
          </div>
        </div>

        {/* Android Touchscreen Controls Tuning */}
        <div className="rounded-3xl border border-purple-400/30 bg-[#140d2d] p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-extrabold text-cyan-300">
            <Smartphone className="h-4 w-4" /> Android Touchscreen Controls
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-white">Virtual Joystick & Skill Buttons</div>
              <div className="text-[11px] text-slate-400">
                Display on-screen touch controls during combat
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({ showTouchControls: !save.settings.showTouchControls })
              }
              className={`rounded-xl px-4 py-2 text-xs font-extrabold transition ${
                save.settings.showTouchControls
                  ? 'bg-emerald-500 text-slate-950'
                  : 'border border-slate-700 bg-slate-900 text-slate-300'
              }`}
            >
              {save.settings.showTouchControls ? 'Enabled' : 'Hidden'}
            </button>
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold">
              <span>Control Cluster Size (Phones & Tablets)</span>
              <span className="text-cyan-300">
                {Math.round(save.settings.touchControlScale * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.85}
              max={1.18}
              step={0.03}
              value={save.settings.touchControlScale}
              onChange={(e) =>
                onUpdateSettings({ touchControlScale: parseFloat(e.target.value) })
              }
              className="mt-2 w-full accent-cyan-400"
            />
          </div>
        </div>

        {/* Graphics Quality Presets */}
        <div className="rounded-3xl border border-purple-400/30 bg-[#140d2d] p-5 space-y-3 lg:col-span-2">
          <div className="flex items-center gap-2 text-sm font-extrabold text-amber-300">
            <Sparkles className="h-4 w-4" /> Graphics & Performance Presets
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {GRAPHICS_OPTIONS.map((opt) => {
              const active = save.settings.graphicsQuality === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playSfx('uiClick');
                    onUpdateSettings({ graphicsQuality: opt.id });
                  }}
                  className={`rounded-2xl border p-3.5 text-left transition ${
                    active
                      ? 'border-amber-400 bg-[#23144a] shadow-lg'
                      : 'border-purple-400/20 bg-slate-950/60 hover:border-purple-400/50'
                  }`}
                >
                  <div className="text-sm font-extrabold text-white">{opt.label}</div>
                  <p className="mt-1 text-[11px] text-slate-300">{opt.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Offline Save Data Backup & Safe Reset */}
        <div className="rounded-3xl border border-purple-400/30 bg-[#140d2d] p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-extrabold text-purple-300">
            <Sliders className="h-4 w-4" /> Offline Save Data Vault
          </div>
          <p className="text-xs text-slate-300">
            All progress (Coins, Heroes, Worlds, Skills, Inventory, Quests & Settings) is
            automatically saved locally on your device for 100% offline single-player play.
          </p>
          {backupStatus && (
            <div className="rounded-xl bg-emerald-950/70 border border-emerald-400/40 px-3 py-2 text-xs font-bold text-emerald-200">
              {backupStatus}
            </div>
          )}
          <div className="flex flex-wrap gap-2.5 pt-1">
            <button
              type="button"
              onClick={handleExportSave}
              className="rounded-xl border border-amber-400/50 bg-amber-500/15 px-4 py-2 text-xs font-extrabold text-amber-200 hover:bg-amber-500/25"
            >
              Export Save JSON
            </button>

            <label className="cursor-pointer rounded-xl border border-purple-400/50 bg-purple-950/60 px-4 py-2 text-xs font-extrabold text-purple-200 hover:border-amber-300">
              Import Save JSON
              <input
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    if (typeof reader.result === 'string') {
                      const ok = onImportSaveJson(reader.result);
                      setBackupStatus(
                        ok
                          ? 'Save Data restored safely!'
                          : 'Invalid save file — existing progress kept safe.'
                      );
                    }
                  };
                  reader.readAsText(file);
                }}
              />
            </label>

            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-4 py-2 text-xs font-bold text-rose-300 hover:bg-rose-900/50"
              >
                Reset Progress
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetSave();
                    setConfirmReset(false);
                    setBackupStatus('Save data reset to fresh starter profile.');
                  }}
                  className="flex items-center gap-1 rounded-xl bg-rose-600 px-3.5 py-2 text-xs font-extrabold text-white"
                >
                  <RotateCcw className="h-3.5 w-3.5" /> Confirm Wipe
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-300"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Android Tablet/Phone Fullscreen & APK Export Info */}
        <div className="rounded-3xl border border-amber-400/30 bg-[#140d2d] p-5 space-y-2.5">
          <div className="text-sm font-extrabold text-amber-300">
            📱 Android Phone / Tablet & APK Build Ready
          </div>
          <p className="text-xs leading-relaxed text-slate-300">
            <strong className="text-white">Offline Single-File Bundle:</strong> This build bundles
            all original anime artwork, Web Audio music, and combat engine into a self-contained
            offline HTML5 package. On Android Chrome, tap{' '}
            <span className="text-amber-200 font-semibold">Add to Home Screen</span> for instant
            fullscreen offline play, or wrap <code className="text-purple-300">dist/</code> into a
            native APK via Capacitor (<code className="text-amber-200">npx cap sync android</code>)
            with Android SDK / Java 17.
          </p>
        </div>
      </div>
    </div>
  );
};
