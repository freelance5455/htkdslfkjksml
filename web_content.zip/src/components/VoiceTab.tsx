import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, ShieldCheck, AlertCircle, Sparkles, RefreshCw } from 'lucide-react';
import { SupportedLanguage, ActionProposal, UserMemory } from '../types';
import { sendMessageToDost } from '../services/api';

interface VoiceTabProps {
  language: SupportedLanguage;
  onExecuteAction: (action: ActionProposal) => void;
  isForegroundActive: boolean;
  memories?: UserMemory[];
  onSaveMemory?: (fact: string) => void;
}

export const VoiceTab: React.FC<VoiceTabProps> = ({
  language,
  onExecuteAction,
  isForegroundActive,
  memories = [],
  onSaveMemory,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [dostReply, setDostReply] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check Web Speech Recognition support
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = language === 'urdu' ? 'ur-PK' : 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setErrorStatus(null);
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setErrorStatus('Microphone permission denied. Browser settings mein mic allow karein.');
        } else if (event.error !== 'no-speech') {
          setErrorStatus(`Voice error: ${event.error}`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setErrorStatus('Web Speech API is not supported in this browser. Type via Chat tab instead.');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [language]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      setErrorStatus('Speech recognition not available.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      if (transcript.trim()) {
        handleProcessVoice(transcript.trim());
      }
    } else {
      setTranscript('');
      setDostReply(null);
      setErrorStatus(null);
      try {
        recognitionRef.current.start();
      } catch (err: any) {
        console.warn('Start recognition failed:', err);
      }
    }
  };

  const handleProcessVoice = async (spokenText: string) => {
    setIsProcessing(true);
    try {
      const res = await sendMessageToDost([{ role: 'user', content: spokenText }], language, memories);
      setDostReply(res.reply);

      if (res.newMemory && onSaveMemory) {
        onSaveMemory(res.newMemory);
      }

      // Speak response using SpeechSynthesis
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(res.reply);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.lang = language === 'urdu' ? 'ur-PK' : 'en-US';
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        window.speechSynthesis.speak(utterance);
      }

      if (res.action) {
        onExecuteAction(res.action);
      }
    } catch (err: any) {
      setErrorStatus(`Error: ${err.message || 'Failed to process voice command.'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 p-6 items-center justify-between text-slate-100 select-none">
      {/* Top Header & Status */}
      <div className="w-full text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/40 text-cyan-400 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>DOST Voice Engine (Android TTS & STT)</span>
        </div>
        <h2 className="text-xl font-bold text-white">Voice Assistant</h2>
        <p className="text-xs text-slate-400">
          {language === 'roman_urdu'
            ? 'Boliye: "Camera kholo", "BTC ka scene batao", ya "Alarm lagao"'
            : language === 'urdu'
            ? 'بولیں: کیمرہ کھولیں، بی ٹی سی ریٹ بتائیں، یا الارم لگائیں'
            : 'Speak: "Open camera", "Check Bitcoin trend", or "Set an alarm"'}
        </p>
      </div>

      {/* Center Interactive Waveform & Push-to-Talk Orb */}
      <div className="flex flex-col items-center justify-center space-y-6 my-auto">
        {/* Dynamic Waveform rings */}
        <div className="relative flex items-center justify-center">
          {isListening && (
            <>
              <div className="absolute w-48 h-48 rounded-full bg-cyan-500/20 animate-ping" />
              <div className="absolute w-40 h-40 rounded-full bg-cyan-500/30 animate-pulse" />
            </>
          )}

          {isSpeaking && (
            <div className="absolute w-44 h-44 rounded-full bg-emerald-500/20 animate-pulse" />
          )}

          {/* Main Push-To-Talk Button */}
          <button
            onClick={toggleListening}
            disabled={isProcessing}
            className={`w-28 h-28 rounded-full flex flex-col items-center justify-center transition-all duration-300 relative z-10 shadow-2xl ${
              isListening
                ? 'bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-red-500/40 scale-105'
                : isSpeaking
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 text-slate-950 shadow-emerald-500/30'
                : 'bg-gradient-to-tr from-cyan-500 to-emerald-400 text-slate-950 hover:scale-105 shadow-cyan-500/30'
            }`}
          >
            {isListening ? (
              <MicOff className="w-10 h-10 animate-bounce" />
            ) : isSpeaking ? (
              <Volume2 className="w-10 h-10 animate-pulse" />
            ) : isProcessing ? (
              <RefreshCw className="w-10 h-10 animate-spin" />
            ) : (
              <Mic className="w-10 h-10" />
            )}
            <span className="text-[11px] font-bold mt-1 uppercase tracking-wider">
              {isListening ? 'Stop' : isSpeaking ? 'Speaking' : isProcessing ? 'Thinking' : 'Push To Talk'}
            </span>
          </button>
        </div>

        {/* Real-time Spoken Transcript */}
        <div className="w-full max-w-sm min-h-[70px] bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-center shadow-lg">
          {transcript ? (
            <div>
              <span className="text-[10px] uppercase font-semibold text-cyan-400 block mb-1">Aap ne bola:</span>
              <p className="text-sm font-medium text-slate-200">"{transcript}"</p>
            </div>
          ) : isListening ? (
            <p className="text-sm text-cyan-300 animate-pulse">DOST sun raha hai... Boliye!</p>
          ) : (
            <p className="text-xs text-slate-500">Tap mic and speak your command in Roman Urdu, Urdu, or English</p>
          )}
        </div>

        {/* DOST Reply Bubble */}
        {dostReply && (
          <div className="w-full max-w-sm bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 text-sm text-slate-200 shadow-xl animate-in fade-in duration-300">
            <div className="flex items-center justify-between gap-2 mb-1.5 border-b border-slate-800 pb-1">
              <span className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> DOST Response
              </span>
              {isSpeaking && <span className="text-[10px] text-emerald-400 animate-pulse">Audio Playing...</span>}
            </div>
            <p className="leading-relaxed">{dostReply}</p>
          </div>
        )}

        {/* Error notification */}
        {errorStatus && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-red-950/60 border border-red-800/50 text-red-300 text-xs max-w-sm">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorStatus}</span>
          </div>
        )}
      </div>

      {/* Android System Compliance Notice */}
      <div className="w-full bg-slate-900/70 border border-slate-800/80 rounded-xl p-3 text-[11px] text-slate-400 space-y-1">
        <div className="flex items-center gap-1.5 font-semibold text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>Android OS Background Microphone Reality:</span>
        </div>
        <p>
          Android 14+ prohibits continuous background microphone recording without an active Foreground Service.
          DOST AI uses a persistent notification quick action for zero-latency manual activation when wake-word listening is suspended by OS battery saver.
        </p>
      </div>
    </div>
  );
};
