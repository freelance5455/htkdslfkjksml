import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  BookOpen,
  Sparkles,
  Flame,
  Cake,
  Plus,
  MapPin,
  Users,
} from 'lucide-react';
import { CalendarDay, LocationPreset, UserSettings } from '../types';
import { ZmanimPanel } from './ZmanimPanel';
import { DailyVerseCard } from './DailyVerseCard';
import { getTranslations } from '../services/i18n';

interface CalendarDayViewProps {
  currentDate: Date;
  onDateChange: (date: Date) => void;
  day: CalendarDay;
  location: LocationPreset;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onOpenAddEvent: (defaultDate?: CalendarDay) => void;
}

export const CalendarDayView: React.FC<CalendarDayViewProps> = ({
  currentDate,
  onDateChange,
  day,
  location,
  settings,
  onUpdateSettings,
  onOpenAddEvent,
}) => {
  const t = getTranslations(settings?.language || 'en');
  const isRtl = (settings?.language || 'en') === 'he';

  const prevDay = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() - 1);
    onDateChange(d);
  };

  const nextDay = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() + 1);
    onDateChange(d);
  };

  const prevMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() - 1);
    onDateChange(d);
  };

  const nextMonth = () => {
    const d = new Date(currentDate);
    d.setMonth(d.getMonth() + 1);
    onDateChange(d);
  };

  const prevYear = () => {
    const d = new Date(currentDate);
    d.setFullYear(d.getFullYear() - 1);
    onDateChange(d);
  };

  const nextYear = () => {
    const d = new Date(currentDate);
    d.setFullYear(d.getFullYear() + 1);
    onDateChange(d);
  };

  const goToToday = () => {
    onDateChange(new Date());
  };

  return (
    <div className="space-y-6">
      {/* Day Top Bar */}
      <div className="bg-[#161616] rounded-2xl p-6 border border-[#2A2A2A] shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-center sm:text-left">
          <div className="flex items-center gap-3 justify-center sm:justify-start">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#C5A267] font-serif-hebrew" dir="rtl">
              {day.hebrewDateStrHe}
            </h2>
            {day.isToday && (
              <span className="px-2.5 py-0.5 rounded-sm text-xs font-bold bg-[#C5A267] text-[#0F0F0F]">
                {t.today}
              </span>
            )}
          </div>
          <p className="text-sm font-medium text-[#888888] mt-1">
            {day.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}{' '}
            • <span className="text-[#D1D1D1]" dir="rtl">{day.hebrewDateStrHe}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={goToToday}
            className="px-4 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs sm:text-sm font-medium text-[#D1D1D1] transition-colors"
          >
            {t.today}
          </button>
          <div className="flex flex-wrap items-center gap-2 bg-[#1A1A1A] p-1 rounded-xl border border-[#2A2A2A]">
            {/* Day Nav */}
            <div className="flex items-center gap-1 border-r border-[#2A2A2A] pr-1.5">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'יום' : 'Day'}</span>
              <button
                onClick={prevDay}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.previousDay}
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextDay}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.nextDay}
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Month Nav */}
            <div className="flex items-center gap-1 border-r border-[#2A2A2A] pr-1.5">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'חודש' : 'Month'}</span>
              <button
                onClick={prevMonth}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.previousMonth}
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextMonth}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.nextMonth}
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Year Nav */}
            <div className="flex items-center gap-1">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'שנה' : 'Year'}</span>
              <button
                onClick={prevYear}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={isRtl ? 'שנה קודמת' : 'Previous Year'}
              >
                <ChevronsLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextYear}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={isRtl ? 'שנה הבאה' : 'Next Year'}
              >
                <ChevronsRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <button
            onClick={() => onOpenAddEvent(day)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs sm:text-sm font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addEvent}</span>
          </button>
        </div>
      </div>

      {/* Grid: Zmanim and Day Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Zmanim Table */}
        <div className="lg:col-span-7">
          <ZmanimPanel
            date={day.gregorianDate}
            location={location}
            settings={settings}
            onUpdateSettings={onUpdateSettings}
          />
        </div>

        {/* Right Column: Holidays, Parasha, Personal Events, Daily Verse */}
        <div className="lg:col-span-5 space-y-6">
          {/* Holidays & Torah Card */}
          <div className="bg-[#1A1A1A] rounded-2xl p-6 border border-[#2A2A2A] shadow-xl space-y-4">
            <span className="text-xs font-bold text-[#555555] uppercase tracking-[0.2em] block">
              Torah & Highlights
            </span>

            {/* Holidays List */}
            {day.holidays.length > 0 ? (
              <div className="space-y-2">
                {day.holidays.map((h, i) => (
                  <div
                    key={i}
                    className="p-3.5 rounded-xl bg-[#251f14] border-l-2 border-[#FCD34D] flex items-center justify-between gap-2"
                  >
                    <div>
                      <div className="font-bold text-sm text-[#FCD34D] flex items-center gap-1.5">
                        <span>{h.name}</span>
                      </div>
                      <div className="text-xs text-[#C5A267] font-hebrew mt-0.5" dir="rtl">
                        {h.hebrewName}
                      </div>
                    </div>
                    {h.description && (
                      <span className="text-xs text-[#888888] max-w-[150px] truncate text-right">
                        {h.description}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#666666] italic">
                No special holidays or fasts on this date.
              </p>
            )}

            {/* Parashat Hashavua */}
            {day.parasha && (
              <div className="p-3.5 rounded-xl bg-[#16202e] border-l-2 border-blue-400">
                <div className="text-xs font-bold text-blue-300 uppercase tracking-wider">
                  Weekly Torah Portion
                </div>
                <div className="text-base font-serif-hebrew font-bold text-[#EAEAEA] mt-0.5" dir="rtl">
                  {day.parasha.name} ({day.parasha.hebrewName})
                </div>
              </div>
            )}

            {/* Personal Hebrew Events on this day */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#555555] uppercase tracking-[0.2em]">
                  {t.personalEvents}
                </span>
                <button
                  onClick={() => onOpenAddEvent(day)}
                  className="text-xs text-[#C5A267] font-semibold hover:underline cursor-pointer"
                >
                  + {t.addEvent}
                </button>
              </div>

              {day.events.length > 0 ? (
                <div className="space-y-2">
                  {day.events.map((ev) => (
                    <div
                      key={ev.id}
                      className="p-3 rounded-xl bg-[#161616] border border-[#2A2A2A] flex items-center justify-between"
                      style={{
                        [isRtl ? 'borderRightColor' : 'borderLeftColor']: ev.color || '#C5A267',
                        [isRtl ? 'borderRightWidth' : 'borderLeftWidth']: 3,
                      }}
                    >
                      <div>
                        <div className="font-bold text-sm text-[#EAEAEA] flex items-center gap-1.5 flex-wrap">
                          {ev.type === 'yahrzeit' ? (
                            <Flame className="w-4 h-4 text-blue-400" />
                          ) : ev.type === 'birthday' ? (
                            <Cake className="w-4 h-4 text-[#C5A267]" />
                          ) : (
                            <Sparkles className="w-4 h-4 text-emerald-400" />
                          )}
                          <span>{ev.displayTitle || ev.title}</span>
                          {ev.displayHebrewTitle && (
                            <span className="text-xs text-[#C5A267] font-hebrew" dir="rtl">
                              ({ev.displayHebrewTitle})
                            </span>
                          )}
                        </div>
                        {ev.location && (
                          <div className="flex items-center gap-1 text-xs text-[#888888] mt-1">
                            <MapPin className="w-3.5 h-3.5 text-[#C5A267]/80" />
                            <span>{ev.location}</span>
                          </div>
                        )}
                        {ev.participants && ev.participants.length > 0 && (
                          <div className="flex items-center gap-1.5 text-xs text-[#888888] mt-1 flex-wrap">
                            <Users className="w-3.5 h-3.5 text-[#C5A267]" />
                            <span>{ev.participants.join(', ')}</span>
                          </div>
                        )}
                        {ev.notes && (
                          <div className="text-xs text-[#777777] mt-1">
                            {ev.notes}
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-[#222222] text-[#888888] uppercase">
                        {ev.type === 'birthday'
                          ? (isRtl ? t.hebrewBirthday : t.birthday)
                          : ev.type === 'yahrzeit'
                          ? (isRtl ? t.yahrzeitMemorial : t.yahrzeit)
                          : ev.type === 'anniversary'
                          ? (isRtl ? t.hebrewAnniversary : t.anniversary)
                          : ev.type === 'barmitzvah'
                          ? (isRtl ? t.barBatMitzvah : t.barmitzvah)
                          : (isRtl ? t.customHebrewEvent : t.customEvent)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-3 rounded-xl border border-dashed border-[#2A2A2A] text-center text-xs text-[#555555]">
                  {isRtl ? 'אין אירועים אישיים מתוכננים לתאריך עברי זה.' : 'No personal events scheduled for this Hebrew date.'}
                </div>
              )}
            </div>
          </div>

          {/* Daily Verse Integration */}
          <DailyVerseCard date={day.gregorianDate} />
        </div>
      </div>
    </div>
  );
};
