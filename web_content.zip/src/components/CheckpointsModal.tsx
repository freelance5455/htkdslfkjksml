/**
 * GODEX v0.0.1 - Checkpoints & Rollback History Modal
 */

import React, { useState } from 'react';
import { History, RotateCcw, Plus, X, Check, Clock } from 'lucide-react';
import { Checkpoint } from '../types';

interface CheckpointsModalProps {
  isOpen: boolean;
  onClose: () => void;
  checkpoints: Checkpoint[];
  onCreateCheckpoint: (name: string, description: string) => void;
  onRollback: (checkpointId: string) => void;
}

export const CheckpointsModal: React.FC<CheckpointsModalProps> = ({
  isOpen,
  onClose,
  checkpoints,
  onCreateCheckpoint,
  onRollback
}) => {
  const [newCheckpointName, setNewCheckpointName] = useState('');
  const [newCheckpointDesc, setNewCheckpointDesc] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCheckpointName.trim()) return;
    onCreateCheckpoint(newCheckpointName.trim(), newCheckpointDesc.trim() || 'Manual Checkpoint');
    setNewCheckpointName('');
    setNewCheckpointDesc('');
    setIsCreating(false);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-xl bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <History className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                PROJECT_CHECKPOINTS.TIMELINE
              </h2>
              <p className="text-[10px] text-neutral-400 font-sans">Deterministic state snapshots with instant rollback</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#07080D]">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
              Snapshots ({checkpoints.length})
            </span>
            <button
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#0E2A38] hover:bg-[#133A4E] border border-cyan-500/60 text-cyan-300 text-xs font-bold transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>CREATE_SNAPSHOT</span>
            </button>
          </div>

          {/* Create Checkpoint Form */}
          {isCreating && (
            <form onSubmit={handleCreate} className="p-3.5 rounded bg-[#0D1018] border border-cyan-500/40 space-y-2.5">
              <div className="text-xs font-bold text-white">Create Checkpoint Snapshot</div>
              <input
                type="text"
                autoFocus
                value={newCheckpointName}
                onChange={(e) => setNewCheckpointName(e.target.value)}
                placeholder="Checkpoint Title (e.g., Before Video Filters Refactor)"
                className="w-full h-8 px-2.5 rounded bg-[#06070A] border border-[#232F46] text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-cyan-500 font-sans"
              />
              <input
                type="text"
                value={newCheckpointDesc}
                onChange={(e) => setNewCheckpointDesc(e.target.value)}
                placeholder="Optional Description..."
                className="w-full h-8 px-2.5 rounded bg-[#06070A] border border-[#232F46] text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-cyan-500 font-sans"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-2.5 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] text-xs text-neutral-300 border border-[#232F46]"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white shadow"
                >
                  SAVE SNAPSHOT
                </button>
              </div>
            </form>
          )}

          {/* Checkpoints Timeline List */}
          <div className="space-y-2">
            {checkpoints.map((cp) => (
              <div
                key={cp.id}
                className="p-3 rounded bg-[#0D1018] border border-[#1B2232] flex items-center justify-between gap-4 transition-all hover:border-[#28354E]"
              >
                <div className="space-y-1 overflow-hidden">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs text-white truncate">{cp.name}</span>
                    <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono uppercase font-bold ${
                      cp.author === 'autopilot' ? 'bg-cyan-950/80 text-cyan-400 border border-cyan-800' : 'bg-[#151D2C] text-neutral-300 border border-[#232F46]'
                    }`}>
                      {cp.author}
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-400 truncate font-sans">{cp.description}</p>
                  <div className="flex items-center gap-3 text-[9px] font-mono text-neutral-500">
                    <span>{new Date(cp.timestamp).toLocaleString()}</span>
                    <span>{Object.keys(cp.files).length} files</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (confirm(`Restore snapshot "${cp.name}"? Current unsaved changes will be reverted.`)) {
                      onRollback(cp.id);
                      onClose();
                    }
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors shrink-0"
                >
                  <RotateCcw className="w-3 h-3 text-cyan-400" />
                  <span>RESTORE</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="h-11 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
