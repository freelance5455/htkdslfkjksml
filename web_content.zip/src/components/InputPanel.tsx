import React, { useRef } from 'react';
import { Play, RotateCcw, Upload, FileText, Clipboard, Sparkles, CheckCheck } from 'lucide-react';
import { SAMPLE_CNICS, formatCnic } from '../utils/cnicParser';

interface InputPanelProps {
  inputVal: string;
  setInputVal: (val: string) => void;
  onCheck: () => void;
  onClear: () => void;
  totalCount: number;
}

export const InputPanel: React.FC<InputPanelProps> = ({
  inputVal,
  setInputVal,
  onCheck,
  onClear,
  totalCount,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setInputVal(text);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputVal(inputVal ? `${inputVal}\n${text}` : text);
      }
    } catch {
      // Fallback
      alert('Clipboard permission not granted. Please paste directly into the box.');
    }
  };

  const handleLoadSamples = () => {
    setInputVal(SAMPLE_CNICS.join('\n'));
  };

  const handleFormatAllWithDashes = () => {
    const lines = inputVal.split(/\r?\n/);
    const formatted = lines
      .map((line) => {
        const raw = line.trim().replace(/\D/g, '');
        return raw.length === 13 ? formatCnic(raw) : line;
      })
      .join('\n');
    setInputVal(formatted);
  };

  const handleStripAllDashes = () => {
    const lines = inputVal.split(/\r?\n/);
    const stripped = lines
      .map((line) => line.trim().replace(/\D/g, ''))
      .filter((x) => x.length > 0)
      .join('\n');
    setInputVal(stripped);
  };

  // Count lines entered
  const enteredLines = inputVal
    .split(/\r?\n/)
    .map((x) => x.trim())
    .filter((x) => x.length > 0).length;

  return (
    <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-emerald-900/10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div>
          <label htmlFor="cnics" className="text-base font-bold text-slate-800 flex items-center gap-2">
            <span>Enter CNIC Numbers</span>
            <span className="text-xs font-normal text-slate-500">
              (13 Digits, with or without dashes)
            </span>
          </label>
          <p className="text-xs text-slate-500 mt-0.5">
            Supports batch paste, newlines, commas, or CSV files.
          </p>
        </div>

        {/* Quick Tools */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={handleLoadSamples}
            className="text-xs font-medium text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100/80 px-2.5 py-1.5 rounded-md transition-colors flex items-center gap-1 border border-emerald-200"
            title="Load realistic sample CNICs to test immediately"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Load Samples</span>
          </button>

          <button
            type="button"
            onClick={handlePasteClipboard}
            className="text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-md transition-colors flex items-center gap-1"
            title="Paste from clipboard"
          >
            <Clipboard className="w-3.5 h-3.5 text-slate-500" />
            <span>Paste</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-md transition-colors flex items-center gap-1"
            title="Upload CSV or TXT batch file"
          >
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            <span>Import File</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.csv"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>
      </div>

      {/* Main Textarea */}
      <div className="mt-3 relative">
        <textarea
          id="cnics"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder={`3520212345671\n35202-1234567-2\n4210198765431\n1730155443321`}
          className="w-full h-44 sm:h-48 p-3.5 sm:p-4 text-slate-800 font-mono text-sm sm:text-base leading-relaxed border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-slate-50/50 resize-y transition-all placeholder:text-slate-400"
          spellCheck={false}
        />

        <div className="flex items-center justify-between text-xs text-slate-500 px-1 mt-1.5">
          <div className="flex items-center gap-3">
            <span>
              Lines detected: <strong className="text-slate-700 font-semibold">{enteredLines}</strong>
            </span>
            {enteredLines > 0 && (
              <>
                <button
                  type="button"
                  onClick={handleFormatAllWithDashes}
                  className="text-emerald-700 hover:underline hover:text-emerald-800"
                >
                  Apply 00000-0000000-0
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={handleStripAllDashes}
                  className="text-slate-600 hover:underline hover:text-slate-800"
                >
                  Raw Digits
                </button>
              </>
            )}
          </div>
          <span>Chars: {inputVal.length}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
        <button
          type="button"
          onClick={onCheck}
          className="w-full py-3.5 px-4 bg-[#07843e] hover:bg-[#066a32] text-white rounded-xl font-bold text-base shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>CHECK CNIC</span>
        </button>

        <button
          type="button"
          onClick={onClear}
          className="w-full py-3.5 px-4 bg-[#262f3a] hover:bg-[#1b2129] text-white rounded-xl font-bold text-base shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
        >
          <RotateCcw className="w-4 h-4 text-slate-300" />
          <span>CLEAR ALL</span>
        </button>
      </div>
    </div>
  );
};
