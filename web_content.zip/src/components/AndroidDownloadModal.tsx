import React, { useState } from 'react';
import {
  Download,
  X,
  Smartphone,
  CheckCircle,
  FileArchive,
  Terminal,
  ExternalLink,
  ShieldCheck,
  Flame,
  Trophy,
  Video,
} from 'lucide-react';

interface AndroidDownloadModalProps {
  onClose: () => void;
}

export const AndroidDownloadModal: React.FC<AndroidDownloadModalProps> = ({ onClose }) => {
  const [downloadStarted, setDownloadStarted] = useState(false);

  const handleDownload = () => {
    setDownloadStarted(true);
    // Trigger download
    const link = document.createElement('a');
    link.href = '/color-rush-android.zip';
    link.download = 'color-rush-android.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloadStarted(false);
    }, 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col max-h-[90vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl overflow-y-auto no-scrollbar">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
              <Smartphone className="h-4 w-4" />
            </div>
            <h2 className="text-base font-black text-white">ANDROID PROJECT ZIP</h2>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Hero Card */}
        <div className="my-3 flex flex-col items-center rounded-2xl bg-gradient-to-tr from-emerald-950/50 via-slate-900 to-indigo-950/50 p-4 border border-emerald-500/30 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-500/20 mb-2">
            <FileArchive className="h-6 w-6" />
          </div>
          <span className="text-sm font-black text-white">color-rush-android.zip</span>
          <span className="text-[11px] text-emerald-300 font-mono mt-0.5">
            Complete Android Studio Package (~520 KB)
          </span>

          {/* Primary Action Button */}
          <button
            onClick={handleDownload}
            className="mt-3.5 flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 font-black text-sm text-white shadow-[0_4px_20px_rgba(16,185,129,0.4)] active:scale-95 transition-all hover:brightness-110"
          >
            {downloadStarted ? (
              <>
                <CheckCircle className="h-4 w-4 text-white animate-bounce" />
                <span>DOWNLOADING ZIP...</span>
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                <span>DOWNLOAD ANDROID ZIP</span>
              </>
            )}
          </button>

          <a
            href="/color-rush-android.zip"
            download="color-rush-android.zip"
            className="mt-2 text-[10px] text-slate-400 underline hover:text-emerald-400 flex items-center gap-1"
          >
            <span>Direct link backup</span>
            <ExternalLink className="h-2.5 w-2.5" />
          </a>
        </div>

        {/* Feature Verification Checklist */}
        <div className="flex flex-col gap-1.5 py-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider text-left">
            Included in this archive:
          </span>

          <div className="flex items-center gap-2 rounded-xl bg-slate-950/60 p-2 border border-slate-800 text-left">
            <Smartphone className="h-4 w-4 text-emerald-400 shrink-0" />
            <div className="flex flex-col text-[11px]">
              <span className="font-bold text-white">Capacitor Android Project</span>
              <span className="text-slate-400 text-[10px]">Gradle files, manifest, SDK 34, icons & splash</span>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl bg-slate-950/60 p-2 border border-slate-800 text-left">
            <Video className="h-4 w-4 text-amber-400 shrink-0" />
            <div className="flex flex-col text-[11px]">
              <span className="font-bold text-white">Google AdMob Rewarded Ads</span>
              <span className="text-slate-400 text-[10px]">App ID & Ad Unit ID ready for production</span>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl bg-slate-950/60 p-2 border border-slate-800 text-left">
            <Trophy className="h-4 w-4 text-yellow-400 shrink-0" />
            <div className="flex flex-col text-[11px]">
              <span className="font-bold text-white">Firebase & Global Leaderboard</span>
              <span className="text-slate-400 text-[10px]">Google Sign-In, Firestore rules, config</span>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl bg-slate-950/60 p-2 border border-slate-800 text-left">
            <Flame className="h-4 w-4 text-orange-400 shrink-0" />
            <div className="flex flex-col text-[11px]">
              <span className="font-bold text-white">Daily Streak & Gameplay</span>
              <span className="text-slate-400 text-[10px]">7-Day streak, 6 themes, sound synthesizer, haptics</span>
            </div>
          </div>
        </div>

        {/* Quick Build Instructions */}
        <div className="mt-2 rounded-2xl bg-slate-950/80 p-3 border border-slate-800 text-left">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 mb-1.5">
            <Terminal className="h-3.5 w-3.5 text-indigo-400" />
            <span>How to Build:</span>
          </div>
          <ol className="list-decimal list-inside text-[11px] text-slate-400 space-y-1">
            <li>Unzip <code className="text-amber-300 font-mono">color-rush-android.zip</code></li>
            <li>Run <code className="text-emerald-300 font-mono">npm install</code></li>
            <li>Open the <code className="text-indigo-300 font-mono">android</code> folder in Android Studio</li>
            <li>Run or build APK from Android Studio!</li>
          </ol>
        </div>

        {/* Footer */}
        <div className="mt-3 text-center text-[10px] text-slate-500">
          Color Rush Pro Android Edition · Ready for Production
        </div>
      </div>
    </div>
  );
};
