import React, { useState, useRef } from 'react';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Download,
  FileSpreadsheet,
  Edit2,
  Trash2,
  Camera,
  Upload,
  CheckCircle,
  AlertTriangle,
  ArrowUpDown,
  X,
  Layers,
  Thermometer,
  ShieldCheck,
  Image as ImageIcon,
  Check,
  Loader2,
  Share2,
  ArrowLeft,
  Home,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { PaintingReport, CoatingLayer, PaintingReportImage, WeatherCondition } from '../types/domain';
import { evaluateCoatingConditions, calculateDewPoint } from '../utils/dewPoint';
import { compressImage } from '../services/storage';
import { exportPaintingReportToExcel, generatePaintingReportExcelBlob } from '../utils/excelExporter';
import { downloadElementAsPdf, printHtmlSafely, generateElementPdfBlob } from '../utils/pdfGenerator';
import { ShareFileModal } from './ShareFileModal';

interface Props {
  reports: PaintingReport[];
  onSaveReport: (report: PaintingReport) => void;
  onDeleteReport: (id: string) => void;
  onOpenPhotoLightbox: (url: string, caption: string, title: string) => void;
  onBackToMenu?: () => void;
}

export const PaintingReportView: React.FC<Props> = ({
  reports,
  onSaveReport,
  onDeleteReport,
  onOpenPhotoLightbox,
  onBackToMenu
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReport, setSelectedReport] = useState<PaintingReport | null>(reports[0] || null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<PaintingReport | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Ref to the rendered printable document
  const sheetRef = useRef<HTMLDivElement>(null);

  // Filtered reports
  const filteredReports = reports.filter((r) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.reportNumber.toLowerCase().includes(q) ||
      r.client.toLowerCase().includes(q) ||
      r.jobSerialNumber.toLowerCase().includes(q) ||
      r.itemName.toLowerCase().includes(q)
    );
  });

  const handleCreateNew = () => {
    setEditingReport(null);
    setIsFormOpen(true);
  };

  const handleEdit = (report: PaintingReport) => {
    setEditingReport(report);
    setIsFormOpen(true);
  };

  // Direct Excel Export with complete formatting
  const handleExportExcel = (report: PaintingReport) => {
    exportPaintingReportToExcel(report);
    setActionFeedback('File Excel formattato esportato con successo (.xls)');
    setTimeout(() => setActionFeedback(null), 4000);
  };

  // Direct PDF Download via jsPDF & html2canvas (bypasses iframe print block)
  const handleDownloadPdf = async (report: PaintingReport) => {
    if (!sheetRef.current) return;
    setIsGeneratingPdf(true);
    setActionFeedback('Generazione PDF in corso...');
    try {
      const safeName = `Painting_Report_${report.reportNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
      await downloadElementAsPdf(sheetRef.current, safeName);
      setActionFeedback('PDF generato e scaricato regolarmente.');
    } catch (err) {
      console.error(err);
      setActionFeedback('Errore nella generazione del PDF. Utilizzo fallback stampa.');
      // Fallback
      if (sheetRef.current) {
        printHtmlSafely(sheetRef.current.innerHTML, `Painting Report ${report.reportNumber}`);
      }
    } finally {
      setIsGeneratingPdf(false);
      setTimeout(() => setActionFeedback(null), 4000);
    }
  };

  // Native print fallback
  const handleNativePrint = (report: PaintingReport) => {
    if (sheetRef.current) {
      printHtmlSafely(sheetRef.current.innerHTML, `Painting Report ${report.reportNumber}`);
    } else {
      window.print();
    }
  };

  return (
    <div className="space-y-6 pb-16 sm:pb-0">
      {/* Mobile Top Back Banner for Google Pixel 9 */}
      {onBackToMenu && (
        <div className="flex items-center justify-between bg-neutral-900 text-white px-3.5 py-2.5 rounded-2xl shadow-sm md:hidden">
          <button
            onClick={onBackToMenu}
            className="inline-flex items-center gap-2 text-xs font-bold hover:text-amber-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Torna al Menù Principale</span>
          </button>
          <span className="text-[10px] font-mono text-neutral-400">Google Pixel 9</span>
        </div>
      )}

      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-neutral-200 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-neutral-900">
              Painting Reports · Rapporti di Verniciatura & Sabbiatura
            </h1>
            <span className="text-[11px] font-mono text-neutral-500 bg-neutral-200 px-2 py-0.5 rounded">
              MOD. RV-U
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Raccolta dati per specifiche di verniciatura industriale, calcolo automatico punto di rugiada, controllo DFT ed esportazione in Excel e PDF
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleCreateNew}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Nuovo Painting Report</span>
          </button>
        </div>
      </div>

      {/* Action notification banner if any */}
      {actionFeedback && (
        <div className="p-3 bg-neutral-900 text-white text-xs rounded-lg flex items-center justify-between no-print shadow-sm">
          <div className="flex items-center gap-2">
            {isGeneratingPdf ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            )}
            <span>{actionFeedback}</span>
          </div>
          {!isGeneratingPdf && (
            <button onClick={() => setActionFeedback(null)} className="text-neutral-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* VIEW MODE CONDITIONAL: LISTATA PRINCIPALE O DETTAGLIO */}
      {viewMode === 'list' ? (
        /* ================= LISTATA PRINCIPALE (A PIENO SCHERMO) ================= */
        <div className="space-y-4 max-w-4xl mx-auto no-print">
          {/* Search Bar & Controls */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cerca per N. Report, Cliente, Commessa o Articolo..."
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-900"
                />
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 text-xs font-mono text-neutral-600">
                <span className="bg-neutral-100 px-3 py-1.5 rounded-xl font-semibold">
                  {filteredReports.length} {filteredReports.length === 1 ? 'Report' : 'Rapporti'}
                </span>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Nuovo</span>
                </button>
              </div>
            </div>
          </div>

          {/* List of Report Cards */}
          <div className="space-y-3">
            {filteredReports.length === 0 ? (
              <div className="p-10 bg-white border border-neutral-200 rounded-3xl text-center space-y-3 shadow-xs">
                <FileText className="w-10 h-10 text-neutral-300 mx-auto" />
                <h3 className="text-sm font-bold text-neutral-800">Nessun Painting Report trovato</h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                  Non ci sono rapporti che corrispondono alla ricerca oppure non ne hai ancora inserito nessuno.
                </p>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Crea il primo Painting Report</span>
                </button>
              </div>
            ) : (
              filteredReports.map((rep) => {
                const totalLayers = rep.layers.length;
                const totalPhotos = rep.images.length;
                const isSigned = rep.signoffs?.companyInspection?.signed;

                return (
                  <div
                    key={rep.id}
                    onClick={() => {
                      setSelectedReport(rep);
                      setViewMode('detail');
                    }}
                    className="bg-white border border-neutral-200 hover:border-neutral-400 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-neutral-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs sm:text-sm font-bold text-neutral-900 bg-neutral-100 px-2.5 py-1 rounded-lg border border-neutral-200">
                          {rep.reportNumber}
                        </span>
                        <span className="text-[11px] font-mono text-neutral-500">
                          📅 {rep.date}
                        </span>
                        <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200">
                          MOD. RV-U
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 self-start sm:self-auto">
                        {isSigned ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            Collaudato
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                            In attesa collaudo
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="py-2.5 space-y-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <h3 className="text-sm sm:text-base font-extrabold text-neutral-900 group-hover:text-amber-600 transition-colors">
                          {rep.client}
                        </h3>
                        <span className="text-xs font-mono text-neutral-500 shrink-0">
                          Commessa: <strong>{rep.jobSerialNumber}</strong>
                        </span>
                      </div>
                      <p className="text-xs text-neutral-600 line-clamp-2">
                        {rep.itemName} {rep.paintSystem ? `· Ciclo: ${rep.paintSystem}` : ''}
                      </p>
                    </div>

                    <div className="pt-2.5 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3 text-xs text-neutral-500 font-medium">
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <Layers className="w-3 h-3 text-neutral-700" />
                          {totalLayers} {totalLayers === 1 ? 'Strato' : 'Strati'}
                        </span>
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <ImageIcon className="w-3 h-3 text-neutral-700" />
                          {totalPhotos} {totalPhotos === 1 ? 'Foto' : 'Foto'}
                        </span>
                        {rep.surfacePreparationStd && (
                          <span className="text-[11px] font-mono text-neutral-400 hidden sm:inline">
                            Prep: {rep.surfacePreparationStd}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        {/* Instant WhatsApp / App Share Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReport(rep);
                            setIsShareModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                          title="Condividi subito questo report su WhatsApp o altre App"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Condividi</span>
                        </button>

                        {/* Open Report Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReport(rep);
                            setViewMode('detail');
                          }}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                        >
                          <span>Apri Report</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        /* ================= DETTAGLIO RAPPORTO SINGOLO (A PIENO SCHERMO) ================= */
        <div className="space-y-4 max-w-5xl mx-auto">
          {/* Top Back Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-neutral-900 text-white p-3 rounded-2xl shadow-sm no-print">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-colors"
              >
                <ArrowLeft className="w-4 h-4 text-amber-400" />
                <span>← Torna all'Elenco Report</span>
              </button>

              {onBackToMenu && (
                <button
                  type="button"
                  onClick={onBackToMenu}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Menù Principale</span>
                </button>
              )}
            </div>

            {selectedReport && (
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-neutral-400 hidden sm:inline">Report:</span>
                <span className="bg-neutral-800 text-amber-300 font-bold px-2.5 py-1 rounded-lg">
                  {selectedReport.reportNumber}
                </span>
              </div>
            )}
          </div>
          {selectedReport ? (
            <>
              {/* Document Action Bar (no-print) */}
              <div className="bg-white border border-neutral-200 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 no-print shadow-xs">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-neutral-800">
                    Painting Report:
                  </span>
                  <span className="font-mono text-xs font-bold text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded">
                    {selectedReport.reportNumber}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Share on WhatsApp / Native Android Share Sheet */}
                  <button
                    onClick={() => setIsShareModalOpen(true)}
                    title="Condividi PDF o Excel su WhatsApp o altre App"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-md transition-colors shadow-xs"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Condividi (WhatsApp / App)</span>
                  </button>

                  {/* Export Formatted Excel (.xls) */}
                  <button
                    onClick={() => handleExportExcel(selectedReport)}
                    title="Esporta foglio Excel formattato con griglia e colori"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-md transition-colors"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Esporta Excel (.xls)</span>
                  </button>

                  {/* Direct PDF Download */}
                  <button
                    onClick={() => handleDownloadPdf(selectedReport)}
                    disabled={isGeneratingPdf}
                    title="Genera e scarica file PDF A4 in alta risoluzione"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors disabled:opacity-50"
                  >
                    {isGeneratingPdf ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Download className="w-3.5 h-3.5" />
                    )}
                    <span>{isGeneratingPdf ? 'Creazione PDF...' : 'Scarica PDF'}</span>
                  </button>

                  {/* Native Print Dialog */}
                  <button
                    onClick={() => handleNativePrint(selectedReport)}
                    title="Stampa documento con finestra di dialogo"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded-md transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Stampa</span>
                  </button>

                  <div className="w-px h-5 bg-neutral-200 mx-1 hidden sm:block" />

                  <button
                    onClick={() => handleEdit(selectedReport)}
                    title="Modifica Dati Report"
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm('Eliminare definitivamente questo Painting Report?')) {
                        onDeleteReport(selectedReport.id);
                        setSelectedReport(reports.find((r) => r.id !== selectedReport.id) || null);
                      }
                    }}
                    title="Elimina Report"
                    className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Printable Painting Report Sheet (with ref for jsPDF capture) */}
              <div
                ref={sheetRef}
                id="printable-painting-report"
                className="bg-white border-2 border-neutral-800 rounded-sm p-6 text-neutral-900 shadow-sm print:p-0 print:border-none print:shadow-none text-xs font-sans"
              >
                {/* Header with Logo, Title and Date */}
                <div className="border-b-2 border-neutral-900 pb-3 flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3">
                      <div className="border-2 border-neutral-900 px-2.5 py-1 text-sm font-extrabold tracking-tighter uppercase font-mono bg-neutral-900 text-white">
                        Sfiller
                      </div>
                      <div className="text-[10px] text-neutral-600 font-medium">
                        L&apos;ESPERIENZA AL SERVIZIO<br />
                        <span className="text-[9px] text-neutral-400">www.sabbiaturaeverniciatura.it</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <h2 className="text-sm font-black uppercase tracking-wider text-neutral-900">
                      Rapporto di Verniciatura
                    </h2>
                    <div className="text-xs font-bold text-neutral-700">
                      PAINTING REPORT No.{' '}
                      <span className="font-mono text-neutral-900 text-sm underline">
                        {selectedReport.reportNumber}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-600 font-mono mt-0.5">
                      Date:{' '}
                      <span className="font-semibold text-neutral-900">
                        {selectedReport.date}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 1. DATI IDENTIFICATIVI / Identification Data */}
                <div className="mt-3 border border-neutral-900">
                  <div className="bg-neutral-200 px-2 py-1 font-bold text-[11px] uppercase tracking-wider border-b border-neutral-900 flex justify-between">
                    <span>Dati Identificativi</span>
                    <span className="font-normal italic">Identification Data</span>
                  </div>
                  <div className="grid grid-cols-2 divide-x divide-neutral-900 text-[11px]">
                    <div className="divide-y divide-neutral-900">
                      <div className="p-1.5 flex flex-col">
                        <span className="text-[10px] font-semibold text-neutral-500 uppercase">
                          Cliente / Client
                        </span>
                        <span className="font-bold text-neutral-900">
                          {selectedReport.client}
                        </span>
                      </div>
                      <div className="p-1.5 flex flex-col">
                        <span className="text-[10px] font-semibold text-neutral-500 uppercase">
                          Commessa - Matricola / Job - Serial Number
                        </span>
                        <span className="font-semibold font-mono text-neutral-900">
                          {selectedReport.jobSerialNumber}
                        </span>
                      </div>
                    </div>

                    <div className="divide-y divide-neutral-900">
                      <div className="p-1.5 flex flex-col">
                        <span className="text-[10px] font-semibold text-neutral-500 uppercase">
                          Subfornitore / Sub-supplier
                        </span>
                        <span className="font-bold text-neutral-900">
                          {selectedReport.subSupplier}
                        </span>
                      </div>
                      <div className="p-1.5 flex flex-col">
                        <span className="text-[10px] font-semibold text-neutral-500 uppercase">
                          N. Ordine - Pos. / Purchase Order N.
                        </span>
                        <span className="font-semibold font-mono text-neutral-900">
                          {selectedReport.purchaseOrderNumber}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="p-1.5 border-t border-neutral-900 flex flex-col bg-neutral-50/50">
                    <span className="text-[10px] font-semibold text-neutral-500 uppercase">
                      Denominazione Item / Item Name
                    </span>
                    <span className="font-bold text-neutral-900">
                      {selectedReport.itemName}
                    </span>
                  </div>
                </div>

                {/* 2. PREPARAZIONE SUPERFICIALE / Surface Preparation */}
                <div className="mt-3 border border-neutral-900">
                  <div className="bg-neutral-200 px-2 py-1 font-bold text-[11px] uppercase tracking-wider border-b border-neutral-900 flex justify-between">
                    <span>Preparazione Superficiale</span>
                    <span className="font-normal italic">Surface Preparation</span>
                  </div>

                  <div className="grid grid-cols-2 divide-x divide-neutral-900 text-[11px]">
                    <div className="divide-y divide-neutral-900">
                      <div className="p-1.5 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          PREPARZ. SUPERFICIALE
                        </span>
                        <span className="font-mono font-bold text-neutral-900">
                          {selectedReport.surfacePreparationStd}
                        </span>
                      </div>
                      <div className="p-1.5 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          TIPO ABRASIVO / Abrasive Type
                        </span>
                        <span className="font-semibold text-neutral-900">
                          {selectedReport.abrasiveTypeMesh}
                        </span>
                      </div>
                      <div className="p-1.5 flex flex-col">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          CONTAMINAZIONI / Abrasive Contaminants
                        </span>
                        <span className="text-[10px] italic text-neutral-800">
                          {selectedReport.abrasiveContaminants}
                        </span>
                      </div>
                    </div>

                    <div className="divide-y divide-neutral-900">
                      <div className="p-1.5 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          RUGOSITÀ / Incision Profile
                        </span>
                        <span className="font-mono font-bold text-neutral-900 bg-amber-100/70 px-1.5 py-0.5 rounded">
                          {selectedReport.incisionProfile}
                        </span>
                      </div>
                      <div className="p-1.5 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          PULIZIA SUPERFICIALE / Blast Cleaning
                        </span>
                        <span className="font-mono font-bold text-neutral-900 bg-amber-100/70 px-1.5 py-0.5 rounded">
                          {selectedReport.blastCleaningGrade}
                        </span>
                      </div>
                      <div className="p-1.5 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-600 font-semibold">
                          CONTAMINAZIONE POLVERE / Dust Testing
                        </span>
                        <span className="font-mono font-semibold text-neutral-900">
                          {selectedReport.dustTestingGrade}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Condizioni Ambiente Sabbiatura */}
                  <div className="border-t border-neutral-900 bg-neutral-100 text-[10px] font-bold px-2 py-0.5 uppercase flex justify-between">
                    <span>Condizioni Ambiente / Weather Conditions</span>
                    <span>OK</span>
                  </div>

                  <div className="grid grid-cols-4 divide-x divide-neutral-900 text-center text-[10px] border-t border-neutral-900">
                    <div className="p-1">
                      <div className="text-neutral-500 font-semibold">DATA</div>
                      <div className="font-mono font-bold text-neutral-900 mt-0.5">
                        {selectedReport.surfacePrepWeather.date}
                      </div>
                    </div>
                    <div className="p-1">
                      <div className="text-neutral-500 font-semibold">TEMP. ARIA</div>
                      <div className="font-mono font-bold text-neutral-900 mt-0.5">
                        {selectedReport.surfacePrepWeather.airTemperature} °C
                      </div>
                    </div>
                    <div className="p-1">
                      <div className="text-neutral-500 font-semibold">TEMP. SUPERFICIE</div>
                      <div className="font-mono font-bold text-neutral-900 mt-0.5">
                        {selectedReport.surfacePrepWeather.surfaceTemperature} °C
                      </div>
                    </div>
                    <div className="p-1 bg-amber-50">
                      <div className="text-neutral-500 font-semibold">PUNTO DI RUGIADA (CALC)</div>
                      <div className="font-mono font-bold text-neutral-900 mt-0.5">
                        {selectedReport.surfacePrepWeather.dewPoint} °C
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. VERNICIATURA / Coating & Multi-layer Spec */}
                <div className="mt-3 border border-neutral-900">
                  <div className="bg-neutral-200 px-2 py-1 font-bold text-[11px] uppercase tracking-wider border-b border-neutral-900 flex justify-between">
                    <span>Verniciatura / Coating</span>
                    <span className="font-mono text-[10px]">
                      SPEC: {selectedReport.paintingSpecification} · CICLO: {selectedReport.paintSystem}
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[10px] border-collapse">
                      <thead>
                        <tr className="bg-neutral-100 border-b border-neutral-900 divide-x divide-neutral-900 font-bold">
                          <th className="p-1.5 w-44">PARAMETRO / PARAMETER</th>
                          {selectedReport.layers.map((layer) => (
                            <th key={layer.id} className="p-1.5 text-center bg-amber-50">
                              <div>{layer.coatType}</div>
                              <div className="text-[9px] font-normal text-neutral-600">
                                REQ&apos;D DFT: {layer.requiredDftUm} µm
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-900">
                        {/* Nome Prodotto */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">NOME PRODOTTO / Paint Name</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-bold text-neutral-900 text-center">
                              {l.paintName}
                            </td>
                          ))}
                        </tr>

                        {/* Lotti Comp A e B */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">LOTTO COMP. A / Batch No. A</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.batchCompA}
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">LOTTO COMP. B / Batch No. B</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.batchCompB}
                            </td>
                          ))}
                        </tr>

                        {/* Colore */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">COLORE / Color</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-medium text-center">
                              {l.color}
                            </td>
                          ))}
                        </tr>

                        {/* Metodo di Applicazione */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">METODO DI APPLIC. / Method</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono font-bold text-center bg-neutral-50">
                              {l.applicationMethod}
                            </td>
                          ))}
                        </tr>

                        {/* Data Applicazione */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">DATA / Date</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.date}
                            </td>
                          ))}
                        </tr>

                        {/* Parametri Ambientali & Dew Point */}
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">TEMP-ARIA / Air Temp.</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.airTemp} °C
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">UMIDITÀ RELATIVA / Rel. Humidity</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.relativeHumidity} %
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 font-semibold text-neutral-700">TEMP-SUPERFICIE / Surface Temp.</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              {l.surfaceTemp} °C
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900 bg-amber-100/60 font-bold">
                          <td className="p-1.5 text-neutral-900">
                            PUNTO DI RUGIADA / Dew Point
                            <span className="block text-[8px] font-normal text-neutral-600">
                              (Valore Calcolato Automaticamente)
                            </span>
                          </td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center text-neutral-900">
                              {l.dewPoint} °C
                              <span className="block text-[8px] text-emerald-700 font-semibold">
                                ΔT {Math.round((l.surfaceTemp - l.dewPoint) * 10) / 10}°C (OK)
                              </span>
                            </td>
                          ))}
                        </tr>

                        {/* Spessore Film Secco (DFT) */}
                        <tr className="divide-x divide-neutral-900 bg-neutral-50">
                          <td className="p-1.5 font-bold text-neutral-900">
                            SPESSORE FILM SEC. (DFT)
                            <span className="block text-[9px] font-normal text-neutral-500">
                              Dry Film Thickness
                            </span>
                          </td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-mono text-center">
                              <div className="font-semibold text-neutral-900">
                                Med: <span className="underline">{l.dftMeasured.med} µm</span>
                              </div>
                              <div className="text-[9px] text-neutral-500">
                                Min: {l.dftMeasured.min} µm · Max: {l.dftMeasured.max} µm
                              </div>
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 4. CONTROLLI / Testing */}
                <div className="mt-3 border border-neutral-900">
                  <div className="bg-neutral-200 px-2 py-1 font-bold text-[11px] uppercase tracking-wider border-b border-neutral-900 flex justify-between">
                    <span>Controlli / Testing</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[10px] border-collapse">
                      <tbody className="divide-y divide-neutral-900">
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 w-44 font-semibold text-neutral-700">ESAME VISIVO / Visual Check</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-bold text-center text-emerald-700">
                              {l.visualCheck}
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 w-44 font-semibold text-neutral-700">SPESSORE FILM SECCO / DFT Av</td>
                          {selectedReport.layers.map((l) => (
                            <td key={l.id} className="p-1.5 font-bold text-center text-emerald-700">
                              {l.dftCheck}
                            </td>
                          ))}
                        </tr>
                        <tr className="divide-x divide-neutral-900">
                          <td className="p-1.5 w-44 font-semibold text-neutral-700">PROVA DI ADESIONE / Pull-Off Test</td>
                          {selectedReport.layers.map((l, idx) => (
                            <td key={l.id} className="p-1.5 font-semibold text-center text-neutral-800">
                              {idx === selectedReport.layers.length - 1 ? l.pullOffTest || 'OK' : '-'}
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 5. NOTE / Remarks & Instruments */}
                <div className="mt-3 border border-neutral-900">
                  <div className="bg-neutral-200 px-2 py-0.5 font-bold text-[10px] uppercase tracking-wider border-b border-neutral-900">
                    Note / Remarks (Strumenti di Misura Tarati)
                  </div>
                  <div className="p-2 text-[10px] font-mono text-neutral-800 whitespace-pre-line bg-neutral-50/50">
                    {selectedReport.instrumentNotes}
                    {selectedReport.generalRemarks && (
                      <div className="mt-1 pt-1 border-t border-neutral-300 font-sans text-neutral-700">
                        {selectedReport.generalRemarks}
                      </div>
                    )}
                  </div>
                </div>

                {/* 6. FOTO ALLEGATE AL REPORT */}
                {selectedReport.images && selectedReport.images.length > 0 && (
                  <div className="mt-3 border border-neutral-900 p-2">
                    <div className="font-bold text-[10px] uppercase tracking-wider mb-2 text-neutral-800 flex items-center justify-between">
                      <span>Rilievi Fotografici e Prove di Conformità ({selectedReport.images.length})</span>
                      <span className="font-mono text-[9px] text-neutral-500">Allegato Documentale</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      {selectedReport.images.map((img) => (
                        <div
                          key={img.id}
                          className="border border-neutral-300 rounded overflow-hidden cursor-pointer"
                          onClick={() => onOpenPhotoLightbox(img.url, img.caption, selectedReport.reportNumber)}
                        >
                          <div className="relative aspect-16/9 bg-neutral-100">
                            <img
                              src={img.url}
                              alt={img.caption}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute top-1 left-1 text-[9px] font-bold text-white bg-black/70 px-1.5 py-0.5 rounded">
                              {img.stage}
                            </div>
                          </div>
                          <div className="p-1.5 bg-neutral-50 text-[9px] text-neutral-800 leading-tight">
                            {img.caption}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 7. COLLAUDO & FIRME */}
                <div className="mt-3 border border-neutral-900">
                  <div className="grid grid-cols-4 divide-x divide-neutral-900 text-center text-[10px]">
                    <div className="p-2 flex flex-col justify-between h-20">
                      <div className="font-bold text-neutral-800">
                        COLLAUDO SABBIATURA & VERNICIATURA SFILLER
                      </div>
                      <div className="text-[9px] text-neutral-500">
                        {selectedReport.signoffs.companyInspection.signed ? (
                          <div className="font-semibold text-emerald-800">
                            F.to: {selectedReport.signoffs.companyInspection.name}
                            <span className="block text-[8px]">{selectedReport.signoffs.companyInspection.date}</span>
                          </div>
                        ) : (
                          'In attesa di firma'
                        )}
                      </div>
                    </div>

                    <div className="p-2 flex flex-col justify-between h-20">
                      <div className="font-bold text-neutral-800">
                        CONTROLLO Q.TA&apos;
                        <span className="block font-normal text-[9px]">Quality Control</span>
                      </div>
                      <div className="text-[9px] text-neutral-500">
                        {selectedReport.signoffs.qualityControl.signed ? (
                          <div className="font-semibold text-emerald-800">
                            F.to: {selectedReport.signoffs.qualityControl.name}
                            <span className="block text-[8px]">{selectedReport.signoffs.qualityControl.date}</span>
                          </div>
                        ) : (
                          'In attesa di firma'
                        )}
                      </div>
                    </div>

                    <div className="p-2 flex flex-col justify-between h-20">
                      <div className="font-bold text-neutral-800">
                        ENTE DI COLLAUDO
                        <span className="block font-normal text-[9px]">Inspection Agency</span>
                      </div>
                      <div className="text-[9px] text-neutral-500">
                        {selectedReport.signoffs.inspectionAgency?.signed ? (
                          <div className="font-semibold text-emerald-800">
                            F.to: {selectedReport.signoffs.inspectionAgency.name}
                            <span className="block text-[8px]">{selectedReport.signoffs.inspectionAgency.date}</span>
                          </div>
                        ) : (
                          'N.A. / Non Richiesto'
                        )}
                      </div>
                    </div>

                    <div className="p-2 flex flex-col justify-between h-20">
                      <div className="font-bold text-neutral-800">
                        ISPETTORE CLIENTE
                        <span className="block font-normal text-[9px]">Customer Inspector</span>
                      </div>
                      <div className="text-[9px] text-neutral-500">
                        {selectedReport.signoffs.customerInspector?.signed ? (
                          <div className="font-semibold text-emerald-800">
                            F.to: {selectedReport.signoffs.customerInspector.name}
                            <span className="block text-[8px]">{selectedReport.signoffs.customerInspector.date}</span>
                          </div>
                        ) : (
                          'In attesa di firma'
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Reference */}
                <div className="mt-2 text-[9px] text-neutral-400 flex justify-between font-mono">
                  <span>MOD. RV-U Rev 0 del 12/04/2013</span>
                  <span>Documento Conforme a Specifica ISO 12944 / ISO 8501-3</span>
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 bg-white border border-neutral-200 rounded-lg text-center space-y-3">
              <FileText className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="text-sm font-semibold text-neutral-900">
                Nessun Painting Report Selezionato
              </h3>
              <p className="text-xs text-neutral-500">
                Seleziona un report dalla lista a sinistra o creane uno nuovo per visualizzare la scheda ufficiale.
              </p>
              <button
                onClick={() => setViewMode('list')}
                className="px-4 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-xl"
              >
                Torna all'Elenco Report
              </button>
            </div>
          )}
        </div>
      )}

      {/* Modal Condivisione File su WhatsApp / Altre App */}
      {selectedReport && (
        <ShareFileModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          title={`Painting Report ${selectedReport.reportNumber}`}
          subtitle={`${selectedReport.client} · ${selectedReport.itemName}`}
          codeOrNumber={selectedReport.reportNumber}
          getPdfBlob={() => generateElementPdfBlob(sheetRef.current!)}
          getExcelBlob={() => generatePaintingReportExcelBlob(selectedReport)}
        />
      )}

      {/* Interactive Modal Form for Painting Report Data Collection */}
      {isFormOpen && (
        <PaintingReportFormModal
          isOpen={isFormOpen}
          initialReport={editingReport}
          onClose={() => {
            setIsFormOpen(false);
            setEditingReport(null);
          }}
          onSave={(rep) => {
            onSaveReport(rep);
            setSelectedReport(rep);
            setViewMode('detail');
            setIsFormOpen(false);
            setEditingReport(null);
          }}
        />
      )}

      {/* Google Pixel 9 Mobile Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-neutral-200 p-2 sm:hidden z-40 flex items-center justify-around gap-1 shadow-lg">
        {viewMode === 'detail' ? (
          <>
            <button
              onClick={() => setViewMode('list')}
              className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
            >
              <ArrowLeft className="w-4 h-4 mb-0.5 text-amber-600" />
              <span>← Elenco</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>Nuovo</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => handleExportExcel(selectedReport)}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-emerald-800 active:bg-emerald-50 rounded-lg"
              >
                <FileSpreadsheet className="w-4 h-4 mb-0.5" />
                <span>Excel</span>
              </button>
            )}
            {selectedReport && (
              <button
                onClick={() => handleDownloadPdf(selectedReport)}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-800 active:bg-neutral-100 rounded-lg"
              >
                <Download className="w-4 h-4 mb-0.5" />
                <span>PDF</span>
              </button>
            )}
          </>
        ) : (
          <>
            {onBackToMenu && (
              <button
                onClick={onBackToMenu}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
              >
                <Home className="w-4 h-4 mb-0.5" />
                <span>Menù</span>
              </button>
            )}
            {reports.length > 0 && (
              <button
                onClick={() => {
                  setSelectedReport(reports[0]);
                  setIsShareModalOpen(true);
                }}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>+ Nuovo</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ======================== MODAL FORM FOR PAINTING REPORT ========================

interface FormProps {
  isOpen: boolean;
  initialReport: PaintingReport | null;
  onClose: () => void;
  onSave: (report: PaintingReport) => void;
}

const PaintingReportFormModal: React.FC<FormProps> = ({
  isOpen,
  initialReport,
  onClose,
  onSave
}) => {
  if (!isOpen) return null;

  // Dati Identificativi
  const [reportNumber, setReportNumber] = useState(
    initialReport?.reportNumber || `2026/${String(Math.floor(Math.random() * 900) + 100)}/SFL`
  );
  const [date, setDate] = useState(initialReport?.date || new Date().toISOString().slice(0, 10));
  const [client, setClient] = useState(initialReport?.client || '');
  const [subSupplier, setSubSupplier] = useState(initialReport?.subSupplier || 'Sfiller Sabbiatura & Verniciatura S.r.l.');
  const [jobSerialNumber, setJobSerialNumber] = useState(initialReport?.jobSerialNumber || '');
  const [purchaseOrderNumber, setPurchaseOrderNumber] = useState(initialReport?.purchaseOrderNumber || '');
  const [itemName, setItemName] = useState(initialReport?.itemName || '');

  // Preparazione Superficiale
  const [surfacePrepStd, setSurfacePrepStd] = useState(initialReport?.surfacePreparationStd || 'ISO 8501-3');
  const [abrasiveType, setAbrasiveType] = useState(initialReport?.abrasiveTypeMesh || 'Garnet 30/60 Mesh');
  const [abrasiveContam, setAbrasiveContam] = useState(
    initialReport?.abrasiveContaminants || 'Dry, clean and free from oil, grease and other contaminants'
  );
  const [incisionProfile, setIncisionProfile] = useState(initialReport?.incisionProfile || 'MEDIUM G (50 µm)');
  const [blastCleaning, setBlastCleaning] = useState(initialReport?.blastCleaningGrade || 'S.A. 2 1/2');
  const [dustTesting, setDustTesting] = useState(initialReport?.dustTestingGrade || 'Classe 1 (ISO 8502-3)');

  // Meteo Sabbiatura
  const [prepAirTemp, setPrepAirTemp] = useState(initialReport?.surfacePrepWeather.airTemperature || 21.0);
  const [prepSurfTemp, setPrepSurfTemp] = useState(initialReport?.surfacePrepWeather.surfaceTemperature || 19.5);
  const [prepRelHum, setPrepRelHum] = useState(initialReport?.surfacePrepWeather.relativeHumidity || 45.0);

  // Calcolo automatico Dew Point per la preparazione
  const prepDewPoint = calculateDewPoint(prepAirTemp, prepRelHum);

  // Verniciatura Specifica
  const [paintingSpec, setPaintingSpec] = useState(initialReport?.paintingSpecification || 'SPEC-ISO12944-C5M');
  const [paintSystem, setPaintSystem] = useState(initialReport?.paintSystem || 'Ciclo Epossidico-Poliuretanico 3 Strati');

  // Strati (Layers)
  const defaultLayers: CoatingLayer[] = [
    {
      id: 'l-1',
      coatNumber: 1,
      coatType: '1 - PRIMER',
      requiredDftUm: 75,
      paintName: 'Jotun Barrier 80',
      batchCompA: 'LT-A-101',
      batchCompB: 'LT-B-101',
      color: 'Zinco Grigio',
      applicationMethod: 'AIRLESS',
      date: date,
      airTemp: 21.5,
      relativeHumidity: 46.0,
      surfaceTemp: 19.8,
      dewPoint: calculateDewPoint(21.5, 46.0),
      dftMeasured: { min: 70, med: 76, max: 82 },
      visualCheck: 'OK',
      dftCheck: 'OK',
      pullOffTest: 'N.A.'
    },
    {
      id: 'l-2',
      coatNumber: 2,
      coatType: '2 - INTERMEDIATE',
      requiredDftUm: 150,
      paintName: 'Jotamastic 90',
      batchCompA: 'LT-A-202',
      batchCompB: 'LT-B-202',
      color: 'Grigio Finestrante',
      applicationMethod: 'AIRLESS',
      date: date,
      airTemp: 21.5,
      relativeHumidity: 46.0,
      surfaceTemp: 19.8,
      dewPoint: calculateDewPoint(21.5, 46.0),
      dftMeasured: { min: 145, med: 155, max: 165 },
      visualCheck: 'OK',
      dftCheck: 'OK',
      pullOffTest: 'N.A.'
    },
    {
      id: 'l-3',
      coatNumber: 3,
      coatType: '4 - FINISH',
      requiredDftUm: 60,
      paintName: 'Hardtop AX',
      batchCompA: 'LT-A-303',
      batchCompB: 'LT-B-303',
      color: 'RAL a scelta cliente',
      applicationMethod: 'AIRLESS',
      date: date,
      airTemp: 22.0,
      relativeHumidity: 45.0,
      surfaceTemp: 20.2,
      dewPoint: calculateDewPoint(22.0, 45.0),
      dftMeasured: { min: 58, med: 65, max: 72 },
      visualCheck: 'OK',
      dftCheck: 'OK',
      pullOffTest: '> 5 MPa - OK'
    }
  ];

  const [layers, setLayers] = useState<CoatingLayer[]>(initialReport?.layers || defaultLayers);

  // Note strumenti
  const [instrumentNotes, setInstrumentNotes] = useState(
    initialReport?.instrumentNotes ||
      'Spessimetro PosiTector 6000 - Matricola 762963 - Sonda FS 234341 - Scadenza Certificato: 29/08/2027\nTemperatura PosiTector DPM - Matricola 762963 - Sonda 240387 - Scadenza Certificato: 04/09/2027\nRugosimetro PosiTector SPG - Matricola 882190'
  );
  const [generalRemarks, setGeneralRemarks] = useState(initialReport?.generalRemarks || '');

  // Immagini
  const [images, setImages] = useState<PaintingReportImage[]>(initialReport?.images || []);
  const [isProcessingImg, setIsProcessingImg] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLayerChange = (index: number, updated: Partial<CoatingLayer>) => {
    setLayers(
      layers.map((l, idx) => {
        if (idx !== index) return l;
        const newLayer = { ...l, ...updated };
        if (updated.airTemp !== undefined || updated.relativeHumidity !== undefined) {
          newLayer.dewPoint = calculateDewPoint(newLayer.airTemp, newLayer.relativeHumidity);
        }
        return newLayer;
      })
    );
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessingImg(true);
    try {
      const newImgs: PaintingReportImage[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith('image/')) continue;
        const comp = await compressImage(file, 1600, 1600, 0.85);
        newImgs.push({
          id: `pimg-${Date.now()}-${i}`,
          url: comp.dataUrl,
          caption: '',
          stage: 'Preparazione Superficiale SA 2.5',
          uploadedAt: new Date().toISOString(),
          fileName: comp.originalName
        });
      }
      setImages((prev) => [...prev, ...newImgs]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessingImg(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const report: PaintingReport = {
      id: initialReport?.id || `paint-rep-${Date.now()}`,
      reportNumber,
      date,
      documentRev: initialReport?.documentRev || 'MOD. RV-U Rev 0 del 12/04/2013',
      client: client.trim(),
      subSupplier: subSupplier.trim(),
      jobSerialNumber: jobSerialNumber.trim(),
      purchaseOrderNumber: purchaseOrderNumber.trim(),
      itemName: itemName.trim(),
      surfacePreparationStd: surfacePrepStd,
      abrasiveTypeMesh: abrasiveType,
      abrasiveContaminants: abrasiveContam,
      incisionProfile,
      blastCleaningGrade: blastCleaning,
      dustTestingGrade: dustTesting,
      surfacePrepWeather: {
        date,
        airTemperature: prepAirTemp,
        surfaceTemperature: prepSurfTemp,
        relativeHumidity: prepRelHum,
        dewPoint: prepDewPoint,
        isDeltaOk: prepSurfTemp >= prepDewPoint + 3.0,
        statusText: prepSurfTemp >= prepDewPoint + 3.0 ? 'OK' : 'NON CONFORME (Rischio Condensa)'
      },
      paintingSpecification: paintingSpec,
      paintSystem,
      layers,
      instrumentNotes,
      generalRemarks,
      signoffs: initialReport?.signoffs || {
        companyInspection: {
          name: 'M. Preato (Responsabile Sabbiatura e Verniciatura)',
          date,
          signed: true
        },
        qualityControl: {
          name: 'Controllo Qualità Sfiller',
          date,
          signed: true
        }
      },
      images,
      createdAt: initialReport?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(report);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-neutral-300 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden my-auto text-xs">
        {/* Header */}
        <div className="px-6 py-3.5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50 shrink-0">
          <div>
            <h2 className="text-sm font-bold text-neutral-900">
              {initialReport ? 'Modifica Painting Report' : 'Compilazione Nuovo Painting Report (MOD. RV-U)'}
            </h2>
            <p className="text-[11px] text-neutral-500">
              Modulo interattivo con calcolo psicrometrico automatico del punto di rugiada ed esportazione Excel/PDF
            </p>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-700 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section 1: Dati Identificativi */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <h3 className="font-bold text-neutral-900 uppercase text-[11px] pb-1 border-b border-neutral-100 flex items-center justify-between">
              <span>1. Dati Identificativi (Identification Data)</span>
              <span className="text-neutral-400 font-mono text-[10px]">Header Documento</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Painting Report No. *
                </label>
                <input
                  type="text"
                  required
                  value={reportNumber}
                  onChange={(e) => setReportNumber(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Data Compilazione
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Subfornitore / Sub-supplier
                </label>
                <input
                  type="text"
                  value={subSupplier}
                  onChange={(e) => setSubSupplier(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Cliente / Client *
                </label>
                <input
                  type="text"
                  required
                  value={client}
                  onChange={(e) => setClient(e.target.value)}
                  placeholder="es. Gruppo Meccanico Nord S.p.A."
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Commessa - Matricola *
                </label>
                <input
                  type="text"
                  required
                  value={jobSerialNumber}
                  onChange={(e) => setJobSerialNumber(e.target.value)}
                  placeholder="COMM-8821 / Mat. 049"
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  N. Ordine - Posizione
                </label>
                <input
                  type="text"
                  value={purchaseOrderNumber}
                  onChange={(e) => setPurchaseOrderNumber(e.target.value)}
                  placeholder="PO-2026-09 / Pos. 1"
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-neutral-700 mb-1">
                  Denominazione Item / Oggetto Lavorato *
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="es. Tubazioni in pressione DN 400 - Telai di carpenteria"
                  className="w-full px-2.5 py-1.5 border border-neutral-300 rounded"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Preparazione Superficiale */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <h3 className="font-bold text-neutral-900 uppercase text-[11px] pb-1 border-b border-neutral-100 flex items-center justify-between">
              <span>2. Preparazione Superficiale (Surface Preparation)</span>
              <span className="text-amber-700 font-semibold text-[10px]">ISO 8501-3 · SA 2.5</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Prep. Superficiale
                </label>
                <input
                  type="text"
                  value={surfacePrepStd}
                  onChange={(e) => setSurfacePrepStd(e.target.value)}
                  className="w-full px-2 py-1 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Tipo Abrasivo / Mesh
                </label>
                <input
                  type="text"
                  value={abrasiveType}
                  onChange={(e) => setAbrasiveType(e.target.value)}
                  className="w-full px-2 py-1 border border-neutral-300 rounded"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Rugosità / Incision Profile
                </label>
                <input
                  type="text"
                  value={incisionProfile}
                  onChange={(e) => setIncisionProfile(e.target.value)}
                  placeholder="MEDIUM G (50 µm)"
                  className="w-full px-2 py-1 border border-neutral-300 rounded font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Pulizia Superficiale / Blast Cleaning
                </label>
                <select
                  value={blastCleaning}
                  onChange={(e) => setBlastCleaning(e.target.value)}
                  className="w-full px-2 py-1 border border-neutral-300 rounded font-mono font-bold"
                >
                  <option value="S.A. 2 1/2">S.A. 2 1/2 (Near-White Metal)</option>
                  <option value="S.A. 3">S.A. 3 (White Metal)</option>
                  <option value="S.A. 2">S.A. 2 (Commercial)</option>
                  <option value="S.A. 1">S.A. 1 (Light Blast)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Contaminazione Polvere / Dust Testing
                </label>
                <input
                  type="text"
                  value={dustTesting}
                  onChange={(e) => setDustTesting(e.target.value)}
                  className="w-full px-2 py-1 border border-neutral-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                  Contaminazioni Abrasivo
                </label>
                <input
                  type="text"
                  value={abrasiveContam}
                  onChange={(e) => setAbrasiveContam(e.target.value)}
                  className="w-full px-2 py-1 border border-neutral-300 rounded"
                />
              </div>
            </div>

            {/* Condizioni Ambiente Sabbiatura con Punto di Rugiada Calcolato */}
            <div className="mt-3 p-3 bg-amber-50/70 border border-amber-200 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-amber-900">
                <span className="flex items-center gap-1.5">
                  <Thermometer className="w-3.5 h-3.5 text-amber-700" />
                  Condizioni Ambiente Sabbiatura
                </span>
                <span className="font-mono text-emerald-800">
                  Punto di Rugiada Calcolato: {prepDewPoint} °C
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] text-neutral-600">Temp. Aria (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={prepAirTemp}
                    onChange={(e) => setPrepAirTemp(Number(e.target.value))}
                    className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-600">Umidità Relativa (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={prepRelHum}
                    onChange={(e) => setPrepRelHum(Number(e.target.value))}
                    className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-600">Temp. Superficie (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={prepSurfTemp}
                    onChange={(e) => setPrepSurfTemp(Number(e.target.value))}
                    className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono tabular-nums"
                  />
                </div>
              </div>

              <div className="text-[10px] text-neutral-600 pt-1 border-t border-amber-200 flex justify-between">
                <span>ΔT (Superficie - Dew Point): <strong>{Math.round((prepSurfTemp - prepDewPoint) * 10) / 10} °C</strong></span>
                {prepSurfTemp >= prepDewPoint + 3.0 ? (
                  <span className="text-emerald-700 font-bold">OK · Conformità Superata (ΔT ≥ 3°C)</span>
                ) : (
                  <span className="text-rose-700 font-bold">ATTENZIONE: Rischio Condensa (ΔT &lt; 3°C)</span>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: Ciclo di Verniciatura e Strati */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-neutral-100 gap-2">
              <div>
                <h3 className="font-bold text-neutral-900 uppercase text-[11px]">
                  3. Specifica di Verniciatura & Ciclo Strati (Coating Layers)
                </h3>
                <p className="text-[10px] text-neutral-500">
                  Inserisci i parametri per ogni strato. Il punto di rugiada viene ricalcolato in tempo reale.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Specifica (es. C5M)"
                  value={paintingSpec}
                  onChange={(e) => setPaintingSpec(e.target.value)}
                  className="px-2 py-1 border border-neutral-300 rounded font-mono text-[11px]"
                />
                <input
                  type="text"
                  placeholder="Ciclo (es. Epossi-Poliuretano)"
                  value={paintSystem}
                  onChange={(e) => setPaintSystem(e.target.value)}
                  className="px-2 py-1 border border-neutral-300 rounded font-mono text-[11px]"
                />
              </div>
            </div>

            {/* Layer Cards */}
            <div className="space-y-4">
              {layers.map((layer, idx) => {
                const deltaT = Math.round((layer.surfaceTemp - layer.dewPoint) * 10) / 10;
                return (
                  <div key={layer.id} className="border border-neutral-200 rounded-lg p-3 bg-neutral-50/60 space-y-3">
                    <div className="flex items-center justify-between bg-neutral-200 px-2.5 py-1 rounded">
                      <span className="font-bold text-neutral-900 text-[11px]">
                        {layer.coatType}
                      </span>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="text-neutral-600">REQ&apos;D DFT (µm):</span>
                        <input
                          type="number"
                          value={layer.requiredDftUm}
                          onChange={(e) => handleLayerChange(idx, { requiredDftUm: Number(e.target.value) })}
                          className="w-16 px-1.5 py-0.5 bg-white border border-neutral-300 rounded font-mono font-bold text-center"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Nome Prodotto</label>
                        <input
                          type="text"
                          value={layer.paintName}
                          onChange={(e) => handleLayerChange(idx, { paintName: e.target.value })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Lotto Comp. A</label>
                        <input
                          type="text"
                          value={layer.batchCompA}
                          onChange={(e) => handleLayerChange(idx, { batchCompA: e.target.value })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Lotto Comp. B</label>
                        <input
                          type="text"
                          value={layer.batchCompB}
                          onChange={(e) => handleLayerChange(idx, { batchCompB: e.target.value })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Colore</label>
                        <input
                          type="text"
                          value={layer.color}
                          onChange={(e) => handleLayerChange(idx, { color: e.target.value })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Metodo Applicazione</label>
                        <select
                          value={layer.applicationMethod}
                          onChange={(e) => handleLayerChange(idx, { applicationMethod: e.target.value as any })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono"
                        >
                          <option value="AIRLESS">AIRLESS</option>
                          <option value="Misto Aria / Airmix">Misto Aria / Airmix</option>
                          <option value="Tazza a Gravità">Tazza a Gravità</option>
                          <option value="Rullo / Pennello">Rullo / Pennello</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Data Applicazione</label>
                        <input
                          type="date"
                          value={layer.date}
                          onChange={(e) => handleLayerChange(idx, { date: e.target.value })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">Esame Visivo</label>
                        <select
                          value={layer.visualCheck}
                          onChange={(e) => handleLayerChange(idx, { visualCheck: e.target.value as any })}
                          className="w-full px-2 py-1 bg-white border border-neutral-300 rounded font-bold"
                        >
                          <option value="OK">OK</option>
                          <option value="KO">KO</option>
                          <option value="N.A.">N.A.</option>
                        </select>
                      </div>
                    </div>

                    {/* Rilievo Ambientale e Spessori DFT */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-neutral-200">
                      {/* Parametri Meteo Layer */}
                      <div className="bg-white p-2.5 rounded border border-neutral-200 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-bold text-neutral-700">
                          <span>Parametri Meteo Applicazione</span>
                          <span className="font-mono text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                            Dew Point: {layer.dewPoint} °C
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-[10px]">
                          <div>
                            <span className="text-neutral-500">T. Aria °C</span>
                            <input
                              type="number"
                              step="0.1"
                              value={layer.airTemp}
                              onChange={(e) => handleLayerChange(idx, { airTemp: Number(e.target.value) })}
                              className="w-full px-1.5 py-0.5 border border-neutral-300 rounded font-mono"
                            />
                          </div>
                          <div>
                            <span className="text-neutral-500">UR %</span>
                            <input
                              type="number"
                              step="0.1"
                              value={layer.relativeHumidity}
                              onChange={(e) => handleLayerChange(idx, { relativeHumidity: Number(e.target.value) })}
                              className="w-full px-1.5 py-0.5 border border-neutral-300 rounded font-mono"
                            />
                          </div>
                          <div>
                            <span className="text-neutral-500">T. Sup °C</span>
                            <input
                              type="number"
                              step="0.1"
                              value={layer.surfaceTemp}
                              onChange={(e) => handleLayerChange(idx, { surfaceTemp: Number(e.target.value) })}
                              className="w-full px-1.5 py-0.5 border border-neutral-300 rounded font-mono"
                            />
                          </div>
                        </div>
                        <div className="text-[9px] text-neutral-500">
                          ΔT: {deltaT}°C · {deltaT >= 3.0 ? <span className="text-emerald-700 font-bold">Idoneo (≥ 3°C)</span> : <span className="text-rose-700 font-bold">Attenzione condensa</span>}
                        </div>
                      </div>

                      {/* Spessori DFT Layer */}
                      <div className="bg-white p-2.5 rounded border border-neutral-200 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-bold text-neutral-700">
                          <span>Rilevamento Spessore Film Secco (DFT µm)</span>
                          <span className="text-[9px] text-neutral-400">PosiTector 6000</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-[10px]">
                          <div>
                            <span className="text-neutral-500">Min µm</span>
                            <input
                              type="number"
                              value={layer.dftMeasured.min}
                              onChange={(e) =>
                                handleLayerChange(idx, {
                                  dftMeasured: { ...layer.dftMeasured, min: Number(e.target.value) }
                                })
                              }
                              className="w-full px-1.5 py-0.5 border border-neutral-300 rounded font-mono text-center"
                            />
                          </div>
                          <div>
                            <span className="text-neutral-500 font-bold">Med µm *</span>
                            <input
                              type="number"
                              value={layer.dftMeasured.med}
                              onChange={(e) =>
                                handleLayerChange(idx, {
                                  dftMeasured: { ...layer.dftMeasured, med: Number(e.target.value) }
                                })
                              }
                              className="w-full px-1.5 py-0.5 border border-neutral-900 rounded font-mono font-bold text-center bg-amber-50"
                            />
                          </div>
                          <div>
                            <span className="text-neutral-500">Max µm</span>
                            <input
                              type="number"
                              value={layer.dftMeasured.max}
                              onChange={(e) =>
                                handleLayerChange(idx, {
                                  dftMeasured: { ...layer.dftMeasured, max: Number(e.target.value) }
                                })
                              }
                              className="w-full px-1.5 py-0.5 border border-neutral-300 rounded font-mono text-center"
                            />
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-neutral-500 pt-0.5">
                          <span>Esito DFT: <strong>{layer.dftCheck}</strong></span>
                          <span>Prova Adesione: <strong>{layer.pullOffTest}</strong></span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 4: Documentazione Fotografica Specifica */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-neutral-100">
              <h3 className="font-bold text-neutral-900 uppercase text-[11px] flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-neutral-700" />
                <span>4. Fotografie di Lavorazione & Controlli ({images.length})</span>
              </h3>
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e.target.files)}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingImg}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Carica Foto Sabbiatura / Verniciatura</span>
                </button>
              </div>
            </div>

            {images.length === 0 ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-neutral-200 hover:border-neutral-400 rounded-lg p-6 text-center cursor-pointer bg-neutral-50/50"
              >
                <Camera className="w-7 h-7 text-neutral-400 mx-auto mb-1" />
                <div className="text-xs font-medium text-neutral-700">
                  Carica foto sabbiatura SA 2.5, rugosità, strati applicati e test spessore DFT
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {images.map((img, i) => (
                  <div key={img.id} className="p-2 border border-neutral-200 rounded-lg bg-neutral-50 flex gap-2">
                    <img
                      src={img.url}
                      alt={img.caption}
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 object-cover rounded shrink-0 border border-neutral-300"
                    />
                    <div className="flex-1 space-y-1.5">
                      <div className="flex justify-between items-center">
                        <select
                          value={img.stage}
                          onChange={(e) =>
                            setImages(
                              images.map((m, idx) => (idx === i ? { ...m, stage: e.target.value as any } : m))
                            )
                          }
                          className="px-1.5 py-0.5 text-[10px] bg-white border border-neutral-300 rounded font-semibold"
                        >
                          <option value="Preparazione Superficiale SA 2.5">Preparazione SA 2.5</option>
                          <option value="Profilo Rugosità">Profilo Rugosità</option>
                          <option value="Primer">Primer</option>
                          <option value="Intermedio">Intermedio</option>
                          <option value="Finitura">Finitura</option>
                          <option value="Controllo DFT / Collaudo">Controllo DFT / Collaudo</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                          className="text-neutral-400 hover:text-rose-600 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <input
                        type="text"
                        placeholder="Didascalia foto..."
                        value={img.caption}
                        onChange={(e) =>
                          setImages(
                            images.map((m, idx) => (idx === i ? { ...m, caption: e.target.value } : m))
                          )
                        }
                        className="w-full px-2 py-1 text-[11px] bg-white border border-neutral-300 rounded"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 5: Note Strumenti Tarati & Osservazioni */}
          <div className="border border-neutral-200 rounded-lg p-4 bg-white space-y-3">
            <h3 className="font-bold text-neutral-900 uppercase text-[11px] pb-1 border-b border-neutral-100">
              5. Strumenti Utilizzati & Note Operative
            </h3>
            <div>
              <label className="block text-[10px] font-medium text-neutral-600 mb-1">
                Matricole e Certificati Strumenti di Misura (Spessimetri, Sonde DPM, Rugosimetri)
              </label>
              <textarea
                rows={3}
                value={instrumentNotes}
                onChange={(e) => setInstrumentNotes(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-neutral-300 rounded font-mono text-[11px]"
              />
            </div>
            <div>
              <label className="block text-[10px] font-medium text-neutral-600 mb-1">
                Osservazioni Generali e Collaudo Finale
              </label>
              <textarea
                rows={2}
                value={generalRemarks}
                onChange={(e) => setGeneralRemarks(e.target.value)}
                placeholder="Trattamento conforme alle prescrizioni. Assenza di difetti..."
                className="w-full px-2.5 py-1.5 border border-neutral-300 rounded text-[11px]"
              />
            </div>
          </div>

          {/* Footer Submit */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50"
            >
              Annulla
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>Salva Painting Report</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
