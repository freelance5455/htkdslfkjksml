import PoliceIcon from './PoliceIcon';

interface PoliceHomeProps {
  onNavigate: (id: string) => void;
}

const quickLinks = [
  { id: 'beginner-guide', title: 'New Officer Guide', description: 'Start here for duty basics, incident flow and decision making.', icon: 'guide' },
  { id: 'state-codes', title: 'State Codes (0-16)', description: 'Every unit status code with rules, radio use and State 0 procedure.', icon: 'radio' },
  { id: 'pace-caution', title: 'PACE Caution', description: 'Correct UK wording, restricted caution and jurisdiction differences.', icon: 'scales' },
  { id: 'arrest-procedure', title: 'Arrest Procedure', description: 'Grounds, Code G necessity, caution, search, PTV transport and custody.', icon: 'clipboard' },
  { id: 'stop-search', title: 'Stop and Search', description: 'Powers, objective grounds, GOWISELY and recording.', icon: 'search' },
  { id: 'bwv', title: 'Body-Worn Video', description: 'Activation, announcement, privacy, retention and evidence.', icon: 'camera' },
  { id: 'common-phrases', title: 'Common Phrases', description: 'Introductions, arrests, searches and custody wording.', icon: 'document' },
  { id: 'force-directory', title: 'UK Force Directory', description: 'Every territorial force plus national special police forces.', icon: 'forces' },
];

const PoliceHome = ({ onNavigate }: PoliceHomeProps) => (
  <div className="police-home">
    <section className="home-hero">
      <div className="home-hero-copy">
        <div className="home-kicker">PROFESSIONAL ROLEPLAY REFERENCE</div>
        <h1>UK Police<br />Knowledge Base</h1>
        <p>A structured guide to police powers, arrest procedure, policy, equipment, incident response and professional standards across the United Kingdom.</p>
        <div className="home-actions">
          <button className="primary-action" onClick={() => onNavigate('beginner-guide')}>Start the officer guide</button>
          <button className="secondary-action" onClick={() => onNavigate('quick-reference')}>Open printable reference</button>
        </div>
      </div>
      <div className="home-hero-mark" aria-hidden="true">
        <PoliceIcon name="shield" className="h-52 w-52" />
        <span>LAW</span>
        <span>PROCEDURE</span>
        <span>ACCOUNTABILITY</span>
      </div>
    </section>

    <section className="home-alert">
      <PoliceIcon name="warning" className="h-6 w-6" />
      <div>
        <strong>UK terminology:</strong> UK policing does not use US “Miranda rights”. England and Wales use the PACE caution. Scotland and Northern Ireland follow their own legal frameworks.
      </div>
    </section>

    <section className="home-section">
      <div className="home-section-heading">
        <div><span>01</span><h2>Essential references</h2></div>
        <p>Open a focused page rather than reading one continuous manual.</p>
      </div>
      <div className="quick-link-grid">
        {quickLinks.map((item) => (
          <button key={item.id} className="quick-link" onClick={() => onNavigate(item.id)}>
            <PoliceIcon name={item.icon} className="h-7 w-7" />
            <div><h3>{item.title}</h3><p>{item.description}</p></div>
            <PoliceIcon name="chevron" className="h-5 w-5" />
          </button>
        ))}
      </div>
    </section>

    <section className="home-section home-learning-path">
      <div className="home-section-heading">
        <div><span>02</span><h2>Recommended learning path</h2></div>
        <p>Build legal and procedural knowledge in this order.</p>
      </div>
      <div className="learning-steps">
        {[
          ['1', 'Foundation', 'Jurisdictions, ranks, start of duty and radio.'],
          ['2', 'Core powers', 'Caution, arrest, stop/search, entry and use of force.'],
          ['3', 'Procedure', 'Incident response, scenes, evidence and custody.'],
          ['4', 'Scenarios', 'Missing people, domestic abuse, mental health, collisions and crime.'],
          ['5', 'Accountability', 'BWV, ethics, information handling and force records.'],
        ].map(([number, title, text]) => (
          <div className="learning-step" key={number}>
            <span>{number}</span><h3>{title}</h3><p>{text}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="home-footer-note">
      <PoliceIcon name="info" className="h-7 w-7" />
      <div><strong>Training and roleplay use.</strong><p>Real-world decisions must use current legislation, College of Policing guidance, authorised professional practice and local force policy.</p></div>
    </section>
  </div>
);

export default PoliceHome;