import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Shield, Swords } from 'lucide-react';
import { ClanDashboardState } from '../shared/cocData';
import { formatCountdown, formatDateTimeRu } from '../utils/formatters';
import { CwlView } from './CwlView';

interface WarsViewProps {
  state: ClanDashboardState;
  nowMs: number;
  initialMode?: 'regular' | 'cwl';
  onSelectPlayer: (tag: string) => void;
}

const WAR_STATUS_RU: Record<string, string> = {
  preparation: 'День подготовки',
  inWar: 'Боевой день',
  warEnded: 'Война завершена',
  notInWar: 'Клан не в войне',
};

export const WarsView: React.FC<WarsViewProps> = ({
  state,
  nowMs,
  initialMode = 'regular',
  onSelectPlayer,
}) => {
  const [mode, setMode] = useState<'regular' | 'cwl'>(initialMode);
  const [attackFilter, setAttackFilter] = useState<'all' | 'attacked' | 'not_attacked'>('all');

  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  const cw = state.currentWar;
  const isInActiveWar = Boolean(cw && cw.state !== 'notInWar');

  const warMembersRating = useMemo(() => {
    if (!cw || cw.state === 'notInWar') return [];
    const maxAtks = cw.attacksPerMember || 2;
    return cw.clan.members
      .map((m) => {
        const used = m.attacks.length;
        const stars = m.attacks.reduce((s, a) => s + a.stars, 0);
        const threeStars = m.attacks.filter((a) => a.stars === 3).length;
        const avgDest =
          used > 0
            ? Number((m.attacks.reduce((s, a) => s + a.destructionPercentage, 0) / used).toFixed(1))
            : 0;
        const efficiency = used > 0 ? Number(((stars / (used * 3)) * 100).toFixed(0)) : 0;
        const warRating = Math.round(stars * 100 + avgDest * 1.5 + threeStars * 40 - Math.max(0, maxAtks - used) * 30);
        return {
          ...m,
          used,
          remaining: Math.max(0, maxAtks - used),
          stars,
          threeStars,
          avgDest,
          efficiency,
          warRating,
        };
      })
      .filter((m) => {
        if (attackFilter === 'attacked') return m.used > 0;
        if (attackFilter === 'not_attacked') return m.remaining > 0;
        return true;
      })
      .sort((a, b) => b.stars - a.stars || b.avgDest - a.avgDest || a.mapPosition - b.mapPosition);
  }, [cw, attackFilter]);

  const warLogSummary = useMemo(() => {
    const total = state.wars.length;
    const wins = state.wars.filter((w) => w.result === 'win').length;
    const losses = state.wars.filter((w) => w.result === 'loss').length;
    const draws = state.wars.filter((w) => w.result === 'draw').length;
    const attacksUsed = state.wars.reduce((s, w) => s + w.attacksUsed, 0);
    const maxAttacks = state.wars.reduce((s, w) => s + w.maxAttacks, 0);
    const missedAttacks = Math.max(0, maxAttacks - attacksUsed);
    const avgDest =
      total > 0
        ? Number((state.wars.reduce((s, w) => s + w.clanDestruction, 0) / total).toFixed(1))
        : 0;
    const totalStars = state.wars.reduce((s, w) => s + w.clanStars, 0);
    const maxStars = state.wars.reduce((s, w) => s + w.maxStars, 0);
    const starSuccessPct = maxStars > 0 ? Number(((totalStars / maxStars) * 100).toFixed(1)) : 0;
    return { total, wins, losses, draws, attacksUsed, maxAttacks, missedAttacks, avgDest, starSuccessPct };
  }, [state.wars]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы загрузить текущую войну, журнал КВ и данные CWL.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Войны и CWL
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Обычные клановые войны и Лига Войн Кланов (CWL) отображаются строго раздельно
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start lg:self-auto">
          <button
            type="button"
            onClick={() => setMode('regular')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              mode === 'regular'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Обычные войны и журнал КВ
          </button>
          <button
            type="button"
            onClick={() => setMode('cwl')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              mode === 'cwl'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Clan War League (CWL)
          </button>
        </div>
      </section>

      {mode === 'cwl' ? (
        <CwlView state={state} onSelectPlayer={onSelectPlayer} embedded />
      ) : (
        <div className="space-y-6">
          {/* War Summary KPIs (Regular Wars Only) */}
          {warLogSummary.total > 0 && (
            <section className="grid grid-cols-2 gap-4 lg:grid-cols-5">
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
                <div className="text-xs text-slate-400">Журнал КВ (В / П / Н)</div>
                <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-slate-100">
                  <span className="text-emerald-400">{warLogSummary.wins}</span> /{' '}
                  <span className="text-rose-400">{warLogSummary.losses}</span> /{' '}
                  <span className="text-amber-400">{warLogSummary.draws}</span>
                </div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
                <div className="text-xs text-slate-400">Успешность (звёзды)</div>
                <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-amber-400">
                  {warLogSummary.starSuccessPct.toFixed(1)}%
                </div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
                <div className="text-xs text-slate-400">Ср. разрушение в КВ</div>
                <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-sky-400">
                  {warLogSummary.avgDest.toFixed(1)}%
                </div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
                <div className="text-xs text-slate-400">Использовано атак</div>
                <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-emerald-400">
                  {warLogSummary.attacksUsed} / {warLogSummary.maxAttacks}
                </div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
                <div className="text-xs text-slate-400">Пропущено атак</div>
                <div className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-rose-400">
                  {warLogSummary.missedAttacks}
                </div>
              </div>
            </section>
          )}

          {/* Current War Section */}
          {isInActiveWar && cw ? (
            <div className="space-y-6">
              <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-2.5 text-sm font-semibold text-amber-400">
                    <Swords className="h-4 w-4" />
                    <span>{WAR_STATUS_RU[cw.state] ?? cw.state}</span>
                    <span className="text-slate-500">·</span>
                    <span className="font-mono text-slate-200">{cw.teamSize}×{cw.teamSize}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 font-mono tabular-nums">
                    {cw.startTime && <span>Начало: {formatDateTimeRu(cw.startTime)}</span>}
                    {cw.endTime && (
                      <span>
                        Окончание: {formatDateTimeRu(cw.endTime)}
                        {(cw.state === 'inWar' || cw.state === 'preparation') && (
                          <strong className="ml-2 text-amber-400">
                            ({formatCountdown(cw.endTime, nowMs)})
                          </strong>
                        )}
                      </span>
                    )}
                  </div>
                </div>

                {/* Scoreboard */}
                <div className="grid grid-cols-1 gap-4 md:grid-cols-3 items-center">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 shrink-0 rounded-lg border border-slate-800 bg-[#0B0F17] flex items-center justify-center overflow-hidden">
                      {cw.clan.badgeUrl ? (
                        <img
                          src={cw.clan.badgeUrl}
                          alt={cw.clan.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <Shield className="h-5 w-5 text-amber-400" />
                      )}
                    </div>
                    <div>
                      <div className="text-base font-bold text-slate-100">{cw.clan.name}</div>
                      <div className="font-mono text-xs text-slate-400">
                        {cw.clan.tag} · Ур. {cw.clan.clanLevel}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center rounded-lg border border-slate-800 bg-[#0B0F17] py-3 px-4">
                    <div className="font-mono text-2xl font-bold tabular-nums text-amber-400">
                      {cw.clan.stars} : {cw.opponent.stars}
                    </div>
                    <div className="mt-1 font-mono text-xs tabular-nums text-slate-300">
                      {cw.clan.destructionPercentage.toFixed(1)}% vs {cw.opponent.destructionPercentage.toFixed(1)}%
                    </div>
                    <div className="mt-1 font-mono text-[11px] text-slate-500 tabular-nums">
                      Атаки: {cw.clan.attacks}/{cw.teamSize * cw.attacksPerMember} vs {cw.opponent.attacks}/{cw.teamSize * cw.attacksPerMember}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 md:justify-end">
                    <div className="md:text-right">
                      <div className="text-base font-bold text-slate-100">{cw.opponent.name}</div>
                      <div className="font-mono text-xs text-slate-400">
                        {cw.opponent.tag} · Ур. {cw.opponent.clanLevel}
                      </div>
                    </div>
                    <div className="h-12 w-12 shrink-0 rounded-lg border border-slate-800 bg-[#0B0F17] flex items-center justify-center overflow-hidden">
                      {cw.opponent.badgeUrl ? (
                        <img
                          src={cw.opponent.badgeUrl}
                          alt={cw.opponent.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <Shield className="h-5 w-5 text-slate-500" />
                      )}
                    </div>
                  </div>
                </div>
              </section>

              {/* War Participants Rating */}
              <section className="rounded-lg border border-slate-800 bg-[#121824]">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-4">
                  <div>
                    <h2 className="font-display text-base font-semibold text-slate-100">
                      Рейтинг участников текущей войны ({cw.clan.members.length})
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-400">
                      Использованные и пропущенные атаки, звёзды, разрушение и эффективность
                    </p>
                  </div>
                  <div className="flex items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
                    {(
                      [
                        { id: 'all', label: 'Все' },
                        { id: 'attacked', label: 'Атаковали' },
                        { id: 'not_attacked', label: 'Недобор атак' },
                      ] as const
                    ).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setAttackFilter(f.id)}
                        className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap ${
                          attackFilter === f.id
                            ? 'bg-amber-500 text-slate-950 font-semibold'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs sm:text-sm">
                    <thead>
                      <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                        <th className="px-4 py-2.5">#</th>
                        <th className="px-4 py-2.5">Участник</th>
                        <th className="px-3 py-2.5 text-right">TH</th>
                        <th className="px-3 py-2.5 text-right">Атаки</th>
                        <th className="px-3 py-2.5 text-right">
                          {cw.state === 'warEnded' ? 'Пропущ.' : 'Осталось'}
                        </th>
                        <th className="px-3 py-2.5 text-right">Звёзды</th>
                        <th className="px-3 py-2.5 text-right">3★</th>
                        <th className="px-3 py-2.5 text-right">Ср. разруш.</th>
                        <th className="px-3 py-2.5 text-right">Успех</th>
                        <th className="px-4 py-2.5">Детали атак</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {warMembersRating.map((m) => (
                        <tr
                          key={m.tag}
                          onClick={() => onSelectPlayer(m.tag)}
                          className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                        >
                          <td className="px-4 py-2.5 font-mono text-xs tabular-nums text-slate-500">
                            {m.mapPosition}
                          </td>
                          <td className="px-4 py-2.5 whitespace-nowrap">
                            <div className="font-medium text-slate-100">{m.name}</div>
                            <div className="font-mono text-[11px] text-slate-500">{m.tag}</div>
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                            {m.townHallLevel}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                            <span className={m.remaining > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                              {m.used}/{cw.attacksPerMember}
                            </span>
                          </td>
                          <td
                            className={`px-3 py-2.5 text-right font-mono tabular-nums ${
                              m.remaining > 0 ? 'text-rose-400 font-semibold' : 'text-slate-500'
                            }`}
                          >
                            {m.remaining}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                            {m.stars}★
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                            {m.threeStars}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                            {m.avgDest.toFixed(1)}%
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                            {m.used > 0 ? `${m.efficiency}%` : '—'}
                          </td>
                          <td className="px-4 py-2.5 text-xs text-slate-300">
                            {m.attacks.length > 0 ? (
                              <div className="space-y-0.5 font-mono">
                                {m.attacks.map((a, idx) => (
                                  <div key={idx}>
                                    {a.stars}★ ({a.destructionPercentage}%) → {a.defenderName ?? a.defenderTag}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <span className="text-rose-400">Ещё не атаковал</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          ) : (
            <section className="rounded-lg border border-slate-800 bg-[#121824] p-6 text-sm text-slate-300">
              {state.clan.isWarLogPublic === false ? (
                <div className="flex items-start gap-3 text-amber-300">
                  <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">Текущая война скрыта или недоступна</div>
                    <p className="mt-1 text-xs text-slate-400">
                      У клана {state.clan.name} отключён публичный журнал войн, поэтому Supercell API ограничивает доступ к деталям текущей войны.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-slate-400">
                  Сейчас клан {state.clan.name} не участвует в обычной клановой войне (для Лиги Войн Кланов переключите вкладку выше на «Clan War League (CWL)»).
                </div>
              )}
            </section>
          )}

          {/* War Log Section */}
          <section className="rounded-lg border border-slate-800 bg-[#121824]">
            <div className="border-b border-slate-800 px-5 py-4">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Журнал клановых войн ({state.wars.length})
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                История завершённых обычных войн из <span className="font-mono">GET /warlog</span>
              </p>
            </div>

            {state.clan.isWarLogPublic === false ? (
              <div className="flex items-start gap-3 p-6 text-xs text-amber-200">
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-amber-400" />
                <div>
                  Журнал войн закрыт настройками приватности клана (<span className="font-mono">isWarLogPublic = false</span>).
                  Чтобы видеть историю войн, лидер клана должен открыть журнал войн в настройках игры.
                </div>
              </div>
            ) : state.wars.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                Записей в журнале войн не найдено.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                      <th className="px-5 py-2.5">Окончание</th>
                      <th className="px-3 py-2.5">Противник</th>
                      <th className="px-3 py-2.5 text-right">Размер</th>
                      <th className="px-3 py-2.5 text-right">Звёзды</th>
                      <th className="px-3 py-2.5 text-right">Разрушение</th>
                      <th className="px-3 py-2.5 text-right">Атаки</th>
                      <th className="px-3 py-2.5 text-right">Пропущ.</th>
                      <th className="px-5 py-2.5 text-right">Результат</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {[...state.wars].reverse().map((w) => {
                      const missed = Math.max(0, w.maxAttacks - w.attacksUsed);
                      return (
                        <tr key={w.id} className="hover:bg-slate-800/25 transition-colors">
                          <td className="px-5 py-2.5 font-mono text-xs text-slate-400 whitespace-nowrap">
                            {w.endTimeIso ? formatDateTimeRu(w.endTimeIso) : w.label}
                          </td>
                          <td className="px-3 py-2.5 font-medium text-slate-100 whitespace-nowrap">
                            {w.opponentName}
                            <span className="ml-2 font-mono text-[11px] text-slate-500">{w.opponentTag}</span>
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                            {w.teamSize}×{w.teamSize}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                            {w.clanStars} : {w.opponentStars}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                            {w.clanDestruction.toFixed(1)}% : {w.opponentDestruction.toFixed(1)}%
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                            {w.attacksUsed}/{w.maxAttacks}
                          </td>
                          <td
                            className={`px-3 py-2.5 text-right font-mono tabular-nums ${
                              missed > 0 ? 'text-rose-400' : 'text-emerald-400'
                            }`}
                          >
                            {missed}
                          </td>
                          <td
                            className={`px-5 py-2.5 text-right text-xs font-semibold ${
                              w.result === 'win'
                                ? 'text-emerald-400'
                                : w.result === 'loss'
                                ? 'text-rose-400'
                                : 'text-amber-400'
                            }`}
                          >
                            {w.result === 'win' ? 'Победа' : w.result === 'loss' ? 'Поражение' : 'Ничья'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
