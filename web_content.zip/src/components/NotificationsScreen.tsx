import React, { useState, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  UserPlus,
  TrendingUp,
  AtSign,
  ChevronDown,
  Award,
  Check,
} from 'lucide-react';
import { NotificationItem } from '../types';
import { subscribeNotifications } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface NotificationsScreenProps {
  onSelectCreator: (username: string) => void;
  onOpenCertificate: (certId: string) => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({
  onSelectCreator,
  onOpenCertificate,
}) => {
  const { userProfile } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'likes' | 'comments' | 'followers'>('all');
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const uid = userProfile?.id || 'current-user';
    const unsubscribe = subscribeNotifications(uid, (items) => {
      setNotifications(items);
    });
    return () => unsubscribe();
  }, [userProfile?.id]);

  const filteredNotifs = notifications.filter((n) => {
    if (filter === 'likes') return n.type === 'like';
    if (filter === 'comments') return n.type === 'comment' || n.type === 'mention';
    if (filter === 'followers') return n.type === 'follow';
    return true;
  });

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like':
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-rose-500 to-pink-500 flex items-center justify-center text-white shrink-0">
            <Heart size={14} className="fill-white" />
          </div>
        );
      case 'comment':
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-500 flex items-center justify-center text-white shrink-0">
            <MessageCircle size={14} className="fill-white" />
          </div>
        );
      case 'follow':
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#9900FF] to-fuchsia-600 flex items-center justify-center text-white shrink-0">
            <UserPlus size={14} />
          </div>
        );
      case 'milestone':
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-white shrink-0">
            <TrendingUp size={14} />
          </div>
        );
      case 'certificate':
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black shrink-0">
            <Award size={14} />
          </div>
        );
      case 'mention':
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center text-white shrink-0">
            <AtSign size={14} />
          </div>
        );
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen bg-[#050505] text-white px-5 pt-4 pb-24 md:pb-12 animate-fade-in select-none">
      {/* Header matching reference image Screen 6:
          Notificações + Dropdown "Todos ⌵" */}
      <div className="flex items-center justify-between mb-5 relative">
        <h1 className="text-xl font-extrabold text-white">Notificações</h1>

        <div className="relative">
          <button
            onClick={() => setShowDropdown((v) => !v)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#101014] border border-[#19191F] text-xs font-semibold text-[#A1A1AA] hover:text-white transition-colors cursor-pointer"
          >
            <span className="capitalize">
              {filter === 'all'
                ? 'Todos'
                : filter === 'likes'
                ? 'Curtidas'
                : filter === 'comments'
                ? 'Comentários'
                : 'Seguidores'}
            </span>
            <ChevronDown size={14} />
          </button>

          {showDropdown && (
            <div className="absolute right-0 top-9 z-30 w-36 bg-[#101014] border border-[#272730] rounded-2xl p-1.5 shadow-2xl">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'likes', label: 'Curtidas' },
                { id: 'comments', label: 'Comentários' },
                { id: 'followers', label: 'Seguidores' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => {
                    setFilter(opt.id as any);
                    setShowDropdown(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between ${
                    filter === opt.id ? 'bg-[#19191F] text-[#FF008C]' : 'text-white hover:bg-[#19191F]'
                  }`}
                >
                  <span>{opt.label}</span>
                  {filter === opt.id && <Check size={14} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3 mb-6">
        {filteredNotifs.map((item) => (
          <div
            key={item.id}
            onClick={() => {
              if (item.type === 'certificate' && item.targetId) {
                onOpenCertificate(item.targetId);
              } else if (item.senderUsername) {
                onSelectCreator(item.senderUsername);
              }
            }}
            className="flex items-center justify-between p-3.5 rounded-2xl bg-[#101014] border border-[#19191F] hover:bg-[#14141a] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 min-w-0">
              {getNotificationIcon(item.type)}

              <div className="text-left min-w-0">
                <p className="text-xs text-white leading-relaxed line-clamp-2">
                  <span className="font-bold">@{item.senderUsername} </span>
                  <span className="text-[#A1A1AA]">{item.message}</span>
                </p>
                <span className="text-[11px] text-[#A1A1AA] block mt-0.5">
                  há alguns instantes
                </span>
              </div>
            </div>

            {/* Target preview thumbnail if applicable */}
            {item.targetThumbnail && (
              <img
                src={item.targetThumbnail}
                alt="thumbnail"
                className="w-10 h-10 rounded-xl object-cover shrink-0 ml-3 border border-[#272730]"
              />
            )}
          </div>
        ))}
      </div>

      {/* "Novos seguidores" section matching reference image:
          Avatares circulares empilhados + "+12" + "Ver todos" */}
      <div className="p-4 rounded-2xl bg-[#101014] border border-[#19191F]">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-bold text-white">Novos seguidores</h2>
          <button className="text-xs font-semibold text-[#FF008C] hover:underline cursor-pointer">
            Ver todos
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Stacked Avatars */}
          <div className="flex items-center -space-x-2.5 overflow-hidden">
            {[
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
              'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
              'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80',
              'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80',
            ].map((src, i) => (
              <img
                key={i}
                src={src}
                alt="seguidor"
                className="w-10 h-10 rounded-full object-cover border-2 border-[#101014]"
              />
            ))}
          </div>

          {/* +12 badge */}
          <span className="text-xs font-bold text-white/80 pl-1">+12</span>
        </div>
      </div>
    </div>
  );
};
