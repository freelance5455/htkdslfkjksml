import React, { useState } from 'react';
import {
  CreditCard,
  Search,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  X,
  Check,
  Building2,
  Receipt,
  FileText,
  DollarSign,
} from 'lucide-react';
import type { PurchaseItem, SaleItem, DebtPayment, PartyDebtSummary } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic, calculateDebts } from '../utils/calculations.ts';

interface DebtsTabProps {
  purchases: PurchaseItem[];
  sales: SaleItem[];
  payments: DebtPayment[];
  onAddPayment: (payment: Omit<DebtPayment, 'id' | 'createdAt'>) => void;
}

export const DebtsTab: React.FC<DebtsTabProps> = ({
  purchases,
  sales,
  payments,
  onAddPayment,
}) => {
  const [activeLedger, setActiveLedger] = useState<'buyers' | 'suppliers'>('buyers');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPartyDetails, setSelectedPartyDetails] = useState<PartyDebtSummary | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // Payment form state
  const todayStr = new Date().toISOString().split('T')[0];
  const [payPartyName, setPayPartyName] = useState('');
  const [payPartyType, setPayPartyType] = useState<'buyer' | 'supplier'>('buyer');
  const [payAmount, setPayAmount] = useState('');
  const [payDate, setPayDate] = useState(todayStr);
  const [payNote, setPayNote] = useState('');

  const debts = calculateDebts(purchases, sales, payments);

  const currentList = activeLedger === 'buyers' ? debts.buyersDebts : debts.suppliersDebts;

  const filteredList = currentList.filter((item) =>
    item.partyName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openPaymentForParty = (party: PartyDebtSummary) => {
    setPayPartyName(party.partyName);
    setPayPartyType(party.partyType);
    setPayAmount(party.balanceRemaining.toString());
    setPayDate(todayStr);
    setPayNote('');
    setShowPaymentModal(true);
  };

  const handleSavePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(payAmount);
    if (!val || val <= 0) {
      alert('يرجى إدخال مبلغ صالح للتسديد');
      return;
    }

    onAddPayment({
      partyType: payPartyType,
      partyName: payPartyName.trim(),
      date: payDate,
      amount: val,
      type: payPartyType === 'buyer' ? 'receipt' : 'payment',
      note: payNote.trim() || undefined,
    });

    setShowPaymentModal(false);
  };

  // Build account statement for selectedPartyDetails
  const getPartyTransactions = (partyName: string, partyType: 'buyer' | 'supplier') => {
    if (partyType === 'buyer') {
      const partySales = sales
        .filter((s) => s.buyer.trim() === partyName.trim())
        .map((s) => ({
          id: s.id,
          type: 'invoice' as const,
          date: s.date,
          description: `فاتورة بيع: ${s.medicineName} (${s.qty} باكيت)`,
          invoiced: s.totalAmount,
          paid: s.amountPaid,
          createdAt: s.createdAt,
        }));

      const partyPayments = payments
        .filter((p) => p.partyType === 'buyer' && p.partyName.trim() === partyName.trim())
        .map((p) => ({
          id: p.id,
          type: 'payment' as const,
          date: p.date,
          description: `تسديد دفعة نقدية: ${p.note || 'قبض كاش'}`,
          invoiced: 0,
          paid: p.amount,
          createdAt: p.createdAt,
        }));

      return [...partySales, ...partyPayments].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt
      );
    } else {
      const partyPurchases = purchases
        .filter((p) => p.supplier.trim() === partyName.trim())
        .map((p) => ({
          id: p.id,
          type: 'invoice' as const,
          date: p.date,
          description: `فاتورة شراء: ${p.medicineName} (${p.qty} باكيت)`,
          invoiced: p.totalAmount,
          paid: p.amountPaid,
          createdAt: p.createdAt,
        }));

      const partyPayments = payments
        .filter((p) => p.partyType === 'supplier' && p.partyName.trim() === partyName.trim())
        .map((p) => ({
          id: p.id,
          type: 'payment' as const,
          date: p.date,
          description: `تسديد دفعة للمذخر: ${p.note || 'دفعة كاش'}`,
          invoiced: 0,
          paid: p.amount,
          createdAt: p.createdAt,
        }));

      return [...partyPurchases, ...partyPayments].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt
      );
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <CreditCard className="h-6 w-6 text-teal-700" />
            دفتر الديون والحسابات
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            متابعة مستحقات الصيدليات (لنا) ومطلوبات المذاخر والموردين (علينا) وتوثيق الدفعات
          </p>
        </div>

        <button
          onClick={() => {
            setPayPartyName('');
            setPayPartyType(activeLedger === 'buyers' ? 'buyer' : 'supplier');
            setPayAmount('');
            setPayDate(todayStr);
            setPayNote('');
            setShowPaymentModal(true);
          }}
          className="flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-teal-800 active:scale-98 transition self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          تسجيل دفعة تسديد
        </button>
      </div>

      {/* High Impact KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Money owed to us */}
        <div
          onClick={() => setActiveLedger('buyers')}
          className={`cursor-pointer rounded-2xl p-4 border transition ${
            activeLedger === 'buyers'
              ? 'bg-teal-700 text-white shadow-md border-teal-800 ring-2 ring-teal-500/50'
              : 'bg-white text-slate-900 border-slate-200/80 shadow-xs hover:border-teal-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold ${activeLedger === 'buyers' ? 'text-teal-100' : 'text-slate-500'}`}>
              ديون لنا على الصيدليات
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeLedger === 'buyers' ? 'bg-teal-800 text-teal-200' : 'bg-teal-50 text-teal-700'
              }`}
            >
              {debts.buyersDebts.length} صيدلية
            </span>
          </div>
          <div className="text-2xl font-black mt-2">{formatIQD(debts.totalOwedToUs)}</div>
          <p className={`text-[11px] mt-1 ${activeLedger === 'buyers' ? 'text-teal-200' : 'text-slate-400'}`}>
            مستحقات بيع بالآجل
          </p>
        </div>

        {/* Money we owe suppliers */}
        <div
          onClick={() => setActiveLedger('suppliers')}
          className={`cursor-pointer rounded-2xl p-4 border transition ${
            activeLedger === 'suppliers'
              ? 'bg-amber-600 text-white shadow-md border-amber-700 ring-2 ring-amber-400/50'
              : 'bg-white text-slate-900 border-slate-200/80 shadow-xs hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold ${activeLedger === 'suppliers' ? 'text-amber-100' : 'text-slate-500'}`}>
              ديون علينا للمذاخر
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeLedger === 'suppliers' ? 'bg-amber-700 text-amber-200' : 'bg-amber-50 text-amber-700'
              }`}
            >
              {debts.suppliersDebts.length} مورد
            </span>
          </div>
          <div className="text-2xl font-black mt-2">{formatIQD(debts.totalWeOwe)}</div>
          <p className={`text-[11px] mt-1 ${activeLedger === 'suppliers' ? 'text-amber-200' : 'text-slate-400'}`}>
            مطلوبات شراء بالآجل
          </p>
        </div>

        {/* Net Balance */}
        <div className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500">صافي المركز المالي للديون</span>
          <div
            className={`text-2xl font-black mt-2 ${
              debts.netDebtPosition >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {formatIQD(debts.netDebtPosition)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            (ديون لنا) مطروحاً منها (ديون علينا)
          </p>
        </div>
      </div>

      {/* Sub-tab switcher */}
      <div className="flex rounded-2xl bg-slate-200/70 p-1">
        <button
          onClick={() => setActiveLedger('buyers')}
          className={`flex-1 py-2.5 text-xs font-black rounded-xl transition ${
            activeLedger === 'buyers'
              ? 'bg-white text-teal-800 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          كشف ديون الصيدليات والزبائن (لنا: {debts.buyersDebts.length})
        </button>
        <button
          onClick={() => setActiveLedger('suppliers')}
          className={`flex-1 py-2.5 text-xs font-black rounded-xl transition ${
            activeLedger === 'suppliers'
              ? 'bg-white text-amber-800 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          كشف ديون المذاخر والموردين (علينا: {debts.suppliersDebts.length})
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={`بحث باسم ${activeLedger === 'buyers' ? 'الصيدلية أو الزبون' : 'المذخر أو المورد'}...`}
          className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pr-10 pl-3 text-xs placeholder:text-slate-400 focus:border-teal-500 focus:outline-hidden focus:ring-1 focus:ring-teal-500"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Debts List */}
      {filteredList.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-400">
          <CreditCard className="mx-auto h-8 w-8 text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">لا توجد ديون مسجلة في هذا القسم</p>
          <p className="text-xs text-slate-400 mt-1">
            جميع الحسابات مسددة بالكامل كاش أو لا تطابق البحث.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredList.map((item) => (
            <div
              key={item.partyName}
              className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-teal-300 transition"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2
                      className={`h-4 w-4 ${
                        item.partyType === 'buyer' ? 'text-teal-600' : 'text-amber-600'
                      }`}
                    />
                    <h3 className="text-sm font-black text-slate-900">{item.partyName}</h3>
                  </div>
                  <div className="text-xs text-slate-500">
                    إجمالي الفواتير: {formatIQD(item.totalInvoiced)} | المسدد منها: {formatIQD(item.totalPaid)}
                  </div>
                </div>

                <div className="text-left">
                  <div
                    className={`text-base font-black ${
                      item.partyType === 'buyer' ? 'text-teal-800' : 'text-amber-800'
                    }`}
                  >
                    {formatIQD(item.balanceRemaining)}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    المتبقي كدين {item.partyType === 'buyer' ? 'لنا' : 'علينا'}
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  آخر حركة: {formatDateArabic(item.lastTransactionDate)}
                </span>

                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedPartyDetails(item)}
                    className="flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
                  >
                    <FileText className="h-3.5 w-3.5 text-slate-500" />
                    كشف حساب
                  </button>

                  <button
                    onClick={() => openPaymentForParty(item)}
                    className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-bold text-white shadow-xs transition ${
                      item.partyType === 'buyer'
                        ? 'bg-teal-700 hover:bg-teal-800'
                        : 'bg-amber-600 hover:bg-amber-700'
                    }`}
                  >
                    <DollarSign className="h-3.5 w-3.5" />
                    {item.partyType === 'buyer' ? 'قبض دفعة' : 'دفع دفعة'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Account Statement Modal */}
      {selectedPartyDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-2xl bg-white p-5 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded">
                  كشف حساب تفصيلي
                </span>
                <h2 className="text-base font-black text-slate-900 mt-1">
                  {selectedPartyDetails.partyName}
                </h2>
              </div>
              <button
                onClick={() => setSelectedPartyDetails(null)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Account Summary header */}
            <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-3 text-center text-xs">
              <div>
                <span className="text-slate-400 text-[11px]">إجمالي الفواتير</span>
                <div className="font-bold text-slate-900 mt-0.5">
                  {formatIQD(selectedPartyDetails.totalInvoiced)}
                </div>
              </div>
              <div>
                <span className="text-slate-400 text-[11px]">إجمالي المسدد</span>
                <div className="font-bold text-emerald-700 mt-0.5">
                  {formatIQD(selectedPartyDetails.totalPaid)}
                </div>
              </div>
              <div>
                <span className="text-slate-400 text-[11px]">الرصيد المتبقي</span>
                <div className="font-black text-rose-700 mt-0.5">
                  {formatIQD(selectedPartyDetails.balanceRemaining)}
                </div>
              </div>
            </div>

            {/* Transactions History */}
            <div className="mt-4 space-y-2">
              <h4 className="text-xs font-bold text-slate-700">سجل الفواتير والدفعات المسددة:</h4>
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                {getPartyTransactions(
                  selectedPartyDetails.partyName,
                  selectedPartyDetails.partyType
                ).map((tx, idx) => (
                  <div key={tx.id + idx} className="p-3 bg-white flex items-center justify-between text-xs">
                    <div className="space-y-0.5">
                      <div className="font-bold text-slate-900">{tx.description}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {formatDateArabic(tx.date)}
                      </div>
                    </div>

                    <div className="text-left font-mono">
                      {tx.type === 'invoice' ? (
                        <>
                          <div className="font-bold text-slate-900">{formatIQD(tx.invoiced)}</div>
                          <div className="text-[10px] text-emerald-600">
                            واصل كاش: {formatIQD(tx.paid)}
                          </div>
                        </>
                      ) : (
                        <div className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                          دفعة مسددة: {formatIQD(tx.paid)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex justify-end gap-2 border-t border-slate-100 pt-3">
              <button
                onClick={() => {
                  const party = selectedPartyDetails;
                  setSelectedPartyDetails(null);
                  openPaymentForParty(party);
                }}
                className="rounded-xl bg-teal-700 px-4 py-2 text-xs font-bold text-white hover:bg-teal-800 transition"
              >
                تسجيل دفعة لهذا الحساب
              </button>
              <button
                onClick={() => setSelectedPartyDetails(null)}
                className="rounded-xl border border-slate-300 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-teal-700" />
                تسجيل دفعة تسديد نقدية
              </h2>
              <button
                onClick={() => setShowPaymentModal(false)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSavePayment} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  نوع الطرف <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPayPartyType('buyer')}
                    className={`py-2 text-xs font-bold rounded-xl border transition ${
                      payPartyType === 'buyer'
                        ? 'border-teal-600 bg-teal-50 text-teal-800 font-black'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    قبض من صيدلية (زبون)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayPartyType('supplier')}
                    className={`py-2 text-xs font-bold rounded-xl border transition ${
                      payPartyType === 'supplier'
                        ? 'border-amber-600 bg-amber-50 text-amber-800 font-black'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    دفع لمذخر (مورد)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الاسم (الصيدلية أو المذخر) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={payPartyName}
                  onChange={(e) => setPayPartyName(e.target.value)}
                  placeholder="اسم الطرف المسدد"
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    المبلغ المسدد (د.ع) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="250"
                    step="250"
                    value={payAmount}
                    onChange={(e) => setPayAmount(e.target.value)}
                    placeholder="المبلغ"
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold focus:border-teal-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تاريخ التسديد <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={payDate}
                    onChange={(e) => setPayDate(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات أو رقم السند / الوصل
                </label>
                <input
                  type="text"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  placeholder="مثال: دفعة نقدية باليد، تحويل زين كاش..."
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 rounded-xl bg-teal-700 px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-teal-800 transition"
                >
                  <Check className="h-4 w-4" />
                  تأكيد وقيد التسديد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
