import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import { Loan, BillReminder } from '../../types';
import {
  HandCoins,
  BellRing,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle,
  Clock,
  Trash2,
  Calendar,
  X,
  Check,
  User,
  Phone
} from 'lucide-react';

export const LoansAndBillsView: React.FC = () => {
  const {
    loans,
    addLoan,
    recordLoanRepayment,
    markLoanPaid,
    deleteLoan,
    bills,
    addBill,
    markBillPaid,
    deleteBill,
    language,
    t
  } = useKhata();

  const [activeSubTab, setActiveSubTab] = useState<'loans' | 'bills'>('loans');
  const [loanTypeFilter, setLoanTypeFilter] = useState<'all' | 'borrowed' | 'lent'>('all');

  // Modals inside this view
  const [showAddLoanModal, setShowAddLoanModal] = useState(false);
  const [showAddBillModal, setShowAddBillModal] = useState(false);
  const [selectedLoanForRepayment, setSelectedLoanForRepayment] = useState<Loan | null>(null);

  // Form states for Add Loan
  const [loanPerson, setLoanPerson] = useState('');
  const [loanPhone, setLoanPhone] = useState('');
  const [loanType, setLoanType] = useState<'borrowed' | 'lent'>('lent');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanDate, setLoanDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [loanDueDate, setLoanDueDate] = useState('');
  const [loanNotes, setLoanNotes] = useState('');

  // Form states for Add Bill
  const [billTitleHi, setBillTitleHi] = useState('');
  const [billCategory, setBillCategory] = useState('electricity');
  const [billAmount, setBillAmount] = useState('');
  const [billDueDate, setBillDueDate] = useState('');
  const [billFrequency, setBillFrequency] = useState<'monthly' | 'one_time' | 'quarterly' | 'yearly'>('monthly');

  // Form state for Repayment
  const [repaymentAmount, setRepaymentAmount] = useState('');
  const [repaymentNote, setRepaymentNote] = useState('');

  // Summary counts
  const totalLentPending = loans
    .filter(l => l.type === 'lent' && l.status !== 'paid')
    .reduce((sum, l) => {
      const repaid = l.repayments.reduce((rSum, r) => rSum + r.amount, 0);
      return sum + Math.max(0, l.amount - repaid);
    }, 0);

  const totalBorrowedPending = loans
    .filter(l => l.type === 'borrowed' && l.status !== 'paid')
    .reduce((sum, l) => {
      const repaid = l.repayments.reduce((rSum, r) => rSum + r.amount, 0);
      return sum + Math.max(0, l.amount - repaid);
    }, 0);

  // Filtered loans
  const filteredLoans = loans.filter(l => {
    if (loanTypeFilter !== 'all' && l.type !== loanTypeFilter) return false;
    return true;
  });

  const handleCreateLoan = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(loanAmount);
    if (!loanPerson.trim() || !amt || amt <= 0) return;

    addLoan({
      personName: loanPerson.trim(),
      phone: loanPhone.trim() || undefined,
      type: loanType,
      amount: amt,
      date: loanDate,
      dueDate: loanDueDate || undefined,
      status: 'pending',
      notes: loanNotes.trim() || undefined
    });

    setShowAddLoanModal(false);
    setLoanPerson('');
    setLoanPhone('');
    setLoanAmount('');
    setLoanNotes('');
  };

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(billAmount);
    if (!billTitleHi.trim() || !amt || amt <= 0 || !billDueDate) return;

    addBill({
      titleHi: billTitleHi.trim(),
      titleEn: billTitleHi.trim(),
      category: billCategory,
      amount: amt,
      dueDate: billDueDate,
      frequency: billFrequency,
      status: 'pending'
    });

    setShowAddBillModal(false);
    setBillTitleHi('');
    setBillAmount('');
    setBillDueDate('');
  };

  const handleRecordRepayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLoanForRepayment) return;
    const amt = parseFloat(repaymentAmount);
    if (!amt || amt <= 0) return;

    recordLoanRepayment(selectedLoanForRepayment.id, amt, repaymentNote.trim() || undefined);
    setSelectedLoanForRepayment(null);
    setRepaymentAmount('');
    setRepaymentNote('');
  };

  return (
    <div className="space-y-4 pb-8">
      {/* Sub-tab Switcher: Loans (उधार) vs Bills (बिल) */}
      <div className="grid grid-cols-2 gap-1 p-1 bg-white rounded-2xl border border-slate-200 shadow-xs">
        <button
          onClick={() => setActiveSubTab('loans')}
          className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'loans'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <HandCoins className="w-4 h-4" />
          <span>{t.loanManagement}</span>
        </button>
        <button
          onClick={() => setActiveSubTab('bills')}
          className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'bills'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BellRing className="w-4 h-4" />
          <span>{t.billReminders}</span>
        </button>
      </div>

      {/* ================= SECTION 1: LOANS / UDHAAR KHATA ================= */}
      {activeSubTab === 'loans' && (
        <div className="space-y-4">
          {/* Summary Strip (To Receive vs To Pay) */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
              <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-semibold mb-1">
                <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
                <span>{t.toReceive} (दिया उधार)</span>
              </div>
              <div className="text-xl sm:text-2xl font-extrabold text-emerald-900 tabular-nums">
                {formatRupee(totalLentPending)}
              </div>
              <div className="text-[11px] text-emerald-700 mt-1">
                {language === 'hi' ? 'लोगों से वापस लेना बाकी है' : 'To collect from others'}
              </div>
            </div>

            <div className="bg-rose-50 p-4 rounded-2xl border border-rose-200">
              <div className="flex items-center gap-1.5 text-rose-800 text-xs font-semibold mb-1">
                <ArrowUpRight className="w-4 h-4 text-rose-600" />
                <span>{t.toPay} (लिया कर्ज)</span>
              </div>
              <div className="text-xl sm:text-2xl font-extrabold text-rose-900 tabular-nums">
                {formatRupee(totalBorrowedPending)}
              </div>
              <div className="text-[11px] text-rose-700 mt-1">
                {language === 'hi' ? 'मुझे दूसरों को चुकाना है' : 'To return to others'}
              </div>
            </div>
          </div>

          {/* Controls: Filter & Add Loan Button */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs">
              <button
                onClick={() => setLoanTypeFilter('all')}
                className={`px-3 py-1.5 rounded-lg font-bold transition ${
                  loanTypeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {t.all}
              </button>
              <button
                onClick={() => setLoanTypeFilter('lent')}
                className={`px-3 py-1.5 rounded-lg font-bold transition ${
                  loanTypeFilter === 'lent' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                {language === 'hi' ? 'दिया उधार' : 'Lent'}
              </button>
              <button
                onClick={() => setLoanTypeFilter('borrowed')}
                className={`px-3 py-1.5 rounded-lg font-bold transition ${
                  loanTypeFilter === 'borrowed' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                {language === 'hi' ? 'लिया कर्ज' : 'Borrowed'}
              </button>
            </div>

            <button
              onClick={() => setShowAddLoanModal(true)}
              className="flex items-center gap-1 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addLoanEntry}</span>
            </button>
          </div>

          {/* Loans List */}
          {filteredLoans.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 space-y-2">
              <HandCoins className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs text-slate-500">{t.noLoansRecorded}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredLoans.map(loan => {
                const totalRepaid = loan.repayments.reduce((sum, r) => sum + r.amount, 0);
                const pendingBalance = Math.max(0, loan.amount - totalRepaid);
                const isPaid = loan.status === 'paid' || pendingBalance === 0;
                const isLent = loan.type === 'lent';

                return (
                  <div
                    key={loan.id}
                    className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-2.5">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                            isLent
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {isLent ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-slate-900">{loan.personName}</h4>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                isPaid
                                  ? 'bg-slate-100 text-slate-600'
                                  : isLent
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {isLent ? 'दिया उधार (I Lent)' : 'लिया कर्ज (I Borrowed)'}
                            </span>
                          </div>

                          {loan.phone && (
                            <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                              <Phone className="w-3 h-3" />
                              <span>{loan.phone}</span>
                            </div>
                          )}

                          <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-1">
                            <span>तारीख: {formatIndianDate(loan.date, language)}</span>
                            {loan.dueDate && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-amber-700 font-semibold">
                                  देय: {formatIndianDate(loan.dueDate, language)}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-base font-extrabold text-slate-900 tabular-nums">
                          {formatRupee(loan.amount)}
                        </div>
                        <div
                          className={`text-xs font-bold tabular-nums mt-0.5 ${
                            isPaid ? 'text-slate-400 line-through' : 'text-rose-600'
                          }`}
                        >
                          {isPaid ? t.paid : `बकाया: ${formatRupee(pendingBalance)}`}
                        </div>
                      </div>
                    </div>

                    {/* Notes if any */}
                    {loan.notes && (
                      <div className="text-xs bg-slate-50 p-2 rounded-lg text-slate-600 italic">
                        "{loan.notes}"
                      </div>
                    )}

                    {/* Repayment History if any */}
                    {loan.repayments.length > 0 && (
                      <div className="pt-2 border-t border-slate-100 space-y-1">
                        <div className="text-[11px] font-bold text-slate-500">{t.repaymentHistory}:</div>
                        {loan.repayments.map(r => (
                          <div key={r.id} className="flex justify-between text-xs text-slate-600">
                            <span>
                              {formatIndianDate(r.date, language)} {r.note ? `(${r.note})` : ''}
                            </span>
                            <span className="font-semibold text-emerald-700 tabular-nums">
                              - {formatRupee(r.amount)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action buttons */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                      <button
                        onClick={() => {
                          if (window.confirm('क्या आप इस कर्ज प्रविष्टि को हटाना चाहते हैं?')) {
                            deleteLoan(loan.id);
                          }
                        }}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded-md"
                        title={t.delete}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-2">
                        {!isPaid && (
                          <>
                            <button
                              onClick={() => setSelectedLoanForRepayment(loan)}
                              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold"
                            >
                              + {t.recordRepayment}
                            </button>
                            <button
                              onClick={() => markLoanPaid(loan.id)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold flex items-center gap-1"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>{t.markFullyPaid}</span>
                            </button>
                          </>
                        )}
                        {isPaid && (
                          <span className="flex items-center gap-1 text-emerald-700 font-bold">
                            <CheckCircle className="w-4 h-4" />
                            <span>{t.paid}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= SECTION 2: BILL REMINDERS ================= */}
      {activeSubTab === 'bills' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">{t.billReminders}</h3>
              <p className="text-[11px] text-slate-500">
                {language === 'hi'
                  ? 'बिजली, पानी, स्कूल फीस और रिचार्ज के समय पर भुगतान का रिमाइंडर'
                  : 'Track & pay electricity, water, gas and school bills on time'}
              </p>
            </div>
            <button
              onClick={() => setShowAddBillModal(true)}
              className="flex items-center gap-1 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addBillReminder}</span>
            </button>
          </div>

          {bills.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 space-y-2">
              <BellRing className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs text-slate-500">{t.allBillsClear}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {bills.map(bill => {
                const isPaid = bill.status === 'paid';
                return (
                  <div
                    key={bill.id}
                    className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isPaid ? 'bg-slate-100 text-slate-400' : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        <BellRing className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">
                          {language === 'hi' ? bill.titleHi : bill.titleEn}
                        </h4>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                          <span>देय तारीख: {formatIndianDate(bill.dueDate, language)}</span>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize">{bill.frequency}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-sm font-extrabold text-slate-900 tabular-nums">
                          {formatRupee(bill.amount)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {isPaid ? t.paid : t.pending}
                        </div>
                      </div>

                      {!isPaid ? (
                        <button
                          onClick={() => markBillPaid(bill.id, true)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition"
                        >
                          {t.payNow}
                        </button>
                      ) : (
                        <span className="p-1.5 text-emerald-600">
                          <CheckCircle className="w-5 h-5" />
                        </span>
                      )}

                      <button
                        onClick={() => {
                          if (window.confirm('क्या आप इस बिल रिमाइंडर को हटाना चाहते हैं?')) {
                            deleteBill(bill.id);
                          }
                        }}
                        className="text-slate-300 hover:text-rose-600 p-1"
                        title={t.delete}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODAL: ADD LOAN */}
      {showAddLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900">{t.addLoanEntry}</h3>
              <button onClick={() => setShowAddLoanModal(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLoan} className="space-y-3.5">
              {/* Type: Lent (दिया) or Borrowed (लिया) */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setLoanType('lent')}
                  className={`py-2 text-xs font-bold rounded-lg transition ${
                    loanType === 'lent' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {t.iLent}
                </button>
                <button
                  type="button"
                  onClick={() => setLoanType('borrowed')}
                  className={`py-2 text-xs font-bold rounded-lg transition ${
                    loanType === 'borrowed' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {t.iBorrowed}
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t.personName} *
                </label>
                <input
                  type="text"
                  required
                  value={loanPerson}
                  onChange={e => setLoanPerson(e.target.value)}
                  placeholder="उदा. रमेश जी, शर्मा जी..."
                  className="w-full px-3 py-2 text-sm border rounded-xl"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t.personPhone}
                </label>
                <input
                  type="tel"
                  value={loanPhone}
                  onChange={e => setLoanPhone(e.target.value)}
                  placeholder="9876543210"
                  className="w-full px-3 py-2 text-sm border rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.amount} *</label>
                <input
                  type="number"
                  required
                  value={loanAmount}
                  onChange={e => setLoanAmount(e.target.value)}
                  placeholder="₹ 5000"
                  className="w-full px-3 py-2 text-lg font-bold border rounded-xl font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.date}</label>
                  <input
                    type="date"
                    required
                    value={loanDate}
                    onChange={e => setLoanDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.dueDate}</label>
                  <input
                    type="date"
                    value={loanDueDate}
                    onChange={e => setLoanDueDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">नोट / विवरण</label>
                <input
                  type="text"
                  value={loanNotes}
                  onChange={e => setLoanNotes(e.target.value)}
                  placeholder="उधार का कारण या विवरण..."
                  className="w-full px-3 py-2 text-xs border rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition"
              >
                {t.save}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD BILL */}
      {showAddBillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900">{t.addBillReminder}</h3>
              <button onClick={() => setShowAddBillModal(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateBill} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.billTitle} *</label>
                <input
                  type="text"
                  required
                  value={billTitleHi}
                  onChange={e => setBillTitleHi(e.target.value)}
                  placeholder="उदा. बिजली बिल, स्कूल फीस, गैस..."
                  className="w-full px-3 py-2 text-sm border rounded-xl"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.amount} *</label>
                <input
                  type="number"
                  required
                  value={billAmount}
                  onChange={e => setBillAmount(e.target.value)}
                  placeholder="₹ 1500"
                  className="w-full px-3 py-2 text-lg font-bold border rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.dueDate} *</label>
                <input
                  type="date"
                  required
                  value={billDueDate}
                  onChange={e => setBillDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.frequency}</label>
                <select
                  value={billFrequency}
                  onChange={e => setBillFrequency(e.target.value as typeof billFrequency)}
                  className="w-full px-3 py-2 text-xs border rounded-xl bg-white"
                >
                  <option value="monthly">{t.frequencyMonthly}</option>
                  <option value="quarterly">{t.frequencyQuarterly}</option>
                  <option value="yearly">{t.frequencyYearly}</option>
                  <option value="one_time">{t.frequencyOneTime}</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition"
              >
                {t.save}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RECORD REPAYMENT */}
      {selectedLoanForRepayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900">{t.recordRepayment}</h3>
              <button onClick={() => setSelectedLoanForRepayment(null)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              {selectedLoanForRepayment.personName} के लिए भुगतान दर्ज करें:
            </p>

            <form onSubmit={handleRecordRepayment} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  भुगतान राशि (₹) *
                </label>
                <input
                  type="number"
                  required
                  value={repaymentAmount}
                  onChange={e => setRepaymentAmount(e.target.value)}
                  placeholder="₹ 1000"
                  className="w-full px-3 py-2 text-xl font-bold border rounded-xl font-mono"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">विवरण / नोट</label>
                <input
                  type="text"
                  value={repaymentNote}
                  onChange={e => setRepaymentNote(e.target.value)}
                  placeholder="उदा. गूगल पे से मिला"
                  className="w-full px-3 py-2 text-xs border rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition"
              >
                {t.save}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
