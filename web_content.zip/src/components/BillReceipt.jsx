import { inr, fmtQty, fmtDateTime, round2 } from '../lib/format'

function billText(bill) {
  const lines = []
  lines.push(bill.shopName || 'Mera Kirana')
  if (bill.shopAddress) lines.push(bill.shopAddress)
  if (bill.shopPhone) lines.push(`Phone: ${bill.shopPhone}`)
  lines.push(`Bill: #${bill.billNo}`)
  lines.push(fmtDateTime(bill.createdAt))
  lines.push('--------------------------------')
  for (const i of bill.items) {
    lines.push(`${i.name}`)
    lines.push(`  ${fmtQty(i.qty)} x ${inr(i.price)} = ${inr(round2(i.price * i.qty))}`)
  }
  lines.push('--------------------------------')
  lines.push(`TOTAL: ${inr(bill.total)}`)
  if (bill.payMode === 'CASH' && bill.cashGiven > bill.total) {
    lines.push(`Diye: ${inr(bill.cashGiven)}`)
    lines.push(`Wapas diye: ${inr(bill.changeReturned)}`)
  }
  lines.push(`Mode: ${bill.payMode}${bill.payMode === 'UDHAR' && bill.customerName ? ` (${bill.customerName})` : ''}`)
  lines.push('')
  lines.push('Dhanyawad, phir aaiye!')
  return lines.join('\n')
}

export default function BillReceipt({ bill, onNewBill, onBack, onVoid }) {
  const text = billText(bill)

  async function share() {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Bill', text })
      } catch {}
    } else {
      await navigator.clipboard.writeText(text)
      window.alert('Bill copy ho gaya. WhatsApp me paste karo.')
    }
  }

  return (
    <div className="receipt-screen">
      <header className="topbar">
        <button className="btn btn-ghost" onClick={onBack}>
          ←
        </button>
        <strong>Bill # {bill.billNo}</strong>
      </header>

      <div className="receipt-paper" id="receipt-paper">
        <div className="receipt-shop">{bill.shopName}</div>
        {bill.shopAddress && <div className="receipt-muted">{bill.shopAddress}</div>}
        {bill.shopPhone && <div className="receipt-muted">📞 {bill.shopPhone}</div>}
        <div className="receipt-muted">
          Bill: #{bill.billNo} · {fmtDateTime(bill.createdAt)}
        </div>

        <div className="receipt-line" />

        <div className="receipt-items">
          {bill.items.map((i, idx) => (
            <div key={idx} className="receipt-item">
              <div className="receipt-name">{i.name}</div>
              <div className="receipt-muted">
                {fmtQty(i.qty)} x {inr(i.price)}
              </div>
              <div className="receipt-amount">{inr(round2(i.price * i.qty))}</div>
            </div>
          ))}
        </div>

        <div className="receipt-line" />

        <div className="receipt-total-row">
          <span>TOTAL</span>
          <span>{inr(bill.total)}</span>
        </div>
        {bill.payMode === 'CASH' && bill.cashGiven > bill.total && (
          <>
            <div className="receipt-muted">Diye: {inr(bill.cashGiven)}</div>
            <div className="receipt-change">Wapas diye: {inr(bill.changeReturned)}</div>
          </>
        )}
        <div className="receipt-muted">
          Mode: {bill.payMode}
          {bill.payMode === 'UDHAR' && bill.customerName ? ` · ${bill.customerName}` : ''}
        </div>

        <div className="receipt-footer">Dhanyawad!</div>
      </div>

      <div className="receipt-actions">
        <button className="btn btn-outline btn-big" onClick={share}>
          📤 Share
        </button>
        <button className="btn btn-primary btn-big" onClick={() => window.print()}>
          🖨 Print / PDF
        </button>
        <button className="btn btn-success btn-big" onClick={onNewBill}>
          + Nayi Bill
        </button>
      </div>

      {onVoid && (
        <div className="receipt-void">
          <button
            className="btn btn-ghost btn-small"
            onClick={() => {
              if (window.confirm(`Bill #${bill.billNo} void karein? Stock wapas ho jayega.`))
                onVoid()
            }}
          >
            ✕ Ye galat bill hai — void karo
          </button>
        </div>
      )}
    </div>
  )
}