import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { exportFileToDeviceFolder } from '../lib/fileExportHelper';
import {
  QrCode,
  Copy,
  Check,
  Download,
  Share2,
  DollarSign,
  Zap,
  Building2,
  Sparkles,
  CreditCard,
  CheckCircle2,
  Layers,
  ArrowDownLeft,
  Smartphone,
  Globe,
  Radio,
  ExternalLink,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { ImsiWalletBalances, imsiEngine } from '../lib/imsiEngine';
import { currencyConverter, DisplayCurrency } from '../lib/currencyConverter';

interface QRPaymentGeneratorProps {
  wallet?: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
}

export type PaymentRail = 
  | 'BTC' 
  | 'ETH' 
  | 'SOL' 
  | 'USDT' 
  | 'CVT'
  | 'NIBSS_NQR'
  | 'SEPA_EUR'
  | 'UK_FASTER'
  | 'US_ZELLE_WIRE'
  | 'UPI_GLOBAL';

interface RailConfig {
  id: PaymentRail;
  category: 'CRYPTO' | 'BANKING';
  name: string;
  subName: string;
  symbol: string;
  defaultAddress: string;
  standard: string;
  icon: string;
  color: string;
}

const PAYMENT_RAILS: RailConfig[] = [
  {
    id: 'BTC',
    category: 'CRYPTO',
    name: 'Bitcoin (BTC)',
    subName: 'Native SegWit / Lightning BIP-21',
    symbol: '₿',
    defaultAddress: 'bc1qjuhnkrixaltarvaultbitcoin999777888',
    standard: 'BIP-21 URI Standard',
    icon: '⚡',
    color: 'from-amber-500 to-yellow-500'
  },
  {
    id: 'ETH',
    category: 'CRYPTO',
    name: 'Ethereum (ETH)',
    subName: 'ERC-681 Smart Contract Standard',
    symbol: 'Ξ',
    defaultAddress: '0x777JUHNKRIXaltarVault99988877766655544433',
    standard: 'EIP-681 Payment Request',
    icon: '💎',
    color: 'from-indigo-500 to-purple-600'
  },
  {
    id: 'SOL',
    category: 'CRYPTO',
    name: 'Solana (SOL)',
    subName: 'Solana Pay Protocol Spec',
    symbol: '◎',
    defaultAddress: '7xJUHNKRIXsolanaAltarVault999888777666555444',
    standard: 'Solana Pay Spec 1.0',
    icon: '🪐',
    color: 'from-purple-500 to-teal-400'
  },
  {
    id: 'USDT',
    category: 'CRYPTO',
    name: 'Tether USD (USDT)',
    subName: 'TRC-20 & Multi-Chain Stablecoin',
    symbol: '$',
    defaultAddress: 'TLJUHNKRIXusdtAltarVault77788899900011',
    standard: 'TRC-20 / ERC-20 QR Protocol',
    icon: '💵',
    color: 'from-emerald-500 to-teal-600'
  },
  {
    id: 'CVT',
    category: 'CRYPTO',
    name: 'Converto Token (CVT)',
    subName: 'Airtime-to-Crypto Prophetic Token',
    symbol: '⚡',
    defaultAddress: 'cvt_juhnkrixmusika.pages.dev_vault777',
    standard: 'Converto Airtime-Crypto Standard',
    icon: '🪙',
    color: 'from-amber-400 to-orange-500'
  },
  {
    id: 'NIBSS_NQR',
    category: 'BANKING',
    name: 'Nigeria NIBSS NQR / EMVCo',
    subName: 'Opay, Moniepoint, Fidelity, PalmPay',
    symbol: '₦',
    defaultAddress: '07071918280 (JUHNKRIX STEPHEN - Opay MFB)',
    standard: 'EMVCo / NIBSS NQR Specification',
    icon: '🇳🇬',
    color: 'from-emerald-600 to-green-500'
  },
  {
    id: 'SEPA_EUR',
    category: 'BANKING',
    name: 'European Union EPC SEPA QR',
    subName: 'Instant Euro Zone Wire (SCT/Inst)',
    symbol: '€',
    defaultAddress: 'NG65FIDL00006555712574',
    standard: 'EPC069-12 European Payment QR',
    icon: '🇪🇺',
    color: 'from-blue-600 to-cyan-500'
  },
  {
    id: 'UK_FASTER',
    category: 'BANKING',
    name: 'UK Faster Payments QR',
    subName: 'Sort Code: 20-00-00 • Acc: 70719182',
    symbol: '£',
    defaultAddress: '20-00-00 / 70719182 (JUHNKRIX MUSIKA)',
    standard: 'UK Open Banking Faster Payment QR',
    icon: '🇬🇧',
    color: 'from-rose-500 to-purple-600'
  },
  {
    id: 'US_ZELLE_WIRE',
    category: 'BANKING',
    name: 'US FedNow / Zelle / Wire',
    subName: 'Instant ACH & Zelle Deposit Rail',
    symbol: '$',
    defaultAddress: 'juhnkrix.musika@gmail.com',
    standard: 'US FedNow & Zelle Dynamic Payload',
    icon: '🇺🇸',
    color: 'from-sky-500 to-blue-600'
  },
  {
    id: 'UPI_GLOBAL',
    category: 'BANKING',
    name: 'UPI Global Mobile Pay',
    subName: 'Unified Payments Interface Spec',
    symbol: '₹',
    defaultAddress: '7071918280@opay',
    standard: 'NPCI UPI QR Format',
    icon: '🌏',
    color: 'from-amber-600 to-orange-600'
  }
];

export const QRPaymentGenerator: React.FC<QRPaymentGeneratorProps> = ({ wallet, onShowToast }) => {
  const [activeCategory, setActiveCategory] = useState<'CRYPTO' | 'BANKING'>('CRYPTO');
  const [selectedRail, setSelectedRail] = useState<PaymentRail>('BTC');
  const [amount, setAmount] = useState<string>('0.005');
  const [donorMemo, setDonorMemo] = useState<string>('Prophetic Kingdom Tithe & Offering');
  const [donorName, setDonorName] = useState<string>('Faithful Partner');
  const [copiedPayload, setCopiedPayload] = useState<boolean>(false);
  const [copiedAddress, setCopiedAddress] = useState<boolean>(false);
  const [isSimulatingPayment, setIsSimulatingPayment] = useState<boolean>(false);
  const [simulatedSuccess, setSimulatedSuccess] = useState<string | null>(null);

  const qrContainerRef = useRef<HTMLDivElement>(null);

  const currentRail = PAYMENT_RAILS.find((r) => r.id === selectedRail) || PAYMENT_RAILS[0];

  // Generate real standard-compliant payment URI string
  const generatePaymentPayload = (): string => {
    const amt = amount.trim() || '0';
    const memoEnc = encodeURIComponent(donorMemo.trim() || 'Prophetic Offering');
    const nameEnc = encodeURIComponent(donorName.trim() || 'Partner');

    switch (selectedRail) {
      case 'BTC':
        return `bitcoin:${currentRail.defaultAddress}?amount=${amt}&label=JUHNKRIX%20MUSIKA&message=${memoEnc}`;
      case 'ETH':
        return `ethereum:${currentRail.defaultAddress}?value=${amt}&message=${memoEnc}`;
      case 'SOL':
        return `solana:${currentRail.defaultAddress}?amount=${amt}&label=JUHNKRIX%20MUSIKA&message=${memoEnc}`;
      case 'USDT':
        return `tron:${currentRail.defaultAddress}?amount=${amt}&token=USDT&memo=${memoEnc}`;
      case 'CVT':
        return `converto:${currentRail.defaultAddress}?amount=${amt}&donor=${nameEnc}&memo=${memoEnc}`;
      case 'NIBSS_NQR':
        // EMVCo compliant NIBSS format
        return `00020101021226680016com.nibss-nqr.ng0111070719182800208OPAY_NG520400005303566540${amt.padStart(5, '0')}5802NG5917JUHNKRIX STEPHEN6005LAGOS62190115${memoEnc.substring(0, 15)}6304`;
      case 'SEPA_EUR':
        return `BCD\n002\n1\nSCT\nJUHNKRIX MUSIKA\n${currentRail.defaultAddress}\nEUR${amt}\n\n${donorMemo}\n`;
      case 'UK_FASTER':
        return `fps://pay?sortCode=200000&account=70719182&name=JUHNKRIX%20MUSIKA&amount=${amt}&ref=${memoEnc}`;
      case 'US_ZELLE_WIRE':
        return `zelle://pay?recipient=${currentRail.defaultAddress}&amount=${amt}&memo=${memoEnc}&token=FEDNOW`;
      case 'UPI_GLOBAL':
        return `upi://pay?pa=${currentRail.defaultAddress}&pn=JUHNKRIX%20MUSIKA&am=${amt}&cu=INR&tn=${memoEnc}`;
      default:
        return `${currentRail.defaultAddress}?amount=${amt}`;
    }
  };

  const payloadString = generatePaymentPayload();

  // Presets based on selected rail
  const getPresets = (): string[] => {
    if (selectedRail === 'BTC') return ['0.0005', '0.001', '0.005', '0.01', '0.05'];
    if (selectedRail === 'ETH') return ['0.01', '0.05', '0.1', '0.5', '1.0'];
    if (selectedRail === 'SOL') return ['0.25', '0.5', '1.0', '2.5', '5.0'];
    if (selectedRail === 'USDT' || selectedRail === 'US_ZELLE_WIRE') return ['25', '50', '100', '250', '500'];
    if (selectedRail === 'CVT') return ['10', '50', '100', '500', '1000'];
    if (selectedRail === 'NIBSS_NQR') return ['2000', '5000', '10000', '25000', '50000'];
    if (selectedRail === 'SEPA_EUR') return ['20', '50', '100', '250', '500'];
    if (selectedRail === 'UK_FASTER') return ['15', '30', '50', '100', '250'];
    return ['100', '500', '1000', '5000'];
  };

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(payloadString);
    setCopiedPayload(true);
    onShowToast?.(`✓ Copied dynamic ${currentRail.name} QR Payment Payload!`);
    setTimeout(() => setCopiedPayload(false), 2500);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(currentRail.defaultAddress);
    setCopiedAddress(true);
    onShowToast?.(`✓ Copied ${currentRail.name} address/account!`);
    setTimeout(() => setCopiedAddress(false), 2500);
  };

  const handleDownloadQrPng = () => {
    try {
      const svg = qrContainerRef.current?.querySelector('svg');
      if (!svg) {
        onShowToast?.('⚠️ QR Code could not be exported.');
        return;
      }

      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      canvas.width = 600;
      canvas.height = 600;

      img.onload = () => {
        if (!ctx) return;
        // Background fill
        ctx.fillStyle = '#030712';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw outer frame
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 12;
        ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);

        // Draw QR
        ctx.drawImage(img, 50, 50, 500, 500);

        const dataUrl = canvas.toDataURL('image/png');
        const fileName = `JUHNKRIX_${selectedRail}_Payment_QR.png`;
        
        // Convert dataURL to Blob
        fetch(dataUrl)
          .then(res => res.blob())
          .then(blob => {
            exportFileToDeviceFolder(fileName, blob, 'image/png');
            onShowToast?.(`✓ Saved ${currentRail.name} High-Res Payment QR Code to device folder!`);
          });
      };

      img.src = `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svgData)))}`;
    } catch (e: any) {
      onShowToast?.(`❌ Export failed: ${e.message || 'Error'}`);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `JUHNKRIX MUSIKA - ${currentRail.name} Donation`,
          text: `Receive dynamic payment of ${amount} ${currentRail.symbol} for ${donorMemo}`,
          url: payloadString
        });
        onShowToast?.('✓ Payment QR Link shared successfully!');
      } catch {
        handleCopyPayload();
      }
    } else {
      handleCopyPayload();
    }
  };

  // Simulate incoming payment from mobile bank or crypto wallet
  const handleSimulatePaymentInflow = () => {
    setIsSimulatingPayment(true);
    setSimulatedSuccess(null);

    setTimeout(() => {
      setIsSimulatingPayment(false);
      const amtNum = Number(amount) || 10;
      const refId = `QR-${Date.now().toString(36).toUpperCase()}`;

      // Deposit into imsiEngine wallet
      if (currentRail.category === 'CRYPTO') {
        const satsToAdd = selectedRail === 'BTC' ? Math.round(amtNum * 100000000) : 50000;
        imsiEngine.depositDirectCredit({
          btcSats: satsToAdd,
          source: `QR Inbound (${currentRail.symbol})`,
          note: `Incoming ${currentRail.name} QR Payment (${refId}) - ${donorMemo}`
        });
      } else {
        const cashToAdd = selectedRail === 'NIBSS_NQR' ? amtNum : amtNum * 1550;
        imsiEngine.depositDirectCredit({
          cashNgn: cashToAdd,
          source: `Instant Mobile Bank (${currentRail.symbol})`,
          note: `Instant Mobile Bank Settlement (${currentRail.name} ${refId}) - ${donorMemo}`
        });
      }

      setSimulatedSuccess(`Received +${amount} ${currentRail.symbol} (${currentRail.name}) into Sovereign Vault! Ref: ${refId}`);
      onShowToast?.(`🎉 Instant Inflow Confirmed! +${amount} ${currentRail.symbol} added to Treasury.`);

      setTimeout(() => setSimulatedSuccess(null), 5000);
    }, 1500);
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <QrCode className="w-4 h-4 text-amber-400" />
            <span>INSTANT QR PAYMENT & DONATION GENERATOR</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Dynamic Multi-Rail QR Inflow Engine
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Generate standard-compliant payment QR codes for Bitcoin (BIP-21), Ethereum (EIP-681), Solana Pay, and global mobile banking (EMVCo NIBSS, SEPA EPC, UK Faster, Zelle/FedNow).
          </p>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex rounded-2xl bg-slate-950 p-1.5 border border-amber-500/30 shrink-0">
          <button
            onClick={() => {
              setActiveCategory('CRYPTO');
              setSelectedRail('BTC');
              setAmount('0.005');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeCategory === 'CRYPTO'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Crypto Rails (5)</span>
          </button>

          <button
            onClick={() => {
              setActiveCategory('BANKING');
              setSelectedRail('NIBSS_NQR');
              setAmount('5000');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeCategory === 'BANKING'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Mobile Banking (5)</span>
          </button>
        </div>
      </div>

      {/* Payment Rail Badges Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
        {PAYMENT_RAILS.filter((r) => r.category === activeCategory).map((rail) => {
          const isSelected = selectedRail === rail.id;
          return (
            <button
              key={rail.id}
              onClick={() => {
                setSelectedRail(rail.id);
                // Adjust default amount appropriately
                if (rail.id === 'BTC') setAmount('0.005');
                else if (rail.id === 'ETH') setAmount('0.05');
                else if (rail.id === 'SOL') setAmount('1.0');
                else if (rail.id === 'USDT') setAmount('50');
                else if (rail.id === 'CVT') return setAmount('50');
                else if (rail.id === 'NIBSS_NQR') setAmount('5000');
                else if (rail.id === 'SEPA_EUR') setAmount('50');
                else if (rail.id === 'UK_FASTER') setAmount('30');
                else if (rail.id === 'US_ZELLE_WIRE') setAmount('100');
                else if (rail.id === 'UPI_GLOBAL') setAmount('2500');
              }}
              className={`p-3 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between group cursor-pointer ${
                isSelected
                  ? 'bg-slate-900 border-amber-400 shadow-lg shadow-amber-500/20 scale-102 ring-1 ring-amber-400'
                  : 'bg-slate-950/70 border-slate-800 hover:border-amber-500/40 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="flex justify-between items-start mb-1.5">
                <span className="text-base">{rail.icon}</span>
                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-md ${
                  isSelected ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {rail.symbol}
                </span>
              </div>
              <div>
                <p className={`text-xs font-black truncate ${isSelected ? 'text-amber-200' : 'text-slate-300'}`}>
                  {rail.name}
                </p>
                <p className="text-[9px] text-slate-500 truncate">{rail.subName}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Generator Core: Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: QR Code Display & Quick Actions (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-950/90 border-2 border-amber-500/30 rounded-3xl p-6 flex flex-col items-center text-center space-y-4 shadow-xl relative overflow-hidden">
          <div className="w-full flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="font-bold text-amber-300 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{currentRail.name}</span>
            </span>
            <span className="text-[10px] font-mono text-emerald-400">Live Dynamic QR</span>
          </div>

          {/* QR Code Container with High-Contrast Canvas Framing */}
          <div
            ref={qrContainerRef}
            className="p-4 bg-white rounded-3xl shadow-2xl shadow-amber-500/20 border-4 border-amber-400/80 relative flex items-center justify-center group"
          >
            <QRCodeSVG
              value={payloadString}
              size={220}
              level="H"
              includeMargin={true}
              fgColor="#030712"
              bgColor="#ffffff"
              imageSettings={{
                src: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=80&q=80',
                x: undefined,
                y: undefined,
                height: 38,
                width: 38,
                excavate: true
              }}
            />
          </div>

          <div className="space-y-1">
            <div className="text-lg font-black text-amber-200 font-serif">
              {amount} {currentRail.symbol}
            </div>
            <p className="text-xs text-slate-300 font-medium line-clamp-1">
              "{donorMemo}"
            </p>
            <p className="text-[10px] text-slate-500 font-mono">
              Standard: {currentRail.standard}
            </p>
          </div>

          {/* Export & Action Buttons */}
          <div className="grid grid-cols-3 gap-2 w-full pt-2">
            <button
              onClick={handleCopyPayload}
              className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center space-x-1 transition-all"
              title="Copy Raw Payment URI Payload"
            >
              {copiedPayload ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedPayload ? 'Copied' : 'Payload'}</span>
            </button>

            <button
              onClick={handleDownloadQrPng}
              className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center justify-center space-x-1 transition-all"
              title="Download QR as High-Res PNG"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>PNG</span>
            </button>

            <button
              onClick={handleShare}
              className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-cyan-300 border border-cyan-500/30 text-xs font-bold flex items-center justify-center space-x-1 transition-all"
              title="Share QR Code Link"
            >
              <Share2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Share</span>
            </button>
          </div>
        </div>

        {/* Right Column: Customization Inputs & Test Inflow Simulator (7 Cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Amount Form & Presets */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-5 space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                <DollarSign className="w-4 h-4 text-amber-400" />
                <span>Requested Inflow Amount ({currentRail.symbol}):</span>
              </label>
              <span className="text-[10px] text-amber-400 font-mono">
                {currentRail.name}
              </span>
            </div>

            <div className="relative">
              <input
                type="text"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount..."
                className="w-full bg-slate-950 border-2 border-amber-500/40 focus:border-amber-400 rounded-2xl px-4 py-3 text-lg font-black text-amber-100 focus:outline-none"
              />
              <span className="absolute right-4 top-3.5 text-sm font-bold text-amber-400">
                {currentRail.symbol}
              </span>
            </div>

            {/* Quick Amount Presets */}
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="text-[10px] font-bold text-slate-400 self-center">Presets:</span>
              {getPresets().map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAmount(preset)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    amount === preset
                      ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                      : 'bg-slate-950 text-slate-300 hover:text-amber-200 border border-slate-800'
                  }`}
                >
                  {preset} {currentRail.symbol}
                </button>
              ))}
            </div>
          </div>

          {/* Memo & Donor Customization */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-5 space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">
                Purpose / Prophetic Memo Reference:
              </label>
              <input
                type="text"
                value={donorMemo}
                onChange={(e) => setDonorMemo(e.target.value)}
                placeholder="e.g. Kingdom Broadcast Tithe & Offering"
                className="w-full bg-slate-950 border border-amber-500/30 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">
                Designated Vault Address / Settlement Account:
              </label>
              <div className="flex items-center space-x-2">
                <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-amber-300 font-mono truncate">
                  {currentRail.defaultAddress}
                </div>
                <button
                  onClick={handleCopyAddress}
                  className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-200 rounded-xl text-xs font-bold flex items-center space-x-1 transition-colors shrink-0"
                >
                  {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAddress ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Simulated Inflow Trigger Engine */}
          <div className="bg-slate-950 border-2 border-emerald-500/40 rounded-3xl p-5 space-y-3 shadow-xl">
            <div className="flex justify-between items-center">
              <span className="text-xs font-black text-emerald-300 uppercase tracking-wider flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Instant Inflow Settlement Simulator</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Test Gateway</span>
            </div>

            <p className="text-xs text-slate-300">
              Simulate an instant customer or partner scan that verifies this dynamic QR code and immediately credits the JUHNKRIX MUSIKA Treasury ledger.
            </p>

            {simulatedSuccess && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-500/60 rounded-2xl flex items-center space-x-2 text-xs text-emerald-200 animate-fadeIn">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-bold">{simulatedSuccess}</span>
              </div>
            )}

            <button
              onClick={handleSimulatePaymentInflow}
              disabled={isSimulatingPayment}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-102 cursor-pointer disabled:opacity-50"
            >
              {isSimulatingPayment ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>PROCESSING INCOMING PAYMENT SCAN...</span>
                </>
              ) : (
                <>
                  <ArrowDownLeft className="w-4 h-4 text-slate-950" />
                  <span>SIMULATE INSTANT {amount} {currentRail.symbol} SCAN & DEPOSIT</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
