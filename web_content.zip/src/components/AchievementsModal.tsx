import React from 'react';
import { ACHIEVEMENTS } from '../data/achievements';
import { SaveData } from '../types/game';
import { X, Award, CheckCircle, Coins } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface AchievementsModalProps {
  saveData: SaveData;
  onClaimAchievement: (id: string, coins: number) => void;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  saveData,
  onClaimAchievement,
  onClose
}) => {
  const completedMap = saveData.achievements || {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              ACHIEVEMENTS
            </h2>
            <p className="text-xs text-slate-400">
              Complete milestones to earn bonus Chroma Coins
            </p>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of achievements */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
          {ACHIEVEMENTS.map((ach) => {
            const isCompleted = Boolean(completedMap[ach.id]);

            return (
              <div
                key={ach.id}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition-all ${
                  isCompleted
                    ? 'bg-slate-950/80 border-amber-500/30'
                    : 'bg-slate-950/40 border-slate-800/80 opacity-70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-lg shrink-0">
                    {ach.icon}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{ach.title}</span>
                      {isCompleted && (
                        <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                      )}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      {ach.description}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono text-xs font-bold">
                  <Coins className="w-3.5 h-3.5" />
                  <span>+{ach.coinReward}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
