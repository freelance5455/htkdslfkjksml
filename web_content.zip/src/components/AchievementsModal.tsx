import React from 'react';
import { Achievement } from '../types';
import { X, Award, CheckCircle, Coins } from 'lucide-react';

interface AchievementsModalProps {
  achievements: Achievement[];
  onClaimAchievement: (achievementId: string) => void;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  achievements,
  onClaimAchievement,
  onClose,
}) => {
  const completedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col max-h-[90vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5 text-rose-400" />
            <h2 className="text-lg font-black text-white">ACHIEVEMENTS</h2>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Progress summary banner */}
        <div className="my-3 flex items-center justify-between rounded-2xl bg-slate-950/70 px-4 py-2.5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400">UNLOCKED</span>
          <span className="font-mono text-sm font-black text-amber-300">
            {completedCount} / {achievements.length}
          </span>
        </div>

        {/* List of achievements */}
        <div className="flex flex-col gap-2.5 overflow-y-auto no-scrollbar py-1">
          {achievements.map((item) => {
            const isCompleted = item.progress >= item.maxProgress;
            const progressPct = Math.min(100, (item.progress / item.maxProgress) * 100);

            return (
              <div
                key={item.id}
                className={`flex items-center justify-between rounded-2xl p-3 border transition-all ${
                  item.unlocked
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-80'
                    : isCompleted
                    ? 'bg-emerald-950/30 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                {/* Icon & Details */}
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-800/90 text-2xl border border-slate-700/60 shadow-inner">
                    {item.icon}
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs font-bold text-white leading-tight">
                      {item.title}
                    </span>
                    <span className="text-[10px] text-slate-400 leading-tight mt-0.5 max-w-[145px]">
                      {item.description}
                    </span>
                    {/* Micro progress bar */}
                    {!item.unlocked && (
                      <div className="mt-1.5 h-1.5 w-24 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 transition-all duration-200"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Status or Claim Button */}
                <div>
                  {item.unlocked ? (
                    <div className="flex items-center gap-1 text-emerald-400 text-xs font-bold px-2 py-1 bg-emerald-500/10 rounded-xl">
                      <CheckCircle className="h-3.5 w-3.5" />
                      <span>Claimed</span>
                    </div>
                  ) : isCompleted ? (
                    <button
                      onClick={() => onClaimAchievement(item.id)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all hover:brightness-110"
                    >
                      <Coins className="h-3 w-3" />
                      <span>+{item.rewardCoins}</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1 text-slate-500 text-[11px] font-mono font-bold">
                      <Coins className="h-3 w-3" />
                      <span>+{item.rewardCoins}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
