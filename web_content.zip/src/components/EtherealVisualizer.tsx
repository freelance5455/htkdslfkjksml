import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../lib/audioEngine';

interface EtherealVisualizerProps {
  isPlaying: boolean;
  synthPreset?: string;
}

export const EtherealVisualizer: React.FC<EtherealVisualizerProps> = ({ isPlaying, synthPreset = '528hz' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const analyser = audioEngine.getAnalyser();

    const dataArray = new Uint8Array(64);

    const render = () => {
      animationId = requestAnimationFrame(render);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!isPlaying) return;

      if (analyser) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        // Fallback fake wave data
        for (let i = 0; i < dataArray.length; i++) {
          dataArray[i] = Math.floor(Math.abs(Math.sin(Date.now() * 0.003 + i * 0.2)) * 180) + 40;
        }
      }

      const barWidth = (canvas.width / 32);
      let x = 0;

      for (let i = 0; i < 32; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.8;

        const gradient = ctx.createLinearGradient(0, canvas.height, 0, 0);
        if (synthPreset === 'warfare') {
          gradient.addColorStop(0, 'rgba(244, 63, 94, 0.2)');
          gradient.addColorStop(1, 'rgba(244, 63, 94, 0.8)');
        } else if (synthPreset === 'angelic') {
          gradient.addColorStop(0, 'rgba(56, 189, 248, 0.2)');
          gradient.addColorStop(1, 'rgba(56, 189, 248, 0.8)');
        } else {
          gradient.addColorStop(0, 'rgba(245, 158, 11, 0.2)');
          gradient.addColorStop(1, 'rgba(251, 191, 36, 0.8)');
        }

        ctx.fillStyle = gradient;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 2, barHeight);

        x += barWidth;
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, synthPreset]);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30 rounded-3xl">
      <canvas
        ref={canvasRef}
        width={600}
        height={200}
        className="w-full h-full object-cover filter blur-[1px]"
      />
    </div>
  );
};
