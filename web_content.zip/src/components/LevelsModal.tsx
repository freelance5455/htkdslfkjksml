import React, { useState } from 'react';
import { X, Star, Lock, Play, CheckCircle2, Gift } from 'lucide-react';
import { LevelConfig, DailyMission, Achievement } from '../types/game';
import { GAME_LEVELS } from '../game/levelsData';

interface LevelsModalProps {
  currentLevel: number;
  completedLevels: number[];
  levelStars: Record<number, number>;
  dailyMissions: DailyMission[];
  achievements: Achievement[];
  onSelectLevel: (level: LevelConfig) => void;
  onClaimMissionReward: (missionId: string) => void;
  onClose: () => void;
}

export const LevelsModal: React.FC<LevelsModalProps> = ({
  currentLevel,
  completedLevels,
  levelStars,
  dailyMissions,
  achievements,
  onSelectLevel,
  onClaimMissionReward,
  onClose
}) => {
  const [tab, setTab] = useState<'levels' | 'missions' | 'achievements'>('levels');

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-3xl h-[88vh] max-h-[750px] shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-xl">
              🗺️
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">المراحل والمهام اليومية</h2>
              <div className="text-xs text-slate-400">انطلق في شوارع متنوعة واجمع النجوم والمكافآت الحصرية</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-2 gap-2 text-xs md:text-sm font-bold">
          <button
            onClick={() => setTab('levels')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'levels' ? 'bg-emerald-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🏙️ مراحل الشوارع
          </button>
          <button
            onClick={() => setTab('missions')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'missions' ? 'bg-emerald-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🎯 مهام يومية
          </button>
          <button
            onClick={() => setTab('achievements')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'achievements' ? 'bg-emerald-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🏆 الإنجازات
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {tab === 'levels' && (
            <div className="space-y-3">
              {GAME_LEVELS.map((lvl) => {
                const isUnlocked = lvl.id === 1 || completedLevels.includes(lvl.id - 1) || lvl.unlocked;
                const isCurrent = currentLevel === lvl.id;
                const stars = levelStars[lvl.id] || 0;

                return (
                  <div
                    key={lvl.id}
                    className={`bg-slate-900 border rounded-2xl p-4 flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'border-emerald-400 shadow-md bg-emerald-950/20'
                        : isUnlocked
                        ? 'border-slate-800 hover:border-slate-700'
                        : 'border-slate-900 opacity-60'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl border ${
                          isUnlocked
                            ? 'bg-gradient-to-br from-emerald-500 to-teal-700 text-white border-emerald-400'
                            : 'bg-slate-800 text-slate-500 border-slate-700'
                        }`}
                      >
                        {isUnlocked ? lvl.id : <Lock className="w-5 h-5" />}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-white text-base">{lvl.title}</h3>
                          {/* Stars */}
                          {isUnlocked && (
                            <div className="flex items-center gap-0.5">
                              {[1, 2, 3].map((s) => (
                                <Star
                                  key={s}
                                  className={`w-3.5 h-3.5 ${
                                    s <= stars ? 'fill-amber-400 text-amber-300' : 'text-slate-700'
                                  }`}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">{lvl.subtitle}</p>
                        <div className="text-[11px] text-amber-400 font-bold mt-1">
                          الهدف: {lvl.targetDistance}م مسافة + {lvl.targetCoins} عملة ذهبية
                        </div>
                      </div>
                    </div>

                    <div>
                      {isUnlocked ? (
                        <button
                          onClick={() => {
                            onSelectLevel(lvl);
                            onClose();
                          }}
                          className="py-2 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-slate-950" />
                          <span>ابدأ المرحلة</span>
                        </button>
                      ) : (
                        <div className="text-xs text-slate-500 font-bold flex items-center gap-1">
                          <Lock className="w-3.5 h-3.5" />
                          <span>أكمل السابقة</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'missions' && (
            <div className="space-y-3">
              {dailyMissions.map((m) => {
                const progress = Math.min(100, Math.floor((m.current / m.target) * 100));

                return (
                  <div key={m.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div className="flex-1 pr-3">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-bold text-white text-sm">{m.title}</h4>
                        <span className="text-xs text-amber-400 font-bold">
                          +{m.rewardCoins} 🪙 {m.rewardGems > 0 && `+${m.rewardGems} 💎`}
                        </span>
                      </div>

                      <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800 my-1.5">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all"
                          style={{ width: `${progress}%` }}
                        />
                      </div>

                      <div className="text-[11px] text-slate-400">
                        التقدم: {m.current} / {m.target}
                      </div>
                    </div>

                    <div>
                      {m.claimed ? (
                        <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>تم الاستلام</span>
                        </span>
                      ) : m.completed ? (
                        <button
                          onClick={() => onClaimMissionReward(m.id)}
                          className="py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 active:scale-95 transition-all shadow-md cursor-pointer animate-pulse"
                        >
                          <Gift className="w-3.5 h-3.5" />
                          <span>استلام المكافأة</span>
                        </button>
                      ) : (
                        <span className="text-xs text-slate-500 font-bold">قيد التقدم</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'achievements' && (
            <div className="space-y-3">
              {achievements.map((ach) => {
                const progress = Math.min(100, Math.floor((ach.current / ach.target) * 100));

                return (
                  <div key={ach.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div className="flex-1 pr-3">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-bold text-white text-sm">{ach.title}</h4>
                        <span className="text-xs text-cyan-400 font-bold">+{ach.rewardGems} 💎</span>
                      </div>
                      <p className="text-xs text-slate-400 mb-1.5">{ach.description}</p>
                      <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-xs font-bold text-slate-400">
                      {ach.completed ? '🏆 مكتمل' : `${ach.current} / ${ach.target}`}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
