import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  X, 
  Send, 
  Bot, 
  User, 
  Loader2, 
  Radio, 
  Compass,
  Zap
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { handleVoiceIntent } from '../../utils/aiIntentHandler';

interface AiVoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (tab: string) => void;
  initialQuery?: string;
}

interface Message {
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export const AiVoiceAssistantModal: React.FC<AiVoiceAssistantModalProps> = ({ isOpen, onClose, onNavigate, initialQuery }) => {
  const { currentUser } = useApp();
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: "Hi! I'm Earnie, your AI Voice Assistant. You can say things like 'Open wallet', 'Start task', or 'Go to games' and I'll take you there instantly!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && initialQuery) {
      // Trigger query execution after a short mount buffer
      const timer = setTimeout(() => {
        handleSendMessage(initialQuery);
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [isOpen, initialQuery]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Speech Recognition Setup
  const recognitionRef = useRef<any>(null);
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputQuery(transcript);
        setIsListening(false);
        handleSendMessage(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. Please type your message.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        setIsListening(true);
        recognitionRef.current.start();
      } catch (err) {
        setIsListening(false);
      }
    }
  };

  const speakText = (text: string) => {
    if (!isVoiceEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.1;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend !== undefined ? textToSend : inputQuery;
    if (!query.trim()) return;

    const userMsg: Message = {
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (textToSend === undefined) setInputQuery('');
    setLoading(true);

    // 1. Check Centralized Local Intent Handler first for instant zero-latency navigation
    const localIntent = handleVoiceIntent(query);
    if (localIntent.action === 'navigate' && localIntent.tab && onNavigate) {
      const aiReply = `${localIntent.spokenFeedback} Navigating now!`;
      const aiMsg: Message = {
        sender: 'ai',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, aiMsg]);
      setLoading(false);
      speakText(aiReply);

      const targetTab = localIntent.tab;
      setTimeout(() => {
        onNavigate(targetTab);
        onClose();
      }, 1500);
      return;
    }

    // 2. Fall back to Server-side Gemini AI Intent & Response
    try {
      const context = {
        userName: currentUser?.name || currentUser?.email || 'User',
        coins: currentUser?.coins || 0,
        membershipTier: currentUser?.membershipTier || 'basic',
        packageName: 'com.subhodip.taskearnpro',
        version: '2.4.0'
      };

      const res = await fetch('/api/ai-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query, context })
      });

      const data = await res.json();
      const aiReply = data.reply || "I'm ready to help you complete tasks and earn coins!";
      const intent = data.intent;

      const aiMsg: Message = {
        sender: 'ai',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, aiMsg]);
      setLoading(false);
      speakText(aiReply);

      // Handle Server Navigation Intent
      if (intent && intent.action === 'navigate' && intent.tab && onNavigate) {
        const targetTab = intent.tab;
        setTimeout(() => {
          onNavigate(targetTab);
          onClose();
        }, 1800);
      }
    } catch (err) {
      setLoading(false);
      const errorMsg: Message = {
        sender: 'ai',
        text: "I'm having trouble connecting right now. Please check your network and try again!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-indigo-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[600px] text-white">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-indigo-900/80 via-purple-900/80 to-slate-900 border-b border-indigo-500/20">
          <div className="flex items-center space-x-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 shadow-lg shadow-indigo-500/30">
              <Bot className="w-6 h-6 text-white animate-pulse" />
              {isSpeaking && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2">
                Earnie AI Voice
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 rounded-full border border-indigo-500/30">
                  Intent Handler
                </span>
              </h2>
              <p className="text-xs text-indigo-200/70">Say "Open wallet" or "Start task"</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                setIsVoiceEnabled(!isVoiceEnabled);
                if (isSpeaking) stopSpeaking();
              }}
              title={isVoiceEnabled ? 'Mute AI Voice' : 'Enable AI Voice'}
              className={`p-2 rounded-xl transition-all ${isVoiceEnabled ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'bg-slate-800 text-slate-400'}`}
            >
              {isVoiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
            <button
              onClick={() => {
                stopSpeaking();
                onClose();
              }}
              className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-950/50">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex items-start space-x-3 ${msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}
            >
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white'
                    : 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              <div
                className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-600/20'
                    : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700/60 shadow-md'
                }`}
              >
                <p>{msg.text}</p>
                <span className={`block text-[10px] mt-1 ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-800 px-4 py-3 rounded-2xl rounded-tl-none border border-slate-700/60 text-slate-400 text-sm flex items-center space-x-2">
                <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Earnie is routing intent...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex gap-2 overflow-x-auto no-scrollbar">
          {[
            'Open wallet',
            'Start task',
            'Go to VIP',
            'Open games',
            'My profile',
            'Membership'
          ].map((suggestion, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(suggestion)}
              className="px-3 py-1 bg-slate-800 hover:bg-indigo-600/30 border border-slate-700/60 hover:border-indigo-500/40 rounded-full text-xs text-slate-300 hover:text-indigo-200 whitespace-nowrap transition-all flex items-center gap-1.5"
            >
              <Compass className="w-3 h-3 text-indigo-400" />
              {suggestion}
            </button>
          ))}
        </div>

        {/* Footer / Input Bar */}
        <div className="p-4 bg-slate-900 border-t border-indigo-500/20 flex items-center space-x-3">
          <button
            onClick={toggleListening}
            className={`relative p-3 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
              isListening
                ? 'bg-red-500 text-white shadow-red-500/40 animate-pulse'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
            }`}
            title={isListening ? 'Listening... Tap to stop' : 'Tap to speak'}
          >
            {isListening ? <Radio className="w-6 h-6 animate-spin" /> : <Mic className="w-6 h-6" />}
          </button>

          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={isListening ? 'Listening to voice intent...' : 'Say "Open wallet", "Start task"...'}
            className="flex-1 px-4 py-3 bg-slate-950 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!inputQuery.trim() || loading}
            className="p-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 text-white rounded-xl shadow-lg shadow-indigo-600/30 transition-all"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

      </div>
    </div>
  );
};
