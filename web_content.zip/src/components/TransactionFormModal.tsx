import React, { useState, useEffect } from 'react';
import { X, ArrowUpRight, ArrowDownLeft, AlertCircle, Receipt, Plus } from 'lucide-react';
import { Product, StoreData, Transaction, TransactionType, PaymentMethod } from '../types';
import { formatMoney, getTodayIso } from '../utils/formatters';
import { feedback } from '../utils/haptics';

interface TransactionFormModalProps {
  type: TransactionType; // 'S' or 'P'
  initialProductId?: string;
  transaction?: Transaction | null;
  store: StoreData;
  calculatedStock: Record<string, { qty: number }>;
  isOpen: boolean;
  onClose: () => void;
  onSave: (txnData: Omit<Transaction, 'id'>, existingId?: string, openReceipt?: boolean) => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const TransactionFormModal: React.FC<TransactionFormModalProps> = ({
  type,
  initialProductId,
  transaction,
  store,
  calculatedStock,
  isOpen,
  onClose,
  onSave,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const isSale = type === 'S';

  const [date, setDate] = useState('');
  const [pid, setPid] = useState('');
  const [qty, setQty] = useState('');
  const [rate, setRate] = useState('');
  const [cust, setCust] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    if (transaction) {
      setDate(transaction.date);
      setPid(transaction.pid);
      setQty(String(transaction.qty));
      setRate(String(transaction.rate));
      setCust(transaction.cust || '');
      setPaymentMethod(transaction.paymentMethod || 'cash');
      setNote(transaction.note || '');
    } else {
      const defaultPid = initialProductId || (store.products[0]?.id || '');
      const prod = store.products.find((p) => p.id === defaultPid);
      setDate(getTodayIso());
      setPid(defaultPid);
      setQty('1');
      setRate(prod ? String(isSale ? prod.price : prod.cost) : '0');
      setCust('');
      setPaymentMethod(isSale ? 'cash' : 'upi');
      setNote('');
    }
    setError(null);
  }, [isOpen, transaction, initialProductId, store.products, isSale]);

  // When changing product, update default rate
  const handleProductChange = (newPid: string) => {
    setPid(newPid);
    const prod = store.products.find((p) => p.id === newPid);
    if (prod) {
      setRate(String(isSale ? prod.price : prod.cost));
    }
  };

  const selectedProduct = store.products.find((p) => p.id === pid);
  const currentStock = selectedProduct ? (calculatedStock[selectedProduct.id]?.qty ?? selectedProduct.open) : 0;
  const qtyNum = parseFloat(qty) || 0;
  const rateNum = parseFloat(rate) || 0;
  const total = qtyNum * rateNum;

  // Autocomplete suggestions
  const customerSuggestions = Array.from(
    new Set(
      store.txns
        .filter((t) => (isSale ? t.type === 'S' : t.type === 'P') && t.cust)
        .map((t) => t.cust as string)
    )
  ).slice(0, 10);

  const handleSubmit = (viewReceipt: boolean) => {
    if (!pid) {
      setError('Please select an item.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    if (!date) {
      setError('Please pick a date.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    if (isNaN(qtyNum) || qtyNum <= 0) {
      setError('Quantity must be greater than 0.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    if (isNaN(rateNum) || rateNum < 0) {
      setError('Rate must be 0 or more.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    // Warning for negative stock on sale, but allowed for backorders with warning
    if (isSale && !transaction && qtyNum > currentStock) {
      feedback.vibrateWarning(hapticsEnabled);
    }

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    feedback.vibrateSuccess(hapticsEnabled);
    feedback.playSuccess(soundEnabled);

    onSave(
      {
        date,
        time: transaction?.time || timeStr,
        pid,
        type,
        qty: qtyNum,
        rate: rateNum,
        cust: cust.trim() || undefined,
        paymentMethod,
        note: note.trim() || undefined,
      },
      transaction?.id,
      viewReceipt
    );

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div
          className={`p-4 text-white flex items-center justify-between ${
            isSale ? 'bg-emerald-700' : 'bg-blue-700'
          }`}
        >
          <div className="flex items-center gap-2">
            {isSale ? (
              <ArrowUpRight className="w-5 h-5 bg-white/20 rounded-full p-0.5" />
            ) : (
              <ArrowDownLeft className="w-5 h-5 bg-white/20 rounded-full p-0.5" />
            )}
            <h3 className="font-bold text-sm tracking-tight">
              {transaction
                ? `Edit ${isSale ? 'Sale (Stock Out)' : 'Purchase (Stock In)'}`
                : `New ${isSale ? 'Sale (Stock Out)' : 'Purchase (Stock In)'}`}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-full bg-white/20 hover:bg-white/30 text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        {store.products.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <p className="text-slate-600 dark:text-slate-300 text-xs">
              Your inventory catalog is currently empty. Please add a product first before recording a sale or purchase.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs transition"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="p-5 overflow-y-auto space-y-3.5 text-xs">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Product Selector */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Item *
              </label>
              {selectedProduct && (
                <span
                  className={`text-[11px] font-medium ${
                    currentStock <= selectedProduct.min
                      ? 'text-red-600 dark:text-red-400 font-bold'
                      : 'text-slate-500'
                  }`}
                >
                  In stock: {currentStock} {selectedProduct.unit}
                </span>
              )}
            </div>

            <select
              value={pid}
              onChange={(e) => handleProductChange(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            >
              {store.products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.unit}) — {isSale ? `Price ${formatMoney(p.price, store.cur)}` : `Cost ${formatMoney(p.cost, store.cur)}`}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity & Quick Increment Buttons */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Quantity {selectedProduct ? `(${selectedProduct.unit})` : ''} *
              </label>
              <div className="flex gap-1">
                {[1, 5, 10, 50].map((inc) => (
                  <button
                    key={inc}
                    type="button"
                    onClick={() => {
                      const cur = parseFloat(qty) || 0;
                      setQty(String(cur + inc));
                      feedback.vibrateSoft(hapticsEnabled);
                    }}
                    className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[10px] font-semibold text-slate-700 dark:text-slate-300 transition"
                  >
                    +{inc}
                  </button>
                ))}
              </div>
            </div>

            <input
              type="number"
              step="any"
              min="0.01"
              required
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              placeholder="1"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-semibold focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>

          {/* Rate & Subtotal */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {isSale ? 'Selling Rate / Unit' : 'Cost Rate / Unit'} ({store.cur}) *
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Customer / Supplier Name */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {isSale ? 'Customer Name' : 'Supplier / Vendor Name'}
            </label>
            <input
              type="text"
              list="cust-suggestions"
              value={cust}
              onChange={(e) => setCust(e.target.value)}
              placeholder={isSale ? 'e.g. Ramesh Sharma / Walk-in' : 'e.g. Apex Wholesale Supplies'}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
            <datalist id="cust-suggestions">
              {customerSuggestions.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Payment Method
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  ['cash', 'Cash'],
                  ['upi', 'UPI / GPay'],
                  ['card', 'Card'],
                  ['credit', 'Due / Credit'],
                ] as const
              ).map(([m, label]) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setPaymentMethod(m);
                    feedback.vibrateSoft(hapticsEnabled);
                  }}
                  className={`py-1.5 px-1 rounded-xl text-center text-[11px] font-semibold transition ${
                    paymentMethod === m
                      ? isSale
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Note / Reference (Optional)
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Bill #104 / Delivered via courier"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>

          {/* Total Calculation Card */}
          <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-slate-500 font-medium">Grand Total</div>
              <div className="text-xs text-slate-600 dark:text-slate-300">
                {qtyNum} × {formatMoney(rateNum, store.cur)}
              </div>
            </div>
            <div className={`text-lg font-black ${isSale ? 'text-emerald-600 dark:text-emerald-400' : 'text-blue-600 dark:text-blue-400'}`}>
              {formatMoney(total, store.cur)}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col gap-2">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSubmit(false)}
                className={`flex-1 py-2.5 rounded-xl text-white font-semibold shadow-sm transition active:scale-98 ${
                  isSale ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                Save Entry
              </button>
            </div>

            {/* Save & View Receipt option */}
            <button
              type="button"
              onClick={() => handleSubmit(true)}
              className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition active:scale-98"
            >
              <Receipt className="w-3.5 h-3.5 text-red-400" />
              Save & Print / View Receipt Slip
            </button>
          </div>
        </div>
      )}
    </div>
  </div>
);
};
