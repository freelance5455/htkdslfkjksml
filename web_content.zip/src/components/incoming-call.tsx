import { Avatar } from "@/components/avatar";
import { Button } from "@/components/ui/button";
import { formatPhone } from "@/lib/emergency";
import { useAppStore } from "@/lib/store";
import { Phone, PhoneOff, AudioLines } from "lucide-react";

export function IncomingCall() {
  const live = useAppStore((s) => s.live);
  const contacts = useAppStore((s) => s.contacts);
  const answerIncoming = useAppStore((s) => s.answerIncoming);
  const lisaHandleIncoming = useAppStore((s) => s.lisaHandleIncoming);
  const rejectIncoming = useAppStore((s) => s.rejectIncoming);
  const decideLisaAccess = useAppStore((s) => s.decideLisaAccess);

  if (!live || live.status !== "ringing") return null;

  const contact = contacts.find((c) => c.id === live.contactId);
  const access = decideLisaAccess({
    number: live.number,
    known: live.known,
    policy: contact?.policy,
  });
  const showLisa = access.allowed && !live.emergency;

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-background px-6 pt-[max(1.5rem,env(safe-area-inset-top))] pb-[max(1.5rem,env(safe-area-inset-bottom))]">
      <p className="text-center text-[0.7rem] font-medium tracking-[0.22em] text-muted-foreground uppercase">
        Lisa Call
      </p>
      <p className="mt-2 text-center text-sm text-muted-foreground">Incoming call</p>

      <div className="flex flex-1 flex-col items-center justify-center">
        <div className="relative mb-8 size-24">
          <span className="ring-soft absolute inset-0 rounded-full border border-accent/40" />
          <span className="ring-soft absolute -inset-3 rounded-full border border-accent/25 [animation-delay:400ms]" />
          <Avatar name={live.name} size="xl" />
        </div>
        <h1 className="text-3xl font-medium tracking-tight">{live.name}</h1>
        <p className="mt-2 text-muted-foreground">{formatPhone(live.number)}</p>
        <p className="mt-3 text-xs tracking-wide text-subtle uppercase">
          {live.emergency
            ? "Emergency — Lisa will not handle this"
            : live.known
              ? "Known contact"
              : "Unknown caller"}
        </p>
      </div>

      <div className="space-y-3">
        {showLisa ? (
          <Button variant="primary" size="xl" className="w-full" onClick={lisaHandleIncoming}>
            <AudioLines className="size-5" />
            Lisa Handles
          </Button>
        ) : null}
        <div className="grid grid-cols-2 gap-3">
          <Button variant="success" size="xl" onClick={answerIncoming}>
            <Phone className="size-5" />
            Answer
          </Button>
          <Button variant="danger" size="xl" onClick={rejectIncoming}>
            <PhoneOff className="size-5" />
            Reject
          </Button>
        </div>
        {!showLisa && contact?.policy === "always_myself" ? (
          <p className="text-center text-xs text-muted-foreground">
            This contact is set to always answer yourself.
          </p>
        ) : null}
      </div>
    </div>
  );
}
