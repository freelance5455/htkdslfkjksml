import React from 'react';
import { CreditCard, Crown } from 'lucide-react';
import { formatDateTr } from '../lib/api';
import type { MembershipInfo, NavSection, PaymentRecord } from '../types/studio';

interface PaymentHistoryViewProps {
  payments: PaymentRecord[];
  membership: MembershipInfo;
  onNavigate: (section: NavSection) => void;
}

export const PaymentHistoryView: React.FC<PaymentHistoryViewProps> = ({
  payments,
  membership,
  onNavigate,
}) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Ödemeler ve Faturalar
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Doğrulanmış Premium satın alma işlemlerinizi, uygulanan promosyon indirimlerini ve
            abonelik durumunuzu görüntüleyin.
          </p>
        </div>

        {!membership.isLifetime && (
          <button
            type="button"
            onClick={() => onNavigate('premium')}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-[#EAB308] hover:bg-[#CA8A04] text-[#0B1020] transition-colors whitespace-nowrap shrink-0"
          >
            <Crown className="w-4 h-4" />
            <span>{membership.isPremium ? 'Planı Yükselt' : 'Premium Satın Al'}</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
        {payments.length === 0 ? (
          <div className="p-12 text-center">
            <CreditCard className="w-7 h-7 text-slate-400 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-900 dark:text-[#F8FAFC]">
              Henüz ödeme kaydınız bulunmuyor
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-[#94A3B8]">
              Premium üyelik satın aldığınızda tüm işlem detayları ve referans kodları burada
              listelenir.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.08] text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3.5 px-6">Paket</th>
                  <th className="py-3.5 px-4">Sağlayıcı</th>
                  <th className="py-3.5 px-4">Referans Kodu</th>
                  <th className="py-3.5 px-4">Promosyon</th>
                  <th className="py-3.5 px-4">Durum</th>
                  <th className="py-3.5 px-4 text-right">Tutar</th>
                  <th className="py-3.5 px-6 text-right">Tarih</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                {payments.map((pay) => (
                  <tr key={pay.id} className="hover:bg-slate-50 dark:hover:bg-white/[0.02]">
                    <td className="py-3.5 px-6 font-semibold text-slate-900 dark:text-[#F8FAFC]">
                      {pay.plan_name}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-[#94A3B8]">
                      {pay.is_test_mode ? 'Test / Demo' : pay.provider}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-500 dark:text-[#94A3B8]">
                      {pay.provider_reference}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-600 dark:text-[#CBD5E1]">
                      {pay.discount_try && pay.discount_try > 0
                        ? `-${pay.discount_try} TL`
                        : '—'}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`font-medium ${
                          pay.status === 'completed'
                            ? 'text-[#22C55E]'
                            : pay.status === 'failed'
                            ? 'text-[#EF4444]'
                            : 'text-amber-500'
                        }`}
                      >
                        {pay.status === 'completed'
                          ? 'Onaylandı'
                          : pay.status === 'failed'
                          ? 'Başarısız'
                          : 'Bekliyor'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                      {pay.amount_try.toLocaleString('tr-TR')} {pay.currency}
                    </td>
                    <td className="py-3.5 px-6 text-right tabular-nums text-slate-500 dark:text-[#94A3B8] whitespace-nowrap">
                      {formatDateTr(pay.created_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
