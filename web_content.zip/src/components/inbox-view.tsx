import { useEffect, useState } from "react";
import { format } from "date-fns";
import {
  ALLOWED_SOURCES,
  fileId,
  isDeskMessage,
  SEED_MESSAGES,
  shr2,
  windowRemain,
  type DeskMessage,
} from "@/lib/rax";
import { Eyebrow, FieldLabel, Panel } from "@/components/desk";

const STORAGE_KEY = "rax-inbox-v1";
const RECIPIENTS = ["user1", "ops", "user2"];

function loadStored(): DeskMessage[] | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return null;
    return parsed.filter(isDeskMessage).slice(0, 50);
  } catch {
    return null;
  }
}

function saveStored(messages: DeskMessage[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(0, 50)));
  } catch {
    /* private mode or a full disk — the desk still works in memory */
  }
}

export function InboxView({ now }: { now: number | null }) {
  const [messages, setMessages] = useState<DeskMessage[]>(SEED_MESSAGES);
  const [ready, setReady] = useState(false);
  const [source, setSource] = useState<string>(ALLOWED_SOURCES[0]);
  const [recipient, setRecipient] = useState("user1");
  const [folder, setFolder] = useState("user1");
  const [content, setContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    const stored = loadStored();
    if (stored) setMessages(stored);
    else saveStored(SEED_MESSAGES);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveStored(messages);
  }, [messages, ready]);

  const compact = now === null ? null : shr2(now);
  const remain = now === null ? null : windowRemain(now);
  const whoPreview = recipient.trim();
  const collision =
    compact !== null &&
    messages.some((m) => m.recipient === whoPreview && m.compactId === compact);
  const visible = messages.filter((m) => m.recipient === folder);

  function send() {
    setNotice(null);
    if (!ALLOWED_SOURCES.includes(source as (typeof ALLOWED_SOURCES)[number])) {
      setError("Unauthorized source.");
      return;
    }
    const who = recipient.trim();
    if (!/^[a-zA-Z0-9._-]{1,32}$/.test(who)) {
      setError("Recipient needs 1–32 letters, numbers, dots, dashes, or underscores.");
      return;
    }
    const body = content.trim();
    if (!body) {
      setError("Write a message first.");
      return;
    }
    if (now === null || compact === null) {
      setError("Clock is not ready.");
      return;
    }
    const id = fileId(
      compact,
      messages.filter((m) => m.recipient === who).map((m) => m.id),
    );
    const next: DeskMessage = {
      id,
      compactId: compact,
      source,
      recipient: who,
      content: body,
      at: now,
    };
    setMessages((prev) => [next, ...prev].slice(0, 50));
    setContent("");
    setError(null);
    setFolder(who);
    setNotice(id === String(compact) ? `Filed ${id}.json` : `Window already used. Filed ${id}.json`);
  }

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <Panel className="lg:col-span-2">
        <Eyebrow>File a message</Eyebrow>
        <p className="mt-2 font-mono text-2xl text-fg tabular-nums">
          {compact === null ? "—" : `${compact}.json`}
        </p>
        <p className="mt-1 text-sm text-muted">
          {remain === null ? "Waiting on the clock." : `This id holds for ${remain}s, then the shift moves.`}
        </p>
        {collision ? (
          <p className="mt-3 text-sm text-brass">
            A file in this 4-second window already exists. The next one gets a suffix — the shift
            discarded the bits that would have told them apart.
          </p>
        ) : null}

        <form
          className="mt-5 flex flex-col gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            send();
          }}
        >
          <label className="flex flex-col gap-2">
            <FieldLabel>Source</FieldLabel>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {[ALLOWED_SOURCES[0], "guest@example.com"].map((option) => {
                const selected = source === option;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => {
                      setSource(option);
                      setError(null);
                    }}
                    className={`min-h-11 border px-3 text-left font-mono text-xs ${
                      selected ? "border-brass text-fg" : "border-line text-muted"
                    }`}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          </label>

          <label className="flex flex-col gap-2">
            <FieldLabel>Recipient</FieldLabel>
            <input
              value={recipient}
              onChange={(event) => setRecipient(event.target.value)}
              className="h-11 border border-line bg-bg px-3 font-mono text-sm text-fg"
              autoComplete="off"
              spellCheck={false}
            />
            <div className="flex flex-wrap gap-2">
              {RECIPIENTS.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => setRecipient(name)}
                  className={`min-h-11 border px-3 font-mono text-sm ${
                    recipient === name ? "border-brass text-fg" : "border-line text-muted"
                  }`}
                >
                  {name}
                </button>
              ))}
            </div>
          </label>

          <label className="flex flex-col gap-2">
            <FieldLabel>Content</FieldLabel>
            <textarea
              value={content}
              onChange={(event) => setContent(event.target.value.slice(0, 400))}
              rows={4}
              className="border border-line bg-bg px-3 py-2 text-sm text-fg"
              placeholder="Hello"
            />
          </label>

          {error ? <p className="text-sm text-brass">{error}</p> : null}
          {notice ? <p className="text-sm text-fg">{notice}</p> : null}

          <button
            type="submit"
            className="inline-flex min-h-11 items-center justify-center bg-brass px-4 font-medium text-bg"
          >
            Save message
          </button>
          <p className="text-xs text-muted">Only trusted@example.com may file. Guest is refused.</p>
        </form>
      </Panel>

      <Panel className="lg:col-span-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <Eyebrow>Inbox</Eyebrow>
          <div className="flex flex-wrap gap-2">
            {Array.from(new Set([...RECIPIENTS, ...messages.map((m) => m.recipient)])).map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setFolder(name)}
                className={`min-h-11 border px-3 font-mono text-sm ${
                  folder === name ? "border-brass text-fg" : "border-line text-muted"
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        {visible.length === 0 ? (
          <p className="mt-6 text-sm text-muted">No files for {folder}.</p>
        ) : (
          <ul className="mt-4 flex flex-col">
            {visible.map((message) => (
              <li key={message.id} className="border-t border-line py-4 first:border-t-0">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate font-mono text-sm text-fg">{message.id}.json</p>
                    <p className="mt-1 text-sm text-muted">
                      {message.source} → {message.recipient}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setMessages((prev) => prev.filter((m) => m.id !== message.id))}
                    className="min-h-11 shrink-0 px-2 text-sm text-muted"
                  >
                    Remove
                  </button>
                </div>
                <p className="mt-2 text-sm text-fg">{message.content}</p>
                <p className="mt-2 font-mono text-xs text-muted tabular-nums">
                  {format(new Date(message.at * 1000), "MMM d, HH:mm:ss")} · id {message.compactId}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
