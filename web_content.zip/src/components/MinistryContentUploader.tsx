import React, { useState, useEffect } from 'react';
import { Upload, FileAudio, Video, Image as ImageIcon, CheckCircle2, Shield, HardDrive, Sparkles, AlertCircle, RefreshCw, Trash2, Edit3, Plus, ExternalLink, RotateCcw, Tag, Save, X } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { UploadedMediaItem } from '../types';

interface PendingUploadItem {
  id: string;
  file: File;
  title: string;
  speaker: string;
  datePreached: string;
  description: string;
  tags: string;
  type: 'audio' | 'video' | 'image' | 'document';
  progress: number;
  uploading: boolean;
  completed: boolean;
}

interface MinistryContentUploaderProps {
  onNavigateTab?: (tab: string) => void;
}

export const MinistryContentUploader: React.FC<MinistryContentUploaderProps> = ({ onNavigateTab }) => {
  const [pendingFiles, setPendingFiles] = useState<PendingUploadItem[]>([]);
  const [ministryCategory, setMinistryCategory] = useState<string>('Prophetic Sound & Glory');
  const [uploadingAll, setUploadingAll] = useState<boolean>(false);
  const [successToast, setSuccessToast] = useState<{ msg: string; type: 'audio' | 'video' | 'image' } | null>(null);
  const [activeMedia, setActiveMedia] = useState<UploadedMediaItem[]>(offlineCache.getUploadedMedia());
  const [trashMedia, setTrashMedia] = useState<UploadedMediaItem[]>(offlineCache.getTrashMedia());
  const [showTrashBin, setShowTrashBin] = useState<boolean>(false);

  // Inline Tags Editor state for existing uploaded media
  const [editingTagsId, setEditingTagsId] = useState<string | null>(null);
  const [editingTagsValue, setEditingTagsValue] = useState<string>('');

  useEffect(() => {
    const unsubscribe = offlineCache.subscribe(() => {
      setActiveMedia(offlineCache.getUploadedMedia());
      setTrashMedia(offlineCache.getTrashMedia());
    });
    return unsubscribe;
  }, []);

  const handleTrash = (id: string) => {
    offlineCache.trashMedia(id);
    setActiveMedia(offlineCache.getUploadedMedia());
    setTrashMedia(offlineCache.getTrashMedia());
  };

  const handleRestore = (id: string) => {
    offlineCache.restoreMedia(id);
    setActiveMedia(offlineCache.getUploadedMedia());
    setTrashMedia(offlineCache.getTrashMedia());
  };

  const handlePermanentDelete = (id: string) => {
    offlineCache.permanentDeleteMedia(id);
    setActiveMedia(offlineCache.getUploadedMedia());
    setTrashMedia(offlineCache.getTrashMedia());
  };

  const handleFilesSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileList: File[] = Array.from(files as unknown as ArrayLike<File>);
    const todayStr = new Date().toISOString().split('T')[0];

    const newItems: PendingUploadItem[] = fileList.map((file, idx) => {
      let t: 'audio' | 'video' | 'image' | 'document' = 'audio';
      if (file.type.startsWith('video/')) t = 'video';
      else if (file.type.startsWith('image/')) t = 'image';
      else if (!file.type.startsWith('audio/')) t = 'document';

      const lastDot = file.name.lastIndexOf('.');
      const baseName = lastDot !== -1 ? file.name.substring(0, lastDot) : file.name;
      const formattedTitle = baseName.replace(/[_]/g, ' ');

      return {
        id: `pending-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 4)}`,
        file,
        title: formattedTitle.charAt(0).toUpperCase() + formattedTitle.slice(1),
        speaker: 'Prophet Juhnkrix Synvagord',
        datePreached: todayStr,
        description: `Anointed ${t} recorded and uploaded by Prophet JUHNKRIX SYNVAGORD (juhnkrix.musika@gmail.com).`,
        tags: `prophetic, worship, glory, ${t}`,
        type: t,
        progress: 0,
        uploading: false,
        completed: false
      };
    });

    setPendingFiles(prev => [...prev, ...newItems]);
    setSuccessToast(null);
  };

  const updatePendingItem = (id: string, field: 'title' | 'speaker' | 'datePreached' | 'description' | 'tags', value: string) => {
    setPendingFiles(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const removePendingItem = (id: string) => {
    setPendingFiles(prev => prev.filter(item => item.id !== id));
  };

  const handleStartBatchUpload = () => {
    if (pendingFiles.length === 0) return;

    setUploadingAll(true);
    setPendingFiles(prev => prev.map(item => ({ ...item, uploading: true, progress: 0 })));
    setSuccessToast(null);

    const interval = setInterval(() => {
      setPendingFiles(prev => {
        let allDone = true;
        const updated = prev.map(item => {
          if (item.completed) return item;
          const nextProg = item.progress + 25;
          if (nextProg >= 100) {
            return { ...item, progress: 100, uploading: false, completed: true };
          } else {
            allDone = false;
            return { ...item, progress: nextProg };
          }
        });

        if (allDone) {
          clearInterval(interval);
          setUploadingAll(false);

          const lastType = prev[0]?.type || 'audio';
          const fileCount = prev.length;

          prev.forEach(item => {
            const mediaUrl = URL.createObjectURL(item.file);
            const tagArray = item.tags.split(',').map(s => s.trim()).filter(Boolean);
            offlineCache.addUploadedMedia({
              type: item.type === 'document' ? 'audio' : item.type,
              title: item.title,
              description: `${item.description} (Speaker: ${item.speaker}, Preached: ${item.datePreached})`,
              url: mediaUrl,
              thumbnailUrl: item.type === 'image' ? mediaUrl : 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
              artistOrProphet: item.speaker,
              tags: tagArray.length > 0 ? tagArray : ['prophetic', 'worship', item.type]
            });
          });

          setSuccessToast({
            msg: `Successfully uploaded and processed ${fileCount} file(s) with tags!`,
            type: lastType === 'document' ? 'audio' : lastType
          });
          setPendingFiles([]);
        }

        return updated;
      });
    }, 250);
  };

  const handleStartEditTags = (file: UploadedMediaItem) => {
    setEditingTagsId(file.id);
    setEditingTagsValue((file.tags || ['prophetic', 'worship']).join(', '));
  };

  const handleSaveTags = (fileId: string) => {
    const tagArray = editingTagsValue.split(',').map(s => s.trim()).filter(Boolean);
    offlineCache.updateUploadedMediaTags(fileId, tagArray.length > 0 ? tagArray : ['prophetic', 'worship']);
    setEditingTagsId(null);
    setEditingTagsValue('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-amber-300">
            <Upload className="w-6 h-6 text-amber-400 animate-pulse" />
            <h2 className="text-lg font-extrabold font-mono tracking-tight text-amber-100">
              Batch Ministry Content Uploader, Tags Editor & IndexedDB Vault
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Authorized for Prophet JUHNKRIX SYNVAGORD. Select audio tracks, sermon videos, or devotional images. Edit titles, descriptions, and searchable tags right here in the owner page for instant cross-app reflection.
          </p>
        </div>
        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 font-mono">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>Encrypted IndexedDB Storage</span>
        </div>
      </div>

      {successToast && (
        <div className="bg-emerald-500/20 border border-emerald-500/40 p-4 rounded-2xl text-emerald-200 text-xs flex items-center justify-between shadow-lg animate-fadeIn">
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold">{successToast.msg}</p>
              <p className="text-[10px] text-emerald-300">Synchronized to IndexedDB and reflected immediately across the entire app.</p>
            </div>
          </div>
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab(successToast.type)}
              className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center space-x-1 transition-all shadow"
            >
              <span>View in {successToast.type.toUpperCase()} Sanctuary</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* File Drop / Selection Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="border-2 border-dashed border-amber-500/40 hover:border-amber-400 rounded-2xl p-8 text-center bg-slate-900/90 transition-all relative group cursor-pointer shadow-xl">
            <input
              type="file"
              multiple
              onChange={handleFilesSelected}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              accept="audio/*,video/*,image/*,.pdf,.doc,.docx"
            />
            <div className="flex flex-col items-center space-y-3 pointer-events-none">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 group-hover:scale-110 transition-transform">
                <Upload className="w-7 h-7" />
              </div>
              <div>
                <p className="text-sm font-bold text-amber-200">
                  Click or Drag & Drop Audio, Video, or Image Files Here
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Supports batch upload with custom tags editor for MP3, WAV, MP4, PNG, JPG
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-300 text-[11px] font-mono border border-amber-500/30">
                Batch Mode & Tags Editor Enabled
              </span>
            </div>
          </div>

          {/* Pending Files Customization Form (Appears after file selection) */}
          {pendingFiles.length > 0 && (
            <div className="space-y-4 bg-slate-900 p-5 rounded-2xl border border-amber-500/30 shadow-xl">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center space-x-2">
                  <Edit3 className="w-4 h-4 text-amber-400" />
                  <span>Customize Selected Files & Tags ({pendingFiles.length}) Before Saving</span>
                </h3>
                <span className="text-[10px] text-slate-400 font-mono">Set Title, Speaker, Date & Searchable Tags</span>
              </div>

              <div className="space-y-4 max-h-[550px] overflow-y-auto pr-1">
                {pendingFiles.map((item) => (
                  <div key={item.id} className="bg-slate-950 p-4 rounded-xl border border-amber-500/20 space-y-3 relative group">
                    <button
                      onClick={() => removePendingItem(item.id)}
                      disabled={item.uploading}
                      className="absolute top-3 right-3 text-slate-400 hover:text-red-400 transition-colors p-1"
                      title="Remove file"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <div className="flex items-center space-x-3 pr-8">
                      <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20 shrink-0">
                        {item.type === 'audio' ? <FileAudio className="w-4 h-4" /> : item.type === 'video' ? <Video className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-amber-100 truncate">{item.file.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">Size: {(item.file.size / (1024 * 1024)).toFixed(2)} MB • Type: {item.type}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <div>
                        <label className="text-[10px] font-semibold text-amber-300 block mb-1">Media Title</label>
                        <input
                          type="text"
                          value={item.title}
                          onChange={(e) => updatePendingItem(item.id, 'title', e.target.value)}
                          disabled={item.uploading}
                          className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-400 font-bold"
                          placeholder="e.g. Divine Breakthrough Encounter"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold text-amber-300 block mb-1">Speaker / Prophet</label>
                        <input
                          type="text"
                          value={item.speaker}
                          onChange={(e) => updatePendingItem(item.id, 'speaker', e.target.value)}
                          disabled={item.uploading}
                          className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-400"
                          placeholder="Prophet Juhnkrix Synvagord"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold text-amber-300 block mb-1">Date Recorded / Preached</label>
                        <input
                          type="date"
                          value={item.datePreached}
                          onChange={(e) => updatePendingItem(item.id, 'datePreached', e.target.value)}
                          disabled={item.uploading}
                          className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold text-amber-300 block mb-1 flex items-center space-x-1">
                          <Tag className="w-3 h-3 text-amber-400" />
                          <span>Searchable Tags (Comma-Separated)</span>
                        </label>
                        <input
                          type="text"
                          value={item.tags}
                          onChange={(e) => updatePendingItem(item.id, 'tags', e.target.value)}
                          disabled={item.uploading}
                          className="w-full bg-slate-900 text-amber-300 border border-amber-500/40 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-400 font-mono font-bold"
                          placeholder="prophetic, worship, 528hz, healing"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-[10px] font-semibold text-slate-400 block mb-1">Spiritual Description</label>
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => updatePendingItem(item.id, 'description', e.target.value)}
                          disabled={item.uploading}
                          className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    {/* Individual Progress Bar per file */}
                    {(item.uploading || item.progress > 0) && (
                      <div className="space-y-1.5 pt-2">
                        <div className="flex items-center justify-between text-[10px] font-mono text-amber-300">
                          <span>{item.completed ? '✓ Stored in IndexedDB with Tags' : 'Uploading to Offline Vault...'}</span>
                          <span>{item.progress}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-amber-500/20">
                          <div
                            className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-200"
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={handleStartBatchUpload}
                disabled={uploadingAll || pendingFiles.length === 0}
                className={`w-full py-3.5 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-xl ${
                  uploadingAll || pendingFiles.length === 0
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 border border-amber-300'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>{uploadingAll ? 'Uploading Batch & Tagging...' : `Upload & Save ${pendingFiles.length} File(s) with Tags`}</span>
              </button>
            </div>
          )}
        </div>

        {/* Configuration Sidebar */}
        <div className="space-y-4 bg-slate-900 p-6 rounded-2xl border border-amber-500/30 flex flex-col justify-between shadow-xl">
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-300">Uploader & Tags Engine</h3>
            
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">Ministry Category (Applied to Batch)</label>
              <input
                type="text"
                value={ministryCategory}
                onChange={(e) => setMinistryCategory(e.target.value)}
                placeholder="e.g. Prophetic Soaking, Sunday Service"
                className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/20 space-y-2">
              <div className="text-[11px] font-bold text-amber-300 flex items-center space-x-1.5">
                <Tag className="w-3.5 h-3.5 text-amber-400" />
                <span>Instant Tag Reflection</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                Tags edited here in the owner page reflect instantly across the entire JUHNKRIX MUSIKA APP for searching, filtering, and categorization.
              </p>
            </div>
          </div>

          <div className="p-4 bg-amber-500/10 rounded-xl border border-amber-500/30 text-center space-y-1">
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">IndexedDB Storage Status</span>
            <div className="text-xs font-mono text-amber-200">Vault Active & Synchronized</div>
          </div>
        </div>
      </div>

      {/* Uploaded Repository List with Tags Editors */}
      <div className="space-y-4 pt-6 border-t border-amber-500/20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-200 flex items-center space-x-2">
              <Tag className="w-4 h-4 text-amber-400" />
              <span>Active Ministry Repository & Tags Manager ({activeMedia.length} Files Available)</span>
            </h3>
            <p className="text-[10px] text-slate-400">Edit tags inline on any audio, video, or image file to update them instantly across the entire app.</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowTrashBin(!showTrashBin)}
              className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold flex items-center space-x-1.5 transition-all shadow"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>{showTrashBin ? 'Hide Trash Bin' : `Trash Bin (${trashMedia.length})`}</span>
            </button>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">● Live Sync Active</span>
          </div>
        </div>

        {/* Trash Bin Section if toggled */}
        {showTrashBin && (
          <div className="bg-red-950/20 border border-red-500/30 rounded-2xl p-5 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-red-300 flex items-center space-x-2">
                <Trash2 className="w-4 h-4 text-red-400" />
                <span>Trash Bin & Lifecycle Management ({trashMedia.length} Items)</span>
              </h4>
              <span className="text-[10px] text-slate-400">Items in trash can be restored or permanently deleted.</span>
            </div>

            {trashMedia.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">Trash bin is currently empty.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {trashMedia.map((file) => (
                  <div key={file.id} className="bg-slate-950 p-4 rounded-xl border border-red-500/30 space-y-3 flex flex-col justify-between">
                    <div>
                      <p className="text-xs font-bold text-red-200 truncate">{file.title}</p>
                      <p className="text-[10px] text-slate-400">{file.date} • {file.type}</p>
                    </div>
                    <div className="flex items-center space-x-2 pt-2 border-t border-red-500/20">
                      <button
                        onClick={() => handleRestore(file.id)}
                        className="flex-1 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center justify-center space-x-1 transition-all"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Restore</span>
                      </button>
                      <button
                        onClick={() => handlePermanentDelete(file.id)}
                        className="flex-1 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 text-[10px] font-bold flex items-center justify-center space-x-1 transition-all"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete Permanently</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeMedia.length === 0 ? (
          <div className="bg-slate-900 p-8 rounded-2xl border border-amber-500/20 text-center text-slate-400 text-xs italic">
            No active ministry files in repository. Upload files above to populate storage.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {activeMedia.map((file) => (
              <div key={file.id} className="bg-slate-900 p-4 rounded-2xl border border-amber-500/20 space-y-3 flex flex-col justify-between shadow-lg relative group">
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20 shrink-0">
                        {file.type === 'audio' ? <FileAudio className="w-5 h-5" /> : file.type === 'video' ? <Video className="w-5 h-5" /> : <ImageIcon className="w-5 h-5" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-amber-100 truncate">{file.title}</p>
                        <p className="text-[10px] text-slate-400 truncate">{file.artistOrProphet}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleTrash(file.id)}
                      className="p-2 rounded-xl bg-slate-950 hover:bg-red-500/20 text-slate-400 hover:text-red-400 border border-amber-500/10 hover:border-red-500/30 transition-all"
                      title="Move file to Trash"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-300 line-clamp-2">{file.description}</p>

                  {/* Tags Section with Inline Editor */}
                  <div className="space-y-2 pt-2 border-t border-amber-500/10">
                    {editingTagsId === file.id ? (
                      <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-amber-500/40">
                        <label className="text-[10px] font-bold text-amber-300 block">Edit Tags (Comma-Separated)</label>
                        <input
                          type="text"
                          value={editingTagsValue}
                          onChange={(e) => setEditingTagsValue(e.target.value)}
                          className="w-full bg-slate-900 text-amber-200 border border-amber-500/30 rounded-lg px-2.5 py-1 text-xs font-mono focus:outline-none focus:border-amber-400"
                          placeholder="prophetic, worship, 528hz"
                        />
                        <div className="flex items-center justify-end space-x-2 pt-1">
                          <button
                            onClick={() => setEditingTagsId(null)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-[10px] font-bold hover:bg-slate-700"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveTags(file.id)}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 text-[10px] font-bold hover:bg-amber-400 flex items-center space-x-1 shadow"
                          >
                            <Save className="w-3 h-3" />
                            <span>Save Tags</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-1.5 items-center">
                          <Tag className="w-3 h-3 text-amber-400 shrink-0" />
                          {(file.tags && file.tags.length > 0 ? file.tags : ['prophetic', file.type]).map((tag, idx) => (
                            <span key={idx} className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 font-mono text-[9px] border border-amber-500/30">
                              #{tag}
                            </span>
                          ))}
                        </div>
                        <button
                          onClick={() => handleStartEditTags(file)}
                          className="px-2 py-1 rounded-lg bg-slate-950 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold flex items-center space-x-1 transition-all shrink-0"
                          title="Edit Tags"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-1 pt-2 border-t border-amber-500/10">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span className="text-amber-300 font-mono capitalize">{file.type} Sanctuary</span>
                    <span className="font-mono">IndexedDB</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] font-mono">
                    <span className="text-emerald-400 font-bold">✓ Offline Ready</span>
                    <span className="text-slate-500">{file.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
