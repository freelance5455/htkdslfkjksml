import React, { useState, useEffect } from 'react';
import { Play, CheckCircle2, X, Sparkles, Volume2, VolumeX, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useAudioFeedback } from '../hooks/useAudioFeedback';

interface WatchAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardEarned: (coins: number) => void;
  rewardCoins?: number;
}

export const WatchAdModal: React.FC<WatchAdModalProps> = ({
  isOpen,
  onClose,
  onRewardEarned,
  rewardCoins = 250,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState<number>(15);
  const [adFinished, setAdFinished] = useState<boolean>(false);
  const [isAdMuted, setIsAdMuted] = useState<boolean>(false);
  const { playCoinCollect, playTick } = useAudioFeedback();

  useEffect(() => {
    if (!isOpen) {
      setSecondsRemaining(15);
      setAdFinished(false);
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setAdFinished(true);
          playCoinCollect(4);
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.6 },
          });
          onRewardEarned(rewardCoins);
          return 0;
        }
        playTick();
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, onRewardEarned, rewardCoins, playCoinCollect, playTick]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl">
        {/* Top bar with timer & provider */}
        <div className="px-4 py-3 bg-slate-950 flex items-center justify-between border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-white">Google AdMob Sponsor</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAdMuted(!isAdMuted)}
              className="text-slate-400 hover:text-white"
            >
              {isAdMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {adFinished ? (
              <button
                onClick={onClose}
                className="w-6 h-6 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-amber-400 font-mono text-[11px] font-bold">
                Reward in {secondsRemaining}s
              </span>
            )}
          </div>
        </div>

        {/* Video Simulation Canvas */}
        <div className="relative aspect-video bg-gradient-to-br from-indigo-950 via-slate-900 to-amber-950 flex flex-col items-center justify-center p-6 text-center overflow-hidden">
          {/* Animated decorative waves */}
          <div className="absolute inset-0 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />

          {adFinished ? (
            <div className="relative z-10 space-y-2 animate-fadeIn">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-base font-black text-white font-display">Reward Verified!</h3>
              <p className="text-xs text-amber-300 font-bold font-mono">
                +{rewardCoins.toLocaleString()} Coins Credited
              </p>
            </div>
          ) : (
            <div className="relative z-10 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 mx-auto flex items-center justify-center animate-pulse">
                <Play className="w-6 h-6 fill-amber-400" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400 uppercase tracking-wider font-bold">
                  Sponsored Video Ad
                </span>
                <h4 className="text-sm font-bold text-white mt-0.5">
                  Top Mobile Games & Fintech Apps
                </h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Keep watching to unlock instant coins & full stamina!
                </p>
              </div>

              {/* Progress bar */}
              <div className="w-48 mx-auto h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-1000"
                  style={{ width: `${((15 - secondsRemaining) / 15) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Bottom banner & Close CTA */}
        <div className="p-4 bg-slate-950 text-center space-y-2">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ad verified by AdMob Partner Network · 100% Secure</span>
          </div>

          {adFinished && (
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-500 text-slate-950 font-black text-xs hover:brightness-105 transition-all shadow-md active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              <span>Collect +{rewardCoins} Coins & Return</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
