import { useState } from "react";
import { useStore } from "../lib/store";
import { findPath } from "../lib/fs";
import { Button, Icon } from "./ui";
import DiffView from "./DiffView";
import { cn } from "../utils/cn";

export default function ChangesView({ running }: { running: boolean }) {
  const { s, undoLast } = useStore();
  const [expanded, setExpanded] = useState<string | null>(null);
  const changes = [...s.changes].reverse();
  const [undoing, setUndoing] = useState(false);
  const latest = changes.find((c) => !c.undone);
  return (
    <div className="mx-auto flex h-full w-full max-w-[900px] flex-col overflow-y-auto px-5 py-6 sm:px-9">
      <div className="mb-7 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-medium tracking-tight">
            Workspace changes
          </h1>
          <p className="mt-1 text-xs text-muted">
            Review your last 12 changes. Undo restores the previous workspace
            state.
          </p>
        </div>
        <Button
          size="sm"
          variant="secondary"
          icon="undo"
          disabled={!latest || running || undoing}
          onClick={async () => {
            setUndoing(true);
            await undoLast();
            setUndoing(false);
          }}
        >
          {undoing ? "Undoing..." : "Undo last"}
        </Button>
      </div>
      {!changes.length ? (
        <div className="flex flex-1 flex-col items-center justify-center pb-20 text-center">
          <Icon name="changes" className="mb-4 h-10 w-10 text-line2" />
          <h2 className="text-base font-medium">A clean slate.</h2>
          <p className="mt-2 max-w-[300px] text-sm leading-relaxed text-muted">
            Changes made by you or the agent will appear here, with a diff and a
            way back.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-line">
          {changes.map((change) => {
            const before = findPath(change.before, change.path)?.content ?? "";
            const after = findPath(change.after, change.path)?.content ?? "";
            return (
              <div
                key={change.id}
                className={cn("py-4", change.undone && "opacity-50")}
              >
                <button
                  onClick={() =>
                    setExpanded(expanded === change.id ? null : change.id)
                  }
                  className="flex w-full items-center gap-3 text-left"
                >
                  <Icon
                    name={change.kind === "delete" ? "trash" : "changes"}
                    className="h-[18px] w-[18px] text-accent"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-[12px]">
                      {change.path}
                    </p>
                    <p className="mt-1 text-[11px] text-muted">
                      {change.label} /{" "}
                      {new Date(change.ts).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "text-[10px]",
                      change.undone ? "text-muted" : "text-ok",
                    )}
                  >
                    {change.undone ? "Undone" : "Applied"}
                  </span>
                  <Icon
                    name={
                      expanded === change.id ? "chevronDown" : "chevronRight"
                    }
                    className="h-4 w-4 text-muted"
                  />
                </button>
                {expanded === change.id && (
                  <div className="mt-4">
                    {before !== after ? (
                      <DiffView before={before} after={after} />
                    ) : (
                      <p className="text-xs text-muted">
                        Folder or path change. Use Undo last to reverse it in
                        order.
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
