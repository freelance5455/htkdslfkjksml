import { useState } from "react";
import { X } from "lucide-react";
import {
  LOCATION_MAP,
  LOCATIONS,
  PRODUCT_MAP,
  PRODUCTS,
  ROLE_META,
  STORE_LABELS,
  SUPPLIERS,
  UPGRADE_COST,
} from "@/game/catalog";
import type { GameHandle } from "@/game/engine";
import type { DayReport, EmployeeRole, PanelId, ProductId } from "@/game/types";
import { fmtMoney } from "./hud";

type Props = {
  panel: PanelId;
  game: GameHandle;
  onClose: () => void;
  onRebuild: () => void;
};

export function GamePanel({ panel, game, onClose, onRebuild }: Props) {
  if (!panel) return null;
  const title =
    panel === "stock"
      ? "Warehouse"
      : panel === "order"
        ? "Suppliers"
        : panel === "shop"
          ? "Store upgrades"
          : panel === "staff"
            ? "Staff"
            : panel === "missions"
              ? "Daily jobs"
              : "Settings";
  return (
    <aside className="pointer-events-auto absolute inset-x-3 bottom-24 z-30 mx-auto flex max-h-[70vh] w-[min(560px,100%)] flex-col overflow-hidden rounded-2xl border border-border bg-surface/95 shadow-xl sm:inset-x-auto sm:right-4 sm:bottom-8 sm:top-20">
      <header className="flex items-center justify-between border-b border-border px-4 py-3">
        <h2 className="font-display text-lg tracking-wide text-fg">{title}</h2>
        <button
          type="button"
          onClick={onClose}
          className="grid size-9 place-items-center rounded-lg text-muted hover:text-fg"
          aria-label="Close"
        >
          <X className="size-4" />
        </button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {panel === "stock" ? <StockBody game={game} /> : null}
        {panel === "order" ? <OrderBody game={game} /> : null}
        {panel === "shop" ? <ShopBody game={game} onRebuild={onRebuild} /> : null}
        {panel === "staff" ? <StaffBody game={game} /> : null}
        {panel === "missions" ? <MissionBody game={game} /> : null}
        {panel === "settings" ? <SettingsBody game={game} /> : null}
      </div>
    </aside>
  );
}

function StockBody({ game }: { game: GameHandle }) {
  const s = game.sim.s;
  const used = game.sim.warehouseUsed();
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted">
        Capacity {used}/{s.warehouseCap} · pick crates in the back room
      </p>
      <ul className="space-y-2">
        {PRODUCTS.filter((p) => s.unlocked[p.id]).map((p) => {
          const onShelf = s.shelves.filter((sh) => sh.productId === p.id).reduce((a, sh) => a + sh.stock, 0);
          return (
            <li key={p.id} className="flex items-center justify-between rounded-xl bg-elevated px-3 py-2">
              <div>
                <p className="text-sm font-medium text-fg">{p.name}</p>
                <p className="text-xs text-muted">
                  Buy {fmtMoney(p.buyPrice)} · Sell {fmtMoney(p.sellPrice * s.sellMul[p.id])} ·{" "}
                  {fmtMoney(p.sellPrice * s.sellMul[p.id] - p.buyPrice)} profit
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm tabular-nums text-fg">{s.warehouse[p.id]} in back</p>
                <p className="text-xs text-muted">{onShelf} on shelf</p>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function OrderBody({ game }: { game: GameHandle }) {
  const s = game.sim.s;
  const [pid, setPid] = useState<ProductId>("milk");
  const [qty, setQty] = useState(24);
  const [sid, setSid] = useState("metro");
  const [err, setErr] = useState("");
  const p = PRODUCT_MAP[pid];
  const sup = SUPPLIERS.find((x) => x.id === sid)!;
  const spec = sup.specialty === "all" || sup.specialty === p.category;
  const cost = p.buyPrice * qty * (spec ? sup.priceMul : sup.priceMul * 1.12) * (qty >= 40 ? sup.bulk : 1);

  return (
    <div className="space-y-4">
      {s.orders.length ? (
        <ul className="space-y-1.5">
          {s.orders.map((o) => (
            <li key={o.id} className="flex justify-between text-xs text-muted">
              <span>
                {o.qty} {PRODUCT_MAP[o.productId].name}
              </span>
              <span className="tabular-nums">{Math.max(0, o.eta).toFixed(0)}s out</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-xs text-muted">No trucks on the way.</p>
      )}
      <label className="block text-xs text-muted">
        Product
        <select
          value={pid}
          onChange={(e) => setPid(e.target.value as ProductId)}
          className="mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg"
        >
          {PRODUCTS.filter((x) => s.unlocked[x.id]).map((x) => (
            <option key={x.id} value={x.id}>
              {x.name}
            </option>
          ))}
        </select>
      </label>
      <label className="block text-xs text-muted">
        Supplier
        <select
          value={sid}
          onChange={(e) => setSid(e.target.value)}
          className="mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg"
        >
          {SUPPLIERS.map((x) => (
            <option key={x.id} value={x.id}>
              {x.name} · {x.delayMin}m · x{x.priceMul}
            </option>
          ))}
        </select>
      </label>
      <label className="block text-xs text-muted">
        Quantity · {qty}
        <input
          type="range"
          min={8}
          max={80}
          step={4}
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          className="mt-2 w-full"
        />
      </label>
      <p className="text-sm tabular-nums text-fg">Order total {fmtMoney(cost)}</p>
      {err ? <p className="text-sm text-danger">{err}</p> : null}
      <button
        type="button"
        onClick={() => {
          const msg = game.sim.placeOrder(pid, qty, sid);
          setErr(msg);
        }}
        className="h-11 w-full rounded-xl bg-accent text-sm font-semibold text-accent-fg"
      >
        Place order
      </button>
    </div>
  );
}

function ShopBody({ game, onRebuild }: { game: GameHandle; onRebuild: () => void }) {
  const s = game.sim.s;
  const [msg, setMsg] = useState("");
  const run = (fn: () => string) => {
    const r = fn();
    if (r === "rebuild") onRebuild();
    else setMsg(r);
  };
  const next = UPGRADE_COST[s.storeLevel] ?? 0;
  return (
    <div className="space-y-3">
      <p className="text-sm text-fg">
        {STORE_LABELS[s.storeLevel - 1]} · {LOCATION_MAP[s.location].name}
      </p>
      {msg ? <p className="text-sm text-danger">{msg}</p> : null}
      <Row
        title={s.storeLevel < 4 ? `Expand to ${STORE_LABELS[s.storeLevel]}` : "Max size"}
        detail={s.storeLevel < 4 ? fmtMoney(next) : "Hypermarket"}
        onClick={() => run(() => game.sim.upgradeStore())}
      />
      <Row title="Extra checkout" detail="$2,500" onClick={() => run(() => game.sim.buyCheckout())} />
      <Row title="Lighting" detail="$1,200" onClick={() => run(() => game.sim.buyLights())} />
      <Row title="Decoration" detail="$1,600" onClick={() => run(() => game.sim.buyDecor())} />
      <Row title="Warehouse" detail="$2,800" onClick={() => run(() => game.sim.expandWarehouse())} />
      <h3 className="pt-2 text-xs font-medium uppercase tracking-wide text-muted">Locations</h3>
      {LOCATIONS.map((l) => (
        <button
          key={l.id}
          type="button"
          onClick={() => run(() => game.sim.setLocation(l.id))}
          className={`w-full rounded-xl border px-3 py-2 text-left ${
            s.location === l.id ? "border-accent bg-elevated" : "border-border bg-elevated/50"
          }`}
        >
          <p className="text-sm text-fg">
            {l.name}
            {s.storeLevel < l.unlockLevel ? " · locked" : ""}
          </p>
          <p className="text-xs text-muted">
            {l.blurb} · rent {fmtMoney(l.rent)}/day
          </p>
        </button>
      ))}
    </div>
  );
}

function StaffBody({ game }: { game: GameHandle }) {
  const s = game.sim.s;
  const [msg, setMsg] = useState("");
  const roles = Object.keys(ROLE_META) as EmployeeRole[];
  return (
    <div className="space-y-3">
      {msg ? <p className="text-sm text-danger">{msg}</p> : null}
      {s.staff.length === 0 ? <p className="text-sm text-muted">No staff yet. Hire a cashier when the queue grows.</p> : null}
      {s.staff.map((e) => (
        <div key={e.id} className="flex items-center justify-between rounded-xl bg-elevated px-3 py-2">
          <div>
            <p className="text-sm text-fg">
              {e.name} · {ROLE_META[e.role].label} · Lv.{e.level}
            </p>
            <p className="text-xs text-muted">{fmtMoney(ROLE_META[e.role].salary + (e.level - 1) * 12)} / day</p>
          </div>
          <div className="flex gap-1">
            <button
              type="button"
              className="h-9 rounded-lg border border-border px-2 text-xs text-fg"
              onClick={() => setMsg(game.sim.train(e.id))}
            >
              Train
            </button>
            <button type="button" className="h-9 rounded-lg px-2 text-xs text-danger" onClick={() => game.sim.fire(e.id)}>
              Fire
            </button>
          </div>
        </div>
      ))}
      <h3 className="pt-1 text-xs font-medium uppercase tracking-wide text-muted">Hire</h3>
      <div className="grid grid-cols-2 gap-2">
        {roles.map((r) => (
          <button
            key={r}
            type="button"
            onClick={() => setMsg(game.sim.hire(r))}
            className="rounded-xl border border-border bg-elevated px-3 py-2 text-left"
          >
            <p className="text-sm text-fg">{ROLE_META[r].label}</p>
            <p className="text-xs text-muted">
              {fmtMoney(ROLE_META[r].hire)} · {ROLE_META[r].blurb}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}

function MissionBody({ game }: { game: GameHandle }) {
  return (
    <ul className="space-y-2">
      {game.sim.s.missions.map((m) => (
        <li key={m.id} className="rounded-xl bg-elevated px-3 py-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-sm font-medium text-fg">{m.title}</p>
              <p className="text-xs text-muted">{m.detail}</p>
            </div>
            {m.done && !m.claimed ? (
              <button
                type="button"
                onClick={() => game.sim.claimMission(m.id)}
                className="h-9 rounded-lg bg-accent px-3 text-xs font-semibold text-accent-fg"
              >
                Claim
              </button>
            ) : (
              <span className="text-xs tabular-nums text-muted">
                {m.progress}/{m.target}
              </span>
            )}
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-bg">
            <div
              className="h-full bg-accent"
              style={{ width: `${Math.min(100, (m.progress / m.target) * 100)}%` }}
            />
          </div>
          <p className="mt-1 text-xs text-subtle">
            {fmtMoney(m.rewardMoney)} · {m.rewardXp} XP
          </p>
        </li>
      ))}
    </ul>
  );
}

function SettingsBody({ game }: { game: GameHandle }) {
  const s = game.sim.s.settings;
  return (
    <div className="space-y-4">
      <label className="block text-xs text-muted">
        Sound {Math.round(s.sfx * 100)}
        <input
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={s.sfx}
          onChange={(e) => {
            s.sfx = Number(e.target.value);
            game.audio.sfxVol = s.sfx;
            game.audio.applyVol();
          }}
          className="mt-2 w-full"
        />
      </label>
      <label className="block text-xs text-muted">
        Music {Math.round(s.music * 100)}
        <input
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={s.music}
          onChange={(e) => {
            s.music = Number(e.target.value);
            game.audio.musicVol = s.music;
            game.audio.applyVol();
          }}
          className="mt-2 w-full"
        />
      </label>
      <label className="flex items-center justify-between text-sm text-fg">
        Camera shake
        <input
          type="checkbox"
          checked={s.shake}
          onChange={(e) => {
            s.shake = e.target.checked;
          }}
        />
      </label>
      <label className="block text-xs text-muted">
        Quality
        <select
          value={s.quality}
          onChange={(e) => game.setQuality(e.target.value as "low" | "med" | "high")}
          className="mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg"
        >
          <option value="low">Low</option>
          <option value="med">Medium</option>
          <option value="high">High</option>
        </select>
      </label>
    </div>
  );
}

function Row({ title, detail, onClick }: { title: string; detail: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-xl border border-border bg-elevated px-3 py-3 text-left"
    >
      <span className="text-sm text-fg">{title}</span>
      <span className="text-xs tabular-nums text-muted">{detail}</span>
    </button>
  );
}

export function PauseMenu({
  onResume,
  onSettings,
  onTitle,
}: {
  onResume: () => void;
  onSettings: () => void;
  onTitle: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 grid place-items-center bg-bg/70 px-6">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-6">
        <h2 className="font-display text-2xl text-fg">Paused</h2>
        <div className="mt-5 flex flex-col gap-2">
          <button type="button" onClick={onResume} className="h-12 rounded-xl bg-accent font-semibold text-accent-fg">
            Resume
          </button>
          <button type="button" onClick={onSettings} className="h-12 rounded-xl border border-border-strong text-fg">
            Settings
          </button>
          <button type="button" onClick={onTitle} className="h-12 rounded-xl text-muted">
            Title
          </button>
        </div>
      </div>
    </div>
  );
}

export function DayEnd({ report, onNext }: { report: DayReport; onNext: () => void }) {
  return (
    <div className="absolute inset-0 z-40 grid place-items-center bg-bg/75 px-6">
      <div className="w-full max-w-md rounded-2xl border border-border bg-surface p-6">
        <p className="text-xs uppercase tracking-[0.2em] text-accent">Closing report</p>
        <h2 className="font-display mt-1 text-3xl text-fg">Day {report.day}</h2>
        <dl className="mt-5 space-y-2 text-sm">
          <Line k="Revenue" v={fmtMoney(report.revenue)} />
          <Line k="Rent" v={fmtMoney(report.rent)} />
          <Line k="Power" v={fmtMoney(report.power)} />
          <Line k="Wages" v={fmtMoney(report.wages)} />
          <Line k="Expenses" v={fmtMoney(report.expenses)} />
          <Line k="Profit" v={fmtMoney(report.profit)} strong />
          <Line k="Sold" v={String(report.sold)} />
          <Line k="Served" v={String(report.served)} />
          <Line k="Walked out" v={String(report.lost)} />
          <Line k="Rating" v={report.rating.toFixed(1)} />
        </dl>
        <button type="button" onClick={onNext} className="mt-6 h-12 w-full rounded-xl bg-accent font-semibold text-accent-fg">
          Next day
        </button>
      </div>
    </div>
  );
}

function Line({ k, v, strong }: { k: string; v: string; strong?: boolean }) {
  return (
    <div className="flex justify-between">
      <dt className="text-muted">{k}</dt>
      <dd className={`tabular-nums ${strong ? "text-money" : "text-fg"}`}>{v}</dd>
    </div>
  );
}
