"use client";

import { useState } from "react";
import type { QuizQuestion } from "@/data/paths";
import { toArabicDigits } from "@/lib/site";

type Props = {
  title: string;
  questions: QuizQuestion[];
};

/** Multiple-choice quiz with instant feedback and a final score. */
export function Quiz({ title, questions }: Props) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const total = questions.length;
  const current = questions[index];

  const restart = () => {
    setIndex(0);
    setSelected(null);
    setScore(0);
    setFinished(false);
  };

  const choose = (optionIndex: number) => {
    if (selected !== null || !current) return;
    setSelected(optionIndex);
    if (optionIndex === current.answer) setScore((s) => s + 1);
  };

  const next = () => {
    if (index + 1 >= total) {
      setFinished(true);
      return;
    }
    setIndex((i) => i + 1);
    setSelected(null);
  };

  if (total === 0) {
    return null;
  }

  const shell =
    "relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)] sm:p-8";

  if (finished) {
    const passed = score >= Math.ceil(total * 0.6);
    return (
      <div className={shell} aria-live="polite">
        <p className="text-sm text-gold">اختبار: {title}</p>
        <p className="mt-6 font-serif text-4xl font-bold text-navy">
          نتيجتك: {toArabicDigits(score)} من {toArabicDigits(total)}
        </p>
        <p className="mt-4 leading-8 text-navy/65">
          {passed
            ? "أحسنت، فهمك لهذا المسار جيد. يمكنك مراجعة الدروس للتثبيت."
            : "لا بأس، راجع الدروس ثم أعد الاختبار لتثبيت المعلومات."}
        </p>
        <button
          type="button"
          onClick={restart}
          className="mt-8 rounded-full bg-navy px-6 py-2.5 text-sm font-medium text-ivory transition-all hover:bg-royal"
        >
          إعادة الاختبار
        </button>
      </div>
    );
  }

  const progress = ((index + (selected !== null ? 1 : 0)) / total) * 100;

  return (
    <div className={shell}>
      <div className="mb-6 flex items-center justify-between gap-4">
        <p className="text-sm text-gold">اختبار: {title}</p>
        <p className="text-xs text-muted-foreground">
          السؤال {toArabicDigits(index + 1)} من {toArabicDigits(total)}
        </p>
      </div>

      <h3 className="mb-6 font-serif text-2xl leading-relaxed font-bold text-navy">{current.question}</h3>

      <ul className="grid gap-3 sm:grid-cols-2">
        {current.options.map((option, optionIndex) => {
          const isAnswer = optionIndex === current.answer;
          const isChosen = optionIndex === selected;
          let style = "border-border bg-ivory text-navy hover:border-gold hover:bg-white";
          if (selected !== null) {
            if (isAnswer) style = "border-gold bg-gold/15 text-navy";
            else if (isChosen) style = "border-destructive/60 bg-destructive/10 text-destructive";
            else style = "border-border bg-ivory text-navy/50";
          }
          return (
            <li key={option}>
              <button
                type="button"
                onClick={() => choose(optionIndex)}
                disabled={selected !== null}
                aria-pressed={isChosen}
                className={`flex w-full items-center justify-between rounded-2xl border px-5 py-4 text-start transition-all duration-300 disabled:cursor-default ${style}`}
              >
                <span>{option}</span>
                {selected !== null && isAnswer && <span className="text-sm font-medium text-royal">✓</span>}
                {selected !== null && isChosen && !isAnswer && (
                  <span className="text-sm font-medium text-destructive">✗</span>
                )}
              </button>
            </li>
          );
        })}
      </ul>

      <div className="mt-6 flex items-center justify-between gap-4">
        <div className="h-1 flex-1 overflow-hidden rounded-full bg-stone">
          <div
            className="h-full rounded-full bg-gold transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <button
          type="button"
          onClick={next}
          disabled={selected === null}
          className="rounded-full bg-navy px-6 py-2.5 text-sm font-medium text-ivory transition-all hover:bg-royal disabled:opacity-40"
        >
          {index + 1 >= total ? "إنهاء" : "التالي"}
        </button>
      </div>
    </div>
  );
}
