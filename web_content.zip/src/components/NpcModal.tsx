import React, { useState } from 'react';
import { CheckCircle2, Coins, Hammer, HeartPulse, ScrollText, ShoppingBag, Sparkles, X } from 'lucide-react';
import { BLACKSMITH_FORGE, MERCHANT_STOCK, QUESTS } from '../game/data/entities';
import { ITEMS } from '../game/data/items';
import { InventoryEntry, NpcDefinition, QuestProgress } from '../game/types';
import { ItemIcon } from './ItemIcon';

interface NpcModalProps {
  npc: NpcDefinition | null;
  gold: number;
  inventory: InventoryEntry[];
  quests: Record<string, QuestProgress>;
  onClose: () => void;
  onBuyItem: (itemId: string, price: number) => void;
  onSellItem: (index: number) => void;
  onCraftItem: (forgeIndex: number) => void;
  onHealPlayer: () => void;
  onAcceptQuest: (questId: string) => void;
  onClaimQuest: (questId: string) => void;
}

export const NpcModal: React.FC<NpcModalProps> = ({
  npc,
  gold,
  inventory,
  quests,
  onClose,
  onBuyItem,
  onSellItem,
  onCraftItem,
  onHealPlayer,
  onAcceptQuest,
  onClaimQuest,
}) => {
  const [merchantTab, setMerchantTab] = useState<'buy' | 'sell'>('buy');

  if (!npc) return null;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-3 sm:p-6"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-amber-500/40 bg-slate-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/90 px-4 py-3">
          <div>
            <h2 className="text-base font-extrabold text-amber-200">{npc.nameAr}</h2>
            <p className="text-xs text-slate-400">{npc.titleAr}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 rounded-lg border border-amber-500/40 bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-300">
              <Coins className="h-3.5 w-3.5" />
              {gold}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 p-1.5 text-slate-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {/* Dialogue Box */}
          <div className="rounded-xl border border-slate-700/80 bg-slate-950/70 p-3 text-sm leading-relaxed text-slate-200">
            «{npc.greetingAr}»
          </div>

          {/* Role 1: Quest Elder */}
          {npc.role === 'quest' && (
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300">
                <ScrollText className="h-4 w-4" />
                <span>المهام المتاحة</span>
              </div>
              {QUESTS.map((q) => {
                const qp = quests[q.id] ?? {
                  accepted: false,
                  progress: 0,
                  completed: false,
                  claimed: false,
                };
                const rewardItem = ITEMS[q.rewardItemId];
                return (
                  <div
                    key={q.id}
                    className="flex flex-col justify-between gap-3 rounded-xl border border-slate-700 bg-slate-950/60 p-3 sm:flex-row sm:items-center"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-amber-100">{q.titleAr}</span>
                        {qp.claimed && (
                          <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
                            مكتملة
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">{q.descriptionAr}</p>
                      <div className="flex flex-wrap items-center gap-2 text-[11px] text-amber-300">
                        <span>التقدم: {qp.progress} / {q.targetCount}</span>
                        <span>•</span>
                        <span>+{q.rewardGold} ذهب</span>
                        <span>+{q.rewardShards} شظية</span>
                        {rewardItem && <span>+{rewardItem.nameAr}</span>}
                      </div>
                    </div>
                    <div>
                      {!qp.accepted ? (
                        <button
                          type="button"
                          onClick={() => onAcceptQuest(q.id)}
                          className="rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-indigo-500"
                        >
                          قبول المهمة
                        </button>
                      ) : qp.completed && !qp.claimed ? (
                        <button
                          type="button"
                          onClick={() => onClaimQuest(q.id)}
                          className="flex items-center gap-1 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-extrabold text-slate-950 hover:bg-amber-400"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          استلام المكافأة
                        </button>
                      ) : qp.claimed ? (
                        <span className="text-xs font-bold text-emerald-400">تم الاستلام</span>
                      ) : (
                        <span className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs text-slate-300">
                          قيد التنفيذ
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Role 2: Merchant */}
          {npc.role === 'merchant' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setMerchantTab('buy')}
                  className={`flex items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-xs font-bold ${
                    merchantTab === 'buy'
                      ? 'bg-emerald-600 text-white'
                      : 'border border-slate-700 bg-slate-800 text-slate-300'
                  }`}
                >
                  <ShoppingBag className="h-3.5 w-3.5" />
                  شراء من المتجر
                </button>
                <button
                  type="button"
                  onClick={() => setMerchantTab('sell')}
                  className={`flex items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-xs font-bold ${
                    merchantTab === 'sell'
                      ? 'bg-amber-600 text-white'
                      : 'border border-slate-700 bg-slate-800 text-slate-300'
                  }`}
                >
                  <Coins className="h-3.5 w-3.5" />
                  بيع من حقيبتك
                </button>
              </div>

              {merchantTab === 'buy' ? (
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                  {MERCHANT_STOCK.map((s) => {
                    const item = ITEMS[s.itemId];
                    if (!item) return null;
                    const canAfford = gold >= s.price;
                    return (
                      <div
                        key={s.itemId}
                        className="flex items-center justify-between gap-2 rounded-xl border border-slate-700 bg-slate-950/60 p-2.5"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 bg-slate-900">
                            <ItemIcon kind={item.icon} tintHex={item.tintHex} className="h-7 w-7" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-100">{item.nameAr}</div>
                            <div className="text-[10px] text-slate-400">{item.descriptionAr}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={!canAfford}
                          onClick={() => onBuyItem(s.itemId, s.price)}
                          className={`shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-bold ${
                            canAfford
                              ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          {s.price} ذهب
                        </button>
                      </div>
                    );
                  })}
                </div>
              ) : inventory.length === 0 ? (
                <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4 text-center text-xs text-slate-400">
                  حقيبتك فارغة حالياً.
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {inventory.map((entry, idx) => {
                    const item = ITEMS[entry.itemId];
                    if (!item) return null;
                    const sellPrice = Math.max(4, Math.round(item.valueGold * 0.55));
                    return (
                      <div
                        key={`${entry.itemId}_${idx}`}
                        className="flex items-center justify-between gap-2 rounded-xl border border-slate-700 bg-slate-950/60 p-2.5"
                      >
                        <div className="flex items-center gap-2">
                          <ItemIcon kind={item.icon} tintHex={item.tintHex} className="h-7 w-7" />
                          <div>
                            <div className="text-xs font-bold text-slate-100">
                              {item.nameAr} ×{entry.quantity}
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => onSellItem(idx)}
                          className="rounded-lg bg-amber-600 px-2.5 py-1.5 text-xs font-bold text-white hover:bg-amber-500"
                        >
                          بيع (+{sellPrice})
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Role 3: Blacksmith */}
          {npc.role === 'blacksmith' && (
            <div className="space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-orange-300">
                <Hammer className="h-4 w-4" />
                <span>الحدادة وتصنيع العتاد</span>
              </div>
              {BLACKSMITH_FORGE.map((recipe, idx) => {
                const item = ITEMS[recipe.itemId];
                if (!item) return null;
                const hasGold = gold >= recipe.goldCost;
                const hasAllMats = recipe.materials.every((m) => {
                  const inv = inventory.find((i) => i.itemId === m.itemId);
                  return (inv?.quantity ?? 0) >= m.qty;
                });
                const canCraft = hasGold && hasAllMats;

                return (
                  <div
                    key={recipe.itemId}
                    className="flex flex-col justify-between gap-3 rounded-xl border border-slate-700 bg-slate-950/60 p-3 sm:flex-row sm:items-center"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700 bg-slate-900">
                        <ItemIcon kind={item.icon} tintHex={item.tintHex} className="h-8 w-8" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-amber-100">{item.nameAr}</div>
                        <div className="text-[11px] text-slate-400">{item.descriptionAr}</div>
                        <div className="mt-1 flex flex-wrap gap-2 text-[10px]">
                          <span className={hasGold ? 'text-amber-300' : 'text-rose-400'}>
                            {recipe.goldCost} ذهب
                          </span>
                          {recipe.materials.map((m) => {
                            const owned = inventory.find((i) => i.itemId === m.itemId)?.quantity ?? 0;
                            const mDef = ITEMS[m.itemId];
                            return (
                              <span
                                key={m.itemId}
                                className={owned >= m.qty ? 'text-emerald-300' : 'text-rose-400'}
                              >
                                {mDef?.nameAr}: {owned}/{m.qty}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={!canCraft}
                      onClick={() => onCraftItem(idx)}
                      className={`shrink-0 rounded-xl px-4 py-2 text-xs font-bold ${
                        canCraft
                          ? 'bg-orange-600 text-white hover:bg-orange-500'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      تصنيع
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Role 4: Healer */}
          {npc.role === 'healer' && (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-rose-500/30 bg-rose-950/20 p-4 text-center">
              <HeartPulse className="h-9 w-9 text-rose-400" />
              <p className="text-xs text-slate-300">
                تستعيد هنا كامل نقاط الحياة (HP) وطاقة السحر (Mana) والنشاط ومؤشرات البقاء مجاناً.
              </p>
              <button
                type="button"
                onClick={onHealPlayer}
                className="flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-emerald-500"
              >
                <Sparkles className="h-4 w-4" />
                علاج واستعادة الطاقة بالكامل
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
