import React, { useRef, useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { useAuth } from '../context/AuthContext';
import { CIVILIZATIONS } from '../game/gameConfig';
import {
  Wheat,
  Trees,
  Mountain,
  Coins,
  Warehouse,
  Users,
  Trophy,
  Clock,
  User,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ResourceType } from '../types/kingdom';
import { ResourceDetailModal } from './ResourceDetailModal';

interface HeaderResourcesProps {
  onOpenAccount?: () => void;
  onNavigateTab?: (tab: 'village' | 'construction' | 'university' | 'army' | 'map' | 'parliament') => void;
  onOpenResourceDetail?: (res: ResourceType) => void;
  onOpenPopulation?: () => void;
  onOpenSeason?: () => void;
}

export const HeaderResources: React.FC<HeaderResourcesProps> = ({
  onOpenAccount,
  onNavigateTab,
  onOpenResourceDetail,
  onOpenPopulation,
  onOpenSeason,
}) => {
  const {
    kingdom,
    rates,
    storageMax,
    maxPopulation,
    demographicRate,
    isSyncing,
    playSound,
    soundEnabled,
    toggleSound,
  } = useKingdom();
  const { user } = useAuth();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedResourceForModal, setSelectedResourceForModal] = useState<ResourceType>('food');

  if (!kingdom) return null;

  const civ = CIVILIZATIONS[kingdom.civilization];

  const formatRes = (val: number) => {
    if (val >= 1000000) return (val / 1000000).toFixed(1) + 'M';
    if (val >= 10000) return (val / 1000).toFixed(1) + 'k';
    return Math.floor(val).toLocaleString();
  };

  const formatRate = (rate: number) => {
    const sign = rate >= 0 ? '+' : '';
    return `${sign}${rate}/h`;
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -220 : 220;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const openResourceDetail = (res: ResourceType) => {
    if (onOpenResourceDetail) {
      onOpenResourceDetail(res);
    } else {
      setSelectedResourceForModal(res);
      setDetailModalOpen(true);
    }
    playSound('click');
  };

  const foodPct = Math.min(100, Math.round((kingdom.resources.food / storageMax.foodMax) * 100));
  const woodPct = Math.min(100, Math.round((kingdom.resources.wood / storageMax.resourcesMax) * 100));
  const stonePct = Math.min(100, Math.round((kingdom.resources.stone / storageMax.resourcesMax) * 100));
  const goldPct = Math.min(100, Math.round((kingdom.resources.gold / storageMax.resourcesMax) * 100));

  const totalCitizens =
    kingdom.workerAllocation.farmers +
    kingdom.workerAllocation.woodcutters +
    kingdom.workerAllocation.miners +
    kingdom.workerAllocation.mintWorkers;

  const resourceItems = [
    {
      type: 'food' as ResourceType,
      name: 'Comida',
      amount: kingdom.resources.food,
      max: storageMax.foodMax,
      rate: rates.foodPerHour,
      pct: foodPct,
      icon: <Wheat className="w-4 h-4 text-amber-500" />,
      badgeBg: 'bg-amber-950/60 text-amber-400 border-amber-800/60',
      barColor: foodPct >= 95 ? 'bg-red-500' : foodPct >= 80 ? 'bg-amber-500' : 'bg-amber-400',
      title: `Comida: ${Math.floor(kingdom.resources.food).toLocaleString()} / ${storageMax.foodMax.toLocaleString()} (${foodPct}% lleno)\nProducción neta: ${formatRate(rates.foodPerHour)}\nHaz clic para ver desglose de granero y consumo.`,
      ariaLabel: `Comida: ${Math.floor(kingdom.resources.food).toLocaleString()} de ${storageMax.foodMax.toLocaleString()} (${foodPct}% lleno). Producción neta: ${formatRate(rates.foodPerHour)}`,
    },
    {
      type: 'wood' as ResourceType,
      name: 'Madera',
      amount: kingdom.resources.wood,
      max: storageMax.resourcesMax,
      rate: rates.woodPerHour,
      pct: woodPct,
      icon: <Trees className="w-4 h-4 text-emerald-500" />,
      badgeBg: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/60',
      barColor: woodPct >= 95 ? 'bg-red-500' : woodPct >= 80 ? 'bg-amber-500' : 'bg-emerald-400',
      title: `Madera: ${Math.floor(kingdom.resources.wood).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${woodPct}% lleno)\nProducción neta: ${formatRate(rates.woodPerHour)}\nHaz clic para ver desglose de aserradero y reservas.`,
      ariaLabel: `Madera: ${Math.floor(kingdom.resources.wood).toLocaleString()} de ${storageMax.resourcesMax.toLocaleString()} (${woodPct}% lleno). Producción neta: ${formatRate(rates.woodPerHour)}`,
    },
    {
      type: 'stone' as ResourceType,
      name: 'Piedra',
      amount: kingdom.resources.stone,
      max: storageMax.resourcesMax,
      rate: rates.stonePerHour,
      pct: stonePct,
      icon: <Mountain className="w-4 h-4 text-slate-400" />,
      badgeBg: 'bg-slate-900 text-slate-300 border-slate-700',
      barColor: stonePct >= 95 ? 'bg-red-500' : stonePct >= 80 ? 'bg-amber-500' : 'bg-slate-400',
      title: `Piedra: ${Math.floor(kingdom.resources.stone).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${stonePct}% lleno)\nProducción neta: ${formatRate(rates.stonePerHour)}\nHaz clic para ver desglose de cantera y almacenes.`,
      ariaLabel: `Piedra: ${Math.floor(kingdom.resources.stone).toLocaleString()} de ${storageMax.resourcesMax.toLocaleString()} (${stonePct}% lleno). Producción neta: ${formatRate(rates.stonePerHour)}`,
    },
    {
      type: 'gold' as ResourceType,
      name: 'Oro',
      amount: kingdom.resources.gold,
      max: storageMax.resourcesMax,
      rate: rates.goldPerHour,
      pct: goldPct,
      icon: <Coins className="w-4 h-4 text-yellow-400" />,
      badgeBg: 'bg-yellow-950/60 text-yellow-300 border-yellow-800/60',
      barColor: goldPct >= 95 ? 'bg-red-500' : goldPct >= 80 ? 'bg-amber-500' : 'bg-yellow-400',
      title: `Oro: ${Math.floor(kingdom.resources.gold).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${goldPct}% lleno)\nProducción neta: ${formatRate(rates.goldPerHour)}\nHaz clic para ver desglose de mina de oro y tributos.`,
      ariaLabel: `Oro: ${Math.floor(kingdom.resources.gold).toLocaleString()} de ${storageMax.resourcesMax.toLocaleString()} (${goldPct}% lleno). Producción neta: ${formatRate(rates.goldPerHour)}`,
    },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-stone-900/95 backdrop-blur border-b border-stone-800 shadow-lg px-3 py-2 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-2">
          {/* Top Row: Kingdom Identity & Quick Profile Badges */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="text-2xl p-1.5 rounded-xl bg-stone-800/90 border border-stone-700 shadow-inner shrink-0"
                title={`Civilización: ${civ.name} (${civ.description})`}
              >
                {civ.badge}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h1 className="font-bold text-stone-100 text-sm sm:text-base leading-tight font-serif tracking-wide truncate">
                    {kingdom.kingdomName}
                  </h1>
                  <span
                    className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-950/80 border border-amber-800/60 text-amber-300 shrink-0"
                    title={civ.description}
                  >
                    {civ.name}
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 leading-tight truncate">
                  {civ.leaderTitle} • {kingdom.castleName}
                </p>
              </div>
            </div>

            {/* Right Meta Controls: Glory, Orders & Account */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Active Queues mini badge */}
              {(kingdom.constructionQueue.length > 0 ||
                kingdom.researchQueue.length > 0 ||
                kingdom.trainingQueue.length > 0) && (
                <div
                  className="flex items-center gap-1.5 bg-stone-800/90 border border-stone-700/80 px-2 py-1 rounded-xl text-[11px] text-stone-300 shrink-0"
                  title={`Obras en construcción: ${kingdom.constructionQueue.length} | Investigaciones: ${kingdom.researchQueue.length} | Adiestramiento: ${kingdom.trainingQueue.length}`}
                >
                  <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                  <span className="font-semibold font-mono">
                    {kingdom.constructionQueue.length +
                      kingdom.researchQueue.length +
                      kingdom.trainingQueue.length}
                  </span>
                  <span className="hidden md:inline text-[10px] text-stone-400">órdenes</span>
                </div>
              )}

              {/* Population / Citizens Quick Badge */}
              <button
                type="button"
                onClick={onOpenPopulation}
                className="flex items-center gap-1.5 bg-stone-800/90 hover:bg-stone-750 border border-stone-700/80 px-2 sm:px-2.5 py-1 rounded-xl text-stone-300 hover:text-stone-100 transition cursor-pointer shrink-0"
                title={`Población: ${Math.floor(kingdom.population)} / ${maxPopulation} habitantes (${demographicRate.statusText})\nClic para abrir el Censo Feudal y gestión demográfica.`}
              >
                <Users className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs font-bold font-mono">
                  {Math.floor(kingdom.population)}
                </span>
                <span className="text-[10px] text-stone-400">
                  /{maxPopulation}
                </span>
                {demographicRate.growthPerHour > 0 && (
                  <span className="hidden sm:inline text-[9px] text-emerald-400 font-mono font-semibold">
                    +{demographicRate.growthPerHour}/h
                  </span>
                )}
              </button>

              {/* Glory Points Badge */}
              <button
                type="button"
                onClick={onOpenSeason}
                className="flex items-center gap-1.5 bg-amber-950/40 hover:bg-amber-950/60 border border-amber-800/50 px-2.5 py-1 rounded-xl text-amber-300 hover:text-amber-200 transition cursor-pointer shrink-0"
                title={`Puntos de Gloria acumulados: ${kingdom.gloryPoints.toLocaleString()} honor y prestigio (clic para ver temporada y ranking)`}
              >
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs font-bold font-mono">
                  {kingdom.gloryPoints.toLocaleString()}
                </span>
                <span className="hidden sm:inline text-[10px] text-amber-400/80 uppercase">
                  Gloria
                </span>
              </button>

              {/* Sound Audio Mute / Unmute Quick Toggle */}
              <button
                type="button"
                onClick={() => {
                  const nowEnabled = toggleSound();
                  if (nowEnabled) playSound('click');
                }}
                className="flex items-center justify-center p-2 bg-stone-800/90 hover:bg-stone-750 border border-stone-700 rounded-xl text-xs transition cursor-pointer shrink-0"
                title={soundEnabled ? 'Sonidos activados (clic para silenciar)' : 'Sonidos silenciados (clic para activar)'}
                aria-label={soundEnabled ? 'Silenciar sonidos' : 'Activar efectos de sonido'}
              >
                {soundEnabled ? (
                  <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                ) : (
                  <VolumeX className="w-3.5 h-3.5 text-stone-500" />
                )}
              </button>

              {/* Account Profile / Cloud status button */}
              {user && (
                <button
                  id="header-account-btn"
                  type="button"
                  onClick={onOpenAccount}
                  className="flex items-center gap-1.5 bg-stone-800/90 hover:bg-stone-750 border border-stone-700 px-2.5 py-1 rounded-xl text-xs text-stone-200 transition cursor-pointer shrink-0"
                  title="Ver perfil de jugador y estado de guardado en la nube"
                  aria-label={`Cuenta de jugador: ${user.email || 'Soberano'}`}
                >
                  <div className="relative">
                    <User className="w-3.5 h-3.5 text-amber-400" />
                    <span
                      className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${
                        isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'
                      }`}
                    />
                  </div>
                  <span className="hidden sm:inline text-[11px] font-medium max-w-[100px] md:max-w-[130px] truncate">
                    {user.email || (user.isAnonymous ? 'Invitado' : user.displayName || 'Soberano')}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Bottom Row: Sliding Line of Resources */}
          <div className="relative flex items-center group pt-1 border-t border-stone-800/60">
            <button
              onClick={() => handleScroll('left')}
              className="absolute left-0 z-10 p-1.5 rounded-lg bg-stone-900/90 hover:bg-stone-800 border border-stone-700 text-stone-300 hover:text-amber-400 transition shadow-md hidden sm:flex items-center justify-center -ml-2 cursor-pointer"
              aria-label="Desplazar recursos hacia la izquierda"
              title="Desplazar recursos a la izquierda"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div
              ref={scrollContainerRef}
              className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth w-full py-0.5 px-0.5"
            >
              {resourceItems.map((item) => (
                <button
                  key={item.type}
                  onClick={() => openResourceDetail(item.type)}
                  className="flex items-center gap-2.5 bg-stone-950/80 hover:bg-stone-850/90 border border-stone-800 hover:border-amber-700/60 px-2.5 py-1.5 rounded-xl transition text-left shrink-0 min-w-[160px] sm:min-w-[175px] cursor-pointer group/card shadow-sm"
                  title={item.title}
                  aria-label={item.ariaLabel}
                >
                  <div
                    className={`p-1.5 rounded-lg border shrink-0 transition-transform group-hover/card:scale-105 ${item.badgeBg}`}
                  >
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <span className="text-[11px] font-bold text-stone-200 group-hover/card:text-amber-400 transition truncate">
                        {item.name}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-medium shrink-0 ${
                          item.rate >= 0 ? 'text-emerald-400' : 'text-red-400'
                        }`}
                        title={`Producción horaria: ${formatRate(item.rate)}`}
                      >
                        {formatRate(item.rate)}
                      </span>
                    </div>
                    <div className="flex items-baseline justify-between text-xs font-mono leading-none mb-1">
                      <span className="font-bold text-stone-100">{formatRes(item.amount)}</span>
                      <span className="text-[10px] text-stone-400">/ {formatRes(item.max)}</span>
                    </div>
                    <div
                      className="w-full bg-stone-800 h-1 rounded-full overflow-hidden"
                      title={`${item.pct}% de capacidad`}
                    >
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${item.barColor}`}
                        style={{ width: `${item.pct}%` }}
                      />
                    </div>
                  </div>
                </button>
              ))}

              {/* Extra Sliding Pill: Population / Workers */}
              <button
                onClick={() => {
                  if (onNavigateTab) onNavigateTab('parliament');
                  playSound('click');
                }}
                className="flex items-center gap-2 bg-stone-950/80 hover:bg-stone-850/90 border border-stone-800 hover:border-amber-700/60 px-2.5 py-1.5 rounded-xl transition text-left shrink-0 min-w-[145px] cursor-pointer group/pop shadow-sm"
                title={`Trabajadores activos: ${totalCitizens}% aldeanos distribuidos en labores\nHaz clic para gestionar mano de obra en el Parlamento`}
                aria-label={`Trabajadores: ${totalCitizens}% asignados`}
              >
                <div className="p-1.5 rounded-lg bg-blue-950/50 border border-blue-800/60 text-blue-400 shrink-0">
                  <Users className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-stone-200 group-hover/pop:text-amber-400 transition truncate">
                    Trabajadores
                  </div>
                  <div className="text-xs font-mono text-stone-100 font-bold">
                    {totalCitizens}% <span className="text-[10px] text-stone-400 font-normal">asignados</span>
                  </div>
                  <div className="text-[9px] text-blue-400/90 font-medium truncate">
                    Gestión laboral
                  </div>
                </div>
              </button>

              {/* Extra Sliding Pill: Storage Overview */}
              <button
                onClick={() => openResourceDetail('food')}
                className="flex items-center gap-2 bg-stone-950/80 hover:bg-stone-850/90 border border-stone-800 hover:border-amber-700/60 px-2.5 py-1.5 rounded-xl transition text-left shrink-0 min-w-[145px] cursor-pointer group/stor shadow-sm"
                title={`Graneros: ${formatRes(storageMax.foodMax)} comida máx\nAlmacenes: ${formatRes(storageMax.resourcesMax)} materiales máx\nHaz clic para ver estado de tesorería`}
                aria-label="Capacidad de graneros y almacenes"
              >
                <div className="p-1.5 rounded-lg bg-amber-950/50 border border-amber-800/60 text-amber-400 shrink-0">
                  <Warehouse className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-stone-200 group-hover/stor:text-amber-400 transition truncate">
                    Almacenes
                  </div>
                  <div className="text-xs font-mono text-stone-100 font-bold truncate">
                    {formatRes(storageMax.resourcesMax)} máx
                  </div>
                  <div className="text-[9px] text-amber-400/90 font-medium truncate">
                    Detalle tesorería
                  </div>
                </div>
              </button>
            </div>

            <button
              onClick={() => handleScroll('right')}
              className="absolute right-0 z-10 p-1.5 rounded-lg bg-stone-900/90 hover:bg-stone-800 border border-stone-700 text-stone-300 hover:text-amber-400 transition shadow-md hidden sm:flex items-center justify-center -mr-2 cursor-pointer"
              aria-label="Desplazar recursos hacia la derecha"
              title="Desplazar recursos a la derecha"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Resource Detail and Treasury Breakdown Modal */}
      <ResourceDetailModal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        initialResource={selectedResourceForModal}
        onNavigateTab={onNavigateTab}
      />
    </>
  );
};
