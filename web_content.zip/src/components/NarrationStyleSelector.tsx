import React from 'react';
import {
  Volume2,
  BookOpen,
  Heart,
  Flame,
  Clapperboard,
  Compass,
  Newspaper,
  GraduationCap,
  Mic,
  Video,
  Eye,
  CloudRain,
  Sparkles,
  Zap,
  Moon,
  Shield,
  Sun,
  Feather,
  MessagesSquare,
  Wind,
} from 'lucide-react';
import { NarrationStyleId } from '../types/tts';
import { NARRATION_STYLES } from '../data/voicesAndStyles';

interface NarrationStyleSelectorProps {
  selectedStyleId: NarrationStyleId;
  onSelectStyle: (styleId: NarrationStyleId) => void;
}

export const NarrationStyleSelector: React.FC<NarrationStyleSelectorProps> = ({
  selectedStyleId,
  onSelectStyle,
}) => {
  // Icon mapper
  const getIcon = (id: NarrationStyleId) => {
    switch (id) {
      case 'normal':
        return <Volume2 className="w-4 h-4" />;
      case 'storytelling':
        return <BookOpen className="w-4 h-4 text-amber-300" />;
      case 'emotional':
        return <Heart className="w-4 h-4 text-pink-400" />;
      case 'motivational':
        return <Flame className="w-4 h-4 text-amber-400" />;
      case 'cinematic':
        return <Clapperboard className="w-4 h-4 text-purple-400" />;
      case 'documentary':
        return <Compass className="w-4 h-4 text-cyan-400" />;
      case 'news':
        return <Newspaper className="w-4 h-4 text-blue-400" />;
      case 'educational':
        return <GraduationCap className="w-4 h-4 text-emerald-400" />;
      case 'podcast':
        return <Mic className="w-4 h-4 text-indigo-400" />;
      case 'youtube':
        return <Video className="w-4 h-4 text-red-400" />;
      case 'suspense':
        return <Eye className="w-4 h-4 text-yellow-400" />;
      case 'sad':
        return <CloudRain className="w-4 h-4 text-slate-400" />;
      case 'inspirational':
        return <Sparkles className="w-4 h-4 text-yellow-300" />;
      case 'energetic':
        return <Zap className="w-4 h-4 text-orange-400" />;
      case 'calm':
        return <Moon className="w-4 h-4 text-teal-400" />;
      case 'serious':
        return <Shield className="w-4 h-4 text-blue-300" />;
      case 'devotional':
        return <Sun className="w-4 h-4 text-amber-300" />;
      case 'poetry':
        return <Feather className="w-4 h-4 text-rose-300" />;
      case 'dialogue':
        return <MessagesSquare className="w-4 h-4 text-emerald-300" />;
      case 'whisper':
        return <Wind className="w-4 h-4 text-cyan-300" />;
      default:
        return <Volume2 className="w-4 h-4" />;
    }
  };

  const selectedStyle = NARRATION_STYLES.find((s) => s.id === selectedStyleId) || NARRATION_STYLES[0];

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>వ్యాఖ్యాన రీతులు</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Narration Styles ({NARRATION_STYLES.length})
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            ఎంచుకున్న రీతి ఆధారంగా గళ శైలి, విరామాలు మరియు భావ వ్యక్తీకరణ సర్దుబాటు చేయబడతాయి
          </p>
        </div>

        <div className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
          <span className="text-slate-500">ప్రస్తుత రీతి:</span>
          <span className="font-bold text-cyan-400 flex items-center gap-1.5">
            {getIcon(selectedStyle.id)}
            <span>{selectedStyle.name}</span>
            <span className="text-slate-400 font-telugu">({selectedStyle.teluguName})</span>
          </span>
        </div>
      </div>

      {/* Grid of Styles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-2">
        {NARRATION_STYLES.map((style) => {
          const isSelected = selectedStyleId === style.id;
          return (
            <button
              key={style.id}
              id={`style-btn-${style.id}`}
              type="button"
              onClick={() => onSelectStyle(style.id)}
              className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 min-h-[78px] ${
                isSelected
                  ? 'bg-gradient-to-b from-cyan-500/20 to-slate-900 border-cyan-500/80 ring-1 ring-cyan-500/40 text-cyan-200 shadow-md shadow-cyan-950/30'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-800/80 text-slate-300'
              }`}
              title={style.description}
            >
              <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'}`}>
                {getIcon(style.id)}
              </div>
              <div className="w-full">
                <div className="text-xs font-bold truncate leading-tight">{style.name}</div>
                <div className="text-[10px] text-slate-400 font-telugu truncate mt-0.5">
                  {style.teluguName}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Style Detail Footer */}
      <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
        <div className="flex items-center gap-2">
          <span className="text-slate-500">శైలి వివరణ:</span>
          <span className="text-slate-300">{selectedStyle.description}</span>
        </div>

        <div className="flex items-center gap-3 text-[11px] font-mono text-slate-500">
          <span>వేగం గుణకం: {selectedStyle.speedMultiplier}x</span>
          <span>•</span>
          <span>వాక్య విరామం: {selectedStyle.sentencePauseMs}ms</span>
        </div>
      </div>
    </div>
  );
};
