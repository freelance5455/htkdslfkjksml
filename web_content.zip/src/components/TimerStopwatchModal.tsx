import React, { useState, useEffect, useRef } from 'react';
import { ClockTheme } from '../types/clock';
import { soundService } from '../services/soundService';
import { Play, Pause, RotateCcw, Flag, X, Timer, Hourglass } from 'lucide-react';

interface TimerStopwatchModalProps {
  theme: ClockTheme;
  onClose: () => void;
}

export const TimerStopwatchModal: React.FC<TimerStopwatchModalProps> = ({ theme, onClose }) => {
  const [mode, setMode] = useState<'timer' | 'stopwatch'>('timer');

  // --- Timer State ---
  const [timerSecondsTotal, setTimerSecondsTotal] = useState(300); // 5 mins default
  const [timerRemaining, setTimerRemaining] = useState(300);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerIntervalRef = useRef<number | null>(null);

  // --- Stopwatch State ---
  const [stopwatchElapsed, setStopwatchElapsed] = useState(0); // in ms
  const [isStopwatchRunning, setIsStopwatchRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const stopwatchIntervalRef = useRef<number | null>(null);
  const stopwatchStartRef = useRef<number>(0);

  // Clean intervals on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (stopwatchIntervalRef.current) clearInterval(stopwatchIntervalRef.current);
    };
  }, []);

  // Timer Tick
  useEffect(() => {
    if (isTimerRunning) {
      timerIntervalRef.current = window.setInterval(() => {
        setTimerRemaining((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            soundService.playSound('marimba', 0.9);
            soundService.playHourlyChime(0.8);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isTimerRunning]);

  // Stopwatch Tick
  useEffect(() => {
    if (isStopwatchRunning) {
      stopwatchStartRef.current = Date.now() - stopwatchElapsed;
      stopwatchIntervalRef.current = window.setInterval(() => {
        setStopwatchElapsed(Date.now() - stopwatchStartRef.current);
      }, 33);
    } else {
      if (stopwatchIntervalRef.current) {
        clearInterval(stopwatchIntervalRef.current);
      }
    }
    return () => {
      if (stopwatchIntervalRef.current) clearInterval(stopwatchIntervalRef.current);
    };
  }, [isStopwatchRunning]);

  // Timer helpers
  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSetTimerPreset = (secs: number) => {
    setIsTimerRunning(false);
    setTimerSecondsTotal(secs);
    setTimerRemaining(secs);
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimerRemaining(timerSecondsTotal);
  };

  // Stopwatch helpers
  const formatStopwatch = (totalMs: number) => {
    const mins = Math.floor(totalMs / 60000);
    const secs = Math.floor((totalMs % 60000) / 1000);
    const hundredths = Math.floor((totalMs % 1000) / 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${hundredths.toString().padStart(2, '0')}`;
  };

  const recordLap = () => {
    if (stopwatchElapsed > 0) {
      setLaps([stopwatchElapsed, ...laps]);
    }
  };

  const resetStopwatch = () => {
    setIsStopwatchRunning(false);
    setStopwatchElapsed(0);
    setLaps([]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div
        className="w-full max-w-lg rounded-3xl border p-6 sm:p-8 space-y-6 shadow-2xl"
        style={{
          backgroundColor: theme.surfaceBg,
          borderColor: theme.border,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b pb-4" style={{ borderColor: theme.border }}>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-neutral-900 border border-neutral-800">
            <button
              onClick={() => setMode('timer')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'timer' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Hourglass className="w-3.5 h-3.5" />
              <span>Countdown Timer</span>
            </button>
            <button
              onClick={() => setMode('stopwatch')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'stopwatch' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Timer className="w-3.5 h-3.5" />
              <span>Stopwatch</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* --- Timer Mode --- */}
        {mode === 'timer' && (
          <div className="space-y-6 text-center">
            {/* Display */}
            <div className="py-4">
              <div
                className="text-6xl sm:text-7xl font-mono font-bold tracking-tight tabular-nums select-none"
                style={{ color: theme.textPrimary }}
              >
                {formatTimer(timerRemaining)}
              </div>
              <div className="w-full max-w-xs mx-auto mt-4 h-1.5 rounded-full overflow-hidden bg-neutral-800">
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${timerSecondsTotal > 0 ? (timerRemaining / timerSecondsTotal) * 100 : 0}%`,
                    backgroundColor: theme.textAccent,
                  }}
                />
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm shadow-md transition-all active:scale-95"
                style={{
                  backgroundColor: theme.textAccent,
                  color: '#fff',
                }}
              >
                {isTimerRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                <span>{isTimerRunning ? 'Pause' : 'Start'}</span>
              </button>

              <button
                onClick={resetTimer}
                className="p-3 rounded-2xl border text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                style={{ borderColor: theme.border }}
                title="Reset timer"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Presets */}
            <div>
              <span className="block text-xs uppercase tracking-wider text-slate-400 mb-2">
                Quick Presets
              </span>
              <div className="flex flex-wrap justify-center gap-2">
                {[
                  { label: '1m', secs: 60 },
                  { label: '3m', secs: 180 },
                  { label: '5m', secs: 300 },
                  { label: '10m', secs: 600 },
                  { label: '15m', secs: 900 },
                  { label: '25m (Pomodoro)', secs: 1500 },
                  { label: '30m', secs: 1800 },
                  { label: '45m', secs: 2700 },
                  { label: '60m', secs: 3600 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => handleSetTimerPreset(preset.secs)}
                    className="px-3 py-1.5 text-xs font-medium rounded-xl border hover:bg-white/5 transition-colors"
                    style={{
                      borderColor: theme.border,
                      color: timerSecondsTotal === preset.secs ? theme.textAccent : theme.textSecondary,
                    }}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* --- Stopwatch Mode --- */}
        {mode === 'stopwatch' && (
          <div className="space-y-6 text-center">
            {/* Display */}
            <div className="py-4">
              <div
                className="text-5xl sm:text-6xl font-mono font-bold tracking-tight tabular-nums select-none"
                style={{ color: theme.textPrimary }}
              >
                {formatStopwatch(stopwatchElapsed)}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setIsStopwatchRunning(!isStopwatchRunning)}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm shadow-md transition-all active:scale-95"
                style={{
                  backgroundColor: theme.textAccent,
                  color: '#fff',
                }}
              >
                {isStopwatchRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                <span>{isStopwatchRunning ? 'Pause' : 'Start'}</span>
              </button>

              <button
                onClick={recordLap}
                disabled={!isStopwatchRunning}
                className="flex items-center gap-1.5 px-4 py-3 rounded-2xl border text-sm font-semibold text-slate-300 hover:bg-white/5 disabled:opacity-40 transition-colors"
                style={{ borderColor: theme.border }}
              >
                <Flag className="w-4 h-4" />
                <span>Lap</span>
              </button>

              <button
                onClick={resetStopwatch}
                className="p-3 rounded-2xl border text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                style={{ borderColor: theme.border }}
                title="Reset stopwatch"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>

            {/* Laps List */}
            {laps.length > 0 && (
              <div className="max-h-40 overflow-y-auto rounded-xl border p-2 space-y-1" style={{ borderColor: theme.border }}>
                {laps.map((lapTime, idx) => (
                  <div
                    key={idx}
                    className="flex justify-between items-center text-xs font-mono px-3 py-1.5 rounded-lg bg-black/20"
                  >
                    <span className="text-slate-400">Lap {laps.length - idx}</span>
                    <span className="font-semibold" style={{ color: theme.textPrimary }}>
                      {formatStopwatch(lapTime)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
