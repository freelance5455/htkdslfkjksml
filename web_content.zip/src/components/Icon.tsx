import React from 'react';
import {
  AlertTriangle,
  BarChart3,
  Barcode,
  Clock,
  Download,
  FileSpreadsheet,
  Home,
  ArrowLeftRight,
  Menu,
  Package,
  Pencil,
  Plus,
  Printer,
  Receipt,
  Search,
  Settings,
  ShoppingCart,
  Tag,
  Trash2,
  Users,
  Wallet,
  X,
} from 'lucide-react';

export type IconName =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'stock'
  | 'customers'
  | 'sales'
  | 'expenses'
  | 'analytics'
  | 'reports'
  | 'categories'
  | 'settings'
  | 'plus'
  | 'trash'
  | 'edit'
  | 'print'
  | 'barcode'
  | 'search'
  | 'clock'
  | 'menu'
  | 'x'
  | 'download'
  | 'alert';

interface IconProps {
  name: IconName;
  className?: string;
}

export const Icon: React.FC<IconProps> = ({ name, className = 'w-5 h-5' }) => {
  const map: Record<IconName, React.ReactNode> = {
    dashboard: <Home className={className} strokeWidth={1.9} />,
    pos: <ShoppingCart className={className} strokeWidth={1.9} />,
    products: <Package className={className} strokeWidth={1.9} />,
    stock: <ArrowLeftRight className={className} strokeWidth={1.9} />,
    customers: <Users className={className} strokeWidth={1.9} />,
    sales: <Receipt className={className} strokeWidth={1.9} />,
    expenses: <Wallet className={className} strokeWidth={1.9} />,
    analytics: <BarChart3 className={className} strokeWidth={1.9} />,
    reports: <FileSpreadsheet className={className} strokeWidth={1.9} />,
    categories: <Tag className={className} strokeWidth={1.9} />,
    settings: <Settings className={className} strokeWidth={1.9} />,
    plus: <Plus className={className} strokeWidth={2.1} />,
    trash: <Trash2 className={className} strokeWidth={1.9} />,
    edit: <Pencil className={className} strokeWidth={1.9} />,
    print: <Printer className={className} strokeWidth={1.9} />,
    barcode: <Barcode className={className} strokeWidth={1.9} />,
    search: <Search className={className} strokeWidth={1.9} />,
    clock: <Clock className={className} strokeWidth={1.9} />,
    menu: <Menu className={className} strokeWidth={2} />,
    x: <X className={className} strokeWidth={2} />,
    download: <Download className={className} strokeWidth={1.9} />,
    alert: <AlertTriangle className={className} strokeWidth={1.9} />,
  };

  return <>{map[name] || null}</>;
};
