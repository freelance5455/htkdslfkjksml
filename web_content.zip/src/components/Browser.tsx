"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { HOME_URL, SEARCH_ENGINES, hostOf, normalizeInput, type SearchEngineId } from "@/lib/browser";
import { DEFAULT_SETTINGS, applyTheme, loadJSON, newTab, saveJSON, type Settings, type Tab } from "@/lib/store";
import { AddressBar } from "./AddressBar";
import { TabBar } from "./TabBar";
import { HomePage } from "./HomePage";
import { AIChat } from "./AIChat";
import { BookmarksPanel, DownloadsPanel, HistoryPanel, SettingsPanel } from "./Panels";
import { Favicon, Icon, IconButton } from "./ui";

type PanelId = "ai" | "history" | "bookmarks" | "downloads" | "settings" | null;
type Task = "chat" | "summarize" | "translate" | "page" | "tabs" | "code";

const SLEEP_AFTER = 10 * 60 * 1000;

export default function Browser() {
  const [ready, setReady] = useState(false);
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activeId, setActiveId] = useState("");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [extensions, setExtensions] = useState<Record<string, boolean>>({ adblock: true, readermode: true, translate: true, darkweb: false });
  const [panel, setPanel] = useState<PanelId>(null);
  const [menu, setMenu] = useState(false);
  const [tabSwitcher, setTabSwitcher] = useState(false);
  const [bookmarked, setBookmarked] = useState<Set<string>>(new Set());
  const [blocked, setBlocked] = useState<Record<string, number>>({});
  const [pendingPrompt, setPendingPrompt] = useState<{ text: string; task: Task; nonce: number } | null>(null);
  const [toast, setToast] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const frames = useRef<Record<string, HTMLIFrameElement | null>>({});
  const lastRecorded = useRef<Record<string, string>>({});
  const textWaiters = useRef<((v: { title: string; url: string; text: string }) => void)[]>([]);
  const tabsRef = useRef<Tab[]>([]);
  const activeRef = useRef("");
  tabsRef.current = tabs;
  activeRef.current = activeId;

  const active = tabs.find((t) => t.id === activeId);

  // ---------- Инициализация ----------
  useEffect(() => {
    const s = loadJSON<Settings>("nova.settings", DEFAULT_SETTINGS);
    setSettings(s);
    setExtensions(loadJSON("nova.extensions", { adblock: true, readermode: true, translate: true, darkweb: false }));
    const saved = loadJSON<{ tabs: Tab[]; activeId: string }>("nova.tabs", { tabs: [], activeId: "" });
    const restored = saved.tabs.filter((t) => !t.incognito).map((t) => ({ ...t, loading: false, sleeping: t.url !== HOME_URL, lastActive: Date.now() }));
    const first = restored.length ? restored : [newTab()];
    setTabs(first);
    const act = first.find((t) => t.id === saved.activeId) || first[0];
    setActiveId(act.id);
    // активную вкладку будим сразу
    setTabs((ts) => ts.map((t) => (t.id === act.id ? { ...t, sleeping: false, loading: t.url !== HOME_URL } : t)));
    applyTheme(s.theme, s.accent);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveJSON("nova.settings", settings);
    applyTheme(settings.theme, settings.accent);
  }, [settings, ready]);
  useEffect(() => {
    if (ready) saveJSON("nova.extensions", extensions);
  }, [extensions, ready]);
  useEffect(() => {
    if (ready) saveJSON("nova.tabs", { tabs: tabs.filter((t) => !t.incognito).map((t) => ({ ...t, loading: false })), activeId });
  }, [tabs, activeId, ready]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const h = () => applyTheme(settings.theme, settings.accent);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, [settings.theme, settings.accent]);

  useEffect(() => {
    fetch(`/api/bookmarks?profileId=${settings.profileId}`)
      .then((r) => r.json())
      .then((d: { url: string }[]) => setBookmarked(new Set((Array.isArray(d) ? d : []).map((b) => b.url))))
      .catch(() => {});
  }, [settings.profileId]);

  // Усыпление неактивных вкладок
  useEffect(() => {
    if (!settings.sleepTabs) return;
    const id = setInterval(() => {
      setTabs((ts) => ts.map((t) => (t.id !== activeRef.current && !t.sleeping && t.url !== HOME_URL && Date.now() - t.lastActive > SLEEP_AFTER ? { ...t, sleeping: true } : t)));
    }, 60000);
    return () => clearInterval(id);
  }, [settings.sleepTabs]);

  const showToast = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(""), 2200);
  };

  // ---------- Навигация ----------
  const updateTab = useCallback((id: string, patch: Partial<Tab> | ((t: Tab) => Partial<Tab>)) => {
    setTabs((ts) => ts.map((t) => (t.id === id ? { ...t, ...(typeof patch === "function" ? patch(t) : patch) } : t)));
  }, []);

  const navigate = useCallback(
    (input: string, opts: { tabId?: string; newTab?: boolean; incognito?: boolean } = {}) => {
      let url = normalizeInput(input, settings.engine);
      if (settings.httpsOnly && url.startsWith("http://") && !/^http:\/\/(localhost|\d+\.)/.test(url)) url = url.replace(/^http:/, "https:");
      if (opts.newTab || !tabsRef.current.length) {
        const parent = tabsRef.current.find((t) => t.id === (opts.tabId || activeRef.current));
        const t = newTab(url, opts.incognito ?? parent?.incognito ?? false);
        setTabs((ts) => [...ts, t]);
        setActiveId(t.id);
        return;
      }
      const id = opts.tabId || activeRef.current;
      updateTab(id, (t) => {
        const stack = [...t.stack.slice(0, t.index + 1), url];
        return { url, stack, index: stack.length - 1, loading: url !== HOME_URL, title: url === HOME_URL ? "Новая вкладка" : hostOf(url) || url, favicon: "", sleeping: false, lastActive: Date.now() };
      });
      setBlocked((b) => ({ ...b, [id]: 0 }));
    },
    [settings.engine, settings.httpsOnly, updateTab]
  );

  const goBack = useCallback(() => {
    const t = tabsRef.current.find((x) => x.id === activeRef.current);
    if (!t || t.index <= 0) return;
    const index = t.index - 1;
    updateTab(t.id, { index, url: t.stack[index], loading: t.stack[index] !== HOME_URL, sleeping: false });
  }, [updateTab]);
  const goForward = useCallback(() => {
    const t = tabsRef.current.find((x) => x.id === activeRef.current);
    if (!t || t.index >= t.stack.length - 1) return;
    const index = t.index + 1;
    updateTab(t.id, { index, url: t.stack[index], loading: t.stack[index] !== HOME_URL, sleeping: false });
  }, [updateTab]);
  const reload = useCallback(() => {
    const t = tabsRef.current.find((x) => x.id === activeRef.current);
    if (!t || t.url === HOME_URL) return;
    updateTab(t.id, { reloadKey: t.reloadKey + 1, loading: true, sleeping: false });
  }, [updateTab]);

  const addTab = useCallback((incognito = false) => {
    const t = newTab(HOME_URL, incognito);
    setTabs((ts) => [...ts, t]);
    setActiveId(t.id);
    setTabSwitcher(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  }, []);

  const closeTab = useCallback((id: string) => {
    const ts = tabsRef.current;
    const idx = ts.findIndex((t) => t.id === id);
    if (idx < 0) return;
    const rest = ts.filter((t) => t.id !== id);
    delete frames.current[id];
    if (!rest.length) {
      const t = newTab();
      setTabs([t]);
      setActiveId(t.id);
      return;
    }
    setTabs(rest);
    if (activeRef.current === id) setActiveId(rest[Math.max(0, idx - 1)].id);
  }, []);

  const selectTab = useCallback(
    (id: string) => {
      setActiveId(id);
      updateTab(id, (t) => ({ lastActive: Date.now(), sleeping: false, loading: t.sleeping && t.url !== HOME_URL ? true : t.loading }));
      setTabSwitcher(false);
    },
    [updateTab]
  );

  const toggleBookmark = useCallback(async () => {
    const t = tabsRef.current.find((x) => x.id === activeRef.current);
    if (!t || t.url === HOME_URL) return;
    const r = await fetch("/api/bookmarks", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ url: t.url, title: t.title, profileId: settings.profileId }) });
    const d = await r.json();
    setBookmarked((s) => {
      const n = new Set(s);
      if (d.removed) n.delete(t.url);
      else n.add(t.url);
      return n;
    });
    showToast(d.removed ? "Закладка удалена" : "Добавлено в закладки");
  }, [settings.profileId]);

  const askAI = useCallback((text: string, task: Task = "chat") => {
    setPanel("ai");
    setPendingPrompt({ text, task, nonce: Date.now() });
  }, []);

  // ---------- Сообщения из iframe ----------
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      const d = e.data;
      if (!d || !d.nova) return;
      // находим вкладку по source
      const entry = Object.entries(frames.current).find(([, f]) => f?.contentWindow === e.source);
      const tabId = entry?.[0] || activeRef.current;
      const tab = tabsRef.current.find((t) => t.id === tabId);
      switch (d.nova) {
        case "navigate":
          navigate(d.url, { tabId, newTab: Boolean(d.newTab) });
          break;
        case "meta": {
          if (!tab) break;
          const patch: Partial<Tab> = { loading: false };
          if (d.title) patch.title = d.title;
          if (d.favicon) patch.favicon = d.favicon;
          if (d.url && d.url !== tab.url) {
            // редирект на сервере — фиксируем конечный URL
            patch.url = d.url;
            const stack = [...tab.stack];
            stack[tab.index] = d.url;
            patch.stack = stack;
          }
          updateTab(tabId, patch);
          if (typeof d.blocked === "number") setBlocked((b) => ({ ...b, [tabId]: d.blocked }));
          const finalUrl = d.url || tab.url;
          if (!tab.incognito && d.title && lastRecorded.current[tabId] !== finalUrl) {
            lastRecorded.current[tabId] = finalUrl;
            fetch("/api/history", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ url: finalUrl, title: d.title, profileId: settings.profileId }) }).catch(() => {});
          }
          break;
        }
        case "back":
          goBack();
          break;
        case "forward":
          goForward();
          break;
        case "reload":
          reload();
          break;
        case "pageText":
          textWaiters.current.splice(0).forEach((fn) => fn({ title: d.title, url: d.url, text: d.text }));
          break;
        case "hotkey":
          handleHotkey(d.key, false);
          break;
      }
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate, goBack, goForward, reload, updateTab, settings.profileId]);

  const getPageText = useCallback(async () => {
    const t = tabsRef.current.find((x) => x.id === activeRef.current);
    if (!t || t.url === HOME_URL) return null;
    const f = frames.current[t.id];
    const viaFrame = new Promise<{ title: string; url: string; text: string } | null>((resolve) => {
      if (!f?.contentWindow) return resolve(null);
      const timer = setTimeout(() => resolve(null), 2500);
      textWaiters.current.push((v) => {
        clearTimeout(timer);
        resolve(v);
      });
      f.contentWindow.postMessage({ nova: "getText" }, "*");
    });
    const r = await viaFrame;
    if (r && r.text.length > 200) return r;
    try {
      const d = await (await fetch(`/api/page-text?url=${encodeURIComponent(t.url)}`)).json();
      return { title: d.title || t.title, url: t.url, text: d.text || "" };
    } catch {
      return r;
    }
  }, []);

  // ---------- Горячие клавиши ----------
  const handleHotkey = useCallback(
    (key: string, shift: boolean) => {
      switch (key) {
        case "t":
          addTab(false);
          break;
        case "n":
          if (shift) addTab(true);
          break;
        case "w":
          closeTab(activeRef.current);
          break;
        case "l":
          inputRef.current?.focus();
          break;
        case "d":
          toggleBookmark();
          break;
        case "r":
          reload();
          break;
        case "k":
          setPanel((p) => (p === "ai" ? null : "ai"));
          break;
        case "h":
          setPanel("history");
          break;
        case "j":
          setPanel("downloads");
          break;
      }
    },
    [addTab, closeTab, toggleBookmark, reload]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && ["t", "w", "l", "d", "r", "k", "h", "j", "n"].includes(k) && !(k === "n" && !e.shiftKey)) {
        e.preventDefault();
        handleHotkey(k, e.shiftKey);
      } else if (e.ctrlKey && e.key === "Tab") {
        e.preventDefault();
        const ts = tabsRef.current;
        const i = ts.findIndex((t) => t.id === activeRef.current);
        selectTab(ts[(i + (e.shiftKey ? -1 : 1) + ts.length) % ts.length].id);
      } else if (e.altKey && e.key === "ArrowLeft") goBack();
      else if (e.altKey && e.key === "ArrowRight") goForward();
      else if (e.key === "Escape") {
        setMenu(false);
        setTabSwitcher(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [handleHotkey, selectTab, goBack, goForward]);

  // ---------- Жесты на оболочке (мобильные) ----------
  const touch = useRef<{ x: number; y: number; t: number } | null>(null);
  const onTouchStart = (e: React.TouchEvent) => {
    touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() };
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touch.current) return;
    const dx = e.changedTouches[0].clientX - touch.current.x;
    const dy = e.changedTouches[0].clientY - touch.current.y;
    if (Math.abs(dx) > 90 && Math.abs(dy) < 60 && Date.now() - touch.current.t < 600) {
      if (dx > 0) goBack();
      else goForward();
    }
    touch.current = null;
  };

  const frameSrc = (t: Tab) => {
    const p = new URLSearchParams({ url: t.url, incognito: t.incognito ? "1" : "0", block: settings.blockTrackers && extensions.adblock ? "1" : "0", dark: extensions.darkweb ? "1" : "0", k: String(t.reloadKey) });
    return `/api/proxy?${p}`;
  };
  const sandbox = useMemo(() => "allow-scripts allow-forms allow-popups allow-modals allow-downloads" + (settings.compat ? " allow-same-origin" : ""), [settings.compat]);

  if (!ready || !active) return <div className="flex h-dvh items-center justify-center text-slate-400">NovaBrowser…</div>;

  const isHome = active.url === HOME_URL;
  const isBm = bookmarked.has(active.url);

  const MenuItem = ({ icon, label, onClick, hint }: { icon: string; label: string; onClick: () => void; hint?: string }) => (
    <button
      type="button"
      onClick={() => {
        setMenu(false);
        onClick();
      }}
      className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm hover:bg-black/5 dark:hover:bg-white/10"
    >
      <Icon name={icon} size={16} className="text-slate-500" />
      <span className="flex-1">{label}</span>
      {hint && <span className="text-[10px] text-slate-400">{hint}</span>}
    </button>
  );

  return (
    <div className={`flex h-dvh flex-col overflow-hidden ${active.incognito ? "bg-violet-950 text-white" : "bg-slate-100 dark:bg-[#0b1020]"}`} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      {/* Вкладки (десктоп) */}
      <div className="hidden sm:block">
        <TabBar tabs={tabs} activeId={activeId} onSelect={selectTab} onClose={closeTab} onNew={() => addTab(false)} onNewIncognito={() => addTab(true)} />
      </div>

      {/* Панель инструментов */}
      <div className={`flex h-14 items-center gap-1 px-2 sm:h-12 ${active.incognito ? "bg-violet-900/60" : "bg-white dark:bg-white/10"}`}>
        <div className="hidden items-center sm:flex">
          <IconButton icon="back" label="Назад (Alt+←)" onClick={goBack} disabled={active.index <= 0} />
          <IconButton icon="forward" label="Вперёд (Alt+→)" onClick={goForward} disabled={active.index >= active.stack.length - 1} />
          <IconButton icon={active.loading ? "close" : "reload"} label={active.loading ? "Остановить" : "Обновить (Ctrl+R)"} onClick={() => (active.loading ? updateTab(active.id, { loading: false }) : reload())} />
          <IconButton icon="home" label="Домой" onClick={() => navigate(HOME_URL)} />
        </div>
        <div className="sm:hidden">
          <IconButton icon="home" label="Домой" onClick={() => navigate(HOME_URL)} />
        </div>

        <AddressBar
          url={active.url}
          engine={settings.engine}
          loading={active.loading}
          blockedCount={blocked[active.id] || 0}
          onNavigate={(v) => navigate(v)}
          onEngineChange={(e) => setSettings((s) => ({ ...s, engine: e }))}
          onSearchWith={(e, q) => navigate(SEARCH_ENGINES[e].url(q))}
          inputRef={inputRef}
        />

        {/* Быстрый поиск Google / Яндекс */}
        <div className="hidden items-center gap-0.5 md:flex">
          {(["google", "yandex"] as SearchEngineId[]).map((id) => (
            <button
              key={id}
              type="button"
              title={`Быстрый поиск в ${SEARCH_ENGINES[id].name}`}
              onClick={() => {
                const q = prompt(`Поиск в ${SEARCH_ENGINES[id].name}:`, inputRef.current?.value || "");
                if (q) navigate(SEARCH_ENGINES[id].url(q));
              }}
              className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold text-white opacity-90 hover:opacity-100"
              style={{ background: SEARCH_ENGINES[id].color }}
            >
              {SEARCH_ENGINES[id].icon}
            </button>
          ))}
        </div>

        <IconButton icon="star" label={isBm ? "Удалить закладку (Ctrl+D)" : "В закладки (Ctrl+D)"} onClick={toggleBookmark} disabled={isHome} className={isBm ? "!text-amber-500" : ""} />
        <button
          type="button"
          onClick={() => setPanel((p) => (p === "ai" ? null : "ai"))}
          title="Nova AI (Ctrl+K)"
          className={`hidden h-9 items-center gap-1.5 rounded-full px-3 text-sm font-medium transition sm:flex ${panel === "ai" ? "accent-bg text-white" : "bg-gradient-to-r from-indigo-500/10 to-cyan-400/10 accent-text hover:from-indigo-500/20"}`}
        >
          <Icon name="sparkles" size={16} /> Nova AI
        </button>
        <div className="relative hidden sm:block">
          <IconButton icon="menu" label="Меню" onClick={() => setMenu((m) => !m)} active={menu} />
          {menu && <Menu />}
        </div>
      </div>

      {/* Прогресс */}
      <div className="relative h-0.5 overflow-hidden">{active.loading && <div className="nova-progress accent-bg absolute inset-y-0 w-1/2 rounded-full" />}</div>

      {/* Контент + боковая панель */}
      <div className="flex min-h-0 flex-1">
        <main className="relative min-w-0 flex-1 bg-white dark:bg-slate-950">
          {tabs.map((t) => {
            const isActive = t.id === activeId;
            if (t.url === HOME_URL) {
              return isActive ? (
                <div key={t.id} className="absolute inset-0">
                  <HomePage engine={settings.engine} incognito={t.incognito} profileId={settings.profileId} onNavigate={(v) => navigate(v)} onEngineChange={(e) => setSettings((s) => ({ ...s, engine: e }))} onAskAI={(q) => askAI(q)} />
                </div>
              ) : null;
            }
            if (t.sleeping && !isActive) return null;
            return (
              <iframe
                key={t.id + ":" + t.reloadKey}
                ref={(el) => {
                  frames.current[t.id] = el;
                }}
                src={frameSrc(t)}
                sandbox={sandbox}
                allow="fullscreen; clipboard-write; autoplay; picture-in-picture"
                referrerPolicy="no-referrer"
                title={t.title}
                onLoad={() => updateTab(t.id, { loading: false })}
                className={`absolute inset-0 h-full w-full border-0 bg-white ${isActive ? "" : "invisible pointer-events-none"}`}
              />
            );
          })}

          {/* Плавающая кнопка «Спросить ИИ про эту страницу» */}
          {!isHome && panel !== "ai" && (
            <button
              type="button"
              onClick={() => askAI("О чём эта страница? Дай краткое содержание и главные тезисы.", "page")}
              className="accent-bg absolute bottom-4 right-4 z-10 flex h-11 items-center gap-2 rounded-full px-4 text-sm font-medium text-white shadow-xl shadow-indigo-500/30 transition hover:scale-105"
            >
              <Icon name="sparkles" size={16} /> <span className="hidden sm:inline">Спросить ИИ про страницу</span>
              <span className="sm:hidden">ИИ</span>
            </button>
          )}
        </main>

        {panel && (
          <aside className="fixed inset-0 z-40 flex flex-col bg-slate-50 sm:static sm:z-auto sm:w-[380px] sm:shrink-0 sm:border-l sm:border-black/5 dark:bg-[#0f152b] dark:sm:border-white/10">
            {panel === "ai" && (
              <AIChat settings={settings} activeTab={active} tabs={tabs} getPageText={getPageText} onOpenUrl={(u) => navigate(u, { newTab: true })} pendingPrompt={pendingPrompt} onPromptConsumed={() => setPendingPrompt(null)} />
            )}
            {panel === "history" && <HistoryPanel profileId={settings.profileId} onOpen={(u) => navigate(u)} onClose={() => setPanel(null)} />}
            {panel === "bookmarks" && <BookmarksPanel profileId={settings.profileId} onOpen={(u) => navigate(u)} onClose={() => setPanel(null)} />}
            {panel === "downloads" && <DownloadsPanel profileId={settings.profileId} onClose={() => setPanel(null)} />}
            {panel === "settings" && (
              <SettingsPanel settings={settings} onChange={(p) => setSettings((s) => ({ ...s, ...p }))} onClose={() => setPanel(null)} extensions={extensions} onToggleExt={(id) => setExtensions((x) => ({ ...x, [id]: !x[id] }))} />
            )}
            {panel === "ai" && (
              <button type="button" onClick={() => setPanel(null)} className="absolute right-2 top-2 z-10 sm:hidden" aria-label="Закрыть">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-black/5 dark:bg-white/10">
                  <Icon name="close" size={16} />
                </span>
              </button>
            )}
          </aside>
        )}
      </div>

      {/* Нижняя панель (мобильные) */}
      <nav className={`flex h-14 items-center justify-around border-t border-black/5 pb-[env(safe-area-inset-bottom)] sm:hidden ${active.incognito ? "bg-violet-900/60" : "bg-white dark:border-white/10 dark:bg-white/10"}`}>
        <IconButton icon="back" label="Назад" onClick={goBack} disabled={active.index <= 0} size={22} />
        <IconButton icon="forward" label="Вперёд" onClick={goForward} disabled={active.index >= active.stack.length - 1} size={22} />
        <IconButton icon="sparkles" label="Nova AI" onClick={() => setPanel((p) => (p === "ai" ? null : "ai"))} active={panel === "ai"} size={22} />
        <button type="button" onClick={() => setTabSwitcher(true)} aria-label="Вкладки" className="flex h-9 w-9 items-center justify-center">
          <span className="flex h-6 min-w-6 items-center justify-center rounded-md border-2 border-current px-1 text-xs font-bold text-slate-600 dark:text-slate-300">{tabs.length}</span>
        </button>
        <div className="relative">
          <IconButton icon="menu" label="Меню" onClick={() => setMenu((m) => !m)} size={22} />
          {menu && <Menu up />}
        </div>
      </nav>

      {/* Переключатель вкладок (мобильные) */}
      {tabSwitcher && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-100/95 backdrop-blur dark:bg-[#0b1020]/95">
          <div className="flex h-12 items-center gap-2 px-3">
            <div className="flex-1 text-sm font-semibold">Вкладки ({tabs.length})</div>
            <IconButton icon="incognito" label="Приватная" onClick={() => addTab(true)} />
            <IconButton icon="plus" label="Новая" onClick={() => addTab(false)} />
            <IconButton icon="close" label="Закрыть" onClick={() => setTabSwitcher(false)} />
          </div>
          <div className="grid flex-1 grid-cols-2 gap-3 overflow-y-auto p-3">
            {tabs.map((t) => (
              <div key={t.id} onClick={() => selectTab(t.id)} className={`relative flex h-40 flex-col overflow-hidden rounded-2xl border-2 bg-white shadow dark:bg-white/10 ${t.id === activeId ? "border-[var(--accent)]" : "border-transparent"} ${t.incognito ? "bg-violet-100 dark:bg-violet-900/40" : ""}`}>
                <div className="flex items-center gap-2 border-b border-black/5 px-2 py-1.5 text-xs dark:border-white/10">
                  <Favicon src={t.favicon} title={t.title} size={14} />
                  <span className="min-w-0 flex-1 truncate">{t.title}</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      closeTab(t.id);
                    }}
                    aria-label="Закрыть"
                  >
                    <Icon name="close" size={14} />
                  </button>
                </div>
                <div className="flex flex-1 items-center justify-center p-3 text-center text-[11px] text-slate-400">{t.url === HOME_URL ? "Новая вкладка" : hostOf(t.url)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {toast && <div className="pointer-events-none fixed bottom-20 left-1/2 z-50 -translate-x-1/2 rounded-full bg-slate-900 px-4 py-2 text-sm text-white shadow-xl sm:bottom-6">{toast}</div>}
    </div>
  );

  function Menu({ up }: { up?: boolean }) {
    const cur = tabsRef.current.find((t) => t.id === activeRef.current);
    const curUrl = cur?.url || HOME_URL;
    const curHome = curUrl === HOME_URL;
    return (
      <>
        <div className="fixed inset-0 z-40" onClick={() => setMenu(false)} />
        <div className={`absolute right-0 z-50 w-64 rounded-2xl border border-black/5 bg-white p-1 shadow-2xl dark:border-white/10 dark:bg-slate-900 ${up ? "bottom-12" : "top-10"}`}>
          <MenuItem icon="plus" label="Новая вкладка" hint="Ctrl+T" onClick={() => addTab(false)} />
          <MenuItem icon="incognito" label="Приватная вкладка" hint="Ctrl+Shift+N" onClick={() => addTab(true)} />
          <div className="my-1 border-t border-black/5 dark:border-white/10" />
          <MenuItem icon="star" label="Закладки" onClick={() => setPanel("bookmarks")} />
          <MenuItem icon="history" label="История" hint="Ctrl+H" onClick={() => setPanel("history")} />
          <MenuItem icon="download" label="Загрузки" hint="Ctrl+J" onClick={() => setPanel("downloads")} />
          <div className="my-1 border-t border-black/5 dark:border-white/10" />
          <MenuItem icon="sparkles" label="Спросить ИИ про страницу" onClick={() => askAI("О чём эта страница?", "page")} />
          {extensions.readermode && <MenuItem icon="doc" label="Режим чтения (ИИ)" onClick={() => askAI("Сделай краткое содержание этой страницы", "summarize")} />}
          {extensions.translate && <MenuItem icon="translate" label="Перевести страницу" onClick={() => askAI("Переведи основной текст этой страницы на русский", "translate")} />}
          <MenuItem
            icon="find"
            label="Найти на странице"
            onClick={() => {
              const q = prompt("Найти на странице:");
              if (q) frames.current[activeId]?.contentWindow?.postMessage({ nova: "find", q }, "*");
            }}
          />
          <MenuItem
            icon="download"
            label="Скачать текущий файл/страницу"
            onClick={() => {
              if (!curHome) window.open(`/api/downloads/file?url=${encodeURIComponent(curUrl)}&profileId=${settings.profileId}`, "_blank");
            }}
          />
          <MenuItem icon="external" label="Открыть в системном браузере" onClick={() => !curHome && window.open(curUrl, "_blank", "noopener")} />
          <MenuItem
            icon="copy"
            label="Копировать ссылку"
            onClick={() => {
              navigator.clipboard?.writeText(curUrl);
              showToast("Ссылка скопирована");
            }}
          />
          <div className="my-1 border-t border-black/5 dark:border-white/10" />
          <MenuItem icon={document.documentElement.classList.contains("dark") ? "sun" : "moon"} label="Переключить тему" onClick={() => setSettings((s) => ({ ...s, theme: document.documentElement.classList.contains("dark") ? "light" : "dark" }))} />
          <MenuItem icon="puzzle" label="Расширения" onClick={() => setPanel("settings")} />
          <MenuItem icon="settings" label="Настройки" onClick={() => setPanel("settings")} />
        </div>
      </>
    );
  }
}
