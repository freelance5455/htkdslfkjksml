import React, { useState, useEffect } from 'react';
import { 
  HelpCircle, 
  Clock, 
  Trophy, 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  RefreshCw, 
  Zap, 
  Layers, 
  Flame, 
  Filter,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  GkQuestion, 
  generateQuestionPool, 
  TOTAL_GK_QUESTIONS_CAPACITY 
} from '../../services/gkQuestionBank';

interface GkQuizGameProps {
  onRewardWon: (coins: number, gameName: string) => void;
  onClose: () => void;
}

export const GkQuizGame: React.FC<GkQuizGameProps> = ({ onRewardWon, onClose }) => {
  const { language } = useApp();

  // Settings
  const [category, setCategory] = useState<string>('all');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const questionsPerRound = 10;

  // Active question set generated from 10,000+ pool
  const [questions, setQuestions] = useState<GkQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(12);
  const [isGameOver, setIsGameOver] = useState(false);

  // Lifelines: 50-50, Time Freeze, Skip
  const [lifeline5050Used, setLifeline5050Used] = useState(false);
  const [lifelineFreezeUsed, setLifelineFreezeUsed] = useState(false);
  const [lifelineSkipUsed, setLifelineSkipUsed] = useState(false);
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);

  // Timer duration based on difficulty
  const baseTimerSeconds = difficulty === 'easy' ? 15 : difficulty === 'medium' ? 12 : 8;
  const rewardPerQuestion = difficulty === 'easy' ? 20 : difficulty === 'medium' ? 30 : 50;

  // Initialize questions on mount or settings change
  useEffect(() => {
    startNewQuizSession();
  }, [category, difficulty]);

  const startNewQuizSession = () => {
    const freshBatch = generateQuestionPool(questionsPerRound, category, difficulty);
    setQuestions(freshBatch);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setTimeLeft(baseTimerSeconds);
    setIsGameOver(false);
    setLifeline5050Used(false);
    setLifelineFreezeUsed(false);
    setLifelineSkipUsed(false);
    setHiddenOptions([]);
  };

  const currentQ = questions[currentIndex];

  // Countdown timer
  useEffect(() => {
    if (isAnswered || isGameOver || !currentQ) return;
    if (timeLeft <= 0) {
      handleSelectOption(-1); // timeout treated as incorrect
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, isAnswered, isGameOver, currentQ]);

  const handleSelectOption = (idx: number) => {
    if (isAnswered || !currentQ) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctIndex;
    const newScore = isCorrect ? score + 1 : score;
    if (isCorrect) {
      setScore(newScore);
    }

    setTimeout(() => {
      if (currentIndex + 1 < questions.length) {
        setCurrentIndex(prev => prev + 1);
        setSelectedOption(null);
        setIsAnswered(false);
        setTimeLeft(baseTimerSeconds);
        setHiddenOptions([]);
      } else {
        finishGame(newScore);
      }
    }, 1300);
  };

  // Lifeline 1: 50-50
  const use5050 = () => {
    if (lifeline5050Used || isAnswered || !currentQ) return;
    const wrongIndices = [0, 1, 2, 3].filter(i => i !== currentQ.correctIndex);
    // Hide 2 wrong options
    const toHide = wrongIndices.slice(0, 2);
    setHiddenOptions(toHide);
    setLifeline5050Used(true);
  };

  // Lifeline 2: +10s Time Freeze
  const useTimeFreeze = () => {
    if (lifelineFreezeUsed || isAnswered) return;
    setTimeLeft(prev => prev + 10);
    setLifelineFreezeUsed(true);
  };

  // Lifeline 3: Skip question with fresh one from 10k pool
  const useSkipQuestion = () => {
    if (lifelineSkipUsed || isAnswered) return;
    const replacement = generateQuestionPool(1, category, difficulty)[0];
    if (replacement) {
      const updated = [...questions];
      updated[currentIndex] = replacement;
      setQuestions(updated);
      setTimeLeft(baseTimerSeconds);
      setHiddenOptions([]);
      setLifelineSkipUsed(true);
    }
  };

  const finishGame = (finalScore: number) => {
    setIsGameOver(true);
    const totalEarned = finalScore * rewardPerQuestion;
    if (totalEarned > 0) {
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      onRewardWon(totalEarned, `GK Quiz (${TOTAL_GK_QUESTIONS_CAPACITY} Pool)`);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner: 10,000+ Question Engine Header */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-700 via-indigo-600 to-blue-600 text-white shadow-md space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-xl shadow-xs">
              🧠
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base tracking-tight flex items-center gap-1.5">
                <span>{language === 'bn' ? 'জিকে কুইজ অ্যারেনা' : 'GK Quiz Arena'}</span>
                <span className="text-[10px] bg-amber-400 text-amber-950 font-black px-1.5 py-0.5 rounded-md uppercase">
                  {TOTAL_GK_QUESTIONS_CAPACITY} Bank
                </span>
              </h3>
              <p className="text-[11px] text-white/90">
                {language === 'bn' 
                  ? `১০,০০০+ প্রশ্নের ভাণ্ডার! প্রতিটি সঠিক উত্তরে ₹${rewardPerQuestion} কয়েন` 
                  : `10,000+ verified questions! Earn ₹${rewardPerQuestion} per correct answer`}
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[9px] text-purple-200 block uppercase font-bold">Max Prize</span>
            <span className="text-base sm:text-lg font-black text-amber-300">
              🪙 ₹{questionsPerRound * rewardPerQuestion}
            </span>
          </div>
        </div>

        {/* Category & Difficulty Filters */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/15">
          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5 bg-black/25 px-2.5 py-1.5 rounded-xl text-[11px]">
            <Filter className="w-3.5 h-3.5 text-purple-200 shrink-0" />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-transparent text-white font-bold outline-none w-full cursor-pointer text-[11px]"
            >
              <option value="all" className="text-slate-900">🌟 All Topics (10,000+ Mixed)</option>
              <option value="india" className="text-slate-900">🇮🇳 India Heritage & States</option>
              <option value="world" className="text-slate-900">🌍 World Capitals & Currencies</option>
              <option value="science" className="text-slate-900">🔬 Science & Inventions</option>
              <option value="sports" className="text-slate-900">🏏 Sports & Cricket</option>
            </select>
          </div>

          {/* Difficulty Dropdown */}
          <div className="flex items-center gap-1.5 bg-black/25 px-2.5 py-1.5 rounded-xl text-[11px]">
            <Flame className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as any)}
              className="bg-transparent text-white font-bold outline-none w-full cursor-pointer text-[11px]"
            >
              <option value="easy" className="text-slate-900">Easy (15s • ₹20/q)</option>
              <option value="medium" className="text-slate-900">Medium (12s • ₹30/q)</option>
              <option value="hard" className="text-slate-900">🔥 Hard / Genius (8s • ₹50/q)</option>
            </select>
          </div>
        </div>
      </div>

      {!isGameOver && currentQ ? (
        <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3.5">
          {/* Progress Header & Lifelines */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            {/* Question Counter & Category Badge */}
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300">
                {currentQ.category}
              </span>
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                Q{currentIndex + 1} of {questions.length}
              </span>
            </div>

            {/* Lifelines Bar */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={use5050}
                disabled={lifeline5050Used || isAnswered}
                title="50:50 Lifeline (Removes 2 incorrect choices)"
                className={`px-2 py-1 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${
                  lifeline5050Used
                    ? 'opacity-40 border-slate-300 dark:border-slate-700 text-slate-400'
                    : 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100'
                }`}
              >
                50:50
              </button>
              <button
                type="button"
                onClick={useTimeFreeze}
                disabled={lifelineFreezeUsed || isAnswered}
                title="+10 Seconds Freeze"
                className={`px-2 py-1 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${
                  lifelineFreezeUsed
                    ? 'opacity-40 border-slate-300 dark:border-slate-700 text-slate-400'
                    : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100'
                }`}
              >
                +10s
              </button>
              <button
                type="button"
                onClick={useSkipQuestion}
                disabled={lifelineSkipUsed || isAnswered}
                title="Skip to another 10,000+ pool question"
                className={`px-2 py-1 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${
                  lifelineSkipUsed
                    ? 'opacity-40 border-slate-300 dark:border-slate-700 text-slate-400'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 hover:bg-amber-100'
                }`}
              >
                Skip ↻
              </button>

              {/* Timer Pill */}
              <div className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black ml-1 ${
                timeLeft <= 4 
                  ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 animate-pulse' 
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
              }`}>
                <Clock className="w-3.5 h-3.5" />
                <span>{timeLeft}s</span>
              </div>
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-1">
            <h4 className="text-sm sm:text-base font-black text-slate-900 dark:text-slate-100 leading-snug">
              {currentIndex + 1}. {language === 'bn' && currentQ.questionBn ? currentQ.questionBn : currentQ.question}
            </h4>
            {language !== 'bn' && currentQ.questionBn && (
              <p className="text-xs text-slate-500 italic">
                {currentQ.questionBn}
              </p>
            )}
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            {currentQ.options.map((option, optIdx) => {
              if (hiddenOptions.includes(optIdx)) {
                return (
                  <div 
                    key={optIdx} 
                    className="p-3.5 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 opacity-25 flex items-center justify-center text-slate-400 text-xs italic"
                  >
                    (Option removed by 50:50)
                  </div>
                );
              }

              const optText = language === 'bn' && currentQ.optionsBn && currentQ.optionsBn[optIdx] 
                ? currentQ.optionsBn[optIdx] 
                : option;
              const isSelected = selectedOption === optIdx;
              const isCorrect = currentQ.correctIndex === optIdx;

              let style = 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800';

              if (isAnswered) {
                if (isCorrect) {
                  style = 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-bold';
                } else if (isSelected) {
                  style = 'bg-rose-100 dark:bg-rose-950/60 border-rose-500 text-rose-800 dark:text-rose-200 font-bold';
                } else {
                  style = 'opacity-40 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-800';
                }
              }

              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  disabled={isAnswered}
                  className={`p-3.5 rounded-xl border text-left text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${style}`}
                >
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-black/5 dark:bg-white/10 text-[10px] font-bold flex items-center justify-center shrink-0">
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span>{optText}</span>
                  </span>
                  {isAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                  {isAnswered && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-rose-500 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation if answered */}
          {isAnswered && currentQ.explanation && (
            <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-900/60 text-xs text-purple-900 dark:text-purple-300">
              💡 <strong>Fact:</strong> {currentQ.explanation}
            </div>
          )}
        </div>
      ) : (
        /* Results Screen */
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-md text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center mx-auto text-3xl shadow-sm">
            🏆
          </div>

          <div className="space-y-1">
            <h4 className="text-xl font-black text-slate-900 dark:text-slate-100">
              {language === 'bn' ? 'কুইজ সম্পন্ন হয়েছে!' : 'Quiz Session Complete!'}
            </h4>
            <p className="text-xs text-slate-500">
              You scored {score} of {questions.length} correct in {category.toUpperCase()} mode!
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300">
            <span className="text-xs font-semibold block uppercase">Total Cash Reward Credited</span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              🪙 +{score * rewardPerQuestion} Coins (₹{score * rewardPerQuestion})
            </span>
          </div>

          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={startNewQuizSession}
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Next 10 Questions from Pool</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold cursor-pointer"
            >
              Back to Game Zone
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
