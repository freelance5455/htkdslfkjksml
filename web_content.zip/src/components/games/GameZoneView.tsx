import React, { useState, useMemo } from 'react';
import { 
  Gamepad2, 
  Sparkles, 
  Trophy, 
  Coins, 
  Flame, 
  Play, 
  Search, 
  Star,
  Zap,
  ArrowRight,
  ShieldCheck,
  Clock,
  ChevronRight,
  Filter,
  Layers
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GameItem } from '../../types';
import { LudoGame } from './LudoGame';
import { GkQuizGame } from './GkQuizGame';
import { SpinWheelGame } from './SpinWheelGame';
import { ScratchCardGame } from './ScratchCardGame';
import { MiniGamesModal } from './MiniGamesModal';
import { CloudArcadePlayerModal } from './CloudArcadePlayerModal';
import { get1000GamesCatalog, CloudGame } from '../../data/games1000Data';

// 23 Featured Interactive Native Games (including 7 Hard Mode Games)
const FEATURED_NATIVE_GAMES: GameItem[] = [
  {
    id: 'impossible_laser',
    title: 'The Impossible Laser Maze (Hard Mode)',
    titleBn: 'ইম্পসিবল লেজার মেজ (চরম হার্ড মোড)',
    category: 'Hardcore Reflex',
    icon: '💀',
    description: 'Navigate rotating lethal lasers, oscillating electric beams and reach the exit portal! Zero error margin!',
    descriptionBn: 'ঘূর্ণায়মান লাল লেজার ও ইলেকট্রিক ব্যারিকেড ফাঁকি দিয়ে সবুজ পোর্টালে পৌঁছান! ভুল করলেই ধ্বংস!',
    minReward: 350,
    maxReward: 350,
    playLimitPerDay: 8,
    badge: '💀 HARD PRO',
  },
  {
    id: 'bullet_hell',
    title: 'Bullet Hell Storm (Survive 25s)',
    titleBn: 'বুলেট হেল ডজ স্টর্ম (২৫ সে. সারভাইভাল)',
    category: 'Hardcore Action',
    icon: '⚡',
    description: 'Dodge rapid spiral plasma bullets, homing missiles & explosive shockwaves for 25 seconds!',
    descriptionBn: 'চারিদিক থেকে ছুটে আসা ভয়ংকর প্লাজমা বুলেট ও মিসাইল ২৫ সেকেন্ড ফাঁকি দিয়ে টিকে থাকুন!',
    minReward: 300,
    maxReward: 300,
    playLimitPerDay: 8,
    badge: '🔥 HARDCORE',
  },
  {
    id: 'bomb_defusal',
    title: 'Bomb Defusal: Minesweeper Pro',
    titleBn: 'মাইনসুইপার বম্ব ডিফিউজার (৩০ সে. লিমিট)',
    category: 'Hard Puzzle',
    icon: '💣',
    description: '30-second ticking clock! Defuse 6 armed C4 explosives and uncover 30 safe nodes without detonating!',
    descriptionBn: 'মাত্র ৩০ সেকেন্ডে ৬টি মারাত্মক সি-৪ বোমা খুঁজে নিষ্ক্রিয় করুন এবং ৩০টি নিরাপদ সার্কিট উন্মোচন করুন!',
    minReward: 300,
    maxReward: 300,
    playLimitPerDay: 10,
    badge: '💣 HARD PRO',
  },
  {
    id: 'hard_math',
    title: 'Hardcore Math Blitz (4.5s Timer)',
    titleBn: 'হার্ডকোর ম্যাথ ব্লিটজ (৪.৫ সে. টাইমার)',
    category: 'Speed & Brain',
    icon: '🧠',
    description: 'Extreme rapid mental arithmetic! 3-term calculations under 4.5s clock. 8 streak wins ₹250!',
    descriptionBn: 'তীব্র গতির জটিল মানসিক গণিত! প্রতি প্রশ্নে ৪.৫ সেকেন্ড সময়। টানা ৮টি সঠিক উত্তর দিয়ে জিতুন ২৫০ টাকা!',
    minReward: 250,
    maxReward: 250,
    playLimitPerDay: 10,
    badge: '⚡ HARD SPEED',
  },
  {
    id: 'extreme_knife',
    title: 'Extreme Knife Hit (Reverse Spin)',
    titleBn: 'এক্সট্রিম নাইফ হিট (রিভার্স স্পিন মোড)',
    category: 'Extreme Skill',
    icon: '🌪️',
    description: 'Erratic rotating timber log suddenly reverses direction and changes speed! Stick 8 blades cleanly!',
    descriptionBn: 'লগটি যেকোনো সময় হঠাৎ উল্টো দিকে ঘুরে যায় ও গতি বদলায়! নিখুঁতভাবে ৮টি ছুরি গেঁথে দিন!',
    minReward: 250,
    maxReward: 250,
    playLimitPerDay: 10,
    badge: '💀 HARD SKILL',
  },
  {
    id: 'flappy_insane',
    title: 'Flappy Insane Storm (Laser Gates)',
    titleBn: 'ফ্ল্যাপী ইনসেন স্টর্ম (লেজার গেটস)',
    category: 'Extreme Arcade',
    icon: '🐦',
    description: 'Hyper-speed flying between narrow moving lethal laser gates! Score 8 gates to win ₹300!',
    descriptionBn: 'ভীষণ দ্রুত গতিতে সরু লাল লেজার গেট ফাঁকি দিয়ে উড়ে যান! ৮টি গেট পার করে জিতুন ৩০০ টাকা!',
    minReward: 300,
    maxReward: 300,
    playLimitPerDay: 10,
    badge: '🔥 INSANE',
  },
  {
    id: 'ludo',
    title: 'Ludo Dice Duel (Hard & Master Mode)',
    titleBn: 'লুডো ডাইস রোল (হার্ড ও মাস্টার মোড)',
    category: 'Board & Dice',
    icon: '🎲',
    description: 'Play Classic, Hard & Master modes! Cut opponent tokens, conquer safe stars, and win up to ₹500!',
    descriptionBn: 'ক্লাসিক, হার্ড ও মাস্টার মোড! ঘুঁটি কেটে কম্পিউটারকে হারিয়ে ৫০০ টাকা পর্যন্ত জিতুন!',
    minReward: 75,
    maxReward: 500,
    playLimitPerDay: 10,
    badge: '🔥 Hard Mode',
  },
  {
    id: 'gk_quiz',
    title: 'GK Quiz Arena (10,000+ Bank)',
    titleBn: 'জিকে কুইজ অ্যারেনা (১০,০০০+ প্রশ্ন)',
    category: 'Trivia & Brain',
    icon: '🧠',
    description: '10,000+ Question Engine! Answer Indian History, World Capitals, Science & Sports trivia with lifelines to win up to ₹500!',
    descriptionBn: '১০,০০০+ প্রশ্নের বিশাল সম্ভার! ভারত, ভূগোল, বিজ্ঞান ও খেলাধুলার কুইজ খেলে ৫০০ টাকা পর্যন্ত আয় করুন!',
    minReward: 20,
    maxReward: 500,
    playLimitPerDay: 15,
    badge: '10,000+ Bank',
  },
  {
    id: 'spin_wheel',
    title: 'Lucky Spin Wheel',
    titleBn: 'লাকি স্পিন হুইল (Spin Wheel)',
    category: 'Fortune',
    icon: '🎡',
    description: 'Spin the fortune wheel daily to win mystery cash rewards & mega jackpots up to ₹500!',
    descriptionBn: 'প্রতিদিন চাকা ঘুরিয়ে সর্বোচ্চ ৫০০ টাকা পর্যন্ত নগদ জিতে নিন!',
    minReward: 10,
    maxReward: 500,
    playLimitPerDay: 5,
    badge: 'Daily Free',
  },
  {
    id: 'scratch_card',
    title: 'Golden Scratch Card',
    titleBn: 'গোল্ডেন স্ক্র্যাচ কার্ড (Scratch Card)',
    category: 'Instant Win',
    icon: '🎟️',
    description: 'Scratch off the gold foil to instantly reveal your guaranteed cash prize!',
    descriptionBn: 'কার্ডের সোনালী স্তর ঘষে তাত্ক্ষণিক ক্যাশ প্রাইজ আবিষ্কার করুন!',
    minReward: 35,
    maxReward: 200,
    playLimitPerDay: 8,
    badge: 'Instant',
  },
  {
    id: 'flappy_coin',
    title: 'Flappy Coin Sky Rush',
    titleBn: 'ফ্ল্যাপী কয়েন স্কাই রাশ',
    category: 'Hyper-Casual',
    icon: '🐦',
    description: 'Tap rhythmically to fly between golden pipes and collect floating coins!',
    descriptionBn: 'সোনালী পাইপ এড়িয়ে সাবধানে উড়ে কয়েন ও ক্যাশ সংগ্রহ করুন!',
    minReward: 30,
    maxReward: 70,
    playLimitPerDay: 15,
    badge: '🔥 Top Hit',
  },
  {
    id: 'knife_hit',
    title: 'Knife Hit Master Blade',
    titleBn: 'নাইফ হিট মাস্টার ব্লেড',
    category: 'Action & Skill',
    icon: '🗡️',
    description: 'Throw throwing knives into spinning timber logs without hitting existing knives!',
    descriptionBn: 'ঘূর্ণায়মান কাঠের গুঁড়িতে নিখুঁত নিশানা লাগিয়ে ছুরি গেঁথে দিন!',
    minReward: 40,
    maxReward: 80,
    playLimitPerDay: 15,
    badge: '⚡ Addictive',
  },
  {
    id: 'retro_snake',
    title: 'Retro Snake 97 Nokia Classic',
    titleBn: 'রেট্রো স্নেক ৯৭ ক্লাসিক',
    category: 'Retro & Arcade',
    icon: '🐍',
    description: 'Classic monochrome 8-bit snake! Eat pixel apples, grow longer, avoid walls.',
    descriptionBn: 'নস্টালজিক নোকিয়া স্নেকের মতো আপেল খেয়ে লম্বা হোন ও বোনাস পান!',
    minReward: 35,
    maxReward: 75,
    playLimitPerDay: 12,
    badge: '🕹️ Classic',
  },
  {
    id: 'cricket_sixer',
    title: 'Cricket Sixer Super Over',
    titleBn: 'ক্রিকেট ছক্কার সুপার ওভার',
    category: 'Sports & Cricket',
    icon: '🏏',
    description: 'Time your bat swing perfectly when the ball hits the green sweet spot to hit 4s and 6s!',
    descriptionBn: 'গ্রিন সুইট স্পটে বল এলে ব্যাট চালিয়ে গ্যালারিতে ছক্কা হাঁকান!',
    minReward: 45,
    maxReward: 90,
    playLimitPerDay: 10,
    badge: '🏏 Cricket',
  },
  {
    id: 'tic_tac_toe',
    title: 'Tic-Tac-Toe AI Duel',
    titleBn: 'টিক-ট্যাক-টো এআই ডুয়েল',
    category: 'Brain & Logic',
    icon: '❌⭕',
    description: 'Compete in 3x3 tactical battle against intelligent computer algorithm!',
    descriptionBn: 'বুদ্ধিমান এআই-র বিরুদ্ধে এক্স এবং ও দিয়ে কৌশলী জয় ছিনিয়ে নিন!',
    minReward: 50,
    maxReward: 50,
    playLimitPerDay: 10,
    badge: '🧠 Logic',
  },
  {
    id: 'rock_paper_scissors',
    title: 'Rock Paper Scissors 3-Round',
    titleBn: 'রক পেপার সিজার্স ৩-রাউন্ড',
    category: 'Instant Win',
    icon: '✂️',
    description: 'Fast-paced rock-paper-scissors tournament against the master bot!',
    descriptionBn: 'বটের বিরুদ্ধে ৩ রাউন্ড খেলে বেশি জিতে তাৎক্ষণিক কয়েন পান!',
    minReward: 45,
    maxReward: 45,
    playLimitPerDay: 15,
    badge: '⚡ Quick',
  },
  {
    id: 'tower_stack',
    title: 'Tower Stack 3D Builder',
    titleBn: 'টাওয়ার স্ট্যাক থ্রিডি',
    category: 'Hyper-Casual',
    icon: '🧱',
    description: 'Time the drop of sliding slabs accurately to build the highest skyscraper!',
    descriptionBn: 'সঠিক টাইমিংয়ে ব্লক ড্রপ করে আকাশছোঁয়া টাওয়ার নির্মাণ করুন!',
    minReward: 35,
    maxReward: 70,
    playLimitPerDay: 12,
    badge: '🏗️ 3D Stack',
  },
  {
    id: 'math_speed',
    title: 'Math Speed Challenge',
    titleBn: 'গণিত স্পিড রান (Math Rush)',
    category: 'Speed & Logic',
    icon: '⚡',
    description: 'Solve mental addition and math problems against a 20-second clock to win coins!',
    descriptionBn: '২০ সেকেন্ডের মধ্যে গণিত সমাধান করে চটপট কয়েন আয় করুন!',
    minReward: 20,
    maxReward: 60,
    playLimitPerDay: 12,
    badge: 'Fast',
  },
  {
    id: 'memory_cards',
    title: 'Memory Card Match',
    titleBn: 'মেমোরি কার্ড ম্যাচ (Memory Game)',
    category: 'Brain & Memory',
    icon: '🃏',
    description: 'Find all matching pairs of hidden reward cards with the fewest moves!',
    descriptionBn: 'লুকানো কার্ডের জোড়া মিলিয়ে স্মরণশক্তি বাড়ান ও বোনাস পান!',
    minReward: 50,
    maxReward: 50,
    playLimitPerDay: 10,
    badge: 'Classic',
  },
  {
    id: 'color_reflex',
    title: 'Color Reflex Rush',
    titleBn: 'কালার রিফ্লেক্স রাশ (Color Reflex)',
    category: 'Arcade',
    icon: '🎯',
    description: 'Test your quick reflexes by tapping the matching color target within 1.5s!',
    descriptionBn: 'রং পরিবর্তনের সাথে সাথে সঠিক বাটন ট্যাপ করে গতি প্রমাণ করুন!',
    minReward: 35,
    maxReward: 35,
    playLimitPerDay: 15,
    badge: 'Skill',
  },
  {
    id: 'coin_tap',
    title: 'Coin Tap Frenzy',
    titleBn: 'কয়েন ট্যাপ ফ্রেঞ্জি (Coin Tapper)',
    category: 'Arcade & Action',
    icon: '💰',
    description: 'Tap fast-bouncing golden coins on screen before time expires!',
    descriptionBn: 'স্ক্রিনে ভেসে ওঠা সোনার কয়েনগুলো দ্রুত স্পর্শ করে সংগ্রহ করুন!',
    minReward: 45,
    maxReward: 45,
    playLimitPerDay: 15,
    badge: 'Fun',
  },
  {
    id: 'dice_7',
    title: 'Dice 7 Up 7 Down',
    titleBn: 'ডাইস সেভেন আপ-ডাউন (Dice 7)',
    category: 'Board & Dice',
    icon: '🎲',
    description: 'Predict whether the sum of two rolling dice will be over 7, under 7, or lucky 7!',
    descriptionBn: 'দুইটি ডাইসের যোগফল ৭ এর বেশি, কম নাকি সমান তা অনুমান করুন!',
    minReward: 60,
    maxReward: 60,
    playLimitPerDay: 10,
    badge: 'Hot',
  },
  {
    id: 'number_guess',
    title: 'Number Mystery Guess',
    titleBn: 'রহস্যময় সংখ্যা অনুমান (Number Guess)',
    category: 'Puzzle',
    icon: '🔢',
    description: 'Guess the hidden secret number between 1 and 50 within 5 attempts!',
    descriptionBn: '১ থেকে ৫০ এর মধ্যে লুকানো সংখ্যাটি ৫ বারের মধ্যে অনুমান করুন!',
    minReward: 55,
    maxReward: 55,
    playLimitPerDay: 10,
    badge: 'Puzzle',
  },
];

export const GameZoneView: React.FC = () => {
  const { language, t, adjustUserCoins, currentUser } = useApp();

  // Active view tab: 'hard' (Hard Mode Games), 'cloud1000' (1000+ Games Catalog), 'featured' (23 native games)
  const [activeTab, setActiveTab] = useState<'hard' | 'cloud1000' | 'featured'>('hard');
  
  // Modals state
  const [activeNativeGameId, setActiveNativeGameId] = useState<string | null>(null);
  const [activeCloudGame, setActiveCloudGame] = useState<CloudGame | null>(null);

  // Search & Filters for 1,000+ games
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'reward'>('popular');
  const [displayCount, setDisplayCount] = useState(24);

  // Load 1,000+ catalog
  const allCloudGames = useMemo(() => get1000GamesCatalog(), []);

  const categories = [
    { id: 'all', name: 'All Games (1,040+)', nameBn: 'সব গেম (১,০৪০+)' },
    { id: 'Action & Shooting', name: '🎯 Action & Shooting (130)', nameBn: '🎯 অ্যাকশন (১৩০)' },
    { id: 'Puzzle & Brain', name: '🧩 Puzzle & Brain (130)', nameBn: '🧩 ধাঁধা ও ব্রেন (১৩০)' },
    { id: 'Racing & Speed', name: '🏎️ Racing & Speed (130)', nameBn: '🏎️ রেসিং ও কার (১৩০)' },
    { id: 'Sports & Cricket', name: '🏏 Sports & Cricket (130)', nameBn: '🏏 ক্রিকেট ও স্পোর্টস (১৩০)' },
    { id: 'Board & Dice', name: '🎲 Board & Dice (130)', nameBn: '🎲 বোর্ড ও লুডো (১৩০)' },
    { id: 'Hyper-Casual & Reflex', name: '⚡ Hyper-Casual (130)', nameBn: '⚡ হাইপার ক্যাজুয়াল (১৩০)' },
    { id: 'Retro & Arcade', name: '🕹️ Retro & Arcade (130)', nameBn: '🕹️ রেট্রো আর্কেড (১৩০)' },
    { id: 'Cards & Casino', name: '🃏 Cards & Casino (130)', nameBn: '🃏 কার্ডস ও তাস (১৩০)' },
  ];

  // Filtered & Sorted Cloud Games
  const filteredCloudGames = useMemo(() => {
    let list = allCloudGames;

    if (selectedCategory !== 'all') {
      list = list.filter(g => g.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(g => 
        g.title.toLowerCase().includes(q) ||
        g.titleBn.toLowerCase().includes(q) ||
        g.category.toLowerCase().includes(q) ||
        g.categoryBn.toLowerCase().includes(q) ||
        g.description.toLowerCase().includes(q) ||
        g.descriptionBn.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'rating') {
      list = [...list].sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'reward') {
      list = [...list].sort((a, b) => b.rewardPerMin - a.rewardPerMin);
    }

    return list;
  }, [allCloudGames, selectedCategory, searchQuery, sortBy]);

  const displayedGames = filteredCloudGames.slice(0, displayCount);

  const handleRewardWon = (coins: number, gameName: string) => {
    if (!currentUser) return;
    adjustUserCoins(currentUser.id, coins, `Game Win: ${gameName}`);
  };

  return (
    <div className="space-y-6 pb-24 md:pb-10 animate-in fade-in duration-300">
      
      {/* Top Banner - 1,000+ Games Arena */}
      <div className="p-5 sm:p-7 rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 text-white border border-emerald-500/30 shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black border border-emerald-500/40">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
            <span>{language === 'bn' ? '🔥 ১,০০০+ গেম আর্কেড হাব' : '🔥 1,000+ Games Arcade Hub'}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
            <Gamepad2 className="w-8 h-8 text-emerald-400" />
            <span>{language === 'bn' ? '১,০০০+ গেম জোন ও রিয়েল আর্নিং' : '1,000+ Games Arena & Earning'}</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
            {language === 'bn' 
              ? '১,০০০টিরও বেশি জনপ্রিয় ক্লাউড, ওয়েব ও আর্কেড গেম খেলুন! প্রতি মিনিটে নিশ্চিত কয়েন (₹) আয় করুন এবং তাৎক্ষণিক ক্যাশআউট করুন।' 
              : 'Play over 1,000+ instant cloud, web & arcade games! Earn guaranteed coins (₹) every minute and withdraw instantly to UPI.'}
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] font-bold">
            <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
              🪙 {language === 'bn' ? 'প্রতি মিনিটে ২০-৩৫ কয়েন আয়' : 'Earn 20-35 Coins/Minute'}
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              ⚡ {language === 'bn' ? 'কোনো ইনস্টল প্রয়োজন নেই' : 'No Download Required'}
            </span>
          </div>
        </div>

        {/* User Balance Card */}
        <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center shrink-0 relative z-10">
          <span className="text-[10px] text-emerald-300 uppercase tracking-wider block font-bold">
            {language === 'bn' ? 'উপলব্ধ ব্যালেন্স' : 'Available Balance'}
          </span>
          <span className="text-2xl font-black text-amber-300">
            🪙 {(currentUser?.coins || 0).toLocaleString()} 
            <span className="text-xs text-slate-300 ml-1">
              (≈ ₹{(currentUser?.coins || 0).toLocaleString()})
            </span>
          </span>
          <p className="text-[10px] text-emerald-400 mt-1">
            {language === 'bn' ? '১ কয়েন = ₹১ নগদ টাকা' : '1 Coin = ₹1 Instant Cash'}
          </p>
        </div>
      </div>

      {/* Primary Tab Switcher */}
      <div className="flex p-1.5 rounded-2xl bg-slate-900 border border-slate-800 gap-1.5">
        <button
          onClick={() => setActiveTab('hard')}
          className={`flex-1 py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'hard'
              ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white shadow-lg shadow-red-950 animate-pulse'
              : 'text-rose-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-300" />
          <span>{language === 'bn' ? '💀 হার্ড গেম (Hard Games)' : '💀 Hard Games Arena'}</span>
        </button>

        <button
          onClick={() => setActiveTab('cloud1000')}
          className={`flex-1 py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'cloud1000'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Sparkles className="w-4 h-4 text-emerald-300" />
          <span>{language === 'bn' ? '🎮 ১,০০০+ গেম হাব' : '🎮 1,000+ Games'}</span>
        </button>

        <button
          onClick={() => setActiveTab('featured')}
          className={`flex-1 py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'featured'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Trophy className="w-4 h-4 text-amber-300" />
          <span>{language === 'bn' ? '🏆 সব নেটিভ গেম (২৩টি)' : '🏆 All 23 Games'}</span>
        </button>
      </div>

      {/* TAB 0: HARD GAMES ARENA */}
      {activeTab === 'hard' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Hard Mode Banner */}
          <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-red-950 via-slate-900 to-rose-950 border border-red-500/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1.5 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/20 text-red-300 text-xs font-black border border-red-500/40">
                <span>🔥</span>
                <span>{language === 'bn' ? 'চরম প্রতিদ্বন্দ্বিতাপূর্ণ হার্ড মোড' : 'Extreme Pro Difficulty Challenge'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white">
                {language === 'bn' ? '💀 হার্ড গেম চ্যালেঞ্জ: মেগা ক্যাশ প্রাইজ' : '💀 Hard Games: High Stakes & Mega Cash'}
              </h3>
              <p className="text-xs text-slate-300 max-w-xl">
                {language === 'bn'
                  ? 'সাধারণ গেমের চেয়ে ৩ গুণ বেশি আয়! কঠোর নিয়মে ভুল না করে সম্পূর্ণ করুন এবং প্রতি গেমে ₹২৫০ থেকে ₹৫০০ পর্যন্ত নগদ কয়েন জিতে নিন।'
                  : 'Earn 3x higher coins than regular games! Zero error tolerance with extreme speed. Win up to ₹500 instant coins per game!'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-black/40 border border-red-500/30 text-center shrink-0">
              <span className="text-[10px] text-red-300 uppercase font-black tracking-wider block">Top Win Prize</span>
              <span className="text-2xl font-black text-amber-300">₹250 - ₹500</span>
              <span className="text-[10px] text-emerald-400 block font-bold">Instant Wallet Credit</span>
            </div>
          </div>

          {/* Hard Games Grid (7 Pro Games) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURED_NATIVE_GAMES.slice(0, 7).map((game) => {
              const title = language === 'bn' && game.titleBn ? game.titleBn : game.title;
              const desc = language === 'bn' && game.descriptionBn ? game.descriptionBn : game.description;

              return (
                <div
                  key={game.id}
                  className="p-5 rounded-3xl bg-slate-950 border-2 border-red-500/40 hover:border-red-400 shadow-xl shadow-red-950/20 hover:shadow-2xl transition-all flex flex-col justify-between space-y-4 group relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/5 rounded-full blur-xl pointer-events-none" />

                  <div className="space-y-3 relative z-10">
                    <div className="flex items-center justify-between">
                      <div className="w-13 h-13 rounded-2xl bg-red-500/15 border border-red-500/30 text-3xl flex items-center justify-center group-hover:scale-110 transition-transform">
                        {game.icon}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
                          {game.badge}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">
                          {game.category}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-base font-black text-white group-hover:text-red-400 transition-colors">
                        {title}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {desc}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between relative z-10">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 block">Mega Hard Win</span>
                      <span className="text-sm font-black text-amber-400 flex items-center gap-1">
                        <span>🪙</span>
                        <span>
                          {game.minReward === game.maxReward
                            ? `₹${game.minReward} Coins`
                            : `₹${game.minReward} - ₹${game.maxReward}`}
                        </span>
                      </span>
                    </div>

                    <button
                      onClick={() => setActiveNativeGameId(game.id)}
                      className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-red-600/30 active:scale-95 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>{language === 'bn' ? 'হার্ড চ্যালেঞ্জ' : 'Accept Challenge'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 1: 1,000+ GAMES HUB */}
      {activeTab === 'cloud1000' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Search & Sort Bar */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative w-full flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setDisplayCount(24);
                }}
                placeholder={language === 'bn' ? '১,০০০+ গেম থেকে নাম লিখে খুঁজুন (যেমন: কার, ক্রিকেট, এলিয়েন)...' : 'Search among 1,000+ games (e.g. Car, Cricket, Alien, Candy)...'}
                className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:border-emerald-500 shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
              <span className="text-xs text-slate-400 font-bold hidden sm:inline">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'popular' | 'rating' | 'reward')}
                className="px-3 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer focus:outline-hidden"
              >
                <option value="popular">🔥 Most Popular</option>
                <option value="rating">⭐ Highest Rating</option>
                <option value="reward">🪙 Highest Coin Reward</option>
              </select>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => {
              const label = language === 'bn' ? cat.nameBn : cat.name;
              const isSelected = selectedCategory === cat.id;

              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setDisplayCount(24);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          {/* Catalog Count Indicator */}
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>
              {language === 'bn'
                ? `প্রদর্শিত: ${Math.min(displayedGames.length, filteredCloudGames.length)} টি গেম (মোট ${filteredCloudGames.length} টির মধ্যে)`
                : `Showing ${Math.min(displayedGames.length, filteredCloudGames.length)} of ${filteredCloudGames.length} games`}
            </span>
            <span className="text-emerald-400 font-bold">
              🪙 {language === 'bn' ? 'খেললেই প্রতি মিনিটে রিওয়ার্ড' : 'Play to Earn Active'}
            </span>
          </div>

          {/* 1,000+ Games Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
            {displayedGames.map((game) => {
              const title = language === 'bn' && game.titleBn ? game.titleBn : game.title;
              const desc = language === 'bn' && game.descriptionBn ? game.descriptionBn : game.description;

              return (
                <div
                  key={game.id}
                  onClick={() => setActiveCloudGame(game)}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 shadow-xs hover:shadow-xl transition-all flex flex-col justify-between group cursor-pointer"
                >
                  <div className="space-y-2">
                    {/* Game Icon & Badge */}
                    <div className="relative aspect-square w-full rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-950 flex items-center justify-center text-4xl group-hover:scale-105 transition-transform overflow-hidden shadow-inner">
                      <span>{game.icon}</span>
                      <span className="absolute top-1.5 right-1.5 text-[8px] font-black px-1.5 py-0.5 rounded-md bg-emerald-500/90 text-slate-950 shadow-xs">
                        {game.badge}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-slate-100 group-hover:text-emerald-400 transition-colors line-clamp-1">
                        {title}
                      </h4>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                        <span>⭐ {game.rating}</span>
                        <span>{game.plays}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2.5 mt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400 flex items-center gap-0.5">
                      <span>🪙</span>
                      <span>+{game.rewardPerMin}/m</span>
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveCloudGame(game);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] flex items-center gap-1 active:scale-95 transition-all shadow-sm"
                    >
                      <Play className="w-2.5 h-2.5 fill-current" />
                      <span>Play</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Load More Button if more games available */}
          {displayedGames.length < filteredCloudGames.length && (
            <div className="text-center pt-4">
              <button
                onClick={() => setDisplayCount(prev => prev + 24)}
                className="px-6 py-3 rounded-2xl bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs border border-slate-800 hover:border-emerald-500/50 shadow-md active:scale-95 transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <span>{language === 'bn' ? 'আরো ২৪টি গেম লোড করুন...' : 'Load 24 More Games...'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: 17 FEATURED NATIVE MINI-GAMES */}
      {activeTab === 'featured' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-800/40 text-xs text-indigo-300 flex items-center justify-between">
            <span>🏆 {language === 'bn' ? '১৭টি সম্পূর্ণ ইন্টারঅ্যাক্টিভ ক্যাশ রিওয়ার্ড গেম' : '17 Fully Interactive Cash Reward Native Games'}</span>
            <span className="font-bold text-amber-300">{language === 'bn' ? 'সর্বোচ্চ ₹৫০০ পর্যন্ত পুরস্কার' : 'Win up to ₹500 Instant Cash'}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURED_NATIVE_GAMES.map((game) => {
              const title = language === 'bn' && game.titleBn ? game.titleBn : game.title;
              const desc = language === 'bn' && game.descriptionBn ? game.descriptionBn : game.description;

              return (
                <div
                  key={game.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between space-y-4 group"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                        {game.icon}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                          {game.badge}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {game.category}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-500 transition-colors">
                        {title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {desc}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Win Cash</span>
                      <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <span>🪙</span>
                        <span>
                          {game.minReward === game.maxReward
                            ? `₹${game.minReward} Coins`
                            : `₹${game.minReward} - ₹${game.maxReward}`}
                        </span>
                      </span>
                    </div>

                    <button
                      onClick={() => setActiveNativeGameId(game.id)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/20 active:scale-95 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>{t('playNow')}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CLOUD ARCADE MODAL (Plays ANY of the 1,000+ games!) */}
      {activeCloudGame && (
        <CloudArcadePlayerModal
          game={activeCloudGame}
          isOpen={true}
          onClose={() => setActiveCloudGame(null)}
          onRewardWon={handleRewardWon}
        />
      )}

      {/* NATIVE GAME MODALS */}
      {activeNativeGameId === 'ludo' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveNativeGameId(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              ✕
            </button>
            <LudoGame onRewardWon={handleRewardWon} onClose={() => setActiveNativeGameId(null)} />
          </div>
        </div>
      )}

      {activeNativeGameId === 'gk_quiz' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveNativeGameId(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              ✕
            </button>
            <GkQuizGame onRewardWon={handleRewardWon} onClose={() => setActiveNativeGameId(null)} />
          </div>
        </div>
      )}

      {activeNativeGameId === 'spin_wheel' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveNativeGameId(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              ✕
            </button>
            <SpinWheelGame onRewardWon={handleRewardWon} onClose={() => setActiveNativeGameId(null)} />
          </div>
        </div>
      )}

      {activeNativeGameId === 'scratch_card' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveNativeGameId(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              ✕
            </button>
            <ScratchCardGame onRewardWon={handleRewardWon} onClose={() => setActiveNativeGameId(null)} />
          </div>
        </div>
      )}

      {/* Mini Games (Math, Memory, Color Reflex, Coin Tap, Dice 7, Number Guess, Flappy, Knife Hit, Snake, Tic Tac Toe, RPS, Cricket, Tower) */}
      {activeNativeGameId && ![
        'ludo', 
        'gk_quiz', 
        'spin_wheel', 
        'scratch_card'
      ].includes(activeNativeGameId) && (
        <MiniGamesModal
          gameId={activeNativeGameId}
          isOpen={true}
          onClose={() => setActiveNativeGameId(null)}
          onRewardWon={handleRewardWon}
        />
      )}

    </div>
  );
};
