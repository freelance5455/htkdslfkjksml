import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  RefreshCw, 
  Sparkles, 
  Flame, 
  ShieldCheck, 
  Star, 
  Zap, 
  Crosshair, 
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface LudoGameProps {
  onRewardWon: (coins: number, gameName: string) => void;
  onClose: () => void;
}

type GameDifficulty = 'classic' | 'hard' | 'master';

interface TokenState {
  id: number;
  name: string;
  pos: number; // 0 = at base, 1 to targetScore = on track
  isHome: boolean;
}

export const LudoGame: React.FC<LudoGameProps> = ({ onRewardWon, onClose }) => {
  const { language } = useApp();
  
  // Game Configuration
  const [difficulty, setDifficulty] = useState<GameDifficulty>('hard');
  
  // Settings based on difficulty
  const targetScore = difficulty === 'classic' ? 20 : difficulty === 'hard' ? 28 : 24;
  const safePositions = difficulty === 'classic' ? [1, 10] : difficulty === 'hard' ? [1, 8, 15, 22] : [1, 9, 17];
  const prizeCoins = difficulty === 'classic' ? 75 : difficulty === 'hard' ? 250 : 500;

  // Dice & Turn state
  const [diceNumber, setDiceNumber] = useState<number>(6);
  const [isRolling, setIsRolling] = useState(false);
  const [turn, setTurn] = useState<'player' | 'computer'>('player');
  const [extraRoll, setExtraRoll] = useState(false);
  const [gameStatus, setGameStatus] = useState<'playing' | 'player_won' | 'computer_won'>('playing');
  const [turnMessage, setTurnMessage] = useState('Your turn! Tap the dice to roll.');
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Tokens: Classic & Hard have 1 token; Master has 2 tokens
  const tokenCount = difficulty === 'master' ? 2 : 1;
  const [playerTokens, setPlayerTokens] = useState<TokenState[]>([
    { id: 1, name: 'Token 1', pos: 0, isHome: false },
    { id: 2, name: 'Token 2', pos: 0, isHome: false }
  ]);
  const [compTokens, setCompTokens] = useState<TokenState[]>([
    { id: 1, name: 'Comp 1', pos: 0, isHome: false },
    { id: 2, name: 'Comp 2', pos: 0, isHome: false }
  ]);

  // Selected player token for multi-token moves
  const [selectedTokenIndex, setSelectedTokenIndex] = useState<number>(0);

  // Reset when difficulty changes
  useEffect(() => {
    resetGame();
  }, [difficulty]);

  const resetGame = () => {
    setIsRolling(false);
    setTurn('player');
    setExtraRoll(false);
    setGameStatus('playing');
    setDiceNumber(6);
    setAlertMessage(null);
    setSelectedTokenIndex(0);
    setPlayerTokens([
      { id: 1, name: 'Token 1', pos: 0, isHome: false },
      { id: 2, name: 'Token 2', pos: 0, isHome: false }
    ]);
    setCompTokens([
      { id: 1, name: 'Comp 1', pos: 0, isHome: false },
      { id: 2, name: 'Comp 2', pos: 0, isHome: false }
    ]);
    setTurnMessage(
      difficulty === 'hard'
        ? (language === 'bn' ? 'কঠিন মোড চালু! কম্পিউটার আপনার ঘুঁটি কাটতে পারে। ডাইস রোল করুন!' : 'Hard Mode Active! AI will hunt & capture your tokens. Roll the dice!')
        : difficulty === 'master'
        ? (language === 'bn' ? 'মাস্টার মোড: ২টি ঘুঁটিই ঘরে পৌঁছাতে হবে (পুরস্কার ₹৫০০)!' : 'Master Mode: Bring BOTH tokens home to win ₹500!')
        : (language === 'bn' ? 'ক্লাসিক মোড: ঘরে পৌঁছান ও জিতুন!' : 'Classic Mode: First to Home wins ₹75!')
    );
  };

  // Trigger temporary capture notification
  const triggerAlert = (msg: string) => {
    setAlertMessage(msg);
    setTimeout(() => setAlertMessage(null), 3500);
  };

  const rollDice = () => {
    if (isRolling || turn !== 'player' || gameStatus !== 'playing') return;

    setIsRolling(true);
    setTurnMessage(language === 'bn' ? 'ডাইস ঘুরছে...' : 'Rolling dice...');

    let count = 0;
    const interval = setInterval(() => {
      setDiceNumber(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 7) {
        clearInterval(interval);
        const finalRoll = Math.floor(Math.random() * 6) + 1;
        setDiceNumber(finalRoll);
        setIsRolling(false);
        handlePlayerTurn(finalRoll);
      }
    }, 60);
  };

  const handlePlayerTurn = (roll: number) => {
    // Determine which token to move
    let targetTokenIdx = selectedTokenIndex;
    if (tokenCount === 1) {
      targetTokenIdx = 0;
    } else {
      // In master mode, if selected token is already home, use the other
      if (playerTokens[targetTokenIdx].isHome) {
        targetTokenIdx = targetTokenIdx === 0 ? 1 : 0;
      }
    }

    const currentToken = playerTokens[targetTokenIdx];
    let nextPos = currentToken.pos === 0 ? roll : currentToken.pos + roll;
    
    // Check if overshoot
    if (nextPos > targetScore) {
      nextPos = targetScore; // Allow landing on home
    }

    const isNowHome = nextPos >= targetScore;
    let didCapture = false;

    // Check if landing on computer token (Capture mechanics in Hard and Master)
    let updatedCompTokens = [...compTokens];
    if (difficulty !== 'classic' && !safePositions.includes(nextPos) && !isNowHome) {
      for (let i = 0; i < tokenCount; i++) {
        if (!updatedCompTokens[i].isHome && updatedCompTokens[i].pos === nextPos) {
          // CAPTURE! Send computer token back to 1
          updatedCompTokens[i] = { ...updatedCompTokens[i], pos: 1 };
          didCapture = true;
          triggerAlert(
            language === 'bn' 
              ? '⚔️ আপনি কম্পিউটারের ঘুঁটি কেটেছেন! কম্পিউটার আবার শুরুতে ফিরে গেছে (+বোনাস রোল)!' 
              : '⚔️ CAPTURE! You cut the computer\'s token and sent it to start! Extra roll granted!'
          );
          break;
        }
      }
    }

    const updatedPlayerTokens = playerTokens.map((t, idx) => 
      idx === targetTokenIdx ? { ...t, pos: nextPos, isHome: isNowHome } : t
    );

    setPlayerTokens(updatedPlayerTokens);
    setCompTokens(updatedCompTokens);

    // Check Win Condition
    const allPlayerHome = updatedPlayerTokens.slice(0, tokenCount).every(t => t.isHome);
    if (allPlayerHome) {
      setGameStatus('player_won');
      setTurnMessage(language === 'bn' ? 'অভিনন্দন! আপনি জিতেছেন 🏆' : 'Victory! You defeated the AI 🏆');
      confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
      onRewardWon(prizeCoins, `Ludo (${difficulty.toUpperCase()} Mode)`);
      return;
    }

    // Extra roll on 6 or capture!
    const getsExtraRoll = roll === 6 || didCapture;
    if (getsExtraRoll) {
      setTurn('player');
      setTurnMessage(
        roll === 6 
          ? (language === 'bn' ? 'ছক্কা (6)! আপনি আবার ডাইস রোল করার সুযোগ পেলেন!' : 'Rolled a 6! You earned a BONUS ROLL!')
          : (language === 'bn' ? 'ঘুঁটি কাটার কারণে বোনাস রোল পেলেন!' : 'Opponent captured! Extra turn granted!')
      );
    } else {
      setTurn('computer');
      setTurnMessage(language === 'bn' ? `আপনি ${roll} পেয়েছেন। এবার কম্পিউটারের চাল...` : `You rolled ${roll}! AI is planning its strike...`);
    }
  };

  // AI Turn Logic (Smart & Aggressive in Hard and Master)
  useEffect(() => {
    if (turn === 'computer' && gameStatus === 'playing') {
      const timer = setTimeout(() => {
        const compRoll = Math.floor(Math.random() * 6) + 1;
        setDiceNumber(compRoll);

        // Choose computer token strategically
        let chosenCompIdx = 0;
        if (tokenCount > 1) {
          if (compTokens[0].isHome) chosenCompIdx = 1;
          else if (compTokens[1].isHome) chosenCompIdx = 0;
          else {
            // Aggressive AI: Check if either token can capture a player token
            const can0Capture = playerTokens.slice(0, tokenCount).some(pt => !pt.isHome && (compTokens[0].pos + compRoll === pt.pos) && !safePositions.includes(pt.pos));
            const can1Capture = playerTokens.slice(0, tokenCount).some(pt => !pt.isHome && (compTokens[1].pos + compRoll === pt.pos) && !safePositions.includes(pt.pos));
            if (can1Capture) chosenCompIdx = 1;
            else if (can0Capture) chosenCompIdx = 0;
            else chosenCompIdx = compTokens[0].pos >= compTokens[1].pos ? 0 : 1;
          }
        }

        const currComp = compTokens[chosenCompIdx];
        let nextCompPos = currComp.pos === 0 ? compRoll : currComp.pos + compRoll;
        if (nextCompPos > targetScore) nextCompPos = targetScore;

        const isCompHome = nextCompPos >= targetScore;
        let aiDidCapture = false;
        let updatedPlayerTokens = [...playerTokens];

        // AI token capture check in Hard and Master
        if (difficulty !== 'classic' && !safePositions.includes(nextCompPos) && !isCompHome) {
          for (let i = 0; i < tokenCount; i++) {
            if (!updatedPlayerTokens[i].isHome && updatedPlayerTokens[i].pos === nextCompPos) {
              // AI Captures Player! Send player back to 1
              updatedPlayerTokens[i] = { ...updatedPlayerTokens[i], pos: 1 };
              aiDidCapture = true;
              triggerAlert(
                language === 'bn'
                  ? '⚠️ সাবধান! কম্পিউটার আপনার ঘুঁটি কেটে দিল! আপনার ঘুঁটি শুরুতে চলে গেল।'
                  : '⚠️ OUCH! The AI captured your token and sent you back to square 1!'
              );
              break;
            }
          }
        }

        const updatedCompTokens = compTokens.map((t, idx) => 
          idx === chosenCompIdx ? { ...t, pos: nextCompPos, isHome: isCompHome } : t
        );

        setCompTokens(updatedCompTokens);
        setPlayerTokens(updatedPlayerTokens);

        // Check if Computer Won
        const allCompHome = updatedCompTokens.slice(0, tokenCount).every(t => t.isHome);
        if (allCompHome) {
          setGameStatus('computer_won');
          setTurnMessage(language === 'bn' ? 'কম্পিউটার আগে ঘরে পৌঁছে গেল! পুনরায় চেষ্টা করুন।' : 'AI reached Home first! Try again to claim reward.');
          return;
        }

        // Computer extra roll on 6 or capture
        const compGetsExtra = compRoll === 6 || aiDidCapture;
        if (compGetsExtra) {
          setTurn('computer');
          setTurnMessage(
            compRoll === 6 
              ? (language === 'bn' ? 'কম্পিউটার ছক্কা (6) পেয়েছে! কম্পিউটার আবারও ডাইস ফেলছে...' : 'AI rolled a 6 and gets another roll!')
              : (language === 'bn' ? 'কম্পিউটার ঘুঁটি কেটে অতিরিক্ত চাল পেল!' : 'AI captured your token and gets an extra turn!')
          );
        } else {
          setTurn('player');
          setTurnMessage(
            language === 'bn' 
              ? `কম্পিউটার ${compRoll} পেল। এবার আপনার পালা! ডাইস রোল করুন।` 
              : `AI rolled ${compRoll}. Your turn! Tap the dice.`
          );
        }
      }, 1000);

      return () => clearTimeout(timer);
    }
  }, [turn, gameStatus, compTokens, playerTokens, difficulty, tokenCount, targetScore]);

  return (
    <div className="space-y-4 text-center">
      {/* Top Banner with Difficulty Picker */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-amber-600 to-emerald-600 text-white shadow-md space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-left">
            <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-xl">
              🎲
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base tracking-tight flex items-center gap-1.5">
                <span>Ludo Dice Duel</span>
                {difficulty === 'hard' && (
                  <span className="text-[10px] bg-rose-500 text-white font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-0.5">
                    <Flame className="w-2.5 h-2.5" /> Hard Game
                  </span>
                )}
                {difficulty === 'master' && (
                  <span className="text-[10px] bg-amber-400 text-amber-950 font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-0.5">
                    <Zap className="w-2.5 h-2.5" /> Master
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-white/90">
                {difficulty === 'hard' 
                  ? (language === 'bn' ? 'কঠিন মোড: ঘুঁটি কাটার যুদ্ধ! পুরস্কার ₹২৫০' : 'Hard Mode: Capture opponent tokens to win ₹250!')
                  : difficulty === 'master'
                  ? (language === 'bn' ? 'মাস্টার মোড: ২টি ঘুঁটিই ঘরে তুলুন! পুরস্কার ₹৫০০' : 'Master Mode: Race 2 tokens & dodge AI strikes! ₹500')
                  : (language === 'bn' ? 'ক্লাসিক মোড: সহজ রেস! পুরস্কার ₹৭৫' : 'Classic Mode: Race to Home! ₹75')}
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[9px] uppercase font-bold text-amber-200 block">Reward</span>
            <span className="text-base sm:text-lg font-black text-amber-300">
              🪙 +{prizeCoins} (₹{prizeCoins})
            </span>
          </div>
        </div>

        {/* Difficulty Selection Pills */}
        <div className="grid grid-cols-3 gap-1.5 pt-1">
          <button
            type="button"
            onClick={() => setDifficulty('classic')}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
              difficulty === 'classic'
                ? 'bg-white text-slate-900 shadow-md ring-2 ring-emerald-400'
                : 'bg-black/25 text-white/80 hover:bg-black/40'
            }`}
          >
            Classic (₹75)
          </button>
          <button
            type="button"
            onClick={() => setDifficulty('hard')}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
              difficulty === 'hard'
                ? 'bg-rose-500 text-white shadow-md ring-2 ring-white font-black'
                : 'bg-black/25 text-white/80 hover:bg-black/40'
            }`}
          >
            <Flame className="w-3 h-3 text-amber-300" />
            <span>🔥 Hard (₹250)</span>
          </button>
          <button
            type="button"
            onClick={() => setDifficulty('master')}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
              difficulty === 'master'
                ? 'bg-amber-400 text-amber-950 shadow-md ring-2 ring-white font-black'
                : 'bg-black/25 text-white/80 hover:bg-black/40'
            }`}
          >
            <Zap className="w-3 h-3" />
            <span>Master 2P (₹500)</span>
          </button>
        </div>
      </div>

      {/* Capture or Alert Notification */}
      {alertMessage && (
        <div className="p-2.5 rounded-xl bg-amber-500 text-white font-black text-xs animate-bounce shadow-md flex items-center justify-center gap-1.5">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{alertMessage}</span>
        </div>
      )}

      {/* Ludo Track & Tokens Card */}
      <div className="p-4 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
        {/* Token Selection for Master Mode */}
        {tokenCount > 1 && (
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700/80">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Select Token to Move:
            </span>
            <div className="flex gap-2">
              {playerTokens.map((tok, idx) => (
                <button
                  key={tok.id}
                  onClick={() => setSelectedTokenIndex(idx)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    selectedTokenIndex === idx
                      ? 'bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-400'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                  <span>{tok.name} ({tok.isHome ? 'Home 🏠' : `${tok.pos}/${targetScore}`})</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Player Progress Bars */}
        <div className="space-y-2 text-left">
          {playerTokens.slice(0, tokenCount).map((tok, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block shadow-xs" />
                  <span>You {tokenCount > 1 ? `(${tok.name})` : '(Green Token)'}</span>
                </span>
                <span className="text-slate-600 dark:text-slate-300">
                  {tok.isHome ? 'Reached Home 🏆' : `${tok.pos} / ${targetScore} Steps`}
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300 rounded-full"
                  style={{ width: `${Math.min(100, (tok.pos / targetScore) * 100)}%` }}
                />
              </div>
            </div>
          ))}

          {/* Computer Progress Bars */}
          {compTokens.slice(0, tokenCount).map((tok, idx) => (
            <div key={idx} className="space-y-1 pt-1">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-rose-500 inline-block shadow-xs" />
                  <span>Computer {tokenCount > 1 ? `(${tok.name})` : '(Red Token)'}</span>
                </span>
                <span className="text-slate-600 dark:text-slate-300">
                  {tok.isHome ? 'Reached Home 🚩' : `${tok.pos} / ${targetScore} Steps`}
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-rose-500 to-orange-400 transition-all duration-300 rounded-full"
                  style={{ width: `${Math.min(100, (tok.pos / targetScore) * 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Board Cells Grid with Star Safe Spots */}
        <div className="space-y-1 pt-1">
          <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-semibold px-1">
            <span className="flex items-center gap-1">
              <Star className="w-3 h-3 text-amber-500 fill-amber-400" />
              <span>Safe Spots (Cannot be captured)</span>
            </span>
            <span>Target: Cell {targetScore}</span>
          </div>

          <div className={`grid gap-1 pt-1 ${targetScore > 24 ? 'grid-cols-7 sm:grid-cols-14' : 'grid-cols-6 sm:grid-cols-12'}`}>
            {Array.from({ length: targetScore }).map((_, idx) => {
              const stepNum = idx + 1;
              const isSafe = safePositions.includes(stepNum);
              const isHome = stepNum === targetScore;

              // Check tokens on this step
              const playerTokensHere = playerTokens.slice(0, tokenCount).filter(t => t.pos === stepNum && !t.isHome);
              const compTokensHere = compTokens.slice(0, tokenCount).filter(t => t.pos === stepNum && !t.isHome);

              return (
                <div 
                  key={idx} 
                  className={`h-9 rounded-lg border flex flex-col items-center justify-center text-[10px] font-bold relative transition-all ${
                    isHome 
                      ? 'bg-amber-100 dark:bg-amber-950 border-amber-400 text-amber-700 dark:text-amber-300 font-black' 
                      : isSafe
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-400'
                  }`}
                  title={isSafe ? 'Safe Star Cell (No capture)' : isHome ? 'Home Cell' : `Step ${stepNum}`}
                >
                  {isHome ? '🏠' : isSafe ? '⭐' : stepNum}

                  {/* Player Token Pins */}
                  {playerTokensHere.length > 0 && (
                    <div className="absolute -top-1.5 flex gap-0.5">
                      {playerTokensHere.map((_, pIdx) => (
                        <span 
                          key={pIdx} 
                          className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white shadow-xs animate-bounce" 
                        />
                      ))}
                    </div>
                  )}

                  {/* Computer Token Pins */}
                  {compTokensHere.length > 0 && (
                    <div className="absolute -bottom-1.5 flex gap-0.5">
                      {compTokensHere.map((_, cIdx) => (
                        <span 
                          key={cIdx} 
                          className="w-3 h-3 rounded-full bg-rose-500 ring-2 ring-white shadow-xs" 
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Turn Status Message */}
      <div className={`p-3 rounded-xl border text-xs font-semibold transition-all ${
        turn === 'player'
          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
          : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
      }`}>
        {turnMessage}
      </div>

      {/* Interactive Dice Roller */}
      <div className="py-2 flex flex-col items-center justify-center gap-2">
        <button
          onClick={rollDice}
          disabled={isRolling || turn !== 'player' || gameStatus !== 'playing'}
          className={`w-24 h-24 rounded-3xl border-2 flex items-center justify-center text-4xl font-black shadow-xl transition-all select-none cursor-pointer ${
            turn === 'player' && gameStatus === 'playing'
              ? 'bg-gradient-to-tr from-amber-400 to-yellow-300 text-amber-950 border-amber-300 ring-4 ring-amber-400/40 hover:scale-105 active:scale-95 animate-pulse'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-300 dark:border-slate-700 opacity-60 cursor-not-allowed'
          }`}
          title="Tap to Roll Dice"
        >
          {diceNumber}
        </button>

        <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
          {turn === 'player' && gameStatus === 'playing'
            ? '👉 Tap the Dice to Roll!'
            : isRolling
            ? 'Rolling...'
            : 'Waiting for AI move...'}
        </p>
      </div>

      {/* Victory / Defeat Modal Action */}
      {gameStatus !== 'playing' && (
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          {gameStatus === 'player_won' ? (
            <div className="space-y-1">
              <h4 className="text-base font-black text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span>Victory! +{prizeCoins} Coins (₹{prizeCoins}) Added to Wallet!</span>
              </h4>
              <p className="text-xs text-slate-500">
                You outsmarted the AI in {difficulty.toUpperCase()} mode!
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <h4 className="text-base font-bold text-rose-500">
                Computer Won This Match!
              </h4>
              <p className="text-xs text-slate-500">
                The AI was aggressive this round. Roll again to claim victory!
              </p>
            </div>
          )}

          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={resetGame}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Play Again</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold cursor-pointer"
            >
              Back to Game Zone
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
