import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Pause, 
  Play, 
  Sparkles, 
  Coins, 
  Trophy, 
  ShieldCheck, 
  Clock, 
  Flame,
  Gamepad2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CloudGame } from '../../data/games1000Data';
import { useApp } from '../../context/AppContext';

interface CloudArcadePlayerModalProps {
  game: CloudGame | null;
  isOpen: boolean;
  onClose: () => void;
  onRewardWon: (coins: number, gameName: string) => void;
}

export const CloudArcadePlayerModal: React.FC<CloudArcadePlayerModalProps> = ({
  game,
  isOpen,
  onClose,
  onRewardWon,
}) => {
  const { language } = useApp();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [playTimeSeconds, setPlayTimeSeconds] = useState(0);
  const [nextRewardCountdown, setNextRewardCountdown] = useState(60);
  const [totalCoinsEarnedThisSession, setTotalCoinsEarnedThisSession] = useState(0);
  const [rewardToast, setRewardToast] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const modalContainerRef = useRef<HTMLDivElement | null>(null);

  // Web Audio Context for Arcade Sounds
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playArcadeSound = (type: 'laser' | 'coin' | 'hit' | 'over') => {
    if (isMuted) return;
    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (type === 'laser') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(150, now + 0.12);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.12);
        osc.start(now);
        osc.stop(now + 0.12);
      } else if (type === 'coin') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.setValueAtTime(1200, now + 0.08);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'hit') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(180, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.15);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'over') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.linearRampToValueAtTime(80, now + 0.4);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      }
    } catch {
      // Audio not supported or blocked
    }
  };

  // Play-to-Earn timer: runs every second while game is active
  useEffect(() => {
    if (!isOpen || !game || isPaused) return;

    const timer = setInterval(() => {
      setPlayTimeSeconds(prev => prev + 1);
      setNextRewardCountdown(prev => {
        if (prev <= 1) {
          // Reward user!
          const rewardAmount = game.rewardPerMin || 25;
          onRewardWon(rewardAmount, `${game.title} (Play-Time Bonus)`);
          setTotalCoinsEarnedThisSession(c => c + rewardAmount);
          confetti({ particleCount: 60, spread: 55 });
          playArcadeSound('coin');

          const msg = language === 'bn' 
            ? `🎉 চমৎকার! ১ মিনিট খেলার জন্য +${rewardAmount} কয়েন (₹${rewardAmount}) আয় করেছেন!`
            : `🎉 Awesome! Earned +${rewardAmount} Coins (₹${rewardAmount}) for 1 min of gameplay!`;
          setRewardToast(msg);
          setTimeout(() => setRewardToast(null), 4000);

          return 60; // reset countdown to 60s
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, game, isPaused, language, onRewardWon]);

  // Canvas Game Loop Engine
  const gameLoopRef = useRef<number | null>(null);
  const gameStateRef = useRef<{
    playerX: number;
    playerY: number;
    playerVx: number;
    playerVy: number;
    bullets: Array<{ x: number; y: number; vy: number }>;
    targets: Array<{ x: number; y: number; size: number; vx: number; vy: number; color: string; hp: number }>;
    coins: Array<{ x: number; y: number; size: number; vy: number }>;
    lives: number;
    isOver: boolean;
    keys: { left: boolean; right: boolean; action: boolean };
  }>({
    playerX: 180,
    playerY: 340,
    playerVx: 0,
    playerVy: 0,
    bullets: [],
    targets: [],
    coins: [],
    lives: 3,
    isOver: false,
    keys: { left: false, right: false, action: false },
  });

  const resetGameState = () => {
    const canvas = canvasRef.current;
    const w = canvas ? canvas.width : 360;
    const h = canvas ? canvas.height : 480;

    gameStateRef.current = {
      playerX: w / 2,
      playerY: h - 60,
      playerVx: 0,
      playerVy: 0,
      bullets: [],
      targets: [],
      coins: [],
      lives: 3,
      isOver: false,
      keys: { left: false, right: false, action: false },
    };
    setScore(0);
    setIsPaused(false);
  };

  useEffect(() => {
    if (!isOpen || !game) return;
    resetGameState();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();
    let spawnTimer = 0;
    let coinTimer = 0;
    let shootTimer = 0;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        gameStateRef.current.keys.left = true;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        gameStateRef.current.keys.right = true;
      }
      if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        gameStateRef.current.keys.action = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        gameStateRef.current.keys.left = false;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        gameStateRef.current.keys.right = false;
      }
      if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        gameStateRef.current.keys.action = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Frame runner
    const render = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      const state = gameStateRef.current;
      const w = canvas.width;
      const h = canvas.height;

      if (!isPaused && !state.isOver) {
        // Player movement
        const speed = 260;
        if (state.keys.left) state.playerX = Math.max(25, state.playerX - speed * dt);
        if (state.keys.right) state.playerX = Math.min(w - 25, state.playerX + speed * dt);

        // Flappy mode gravity
        if (game.arcadeType === 'flappy_bird') {
          state.playerVy += 750 * dt;
          state.playerY += state.playerVy * dt;
          if (state.playerY > h - 35) {
            state.playerY = h - 35;
            state.isOver = true;
            playArcadeSound('over');
          }
          if (state.playerY < 20) state.playerY = 20;
        }

        // Action / Shoot
        shootTimer += dt;
        if (state.keys.action && shootTimer > 0.18) {
          shootTimer = 0;
          if (game.arcadeType === 'flappy_bird') {
            state.playerVy = -320;
            playArcadeSound('laser');
          } else {
            state.bullets.push({ x: state.playerX, y: state.playerY - 18, vy: -450 });
            playArcadeSound('laser');
          }
        }

        // Spawn targets / obstacles
        spawnTimer += dt;
        if (spawnTimer > (game.arcadeType === 'car_racing' ? 0.9 : 0.75)) {
          spawnTimer = 0;
          const colors = ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899'];
          const targetColor = colors[Math.floor(Math.random() * colors.length)];
          const size = game.arcadeType === 'car_racing' ? 32 : Math.floor(Math.random() * 16) + 18;

          state.targets.push({
            x: Math.random() * (w - 60) + 30,
            y: -20,
            size,
            vx: (Math.random() - 0.5) * 50,
            vy: game.arcadeType === 'car_racing' ? 240 : 130 + Math.random() * 80,
            color: targetColor,
            hp: 1,
          });
        }

        // Spawn bonus coins
        coinTimer += dt;
        if (coinTimer > 2.0) {
          coinTimer = 0;
          state.coins.push({
            x: Math.random() * (w - 60) + 30,
            y: -20,
            size: 14,
            vy: 160,
          });
        }

        // Update bullets
        state.bullets.forEach(b => {
          b.y += b.vy * dt;
        });
        state.bullets = state.bullets.filter(b => b.y > -20);

        // Update targets & collision
        for (let i = state.targets.length - 1; i >= 0; i--) {
          const t = state.targets[i];
          t.y += t.vy * dt;
          t.x += t.vx * dt;

          // Collision with bullets
          for (let j = state.bullets.length - 1; j >= 0; j--) {
            const b = state.bullets[j];
            const dist = Math.hypot(b.x - t.x, b.y - t.y);
            if (dist < t.size + 6) {
              state.bullets.splice(j, 1);
              state.targets.splice(i, 1);
              playArcadeSound('hit');
              setScore(s => {
                const nextScore = s + 10;
                setHighScore(hs => Math.max(hs, nextScore));
                return nextScore;
              });
              break;
            }
          }

          // Collision with player
          const distToPlayer = Math.hypot(state.playerX - t.x, state.playerY - t.y);
          if (distToPlayer < t.size + 16) {
            state.targets.splice(i, 1);
            state.lives -= 1;
            playArcadeSound('hit');
            if (state.lives <= 0) {
              state.isOver = true;
              playArcadeSound('over');
            }
          }
        }
        state.targets = state.targets.filter(t => t.y < h + 40);

        // Update coins & player collect
        for (let i = state.coins.length - 1; i >= 0; i--) {
          const c = state.coins[i];
          c.y += c.vy * dt;
          const dist = Math.hypot(state.playerX - c.x, state.playerY - c.y);
          if (dist < c.size + 20) {
            state.coins.splice(i, 1);
            playArcadeSound('coin');
            setScore(s => {
              const nextScore = s + 25;
              setHighScore(hs => Math.max(hs, nextScore));
              return nextScore;
            });
          }
        }
        state.coins = state.coins.filter(c => c.y < h + 30);
      }

      // Drawing the frame
      ctx.clearRect(0, 0, w, h);

      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(1, '#0f172a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Starfield / Grid lines
      ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
      for (let i = 0; i < 25; i++) {
        const sx = ((i * 37 + time * 0.05) % w);
        const sy = ((i * 73 + time * 0.12) % h);
        ctx.fillRect(sx, sy, 2, 2);
      }

      // Draw road if racing
      if (game.arcadeType === 'car_racing') {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(40, 0, w - 80, h);
        ctx.strokeStyle = '#f59e0b';
        ctx.setLineDash([20, 20]);
        ctx.lineDashOffset = -time * 0.3;
        ctx.beginPath();
        ctx.moveTo(w / 2, 0);
        ctx.lineTo(w / 2, h);
        ctx.lineWidth = 4;
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Draw Bullets
      ctx.fillStyle = '#38bdf8';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#0ea5e9';
      state.bullets.forEach(b => {
        ctx.beginPath();
        ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.shadowBlur = 0;

      // Draw Targets / Obstacles
      state.targets.forEach(t => {
        ctx.fillStyle = t.color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = t.color;
        ctx.beginPath();
        if (game.arcadeType === 'car_racing') {
          // Draw opponent car
          ctx.roundRect(t.x - 14, t.y - 20, 28, 40, 6);
          ctx.fill();
        } else {
          ctx.arc(t.x, t.y, t.size, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      ctx.shadowBlur = 0;

      // Draw Coins
      state.coins.forEach(c => {
        ctx.fillStyle = '#fbbf24';
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#f59e0b';
        ctx.beginPath();
        ctx.arc(c.x, c.y, c.size, 0, Math.PI * 2);
        ctx.fill();
        // Inner detail
        ctx.fillStyle = '#78350f';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('₹', c.x, c.y);
      });
      ctx.shadowBlur = 0;

      // Draw Player
      ctx.save();
      ctx.translate(state.playerX, state.playerY);
      if (game.arcadeType === 'flappy_bird') {
        // Flappy character
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(6, -4, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(8, -4, 2, 0, Math.PI * 2);
        ctx.fill();
        // Beak
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.moveTo(14, 0);
        ctx.lineTo(22, 4);
        ctx.lineTo(14, 8);
        ctx.fill();
      } else if (game.arcadeType === 'car_racing') {
        // Sports car
        ctx.fillStyle = '#10b981';
        ctx.roundRect(-16, -24, 32, 48, 8);
        ctx.fill();
        // Windshield
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-10, -10, 20, 14);
      } else {
        // Spaceship
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.moveTo(0, -22);
        ctx.lineTo(18, 16);
        ctx.lineTo(0, 8);
        ctx.lineTo(-18, 16);
        ctx.closePath();
        ctx.fill();
        // Thruster flame
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.moveTo(-6, 12);
        ctx.lineTo(0, 24 + Math.sin(time * 0.03) * 6);
        ctx.lineTo(6, 12);
        ctx.fill();
      }
      ctx.restore();

      // Game Over Overlay
      if (state.isOver) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.fillRect(0, 0, w, h);

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 26px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(language === 'bn' ? 'গেম শেষ!' : 'GAME OVER', w / 2, h / 2 - 30);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText(`${language === 'bn' ? 'স্কোর:' : 'Score:'} ${score}`, w / 2, h / 2 + 10);

        ctx.fillStyle = '#38bdf8';
        ctx.font = '13px sans-serif';
        ctx.fillText(language === 'bn' ? 'পুনরায় শুরু করতে রিস্টার্ট ট্যাপ করুন' : 'Tap Restart or Press Space to Retry', w / 2, h / 2 + 45);
      }

      gameLoopRef.current = requestAnimationFrame(render);
    };

    gameLoopRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isOpen, game, isPaused, language, score]);

  const toggleFullscreen = () => {
    if (!modalContainerRef.current) return;
    if (!document.fullscreenElement) {
      modalContainerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const triggerMobileAction = (type: 'left' | 'right' | 'action') => {
    const state = gameStateRef.current;
    if (state.isOver) {
      resetGameState();
      return;
    }
    if (type === 'left') {
      state.playerX = Math.max(25, state.playerX - 35);
    } else if (type === 'right') {
      const canvas = canvasRef.current;
      const w = canvas ? canvas.width : 360;
      state.playerX = Math.min(w - 25, state.playerX + 35);
    } else if (type === 'action') {
      if (game?.arcadeType === 'flappy_bird') {
        state.playerVy = -320;
        playArcadeSound('laser');
      } else {
        state.bullets.push({ x: state.playerX, y: state.playerY - 18, vy: -450 });
        playArcadeSound('laser');
      }
    }
  };

  if (!isOpen || !game) return null;

  const title = language === 'bn' && game.titleBn ? game.titleBn : game.title;
  const desc = language === 'bn' && game.descriptionBn ? game.descriptionBn : game.description;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        ref={modalContainerRef}
        className={`w-full ${isFullscreen ? 'h-full max-w-none rounded-none' : 'max-w-2xl max-h-[95vh] rounded-3xl'} bg-slate-950 border border-slate-800 shadow-2xl flex flex-col overflow-hidden relative`}
      >
        {/* Top Floating Reward Notification */}
        {rewardToast && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-emerald-500 text-slate-950 font-black text-xs px-4 py-2 rounded-2xl shadow-2xl animate-bounce flex items-center gap-2">
            <span>🪙</span>
            <span>{rewardToast}</span>
          </div>
        )}

        {/* Modal Header */}
        <div className="p-3.5 sm:p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xl shrink-0">
              {game.icon}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-black text-white truncate">{title}</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                  {game.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">{game.category}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setIsMuted(m => !m)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Play-To-Earn Live Status Bar */}
        <div className="px-4 py-2 bg-gradient-to-r from-emerald-950/80 via-slate-900 to-amber-950/80 border-b border-emerald-900/50 flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 text-emerald-400 font-bold">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>
                {Math.floor(playTimeSeconds / 60).toString().padStart(2, '0')}:
                {(playTimeSeconds % 60).toString().padStart(2, '0')}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="text-[10px] text-slate-400">Next Cash Reward:</span>
              <span className="font-mono font-black text-amber-400">{nextRewardCountdown}s</span>
              <span className="text-[10px] font-bold text-emerald-400">(+{game.rewardPerMin} Coins)</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-amber-300 font-black flex items-center gap-1">
              <span>🪙 Session Won:</span>
              <span>+{totalCoinsEarnedThisSession}</span>
            </div>
            <div className="text-white font-bold flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Score: {score}</span>
            </div>
          </div>
        </div>

        {/* Main Canvas Container */}
        <div className="relative flex-1 bg-slate-950 flex items-center justify-center overflow-hidden p-2 min-h-[340px]">
          <canvas
            ref={canvasRef}
            width={380}
            height={460}
            className="w-full max-w-[380px] h-auto max-h-[460px] bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 touch-none"
          />

          {/* Quick HUD controls overlay */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button
              onClick={() => setIsPaused(p => !p)}
              className="p-2.5 rounded-2xl bg-black/60 hover:bg-black/90 backdrop-blur-md text-white border border-white/20 shadow-lg cursor-pointer transition-all"
            >
              {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
            </button>
            <button
              onClick={resetGameState}
              className="p-2.5 rounded-2xl bg-black/60 hover:bg-black/90 backdrop-blur-md text-white border border-white/20 shadow-lg cursor-pointer transition-all"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile On-Screen Virtual Controls */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 shrink-0">
          <div className="max-w-md mx-auto flex items-center justify-between gap-3">
            {/* Left / Right Buttons */}
            <div className="flex items-center gap-2">
              <button
                onTouchStart={(e) => { e.preventDefault(); triggerMobileAction('left'); }}
                onClick={() => triggerMobileAction('left')}
                className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-xl flex items-center justify-center border border-slate-700 shadow-md active:scale-95 cursor-pointer select-none"
              >
                ◀
              </button>
              <button
                onTouchStart={(e) => { e.preventDefault(); triggerMobileAction('right'); }}
                onClick={() => triggerMobileAction('right')}
                className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-xl flex items-center justify-center border border-slate-700 shadow-md active:scale-95 cursor-pointer select-none"
              >
                ▶
              </button>
            </div>

            {/* Fire / Jump Action Button */}
            <button
              onTouchStart={(e) => { e.preventDefault(); triggerMobileAction('action'); }}
              onClick={() => triggerMobileAction('action')}
              className="flex-1 max-w-[200px] h-12 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 active:from-emerald-700 active:to-teal-600 text-white font-black text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/30 active:scale-95 cursor-pointer select-none"
            >
              <span>⚡</span>
              <span>{game.arcadeType === 'flappy_bird' ? 'FLAP / JUMP' : 'FIRE / ACTION'}</span>
            </button>
          </div>

          <p className="text-center text-[10px] text-slate-400 mt-2">
            💡 {language === 'bn' ? 'কীবোর্ডের Left/Right/Space কী অথবা স্ক্রিনের বাটন ব্যবহার করুন।' : 'Use Keyboard Arrow Keys & Space or On-Screen Touch Buttons.'}
          </p>
        </div>
      </div>
    </div>
  );
};
