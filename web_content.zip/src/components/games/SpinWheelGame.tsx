import React, { useState, useRef } from 'react';
import { Sparkles, Trophy, RotateCw, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface SpinWheelGameProps {
  onRewardWon: (coins: number, gameName: string) => void;
  onClose: () => void;
}

const SEGMENTS = [
  { label: '₹10', value: 10, color: '#10B981' },
  { label: '₹25', value: 25, color: '#3B82F6' },
  { label: '₹50', value: 50, color: '#8B5CF6' },
  { label: '₹100', value: 100, color: '#EC4899' },
  { label: '₹200', value: 200, color: '#F59E0B' },
  { label: '₹500', value: 500, color: '#EF4444' },
  { label: '₹15', value: 15, color: '#06B6D4' },
  { label: '₹30', value: 30, color: '#6366F1' },
];

export const SpinWheelGame: React.FC<SpinWheelGameProps> = ({ onRewardWon, onClose }) => {
  const { language } = useApp();
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<number | null>(null);

  const spinWheel = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setWonPrize(null);

    // Pick random segment
    const selectedIdx = Math.floor(Math.random() * SEGMENTS.length);
    const segmentAngle = 360 / SEGMENTS.length;
    // Calculate final angle to land on selected segment (with extra 5-7 rotations)
    const extraSpins = (5 + Math.floor(Math.random() * 3)) * 360;
    // Align with indicator at top (270 deg)
    const targetAngle = extraSpins + (360 - (selectedIdx * segmentAngle + segmentAngle / 2));

    setRotation(targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const prize = SEGMENTS[selectedIdx].value;
      setWonPrize(prize);
      confetti({ particleCount: 90, spread: 70 });
      onRewardWon(prize, 'Lucky Spin Wheel');
    }, 4000);
  };

  return (
    <div className="space-y-5 text-center">
      {/* Title */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white shadow-md flex items-center justify-between">
        <div className="flex items-center gap-2.5 text-left">
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-xl">
            🎡
          </div>
          <div>
            <h3 className="font-black text-sm sm:text-base tracking-tight">
              {language === 'bn' ? 'লাকি স্পিন হুইল (Spin & Win)' : 'Lucky Spin Wheel (Spin & Earn)'}
            </h3>
            <p className="text-[11px] text-white/90">
              {language === 'bn' ? 'চাকা ঘুরিয়ে সর্বোচ্চ ৫০০ কয়েন (₹৫০০) জিতুন' : 'Spin the wheel to win up to ₹500 instant cash!'}
            </p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white text-orange-600 shadow-xs">
          Daily Lucky Spin
        </span>
      </div>

      {/* Wheel Container */}
      <div className="relative w-64 h-64 mx-auto flex items-center justify-center my-3">
        {/* Pointer indicator */}
        <div className="absolute top-0 z-20 w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[24px] border-t-amber-400 drop-shadow-md -mt-2" />

        {/* Wheel Disk */}
        <div
          className="w-full h-full rounded-full border-4 border-amber-300 dark:border-amber-500 shadow-2xl relative overflow-hidden transition-transform duration-[4000ms] cubic-bezier(0.15, 0.9, 0.25, 1)"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          {SEGMENTS.map((seg, idx) => {
            const angle = (360 / SEGMENTS.length) * idx;
            return (
              <div
                key={idx}
                className="absolute w-1/2 h-1/2 top-0 right-0 origin-bottom-left flex items-center justify-center"
                style={{
                  transform: `rotate(${angle}deg)`,
                  backgroundColor: seg.color,
                  clipPath: 'polygon(0 0, 100% 0, 0 100%)',
                }}
              >
                <span 
                  className="font-black text-white text-xs tracking-wider absolute drop-shadow-sm select-none"
                  style={{
                    transform: 'rotate(45deg) translate(36px, -18px)',
                  }}
                >
                  {seg.label}
                </span>
              </div>
            );
          })}

          {/* Center Hub */}
          <div className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-slate-900 border-2 border-amber-400 shadow-md flex items-center justify-center z-10">
            <span className="text-amber-400 font-black text-xs">SPIN</span>
          </div>
        </div>
      </div>

      {/* Prize Won Message */}
      {wonPrize !== null && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 animate-in zoom-in-95 duration-200">
          <p className="text-xs uppercase font-bold tracking-wider">Congratulations!</p>
          <p className="text-xl font-black text-emerald-600 dark:text-emerald-400">
            You Won 🪙 +{wonPrize} Coins (₹{wonPrize} INR)
          </p>
        </div>
      )}

      {/* Spin Button */}
      <div className="flex justify-center gap-3 pt-2">
        <button
          onClick={spinWheel}
          disabled={isSpinning}
          className="px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-sm shadow-lg shadow-orange-500/25 active:scale-95 disabled:opacity-50 cursor-pointer flex items-center gap-2"
        >
          <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
          <span>{isSpinning ? 'Spinning...' : 'SPIN WHEEL NOW'}</span>
        </button>

        <button
          onClick={onClose}
          className="px-5 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold cursor-pointer"
        >
          Close
        </button>
      </div>
    </div>
  );
};
