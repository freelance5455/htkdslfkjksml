import React, { useState, useEffect, useRef } from 'react';
import { X, RefreshCw, Trophy, Clock, Check, Sparkles, Flame, Target, ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface MiniGamesModalProps {
  gameId: string;
  isOpen: boolean;
  onClose: () => void;
  onRewardWon: (coins: number, gameName: string) => void;
}

export const MiniGamesModal: React.FC<MiniGamesModalProps> = ({
  gameId,
  isOpen,
  onClose,
  onRewardWon,
}) => {
  const { language } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto"
        role="dialog"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer z-20"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Existing Mini Games */}
        {gameId === 'math_speed' && (
          <MathSpeedChallenge onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'memory_cards' && (
          <MemoryCardsGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'color_reflex' && (
          <ColorReflexGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'coin_tap' && (
          <CoinTapGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'dice_7' && (
          <Dice7Game onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'number_guess' && (
          <NumberGuessGame onRewardWon={onRewardWon} onClose={onClose} />
        )}

        {/* New Rich Interactive Mini Games */}
        {gameId === 'flappy_coin' && (
          <FlappyCoinGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'knife_hit' && (
          <KnifeHitGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'retro_snake' && (
          <RetroSnakeGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'tic_tac_toe' && (
          <TicTacToeGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'rock_paper_scissors' && (
          <RockPaperScissorsGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'cricket_sixer' && (
          <CricketSixerGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'tower_stack' && (
          <TowerStackGame onRewardWon={onRewardWon} onClose={onClose} />
        )}

        {/* PRO HARD MODE GAMES */}
        {gameId === 'impossible_laser' && (
          <ImpossibleLaserMazeGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'bullet_hell' && (
          <BulletHellStormGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'bomb_defusal' && (
          <BombDefusalGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'hard_math' && (
          <HardcoreMathBlitzGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'extreme_knife' && (
          <ExtremeKnifeHitGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
        {gameId === 'flappy_insane' && (
          <FlappyInsaneStormGame onRewardWon={onRewardWon} onClose={onClose} />
        )}
      </div>
    </div>
  );
};

/* 1. Math Speed Challenge */
const MathSpeedChallenge: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const [num1, setNum1] = useState(12);
  const [num2, setNum2] = useState(15);
  const [userAns, setUserAns] = useState('');
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [isOver, setIsOver] = useState(false);

  useEffect(() => {
    if (isOver) return;
    if (timeLeft <= 0) {
      setIsOver(true);
      const coins = Math.min(60, score * 10 + 20);
      if (score > 0) {
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(coins, 'Math Speed Challenge');
      }
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, isOver, score, onRewardWon]);

  const generateProblem = () => {
    setNum1(Math.floor(Math.random() * 30) + 5);
    setNum2(Math.floor(Math.random() * 25) + 3);
    setUserAns('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parseInt(userAns) === num1 + num2) {
      setScore(prev => prev + 1);
      generateProblem();
    } else {
      setUserAns('');
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">⚡ Math Speed Rush</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">⏱️ {timeLeft}s Left</span>
      </div>

      {!isOver ? (
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <p className="text-3xl font-black text-slate-900 dark:text-slate-100">
            {num1} + {num2} = ?
          </p>
          <input
            type="number"
            autoFocus
            value={userAns}
            onChange={(e) => setUserAns(e.target.value)}
            placeholder="Type answer & press Enter"
            className="w-48 mx-auto px-4 py-3 text-center text-xl font-black rounded-2xl border-2 border-blue-500 focus:outline-hidden"
          />
          <p className="text-xs text-slate-400">Score: {score} correct</p>
        </form>
      ) : (
        <div className="space-y-3 py-4">
          <h4 className="text-lg font-black text-emerald-600">Time's Up! You scored {score}</h4>
          <p className="text-xs text-slate-500">Won 🪙 +{Math.min(60, score * 10 + 20)} Coins (₹{Math.min(60, score * 10 + 20)})</p>
          <button onClick={onClose} className="px-5 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs cursor-pointer">Close</button>
        </div>
      )}
    </div>
  );
};

/* 2. Memory Card Match */
const MemoryCardsGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const icons = ['🪙', '💎', '👑', '🎁', '🚀', '⭐'];
  const [cards] = useState(() => [...icons, ...icons].sort(() => Math.random() - 0.5));
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);

  const handleCardClick = (idx: number) => {
    if (flipped.length === 2 || flipped.includes(idx) || matched.includes(idx)) return;
    const newFlipped = [...flipped, idx];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      const [first, second] = newFlipped;
      if (cards[first] === cards[second]) {
        const nextMatched = [...matched, first, second];
        setMatched(nextMatched);
        setFlipped([]);
        if (nextMatched.length === cards.length) {
          confetti({ particleCount: 80, spread: 60 });
          onRewardWon(50, 'Memory Card Match');
        }
      } else {
        setTimeout(() => setFlipped([]), 800);
      }
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🃏 Memory Card Match</span>
        <span className="text-xs font-bold text-amber-200">Prize: ₹50</span>
      </div>

      <div className="grid grid-cols-4 gap-2.5 py-2">
        {cards.map((icon, idx) => {
          const isRevealed = flipped.includes(idx) || matched.includes(idx);
          return (
            <button
              key={idx}
              onClick={() => handleCardClick(idx)}
              className={`h-16 rounded-2xl text-2xl font-bold flex items-center justify-center border-2 transition-all cursor-pointer ${
                isRevealed
                  ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-400'
                  : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 hover:scale-105'
              }`}
            >
              {isRevealed ? icon : '❓'}
            </button>
          );
        })}
      </div>

      {matched.length === cards.length && (
        <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold text-xs">
          All pairs matched! 🪙 +50 Coins (₹50) Added!
        </div>
      )}
    </div>
  );
};

/* 3. Color Reflex Rush */
const ColorReflexGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const colors = [
    { name: 'RED', hex: '#EF4444' },
    { name: 'BLUE', hex: '#3B82F6' },
    { name: 'GREEN', hex: '#10B981' },
    { name: 'YELLOW', hex: '#F59E0B' },
  ];
  const [targetColor, setTargetColor] = useState(colors[0]);
  const [streak, setStreak] = useState(0);

  const nextColor = () => {
    const random = colors[Math.floor(Math.random() * colors.length)];
    setTargetColor(random);
  };

  const handlePick = (col: typeof colors[0]) => {
    if (col.name === targetColor.name) {
      const nextStreak = streak + 1;
      setStreak(nextStreak);
      if (nextStreak >= 5) {
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(35, 'Color Reflex Rush');
      }
      nextColor();
    } else {
      setStreak(0);
      nextColor();
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🎯 Color Reflex Rush</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">Streak: {streak}/5</span>
      </div>

      <div className="py-4 space-y-3">
        <p className="text-xs font-semibold text-slate-500">Tap the color button matching:</p>
        <div 
          className="text-3xl font-black tracking-wider py-2 select-none"
          style={{ color: targetColor.hex }}
        >
          {targetColor.name}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {colors.map((c) => (
          <button
            key={c.name}
            onClick={() => handlePick(c)}
            style={{ backgroundColor: c.hex }}
            className="py-3 rounded-2xl text-white font-bold text-xs shadow-md active:scale-95 cursor-pointer"
          >
            {c.name}
          </button>
        ))}
      </div>
    </div>
  );
};

/* 4. Coin Tap Frenzy */
const CoinTapGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [coinPos, setCoinPos] = useState({ top: 40, left: 50 });

  useEffect(() => {
    if (timeLeft <= 0) {
      if (score >= 10) {
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(45, 'Coin Tap Frenzy');
      }
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, score, onRewardWon]);

  const handleTap = () => {
    setScore(prev => prev + 1);
    setCoinPos({
      top: Math.floor(Math.random() * 70) + 15,
      left: Math.floor(Math.random() * 75) + 10,
    });
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">💰 Coin Tap Frenzy</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">⏱️ {timeLeft}s • Taps: {score}</span>
      </div>

      <div className="relative h-56 rounded-3xl bg-slate-100 dark:bg-slate-800 border overflow-hidden select-none">
        {timeLeft > 0 ? (
          <button
            onClick={handleTap}
            style={{ top: `${coinPos.top}%`, left: `${coinPos.left}%` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-amber-950 text-2xl font-black flex items-center justify-center shadow-lg active:scale-90 transition-all cursor-pointer"
          >
            🪙
          </button>
        ) : (
          <div className="h-full flex flex-col items-center justify-center space-y-2">
            <h4 className="text-lg font-black text-emerald-600">Finished! Tapped {score} coins</h4>
            <p className="text-xs text-slate-500">Won 🪙 +45 Coins (₹45)</p>
          </div>
        )}
      </div>
    </div>
  );
};

/* 5. Dice 7 Up 7 Down */
const Dice7Game: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const [d1, setD1] = useState(3);
  const [d2, setD2] = useState(4);
  const [resultMsg, setResultMsg] = useState('');

  const roll = (userGuess: 'down' | 'exact' | 'up') => {
    const r1 = Math.floor(Math.random() * 6) + 1;
    const r2 = Math.floor(Math.random() * 6) + 1;
    setD1(r1);
    setD2(r2);
    const sum = r1 + r2;

    const won = (userGuess === 'down' && sum < 7) ||
                (userGuess === 'exact' && sum === 7) ||
                (userGuess === 'up' && sum > 7);

    if (won) {
      setResultMsg(`Sum is ${sum}! You Won 🪙 +60 Coins (₹60)!`);
      confetti({ particleCount: 70, spread: 60 });
      onRewardWon(60, 'Dice 7 Up 7 Down');
    } else {
      setResultMsg(`Sum is ${sum}! Try again.`);
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🎲 Dice 7 Up 7 Down</span>
        <span className="text-xs font-bold text-amber-200">Prize: ₹60</span>
      </div>

      <div className="flex justify-center gap-4 py-4 text-4xl">
        <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center font-black border border-amber-400">
          {d1}
        </div>
        <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center font-black border border-amber-400">
          {d2}
        </div>
      </div>

      {resultMsg && (
        <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200">
          {resultMsg}
        </div>
      )}

      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => roll('down')}
          className="p-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer"
        >
          7 Down (2-6)
        </button>
        <button
          onClick={() => roll('exact')}
          className="p-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs cursor-pointer"
        >
          Lucky 7
        </button>
        <button
          onClick={() => roll('up')}
          className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer"
        >
          7 Up (8-12)
        </button>
      </div>
    </div>
  );
};

/* 6. Number Mystery Guess */
const NumberGuessGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon, onClose }) => {
  const [secret] = useState(() => Math.floor(Math.random() * 50) + 1);
  const [guessInput, setGuessInput] = useState('');
  const [attempts, setAttempts] = useState(5);
  const [feedback, setFeedback] = useState('Guess a number between 1 and 50');
  const [won, setWon] = useState(false);

  const handleGuess = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(guessInput);
    if (isNaN(val)) return;

    if (val === secret) {
      setWon(true);
      setFeedback(`Correct! The number was ${secret}. You won 🪙 +55 Coins (₹55)!`);
      confetti({ particleCount: 70, spread: 60 });
      onRewardWon(55, 'Number Mystery Guess');
    } else {
      const left = attempts - 1;
      setAttempts(left);
      if (left <= 0) {
        setFeedback(`Game Over! The number was ${secret}.`);
      } else {
        setFeedback(val < secret ? 'Too Low! Guess higher ⬆️' : 'Too High! Guess lower ⬇️');
      }
    }
    setGuessInput('');
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🔢 Number Mystery Guess</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{attempts} Tries Left</span>
      </div>

      <div className="py-2 space-y-2">
        <p className="text-sm font-bold text-slate-800 dark:text-slate-200">{feedback}</p>
        {!won && attempts > 0 && (
          <form onSubmit={handleGuess} className="flex gap-2 justify-center pt-2">
            <input
              type="number"
              min={1}
              max={50}
              value={guessInput}
              onChange={(e) => setGuessInput(e.target.value)}
              placeholder="1 - 50"
              className="w-24 px-3 py-2 text-center rounded-xl border border-slate-300 dark:border-slate-700 font-bold"
            />
            <button type="submit" className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs cursor-pointer">
              Guess
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

/* 7. NEW: Flappy Coin Rush */
const FlappyCoinGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const birdYRef = useRef(150);
  const birdVelRef = useRef(0);
  const pipesRef = useRef<Array<{ x: number; top: number; bottom: number; passed: boolean }>>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const flap = () => {
    if (!hasStarted) {
      setHasStarted(true);
      setIsGameOver(false);
      birdYRef.current = 150;
      birdVelRef.current = -5.5;
      pipesRef.current = [{ x: 300, top: 80, bottom: 120, passed: false }];
      setScore(0);
      return;
    }
    if (isGameOver) {
      setHasStarted(false);
      setIsGameOver(false);
      birdYRef.current = 150;
      birdVelRef.current = 0;
      pipesRef.current = [];
      setScore(0);
      return;
    }
    birdVelRef.current = -5.8;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = () => {
      ctx.clearRect(0, 0, 320, 320);

      // Sky background
      const grad = ctx.createLinearGradient(0, 0, 0, 320);
      grad.addColorStop(0, '#0284c7');
      grad.addColorStop(1, '#bae6fd');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 320, 320);

      // Ground
      ctx.fillStyle = '#15803d';
      ctx.fillRect(0, 290, 320, 30);

      if (hasStarted && !isGameOver) {
        birdVelRef.current += 0.28; // gravity
        birdYRef.current += birdVelRef.current;

        // Spawn pipes
        if (pipesRef.current.length === 0 || pipesRef.current[pipesRef.current.length - 1].x < 170) {
          const topH = Math.floor(Math.random() * 110) + 40;
          pipesRef.current.push({ x: 320, top: topH, bottom: 290 - topH - 85, passed: false });
        }

        // Move pipes
        pipesRef.current.forEach(p => {
          p.x -= 2;
          if (!p.passed && p.x < 70) {
            p.passed = true;
            setScore(s => {
              const ns = s + 1;
              if (ns >= 5) {
                confetti({ particleCount: 50, spread: 50 });
                onRewardWon(Math.min(70, ns * 10), 'Flappy Coin Rush');
              }
              return ns;
            });
          }
        });

        // Collision check
        if (birdYRef.current > 275 || birdYRef.current < 5) {
          setIsGameOver(true);
        }
        pipesRef.current.forEach(p => {
          if (p.x < 90 && p.x + 35 > 60) {
            if (birdYRef.current < p.top || birdYRef.current + 20 > 290 - p.bottom) {
              setIsGameOver(true);
            }
          }
        });
        pipesRef.current = pipesRef.current.filter(p => p.x > -50);
      }

      // Draw pipes
      ctx.fillStyle = '#16a34a';
      pipesRef.current.forEach(p => {
        ctx.fillRect(p.x, 0, 35, p.top);
        ctx.fillRect(p.x, 290 - p.bottom, 35, p.bottom);
      });

      // Draw Bird Coin
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(75, birdYRef.current + 10, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#78350f';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🪙', 75, birdYRef.current + 14);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [hasStarted, isGameOver, onRewardWon]);

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🐦 Flappy Coin Rush</span>
        <span className="text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-bold">Score: {score}</span>
      </div>

      <div className="relative mx-auto w-[320px] h-[320px] rounded-3xl overflow-hidden border border-slate-300 dark:border-slate-700 shadow-md">
        <canvas ref={canvasRef} width={320} height={320} onClick={flap} className="cursor-pointer" />
        {!hasStarted && (
          <div onClick={flap} className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white cursor-pointer p-4">
            <span className="text-3xl mb-1">🪙</span>
            <p className="font-black text-sm">TAP TO START & JUMP</p>
            <p className="text-[11px] text-amber-300 mt-1">Fly between green pipes to earn coins!</p>
          </div>
        )}
        {isGameOver && (
          <div onClick={flap} className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white cursor-pointer p-4">
            <p className="font-black text-lg text-rose-400">CRASHED!</p>
            <p className="text-xs text-slate-200 mt-1">Score: {score} • Tap to Play Again</p>
          </div>
        )}
      </div>

      <button onClick={flap} className="w-full py-3 rounded-2xl bg-emerald-600 text-white font-black text-sm active:scale-95 transition-all cursor-pointer">
        👆 TAP TO FLAP
      </button>
    </div>
  );
};

/* 8. NEW: Knife Hit Master */
const KnifeHitGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [knivesInLog, setKnivesInLog] = useState<number[]>([0, 1.8]);
  const [knivesLeft, setKnivesLeft] = useState(7);
  const [score, setScore] = useState(0);
  const [logAngle, setLogAngle] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isWin, setIsWin] = useState(false);

  useEffect(() => {
    if (isGameOver || isWin) return;
    const interval = setInterval(() => {
      setLogAngle(a => (a + 0.05) % (Math.PI * 2));
    }, 20);
    return () => clearInterval(interval);
  }, [isGameOver, isWin]);

  const throwKnife = () => {
    if (isGameOver || isWin || knivesLeft <= 0) return;

    // Knife hits bottom of log at angle (Math.PI / 2 - logAngle)
    const hitAngle = ((Math.PI / 2) - logAngle + Math.PI * 2) % (Math.PI * 2);

    // Check collision with existing knives (tolerance: ~0.25 radians)
    const hitsOther = knivesInLog.some(a => {
      const diff = Math.abs(a - hitAngle);
      return diff < 0.28 || Math.abs(diff - Math.PI * 2) < 0.28;
    });

    if (hitsOther) {
      setIsGameOver(true);
    } else {
      const nextKnives = [...knivesInLog, hitAngle];
      setKnivesInLog(nextKnives);
      const nextLeft = knivesLeft - 1;
      setKnivesLeft(nextLeft);
      const nextScore = score + 1;
      setScore(nextScore);

      if (nextLeft <= 0) {
        setIsWin(true);
        confetti({ particleCount: 75, spread: 60 });
        onRewardWon(80, 'Knife Hit Master');
      }
    }
  };

  const restart = () => {
    setKnivesInLog([0, 1.8]);
    setKnivesLeft(7);
    setScore(0);
    setIsGameOver(false);
    setIsWin(false);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-600 to-rose-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🗡️ Knife Hit Master</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold">Knives Left: {knivesLeft}</span>
      </div>

      <div className="relative h-64 bg-slate-900 rounded-3xl border border-slate-800 flex items-center justify-center overflow-hidden">
        {/* Rotating Wooden Log */}
        <div 
          className="w-28 h-28 rounded-full bg-amber-800 border-4 border-amber-600 flex items-center justify-center relative shadow-2xl transition-transform"
          style={{ transform: `rotate(${logAngle}rad)` }}
        >
          <span className="text-2xl select-none">🎯</span>
          {knivesInLog.map((angle, i) => (
            <div
              key={i}
              className="absolute w-2 h-10 bg-slate-200 border border-slate-400 origin-bottom"
              style={{
                top: '-40px',
                left: 'calc(50% - 4px)',
                transformOrigin: '50% 96px',
                transform: `rotate(${angle}rad)`,
              }}
            />
          ))}
        </div>

        {/* Ready Knife at bottom */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-2xl select-none animate-bounce">
          🗡️
        </div>

        {/* Game State Overlay */}
        {(isGameOver || isWin) && (
          <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center space-y-2 p-4 text-white">
            <h4 className={`text-lg font-black ${isWin ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isWin ? '🏆 STAGE CLEARED!' : '💥 KNIFE DEFLECTED!'}
            </h4>
            <p className="text-xs text-slate-300">
              {isWin ? 'Earned 🪙 +80 Coins (₹80)!' : `Score: ${score} knives placed`}
            </p>
            <button onClick={restart} className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs cursor-pointer">
              Try Again
            </button>
          </div>
        )}
      </div>

      <button
        onClick={throwKnife}
        disabled={isGameOver || isWin}
        className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-amber-600 text-white font-black text-sm active:scale-95 transition-all cursor-pointer shadow-lg disabled:opacity-50"
      >
        🎯 THROW KNIFE
      </button>
    </div>
  );
};

/* 9. NEW: Retro Snake 97 */
const RetroSnakeGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [snake, setSnake] = useState<Array<{ x: number; y: number }>>([
    { x: 7, y: 7 },
    { x: 6, y: 7 },
  ]);
  const [food, setFood] = useState<{ x: number; y: number }>({ x: 12, y: 7 });
  const [dir, setDir] = useState<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('RIGHT');
  const [score, setScore] = useState(0);
  const [isOver, setIsOver] = useState(false);

  useEffect(() => {
    if (isOver) return;

    const moveSnake = () => {
      setSnake(prev => {
        const head = { ...prev[0] };
        if (dir === 'UP') head.y -= 1;
        if (dir === 'DOWN') head.y += 1;
        if (dir === 'LEFT') head.x -= 1;
        if (dir === 'RIGHT') head.x += 1;

        // Collision wall
        if (head.x < 0 || head.x >= 15 || head.y < 0 || head.y >= 15) {
          setIsOver(true);
          return prev;
        }

        // Collision self
        if (prev.some(seg => seg.x === head.x && seg.y === head.y)) {
          setIsOver(true);
          return prev;
        }

        const newSnake = [head, ...prev];

        // Eat food
        if (head.x === food.x && head.y === food.y) {
          setScore(s => {
            const ns = s + 1;
            if (ns >= 5) {
              confetti({ particleCount: 50, spread: 50 });
              onRewardWon(Math.min(75, ns * 15), 'Retro Snake 97');
            }
            return ns;
          });
          setFood({
            x: Math.floor(Math.random() * 14),
            y: Math.floor(Math.random() * 14),
          });
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    };

    const interval = setInterval(moveSnake, 220);
    return () => clearInterval(interval);
  }, [dir, food, isOver, onRewardWon]);

  const restart = () => {
    setSnake([{ x: 7, y: 7 }, { x: 6, y: 7 }]);
    setFood({ x: 12, y: 7 });
    setDir('RIGHT');
    setScore(0);
    setIsOver(false);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-green-700 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🐍 Retro Snake 97</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold">Apples: {score}</span>
      </div>

      <div className="relative mx-auto w-[240px] h-[240px] bg-emerald-950 border-4 border-emerald-800 rounded-2xl overflow-hidden p-1 shadow-inner">
        <div className="grid grid-cols-15 grid-rows-15 w-full h-full gap-0.5">
          {Array.from({ length: 225 }).map((_, idx) => {
            const x = idx % 15;
            const y = Math.floor(idx / 15);
            const isHead = snake[0].x === x && snake[0].y === y;
            const isBody = snake.slice(1).some(s => s.x === x && s.y === y);
            const isApple = food.x === x && food.y === y;

            return (
              <div
                key={idx}
                className={`w-full h-full rounded-xs ${
                  isHead
                    ? 'bg-amber-400'
                    : isBody
                    ? 'bg-emerald-400'
                    : isApple
                    ? 'bg-rose-500 animate-pulse'
                    : 'bg-emerald-900/30'
                }`}
              />
            );
          })}
        </div>

        {isOver && (
          <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-3 text-white space-y-2">
            <h5 className="font-black text-rose-400">GAME OVER!</h5>
            <p className="text-xs">Score: {score} apples</p>
            <button onClick={restart} className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs cursor-pointer">
              Restart
            </button>
          </div>
        )}
      </div>

      {/* D-Pad Controls */}
      <div className="flex flex-col items-center gap-1">
        <button
          onClick={() => { if (dir !== 'DOWN') setDir('UP'); }}
          className="w-12 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center active:scale-95 cursor-pointer"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => { if (dir !== 'RIGHT') setDir('LEFT'); }}
            className="w-12 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center active:scale-95 cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => { if (dir !== 'UP') setDir('DOWN'); }}
            className="w-12 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center active:scale-95 cursor-pointer"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
          <button
            onClick={() => { if (dir !== 'LEFT') setDir('RIGHT'); }}
            className="w-12 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center active:scale-95 cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

/* 10. NEW: Tic-Tac-Toe Smart AI */
const TicTacToeGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [board, setBoard] = useState<Array<string | null>>(Array(9).fill(null));
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  const checkWinner = (squares: Array<string | null>) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (const [a, b, c] of lines) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    if (squares.every(Boolean)) return 'Tie';
    return null;
  };

  const handleCellClick = (idx: number) => {
    if (board[idx] || winner || !isPlayerTurn) return;

    const newBoard = [...board];
    newBoard[idx] = 'X';
    setBoard(newBoard);

    const win = checkWinner(newBoard);
    if (win) {
      setWinner(win);
      if (win === 'X') {
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(50, 'Tic-Tac-Toe AI');
      }
      return;
    }

    setIsPlayerTurn(false);

    // AI move
    setTimeout(() => {
      const emptyIdxs = newBoard.map((val, i) => (val === null ? i : null)).filter(i => i !== null) as number[];
      if (emptyIdxs.length > 0) {
        const aiPick = emptyIdxs[Math.floor(Math.random() * emptyIdxs.length)];
        newBoard[aiPick] = 'O';
        setBoard(newBoard);
        const aiWin = checkWinner(newBoard);
        if (aiWin) setWinner(aiWin);
      }
      setIsPlayerTurn(true);
    }, 400);
  };

  const reset = () => {
    setBoard(Array(9).fill(null));
    setIsPlayerTurn(true);
    setWinner(null);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">❌⭕ Tic-Tac-Toe AI Challenge</span>
        <span className="text-xs font-bold text-amber-200">Prize: ₹50</span>
      </div>

      <p className="text-xs text-slate-400">You are <span className="font-bold text-indigo-400">X</span>, AI is <span className="font-bold text-rose-400">O</span></p>

      <div className="grid grid-cols-3 gap-2.5 max-w-[240px] mx-auto py-2">
        {board.map((cell, idx) => (
          <button
            key={idx}
            onClick={() => handleCellClick(idx)}
            className="w-18 h-18 rounded-2xl bg-slate-100 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-700 text-3xl font-black flex items-center justify-center cursor-pointer transition-transform active:scale-95"
          >
            <span className={cell === 'X' ? 'text-indigo-600 dark:text-indigo-400' : 'text-rose-500'}>
              {cell}
            </span>
          </button>
        ))}
      </div>

      {winner && (
        <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 space-y-2">
          <p className="text-sm font-black text-slate-800 dark:text-slate-100">
            {winner === 'X' ? '🎉 YOU DEFEATED THE AI! (+50 Coins)' : winner === 'Tie' ? '🤝 MATCH TIED!' : '🤖 AI WON THIS ROUND!'}
          </p>
          <button onClick={reset} className="px-4 py-2 rounded-xl bg-violet-600 text-white font-bold text-xs cursor-pointer">
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};

/* 11. NEW: Rock Paper Scissors Duel */
const RockPaperScissorsGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const choices = [
    { name: 'Rock', icon: '🪨' },
    { name: 'Paper', icon: '📄' },
    { name: 'Scissors', icon: '✂️' },
  ];
  const [userPick, setUserPick] = useState<string | null>(null);
  const [botPick, setBotPick] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [score, setScore] = useState(0);

  const play = (choice: string) => {
    const botChoice = choices[Math.floor(Math.random() * choices.length)].name;
    setUserPick(choice);
    setBotPick(botChoice);

    if (choice === botChoice) {
      setResult('Tie! Draw');
    } else if (
      (choice === 'Rock' && botChoice === 'Scissors') ||
      (choice === 'Paper' && botChoice === 'Rock') ||
      (choice === 'Scissors' && botChoice === 'Paper')
    ) {
      setResult('You Won!');
      const nextScore = score + 1;
      setScore(nextScore);
      if (nextScore >= 3) {
        confetti({ particleCount: 65, spread: 55 });
        onRewardWon(45, 'Rock Paper Scissors');
      }
    } else {
      setResult('Bot Won!');
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-orange-600 to-amber-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">✂️ Rock Paper Scissors</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold">Wins: {score}/3</span>
      </div>

      <div className="py-4 flex justify-around items-center">
        <div className="space-y-1">
          <p className="text-[10px] text-slate-400 uppercase font-bold">You</p>
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-3xl flex items-center justify-center border">
            {userPick ? choices.find(c => c.name === userPick)?.icon : '❔'}
          </div>
        </div>
        <span className="text-xl font-black text-amber-500">VS</span>
        <div className="space-y-1">
          <p className="text-[10px] text-slate-400 uppercase font-bold">Bot</p>
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-3xl flex items-center justify-center border">
            {botPick ? choices.find(c => c.name === botPick)?.icon : '🤖'}
          </div>
        </div>
      </div>

      {result && <p className="text-sm font-black text-amber-500">{result}</p>}

      <div className="grid grid-cols-3 gap-2">
        {choices.map(c => (
          <button
            key={c.name}
            onClick={() => play(c.name)}
            className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:scale-105 active:scale-95 transition-all cursor-pointer space-y-1"
          >
            <div className="text-2xl">{c.icon}</div>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{c.name}</p>
          </button>
        ))}
      </div>
    </div>
  );
};

/* 12. NEW: Cricket Sixer Super Over */
const CricketSixerGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [ballsLeft, setBallsLeft] = useState(6);
  const [runs, setRuns] = useState(0);
  const [shotResult, setShotResult] = useState<string | null>(null);
  const [ballPosition, setBallPosition] = useState(0); // 0 to 100%
  const [isBowling, setIsBowling] = useState(false);

  const bowl = () => {
    if (ballsLeft <= 0 || isBowling) return;
    setIsBowling(true);
    setShotResult(null);
    setBallPosition(0);

    const start = Date.now();
    const duration = 1200;

    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const progress = Math.min(100, (elapsed / duration) * 100);
      setBallPosition(progress);

      if (progress >= 100) {
        clearInterval(interval);
        setIsBowling(false);
        setShotResult('Dot Ball! Missed timing.');
        setBallsLeft(b => b - 1);
      }
    }, 20);
  };

  const hitShot = () => {
    if (!isBowling) return;
    setIsBowling(false);

    // Sweet spot is between 68% and 84%
    if (ballPosition >= 72 && ballPosition <= 80) {
      setShotResult('🔥 MASSIVE 6 RUNS! Out of the stadium!');
      setRuns(r => r + 6);
    } else if (ballPosition >= 60 && ballPosition <= 88) {
      setShotResult('🏏 FOUR RUNS! Pierced the boundary!');
      setRuns(r => r + 4);
    } else {
      setShotResult('Wicket! Edge caught.');
    }

    const nextBalls = ballsLeft - 1;
    setBallsLeft(nextBalls);

    if (nextBalls <= 0) {
      confetti({ particleCount: 70, spread: 60 });
      onRewardWon(90, 'Cricket Sixer Super Over');
    }
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-700 to-indigo-700 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🏏 Cricket Sixer Super Over</span>
        <span className="text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-bold">Runs: {runs} • Balls: {ballsLeft}</span>
      </div>

      {/* Pitch track */}
      <div className="relative h-28 bg-emerald-900/40 rounded-3xl border border-emerald-700 overflow-hidden flex items-center px-4">
        {/* Pitch crease */}
        <div className="w-full h-8 bg-amber-200/20 border-t border-b border-amber-400/40 relative">
          {/* Green sweet spot marker */}
          <div className="absolute top-0 bottom-0 left-[68%] w-[16%] bg-emerald-500/50 border-x-2 border-emerald-400" />
          {/* Ball */}
          <div
            className="absolute top-1/2 -translate-y-1/2 text-xl transition-all"
            style={{ left: `${ballPosition}%` }}
          >
            🔴
          </div>
          {/* Batsman */}
          <div className="absolute right-2 top-1/2 -translate-y-1/2 text-2xl">
            🏏
          </div>
        </div>
      </div>

      {shotResult && <p className="text-xs font-bold text-amber-400">{shotResult}</p>}

      <div className="flex gap-2">
        <button
          onClick={bowl}
          disabled={isBowling || ballsLeft <= 0}
          className="flex-1 py-3 rounded-2xl bg-indigo-600 disabled:opacity-50 text-white font-black text-xs cursor-pointer"
        >
          🎳 BOWL BALL
        </button>
        <button
          onClick={hitShot}
          disabled={!isBowling}
          className="flex-1 py-3 rounded-2xl bg-emerald-600 disabled:opacity-50 text-white font-black text-xs cursor-pointer"
        >
          💥 HIT SIX!
        </button>
      </div>
    </div>
  );
};

/* 13. NEW: Tower Stack Builder */
const TowerStackGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [stackHeight, setStackHeight] = useState(1);
  const [blockPos, setBlockPos] = useState(50);
  const [isMovingRight, setIsMovingRight] = useState(true);
  const [isOver, setIsOver] = useState(false);

  useEffect(() => {
    if (isOver) return;
    const interval = setInterval(() => {
      setBlockPos(p => {
        if (p >= 80) setIsMovingRight(false);
        if (p <= 20) setIsMovingRight(true);
        return isMovingRight ? p + 4 : p - 4;
      });
    }, 40);
    return () => clearInterval(interval);
  }, [isMovingRight, isOver]);

  const dropBlock = () => {
    if (isOver) return;

    // Check accuracy against center (50)
    const diff = Math.abs(blockPos - 50);
    if (diff < 18) {
      const nextH = stackHeight + 1;
      setStackHeight(nextH);
      if (nextH >= 8) {
        setIsOver(true);
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(70, 'Tower Stack Builder');
      }
    } else {
      setIsOver(true);
    }
  };

  const restart = () => {
    setStackHeight(1);
    setBlockPos(50);
    setIsOver(false);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white flex justify-between items-center">
        <span className="font-bold text-sm">🧱 Tower Stack 3D</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold">Floors: {stackHeight}</span>
      </div>

      <div className="relative h-60 bg-slate-900 rounded-3xl border border-slate-800 flex flex-col justify-end p-4 overflow-hidden">
        {/* Moving active block */}
        {!isOver && (
          <div
            className="absolute top-8 w-24 h-6 rounded-md bg-amber-400 border border-amber-200 shadow-md transition-all -translate-x-1/2"
            style={{ left: `${blockPos}%` }}
          />
        )}

        {/* Existing built stack */}
        <div className="flex flex-col-reverse items-center gap-1">
          {Array.from({ length: stackHeight }).map((_, i) => (
            <div
              key={i}
              className="w-24 h-5 rounded-md bg-gradient-to-r from-purple-500 to-fuchsia-500 border border-purple-300"
            />
          ))}
        </div>

        {isOver && (
          <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-3 text-white space-y-2">
            <h5 className="font-black text-rose-400">{stackHeight >= 8 ? '🎉 TOWER COMPLETED!' : 'MISALIGNED!'}</h5>
            <p className="text-xs">Floors Built: {stackHeight}</p>
            <button onClick={restart} className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs cursor-pointer">
              Try Again
            </button>
          </div>
        )}
      </div>

      <button
        onClick={dropBlock}
        disabled={isOver}
        className="w-full py-3 rounded-2xl bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white font-black text-sm active:scale-95 transition-all cursor-pointer"
      >
        👇 DROP BLOCK
      </button>
    </div>
  );
};

/* 14. HARD GAME: Impossible Laser Maze */
const ImpossibleLaserMazeGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [level, setLevel] = useState(1);
  const [playerPos, setPlayerPos] = useState({ x: 30, y: 30 });
  const [isHit, setIsHit] = useState(false);
  const [isCleared, setIsCleared] = useState(false);
  const [laserAngle, setLaserAngle] = useState(0);

  // Rotating lasers animation
  useEffect(() => {
    if (isCleared) return;
    const interval = setInterval(() => {
      setLaserAngle(a => (a + 0.08) % (Math.PI * 2));
    }, 30);
    return () => clearInterval(interval);
  }, [isCleared]);

  const movePlayer = (dx: number, dy: number) => {
    if (isHit || isCleared) return;
    setPlayerPos(prev => {
      const nx = Math.min(270, Math.max(30, prev.x + dx));
      const ny = Math.min(270, Math.max(30, prev.y + dy));

      // Laser center is (150, 150)
      const cx = 150;
      const cy = 150;
      const dist = Math.hypot(nx - cx, ny - cy);

      // Check collision with rotating beam
      if (dist > 15 && dist < 125) {
        const angleToPlayer = (Math.atan2(ny - cy, nx - cx) + Math.PI * 2) % (Math.PI * 2);
        const normLaser = (laserAngle + Math.PI * 2) % (Math.PI * 2);
        const diff1 = Math.abs(angleToPlayer - normLaser);
        const diff2 = Math.abs(angleToPlayer - ((normLaser + Math.PI) % (Math.PI * 2)));

        if (diff1 < 0.22 || diff2 < 0.22) {
          setIsHit(true);
          setTimeout(() => {
            setPlayerPos({ x: 30, y: 30 });
            setIsHit(false);
          }, 600);
          return prev;
        }
      }

      // Check reaching GOAL (260, 260)
      if (nx > 240 && ny > 240) {
        if (level < 3) {
          setLevel(l => l + 1);
          return { x: 30, y: 30 };
        } else {
          setIsCleared(true);
          confetti({ particleCount: 90, spread: 70 });
          onRewardWon(350, 'Impossible Laser Maze');
        }
      }

      return { x: nx, y: ny };
    });
  };

  const restart = () => {
    setLevel(1);
    setPlayerPos({ x: 30, y: 30 });
    setIsHit(false);
    setIsCleared(false);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-rose-700 to-black text-white flex justify-between items-center border border-red-500/40">
        <div className="flex items-center gap-1.5 font-black text-sm">
          <span>💀</span>
          <span>Impossible Laser Maze (Hard)</span>
        </div>
        <span className="text-xs bg-red-500/30 px-2.5 py-0.5 rounded-full font-bold">Stage: {level}/3</span>
      </div>

      <div className="relative mx-auto w-[300px] h-[300px] bg-slate-950 rounded-3xl border-2 border-red-500/50 overflow-hidden shadow-2xl select-none">
        {/* Goal Portal */}
        <div className="absolute right-4 bottom-4 w-12 h-12 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center font-bold text-xs text-emerald-300 animate-pulse">
          GOAL
        </div>

        {/* Start Pad */}
        <div className="absolute left-4 top-4 w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400 flex items-center justify-center font-bold text-[10px] text-indigo-300">
          START
        </div>

        {/* Central Laser Generator */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-red-600 border-2 border-white shadow-[0_0_20px_#ef4444] z-10" />

        {/* Rotating Laser Beams */}
        <div
          className="absolute left-1/2 top-1/2 w-[240px] h-1.5 bg-gradient-to-r from-red-500 via-rose-400 to-red-500 shadow-[0_0_15px_#ef4444] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
          style={{ transform: `translate(-50%, -50%) rotate(${laserAngle}rad)` }}
        />
        {level >= 2 && (
          <div
            className="absolute left-1/2 top-1/2 w-[240px] h-1.5 bg-gradient-to-r from-red-500 via-rose-400 to-red-500 shadow-[0_0_15px_#ef4444] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
            style={{ transform: `translate(-50%, -50%) rotate(${laserAngle + Math.PI / 2}rad)` }}
          />
        )}

        {/* Player Orb */}
        <div
          className={`absolute w-7 h-7 rounded-full transition-all duration-75 flex items-center justify-center text-xs font-bold border-2 ${
            isHit ? 'bg-red-500 border-white scale-125' : 'bg-cyan-400 border-cyan-200 shadow-[0_0_15px_#22d3ee]'
          }`}
          style={{ left: playerPos.x - 14, top: playerPos.y - 14 }}
        >
          {isHit ? '💥' : '⚡'}
        </div>

        {/* Win Overlay */}
        {isCleared && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center space-y-3 p-4 text-white z-20">
            <h4 className="text-xl font-black text-amber-400">🏆 MAZE CONQUERED!</h4>
            <p className="text-xs text-emerald-300 font-bold">Earned 🪙 +350 Coins (₹350 Instant Cash)!</p>
            <button onClick={restart} className="px-5 py-2 rounded-xl bg-red-600 text-white font-bold text-xs cursor-pointer">
              Play Again
            </button>
          </div>
        )}
      </div>

      {/* D-Pad Controls */}
      <div className="flex flex-col items-center gap-1.5">
        <button
          onClick={() => movePlayer(0, -28)}
          className="w-16 h-11 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => movePlayer(-28, 0)}
            className="w-16 h-11 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ◀
          </button>
          <button
            onClick={() => movePlayer(0, 28)}
            className="w-16 h-11 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ▼
          </button>
          <button
            onClick={() => movePlayer(28, 0)}
            className="w-16 h-11 rounded-2xl bg-slate-800 active:bg-slate-700 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ▶
          </button>
        </div>
      </div>
      <p className="text-[11px] text-slate-400">Guide your cyan orb to the green GOAL without touching red lasers!</p>
    </div>
  );
};

/* 15. HARD GAME: Bullet Hell Storm */
const BulletHellStormGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [timeLeft, setTimeLeft] = useState(25);
  const [lives, setLives] = useState(3);
  const [isWon, setIsWon] = useState(false);
  const [isOver, setIsOver] = useState(false);
  const playerRef = useRef({ x: 150, y: 220 });
  const bulletsRef = useRef<Array<{ x: number; y: number; vx: number; vy: number; color: string }>>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const movePlayer = (dx: number, dy: number) => {
    playerRef.current.x = Math.max(20, Math.min(280, playerRef.current.x + dx));
    playerRef.current.y = Math.max(20, Math.min(280, playerRef.current.y + dy));
  };

  useEffect(() => {
    if (isOver || isWon) return;

    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          setIsWon(true);
          confetti({ particleCount: 85, spread: 65 });
          onRewardWon(300, 'Bullet Hell Storm');
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOver, isWon, onRewardWon]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let spawnCount = 0;

    const loop = () => {
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, 300, 300);

      // Spawn bullets wave
      spawnCount++;
      if (spawnCount % 5 === 0 && !isOver && !isWon) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1.8 + Math.random() * 2.2;
        bulletsRef.current.push({
          x: 150,
          y: 60,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: '#f43f5e',
        });
        bulletsRef.current.push({
          x: Math.random() * 300,
          y: 0,
          vx: (Math.random() - 0.5) * 1.5,
          vy: 2.5 + Math.random() * 1.5,
          color: '#fbbf24',
        });
      }

      // Update & render bullets
      for (let i = bulletsRef.current.length - 1; i >= 0; i--) {
        const b = bulletsRef.current[i];
        b.x += b.vx;
        b.y += b.vy;

        // Collision with player
        const dist = Math.hypot(b.x - playerRef.current.x, b.y - playerRef.current.y);
        if (dist < 12 && !isOver && !isWon) {
          bulletsRef.current.splice(i, 1);
          setLives(l => {
            const nextL = l - 1;
            if (nextL <= 0) setIsOver(true);
            return nextL;
          });
          continue;
        }

        ctx.fillStyle = b.color;
        ctx.beginPath();
        ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
        ctx.fill();

        if (b.x < -10 || b.x > 310 || b.y < -10 || b.y > 310) {
          bulletsRef.current.splice(i, 1);
        }
      }

      // Draw player ship
      const p = playerRef.current;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(p.x, p.y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#bae6fd';
      ctx.lineWidth = 2;
      ctx.stroke();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isOver, isWon]);

  const restart = () => {
    setTimeLeft(25);
    setLives(3);
    setIsWon(false);
    setIsOver(false);
    playerRef.current = { x: 150, y: 220 };
    bulletsRef.current = [];
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-700 via-rose-700 to-black text-white flex justify-between items-center border border-purple-500/40">
        <span className="font-black text-sm">⚡ Bullet Hell Storm (Survive 25s)</span>
        <div className="flex items-center gap-2 text-xs font-bold">
          <span className="text-amber-300">⏱️ {timeLeft}s</span>
          <span className="text-rose-400">❤️ {lives}</span>
        </div>
      </div>

      <div className="relative mx-auto w-[300px] h-[300px] rounded-3xl overflow-hidden border-2 border-purple-500/40 shadow-2xl">
        <canvas ref={canvasRef} width={300} height={300} />

        {isOver && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center p-4 text-white space-y-2">
            <h4 className="text-xl font-black text-rose-500">💥 DESTROYED!</h4>
            <p className="text-xs text-slate-300">Survive for 25s to claim ₹300 coins</p>
            <button onClick={restart} className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs cursor-pointer">
              Retry
            </button>
          </div>
        )}

        {isWon && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center p-4 text-white space-y-2">
            <h4 className="text-xl font-black text-amber-400">🏆 SURVIVAL MASTER!</h4>
            <p className="text-xs text-emerald-300 font-bold">Earned 🪙 +300 Coins (₹300)!</p>
            <button onClick={restart} className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs cursor-pointer">
              Play Again
            </button>
          </div>
        )}
      </div>

      {/* D-Pad Controls */}
      <div className="flex flex-col items-center gap-1.5">
        <button
          onClick={() => movePlayer(0, -30)}
          className="w-16 h-11 rounded-2xl bg-slate-800 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => movePlayer(-30, 0)}
            className="w-16 h-11 rounded-2xl bg-slate-800 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ◀
          </button>
          <button
            onClick={() => movePlayer(0, 30)}
            className="w-16 h-11 rounded-2xl bg-slate-800 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ▼
          </button>
          <button
            onClick={() => movePlayer(30, 0)}
            className="w-16 h-11 rounded-2xl bg-slate-800 text-white font-black text-lg flex items-center justify-center border border-slate-700 active:scale-95 cursor-pointer"
          >
            ▶
          </button>
        </div>
      </div>
    </div>
  );
};

/* 16. HARD GAME: Bomb Defusal Minesweeper Pro */
const BombDefusalGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [timeLeft, setTimeLeft] = useState(30);
  const [isOver, setIsOver] = useState(false);
  const [isWon, setIsWon] = useState(false);
  const [flagMode, setFlagMode] = useState(false);

  // 6x6 grid with 6 bombs
  const [grid, setGrid] = useState<Array<{ isBomb: boolean; count: number; revealed: boolean; flagged: boolean }>>(() => {
    const cells = Array(36).fill(null).map(() => ({ isBomb: false, count: 0, revealed: false, flagged: false }));
    let placed = 0;
    while (placed < 6) {
      const idx = Math.floor(Math.random() * 36);
      if (!cells[idx].isBomb) {
        cells[idx].isBomb = true;
        placed++;
      }
    }
    // Calculate neighbor counts
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 6; c++) {
        const i = r * 6 + c;
        if (cells[i].isBomb) continue;
        let count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            const nr = r + dr;
            const nc = c + dc;
            if (nr >= 0 && nr < 6 && nc >= 0 && nc < 6) {
              if (cells[nr * 6 + nc].isBomb) count++;
            }
          }
        }
        cells[i].count = count;
      }
    }
    return cells;
  });

  useEffect(() => {
    if (isOver || isWon) return;
    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          setIsOver(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isOver, isWon]);

  const handleCellClick = (idx: number) => {
    if (isOver || isWon || grid[idx].revealed) return;

    if (flagMode) {
      setGrid(prev => prev.map((cell, i) => i === idx ? { ...cell, flagged: !cell.flagged } : cell));
      return;
    }

    if (grid[idx].flagged) return;

    if (grid[idx].isBomb) {
      setIsOver(true);
      setGrid(prev => prev.map(c => ({ ...c, revealed: true })));
      return;
    }

    const nextGrid = [...grid];
    nextGrid[idx].revealed = true;
    setGrid(nextGrid);

    // Check win condition (30 safe cells revealed)
    const revealedSafe = nextGrid.filter(c => !c.isBomb && c.revealed).length;
    if (revealedSafe >= 30) {
      setIsWon(true);
      confetti({ particleCount: 80, spread: 60 });
      onRewardWon(300, 'Bomb Defusal Minesweeper');
    }
  };

  const restart = () => {
    setTimeLeft(30);
    setIsOver(false);
    setIsWon(false);
    const cells = Array(36).fill(null).map(() => ({ isBomb: false, count: 0, revealed: false, flagged: false }));
    let placed = 0;
    while (placed < 6) {
      const idx = Math.floor(Math.random() * 36);
      if (!cells[idx].isBomb) {
        cells[idx].isBomb = true;
        placed++;
      }
    }
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 6; c++) {
        const i = r * 6 + c;
        if (cells[i].isBomb) continue;
        let count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            const nr = r + dr;
            const nc = c + dc;
            if (nr >= 0 && nr < 6 && nc >= 0 && nc < 6) {
              if (cells[nr * 6 + nc].isBomb) count++;
            }
          }
        }
        cells[i].count = count;
      }
    }
    setGrid(cells);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-600 via-rose-700 to-black text-white flex justify-between items-center border border-amber-500/40">
        <span className="font-black text-sm">💣 Bomb Defusal Pro (Defuse 6 C4)</span>
        <span className="text-xs bg-black/40 px-2.5 py-0.5 rounded-full font-mono font-bold text-amber-300">
          ⏱️ {timeLeft}s
        </span>
      </div>

      <div className="flex justify-between items-center px-1">
        <span className="text-xs text-slate-400">Safe: {grid.filter(c => !c.isBomb && c.revealed).length}/30</span>
        <button
          onClick={() => setFlagMode(!flagMode)}
          className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer ${
            flagMode ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-300'
          }`}
        >
          <span>🚩 Flag Mode:</span>
          <span>{flagMode ? 'ON' : 'OFF'}</span>
        </button>
      </div>

      <div className="grid grid-cols-6 gap-1.5 max-w-[280px] mx-auto p-2 bg-slate-950 rounded-2xl border border-slate-800">
        {grid.map((cell, idx) => (
          <button
            key={idx}
            onClick={() => handleCellClick(idx)}
            className={`w-10 h-10 rounded-xl font-black text-xs flex items-center justify-center transition-all cursor-pointer ${
              cell.revealed
                ? cell.isBomb
                  ? 'bg-rose-600 text-white'
                  : 'bg-slate-800 text-emerald-400'
                : 'bg-slate-700 hover:bg-slate-650 text-white'
            }`}
          >
            {cell.revealed ? (cell.isBomb ? '💣' : cell.count > 0 ? cell.count : '') : cell.flagged ? '🚩' : ''}
          </button>
        ))}
      </div>

      {(isOver || isWon) && (
        <div className="p-3 rounded-2xl bg-slate-800 space-y-2">
          <h4 className={`text-sm font-black ${isWon ? 'text-emerald-400' : 'text-rose-400'}`}>
            {isWon ? '🎉 BOMB DEFUSED! Won 🪙 +300 Coins (₹300)!' : '💥 DETONATION! Bomb Exploded!'}
          </h4>
          <button onClick={restart} className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs cursor-pointer">
            Try Again
          </button>
        </div>
      )}
    </div>
  );
};

/* 17. HARD GAME: Hardcore Math Blitz */
const HardcoreMathBlitzGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [problem, setProblem] = useState({ text: '18 × 6 - 28', ans: 80 });
  const [userAns, setUserAns] = useState('');
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(5);
  const [isOver, setIsOver] = useState(false);

  const generateHardProblem = () => {
    const types = [
      () => {
        const a = Math.floor(Math.random() * 15) + 12;
        const b = Math.floor(Math.random() * 8) + 4;
        const c = Math.floor(Math.random() * 40) + 10;
        return { text: `${a} × ${b} - ${c}`, ans: a * b - c };
      },
      () => {
        const a = Math.floor(Math.random() * 12) + 11;
        const b = Math.floor(Math.random() * 12) + 11;
        const c = Math.floor(Math.random() * 50) + 15;
        return { text: `${a} × ${b} + ${c}`, ans: a * b + c };
      },
      () => {
        const a = Math.floor(Math.random() * 80) + 45;
        const b = Math.floor(Math.random() * 65) + 35;
        const c = Math.floor(Math.random() * 45) + 20;
        return { text: `${a} + ${b} - ${c}`, ans: a + b - c };
      },
    ];
    const pick = types[Math.floor(Math.random() * types.length)]();
    setProblem(pick);
    setUserAns('');
    setTimeLeft(5);
  };

  useEffect(() => {
    if (isOver) return;
    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          setIsOver(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [problem, isOver]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parseInt(userAns) === problem.ans) {
      const nextScore = score + 1;
      setScore(nextScore);
      if (nextScore >= 8) {
        setIsOver(true);
        confetti({ particleCount: 75, spread: 60 });
        onRewardWon(250, 'Hardcore Math Blitz');
      } else {
        generateHardProblem();
      }
    } else {
      setIsOver(true);
    }
  };

  const restart = () => {
    setScore(0);
    setIsOver(false);
    generateHardProblem();
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-800 to-black text-white flex justify-between items-center border border-indigo-500/40">
        <span className="font-black text-sm">🧠 Hardcore Math Blitz (4.5s Limit)</span>
        <span className="text-xs bg-indigo-500/30 px-2.5 py-0.5 rounded-full font-bold">Streak: {score}/8</span>
      </div>

      {!isOver ? (
        <form onSubmit={handleSubmit} className="space-y-4 py-3">
          <div className="text-3xl font-black text-slate-100 tracking-wider">
            {problem.text} = ?
          </div>
          <p className="text-xs font-bold text-amber-400">⏱️ {timeLeft}s Left to Answer!</p>

          <input
            type="number"
            autoFocus
            value={userAns}
            onChange={(e) => setUserAns(e.target.value)}
            placeholder="Type answer"
            className="w-44 mx-auto px-4 py-2.5 text-center text-xl font-black rounded-2xl border-2 border-indigo-500 bg-slate-900 text-white focus:outline-hidden"
          />

          <button type="submit" className="w-full py-3 rounded-2xl bg-indigo-600 text-white font-bold text-xs cursor-pointer">
            Submit Answer (Enter)
          </button>
        </form>
      ) : (
        <div className="space-y-3 py-4">
          <h4 className={`text-lg font-black ${score >= 8 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {score >= 8 ? '🏆 MATH MASTER! Won 🪙 +250 Coins (₹250)!' : 'TIME EXPIRED / WRONG ANSWER!'}
          </h4>
          <p className="text-xs text-slate-400">Target was {problem.ans} • Final Streak: {score}</p>
          <button onClick={restart} className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-xs cursor-pointer">
            Retry Challenge
          </button>
        </div>
      )}
    </div>
  );
};

/* 18. HARD GAME: Extreme Knife Hit Reverse Spin */
const ExtremeKnifeHitGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [knivesInLog, setKnivesInLog] = useState<number[]>([0.2, 1.4, 3.2]);
  const [knivesLeft, setKnivesLeft] = useState(8);
  const [score, setScore] = useState(0);
  const [logAngle, setLogAngle] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isWin, setIsWin] = useState(false);
  const speedRef = useRef(0.06);

  useEffect(() => {
    if (isGameOver || isWin) return;
    const interval = setInterval(() => {
      // Random direction reversal and erratic speed
      if (Math.random() < 0.03) {
        speedRef.current = (Math.random() - 0.5) * 0.18;
      }
      setLogAngle(a => (a + speedRef.current) % (Math.PI * 2));
    }, 20);
    return () => clearInterval(interval);
  }, [isGameOver, isWin]);

  const throwKnife = () => {
    if (isGameOver || isWin || knivesLeft <= 0) return;

    const hitAngle = ((Math.PI / 2) - logAngle + Math.PI * 2) % (Math.PI * 2);

    const hitsOther = knivesInLog.some(a => {
      const diff = Math.abs(a - hitAngle);
      return diff < 0.32 || Math.abs(diff - Math.PI * 2) < 0.32;
    });

    if (hitsOther) {
      setIsGameOver(true);
    } else {
      const nextKnives = [...knivesInLog, hitAngle];
      setKnivesInLog(nextKnives);
      const nextLeft = knivesLeft - 1;
      setKnivesLeft(nextLeft);
      const nextScore = score + 1;
      setScore(nextScore);

      if (nextLeft <= 0) {
        setIsWin(true);
        confetti({ particleCount: 75, spread: 60 });
        onRewardWon(250, 'Extreme Knife Hit Reverse');
      }
    }
  };

  const restart = () => {
    setKnivesInLog([0.2, 1.4, 3.2]);
    setKnivesLeft(8);
    setScore(0);
    setIsGameOver(false);
    setIsWin(false);
  };

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-amber-600 to-black text-white flex justify-between items-center border border-red-500/40">
        <span className="font-black text-sm">🌪️ Extreme Knife Hit (Reverse Spin)</span>
        <span className="text-xs bg-red-500/30 px-2 py-0.5 rounded-full font-bold">Blades: {knivesLeft}</span>
      </div>

      <div className="relative h-64 bg-slate-950 rounded-3xl border-2 border-red-500/30 flex items-center justify-center overflow-hidden">
        <div 
          className="w-28 h-28 rounded-full bg-red-950 border-4 border-red-600 flex items-center justify-center relative shadow-2xl"
          style={{ transform: `rotate(${logAngle}rad)` }}
        >
          <span className="text-2xl select-none">💀</span>
          {knivesInLog.map((angle, i) => (
            <div
              key={i}
              className="absolute w-2 h-10 bg-slate-200 border border-slate-400 origin-bottom"
              style={{
                top: '-40px',
                left: 'calc(50% - 4px)',
                transformOrigin: '50% 96px',
                transform: `rotate(${angle}rad)`,
              }}
            />
          ))}
        </div>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-2xl select-none animate-bounce">
          🗡️
        </div>

        {(isGameOver || isWin) && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center space-y-2 p-4 text-white">
            <h4 className={`text-lg font-black ${isWin ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isWin ? '🏆 MASTER BLADE! Won 🪙 +250 Coins (₹250)!' : '💥 BLADE DEFLECTED!'}
            </h4>
            <button onClick={restart} className="px-4 py-2 rounded-xl bg-red-600 text-white font-bold text-xs cursor-pointer">
              Try Again
            </button>
          </div>
        )}
      </div>

      <button
        onClick={throwKnife}
        disabled={isGameOver || isWin}
        className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 text-white font-black text-sm active:scale-95 transition-all cursor-pointer shadow-lg disabled:opacity-50"
      >
        🎯 STRIKE KNIFE NOW
      </button>
    </div>
  );
};

/* 19. HARD GAME: Flappy Insane Storm */
const FlappyInsaneStormGame: React.FC<{ onRewardWon: (c: number, g: string) => void; onClose: () => void }> = ({ onRewardWon }) => {
  const [score, setScore] = useState(0);
  const [isOver, setIsOver] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const birdYRef = useRef(140);
  const birdVelRef = useRef(0);
  const gatesRef = useRef<Array<{ x: number; top: number; bottom: number; passed: boolean }>>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const flap = () => {
    if (!hasStarted) {
      setHasStarted(true);
      setIsOver(false);
      birdYRef.current = 140;
      birdVelRef.current = -5.8;
      gatesRef.current = [{ x: 300, top: 90, bottom: 120, passed: false }];
      setScore(0);
      return;
    }
    if (isOver) {
      setHasStarted(false);
      setIsOver(false);
      birdYRef.current = 140;
      birdVelRef.current = 0;
      gatesRef.current = [];
      setScore(0);
      return;
    }
    birdVelRef.current = -6.2;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = () => {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 320, 320);

      // Red laser grid background
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.15)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 320; i += 30) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, 320);
        ctx.stroke();
      }

      if (hasStarted && !isOver) {
        birdVelRef.current += 0.38; // Faster gravity in Insane Mode!
        birdYRef.current += birdVelRef.current;

        // Spawn narrow gates
        if (gatesRef.current.length === 0 || gatesRef.current[gatesRef.current.length - 1].x < 150) {
          const topH = Math.floor(Math.random() * 120) + 40;
          gatesRef.current.push({ x: 320, top: topH, bottom: 320 - topH - 68, passed: false });
        }

        gatesRef.current.forEach(g => {
          g.x -= 3.2; // High speed!
          if (!g.passed && g.x < 70) {
            g.passed = true;
            setScore(s => {
              const ns = s + 1;
              if (ns >= 8) {
                confetti({ particleCount: 75, spread: 60 });
                onRewardWon(300, 'Flappy Insane Storm');
              }
              return ns;
            });
          }
        });

        if (birdYRef.current > 300 || birdYRef.current < 5) setIsOver(true);

        gatesRef.current.forEach(g => {
          if (g.x < 85 && g.x + 30 > 60) {
            if (birdYRef.current < g.top || birdYRef.current + 18 > 320 - g.bottom) {
              setIsOver(true);
            }
          }
        });

        gatesRef.current = gatesRef.current.filter(g => g.x > -50);
      }

      // Draw Laser Gates
      ctx.fillStyle = '#ef4444';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#dc2626';
      gatesRef.current.forEach(g => {
        ctx.fillRect(g.x, 0, 30, g.top);
        ctx.fillRect(g.x, 320 - g.bottom, 30, g.bottom);
      });
      ctx.shadowBlur = 0;

      // Draw Bird
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(75, birdYRef.current + 8, 10, 0, Math.PI * 2);
      ctx.fill();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [hasStarted, isOver, onRewardWon]);

  return (
    <div className="space-y-4 text-center">
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-700 via-rose-800 to-black text-white flex justify-between items-center border border-red-500/40">
        <span className="font-black text-sm">🐦 Flappy Insane Storm (Score 8 to Win)</span>
        <span className="text-xs bg-red-500/30 px-2 py-0.5 rounded-full font-bold">Gates: {score}/8</span>
      </div>

      <div className="relative mx-auto w-[320px] h-[320px] rounded-3xl overflow-hidden border-2 border-red-500/40 shadow-2xl">
        <canvas ref={canvasRef} width={320} height={320} onClick={flap} className="cursor-pointer" />
        {!hasStarted && (
          <div onClick={flap} className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white cursor-pointer p-4">
            <span className="text-3xl mb-1">⚡</span>
            <p className="font-black text-sm text-red-400">INSANE SPEED MODE</p>
            <p className="text-[11px] text-slate-300 mt-1">Tap to flap through narrow laser gates!</p>
          </div>
        )}
        {isOver && (
          <div onClick={flap} className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white cursor-pointer p-4">
            <p className="font-black text-lg text-rose-400">CRASHED!</p>
            <p className="text-xs text-slate-200 mt-1">Score: {score}/8 • Tap to Retry</p>
          </div>
        )}
      </div>

      <button onClick={flap} className="w-full py-3 rounded-2xl bg-red-600 text-white font-black text-sm active:scale-95 transition-all cursor-pointer">
        👆 TAP TO FLAP
      </button>
    </div>
  );
};
