import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Trophy, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface ScratchCardGameProps {
  onRewardWon: (coins: number, gameName: string) => void;
  onClose: () => void;
}

export const ScratchCardGame: React.FC<ScratchCardGameProps> = ({ onRewardWon, onClose }) => {
  const { language } = useApp();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isScratched, setIsScratched] = useState(false);
  const [prize] = useState<number>(() => {
    const prizes = [35, 50, 75, 100, 150, 200];
    return prizes[Math.floor(Math.random() * prizes.length)];
  });
  const [scratchedPercent, setScratchedPercent] = useState(0);

  useEffect(() => {
    initCanvas();
  }, []);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw gold foil background
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#F59E0B');
    grad.addColorStop(0.5, '#FCD34D');
    grad.addColorStop(1, '#D97706');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add pattern / text
    ctx.fillStyle = '#78350F';
    ctx.font = 'bold 16px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('✨ SCRATCH HERE ✨', canvas.width / 2, canvas.height / 2 - 10);
    ctx.font = '11px sans-serif';
    ctx.fillText('Scratch to Reveal Cash Prize', canvas.width / 2, canvas.height / 2 + 15);
  };

  const handleScratch = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (isScratched) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 24, 0, Math.PI * 2);
    ctx.fill();

    // Check approximate percentage scratched
    setScratchedPercent(prev => {
      const next = prev + 5;
      if (next >= 40 && !isScratched) {
        setIsScratched(true);
        confetti({ particleCount: 70, spread: 60 });
        onRewardWon(prize, 'Golden Scratch Card');
      }
      return next;
    });
  };

  const handleRevealAll = () => {
    if (isScratched) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    setIsScratched(true);
    confetti({ particleCount: 70, spread: 60 });
    onRewardWon(prize, 'Golden Scratch Card');
  };

  return (
    <div className="space-y-5 text-center">
      {/* Title */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-700 text-white shadow-md flex items-center justify-between">
        <div className="flex items-center gap-2.5 text-left">
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-xl">
            🎟️
          </div>
          <div>
            <h3 className="font-black text-sm sm:text-base tracking-tight">
              {language === 'bn' ? 'গোল্ডেন স্ক্র্যাচ কার্ড (Scratch & Win)' : 'Golden Scratch Card (Instant Win)'}
            </h3>
            <p className="text-[11px] text-white/90">
              {language === 'bn' ? 'কার্ড ঘষে নগদ ক্যাশ জিতে নিন' : 'Scratch the card to reveal your prize!'}
            </p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white text-amber-700">
          Instant Cash
        </span>
      </div>

      {/* Card area with canvas overlay */}
      <div className="relative w-72 h-44 mx-auto rounded-3xl overflow-hidden border-4 border-amber-300 dark:border-amber-600 shadow-xl select-none">
        {/* Underlying Prize */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 to-teal-800 text-white flex flex-col items-center justify-center p-4">
          <span className="text-3xl mb-1">🎁</span>
          <span className="text-xs uppercase font-bold text-emerald-200">You Won</span>
          <span className="text-3xl font-black text-amber-300">
            🪙 +{prize} Coins (₹{prize})
          </span>
          <span className="text-[10px] text-emerald-100 mt-1">Directly credited to wallet!</span>
        </div>

        {/* Scratchable Canvas */}
        <canvas
          ref={canvasRef}
          width={288}
          height={176}
          onMouseMove={(e) => {
            if (e.buttons === 1) handleScratch(e);
          }}
          onTouchMove={handleScratch}
          onClick={handleScratch}
          className="absolute inset-0 cursor-crosshair touch-none"
        />
      </div>

      <div className="flex flex-col sm:flex-row justify-center gap-2.5 pt-2">
        {!isScratched ? (
          <button
            onClick={handleRevealAll}
            className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md cursor-pointer"
          >
            Quick Scratch / Reveal All
          </button>
        ) : (
          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
            Prize ₹{prize} Credited Successfully!
          </div>
        )}

        <button
          onClick={onClose}
          className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold cursor-pointer"
        >
          Back to Game Zone
        </button>
      </div>
    </div>
  );
};
