import React, { useState } from 'react';
import { X, Check, Copy, Terminal, Server, Smartphone, Globe, Shield, Sparkles, FolderTree } from 'lucide-react';

interface DeployGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeployGuideModal: React.FC<DeployGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'run' | 'structure' | 'security' | 'deploy' | 'android'>('run');
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-[#0A1126] border border-blue-800/60 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-right text-slate-100">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-blue-900/50 flex items-center justify-between bg-[#0E1730]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-white">دليل تشغيل ونشر Mostafa AI</h3>
              <p className="text-xs text-blue-300/80">شرح تفصيلي خطوة بخطوة باللغة العربية</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-blue-900/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-[#070D1F] border-b border-blue-900/40 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('run')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'run'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-blue-950/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>1. التشغيل المحلي</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-blue-950/50'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>2. أمان مفتاح API</span>
          </button>

          <button
            onClick={() => setActiveTab('structure')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'structure'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-blue-950/50'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            <span>3. تنظيم الملفات</span>
          </button>

          <button
            onClick={() => setActiveTab('deploy')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'deploy'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-blue-950/50'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>4. النشر على السحابة</span>
          </button>

          <button
            onClick={() => setActiveTab('android')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'android'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-blue-950/50'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>5. تشغيل على أندرويد</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 text-sm leading-relaxed">
          {/* Tab 1: Local Run */}
          {activeTab === 'run' && (
            <div className="space-y-4 animate-fade-in">
              <h4 className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                طريقة تشغيل تطبيق Mostafa AI على جهازك المحلي
              </h4>
              <p className="text-slate-300">
                اتبع الخطوات البسيطة التالية لتشغيل التطبيق على حاسوبك الشخصي:
              </p>

              <div className="space-y-3">
                <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-900/50">
                  <span className="font-bold text-white block mb-1">الخطوة 1: تثبيت الحزم والمكتبات</span>
                  <p className="text-xs text-slate-300 mb-2">افتح شاشة الأوامر (Terminal) داخل مجلد المشروع ونفّذ:</p>
                  <div className="relative flex items-center justify-between p-2.5 rounded-xl bg-[#060B18] font-mono text-xs text-cyan-300 border border-blue-900/40">
                    <span>npm install</span>
                    <button
                      onClick={() => copyToClipboard('npm install', 'c1')}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      {copiedSnippet === 'c1' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-900/50">
                  <span className="font-bold text-white block mb-1">الخطوة 2: إنشاء ملف .env لمفتاح الذكاء الاصطناعي</span>
                  <p className="text-xs text-slate-300 mb-2">أنشئ ملفاً باسم <code className="text-blue-300">.env</code> وضع بداخله مفتاح Gemini API الخاص بك:</p>
                  <div className="relative flex items-center justify-between p-2.5 rounded-xl bg-[#060B18] font-mono text-xs text-cyan-300 border border-blue-900/40">
                    <span>GEMINI_API_KEY="AIzaSy..."</span>
                    <button
                      onClick={() => copyToClipboard('GEMINI_API_KEY="مفتاح_الـ_API_هنا"', 'c2')}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      {copiedSnippet === 'c2' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-amber-300/80 mt-1.5">
                    * يمكنك الحصول على مفتاح مجاني وسريع من Google AI Studio عبر موقع aistudio.google.com.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-900/50">
                  <span className="font-bold text-white block mb-1">الخطوة 3: تشغيل الخادم وتطبيق الويب</span>
                  <p className="text-xs text-slate-300 mb-2">شغّل أمر التطوير المباشر:</p>
                  <div className="relative flex items-center justify-between p-2.5 rounded-xl bg-[#060B18] font-mono text-xs text-cyan-300 border border-blue-900/40">
                    <span>npm run dev</span>
                    <button
                      onClick={() => copyToClipboard('npm run dev', 'c3')}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      {copiedSnippet === 'c3' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-xs text-emerald-300 mt-2">
                    ✓ سيعمل التطبيق مباشرة على الرابط: <span className="font-mono underline">http://localhost:3000</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Security & API Key */}
          {activeTab === 'security' && (
            <div className="space-y-4 animate-fade-in">
              <h4 className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                حماية مفتاح Gemini API (عدم كشفه في الواجهة الأمامية)
              </h4>
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-200">
                <p className="font-bold mb-1">كيف تم تطبيق شرط الحماية في Mostafa AI؟</p>
                <p className="text-xs text-emerald-300/90 leading-relaxed">
                  تم بناء التطبيق بنظام خادم وسيط (Server-Side Architecture). المتصفح لا يتصل مباشرة بجوجل ولا يحتوي كود الواجهة الأمامية (HTML/React/JS) على أي مفتاح سري على الإطلاق!
                </p>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40">
                  <span className="font-semibold text-white block mb-0.5">1. قراءة المفتاح من بيئة الخادم:</span>
                  يقرأ ملف <code className="text-blue-300">server.ts</code> المفتاح من خلال متغير البيئة <code className="text-cyan-300 font-mono">process.env.GEMINI_API_KEY</code> فقط.
                </div>
                <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40">
                  <span className="font-semibold text-white block mb-0.5">2. نقطة اتصال داخلية آمنة:</span>
                  ترسل الواجهة الأمامية طلبات الشات إلى مسار <code className="text-cyan-300 font-mono">/api/chat</code> الداخلي في خادمك، والذي يتولى التحقق واستدعاء النموذج وإرجاع الرد للمستخدم.
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Structure */}
          {activeTab === 'structure' && (
            <div className="space-y-3 animate-fade-in">
              <h4 className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <FolderTree className="w-4 h-4" />
                تنظيم الكود والملفات في التطبيق
              </h4>
              <p className="text-xs text-slate-300">
                الكود مقسّم هندسياً بطريقة نظيفة ومعيارية (Clean Architecture):
              </p>

              <div className="p-3.5 rounded-2xl bg-[#060B18] border border-blue-900/50 font-mono text-xs text-slate-300 space-y-1.5 leading-relaxed">
                <div>├── <span className="text-cyan-400 font-bold">index.html</span> : صفحة الدخول، مهيأة للغة العربية (RTL) مع خطوط تجوال والقاهرة ووسوم أندرويد.</div>
                <div>├── <span className="text-cyan-400 font-bold">server.ts</span> : خادم Node/Express الخلفي الذي يتعامل بأمان مع Gemini API ويحمي المفتاح.</div>
                <div>├── <span className="text-cyan-400 font-bold">src/index.css</span> : ملف التنسيقات وتخصيص شريط التمرير الكحلي وخصائص المظهر العصري.</div>
                <div>├── <span className="text-cyan-400 font-bold">src/App.tsx</span> : المكون الرئيسي لإدارة المحادثة وحفظ السجل واستقبال الرسائل.</div>
                <div>├── <span className="text-cyan-400 font-bold">src/components/</span> : مكونات الواجهة:</div>
                <div className="pr-4">├── <span className="text-blue-300">Header.tsx</span> : الشريط العلوي وزر محادثة جديدة وشعار Mostafa AI.</div>
                <div className="pr-4">├── <span className="text-blue-300">ChatMessage.tsx</span> : فقاعة الرسالة وتنسيق Markdown ونسخ الكود والقراءة الصوتية.</div>
                <div className="pr-4">├── <span className="text-blue-300">ChatInput.tsx</span> : مربع كتابة الرسائل، الإملاء الصوتي، وإرفاق الصور.</div>
                <div className="pr-4">├── <span className="text-blue-300">Sidebar.tsx</span> : القائمة الجانبية لسجل المحادثات السابقة.</div>
                <div className="pr-4">└── <span className="text-blue-300">Suggestions.tsx</span> : اقتراحات أسئلة سريعة باللغة العربية.</div>
                <div>└── <span className="text-cyan-400 font-bold">src/services/api.ts</span> : استدعاء آمن لنقاط نهاية الخادم دون تسريب أي بيانات حساسة.</div>
              </div>
            </div>
          )}

          {/* Tab 4: Cloud Deploy */}
          {activeTab === 'deploy' && (
            <div className="space-y-3 animate-fade-in">
              <h4 className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <Globe className="w-4 h-4" />
                طريقة نشر التطبيق على السحابة (Cloud Deployment)
              </h4>
              <p className="text-xs text-slate-300">
                يمكنك نشر Mostafa AI مجاناً أو بتكلفة منخفضة على منصات مثل Google Cloud Run، Render، أو Railway:
              </p>

              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40">
                  <span className="font-bold text-white block mb-1">1. بناء حزمة الإنتاج:</span>
                  <div className="p-2 bg-[#060B18] rounded-lg font-mono text-cyan-300 mb-1">npm run build</div>
                  يقوم هذا الأمر بتجميع كود الواجهة إلى مجلد <code className="text-blue-300">dist</code> عالي السرعة والأداء.
                </div>

                <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40">
                  <span className="font-bold text-white block mb-1">2. أمر بدء التشغيل في بيئة الإنتاج:</span>
                  <div className="p-2 bg-[#060B18] rounded-lg font-mono text-cyan-300 mb-1">npm start</div>
                  يقوم الخادم بخدمة ملفات الويب وتقديم الـ API في نفس الوقت على المنفذ المخصص.
                </div>

                <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40">
                  <span className="font-bold text-white block mb-1">3. إضافة متغير البيئة في لوحة الاستضافة:</span>
                  في إعدادات المنصة (مثل Render أو Cloud Run)، أضف المتغير:
                  <div className="p-2 bg-[#060B18] rounded-lg font-mono text-cyan-300 mt-1">
                    Key: GEMINI_API_KEY | Value: مفتاحك_السري
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 5: Android */}
          {activeTab === 'android' && (
            <div className="space-y-3 animate-fade-in">
              <h4 className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                طريقة تشغيل التطبيق على شاشات وهواتف أندرويد
              </h4>
              <p className="text-xs text-slate-300">
                تم تصميم التطبيق ليعمل بسلاسة فائقة وكأنه تطبيق أندرويد أصلي (Native App):
              </p>

              <div className="space-y-2.5 text-xs text-slate-300">
                <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-900/50">
                  <span className="font-bold text-white block mb-1">الطريقة الأولى: التثبيت الفوري كـ Web App على الشاشة الرئيسية (PWA)</span>
                  <ol className="list-decimal list-inside space-y-1 text-slate-300 pr-1">
                    <li>افتح رابط التطبيق في متصفح Google Chrome على هاتف أندرويد.</li>
                    <li>اضغط على زر النقاط الثلاث (⋮) في أعلى المتصفح.</li>
                    <li>اختر <strong>"إضافة إلى الشاشة الرئيسية" (Add to Home screen)</strong> أو <strong>"تثبيت التطبيق" (Install App)</strong>.</li>
                    <li>سيظهر تطبيق Mostafa AI بأيقونته في شاشة هاتفك ويعمل بملء الشاشة بدون أشرطة المتصفح!</li>
                  </ol>
                </div>

                <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-900/50">
                  <span className="font-bold text-white block mb-1">الطريقة الثانية: تحويله إلى ملف APK حقيقي</span>
                  <p className="text-slate-300 mb-2">
                    باستخدام أداة Google الرسمية <strong>Bubblewrap (Trusted Web Activity)</strong> أو <strong>Capacitor</strong>:
                  </p>
                  <div className="p-2 bg-[#060B18] rounded-lg font-mono text-cyan-300 mb-1">
                    npm i -g @bubblewrap/cli && bubblewrap init --manifest=YOUR_URL/manifest.json
                  </div>
                  <p className="text-[11px] text-slate-400">
                    تقوم الأداة بإنشاء ملف APK قابل للتثبيت مباشرة على أي هاتف أندرويد أو نشره على متجر Google Play!
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-blue-900/50 bg-[#0E1730] flex items-center justify-between text-xs">
          <span className="text-slate-400">Mostafa AI • إصدار كامل جاهز للتشغيل والنشر</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold shadow-md active:scale-95 transition-all"
          >
            إغلاق الدليل
          </button>
        </div>
      </div>
    </div>
  );
};
