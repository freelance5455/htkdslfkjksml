import React, { useState, useEffect, useRef } from 'react';
import { Conversation, Message, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { wsClient } from '../../services/websocket';
import {
  Search, Phone, Video, MoreVertical, Send,
  Mic, Square, Paperclip, Image, Smile, Pin,
  Trash2, Reply, Check, CheckCheck, Clock, MapPin,
  User as UserIcon, X, AlertCircle, FileText, Download
} from 'lucide-react';

interface ChatViewProps {
  onStartCall: (toUser: User, callType: 'audio' | 'video') => void;
  initialConversationId?: string;
}

export const ChatView: React.FC<ChatViewProps> = ({ onStartCall, initialConversationId }) => {
  const { currentUser, onlineUsers } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [replyMessage, setReplyMessage] = useState<Message | null>(null);
  const [isTypingRemote, setIsTypingRemote] = useState<boolean>(false);
  const [remoteTypingUser, setRemoteTypingUser] = useState<string>('');
  const [showOptions, setShowOptions] = useState(false);
  const [ephemeralTimer, setEphemeralTimer] = useState<number>(0);

  // Audio Recording
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordIntervalRef = useRef<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Load conversations
  const loadConversations = async () => {
    if (!currentUser) return;
    try {
      const res = await api.getConversations(currentUser.id);
      setConversations(res.conversations || []);
      if (!activeConversation && res.conversations?.length > 0) {
        if (initialConversationId) {
          const match = res.conversations.find(c => c.id === initialConversationId);
          setActiveConversation(match || res.conversations[0]);
        } else {
          setActiveConversation(res.conversations[0]);
        }
      }
    } catch (err) {
      console.error('Erro ao carregar conversas:', err);
    }
  };

  useEffect(() => {
    loadConversations();
  }, [currentUser?.id]);

  // Load messages when active conversation changes
  useEffect(() => {
    if (!activeConversation || !currentUser) return;
    const fetchMsgs = async () => {
      try {
        const res = await api.getMessages(activeConversation.id, currentUser.id);
        setMessages(res.messages || []);
        // Mark as read
        await api.markMessagesAsRead(activeConversation.id, currentUser.id);
        loadConversations();
      } catch (err) {
        console.error('Erro ao carregar mensagens:', err);
      }
    };
    fetchMsgs();
  }, [activeConversation?.id]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTypingRemote]);

  // WebSocket listeners
  useEffect(() => {
    const unsubMsg = wsClient.on('message:new', (data) => {
      if (data.message && data.message.conversationId === activeConversation?.id) {
        setMessages(prev => {
          if (prev.some(m => m.id === data.message.id)) return prev;
          return [...prev, data.message];
        });
        if (currentUser && activeConversation) {
          api.markMessagesAsRead(activeConversation.id, currentUser.id).catch(() => {});
        }
      }
      loadConversations();
    });

    const unsubTyping = wsClient.on('typing', (data) => {
      if (data.conversationId === activeConversation?.id) {
        setIsTypingRemote(data.isTyping);
        setRemoteTypingUser(data.userId);
      }
    });

    return () => {
      unsubMsg();
      unsubTyping();
    };
  }, [activeConversation?.id, currentUser?.id]);

  // Handle typing debounce
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setText(e.target.value);
    if (!activeConversation || !currentUser) return;

    const recipients = activeConversation.participantIds.filter(id => id !== currentUser.id);
    wsClient.sendTyping(activeConversation.id, recipients, true);

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      wsClient.sendTyping(activeConversation.id, recipients, false);
    }, 1500);
  };

  // Send message
  const handleSendMessage = async (customPayload?: Partial<Message>) => {
    if (!activeConversation || !currentUser) return;
    const messageText = customPayload?.text !== undefined ? customPayload.text : text;
    if (!messageText?.trim() && !customPayload?.mediaUrl && !customPayload?.location && !customPayload?.contact) {
      return;
    }

    try {
      const payload: Partial<Message> = {
        conversationId: activeConversation.id,
        senderId: currentUser.id,
        text: messageText,
        type: customPayload?.type || 'text',
        mediaUrl: customPayload?.mediaUrl,
        fileName: customPayload?.fileName,
        fileSize: customPayload?.fileSize,
        audioDurationSeconds: customPayload?.audioDurationSeconds,
        location: customPayload?.location,
        contact: customPayload?.contact,
        replyTo: replyMessage ? {
          messageId: replyMessage.id,
          text: replyMessage.text,
          senderName: replyMessage.senderId === currentUser.id ? 'Você' : 'Outro'
        } : undefined
      };

      const res = await api.sendMessage(payload);
      if (res.message) {
        setMessages(prev => [...prev, res.message]);
        setText('');
        setReplyMessage(null);

        // Broadcast over WebSocket to recipients
        const recipients = activeConversation.participantIds.filter(id => id !== currentUser.id);
        wsClient.sendChatMessage(res.message, recipients);
        loadConversations();
      }
    } catch (err) {
      console.error('Erro ao enviar mensagem:', err);
    }
  };

  // Handle File Upload in chat
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploadRes = await api.uploadFile(base64, file.name);

        let type: Message['type'] = 'file';
        if (file.type.startsWith('image/')) type = 'image';
        else if (file.type.startsWith('video/')) type = 'video';
        else if (file.type.startsWith('audio/')) type = 'audio';

        await handleSendMessage({
          type,
          mediaUrl: uploadRes.url,
          fileName: file.name,
          fileSize: `${(file.size / 1024).toFixed(0)} KB`,
          text: file.name
        });
      } catch (err: any) {
        alert('Erro ao enviar ficheiro: ' + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  // Real Audio Recording with Web MediaRecorder
  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = reader.result as string;
          const uploadRes = await api.uploadFile(base64, 'voice_note.webm');
          await handleSendMessage({
            type: 'audio',
            mediaUrl: uploadRes.url,
            audioDurationSeconds: recordingSeconds,
            text: 'Mensagem de voz'
          });
        };
        reader.readAsDataURL(audioBlob);

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      recordIntervalRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } catch (err) {
      alert('Acesso ao microfone não concedido ou indisponível.');
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(recordIntervalRef.current);
    }
  };

  // Send Location
  const handleSendLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocalização não suportada no seu navegador.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        handleSendMessage({
          type: 'location',
          location: {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            address: `Luanda, Angola (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`
          },
          text: 'Localização partilhada'
        });
      },
      () => {
        // Fallback demo location in Luanda
        handleSendMessage({
          type: 'location',
          location: {
            lat: -8.8383,
            lng: 13.2344,
            address: 'Baía de Luanda, Marginal, Angola'
          },
          text: 'Localização: Baía de Luanda, Angola'
        });
      }
    );
  };

  // React to message
  const handleReactToMessage = async (msgId: string, emoji: string) => {
    if (!currentUser) return;
    try {
      await api.reactMessage(msgId, currentUser.id, emoji);
      const res = await api.getMessages(activeConversation!.id, currentUser.id);
      setMessages(res.messages);
    } catch (err) {
      console.error(err);
    }
  };

  // Delete message
  const handleDeleteMessage = async (msgId: string, forEveryone: boolean) => {
    if (!currentUser) return;
    try {
      await api.deleteMessage(msgId, currentUser.id, forEveryone);
      const res = await api.getMessages(activeConversation!.id, currentUser.id);
      setMessages(res.messages);
    } catch (err) {
      console.error(err);
    }
  };

  // Pin message
  const handlePinMessage = async (msgId: string) => {
    try {
      await api.pinMessage(msgId);
      const res = await api.getMessages(activeConversation!.id, currentUser!.id);
      setMessages(res.messages);
    } catch (err) {
      console.error(err);
    }
  };

  // Other user in direct conversation
  const targetUser = activeConversation?.otherUsers?.[0];
  const isTargetOnline = targetUser ? onlineUsers.includes(targetUser.id) : false;

  // Filter conversations by search
  const filteredConversations = conversations.filter(c => {
    if (!searchQuery.trim()) return true;
    const name = c.type === 'group' ? (c.name || '') : (c.otherUsers?.[0]?.name || '');
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 h-[calc(100vh-5rem)]">
      <div className="grid grid-cols-1 md:grid-cols-12 h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">

        {/* LEFT PANE: Conversations list (4 cols) */}
        <aside className={`${activeConversation ? 'hidden md:flex' : 'flex'} md:col-span-4 flex-col border-r border-slate-800 bg-slate-950/60 h-full`}>

          {/* Conversations Header */}
          <div className="p-4 border-b border-slate-800">
            <h2 className="text-base font-bold text-white font-display flex items-center justify-between">
              <span>Mensagens Angola Connect</span>
              <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Tempo Real
              </span>
            </h2>

            {/* Search */}
            <div className="relative mt-3">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Pesquisar conversas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40">
            {filteredConversations.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                Nenhuma conversa encontrada.
              </div>
            ) : (
              filteredConversations.map((conv) => {
                const isGroup = conv.type === 'group';
                const other = conv.otherUsers?.[0];
                const convTitle = isGroup ? conv.name : (other?.name || 'Utilizador');
                const convAvatar = isGroup ? conv.avatar : (other?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg');
                const isOnline = other ? onlineUsers.includes(other.id) : false;
                const isSelected = activeConversation?.id === conv.id;

                return (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConversation(conv)}
                    className={`w-full p-3.5 text-left flex items-center gap-3 transition-colors ${isSelected ? 'bg-slate-800/70 border-l-2 border-amber-400' : 'hover:bg-slate-900/60'}`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={convAvatar}
                        alt={convTitle}
                        className="w-11 h-11 rounded-full object-cover ring-1 ring-slate-800"
                      />
                      {!isGroup && isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-slate-950" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <p className="font-semibold text-xs text-white truncate">{convTitle}</p>
                        <span className="text-[10px] text-slate-500 shrink-0">
                          {conv.lastMessageTime ? new Date(conv.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-[11px] text-slate-400 truncate">
                          {conv.lastMessage || 'Conversa vazia'}
                        </p>
                        {conv.unreadCount && conv.unreadCount > 0 ? (
                          <span className="w-4 h-4 bg-amber-500 text-slate-950 text-[10px] font-bold rounded-full flex items-center justify-center shrink-0 ml-1">
                            {conv.unreadCount}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>

        </aside>

        {/* RIGHT PANE: Active Chat Conversation (8 cols) */}
        {activeConversation ? (
          <main className="md:col-span-8 flex flex-col h-full bg-slate-900">

            {/* Chat Header */}
            <div className="p-3.5 px-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveConversation(null)}
                  className="p-1 md:hidden text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="relative">
                  <img
                    src={activeConversation.type === 'group' ? activeConversation.avatar : (targetUser?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg')}
                    alt="Chat avatar"
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-700"
                  />
                  {activeConversation.type === 'direct' && isTargetOnline && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-slate-900" />
                  )}
                </div>

                <div>
                  <h3 className="font-bold text-sm text-white font-display">
                    {activeConversation.type === 'group' ? activeConversation.name : (targetUser?.name || 'Conversa')}
                  </h3>
                  <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    {isTypingRemote ? (
                      <span className="text-amber-400 font-medium italic animate-pulse">a escrever...</span>
                    ) : activeConversation.type === 'direct' ? (
                      isTargetOnline ? (
                        <span className="text-emerald-400 font-medium">Online</span>
                      ) : (
                        <span>Visto recentemente · 🇦🇴 {targetUser?.province}</span>
                      )
                    ) : (
                      <span>{activeConversation.participantIds.length} membros</span>
                    )}
                  </p>
                </div>
              </div>

              {/* Call triggers & Options */}
              <div className="flex items-center gap-1.5">
                {targetUser && (
                  <>
                    <button
                      onClick={() => onStartCall(targetUser, 'audio')}
                      className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 text-slate-300 hover:text-amber-400 hover:bg-slate-700 transition-colors"
                      title="Chamada de Voz"
                    >
                      <Phone className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onStartCall(targetUser, 'video')}
                      className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 text-slate-300 hover:text-amber-400 hover:bg-slate-700 transition-colors"
                      title="Chamada de Vídeo"
                    >
                      <Video className="w-4 h-4" />
                    </button>
                  </>
                )}

                <div className="relative">
                  <button
                    onClick={() => setShowOptions(prev => !prev)}
                    className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>

                  {showOptions && (
                    <div
                      className="absolute right-0 mt-2 w-48 bg-slate-950 border border-slate-800 rounded-xl shadow-xl py-1 text-xs text-slate-200 z-30"
                      onClick={() => setShowOptions(false)}
                    >
                      <button
                        onClick={handleSendLocation}
                        className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2"
                      >
                        <MapPin className="w-3.5 h-3.5 text-amber-400" />
                        <span>Partilhar Localização</span>
                      </button>
                      <button
                        onClick={() => {
                          const min = prompt('Temporizador de mensagens temporárias em minutos (0 para desativar):', '60');
                          if (min !== null) setEphemeralTimer(parseInt(min, 10) || 0);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2"
                      >
                        <Clock className="w-3.5 h-3.5 text-blue-400" />
                        <span>Mensagens Temporárias</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-950/40">
              {messages.map((msg) => {
                const isMe = msg.senderId === currentUser?.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group`}
                  >
                    {/* Reply To quote if any */}
                    {msg.replyTo && (
                      <div className={`text-[10px] p-1.5 px-3 mb-1 rounded-lg border max-w-xs truncate ${isMe ? 'bg-amber-950/30 border-amber-600/30 text-amber-200' : 'bg-slate-800 border-slate-700 text-slate-300'}`}>
                        <span className="font-semibold block">{msg.replyTo.senderName}:</span>
                        <span>{msg.replyTo.text}</span>
                      </div>
                    )}

                    {/* Main Message Bubble */}
                    <div
                      className={`relative max-w-sm sm:max-w-md rounded-2xl p-3 shadow-md ${
                        isMe
                          ? 'bg-amber-500 text-slate-950 rounded-br-xs font-normal'
                          : 'bg-slate-800 text-white rounded-bl-xs'
                      }`}
                    >
                      {/* Pinned badge */}
                      {msg.isPinned && (
                        <div className="flex items-center gap-1 text-[10px] font-bold text-amber-300 mb-1">
                          <Pin className="w-3 h-3 fill-amber-300" />
                          <span>Mensagem Fixada</span>
                        </div>
                      )}

                      {/* Content by Type */}
                      {msg.type === 'text' && (
                        <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-line">{msg.text}</p>
                      )}

                      {msg.type === 'image' && msg.mediaUrl && (
                        <div className="space-y-1">
                          <img
                            src={msg.mediaUrl}
                            alt="Foto enviada"
                            className="rounded-xl max-h-60 object-cover w-full"
                          />
                          {msg.text && msg.text !== msg.fileName && (
                            <p className="text-xs mt-1">{msg.text}</p>
                          )}
                        </div>
                      )}

                      {msg.type === 'video' && msg.mediaUrl && (
                        <video src={msg.mediaUrl} controls className="rounded-xl max-h-60 w-full" />
                      )}

                      {msg.type === 'audio' && msg.mediaUrl && (
                        <div className="flex items-center gap-2 py-1">
                          <audio src={msg.mediaUrl} controls className="h-8 max-w-[220px]" />
                        </div>
                      )}

                      {msg.type === 'file' && (
                        <div className="flex items-center gap-2.5 p-2 bg-black/10 rounded-xl">
                          <FileText className="w-5 h-5 shrink-0" />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-semibold truncate">{msg.fileName || 'Documento'}</p>
                            <p className="text-[10px] opacity-75">{msg.fileSize || 'Ficheiro'}</p>
                          </div>
                          {msg.mediaUrl && (
                            <a
                              href={msg.mediaUrl}
                              download
                              className="p-1 hover:bg-black/20 rounded text-xs"
                            >
                              <Download className="w-4 h-4" />
                            </a>
                          )}
                        </div>
                      )}

                      {msg.type === 'location' && msg.location && (
                        <div className="space-y-1.5">
                          <div className="w-full h-24 bg-slate-900 rounded-lg flex items-center justify-center border border-slate-700">
                            <MapPin className="w-6 h-6 text-red-500" />
                          </div>
                          <p className="text-xs font-semibold">{msg.location.address}</p>
                        </div>
                      )}

                      {/* Timestamp & Status Icon */}
                      <div className={`flex items-center justify-end gap-1 text-[9px] mt-1 ${isMe ? 'text-slate-900/80 font-medium' : 'text-slate-400'}`}>
                        <span>
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {isMe && (
                          <span>
                            {msg.status === 'read' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-blue-900" />
                            ) : msg.status === 'delivered' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-slate-800" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-slate-800" />
                            )}
                          </span>
                        )}
                      </div>

                      {/* Reactions display */}
                      {msg.reactions && msg.reactions.length > 0 && (
                        <div className="absolute -bottom-2.5 right-2 flex items-center bg-slate-900 border border-slate-700 rounded-full px-1.5 py-0.2 shadow-sm text-xs">
                          {msg.reactions.map((r, i) => (
                            <span key={i}>{r.emoji}</span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Hover Quick Actions */}
                    <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 mt-1 text-slate-400 text-xs transition-opacity">
                      <button
                        onClick={() => handleReactToMessage(msg.id, '❤️')}
                        className="hover:scale-125 transition-transform"
                      >
                        ❤️
                      </button>
                      <button
                        onClick={() => handleReactToMessage(msg.id, '👍')}
                        className="hover:scale-125 transition-transform"
                      >
                        👍
                      </button>
                      <button
                        onClick={() => handleReactToMessage(msg.id, '🇦🇴')}
                        className="hover:scale-125 transition-transform"
                      >
                        🇦🇴
                      </button>
                      <button
                        onClick={() => setReplyMessage(msg)}
                        className="p-1 hover:text-white"
                        title="Responder"
                      >
                        <Reply className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handlePinMessage(msg.id)}
                        className="p-1 hover:text-white"
                        title="Fixar"
                      >
                        <Pin className="w-3 h-3" />
                      </button>
                      {isMe && (
                        <button
                          onClick={() => handleDeleteMessage(msg.id, true)}
                          className="p-1 hover:text-red-400"
                          title="Eliminar para todos"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Active Reply Banner */}
            {replyMessage && (
              <div className="p-2 px-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
                <div className="flex items-center gap-2 truncate">
                  <Reply className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">A responder a: "{replyMessage.text}"</span>
                </div>
                <button onClick={() => setReplyMessage(null)} className="p-1 text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Input Bar */}
            <div className="p-3 bg-slate-950 border-t border-slate-800">
              {isRecording ? (
                <div className="flex items-center justify-between p-2 bg-red-950/40 border border-red-800/60 rounded-xl text-red-400 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                    <span>A gravar áudio de voz: <strong>{recordingSeconds}s</strong></span>
                  </div>
                  <button
                    onClick={handleStopRecording}
                    className="flex items-center gap-1.5 px-3 py-1 bg-red-600 text-white rounded-lg font-bold hover:bg-red-500"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Terminar e Enviar</span>
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
                  className="flex items-center gap-2"
                >
                  {/* File attach */}
                  <label className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 cursor-pointer transition-colors">
                    <Paperclip className="w-4 h-4" />
                    <input
                      type="file"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>

                  <input
                    type="text"
                    placeholder="Escreva uma mensagem no Angola Connect..."
                    value={text}
                    onChange={handleTextChange}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                  />

                  {/* Audio record button */}
                  <button
                    type="button"
                    onClick={handleStartRecording}
                    className="p-2 text-slate-400 hover:text-amber-400 rounded-xl hover:bg-slate-800 transition-colors"
                    title="Gravar mensagem de voz"
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  {/* Send */}
                  <button
                    type="submit"
                    disabled={!text.trim()}
                    className="w-10 h-10 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center justify-center transition-colors disabled:opacity-30 shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>

          </main>
        ) : (
          <div className="hidden md:flex md:col-span-8 flex-col items-center justify-center p-12 text-center text-slate-500">
            <div className="w-16 h-16 rounded-full bg-slate-800/80 flex items-center justify-center mb-3 text-amber-400">
              <Phone className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-white text-base">Mensagens em Tempo Real</h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              Selecione uma conversa à esquerda para conversar, enviar fotos, áudios e fazer chamadas de voz e vídeo.
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
