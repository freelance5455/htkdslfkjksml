import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { ClimbEntry, ClimbingStyle } from '../types/climbing';
import { BarChart3, PieChart as PieIcon } from 'lucide-react';
import { useClimbing } from '../context/ClimbingContext';

interface DashboardChartsProps {
  climbs: ClimbEntry[];
}

export const DashboardCharts: React.FC<DashboardChartsProps> = ({ climbs }) => {
  const { theme } = useClimbing();
  const isDark = theme === 'dark';

  // 1. Data for "Total Climbs per Month"
  const monthlyData = useMemo(() => {
    const monthCounts: Record<string, number> = {};

    // Collect counts by YYYY-MM
    climbs.forEach(c => {
      if (c.date) {
        const ym = c.date.substring(0, 7); // e.g., '2026-03'
        monthCounts[ym] = (monthCounts[ym] || 0) + 1;
      }
    });

    // If climbs are present, sort chronological
    const sortedKeys = Object.keys(monthCounts).sort();

    // If there are fewer than 4 months, populate standard recent 4 months so chart looks neat
    if (sortedKeys.length === 0) {
      const now = new Date();
      const demoKeys = [];
      for (let i = 3; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        demoKeys.push(ym);
      }
      return demoKeys.map(ym => {
        const [y, m] = ym.split('-');
        const d = new Date(parseInt(y, 10), parseInt(m, 10) - 1, 1);
        return {
          monthKey: ym,
          monthName: d.toLocaleString('default', { month: 'short' }),
          climbs: 0
        };
      });
    }

    return sortedKeys.map(ym => {
      const [y, m] = ym.split('-');
      const d = new Date(parseInt(y, 10), parseInt(m, 10) - 1, 1);
      return {
        monthKey: ym,
        monthName: `${d.toLocaleString('default', { month: 'short' })} '${y.substring(2)}`,
        climbs: monthCounts[ym]
      };
    });
  }, [climbs]);

  // 2. Data for "Distribution of Climb Styles"
  const styleData = useMemo(() => {
    const counts: Record<ClimbingStyle, number> = {
      'Top Rope': 0,
      Lead: 0,
      Bouldering: 0,
      'Auto-Belay': 0
    };

    climbs.forEach(c => {
      if (counts[c.style] !== undefined) {
        counts[c.style] += 1;
      }
    });

    const colors: Record<ClimbingStyle, string> = {
      'Top Rope': '#ea580c', // Orange
      Lead: '#c2410c', // Dark orange
      Bouldering: '#f97316', // Vibrant orange
      'Auto-Belay': '#fb923c' // Light orange
    };

    const total = climbs.length;

    return (['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'] as ClimbingStyle[]).map(style => ({
      name: style,
      value: counts[style],
      percentage: total > 0 ? Math.round((counts[style] / total) * 100) : 0,
      color: colors[style]
    }));
  }, [climbs]);

  const hasData = climbs.length > 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 w-full max-w-full">
      {/* 1. Bar Chart: Total Climbs per Month */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
        <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/80 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Total Climbs per Month</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Monthly progression volume</p>
            </div>
          </div>
          <span className="text-[10px] font-mono text-orange-600 dark:text-orange-400 font-bold bg-orange-50 dark:bg-orange-950/50 px-2 py-0.5 rounded">
            Recharts
          </span>
        </div>

        <div className="py-4 h-64 w-full">
          {!hasData ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 text-xs">
              <p className="font-semibold">No monthly data logged yet</p>
              <p className="text-[11px]">Ascents will chart across months here</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis
                  dataKey="monthName"
                  stroke={isDark ? '#94a3b8' : '#64748b'}
                  fontSize={11}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  stroke={isDark ? '#94a3b8' : '#64748b'}
                  fontSize={11}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: isDark ? '#0f172a' : '#ffffff',
                    borderColor: isDark ? '#334155' : '#cbd5e1',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: isDark ? '#f8fafc' : '#0f172a'
                  }}
                  formatter={(val: any) => [`${val} climbs`, 'Total Volume']}
                />
                <Bar
                  dataKey="climbs"
                  fill="#ea580c"
                  radius={[4, 4, 0, 0]}
                  name="Climbs"
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 flex items-center justify-between font-mono">
          <span>Total ascents: {climbs.length}</span>
          <span>{monthlyData.length} months tracked</span>
        </div>
      </div>

      {/* 2. Pie Chart: Distribution of Climb Styles */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
        <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/80 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold">
              <PieIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Climb Style Distribution</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Discipline balance</p>
            </div>
          </div>
          <span className="text-[10px] font-mono text-orange-600 dark:text-orange-400 font-bold bg-orange-50 dark:bg-orange-950/50 px-2 py-0.5 rounded">
            Recharts
          </span>
        </div>

        <div className="py-4 h-64 w-full">
          {!hasData ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 text-xs">
              <p className="font-semibold">No climb styles recorded</p>
              <p className="text-[11px]">Styles breakdown will render after logging</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={styleData.filter(s => s.value > 0)}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={3}
                  label={(entry: any) => `${entry.name} (${Math.round((entry.percent || 0) * 100)}%)`}
                  labelLine={false}
                >
                  {styleData.map(entry => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: isDark ? '#0f172a' : '#ffffff',
                    borderColor: isDark ? '#334155' : '#cbd5e1',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                  formatter={(val: any, name: any) => [`${val} climbs`, name]}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 flex items-center justify-between font-mono">
          <span>Top Rope / Lead / Boulder / Auto-Belay</span>
          <span>100% total</span>
        </div>
      </div>
    </div>
  );
};
