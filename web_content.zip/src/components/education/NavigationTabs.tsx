import React from 'react';
import { BookOpen, Calculator, Atom, BookHeart, Video, Trophy, Palette } from 'lucide-react';
import { playPop } from '../../utils/soundEffects';

import { EducationTab } from '../../types/education';

export type MainTab = 'letters' | 'math' | 'science' | 'stories' | 'videos' | 'quiz' | 'quizzes' | 'whiteboard';

interface NavigationTabsProps {
  activeTab: EducationTab | MainTab;
  onChangeTab?: (tab: any) => void;
  onSelectTab?: (tab: any) => void;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({ activeTab, onChangeTab, onSelectTab }) => {
  const handleTabClick = (tabId: string) => {
    if (onChangeTab) onChangeTab(tabId);
    if (onSelectTab) onSelectTab(tabId);
  };
  const tabs = [
    {
      id: 'letters' as MainTab,
      title: 'الْحُرُوفُ وَالْكَلِمَاتُ',
      subtitle: 'حروف • كلمات • جمل',
      icon: BookOpen,
      emoji: '🔤',
      color: 'from-amber-500 to-orange-500',
      activeBg: 'bg-amber-500 text-white shadow-md shadow-amber-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-amber-50 border-amber-200'
    },
    {
      id: 'math' as MainTab,
      title: 'الْحِسَابُ وَالرِّيَاضِيَّاتُ',
      subtitle: 'جمع • طرح • ضرب • قيمة',
      icon: Calculator,
      emoji: '🧮',
      color: 'from-blue-500 to-indigo-600',
      activeBg: 'bg-blue-600 text-white shadow-md shadow-blue-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-blue-50 border-blue-200'
    },
    {
      id: 'science' as MainTab,
      title: 'الْعُلُومُ وَالِاسْتِكْشَافُ',
      subtitle: 'فضاء • جسم الإنسان • نبات',
      icon: Atom,
      emoji: '🔬',
      color: 'from-emerald-500 to-teal-600',
      activeBg: 'bg-emerald-600 text-white shadow-md shadow-emerald-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-emerald-50 border-emerald-200'
    },
    {
      id: 'stories' as MainTab,
      title: 'الْقِصَصُ التَّعْلِيمِيَّةُ',
      subtitle: 'قصص مصورة ومسموعة',
      icon: BookHeart,
      emoji: '📖',
      color: 'from-pink-500 to-rose-600',
      activeBg: 'bg-pink-600 text-white shadow-md shadow-pink-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-pink-50 border-pink-200'
    },
    {
      id: 'videos' as MainTab,
      title: 'فِيدْيُوهَاتٌ هَادِفَةٌ',
      subtitle: 'أناشيد ودروس مرئية',
      icon: Video,
      emoji: '🎬',
      color: 'from-purple-500 to-violet-600',
      activeBg: 'bg-purple-600 text-white shadow-md shadow-purple-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-purple-50 border-purple-200'
    },
    {
      id: 'quizzes' as MainTab,
      title: 'الِاخْتِبَارَاتُ وَالتَّحَدِّيَاتُ',
      subtitle: 'تحديات ذكاء وجوائز',
      icon: Trophy,
      emoji: '🏆',
      color: 'from-yellow-500 to-amber-600',
      activeBg: 'bg-amber-600 text-white shadow-md shadow-amber-600/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-amber-50 border-amber-200'
    },
    {
      id: 'whiteboard' as MainTab,
      title: 'السَّبُّورَةُ السِّحْرِيَّةُ',
      subtitle: 'رسم وتدريب الخط',
      icon: Palette,
      emoji: '🎨',
      color: 'from-cyan-500 to-teal-600',
      activeBg: 'bg-cyan-600 text-white shadow-md shadow-cyan-500/25',
      inactiveBg: 'bg-white text-slate-700 hover:bg-cyan-50 border-cyan-200'
    }
  ];

  return (
    <nav aria-label="أقسام البرنامج التعليمي" className="w-full bg-amber-100/60 border-b border-amber-200 py-3 px-2 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto pb-1.5 pt-0.5 no-scrollbar">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id || (tab.id === 'quizzes' && activeTab === 'quiz');
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => {
                  playPop();
                  handleTabClick(tab.id === 'quizzes' ? 'quiz' : tab.id);
                }}
                className={`flex-shrink-0 flex items-center gap-2.5 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-2xl border transition-all text-right ${
                  isActive
                    ? tab.activeBg + ' scale-[1.02]'
                    : tab.inactiveBg
                }`}
              >
                <span className="text-xl sm:text-2xl">{tab.emoji}</span>
                <div className="flex flex-col">
                  <span className="font-extrabold text-xs sm:text-sm tracking-wide whitespace-nowrap">
                    {tab.title}
                  </span>
                  <span className={`text-[10px] sm:text-[11px] whitespace-nowrap ${isActive ? 'text-white/90' : 'text-slate-500'}`}>
                    {tab.subtitle}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
