import React, { useState } from 'react';
import { Volume2, Sparkles, CheckCircle2, RotateCcw, ArrowRight, ArrowLeft, Star, Pencil, BookOpen, Layers } from 'lucide-react';
import { ARABIC_LETTERS, VOCABULARY_LIST, SENTENCE_EXERCISES } from '../../data/curriculumData';
import { LetterData, WordData, SentenceExercise, AgeGroup } from '../../types/education';
import { speakArabic, playSuccess, playIncorrect, playPop, playStarTwinkle } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface LettersAndWordsModuleProps {
  ageGroup: AgeGroup;
  onEarnStars: (amount: number) => void;
  onOpenWhiteboardWithLetter?: (letter: string) => void;
  onOpenWhiteboard?: (letter: string) => void;
}

export const LettersAndWordsModule: React.FC<LettersAndWordsModuleProps> = ({
  ageGroup,
  onEarnStars,
  onOpenWhiteboardWithLetter,
  onOpenWhiteboard
}) => {
  const handleOpenBoard = (char: string) => {
    if (onOpenWhiteboardWithLetter) onOpenWhiteboardWithLetter(char);
    if (onOpenWhiteboard) onOpenWhiteboard(char);
  };
  const [subTab, setSubTab] = useState<'letters' | 'words' | 'sentences'>('letters');
  
  // Letters state
  const [selectedLetter, setSelectedLetter] = useState<LetterData>(ARABIC_LETTERS[0]);
  const [activeVowel, setActiveVowel] = useState<'fatha' | 'damma' | 'kasra' | 'sukun'>('fatha');

  // Word spelling game state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const filteredWords = VOCABULARY_LIST.filter(w => selectedCategory === 'all' || w.category === selectedCategory);
  const [currentWordIndex, setCurrentWordIndex] = useState<number>(0);
  const currentWord = filteredWords[currentWordIndex] || filteredWords[0];
  const [spelledLetters, setSpelledLetters] = useState<string[]>([]);
  const [scrambledPool, setScrambledPool] = useState<{ id: string; letter: string; used: boolean }[]>([]);
  const [wordSuccess, setWordSuccess] = useState<boolean>(false);

  // Initialize or reset word game when word changes
  React.useEffect(() => {
    if (currentWord) {
      const letters = [...currentWord.letters];
      // Randomize scrambled pool
      const shuffled = letters
        .map((letter, idx) => ({ id: `${letter}-${idx}-${Math.random()}`, letter, used: false }))
        .sort(() => Math.random() - 0.5);
      setScrambledPool(shuffled);
      setSpelledLetters([]);
      setWordSuccess(false);
    }
  }, [currentWordIndex, selectedCategory]);

  // Handle letter click in spelling game
  const handlePickLetter = (item: { id: string; letter: string; used: boolean }) => {
    if (item.used || wordSuccess) return;
    playPop();

    const nextSpelled = [...spelledLetters, item.letter];
    const targetLetters = currentWord.letters;

    // Check if next letter matches current target position
    const currentIndex = spelledLetters.length;
    if (item.letter === targetLetters[currentIndex]) {
      setSpelledLetters(nextSpelled);
      // Mark as used
      setScrambledPool(prev => prev.map(p => p.id === item.id ? { ...p, used: true } : p));
      
      // Speak the letter
      speakArabic(item.letter);

      // Check if word completed
      if (nextSpelled.length === targetLetters.length) {
        setWordSuccess(true);
        playSuccess();
        playStarTwinkle();
        confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
        onEarnStars(2);
        // Pronounce full word
        setTimeout(() => {
          speakArabic(currentWord.tashkeel);
        }, 600);
      }
    } else {
      // Mistake
      playIncorrect();
      speakArabic('حاول مرة ثانية يا بطل');
    }
  };

  const handleResetWord = () => {
    playPop();
    setSpelledLetters([]);
    setScrambledPool(prev => prev.map(p => ({ ...p, used: false })));
    setWordSuccess(false);
  };

  // Sentences state
  const relevantSentences = SENTENCE_EXERCISES.filter(s => ageGroup === '5-7' ? s.ageGroup === '5-7' : true);
  const [sentenceIndex, setSentenceIndex] = useState<number>(0);
  const currentSentence = relevantSentences[sentenceIndex] || relevantSentences[0];
  const [selectedWordsInOrder, setSelectedWordsInOrder] = useState<string[]>([]);
  const [availableWordsPool, setAvailableWordsPool] = useState<{ id: string; word: string; used: boolean }[]>([]);
  const [sentenceSuccess, setSentenceSuccess] = useState<boolean>(false);

  React.useEffect(() => {
    if (currentSentence) {
      const pool = currentSentence.scrambledWords.map((w, idx) => ({
        id: `${w}-${idx}-${Math.random()}`,
        word: w,
        used: false
      }));
      setAvailableWordsPool(pool);
      setSelectedWordsInOrder([]);
      setSentenceSuccess(false);
    }
  }, [sentenceIndex, ageGroup]);

  const handlePickSentenceWord = (item: { id: string; word: string; used: boolean }) => {
    if (item.used || sentenceSuccess) return;
    playPop();

    const nextOrder = [...selectedWordsInOrder, item.word];
    const targetWords = currentSentence.words;
    const targetWordAtPos = targetWords[selectedWordsInOrder.length];

    if (item.word === targetWordAtPos) {
      setSelectedWordsInOrder(nextOrder);
      setAvailableWordsPool(prev => prev.map(p => p.id === item.id ? { ...p, used: true } : p));
      speakArabic(item.word);

      if (nextOrder.length === targetWords.length) {
        setSentenceSuccess(true);
        playSuccess();
        playStarTwinkle();
        confetti({ particleCount: 75, spread: 70, origin: { y: 0.5 } });
        onEarnStars(3);
        setTimeout(() => {
          speakArabic(currentSentence.sentence);
        }, 700);
      }
    } else {
      playIncorrect();
      speakArabic('فكّر جيداً في الكلمة المناسبة');
    }
  };

  const handleResetSentence = () => {
    playPop();
    setSelectedWordsInOrder([]);
    setAvailableWordsPool(prev => prev.map(p => ({ ...p, used: false })));
    setSentenceSuccess(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Sub navigation pills */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-amber-200 shadow-sm">
        <div className="flex items-center gap-2">
          <button
            id="subtab-letters"
            onClick={() => { playPop(); setSubTab('letters'); }}
            className={`px-4 py-2 rounded-xl text-sm sm:text-base font-bold transition-all flex items-center gap-2 ${
              subTab === 'letters'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-amber-50 text-slate-700 hover:bg-amber-100'
            }`}
          >
            <span>🔤</span>
            <span>الْحُرُوفُ وَالتَّشْكِيلُ (28)</span>
          </button>

          <button
            id="subtab-words"
            onClick={() => { playPop(); setSubTab('words'); }}
            className={`px-4 py-2 rounded-xl text-sm sm:text-base font-bold transition-all flex items-center gap-2 ${
              subTab === 'words'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-amber-50 text-slate-700 hover:bg-amber-100'
            }`}
          >
            <span>🧩</span>
            <span>لُعْبَةُ تَرْكِيبِ الْكَلِمَاتِ</span>
          </button>

          <button
            id="subtab-sentences"
            onClick={() => { playPop(); setSubTab('sentences'); }}
            className={`px-4 py-2 rounded-xl text-sm sm:text-base font-bold transition-all flex items-center gap-2 ${
              subTab === 'sentences'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-amber-50 text-slate-700 hover:bg-amber-100'
            }`}
          >
            <span>📖</span>
            <span>تَكْوِينُ الْجُمَلِ وَالْقِرَاءَةُ</span>
          </button>
        </div>

        <div className="text-xs sm:text-sm font-semibold text-amber-900 bg-amber-100/60 px-3 py-1.5 rounded-xl">
          اضغط على أي عنصر لسماع النطق الصوتي الفوري 🔊
        </div>
      </div>

      {/* 1. LETTERS EXPLORER */}
      {subTab === 'letters' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Detailed Letter Hero Card */}
          <div className="lg:col-span-5 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-300 rounded-3xl p-6 shadow-sm flex flex-col items-center text-center">
            
            {/* Letter Big Badge */}
            <div className={`w-36 h-36 sm:w-44 sm:h-44 rounded-3xl bg-gradient-to-tr ${selectedLetter.color} text-white flex items-center justify-center text-7xl sm:text-8xl font-extrabold shadow-lg mb-4 transform hover:scale-105 transition-transform relative group cursor-pointer`}
              onClick={() => {
                playPop();
                const vowelText = activeVowel === 'fatha' ? selectedLetter.withFatha :
                  activeVowel === 'damma' ? selectedLetter.withDamma :
                  activeVowel === 'kasra' ? selectedLetter.withKasra : selectedLetter.withSukun;
                speakArabic(`${selectedLetter.name}، ${vowelText}`);
              }}
              title="اضغط لسماع نطق الحرف"
            >
              <span>
                {activeVowel === 'fatha' && selectedLetter.withFatha}
                {activeVowel === 'damma' && selectedLetter.withDamma}
                {activeVowel === 'kasra' && selectedLetter.withKasra}
                {activeVowel === 'sukun' && selectedLetter.withSukun}
              </span>
              <div className="absolute -bottom-2 -right-2 bg-white text-slate-800 p-2 rounded-full shadow-md text-sm">
                <Volume2 className="w-5 h-5 text-amber-600" />
              </div>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-800 mb-1">
              حَرْفُ {selectedLetter.name} ({selectedLetter.letter})
            </h3>
            <p className="text-slate-500 text-sm font-medium mb-4">
              نطقه الصوتي: {selectedLetter.transliteration}
            </p>

            {/* Vowels / Tashkeel Selector */}
            <div className="w-full bg-white rounded-2xl p-3 border border-amber-200 shadow-inner mb-5">
              <span className="text-xs font-bold text-slate-600 block mb-2">
                اختر الحركة لسماع صوت الحرف:
              </span>
              <div className="grid grid-cols-4 gap-2">
                <button
                  id="vowel-fatha"
                  onClick={() => {
                    playPop();
                    setActiveVowel('fatha');
                    speakArabic(selectedLetter.withFatha);
                  }}
                  className={`py-2 rounded-xl font-bold text-lg transition-all border ${
                    activeVowel === 'fatha'
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                      : 'bg-amber-50 text-slate-700 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  {selectedLetter.withFatha}
                  <span className="block text-[11px] font-normal">فَتْحَة</span>
                </button>

                <button
                  id="vowel-damma"
                  onClick={() => {
                    playPop();
                    setActiveVowel('damma');
                    speakArabic(selectedLetter.withDamma);
                  }}
                  className={`py-2 rounded-xl font-bold text-lg transition-all border ${
                    activeVowel === 'damma'
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                      : 'bg-amber-50 text-slate-700 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  {selectedLetter.withDamma}
                  <span className="block text-[11px] font-normal">ضَمَّة</span>
                </button>

                <button
                  id="vowel-kasra"
                  onClick={() => {
                    playPop();
                    setActiveVowel('kasra');
                    speakArabic(selectedLetter.withKasra);
                  }}
                  className={`py-2 rounded-xl font-bold text-lg transition-all border ${
                    activeVowel === 'kasra'
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                      : 'bg-amber-50 text-slate-700 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  {selectedLetter.withKasra}
                  <span className="block text-[11px] font-normal">كَسْرَة</span>
                </button>

                <button
                  id="vowel-sukun"
                  onClick={() => {
                    playPop();
                    setActiveVowel('sukun');
                    speakArabic(selectedLetter.withSukun);
                  }}
                  className={`py-2 rounded-xl font-bold text-lg transition-all border ${
                    activeVowel === 'sukun'
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                      : 'bg-amber-50 text-slate-700 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  {selectedLetter.withSukun}
                  <span className="block text-[11px] font-normal">سُكُون</span>
                </button>
              </div>
            </div>

            {/* Example word card */}
            <div className="w-full bg-white p-4 rounded-2xl border border-amber-200 shadow-sm flex items-center gap-4 text-right mb-4">
              <span className="text-4xl sm:text-5xl p-2 bg-amber-100 rounded-2xl">{selectedLetter.exampleEmoji}</span>
              <div className="flex-1">
                <span className="text-xs font-bold text-amber-700 block">مِثَالٌ عَلَى الْحَرْفِ:</span>
                <span className="text-2xl font-black text-slate-800 block">{selectedLetter.exampleWord}</span>
                <p className="text-xs text-slate-600 font-medium">{selectedLetter.exampleMeaning}</p>
              </div>
              <button
                onClick={() => {
                  playPop();
                  speakArabic(selectedLetter.exampleWord);
                }}
                className="p-3 bg-amber-500 hover:bg-amber-600 text-white rounded-xl shadow-sm transition-all"
                title="استمع للمثال"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* Action buttons */}
            <div className="w-full flex items-center gap-2">
              <button
                id="listen-pronunciation-btn"
                onClick={() => {
                  playPop();
                  speakArabic(`${selectedLetter.name}، مِثْل: ${selectedLetter.exampleWord}`);
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <Volume2 className="w-4 h-4" />
                <span>نُطْقُ الْحَرْفِ وَالْمِثَالِ</span>
              </button>

              {(onOpenWhiteboardWithLetter || onOpenWhiteboard) && (
                <button
                  id="trace-letter-btn"
                  onClick={() => {
                    playPop();
                    handleOpenBoard(selectedLetter.letter);
                  }}
                  className="py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
                  title="تدرّب على رسم وكتابة هذا الحرف على السبورة"
                >
                  <Pencil className="w-4 h-4" />
                  <span>تَدْرِيبُ الْكِتَابَةِ</span>
                </button>
              )}
            </div>

          </div>

          {/* 28 Letters Grid */}
          <div className="lg:col-span-7 bg-white p-5 rounded-3xl border border-amber-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-extrabold text-slate-800 text-base sm:text-lg flex items-center gap-2">
                <span>🎨</span>
                <span>قَائِمَةُ الْحُرُوفِ الْهِجَائِيَّةِ الْعَرَبِيَّةِ (اخْتَرِ حَرْفاً)</span>
              </h4>
              <span className="text-xs text-amber-700 font-bold bg-amber-100 px-2.5 py-1 rounded-full">
                28 حَرْفاً
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5 sm:gap-3">
              {ARABIC_LETTERS.map((letterItem) => {
                const isSelected = selectedLetter.letter === letterItem.letter;
                return (
                  <button
                    key={letterItem.letter}
                    id={`letter-item-${letterItem.letter}`}
                    onClick={() => {
                      playPop();
                      setSelectedLetter(letterItem);
                      speakArabic(letterItem.name);
                    }}
                    className={`aspect-square rounded-2xl flex flex-col items-center justify-center border-2 transition-all transform hover:-translate-y-1 ${
                      isSelected
                        ? 'bg-amber-500 text-white border-amber-600 shadow-md scale-105 ring-2 ring-amber-400'
                        : 'bg-amber-50/70 hover:bg-amber-100/90 text-slate-800 border-amber-200'
                    }`}
                  >
                    <span className="text-2xl sm:text-3xl font-extrabold">
                      {letterItem.letter}
                    </span>
                    <span className={`text-[10px] sm:text-[11px] font-bold ${isSelected ? 'text-amber-100' : 'text-slate-500'}`}>
                      {letterItem.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* 2. WORDS & SPELLING PUZZLE */}
      {subTab === 'words' && (
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Category Filter */}
          <div className="flex flex-wrap items-center justify-center gap-2 bg-white p-2.5 rounded-2xl border border-amber-200">
            {[
              { id: 'all', label: 'الْكُلُّ', icon: '🌟' },
              { id: 'animals', label: 'الْحَيَوَانَاتُ', icon: '🦁' },
              { id: 'fruits', label: 'الْفَوَاكِهُ', icon: '🍎' },
              { id: 'nature', label: 'الطَّبِيعَةُ وَالْكَوْنُ', icon: '🪐' },
              { id: 'professions', label: 'الْمِهَنُ وَالْعُلُومُ', icon: '🧑‍🚀' }
            ].map(cat => (
              <button
                key={cat.id}
                id={`cat-filter-${cat.id}`}
                onClick={() => {
                  playPop();
                  setSelectedCategory(cat.id);
                  setCurrentWordIndex(0);
                }}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center gap-1.5 ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-white shadow-sm'
                    : 'bg-amber-50 text-slate-700 hover:bg-amber-100'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Spelling Game Arena */}
          <div className="bg-white rounded-3xl border-2 border-amber-300 p-6 sm:p-8 shadow-sm text-center relative overflow-hidden">
            
            {/* Top Navigation for Words */}
            <div className="flex items-center justify-between mb-6">
              <button
                id="prev-word-btn"
                onClick={() => {
                  playPop();
                  setCurrentWordIndex((prev) => (prev > 0 ? prev - 1 : filteredWords.length - 1));
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 hover:bg-amber-200 font-bold text-xs sm:text-sm"
              >
                <ArrowRight className="w-4 h-4" />
                <span>السَّابِق</span>
              </button>

              <div className="text-xs sm:text-sm font-bold text-slate-500">
                الْكَلِمَةُ {currentWordIndex + 1} مِنْ {filteredWords.length}
              </div>

              <button
                id="next-word-btn"
                onClick={() => {
                  playPop();
                  setCurrentWordIndex((prev) => (prev < filteredWords.length - 1 ? prev + 1 : 0));
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 hover:bg-amber-200 font-bold text-xs sm:text-sm"
              >
                <span>التَّالِي</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Target Word Illustration */}
            <div className="inline-block p-4 sm:p-6 bg-amber-50 rounded-3xl border border-amber-200 mb-4">
              <span className="text-6xl sm:text-8xl block animate-pulse">
                {currentWord.emoji}
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-800 mb-2">
              {currentWord.meaning}
            </h3>

            {/* Target Slots for Letters */}
            <div className="flex items-center justify-center gap-2 sm:gap-3 my-6" dir="rtl">
              {currentWord.letters.map((char, index) => {
                const filledChar = spelledLetters[index];
                return (
                  <div
                    key={index}
                    className={`w-14 h-16 sm:w-16 sm:h-20 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl font-extrabold border-2 transition-all ${
                      filledChar
                        ? 'bg-emerald-500 text-white border-emerald-600 shadow-md scale-105'
                        : 'bg-slate-100 text-slate-400 border-dashed border-slate-300'
                    }`}
                  >
                    {filledChar || '?'}
                  </div>
                );
              })}
            </div>

            {/* Scrambled letter buttons pool */}
            <div className="bg-amber-50/80 p-5 rounded-2xl border border-amber-200 mb-6">
              <p className="text-xs sm:text-sm font-bold text-amber-900 mb-3">
                اضغط على الحروف بالترتيب الصحيح لتكوين الكلمة:
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-4">
                {scrambledPool.map((item) => (
                  <button
                    key={item.id}
                    id={`scrambled-letter-${item.letter}`}
                    disabled={item.used || wordSuccess}
                    onClick={() => handlePickLetter(item)}
                    className={`w-12 h-14 sm:w-14 sm:h-16 rounded-2xl font-extrabold text-2xl sm:text-3xl shadow-md transition-all ${
                      item.used
                        ? 'bg-slate-200 text-slate-400 opacity-40 cursor-not-allowed'
                        : 'bg-white hover:bg-amber-100 text-amber-950 border-2 border-amber-300 hover:scale-105 active:scale-95'
                    }`}
                  >
                    {item.letter}
                  </button>
                ))}
              </div>
            </div>

            {/* Success state celebration */}
            {wordSuccess && (
              <div className="bg-emerald-50 border-2 border-emerald-400 rounded-2xl p-4 mb-4 flex flex-col items-center animate-bounce">
                <span className="text-3xl mb-1">🎉🌟👏</span>
                <span className="text-lg sm:text-xl font-black text-emerald-800">
                  أَحْسَنْتَ يَا بَطَل! الْكَلِمَةُ هِيَ: {currentWord.tashkeel}
                </span>
                <span className="text-xs font-bold text-emerald-600 mt-1">
                  ربحت +2 نجمة ذهبية ⭐
                </span>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={handleResetWord}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إِعَادَةُ الْمُحَاوَلَةِ</span>
              </button>

              <button
                onClick={() => {
                  playPop();
                  speakArabic(currentWord.tashkeel);
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm"
              >
                <Volume2 className="w-4 h-4" />
                <span>سَمَاعُ الْكَلِمَةِ</span>
              </button>
            </div>

          </div>

        </div>
      )}

      {/* 3. SENTENCE ARRANGER & READING */}
      {subTab === 'sentences' && (
        <div className="max-w-4xl mx-auto space-y-6">
          
          <div className="bg-white rounded-3xl border-2 border-amber-300 p-6 sm:p-8 shadow-sm">
            
            <div className="flex items-center justify-between mb-6">
              <span className="px-3 py-1 bg-amber-100 text-amber-900 rounded-full text-xs font-bold">
                تَمْرِينُ {sentenceIndex + 1} مِنْ {relevantSentences.length}
              </span>
              <div className="text-3xl">{currentSentence.emoji}</div>
            </div>

            <h3 className="text-lg sm:text-xl font-black text-slate-800 text-center mb-1">
              رَتِّبِ الْكَلِمَاتِ لِتَكْوِينَ جُمْلَةٍ مُفِيدَةٍ وَصَحِيحَةٍ:
            </h3>
            <p className="text-xs text-slate-500 text-center mb-6">
              المعنى: {currentSentence.meaning}
            </p>

            {/* Answer Display Box */}
            <div className="min-h-20 bg-amber-50/80 border-2 border-dashed border-amber-300 rounded-2xl p-4 flex flex-wrap items-center justify-center gap-2 mb-6">
              {selectedWordsInOrder.length === 0 ? (
                <span className="text-slate-400 text-sm font-medium">
                  اضغط على الكلمات بالأسفل بالترتيب الصحيح لتظهر هنا...
                </span>
              ) : (
                selectedWordsInOrder.map((word, idx) => (
                  <span
                    key={idx}
                    className="px-4 py-2 bg-amber-500 text-white rounded-xl font-black text-base sm:text-lg shadow-sm animate-fade-in"
                  >
                    {word}
                  </span>
                ))
              )}
            </div>

            {/* Scrambled word bank */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3 mb-6">
              {availableWordsPool.map(item => (
                <button
                  key={item.id}
                  id={`sentence-word-${item.word}`}
                  disabled={item.used || sentenceSuccess}
                  onClick={() => handlePickSentenceWord(item)}
                  className={`px-4 py-2.5 rounded-2xl font-black text-base sm:text-lg shadow-sm transition-all ${
                    item.used
                      ? 'bg-slate-200 text-slate-400 opacity-40 cursor-not-allowed'
                      : 'bg-white hover:bg-amber-100 text-slate-800 border-2 border-amber-300 hover:scale-105 active:scale-95'
                  }`}
                >
                  {item.word}
                </button>
              ))}
            </div>

            {/* Success Banner */}
            {sentenceSuccess && (
              <div className="bg-emerald-50 border-2 border-emerald-400 rounded-2xl p-5 mb-6 text-center animate-bounce">
                <span className="text-3xl mb-1 block">🏆🌟</span>
                <h4 className="text-xl font-black text-emerald-800 mb-1">
                  أَحْسَنْتَ يَا عَبْقَرِيَّ الْقِرَاءَةِ!
                </h4>
                <p className="text-base font-extrabold text-emerald-900">
                  {currentSentence.sentence}
                </p>
                <span className="text-xs font-bold text-emerald-600 mt-2 block">
                  ربحت +3 نجوم ذهبية ⭐
                </span>
              </div>
            )}

            {/* Controls */}
            <div className="flex items-center justify-between border-t border-amber-100 pt-4">
              <button
                onClick={handleResetSentence}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إِعَادَةُ التَّرْتِيبِ</span>
              </button>

              <button
                onClick={() => {
                  playPop();
                  speakArabic(currentSentence.sentence);
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5"
              >
                <Volume2 className="w-4 h-4" />
                <span>سَمَاعُ الْجُمْلَةِ كَامِلَةً</span>
              </button>

              <button
                onClick={() => {
                  playPop();
                  setSentenceIndex((prev) => (prev < relevantSentences.length - 1 ? prev + 1 : 0));
                }}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5"
              >
                <span>الْجُمْلَةُ التَّالِيَةُ</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
