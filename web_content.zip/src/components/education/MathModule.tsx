import React, { useState } from 'react';
import { Calculator, Plus, Minus, X, Layers, Sparkles, Volume2, RefreshCw, Star, CheckCircle, HelpCircle } from 'lucide-react';
import { PLACE_VALUE_PROBLEMS } from '../../data/curriculumData';
import { PlaceValueProblem, AgeGroup } from '../../types/education';
import { speakArabic, playSuccess, playIncorrect, playPop, playStarTwinkle } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface MathModuleProps {
  ageGroup: AgeGroup;
  onEarnStars: (amount: number) => void;
}

export const MathModule: React.FC<MathModuleProps> = ({ ageGroup, onEarnStars }) => {
  const [subTab, setSubTab] = useState<'counting' | 'addition' | 'subtraction' | 'multiplication' | 'place_value'>(
    ageGroup === '5-7' ? 'counting' : 'multiplication'
  );

  // 1. Counting state
  const [countingTarget, setCountingTarget] = useState<number>(7);
  const [countedItems, setCountedItems] = useState<number[]>([]);
  const countingItemType = '🍎';

  const handleTapCountItem = (index: number) => {
    playPop();
    if (countedItems.includes(index)) {
      setCountedItems(prev => prev.filter(i => i !== index));
    } else {
      const nextCounted = [...countedItems, index];
      setCountedItems(nextCounted);
      speakArabic(`${nextCounted.length}`);
      if (nextCounted.length === countingTarget) {
        playSuccess();
        playStarTwinkle();
        confetti({ particleCount: 50, spread: 50 });
        onEarnStars(2);
      }
    }
  };

  // 2. Addition & Subtraction State
  const [num1, setNum1] = useState<number>(ageGroup === '5-7' ? 4 : 15);
  const [num2, setNum2] = useState<number>(ageGroup === '5-7' ? 3 : 8);
  const [userMathAnswer, setUserMathAnswer] = useState<string>('');
  const [mathFeedback, setMathFeedback] = useState<'correct' | 'wrong' | null>(null);

  const generateNewMathProblem = (isAdd: boolean) => {
    playPop();
    setUserMathAnswer('');
    setMathFeedback(null);
    if (ageGroup === '5-7') {
      if (isAdd) {
        setNum1(Math.floor(Math.random() * 6) + 1);
        setNum2(Math.floor(Math.random() * 5) + 1);
      } else {
        const a = Math.floor(Math.random() * 8) + 3;
        const b = Math.floor(Math.random() * (a - 1)) + 1;
        setNum1(a);
        setNum2(b);
      }
    } else {
      if (isAdd) {
        setNum1(Math.floor(Math.random() * 40) + 10);
        setNum2(Math.floor(Math.random() * 40) + 5);
      } else {
        const a = Math.floor(Math.random() * 60) + 20;
        const b = Math.floor(Math.random() * (a - 5)) + 5;
        setNum1(a);
        setNum2(b);
      }
    }
  };

  const handleCheckMath = (expected: number) => {
    const val = parseInt(userMathAnswer, 10);
    if (isNaN(val)) return;

    if (val === expected) {
      setMathFeedback('correct');
      playSuccess();
      playStarTwinkle();
      confetti({ particleCount: 60, spread: 60 });
      onEarnStars(3);
      speakArabic(`ممتاز! الإجابة الصحيحة هي ${expected}`);
    } else {
      setMathFeedback('wrong');
      playIncorrect();
      speakArabic(`حاول ثانية! الإجابة ليست ${val}`);
    }
  };

  // 3. Multiplication Table & Speed Drill
  const [selectedTable, setSelectedTable] = useState<number>(5);
  const [drillFactor, setDrillFactor] = useState<number>(4);
  const [drillAnswer, setDrillAnswer] = useState<string>('');
  const [drillFeedback, setDrillFeedback] = useState<'correct' | 'wrong' | null>(null);

  const handleCheckDrill = () => {
    const expected = selectedTable * drillFactor;
    const val = parseInt(drillAnswer, 10);
    if (val === expected) {
      setDrillFeedback('correct');
      playSuccess();
      playStarTwinkle();
      confetti({ particleCount: 50, spread: 55 });
      onEarnStars(3);
      speakArabic(`رائع! ${selectedTable} ضرب ${drillFactor} يساوي ${expected}`);
      setTimeout(() => {
        setDrillFactor(Math.floor(Math.random() * 10) + 1);
        setDrillAnswer('');
        setDrillFeedback(null);
      }, 1500);
    } else {
      setDrillFeedback('wrong');
      playIncorrect();
      speakArabic(`حاول مرة أخرى يا بطل! فكر في ${selectedTable} مكررة ${drillFactor} مرات`);
    }
  };

  // 4. Place Value State (القيمة المكانية)
  const [pvThousands, setPvThousands] = useState<number>(3);
  const [pvHundreds, setPvHundreds] = useState<number>(4);
  const [pvTens, setPvTens] = useState<number>(5);
  const [pvUnits, setPvUnits] = useState<number>(8);
  const totalPvNumber = pvThousands * 1000 + pvHundreds * 100 + pvTens * 10 + pvUnits;

  // Place Value Quiz Questions
  const [pvQuizIndex, setPvQuizIndex] = useState<number>(0);
  const currentPvProblem = PLACE_VALUE_PROBLEMS[pvQuizIndex];
  const [selectedPvOption, setSelectedPvOption] = useState<number | null>(null);
  const [pvAnswerStatus, setPvAnswerStatus] = useState<'correct' | 'wrong' | null>(null);

  const handlePvAnswer = (opt: number) => {
    if (pvAnswerStatus === 'correct') return;
    setSelectedPvOption(opt);
    if (opt === currentPvProblem.correctAnswer) {
      setPvAnswerStatus('correct');
      playSuccess();
      playStarTwinkle();
      confetti({ particleCount: 60, spread: 60 });
      onEarnStars(3);
      speakArabic(currentPvProblem.explanation);
    } else {
      setPvAnswerStatus('wrong');
      playIncorrect();
      speakArabic('إجابة غير صحيحة، فكر في اسم الخانة وموقع الرقم');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Sub Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-3 rounded-2xl border border-blue-200 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          
          <button
            id="subtab-counting"
            onClick={() => { playPop(); setSubTab('counting'); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              subTab === 'counting'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 text-slate-700 hover:bg-blue-100'
            }`}
          >
            <span>🔢</span>
            <span>الْعَدُّ وَالْأَرْقَامُ</span>
          </button>

          <button
            id="subtab-addition"
            onClick={() => { playPop(); setSubTab('addition'); generateNewMathProblem(true); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              subTab === 'addition'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 text-slate-700 hover:bg-blue-100'
            }`}
          >
            <span>➕</span>
            <span>عَمَلِيَّةُ الْجَمْعِ</span>
          </button>

          <button
            id="subtab-subtraction"
            onClick={() => { playPop(); setSubTab('subtraction'); generateNewMathProblem(false); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              subTab === 'subtraction'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 text-slate-700 hover:bg-blue-100'
            }`}
          >
            <span>➖</span>
            <span>عَمَلِيَّةُ الطَّرْحِ</span>
          </button>

          <button
            id="subtab-multiplication"
            onClick={() => { playPop(); setSubTab('multiplication'); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              subTab === 'multiplication'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 text-slate-700 hover:bg-blue-100'
            }`}
          >
            <span>✖️</span>
            <span>جَدْوَلُ الضَّرْبِ (1 - 10)</span>
          </button>

          <button
            id="subtab-place-value"
            onClick={() => { playPop(); setSubTab('place_value'); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              subTab === 'place_value'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-indigo-50 text-indigo-900 hover:bg-indigo-100'
            }`}
          >
            <span>🏛️</span>
            <span>الْقِيمَةُ الْمَكَانِيَّةُ (آحَاد • عَشَرَات • مِئَات • آلَاف)</span>
          </button>

        </div>

        <div className="text-xs font-bold text-blue-900 bg-blue-50 px-3 py-1.5 rounded-xl">
          الرياضيات لغة الأذكياء 🧠
        </div>
      </div>

      {/* 1. COUNTING MODULE */}
      {subTab === 'counting' && (
        <div className="max-w-4xl mx-auto bg-white rounded-3xl border-2 border-blue-200 p-6 sm:p-8 shadow-sm text-center">
          
          <div className="flex items-center justify-between mb-6">
            <span className="text-xs font-bold text-blue-800 bg-blue-100 px-3 py-1 rounded-full">
              تَدْرِيبُ الْعَدِّ الْبَصَرِيِّ
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">اختر عدد العناصر:</span>
              {[5, 7, 10, 15].map((n) => (
                <button
                  key={n}
                  onClick={() => {
                    playPop();
                    setCountingTarget(n);
                    setCountedItems([]);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                    countingTarget === n ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          <h3 className="text-2xl font-black text-slate-800 mb-2">
            اعْدُدِ التُّفَّاحَاتِ بِالضَّغْطِ عَلَيْهَا:
          </h3>
          <p className="text-sm text-slate-500 mb-6">
            اضغط على كل تفاحة لتعدها بصوت عالٍ حتى تصل إلى {countingTarget}
          </p>

          {/* Interactive items grid */}
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 p-6 bg-amber-50/50 rounded-3xl border border-amber-200 mb-6">
            {Array.from({ length: countingTarget }).map((_, idx) => {
              const isCounted = countedItems.includes(idx);
              return (
                <button
                  key={idx}
                  id={`count-item-${idx}`}
                  onClick={() => handleTapCountItem(idx)}
                  className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex flex-col items-center justify-center text-3xl sm:text-4xl shadow-md transition-all transform active:scale-90 ${
                    isCounted
                      ? 'bg-emerald-100 border-2 border-emerald-400 scale-105 ring-2 ring-emerald-300'
                      : 'bg-white border-2 border-slate-200 hover:scale-105'
                  }`}
                >
                  <span>{countingItemType}</span>
                  {isCounted && (
                    <span className="text-xs font-black text-emerald-800 bg-white/90 px-2 py-0.5 rounded-full mt-1">
                      {countedItems.indexOf(idx) + 1}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Progress Bar & Counter */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="text-lg font-black text-blue-900">
              عَدَدْتَ: <span className="text-2xl text-emerald-600">{countedItems.length}</span> مِنْ {countingTarget}
            </div>
          </div>

          {countedItems.length === countingTarget && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl animate-bounce mb-4 text-emerald-900 font-black text-lg">
              🎉 رَائِعٌ جِدّاً! أَكْمَلْتَ عَدَّ {countingTarget} تُفَّاحَاتٍ بِنَجَاحٍ!
            </div>
          )}

          <button
            onClick={() => {
              playPop();
              setCountedItems([]);
            }}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm"
          >
            إِعَادَةُ الْعَدِّ مِنْ جَدِيدٍ
          </button>

        </div>
      )}

      {/* 2. ADDITION MODULE */}
      {subTab === 'addition' && (
        <div className="max-w-3xl mx-auto bg-white rounded-3xl border-2 border-blue-200 p-6 sm:p-8 shadow-sm text-center">
          
          <div className="flex items-center justify-between mb-6">
            <span className="text-xs font-bold text-blue-800 bg-blue-100 px-3 py-1 rounded-full">
              تَدْرِيبُ الْجَمْعِ الذَّكِيِّ
            </span>
            <button
              onClick={() => generateNewMathProblem(true)}
              className="px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold text-xs flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>مَسْأَلَةٌ جَدِيدَةٌ</span>
            </button>
          </div>

          {/* Visual representation of problem for young children */}
          {ageGroup === '5-7' && (
            <div className="flex items-center justify-center gap-3 p-4 bg-blue-50 rounded-2xl mb-6">
              <div className="flex flex-wrap gap-1 max-w-[150px] justify-center">
                {Array.from({ length: num1 }).map((_, i) => (
                  <span key={i} className="text-2xl">⭐</span>
                ))}
              </div>
              <span className="text-2xl font-black text-blue-600">➕</span>
              <div className="flex flex-wrap gap-1 max-w-[150px] justify-center">
                {Array.from({ length: num2 }).map((_, i) => (
                  <span key={i} className="text-2xl">⭐</span>
                ))}
              </div>
            </div>
          )}

          {/* Math Equation Formula Display */}
          <div className="flex items-center justify-center gap-3 sm:gap-5 text-4xl sm:text-6xl font-black text-slate-800 my-6" dir="ltr">
            <span className="px-4 py-2 bg-blue-50 border-2 border-blue-200 rounded-2xl">{num1}</span>
            <span className="text-blue-600">+</span>
            <span className="px-4 py-2 bg-blue-50 border-2 border-blue-200 rounded-2xl">{num2}</span>
            <span>=</span>
            <input
              id="addition-answer-input"
              type="number"
              value={userMathAnswer}
              onChange={(e) => setUserMathAnswer(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleCheckMath(num1 + num2); }}
              placeholder="؟"
              className="w-24 sm:w-32 h-16 sm:h-20 text-center rounded-2xl border-4 border-dashed border-blue-400 bg-amber-50 focus:border-blue-600 focus:outline-none text-blue-900 font-black shadow-inner"
            />
          </div>

          {/* Quick Digit Pad */}
          <div className="max-w-xs mx-auto grid grid-cols-5 gap-2 mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((d) => (
              <button
                key={d}
                onClick={() => {
                  playPop();
                  setUserMathAnswer(prev => prev + d.toString());
                }}
                className="py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-lg text-slate-800 shadow-sm active:scale-95"
              >
                {d}
              </button>
            ))}
          </div>

          {/* Feedback */}
          {mathFeedback === 'correct' && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl text-emerald-900 font-extrabold text-lg mb-4 animate-bounce">
              🎉 مُمْتَازٌ جِدّاً! {num1} + {num2} = {num1 + num2}
            </div>
          )}

          {mathFeedback === 'wrong' && (
            <div className="p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl text-rose-900 font-extrabold text-sm mb-4">
              فَكِّرْ مَرَّةً أُخْرَى، عُدَّ النُّجُومَ بِتَأَنٍّ!
            </div>
          )}

          <div className="flex items-center justify-center gap-3">
            <button
              id="verify-addition-btn"
              onClick={() => handleCheckMath(num1 + num2)}
              className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-base shadow-md transition-all active:scale-95"
            >
              تَأْكِيدُ الْإِجَابَةِ ✔️
            </button>

            <button
              onClick={() => setUserMathAnswer('')}
              className="px-4 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm"
            >
              مَسْح
            </button>
          </div>

        </div>
      )}

      {/* 3. SUBTRACTION MODULE */}
      {subTab === 'subtraction' && (
        <div className="max-w-3xl mx-auto bg-white rounded-3xl border-2 border-blue-200 p-6 sm:p-8 shadow-sm text-center">
          
          <div className="flex items-center justify-between mb-6">
            <span className="text-xs font-bold text-rose-800 bg-rose-100 px-3 py-1 rounded-full">
              تَدْرِيبُ الطَّرْحِ الذَّكِيِّ
            </span>
            <button
              onClick={() => generateNewMathProblem(false)}
              className="px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold text-xs flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>مَسْأَلَةٌ جَدِيدَةٌ</span>
            </button>
          </div>

          {/* Visual representation */}
          {ageGroup === '5-7' && (
            <div className="p-4 bg-rose-50 rounded-2xl mb-6">
              <p className="text-xs font-bold text-rose-900 mb-2">
                لَدَيْنَا {num1} بَالُوناً، سَنَشْطُبُ مِنْهَا {num2}:
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                {Array.from({ length: num1 }).map((_, i) => (
                  <span
                    key={i}
                    className={`text-2xl sm:text-3xl ${i < num2 ? 'opacity-30 line-through' : ''}`}
                  >
                    🎈
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Equation */}
          <div className="flex items-center justify-center gap-3 sm:gap-5 text-4xl sm:text-6xl font-black text-slate-800 my-6" dir="ltr">
            <span className="px-4 py-2 bg-rose-50 border-2 border-rose-200 rounded-2xl">{num1}</span>
            <span className="text-rose-600">-</span>
            <span className="px-4 py-2 bg-rose-50 border-2 border-rose-200 rounded-2xl">{num2}</span>
            <span>=</span>
            <input
              id="subtraction-answer-input"
              type="number"
              value={userMathAnswer}
              onChange={(e) => setUserMathAnswer(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleCheckMath(num1 - num2); }}
              placeholder="؟"
              className="w-24 sm:w-32 h-16 sm:h-20 text-center rounded-2xl border-4 border-dashed border-rose-400 bg-amber-50 focus:border-rose-600 focus:outline-none text-rose-900 font-black shadow-inner"
            />
          </div>

          {/* Quick Digit Pad */}
          <div className="max-w-xs mx-auto grid grid-cols-5 gap-2 mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((d) => (
              <button
                key={d}
                onClick={() => {
                  playPop();
                  setUserMathAnswer(prev => prev + d.toString());
                }}
                className="py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-lg text-slate-800 shadow-sm active:scale-95"
              >
                {d}
              </button>
            ))}
          </div>

          {mathFeedback === 'correct' && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl text-emerald-900 font-extrabold text-lg mb-4 animate-bounce">
              🎉 عَبْقَرِيٌّ! {num1} - {num2} = {num1 - num2}
            </div>
          )}

          {mathFeedback === 'wrong' && (
            <div className="p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl text-rose-900 font-extrabold text-sm mb-4">
              فَكِّرْ مَرَّةً أُخْرَى كَمْ بَقِيَ بَعْدَ حَذْفِ {num2}؟
            </div>
          )}

          <div className="flex items-center justify-center gap-3">
            <button
              id="verify-subtraction-btn"
              onClick={() => handleCheckMath(num1 - num2)}
              className="px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-black text-base shadow-md transition-all active:scale-95"
            >
              تَأْكِيدُ الْإِجَابَةِ ✔️
            </button>

            <button
              onClick={() => setUserMathAnswer('')}
              className="px-4 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm"
            >
              مَسْح
            </button>
          </div>

        </div>
      )}

      {/* 4. MULTIPLICATION MODULE (جدول الضرب) */}
      {subTab === 'multiplication' && (
        <div className="space-y-6">
          
          {/* Table Selector Bar (1 to 10) */}
          <div className="bg-white p-4 rounded-3xl border border-blue-200 shadow-sm">
            <span className="text-xs font-bold text-slate-600 block mb-2 text-center">
              اختر جدول الضرب الذي تريد تعلمه وتدريبه:
            </span>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((tableNum) => (
                <button
                  key={tableNum}
                  id={`mult-table-${tableNum}`}
                  onClick={() => {
                    playPop();
                    setSelectedTable(tableNum);
                    speakArabic(`جدول ضرب ${tableNum}`);
                  }}
                  className={`px-4 py-2 rounded-2xl font-black text-base transition-all border-2 ${
                    selectedTable === tableNum
                      ? 'bg-blue-600 text-white border-blue-700 shadow-md scale-105'
                      : 'bg-blue-50 text-blue-950 border-blue-200 hover:bg-blue-100'
                  }`}
                >
                  جَدْوَل {tableNum}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Multiplication Flashcards List */}
            <div className="lg:col-span-6 bg-white p-5 rounded-3xl border border-blue-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-extrabold text-slate-800 text-lg flex items-center gap-2">
                  <span>✖️</span>
                  <span>جَدْوَلُ الضَّرْبِ لِلرَّقَمِ ({selectedTable})</span>
                </h4>
                <button
                  onClick={() => {
                    playPop();
                    const tableText = Array.from({ length: 10 })
                      .map((_, i) => `${selectedTable} ضرب ${i + 1} يساوي ${selectedTable * (i + 1)}`)
                      .join('، ');
                    speakArabic(tableText);
                  }}
                  className="px-3 py-1 rounded-xl bg-blue-100 text-blue-800 hover:bg-blue-200 font-bold text-xs flex items-center gap-1"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>اسْتَمِعْ لِلْجَدْوَلِ كَامِلاً</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {Array.from({ length: 10 }).map((_, i) => {
                  const factor = i + 1;
                  const res = selectedTable * factor;
                  return (
                    <div
                      key={factor}
                      onClick={() => {
                        playPop();
                        speakArabic(`${selectedTable} ضَرْب ${factor} يُسَاوِي ${res}`);
                      }}
                      className="p-3 rounded-2xl bg-blue-50/70 hover:bg-blue-100/90 border border-blue-200 flex items-center justify-between cursor-pointer transition-all hover:scale-102"
                    >
                      <span className="font-black text-base text-slate-700" dir="ltr">
                        {selectedTable} × {factor}
                      </span>
                      <span className="w-8 h-8 rounded-xl bg-blue-600 text-white font-extrabold text-sm flex items-center justify-center shadow-sm">
                        {res}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive Array Visualizer & Speed Drill */}
            <div className="lg:col-span-6 space-y-6">
              
              {/* Dot Grid Visualizer */}
              <div className="bg-white p-5 rounded-3xl border border-blue-200 shadow-sm text-center">
                <h4 className="text-sm font-extrabold text-slate-700 mb-1">
                  الرَّسْمُ الْبَصَرِيُّ لِلضَّرْبِ ({selectedTable} × {drillFactor}):
                </h4>
                <p className="text-xs text-slate-500 mb-4">
                  الضرب يعني تكرار الجمع: {selectedTable} مصفوفات تحتوي كل واحدة على {drillFactor} نقطة!
                </p>

                <div className="inline-block p-4 bg-amber-50 rounded-2xl border border-amber-200">
                  <div className="grid gap-1.5 justify-center" style={{ gridTemplateColumns: `repeat(${drillFactor}, minmax(0, 1fr))` }}>
                    {Array.from({ length: selectedTable * drillFactor }).map((_, idx) => (
                      <div
                        key={idx}
                        className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-blue-500 shadow-xs animate-pulse"
                      />
                    ))}
                  </div>
                </div>
                <div className="text-sm font-black text-blue-900 mt-3">
                  المجموع الكلي للنقاط = {selectedTable * drillFactor}
                </div>
              </div>

              {/* Speed Drill Challenge */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-3xl border-2 border-blue-300 shadow-sm text-center">
                <span className="text-xs font-bold text-indigo-900 bg-indigo-100 px-3 py-1 rounded-full mb-3 inline-block">
                  ⚡ تَحَدِّي سُرْعَةِ الضَّرْبِ
                </span>

                <div className="text-3xl sm:text-5xl font-black text-slate-800 my-3" dir="ltr">
                  <span>{selectedTable}</span>
                  <span className="text-indigo-600 mx-2">×</span>
                  <span>{drillFactor}</span>
                  <span className="mx-2">=</span>
                  <input
                    id="mult-drill-input"
                    type="number"
                    value={drillAnswer}
                    onChange={(e) => setDrillAnswer(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleCheckDrill(); }}
                    placeholder="؟"
                    className="w-20 sm:w-28 h-14 sm:h-16 text-center rounded-2xl border-2 border-dashed border-indigo-400 bg-white text-indigo-950 font-black text-2xl sm:text-3xl focus:outline-none"
                  />
                </div>

                {drillFeedback === 'correct' && (
                  <div className="text-emerald-700 font-extrabold text-sm mb-3">
                    أحسنت! إجابة سريعة وصحيحة 🌟
                  </div>
                )}

                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={handleCheckDrill}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm shadow-sm"
                  >
                    تَحَقَّقْ مِنَ الْإِجَابَةِ ✔️
                  </button>

                  <button
                    onClick={() => {
                      playPop();
                      setDrillFactor(Math.floor(Math.random() * 10) + 1);
                      setDrillAnswer('');
                      setDrillFeedback(null);
                    }}
                    className="px-3 py-2.5 rounded-xl bg-white text-slate-700 hover:bg-slate-100 font-bold text-sm border border-slate-200"
                  >
                    تَغْيِيرُ الرَّقَمِ
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* 5. PLACE VALUE MODULE (القيمة المكانية) */}
      {subTab === 'place_value' && (
        <div className="space-y-6">
          
          {/* Explanation Banner */}
          <div className="bg-gradient-to-r from-indigo-900 to-purple-900 text-white p-6 rounded-3xl shadow-md">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-3xl">🏛️</span>
              <h3 className="text-xl sm:text-2xl font-black">
                دَرْسُ الْقِيمَةِ الْمَكَانِيَّةِ لِلْأَرْقَامِ
              </h3>
            </div>
            <p className="text-sm sm:text-base text-indigo-100 font-medium leading-relaxed max-w-3xl">
              تتحدد قيمة أي رقم حسب موقعه (خانته) داخل العدد:
              <br />
              • <strong className="text-amber-300">الْآحَاد (Units):</strong> قيمتها كما هي (من 1 إلى 9).
              <br />
              • <strong className="text-emerald-300">الْعَشَرَات (Tens):</strong> تضرب في 10 (مثل: 5 في العشرات = 50).
              <br />
              • <strong className="text-cyan-300">الْمِئَات (Hundreds):</strong> تضرب في 100 (مثل: 3 في المئات = 300).
              <br />
              • <strong className="text-rose-300">الْآلَاف (Thousands):</strong> تضرب في 1000 (مثل: 4 في الآلاف = 4000).
            </p>
          </div>

          {/* Interactive Place Value Base-10 Blocks Visualizer */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-indigo-200 shadow-sm">
            
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h4 className="font-extrabold text-slate-800 text-lg">
                  مُفَكِّكُ الْأَعْدَادِ التَّفَاعُلِيُّ:
                </h4>
                <p className="text-xs text-slate-500">
                  حرّك أو اختر القيم في كل خانة لمشاهدة تفكيك الرقم بصرياً
                </p>
              </div>

              {/* Total Computed Number Display */}
              <div className="px-5 py-2.5 bg-indigo-50 border-2 border-indigo-300 rounded-2xl text-center">
                <span className="text-xs font-bold text-indigo-900 block">الْعَدَدُ الْإِجْمَالِيُّ:</span>
                <span className="text-3xl sm:text-4xl font-black text-indigo-950" dir="ltr">
                  {totalPvNumber.toLocaleString('ar-EG')} ({totalPvNumber})
                </span>
              </div>
            </div>

            {/* Interactive Columns Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
              
              {/* Thousands */}
              <div className="bg-rose-50/70 border-2 border-rose-200 rounded-2xl p-4 text-center">
                <span className="text-xs font-black text-rose-800 block mb-1">الْآلَاف (Thousands)</span>
                <span className="text-4xl block mb-2">🧱</span>
                <span className="text-2xl font-black text-rose-950 block">{pvThousands}</span>
                <span className="text-xs text-rose-600 font-bold block mb-3">= {pvThousands * 1000}</span>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => { playPop(); setPvThousands(Math.max(0, pvThousands - 1)); }}
                    className="w-8 h-8 rounded-xl bg-rose-200 hover:bg-rose-300 text-rose-900 font-black text-lg"
                  >
                    -
                  </button>
                  <button
                    onClick={() => { playPop(); setPvThousands(Math.min(9, pvThousands + 1)); }}
                    className="w-8 h-8 rounded-xl bg-rose-200 hover:bg-rose-300 text-rose-900 font-black text-lg"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Hundreds */}
              <div className="bg-cyan-50/70 border-2 border-cyan-200 rounded-2xl p-4 text-center">
                <span className="text-xs font-black text-cyan-800 block mb-1">الْمِئَات (Hundreds)</span>
                <span className="text-4xl block mb-2">🟩</span>
                <span className="text-2xl font-black text-cyan-950 block">{pvHundreds}</span>
                <span className="text-xs text-cyan-600 font-bold block mb-3">= {pvHundreds * 100}</span>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => { playPop(); setPvHundreds(Math.max(0, pvHundreds - 1)); }}
                    className="w-8 h-8 rounded-xl bg-cyan-200 hover:bg-cyan-300 text-cyan-900 font-black text-lg"
                  >
                    -
                  </button>
                  <button
                    onClick={() => { playPop(); setPvHundreds(Math.min(9, pvHundreds + 1)); }}
                    className="w-8 h-8 rounded-xl bg-cyan-200 hover:bg-cyan-300 text-cyan-900 font-black text-lg"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Tens */}
              <div className="bg-emerald-50/70 border-2 border-emerald-200 rounded-2xl p-4 text-center">
                <span className="text-xs font-black text-emerald-800 block mb-1">الْعَشَرَات (Tens)</span>
                <span className="text-4xl block mb-2">📏</span>
                <span className="text-2xl font-black text-emerald-950 block">{pvTens}</span>
                <span className="text-xs text-emerald-600 font-bold block mb-3">= {pvTens * 10}</span>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => { playPop(); setPvTens(Math.max(0, pvTens - 1)); }}
                    className="w-8 h-8 rounded-xl bg-emerald-200 hover:bg-emerald-300 text-emerald-900 font-black text-lg"
                  >
                    -
                  </button>
                  <button
                    onClick={() => { playPop(); setPvTens(Math.min(9, pvTens + 1)); }}
                    className="w-8 h-8 rounded-xl bg-emerald-200 hover:bg-emerald-300 text-emerald-900 font-black text-lg"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Units */}
              <div className="bg-amber-50/70 border-2 border-amber-200 rounded-2xl p-4 text-center">
                <span className="text-xs font-black text-amber-800 block mb-1">الْآحَاد (Units)</span>
                <span className="text-4xl block mb-2">🟦</span>
                <span className="text-2xl font-black text-amber-950 block">{pvUnits}</span>
                <span className="text-xs text-amber-600 font-bold block mb-3">= {pvUnits}</span>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => { playPop(); setPvUnits(Math.max(0, pvUnits - 1)); }}
                    className="w-8 h-8 rounded-xl bg-amber-200 hover:bg-amber-300 text-amber-900 font-black text-lg"
                  >
                    -
                  </button>
                  <button
                    onClick={() => { playPop(); setPvUnits(Math.min(9, pvUnits + 1)); }}
                    className="w-8 h-8 rounded-xl bg-amber-200 hover:bg-amber-300 text-amber-900 font-black text-lg"
                  >
                    +
                  </button>
                </div>
              </div>

            </div>

            {/* Formula Decomposition breakdown equation */}
            <div className="p-4 bg-slate-900 text-amber-300 rounded-2xl font-mono text-center text-sm sm:text-base font-bold shadow-inner">
              {pvThousands * 1000} (آلاف) + {pvHundreds * 100} (مئات) + {pvTens * 10} (عشرات) + {pvUnits} (آحاد) = {totalPvNumber}
            </div>

          </div>

          {/* Place Value Quiz Drill */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-indigo-300 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-900 rounded-full text-xs font-bold">
                تَحَدِّي الْقِيمَةِ الْمَكَانِيَّةِ (سؤال {pvQuizIndex + 1} مِنْ {PLACE_VALUE_PROBLEMS.length})
              </span>
              <button
                onClick={() => {
                  playPop();
                  speakArabic(currentPvProblem.question);
                }}
                className="p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800"
                title="استمع للسؤال"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            <h4 className="text-lg sm:text-xl font-black text-slate-800 mb-4 text-center">
              {currentPvProblem.question}
            </h4>

            {/* Options grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              {currentPvProblem.options.map((opt: number) => {
                const isSelected = selectedPvOption === opt;
                const isCorrect = opt === currentPvProblem.correctAnswer;
                let btnStyle = 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-indigo-50';

                if (pvAnswerStatus !== null && isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-500 text-white border-emerald-600 shadow-md scale-105'
                    : 'bg-rose-500 text-white border-rose-600';
                } else if (pvAnswerStatus === 'correct' && isCorrect) {
                  btnStyle = 'bg-emerald-500 text-white border-emerald-600';
                }

                return (
                  <button
                    key={opt}
                    onClick={() => handlePvAnswer(opt)}
                    className={`py-3.5 px-4 rounded-2xl font-black text-lg sm:text-xl border-2 transition-all ${btnStyle}`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            {pvAnswerStatus === 'correct' && (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl text-emerald-900 font-extrabold text-sm mb-4 animate-fade-in text-center">
                🎉 إِجَابَةٌ صَحِيحَةٌ! {currentPvProblem.explanation}
              </div>
            )}

            <div className="flex justify-end">
              <button
                onClick={() => {
                  playPop();
                  setPvQuizIndex(prev => (prev < PLACE_VALUE_PROBLEMS.length - 1 ? prev + 1 : 0));
                  setSelectedPvOption(null);
                  setPvAnswerStatus(null);
                }}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm shadow-sm"
              >
                السُّؤَالُ التَّالِي ➡️
              </button>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
