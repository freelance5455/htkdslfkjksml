import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AttendanceStatus } from '../../types';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  Download,
  Search,
  Users,
} from 'lucide-react';

export const AttendanceView: React.FC = () => {
  const { attendance, updateAttendance, markAllAttendance } = useApp();

  const [selectedClass, setSelectedClass] = useState<string>('Grade 10-A');
  const [selectedDate, setSelectedDate] = useState<string>('2026-10-30');
  const [searchStudent, setSearchStudent] = useState<string>('');

  const filteredStudents = attendance.filter((stu) => {
    const matchesClass = selectedClass === 'All' || stu.classGroup === selectedClass;
    const matchesSearch =
      stu.studentName.toLowerCase().includes(searchStudent.toLowerCase()) ||
      stu.rollNumber.toLowerCase().includes(searchStudent.toLowerCase()) ||
      stu.studentId.toLowerCase().includes(searchStudent.toLowerCase());
    return matchesClass && matchesSearch;
  });

  const total = filteredStudents.length;
  const presentCount = filteredStudents.filter((s) => s.status === 'present').length;
  const absentCount = filteredStudents.filter((s) => s.status === 'absent').length;
  const lateCount = filteredStudents.filter((s) => s.status === 'late').length;
  const excusedCount = filteredStudents.filter((s) => s.status === 'excused').length;
  const attendanceRate = total > 0 ? ((presentCount / total) * 100).toFixed(1) : '0.0';

  const exportCSV = () => {
    const rows = [
      ['Student ID', 'Roll Number', 'Student Name', 'Class', 'Date', 'Status', 'Notes'],
      ...filteredStudents.map((s) => [
        s.studentId,
        s.rollNumber,
        s.studentName,
        s.classGroup,
        selectedDate,
        s.status,
        s.notes || '',
      ]),
    ];
    const csvContent =
      'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Attendance_${selectedClass}_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Digital Student Attendance Ledger
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Conduct daily homeroom and subject period roll calls, verify absences, and export attendance records.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => markAllAttendance('present')}
            className="px-3.5 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
          >
            Mark All Present
          </button>
          <button
            onClick={exportCSV}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Class Selector & Date Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3 flex-wrap text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Select Class / Cohort
            </label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500"
            >
              <option value="Grade 10-A">Grade 10-A (STEM Honors)</option>
              <option value="Grade 11-B">Grade 11-B (AP Physics)</option>
              <option value="Class 8">Class 8 (Computer Science)</option>
              <option value="All">All Registered Classes</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Attendance Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Student Search */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchStudent}
            onChange={(e) => setSearchStudent(e.target.value)}
            placeholder="Search student or roll no..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Metric Cards (Clean unboxed style) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Attendance Rate
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {attendanceRate}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{presentCount} of {total} present</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-600">
            Present
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {presentCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">In classroom / lab</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-red-600">
            Absent
          </div>
          <div className="text-2xl font-bold font-mono text-red-700 mt-1 tabular-nums">
            {absentCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Unexcused absence</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-amber-600">
            Late / Excused
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            {lateCount + excusedCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{lateCount} late · {excusedCount} excused</div>
        </div>
      </div>

      {/* Student Roster Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Student & Roll No</th>
                <th className="py-3 px-4">Class</th>
                <th className="py-3 px-4 text-center">Status Selector</th>
                <th className="py-3 px-4">Teacher Remark / Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((student) => (
                <tr key={student.studentId} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 flex items-center gap-3">
                    <img
                      src={student.avatar}
                      alt={student.studentName}
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <div className="font-semibold text-slate-900">{student.studentName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {student.rollNumber} · {student.studentId}
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 font-medium">
                    {student.classGroup}
                  </td>
                  <td className="py-3.5 px-4">
                    {/* Status Button Group */}
                    <div className="flex items-center justify-center gap-1 p-1 bg-slate-100 rounded-lg max-w-xs mx-auto">
                      {(['present', 'absent', 'late', 'excused'] as AttendanceStatus[]).map((st) => {
                        const isCurrent = student.status === st;
                        return (
                          <button
                            key={st}
                            onClick={() => updateAttendance(student.studentId, st)}
                            className={`px-2.5 py-1 rounded text-[11px] font-semibold capitalize transition-all ${
                              isCurrent
                                ? st === 'present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : st === 'absent'
                                  ? 'bg-red-600 text-white shadow-xs'
                                  : st === 'late'
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'bg-indigo-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {st}
                          </button>
                        );
                      })}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <input
                      type="text"
                      defaultValue={student.notes || ''}
                      onBlur={(e) => updateAttendance(student.studentId, student.status, e.target.value)}
                      placeholder="Add roll call note..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
