import React from 'react';
import { Sparkles, Volume2, VolumeX, Bot, Award, Star, BookOpen } from 'lucide-react';
import { ChildProfile, AgeGroup } from '../../types/education';
import { isSoundEnabled, setSoundEnabled, playPop } from '../../utils/soundEffects';

interface HeaderProps {
  profile: ChildProfile;
  onUpdateAgeGroup?: (ageGroup: AgeGroup) => void;
  onAgeGroupChange?: (ageGroup: AgeGroup) => void;
  onOpenProfile?: () => void;
  onOpenAi?: () => void;
  onOpenSimsim?: () => void;
  soundOn?: boolean;
  onToggleSound?: () => void;
  onSoundToggle?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  onUpdateAgeGroup,
  onAgeGroupChange,
  onOpenProfile,
  onOpenAi,
  onOpenSimsim,
  soundOn,
  onToggleSound,
  onSoundToggle
}) => {
  const currentSoundOn = soundOn !== undefined ? soundOn : profile.soundEnabled;
  const currentStars = profile.starsCount !== undefined ? profile.starsCount : (profile.stars || 0);

  const handleAgeChange = (group: AgeGroup) => {
    if (onUpdateAgeGroup) onUpdateAgeGroup(group);
    if (onAgeGroupChange) onAgeGroupChange(group);
  };

  const handleAiClick = () => {
    if (onOpenAi) onOpenAi();
    if (onOpenSimsim) onOpenSimsim();
  };

  const handleToggle = () => {
    if (onToggleSound) onToggleSound();
    if (onSoundToggle) onSoundToggle();
  };
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-amber-200 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Logo and App Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 flex items-center justify-center text-white text-2xl shadow-md transform hover:rotate-6 transition-transform">
            🌱
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg sm:text-2xl text-slate-800 tracking-tight">
                بَرَاعِمُ <span className="text-amber-600">الْمَعْرِفَةِ</span>
              </span>
              <span className="hidden md:inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
                5 - 10 سَنَوَات
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-500 font-medium hidden sm:block">
              البرنامج التعليمي التفاعلي الشامل للبراعم والأبطال
            </p>
          </div>
        </div>

        {/* Age Group Switcher */}
        <div className="flex items-center bg-amber-100/80 p-1 rounded-2xl border border-amber-300 shadow-inner">
          <button
            id="age-bracket-5-7"
            onClick={() => {
              playPop();
              handleAgeChange('5-7');
            }}
            className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              profile.ageGroup === '5-7'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md'
                : 'text-amber-900 hover:text-amber-950'
            }`}
          >
            <span>🐣</span>
            <span className="hidden xs:inline">الصغار</span>
            <span className="text-[11px] opacity-90">(5-7)</span>
          </button>
          
          <button
            id="age-bracket-8-10"
            onClick={() => {
              playPop();
              handleAgeChange('8-10');
            }}
            className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
              profile.ageGroup === '8-10'
                ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md'
                : 'text-indigo-900 hover:text-indigo-950'
            }`}
          >
            <span>🚀</span>
            <span className="hidden xs:inline">الأبطال</span>
            <span className="text-[11px] opacity-90">(8-10)</span>
          </button>
        </div>

        {/* Actions & Child Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Stars Counter */}
          <div className="flex items-center gap-1 bg-amber-50 border-2 border-amber-300 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-full text-amber-800 font-extrabold text-sm sm:text-base shadow-sm">
            <Star className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500 fill-amber-400 animate-bounce" />
            <span dir="ltr">{currentStars}</span>
          </div>

          {/* AI Mentor Simsim Button */}
          <button
            id="open-ai-mentor-btn"
            onClick={() => {
              playPop();
              handleAiClick();
            }}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs sm:text-sm shadow-sm hover:shadow-md hover:scale-105 active:scale-95 transition-all"
            title="تحدث مع المعلم الذكي سِمْسِم"
          >
            <Bot className="w-4 h-4 animate-pulse" />
            <span className="hidden sm:inline">سِمْسِم الذكي</span>
          </button>

          {/* Sound Toggle */}
          <button
            id="sound-toggle-btn"
            onClick={() => {
              const next = !currentSoundOn;
              setSoundEnabled(next);
              handleToggle();
              if (next) playPop();
            }}
            className={`p-2 rounded-xl border text-sm font-semibold transition-all ${
              currentSoundOn
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700 hover:bg-emerald-100'
                : 'bg-slate-100 border-slate-300 text-slate-400 hover:bg-slate-200'
            }`}
            title={currentSoundOn ? 'كتم الصوت' : 'تشغيل الصوت'}
          >
            {currentSoundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Profile Card Button */}
          <button
            id="open-child-profile-btn"
            onClick={() => {
              playPop();
              if (onOpenProfile) onOpenProfile();
            }}
            className="flex items-center gap-1.5 pl-1 pr-2 sm:px-2.5 py-1 rounded-2xl bg-amber-100/90 hover:bg-amber-200/90 border border-amber-300 transition-all text-slate-800"
            title="الملف التعريفي والأوسمة"
          >
            <span className="text-xl sm:text-2xl">{profile.avatar}</span>
            <span className="font-bold text-xs sm:text-sm max-w-[80px] sm:max-w-[110px] truncate hidden xs:inline">
              {profile.name}
            </span>
          </button>

        </div>
      </div>
    </header>
  );
};
