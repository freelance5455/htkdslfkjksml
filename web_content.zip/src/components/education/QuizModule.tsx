import React, { useState } from 'react';
import { Trophy, Star, Sparkles, CheckCircle2, XCircle, RotateCcw, Award, Volume2, ArrowLeft } from 'lucide-react';
import { QUIZ_BANK } from '../../data/curriculumData';
import { QuizItem, AgeGroup, ChildProfile } from '../../types/education';
import { speakArabic, playSuccess, playIncorrect, playCelebration, playPop, playStarTwinkle } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface QuizModuleProps {
  profile: ChildProfile;
  ageGroup: AgeGroup;
  onEarnStars: (amount: number) => void;
}

export const QuizModule: React.FC<QuizModuleProps> = ({ profile, ageGroup, onEarnStars }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Filter questions according to age & category
  const questionsList = QUIZ_BANK.filter(q => {
    const matchesCategory = selectedCategory === 'all' || q.category === selectedCategory;
    const matchesAge = ageGroup === '5-7' ? q.ageGroup === '5-7' : true;
    return matchesCategory && matchesAge;
  });

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const currentQuestion = questionsList[currentIndex] || questionsList[0];

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const handleSelectOption = (idx: number) => {
    if (isAnswered || quizFinished) return;
    playPop();
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQuestion.correctIndex;
    if (isCorrect) {
      setScore(prev => prev + 1);
      setStreak(prev => prev + 1);
      playSuccess();
      playStarTwinkle();
      onEarnStars(3);
      speakArabic('إجابة صحيحة يا بطل! أحسنت!');
    } else {
      setStreak(0);
      playIncorrect();
      speakArabic('إجابة غير صحيحة، اقرأ التوضيح لتتعلم!');
    }
  };

  const handleNextQuestion = () => {
    playPop();
    if (currentIndex < questionsList.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
      playCelebration();
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
      onEarnStars(5);
    }
  };

  const handleRestartQuiz = () => {
    playPop();
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setStreak(0);
    setQuizFinished(false);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-3 rounded-2xl border border-amber-200 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: 'كُلُّ التَّحَدِّيَاتِ', icon: '🌟' },
            { id: 'letters', label: 'الْحُرُوفُ', icon: '🔤' },
            { id: 'words', label: 'الْكَلِمَاتُ', icon: '📝' },
            { id: 'math', label: 'الرِّيَاضِيَّاتُ', icon: '🧮' },
            { id: 'science', label: 'الْعُلُومُ', icon: '🔬' }
          ].map((cat) => (
            <button
              key={cat.id}
              id={`quiz-cat-${cat.id}`}
              onClick={() => {
                playPop();
                setSelectedCategory(cat.id);
                handleRestartQuiz();
              }}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'bg-amber-50 text-slate-700 hover:bg-amber-100'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Live Streak indicator */}
        {streak > 1 && (
          <div className="flex items-center gap-1.5 bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-xs font-black animate-pulse">
            <span>🔥</span>
            <span>حَمَاس! {streak} إِجَابَاتٍ مُتَتَالِيَةٍ!</span>
          </div>
        )}
      </div>

      {!quizFinished ? (
        /* Active Question Card */
        <div className="bg-white rounded-3xl border-2 border-amber-300 p-6 sm:p-8 shadow-sm">
          
          {/* Header with question number and audio button */}
          <div className="flex items-center justify-between border-b border-amber-100 pb-4 mb-6">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center font-black text-sm">
                {currentIndex + 1}
              </span>
              <span className="text-xs sm:text-sm font-bold text-slate-500">
                مِنْ {questionsList.length} أَسْئِلَةٍ ({currentQuestion.categoryAr})
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playPop();
                  speakArabic(currentQuestion.question);
                }}
                className="p-2 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200"
                title="استمع للسؤال"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden mb-6">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / questionsList.length) * 100}%` }}
            />
          </div>

          {/* Question visual icon / illustration */}
          {currentQuestion.visualEmoji && (
            <div className="text-center mb-4">
              <span className="inline-block p-4 bg-amber-50 rounded-2xl text-4xl sm:text-5xl shadow-xs">
                {currentQuestion.visualEmoji}
              </span>
            </div>
          )}

          {/* Question Title */}
          <h3 className="text-lg sm:text-2xl font-black text-slate-800 text-center leading-relaxed mb-6">
            {currentQuestion.question}
          </h3>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {currentQuestion.options.map((opt, optIdx) => {
              const isSelected = selectedOption === optIdx;
              const isCorrect = optIdx === currentQuestion.correctIndex;
              let btnStyle = 'bg-white border-slate-200 text-slate-800 hover:bg-amber-50 hover:border-amber-300';

              if (isAnswered) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-500 text-white border-emerald-600 shadow-sm';
                } else if (isSelected && !isCorrect) {
                  btnStyle = 'bg-rose-500 text-white border-rose-600';
                }
              }

              return (
                <button
                  key={optIdx}
                  id={`quiz-option-${optIdx}`}
                  disabled={isAnswered}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`p-4 rounded-2xl border-2 font-bold text-base sm:text-lg text-right transition-all flex items-center justify-between ${btnStyle}`}
                >
                  <span>{opt}</span>
                  {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 shrink-0 text-white" />}
                  {isAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 shrink-0 text-white" />}
                </button>
              );
            })}
          </div>

          {/* Feedback & Explanation Card */}
          {isAnswered && (
            <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200 mb-6 animate-fade-in text-right">
              <span className="text-xs font-black text-amber-900 block mb-1">
                تَوْضِيحُ الْإِجَابَةِ:
              </span>
              <p className="text-sm text-slate-700 font-medium leading-relaxed">
                {currentQuestion.explanation}
              </p>
            </div>
          )}

          {/* Next Button */}
          {isAnswered && (
            <div className="flex justify-end">
              <button
                id="next-quiz-question-btn"
                onClick={handleNextQuestion}
                className="px-6 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-black text-sm sm:text-base shadow-md transition-all flex items-center gap-2"
              >
                <span>{currentIndex < questionsList.length - 1 ? 'السُّؤَالُ التَّالِي' : 'عَرْضُ النَّتِيجَةِ 🏆'}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      ) : (
        /* End-of-Quiz Result & Certificate */
        <div className="bg-white rounded-3xl border-2 border-amber-300 p-6 sm:p-10 shadow-sm text-center animate-fade-in">
          
          <span className="text-6xl sm:text-7xl block mb-2 animate-bounce">🏆</span>
          
          <h3 className="text-2xl sm:text-3xl font-black text-slate-800 mb-1">
            مَبْرُوكٌ يَا {profile.name}!
          </h3>
          <p className="text-sm sm:text-base text-slate-500 mb-6 font-medium">
            لقد أتممت التحدي التعليمي بكل تفوق وجدارة!
          </p>

          {/* Score Circle Card */}
          <div className="max-w-xs mx-auto bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-300 rounded-3xl p-6 mb-6 shadow-sm">
            <span className="text-xs font-black text-amber-900 block mb-1">دَرَجَتُكَ النِّهَائِيَّةُ:</span>
            <div className="text-5xl font-black text-amber-600 my-2">
              {score} <span className="text-2xl text-slate-400">/ {questionsList.length}</span>
            </div>
            <div className="text-xs font-bold text-emerald-700 bg-emerald-100 py-1 px-3 rounded-full inline-block">
              نسبة النجاح: {Math.round((score / questionsList.length) * 100)}%
            </div>
          </div>

          {/* Reward Certificate Badge */}
          <div className="p-6 bg-slate-900 text-white rounded-3xl border-4 border-amber-400 mb-6 max-w-lg mx-auto shadow-md">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Award className="w-6 h-6 text-amber-400" />
              <span className="font-extrabold text-lg text-amber-300">
                شَهَادَةُ الْعَبْقَرِيِّ الصَّغِيرِ
              </span>
              <Award className="w-6 h-6 text-amber-400" />
            </div>
            <p className="text-sm text-slate-300 mb-2">
              نُشْهِدُ بِأَنَّ الْبَطَلَ <strong className="text-white text-base">({profile.name})</strong> قَدْ أَظْهَرَ ذَكَاءً بَاهِراً فِي اسْتِيعَابِ الْحُرُوفِ وَالْحِسَابِ وَالْعُلُومِ!
            </p>
            <div className="flex justify-center gap-1 text-2xl text-amber-400">
              ⭐⭐⭐⭐⭐
            </div>
          </div>

          <div className="flex items-center justify-center gap-3">
            <button
              onClick={handleRestartQuiz}
              className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black text-sm flex items-center gap-2 shadow-sm"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إِعَادَةُ التَّحَدِّي</span>
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
