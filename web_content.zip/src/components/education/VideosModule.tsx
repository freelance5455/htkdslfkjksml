import React, { useState } from 'react';
import { Video, Play, Volume2, CheckCircle2, Star, Sparkles, ExternalLink } from 'lucide-react';
import { EDUCATIONAL_VIDEOS } from '../../data/curriculumData';
import { VideoItem, AgeGroup } from '../../types/education';
import { speakArabic, playPop, playStarTwinkle } from '../../utils/soundEffects';

interface VideosModuleProps {
  ageGroup: AgeGroup;
  onNavigateToQuiz: () => void;
}

export const VideosModule: React.FC<VideosModuleProps> = ({ ageGroup, onNavigateToQuiz }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const filteredVideos = EDUCATIONAL_VIDEOS.filter(v => selectedCategory === 'all' || v.category === selectedCategory);
  const [activeVideo, setActiveVideo] = useState<VideoItem>(filteredVideos[0] || EDUCATIONAL_VIDEOS[0]);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Category Pills */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-purple-200 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: 'كُلُّ الْفِيدْيُوهَاتِ', icon: '🌟' },
            { id: 'letters', label: 'الْحُرُوفُ وَاللُّغَةُ', icon: '🔤' },
            { id: 'math', label: 'الْحِسَابُ وَالضَّرْبُ', icon: '🔢' },
            { id: 'science', label: 'الْعُلُومُ وَالْفَضَاءُ', icon: '🪐' }
          ].map(cat => (
            <button
              key={cat.id}
              id={`video-cat-${cat.id}`}
              onClick={() => {
                playPop();
                setSelectedCategory(cat.id);
              }}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-purple-50 text-purple-950 hover:bg-purple-100'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        <span className="text-xs text-purple-800 font-bold bg-purple-100 px-3 py-1 rounded-full">
          محتوى مرئي تعليمي آمن للأطفال 🔒
        </span>
      </div>

      {/* Active Theater Player */}
      <div className="bg-white rounded-3xl border-2 border-purple-300 p-4 sm:p-6 shadow-sm">
        
        {/* Video Frame */}
        <div className="w-full aspect-video rounded-2xl overflow-hidden bg-slate-900 shadow-inner mb-4 relative">
          <iframe
            src={`${activeVideo.embedUrl}?rel=0&modestbranding=1&autoplay=0`}
            title={activeVideo.title}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>

        {/* Video Info & Summary */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-purple-100 pb-4 mb-4">
          <div>
            <span className="px-3 py-0.5 rounded-full text-xs font-black bg-purple-100 text-purple-800 mb-1.5 inline-block">
              {activeVideo.categoryAr} • المدة: {activeVideo.duration}
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-slate-800">
              {activeVideo.title}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playPop();
                speakArabic(`${activeVideo.title}. ${activeVideo.description}`);
              }}
              className="px-3.5 py-2 rounded-xl bg-purple-50 text-purple-800 hover:bg-purple-100 font-bold text-xs flex items-center gap-1.5 border border-purple-200"
            >
              <Volume2 className="w-4 h-4" />
              <span>اسْتَمِعْ لِلْمُلَخَّصِ</span>
            </button>

            <button
              onClick={() => {
                playPop();
                onNavigateToQuiz();
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-sm hover:scale-102 transition-all flex items-center gap-1.5"
            >
              <Star className="w-4 h-4 text-amber-300" />
              <span>اخْتَبِرْ مَعْلُومَاتِكَ</span>
            </button>
          </div>
        </div>

        <p className="text-sm text-slate-600 font-medium leading-relaxed mb-4">
          {activeVideo.description}
        </p>

        {/* Key Takeaways */}
        <div className="bg-purple-50/60 p-4 rounded-2xl border border-purple-200">
          <h4 className="text-xs font-black text-purple-950 mb-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-purple-600" />
            <span>أَهَمُّ النِّقَاطِ الْمُسْتَفَادَةِ مِنَ الْفِيدْيُو:</span>
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {activeVideo.keyPoints.map((point, idx) => (
              <div key={idx} className="bg-white p-2.5 rounded-xl border border-purple-100 text-xs font-semibold text-slate-700 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-black text-[10px] shrink-0">
                  {idx + 1}
                </span>
                <span>{point}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Video Playlist Grid */}
      <div>
        <h4 className="font-extrabold text-slate-800 text-lg mb-3 flex items-center gap-2">
          <span>🎬</span>
          <span>اخْتَرْ فِيدْيُو تَعْلِيمِيّاً آخَرَ:</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredVideos.map((video) => {
            const isPlaying = activeVideo.id === video.id;
            return (
              <button
                key={video.id}
                id={`video-card-${video.id}`}
                onClick={() => {
                  playPop();
                  setActiveVideo(video);
                  window.scrollTo({ top: 100, behavior: 'smooth' });
                }}
                className={`p-4 rounded-2xl border-2 text-right transition-all flex items-start gap-3 group ${
                  isPlaying
                    ? 'bg-purple-50 border-purple-600 ring-2 ring-purple-300 shadow-sm'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-600 text-white flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition-transform shadow-xs">
                  {video.thumbnailEmoji}
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                    {video.categoryAr} • {video.duration}
                  </span>
                  <h5 className="font-extrabold text-xs sm:text-sm text-slate-800 truncate mt-1">
                    {video.title}
                  </h5>
                  <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                    {video.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

    </div>
  );
};
