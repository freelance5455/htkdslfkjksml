import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Assignment, AssignmentSubmission } from '../../types';
import {
  BookOpen,
  Plus,
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  X,
  Upload,
  UserCheck,
} from 'lucide-react';

export const HomeworkView: React.FC = () => {
  const { assignments, createAssignment, gradeSubmission, currentUser } = useApp();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment>(assignments[0]);
  const [activeSubmissionToGrade, setActiveSubmissionToGrade] = useState<AssignmentSubmission | null>(null);

  // New assignment form states
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('AP Physics');
  const [classGroup, setClassGroup] = useState('Grade 10-A');
  const [dueDate, setDueDate] = useState('2026-11-10');
  const [totalMarks, setTotalMarks] = useState('50');
  const [instructions, setInstructions] = useState('');
  const [attachmentName, setAttachmentName] = useState('Lab_Assignment_Guide.pdf');

  // Grading form state
  const [scoreInput, setScoreInput] = useState('');
  const [feedbackInput, setFeedbackInput] = useState('');

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createAssignment({
      title: title.trim(),
      subject,
      classGroup,
      dueDate,
      totalMarks: parseInt(totalMarks, 10) || 50,
      instructions: instructions.trim() || 'Please complete exercises and upload your derivation.',
      attachmentName,
    });

    setIsCreateModalOpen(false);
    setTitle('');
    setInstructions('');
  };

  const handleOpenGradeModal = (sub: AssignmentSubmission) => {
    setActiveSubmissionToGrade(sub);
    setScoreInput(sub.score !== undefined ? String(sub.score) : '');
    setFeedbackInput(sub.feedback || '');
  };

  const handleSubmitGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSubmissionToGrade) return;

    const numericScore = parseFloat(scoreInput) || 0;
    gradeSubmission(
      selectedAssignment.id,
      activeSubmissionToGrade.id,
      numericScore,
      feedbackInput.trim() || 'Work reviewed and approved.'
    );

    setActiveSubmissionToGrade(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Homework & Coursework Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Publish academic assignments, distribute lab materials, and grade student problem set submissions.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Upload Assignment</span>
        </button>
      </div>

      {/* Main Split: Assignment Cards & Submissions Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Assignment Catalog */}
        <div className="lg:col-span-1 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
            Active Assignments ({assignments.length})
          </div>

          {assignments.map((asg) => {
            const isSelected = selectedAssignment.id === asg.id;
            return (
              <div
                key={asg.id}
                onClick={() => setSelectedAssignment(asg)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-indigo-50/70 border-indigo-400 shadow-xs'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-indigo-700">{asg.subject}</span>
                  <span className="font-mono text-[11px]">{asg.classGroup}</span>
                </div>
                <h3 className="text-sm font-bold text-slate-900 mb-2 leading-snug">{asg.title}</h3>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <span className="flex items-center gap-1 font-mono text-[11px]">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Due {asg.dueDate}
                  </span>
                  <span className="font-semibold text-slate-700">
                    {asg.submissions.length} Submissions
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 2 Columns: Selected Assignment Details & Student Submissions */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            {/* Header info */}
            <div className="pb-4 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                <span>{selectedAssignment.subject}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedAssignment.classGroup}</span>
                <span aria-hidden="true">·</span>
                <span>Max Marks: {selectedAssignment.totalMarks}</span>
              </div>
              <h2 className="text-lg font-bold text-slate-900">{selectedAssignment.title}</h2>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                {selectedAssignment.instructions}
              </p>

              {selectedAssignment.attachmentName && (
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-700">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  <span>{selectedAssignment.attachmentName}</span>
                </div>
              )}
            </div>

            {/* Submissions Table */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Student Submissions ({selectedAssignment.submissions.length})
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  {selectedAssignment.submissions.filter((s) => s.status === 'graded').length} graded
                </span>
              </div>

              {selectedAssignment.submissions.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <p className="text-xs">No student submissions uploaded yet for this assignment.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                  {selectedAssignment.submissions.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-3.5 flex items-center justify-between text-xs hover:bg-slate-50/70 transition-colors"
                    >
                      <div>
                        <div className="font-bold text-slate-900">{sub.studentName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          Submitted {sub.submittedAt} · File: {sub.fileAttachment}
                        </div>
                        {sub.feedback && (
                          <div className="text-[11px] text-slate-600 italic mt-1">
                            Teacher Feedback: "{sub.feedback}"
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-3">
                        {sub.score !== undefined ? (
                          <div className="text-right">
                            <span className="font-mono font-bold text-sm text-emerald-700 tabular-nums">
                              {sub.score} / {sub.maxScore}
                            </span>
                            <div className="text-[10px] text-slate-400 uppercase font-semibold">Graded</div>
                          </div>
                        ) : (
                          <span className="text-amber-700 font-semibold text-[11px]">Pending Review</span>
                        )}

                        <button
                          onClick={() => handleOpenGradeModal(sub)}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>{sub.score !== undefined ? 'Edit Grade' : 'Grade'}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* CREATE ASSIGNMENT MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Upload New Course Assignment</h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAssignment} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assignment Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Newton’s Second Law Experimental Report"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="AP Physics">AP Physics</option>
                    <option value="Pure Mathematics">Pure Mathematics</option>
                    <option value="Inorganic Chemistry">Inorganic Chemistry</option>
                    <option value="Computer Science">Computer Science</option>
                    <option value="English Rhetoric">English Rhetoric</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Class</label>
                  <select
                    value={classGroup}
                    onChange={(e) => setClassGroup(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="Grade 10-A">Grade 10-A (STEM Honors)</option>
                    <option value="Grade 11-B">Grade 11-B (AP Physics)</option>
                    <option value="Class 8">Class 8 (Computer Science)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Submission Deadline</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Maximum Marks</label>
                  <input
                    type="number"
                    required
                    value={totalMarks}
                    onChange={(e) => setTotalMarks(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Attachment File Name</label>
                <input
                  type="text"
                  value={attachmentName}
                  onChange={(e) => setAttachmentName(e.target.value)}
                  placeholder="e.g. Lab_Manual_Ch04.pdf"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Instructions & Problem Prompts</label>
                <textarea
                  rows={3}
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="Provide detailed submission requirements, rubric weights, and expected formats..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Publish Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GRADE SUBMISSION MODAL */}
      {activeSubmissionToGrade && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Grade Student Submission</h3>
                <p className="text-xs text-slate-500">{activeSubmissionToGrade.studentName}</p>
              </div>
              <button
                onClick={() => setActiveSubmissionToGrade(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitGrade} className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-[11px] text-slate-400 font-semibold uppercase">Submitted Asset</div>
                <div className="font-mono text-slate-800 font-medium mt-0.5">
                  {activeSubmissionToGrade.fileAttachment}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Awarded Score (out of {activeSubmissionToGrade.maxScore})
                </label>
                <input
                  type="number"
                  step="0.5"
                  max={activeSubmissionToGrade.maxScore}
                  min={0}
                  required
                  value={scoreInput}
                  onChange={(e) => setScoreInput(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Instructor Feedback & Remarks</label>
                <textarea
                  rows={3}
                  value={feedbackInput}
                  onChange={(e) => setFeedbackInput(e.target.value)}
                  placeholder="Provide comments on student calculations, formatting, or theoretical derivations..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveSubmissionToGrade(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Save & Publish Grade
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
