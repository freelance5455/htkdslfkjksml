import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StudentReportCard } from '../../types';
import {
  GraduationCap,
  FileText,
  Search,
  Award,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export const GradeBookView: React.FC = () => {
  const { reportCards, setSelectedReportCard } = useApp();
  const [selectedTerm, setSelectedTerm] = useState<string>('Mid-Term 2026');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCards = reportCards.filter((card) => {
    const matchesTerm = card.term === selectedTerm;
    const matchesSearch =
      card.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.rollNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.classGroup.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTerm && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Student Grade Book & Academic Report Cards
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Maintain term exam results, track GPA distributions, record faculty assessments, and issue verifiable report cards.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search student or roll no..."
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Cohort Performance Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Cohort Average GPA
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            3.86 / 4.00
          </div>
          <div className="text-[11px] text-emerald-600 mt-0.5 font-medium">+0.14 vs previous term</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Honor Roll Distinctions
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-700 mt-1 tabular-nums">
            9 Students
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">GPA exceeding 3.80</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Average Exam Attendance
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            96.8%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Zero unexcused absences during finals</div>
        </div>
      </div>

      {/* Grade Book Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="text-sm font-bold text-slate-900">
            Grade 10-A STEM Cohort Examination Matrix
          </h2>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Term:</span>
            <select
              value={selectedTerm}
              onChange={(e) => setSelectedTerm(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500"
            >
              <option value="Mid-Term 2026">Mid-Term 2026</option>
              <option value="Annual Finals 2026">Annual Finals 2026</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Student & Roll No</th>
                <th className="py-3 px-3 text-center">Calculus</th>
                <th className="py-3 px-3 text-center">Physics</th>
                <th className="py-3 px-3 text-center">Chemistry</th>
                <th className="py-3 px-3 text-center">Comp Sci</th>
                <th className="py-3 px-4 text-center">GPA</th>
                <th className="py-3 px-4 text-center">Class Rank</th>
                <th className="py-3 px-4 text-right">Official Document</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCards.map((card) => {
                const mathScore = card.subjects.find((s) => s.subject.includes('Calculus'))?.totalMarks || 90;
                const physicsScore = card.subjects.find((s) => s.subject.includes('Physics'))?.totalMarks || 88;
                const chemScore = card.subjects.find((s) => s.subject.includes('Chemistry'))?.totalMarks || 85;
                const csScore = card.subjects.find((s) => s.subject.includes('Computer'))?.totalMarks || 95;

                return (
                  <tr key={card.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{card.studentName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {card.rollNumber} · {card.classGroup}
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono font-medium">{mathScore}</td>
                    <td className="py-3.5 px-3 text-center font-mono font-medium">{physicsScore}</td>
                    <td className="py-3.5 px-3 text-center font-mono font-medium">{chemScore}</td>
                    <td className="py-3.5 px-3 text-center font-mono font-medium">{csScore}</td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded text-xs">
                        {card.overallGPA.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono font-semibold text-slate-700">
                      Rank #{card.classRank}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setSelectedReportCard(card)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View Report Card</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
