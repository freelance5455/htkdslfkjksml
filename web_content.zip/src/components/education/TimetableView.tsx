import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TimetableSlot } from '../../types';
import {
  Calendar,
  Clock,
  Plus,
  MapPin,
  User,
  X,
  Filter,
} from 'lucide-react';

export const TimetableView: React.FC = () => {
  const { timetable, addTimetableSlot } = useApp();

  const [selectedClass, setSelectedClass] = useState<string>('Grade 10-A');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New slot form state
  const [day, setDay] = useState<TimetableSlot['day']>('Monday');
  const [period, setPeriod] = useState(1);
  const [timeSlot, setTimeSlot] = useState('08:30 - 09:20');
  const [subject, setSubject] = useState('Advanced Calculus');
  const [room, setRoom] = useState('Hall 302');
  const [teacher, setTeacher] = useState('Prof. Arthur Pendelton');
  const [color, setColor] = useState('indigo');

  const days: TimetableSlot['day'][] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const periods = [
    { num: 1, time: '08:30 - 09:20' },
    { num: 2, time: '09:25 - 10:15' },
    { num: 3, time: '10:30 - 11:20' },
    { num: 4, time: '11:25 - 12:15' },
    { num: 5, time: '01:15 - 02:05' },
    { num: 6, time: '02:10 - 03:00' },
  ];

  const filteredTimetable = timetable.filter((slot) => {
    return selectedClass === 'All' || slot.classGroup === selectedClass;
  });

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    addTimetableSlot({
      day,
      period,
      timeSlot,
      subject,
      room,
      teacher,
      classGroup: selectedClass === 'All' ? 'Grade 10-A' : selectedClass,
      color,
    });
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Academic Schedules & Master Timetable
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Maintain weekly period schedules, allocate laboratory rooms, and coordinate faculty teaching assignments.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500 shadow-xs"
          >
            <option value="Grade 10-A">Grade 10-A (STEM Honors)</option>
            <option value="Grade 11-B">Grade 11-B (AP Physics)</option>
            <option value="All">All Cohorts Master Schedule</option>
          </select>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Class Period</span>
          </button>
        </div>
      </div>

      {/* Timetable Grid View */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px]">
                <th className="py-3 px-4 w-32 border-r border-slate-200 text-left">Period / Time</th>
                {days.map((d) => (
                  <th key={d} className="py-3 px-4 border-r last:border-r-0 border-slate-200 text-center font-bold">
                    {d}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {periods.map((p) => (
                <tr key={p.num} className="hover:bg-slate-50/50 transition-colors">
                  {/* Period Time Header */}
                  <td className="py-4 px-4 bg-slate-50/80 border-r border-slate-200">
                    <div className="font-bold text-slate-900 font-mono">Period {p.num}</div>
                    <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {p.time}
                    </div>
                  </td>

                  {/* Days */}
                  {days.map((d) => {
                    const slot = filteredTimetable.find((s) => s.day === d && s.period === p.num);
                    return (
                      <td key={d} className="py-2.5 px-3 border-r last:border-r-0 border-slate-200 align-top min-w-[150px]">
                        {slot ? (
                          <div className="p-3 rounded-lg border border-slate-200 bg-white hover:border-indigo-300 transition-all shadow-2xs">
                            <div className="font-bold text-slate-900 text-xs mb-1">
                              {slot.subject}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
                              <MapPin className="w-3 h-3 text-slate-400" />
                              <span>{slot.room}</span>
                            </div>
                            <div className="text-[11px] text-slate-600 flex items-center gap-1">
                              <User className="w-3 h-3 text-slate-400" />
                              <span className="truncate">{slot.teacher}</span>
                            </div>
                          </div>
                        ) : (
                          <div className="h-full min-h-[70px] flex items-center justify-center rounded-lg border border-dashed border-slate-100 hover:border-slate-300 transition-colors group cursor-pointer"
                            onClick={() => {
                              setDay(d);
                              setPeriod(p.num);
                              setTimeSlot(p.time);
                              setIsAddModalOpen(true);
                            }}
                          >
                            <span className="text-[11px] text-slate-300 group-hover:text-slate-500">
                              + Assign
                            </span>
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD PERIOD MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Schedule Class Period</h2>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSlot} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Day of Week</label>
                  <select
                    value={day}
                    onChange={(e) => setDay(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    {days.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Period Slot</label>
                  <select
                    value={period}
                    onChange={(e) => {
                      const pNum = parseInt(e.target.value, 10);
                      setPeriod(pNum);
                      setTimeSlot(periods.find((x) => x.num === pNum)?.time || '08:30 - 09:20');
                    }}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    {periods.map((p) => (
                      <option key={p.num} value={p.num}>
                        Period {p.num} ({p.time})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject / Course</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Theoretical Physics"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room / Lab Number</label>
                  <input
                    type="text"
                    required
                    value={room}
                    onChange={(e) => setRoom(e.target.value)}
                    placeholder="e.g. Lab B-12"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assigned Teacher</label>
                  <input
                    type="text"
                    required
                    value={teacher}
                    onChange={(e) => setTeacher(e.target.value)}
                    placeholder="e.g. Prof. Arthur Pendelton"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Save Schedule Slot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
