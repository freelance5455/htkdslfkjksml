import React, { useState } from 'react';
import { X, Send, Bot, Volume2, Sparkles, User, RefreshCw } from 'lucide-react';
import { AgeGroup, ChildProfile } from '../../types/education';
import { speakArabic, playPop, playSuccess } from '../../utils/soundEffects';

interface AiSimsimModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ChildProfile;
  ageGroup: AgeGroup;
}

interface Message {
  sender: 'user' | 'simsim';
  text: string;
}

export const AiSimsimModal: React.FC<AiSimsimModalProps> = ({
  isOpen,
  onClose,
  profile,
  ageGroup
}) => {
  if (!isOpen) return null;

  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'simsim',
      text: `مَرْحَباً بِكَ يَا بَطَلِي ${profile.name}! أَنَا سِمْسِم، مُعَلِّمُكَ الذَّكِيُّ وَصَدِيقُكَ اللَّطِيفُ. تَسْتَطِيعُ أَنْ تَسْأَلَنِي عَنْ أَيِّ شَيْءٍ فِي الْحُرُوفِ، الرِّيَاضِيَّاتِ، أَوْ الْعُلُومِ وَالْفَضَاءِ! مَاذَا نَتَعَلَّمُ الْيَوْمَ؟ 🌟`
    }
  ]);

  const quickPrompts = [
    'لِمَاذَا تَلْمَعُ النُّجُومُ فِي السَّمَاءِ؟ ✨',
    'كَيْفَ يَضُخُّ الْقَلْبُ الدَّمَ؟ ❤️',
    'احْكِ لِي نُكْتَةً لَطِيفَةً وَمُضْحِكَةً! 😄',
    'كَيْفَ أَحْفَظُ جَدْوَلَ الضَّرْبِ بِسُهُولَةٍ؟ ✖️',
    'مَا هُوَ الْفَرْقُ بَيْنَ الْآحَادِ وَالْعَشَرَاتِ؟ 🔢'
  ];

  const handleSend = async (customText?: string) => {
    const queryToSend = customText || inputQuery;
    if (!queryToSend.trim() || loading) return;

    playPop();
    const userMsg = queryToSend.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setInputQuery('');
    setLoading(true);

    try {
      const response = await fetch('/api/gemini/kids-helper', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsg,
          childName: profile.name,
          ageGroup: ageGroup
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get answer');
      }

      const data = await response.json();
      const reply = data.text || 'أحسنت يا بطل! سؤالك رائع جداً.';
      setMessages(prev => [...prev, { sender: 'simsim', text: reply }]);
      playSuccess();
    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          sender: 'simsim',
          text: 'عَفْواً يَا بَطَلِي، حَاوِلْ مَرَّةً أُخْرَى، أَنَا دَائِماً هُنَا لِمُسَاعَدَتِكَ!'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl border-2 border-amber-300 w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-scale-up">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-400 to-orange-500 p-4 sm:p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-2xl shadow-xs">
              🦉
            </div>
            <div>
              <h3 className="font-black text-lg sm:text-xl flex items-center gap-1.5">
                <span>الْمُعَلِّمُ الذَّكِيُّ سِمْسِم</span>
                <Sparkles className="w-4 h-4 text-amber-200 animate-spin" />
              </h3>
              <p className="text-xs text-amber-100 font-medium">
                مساعد ذكي وممتع مخصص للأطفال من سن 5 إلى 10 سنوات
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="bg-amber-50/70 p-2.5 border-b border-amber-200 overflow-x-auto no-scrollbar flex items-center gap-2">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              disabled={loading}
              onClick={() => handleSend(p)}
              className="px-3 py-1 bg-white hover:bg-amber-100 border border-amber-300 rounded-full text-xs font-bold text-slate-700 whitespace-nowrap transition-all shadow-2xs active:scale-95 disabled:opacity-40"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Conversation Message List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[450px]">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${m.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-base shrink-0 ${
                  m.sender === 'user' ? 'bg-blue-600 text-white' : 'bg-amber-100 border border-amber-300'
                }`}
              >
                {m.sender === 'user' ? '👦' : '🦉'}
              </div>

              <div
                className={`max-w-[82%] p-4 rounded-2xl text-sm sm:text-base leading-relaxed font-medium shadow-2xs relative group ${
                  m.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-none'
                    : 'bg-amber-50/90 text-slate-800 border border-amber-200 rounded-tl-none'
                }`}
              >
                <p className="font-['Cairo',sans-serif]">{m.text}</p>

                {m.sender === 'simsim' && (
                  <button
                    onClick={() => {
                      playPop();
                      speakArabic(m.text);
                    }}
                    className="mt-2.5 px-2.5 py-1 rounded-lg bg-amber-200/60 hover:bg-amber-200 text-amber-900 text-xs font-bold flex items-center gap-1 transition-colors"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>اسْتَمِعْ لِسِمْسِم</span>
                  </button>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-amber-700 text-xs font-bold p-2 bg-amber-50 rounded-xl w-fit animate-pulse">
              <span>🦉 سِمْسِم يُفَكِّرُ فِي إِجَابَةٍ ذَكِيَّةٍ لَكَ...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
          <input
            id="simsim-query-input"
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleSend(); }}
            placeholder="اسأل سمسم أي سؤال يا بطل... (مثال: كيف أجمع 5 مع 3؟)"
            className="flex-1 px-4 py-3 rounded-2xl border-2 border-amber-300 bg-white text-slate-800 text-sm sm:text-base focus:outline-none focus:border-amber-500 shadow-inner"
          />

          <button
            id="simsim-send-btn"
            disabled={!inputQuery.trim() || loading}
            onClick={() => handleSend()}
            className="p-3.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-bold transition-all shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5 rotate-180" />
          </button>
        </div>

      </div>
    </div>
  );
};
