import React, { useState } from 'react';
import { Atom, Volume2, Sparkles, CheckCircle2, ChevronLeft, ChevronRight, Beaker, HelpCircle, Star } from 'lucide-react';
import { SCIENCE_LESSONS } from '../../data/curriculumData';
import { ScienceLesson, AgeGroup } from '../../types/education';
import { speakArabic, playSuccess, playIncorrect, playPop, playStarTwinkle } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface ScienceModuleProps {
  ageGroup: AgeGroup;
  onEarnStars: (amount: number) => void;
}

export const ScienceModule: React.FC<ScienceModuleProps> = ({ ageGroup, onEarnStars }) => {
  const [selectedLessonIndex, setSelectedLessonIndex] = useState<number>(0);
  const currentLesson = SCIENCE_LESSONS[selectedLessonIndex] || SCIENCE_LESSONS[0];

  // Interactive Matter Simulator State (صلب، سائل، غاز)
  const [matterTemp, setMatterTemp] = useState<number>(20); // Celsius

  // Virtual Sink or Float Experiment State
  const [testedItems, setTestedItems] = useState<{ name: string; icon: string; density: string; floats: boolean; state: 'shelf' | 'tank' }[]>([
    { name: 'قِطْعَةُ خَشَبٍ', icon: '🪵', density: 'خفيفة وبها مسامات هواء', floats: true, state: 'shelf' },
    { name: 'عُمْلَةٌ مَعْدِنِيَّةٌ', icon: '🪙', density: 'معدن ثقيل عالي الكثافة', floats: false, state: 'shelf' },
    { name: 'تُفَّاحَةٌ طَازَجَةٌ', icon: '🍎', density: 'تحتوي على 25% هواء', floats: true, state: 'shelf' },
    { name: 'مِفْتَاحُ حَدِيدٍ', icon: '🔑', density: 'حديد صلب ثقيل', floats: false, state: 'shelf' },
    { name: 'كُرَةٌ بِلَاسْتِيكِيَّةٌ', icon: '⚽', density: 'مجوفة ومليئة بالهواء', floats: true, state: 'shelf' }
  ]);

  // Quiz state for current lesson
  const [selectedQuizOpt, setSelectedQuizOpt] = useState<number | null>(null);
  const [quizAnswered, setQuizAnswered] = useState<boolean>(false);

  const handleDropIntoTank = (index: number) => {
    playPop();
    const item = testedItems[index];
    setTestedItems(prev => prev.map((it, i) => i === index ? { ...it, state: 'tank' } : it));

    setTimeout(() => {
      if (item.floats) {
        playSuccess();
        speakArabic(`${item.name} تطفو فوق سطح الماء لأن كثافتها أقل من الماء!`);
      } else {
        playPop();
        speakArabic(`${item.name} تغوص في القاع لأن كثافتها ثقيلة وأعلى من الماء!`);
      }
    }, 400);
  };

  const handleResetExperiment = () => {
    playPop();
    setTestedItems(prev => prev.map(it => ({ ...it, state: 'shelf' })));
  };

  const handleQuizAnswer = (optIndex: number) => {
    if (quizAnswered) return;
    setSelectedQuizOpt(optIndex);
    setQuizAnswered(true);

    if (optIndex === currentLesson.quizQuestion.correctIndex) {
      playSuccess();
      playStarTwinkle();
      confetti({ particleCount: 60, spread: 60 });
      onEarnStars(3);
      speakArabic(currentLesson.quizQuestion.explanation);
    } else {
      playIncorrect();
      speakArabic('إجابة غير صحيحة، راجع ملخص الدرس وحاول ثانية!');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Lesson Selector Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar bg-white p-3 rounded-2xl border border-emerald-200">
        {SCIENCE_LESSONS.map((lesson, idx) => {
          const isSelected = selectedLessonIndex === idx;
          return (
            <button
              key={lesson.id}
              id={`science-lesson-${lesson.id}`}
              onClick={() => {
                playPop();
                setSelectedLessonIndex(idx);
                setSelectedQuizOpt(null);
                setQuizAnswered(false);
              }}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm border-2 transition-all ${
                isSelected
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm scale-102'
                  : 'bg-emerald-50/70 hover:bg-emerald-100 text-emerald-950 border-emerald-200'
              }`}
            >
              <span className="text-xl">{lesson.icon}</span>
              <span>{lesson.title}</span>
            </button>
          );
        })}
      </div>

      {/* Hero Lesson Header */}
      <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-r ${currentLesson.coverColor} shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4`}>
        <div>
          <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-black uppercase tracking-wider mb-2 inline-block">
            {currentLesson.categoryAr}
          </span>
          <h2 className="text-2xl sm:text-3xl font-black mb-2 flex items-center gap-2">
            <span>{currentLesson.icon}</span>
            <span>{currentLesson.title}</span>
          </h2>
          <p className="text-sm sm:text-base font-medium opacity-90 max-w-2xl">
            {currentLesson.summary}
          </p>
        </div>

        <button
          onClick={() => {
            playPop();
            speakArabic(`${currentLesson.title}. ${currentLesson.summary}`);
          }}
          className="px-4 py-2.5 rounded-2xl bg-white text-slate-800 font-bold text-xs sm:text-sm shadow-sm flex items-center gap-2 hover:bg-amber-50 active:scale-95 transition-all self-start sm:self-auto"
        >
          <Volume2 className="w-4 h-4 text-emerald-600" />
          <span>اسْتَمِعْ لِلْمُلَخَّصِ</span>
        </button>
      </div>

      {/* Lesson Content Sections */}
      <div className="space-y-6">
        {currentLesson.sections.map((sec, sIdx) => (
          <div key={sIdx} className="bg-white p-6 rounded-3xl border border-emerald-200 shadow-sm">
            <h3 className="text-lg sm:text-xl font-extrabold text-slate-800 mb-3 flex items-center gap-2">
              <span className="w-2 h-6 bg-emerald-500 rounded-full inline-block"></span>
              <span>{sec.heading}</span>
            </h3>
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed font-medium mb-4">
              {sec.text}
            </p>

            {/* Visual Cards if present (e.g. 8 planets or bodily organs) */}
            {sec.visualItems && sec.visualItems.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {sec.visualItems.map((item, iIdx) => (
                  <div
                    key={iIdx}
                    onClick={() => {
                      playPop();
                      speakArabic(`${item.name}، ${item.desc}`);
                    }}
                    className="p-4 rounded-2xl bg-emerald-50/60 hover:bg-emerald-100/80 border border-emerald-200 cursor-pointer transition-all hover:scale-102 flex flex-col items-center text-center group"
                  >
                    <span className="text-4xl sm:text-5xl mb-2 group-hover:scale-110 transition-transform">
                      {item.icon}
                    </span>
                    <span className="font-extrabold text-base text-emerald-950 mb-1">
                      {item.name}
                    </span>
                    <p className="text-xs text-slate-600 leading-normal">
                      {item.desc}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Interactive Simulation: Matter State Simulator (if on Matter lesson) */}
      {currentLesson.id === 'sci-matter' && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-cyan-300 shadow-sm text-center">
          <h3 className="text-xl font-black text-slate-800 mb-2">
            🌡️ مُحَاكِي حَالَاتِ الْمَادَّةِ (غَيِّرْ دَرَجَةَ الْحَرَارَةِ)
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            حرّك المؤشر لمشاهدة كيف يتحول الماء بين الصلب والسائل والغاز:
          </p>

          <div className="max-w-md mx-auto mb-6">
            <div className="flex justify-between text-xs font-black text-slate-500 mb-1">
              <span>شديد البرودة (-20°C)</span>
              <span className="text-cyan-700 font-extrabold text-sm">{matterTemp}° مئوية</span>
              <span>شديد الغليان (120°C)</span>
            </div>
            <input
              type="range"
              min="-20"
              max="120"
              value={matterTemp}
              onChange={(e) => setMatterTemp(parseInt(e.target.value, 10))}
              className="w-full h-3 bg-cyan-100 rounded-lg appearance-none cursor-pointer accent-cyan-600"
            />
          </div>

          {/* Visualization box */}
          <div className="inline-block p-6 rounded-3xl border-2 border-cyan-200 min-w-[260px] bg-cyan-50/50">
            {matterTemp <= 0 ? (
              <div className="animate-fade-in">
                <span className="text-6xl sm:text-7xl block mb-2">🧊</span>
                <span className="text-xl font-black text-blue-900 block">حَالَةٌ صَلْبَةٌ (جَلِيدٌ وَثَلْجٌ)</span>
                <p className="text-xs text-slate-600 mt-1">الجسيمات متراصة ومترابطة بقوة وذات شكل محدد</p>
              </div>
            ) : matterTemp >= 100 ? (
              <div className="animate-fade-in">
                <span className="text-6xl sm:text-7xl block mb-2">💨♨️</span>
                <span className="text-xl font-black text-rose-900 block">حَالَةٌ غَازِيَّةٌ (بُخَارُ مَاءٍ)</span>
                <p className="text-xs text-slate-600 mt-1">الجسيمات حرة الحركة تماماً ومتباعدة وتملأ الفضاء</p>
              </div>
            ) : (
              <div className="animate-fade-in">
                <span className="text-6xl sm:text-7xl block mb-2">💧🌊</span>
                <span className="text-xl font-black text-cyan-900 block">حَالَةٌ سَائِلَةٌ (مَاءٌ مُنْعِشٌ)</span>
                <p className="text-xs text-slate-600 mt-1">الجسيمات تنزلق فوق بعضها وتأخذ شكل الإناء</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Interactive Simulation: Sink or Float Experiment (if on Experiments lesson) */}
      {currentLesson.id === 'sci-experiments' && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-amber-300 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-black text-slate-800">
                🧪 مُخْتَبَرُ الطَّفْوِ وَالْغَرَقِ التَّفَاعُلِيُّ
              </h3>
              <p className="text-xs text-slate-500">
                اضغط على أي عنصر لإسقاطه في حوض الماء وشاهد ماذا يحدث له!
              </p>
            </div>
            <button
              onClick={handleResetExperiment}
              className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
            >
              إِعَادَةُ التَّجْرِبَةِ
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* Shelf Items */}
            <div className="md:col-span-5 bg-amber-50/60 p-4 rounded-2xl border border-amber-200">
              <span className="text-xs font-bold text-amber-900 block mb-3">
                الأجسام الجاهزة للاختبار (اضغط عليها):
              </span>
              <div className="space-y-2">
                {testedItems.map((item, idx) => (
                  <button
                    key={idx}
                    disabled={item.state === 'tank'}
                    onClick={() => handleDropIntoTank(idx)}
                    className={`w-full p-3 rounded-xl border flex items-center justify-between text-right transition-all ${
                      item.state === 'tank'
                        ? 'bg-slate-100 border-slate-200 opacity-40 cursor-not-allowed'
                        : 'bg-white hover:bg-amber-100 border-amber-300 shadow-xs active:scale-98'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      <span className="font-bold text-sm text-slate-800">{item.name}</span>
                    </div>
                    <span className="text-[11px] text-slate-500">{item.density}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Water Tank Simulation */}
            <div className="md:col-span-7 bg-sky-100 border-4 border-sky-400 rounded-3xl p-4 flex flex-col justify-between min-h-[280px] relative overflow-hidden shadow-inner">
              
              {/* Surface Level (Floating zone) */}
              <div className="h-24 border-b-2 border-dashed border-sky-300 flex items-center justify-around px-4">
                {testedItems.filter(it => it.state === 'tank' && it.floats).map((it, idx) => (
                  <div key={idx} className="flex flex-col items-center animate-bounce">
                    <span className="text-4xl">{it.icon}</span>
                    <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full mt-1">
                      يطفو ⛵
                    </span>
                  </div>
                ))}
              </div>

              {/* Water Middle */}
              <div className="text-center text-xs font-bold text-sky-700/60 select-none py-4">
                🌊 مَاءٌ نَقِيٌّ 🌊
              </div>

              {/* Deep Bottom (Sinking zone) */}
              <div className="h-20 bg-sky-200/80 rounded-b-2xl flex items-center justify-around px-4">
                {testedItems.filter(it => it.state === 'tank' && !it.floats).map((it, idx) => (
                  <div key={idx} className="flex flex-col items-center">
                    <span className="text-4xl">{it.icon}</span>
                    <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full mt-1">
                      يغوص ⚓
                    </span>
                  </div>
                ))}
              </div>

            </div>

          </div>

        </div>
      )}

      {/* Interactive Fact & Lesson Quiz Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-emerald-300 shadow-sm">
        
        {/* Did You Know Fact */}
        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-3 mb-6">
          <span className="text-3xl">💡</span>
          <div>
            <span className="font-extrabold text-amber-900 text-sm block">هَلْ تَعْلَمُ؟ (مَعْلُومَةٌ سِحْرِيَّةٌ):</span>
            <p className="text-xs sm:text-sm text-slate-700 font-medium">
              {currentLesson.interactiveFact}
            </p>
          </div>
        </div>

        {/* Quick Lesson Check Quiz */}
        <div className="border-t border-slate-100 pt-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              تَحَدِّي اسْتِيعَابِ الدَّرْسِ 🎯
            </span>
          </div>

          <h4 className="text-base sm:text-lg font-black text-slate-800 mb-4">
            {currentLesson.quizQuestion.question}
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            {currentLesson.quizQuestion.options.map((opt, oIdx) => {
              const isSelected = selectedQuizOpt === oIdx;
              const isCorrect = oIdx === currentLesson.quizQuestion.correctIndex;
              let btnCls = 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-emerald-50';

              if (quizAnswered && isSelected) {
                btnCls = isCorrect ? 'bg-emerald-500 text-white border-emerald-600' : 'bg-rose-500 text-white border-rose-600';
              } else if (quizAnswered && isCorrect) {
                btnCls = 'bg-emerald-500 text-white border-emerald-600';
              }

              return (
                <button
                  key={oIdx}
                  onClick={() => handleQuizAnswer(oIdx)}
                  className={`p-3.5 rounded-2xl font-bold text-sm sm:text-base border-2 text-right transition-all ${btnCls}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {quizAnswered && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl text-emerald-900 font-bold text-sm animate-fade-in">
              {currentLesson.quizQuestion.explanation}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
