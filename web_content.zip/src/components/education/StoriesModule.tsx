import React, { useState } from 'react';
import { BookOpen, Volume2, VolumeX, ArrowRight, ArrowLeft, Star, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';
import { STORIES_LIST } from '../../data/curriculumData';
import { Story, AgeGroup } from '../../types/education';
import { speakArabic, stopSpeaking, playSuccess, playIncorrect, playPop, playStarTwinkle } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface StoriesModuleProps {
  ageGroup: AgeGroup;
  onEarnStars: (amount: number) => void;
}

export const StoriesModule: React.FC<StoriesModuleProps> = ({ ageGroup, onEarnStars }) => {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number>(0);
  const currentStory = STORIES_LIST[selectedStoryIndex] || STORIES_LIST[0];
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [isNarrating, setIsNarrating] = useState<boolean>(false);

  // Comprehension questions state
  const [showQuestions, setShowQuestions] = useState<boolean>(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [questionsSubmitted, setQuestionsSubmitted] = useState<boolean>(false);

  const page = currentStory.pages[currentPage];

  const handleReadPage = () => {
    if (isNarrating) {
      stopSpeaking();
      setIsNarrating(false);
    } else {
      setIsNarrating(true);
      playPop();
      speakArabic(page.text, () => {
        setIsNarrating(false);
      });
    }
  };

  const handleNextPage = () => {
    playPop();
    stopSpeaking();
    setIsNarrating(false);
    if (currentPage < currentStory.pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    } else {
      setShowQuestions(true);
    }
  };

  const handlePrevPage = () => {
    playPop();
    stopSpeaking();
    setIsNarrating(false);
    if (showQuestions) {
      setShowQuestions(false);
    } else if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  const handleSelectStory = (idx: number) => {
    playPop();
    stopSpeaking();
    setIsNarrating(false);
    setSelectedStoryIndex(idx);
    setCurrentPage(0);
    setShowQuestions(false);
    setSelectedAnswers({});
    setQuestionsSubmitted(false);
  };

  const handleAnswerQuestion = (qIdx: number, optIdx: number) => {
    if (questionsSubmitted) return;
    playPop();
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleSubmitQuiz = () => {
    setQuestionsSubmitted(true);
    let correctCount = 0;
    currentStory.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });

    if (correctCount === currentStory.questions.length) {
      playSuccess();
      playStarTwinkle();
      confetti({ particleCount: 70, spread: 70 });
      onEarnStars(5);
      speakArabic('ما شاء الله عليك! لقد فهمت القصة واستوعبت الحكمة بامتياز!');
    } else {
      playIncorrect();
      speakArabic('أحسنت المحاولة! راجع إجاباتك وتعلم من القصة الجميلة.');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Story Selector Cards */}
      <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
        {STORIES_LIST.map((story, idx) => {
          const isSelected = selectedStoryIndex === idx;
          return (
            <button
              key={story.id}
              id={`story-btn-${story.id}`}
              onClick={() => handleSelectStory(idx)}
              className={`flex-shrink-0 flex items-center gap-2.5 px-4 py-3 rounded-2xl border-2 transition-all ${
                isSelected
                  ? 'bg-rose-500 text-white border-rose-600 shadow-md scale-102'
                  : 'bg-white hover:bg-rose-50 text-slate-800 border-rose-200'
              }`}
            >
              <span className="text-2xl">{story.coverEmoji}</span>
              <div className="text-right">
                <span className="font-extrabold text-xs sm:text-sm block whitespace-nowrap">
                  {story.title}
                </span>
                <span className={`text-[10px] font-bold ${isSelected ? 'text-rose-100' : 'text-slate-500'}`}>
                  {story.category}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Storybook Container */}
      <div className="bg-white rounded-3xl border-2 border-rose-200 shadow-sm p-6 sm:p-10 relative overflow-hidden">
        
        {/* Book Header Bar */}
        <div className="flex items-center justify-between border-b border-rose-100 pb-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="text-2xl sm:text-3xl">{currentStory.coverEmoji}</span>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-slate-800">
                {currentStory.title}
              </h3>
              <span className="text-xs text-rose-700 font-bold bg-rose-50 px-2.5 py-0.5 rounded-full">
                {currentStory.category}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="read-story-aloud-btn"
              onClick={handleReadPage}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
                isNarrating
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200'
              }`}
            >
              {isNarrating ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{isNarrating ? 'إِيقَافُ الْقِرَاءَةِ' : 'اقْرَأْ لِي'}</span>
            </button>
          </div>
        </div>

        {/* Story Pages View */}
        {!showQuestions ? (
          <div className="space-y-6">
            
            {/* Animated Scene Illustration */}
            <div className="w-full bg-gradient-to-br from-amber-50 to-rose-50 border border-rose-200 rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center text-center shadow-inner">
              <span className="text-6xl sm:text-8xl mb-2 tracking-widest animate-pulse select-none">
                {page.sceneEmoji}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {page.illustration}
              </span>
            </div>

            {/* Formatted Tashkeel Story Paragraph */}
            <div className="p-4 sm:p-6 bg-rose-50/40 rounded-2xl border border-rose-100">
              <p className="text-lg sm:text-2xl font-black text-slate-800 leading-loose text-center font-['Cairo',sans-serif]">
                {page.text}
              </p>
            </div>

            {/* Page Navigation & Pagination */}
            <div className="flex items-center justify-between pt-4 border-t border-rose-100">
              <button
                disabled={currentPage === 0}
                onClick={handlePrevPage}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs sm:text-sm flex items-center gap-1.5 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-200"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الصَّفْحَةُ السَّابِقَةُ</span>
              </button>

              <div className="text-xs sm:text-sm font-bold text-slate-500">
                صَفْحَةُ {currentPage + 1} مِنْ {currentStory.pages.length}
              </div>

              <button
                onClick={handleNextPage}
                className="px-4 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 hover:bg-rose-700 shadow-sm"
              >
                <span>{currentPage === currentStory.pages.length - 1 ? 'أَسْئِلَةُ الْفَهْمِ 🎯' : 'الصَّفْحَةُ التَّالِيَةُ'}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

          </div>
        ) : (
          /* Comprehension Quiz View */
          <div className="space-y-6 animate-fade-in">
            
            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-center">
              <span className="text-2xl mb-1 block">💡</span>
              <h4 className="font-extrabold text-amber-900 text-base mb-1">
                الْحِكْمَةُ وَالْعِبْرَةُ الْمُسْتَفَادَةُ:
              </h4>
              <p className="text-sm text-slate-700 font-medium">
                {currentStory.moral}
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="text-base sm:text-lg font-black text-slate-800">
                اخْتَبِرْ فَهْمَكَ لِلْقِصَّةِ لِتَرْبَحَ النُّجُومَ:
              </h4>

              {currentStory.questions.map((q, qIdx) => (
                <div key={qIdx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <p className="font-black text-sm sm:text-base text-slate-800 mb-3">
                    {qIdx + 1}. {q.question}
                  </p>
                  <div className="space-y-2">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = selectedAnswers[qIdx] === optIdx;
                      const isCorrect = optIdx === q.correctIndex;
                      let optCls = 'bg-white border-slate-200 text-slate-700 hover:bg-rose-50';

                      if (questionsSubmitted) {
                        if (isCorrect) {
                          optCls = 'bg-emerald-500 text-white border-emerald-600';
                        } else if (isSelected && !isCorrect) {
                          optCls = 'bg-rose-500 text-white border-rose-600';
                        }
                      } else if (isSelected) {
                        optCls = 'bg-rose-100 border-rose-400 text-rose-950 font-bold';
                      }

                      return (
                        <button
                          key={optIdx}
                          disabled={questionsSubmitted}
                          onClick={() => handleAnswerQuestion(qIdx, optIdx)}
                          className={`w-full p-3 rounded-xl border text-right text-xs sm:text-sm transition-all font-medium ${optCls}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between border-t border-rose-100 pt-4">
              <button
                onClick={handlePrevPage}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs sm:text-sm flex items-center gap-1.5"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الْعَوْدَةُ لِلْقِصَّةِ</span>
              </button>

              {!questionsSubmitted ? (
                <button
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(selectedAnswers).length < currentStory.questions.length}
                  className="px-6 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-sm shadow-md disabled:opacity-40 hover:bg-rose-700 transition-all"
                >
                  إِرْسَالُ الْإِجَابَاتِ 🌟
                </button>
              ) : (
                <button
                  onClick={() => {
                    setQuestionsSubmitted(false);
                    setSelectedAnswers({});
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs sm:text-sm flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إِعَادَةُ الِاخْتِبَارِ</span>
                </button>
              )}
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
