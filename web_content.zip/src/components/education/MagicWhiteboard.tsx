import React, { useRef, useState, useEffect } from 'react';
import { Palette, Eraser, Trash2, Download, Volume2, Sparkles, Pencil } from 'lucide-react';
import { ARABIC_LETTERS } from '../../data/curriculumData';
import { speakArabic, playPop, playSuccess } from '../../utils/soundEffects';

interface MagicWhiteboardProps {
  initialLetter?: string;
}

export const MagicWhiteboard: React.FC<MagicWhiteboardProps> = ({ initialLetter }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [brushColor, setBrushColor] = useState<string>('#3b82f6');
  const [brushSize, setBrushSize] = useState<number>(8);
  const [isEraser, setIsEraser] = useState<boolean>(false);

  // Tracing template letter or number
  const [templateChar, setTemplateChar] = useState<string>(initialLetter || 'أ');
  const [showTemplate, setShowTemplate] = useState<boolean>(true);

  const colors = [
    { name: 'أزرق', hex: '#2563eb' },
    { name: 'أحمر', hex: '#dc2626' },
    { name: 'أخضر', hex: '#16a34a' },
    { name: 'برتقالي', hex: '#ea580c' },
    { name: 'بنفسجي', hex: '#9333ea' },
    { name: 'وردي', hex: '#db2777' },
    { name: 'أصفر', hex: '#ca8a04' },
    { name: 'أسود', hex: '#1e293b' }
  ];

  useEffect(() => {
    if (initialLetter) {
      setTemplateChar(initialLetter);
    }
  }, [initialLetter]);

  // Canvas drawing handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = brushSize;
    ctx.strokeStyle = isEraser ? '#ffffff' : brushColor;

    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    playPop();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const downloadDrawing = () => {
    playPop();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `لوحة-الطفل-البطل-${templateChar}.png`;
    link.href = canvas.toDataURL();
    link.click();
    playSuccess();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Controls Bar */}
      <div className="bg-white p-4 rounded-3xl border border-cyan-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        
        {/* Colors Palette */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 hidden sm:inline">الألوان:</span>
          {colors.map((c) => (
            <button
              key={c.hex}
              onClick={() => {
                playPop();
                setBrushColor(c.hex);
                setIsEraser(false);
              }}
              style={{ backgroundColor: c.hex }}
              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full transition-transform shadow-xs ${
                brushColor === c.hex && !isEraser ? 'scale-125 ring-3 ring-cyan-400' : 'hover:scale-110'
              }`}
              title={c.name}
            />
          ))}

          {/* Eraser */}
          <button
            onClick={() => {
              playPop();
              setIsEraser(!isEraser);
            }}
            className={`p-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-1 ${
              isEraser
                ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'
            }`}
            title="ممحاة"
          >
            <Eraser className="w-4 h-4" />
            <span className="hidden sm:inline">مِمْحَاة</span>
          </button>
        </div>

        {/* Thickness & Tracing toggle */}
        <div className="flex items-center gap-2">
          
          <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-1 rounded-xl">
            <span className="text-xs font-bold text-slate-600">سُمْكُ الْخَطِّ:</span>
            {[4, 8, 16].map((s) => (
              <button
                key={s}
                onClick={() => { playPop(); setBrushSize(s); }}
                className={`w-6 h-6 rounded-lg text-xs font-black ${
                  brushSize === s ? 'bg-cyan-600 text-white' : 'bg-white text-slate-700'
                }`}
              >
                {s === 4 ? '1' : s === 8 ? '2' : '3'}
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              playPop();
              setShowTemplate(!showTemplate);
            }}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all border ${
              showTemplate
                ? 'bg-cyan-100 text-cyan-900 border-cyan-300'
                : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            {showTemplate ? 'إِخْفَاءُ نَمُوذَجِ التَّتَبُّعِ' : 'إِظْهَارُ نَمُوذَجِ التَّتَبُّعِ'}
          </button>

          <button
            onClick={clearCanvas}
            className="p-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 transition-all border border-slate-200"
            title="مسح السبورة بالكامل"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <button
            onClick={downloadDrawing}
            className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white transition-all shadow-xs"
            title="حفظ الرسمة كصورة"
          >
            <Download className="w-4 h-4" />
          </button>

        </div>

      </div>

      {/* Tracing Character Quick Select */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar bg-white p-2.5 rounded-2xl border border-cyan-200">
        <span className="text-xs font-bold text-slate-500 shrink-0">اختر حرفاً أو رقماً للتتبع:</span>
        {['أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'د', 'ر', 'س', 'ص', 'ط', 'ع', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', '1', '2', '3', '4', '5'].map((ch) => (
          <button
            key={ch}
            onClick={() => {
              playPop();
              setTemplateChar(ch);
              setShowTemplate(true);
              clearCanvas();
              speakArabic(ch);
            }}
            className={`w-9 h-9 rounded-xl font-black text-base shrink-0 transition-all ${
              templateChar === ch
                ? 'bg-cyan-600 text-white shadow-xs scale-105'
                : 'bg-slate-50 hover:bg-cyan-50 text-slate-800 border border-slate-200'
            }`}
          >
            {ch}
          </button>
        ))}
      </div>

      {/* Interactive Drawing Canvas Stage */}
      <div className="bg-white rounded-3xl border-4 border-cyan-300 shadow-md p-4 flex flex-col items-center relative overflow-hidden">
        
        <div className="relative w-full aspect-[4/3] max-h-[520px] bg-amber-50/30 rounded-2xl border-2 border-dashed border-cyan-200 overflow-hidden touch-none flex items-center justify-center">
          
          {/* Faint Dotted Tracing Template in Background */}
          {showTemplate && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
              <span className="text-[180px] sm:text-[260px] font-bold text-cyan-200/60 font-['Cairo',sans-serif] leading-none">
                {templateChar}
              </span>
            </div>
          )}

          {/* Foreground Drawing Canvas */}
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full h-full cursor-crosshair relative z-10"
          />

        </div>

        {/* Tip text */}
        <p className="text-xs font-semibold text-slate-500 mt-3 text-center">
          تدرّب على تحريك إصبعك أو الفأرة على خط الحرف المنقّط لتتعلم كيفية رسمه بدقة وجمال! 🎨
        </p>

      </div>

    </div>
  );
};
