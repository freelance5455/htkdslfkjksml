import ControlsHint from './ControlsHint';

interface Props {
  score: number;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  muted: boolean;
  onToggleMute: () => void;
}

export default function PauseOverlay({ score, onResume, onRestart, onQuit, muted, onToggleMute }: Props) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-night/70 p-4 backdrop-blur-[2px] animate-fade-in">
      <div className="panel w-full max-w-sm rounded-3xl p-6 text-center animate-pop-in">
        <div className="font-display text-xs font-black tracking-[0.35em] text-ink-soft">TAKE A BREATH</div>
        <h2 className="mt-1 font-display text-4xl font-black tracking-[0.15em] text-ink">PAUSED</h2>
        <div className="mx-auto mt-3 inline-block rounded-full border border-gold-dark/40 bg-white/50 px-4 py-1 text-xs font-black uppercase tracking-wider text-ink-soft">
          Score <span className="font-display text-base text-ink">{score.toLocaleString('en-US')}</span>
        </div>

        <div className="mt-5 flex flex-col gap-3">
          <button
            type="button"
            autoFocus
            onClick={onResume}
            className="btn-gold rounded-2xl px-6 py-3.5 font-display text-xl font-black tracking-[0.15em] outline-none focus-visible:ring-4 focus-visible:ring-gold-light/70"
          >
            ▶ RESUME
          </button>
          <div className="grid grid-cols-2 gap-3">
            <button type="button" onClick={onRestart} className="rounded-xl border-2 border-gold-dark/60 bg-white/40 px-4 py-2.5 font-display text-sm font-black tracking-wider text-ink hover:bg-white/70">
              ↻ RESTART
            </button>
            <button type="button" onClick={onQuit} className="rounded-xl border-2 border-gold-dark/60 bg-white/40 px-4 py-2.5 font-display text-sm font-black tracking-wider text-ink hover:bg-white/70">
              ⌂ MENU
            </button>
          </div>
          <button type="button" onClick={onToggleMute} className="mx-auto mt-1 rounded-lg px-3 py-1 text-sm font-black text-ink-soft hover:text-ink">
            {muted ? '🔇 Sound off' : '🔊 Sound on'}
          </button>
        </div>

        <div className="mt-5 rounded-xl bg-ink/90 p-2">
          <ControlsHint compact />
        </div>
        <div className="mt-3 text-[11px] font-bold uppercase tracking-[0.2em] text-ink-soft">Esc / P to resume</div>
      </div>
    </div>
  );
}
