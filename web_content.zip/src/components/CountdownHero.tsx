import React from 'react';
import { Volume2, BellRing, Clock } from 'lucide-react';
import { NextPrayerInfo, PrayerSettings } from '../types/prayer';
import { formatPrayerTime, getHijriDate } from '../utils/prayerCalculator';
import bannerImg from '../assets/images/salat_sathi_banner_1791472538994.jpg';

interface CountdownHeroProps {
  now: Date;
  nextPrayer: NextPrayerInfo;
  settings: PrayerSettings;
  onTestAdhan: () => void;
  onTestAlarm: () => void;
}

export const CountdownHero: React.FC<CountdownHeroProps> = ({
  now,
  nextPrayer,
  settings,
  onTestAdhan,
  onTestAlarm,
}) => {
  const hijriString = getHijriDate(now);

  const formattedDate = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    timeZone: settings.timeZone === 'Asia/Dhaka' ? 'Asia/Dhaka' : undefined,
  }).format(now);

  const currentTimeStr = new Intl.DateTimeFormat('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: settings.timeFormat === '12h',
    timeZone: settings.timeZone === 'Asia/Dhaka' ? 'Asia/Dhaka' : undefined,
  }).format(now);

  return (
    <div className="relative overflow-hidden rounded-3xl border border-emerald-900/50 bg-slate-900 shadow-2xl">
      {/* Background Image with Measured Contrast Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={bannerImg}
          alt="Mosque courtyard at twilight with crescent moon"
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center scale-105 transition-transform duration-1000"
        />
        {/* Scrim ensuring > 4.5:1 text contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-900/40" />
        <div className="absolute inset-0 bg-emerald-950/30 mix-blend-multiply" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 px-6 py-8 sm:px-10 sm:py-12 max-w-4xl">
        {/* Unboxed Metadata Header */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-emerald-300/90 tracking-wide">
          <span>Dhaka, Bangladesh (BST UTC+06:00)</span>
          <span aria-hidden="true" className="text-emerald-500/50">·</span>
          <span>{hijriString}</span>
          <span aria-hidden="true" className="text-emerald-500/50">·</span>
          <span>{formattedDate}</span>
        </div>

        {/* Live Clock Display */}
        <div className="mt-3 flex items-baseline gap-3">
          <span className="font-mono text-3xl sm:text-4xl font-bold tracking-tight text-white tabular-nums drop-shadow-md">
            {currentTimeStr}
          </span>
          <span className="text-xs font-medium text-slate-300 flex items-center gap-1">
            <Clock className="w-3 h-3 text-emerald-400" />
            Live Bangladesh Time
          </span>
        </div>

        {/* Next Prayer Countdown Callout */}
        <div className="mt-6 border-l-2 border-emerald-400 pl-4 py-1">
          <div className="text-xs uppercase tracking-wider font-semibold text-emerald-300">
            {nextPrayer.isAlarm ? 'Upcoming Salah Alarm' : 'Upcoming Adhan'}
          </div>
          <div className="mt-1 flex flex-wrap items-baseline gap-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              {nextPrayer.label} at {formatPrayerTime(nextPrayer.targetTime, settings.timeFormat)}
            </h1>
          </div>
          <div className="mt-2 flex items-center gap-3">
            <span className="font-mono text-xl sm:text-2xl font-bold text-emerald-400 tabular-nums">
              {nextPrayer.formattedCountdown}
            </span>
            <span className="text-xs text-slate-300">remaining</span>
          </div>
        </div>

        {/* Progress Bar towards Next Prayer */}
        <div className="mt-4 max-w-md">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800/80">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-amber-400 transition-all duration-1000"
              style={{ width: `${Math.max(5, Math.min(100, nextPrayer.progressPercent))}%` }}
            />
          </div>
        </div>

        {/* Quick Audio Test Actions */}
        <div className="mt-7 flex flex-wrap items-center gap-3">
          <button
            onClick={onTestAdhan}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-semibold text-white shadow-lg shadow-emerald-900/30 hover:bg-emerald-500 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
          >
            <Volume2 className="w-4 h-4" />
            Test Adhan Audio
          </button>
          <button
            onClick={onTestAlarm}
            className="flex items-center gap-2 rounded-xl border border-emerald-700/60 bg-slate-900/80 backdrop-blur-sm px-4 py-2.5 text-xs font-semibold text-emerald-300 hover:bg-slate-800 hover:text-white active:scale-95 transition-all cursor-pointer whitespace-nowrap"
          >
            <BellRing className="w-4 h-4" />
            Test Salah Alarm ({settings.alarmDelayMinutes}m Delay)
          </button>
        </div>
      </div>
    </div>
  );
};
