import { useMemo, useRef, useState, type PointerEvent as PE } from "react";
import { mark } from "./Express";
import { CATEGORIES, SHOPS, ZONES, waLink, zoneLabel } from "../data/shops";
import { IMG } from "../media";
import { useStore } from "../store";
import type { Shop } from "../types";
import { IconArrow, IconCart, IconClock, IconHome, IconPin, IconSearch, IconStar, IconTruck, IconUser } from "./Icons";

export function TopNav() {
  const { setModal, zone, setZone } = useStore();
  const [active, setActive] = useState("home");
  const go = (id: string) => {
    setActive(id);
    if (id === "track") {
      window.open(waLink("Hi TurfBuddy, I want to check my order status."), "_blank");
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0b0b0b] text-white">
      <div className="mx-auto flex h-[72px] max-w-[1280px] items-center justify-between px-4 md:px-6">
        <a href="#home" className="leading-none">
          <span className="block text-[22px] font-black tracking-tight">
            <span className="text-[#FF6A00]">TURF</span>BUDDY
          </span>
          <span className="text-[8px] font-semibold tracking-[0.22em] text-white/45">FOOD. DRINKS. ERRANDS.</span>
        </a>
        <nav className="hidden items-center gap-6 text-[14px] font-semibold lg:flex">
          {[
            ["home", "Home"],
            ["restaurants", "Restaurants"],
            ["track", "Track Order"],
            ["categories", "Categories"],
            ["deals", "Deals"],
          ].map(([id, label]) => (
            <button
              key={id}
              onClick={() => go(id)}
              className={active === id ? "border-b-2 border-[#FF6A00] pb-1 text-[#FF6A00]" : "text-white/70 hover:text-white"}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <select
            value={zone}
            onChange={(e) => setZone(e.target.value as typeof zone)}
            className="hidden h-10 rounded-full border border-white/12 bg-white/6 px-3 text-[12px] font-semibold md:block"
          >
            {ZONES.map((z) => (
              <option key={z.id} value={z.id} className="text-black">
                {z.label}
              </option>
            ))}
          </select>
          <button onClick={() => setModal("search")} className="grid h-10 w-10 place-items-center rounded-full bg-white/8">
            <IconSearch className="h-4 w-4" />
          </button>
          <button onClick={() => setModal("auth")} className="grid h-10 w-10 place-items-center rounded-full bg-white/8">
            <IconUser className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}

function FeatCard({ shop }: { shop: Shop }) {
  const { openShop } = useStore();
  return (
    <button onClick={() => openShop(shop)} className="press w-[228px] shrink-0 text-left">
      <div className="relative h-[148px] overflow-hidden rounded-2xl">
        <img src={shop.image} alt="" className="h-full w-full object-cover" />
        {(() => {
          const b = mark(shop);
          return "logo" in b && b.logo ? (
            <img src={b.logo} alt="" className="absolute bottom-2 left-2 h-10 w-10 rounded-full border-2 border-white object-cover" />
          ) : (
            <span className="absolute bottom-2 left-2 grid h-10 w-10 place-items-center rounded-full bg-black/70 text-[8px] font-black uppercase leading-tight text-white ring-2 ring-white/80">
              {"t" in b ? b.t : shop.name.slice(0, 1)}
            </span>
          );
        })()}
      </div>
      <p className="mt-2 truncate text-[15px] font-extrabold text-[#171717]">{shop.name}</p>
      <p className="mt-0.5 flex items-center gap-2 text-[11px] text-[#777]">
        <span className="inline-flex items-center gap-0.5 font-semibold text-[#171717]">
          <IconStar className="h-3.5 w-3.5 text-[#FF6A00]" /> {shop.rating.toFixed(1)} ({shop.reviews}+)
        </span>
        <span className="inline-flex items-center gap-1">
          <IconClock className="h-3 w-3" /> {shop.eta}
        </span>
      </p>
      <p className="mt-0.5 inline-flex items-center gap-1 text-[11px] text-[#888]">
        <IconPin className="h-3 w-3" /> {zoneLabel(shop.zone)}
      </p>
    </button>
  );
}

export function Landing() {
  const { setQuery, category, setCategory, setModal, zone, setZone, openShop } = useStore();
  const [q, setQ] = useState("");
  const featured = SHOPS.filter((s) => s.featured).slice(0, 10);
  const popular = useMemo(() => SHOPS.filter((s) => s.zone === "gate1" || s.zone === "gate2").slice(0, 6), []);

  return (
    <div className="bg-[#f6f6f6] pb-28">
      <section id="home" className="relative bg-black pt-[72px]">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <img src={IMG.heroBurger} alt="" className="h-full w-full object-cover object-[70%_center]" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/20" />
        </div>
        <div className="relative mx-auto grid max-w-[1280px] items-center gap-8 px-4 pb-16 pt-12 md:px-6 lg:grid-cols-[1.1fr_.9fr] lg:pb-20">
          <div>
            <h1 className="max-w-xl text-[42px] font-black leading-[1.05] text-white md:text-[58px]">
              Good food.
              <br />
              Good mood.
              <br />
              We <span className="text-[#FF6A00] underline decoration-[#FF6A00] decoration-4 underline-offset-4">deliver.</span>
            </h1>
            <p className="mt-4 max-w-md text-[15px] text-white/65">
              From Gate 1 to Gate 2 and beyond.
              <br />
              We deliver food, drinks, groceries and more.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setQuery(q);
                document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="mt-7 flex max-w-[540px] items-center rounded-full bg-white p-1.5"
            >
              <div className="flex min-w-0 flex-1 items-center gap-2 px-4 text-[#999]">
                <IconPin className="h-4 w-4 text-[#FF6A00]" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What would you like delivered?" className="h-11 w-full bg-transparent text-sm font-medium text-black outline-none" />
              </div>
              <button className="flex h-11 items-center gap-1 rounded-full bg-[#FF6A00] px-5 text-sm font-bold text-white">
                Order Now <IconArrow className="h-4 w-4" />
              </button>
            </form>
            <div className="mt-6 flex flex-wrap gap-6 text-[13px] font-semibold text-white">
              <span className="inline-flex items-center gap-2">
                <IconTruck className="h-5 w-5 text-[#FF6A00]" /> Delivery from R35
              </span>
              <span className="inline-flex items-center gap-2">
                <IconClock className="h-5 w-5 text-[#FF6A00]" /> 30–45 min delivery time
              </span>
            </div>
          </div>
          <div className="hidden justify-self-end lg:block">
            <div className="w-[280px] rounded-[24px] bg-[#141414] p-5 text-white shadow-2xl ring-1 ring-white/10">
              <p className="inline-flex items-center gap-1 text-[12px] text-white/60">
                <IconPin className="h-3.5 w-3.5 text-[#FF6A00]" /> Ordering From
              </p>
              <select value={zone} onChange={(e) => setZone(e.target.value as typeof zone)} className="mt-2 w-full rounded-xl bg-white/8 px-3 py-2 text-sm font-bold">
                {ZONES.map((z) => (
                  <option key={z.id} value={z.id} className="text-black">
                    {z.label}
                  </option>
                ))}
              </select>
              <img src={IMG.rider} alt="" className="mx-auto mt-4 h-16 w-16 rounded-full object-cover" />
              <p className="mt-3 text-center text-[13px] text-white/55">Welcome to</p>
              <p className="text-center text-[22px] font-black">
                Turf<span className="text-[#FF6A00]">Buddy</span>
              </p>
              <p className="mt-1 text-center text-[12px] text-white/45">Good food, good mood.</p>
              <button onClick={() => document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" })} className="mt-4 h-11 w-full rounded-full bg-[#FF6A00] text-sm font-bold">
                Let’s Order
              </button>
            </div>
          </div>
        </div>

        </section>

        <div id="categories" className="relative z-20 mx-auto -mt-8 max-w-[1280px] px-4 md:-mt-12 md:px-6">
          <div className="rounded-[28px] bg-white px-4 py-5 shadow-[0_16px_50px_rgba(0,0,0,0.12)] md:px-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[20px] font-extrabold text-[#171717]">Explore Categories</h2>
              <button
                onClick={() => {
                  setCategory("all");
                  document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="text-[13px] font-bold text-[#FF6A00]"
              >
                View all →
              </button>
            </div>
            <div className="hide-scroll flex items-start justify-start gap-3 overflow-x-auto pb-1 lg:justify-between lg:overflow-visible">
              {CATEGORIES.map((c) => {
                const on = category === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => {
                      setCategory(on ? "all" : c.id);
                      document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="flex w-[78px] shrink-0 flex-col items-center gap-1.5 press lg:w-auto lg:min-w-0 lg:flex-1"
                  >
                    <span className={`grid h-[64px] w-[64px] overflow-hidden rounded-2xl bg-[#f3f3f3] lg:h-[72px] lg:w-[72px] ${on ? "ring-2 ring-[#FF6A00] ring-offset-2" : ""}`}>
                      <img src={c.image} alt="" className="h-full w-full object-cover" />
                    </span>
                    <span className={`w-full truncate text-center text-[11px] font-bold leading-none ${on ? "text-[#FF6A00]" : "text-[#333]"}`}>
                      {c.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <section className="mx-auto max-w-[1280px] px-4 pt-8 md:px-6 md:pt-10">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[22px] font-extrabold text-[#171717]">Featured Restaurants</h2>
            <a href="#restaurants" className="text-[13px] font-bold text-[#FF6A00]">
              View all →
            </a>
          </div>
          <div className="overflow-hidden">
            <div className="marquee gap-4 pb-2">
              {[...featured, ...featured].map((s, i) => (
                <FeatCard key={`${s.id}-${i}`} shop={s} />
              ))}
            </div>
          </div>
        </section>

      <section className="mx-auto mt-10 max-w-[1280px] px-4 md:px-6">
        <div className="flex flex-wrap items-center gap-6 rounded-[28px] bg-[#111] p-6 text-white md:p-8">
          <div className="min-w-[200px] flex-1">
            <p className="text-[11px] font-black uppercase tracking-widest text-[#FF6A00]">New · TurfBuddy Loyalty Rewards</p>
            <p className="mt-2 text-lg font-extrabold">Order more. Earn points. Get rewards.</p>
            <button onClick={() => setModal("auth")} className="mt-4 h-10 rounded-full bg-[#FF6A00] px-5 text-sm font-bold">
              Learn More
            </button>
          </div>
          <div className="grid flex-1 grid-cols-3 gap-3 text-center text-[12px]">
            <div className="rounded-2xl bg-white/6 p-3">
              <p className="font-extrabold">Earn Points</p>
              <p className="mt-1 text-white/50">On every order</p>
            </div>
            <div className="rounded-2xl bg-white/6 p-3">
              <p className="font-extrabold">Exclusive Deals</p>
              <p className="mt-1 text-white/50">For members</p>
            </div>
            <div className="rounded-2xl bg-white/6 p-3">
              <p className="font-extrabold">Birthday Treats</p>
              <p className="mt-1 text-white/50">Special surprises</p>
            </div>
          </div>
        </div>
      </section>

      <section id="deals" className="mx-auto mt-8 grid max-w-[1280px] gap-4 px-4 md:grid-cols-3 md:px-6">
        <div className="rounded-3xl bg-white p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-extrabold text-[#171717]">Popular Near You</h3>
            <a href="#restaurants" className="text-[12px] font-bold text-[#FF6A00]">
              View all
            </a>
          </div>
          <div className="overflow-hidden">
            <div className="marquee marquee-fast gap-3">
              {[...popular, ...popular].map((s, i) => (
                <button key={`${s.id}-pop-${i}`} onClick={() => openShop(s)} className="w-[120px] shrink-0 text-left">
                  <img src={s.image} alt="" className="h-20 w-full rounded-xl object-cover" />
                  <p className="mt-1 truncate text-[12px] font-bold text-[#171717]">{s.name}</p>
                  <p className="text-[10px] text-[#888]">
                    {s.rating} · {zoneLabel(s.zone)}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-3xl bg-[#FF6A00] p-6 text-white">
          <img src={IMG.rider} alt="" className="absolute right-0 bottom-0 h-full w-1/2 object-cover opacity-80" />
          <div className="relative">
            <p className="text-3xl font-black leading-none">FREE DELIVERY</p>
            <p className="mt-2 text-sm font-semibold">On orders over R150</p>
            <p className="mt-6 inline-block rounded-full bg-white px-4 py-2 text-[12px] font-black text-[#FF6A00]">USE CODE TURFBUDDY</p>
          </div>
        </div>
        <div className="rounded-3xl bg-white p-4">
          <h3 className="font-extrabold text-[#171717]">Today’s Deals</h3>
          <div className="mt-3 space-y-3">
            <Deal name="Munch Burger Combo" from={110} now={89} off="20% OFF" onClick={() => { const s = SHOPS.find((x) => x.id === "the-munch"); if (s) openShop(s); }} />
            <Deal name="2 Large Pizzas" from={260} now={199} off="23% OFF" onClick={() => { const s = SHOPS.find((x) => x.id === "drr-pizza"); if (s) openShop(s); }} />
          </div>
        </div>
      </section>

      <section id="restaurants" className="mx-auto mt-10 max-w-[1280px] px-4 pb-8 md:px-6">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="text-[22px] font-extrabold text-[#171717]">All places</h2>
            <p className="mt-1 text-[12px] text-[#888]">Swipe left or right to change category · tap a shop for the menu</p>
          </div>
          <p className="text-[13px] font-bold text-[#FF6A00]">{ZONES.find((z) => z.id === zone)?.label}</p>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {ZONES.map((z) => (
            <button key={z.id} onClick={() => setZone(z.id)} className={`rounded-full px-3 py-1.5 text-[12px] font-bold ${zone === z.id ? "bg-[#FF6A00] text-white" : "bg-white text-[#444]"}`}>
              {z.label}
            </button>
          ))}
        </div>
        <SwipeDeck />
      </section>
    </div>
  );
}

function SwipeDeck() {
  const { zone, setZone, category, setCategory, openShop } = useStore();
  const start = useRef({ x: 0, y: 0 });
  const [slide, setSlide] = useState(0);
  const list = SHOPS.filter((s) => (category !== "all" ? s.category === category : s.zone === zone));
  const idx = ZONES.findIndex((z) => z.id === zone);

  const go = (dir: number) => {
    const next = idx + dir;
    if (next < 0 || next >= ZONES.length) return;
    setSlide(dir);
    window.setTimeout(() => {
      setCategory("all");
      setZone(ZONES[next].id);
      setSlide(0);
    }, 160);
  };

  const down = (e: PE<HTMLDivElement>) => {
    start.current = { x: e.clientX, y: e.clientY };
  };
  const up = (e: PE<HTMLDivElement>) => {
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;
    if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
    go(dx < 0 ? 1 : -1);
  };

  return (
    <div className="relative mt-5 touch-pan-y select-none" onPointerDown={down} onPointerUp={up}>
      <div
        className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5"
        style={{
          transform: slide ? `translate3d(${slide * -28}px,0,0)` : "none",
          opacity: slide ? 0.55 : 1,
          transition: "transform .16s ease, opacity .16s ease",
        }}
      >
        {list.map((s) => (
          <button
            key={s.id}
            onClick={() => openShop(s)}
            className="overflow-hidden rounded-2xl bg-white text-left shadow-sm"
          >
            <img src={s.image} alt="" className="h-28 w-full object-cover" />
            <div className="p-2.5">
              <p className="truncate text-[13px] font-extrabold text-[#171717]">{s.name}</p>
              <p className="text-[11px] text-[#888]">
                ★ {s.rating} · tap for menu
              </p>
            </div>
          </button>
        ))}
      </div>
      {!list.length && <p className="py-10 text-center text-sm text-[#999]">No shops in this category.</p>}
      <div className="mt-4 flex items-center justify-between">
        <button onClick={() => go(-1)} disabled={idx <= 0} className="rounded-full bg-white px-3 py-1.5 text-[12px] font-bold text-[#444] disabled:opacity-30">
          ← {idx > 0 ? ZONES[idx - 1].label : "Start"}
        </button>
        <div className="flex gap-1.5">
          {ZONES.map((z) => (
            <span key={z.id} className={`h-1.5 rounded-full ${z.id === zone ? "w-5 bg-[#FF6A00]" : "w-1.5 bg-[#ddd]"}`} />
          ))}
        </div>
        <button onClick={() => go(1)} disabled={idx >= ZONES.length - 1} className="rounded-full bg-white px-3 py-1.5 text-[12px] font-bold text-[#444] disabled:opacity-30">
          {idx < ZONES.length - 1 ? ZONES[idx + 1].label : "End"} →
        </button>
      </div>
    </div>
  );
}

function Deal({ name, from, now, off, onClick }: { name: string; from: number; now: number; off: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center justify-between gap-3 text-left">
      <div>
        <p className="text-[13px] font-bold text-[#171717]">{name}</p>
        <p className="text-[12px] text-[#888]">
          <span className="font-extrabold text-[#FF6A00]">R{now}</span> <s>R{from}</s> <span className="text-[#1F8A4C]">{off}</span>
        </p>
      </div>
      <span className="grid h-8 w-8 place-items-center rounded-full bg-[#FF6A00] text-lg font-bold text-white">+</span>
    </button>
  );
}

export function CartBar() {
  const { count, subtotal, setModal } = useStore();
  if (!count) return null;
  return (
    <div className="fixed bottom-[58px] left-1/2 z-40 w-[min(96vw,720px)] -translate-x-1/2 md:bottom-6">
      <div className="flex items-center justify-between rounded-full bg-[#141414] px-4 py-2.5 text-white shadow-2xl">
        <button onClick={() => setModal("cart")} className="flex items-center gap-2 text-left">
          <span className="relative grid h-10 w-10 place-items-center rounded-full bg-white/10">
            <IconCart />
            <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#FF6A00] text-[10px] font-bold">{count}</span>
          </span>
          <span>
            <span className="block text-[12px] text-white/60">{count} items</span>
            <span className="text-[13px] font-bold text-[#FF6A00]">View Cart</span>
          </span>
        </button>
        <span className="text-right">
          <span className="block text-[11px] text-white/50">Subtotal</span>
          <span className="text-[18px] font-black">R{subtotal}</span>
        </span>
        <button onClick={() => setModal("checkout")} className="h-11 rounded-full bg-[#FF6A00] px-5 text-sm font-bold">
          Checkout →
        </button>
      </div>
    </div>
  );
}

export function DarkDock() {
  const { setModal } = useStore();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/8 bg-[#111] px-2 pb-[max(8px,env(safe-area-inset-bottom))] pt-2 text-white md:hidden">
      <div className="mx-auto grid max-w-md grid-cols-4">
        <a href="#home" className="flex flex-col items-center gap-0.5 text-[10px] font-bold text-[#FF6A00]">
          <IconHome className="h-5 w-5" /> Home
        </a>
        <button onClick={() => setModal("search")} className="flex flex-col items-center gap-0.5 text-[10px] font-bold text-white/40">
          <IconSearch className="h-5 w-5" /> Search
        </button>
        <button onClick={() => setModal("cart")} className="flex flex-col items-center gap-0.5 text-[10px] font-bold text-white/40">
          <IconCart className="h-5 w-5" /> Orders
        </button>
        <button onClick={() => setModal("auth")} className="flex flex-col items-center gap-0.5 text-[10px] font-bold text-white/40">
          <IconUser className="h-5 w-5" /> Profile
        </button>
      </div>
    </nav>
  );
}
