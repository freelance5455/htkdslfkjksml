import { useState } from "react";
import { MAPS, MISSION, WAVES, mapById, type ControlSettings, type HuntRecord, type Loadout, type MapId } from "@/data";
import {
  ArrowRight,
  AwardIcon,
  BookIcon,
  CheckIcon,
  CloseIcon,
  CompassIcon,
  CrosshairIcon,
  DownloadIcon,
  LeafIcon,
  Logo,
  MenuIcon,
  MutedIcon,
  PlayIcon,
  RifleIcon,
  SmartphoneIcon,
  SoundIcon,
  SunIcon,
  WindIcon,
} from "@/components/Icons";

export type LandingPanel = "guide" | "records" | "loadout" | "howto" | "controls" | "android";

interface Props {
  loadout: Loadout;
  records: HuntRecord[];
  muted: boolean;
  controls: ControlSettings;
  installed: boolean;
  canInstall: boolean;
  onToggleMute: () => void;
  onStart: () => void;
  onOpen: (panel: LandingPanel) => void;
  onSelectMap: (id: MapId) => void;
}

const NAV = [
  { label: "The hunt", panel: null },
  { label: "Field guide", panel: "guide" as LandingPanel },
  { label: "Record book", panel: "records" as LandingPanel },
  { label: "Armoury", panel: "loadout" as LandingPanel },
  { label: "Controls", panel: "controls" as LandingPanel },
];

export default function Landing({ loadout, records, muted, controls, installed, canInstall, onToggleMute, onStart, onOpen, onSelectMap }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const best = records.reduce((max, record) => Math.max(max, record.score), 0);
  const ground = mapById(controls.map);

  const open = (panel: LandingPanel) => {
    setMenuOpen(false);
    onOpen(panel);
  };

  return (
    <div className="relative z-10 h-full overflow-y-auto overflow-x-hidden no-scrollbar">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-bark-950 via-bark-950/72 to-bark-950/5" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-bark-950 via-transparent to-bark-950/45" />
      <div className="pointer-events-none absolute inset-0 grain" />

      <div className="relative z-10 flex min-h-full flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-sand-100/10 px-4 pb-4 pt-[max(1rem,env(safe-area-inset-top))] md:px-9 md:pb-5">
          <button onClick={onStart} className="text-left" aria-label="Ridgeline Hunting Club — begin">
            <Logo />
          </button>

          <nav className="hidden items-center gap-5 lg:flex xl:gap-7" aria-label="Primary">
            {NAV.map((item, index) => (
              <button
                key={item.label}
                onClick={() => (item.panel ? open(item.panel) : onStart())}
                className={`group relative font-condensed text-[0.78rem] font-medium uppercase tracking-[0.22em] transition-colors ${
                  index === 0 ? "text-sand-100" : "text-sand-300/75 hover:text-sand-100"
                }`}
              >
                {item.label}
                <span
                  className={`absolute -bottom-2.5 left-1/2 h-px -translate-x-1/2 bg-brass-300 transition-all duration-300 ${
                    index === 0 ? "w-full" : "w-0 group-hover:w-full"
                  }`}
                />
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2 md:gap-2.5">
            <button
              onClick={() => open("android")}
              className={`hidden h-10 items-center gap-2 rounded-sm border px-3 backdrop-blur-md transition md:flex ${
                installed
                  ? "border-brass-300/40 bg-brass-300/10 text-brass-300"
                  : "border-sand-100/16 bg-bark-950/35 text-sand-200 hover:border-brass-300/50 hover:text-brass-300"
              }`}
            >
              {installed ? <CheckIcon size={15} /> : <SmartphoneIcon size={15} />}
              <span className="font-condensed text-[0.62rem] uppercase tracking-[0.14em]">{installed ? "Installed" : "Get app"}</span>
              {!installed && canInstall && <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />}
            </button>
            <div className="hidden items-center gap-2.5 rounded-sm border border-sand-100/14 bg-bark-950/35 px-3.5 py-2 backdrop-blur-md xl:flex">
              <SunIcon size={14} className="text-brass-300" />
              <span className="num text-sm text-sand-100">{ground.temperature}</span>
              <span className="h-3 w-px bg-sand-100/20" />
              <span className="eyebrow text-[0.58rem] text-sand-300/80">{ground.conditions}</span>
            </div>
            <button
              onClick={onToggleMute}
              aria-label={muted ? "Enable sound" : "Mute sound"}
              className="flex h-10 w-10 items-center justify-center rounded-sm border border-sand-100/16 bg-bark-950/35 text-sand-200 backdrop-blur-md transition hover:border-brass-300/50 hover:text-brass-300"
            >
              {muted ? <MutedIcon size={17} /> : <SoundIcon size={17} />}
            </button>
            <button
              onClick={() => setMenuOpen((value) => !value)}
              aria-label="Open menu"
              aria-expanded={menuOpen}
              className="flex h-10 w-10 items-center justify-center rounded-sm border border-sand-100/16 bg-bark-950/35 text-sand-200 backdrop-blur-md transition hover:border-brass-300/50 hover:text-brass-300 lg:hidden"
            >
              {menuOpen ? <CloseIcon size={18} /> : <MenuIcon size={18} />}
            </button>
          </div>
        </header>

        {menuOpen && (
          <div className="absolute right-5 top-[76px] z-30 w-[240px] animate-rise rounded-sm glass p-2 lg:hidden">
            {NAV.map((item) => (
              <button
                key={item.label}
                onClick={() => (item.panel ? open(item.panel) : onStart())}
                className="flex w-full items-center justify-between rounded-sm px-3.5 py-3 text-left font-condensed text-sm uppercase tracking-[0.18em] text-sand-200 transition hover:bg-sand-100/8 hover:text-white"
              >
                {item.label}
                <ArrowRight size={14} className="text-brass-300/70" />
              </button>
            ))}
            <button
              onClick={() => open("android")}
              className="flex w-full items-center justify-between rounded-sm border border-brass-300/25 bg-brass-300/8 px-3.5 py-3 text-left font-condensed text-sm uppercase tracking-[0.18em] text-brass-200 transition hover:bg-brass-300/15"
            >
              {installed ? "App installed" : "Install Android app"}
              <SmartphoneIcon size={15} />
            </button>
            <div className="mt-1 border-t border-sand-100/10 px-3.5 pb-2 pt-3">
              <p className="eyebrow text-[0.55rem] text-sand-400">Personal best</p>
              <p className="num mt-1 text-2xl text-brass-300">{best > 0 ? best.toLocaleString() : "— — —"}</p>
            </div>
          </div>
        )}

        <main className="grid flex-1 items-center gap-8 px-5 py-9 md:px-9 md:py-10 xl:grid-cols-[1.22fr_0.78fr] xl:py-6">
          <section className="max-w-[690px]">
            <div className="animate-enter flex items-center gap-3">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brass-300 opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-brass-300" />
              </span>
              <span className="eyebrow text-brass-300">Season 04 · Dawn patrol</span>
              <span className="hidden h-px w-12 bg-brass-300/40 sm:block" />
              <span className="eyebrow hidden text-sand-400 sm:block">Northern Range</span>
            </div>

            <h1 className="animate-enter delay-1 mt-5 font-serif text-[clamp(3.5rem,8.4vw,7rem)] leading-[0.86] tracking-[-0.028em] text-sand-100 drop-shadow-[0_4px_28px_rgba(0,0,0,0.35)]">
              Earn the
              <br />
              <span className="relative inline-block italic text-brass-300">
                quiet.
                <svg className="absolute -bottom-2 left-0 w-full text-brass-400/45" viewBox="0 0 200 12" fill="none" aria-hidden>
                  <path d="M2 9c38-6 96-9 196-4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                </svg>
              </span>
            </h1>

            <p className="animate-enter delay-2 mt-7 max-w-[500px] text-pretty text-[0.98rem] leading-[1.75] text-sand-200/85">
              A first-person expedition into four wild ranges. Track six species through five driven waves, choose your
              hunting ground from Option A, and hunt with unlimited ammunition in the magazine.
            </p>

            <div className="animate-enter delay-3 mt-8 flex flex-wrap items-center gap-3">
              <button onClick={onStart} className="btn-primary h-[52px] rounded-sm px-7 text-sm">
                <PlayIcon size={14} />
                Begin the hunt
              </button>
              <button onClick={() => open("controls")} className="btn-ghost h-[52px] rounded-sm px-5 text-sm">
                <CrosshairIcon size={14} className="text-brass-300" />
                Android · Option {controls.layout}
              </button>
              <button onClick={() => open("howto")} className="btn-ghost h-[52px] rounded-sm px-5 text-sm">
                How to play
              </button>
            </div>
            <p className="animate-enter delay-3 mt-3 flex items-center gap-2 text-[0.62rem] text-sand-400">
              <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />
              Option A thumbstick · 4 maps · ∞ ammo on by default · five driven waves
            </p>

            <button
              onClick={() => open("android")}
              className="animate-enter delay-4 mt-6 flex w-full max-w-[520px] items-center justify-between gap-3 rounded-sm border border-brass-300/25 bg-gradient-to-r from-brass-300/10 via-bark-900/60 to-bark-950/40 px-3 py-2 text-left backdrop-blur-sm transition hover:border-brass-300/50 hover:from-brass-300/16"
            >
              <span className="flex items-center gap-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded-sm border border-brass-300/35 bg-brass-300/10 text-brass-300">
                  <SmartphoneIcon size={14} />
                </span>
                <span>
                  <span className="block font-condensed text-[0.68rem] uppercase tracking-[0.12em] text-sand-100">
                    {installed ? "Ridgeline is on this device" : "Get the Android app"}
                  </span>
                  <span className="mt-0.5 block text-[0.58rem] text-sand-400">
                    {installed ? "Offline-ready · launch from your home screen" : "Install in one tap, or build the APK from the included native project"}
                  </span>
                </span>
              </span>
              <span className="flex shrink-0 items-center gap-1 rounded-[2px] border border-brass-300/30 px-1.5 py-1 font-condensed text-[0.5rem] uppercase tracking-[0.12em] text-brass-300">
                {installed ? <CheckIcon size={10} /> : <DownloadIcon size={10} />} {installed ? "Ready" : "Install"}
              </span>
            </button>

            <div className="animate-enter delay-4 mt-4 max-w-[520px]">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-[0.5rem] text-brass-300">The five drives</span>
                <span className="eyebrow text-[0.46rem] text-sand-400">Quota per wave</span>
              </div>
              <div className="mt-2 grid grid-cols-5 gap-1">
                {WAVES.map((wave) => (
                  <div key={wave.id} className="group relative rounded-sm border border-sand-100/12 bg-bark-950/35 px-1.5 py-2 backdrop-blur-sm transition hover:border-brass-300/40 hover:bg-brass-300/6">
                    <p className="num text-[0.56rem] text-brass-300">{String(WAVES.indexOf(wave) + 1).padStart(2, "0")}</p>
                    <p className="mt-1 truncate font-condensed text-[0.55rem] uppercase tracking-[0.06em] text-sand-200">{wave.name}</p>
                    <p className="num mt-1 text-[0.56rem] text-sand-400">{wave.quota} game · {wave.duration}s</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="animate-enter delay-4 mt-6 flex max-w-[480px] items-stretch gap-5 border-t border-sand-100/12 pt-5 sm:gap-8">
              {[
                { value: "18,240", label: "Acres to roam" },
                { value: "06", label: "Species to track" },
                { value: String(WAVES.length).padStart(2, "0"), label: "Driven waves" },
                { value: String(MAPS.length).padStart(2, "0"), label: "Hunting grounds" },
              ].map((stat, index) => (
                <div key={stat.label} className={index > 0 ? "border-l border-sand-100/12 pl-5 sm:pl-8" : ""}>
                  <p className="num text-[1.45rem] leading-none text-sand-100">{stat.value}</p>
                  <p className="eyebrow mt-2 text-[0.55rem] text-sand-400">{stat.label}</p>
                </div>
              ))}
            </div>
          </section>

          <aside className="hidden flex-col items-end justify-between gap-10 pb-3 xl:flex">
            <div className="flex items-center gap-3 self-end text-right">
              <div className="text-right">
                <p className="eyebrow text-[0.55rem] text-sand-400">Hunting ground</p>
                <p className="num mt-1 text-sm tracking-[0.14em] text-sand-200">{ground.name} · {MAPS.length} ranges</p>
              </div>
              <span className="flex h-9 w-9 items-center justify-center rounded-full border border-brass-300/30 text-brass-300">
                <CompassIcon size={16} />
              </span>
            </div>

            <div className="w-[272px] animate-enter-slow delay-3 glass corner-frame rounded-sm p-5">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-[0.55rem] text-sand-300/80">Live conditions</span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />
                  <span className="eyebrow text-[0.5rem] text-brass-300">Live</span>
                </span>
              </div>
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <p className="num text-5xl leading-none text-sand-100">{ground.temperature.replace("°C", "°")}</p>
                  <p className="eyebrow mt-2 text-[0.55rem] text-sand-400">{ground.conditions}</p>
                </div>
                <div className="relative flex h-[72px] w-[72px] items-center justify-center rounded-full border border-sand-100/16">
                  <span className="absolute inset-[9px] rounded-full border border-dashed border-sand-100/12" />
                  <WindIcon size={21} className="text-brass-300" />
                  <span className="absolute -top-1 left-1/2 -translate-x-1/2 font-condensed text-[0.5rem] tracking-widest text-sand-400">N</span>
                </div>
              </div>
              <div className="mt-4 h-px bg-sand-100/12" />
              <div className="mt-4 grid grid-cols-3 gap-2">
                {[
                  ["Wind", ground.wind],
                  ["Ground", ground.name.split(" ")[0]],
                  ["Map", `${MAPS.indexOf(ground) + 1} / ${MAPS.length}`],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="eyebrow text-[0.48rem] text-sand-400">{label}</p>
                    <p className="num mt-1 text-[0.78rem] text-sand-200">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="self-end text-right">
              <p className="eyebrow text-[0.52rem] text-sand-400">{ground.region} · Study no. 04</p>
              <p className="mt-1 font-serif text-xl italic text-sand-200/90">{ground.name} at first light</p>
            </div>
          </aside>
        </main>

        <footer className="relative z-20 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] md:px-9">
          <div className="grid gap-3 lg:grid-cols-[1.35fr_1fr]">
            <div className="glass corner-frame animate-enter delay-3 rounded-sm p-4 md:p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="eyebrow text-[0.55rem] text-brass-300">Assignment 04</p>
                  <h2 className="mt-1.5 font-serif text-[1.65rem] leading-none text-sand-100">{MISSION.name}</h2>
                  <p className="eyebrow mt-2 text-[0.52rem] text-sand-400">Northern Range · Unit 12 · 5 drives · 05:00 window</p>
                </div>
                <button
                  onClick={() => open("howto")}
                  className="hidden shrink-0 border border-brass-300/30 px-2.5 py-1 font-condensed text-[0.6rem] uppercase tracking-[0.18em] text-brass-300 transition hover:bg-brass-300/10 sm:block"
                >
                  Briefing
                </button>
              </div>
              <div className="mt-3.5 grid gap-x-5 gap-y-2 border-t border-sand-100/10 pt-3.5 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                {MISSION.objectives.map((objective, index) => (
                  <div key={objective.id} className="flex items-center gap-2.5">
                    <span className="num flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-brass-300/35 text-[0.6rem] text-brass-300">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="text-[0.76rem] leading-tight text-sand-200/85">{objective.label}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass animate-enter delay-4 rounded-sm p-4 md:p-5">
              <div className="flex items-center justify-between">
                <p className="eyebrow text-[0.55rem] text-brass-300">In the field</p>
                <span className="eyebrow text-[0.5rem] text-sand-400">Equipped</span>
              </div>
              <div className="mt-3 flex items-center gap-3.5">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm border border-brass-300/25 bg-brass-300/5 text-brass-300">
                  <RifleIcon size={27} />
                </span>
                <div className="min-w-0">
                  <p className="font-serif text-[1.25rem] leading-tight text-sand-100">
                    {loadout.name} <span className="text-brass-300">{loadout.calibre.split(" ")[0]}</span>
                  </p>
                  <p className="eyebrow mt-1 text-[0.5rem] text-sand-400">
                    {loadout.magazine}-round mag · {loadout.range} effective
                  </p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-sand-100/10 pt-3">
                {[
                  ["Stability", `${loadout.stability} / 5`],
                  ["Weight", loadout.weight],
                  ["Optic", `${loadout.zoomFov < 17 ? "6" : loadout.zoomFov < 22 ? "4" : "2"}×`],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="eyebrow text-[0.46rem] text-sand-400">{label}</p>
                    <p className="num mt-1 text-[0.78rem] text-sand-200">{value}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 border-t border-sand-100/10 pt-2.5">
                <div className="flex items-center justify-between">
                  <span className="eyebrow text-[0.45rem] text-sand-400">Hunting ground · extra maps</span>
                  {controls.infiniteAmmo && <span className="flex items-center gap-1 text-brass-300"><RifleIcon size={11} /><span className="eyebrow text-[0.44rem]">∞ ammo</span></span>}
                </div>
                <div className="mt-1.5 grid grid-cols-4 gap-1">
                  {MAPS.map((map) => (
                    <button
                      key={map.id}
                      onClick={() => onSelectMap(map.id)}
                      aria-pressed={controls.map === map.id}
                      title={`${map.name} · ${map.conditions}`}
                      className={`group relative overflow-hidden rounded-[2px] border text-left transition ${
                        controls.map === map.id ? "border-brass-300/70" : "border-sand-100/12 hover:border-sand-100/30"
                      }`}
                    >
                      <span className="block h-5 w-full" style={{ background: `linear-gradient(110deg, ${map.swatch[0]}, ${map.swatch[1]} 60%, ${map.swatch[2]})` }} />
                      <span className={`block truncate px-1 py-0.5 font-condensed text-[0.44rem] uppercase tracking-[0.04em] ${controls.map === map.id ? "bg-brass-300/12 text-brass-200" : "text-sand-400"}`}>
                        {map.name.split(" ")[0]}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-2.5 flex items-center justify-between">
                <button
                  onClick={() => open("loadout")}
                  className="group flex items-center gap-1.5 font-condensed text-[0.64rem] uppercase tracking-[0.16em] text-brass-300 transition hover:text-brass-200"
                >
                  Change rifle
                  <ArrowRight size={12} className="transition-transform group-hover:translate-x-0.5" />
                </button>
                <button
                  onClick={() => open("controls")}
                  className="flex items-center gap-1.5 rounded-sm border border-brass-300/25 bg-brass-300/6 px-2 py-1 font-condensed text-[0.54rem] uppercase tracking-[0.12em] text-brass-300 transition hover:bg-brass-300/12"
                >
                  <CrosshairIcon size={10} /> Option {controls.layout} · Maps
                </button>
              </div>
            </div>

            <div className="relative hidden overflow-hidden rounded-sm border border-sand-100/12 bg-gradient-to-br from-bark-800/80 to-bark-950/85 p-4 md:p-5 lg:block">
              <LeafIcon size={18} className="text-brass-300/80" />
              <p className="mt-3 font-serif text-[1.18rem] italic leading-snug text-sand-200">
                “Take the shot you can explain to the mountain.”
              </p>
              <p className="eyebrow mt-2.5 text-[0.48rem] text-sand-400">Trail journal · p. 14</p>
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => open("guide")}
                  className="flex h-8 flex-1 items-center justify-center gap-1.5 border border-sand-100/16 text-[0.58rem] font-condensed uppercase tracking-[0.14em] text-sand-200 transition hover:bg-sand-100/8 hover:text-white"
                >
                  <BookIcon size={12} /> Field guide
                </button>
                <button
                  onClick={() => open("records")}
                  className="flex h-8 flex-1 items-center justify-center gap-1.5 border border-sand-100/16 text-[0.58rem] font-condensed uppercase tracking-[0.14em] text-sand-200 transition hover:bg-sand-100/8 hover:text-white"
                >
                  <AwardIcon size={12} /> Records
                </button>
                <button
                  onClick={() => open("controls")}
                  className="flex h-8 flex-1 items-center justify-center gap-1.5 border border-sand-100/16 text-[0.58rem] font-condensed uppercase tracking-[0.14em] text-sand-200 transition hover:bg-sand-100/8 hover:text-white"
                >
                  <CrosshairIcon size={12} /> Option {controls.layout}
                </button>
              </div>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-[0.55rem] font-condensed uppercase tracking-[0.18em] text-sand-400/70">
              <span className="h-1 w-1 animate-pulse-soft rounded-full bg-brass-300" />
              Live wilderness · Real-time 3D · Option A controls · ∞ ammo available
            </div>
            <p className="hidden text-[0.55rem] font-condensed uppercase tracking-[0.18em] text-sand-400/60 sm:block">
              Ridgeline Hunting Club © 2026 · Leave it better
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
