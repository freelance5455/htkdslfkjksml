import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Eraser,
  FilePlus2,
  FileText,
  FileUp,
  Highlighter,
  ImagePlus,
  Layers,
  Maximize2,
  Minimize2,
  MousePointerClick,
  MoveHorizontal,
  Pencil,
  PenTool,
  Plus,
  Redo2,
  RotateCw,
  Square,
  TextSelect,
  Trash2,
  Type,
  Undo2,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  CustomFont,
  ExtractedTextBlock,
  OverlayElement,
  PdfDocumentTab,
  PdfPageModel,
  TextOverlayElement,
  ToolMode,
  UILanguage,
} from '../types/pdf';
import { detectTextScript, isRtlText, resolveCssFontFamily } from '../utils/fonts';
import { UI_COPY } from '../utils/i18n';
import {
  resolveTextRenderPlans,
  samplePixelColorFromImage,
} from '../utils/pdfEngine';

interface PdfWorkspaceProps {
  lang: UILanguage;
  documents: PdfDocumentTab[];
  activeDocId: string | null;
  pages: PdfPageModel[];
  activePageId: string;
  scrollRequest: { pageId: string; nonce: number } | null;
  overlays: OverlayElement[];
  selectedOverlayId: string | null;
  toolMode: ToolMode;
  zoom: number;
  customFonts: CustomFont[];
  canUndo: boolean;
  canRedo: boolean;
  isLoading: boolean;
  isPickingBgColor: boolean;
  isFullscreen: boolean;
  onSelectDocument: (docId: string) => void;
  onCloseDocument: (docId: string) => void;
  onSelectPage: (pageId: string) => void;
  onOpenPagesDrawer: () => void;
  onAddBlankPage: (afterPageId?: string) => void;
  onDeletePage: (pageId: string) => void;
  onPrevPage: () => void;
  onNextPage: () => void;
  onRotateActivePage: () => void;
  onToggleFullscreen: () => void;
  onSetToolMode: (mode: ToolMode) => void;
  onSetZoom: (zoom: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  onSelectOverlay: (id: string | null) => void;
  onActivateExtractedBlock: (block: ExtractedTextBlock) => void;
  onActivateMultiBlocks: (
    pageId: string,
    blocks: ExtractedTextBlock[],
    overlappingOverlays: TextOverlayElement[]
  ) => string | null;
  onAbsorbBelowBlock: (overlayId: string, belowBlock: ExtractedTextBlock) => void;
  onCreateTextAt: (pageId: string, xPt: number, yPt: number) => void;
  onCreateDrawOverlay: (
    pageId: string,
    kind: 'patch' | 'shape' | 'highlight',
    xPt: number,
    yPt: number,
    widthPt: number,
    heightPt: number
  ) => void;
  onCreatePenStroke: (pageId: string, points: Array<{ x: number; y: number }>) => void;
  onUpdateOverlay: (id: string, updater: (prev: OverlayElement) => OverlayElement) => void;
  onFinishInlineEdit: (id: string) => void;
  onPickBgColorValue: (hex: string) => void;
  onOpenSignature: () => void;
  onUploadImage: (file: File) => void;
  onDropPdfFiles: (files: File[]) => void;
}

export const PdfWorkspace: React.FC<PdfWorkspaceProps> = ({
  lang,
  documents,
  activeDocId,
  pages,
  activePageId,
  scrollRequest,
  overlays,
  selectedOverlayId,
  toolMode,
  zoom,
  customFonts,
  canUndo,
  canRedo,
  isLoading,
  isPickingBgColor,
  isFullscreen,
  onSelectDocument,
  onCloseDocument,
  onSelectPage,
  onOpenPagesDrawer,
  onAddBlankPage,
  onDeletePage,
  onPrevPage,
  onNextPage,
  onRotateActivePage,
  onToggleFullscreen,
  onSetToolMode,
  onSetZoom,
  onUndo,
  onRedo,
  onSelectOverlay,
  onActivateExtractedBlock,
  onActivateMultiBlocks,
  onAbsorbBelowBlock,
  onCreateTextAt,
  onCreateDrawOverlay,
  onCreatePenStroke,
  onUpdateOverlay,
  onFinishInlineEdit,
  onPickBgColorValue,
  onOpenSignature,
  onUploadImage,
  onDropPdfFiles,
}) => {
  const t = UI_COPY[lang];
  const viewportScrollRef = useRef<HTMLDivElement>(null);
  const pagesStageRef = useRef<HTMLDivElement>(null);
  const zoomLabelRef = useRef<HTMLSpanElement>(null);
  const inlineTextareaRef = useRef<HTMLTextAreaElement | null>(null);
  const pendingCaretRef = useRef<{ id: string; start: number; end: number } | null>(null);
  const pendingScrollAnchorRef = useRef<{
    pinchOriginX: number;
    pinchOriginY: number;
    finalRatio: number;
    relX: number;
    relY: number;
  } | null>(null);
  const pageWrapperRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const pageSheetRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const imgInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const addTabPdfInputRef = useRef<HTMLInputElement>(null);
  const autoFittedDocsRef = useRef<Set<string>>(new Set());
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;

  const [inlineEditingId, setInlineEditingId] = useState<string | null>(null);
  const [selectedExtractedId, setSelectedExtractedId] = useState<string | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  const [drawBox, setDrawBox] = useState<{
    pageId: string;
    startX: number;
    startY: number;
    curX: number;
    curY: number;
    isMarqueeSelect?: boolean;
  } | null>(null);

  const [penPoints, setPenPoints] = useState<{
    pageId: string;
    points: Array<{ x: number; y: number }>;
  } | null>(null);

  const dragStateRef = useRef<{
    id: string;
    mode: 'move' | 'resize-se' | 'resize-e';
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
    origW: number;
    origH: number;
  } | null>(null);

  const activeInlineOverlay = inlineEditingId
    ? overlays.find(
        (o): o is TextOverlayElement => o.id === inlineEditingId && o.kind === 'text'
      ) || null
    : null;

  // MS Word-style caret restoration & automatic below-block reflow when wrapped text reaches lower blocks
  useLayoutEffect(() => {
    const el = inlineTextareaRef.current;
    const ov = activeInlineOverlay;
    if (!el || !ov) return;

    if (pendingCaretRef.current && pendingCaretRef.current.id === ov.id) {
      const { start, end } = pendingCaretRef.current;
      pendingCaretRef.current = null;
      el.focus();
      try {
        el.setSelectionRange(start, end);
      } catch {
        // ignore if out of range
      }
    }

    const pageObj = pages.find((p) => p.id === ov.pageId);
    if (!pageObj || pageObj.rotation !== 0) return;

    const pageOverlays = overlays.filter((o) => o.pageId === pageObj.id);
    const coveredBlockIds = new Set<string>();
    for (const po of pageOverlays) {
      if (po.kind === 'text') {
        if (po.sourceBlockId) coveredBlockIds.add(po.sourceBlockId);
        for (const mid of po.mergedBlockIds || []) coveredBlockIds.add(mid);
      }
    }

    const measuredHeightPt = el.getBoundingClientRect().height / Math.max(0.25, zoom);
    const maxWrapPt = ov.maxPageWidth
      ? Math.min(ov.maxPageWidth, Math.max(60, pageObj.widthPt - ov.x - 16))
      : Math.max(60, pageObj.widthPt - ov.x - 16);
    const bottomPt = ov.y + measuredHeightPt;
    const myRightPt = ov.x + maxWrapPt;

    const candidateBelow = pageObj.extractedBlocks
      .filter((blk) => {
        if (coveredBlockIds.has(blk.id)) return false;
        if (blk.y <= ov.y + 4) return false;
        if (bottomPt + 2 < blk.y) return false;
        const blkRight = blk.x + blk.width;
        const overlapX = Math.max(0, Math.min(myRightPt, blkRight) - Math.max(ov.x, blk.x));
        const minW = Math.min(maxWrapPt, blk.width);
        return minW > 0 && overlapX >= minW * 0.25;
      })
      .sort((a, b) => a.y - b.y)[0];

    if (candidateBelow) {
      pendingCaretRef.current = {
        id: ov.id,
        start: el.selectionStart ?? ov.text.length,
        end: el.selectionEnd ?? ov.text.length,
      };
      onAbsorbBelowBlock(ov.id, candidateBelow);
    }
  }, [activeInlineOverlay, activeInlineOverlay?.text, overlays, pages, zoom, onAbsorbBelowBlock]);

  const activePageIndex = Math.max(
    0,
    pages.findIndex((p) => p.id === activePageId)
  );
  const activePage = pages[activePageIndex] || pages[0] || null;
  const pageCount = pages.length;

  const computeFitZoom = useCallback(() => {
    const refPage = activePage || pages[0];
    if (!refPage || !viewportScrollRef.current) return;
    const availW = viewportScrollRef.current.clientWidth - 28;
    const pageW =
      refPage.rotation === 90 || refPage.rotation === 270
        ? refPage.heightPt
        : refPage.widthPt;
    if (availW > 120 && pageW > 0) {
      const fitted = Math.max(0.35, Math.min(1.8, Number((availW / pageW).toFixed(2))));
      onSetZoom(fitted);
    }
  }, [activePage, pages, onSetZoom]);

  // Auto-fit once per newly opened document
  useEffect(() => {
    if (!activeDocId || pages.length === 0) return;
    if (!autoFittedDocsRef.current.has(activeDocId)) {
      autoFittedDocsRef.current.add(activeDocId);
      computeFitZoom();
    }
  }, [activeDocId, pages.length, computeFitZoom]);

  // Smoothly scroll to a specific page when requested via Prev/Next/Sidebar/NewPage
  useEffect(() => {
    if (!scrollRequest) return;
    const target = pageWrapperRefs.current[scrollRequest.pageId];
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [scrollRequest]);

  // Sync activePageId automatically as user scrolls through continuous multi-page view
  useEffect(() => {
    const container = viewportScrollRef.current;
    if (!container || pages.length <= 1) return;

    const ratios = new Map<string, number>();
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const pid = (entry.target as HTMLElement).dataset.pageId;
          if (pid) {
            ratios.set(pid, entry.intersectionRatio);
          }
        }
        let bestId = '';
        let bestRatio = 0;
        for (const [pid, ratio] of ratios.entries()) {
          if (ratio > bestRatio) {
            bestRatio = ratio;
            bestId = pid;
          }
        }
        if (bestId && bestRatio > 0.15) {
          onSelectPage(bestId);
        }
      },
      {
        root: container,
        threshold: [0.15, 0.35, 0.6, 0.85],
      }
    );

    for (const page of pages) {
      const el = pageWrapperRefs.current[page.id];
      if (el) observer.observe(el);
    }

    return () => observer.disconnect();
  }, [pages, onSelectPage]);

  // Restore exact focal scroll offset right after a pinch-zoom commit
  useEffect(() => {
    const anchor = pendingScrollAnchorRef.current;
    const container = viewportScrollRef.current;
    const stage = pagesStageRef.current;
    if (!anchor || !container || !stage) return;
    pendingScrollAnchorRef.current = null;
    requestAnimationFrame(() => {
      container.scrollLeft = Math.max(
        0,
        stage.offsetLeft + anchor.pinchOriginX * anchor.finalRatio - anchor.relX
      );
      container.scrollTop = Math.max(
        0,
        stage.offsetTop + anchor.pinchOriginY * anchor.finalRatio - anchor.relY
      );
    });
  }, [zoom]);

  // Smooth 60fps GPU-transformed two-finger pinch-to-zoom + multiplicative trackpad zoom
  useEffect(() => {
    const container = viewportScrollRef.current;
    if (!container) return;

    let pinchStartDist = 0;
    let pinchStartZoom = 1;
    let pinchOriginX = 0;
    let pinchOriginY = 0;
    let startStageLeft = 0;
    let startStageTop = 0;
    let lastRelX = 0;
    let lastRelY = 0;
    let latestTargetZoom = 1;
    let isPinching = false;
    let rafId: number | null = null;

    const getTouchDistance = (t0: Touch, t1: Touch) =>
      Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);

    const applyLivePinchTransform = (
      ratio: number,
      curMidX: number,
      curMidY: number
    ) => {
      const stage = pagesStageRef.current;
      if (!stage) return;
      const dx = curMidX - startStageLeft - pinchOriginX * ratio;
      const dy = curMidY - startStageTop - pinchOriginY * ratio;
      stage.style.transformOrigin = '0 0';
      stage.style.willChange = 'transform';
      stage.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${ratio})`;
      if (zoomLabelRef.current) {
        zoomLabelRef.current.textContent = `${Math.round(latestTargetZoom * 100)}%`;
      }
    };

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const stage = pagesStageRef.current;
        if (!stage) return;

        isPinching = true;
        dragStateRef.current = null;
        setPenPoints(null);
        setDrawBox(null);

        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const midX = (t0.clientX + t1.clientX) / 2;
        const midY = (t0.clientY + t1.clientY) / 2;
        const containerRect = container.getBoundingClientRect();
        const stageRect = stage.getBoundingClientRect();

        pinchStartDist = Math.max(12, getTouchDistance(t0, t1));
        pinchStartZoom = zoomRef.current;
        latestTargetZoom = pinchStartZoom;

        startStageLeft = stageRect.left;
        startStageTop = stageRect.top;
        pinchOriginX = midX - stageRect.left;
        pinchOriginY = midY - stageRect.top;
        lastRelX = midX - containerRect.left;
        lastRelY = midY - containerRect.top;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && isPinching) {
        e.preventDefault();
        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const curDist = getTouchDistance(t0, t1);
        const curMidX = (t0.clientX + t1.clientX) / 2;
        const curMidY = (t0.clientY + t1.clientY) / 2;
        const containerRect = container.getBoundingClientRect();
        lastRelX = curMidX - containerRect.left;
        lastRelY = curMidY - containerRect.top;

        const scaleRatio = curDist / pinchStartDist;
        latestTargetZoom = Math.max(
          0.25,
          Math.min(4.0, Number((pinchStartZoom * scaleRatio).toFixed(3)))
        );
        const visualRatio = latestTargetZoom / pinchStartZoom;

        if (rafId !== null) cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(() => {
          applyLivePinchTransform(visualRatio, curMidX, curMidY);
          rafId = null;
        });
      }
    };

    const finishPinch = () => {
      if (!isPinching) return;
      isPinching = false;
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
      const stage = pagesStageRef.current;
      if (stage) {
        stage.style.transform = '';
        stage.style.transformOrigin = '';
        stage.style.willChange = '';
      }
      const finalZoom = Math.max(0.25, Math.min(4.0, Number(latestTargetZoom.toFixed(2))));
      if (Math.abs(finalZoom - zoomRef.current) >= 0.01) {
        pendingScrollAnchorRef.current = {
          pinchOriginX,
          pinchOriginY,
          finalRatio: finalZoom / pinchStartZoom,
          relX: lastRelX,
          relY: lastRelY,
        };
        onSetZoom(finalZoom);
      } else if (zoomLabelRef.current) {
        zoomLabelRef.current.textContent = `${Math.round(zoomRef.current * 100)}%`;
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (e.touches.length < 2) {
        finishPinch();
      }
    };

    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const factor = Math.exp(-e.deltaY * 0.003);
        const nextZoom = Math.max(
          0.25,
          Math.min(4.0, Number((zoomRef.current * factor).toFixed(2)))
        );
        onSetZoom(nextZoom);
      }
    };

    container.addEventListener('touchstart', onTouchStart, { passive: false });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    container.addEventListener('touchcancel', onTouchEnd, { passive: true });
    container.addEventListener('wheel', onWheel, { passive: false });

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
      container.removeEventListener('wheel', onWheel);
    };
  }, [onSetZoom, pages.length]);

  const clientToPdfPt = (pageId: string, clientX: number, clientY: number) => {
    const sheet = pageSheetRefs.current[pageId];
    if (!sheet) return { x: 0, y: 0 };
    const rect = sheet.getBoundingClientRect();
    return {
      x: Math.max(0, (clientX - rect.left) / zoom),
      y: Math.max(0, (clientY - rect.top) / zoom),
    };
  };

  const handleSheetPointerDown = async (
    page: PdfPageModel,
    e: React.PointerEvent<HTMLDivElement>
  ) => {
    onSelectPage(page.id);

    if (isPickingBgColor && page.previewDataUrl) {
      e.stopPropagation();
      const sheet = pageSheetRefs.current[page.id];
      if (!sheet) return;
      const rect = sheet.getBoundingClientRect();
      const normX = (e.clientX - rect.left) / rect.width;
      const normY = (e.clientY - rect.top) / rect.height;
      const hex = await samplePixelColorFromImage(page.previewDataUrl, normX, normY);
      onPickBgColorValue(hex);
      return;
    }

    if (toolMode === 'pen') {
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      const pt = clientToPdfPt(page.id, e.clientX, e.clientY);
      setPenPoints({ pageId: page.id, points: [pt] });
      return;
    }

    const isMarqueeTrigger =
      toolMode === 'select-region' || (toolMode === 'edit-text' && e.shiftKey);

    if (
      !isMarqueeTrigger &&
      e.target !== pageSheetRefs.current[page.id] &&
      !(e.target as HTMLElement).dataset.pageCanvas
    ) {
      return;
    }

    setInlineEditingId(null);
    setSelectedExtractedId(null);

    if (toolMode === 'add-text') {
      const pt = clientToPdfPt(page.id, e.clientX, e.clientY);
      onCreateTextAt(page.id, pt.x, pt.y);
      return;
    }

    if (
      isMarqueeTrigger ||
      toolMode === 'patch' ||
      toolMode === 'shape' ||
      toolMode === 'highlight'
    ) {
      e.currentTarget.setPointerCapture(e.pointerId);
      const pt = clientToPdfPt(page.id, e.clientX, e.clientY);
      setDrawBox({
        pageId: page.id,
        startX: pt.x,
        startY: pt.y,
        curX: pt.x,
        curY: pt.y,
        isMarqueeSelect: isMarqueeTrigger,
      });
      return;
    }

    onSelectOverlay(null);
  };

  const handleSheetPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStateRef.current) {
      const ds = dragStateRef.current;
      const dx = (e.clientX - ds.startClientX) / zoom;
      const dy = (e.clientY - ds.startClientY) / zoom;

      onUpdateOverlay(ds.id, (prev) => {
        if (ds.mode === 'move') {
          return {
            ...prev,
            x: Math.max(0, ds.origX + dx),
            y: Math.max(0, ds.origY + dy),
          };
        }
        if (ds.mode === 'resize-e') {
          return {
            ...prev,
            width: Math.max(24, ds.origW + dx),
            ...(prev.kind === 'text' ? { hasCustomWidth: true } : {}),
          };
        }
        return {
          ...prev,
          width: Math.max(24, ds.origW + dx),
          height: Math.max(16, ds.origH + dy),
        };
      });
      return;
    }

    if (penPoints) {
      const pt = clientToPdfPt(penPoints.pageId, e.clientX, e.clientY);
      setPenPoints((prev) =>
        prev ? { ...prev, points: [...prev.points, pt] } : null
      );
      return;
    }

    if (drawBox) {
      const pt = clientToPdfPt(drawBox.pageId, e.clientX, e.clientY);
      setDrawBox({ ...drawBox, curX: pt.x, curY: pt.y });
    }
  };

  const handleSheetPointerUp = () => {
    dragStateRef.current = null;

    if (penPoints) {
      if (penPoints.points.length > 1) {
        onCreatePenStroke(penPoints.pageId, penPoints.points);
      }
      setPenPoints(null);
      return;
    }

    if (drawBox) {
      const x = Math.min(drawBox.startX, drawBox.curX);
      const y = Math.min(drawBox.startY, drawBox.curY);
      const w = Math.abs(drawBox.curX - drawBox.startX);
      const h = Math.abs(drawBox.curY - drawBox.startY);
      const targetPageId = drawBox.pageId;
      const wasMarquee = Boolean(drawBox.isMarqueeSelect);
      setDrawBox(null);

      if (wasMarquee && w > 6 && h > 6) {
        const targetPage = pages.find((p) => p.id === targetPageId);
        if (targetPage) {
          const pageOvs = overlays.filter((o) => o.pageId === targetPageId);
          const alreadyEditedIds = new Set<string>();
          for (const po of pageOvs) {
            if (po.kind === 'text') {
              if (po.sourceBlockId) alreadyEditedIds.add(po.sourceBlockId);
              for (const mid of po.mergedBlockIds || []) alreadyEditedIds.add(mid);
            }
          }

          const intersects = (bx: number, by: number, bw: number, bh: number) =>
            bx < x + w && bx + bw > x && by < y + h && by + bh > y;

          const matchedBlocks = targetPage.extractedBlocks.filter(
            (blk) =>
              !alreadyEditedIds.has(blk.id) &&
              intersects(blk.x, blk.y, blk.width, blk.height)
          );
          const matchedOverlays = pageOvs.filter(
            (ov): ov is TextOverlayElement =>
              ov.kind === 'text' && intersects(ov.x, ov.y, ov.width, ov.height)
          );

          if (matchedBlocks.length > 0 || matchedOverlays.length > 0) {
            const newId = onActivateMultiBlocks(
              targetPageId,
              matchedBlocks,
              matchedOverlays
            );
            if (newId) {
              setInlineEditingId(newId);
            }
          }
        }
        return;
      }

      if (
        w > 8 &&
        h > 6 &&
        (toolMode === 'patch' || toolMode === 'shape' || toolMode === 'highlight')
      ) {
        onCreateDrawOverlay(targetPageId, toolMode, x, y, w, h);
      }
    }
  };

  const toolHint =
    toolMode === 'select-region'
      ? t.dragToSelectRegion
      : toolMode === 'add-text'
      ? t.clickToPlaceText
      : toolMode === 'highlight'
      ? t.dragToDrawHighlight
      : toolMode === 'pen'
      ? t.dragToDrawPen
      : toolMode === 'patch'
      ? t.dragToDrawPatch
      : toolMode === 'shape'
      ? t.dragToDrawShape
      : t.clickTextToEdit;

  return (
    <main
      className="flex-1 flex flex-col min-w-0 h-full bg-[#F4F5F7] relative overflow-hidden"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDraggingFile(true);
      }}
      onDragLeave={() => setIsDraggingFile(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDraggingFile(false);
        const dropped = Array.from(e.dataTransfer.files || []).filter(
          (f) => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf')
        );
        if (dropped.length > 0) {
          onDropPdfFiles(dropped);
        }
      }}
    >
      {/* Multi-PDF Open Documents Tab Strip */}
      {documents.length > 0 && (
        <div className="bg-[#EEF0F4] border-b border-slate-200 px-2.5 py-1 flex items-center gap-1.5 overflow-x-auto shrink-0">
          {documents.map((doc) => {
            const isTabActive = doc.id === activeDocId;
            return (
              <div
                key={doc.id}
                onClick={() => onSelectDocument(doc.id)}
                className={`group flex items-center gap-1.5 pl-2.5 pr-1.5 py-1 rounded-md border text-xs transition-colors cursor-pointer shrink-0 ${
                  isTabActive
                    ? 'bg-white border-slate-300 text-slate-900 font-semibold shadow-2xs'
                    : 'bg-transparent border-transparent text-slate-600 hover:bg-white/70 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                <span className="truncate max-w-[140px]">{doc.docName}</span>
                <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                  {doc.pages.length}
                </span>
                <button
                  type="button"
                  data-tooltip={t.closeDocument}
                  aria-label={t.closeDocument}
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseDocument(doc.id);
                  }}
                  className="p-0.5 rounded text-slate-400 hover:text-slate-800 hover:bg-slate-200/70 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}

          <button
            type="button"
            onClick={() => addTabPdfInputRef.current?.click()}
            data-tooltip={t.openAnotherPdf}
            aria-label={t.openAnotherPdf}
            className="inline-flex items-center justify-center p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-md transition-colors shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          <input
            ref={addTabPdfInputRef}
            type="file"
            accept="application/pdf,.pdf"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = e.target.files ? Array.from(e.target.files) : [];
              if (files.length > 0) onDropPdfFiles(files);
              e.target.value = '';
            }}
          />
        </div>
      )}

      {/* Full-Featured PDF Editor Toolbar (only visible when a PDF is open) */}
      {activePage && (
        <>
          <div className="bg-white border-b border-slate-200 px-2 py-1 flex flex-nowrap items-center gap-1.5 overflow-x-auto shrink-0">
            {/* Single-Line Icon-Only Editing Tools */}
            <div className="flex items-center gap-0.5 p-0.5 bg-slate-100 rounded-lg shrink-0">
              <button
                type="button"
                onClick={() => onSetToolMode('edit-text')}
                data-tooltip={t.toolEditText}
                aria-label={t.toolEditText}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'edit-text'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <MousePointerClick className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('select-region')}
                data-tooltip={t.toolSelectRegion}
                aria-label={t.toolSelectRegion}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'select-region'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <TextSelect className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('add-text')}
                data-tooltip={t.toolAddText}
                aria-label={t.toolAddText}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'add-text'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Type className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('highlight')}
                data-tooltip={t.toolHighlight}
                aria-label={t.toolHighlight}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'highlight'
                    ? 'bg-white text-amber-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Highlighter className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('pen')}
                data-tooltip={t.toolPen}
                aria-label={t.toolPen}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'pen'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('patch')}
                data-tooltip={t.toolPatch}
                aria-label={t.toolPatch}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'patch'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Eraser className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onOpenSignature}
                data-tooltip={t.toolSignature}
                aria-label={t.toolSignature}
                className="p-1.5 rounded-md text-slate-600 hover:text-slate-900 hover:bg-white/60 transition-colors shrink-0 cursor-pointer"
              >
                <PenTool className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => imgInputRef.current?.click()}
                data-tooltip={t.toolImage}
                aria-label={t.toolImage}
                className="p-1.5 rounded-md text-slate-600 hover:text-slate-900 hover:bg-white/60 transition-colors shrink-0 cursor-pointer"
              >
                <ImagePlus className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onSetToolMode('shape')}
                data-tooltip={t.toolShape}
                aria-label={t.toolShape}
                className={`p-1.5 rounded-md transition-colors shrink-0 cursor-pointer ${
                  toolMode === 'shape'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Square className="w-4 h-4" />
              </button>
            </div>

            <input
              ref={imgInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onUploadImage(f);
                e.target.value = '';
              }}
            />

            {/* Single-Line Page Nav + Rotate + Add/Delete + History + Zoom + Fullscreen */}
            <div className="flex items-center gap-1 flex-nowrap shrink-0 ml-auto">
              <div className="flex items-center gap-0.5 border border-slate-200 rounded-md bg-white px-0.5 py-0.5 shrink-0">
                <button
                  type="button"
                  onClick={onOpenPagesDrawer}
                  data-tooltip={t.togglePagesPanel}
                  aria-label={t.togglePagesPanel}
                  className="inline-flex items-center gap-1 px-1.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded cursor-pointer whitespace-nowrap"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span className="font-mono tabular-nums text-[11px]">
                    {activePageIndex + 1}/{pageCount}
                  </span>
                </button>
                <button
                  type="button"
                  disabled={activePageIndex <= 0}
                  onClick={onPrevPage}
                  data-tooltip={t.prevPage}
                  aria-label={t.prevPage}
                  className="p-1 text-slate-600 hover:text-slate-900 disabled:opacity-30 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={activePageIndex >= pageCount - 1}
                  onClick={onNextPage}
                  data-tooltip={t.nextPage}
                  aria-label={t.nextPage}
                  className="p-1 text-slate-600 hover:text-slate-900 disabled:opacity-30 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={onRotateActivePage}
                  data-tooltip={t.rotatePage}
                  aria-label={t.rotatePage}
                  className="p-1 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onAddBlankPage(activePage.id)}
                  data-tooltip={t.addBlankPage}
                  aria-label={t.addBlankPage}
                  className="p-1 text-blue-700 hover:bg-blue-50 rounded cursor-pointer"
                >
                  <FilePlus2 className="w-3.5 h-3.5" />
                </button>
                {pageCount > 1 && (
                  <button
                    type="button"
                    onClick={() => onDeletePage(activePage.id)}
                    data-tooltip={t.deletePage}
                    aria-label={t.deletePage}
                    className="p-1 text-slate-500 hover:text-red-600 rounded hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-0.5 border-r border-slate-200 pr-1 shrink-0">
                <button
                  type="button"
                  disabled={!canUndo}
                  onClick={onUndo}
                  data-tooltip={t.undo}
                  aria-label={t.undo}
                  className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-35 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <Undo2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={!canRedo}
                  onClick={onRedo}
                  data-tooltip={t.redo}
                  aria-label={t.redo}
                  className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-35 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <Redo2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-0.5 shrink-0">
                <button
                  type="button"
                  onClick={() => onSetZoom(Math.max(0.25, Number((zoom - 0.15).toFixed(2))))}
                  data-tooltip={t.zoomOut}
                  aria-label={t.zoomOut}
                  className="p-1.5 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span
                  ref={zoomLabelRef}
                  className="text-[11px] font-mono tabular-nums text-slate-700 w-9 text-center shrink-0"
                >
                  {Math.round(zoom * 100)}%
                </span>
                <button
                  type="button"
                  onClick={() => onSetZoom(Math.min(4.0, Number((zoom + 0.15).toFixed(2))))}
                  data-tooltip={t.zoomIn}
                  aria-label={t.zoomIn}
                  className="p-1.5 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={computeFitZoom}
                  data-tooltip={t.fitWidth}
                  aria-label={t.fitWidth}
                  className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                >
                  <MoveHorizontal className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                type="button"
                onClick={onToggleFullscreen}
                data-tooltip={isFullscreen ? t.exitFullscreen : t.fullscreen}
                aria-label={isFullscreen ? t.exitFullscreen : t.fullscreen}
                className="p-1.5 text-slate-600 hover:text-slate-900 rounded-md border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer shrink-0"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-3.5 h-3.5" />
                ) : (
                  <Maximize2 className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>

          {/* Subtle instructional strip */}
          <div className="px-4 py-1 bg-[#F8F9FB] border-b border-slate-200/80 text-[11px] text-slate-500 flex items-center justify-between gap-4 shrink-0">
            <span className="truncate">{toolHint}</span>
            {isPickingBgColor && (
              <span className="font-semibold text-blue-700 shrink-0">
                {t.pickFromPage}
              </span>
            )}
          </div>
        </>
      )}

      {/* Continuous Multi-Page Scrollable Canvas Area (supports two-finger pinch zoom) */}
      <div
        ref={viewportScrollRef}
        className={`flex-1 overflow-auto p-3 sm:p-5 flex ${
          pages.length > 0 ? 'flex-col items-center justify-start gap-6' : 'items-center justify-center'
        }`}
        style={{ touchAction: 'pan-x pan-y' }}
        onPointerMove={handleSheetPointerMove}
        onPointerUp={handleSheetPointerUp}
      >
        {isLoading ? (
          <div className="my-20 flex flex-col items-center gap-3 text-slate-500">
            <div className="w-7 h-7 border-2 border-blue-700 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs font-medium">{t.loadingPdf}</span>
          </div>
        ) : pages.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center p-6">
            <button
              type="button"
              onClick={() => pdfInputRef.current?.click()}
              className="group flex flex-col items-center gap-3 px-10 py-8 bg-white border border-dashed border-slate-300 hover:border-blue-600 rounded-2xl transition-colors cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center group-hover:bg-blue-700 group-hover:text-white transition-colors">
                <FileUp className="w-5 h-5" />
              </div>
              <span className="text-sm font-semibold text-slate-900">
                {t.emptyOpenBtn}
              </span>
              <span className="text-xs text-slate-500 max-w-xs">
                {t.emptyOpenSub}
              </span>
            </button>
            <input
              ref={pdfInputRef}
              type="file"
              accept="application/pdf,.pdf"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = e.target.files ? Array.from(e.target.files) : [];
                if (files.length > 0) onDropPdfFiles(files);
                e.target.value = '';
              }}
            />
          </div>
        ) : (
          <div
            ref={pagesStageRef}
            className="flex flex-col items-center gap-6 shrink-0"
          >
            {pages.map((page, pageIdx) => {
              const pageDisplayW =
                (page.rotation === 90 || page.rotation === 270
                  ? page.heightPt
                  : page.widthPt) * zoom;
              const pageDisplayH =
                (page.rotation === 90 || page.rotation === 270
                  ? page.widthPt
                  : page.heightPt) * zoom;

              const pageOverlays = overlays.filter((o) => o.pageId === page.id);
              const editedBlockIds = new Set<string>();
              for (const po of pageOverlays) {
                if (po.kind === 'text') {
                  if (po.sourceBlockId) editedBlockIds.add(po.sourceBlockId);
                  for (const mid of po.mergedBlockIds || []) {
                    editedBlockIds.add(mid);
                  }
                }
              }
              const isDrawingHere =
                toolMode === 'select-region' ||
                toolMode === 'pen' ||
                toolMode === 'patch' ||
                toolMode === 'shape' ||
                toolMode === 'highlight';

              return (
                <div
                  key={page.id}
                  data-page-id={page.id}
                  ref={(el) => {
                    pageWrapperRefs.current[page.id] = el;
                  }}
                  className="flex flex-col items-center shrink-0"
                >
                  <div
                    onClick={() => onSelectPage(page.id)}
                    className="w-full flex items-center justify-between gap-2 text-[11px] text-slate-500 mb-1.5 px-0.5 select-none min-h-[24px] cursor-pointer"
                  >
                    <span className="font-mono tabular-nums">
                      {String(pageIdx + 1).padStart(2, '0')} / {pages.length}
                    </span>
                    {page.id === activePageId && pages.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeletePage(page.id);
                        }}
                        data-tooltip={t.deletePage}
                        aria-label={t.deletePage}
                        className="p-1 bg-white hover:bg-red-50 text-red-600 border border-slate-200 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                <div
                  ref={(el) => {
                    pageSheetRefs.current[page.id] = el;
                  }}
                  onPointerDown={(e) => handleSheetPointerDown(page, e)}
                  style={{
                    width: `${pageDisplayW}px`,
                    height: `${pageDisplayH}px`,
                    cursor: isPickingBgColor
                      ? 'crosshair'
                      : toolMode === 'add-text'
                      ? 'text'
                      : isDrawingHere
                      ? 'crosshair'
                      : 'default',
                    touchAction: isDrawingHere ? 'none' : 'pan-x pan-y',
                  }}
                  className={`relative bg-white shadow-md border select-none shrink-0 overflow-hidden ${
                    page.id === activePageId ? 'border-blue-400' : 'border-slate-200'
                  }`}
                >
                  {/* Original PDF Page Design Layer */}
                  {page.previewDataUrl && (
                    <img
                      src={page.previewDataUrl}
                      alt={`PDF Page ${pageIdx + 1}`}
                      data-page-canvas="true"
                      referrerPolicy="no-referrer"
                      draggable={false}
                      style={{
                        width: `${page.widthPt * zoom}px`,
                        height: `${page.heightPt * zoom}px`,
                        transform:
                          page.rotation === 0
                            ? 'none'
                            : page.rotation === 90
                            ? `translate(${pageDisplayW}px, 0) rotate(90deg)`
                            : page.rotation === 180
                            ? `translate(${pageDisplayW}px, ${pageDisplayH}px) rotate(180deg)`
                            : `translate(0, ${pageDisplayH}px) rotate(270deg)`,
                        transformOrigin: 'top left',
                      }}
                      className="block max-w-none pointer-events-auto"
                    />
                  )}

                  {/* Interactive Extracted Paragraph / Text Blocks — Tap + Edit, Double-click, or Marquee Highlight */}
                  {page.rotation === 0 &&
                    (toolMode === 'edit-text' || toolMode === 'select-region') &&
                    page.extractedBlocks.map((block) => {
                      if (editedBlockIds.has(block.id)) return null;
                      const isPreSelected = selectedExtractedId === block.id;
                      const isMarqueeHover =
                        drawBox &&
                        drawBox.pageId === page.id &&
                        drawBox.isMarqueeSelect &&
                        (() => {
                          const mx = Math.min(drawBox.startX, drawBox.curX);
                          const my = Math.min(drawBox.startY, drawBox.curY);
                          const mw = Math.abs(drawBox.curX - drawBox.startX);
                          const mh = Math.abs(drawBox.curY - drawBox.startY);
                          return (
                            block.x < mx + mw &&
                            block.x + block.width > mx &&
                            block.y < my + mh &&
                            block.y + block.height > my
                          );
                        })();

                      return (
                        <div
                          key={block.id}
                          onClick={(e) => {
                            if (toolMode === 'select-region') return;
                            e.stopPropagation();
                            onSelectPage(page.id);
                            setSelectedExtractedId(block.id);
                          }}
                          onDoubleClick={(e) => {
                            if (toolMode === 'select-region') return;
                            e.stopPropagation();
                            onSelectPage(page.id);
                            const createdId = block.id;
                            setSelectedExtractedId(null);
                            onActivateExtractedBlock(block);
                            setInlineEditingId(`ov-${createdId}`);
                          }}
                          title={block.originalText}
                          style={{
                            left: `${block.x * zoom - 2}px`,
                            top: `${block.y * zoom - 1}px`,
                            width: `${block.width * zoom + 4}px`,
                            height: `${block.height * zoom + 2}px`,
                          }}
                          className={`absolute border rounded-[2px] transition-colors ${
                            toolMode === 'select-region'
                              ? isMarqueeHover
                                ? 'border-blue-600 bg-blue-500/20 pointer-events-none z-10'
                                : 'border-transparent pointer-events-none'
                              : isMarqueeHover
                              ? 'border-blue-600 bg-blue-500/20 z-10 cursor-crosshair'
                              : isPreSelected
                              ? 'border-blue-600/90 bg-blue-500/8 z-10 cursor-text'
                              : 'border-transparent hover:border-blue-500/70 hover:bg-blue-500/5 cursor-text'
                          }`}
                        >
                          {isPreSelected && toolMode === 'edit-text' && (
                            <button
                              type="button"
                              data-tooltip={t.editParagraphBtn}
                              aria-label={t.editParagraphBtn}
                              onPointerDown={(e) => e.stopPropagation()}
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectPage(page.id);
                                const createdId = block.id;
                                setSelectedExtractedId(null);
                                onActivateExtractedBlock(block);
                                setInlineEditingId(`ov-${createdId}`);
                              }}
                              className="absolute -top-6 left-0 px-2 py-0.5 text-[11px] font-semibold bg-blue-700 hover:bg-blue-800 text-white rounded shadow-sm flex items-center gap-1 whitespace-nowrap cursor-pointer"
                            >
                              <Pencil className="w-2.5 h-2.5" />
                              <span>{t.editParagraphBtn}</span>
                            </button>
                          )}
                        </div>
                      );
                    })}

                  {/* Active Overlays on This Page */}
                  {pageOverlays.map((ov) => {
                    const isSelected = ov.id === selectedOverlayId;
                    const isInlineEditing = inlineEditingId === ov.id;

                    if (ov.kind === 'text') {
                      const plan = isInlineEditing
                        ? {
                            shouldRender: true,
                            items: [
                              {
                                maskRect: ov.maskRect?.enabled ? ov.maskRect : null,
                                drawX: ov.x,
                                drawY: ov.y,
                                drawText: ov.text,
                                drawWidth: ov.width,
                                drawHeight: ov.height,
                                textAlign: ov.textAlign,
                              },
                            ],
                          }
                        : resolveTextRenderPlans(ov, customFonts);

                      if (!plan.shouldRender && !isInlineEditing) {
                        return null;
                      }

                      const pageAvailMaxPt = Math.max(60, page.widthPt - ov.x - 16);
                      const maxWrapWidthPt = ov.maxPageWidth
                        ? Math.min(ov.maxPageWidth, pageAvailMaxPt)
                        : pageAvailMaxPt;
                      const rtlMode = isRtlText(ov.text);

                      return (
                        <React.Fragment key={ov.id}>
                          {/* Render masks ONLY for lines/spans that actually changed */}
                          {plan.items.map(
                            (item, itemIdx) =>
                              item.maskRect && (
                                <div
                                  key={`${ov.id}-m-${itemIdx}`}
                                  style={{
                                    left: `${(item.maskRect.x - item.maskRect.padding) * zoom}px`,
                                    top: `${(item.maskRect.y - item.maskRect.padding) * zoom}px`,
                                    width: `${(item.maskRect.width + item.maskRect.padding * 2) * zoom}px`,
                                    height: `${(item.maskRect.height + item.maskRect.padding * 2) * zoom}px`,
                                    backgroundColor: item.maskRect.color,
                                  }}
                                  className="absolute pointer-events-none"
                                />
                              )
                          )}

                          {/* When not inline editing, render modified text wrapped automatically within page margins */}
                          {!isInlineEditing &&
                            plan.items.map((item, itemIdx) => {
                              const itemMaxWrapPt = Math.max(
                                40,
                                page.widthPt - item.drawX - 16
                              );
                              const useFixedWidth = Boolean(ov.hasCustomWidth);
                              return (
                                <div
                                  key={`${ov.id}-t-${itemIdx}`}
                                  dir={isRtlText(item.drawText) ? 'rtl' : 'ltr'}
                                  style={{
                                    left: `${item.drawX * zoom}px`,
                                    top: `${item.drawY * zoom}px`,
                                    width: useFixedWidth
                                      ? `${Math.min(item.drawWidth, itemMaxWrapPt) * zoom}px`
                                      : 'max-content',
                                    minWidth: `${Math.min(item.drawWidth, itemMaxWrapPt) * zoom}px`,
                                    maxWidth: `${itemMaxWrapPt * zoom}px`,
                                    fontFamily: resolveCssFontFamily(ov.fontId, customFonts),
                                    fontSize: `${ov.fontSize * zoom}px`,
                                    fontWeight: ov.fontWeight,
                                    fontStyle: ov.fontStyle,
                                    textAlign: item.textAlign,
                                    lineHeight: ov.lineHeight,
                                    letterSpacing: `${ov.letterSpacing * zoom}px`,
                                    color: ov.color,
                                    opacity: ov.opacity,
                                    whiteSpace: 'pre-wrap',
                                    wordBreak: 'break-word',
                                  }}
                                  className="absolute pointer-events-none"
                                >
                                  {item.drawText || ' '}
                                </div>
                              );
                            })}

                          {/* Interactive Selection / Drag / MS Word Auto-Wrapping Inline Editor Container */}
                          <div
                            onPointerDown={(e) => {
                              if (isPickingBgColor || toolMode === 'pen') return;
                              if (toolMode === 'select-region' || e.shiftKey) return;
                              e.stopPropagation();
                              onSelectPage(page.id);
                              onSelectOverlay(ov.id);
                              if (isInlineEditing) return;
                              dragStateRef.current = {
                                id: ov.id,
                                mode: 'move',
                                startClientX: e.clientX,
                                startClientY: e.clientY,
                                origX: ov.x,
                                origY: ov.y,
                                origW: ov.width,
                                origH: ov.height,
                              };
                            }}
                            onDoubleClick={(e) => {
                              if (toolMode === 'select-region') return;
                              e.stopPropagation();
                              setInlineEditingId(ov.id);
                            }}
                            style={{
                              left: `${ov.x * zoom}px`,
                              top: `${ov.y * zoom}px`,
                              width: ov.hasCustomWidth
                                ? `${Math.min(ov.width, maxWrapWidthPt) * zoom}px`
                                : 'max-content',
                              minWidth: `${Math.min(ov.width, maxWrapWidthPt) * zoom}px`,
                              maxWidth: `${maxWrapWidthPt * zoom}px`,
                              minHeight: `${ov.height * zoom}px`,
                            }}
                            className={`absolute group ${
                              toolMode === 'select-region'
                                ? 'pointer-events-none'
                                : isInlineEditing
                                ? 'ring-1 ring-blue-600 z-20 cursor-text'
                                : isSelected
                                ? 'ring-1.5 ring-blue-600 z-10 cursor-move'
                                : 'hover:ring-1 hover:ring-blue-400/70 cursor-move'
                            }`}
                          >
                            {/* Quick A- / A+ / Edit / Done micro-bar above selected overlay */}
                            {isSelected && !isInlineEditing && (
                              <div
                                data-inspector-panel="true"
                                onPointerDown={(e) => e.stopPropagation()}
                                className="absolute -top-7 left-0 flex items-center gap-1 bg-white border border-slate-200 rounded-md shadow-sm px-1 py-0.5 z-30"
                              >
                                <button
                                  type="button"
                                  data-tooltip={t.toolEditText}
                                  aria-label={t.toolEditText}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setInlineEditingId(ov.id);
                                  }}
                                  className="px-1.5 py-0.5 text-[11px] font-semibold text-blue-700 hover:bg-blue-50 rounded cursor-pointer whitespace-nowrap"
                                >
                                  {t.toolEditText}
                                </button>
                                <button
                                  type="button"
                                  data-tooltip={t.decreaseFontSize}
                                  aria-label={t.decreaseFontSize}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onUpdateOverlay(ov.id, (prev) =>
                                      prev.kind === 'text'
                                        ? {
                                            ...prev,
                                            fontSize: Math.max(6, Number((prev.fontSize - 1).toFixed(1))),
                                          }
                                        : prev
                                    );
                                  }}
                                  className="px-1.5 py-0.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                                >
                                  A-
                                </button>
                                <button
                                  type="button"
                                  data-tooltip={t.increaseFontSize}
                                  aria-label={t.increaseFontSize}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onUpdateOverlay(ov.id, (prev) =>
                                      prev.kind === 'text'
                                        ? {
                                            ...prev,
                                            fontSize: Math.min(96, Number((prev.fontSize + 1).toFixed(1))),
                                          }
                                        : prev
                                    );
                                  }}
                                  className="px-1.5 py-0.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                                >
                                  A+
                                </button>
                                <button
                                  type="button"
                                  data-tooltip={t.done}
                                  aria-label={t.done}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onFinishInlineEdit(ov.id);
                                    onSelectOverlay(null);
                                  }}
                                  className="p-0.5 text-emerald-700 hover:bg-emerald-50 rounded cursor-pointer"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}

                            {isInlineEditing && (
                              <div
                                className="relative inline-grid align-top"
                                style={{
                                  minWidth: `${Math.min(ov.width, maxWrapWidthPt) * zoom}px`,
                                  maxWidth: `${maxWrapWidthPt * zoom}px`,
                                  width: ov.hasCustomWidth
                                    ? `${Math.min(ov.width, maxWrapWidthPt) * zoom}px`
                                    : undefined,
                                }}
                              >
                                <div
                                  aria-hidden="true"
                                  dir={rtlMode ? 'rtl' : 'ltr'}
                                  style={{
                                    fontFamily: resolveCssFontFamily(ov.fontId, customFonts),
                                    fontSize: `${ov.fontSize * zoom}px`,
                                    fontWeight: ov.fontWeight,
                                    fontStyle: ov.fontStyle,
                                    textAlign: ov.textAlign,
                                    lineHeight: ov.lineHeight,
                                    letterSpacing: `${ov.letterSpacing * zoom}px`,
                                    whiteSpace: 'pre-wrap',
                                    wordBreak: 'break-word',
                                  }}
                                  className="col-start-1 row-start-1 invisible pointer-events-none p-0 m-0"
                                >
                                  {ov.text ? `${ov.text}\u200b` : ' '}
                                </div>
                                <textarea
                                  ref={inlineTextareaRef}
                                  autoFocus
                                  dir={rtlMode ? 'rtl' : 'ltr'}
                                  value={ov.text}
                                  onChange={(e) => {
                                    const nextVal = e.target.value;
                                    onUpdateOverlay(ov.id, (prev) => {
                                      if (prev.kind !== 'text') return prev;
                                      if (!prev.sourceBlockId && nextVal.trim()) {
                                        const prevScript = detectTextScript(prev.text);
                                        const nextScript = detectTextScript(nextVal);
                                        if (nextScript !== prevScript) {
                                          return {
                                            ...prev,
                                            text: nextVal,
                                            fontId:
                                              nextScript === 'ur'
                                                ? 'noto-nastaliq-urdu'
                                                : nextScript === 'fa'
                                                ? 'vazirmatn-persian'
                                                : nextScript === 'ar'
                                                ? 'noto-naskh-arabic'
                                                : nextScript === 'bn'
                                                ? 'noto-sans-bengali'
                                                : 'plus-jakarta-sans',
                                            textAlign:
                                              nextScript === 'ur' ||
                                              nextScript === 'fa' ||
                                              nextScript === 'ar'
                                                ? 'right'
                                                : 'left',
                                          };
                                        }
                                      }
                                      return { ...prev, text: nextVal };
                                    });
                                  }}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Escape') {
                                      e.preventDefault();
                                      setInlineEditingId(null);
                                      onFinishInlineEdit(ov.id);
                                    }
                                  }}
                                  onBlur={(e) => {
                                    setInlineEditingId(null);
                                    const toInspector = (
                                      e.relatedTarget as HTMLElement | null
                                    )?.closest('[data-inspector-panel="true"]');
                                    if (!toInspector) {
                                      onFinishInlineEdit(ov.id);
                                    }
                                  }}
                                  onPointerDown={(e) => e.stopPropagation()}
                                  style={{
                                    fontFamily: resolveCssFontFamily(ov.fontId, customFonts),
                                    fontSize: `${ov.fontSize * zoom}px`,
                                    fontWeight: ov.fontWeight,
                                    fontStyle: ov.fontStyle,
                                    textAlign: ov.textAlign,
                                    lineHeight: ov.lineHeight,
                                    letterSpacing: `${ov.letterSpacing * zoom}px`,
                                    color: ov.color,
                                    backgroundColor: ov.maskRect?.color || 'rgba(255,255,255,0.95)',
                                    whiteSpace: 'pre-wrap',
                                    wordBreak: 'break-word',
                                  }}
                                  className="col-start-1 row-start-1 w-full h-full focus:outline-none resize-none overflow-hidden p-0 m-0 border-0 block"
                                />

                                <button
                                  type="button"
                                  data-tooltip={t.done}
                                  aria-label={t.done}
                                  onMouseDown={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setInlineEditingId(null);
                                    onFinishInlineEdit(ov.id);
                                  }}
                                  className="absolute -top-3 -right-3 w-5 h-5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm flex items-center justify-center cursor-pointer"
                                >
                                  <Check className="w-3 h-3" />
                                </button>
                              </div>
                            )}

                            {isSelected && !isInlineEditing && (
                              <div
                                onPointerDown={(e) => {
                                  e.stopPropagation();
                                  dragStateRef.current = {
                                    id: ov.id,
                                    mode: 'resize-e',
                                    startClientX: e.clientX,
                                    startClientY: e.clientY,
                                    origX: ov.x,
                                    origY: ov.y,
                                    origW: ov.width,
                                    origH: ov.height,
                                  };
                                }}
                                className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-2.5 h-5 bg-white border border-blue-600 rounded-xs cursor-ew-resize"
                              />
                            )}
                          </div>
                        </React.Fragment>
                      );
                    }

                    return (
                      <React.Fragment key={ov.id}>
                        <div
                          onPointerDown={(e) => {
                            if (isPickingBgColor || toolMode === 'pen') return;
                            e.stopPropagation();
                            onSelectPage(page.id);
                            onSelectOverlay(ov.id);
                            dragStateRef.current = {
                              id: ov.id,
                              mode: 'move',
                              startClientX: e.clientX,
                              startClientY: e.clientY,
                              origX: ov.x,
                              origY: ov.y,
                              origW: ov.width,
                              origH: ov.height,
                            };
                          }}
                          style={{
                            left: `${ov.x * zoom}px`,
                            top: `${ov.y * zoom}px`,
                            width: `${ov.width * zoom}px`,
                            minHeight: `${ov.height * zoom}px`,
                            height: `${ov.height * zoom}px`,
                            opacity: ov.opacity,
                          }}
                          className={`absolute group ${
                            isSelected
                              ? 'ring-1.5 ring-blue-600 z-10'
                              : 'hover:ring-1 hover:ring-blue-400/70'
                          } cursor-move`}
                        >

                          {ov.kind === 'patch' && (
                            <div
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundColor: ov.fillColor,
                                border:
                                  ov.borderWidth > 0
                                    ? `${ov.borderWidth * zoom}px solid ${ov.borderColor}`
                                    : 'none',
                              }}
                            />
                          )}

                          {ov.kind === 'shape' &&
                            (ov.shapeType === 'line' ? (
                              <div className="w-full h-full flex items-center">
                                <div
                                  style={{
                                    width: '100%',
                                    height: `${Math.max(1, ov.strokeWidth * zoom)}px`,
                                    backgroundColor: ov.strokeColor,
                                  }}
                                />
                              </div>
                            ) : (
                              <div
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  backgroundColor:
                                    ov.fillColor === 'transparent'
                                      ? 'transparent'
                                      : ov.fillColor,
                                  border:
                                    ov.strokeWidth > 0
                                      ? `${ov.strokeWidth * zoom}px solid ${ov.strokeColor}`
                                      : 'none',
                                }}
                              />
                            ))}

                          {ov.kind === 'pen' && ov.points.length > 1 && (
                            <svg
                              viewBox={`0 0 ${Math.max(1, ov.width)} ${Math.max(1, ov.height)}`}
                              className="w-full h-full overflow-visible pointer-events-none"
                            >
                              <polyline
                                fill="none"
                                stroke={ov.strokeColor}
                                strokeWidth={ov.strokeWidth}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                points={ov.points.map((p) => `${p.x},${p.y}`).join(' ')}
                              />
                            </svg>
                          )}

                          {ov.kind === 'image' && (
                            <img
                              src={ov.dataUrl}
                              alt="Placed asset"
                              draggable={false}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-contain pointer-events-none"
                            />
                          )}

                          {isSelected && inlineEditingId !== ov.id && ov.kind !== 'pen' && (
                            <>
                              <div
                                onPointerDown={(e) => {
                                  e.stopPropagation();
                                  dragStateRef.current = {
                                    id: ov.id,
                                    mode: 'resize-e',
                                    startClientX: e.clientX,
                                    startClientY: e.clientY,
                                    origX: ov.x,
                                    origY: ov.y,
                                    origW: ov.width,
                                    origH: ov.height,
                                  };
                                }}
                                className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-2.5 h-5 bg-white border border-blue-600 rounded-xs cursor-ew-resize"
                              />
                              <div
                                onPointerDown={(e) => {
                                  e.stopPropagation();
                                  dragStateRef.current = {
                                    id: ov.id,
                                    mode: 'resize-se',
                                    startClientX: e.clientX,
                                    startClientY: e.clientY,
                                    origX: ov.x,
                                    origY: ov.y,
                                    origW: ov.width,
                                    origH: ov.height,
                                  };
                                }}
                                className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border border-blue-600 rounded-xs cursor-nwse-resize"
                              />
                            </>
                          )}
                        </div>
                      </React.Fragment>
                    );
                  })}

                  {/* Live Freehand Pen Stroke Preview */}
                  {penPoints && penPoints.pageId === page.id && penPoints.points.length > 1 && (
                    <svg
                      className="absolute inset-0 w-full h-full pointer-events-none"
                      viewBox={`0 0 ${pageDisplayW / zoom} ${pageDisplayH / zoom}`}
                    >
                      <polyline
                        fill="none"
                        stroke="#1d4ed8"
                        strokeWidth={2.5}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={penPoints.points.map((p) => `${p.x},${p.y}`).join(' ')}
                      />
                    </svg>
                  )}

                  {/* Live Drawing Box Preview */}
                  {drawBox && drawBox.pageId === page.id && (
                    <div
                      style={{
                        left: `${Math.min(drawBox.startX, drawBox.curX) * zoom}px`,
                        top: `${Math.min(drawBox.startY, drawBox.curY) * zoom}px`,
                        width: `${Math.abs(drawBox.curX - drawBox.startX) * zoom}px`,
                        height: `${Math.abs(drawBox.curY - drawBox.startY) * zoom}px`,
                      }}
                      className={`absolute border-1.5 border-dashed pointer-events-none ${
                        toolMode === 'highlight'
                          ? 'border-amber-500 bg-yellow-300/35'
                          : 'border-blue-600 bg-blue-500/10'
                      }`}
                    />
                  )}
                </div>
              </div>
            );
          })}
          </div>
        )}
      </div>

      {isDraggingFile && (
        <div className="absolute inset-0 z-40 bg-blue-900/20 backdrop-blur-[2px] flex items-center justify-center p-8 pointer-events-none">
          <div className="bg-white border-2 border-dashed border-blue-600 rounded-xl px-10 py-8 text-center shadow-lg">
            <div className="text-base font-semibold text-slate-900">
              {t.dropPdfPrompt}
            </div>
            <div className="text-xs text-slate-500 mt-1">{t.dropPdfSub}</div>
          </div>
        </div>
      )}
    </main>
  );
};
