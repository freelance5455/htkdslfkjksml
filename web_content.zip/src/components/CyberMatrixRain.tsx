import { useEffect, useRef } from 'react';

interface Props {
  opacity?: number;
  speed?: number;
}

export default function CyberMatrixRain({ opacity = 0.25, speed = 33 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Characters for cyber stream (matrix glyphs, binary, hex, bangla numerals & hacker characters)
    const characters = '0101010101ABCDEF0123456789GXTEAM-MEHEDIVAI-CYBER-SIGNAL-HASH-890১২৩৪৫৬৭৮৯#@%*<>';
    const fontSize = 14;
    const columns = Math.floor(width / fontSize);
    const drops: number[] = Array.from({ length: columns }, () => Math.floor(Math.random() * -100));

    let lastTime = 0;
    const render = (time: number) => {
      if (time - lastTime >= speed) {
        lastTime = time;
        // Fade effect
        ctx.fillStyle = 'rgba(5, 7, 10, 0.12)';
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = '#00ff88';
        ctx.font = `${fontSize}px 'JetBrains Mono', monospace`;

        for (let i = 0; i < drops.length; i++) {
          const char = characters[Math.floor(Math.random() * characters.length)];
          const x = i * fontSize;
          const y = drops[i] * fontSize;

          // Tip of stream is bright white/cyan
          if (Math.random() > 0.85) {
            ctx.fillStyle = '#ffffff';
          } else if (Math.random() > 0.5) {
            ctx.fillStyle = '#00e5ff';
          } else {
            ctx.fillStyle = '#00ff88';
          }

          ctx.fillText(char, x, y);

          if (y > height && Math.random() > 0.975) {
            drops[i] = 0;
          }
          drops[i]++;
        }
      }
      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
    };
  }, [speed]);

  return (
    <canvas
      ref={canvasRef}
      style={{ opacity }}
      className="fixed inset-0 pointer-events-none z-0"
    />
  );
}
