import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import { CommunityPost, PostReport } from '../../types/community';

interface ReportPostModalProps {
  post: CommunityPost | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReport: (report: PostReport) => Promise<void>;
  currentUserId: string;
}

const REPORT_REASONS: PostReport['reason'][] = [
  'Fake job or scam link',
  'Paid registration scam',
  'Misleading examination date',
  'Spam or irrelevant',
  'Inappropriate content'
];

export const ReportPostModal: React.FC<ReportPostModalProps> = ({
  post,
  isOpen,
  onClose,
  onSubmitReport,
  currentUserId
}) => {
  const [selectedReason, setSelectedReason] = useState<PostReport['reason']>(
    'Fake job or scam link'
  );
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen || !post) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);
      await onSubmitReport({
        id: `rep_${Date.now()}`,
        postId: post.id,
        postAuthorName: post.authorName,
        reportedBy: currentUserId,
        reason: selectedReason,
        details: details.trim() || undefined,
        createdAt: new Date().toISOString(),
        status: 'PENDING'
      });
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setDetails('');
        onClose();
      }, 1500);
    } catch {
      // Non-critical
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="report-community-post-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2 text-amber-400">
            <AlertTriangle className="w-5 h-5" />
            <h2 className="text-sm font-bold text-white">Report Community Post</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="p-8 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
            <h3 className="text-base font-bold text-white">Report Received</h3>
            <p className="text-xs text-slate-400">
              Thank you for keeping India Job Hub safe and authentic. Our moderation team will inspect this post promptly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 text-xs text-slate-300">
              Reporting post by <span className="font-semibold text-white">{post.authorName}</span>:
              <p className="text-slate-400 italic line-clamp-1 mt-1">"{post.content}"</p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Why are you reporting this post?
              </label>
              <div className="space-y-1.5">
                {REPORT_REASONS.map((reason) => (
                  <label
                    key={reason}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedReason === reason
                        ? 'bg-amber-950/30 border-amber-600/60 text-amber-200'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reportReason"
                      value={reason}
                      checked={selectedReason === reason}
                      onChange={() => setSelectedReason(reason)}
                      className="text-amber-500 focus:ring-0"
                    />
                    <span>{reason}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">
                Additional Details (Optional)
              </label>
              <textarea
                rows={2}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Provide context or evidence (e.g. invalid fee link, expired notice)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
              >
                {isSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Submit Report</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
