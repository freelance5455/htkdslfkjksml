import React, { useState } from 'react';
import { ReadingRoom, FriendUser, Book } from '../../types';
import { communityService } from '../../services/communityService';
import { CoverImage } from '../common/CoverImage';
import {
  X,
  Users,
  MessageSquare,
  Sparkles,
  Send,
  Reply,
  BookOpen,
  UserPlus,
  Share2,
  Check,
  Heart,
  Flame,
  ThumbsUp,
} from 'lucide-react';

interface RoomDetailModalProps {
  room: ReadingRoom | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenReaderForBook: (bookId: string) => void;
  allFriends: FriendUser[];
  onRoomUpdated?: (updatedRoom: ReadingRoom) => void;
}

export const RoomDetailModal: React.FC<RoomDetailModalProps> = ({
  room,
  isOpen,
  onClose,
  onOpenReaderForBook,
  allFriends,
  onRoomUpdated,
}) => {
  if (!isOpen || !room) return null;

  const [activeTab, setActiveTab] = useState<'chat' | 'shared' | 'participants'>('chat');
  const [messageInput, setMessageInput] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ id: string; user: string; text: string } | null>(null);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [selectedInviteFriends, setSelectedInviteFriends] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Find who is currently reading this book
  const readingNowParticipants = room.participants.filter((p) => p.isReadingNow);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    const updated = communityService.addMessage(
      room.id,
      messageInput.trim(),
      replyingTo?.id
    );
    if (updated && onRoomUpdated) {
      onRoomUpdated(updated);
    }
    setMessageInput('');
    setReplyingTo(null);
  };

  const handleReaction = (messageId: string, emoji: string) => {
    const updated = communityService.addReactionToMessage(room.id, messageId, emoji);
    if (updated && onRoomUpdated) {
      onRoomUpdated(updated);
    }
  };

  const handleInviteFriends = () => {
    if (selectedInviteFriends.length === 0) return;
    const friendsToInvite = allFriends.filter((f) => selectedInviteFriends.includes(f.id));
    const newParticipants = friendsToInvite.map((f) => ({
      userId: f.id,
      name: f.name.split(' ')[0],
      avatar: f.avatar,
      progress: 0,
      currentPage: 0,
      isReadingNow: Boolean(f.isReadingNow),
      lastActive: 'Recién invitado',
    }));

    const updatedRoom: ReadingRoom = {
      ...room,
      participants: [...room.participants, ...newParticipants],
    };
    const allRooms = communityService.getRooms();
    const idx = allRooms.findIndex((r) => r.id === room.id);
    if (idx !== -1) {
      allRooms[idx] = updatedRoom;
      communityService.saveRooms(allRooms);
      if (onRoomUpdated) onRoomUpdated(updatedRoom);
    }
    setIsInviteOpen(false);
    setSelectedInviteFriends([]);
    showToast(`Invitación enviada a ${newParticipants.length} amigo(s).`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-3xl glass-panel rounded-3xl border border-white/15 shadow-2xl flex flex-col h-[90vh] max-h-[850px] overflow-hidden">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-white/[0.02]">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-11 h-16 sm:w-12 sm:h-18 rounded-lg overflow-hidden shrink-0 border border-white/15 shadow-md">
              <CoverImage
                url={room.bookCover}
                title={room.bookTitle}
                author={room.bookAuthor}
                showShadow={false}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 uppercase tracking-wider">
                  Sala de lectura compartida
                </span>
                {/* Requisito 12: ESTAMOS LEYENDO indicador discreto */}
                {readingNowParticipants.length > 0 && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[10px] font-semibold text-emerald-400 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    {readingNowParticipants.map((p) => p.name).join(', ')} está leyendo
                  </span>
                )}
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight truncate font-['Syne'] mt-1">
                {room.bookTitle}
              </h2>
              <p className="text-xs text-zinc-400 truncate">{room.bookAuthor}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onOpenReaderForBook(room.bookId)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-sm transition-all"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Abrir en lector</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Requisito 7: Progreso individual de cada participante (sin sincronizar páginas a la fuerza) */}
        <div className="px-4 py-3 bg-white/[0.015] border-b border-white/[0.06] shrink-0">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-zinc-300" />
              <span>Participantes ({room.participants.length}) — Progreso individual</span>
            </span>
            <button
              onClick={() => setIsInviteOpen(true)}
              className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
            >
              <UserPlus className="w-3 h-3" />
              <span>Invitar amigos</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {room.participants.map((p) => {
              const isMe = p.userId === 'me';
              return (
                <div
                  key={p.userId}
                  className={`p-2.5 rounded-xl border transition-all ${
                    isMe
                      ? 'bg-cyan-500/10 border-cyan-500/30'
                      : 'bg-white/[0.03] border-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1.5">
                    <div className="flex items-center gap-2 min-w-0">
                      {p.avatar ? (
                        <img
                          src={p.avatar}
                          alt={p.name}
                          className="w-6 h-6 rounded-full object-cover border border-white/20 shrink-0"
                        />
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-zinc-800 border border-white/20 flex items-center justify-center text-[10px] font-bold text-white shrink-0">
                          {p.name.charAt(0)}
                        </div>
                      )}
                      <div className="min-w-0">
                        <span className="text-xs font-semibold text-white truncate block">
                          {p.name}
                        </span>
                        {p.isReadingNow && (
                          <span className="text-[9px] text-emerald-400 font-medium block">
                            Leyendo ahora
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-white shrink-0">
                      {p.progress}%
                    </span>
                  </div>

                  {/* Individual progress bar */}
                  <div className="w-full h-1 rounded-full bg-white/10 overflow-hidden mt-2">
                    <div
                      className={`h-full rounded-full ${
                        isMe ? 'bg-cyan-400' : 'bg-zinc-300'
                      }`}
                      style={{ width: `${p.progress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tab Switcher: Conversación de la sala | Contenido compartido */}
        <div className="flex items-center px-4 border-b border-white/10 text-xs shrink-0">
          <button
            onClick={() => setActiveTab('chat')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'chat'
                ? 'border-white text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Conversación de la sala ({room.messages.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('shared')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'shared'
                ? 'border-white text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Contenido compartido ({room.sharedItems.length})</span>
          </button>
        </div>

        {/* Toast message if any */}
        {toastMessage && (
          <div className="mx-4 mt-2 p-2.5 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2">
            <Check className="w-3.5 h-3.5 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Tab 1: Conversación de la Sala (Chat) */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Messages list */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
              {room.messages.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 text-xs">
                  Aún no hay mensajes. Sé el primero en iniciar la conversación sobre este libro.
                </div>
              ) : (
                room.messages.map((m) => {
                  const isMe = m.userId === 'me';
                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                    >
                      <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                        <span className="font-semibold text-zinc-300">{m.userName}</span>
                        <span>·</span>
                        <span>
                          {new Date(m.createdAt).toLocaleTimeString('es-ES', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      {/* Replying context */}
                      {m.replyToText && (
                        <div className="text-[11px] text-zinc-400 bg-white/[0.04] border-l-2 border-cyan-400 px-2.5 py-1 rounded max-w-md truncate">
                          ↳ <span className="italic">{m.replyToText}</span>
                        </div>
                      )}

                      {/* Message Bubble */}
                      <div
                        className={`group relative max-w-md p-3 rounded-2xl text-xs leading-relaxed ${
                          isMe
                            ? 'bg-zinc-800 text-white border border-white/15'
                            : 'glass-panel-subtle text-zinc-200 border border-white/10'
                        }`}
                      >
                        <p>{m.text}</p>

                        {/* Hover actions: Reply & React */}
                        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-black/60 rounded-lg p-0.5">
                          <button
                            type="button"
                            onClick={() =>
                              setReplyingTo({ id: m.id, user: m.userName, text: m.text })
                            }
                            className="p-1 hover:text-cyan-400 text-zinc-400"
                            title="Responder"
                          >
                            <Reply className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleReaction(m.id, '❤️')}
                            className="p-1 hover:scale-125 transition-transform"
                            title="Me gusta"
                          >
                            ❤️
                          </button>
                          <button
                            type="button"
                            onClick={() => handleReaction(m.id, '🔥')}
                            className="p-1 hover:scale-125 transition-transform"
                            title="Fuego"
                          >
                            🔥
                          </button>
                        </div>
                      </div>

                      {/* Reactions Pills */}
                      {m.reactions && Object.keys(m.reactions).length > 0 && (
                        <div className="flex items-center gap-1">
                          {Object.entries(m.reactions).map(([emoji, users]) => (
                            <button
                              key={emoji}
                              type="button"
                              onClick={() => handleReaction(m.id, emoji)}
                              className={`px-1.5 py-0.5 rounded-full text-[10px] flex items-center gap-1 border transition-all ${
                                users.includes('Tú (Yo)')
                                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                                  : 'bg-white/[0.05] border-white/10 text-zinc-300 hover:bg-white/10'
                              }`}
                            >
                              <span>{emoji}</span>
                              <span className="font-mono">{users.length}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Reply banner if active */}
            {replyingTo && (
              <div className="px-4 py-1.5 bg-zinc-900 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-zinc-400 truncate">
                  Respondiendo a <strong className="text-white">{replyingTo.user}</strong>: "{replyingTo.text}"
                </span>
                <button
                  type="button"
                  onClick={() => setReplyingTo(null)}
                  className="text-zinc-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Input bar */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 border-t border-white/10 bg-white/[0.02] flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Escribe un comentario en la sala..."
                className="flex-1 bg-zinc-900/90 border border-white/15 focus:border-cyan-400/80 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!messageInput.trim()}
                className="w-9 h-9 rounded-xl bg-white hover:bg-zinc-200 disabled:opacity-40 text-zinc-950 flex items-center justify-center transition-all shrink-0 font-bold"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: Contenido Compartido */}
        {activeTab === 'shared' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {room.sharedItems.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 text-xs">
                Aún no hay subrayados, anotaciones o frases compartidas en esta sala. Cuando leas el libro, selecciona cualquier texto y elige "Compartir con la sala".
              </div>
            ) : (
              room.sharedItems.map((item) => (
                <div
                  key={item.id}
                  className="glass-panel-subtle rounded-2xl p-4 border border-white/10 space-y-2 relative"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      {item.userAvatar ? (
                        <img
                          src={item.userAvatar}
                          alt={item.userName}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-zinc-800 flex items-center justify-center text-[9px] font-bold text-white">
                          {item.userName.charAt(0)}
                        </div>
                      )}
                      <span className="font-semibold text-white">{item.userName}</span>
                      <span className="text-[10px] text-zinc-400">
                        en pág. {item.page}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.reaction && (
                        <span className="px-2 py-0.5 rounded-lg bg-white/10 text-xs">
                          {item.reaction}
                        </span>
                      )}
                      <button
                        onClick={() => onOpenReaderForBook(room.bookId)}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold underline ml-1"
                      >
                        Ver en libro
                      </button>
                    </div>
                  </div>

                  {item.text && (
                    <blockquote
                      className="p-3 rounded-xl text-xs font-serif italic text-zinc-200 border-l-2 bg-white/[0.02]"
                      style={{ borderColor: item.color || '#a855f7' }}
                    >
                      "{item.text}"
                    </blockquote>
                  )}

                  {item.note && (
                    <div className="text-xs text-zinc-300 bg-white/[0.03] p-2.5 rounded-xl border border-white/[0.06]">
                      <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-0.5">
                        Anotación compartida:
                      </span>
                      {item.note}
                    </div>
                  )}

                  {item.stickerUrl && (
                    <div className="pt-1">
                      <img
                        src={item.stickerUrl}
                        alt="Sticker"
                        className="w-14 h-14 object-contain rounded-lg border border-white/10"
                      />
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Invite Friends Modal Overlay */}
        {isInviteOpen && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="w-full max-w-md glass-panel rounded-2xl p-5 border border-white/20 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <h3 className="font-bold text-white text-sm">Invitar amigos a la sala</h3>
                <button
                  type="button"
                  onClick={() => setIsInviteOpen(false)}
                  className="text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {allFriends
                  .filter((f) => !room.participants.some((p) => p.userId === f.id))
                  .map((friend) => {
                    const isSelected = selectedInviteFriends.includes(friend.id);
                    return (
                      <div
                        key={friend.id}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedInviteFriends(
                              selectedInviteFriends.filter((id) => id !== friend.id)
                            );
                          } else {
                            setSelectedInviteFriends([...selectedInviteFriends, friend.id]);
                          }
                        }}
                        className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-cyan-500/15 border-cyan-400 text-white'
                            : 'bg-white/[0.03] border-white/10 text-zinc-300 hover:bg-white/[0.08]'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <img
                            src={friend.avatar}
                            alt={friend.name}
                            className="w-8 h-8 rounded-full object-cover border border-white/20"
                          />
                          <div>
                            <span className="text-xs font-bold block">{friend.name}</span>
                            <span className="text-[10px] text-zinc-400 block">{friend.statusText}</span>
                          </div>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                            isSelected
                              ? 'bg-cyan-400 border-cyan-400 text-zinc-950 font-bold text-xs'
                              : 'border-white/30'
                          }`}
                        >
                          {isSelected && '✓'}
                        </div>
                      </div>
                    );
                  })}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsInviteOpen(false)}
                  className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleInviteFriends}
                  disabled={selectedInviteFriends.length === 0}
                  className="px-4 py-2 bg-white hover:bg-zinc-200 disabled:opacity-40 text-zinc-950 font-bold text-xs rounded-xl transition-all shadow"
                >
                  Enviar invitación ({selectedInviteFriends.length})
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
