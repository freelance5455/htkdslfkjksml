import React, { useState } from 'react';
import { X, Send, MessageSquare, Trash2, Clock } from 'lucide-react';
import { PostComment, UserProfile } from '../../types/community';

interface CommentsDrawerProps {
  isOpen: boolean;
  postId: string;
  postTitle?: string;
  comments: PostComment[];
  currentUserId: string;
  currentUserProfile: UserProfile;
  onClose: () => void;
  onAddComment: (postId: string, content: string) => Promise<void>;
  onDeleteComment?: (commentId: string) => Promise<void>;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({
  isOpen,
  postId,
  postTitle,
  comments,
  currentUserId,
  currentUserProfile,
  onClose,
  onAddComment,
  onDeleteComment
}) => {
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || isSubmitting) return;

    try {
      setIsSubmitting(true);
      await onAddComment(postId, newComment.trim());
      setNewComment('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatRelativeTime = (isoString: string) => {
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const minutes = Math.floor(diff / 60000);
      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes}m ago`;
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    } catch {
      return 'Recently';
    }
  };

  return (
    <div
      id="comments-drawer"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4 animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm sm:text-base font-bold text-white">
              Discussion ({comments.length})
            </h2>
          </div>
          <button
            id="btn-close-comments-drawer"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 divide-y divide-slate-800/40">
          {comments.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <MessageSquare className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm font-medium text-slate-300">No comments yet</p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Be the first aspirant to share your perspective, query, or exam advice!
              </p>
            </div>
          ) : (
            comments.map((comment) => {
              const isAuthor =
                comment.authorUid === currentUserId || comment.authorId === currentUserId;
              return (
                <div key={comment.id} className="pt-3.5 first:pt-0 flex gap-3 group">
                  {/* Avatar */}
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-200 overflow-hidden shrink-0 ring-1 ring-slate-700">
                    {comment.authorAvatar ? (
                      <img
                        src={comment.authorAvatar}
                        alt={comment.authorName}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      comment.authorName.charAt(0)
                    )}
                  </div>

                  {/* Comment Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-slate-200">
                          {comment.authorName}
                        </span>
                        {comment.authorHeadline && (
                          <span className="text-[10px] text-slate-400 truncate max-w-[180px]">
                            • {comment.authorHeadline}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                          <Clock className="w-3 h-3" />
                          {formatRelativeTime(comment.createdAt)}
                        </span>
                        {isAuthor && onDeleteComment && (
                          <button
                            onClick={() => onDeleteComment(comment.id)}
                            className="text-slate-600 hover:text-red-400 p-1 rounded transition-colors"
                            title="Delete your comment"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 mt-1 leading-relaxed break-words whitespace-pre-wrap">
                      {comment.content}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSubmit}
          className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2"
        >
          <div className="w-7 h-7 rounded-full bg-indigo-900/60 text-indigo-200 flex items-center justify-center text-xs font-bold shrink-0">
            {currentUserProfile.avatar ? (
              <img
                src={currentUserProfile.avatar}
                alt={currentUserProfile.name}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              currentUserProfile.name.charAt(0)
            )}
          </div>

          <input
            type="text"
            id="input-new-comment"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment or question..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />

          <button
            type="submit"
            id="btn-send-comment"
            disabled={!newComment.trim() || isSubmitting}
            className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl transition-all shrink-0 active:scale-95"
            title="Post comment"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
