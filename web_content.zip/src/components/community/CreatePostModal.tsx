import React, { useState, useRef } from 'react';
import {
  X,
  Image as ImageIcon,
  Link as LinkIcon,
  Briefcase,
  Building,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  Tag
} from 'lucide-react';
import { CreatePostInput, UserProfile } from '../../types/community';
import { getUserFriendlyErrorMessage } from '../../lib/firebase';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (input: CreatePostInput) => Promise<void>;
  currentUserProfile: UserProfile;
}

const MAX_CHARACTERS = 1500;

const SUGGESTED_TAGS = [
  '#GovtJobs',
  '#SarkariNaukri',
  '#ExamStrategy',
  '#RailwayJobs',
  '#BankingJobs',
  '#SSCCGL',
  '#FresherJobs',
  '#DocumentVerification',
  '#InterviewTips'
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  currentUserProfile
}) => {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [jobLink, setJobLink] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [jobOrganization, setJobOrganization] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showJobLinkInput, setShowJobLinkInput] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageUploadLoading, setImageUploadLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImageFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage('Image size should be under 5MB');
      return;
    }

    setSelectedFile(file);
    setImageUploadLoading(true);
    setErrorMessage('');

    // Read as Data URL so it is immediately previewable in the UI
    const reader = new FileReader();
    reader.onload = () => {
      setImageUrl(reader.result as string);
      setImageUploadLoading(false);
    };
    reader.onerror = () => {
      setErrorMessage('Failed to read image file');
      setImageUploadLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      if (selectedTags.length < 5) {
        setSelectedTags([...selectedTags, tag]);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !imageUrl && !selectedFile) {
      setErrorMessage('Please write some text or attach an image to share.');
      return;
    }

    if (jobLink && !jobLink.startsWith('http://') && !jobLink.startsWith('https://')) {
      setErrorMessage('Job application link must start with https:// or http://');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMessage('');

      await onSubmit({
        content: content.trim(),
        imageFile: selectedFile || undefined,
        imageUrl: imageUrl.trim() || undefined,
        jobLink: jobLink.trim() || undefined,
        jobTitle: jobTitle.trim() || undefined,
        jobOrganization: jobOrganization.trim() || undefined,
        tags: selectedTags
      });

      // Reset form
      setContent('');
      setImageUrl('');
      setSelectedFile(null);
      setJobLink('');
      setJobTitle('');
      setJobOrganization('');
      setSelectedTags([]);
      setShowJobLinkInput(false);
      onClose();
    } catch (err: any) {
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Failed to publish post. Please try again.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const remainingChars = MAX_CHARACTERS - content.length;
  const isOverLimit = remainingChars < 0;

  return (
    <div
      id="create-post-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-white">Create Community Post</h2>
          </div>
          <button
            id="btn-close-create-post"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
            title="Cancel"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Author Badge */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-600 to-amber-500 flex items-center justify-center text-white font-bold text-sm overflow-hidden ring-2 ring-indigo-500/30 shrink-0">
              {currentUserProfile.avatar ? (
                <img
                  src={currentUserProfile.avatar}
                  alt={currentUserProfile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                currentUserProfile.name.charAt(0)
              )}
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-semibold text-white truncate flex items-center gap-1.5">
                <span>{currentUserProfile.name}</span>
                {currentUserProfile.isVerified && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20" />
                )}
              </h3>
              <p className="text-xs text-slate-400 truncate">
                {currentUserProfile.headline}
              </p>
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-xl flex items-center gap-2 text-xs text-red-300">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Text Area */}
          <div className="space-y-1">
            <textarea
              id="post-content-textarea"
              rows={5}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What job updates, preparation strategy, or vacancy notice do you want to share with fellow Indian aspirants?"
              className="w-full bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm resize-none"
            />
            <div className="flex items-center justify-between text-xs px-1">
              <span className="text-slate-500">Supports multi-line formatting and links</span>
              <span
                className={`font-mono font-medium ${
                  isOverLimit ? 'text-red-400' : remainingChars < 100 ? 'text-amber-400' : 'text-slate-500'
                }`}
              >
                {remainingChars} chars remaining
              </span>
            </div>
          </div>

          {/* Image Preview if selected */}
          {imageUrl && (
            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 group">
              <img
                src={imageUrl}
                alt="Post preview"
                className="w-full max-h-56 object-cover"
              />
              <button
                type="button"
                id="btn-remove-post-image"
                onClick={() => {
                  setImageUrl('');
                  setSelectedFile(null);
                }}
                className="absolute top-2 right-2 p-1.5 bg-slate-900/80 hover:bg-red-600 text-white rounded-full transition-colors shadow-md"
                title="Remove image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Job/Application Link Section */}
          {showJobLinkInput ? (
            <div className="p-3.5 bg-slate-950/80 border border-indigo-900/40 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-400 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" /> Job Application / Notification Link
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setShowJobLinkInput(false);
                    setJobLink('');
                    setJobTitle('');
                    setJobOrganization('');
                  }}
                  className="text-xs text-slate-500 hover:text-slate-300"
                >
                  Remove
                </button>
              </div>

              <input
                type="url"
                id="post-job-link-input"
                value={jobLink}
                onChange={(e) => setJobLink(e.target.value)}
                placeholder="https://official-portal.gov.in/careers"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="relative">
                  <Briefcase className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    id="post-job-title-input"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="Job Title (e.g., RRB NTPC 2026)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="relative">
                  <Building className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    id="post-job-org-input"
                    value={jobOrganization}
                    onChange={(e) => setJobOrganization(e.target.value)}
                    placeholder="Organization (e.g., Indian Railways)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>
          ) : (
            <button
              type="button"
              id="btn-toggle-job-link-field"
              onClick={() => setShowJobLinkInput(true)}
              className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-medium py-1 px-2.5 rounded-lg border border-indigo-500/20 hover:bg-indigo-950/20 transition-all"
            >
              <LinkIcon className="w-3.5 h-3.5" />
              <span>+ Add Official Job / Application Link</span>
            </button>
          )}

          {/* Quick Tag selector */}
          <div className="space-y-1.5">
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Tag className="w-3 h-3 text-slate-500" /> Select relevant topics (up to 5):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SUGGESTED_TAGS.map((tag) => {
                const isSelected = selectedTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`text-xs px-2.5 py-1 rounded-full border transition-all ${
                      isSelected
                        ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300 font-semibold'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Hidden File Input for Image */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleImageFileSelect}
          />

          {/* Bottom Actions Bar */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="btn-upload-image-post"
                onClick={() => fileInputRef.current?.click()}
                disabled={imageUploadLoading}
                className="p-2 text-slate-400 hover:text-indigo-400 hover:bg-indigo-950/30 border border-slate-800 rounded-xl transition-all flex items-center gap-1.5 text-xs font-medium"
                title="Add an image or vacancy flyer"
              >
                {imageUploadLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                ) : (
                  <ImageIcon className="w-4 h-4 text-emerald-400" />
                )}
                <span>Photo / Flyer</span>
              </button>
            </div>

            <button
              type="submit"
              id="btn-submit-post"
              disabled={isSubmitting || isOverLimit || (!content.trim() && !imageUrl)}
              className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold rounded-xl text-sm transition-all shadow-md shadow-indigo-950/50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Publishing...</span>
                </>
              ) : (
                <span>Post to Community</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
