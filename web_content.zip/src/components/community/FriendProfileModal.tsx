import React from 'react';
import { FriendUser, Book } from '../../types';
import { CoverImage } from '../common/CoverImage';
import {
  X,
  BookOpen,
  Heart,
  User,
  Sparkles,
  Flame,
  Award,
  Layers,
  MessageCircle,
} from 'lucide-react';

interface FriendProfileModalProps {
  friend: FriendUser | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenBookDetail?: (book: Book) => void;
  books: Book[];
}

export const FriendProfileModal: React.FC<FriendProfileModalProps> = ({
  friend,
  isOpen,
  onClose,
  onOpenBookDetail,
  books,
}) => {
  if (!isOpen || !friend) return null;

  const shared = friend.sharedProfile;
  const theme = shared?.theme || {
    primaryColor: '#8b5cf6',
    accentColor: '#ec4899',
    avatarFrameColor: '#a855f7',
    avatarFrameShape: 'circle',
    bannerType: 'preset',
    bannerValue: 'linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%)',
    bannerBlur: 16,
  };

  const privacy = shared?.privacy || {
    showBooks: true,
    showFavoriteBook: true,
    showCurrentBook: true,
    showFavoriteAuthor: true,
    showFavoriteGenre: true,
    showStats: true,
    showActivity: true,
    showCollections: true,
    showQuotes: true,
  };

  const profileAccent = theme.accentColor || theme.primaryColor || '#ec4899';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div
        className="w-full max-w-xl glass-panel rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-all"
        style={{
          borderColor: `${profileAccent}45`,
          boxShadow: `0 25px 60px -15px ${profileAccent}35, 0 0 50px ${profileAccent}15`,
        }}
      >
        {/* Banner with blur effect behind profile info (Requirement 3 & 9) */}
        <div className="relative h-44 sm:h-52 w-full overflow-hidden shrink-0">
          <div
            className="absolute inset-0 w-full h-full scale-110"
            style={{
              background: theme.bannerValue.startsWith('http')
                ? `url(${theme.bannerValue}) center/cover no-repeat`
                : theme.bannerValue,
              filter: `blur(${theme.bannerBlur || 16}px)`,
              opacity: 0.75,
            }}
          />
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.4) 60%, #07080a 100%), radial-gradient(circle at 50% 0%, ${profileAccent}30 0%, transparent 70%)`,
            }}
          />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition-all border border-white/20 active:scale-95"
            style={{ borderColor: `${profileAccent}50` }}
            title="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Card Body */}
        <div className="px-6 pb-6 -mt-16 sm:-mt-20 relative z-10 flex-1 overflow-y-auto space-y-5">
          {/* Avatar and Main Info */}
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4 text-center sm:text-left">
            <div className="relative">
              <img
                src={friend.avatar}
                alt={friend.name}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover shadow-2xl border-4"
                style={{
                  borderColor: theme.avatarFrameColor || profileAccent || '#ffffff',
                  boxShadow: `0 0 28px ${profileAccent}66`,
                }}
              />
              {friend.isReadingNow && (
                <div
                  className="absolute -bottom-1 -right-1 px-2.5 py-0.5 rounded-full text-zinc-950 text-[10px] font-bold border-2 border-black flex items-center gap-1 shadow"
                  style={{ backgroundColor: profileAccent }}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-black animate-pulse" />
                  Leyendo
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
                {friend.name}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-300 mt-0.5">{friend.bio}</p>
              <div className="flex items-center justify-center sm:justify-start gap-2 mt-2">
                <span
                  className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-white border shadow-sm"
                  style={{
                    backgroundColor: `${profileAccent}33`,
                    borderColor: `${profileAccent}77`,
                    color: '#ffffff',
                  }}
                >
                  Perfil de Amigo
                </span>
                {friend.statusText && (
                  <span className="text-[11px] text-zinc-300">· {friend.statusText}</span>
                )}
              </div>
            </div>
          </div>

          {/* Special Reading Favorites (Libro favorito, Leyendo actualmente, Autor favorito, Género favorito) */}
          {/* Special Reading Favorites (Libro favorito, Leyendo actualmente, Autor favorito, Género favorito) */}
          <div className="space-y-3 pt-2">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" style={{ color: profileAccent }} />
              <span>Gusto literario</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Libro Favorito */}
              {privacy.showFavoriteBook && shared?.favoriteBookTitle && (
                <div
                  className="rounded-2xl p-3.5 border flex items-center gap-3 transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(135deg, ${profileAccent}18, rgba(255,255,255,0.03))`,
                  }}
                >
                  {shared.favoriteBookCover && (
                    <div
                      className="w-10 h-14 rounded-lg overflow-hidden shrink-0 border shadow-md"
                      style={{ borderColor: `${profileAccent}50` }}
                    >
                      <CoverImage
                        url={shared.favoriteBookCover}
                        title={shared.favoriteBookTitle}
                        author={shared.favoriteBookAuthor || ''}
                        showShadow={false}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="min-w-0">
                    <span
                      className="text-[10px] uppercase font-bold block"
                      style={{ color: profileAccent }}
                    >
                      Libro Favorito
                    </span>
                    <h4 className="text-xs font-bold text-white truncate mt-0.5">
                      {shared.favoriteBookTitle}
                    </h4>
                    {shared.favoriteBookAuthor && (
                      <p className="text-[11px] text-zinc-300 truncate">{shared.favoriteBookAuthor}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Leyendo actualmente */}
              {privacy.showCurrentBook && shared?.currentBookTitle && (
                <div
                  className="rounded-2xl p-3.5 border flex items-center gap-3 transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(135deg, ${profileAccent}18, rgba(255,255,255,0.03))`,
                  }}
                >
                  {shared.currentBookCover && (
                    <div
                      className="w-10 h-14 rounded-lg overflow-hidden shrink-0 border shadow-md"
                      style={{ borderColor: `${profileAccent}50` }}
                    >
                      <CoverImage
                        url={shared.currentBookCover}
                        title={shared.currentBookTitle}
                        author={shared.currentBookAuthor || ''}
                        showShadow={false}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="min-w-0">
                    <span
                      className="text-[10px] uppercase font-bold block flex items-center gap-1"
                      style={{ color: profileAccent }}
                    >
                      <span
                        className="w-1.5 h-1.5 rounded-full animate-pulse"
                        style={{ backgroundColor: profileAccent }}
                      />
                      Leyendo ahora
                    </span>
                    <h4 className="text-xs font-bold text-white truncate mt-0.5">
                      {shared.currentBookTitle}
                    </h4>
                    {shared.favoriteBookAuthor && (
                      <p className="text-[11px] text-zinc-300 truncate">{shared.currentBookAuthor}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Autor Favorito */}
              {privacy.showFavoriteAuthor && shared?.favoriteAuthor && (
                <div
                  className="rounded-2xl p-3 border transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(135deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }}
                >
                  <span
                    className="text-[10px] uppercase font-bold block"
                    style={{ color: profileAccent }}
                  >
                    Autor Favorito
                  </span>
                  <p className="text-xs font-bold text-white truncate mt-1">
                    {shared.favoriteAuthor}
                  </p>
                </div>
              )}

              {/* Género Favorito */}
              {privacy.showFavoriteGenre && shared?.favoriteGenre && (
                <div
                  className="rounded-2xl p-3 border transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(135deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }}
                >
                  <span
                    className="text-[10px] uppercase font-bold block"
                    style={{ color: profileAccent }}
                  >
                    Género Favorito
                  </span>
                  <p className="text-xs font-bold text-white truncate mt-1">
                    {shared.favoriteGenre}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Estadísticas de Amigo (si están habilitadas) */}
          {privacy.showStats && (
            <div className="space-y-2 pt-2">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" style={{ color: profileAccent }} />
                <span>Estadísticas de lectura</span>
              </h3>
              <div className="grid grid-cols-3 gap-2">
                <div
                  className="rounded-xl p-3 text-center border transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}18, rgba(255,255,255,0.02))`,
                  }}
                >
                  <span className="text-[10px] uppercase font-semibold block" style={{ color: profileAccent }}>
                    Libros
                  </span>
                  <span className="text-base font-bold text-white font-mono mt-0.5 block">14</span>
                </div>
                <div
                  className="rounded-xl p-3 text-center border transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}18, rgba(255,255,255,0.02))`,
                  }}
                >
                  <span className="text-[10px] uppercase font-semibold block" style={{ color: profileAccent }}>
                    Páginas
                  </span>
                  <span className="text-base font-bold text-white font-mono mt-0.5 block">4,280</span>
                </div>
                <div
                  className="rounded-xl p-3 text-center border transition-all"
                  style={{
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}18, rgba(255,255,255,0.02))`,
                  }}
                >
                  <span className="text-[10px] uppercase font-semibold block" style={{ color: profileAccent }}>
                    Racha
                  </span>
                  <span className="text-base font-bold text-white font-mono mt-0.5 block">18d</span>
                </div>
              </div>
            </div>
          )}

          {/* Acciones */}
          <div
            className="pt-3 border-t flex items-center justify-between"
            style={{ borderColor: `${profileAccent}30` }}
          >
            <span className="text-[11px] text-zinc-300">
              Conectados en Mi Biblioteca
            </span>
            <button
              onClick={onClose}
              className="px-4 py-2 font-bold text-xs rounded-xl shadow-lg transition-all active:scale-95"
              style={{
                backgroundColor: profileAccent,
                color: '#ffffff',
                boxShadow: `0 4px 18px ${profileAccent}55`,
              }}
            >
              Cerrar perfil
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
