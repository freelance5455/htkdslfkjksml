import React, { useState, useEffect } from 'react';
import {
  FriendUser,
  FriendRequest,
  ReadingRoom,
  RoomActivity,
  Book,
} from '../../types';
import { communityService } from '../../services/communityService';
import { RoomDetailModal } from './RoomDetailModal';
import { FriendProfileModal } from './FriendProfileModal';
import { CoverImage } from '../common/CoverImage';
import {
  Users,
  MessageSquare,
  BookOpen,
  Plus,
  Share2,
  Clock,
  Sparkles,
  Search,
  UserPlus,
  Check,
  X,
  ArrowRight,
  Flame,
  Radio,
} from 'lucide-react';

interface CommunityViewProps {
  books: Book[];
  onOpenReaderForBook: (book: Book) => void;
  onOpenBookDetail: (book: Book) => void;
  initialRoomId?: string | null;
}

export const CommunityView: React.FC<CommunityViewProps> = ({
  books,
  onOpenReaderForBook,
  onOpenBookDetail,
  initialRoomId,
}) => {
  const [activeSection, setActiveSection] = useState<'salas' | 'amigos' | 'actividad'>('salas');
  const [friends, setFriends] = useState<FriendUser[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [rooms, setRooms] = useState<ReadingRoom[]>([]);
  const [activities, setActivities] = useState<RoomActivity[]>([]);

  // Modals inside Community
  const [selectedRoom, setSelectedRoom] = useState<ReadingRoom | null>(null);
  const [selectedFriend, setSelectedFriend] = useState<FriendUser | null>(null);
  const [isCreateRoomOpen, setIsCreateRoomOpen] = useState(false);
  const [selectedBookForNewRoom, setSelectedBookForNewRoom] = useState<string>('');
  const [selectedFriendsForNewRoom, setSelectedFriendsForNewRoom] = useState<string[]>([]);
  const [searchFriendQuery, setSearchFriendQuery] = useState('');
  const [addFriendInput, setAddFriendInput] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const reloadData = () => {
    setFriends(communityService.getFriends());
    setRequests(communityService.getFriendRequests());
    setRooms(communityService.getRooms());
    setActivities(communityService.getAllRecentActivities());
  };

  useEffect(() => {
    reloadData();
  }, []);

  useEffect(() => {
    if (initialRoomId) {
      const allRooms = communityService.getRooms();
      const r = allRooms.find((x) => x.id === initialRoomId);
      if (r) {
        setSelectedRoom(r);
        setActiveSection('salas');
      }
    }
  }, [initialRoomId]);

  const handleAcceptRequest = (reqId: string) => {
    const res = communityService.respondFriendRequest(reqId, true);
    setRequests(res.requests);
    setFriends(res.friends);
    showNotification('¡Solicitud de amistad aceptada!');
  };

  const handleRejectRequest = (reqId: string) => {
    const res = communityService.respondFriendRequest(reqId, false);
    setRequests(res.requests);
    showNotification('Solicitud rechazada.');
  };

  const handleAddNewFriend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addFriendInput.trim()) return;
    const newFriend: FriendUser = {
      id: 'friend-' + Date.now(),
      name: addFriendInput.trim(),
      avatar: `https://images.unsplash.com/photo-${1534528741775 + Math.floor(Math.random() * 1000)}?auto=format&fit=crop&q=80&w=256`,
      bio: 'Amante de la literatura y descubridor de historias.',
      statusText: 'Nuevo en la comunidad',
      isReadingNow: false,
    };
    const updated = communityService.addFriend(newFriend);
    setFriends(updated);
    setAddFriendInput('');
    showNotification(`¡Añadiste a ${newFriend.name} como amigo!`);
  };

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    const targetBook = books.find((b) => b.id === selectedBookForNewRoom);
    if (!targetBook) return;

    const newRoom = communityService.createRoom(
      targetBook,
      selectedFriendsForNewRoom,
      targetBook.progress || 0,
      targetBook.pagesRead || 0
    );
    setRooms(communityService.getRooms());
    setIsCreateRoomOpen(false);
    setSelectedBookForNewRoom('');
    setSelectedFriendsForNewRoom([]);
    setSelectedRoom(newRoom);
    showNotification(`¡Sala de lectura creada para "${targetBook.title}"!`);
  };

  const filteredFriends = friends.filter((f) =>
    f.name.toLowerCase().includes(searchFriendQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-20 animate-fadeIn">
      {/* Community Header & Primary Navigation Tabs */}
      <div className="glass-panel rounded-3xl p-5 sm:p-7 border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 uppercase tracking-wider">
                Comunidad de Lectura
              </span>
              {requests.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-500/40 text-[10px] font-bold text-rose-300 animate-pulse">
                  {requests.length} solicitud pendiente
                </span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne'] mt-1">
              Amigos & Salas de Lectura
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">
              Comparte progresos, citas, notas y conversaciones sin sincronizar páginas a la fuerza.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => setIsCreateRoomOpen(true)}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Crear sala de lectura</span>
            </button>
          </div>
        </div>

        {/* Section Navigation Tabs: Salas | Amigos | Actividad */}
        <div className="flex items-center gap-2 mt-6 border-t border-white/10 pt-4 overflow-x-auto text-xs no-scrollbar">
          <button
            onClick={() => setActiveSection('salas')}
            className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
              activeSection === 'salas'
                ? 'bg-white/15 text-white shadow-sm border border-white/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <Radio className="w-4 h-4 text-cyan-400" />
            <span>Salas de Lectura ({rooms.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('amigos')}
            className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
              activeSection === 'amigos'
                ? 'bg-white/15 text-white shadow-sm border border-white/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <Users className="w-4 h-4 text-purple-400" />
            <span>Amigos ({friends.length})</span>
            {requests.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500" />
            )}
          </button>

          <button
            onClick={() => setActiveSection('actividad')}
            className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
              activeSection === 'actividad'
                ? 'bg-white/15 text-white shadow-sm border border-white/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Actividad de Salas</span>
          </button>
        </div>
      </div>

      {/* In-view Toast Notification */}
      {notification && (
        <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2 animate-fadeIn shadow-lg">
          <Check className="w-4 h-4 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* SECTION 1: SALAS DE LECTURA */}
      {activeSection === 'salas' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Tus Salas de Lectura Compartida
            </h2>
            <span className="text-xs text-zinc-400">
              Cada lector conserva su propio ritmo y posición
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rooms.map((room) => {
              const readingNow = room.participants.filter((p) => p.isReadingNow);
              return (
                <div
                  key={room.id}
                  onClick={() => setSelectedRoom(room)}
                  className="glass-panel-interactive rounded-3xl p-5 border border-white/10 cursor-pointer space-y-4 group relative overflow-hidden"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-xl overflow-hidden shrink-0 border border-white/15 shadow-xl group-hover:scale-105 transition-transform duration-300">
                      <CoverImage
                        url={room.bookCover}
                        title={room.bookTitle}
                        author={room.bookAuthor}
                        showShadow={false}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-semibold text-zinc-300">
                          {room.participants.length} miembros
                        </span>
                        {/* Indicador discreto: Estamos leyendo (Requisito 12) */}
                        {readingNow.length > 0 && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-[10px] font-semibold text-emerald-400 flex items-center gap-1 animate-pulse">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            {readingNow[0].name} leyendo
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-white tracking-tight truncate group-hover:text-cyan-300 transition-colors">
                        {room.bookTitle}
                      </h3>
                      <p className="text-xs text-zinc-400 truncate">{room.bookAuthor}</p>

                      <p className="text-[11px] text-zinc-400 mt-2 line-clamp-1">
                        Último mensaje: "{room.messages[room.messages.length - 1]?.text || 'Conversación abierta'}"
                      </p>
                    </div>
                  </div>

                  {/* Participantes individual progress row */}
                  <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-3 space-y-2">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                      Progreso individual
                    </span>
                    <div className="space-y-1.5">
                      {room.participants.slice(0, 3).map((p) => (
                        <div key={p.userId} className="flex items-center justify-between text-xs">
                          <span className="text-zinc-300 truncate max-w-[120px]">
                            {p.name}
                          </span>
                          <div className="flex items-center gap-2 w-36">
                            <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                              <div
                                className={`h-full rounded-full ${
                                  p.userId === 'me' ? 'bg-cyan-400' : 'bg-white'
                                }`}
                                style={{ width: `${p.progress}%` }}
                              />
                            </div>
                            <span className="text-[11px] font-mono text-zinc-400 font-bold w-7 text-right">
                              {p.progress}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bottom bar: enter room */}
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <span className="text-zinc-400 text-[11px]">
                      {room.sharedItems.length} aportaciones compartidas
                    </span>
                    <span className="text-cyan-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      Entrar a la sala <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 2: AMIGOS & SOLICITUDES */}
      {activeSection === 'amigos' && (
        <div className="space-y-6">
          {/* Solicitudes de Amistad (Pendientes) */}
          {requests.length > 0 && (
            <div className="glass-panel rounded-2xl p-5 border border-rose-500/20 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-rose-400" />
                <span>Solicitudes de Amistad ({requests.length})</span>
              </h3>

              <div className="space-y-2">
                {requests.map((req) => (
                  <div
                    key={req.id}
                    className="p-3 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={req.senderAvatar}
                        alt={req.senderName}
                        className="w-10 h-10 rounded-full object-cover border border-white/20"
                      />
                      <div>
                        <h4 className="text-xs font-bold text-white">{req.senderName}</h4>
                        <span className="text-[10px] text-zinc-400">
                          Quiere ser tu amigo de lectura
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleAcceptRequest(req.id)}
                        className="px-3 py-1.5 bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs rounded-lg transition-all"
                      >
                        Aceptar
                      </button>
                      <button
                        onClick={() => handleRejectRequest(req.id)}
                        className="p-1.5 text-zinc-400 hover:text-white rounded-lg transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Search & Add Friend */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                value={searchFriendQuery}
                onChange={(e) => setSearchFriendQuery(e.target.value)}
                placeholder="Buscar entre tus amigos..."
                className="w-full bg-zinc-900/90 border border-white/15 focus:border-white/40 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none"
              />
            </div>

            <form onSubmit={handleAddNewFriend} className="flex items-center gap-2">
              <input
                type="text"
                value={addFriendInput}
                onChange={(e) => setAddFriendInput(e.target.value)}
                placeholder="Nombre de nuevo amigo..."
                className="flex-1 bg-zinc-900/90 border border-white/15 focus:border-white/40 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!addFriendInput.trim()}
                className="px-4 py-2.5 bg-white hover:bg-zinc-200 disabled:opacity-40 text-zinc-950 font-bold text-xs rounded-xl shadow transition-all shrink-0 flex items-center gap-1.5"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Añadir</span>
              </button>
            </form>
          </div>

          {/* Friends Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredFriends.map((friend) => (
              <div
                key={friend.id}
                onClick={() => setSelectedFriend(friend)}
                className="glass-panel-interactive rounded-2xl p-4 border border-white/10 cursor-pointer space-y-3 group"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-12 h-12 rounded-xl object-cover border border-white/20 group-hover:scale-105 transition-transform"
                    />
                    {friend.isReadingNow && (
                      <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-zinc-950" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-white truncate group-hover:text-cyan-300 transition-colors">
                      {friend.name}
                    </h3>
                    <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                      {friend.statusText || friend.bio}
                    </p>
                    {friend.currentBookTitle && (
                      <span className="text-[10px] text-zinc-400 block truncate mt-0.5">
                        📖 {friend.currentBookTitle}
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between text-[11px]">
                  <span className="text-zinc-400">Ver perfil personalizado</span>
                  <ArrowRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 3: ACTIVIDAD DE LAS SALAS */}
      {activeSection === 'actividad' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Muro de Actividad de las Salas
            </h2>
            <span className="text-xs text-zinc-400">Eventos en tiempo real</span>
          </div>

          <div className="space-y-2.5">
            {activities.map((act) => (
              <div
                key={act.id}
                onClick={() => {
                  const targetRoom = rooms.find((r) => r.id === act.roomId) || rooms[0];
                  if (targetRoom) setSelectedRoom(targetRoom);
                }}
                className="glass-panel-interactive rounded-2xl p-3.5 border border-white/10 flex items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  {act.userAvatar ? (
                    <img
                      src={act.userAvatar}
                      alt={act.userName}
                      className="w-9 h-9 rounded-full object-cover border border-white/20 shrink-0"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-zinc-800 border border-white/20 flex items-center justify-center text-xs font-bold text-white shrink-0">
                      {act.userName.charAt(0)}
                    </div>
                  )}

                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors">
                      {act.text}
                    </p>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      En "{act.bookTitle}" · {act.timestamp}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  className="text-xs text-cyan-400 font-semibold shrink-0 group-hover:translate-x-1 transition-transform flex items-center gap-1"
                >
                  <span>Ver sala</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create Room Modal */}
      {isCreateRoomOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <form
            onSubmit={handleCreateRoom}
            className="w-full max-w-lg glass-panel rounded-3xl p-6 border border-white/20 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-white text-base font-['Syne']">
                  Nueva Sala de Lectura
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateRoomOpen(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Select Book */}
            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1.5">
                Selecciona un libro de tu biblioteca *
              </label>
              <select
                value={selectedBookForNewRoom}
                onChange={(e) => setSelectedBookForNewRoom(e.target.value)}
                required
                className="w-full bg-zinc-900 border border-white/15 focus:border-cyan-400 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="">-- Elige un libro --</option>
                {books.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.title} ({b.author})
                  </option>
                ))}
              </select>
            </div>

            {/* Invite Friends Checkboxes */}
            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1.5">
                Invitar amigos a la sala
              </label>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {friends.map((f) => {
                  const isChecked = selectedFriendsForNewRoom.includes(f.id);
                  return (
                    <div
                      key={f.id}
                      onClick={() => {
                        if (isChecked) {
                          setSelectedFriendsForNewRoom(
                            selectedFriendsForNewRoom.filter((id) => id !== f.id)
                          );
                        } else {
                          setSelectedFriendsForNewRoom([...selectedFriendsForNewRoom, f.id]);
                        }
                      }}
                      className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-cyan-500/15 border-cyan-400 text-white'
                          : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <img
                          src={f.avatar}
                          alt={f.name}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="text-xs font-medium">{f.name}</span>
                      </div>
                      <span className="text-xs">{isChecked ? '✓' : ''}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-[11px] text-zinc-400 space-y-1">
              <p>💡 Cada participante conserva su propio progreso y posición.</p>
              <p>No se sincronizan automáticamente las páginas entre usuarios.</p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={() => setIsCreateRoomOpen(false)}
                className="px-4 py-2 text-xs text-zinc-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!selectedBookForNewRoom}
                className="px-5 py-2.5 bg-white hover:bg-zinc-200 disabled:opacity-40 text-zinc-950 font-bold text-xs rounded-xl shadow transition-all"
              >
                Crear sala
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Room Detail Modal */}
      <RoomDetailModal
        room={selectedRoom}
        isOpen={Boolean(selectedRoom)}
        onClose={() => setSelectedRoom(null)}
        allFriends={friends}
        onOpenReaderForBook={(bookId) => {
          const targetBook = books.find((b) => b.id === bookId);
          if (targetBook) onOpenReaderForBook(targetBook);
        }}
        onRoomUpdated={(upd) => {
          setSelectedRoom(upd);
          reloadData();
        }}
      />

      {/* Friend Profile Modal */}
      <FriendProfileModal
        friend={selectedFriend}
        isOpen={Boolean(selectedFriend)}
        onClose={() => setSelectedFriend(null)}
        books={books}
        onOpenBookDetail={onOpenBookDetail}
      />
    </div>
  );
};
