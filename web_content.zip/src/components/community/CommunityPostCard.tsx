import React, { useState } from 'react';
import {
  Heart,
  MessageSquare,
  Bookmark,
  Share2,
  ExternalLink,
  MoreVertical,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Briefcase,
  Building,
  Clock,
  Check
} from 'lucide-react';
import { CommunityPost } from '../../types/community';

interface CommunityPostCardProps {
  post: CommunityPost;
  currentUserId: string;
  isLiked: boolean;
  isSaved: boolean;
  onLike: (postId: string) => void;
  onComment: (post: CommunityPost) => void;
  onSave: (postId: string) => void;
  onShare: (post: CommunityPost) => void;
  onDelete?: (postId: string) => void;
  onReport: (post: CommunityPost) => void;
  onViewAuthor: (authorId: string) => void;
  isAdmin?: boolean;
}

export const CommunityPostCard: React.FC<CommunityPostCardProps> = ({
  post,
  currentUserId,
  isLiked,
  isSaved,
  onLike,
  onComment,
  onSave,
  onShare,
  onDelete,
  onReport,
  onViewAuthor,
  isAdmin = false
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  const isOwnPost = post.authorUid === currentUserId || post.authorId === currentUserId;

  const formatPostTime = (isoString: string) => {
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const minutes = Math.floor(diff / 60000);
      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes}m ago`;
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / 24);
      if (days < 7) return `${days}d ago`;
      return new Date(isoString).toLocaleDateString('en-IN', {
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return 'Recently';
    }
  };

  const handleShareClick = () => {
    onShare(post);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Helper to extract clean domain from link
  const getDomain = (url: string) => {
    try {
      const parsed = new URL(url);
      return parsed.hostname.replace('www.', '');
    } catch {
      return 'Official Portal';
    }
  };

  return (
    <article
      id={`community-post-${post.id}`}
      className="bg-slate-900 border border-slate-800/90 rounded-2xl overflow-hidden shadow-sm hover:border-slate-700/80 transition-all space-y-3 p-4 sm:p-5"
    >
      {/* Author Header */}
      <div className="flex items-start justify-between gap-3">
        <div
          onClick={() => onViewAuthor(post.authorUid || post.authorId || '')}
          className="flex items-start gap-3 cursor-pointer group min-w-0"
        >
          {/* Profile Photo */}
          <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-indigo-600 to-amber-500 p-0.5 shrink-0 overflow-hidden ring-2 ring-slate-800 group-hover:ring-indigo-500 transition-all">
            {post.authorAvatar ? (
              <img
                src={post.authorAvatar}
                alt={post.authorName}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-slate-800 rounded-full flex items-center justify-center text-white font-bold text-sm">
                {post.authorName.charAt(0)}
              </div>
            )}
          </div>

          {/* Name, Headline & Time */}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                {post.authorName}
              </h4>
              {post.authorVerified && (
                <CheckCircle2
                  className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20 shrink-0"
                  title="Verified Aspirant/Contributor"
                />
              )}
            </div>

            <p className="text-xs text-slate-400 truncate leading-tight mt-0.5">
              {post.authorHeadline}
            </p>

            <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatPostTime(post.createdAt)}
              </span>
              {post.authorLocation && (
                <>
                  <span>•</span>
                  <span className="truncate">{post.authorLocation}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Action Menu (Delete if own post, Report) */}
        <div className="relative">
          <button
            id={`btn-post-menu-${post.id}`}
            onClick={() => setShowMenu(!showMenu)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
            title="Options"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-8 w-44 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl py-1.5 z-20 text-xs animate-fadeIn">
              <button
                onClick={() => {
                  setShowMenu(false);
                  onViewAuthor(post.authorId);
                }}
                className="w-full text-left px-3.5 py-2 text-slate-300 hover:bg-slate-800/80 hover:text-white flex items-center gap-2"
              >
                <span>View Author Profile</span>
              </button>

              {isAdmin && onDelete && (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    if (window.confirm('Are you sure you want to delete this post?')) {
                      onDelete(post.id);
                    }
                  }}
                  className="w-full text-left px-3.5 py-2 text-red-400 hover:bg-red-950/40 hover:text-red-300 flex items-center gap-2 font-medium"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Post</span>
                </button>
              )}

              <button
                onClick={() => {
                  setShowMenu(false);
                  onReport(post);
                }}
                className="w-full text-left px-3.5 py-2 text-slate-400 hover:bg-slate-800/80 hover:text-amber-300 flex items-center gap-2"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Report Post</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Content */}
      <div className="space-y-2">
        <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-line break-words">
          {post.content}
        </p>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="text-[11px] font-medium text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                {tag.startsWith('#') ? tag : `#${tag}`}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Post Image Attachment (if present) */}
      {post.imageUrl && (
        <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
          <img
            src={post.imageUrl}
            alt="Community Post Attachment"
            className="w-full max-h-96 object-cover hover:scale-[1.01] transition-transform duration-200"
            loading="lazy"
          />
        </div>
      )}

      {/* Job / Application Link Box (if attached) */}
      {post.jobLink && (
        <a
          href={post.jobLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-3 bg-indigo-950/20 hover:bg-indigo-950/40 border border-indigo-900/40 hover:border-indigo-600/60 rounded-xl transition-all group"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Briefcase className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white group-hover:text-indigo-300 truncate">
                  {post.jobTitle || 'Official Vacancy / Application Link'}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                {post.jobOrganization && (
                  <span className="flex items-center gap-1 truncate text-slate-300">
                    <Building className="w-3 h-3 text-slate-500" />
                    {post.jobOrganization}
                  </span>
                )}
                <span>•</span>
                <span className="text-indigo-400 font-medium truncate">
                  {getDomain(post.jobLink)}
                </span>
              </div>
            </div>
          </div>

          <div className="p-2 text-indigo-400 group-hover:text-white group-hover:translate-x-0.5 transition-all shrink-0">
            <ExternalLink className="w-4 h-4" />
          </div>
        </a>
      )}

      {/* Interaction Counters Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 pt-1 px-1 border-t border-slate-800/60">
        <div className="flex items-center gap-1">
          {post.likesCount > 0 && (
            <span className="flex items-center gap-1">
              <span className="w-4 h-4 rounded-full bg-rose-600/20 text-rose-400 flex items-center justify-center text-[10px]">
                ❤️
              </span>
              <span>{post.likesCount} {post.likesCount === 1 ? 'like' : 'likes'}</span>
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 text-slate-500">
          {post.commentsCount > 0 && (
            <span>{post.commentsCount} {post.commentsCount === 1 ? 'comment' : 'comments'}</span>
          )}
          {post.savesCount > 0 && (
            <span>{post.savesCount} saved</span>
          )}
        </div>
      </div>

      {/* Bottom Actions Bar (Like, Comment, Save, Share) */}
      <div className="grid grid-cols-4 gap-1 pt-1 border-t border-slate-800">
        {/* Like Button */}
        <button
          id={`btn-like-${post.id}`}
          onClick={() => onLike(post.id)}
          className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium transition-all active:scale-95 ${
            isLiked
              ? 'text-rose-400 bg-rose-950/20 font-bold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Heart
            className={`w-4 h-4 transition-transform ${
              isLiked ? 'fill-rose-500 scale-110 text-rose-500' : ''
            }`}
          />
          <span>Like</span>
        </button>

        {/* Comment Button */}
        <button
          id={`btn-comment-${post.id}`}
          onClick={() => onComment(post)}
          className="flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-indigo-300 hover:bg-slate-800/50 transition-all active:scale-95"
        >
          <MessageSquare className="w-4 h-4" />
          <span>Comment</span>
        </button>

        {/* Save Button */}
        <button
          id={`btn-save-post-${post.id}`}
          onClick={() => onSave(post.id)}
          className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium transition-all active:scale-95 ${
            isSaved
              ? 'text-amber-400 bg-amber-950/20 font-bold'
              : 'text-slate-400 hover:text-amber-300 hover:bg-slate-800/50'
          }`}
        >
          <Bookmark
            className={`w-4 h-4 ${isSaved ? 'fill-amber-500 text-amber-500' : ''}`}
          />
          <span>{isSaved ? 'Saved' : 'Save'}</span>
        </button>

        {/* Share Button */}
        <button
          id={`btn-share-post-${post.id}`}
          onClick={handleShareClick}
          className="flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-emerald-300 hover:bg-slate-800/50 transition-all active:scale-95"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400 font-bold">Copied</span>
            </>
          ) : (
            <>
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </>
          )}
        </button>
      </div>
    </article>
  );
};
