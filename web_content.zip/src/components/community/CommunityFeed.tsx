import React, { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Search,
  Sparkles,
  MessageSquare,
  AlertCircle,
  RefreshCw,
  TrendingUp,
  Bookmark,
  Share2,
  FileText,
  SlidersHorizontal,
  Flame,
  UserCheck
} from 'lucide-react';
import {
  CommunityPost,
  PostComment,
  UserProfile,
  PostReport,
  CreatePostInput
} from '../../types/community';
import { CommunityPostCard } from './CommunityPostCard';
import { CreatePostModal } from './CreatePostModal';
import { CommentsDrawer } from './CommentsDrawer';
import { AuthorProfileModal } from './AuthorProfileModal';
import { ReportPostModal } from './ReportPostModal';
import {
  auth,
  uploadCommunityPostImage,
  subscribeToCommunityPosts,
  createCommunityPostInFirestore,
  deleteCommunityPostInFirestore,
  toggleLikeCommunityPostInFirestore,
  toggleSaveCommunityPostInFirestore,
  addCommunityCommentInFirestore,
  deleteCommunityCommentInFirestore,
  subscribeToPostComments,
  submitCommunityPostReport,
  getUserFriendlyErrorMessage,
  isFirestoreUnavailableError,
  isAuthorizedAdminUid
} from '../../lib/firebase';

interface CommunityFeedProps {
  currentUserId: string;
  currentUserEmail?: string;
  onNavigateToJobDetail?: (jobId: string) => void;
  isAdmin?: boolean;
}

type FeedFilter = 'all' | 'saved' | 'notices' | 'strategy' | 'freshers';

export const CommunityFeed: React.FC<CommunityFeedProps> = ({
  currentUserId,
  currentUserEmail,
  onNavigateToJobDetail,
  isAdmin: isAdminProp = false
}) => {
  // Verified Admin check for post authoring permissions
  const [isAdminUser, setIsAdminUser] = useState<boolean>(isAdminProp);

  useEffect(() => {
    let isCancelled = false;
    async function verifyAdminStatus() {
      const activeUser = auth.currentUser;
      if (!activeUser) {
        setIsAdminUser(false);
        return;
      }
      try {
        const authorized = await isAuthorizedAdminUid(activeUser.uid);
        if (!isCancelled) {
          setIsAdminUser(authorized);
        }
      } catch {
        if (!isCancelled) {
          setIsAdminUser(Boolean(isAdminProp));
        }
      }
    }
    verifyAdminStatus();
    return () => {
      isCancelled = true;
    };
  }, [currentUserId, isAdminProp]);
  // Real Firestore posts state (empty array by default, populated via real-time subscription)
  const [posts, setPosts] = useState<CommunityPost[]>([]);

  // Comments map state for real-time discussions
  const [commentsMap, setCommentsMap] = useState<Record<string, PostComment[]>>({});

  // User's liked & saved posts
  const [likedPostIds, setLikedPostIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(`india_job_hub_post_likes_${currentUserId}`);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(`india_job_hub_post_saves_${currentUserId}`);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // UI Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<FeedFilter>('all');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Loading & Error States
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeCommentPost, setActiveCommentPost] = useState<CommunityPost | null>(null);
  const [activeAuthorProfile, setActiveAuthorProfile] = useState<UserProfile | null>(null);
  const [activeReportPost, setActiveReportPost] = useState<CommunityPost | null>(null);

  // Current User Profile for posting
  const currentUserProfile = useMemo<UserProfile>(() => {
    const user = auth.currentUser;
    return {
      id: currentUserId,
      name:
        user?.displayName ||
        (currentUserEmail ? currentUserEmail.split('@')[0].replace('.', ' ') : 'Job Aspirant'),
      avatar: user?.photoURL || undefined,
      headline: 'Competitive Exam Aspirant',
      location: 'All India',
      qualification: 'Graduate Aspirant',
      targetExams: ['Government & Private Exams'],
      bio: 'Active participant in the India Job Hub community.',
      joinedDate: '2025',
      postsCount: posts.filter((p) => p.authorUid === currentUserId || p.authorId === currentUserId).length,
      isVerified: false
    };
  }, [currentUserId, currentUserEmail, posts]);

  // Sync like/save preferences to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        `india_job_hub_post_likes_${currentUserId}`,
        JSON.stringify(likedPostIds)
      );
    } catch (e) {
      console.warn('Local storage write warning', e);
    }
  }, [likedPostIds, currentUserId]);

  useEffect(() => {
    try {
      localStorage.setItem(
        `india_job_hub_post_saves_${currentUserId}`,
        JSON.stringify(savedPostIds)
      );
    } catch (e) {
      console.warn('Local storage write warning', e);
    }
  }, [savedPostIds, currentUserId]);

  // Real-time Cloud Firestore subscription to community_posts collection
  useEffect(() => {
    setIsLoading(true);
    setLoadError(null);

    const unsubscribe = subscribeToCommunityPosts(
      (firestorePosts) => {
        setIsLoading(false);
        setLoadError(null);
        setPosts(firestorePosts || []);
      },
      (err: any) => {
        setIsLoading(false);
        console.warn('Community Firestore sync notice:', err?.code || err?.message || err);
        // If Firestore is temporarily offline or unavailable, keep current posts and allow auto-reconnect
        if (!isFirestoreUnavailableError(err)) {
          setLoadError(getUserFriendlyErrorMessage(err, 'Unable to connect to Community posts. Please check network or retry.'));
        }
      }
    );

    return () => unsubscribe();
  }, []);

  // Real-time comments subscription for the active post
  const activeCommentPostId = activeCommentPost?.id;
  useEffect(() => {
    if (!activeCommentPostId) return;
    const unsub = subscribeToPostComments(
      activeCommentPostId,
      (comments) => {
        setCommentsMap((prev) => ({ ...prev, [activeCommentPostId]: comments }));
      },
      (err) => {
        console.warn('Comments subscription notice:', err);
      }
    );

    return () => unsub();
  }, [activeCommentPostId]);

  // Post creation handler connected to Firebase Auth, Storage, and Firestore
  const handleCreatePost = async (input: CreatePostInput) => {
    if (!isAdminUser) {
      alert('Only verified Administrators can publish community posts.');
      return;
    }

    // 1. Identify active authenticated UID or aspirant user ID
    const authorUid = auth.currentUser?.uid || currentUserId;
    const authorDisplayName =
      auth.currentUser?.displayName ||
      (currentUserEmail ? currentUserEmail.split('@')[0].replace('.', ' ') : 'Job Aspirant');
    const authorAvatar = auth.currentUser?.photoURL || undefined;

    let finalImageUrl = input.imageUrl;

    // 2. Connect post image to Firebase Storage if an image file was provided
    if (input.imageFile) {
      try {
        finalImageUrl = await uploadCommunityPostImage(input.imageFile, authorUid);
      } catch (uploadErr) {
        console.warn('Firebase Storage upload notice, using preview url as fallback:', uploadErr);
        finalImageUrl = input.imageUrl || '';
      }
    }

    // 3. Store post in Firestore community_posts collection
    await createCommunityPostInFirestore({
      authorUid: authorUid,
      authorId: authorUid,
      authorName: authorDisplayName,
      authorAvatar: authorAvatar,
      authorHeadline: 'Competitive Exam Aspirant',
      authorLocation: 'All India',
      authorVerified: false,
      content: input.content,
      imageUrl: finalImageUrl,
      jobLink: input.jobLink,
      jobTitle: input.jobTitle,
      jobOrganization: input.jobOrganization,
      tags: input.tags || []
    });
  };

  const handleDeletePost = async (postId: string) => {
    // Optimistic UI update
    setPosts((prev) => prev.filter((p) => p.id !== postId));

    try {
      await deleteCommunityPostInFirestore(postId);
    } catch (e) {
      console.warn('Firestore delete error:', e);
    }
  };

  const handleToggleLike = async (postId: string) => {
    const isCurrentlyLiked = likedPostIds.includes(postId);
    const nextLiked = !isCurrentlyLiked;

    setLikedPostIds((prev) =>
      nextLiked ? [...prev, postId] : prev.filter((id) => id !== postId)
    );

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const count = nextLiked ? post.likesCount + 1 : Math.max(0, post.likesCount - 1);
          return { ...post, likesCount: count };
        }
        return post;
      })
    );

    try {
      const activeUid = auth.currentUser?.uid || currentUserId;
      await toggleLikeCommunityPostInFirestore(postId, activeUid, isCurrentlyLiked);
    } catch (e) {
      console.warn('Firestore like toggle error:', e);
    }
  };

  const handleToggleSave = async (postId: string) => {
    const isCurrentlySaved = savedPostIds.includes(postId);
    const nextSaved = !isCurrentlySaved;

    setSavedPostIds((prev) =>
      nextSaved ? [...prev, postId] : prev.filter((id) => id !== postId)
    );

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const count = nextSaved ? post.savesCount + 1 : Math.max(0, post.savesCount - 1);
          return { ...post, savesCount: count };
        }
        return post;
      })
    );

    try {
      const activeUid = auth.currentUser?.uid || currentUserId;
      await toggleSaveCommunityPostInFirestore(postId, activeUid, isCurrentlySaved);
    } catch (e) {
      console.warn('Firestore save toggle error:', e);
    }
  };

  const handleAddComment = async (postId: string, content: string) => {
    const activeUid = auth.currentUser?.uid || currentUserId;
    const authorName =
      auth.currentUser?.displayName ||
      (currentUserEmail ? currentUserEmail.split('@')[0].replace('.', ' ') : 'Aspirant');
    const authorAvatar = auth.currentUser?.photoURL || undefined;

    await addCommunityCommentInFirestore(postId, {
      content,
      authorUid: activeUid,
      authorId: activeUid,
      authorName,
      authorAvatar,
      authorHeadline: 'Job Aspirant'
    });
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!activeCommentPost) return;
    const postId = activeCommentPost.id;

    try {
      await deleteCommunityCommentInFirestore(postId, commentId);
    } catch (e) {
      console.warn('Firestore comment delete error:', e);
    }
  };

  const handleSharePost = (post: CommunityPost) => {
    if (navigator.share) {
      navigator
        .share({
          title: `Post by ${post.authorName} on India Job Hub`,
          text: post.content.slice(0, 140) + '...',
          url: post.jobLink || window.location.href
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(
        `"${post.content}" - shared via India Job Hub Community\n${post.jobLink || window.location.href}`
      );
    }
  };

  const handleViewAuthor = (authorId: string) => {
    const authorPost = posts.find((p) => p.authorUid === authorId || p.authorId === authorId);
    const authorPostsCount = posts.filter(
      (p) => p.authorUid === authorId || p.authorId === authorId
    ).length;

    const dynamicProfile: UserProfile = {
      id: authorId,
      name: authorPost?.authorName || 'Community Aspirant',
      avatar: authorPost?.authorAvatar,
      headline: authorPost?.authorHeadline || 'Competitive Exam Aspirant',
      location: authorPost?.authorLocation || 'India',
      qualification: 'Competitive Exam Aspirant',
      targetExams: ['Government & Private Jobs'],
      bio: 'Active participant in the India Job Hub community.',
      joinedDate: '2025',
      postsCount: authorPostsCount,
      isVerified: authorPost?.authorVerified || false
    };

    setActiveAuthorProfile(dynamicProfile);
  };

  const handleSubmitReport = async (report: PostReport) => {
    try {
      await submitCommunityPostReport(report);
    } catch (e) {
      console.warn('Report post write error:', e);
    }
  };

  // Filter & Search Logic
  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesContent = post.content.toLowerCase().includes(q);
        const matchesAuthor = post.authorName.toLowerCase().includes(q);
        const matchesOrg = post.jobOrganization?.toLowerCase().includes(q);
        const matchesTitle = post.jobTitle?.toLowerCase().includes(q);
        const matchesTags = post.tags?.some((t) => t.toLowerCase().includes(q));
        if (!matchesContent && !matchesAuthor && !matchesOrg && !matchesTitle && !matchesTags) {
          return false;
        }
      }

      // Tag filter
      if (selectedTag) {
        if (!post.tags?.some((t) => t.toLowerCase() === selectedTag.toLowerCase())) {
          return false;
        }
      }

      // Active tab filter
      if (activeFilter === 'saved') {
        return (
          savedPostIds.includes(post.id) ||
          (currentUserId && post.savedBy?.includes(currentUserId))
        );
      }
      if (activeFilter === 'notices') {
        return Boolean(
          post.jobLink ||
            post.tags?.some((t) => t.toLowerCase().includes('notice') || t.toLowerCase().includes('naukri'))
        );
      }
      if (activeFilter === 'strategy') {
        return post.tags?.some(
          (t) =>
            t.toLowerCase().includes('strategy') ||
            t.toLowerCase().includes('aptitude') ||
            t.toLowerCase().includes('prep')
        );
      }
      if (activeFilter === 'freshers') {
        return post.tags?.some(
          (t) =>
            t.toLowerCase().includes('fresher') ||
            t.toLowerCase().includes('private') ||
            t.toLowerCase().includes('tech')
        );
      }

      return true;
    });
  }, [posts, searchQuery, activeFilter, selectedTag, savedPostIds, currentUserId]);

  return (
    <div id="community-feed-screen" className="flex-1 flex flex-col bg-slate-950 pb-20">
      {/* Top Professional Community Banner */}
      <div className="bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border-b border-slate-800/80 px-4 py-3.5 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5 leading-tight">
                <span>Aspirant & Career Community</span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-semibold px-1.5 py-0.2 rounded border border-indigo-500/30">
                  Network
                </span>
              </h2>
              <p className="text-[11px] text-slate-400 leading-none mt-0.5">
                Verified recruitment updates, exam strategies, and career mentorship
              </p>
            </div>
          </div>

          {isAdminUser && (
            <button
              id="btn-open-create-post-header"
              onClick={() => setIsCreateModalOpen(true)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-1.5 shrink-0 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Post</span>
              <span className="sm:hidden">Post</span>
            </button>
          )}
        </div>

        {/* Quick Compose Trigger Box - Visible ONLY to verified Administrators */}
        {isAdminUser && (
          <div
            onClick={() => setIsCreateModalOpen(true)}
            className="bg-slate-950/70 hover:bg-slate-800/50 border border-slate-800 rounded-2xl p-3 flex items-center gap-3 cursor-pointer transition-all group"
          >
            <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300 overflow-hidden shrink-0 ring-1 ring-slate-700">
              {currentUserProfile.avatar ? (
                <img
                  src={currentUserProfile.avatar}
                  alt="My Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                currentUserProfile.name.charAt(0)
              )}
            </div>
            <div className="flex-1 text-xs text-slate-400 group-hover:text-slate-200 transition-colors">
              Share exam advice, official vacancy links, or ask a career query...
            </div>
            <span className="text-xs font-semibold text-indigo-400 group-hover:underline">
              Share
            </span>
          </div>
        )}

        {/* Search & Topic Filters */}
        <div className="space-y-2">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              id="input-community-search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search posts, topics (#SarkariNaukri), organizations (UPSC, RRB)..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-xs text-slate-500 hover:text-slate-300"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            <button
              onClick={() => {
                setActiveFilter('all');
                setSelectedTag(null);
              }}
              className={`px-3 py-1 rounded-full whitespace-nowrap border transition-all ${
                activeFilter === 'all' && !selectedTag
                  ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              All Posts
            </button>

            <button
              onClick={() => setActiveFilter('notices')}
              className={`px-3 py-1 rounded-full whitespace-nowrap border transition-all flex items-center gap-1 ${
                activeFilter === 'notices'
                  ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3 h-3" />
              <span>Official Notices</span>
            </button>

            <button
              onClick={() => setActiveFilter('strategy')}
              className={`px-3 py-1 rounded-full whitespace-nowrap border transition-all flex items-center gap-1 ${
                activeFilter === 'strategy'
                  ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span>Exam Prep & Strategy</span>
            </button>

            <button
              onClick={() => setActiveFilter('freshers')}
              className={`px-3 py-1 rounded-full whitespace-nowrap border transition-all flex items-center gap-1 ${
                activeFilter === 'freshers'
                  ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <Flame className="w-3 h-3" />
              <span>Off-Campus & Tech</span>
            </button>

            <button
              onClick={() => setActiveFilter('saved')}
              className={`px-3 py-1 rounded-full whitespace-nowrap border transition-all flex items-center gap-1 ${
                activeFilter === 'saved'
                  ? 'bg-amber-600 text-white border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <Bookmark className="w-3 h-3" />
              <span>Saved ({savedPostIds.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Posts Stream Content */}
      <div className="flex-1 max-w-2xl w-full mx-auto p-3 sm:p-4 space-y-4">
        {/* Loading State Shimmer */}
        {isLoading && (
          <div className="space-y-4 animate-pulse">
            {[1, 2].map((i) => (
              <div key={i} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-800" />
                  <div className="space-y-1.5 flex-1">
                    <div className="h-3.5 bg-slate-800 rounded w-1/3" />
                    <div className="h-2.5 bg-slate-800 rounded w-1/2" />
                  </div>
                </div>
                <div className="h-16 bg-slate-800/60 rounded" />
                <div className="h-8 bg-slate-800/40 rounded" />
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {loadError && (
          <div className="p-4 bg-red-950/40 border border-red-900/60 rounded-2xl flex items-center justify-between text-xs text-red-300">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <span>{loadError}</span>
            </div>
            <button
              onClick={() => {
                setLoadError(null);
                setIsLoading(true);
                setTimeout(() => setIsLoading(false), 800);
              }}
              className="px-2.5 py-1 bg-red-900/60 hover:bg-red-800 text-white rounded-lg transition-colors flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && filteredPosts.length === 0 && (
          <div className="py-16 text-center space-y-3 px-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-indigo-400">
              <MessageSquare className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-white">No discussions found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {searchQuery
                ? `No posts matching "${searchQuery}". Try different keywords or clear filters.`
                : activeFilter === 'saved'
                ? 'You haven’t saved any community posts yet. Click the Save button on any post to bookmark it here!'
                : isAdminUser
                ? 'Be the first admin to share an exam notice, preparation resource, or vacancy link!'
                : 'No announcements or updates posted yet. Check back soon!'}
            </p>
            {isAdminUser ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveFilter('all');
                  setSelectedTag(null);
                  setIsCreateModalOpen(true);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-colors"
              >
                Publish First Post
              </button>
            ) : (
              (searchQuery || activeFilter !== 'all' || selectedTag) && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveFilter('all');
                    setSelectedTag(null);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs transition-colors"
                >
                  Clear Filters
                </button>
              )
            )}
          </div>
        )}

        {/* Posts List */}
        {!isLoading &&
          filteredPosts.map((post) => (
            <CommunityPostCard
              key={post.id}
              post={post}
              currentUserId={currentUserId}
              isAdmin={isAdminUser}
              isLiked={likedPostIds.includes(post.id)}
              isSaved={savedPostIds.includes(post.id)}
              onLike={handleToggleLike}
              onComment={(p) => setActiveCommentPost(p)}
              onSave={handleToggleSave}
              onShare={handleSharePost}
              onDelete={handleDeletePost}
              onReport={(p) => setActiveReportPost(p)}
              onViewAuthor={handleViewAuthor}
            />
          ))}
      </div>

      {/* Floating Action Button for Mobile - Only for verified Admins */}
      {isAdminUser && (
        <button
          id="btn-fab-create-post"
          onClick={() => setIsCreateModalOpen(true)}
          className="fixed right-4 bottom-20 z-20 sm:hidden w-13 h-13 p-3.5 bg-gradient-to-tr from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white rounded-full shadow-2xl shadow-indigo-950 flex items-center justify-center active:scale-95 transition-transform"
          title="Create Post"
          aria-label="Create Post"
        >
          <Plus className="w-6 h-6" />
        </button>
      )}

      {/* Create Post Screen / Modal - Only for verified Admins */}
      {isAdminUser && (
        <CreatePostModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onSubmit={handleCreatePost}
          currentUserProfile={currentUserProfile}
        />
      )}

      {/* Comments Drawer */}
      <CommentsDrawer
        isOpen={Boolean(activeCommentPost)}
        postId={activeCommentPost?.id || ''}
        postTitle={activeCommentPost?.jobTitle}
        comments={activeCommentPost ? commentsMap[activeCommentPost.id] || [] : []}
        currentUserId={currentUserId}
        currentUserProfile={currentUserProfile}
        onClose={() => setActiveCommentPost(null)}
        onAddComment={handleAddComment}
        onDeleteComment={handleDeleteComment}
      />

      {/* Author Profile View Modal */}
      <AuthorProfileModal
        isOpen={Boolean(activeAuthorProfile)}
        profile={activeAuthorProfile}
        posts={posts}
        onClose={() => setActiveAuthorProfile(null)}
        onSelectPost={(post) => {
          setActiveAuthorProfile(null);
          // Scroll or focus post if needed
        }}
      />

      {/* Report Post Modal */}
      <ReportPostModal
        post={activeReportPost}
        isOpen={Boolean(activeReportPost)}
        onClose={() => setActiveReportPost(null)}
        onSubmitReport={handleSubmitReport}
        currentUserId={currentUserId}
      />
    </div>
  );
};
