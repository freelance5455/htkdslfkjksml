import React from 'react';
import {
  X,
  MapPin,
  GraduationCap,
  Target,
  Calendar,
  CheckCircle2,
  FileText,
  Briefcase
} from 'lucide-react';
import { UserProfile, CommunityPost } from '../../types/community';

interface AuthorProfileModalProps {
  isOpen: boolean;
  profile: UserProfile | null;
  posts: CommunityPost[];
  onClose: () => void;
  onSelectPost?: (post: CommunityPost) => void;
}

export const AuthorProfileModal: React.FC<AuthorProfileModalProps> = ({
  isOpen,
  profile,
  posts,
  onClose,
  onSelectPost
}) => {
  if (!isOpen || !profile) return null;

  const authorPosts = posts.filter((p) => p.authorUid === profile.id || p.authorId === profile.id);

  return (
    <div
      id="author-profile-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4 animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Banner with tricolor accent */}
        <div className="relative h-24 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-900 border-b border-slate-800 shrink-0">
          <div className="absolute top-0 inset-x-0 h-1 flex">
            <div className="h-full flex-1 bg-amber-500" />
            <div className="h-full flex-1 bg-white" />
            <div className="h-full flex-1 bg-emerald-500" />
          </div>

          <button
            id="btn-close-author-profile"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white rounded-full transition-colors z-10"
            title="Close profile"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Content */}
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
          {/* Avatar & Name Header */}
          <div className="relative -mt-12 flex items-end gap-3.5">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-amber-500 p-0.5 shadow-xl ring-4 ring-slate-900 shrink-0 overflow-hidden">
              {profile.avatar ? (
                <img
                  src={profile.avatar}
                  alt={profile.name}
                  className="w-full h-full object-cover rounded-2xl"
                />
              ) : (
                <div className="w-full h-full bg-slate-800 flex items-center justify-center text-white text-2xl font-bold">
                  {profile.name.charAt(0)}
                </div>
              )}
            </div>

            <div className="min-w-0 pb-1">
              <h2 className="text-lg font-bold text-white flex items-center gap-1.5 truncate">
                <span>{profile.name}</span>
                {profile.isVerified && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20 shrink-0" />
                )}
              </h2>
              <p className="text-xs text-indigo-300 line-clamp-2 leading-tight mt-0.5">
                {profile.headline}
              </p>
            </div>
          </div>

          {/* Quick Details Badges */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-400 pt-1">
            {profile.location && (
              <span className="flex items-center gap-1 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                {profile.location}
              </span>
            )}
            {profile.joinedDate && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Joined {profile.joinedDate}
              </span>
            )}
            <span className="flex items-center gap-1 text-indigo-400 font-medium">
              <FileText className="w-3.5 h-3.5" />
              {authorPosts.length} Community Posts
            </span>
          </div>

          {/* Bio Section */}
          {profile.bio && (
            <div className="p-3.5 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">About Aspirant</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{profile.bio}</p>
            </div>
          )}

          {/* Qualification & Target Exams */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {profile.qualification && (
              <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-400" /> Qualification
                </span>
                <p className="text-xs font-medium text-slate-200 truncate">
                  {profile.qualification}
                </p>
              </div>
            )}

            {profile.targetExams && profile.targetExams.length > 0 && (
              <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                  <Target className="w-3.5 h-3.5 text-emerald-400" /> Target Exams / Focus
                </span>
                <div className="flex flex-wrap gap-1">
                  {profile.targetExams.map((exam) => (
                    <span
                      key={exam}
                      className="text-[10px] bg-emerald-950/50 border border-emerald-800/50 text-emerald-300 px-1.5 py-0.5 rounded"
                    >
                      {exam}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Author's Posts Section */}
          <div className="space-y-2.5 pt-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-indigo-400" /> Recent Posts by {profile.name}
            </h3>

            {authorPosts.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-2">No other public posts found.</p>
            ) : (
              <div className="space-y-2">
                {authorPosts.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      if (onSelectPost) onSelectPost(p);
                      onClose();
                    }}
                    className="p-3 bg-slate-950/60 hover:bg-slate-800/60 border border-slate-800 rounded-xl cursor-pointer transition-colors space-y-1.5"
                  >
                    <p className="text-xs text-slate-200 line-clamp-2 leading-snug">
                      {p.content}
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{new Date(p.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      <span className="text-indigo-400 font-medium">
                        {p.likesCount} Likes • {p.commentsCount} Comments
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
