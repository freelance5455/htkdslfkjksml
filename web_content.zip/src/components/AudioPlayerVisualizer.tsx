import React, { useEffect, useRef, useState } from 'react';
import { 
  Play, 
  Pause, 
  Square, 
  RotateCcw, 
  Download, 
  Share2, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Wifi, 
  WifiOff, 
  FileAudio,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import { EngineMode, ExportFormat, CloudStorageProvider } from '../types/tts';
import { downloadBlob } from '../utils/audioEncoder';
import { Cloud, HardDrive, Box } from 'lucide-react';

interface AudioPlayerVisualizerProps {
  isPlaying: boolean;
  isSynthesizing: boolean;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  onReplay: () => void;
  onSynthesizeAndPlay: () => void;
  audioBlob: Blob | null;
  audioUrl: string | null;
  duration: number;
  engineMode: EngineMode;
  onExport: (format: ExportFormat) => void;
  onOpenShare: () => void;
  languageName: string;
  personaName: string;
  onSaveToCloud?: (provider: CloudStorageProvider, format: ExportFormat) => void;
  isSavingToCloud?: boolean;
  onCancelSynthesis?: () => void;
  onOpenCloudModal?: () => void;
}

export const AudioPlayerVisualizer: React.FC<AudioPlayerVisualizerProps> = ({
  isPlaying,
  isSynthesizing,
  onPlay,
  onPause,
  onStop,
  onReplay,
  onSynthesizeAndPlay,
  audioBlob,
  audioUrl,
  duration,
  engineMode,
  onExport,
  onOpenShare,
  languageName,
  personaName,
  onSaveToCloud,
  isSavingToCloud = false,
  onCancelSynthesis,
  onOpenCloudModal,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showCloudMenu, setShowCloudMenu] = useState(false);
  const animationFrameRef = useRef<number | null>(null);

  // Audio element for cloud / decoded blob playback
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }
    const audio = audioRef.current;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const handleEnded = () => {
      setCurrentTime(0);
      onStop();
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [onStop]);

  // Sync audio source when audioUrl updates
  useEffect(() => {
    if (audioRef.current && audioUrl) {
      audioRef.current.src = audioUrl;
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [audioUrl, isMuted, volume]);

  // Handle play/pause with HTML audio when audioUrl is present
  useEffect(() => {
    if (audioRef.current && audioUrl) {
      if (isPlaying) {
        audioRef.current.play().catch(() => {});
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, audioUrl]);

  // Real-time canvas visualizer animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const numBars = 36;
      const barWidth = Math.max(2, Math.floor(width / numBars) - 2);

      // Draw background glow wave
      ctx.beginPath();
      ctx.strokeStyle = isPlaying ? 'rgba(139, 92, 246, 0.4)' : 'rgba(113, 113, 122, 0.15)';
      ctx.lineWidth = 2;

      for (let i = 0; i < width; i += 4) {
        const amp = isPlaying ? Math.sin(i * 0.05 + phase) * (height * 0.25) : 0;
        const y = height / 2 + amp;
        if (i === 0) ctx.moveTo(i, y);
        else ctx.lineTo(i, y);
      }
      ctx.stroke();

      // Draw dynamic frequency bars
      for (let i = 0; i < numBars; i++) {
        const x = i * (barWidth + 2);
        let barHeight = 4;

        if (isPlaying) {
          // Dynamic harmonic height
          const v = Math.sin(phase * 2 + i * 0.35) * Math.cos(phase * 1.5 + i * 0.2);
          barHeight = Math.max(4, Math.abs(v) * (height * 0.75));
        } else if (isSynthesizing) {
          barHeight = 8 + Math.sin(phase * 3 + i * 0.5) * 6;
        }

        const y = (height - barHeight) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isPlaying) {
          grad.addColorStop(0, '#8b5cf6'); // violet-500
          grad.addColorStop(0.5, '#6366f1'); // indigo-500
          grad.addColorStop(1, '#06b6d4'); // cyan-500
        } else if (isSynthesizing) {
          grad.addColorStop(0, '#f59e0b');
          grad.addColorStop(1, '#ec4899');
        } else {
          grad.addColorStop(0, '#71717a');
          grad.addColorStop(1, '#3f3f46');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, 2);
        ctx.fill();
      }

      if (isPlaying || isSynthesizing) {
        phase += 0.08;
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, isSynthesizing]);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    setCurrentTime(targetTime);
    if (audioRef.current && audioUrl) {
      audioRef.current.currentTime = targetTime;
    }
  };

  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-xl overflow-hidden p-4 sm:p-5 space-y-4">
      {/* Top player header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-violet-600/10 dark:bg-violet-500/20 flex items-center justify-center text-violet-600 dark:text-violet-400">
            <FileAudio className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
              <span>{personaName}</span>
              <span className="text-xs font-normal text-zinc-400">· {languageName}</span>
            </h3>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  engineMode === 'neural'
                    ? 'bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20'
                    : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                }`}
              >
                {engineMode === 'neural' ? (
                  <>
                    <Wifi className="w-3 h-3" /> SK Neural AI Cloud
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3 h-3" /> 100% Offline Engine
                  </>
                )}
              </span>
              {duration > 0 && (
                <span className="text-[11px] text-zinc-500 font-mono">
                  {formatTime(duration)}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Primary Synthesize / Play Button */}
        <div className="w-full sm:w-auto flex items-center gap-2">
          <button
            onClick={onSynthesizeAndPlay}
            disabled={isSynthesizing}
            className={`w-full sm:w-auto px-5 py-3 rounded-2xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer touch-press ${
              isSynthesizing
                ? 'bg-zinc-300 dark:bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 hover:from-violet-500 hover:via-indigo-500 hover:to-cyan-500 text-white shadow-violet-600/25 active:scale-95'
            }`}
          >
            <Sparkles className={`w-4 h-4 ${isSynthesizing ? 'animate-spin' : ''}`} />
            <span>{isSynthesizing ? 'Synthesizing...' : 'Generate & Play Voice'}</span>
          </button>

          {isSynthesizing && onCancelSynthesis && (
            <button
              onClick={onCancelSynthesis}
              className="px-3.5 py-3 rounded-2xl font-bold text-xs bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 transition-all cursor-pointer shrink-0"
              title="Cancel and switch to instant offline synthesis"
            >
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* Visualizer Canvas */}
      <div className="h-16 w-full bg-zinc-950 rounded-xl overflow-hidden relative border border-zinc-800/80 shadow-inner flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={640}
          height={64}
          className="w-full h-full object-cover"
        />
        {isSynthesizing && (
          <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-xs flex flex-col sm:flex-row items-center justify-center gap-2 text-violet-300 text-xs font-semibold animate-pulse px-3 text-center">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-violet-400 animate-spin" />
              <span>Synthesizing voice...</span>
            </div>
            {onCancelSynthesis && (
              <button
                onClick={onCancelSynthesis}
                className="text-[11px] font-bold text-amber-400 hover:text-amber-300 underline underline-offset-2 ml-1 cursor-pointer"
              >
                Use Instant Offline Playback
              </button>
            )}
          </div>
        )}
      </div>

      {/* Playback Controls & Timeline Slider */}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-zinc-500 w-10 text-right">
            {formatTime(currentTime)}
          </span>

          <input
            type="range"
            min="0"
            max={duration > 0 ? duration : 10}
            step="0.1"
            value={currentTime}
            onChange={handleSeek}
            disabled={duration <= 0}
            className="flex-1 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-violet-600"
          />

          <span className="text-xs font-mono text-zinc-500 w-10">
            {formatTime(duration)}
          </span>
        </div>

        {/* Bottom Toolbar: Play/Pause/Stop, Volume, Export, Share */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Audio Transport Controls */}
          <div className="flex items-center gap-1.5">
            {isPlaying ? (
              <button
                onClick={onPause}
                className="w-9 h-9 rounded-xl bg-violet-600 text-white flex items-center justify-center hover:bg-violet-500 transition-all shadow-md shadow-violet-600/30"
                title="Pause"
              >
                <Pause className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={onPlay}
                disabled={isSynthesizing}
                className="w-9 h-9 rounded-xl bg-violet-600 text-white flex items-center justify-center hover:bg-violet-500 transition-all shadow-md shadow-violet-600/30 disabled:opacity-50"
                title="Play"
              >
                <Play className="w-4 h-4 ml-0.5" />
              </button>
            )}

            <button
              onClick={onStop}
              className="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white flex items-center justify-center hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all"
              title="Stop"
            >
              <Square className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onReplay}
              className="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white flex items-center justify-center hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all"
              title="Replay from start"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            {/* Volume control */}
            <div className="flex items-center gap-1.5 pl-2 ml-1 border-l border-zinc-200 dark:border-zinc-800">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  setVolume(parseFloat(e.target.value));
                  setIsMuted(false);
                }}
                className="w-16 h-1 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-violet-600 hidden sm:block"
              />
            </div>
          </div>

          {/* Export & Social Share Buttons */}
          <div className="grid grid-cols-3 sm:flex items-center gap-1.5 w-full sm:w-auto">
            
            {/* Save to Cloud / Cloud Storage Box */}
            {(onSaveToCloud || onOpenCloudModal) && (
              <div className="relative">
                <button
                  onClick={() => {
                    if (onOpenCloudModal) {
                      onOpenCloudModal();
                    } else {
                      setShowCloudMenu(!showCloudMenu);
                    }
                  }}
                  disabled={isSavingToCloud}
                  className="w-full flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl text-xs font-semibold bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer touch-press"
                  title="Open Cloud Storage Box (Google Drive Sync)"
                >
                  <Cloud className="w-3.5 h-3.5 text-cyan-500 shrink-0" />
                  <span className="truncate">{isSavingToCloud ? 'Saving...' : 'Cloud'}</span>
                </button>

                {showCloudMenu && (
                  <div className="absolute right-0 bottom-full mb-2 w-56 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-200 dark:border-zinc-800 p-1.5 z-50 animate-in fade-in zoom-in-95">
                    <div className="text-[10px] uppercase font-bold text-zinc-400 px-2 py-1">
                      Save Directly to Cloud Storage
                    </div>

                    <button
                      onClick={() => {
                        onSaveToCloud?.('google-drive', 'mp3');
                        setShowCloudMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg text-xs hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-zinc-800 dark:text-zinc-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-emerald-500" />
                        <div>
                          <div className="font-bold">Google Drive</div>
                          <div className="text-[10px] text-zinc-400">/SK Text to Speech/Audio</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-600 font-bold px-1.5 py-0.5 rounded">
                        .mp3
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        onSaveToCloud?.('dropbox', 'mp3');
                        setShowCloudMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg text-xs hover:bg-blue-50 dark:hover:bg-blue-950/40 text-zinc-800 dark:text-zinc-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Box className="w-4 h-4 text-blue-500" />
                        <div>
                          <div className="font-bold">Dropbox</div>
                          <div className="text-[10px] text-zinc-400">/Apps/SK_TTS_Exports</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-blue-500/10 text-blue-600 font-bold px-1.5 py-0.5 rounded">
                        .mp3
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        onSaveToCloud?.('onedrive', 'mp3');
                        setShowCloudMenu(false);
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg text-xs hover:bg-sky-50 dark:hover:bg-sky-950/40 text-zinc-800 dark:text-zinc-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Cloud className="w-4 h-4 text-sky-500" />
                        <div>
                          <div className="font-bold">Microsoft OneDrive</div>
                          <div className="text-[10px] text-zinc-400">/Documents/SK_TTS_Audio</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-sky-500/10 text-sky-600 font-bold px-1.5 py-0.5 rounded">
                        .mp3
                      </span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Export Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="w-full flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl text-xs font-semibold bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 transition-all touch-press cursor-pointer"
                title="Export audio file"
              >
                <Download className="w-3.5 h-3.5 text-violet-500 shrink-0" />
                <span className="truncate">Export</span>
                {showExportMenu ? <ChevronUp className="w-3 h-3 shrink-0" /> : <ChevronDown className="w-3 h-3 shrink-0" />}
              </button>

              {showExportMenu && (
                <div className="absolute right-0 bottom-full mb-2 w-48 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-200 dark:border-zinc-800 p-1.5 z-50 animate-in fade-in zoom-in-95">
                  <div className="text-[10px] uppercase font-bold text-zinc-400 px-2 py-1">
                    Select Audio Format
                  </div>
                  
                  <button
                    onClick={() => {
                      onExport('wav');
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg text-xs hover:bg-violet-50 dark:hover:bg-violet-950/40 text-zinc-800 dark:text-zinc-200 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold">Lossless WAV (.wav)</div>
                      <div className="text-[10px] text-zinc-400">24kHz / 16-bit uncompressed</div>
                    </div>
                    <span className="text-[10px] bg-violet-500/10 text-violet-500 font-bold px-1.5 py-0.5 rounded">
                      Studio
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      onExport('mp3');
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg text-xs hover:bg-violet-50 dark:hover:bg-violet-950/40 text-zinc-800 dark:text-zinc-200 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold">Standard MP3 (.mp3)</div>
                      <div className="text-[10px] text-zinc-400">192 kbps universal playback</div>
                    </div>
                    <span className="text-[10px] bg-cyan-500/10 text-cyan-500 font-bold px-1.5 py-0.5 rounded">
                      Compact
                    </span>
                  </button>
                </div>
              )}
            </div>

            {/* Social Share Button */}
            <button
              onClick={onOpenShare}
              className="w-full flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-violet-600/10 to-indigo-600/10 hover:from-violet-600/20 hover:to-indigo-600/20 text-violet-700 dark:text-violet-300 border border-violet-500/30 transition-all touch-press cursor-pointer"
              title="Share synthesized speech to social media"
            >
              <Share2 className="w-3.5 h-3.5 text-violet-500 shrink-0" />
              <span className="truncate">Share</span>
            </button>

          </div>
        </div>
      </div>
    </div>
  );
};
