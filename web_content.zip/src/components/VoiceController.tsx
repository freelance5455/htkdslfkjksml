import React from 'react';
import { Mic, AlertCircle, Key } from 'lucide-react';
import { SessionState } from '../types';

interface VoiceControllerProps {
  sessionState: SessionState;
  onToggleSession: () => void;
  volumeLevel: number;
  errorMessage?: string | null;
  hasSavedKey: boolean;
  onOpenSettings: () => void;
}

export const VoiceController: React.FC<VoiceControllerProps> = ({
  sessionState,
  onToggleSession,
  volumeLevel,
  errorMessage,
  hasSavedKey,
  onOpenSettings,
}) => {
  const isConnected = sessionState === 'LISTENING' || sessionState === 'SPEAKING';
  const isConnecting = sessionState === 'CONNECTING';
  const isSpeaking = sessionState === 'SPEAKING';
  const isListening = sessionState === 'LISTENING';

  // Multi-bar soundwave heights
  const bars = [0.35, 0.65, 0.95, 0.5, 0.8, 1.0, 0.75, 0.45, 0.85, 0.6, 0.35];

  return (
    <div className="w-full flex flex-col items-center justify-center space-y-3 px-4 select-none pb-4 shrink-0">
      {/* API Key Gate Alert Message if error or key missing */}
      {errorMessage && (
        <div className="w-full max-w-xs px-3.5 py-1.5 rounded-xl bg-purple-950/70 border border-purple-500/40 text-purple-200 text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2 truncate">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 text-pink-400" />
            <span className="truncate">{errorMessage}</span>
          </div>
          {!hasSavedKey && (
            <button
              onClick={onOpenSettings}
              className="ml-2 px-2 py-0.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[10px] shrink-0 active:scale-95"
            >
              Settings
            </button>
          )}
        </div>
      )}

      {/* Main Start / Mic Glowing Button */}
      <div className="relative flex items-center justify-center my-1">
        {/* Ambient background glow */}
        <div
          className={`absolute w-32 h-32 rounded-full transition-all duration-700 blur-xl ${
            isSpeaking
              ? 'bg-gradient-to-r from-purple-500/60 via-pink-500/60 to-cyan-500/60 scale-125'
              : isListening
              ? 'bg-gradient-to-r from-blue-500/40 via-purple-500/40 to-cyan-400/40 scale-110'
              : 'bg-purple-600/30 scale-95'
          }`}
        />

        {/* Concentric pulsing outer rings */}
        <div
          className={`absolute w-24 h-24 rounded-full border border-purple-400/30 pointer-events-none transition-all duration-500 ${
            isConnected ? 'animate-ping opacity-30' : 'opacity-0'
          }`}
        />

        <div className="relative rounded-full bg-gradient-to-tr from-purple-600 via-pink-500 to-cyan-400 p-[2px] shadow-2xl">
          <button
            onClick={onToggleSession}
            disabled={isConnecting}
            className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-300 active:scale-90 ${
              isConnecting
                ? 'bg-[#121830] opacity-80 cursor-wait'
                : isSpeaking
                ? 'bg-gradient-to-br from-pink-600 to-purple-800 text-white shadow-[0_0_30px_rgba(236,72,153,0.7)]'
                : isListening
                ? 'bg-gradient-to-br from-purple-600 to-indigo-900 text-white shadow-[0_0_30px_rgba(139,92,246,0.6)]'
                : 'bg-gradient-to-br from-purple-700 via-indigo-900 to-[#0d1224] text-purple-200 hover:text-white hover:scale-105'
            }`}
          >
            {isConnecting ? (
              <div className="w-6 h-6 border-2 border-purple-300 border-t-transparent rounded-full animate-spin" />
            ) : isConnected ? (
              <Mic className="w-7 h-7 animate-pulse text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
            ) : (
              <Mic className="w-7 h-7 text-purple-200" />
            )}
          </button>
        </div>
      </div>

      {/* Audio Waveform Visualization */}
      <div className="flex items-center justify-center space-x-1 h-6 px-4">
        {isConnected ? (
          bars.map((heightMultiplier, idx) => {
            const activeScale = isSpeaking
              ? Math.max(0.2, Math.min(1.2, heightMultiplier * (0.4 + volumeLevel * 2.5)))
              : isListening
              ? Math.max(0.15, Math.min(1, heightMultiplier * (0.3 + volumeLevel * 1.8)))
              : 0.15;

            return (
              <span
                key={idx}
                className={`w-1 rounded-full transition-all duration-75 ${
                  isSpeaking
                    ? 'bg-gradient-to-t from-purple-400 to-pink-400 shadow-[0_0_8px_rgba(236,72,153,0.6)]'
                    : 'bg-gradient-to-t from-cyan-400 to-blue-400 shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                }`}
                style={{
                  height: `${Math.round(activeScale * 22)}px`,
                  minHeight: '4px',
                }}
              />
            );
          })
        ) : (
          <span className="text-[11px] text-slate-400 font-medium tracking-wide">
            {hasSavedKey ? 'Tap Start to talk with AI' : 'Save API key in Settings to activate'}
          </span>
        )}
      </div>

      {/* State Status Indicator Text */}
      <div className="flex items-center space-x-1.5">
        {isConnected && (
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isSpeaking ? 'bg-pink-400 animate-ping' : 'bg-emerald-400 animate-pulse'
            }`}
          />
        )}
        <span className="text-xs font-semibold tracking-wide text-slate-200">
          {sessionState === 'DISCONNECTED' && 'Tap to Start'}
          {sessionState === 'CONNECTING' && 'Connecting...'}
          {sessionState === 'LISTENING' && 'Listening...'}
          {sessionState === 'SPEAKING' && 'Speaking...'}
          {sessionState === 'ANALYZING' && 'Analyzing...'}
          {sessionState === 'ERROR' && 'Tap to Reconnect'}
        </span>
      </div>
    </div>
  );
};
