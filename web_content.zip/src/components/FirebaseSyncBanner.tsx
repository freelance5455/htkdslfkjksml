import React, { useState, useEffect } from 'react';
import { auth, signInWithGoogle, logOut, db, handleFirestoreError, OperationType } from '../firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { StorageService } from '../db/storage';
import { Cloud, CheckCircle2, LogIn, LogOut, User, RefreshCw, ShieldCheck } from 'lucide-react';

interface FirebaseSyncBannerProps {
  lang: 'bn' | 'en';
}

export const FirebaseSyncBanner: React.FC<FirebaseSyncBannerProps> = ({ lang }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      if (currentUser) {
        syncToFirestore(currentUser);
      }
    });
    return () => unsubscribe();
  }, []);

  const syncToFirestore = async (activeUser: FirebaseUser) => {
    setSyncing(true);
    try {
      const profile = StorageService.getBusinessProfile();
      const products = StorageService.getProducts();
      const customers = StorageService.getCustomers();
      const invoices = StorageService.getInvoices();

      // Sync user profile & metadata
      const userRef = doc(db, 'users', activeUser.uid);
      await setDoc(
        userRef,
        {
          uid: activeUser.uid,
          email: activeUser.email || '',
          displayName: activeUser.displayName || '',
          photoURL: activeUser.photoURL || '',
          businessName: profile?.businessName || '',
          ownerName: profile?.ownerName || '',
          phone: profile?.phone || '',
          address: profile?.address || '',
          lastSyncedAt: new Date().toISOString(),
          totalProductsCount: products.length,
          totalCustomersCount: customers.length,
          totalInvoicesCount: invoices.length,
        },
        { merge: true }
      );

      setLastSynced(new Date().toLocaleTimeString());
      setSyncing(false);
    } catch (err) {
      console.warn('Firestore sync notice:', err);
      setSyncing(false);
    }
  };

  const handleSignIn = async () => {
    try {
      setLoading(true);
      const signedInUser = await signInWithGoogle();
      if (signedInUser) {
        setUser(signedInUser);
      }
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logOut();
      setUser(null);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white px-4 py-2.5 shadow-sm text-xs print:hidden">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left Status */}
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
            <Cloud className="w-3.5 h-3.5 text-blue-300" />
          </div>
          <div>
            {user ? (
              <div className="flex items-center gap-2">
                <span className="font-semibold text-emerald-300 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  {lang === 'bn' ? 'Firebase সিঙ্ক সংযুক্ত:' : 'Firebase Synced:'}
                </span>
                <span className="text-white font-medium">{user.displayName || user.email}</span>
                {lastSynced && (
                  <span className="text-slate-400 text-[10px] hidden sm:inline">
                    (সর্বশেষ সিঙ্ক: {lastSynced})
                  </span>
                )}
              </div>
            ) : (
              <span className="text-slate-300 font-medium">
                {lang === 'bn'
                  ? 'গুগল একাউন্ট দিয়ে লগইন করুন এবং ফায়ারবেস ক্লাউডে ব্যাকআপ রাখুন'
                  : 'Sign in with Google to sync with Firebase Cloud Database'}
              </span>
            )}
          </div>
        </div>

        {/* Right Action */}
        <div className="flex items-center gap-2">
          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => syncToFirestore(user)}
                disabled={syncing}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                title="Sync Now"
              >
                <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
                <span>{syncing ? (lang === 'bn' ? 'সিঙ্ক হচ্ছে...' : 'Syncing...') : (lang === 'bn' ? 'সিঙ্ক' : 'Sync')}</span>
              </button>
              <button
                onClick={handleSignOut}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-red-500/30 text-red-200 hover:text-white font-semibold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <LogOut className="w-3 h-3" />
                <span>{lang === 'bn' ? 'লগআউট' : 'Sign Out'}</span>
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={loading}
              className="px-3 py-1.5 rounded-xl bg-white text-slate-900 hover:bg-blue-50 font-bold flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 transition-all"
            >
              <LogIn className="w-3.5 h-3.5 text-blue-600" />
              <span>{lang === 'bn' ? 'Google সাইন-ইন' : 'Google Sign In'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
