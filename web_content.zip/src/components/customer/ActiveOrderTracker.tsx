import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Phone,
  MessageSquare,
  ShieldAlert,
  Clock,
  CheckCircle2,
  MapPin,
  Star,
  AlertOctagon,
  XCircle,
  Truck,
  RotateCcw
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';

interface ActiveOrderTrackerProps {
  order: Order;
  onBack: () => void;
  onOpenChat: (sessionId: string) => void;
}

export const ActiveOrderTracker: React.FC<ActiveOrderTrackerProps> = ({
  order,
  onBack,
  onOpenChat
}) => {
  const {
    updateOrderStatus,
    cancelOrder,
    rateOrder,
    setIsSosOpen,
    chatSessions,
    deliveryPartners
  } = useApp();

  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('Change of plans');
  const [ratingVal, setRatingVal] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [hasRated, setHasRated] = useState(false);

  // Find linked chat session
  const linkedChat = chatSessions.find(s => s.orderId === order.id) || chatSessions[0];

  const steps: { status: OrderStatus; label: string; desc: string }[] = [
    { status: 'placed', label: 'Placed', desc: 'Order sent to partner' },
    { status: 'accepted', label: 'Confirmed', desc: 'Partner accepted booking' },
    { status: 'assigned', label: 'Dispatched', desc: 'Partner moving towards location' },
    { status: 'out_for_delivery', label: 'On The Way', desc: 'Arriving at your doorstep' },
    { status: 'completed', label: 'Completed', desc: 'Job successfully finished' }
  ];

  const getStepIndex = (currentStatus: OrderStatus) => {
    switch (currentStatus) {
      case 'placed':
        return 0;
      case 'accepted':
      case 'preparing':
        return 1;
      case 'assigned':
        return 2;
      case 'out_for_delivery':
      case 'in_progress':
        return 3;
      case 'completed':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIdx = getStepIndex(order.status);
  const isCancelled = order.status === 'cancelled' || order.status === 'refunded';

  const handleCancelSubmit = async () => {
    await cancelOrder(order.id, cancelReason);
    setCancelModalOpen(false);
  };

  const handleRateSubmit = async () => {
    await rateOrder(order.id, ratingVal, reviewText);
    setHasRated(true);
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-black text-slate-900">Live Status • #{order.orderNumber}</h2>
            <p className="text-[11px] text-slate-500 font-semibold capitalize">
              {order.category.replace('_', ' ')}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSosOpen(true)}
          className="px-2.5 py-1 rounded-full bg-red-50 text-red-600 border border-red-200 text-xs font-bold flex items-center gap-1 hover:bg-red-100"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>SOS</span>
        </button>
      </div>

      {/* Hero ETA Card */}
      {!isCancelled ? (
        <div className="m-4 p-4 bg-gradient-to-tr from-slate-900 to-slate-800 text-white rounded-3xl shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 block">
                {order.status === 'completed' ? 'Order Finished' : 'Estimated Arrival'}
              </span>
              <h3 className="text-2xl font-black text-white mt-0.5">
                {order.status === 'completed' ? 'Delivered' : order.eta || '15 mins'}
              </h3>
            </div>
            {order.deliveryOtp && order.status !== 'completed' && (
              <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-right">
                <span className="text-[9px] uppercase font-black text-amber-400 block">
                  Delivery PIN
                </span>
                <span className="text-lg font-black text-amber-400 tracking-widest">
                  {order.deliveryOtp}
                </span>
              </div>
            )}
          </div>

          {/* Step Timeline */}
          <div className="mt-5 pt-3 border-t border-slate-700/60">
            <div className="flex items-center justify-between relative">
              <div className="absolute top-2.5 left-2 right-2 h-0.5 bg-slate-700 -z-0" />
              <div
                className="absolute top-2.5 left-2 h-0.5 bg-amber-500 transition-all duration-500 -z-0"
                style={{ width: `${(currentStepIdx / 4) * 95}%` }}
              />

              {steps.map((s, idx) => {
                const isPassed = idx <= currentStepIdx;
                return (
                  <div key={s.status} className="flex flex-col items-center relative z-10">
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-all ${
                        isPassed
                          ? 'bg-amber-500 text-slate-950 border-amber-400 scale-110 shadow-md'
                          : 'bg-slate-800 text-slate-500 border-slate-600'
                      }`}
                    >
                      {isPassed ? '✓' : idx + 1}
                    </div>
                    <span
                      className={`text-[9px] mt-1 font-bold ${
                        isPassed ? 'text-amber-300' : 'text-slate-500'
                      }`}
                    >
                      {s.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="m-4 p-4 bg-rose-50 border border-rose-200 text-rose-900 rounded-3xl">
          <div className="flex items-center gap-2 font-bold text-sm">
            <XCircle className="w-5 h-5 text-rose-600" />
            <span>Order Cancelled</span>
          </div>
          <p className="text-xs text-rose-700 mt-1">
            Reason: {order.cancelReason || 'Cancelled by customer'}
          </p>
          {order.refundAmount && order.refundAmount > 0 ? (
            <div className="mt-2 p-2 rounded-xl bg-white text-xs font-bold text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
              <RotateCcw className="w-4 h-4 text-emerald-600" />
              <span>₹{order.refundAmount} refunded to your AllJi Wallet.</span>
            </div>
          ) : null}
        </div>
      )}

      {/* Partner / Provider Contact Card */}
      {!isCancelled && (
        <div className="mx-4 p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-base">
              {order.deliveryPartnerName ? '🛵' : '👨‍🔧'}
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                {order.deliveryPartnerName ? 'Delivery Partner' : 'Service Specialist'}
              </span>
              <h4 className="text-xs font-black text-slate-900">
                {order.deliveryPartnerName || order.providerName || 'AllJi Verified Pro'}
              </h4>
              <p className="text-[11px] text-slate-500">
                {order.deliveryPartnerPhone || '+91 98711 00223'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Call */}
            <a
              href={`tel:${order.deliveryPartnerPhone || '+919876543210'}`}
              className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center transition-colors"
              title="Call Partner"
            >
              <Phone className="w-4 h-4 text-emerald-600" />
            </a>

            {/* In-App Chat */}
            {linkedChat && (
              <button
                id="open-in-app-chat-btn"
                onClick={() => onOpenChat(linkedChat.id)}
                className="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-sm transition-all"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Simulated Live Route Map */}
      {!isCancelled && order.status !== 'completed' && (
        <div className="mx-4 mt-3 rounded-2xl bg-slate-900 h-40 border border-slate-800 relative overflow-hidden flex items-center justify-center shadow-inner">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#33415510_1px,transparent_1px),linear-gradient(to_bottom,#33415510_1px,transparent_1px)] bg-[size:20px_20px]" />
          
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 380 160">
            <path
              d="M 50 120 Q 120 30 200 90 T 320 50"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="4"
              strokeDasharray="6,4"
            />
          </svg>

          <div className="absolute left-8 bottom-4 flex flex-col items-center">
            <span className="text-[8px] bg-slate-800 text-white px-1.5 py-0.5 rounded-md font-bold mb-0.5">
              Pickup
            </span>
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-md" />
          </div>

          <div className="absolute left-[190px] top-[70px] -translate-x-1/2 -translate-y-1/2 p-2 rounded-full bg-amber-500 text-slate-950 border-2 border-white shadow-xl animate-bounce">
            <Truck className="w-4 h-4" />
          </div>

          <div className="absolute right-8 top-6 flex flex-col items-center">
            <span className="text-[8px] bg-slate-800 text-white px-1.5 py-0.5 rounded-md font-bold mb-0.5">
              You
            </span>
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-md" />
          </div>

          <div className="absolute bottom-2 px-3 py-1 rounded-full bg-slate-950/80 backdrop-blur-md text-[10px] text-slate-300 font-semibold border border-slate-800">
            Live GPS Tracking Active • High Precision
          </div>
        </div>
      )}

      {/* Order Item Details */}
      <div className="p-4 space-y-2.5">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
          Booking Summary
        </h4>
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
          {order.items.map((i, idx) => (
            <div key={idx} className="flex justify-between font-semibold text-slate-800">
              <span>
                {i.quantity}x {i.title}
              </span>
              <span>₹{i.price * i.quantity}</span>
            </div>
          ))}

          <div className="pt-2 border-t border-slate-100 flex justify-between font-black text-slate-900 text-sm">
            <span>Grand Total</span>
            <span>₹{order.grandTotal}</span>
          </div>
          <div className="flex justify-between text-[11px] text-slate-500">
            <span>Payment</span>
            <span className="uppercase font-bold text-amber-700">
              {order.paymentMethod} ({order.paymentStatus})
            </span>
          </div>
        </div>
      </div>

      {/* Order Actions: Cancel / Quick advance demo buttons */}
      <div className="px-4 space-y-2">
        {!isCancelled && order.status !== 'completed' && (
          <>
            <button
              onClick={() => setCancelModalOpen(true)}
              className="w-full py-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 font-bold text-xs transition-colors"
            >
              Cancel Order & Instant Refund
            </button>

            {/* Quick Demo Status Advancer */}
            <div className="p-2.5 bg-slate-100 rounded-2xl flex items-center justify-between text-[11px]">
              <span className="text-slate-500 font-bold">Simulator:</span>
              <div className="flex gap-1">
                {order.status !== 'completed' && (
                  <button
                    onClick={() => updateOrderStatus(order.id, 'completed')}
                    className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700"
                  >
                    Mark Delivered
                  </button>
                )}
              </div>
            </div>
          </>
        )}

        {/* Rating and Review for Completed Order */}
        {order.status === 'completed' && !hasRated && !order.rating && (
          <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-2.5">
            <h4 className="text-xs font-black text-amber-950">How was your service?</h4>
            <div className="flex items-center gap-1 text-amber-500">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  onClick={() => setRatingVal(star)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`w-6 h-6 ${
                      star <= ratingVal ? 'fill-amber-500 text-amber-500' : 'text-slate-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <input
              type="text"
              placeholder="Write a review for the worker/rider..."
              value={reviewText}
              onChange={e => setReviewText(e.target.value)}
              className="w-full p-2 bg-white text-xs rounded-xl border border-slate-200"
            />
            <button
              onClick={handleRateSubmit}
              className="px-4 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl"
            >
              Submit Rating & Review
            </button>
          </div>
        )}

        {order.rating && (
          <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center gap-2 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-semibold text-slate-700">
              You rated this {order.rating} ⭐ {order.reviewComment ? `("${order.reviewComment}")` : ''}
            </span>
          </div>
        )}
      </div>

      {/* Cancel Order Modal */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3">
            <h3 className="text-sm font-black text-slate-900">Cancel Order #{order.orderNumber}</h3>
            <p className="text-xs text-slate-500">
              Orders paid online will receive a 100% instant refund directly to your AllJi Wallet.
            </p>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Reason for cancellation:
              </label>
              <select
                value={cancelReason}
                onChange={e => setCancelReason(e.target.value)}
                className="w-full p-2 text-xs rounded-xl border border-slate-200 bg-white"
              >
                <option value="Change of plans">Change of plans</option>
                <option value="Ordered by mistake">Ordered by mistake</option>
                <option value="Delayed delivery partner">Delayed delivery partner</option>
                <option value="Found better alternative">Found better alternative</option>
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setCancelModalOpen(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Keep Order
              </button>
              <button
                onClick={handleCancelSubmit}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs"
              >
                Confirm Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
