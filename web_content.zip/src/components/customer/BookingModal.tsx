import React, { useState } from 'react';
import { ProviderProfile } from '../../types';
import { useMohalla } from '../../context/MohallaContext';
import {
  X,
  Calendar,
  Clock,
  Camera,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { formatCurrencyPKR } from '../../utils/geo';

interface BookingModalProps {
  provider: ProviderProfile;
  isEmergency?: boolean;
  onClose: () => void;
  onSuccess: (bookingId: string) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  provider,
  isEmergency = false,
  onClose,
  onSuccess,
}) => {
  const { currentUser, selectedArea, createBooking, language } = useMohalla();

  const [description, setDescription] = useState('');
  const [preferredTime, setPreferredTime] = useState(
    isEmergency ? 'Immediate Emergency (Within 20 mins)' : 'As Soon As Possible (Today)'
  );
  const [address, setAddress] = useState(`House 12B, Street 4, ${selectedArea.name}, Karachi`);
  const [phone, setPhone] = useState(currentUser.phone);
  const [photos, setPhotos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Quick problem symptom suggestions based on category
  const suggestedProblems: { [key: string]: string[] } = {
    electrician: ['Short circuit & breaker tripping', 'Fan speed regulator broken', 'Ceiling light wiring fault', 'UPS inverter not charging'],
    plumber: ['Main pipeline leakage', 'Bathroom mixer faucet broken', 'Water tank overflow', 'Motor pump stopped pumping'],
    ac_technician: ['AC blowing room temperature air', 'Water dripping inside room', 'Gas leak & compressor noise', 'Chemical wash service'],
    car_mechanic: ['Car won’t start / Battery dead', 'Brakes squeaking & vibrating', 'Engine overheating smoke', 'Puncture & flat tire'],
  };

  const currentSuggestions = suggestedProblems[provider.category] || [
    'Emergency fixing needed',
    'Routine maintenance service',
    'Inspection and repair quote',
  ];

  const handleAddSamplePhoto = () => {
    // Simulated photo upload
    const samplePhotos = [
      'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=600&auto=format&fit=crop&q=80',
    ];
    setPhotos([...photos, samplePhotos[photos.length % samplePhotos.length]]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      alert('Please describe the problem so the technician brings the correct tools.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const newBooking = createBooking({
        customerId: currentUser.id,
        customerName: currentUser.name,
        customerPhone: phone,
        providerId: provider.id,
        providerName: provider.businessName,
        providerPhone: '0321-9456781',
        providerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        categoryId: provider.category,
        categoryName: provider.category.replace('_', ' ').toUpperCase(),
        problemDescription: description,
        photos,
        preferredTime,
        isEmergency,
        visitFee: provider.visitCharge + (isEmergency ? 250 : 0),
        paymentMethod: 'cash',
        paymentStatus: 'pending',
        location: {
          area: selectedArea.name,
          city: 'Karachi',
          address,
          lat: selectedArea.lat,
          lng: selectedArea.lng,
        },
      });

      setIsSubmitting(false);
      onSuccess(newBooking.id);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-base sm:text-lg">
                {isEmergency ? '🚨 Emergency Booking Request' : 'Book Local Service'}
              </h3>
              {isEmergency && (
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                  Priority Dispatch
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Requesting {provider.businessName}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200/80 text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {/* Provider snapshot */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200/70 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-700 text-white font-bold flex items-center justify-center text-sm">
                {provider.businessName.charAt(0)}
              </div>
              <div>
                <span className="font-bold text-slate-900 block">{provider.businessName}</span>
                <span className="text-emerald-700 flex items-center gap-1 font-semibold">
                  <ShieldCheck className="w-3 h-3" />
                  {provider.verificationBadge}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Visit Fee</span>
              <span className="font-extrabold text-slate-900 text-sm">
                {formatCurrencyPKR(provider.visitCharge + (isEmergency ? 250 : 0))}
              </span>
            </div>
          </div>

          {/* Problem Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Describe the Problem or Work Needed <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Master bedroom switch board has burnt smell, tripping the main DB breaker..."
              className="w-full p-3 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-xs sm:text-sm text-slate-800 outline-hidden placeholder:text-slate-400"
            />

            {/* Quick chips */}
            <div className="mt-2 flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-slate-400 font-medium">Quick suggestions:</span>
              {currentSuggestions.map((sugg, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => setDescription(sugg)}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
                >
                  + {sugg}
                </button>
              ))}
            </div>
          </div>

          {/* Time Preference */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              Preferred Time Slot
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                'Immediate (Available Now)',
                'Today Evening (6PM - 8PM)',
                'Tomorrow Morning (10AM - 1PM)',
                'Tomorrow Evening (5PM - 8PM)',
              ].map((slot, i) => (
                <button
                  type="button"
                  key={i}
                  onClick={() => setPreferredTime(slot)}
                  className={`p-2.5 rounded-xl border text-left font-medium transition-colors cursor-pointer ${
                    preferredTime === slot
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>
          </div>

          {/* Address & Contact */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                Service Address ({selectedArea.name}, Karachi)
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 text-xs text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Your Contact Phone (for arrival coordination)
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0300-XXXXXXX"
                className="w-full p-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 text-xs text-slate-800 font-mono"
              />
            </div>
          </div>

          {/* Photo attachment simulation */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Camera className="w-3.5 h-3.5 text-slate-500" />
                Attach Fault Photos (Optional)
              </span>
              <button
                type="button"
                onClick={handleAddSamplePhoto}
                className="text-emerald-700 hover:text-emerald-800 text-[11px] font-bold cursor-pointer"
              >
                + Add Photo
              </button>
            </label>

            {photos.length > 0 ? (
              <div className="flex gap-2 overflow-x-auto py-1">
                {photos.map((src, i) => (
                  <div key={i} className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
                    <img src={src} alt="Fault photo" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotos(photos.filter((_, idx) => idx !== i))}
                      className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/60 text-white flex items-center justify-center text-[10px]"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-slate-400">
                Helps the technician bring the right spare parts before leaving.
              </p>
            )}
          </div>

          {/* Payment disclaimer */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2">
            <DollarSign className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-900">Payment: Cash on Completion</span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Pay the visit charge directly to the technician only after he arrives and inspects the job.
              </p>
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-2 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer hover:scale-[1.02] active:scale-95 disabled:opacity-50"
            >
              {isSubmitting
                ? 'Sending Request...'
                : isEmergency
                ? 'Send Emergency Dispatch'
                : 'Confirm Booking Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
