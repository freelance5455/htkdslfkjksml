import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Smartphone,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  User,
  MessageSquare,
  Lock,
  Zap,
  Truck,
  Award,
} from 'lucide-react';
import { CustomerUser } from '../../types';
import { DEMO_CUSTOMERS } from '../../data/mockData';
import { Logo } from '../common/Logo';

interface CustomerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: CustomerUser) => void;
  initialPhone?: string;
}

export const CustomerLoginModal: React.FC<CustomerLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialPhone = '',
}) => {
  // Step: 'PHONE' or 'OTP'
  const [step, setStep] = useState<'PHONE' | 'OTP'>('PHONE');

  // Phone input
  const [phone, setPhone] = useState<string>(initialPhone.replace(/\D/g, '').slice(-10) || '9876543210');
  const [phoneError, setPhoneError] = useState<string | null>(null);

  // New user name input if phone is unrecognized
  const [userName, setUserName] = useState<string>('');

  // OTP inputs (4 digits)
  const [otp, setOtp] = useState<string[]>(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState<string>('4829');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [resendTimer, setResendTimer] = useState<number>(30);
  const [showSimulatedSms, setShowSimulatedSms] = useState<boolean>(false);

  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Reset or initialize when modal opens
  useEffect(() => {
    if (isOpen) {
      setStep('PHONE');
      setOtp(['', '', '', '']);
      setOtpError(null);
      setPhoneError(null);
      setShowSimulatedSms(false);
      setIsVerifying(false);
      if (initialPhone) {
        setPhone(initialPhone.replace(/\D/g, '').slice(-10));
      }
    }
  }, [isOpen, initialPhone]);

  // Resend OTP countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 'OTP' && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, resendTimer]);

  if (!isOpen) return null;

  // Handle phone submission -> generate OTP
  const handleSendOtp = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanPhone = phone.trim().replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setPhoneError('Please enter a valid 10-digit mobile number');
      return;
    }

    setPhoneError(null);
    // Generate realistic 4-digit OTP (e.g. 4829 or random)
    const newOtp = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(newOtp);
    setStep('OTP');
    setResendTimer(30);
    setOtp(['', '', '', '']);
    setOtpError(null);

    // Auto-fill existing name if in DEMO_CUSTOMERS
    const existing = DEMO_CUSTOMERS.find((c) => c.phone.replace(/\D/g, '') === cleanPhone);
    if (existing) {
      setUserName(existing.name);
    } else if (!userName) {
      setUserName('New Customer');
    }

    // Trigger simulated SMS banner after a short delay
    setTimeout(() => {
      setShowSimulatedSms(true);
    }, 600);

    // Focus first OTP field
    setTimeout(() => {
      otpInputRefs.current[0]?.focus();
    }, 300);
  };

  // Handle OTP digit change with auto-advance
  const handleOtpChange = (index: number, value: string) => {
    const digit = value.replace(/\D/g, '').slice(-1);
    const newOtp = [...otp];
    newOtp[index] = digit;
    setOtp(newOtp);
    setOtpError(null);

    if (digit && index < 3) {
      otpInputRefs.current[index + 1]?.focus();
    }

    // Auto submit if all 4 entered
    if (digit && index === 3 && newOtp.every((d) => d !== '')) {
      verifyOtpCode(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handlePasteOtp = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
    if (pasted.length > 0) {
      const newOtp = ['', '', '', ''];
      for (let i = 0; i < pasted.length; i++) {
        newOtp[i] = pasted[i];
      }
      setOtp(newOtp);
      if (pasted.length === 4) {
        verifyOtpCode(pasted);
      } else {
        otpInputRefs.current[pasted.length]?.focus();
      }
    }
  };

  // Auto-fill OTP helper button
  const handleAutoFillOtp = () => {
    const digits = generatedOtp.split('');
    setOtp(digits);
    verifyOtpCode(generatedOtp);
  };

  // Verify code
  const verifyOtpCode = (enteredCode: string) => {
    setIsVerifying(true);
    setOtpError(null);

    setTimeout(() => {
      // Demo allows generated OTP or '1234' or '0000'
      if (enteredCode === generatedOtp || enteredCode === '1234' || enteredCode === '0000') {
        const cleanPhone = phone.trim().replace(/\D/g, '');
        const existing = DEMO_CUSTOMERS.find((c) => c.phone.replace(/\D/g, '') === cleanPhone);

        const authenticatedUser: CustomerUser = {
          id: existing?.id || `cust_${cleanPhone.slice(-6)}`,
          name: existing?.name || (userName.trim() || `Customer (${cleanPhone.slice(-4)})`),
          phone: `+91 ${cleanPhone.slice(0, 5)} ${cleanPhone.slice(5)}`,
          email: existing?.email || `user.${cleanPhone.slice(-4)}@pcmart.in`,
          isLoggedIn: true,
          avatar:
            existing?.avatar ||
            'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
          joinedDate: existing?.joinedDate || new Date().toISOString().split('T')[0],
        };

        setIsVerifying(false);
        onLoginSuccess(authenticatedUser);
        onClose();
      } else {
        setIsVerifying(false);
        setOtpError(`Invalid OTP. Please enter ${generatedOtp} (or try 1234).`);
      }
    }, 500);
  };

  // Select demo phone chip
  const selectDemoProfile = (demo: CustomerUser) => {
    setPhone(demo.phone.replace(/\D/g, ''));
    setUserName(demo.name);
    setPhoneError(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative flex flex-col">
        {/* Top Header Banner with Brand Style */}
        <div className="bg-gradient-to-r from-[#1746A2] via-[#10347a] to-slate-900 p-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 bg-black/30 hover:bg-black/50 text-white rounded-full transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <Logo size="sm" showTagline={false} variant="horizontal" />
            <span className="text-[10px] bg-[#FFD447] text-slate-950 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
              Customer Login
            </span>
          </div>

          <h3 className="text-base font-black text-white">
            {step === 'PHONE' ? 'Sign in with Mobile Number' : 'Verify Mobile OTP'}
          </h3>
          <p className="text-xs text-blue-100/80 mt-0.5">
            {step === 'PHONE'
              ? 'Get instant access to orders, wishlist & verified buyer reviews'
              : `Enter the 4-digit code sent to +91 ${phone}`}
          </p>
        </div>

        {/* Simulated Push Notification Banner */}
        {showSimulatedSms && step === 'OTP' && (
          <div className="mx-4 mt-3 p-3 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-500/50 rounded-2xl shadow-lg flex items-start gap-2.5 animate-slideDown">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> SMS • PCMART OTP
                </span>
                <span className="text-[10px] text-slate-400">Just now</span>
              </div>
              <p className="text-slate-200 text-[11px] mt-0.5 leading-tight">
                Your login OTP is <strong className="text-amber-400 text-sm font-black tracking-widest">{generatedOtp}</strong>. Valid for 10 minutes.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAutoFillOtp}
                  className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-lg text-[10px] flex items-center gap-1 shadow transition-all active:scale-95"
                >
                  <Zap className="w-3 h-3 fill-current" /> Auto-fill {generatedOtp}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {step === 'PHONE' ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              {/* Quick Profile Selection Chips */}
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Fast Demo Logins (Click to autofill)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {DEMO_CUSTOMERS.slice(0, 2).map((demo) => (
                    <button
                      key={demo.id}
                      type="button"
                      onClick={() => selectDemoProfile(demo)}
                      className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                        phone === demo.phone.replace(/\D/g, '')
                          ? 'border-[#FFD447] bg-[#FFD447]/10 text-white'
                          : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <img src={demo.avatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
                      <div className="truncate">
                        <span className="text-xs font-bold block truncate">{demo.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">+91 {demo.phone.slice(-10)}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Mobile Number Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-white block">
                  Enter 10-digit Mobile Number
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden focus-within:border-[#FFD447] transition-all shadow-inner">
                  {/* Indian Country Code */}
                  <div className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-900 border-r border-slate-800 text-xs font-bold text-slate-200 shrink-0">
                    <span className="text-sm">🇮🇳</span>
                    <span>+91</span>
                  </div>

                  <input
                    type="tel"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      setPhone(val);
                      if (val.length === 10) setPhoneError(null);
                    }}
                    placeholder="98765 43210"
                    className="flex-1 bg-transparent px-3 py-2.5 text-sm text-white font-mono tracking-wider placeholder:text-slate-600 focus:outline-none"
                    autoFocus
                  />
                  {phone.length === 10 && (
                    <div className="pr-3 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                </div>
                {phoneError && <p className="text-[11px] text-red-400">{phoneError}</p>}
              </div>

              {/* Optional Name (Pre-filled or Editable) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">
                  Customer Name <span className="text-slate-500 font-normal">(Display Name on Orders)</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-2xl px-3 py-2 text-xs focus-within:border-[#FFD447]">
                  <User className="w-4 h-4 text-slate-500 mr-2 shrink-0" />
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="E.g., Karan Sharma"
                    className="w-full bg-transparent text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Trust & E-commerce Highlights */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 space-y-2 text-[11px] text-slate-400">
                <div className="flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-[#FFD447] shrink-0" />
                  <span>1-Click SMS OTP Verification (No password required)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  <span>Track BlueDart / Delhivery shipments in real-time</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Post Verified Customer Reviews after delivery</span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={phone.length !== 10}
                className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all active:scale-98 flex items-center justify-center gap-1.5"
              >
                <span>Get OTP on Mobile</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <div className="space-y-4">
              {/* Phone Display and Change */}
              <div className="flex items-center justify-between p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">OTP sent via SMS to</span>
                  <span className="text-white font-bold font-mono">+91 {phone}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setStep('PHONE')}
                  className="text-xs font-bold text-[#FFD447] hover:underline"
                >
                  Change
                </button>
              </div>

              {/* 4-Box OTP Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-white block text-center">
                  Enter 4-Digit Verification Code
                </label>
                <div className="flex justify-center gap-3">
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={(el) => {
                        otpInputRefs.current[idx] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(idx, e)}
                      onPaste={handlePasteOtp}
                      className={`w-12 h-14 bg-slate-950 border-2 rounded-2xl text-center text-xl font-bold font-mono text-white focus:outline-none transition-all shadow-inner ${
                        digit
                          ? 'border-[#FFD447] shadow-[0_0_12px_rgba(255,212,71,0.25)]'
                          : 'border-slate-800 focus:border-blue-500'
                      }`}
                    />
                  ))}
                </div>
                {otpError && <p className="text-xs text-red-400 text-center font-medium">{otpError}</p>}
              </div>

              {/* Resend and Auto-fill helper row */}
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>
                  Didn't receive code?{' '}
                  {resendTimer > 0 ? (
                    <span className="text-slate-500 font-mono font-bold">Resend in {resendTimer}s</span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendOtp()}
                      className="text-[#FFD447] font-bold hover:underline"
                    >
                      Resend SMS OTP
                    </button>
                  )}
                </span>
                <button
                  type="button"
                  onClick={handleAutoFillOtp}
                  className="text-emerald-400 font-bold hover:underline flex items-center gap-1"
                >
                  <Zap className="w-3 h-3" /> Auto-fill {generatedOtp}
                </button>
              </div>

              {/* Verify Button */}
              <button
                type="button"
                onClick={() => verifyOtpCode(otp.join(''))}
                disabled={otp.some((d) => d === '') || isVerifying}
                className="w-full py-3 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 disabled:opacity-50 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all active:scale-98 flex items-center justify-center gap-1.5"
              >
                {isVerifying ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Verifying OTP...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" /> Verify & Continue
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-950 border-t border-slate-800/80 text-center text-[10px] text-slate-500">
          By continuing, you agree to PCMART's Terms of Use and Privacy Policy.
        </div>
      </div>
    </div>
  );
};
