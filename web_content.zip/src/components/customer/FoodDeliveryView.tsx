import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ServiceItem } from '../../types';
import {
  ArrowLeft,
  Star,
  Plus,
  Minus,
  Check,
  Clock,
  Flame,
  Filter,
  CheckCircle2
} from 'lucide-react';

interface FoodDeliveryViewProps {
  onBack: () => void;
  onOpenCart: () => void;
}

export const FoodDeliveryView: React.FC<FoodDeliveryViewProps> = ({ onBack, onOpenCart }) => {
  const { services, addToCart, cart, updateCartQuantity, providers } = useApp();
  const [filterVegOnly, setFilterVegOnly] = useState(false);
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<ServiceItem | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});

  const foodServices = services.filter(s => s.categoryId === 'food');
  const filteredList = filterVegOnly ? foodServices.filter(s => s.isVeg) : foodServices;

  const restaurant = providers.find(p => p.category === 'food') || {
    businessName: 'Royal Dawat Biryani & Kebabs',
    rating: 4.8,
    reviewCount: 1420,
    serviceRadiusKm: 10
  };

  const getCartQuantity = (id: string) => {
    const item = cart.find(i => i.service.id === id);
    return item ? item.quantity : 0;
  };

  const handleOpenCustomize = (service: ServiceItem) => {
    if (service.options && service.options.length > 0) {
      setSelectedServiceForModal(service);
      const defaults: Record<string, string> = {};
      service.options.forEach(opt => {
        defaults[opt.name] = opt.choices[0].label;
      });
      setSelectedOptions(defaults);
    } else {
      addToCart(service);
    }
  };

  const handleConfirmCustomize = () => {
    if (!selectedServiceForModal) return;
    const optList = Object.entries(selectedOptions).map(([k, v]) => `${k}: ${v}`);
    addToCart(selectedServiceForModal, optList);
    setSelectedServiceForModal(null);
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-bold text-slate-900">{restaurant.businessName}</h2>
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <span className="flex items-center text-amber-500 font-bold">
                <Star className="w-3 h-3 fill-amber-400 mr-0.5" />
                {restaurant.rating}
              </span>
              <span>•</span>
              <span>25-35 Mins Delivery</span>
            </div>
          </div>
        </div>

        {/* Veg Toggle */}
        <button
          onClick={() => setFilterVegOnly(!filterVegOnly)}
          className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1 border transition-all ${
            filterVegOnly
              ? 'bg-emerald-600 text-white border-emerald-600'
              : 'bg-slate-100 text-slate-600 border-slate-200'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Pure Veg</span>
        </button>
      </div>

      {/* Hero Banner */}
      <div className="relative h-36 bg-slate-900 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80"
          alt="Food Banner"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-4 flex flex-col justify-end">
          <span className="px-2 py-0.5 bg-amber-500 text-slate-950 text-[10px] font-black rounded-md w-fit mb-1">
            FLAT ₹50 OFF CODE: ALLJITREAT
          </span>
          <p className="text-white text-xs font-medium">Free delivery on orders above ₹499</p>
        </div>
      </div>

      {/* Dishes List */}
      <div className="p-4 space-y-3">
        <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
          Recommended Delicacies ({filteredList.length})
        </h3>

        {filteredList.map(item => {
          const qty = getCartQuantity(item.id);
          return (
            <div
              key={item.id}
              className="p-3 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
            >
              {/* Info */}
              <div className="flex-1">
                <div className="flex items-center gap-1.5 mb-1">
                  <span
                    className={`w-3.5 h-3.5 rounded-sm border flex items-center justify-center p-[2px] ${
                      item.isVeg ? 'border-emerald-600' : 'border-rose-600'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        item.isVeg ? 'bg-emerald-600' : 'bg-rose-600'
                      }`}
                    />
                  </span>
                  {item.tags?.includes('Bestseller') && (
                    <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800">
                      Bestseller
                    </span>
                  )}
                </div>

                <h4 className="text-xs font-bold text-slate-900 leading-snug">{item.title}</h4>
                <div className="flex items-baseline gap-1.5 mt-1">
                  <span className="text-sm font-black text-slate-900">₹{item.discountPrice || item.price}</span>
                  {item.discountPrice && (
                    <span className="text-xs text-slate-400 line-through">₹{item.price}</span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Image & Add Button */}
              <div className="w-24 shrink-0 flex flex-col items-center">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-22 h-20 rounded-xl object-cover shadow-xs"
                />
                <div className="-mt-3 z-10 w-20">
                  {qty === 0 ? (
                    <button
                      id={`add-food-${item.id}`}
                      onClick={() => handleOpenCustomize(item)}
                      className="w-full py-1.5 bg-white hover:bg-amber-50 text-amber-600 font-extrabold text-xs rounded-xl border border-amber-300 shadow-sm flex items-center justify-center gap-1 active:scale-95 transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>ADD</span>
                    </button>
                  ) : (
                    <div className="w-full py-1 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-sm flex items-center justify-between px-2">
                      <button
                        onClick={() => updateCartQuantity(item.id, qty - 1)}
                        className="hover:opacity-75"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span>{qty}</span>
                      <button
                        onClick={() => updateCartQuantity(item.id, qty + 1)}
                        className="hover:opacity-75"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Bottom Cart Bar */}
      {cart.length > 0 && (
        <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
          <button
            id="view-food-cart-btn"
            onClick={onOpenCart}
            className="w-full p-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black rounded-2xl shadow-xl flex items-center justify-between active:scale-98 transition-all"
          >
            <div className="text-left">
              <span className="text-xs uppercase font-extrabold tracking-wider block text-slate-900/80">
                {cart.reduce((a, b) => a + b.quantity, 0)} Items Added
              </span>
              <span className="text-sm font-black">
                Total: ₹
                {cart.reduce((a, b) => a + (b.service.discountPrice || b.service.price) * b.quantity, 0)}
              </span>
            </div>
            <span className="text-xs bg-slate-950 text-white px-3 py-1.5 rounded-xl font-bold">
              View Cart →
            </span>
          </button>
        </div>
      )}

      {/* Customization Modal */}
      {selectedServiceForModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end justify-center">
          <div className="w-full max-w-sm bg-white rounded-t-3xl p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-black text-slate-900">
              Customize: {selectedServiceForModal.title}
            </h3>

            {selectedServiceForModal.options?.map(opt => (
              <div key={opt.name}>
                <p className="text-xs font-bold text-slate-700 mb-1.5">{opt.name}</p>
                <div className="grid grid-cols-2 gap-2">
                  {opt.choices.map(c => (
                    <button
                      key={c.label}
                      onClick={() =>
                        setSelectedOptions(prev => ({ ...prev, [opt.name]: c.label }))
                      }
                      className={`p-2 rounded-xl text-xs font-semibold border text-left transition-all ${
                        selectedOptions[opt.name] === c.label
                          ? 'border-amber-500 bg-amber-50 text-amber-900'
                          : 'border-slate-200 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{c.label}</span>
                        {c.price > 0 && <span className="text-[10px] text-amber-700">+₹{c.price}</span>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedServiceForModal(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmCustomize}
                className="flex-2 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Add Item to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
