import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Utensils,
  ShoppingBag,
  Car,
  Zap,
  Wrench,
  Cpu,
  Sparkles,
  Scissors,
  HeartHandshake,
  Package,
  Home,
  Palette,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { ServiceCategoryType } from '../../types';

interface CategoryListProps {
  onSelectCategory: (cat: ServiceCategoryType) => void;
}

const ICON_MAP: Record<string, any> = {
  Utensils,
  ShoppingBag,
  Car,
  Zap,
  Wrench,
  Cpu,
  Sparkles,
  Scissors,
  HeartHandshake,
  Package,
  Home,
  Palette
};

export const CategoryList: React.FC<CategoryListProps> = ({ onSelectCategory }) => {
  const { categories } = useApp();

  return (
    <div className="space-y-4">
      {/* Banner / Value Proposition */}
      <div className="mx-4 mt-2 p-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-950 shadow-md relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-slate-950/80">
            <Sparkles className="w-3.5 h-3.5 text-slate-950" />
            <span>AllJi Express Guarantee</span>
          </div>
          <h2 className="text-base font-black text-slate-950 mt-0.5 leading-tight">
            Sab Kuch, Ek Hi Jagah.
          </h2>
          <p className="text-xs font-semibold text-slate-950/90 mt-1 max-w-[240px]">
            From 10-min groceries & biryani to master electricians, taxis & salon at home.
          </p>
        </div>
        {/* Decorative circle */}
        <div className="absolute -right-6 -bottom-8 w-28 h-28 bg-white/20 rounded-full blur-xs pointer-events-none" />
      </div>

      {/* Main Services Grid */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
            All Services & Categories
          </h3>
          <span className="text-[11px] text-amber-600 font-bold flex items-center gap-0.5">
            12 Categories
          </span>
        </div>

        <div className="grid grid-cols-4 gap-2.5">
          {categories.map(cat => {
            const Icon = ICON_MAP[cat.icon] || Sparkles;
            return (
              <button
                key={cat.id}
                id={`cat-card-${cat.id}`}
                onClick={() => onSelectCategory(cat.id)}
                className="flex flex-col items-center text-center p-2 rounded-2xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-md transition-all group active:scale-95"
              >
                <div
                  className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${cat.color} text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform relative`}
                >
                  <Icon className="w-6 h-6" />
                  {cat.badge && (
                    <span className="absolute -bottom-1.5 px-1.5 py-0.2 bg-slate-950 text-amber-300 text-[8px] font-black rounded-full border border-slate-800 tracking-tighter whitespace-nowrap">
                      {cat.badge}
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-bold text-slate-800 mt-2 leading-tight line-clamp-2">
                  {cat.title}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Trust & Safety Highlights */}
      <div className="px-4 grid grid-cols-3 gap-2">
        <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200/60 text-center">
          <Clock className="w-4 h-4 text-amber-700 mx-auto mb-1" />
          <p className="text-[11px] font-black text-slate-900">10-30 Mins</p>
          <p className="text-[9px] text-slate-600">Hyperlocal Dispatch</p>
        </div>
        <div className="p-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200/60 text-center">
          <ShieldCheck className="w-4 h-4 text-emerald-700 mx-auto mb-1" />
          <p className="text-[11px] font-black text-slate-900">KYC Verified</p>
          <p className="text-[9px] text-slate-600">Police & ID Checked</p>
        </div>
        <div className="p-2.5 rounded-xl bg-blue-50/80 border border-blue-200/60 text-center">
          <TrendingUp className="w-4 h-4 text-blue-700 mx-auto mb-1" />
          <p className="text-[11px] font-black text-slate-900">Fair Pricing</p>
          <p className="text-[9px] text-slate-600">No Hidden Costs</p>
        </div>
      </div>
    </div>
  );
};
