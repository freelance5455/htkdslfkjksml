import React from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { ServiceCategory } from '../../types';
import {
  Zap,
  Droplets,
  Snowflake,
  Car,
  Bike,
  Sparkles,
  Smartphone,
  Hammer,
  Paintbrush,
  Wrench,
  Scissors,
  Truck,
  GraduationCap,
  ShieldAlert,
  Flame,
  HelpCircle,
} from 'lucide-react';

interface CategoryListProps {
  selectedCategoryId: string | null;
  onSelectCategory: (categoryId: string | null) => void;
}

export const CategoryIcon: React.FC<{ icon: string; className?: string }> = ({
  icon,
  className = 'w-6 h-6',
}) => {
  switch (icon) {
    case 'Zap':
      return <Zap className={className} />;
    case 'Droplets':
      return <Droplets className={className} />;
    case 'Snowflake':
      return <Snowflake className={className} />;
    case 'Car':
      return <Car className={className} />;
    case 'Bike':
      return <Bike className={className} />;
    case 'Sparkles':
      return <Sparkles className={className} />;
    case 'Smartphone':
      return <Smartphone className={className} />;
    case 'Hammer':
      return <Hammer className={className} />;
    case 'Paintbrush':
      return <Paintbrush className={className} />;
    case 'Wrench':
      return <Wrench className={className} />;
    case 'Scissors':
      return <Scissors className={className} />;
    case 'Truck':
      return <Truck className={className} />;
    case 'GraduationCap':
      return <GraduationCap className={className} />;
    case 'ShieldAlert':
      return <ShieldAlert className={className} />;
    case 'Flame':
      return <Flame className={className} />;
    default:
      return <HelpCircle className={className} />;
  }
};

export const CategoryList: React.FC<CategoryListProps> = ({
  selectedCategoryId,
  onSelectCategory,
}) => {
  const { categories, providers, language } = useMohalla();

  // Count active providers per category
  const getProviderCount = (catId: string) => {
    return providers.filter((p) => p.category === catId && p.isAvailableNow).length;
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
          <span>{language === 'ur' ? 'سروس کیٹیگریز' : 'Service Categories'}</span>
          <span className="text-xs font-normal text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {categories.length}
          </span>
        </h2>
        {selectedCategoryId && (
          <button
            onClick={() => onSelectCategory(null)}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
          >
            {language === 'ur' ? 'سب دکھائیں' : 'Clear Filter'}
          </button>
        )}
      </div>

      {/* Grid of categories */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2.5 sm:gap-3">
        {categories.map((cat) => {
          const isSelected = selectedCategoryId === cat.id;
          const availableCount = getProviderCount(cat.id);

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(isSelected ? null : cat.id)}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all cursor-pointer relative group ${
                isSelected
                  ? 'border-emerald-600 bg-emerald-600 text-white shadow-md shadow-emerald-700/25 scale-[1.02]'
                  : 'border-slate-200/90 bg-white hover:border-emerald-300 hover:bg-emerald-50/30 text-slate-700 shadow-2xs'
              }`}
            >
              {/* Category Icon circle */}
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center mb-1.5 transition-colors ${
                  isSelected
                    ? 'bg-white/20 text-white'
                    : 'bg-emerald-50 text-emerald-700 group-hover:bg-emerald-100'
                }`}
              >
                <CategoryIcon icon={cat.icon} className="w-5 h-5" />
              </div>

              {/* Title */}
              <span className="text-xs font-bold leading-tight line-clamp-1">
                {language === 'ur' ? cat.nameUrdu : cat.name}
              </span>

              {/* Sub-label */}
              <span
                className={`text-[10px] mt-0.5 font-medium ${
                  isSelected ? 'text-emerald-100' : 'text-slate-400'
                }`}
              >
                {availableCount > 0 ? (
                  <span className="text-emerald-600 font-semibold group-data-[selected=true]:text-white">
                    {availableCount} {language === 'ur' ? 'دستیاب' : 'now'}
                  </span>
                ) : (
                  <span>Rs. {cat.typicalVisitCharge}</span>
                )}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
