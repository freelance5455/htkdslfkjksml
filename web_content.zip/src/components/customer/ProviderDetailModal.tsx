import React, { useState } from 'react';
import { ProviderProfile } from '../../types';
import { useMohalla } from '../../context/MohallaContext';
import {
  X,
  Star,
  ShieldCheck,
  MapPin,
  Clock,
  Award,
  Phone,
  Calendar,
  CheckCircle,
  ThumbsUp,
  AlertTriangle,
  Image as ImageIcon,
  MessageSquare,
} from 'lucide-react';
import { calculateDistanceKm, formatCurrencyPKR, formatDistance } from '../../utils/geo';

interface ProviderDetailModalProps {
  provider: ProviderProfile;
  onClose: () => void;
  onBookNow: (provider: ProviderProfile) => void;
  onOpenReport: (provider: ProviderProfile) => void;
}

export const ProviderDetailModal: React.FC<ProviderDetailModalProps> = ({
  provider,
  onClose,
  onBookNow,
  onOpenReport,
}) => {
  const { selectedArea, reviews, language } = useMohalla();
  const [activeTab, setActiveTab] = useState<'about' | 'portfolio' | 'reviews' | 'trust'>('about');

  const distanceKm = calculateDistanceKm(
    selectedArea.lat,
    selectedArea.lng,
    provider.location.lat,
    provider.location.lng
  );

  const providerReviews = reviews.filter((r) => r.providerId === provider.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header Banner */}
        <div className="relative bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-5 sm:p-6 shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/20 hover:bg-black/40 text-white cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-start gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-2xl font-black text-white shrink-0 shadow-lg">
              {provider.businessName.charAt(0)}
            </div>

            <div className="flex-1 min-w-0 pr-8">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-bold truncate">
                  {provider.businessName}
                </h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 ${
                    provider.isAvailableNow
                      ? 'bg-emerald-400 text-emerald-950'
                      : 'bg-slate-300 text-slate-800'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      provider.isAvailableNow ? 'bg-emerald-950 animate-ping' : 'bg-slate-700'
                    }`}
                  />
                  {provider.isAvailableNow ? 'Available Now' : 'Busy'}
                </span>
              </div>

              <div className="flex items-center gap-2 mt-1.5 flex-wrap text-xs text-emerald-100">
                <span className="flex items-center gap-1 font-semibold text-white">
                  <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                  {provider.rating.toFixed(1)} ({provider.reviewCount} reviews)
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {formatDistance(distanceKm)} away ({provider.location.areaName})
                </span>
              </div>

              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-700/80 text-emerald-100 border border-emerald-500/30">
                  <ShieldCheck className="w-3 h-3 text-emerald-300" />
                  {provider.verificationBadge}
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-amber-400/20 text-amber-200 border border-amber-300/30">
                  <Award className="w-3 h-3 text-amber-300" />
                  Trust Score {provider.trustScore}/100
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50/70 text-xs font-bold text-slate-500 shrink-0">
          <button
            onClick={() => setActiveTab('about')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'about'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Overview & Services
          </button>
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'portfolio'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Past Work ({provider.portfolio.length})
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'reviews'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Reviews ({providerReviews.length})
          </button>
          <button
            onClick={() => setActiveTab('trust')}
            className={`py-3 px-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'trust'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Trust & Safety
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 text-slate-800">
          {activeTab === 'about' && (
            <>
              {/* About description */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  About Provider
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed">{provider.bio}</p>
              </div>

              {/* Service Offerings */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Key Services & Skills
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {provider.subServices.map((sub, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70 text-xs font-semibold text-slate-800"
                    >
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{sub}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing & Guarantee */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-900 block">
                    Fixed Visit & Diagnostic Charge
                  </span>
                  <p className="text-xs text-emerald-700 mt-0.5">
                    Pay only in cash upon arrival. No advance payment required.
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xl font-black text-emerald-950">
                    {formatCurrencyPKR(provider.visitCharge)}
                  </span>
                </div>
              </div>

              {/* Service Areas */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Service Coverage Areas
                </h4>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {provider.serviceAreas.map((area, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium"
                    >
                      📍 {area}
                    </span>
                  ))}
                  <span className="text-xs text-slate-400 font-medium">
                    (Within {provider.serviceRadiusKm} km radius)
                  </span>
                </div>
              </div>
            </>
          )}

          {activeTab === 'portfolio' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Verified Work Completed in Karachi
              </h4>
              {provider.portfolio.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl">
                  <ImageIcon className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  No portfolio images uploaded yet for this provider.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {provider.portfolio.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-50 shadow-xs"
                    >
                      <img
                        src={item.afterPhoto}
                        alt={item.title}
                        className="w-full h-44 object-cover"
                      />
                      <div className="p-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">{item.title}</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                            Verified Work
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Customer Ratings & Experiences
                </span>
                <span className="text-xs font-bold text-slate-700">
                  ⭐ {provider.rating.toFixed(1)} / 5.0
                </span>
              </div>

              {providerReviews.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl">
                  No public reviews recorded yet for this provider.
                </div>
              ) : (
                providerReviews.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{rev.customerName}</span>
                        <div className="flex text-amber-400">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-current" />
                          ))}
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {new Date(rev.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>

                    {rev.tags && (
                      <div className="flex items-center gap-1.5 flex-wrap pt-1">
                        {rev.tags.map((t, i) => (
                          <span
                            key={i}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 font-semibold"
                          >
                            ✓ {t}
                          </span>
                        ))}
                      </div>
                    )}

                    {rev.providerResponse && (
                      <div className="mt-2 pl-3 border-l-2 border-emerald-500 bg-emerald-50/60 p-2 rounded-r-lg text-xs text-emerald-950">
                        <span className="font-bold block text-[11px] text-emerald-800">
                          Provider Reply:
                        </span>
                        {rev.providerResponse}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'trust' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600" />
                    <span className="font-bold text-sm text-amber-950">
                      Mohalla Trust Algorithm Score
                    </span>
                  </div>
                  <span className="text-xl font-black text-amber-900">
                    {provider.trustScore}/100
                  </span>
                </div>
                <p className="text-xs text-amber-800">
                  Computed based on official Pakistani CNIC identity verification, repeat job
                  satisfaction, low cancellation rate, and on-time punctuality.
                </p>
              </div>

              {/* Factors */}
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="font-medium text-slate-700">Identity Verification Status</span>
                  <span className="font-bold text-emerald-700 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Government CNIC Verified
                  </span>
                </div>

                <div className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="font-medium text-slate-700">On-Time Arrival Rate</span>
                  <span className="font-bold text-slate-900">{provider.onTimePercentage}%</span>
                </div>

                <div className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="font-medium text-slate-700">Cancellation Rate</span>
                  <span className="font-bold text-slate-900">
                    {provider.cancellationRatePercentage}% (Very Low)
                  </span>
                </div>

                <div className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="font-medium text-slate-700">Masked National ID</span>
                  <span className="font-mono text-slate-600">{provider.cnicMasked}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onOpenReport(provider)}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Report suspicious activity or issue with this provider
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Visit Fee
            </span>
            <span className="text-base sm:text-lg font-extrabold text-slate-900">
              {formatCurrencyPKR(provider.visitCharge)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 text-xs font-semibold cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onBookNow(provider);
              }}
              className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md cursor-pointer hover:scale-105 active:scale-95 transition-all"
            >
              {language === 'ur' ? 'ابھی بک کریں' : 'Book This Provider'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
