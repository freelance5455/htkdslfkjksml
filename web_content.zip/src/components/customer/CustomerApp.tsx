import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Mic,
  ShoppingCart,
  Heart,
  User,
  Home,
  Grid,
  Film,
  Sparkles,
  ChevronRight,
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  CheckCircle2,
  Clock,
  ArrowLeft,
  X,
  Plus,
  Minus,
  Trash2,
  Send,
  Smartphone,
  Maximize2,
  Volume2,
  Share2,
  MapPin,
  Tag,
  CreditCard,
  QrCode,
  AlertCircle,
  ExternalLink,
  Package,
  Store,
  ThumbsUp,
  Check,
  MessageSquare,
  Phone,
  LogOut,
  UserCheck,
  Download,
} from 'lucide-react';
import { Product, CartItem, Address, Order, VideoReel, Coupon, Review, OrderItem, CustomerUser } from '../../types';
import { Logo } from '../common/Logo';
import { DEMO_CUSTOMERS } from '../../data/mockData';
import { CustomerLoginModal } from './CustomerLoginModal';
import { ApkDownloadModal } from '../common/ApkDownloadModal';

interface CustomerAppProps {
  products: Product[];
  reels: VideoReel[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  onAddToCart: (product: Product, variantId?: string, qty?: number) => void;
  onUpdateCartQty: (productId: string, variantId: string | undefined, qty: number) => void;
  onRemoveFromCart: (productId: string, variantId?: string) => void;
  onToggleWishlist: (productId: string) => void;
  onPlaceOrder: (order: Order) => void;
  onCancelOrder: (orderId: string) => void;
  onRequestReturn: (orderId: string, reason: string) => void;
  onAddReview?: (productId: string, orderId: string, review: Review) => void;
  onUpdateOrderStatus?: (orderId: string, status: Order['status']) => void;
  onLoadSampleOrders?: () => void;
  activeViewMode: 'phone' | 'fullscreen';
  onToggleViewMode: () => void;
  onOpenSellerRegistration?: () => void;
}

export const CustomerApp: React.FC<CustomerAppProps> = ({
  products,
  reels,
  cart,
  wishlist,
  orders,
  onAddToCart,
  onUpdateCartQty,
  onRemoveFromCart,
  onToggleWishlist,
  onPlaceOrder,
  onCancelOrder,
  onRequestReturn,
  onAddReview,
  onUpdateOrderStatus,
  onLoadSampleOrders,
  activeViewMode,
  onToggleViewMode,
  onOpenSellerRegistration,
}) => {
  // Navigation tabs: 'home' | 'categories' | 'reels' | 'wishlist' | 'cart' | 'orders' | 'assistant'
  const [activeTab, setActiveTab] = useState<'home' | 'categories' | 'reels' | 'wishlist' | 'cart' | 'orders' | 'assistant'>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  // Active product kept reactive with products state (for live review updates)
  const activeProduct = selectedProduct ? products.find((p) => p.id === selectedProduct.id) || selectedProduct : null;
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearchingVoice, setIsSearchingVoice] = useState<boolean>(false);
  const [voiceSearchMessage, setVoiceSearchMessage] = useState<string | null>(null);

  // Customer Auth state (Meesho / Flipkart / Blinkit Mobile OTP standard)
  const [currentCustomer, setCurrentCustomer] = useState<CustomerUser | null>(DEMO_CUSTOMERS[0]);
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [showAccountDrawer, setShowAccountDrawer] = useState<boolean>(false);
  const [showApkModal, setShowApkModal] = useState<boolean>(false);
  const [loginToast, setLoginToast] = useState<string | null>(null);

  const handleLoginSuccess = (user: CustomerUser) => {
    setCurrentCustomer(user);
    setShowLoginModal(false);
    setLoginToast(`Namaste ${user.name}! Logged in with ${user.phone}`);
    setTimeout(() => setLoginToast(null), 3500);

    setAddresses((prev) =>
      prev.map((addr, idx) =>
        idx === 0
          ? {
              ...addr,
              fullName: user.name,
              phoneNumber: user.phone,
            }
          : addr
      )
    );
  };

  const handleLogout = () => {
    setCurrentCustomer(null);
    setShowAccountDrawer(false);
    setLoginToast('Logged out. You are now in Guest Shopping mode.');
    setTimeout(() => setLoginToast(null), 3500);
  };

  // Cart & Checkout state
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponInput, setCouponInput] = useState<string>('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isCheckingOut, setIsCheckingOut] = useState<boolean>(false);
  const [checkoutStep, setCheckoutStep] = useState<'address' | 'payment' | 'success'>('address');
  const [selectedAddressIndex, setSelectedAddressIndex] = useState<number>(0);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'UPI' | 'CARD' | 'NETBANKING' | 'COD'>('UPI');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  // AI Assistant chat state
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string; time: string }>>([
    {
      sender: 'assistant',
      text: 'Namaste! I am your PC Assistant. Ask me anything in Hindi or English about our products, sizes, offers, or return policies!',
      time: '10:42 AM',
    },
  ]);
  const [chatInput, setChatInput] = useState<string>('');
  const [isAssistantThinking, setIsAssistantThinking] = useState<boolean>(false);

  // AI Product Review Summary State
  const [aiReviewSummary, setAiReviewSummary] = useState<any>(null);
  const [isLoadingReviewSummary, setIsLoadingReviewSummary] = useState<boolean>(false);

  // Customer Product Rating & Review State
  const [reviewModalData, setReviewModalData] = useState<{ order: Order; item: OrderItem } | null>(null);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [reviewTitle, setReviewTitle] = useState<string>('');
  const [reviewComment, setReviewComment] = useState<string>('');
  const [reviewToast, setReviewToast] = useState<string | null>(null);
  const [votedHelpfulReviews, setVotedHelpfulReviews] = useState<Record<string, boolean>>({});
  const [reviewFilterRating, setReviewFilterRating] = useState<number | 'ALL'>('ALL');

  const handleOpenReviewModal = (order: Order, item: OrderItem) => {
    const targetProd = products.find((p) => p.id === item.productId);
    const existing = targetProd?.reviews?.find(
      (r) => r.userName === order.customerName || r.userId === order.customerId
    );

    setReviewModalData({ order, item });
    setReviewRating(existing ? existing.rating : item.reviewRating || 5);
    setHoverRating(0);
    setReviewTitle(existing ? existing.title : '');
    setReviewComment(existing ? existing.comment : '');
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalData) return;
    const { order, item } = reviewModalData;

    const newReview: Review = {
      id: `rev_${Date.now()}`,
      userId: currentCustomer?.id || order.customerId || 'cust_current',
      userName: currentCustomer?.name || order.customerName || 'Karan Sharma',
      rating: reviewRating,
      title: reviewTitle.trim() || `${reviewRating}★ Verified Rating`,
      comment: reviewComment.trim() || 'Genuine verified product. Fast delivery and high quality build!',
      date: new Date().toISOString().split('T')[0],
      verifiedPurchase: true,
      helpfulCount: 0,
    };

    if (onAddReview) {
      onAddReview(item.productId, order.id, newReview);
    }

    setReviewToast(`Your ${reviewRating}★ review for "${item.title}" has been published!`);
    setTimeout(() => setReviewToast(null), 4000);
    setReviewModalData(null);
  };

  const handleToggleHelpful = (reviewId: string) => {
    setVotedHelpfulReviews((prev) => ({
      ...prev,
      [reviewId]: !prev[reviewId],
    }));
  };

  // Delivery Pincode Checker
  const [deliveryPincode, setDeliveryPincode] = useState<string>('400053');
  const [pincodeVerified, setPincodeVerified] = useState<boolean>(true);

  // Reels feed active index
  const [activeReelIndex, setActiveReelIndex] = useState<number>(0);

  // Saved Addresses
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: 'addr_1',
      fullName: 'Karan Sharma',
      phoneNumber: '+91 98765 43210',
      streetAddress: 'Flat 402, Sunshine Heights, Andheri West',
      landmark: 'Near Infiniti Mall',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400053',
      addressType: 'HOME',
      isDefault: true,
    },
    {
      id: 'addr_2',
      fullName: 'Karan Sharma',
      phoneNumber: '+91 98765 43210',
      streetAddress: 'Tech Tower, Level 6, BKC G Block',
      landmark: 'Opposite Diamond Bourse',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400051',
      addressType: 'WORK',
      isDefault: false,
    },
  ]);

  const categories = ['All', 'Audio', 'Smart Watches', 'Fashion', 'Electronics', 'Home & Office'];

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  // Calculate cart totals
  const cartSubtotal = cart.reduce((acc, item) => acc + item.priceAtAddition * item.quantity, 0);
  const cartDiscount = appliedCoupon
    ? appliedCoupon.discountType === 'FLAT'
      ? appliedCoupon.value
      : Math.min((cartSubtotal * appliedCoupon.value) / 100, appliedCoupon.maxDiscount || 500)
    : 0;
  const deliveryFee = cartSubtotal >= 499 || cartSubtotal === 0 ? 0 : 49;
  const platformFee = cartSubtotal > 0 ? 5 : 0;
  const finalPayable = Math.max(0, cartSubtotal - cartDiscount + deliveryFee + platformFee);

  // Apply coupon
  const handleApplyCoupon = (codeToApply?: string) => {
    const code = (codeToApply || couponInput).trim().toUpperCase();
    if (!code) return;
    setCouponError(null);

    if (code === 'PCFIRST200') {
      if (cartSubtotal >= 999) {
        setAppliedCoupon({
          code: 'PCFIRST200',
          description: 'Flat ₹200 OFF on order above ₹999',
          discountType: 'FLAT',
          value: 200,
          minOrderValue: 999,
          expiryDate: '2026-12-31',
        });
        setCouponInput('');
      } else {
        setCouponError('Add items worth ₹' + (999 - cartSubtotal) + ' more to apply PCFIRST200');
      }
    } else if (code === 'PREMIUM15') {
      if (cartSubtotal >= 1499) {
        setAppliedCoupon({
          code: 'PREMIUM15',
          description: '15% instant savings up to ₹500',
          discountType: 'PERCENTAGE',
          value: 15,
          minOrderValue: 1499,
          maxDiscount: 500,
          expiryDate: '2026-12-31',
        });
        setCouponInput('');
      } else {
        setCouponError('Add items worth ₹' + (1499 - cartSubtotal) + ' more to apply PREMIUM15');
      }
    } else if (code === 'FREESHIP') {
      setAppliedCoupon({
        code: 'FREESHIP',
        description: 'Free expedited delivery',
        discountType: 'FLAT',
        value: 49,
        minOrderValue: 499,
        expiryDate: '2026-12-31',
      });
      setCouponInput('');
    } else {
      setCouponError('Invalid coupon code. Try PCFIRST200 or PREMIUM15');
    }
  };

  // Trigger Gemini AI review summary when product detail opens
  useEffect(() => {
    if (!selectedProduct) {
      setAiReviewSummary(null);
      return;
    }
    const fetchSummary = async () => {
      setIsLoadingReviewSummary(true);
      try {
        const res = await fetch('/api/ai/review-summary', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            productName: selectedProduct.title,
            reviews: [
              { rating: 5, comment: 'Exceptional ANC and microphone clarity during long calls.' },
              { rating: 5, comment: 'Battery lasts for days. Fast pairing with Android & laptop.' },
              { rating: 4, comment: 'Bass is tight and deep, very premium finish.' },
            ],
          }),
        });
        const data = await res.json();
        if (data.success && data.data) {
          setAiReviewSummary(data.data);
        }
      } catch (err) {
        console.error('Failed to get review summary:', err);
      } finally {
        setIsLoadingReviewSummary(false);
      }
    };
    fetchSummary();
  }, [selectedProduct?.id]);

  // Handle Hindi/English Voice Search
  const handleVoiceSearch = async (sampleQuery?: string) => {
    setIsSearchingVoice(true);
    setVoiceSearchMessage('Listening in Hindi / English...');
    const query = sampleQuery || 'Mujhe wireless earbuds dikhao best quality under 3000';

    try {
      setVoiceSearchMessage(`Processing: "${query}"...`);
      const res = await fetch('/api/ai/voice-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        const info = data.data;
        setVoiceSearchMessage(info.politeReply || `Showing results for ${info.cleanQuery}`);
        if (info.cleanQuery) {
          setSearchQuery(info.cleanQuery);
        }
        if (info.normalizedCategory && info.normalizedCategory !== 'All') {
          setSelectedCategory(info.normalizedCategory);
        }
        setTimeout(() => {
          setIsSearchingVoice(false);
          setVoiceSearchMessage(null);
        }, 2200);
      }
    } catch {
      setSearchQuery(query);
      setIsSearchingVoice(false);
      setVoiceSearchMessage(null);
    }
  };

  // Handle Assistant Chat message
  const handleSendChatMessage = async () => {
    if (!chatInput.trim() || isAssistantThinking) return;
    const userMsg = chatInput.trim();
    setChatInput('');
    setChatMessages((prev) => [
      ...prev,
      { sender: 'user', text: userMsg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ]);
    setIsAssistantThinking(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMsg,
          chatHistory: chatMessages,
          catalogSample: products.map((p) => ({
            id: p.id,
            title: p.title,
            category: p.category,
            price: p.price,
            rating: p.rating,
            inStock: p.inStock,
          })),
        }),
      });
      const data = await res.json();
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          text: data.reply || 'Here is what I recommend from PCMART verified inventory.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          text: 'You can check our top rated SoundPulse Pro ANC Earbuds or Apex ChronoFit Smartwatch!',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsAssistantThinking(false);
    }
  };

  // Complete Checkout with approved payment gateway simulation and server signature
  const handleConfirmOrder = async () => {
    if (cart.length === 0) return;
    setIsProcessingPayment(true);

    const orderId = `ord_pcm_${Date.now().toString().slice(-6)}`;
    const address = addresses[selectedAddressIndex] || addresses[0];

    try {
      // 1. Request server-side order signature token
      const tokenRes = await fetch('/api/checkout/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          amount: finalPayable,
          currency: 'INR',
          customerId: 'cust_01',
        }),
      });
      const tokenData = await tokenRes.json();

      // 2. Verify server-side payment signature
      const verifyRes = await fetch('/api/checkout/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: tokenData.orderId,
          paymentId: tokenData.paymentId,
          signature: tokenData.signature,
        }),
      });
      const verifyData = await verifyRes.json();

      if (verifyData.verified || selectedPaymentMethod === 'COD') {
        const newOrder: Order = {
          id: orderId,
          orderNumber: `PCM-${new Date().getFullYear()}-${orderId.slice(-5)}`,
          customerId: currentCustomer?.id || 'cust_01',
          customerName: currentCustomer?.name || address.fullName,
          customerPhone: currentCustomer?.phone || address.phoneNumber,
          items: cart.map((c) => ({
            productId: c.productId,
            variantId: c.variantId,
            title: c.product.title,
            variantName: c.variantName,
            image: c.product.images[0],
            quantity: c.quantity,
            unitPrice: c.priceAtAddition,
            totalPrice: c.priceAtAddition * c.quantity,
            sellerId: c.product.sellerId,
            sellerName: c.product.sellerName,
            status: 'CONFIRMED',
          })),
          subtotal: cartSubtotal,
          discount: cartDiscount,
          deliveryFee,
          platformFee,
          totalAmount: finalPayable,
          shippingAddress: address,
          paymentMethod: selectedPaymentMethod,
          paymentStatus: selectedPaymentMethod === 'COD' ? 'PENDING_COD' : 'PAID',
          paymentTransactionId: tokenData.paymentId,
          status: 'CONFIRMED',
          carrier: 'BlueDart Express',
          trackingNumber: `BD-${Math.floor(100000000 + Math.random() * 900000000)}`,
          estimatedDeliveryDate: '2 Business Days',
          createdAt: new Date().toISOString(),
        };

        onPlaceOrder(newOrder);
        setLastPlacedOrder(newOrder);
        setCheckoutStep('success');
      }
    } catch (err) {
      console.error('Checkout error:', err);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Inner phone frame or full screen container
  const content = (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Android Status Bar */}
      <div className="h-7 bg-slate-900/90 backdrop-blur-md px-4 flex items-center justify-between text-[11px] text-slate-300 font-medium z-30 shrink-0 border-b border-slate-800/40">
        <div className="flex items-center gap-1.5">
          <span className="font-semibold text-white">10:42</span>
          <span className="text-[9px] bg-[#1746A2] text-white px-1 rounded font-bold">5G+</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px]">VoLTE</span>
          <div className="w-4 h-2.5 border border-slate-400 rounded-xs relative flex items-center p-0.5">
            <div className="h-full bg-emerald-400 w-3/4 rounded-2xs"></div>
            <div className="absolute -right-1 top-0.5 w-0.5 h-1.5 bg-slate-400 rounded-r-xs"></div>
          </div>
        </div>
      </div>

      {/* Main Top Header */}
      <div className="bg-[#1746A2] text-white px-3.5 pt-2.5 pb-3 shadow-md shrink-0 z-20">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Logo size="sm" showTagline={false} variant="horizontal" />
          </div>

          <div className="flex items-center gap-2">
            {/* Delivery Pincode Indicator */}
            <div className="flex items-center gap-1 bg-white/10 hover:bg-white/20 transition-colors px-2 py-1 rounded-full text-[11px]">
              <MapPin className="w-3 h-3 text-[#FFD447]" />
              <span className="font-medium text-white truncate max-w-[85px]">Mumbai 400053</span>
            </div>

            {/* Customer Login / Account Button (Meesho / Flipkart Standard) */}
            {currentCustomer ? (
              <button
                onClick={() => setShowAccountDrawer(true)}
                title={`Account: ${currentCustomer.name} (${currentCustomer.phone})`}
                className="flex items-center gap-1 bg-white/15 hover:bg-white/25 px-2 py-1 rounded-full text-[11px] font-bold text-white transition-all border border-white/10"
              >
                <img
                  src={currentCustomer.avatar}
                  alt={currentCustomer.name}
                  className="w-4 h-4 rounded-full object-cover border border-[#FFD447]"
                />
                <span className="truncate max-w-[55px]">{currentCustomer.name.split(' ')[0]}</span>
              </button>
            ) : (
              <button
                onClick={() => setShowLoginModal(true)}
                className="flex items-center gap-1 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black px-2.5 py-1 rounded-full text-[11px] shadow transition-all active:scale-95"
              >
                <Phone className="w-3 h-3" />
                <span>Login</span>
              </button>
            )}

            {/* APK Download Button */}
            <button
              onClick={() => setShowApkModal(true)}
              title="Download Android APK / Install on Phone"
              className="flex items-center gap-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-2 py-1 rounded-full text-[11px] font-bold transition-all shadow-sm active:scale-95"
            >
              <Download className="w-3 h-3" />
              <span>APK</span>
            </button>

            {/* View Mode Toggle Button */}
            <button
              onClick={onToggleViewMode}
              title={activeViewMode === 'phone' ? 'Switch to Fullscreen' : 'Switch to Android Frame'}
              className="p-1.5 bg-white/15 hover:bg-white/25 rounded-full text-white transition-colors"
            >
              {activeViewMode === 'phone' ? <Maximize2 className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            </button>

            {/* Cart Icon with badge */}
            <button
              onClick={() => setActiveTab('cart')}
              className="relative p-1.5 bg-white/15 hover:bg-white/25 rounded-full text-white transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#FFD447] text-slate-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow">
                  {cart.reduce((a, b) => a + b.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search Bar with Hindi/English Voice Input */}
        <div className="mt-2.5 relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audio, watches, fashion... (English/हिंदी)"
            className="w-full bg-slate-900/90 text-white pl-9 pr-16 py-2 rounded-xl text-xs placeholder:text-slate-400 border border-slate-700/60 focus:outline-none focus:border-[#FFD447] transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-10 p-1 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => handleVoiceSearch()}
            title="Voice Search (Hindi / English)"
            className={`absolute right-2 p-1.5 rounded-lg transition-all ${
              isSearchingVoice ? 'bg-red-500 text-white animate-pulse' : 'bg-[#FFD447] text-slate-950 hover:bg-amber-300'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Voice Search Feedback Banner */}
        {isSearchingVoice && (
          <div className="mt-2 py-1.5 px-3 bg-white/15 backdrop-blur-md rounded-lg flex items-center justify-between text-xs text-[#FFD447] animate-fadeIn">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping"></span>
              {voiceSearchMessage}
            </span>
            <span className="text-[10px] text-white/80">Gemini Voice AI</span>
          </div>
        )}
      </div>

      {/* Main Tab Content Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar relative bg-slate-950">
        {/* TAB 1: HOME */}
        {activeTab === 'home' && (
          <div className="pb-20 space-y-4">
            {/* Category Pills Slider */}
            <div className="px-3 pt-3 flex gap-2 overflow-x-auto no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    selectedCategory === cat
                      ? 'bg-[#FFD447] text-slate-950 shadow-md font-bold'
                      : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Hero Offer Carousel */}
            <div className="px-3">
              <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#1746A2] to-blue-900 p-4 text-white shadow-xl border border-blue-800/40">
                <div className="relative z-10 max-w-[65%]">
                  <span className="inline-block bg-[#FFD447] text-slate-950 text-[10px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider mb-1.5">
                    MEGA MART FEST
                  </span>
                  <h3 className="text-base font-black leading-tight text-white">
                    Har Choice, Premium Choice!
                  </h3>
                  <p className="text-[11px] text-blue-100 mt-1 line-clamp-2">
                    Up to 55% OFF on ANC Audio & AMOLED Watches with 7-day doorstep replacement.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategory('Audio');
                      window.scrollTo({ top: 300, behavior: 'smooth' });
                    }}
                    className="mt-3 inline-flex items-center gap-1 bg-white text-[#1746A2] hover:bg-slate-100 font-extrabold text-xs px-3 py-1.5 rounded-xl shadow-md transition-transform active:scale-95"
                  >
                    Explore Deals <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="absolute right-0 bottom-0 top-0 w-36 overflow-hidden flex items-center justify-center">
                  <img
                    src="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&auto=format&fit=crop&q=80"
                    alt="Headphones Offer"
                    className="object-cover h-full w-full opacity-80 mix-blend-screen"
                  />
                </div>
              </div>
            </div>

            {/* PC Reels Quick Teaser Bar (if reels exist) */}
            {reels.length > 0 && (
              <div className="px-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <Film className="w-4 h-4 text-[#FFD447]" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">PC Reels • Shoppable Videos</span>
                  </div>
                  <button
                    onClick={() => setActiveTab('reels')}
                    className="text-[11px] text-[#FFD447] hover:underline font-semibold flex items-center gap-0.5"
                  >
                    Watch All <ChevronRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="flex gap-2.5 overflow-x-auto no-scrollbar py-1">
                  {reels.map((reel, idx) => (
                    <div
                      key={reel.id}
                      onClick={() => {
                        setActiveReelIndex(idx);
                        setActiveTab('reels');
                      }}
                      className="w-24 shrink-0 rounded-xl overflow-hidden relative cursor-pointer group shadow-md border border-slate-800 hover:border-[#FFD447] transition-all"
                    >
                      <div className="aspect-[9/14] bg-slate-900 relative">
                        <img
                          src={reel.thumbnailUrl}
                          alt={reel.productTitle}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                        <div className="absolute bottom-1.5 left-1.5 right-1.5 text-white">
                          <span className="text-[10px] font-bold block truncate">{reel.productTitle}</span>
                          <span className="text-[9px] text-[#FFD447] font-extrabold">₹{reel.productPrice}</span>
                        </div>
                        <div className="absolute top-1.5 right-1.5 bg-black/60 backdrop-blur-xs p-1 rounded-full text-white">
                          <Film className="w-2.5 h-2.5" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Flash Deals / Live Specials */}
            <div className="px-3">
              <div className="flex items-center justify-between mb-2.5">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                  <span className="text-xs font-extrabold text-white tracking-wide uppercase">
                    {filteredProducts.length > 0 ? 'Choice Flash Deals' : 'Marketplace Products'}
                  </span>
                </div>
                {filteredProducts.length > 0 && (
                  <div className="flex items-center gap-1 bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded text-[10px] font-mono font-semibold">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>Ends in 03h:41m:12s</span>
                  </div>
                )}
              </div>

              {/* Product Grid / Empty State */}
              {filteredProducts.length === 0 ? (
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-[#1746A2]/20 border border-[#1746A2]/40 flex items-center justify-center text-[#FFD447]">
                    <Package className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-white">Koi Product Available Nahi Hai (0 Items)</h4>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto">
                      Aapke anurodh par sabhi purane seller accounts aur mock products remove kar diye gaye hain.
                    </p>
                    <p className="text-[11px] text-[#FFD447] font-semibold">
                      Naye sellers register karke turant apne verified products list kar sakte hain!
                    </p>
                  </div>
                  {onOpenSellerRegistration && (
                    <button
                      onClick={onOpenSellerRegistration}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#FFD447] hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-transform active:scale-95"
                    >
                      <Store className="w-4 h-4" /> + Nayi Dukan Kholein / Sell Products
                    </button>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2.5">
                  {filteredProducts.map((product) => {
                    const isWish = wishlist.includes(product.id);
                    return (
                      <div
                        key={product.id}
                        className="bg-slate-900 rounded-2xl overflow-hidden border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col justify-between shadow-sm group"
                      >
                        <div className="relative cursor-pointer" onClick={() => setSelectedProduct(product)}>
                          <div className="aspect-square bg-slate-950 overflow-hidden relative">
                            <img
                              src={product.images[0]}
                              alt={product.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            {/* Discount Badge */}
                            <span className="absolute top-2 left-2 bg-[#FFD447] text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-md shadow">
                              {product.discountPercentage}% OFF
                            </span>
                            {/* Video reel indicator */}
                            {product.videoUrl && (
                              <span className="absolute bottom-2 left-2 bg-slate-950/80 backdrop-blur-xs text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
                                <Film className="w-2.5 h-2.5 text-[#FFD447]" /> Video
                              </span>
                            )}
                          </div>

                          {/* Wishlist toggle */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleWishlist(product.id);
                            }}
                            className={`absolute top-2 right-2 p-1.5 rounded-full backdrop-blur-md transition-colors ${
                              isWish ? 'bg-red-500 text-white' : 'bg-slate-900/70 text-slate-300 hover:text-white'
                            }`}
                          >
                            <Heart className={`w-3.5 h-3.5 ${isWish ? 'fill-current' : ''}`} />
                          </button>
                        </div>

                        {/* Content */}
                        <div className="p-2.5 flex-1 flex flex-col justify-between">
                          <div className="cursor-pointer" onClick={() => setSelectedProduct(product)}>
                            <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                              <span className="text-[#FFD447] font-semibold">{product.brand}</span>
                              <span>•</span>
                              <span className="flex items-center text-amber-400 font-bold">
                                <Star className="w-2.5 h-2.5 fill-current inline mr-0.5" />
                                {product.rating}
                              </span>
                            </div>
                            <h4 className="text-xs font-bold text-slate-100 line-clamp-2 leading-tight">
                              {product.title}
                            </h4>
                            <div className="mt-1.5 flex items-baseline gap-1.5">
                              <span className="text-sm font-black text-white">₹{product.price}</span>
                              <span className="text-[10px] text-slate-400 line-through">₹{product.mrp}</span>
                            </div>
                          </div>

                          {/* Quick Add To Cart Button */}
                          <button
                            onClick={() => onAddToCart(product, product.selectedVariantId, 1)}
                            className="mt-2.5 w-full py-1.5 px-2 bg-[#1746A2] hover:bg-blue-700 active:scale-95 text-white text-[11px] font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm"
                          >
                            <ShoppingCart className="w-3.5 h-3.5" /> Add to Cart
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Peace of Mind Guarantee Banner */}
            <div className="px-3 pt-2">
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="flex flex-col items-center gap-1 text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold">100% Genuine</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-slate-300 border-x border-slate-800">
                  <RotateCcw className="w-4 h-4 text-[#FFD447]" />
                  <span className="font-semibold">7 Days Return</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-slate-300">
                  <Truck className="w-4 h-4 text-blue-400" />
                  <span className="font-semibold">Pan-India Express</span>
                </div>
              </div>
            </div>

            {/* Sell on PCMART Banner for Prospective Merchants */}
            {onOpenSellerRegistration && (
              <div className="px-3 pt-1">
                <div
                  onClick={onOpenSellerRegistration}
                  className="bg-gradient-to-r from-blue-950/80 to-slate-900 border border-[#FFD447]/40 rounded-2xl p-3.5 flex items-center justify-between cursor-pointer hover:border-[#FFD447] transition-all shadow-md group"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] bg-[#FFD447] text-slate-950 px-2 py-0.5 rounded font-black uppercase tracking-wider inline-block">
                      MERCHANT NETWORK
                    </span>
                    <h4 className="text-xs font-black text-white group-hover:text-[#FFD447] transition-colors">
                      Apni Dukan PCMART Par Kholein!
                    </h4>
                    <p className="text-[10px] text-slate-300">
                      GSTIN & Bank Account se 2 minute me register karein aur India bhar me bechein.
                    </p>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-[#1746A2] text-[#FFD447] flex items-center justify-center shrink-0 shadow">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CATEGORIES */}
        {activeTab === 'categories' && (
          <div className="p-3 pb-20 space-y-3">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">Explore All Categories</h3>
            <div className="grid grid-cols-2 gap-2.5">
              {categories
                .filter((c) => c !== 'All')
                .map((cat) => (
                  <div
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setActiveTab('home');
                    }}
                    className="p-3.5 bg-slate-900 border border-slate-800 hover:border-[#1746A2] rounded-2xl cursor-pointer transition-all shadow-sm flex flex-col justify-between"
                  >
                    <div>
                      <span className="text-xs font-bold text-white block">{cat}</span>
                      <span className="text-[10px] text-slate-400">
                        {products.filter((p) => p.category === cat).length} Verified Products
                      </span>
                    </div>
                    <div className="mt-3 flex justify-end">
                      <span className="w-7 h-7 rounded-full bg-[#1746A2]/30 flex items-center justify-center text-[#FFD447]">
                        <ChevronRight className="w-4 h-4" />
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* TAB 3: REELS (Vertical short video product feed) */}
        {activeTab === 'reels' && (
          <div className="h-full relative bg-black flex flex-col justify-between">
            {reels[activeReelIndex] ? (
              <div className="relative h-full flex flex-col justify-between overflow-hidden">
                {/* Reel Video Background */}
                <video
                  src={reels[activeReelIndex].videoUrl}
                  poster={reels[activeReelIndex].thumbnailUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover opacity-85"
                />

                {/* Top overlay */}
                <div className="relative z-10 p-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between text-white">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold tracking-wide uppercase text-[#FFD447]">PC Reels</span>
                    <span className="text-[10px] bg-red-600 px-1.5 py-0.2 rounded font-bold">LIVE</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveReelIndex((prev) => (prev > 0 ? prev - 1 : reels.length - 1))}
                      className="p-1 bg-black/50 rounded-full text-white text-xs"
                    >
                      ▲
                    </button>
                    <button
                      onClick={() => setActiveReelIndex((prev) => (prev < reels.length - 1 ? prev + 1 : 0))}
                      className="p-1 bg-black/50 rounded-full text-white text-xs"
                    >
                      ▼
                    </button>
                  </div>
                </div>

                {/* Right side interaction buttons */}
                <div className="absolute right-3 bottom-24 z-10 flex flex-col items-center gap-4 text-white">
                  <div className="flex flex-col items-center gap-1">
                    <button className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md flex items-center justify-center text-white active:scale-90 transition-transform">
                      <Heart className="w-5 h-5 text-red-500 fill-current" />
                    </button>
                    <span className="text-[10px] font-bold">{reels[activeReelIndex].likesCount}</span>
                  </div>

                  <div className="flex flex-col items-center gap-1">
                    <button className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md flex items-center justify-center text-white">
                      <Share2 className="w-5 h-5" />
                    </button>
                    <span className="text-[10px] font-bold">{reels[activeReelIndex].sharesCount}</span>
                  </div>

                  <div className="flex flex-col items-center gap-1">
                    <button
                      onClick={() => {
                        const targetProd = products.find((p) => p.id === reels[activeReelIndex].productId);
                        if (targetProd) setSelectedProduct(targetProd);
                      }}
                      className="w-10 h-10 rounded-full bg-[#FFD447] text-slate-950 flex items-center justify-center shadow-lg font-bold"
                    >
                      <ShoppingCart className="w-5 h-5" />
                    </button>
                    <span className="text-[9px] font-extrabold text-[#FFD447]">BUY</span>
                  </div>
                </div>

                {/* Bottom caption and linked product card */}
                <div className="relative z-10 p-3 pb-20 bg-gradient-to-t from-black via-black/70 to-transparent text-white space-y-2">
                  <div>
                    <span className="text-xs font-bold text-[#FFD447]">{reels[activeReelIndex].sellerName}</span>
                    <p className="text-xs text-slate-200 line-clamp-2 mt-0.5">{reels[activeReelIndex].caption}</p>
                  </div>

                  {/* Product quick-buy banner */}
                  <div
                    onClick={() => {
                      const prod = products.find((p) => p.id === reels[activeReelIndex].productId);
                      if (prod) setSelectedProduct(prod);
                    }}
                    className="bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-2 flex items-center justify-between cursor-pointer hover:border-[#FFD447]"
                  >
                    <div className="flex items-center gap-2">
                      <img
                        src={reels[activeReelIndex].productImage}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                      <div>
                        <h5 className="text-xs font-bold text-white truncate max-w-[170px]">
                          {reels[activeReelIndex].productTitle}
                        </h5>
                        <span className="text-xs font-extrabold text-[#FFD447]">
                          ₹{reels[activeReelIndex].productPrice}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const p = products.find((pr) => pr.id === reels[activeReelIndex].productId);
                        if (p) onAddToCart(p, p.selectedVariantId, 1);
                      }}
                      className="px-3 py-1 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-lg shadow"
                    >
                      Shop Now
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-slate-400">No reels available</div>
            )}
          </div>
        )}

        {/* TAB 4: WISHLIST */}
        {activeTab === 'wishlist' && (
          <div className="p-3 pb-20 space-y-3">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              My Wishlist ({wishlist.length})
            </h3>
            {wishlist.length === 0 ? (
              <div className="py-16 text-center text-slate-400 space-y-3">
                <Heart className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-xs">Your wishlist is empty.</p>
                <button
                  onClick={() => setActiveTab('home')}
                  className="px-4 py-2 bg-[#1746A2] text-white text-xs font-bold rounded-xl"
                >
                  Explore Premium Choice Mart
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5">
                {products
                  .filter((p) => wishlist.includes(p.id))
                  .map((product) => (
                    <div key={product.id} className="bg-slate-900 rounded-2xl p-2 border border-slate-800 space-y-2">
                      <img
                        src={product.images[0]}
                        alt=""
                        className="w-full aspect-square object-cover rounded-xl cursor-pointer"
                        onClick={() => setSelectedProduct(product)}
                      />
                      <div>
                        <h4 className="text-xs font-bold text-white truncate">{product.title}</h4>
                        <div className="flex items-baseline gap-1.5 mt-0.5">
                          <span className="text-xs font-black text-[#FFD447]">₹{product.price}</span>
                          <span className="text-[10px] text-slate-400 line-through">₹{product.mrp}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          onAddToCart(product, product.selectedVariantId, 1);
                          onToggleWishlist(product.id);
                        }}
                        className="w-full py-1.5 bg-[#1746A2] text-white text-[11px] font-bold rounded-xl"
                      >
                        Move to Cart
                      </button>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: CART & CHECKOUT */}
        {activeTab === 'cart' && (
          <div className="p-3 pb-24 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Shopping Cart ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h3>
              {cart.length > 0 && (
                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Eligible for Free Delivery
                </span>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="py-16 text-center text-slate-400 space-y-3">
                <ShoppingCart className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-xs">Your shopping cart is empty.</p>
                <button
                  onClick={() => setActiveTab('home')}
                  className="px-4 py-2 bg-[#1746A2] text-white text-xs font-bold rounded-xl"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Cart Items list */}
                <div className="space-y-2">
                  {cart.map((item) => (
                    <div
                      key={`${item.productId}_${item.variantId || ''}`}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-2xl flex gap-2.5 items-center justify-between"
                    >
                      <img
                        src={item.product.images[0]}
                        alt=""
                        className="w-14 h-14 rounded-xl object-cover shrink-0 cursor-pointer"
                        onClick={() => setSelectedProduct(item.product)}
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white truncate">{item.product.title}</h4>
                        {item.variantName && (
                          <span className="text-[10px] text-slate-400 block">{item.variantName}</span>
                        )}
                        <span className="text-xs font-black text-[#FFD447]">
                          ₹{item.priceAtAddition}
                        </span>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800">
                        <button
                          onClick={() => onUpdateCartQty(item.productId, item.variantId, item.quantity - 1)}
                          className="text-slate-400 hover:text-white"
                        >
                          {item.quantity === 1 ? <Trash2 className="w-3 h-3 text-red-400" /> : <Minus className="w-3 h-3" />}
                        </button>
                        <span className="text-xs font-bold text-white w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateCartQty(item.productId, item.variantId, item.quantity + 1)}
                          className="text-slate-400 hover:text-white"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Apply Coupon Box */}
                <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                    <Tag className="w-3.5 h-3.5 text-[#FFD447]" />
                    <span>Apply Coupon</span>
                  </div>

                  {appliedCoupon ? (
                    <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/40 p-2 rounded-xl text-xs text-emerald-400">
                      <div>
                        <span className="font-extrabold">{appliedCoupon.code}</span> applied!
                        <span className="block text-[10px] text-emerald-300">
                          {appliedCoupon.description} (You save ₹{cartDiscount})
                        </span>
                      </div>
                      <button
                        onClick={() => setAppliedCoupon(null)}
                        className="text-xs font-bold text-red-400 hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={couponInput}
                          onChange={(e) => setCouponInput(e.target.value)}
                          placeholder="Enter coupon code (e.g. PCFIRST200)"
                          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white uppercase placeholder:normal-case focus:outline-none focus:border-[#FFD447]"
                        />
                        <button
                          onClick={() => handleApplyCoupon()}
                          className="px-3 py-1.5 bg-[#FFD447] text-slate-950 font-bold text-xs rounded-xl"
                        >
                          Apply
                        </button>
                      </div>
                      {couponError && <p className="text-[10px] text-red-400">{couponError}</p>}
                      <div className="flex gap-1.5 pt-1">
                        <button
                          onClick={() => handleApplyCoupon('PCFIRST200')}
                          className="text-[10px] bg-slate-800 hover:bg-slate-700 text-[#FFD447] px-2 py-0.5 rounded font-mono"
                        >
                          PCFIRST200 (₹200 OFF)
                        </button>
                        <button
                          onClick={() => handleApplyCoupon('PREMIUM15')}
                          className="text-[10px] bg-slate-800 hover:bg-slate-700 text-[#FFD447] px-2 py-0.5 rounded font-mono"
                        >
                          PREMIUM15 (15% OFF)
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bill Details */}
                <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-2 text-xs">
                  <span className="font-bold text-white block">Price Summary</span>
                  <div className="flex justify-between text-slate-400">
                    <span>Items Total</span>
                    <span>₹{cartSubtotal}</span>
                  </div>
                  {cartDiscount > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Marketplace Discount</span>
                      <span>- ₹{cartDiscount}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-400">
                    <span>Delivery Fee</span>
                    <span>{deliveryFee === 0 ? <span className="text-emerald-400">FREE</span> : `₹${deliveryFee}`}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Platform Fee</span>
                    <span>₹{platformFee}</span>
                  </div>
                  <div className="border-t border-slate-800 pt-2 flex justify-between font-extrabold text-white text-sm">
                    <span>Total Amount</span>
                    <span className="text-[#FFD447]">₹{finalPayable}</span>
                  </div>
                </div>

                {/* Checkout Trigger Button */}
                <button
                  onClick={() => {
                    if (!currentCustomer) {
                      setShowLoginModal(true);
                      return;
                    }
                    setIsCheckingOut(true);
                    setCheckoutStep('address');
                  }}
                  className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-transform active:scale-98 flex items-center justify-center gap-2"
                >
                  Proceed to Checkout (₹{finalPayable}) <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 6: ORDERS & TRACKING */}
        {activeTab === 'orders' && (
          <div className="p-3 pb-20 space-y-3">
            {!currentCustomer ? (
              <div className="py-12 px-4 text-center bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#1746A2]/20 text-[#FFD447] mx-auto flex items-center justify-center border border-[#1746A2]/50">
                  <Phone className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-white">Log in to view your orders</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                    Enter your 10-digit mobile number to track shipments in real-time, view invoice details, and rate delivered items.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" /> Log In with Mobile OTP
                  </button>
                  <button
                    onClick={() => {
                      setCurrentCustomer(DEMO_CUSTOMERS[0]);
                      if (orders.length === 0 && onLoadSampleOrders) onLoadSampleOrders();
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors"
                  >
                    Use Demo Profile (Karan Sharma)
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider">
                      My Orders ({orders.length})
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Account: <strong className="text-white">{currentCustomer.name}</strong> • {currentCustomer.phone}
                    </span>
                  </div>
                  {orders.length > 0 && onLoadSampleOrders && (
                    <button
                      onClick={onLoadSampleOrders}
                      className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                    >
                      <Star className="w-3 h-3 fill-current" /> Reload Delivered Order
                    </button>
                  )}
                </div>

                {orders.length === 0 ? (
                  <div className="py-14 text-center text-slate-400 space-y-3 bg-slate-900/40 border border-slate-800/80 rounded-3xl p-6">
                    <Truck className="w-12 h-12 text-slate-600 mx-auto" />
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-white">No Orders Placed Yet</p>
                      <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                        Once an order is marked as <strong className="text-emerald-400 font-bold">DELIVERED</strong>, you can rate your purchased products and share verified customer reviews.
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-3">
                      <button
                        onClick={() => setActiveTab('home')}
                        className="px-4 py-2 bg-[#1746A2] hover:bg-blue-600 text-white text-xs font-bold rounded-xl shadow transition-colors"
                      >
                        Browse Catalog
                      </button>
                      {onLoadSampleOrders && (
                        <button
                          onClick={onLoadSampleOrders}
                          className="px-4 py-2 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-transform active:scale-95"
                        >
                          <Star className="w-3.5 h-3.5 fill-current" /> Load Demo Delivered Order (Test Reviews)
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
              <div className="space-y-3">
                {orders.map((ord) => (
                  <div key={ord.id} className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 shadow-sm">
                    <div className="flex items-center justify-between text-xs border-b border-slate-800/80 pb-2.5">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-white text-xs">{ord.orderNumber}</span>
                          {ord.status === 'DELIVERED' && (
                            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold">
                              Delivered
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          Placed on {new Date(ord.createdAt).toLocaleDateString()} • ₹{ord.totalAmount}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-extrabold flex items-center gap-1 ${
                            ord.status === 'DELIVERED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                              : ord.status === 'CANCELLED'
                              ? 'bg-red-950 text-red-400 border border-red-500/40'
                              : ord.status === 'SHIPPED'
                              ? 'bg-blue-950 text-blue-400 border border-blue-500/40'
                              : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                          }`}
                        >
                          {ord.status === 'DELIVERED' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                          {ord.status.replace(/_/g, ' ')}
                        </span>

                        {ord.status !== 'DELIVERED' && ord.status !== 'CANCELLED' && onUpdateOrderStatus && (
                          <button
                            onClick={() => onUpdateOrderStatus(ord.id, 'DELIVERED')}
                            className="text-[10px] bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded font-semibold flex items-center gap-1 transition-colors"
                            title="Click to simulate delivery and test product reviews"
                          >
                            <Truck className="w-3 h-3" /> Mark Delivered (Demo)
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Items in order */}
                    <div className="space-y-2.5">
                      {ord.items.map((item, idx) => {
                        const targetProd = products.find((p) => p.id === item.productId);
                        const userReview = targetProd?.reviews?.find(
                          (r) => r.userName === ord.customerName || r.userId === ord.customerId
                        );
                        const isDelivered = ord.status === 'DELIVERED';
                        const isItemReviewed = item.isReviewed || !!userReview;
                        const ratingGiven = item.reviewRating || userReview?.rating || 5;

                        return (
                          <div key={idx} className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80 space-y-2">
                            <div className="flex gap-2.5 items-center text-xs">
                              <img src={item.image} alt="" className="w-12 h-12 rounded-lg object-cover border border-slate-800 shrink-0" />
                              <div className="flex-1 min-w-0">
                                <span className="font-bold text-white truncate block">{item.title}</span>
                                {item.variantName && (
                                  <span className="text-[10px] text-slate-400 block">
                                    Option: {item.variantName}
                                  </span>
                                )}
                                <div className="flex items-center justify-between mt-0.5">
                                  <span className="text-[10px] text-slate-400">
                                    Qty: {item.quantity} • Seller: {item.sellerName}
                                  </span>
                                  <span className="text-xs font-black text-[#FFD447]">₹{item.totalPrice}</span>
                                </div>
                              </div>
                            </div>

                            {/* DELIVERED: Rate & Review controls */}
                            {isDelivered && (
                              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                                {isItemReviewed ? (
                                  <div className="flex items-center gap-2">
                                    <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-lg font-bold">
                                      <Check className="w-3 h-3 text-emerald-400" />
                                      Reviewed (★ {ratingGiven}/5)
                                    </span>
                                    <button
                                      onClick={() => handleOpenReviewModal(ord, item)}
                                      className="text-[10px] text-amber-400 hover:text-amber-300 underline font-semibold"
                                    >
                                      Edit Review
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => handleOpenReviewModal(ord, item)}
                                    className="px-3 py-1 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl shadow flex items-center gap-1.5 active:scale-95 transition-all"
                                  >
                                    <Star className="w-3.5 h-3.5 fill-current" /> Rate & Write Review
                                  </button>
                                )}

                                <button
                                  onClick={() => {
                                    if (targetProd) setSelectedProduct(targetProd);
                                  }}
                                  className="text-[10px] text-slate-400 hover:text-[#FFD447] flex items-center gap-0.5 font-medium transition-colors"
                                >
                                  Product Ratings <ChevronRight className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Courier and Milestone tracking */}
                    {ord.status !== 'CANCELLED' && (
                      <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 space-y-2">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400">Carrier: {ord.carrier || 'BlueDart Express'}</span>
                          <span className="font-mono text-white font-semibold">AWB: {ord.trackingNumber || 'BD-882910443'}</span>
                        </div>

                        {/* Milestone progress dots */}
                        <div className="pt-2">
                          <div className="flex items-center justify-between relative text-[9px] text-slate-400 font-bold">
                            <div className="flex flex-col items-center z-10">
                              <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-black">
                                ✓
                              </span>
                              <span className="mt-1 text-emerald-400">Confirmed</span>
                            </div>
                            <div className="flex flex-col items-center z-10">
                              <span
                                className={`w-4 h-4 rounded-full flex items-center justify-center ${
                                  ['PACKED', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'].includes(ord.status)
                                    ? 'bg-emerald-500 text-slate-950 font-black'
                                    : 'bg-slate-800 text-slate-500'
                                }`}
                              >
                                {['PACKED', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'].includes(ord.status) ? '✓' : '2'}
                              </span>
                              <span>Packed</span>
                            </div>
                            <div className="flex flex-col items-center z-10">
                              <span
                                className={`w-4 h-4 rounded-full flex items-center justify-center ${
                                  ['SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'].includes(ord.status)
                                    ? 'bg-emerald-500 text-slate-950 font-black'
                                    : 'bg-slate-800 text-slate-500'
                                }`}
                              >
                                {['SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'].includes(ord.status) ? '✓' : '3'}
                              </span>
                              <span>Shipped</span>
                            </div>
                            <div className="flex flex-col items-center z-10">
                              <span
                                className={`w-4 h-4 rounded-full flex items-center justify-center ${
                                  ord.status === 'DELIVERED'
                                    ? 'bg-emerald-500 text-slate-950 font-black'
                                    : 'bg-slate-800 text-slate-500'
                                }`}
                              >
                                {ord.status === 'DELIVERED' ? '✓' : '4'}
                              </span>
                              <span className={ord.status === 'DELIVERED' ? 'text-emerald-400 font-bold' : ''}>Delivered</span>
                            </div>
                            <div className="absolute top-2 left-3 right-3 h-0.5 bg-slate-800 -z-0"></div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Actions: Cancel or Return / Review */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      {['CONFIRMED', 'PACKED'].includes(ord.status) && (
                        <button
                          onClick={() => onCancelOrder(ord.id)}
                          className="flex-1 py-1.5 border border-red-500/40 text-red-400 hover:bg-red-500/10 text-xs font-bold rounded-xl transition-colors"
                        >
                          Cancel Order
                        </button>
                      )}
                      {ord.status === 'DELIVERED' && (
                        <div className="flex gap-2 w-full">
                          {ord.items.some((it) => !it.isReviewed) && (
                            <button
                              onClick={() => {
                                const unreviewed = ord.items.find((it) => !it.isReviewed) || ord.items[0];
                                handleOpenReviewModal(ord, unreviewed);
                              }}
                              className="flex-1 py-2 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black rounded-xl shadow flex items-center justify-center gap-1.5 transition-all"
                            >
                              <Star className="w-3.5 h-3.5 fill-current" /> Rate Delivered Product
                            </button>
                          )}
                          <button
                            onClick={() => {
                              const reason = prompt('Please describe reason for return (e.g. Size mismatch, defective):');
                              if (reason) onRequestReturn(ord.id, reason);
                            }}
                            className="py-2 px-3 border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-bold rounded-xl transition-colors"
                          >
                            Return / Refund
                          </button>
                        </div>
                      )}
                      {ord.status === 'RETURN_REQUESTED' && (
                        <span className="text-[11px] text-amber-400 font-medium">
                          Return request under review by PCMART Dispute Desk.
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
              </>
            )}
          </div>
        )}

        {/* TAB 7: PC ASSISTANT CHAT */}
        {activeTab === 'assistant' && (
          <div className="h-full flex flex-col justify-between pb-20">
            {/* Header */}
            <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#1746A2] flex items-center justify-center text-[#FFD447]">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-white">PC Shopping Assistant</h4>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Grounded in PCMART Catalog
                  </span>
                </div>
              </div>
              <button
                onClick={() =>
                  setChatMessages([
                    {
                      sender: 'assistant',
                      text: 'Namaste! I am your PC Assistant. Ask me anything in Hindi or English about our products, sizes, offers, or return policies!',
                      time: '10:42 AM',
                    },
                  ])
                }
                className="text-[10px] text-slate-400 hover:text-white"
              >
                Clear
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-[#1746A2] text-white rounded-br-xs'
                        : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-bl-xs'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[9px] text-slate-500 mt-1 px-1">{msg.time}</span>
                </div>
              ))}
              {isAssistantThinking && (
                <div className="flex items-center gap-1.5 text-xs text-[#FFD447] bg-slate-900 p-2.5 rounded-xl w-36 border border-slate-800">
                  <Sparkles className="w-3.5 h-3.5 animate-spin" /> Thinking...
                </div>
              )}
            </div>

            {/* Suggestions chips */}
            <div className="px-3 py-1 flex gap-1.5 overflow-x-auto no-scrollbar">
              <button
                onClick={() => {
                  setChatInput('Best wireless earbuds under 3000 with ANC?');
                }}
                className="text-[10px] bg-slate-900 text-slate-300 border border-slate-800 px-2 py-1 rounded-full whitespace-nowrap hover:border-[#FFD447]"
              >
                🎧 Best ANC Earbuds
              </button>
              <button
                onClick={() => {
                  setChatInput('What is PCMART return policy on clothes?');
                }}
                className="text-[10px] bg-slate-900 text-slate-300 border border-slate-800 px-2 py-1 rounded-full whitespace-nowrap hover:border-[#FFD447]"
              >
                🔄 7-day Return Rules
              </button>
              <button
                onClick={() => {
                  setChatInput('Kurta set sizing guide for Bust 38');
                }}
                className="text-[10px] bg-slate-900 text-slate-300 border border-slate-800 px-2 py-1 rounded-full whitespace-nowrap hover:border-[#FFD447]"
              >
                👗 Sizing Guide
              </button>
            </div>

            {/* Chat Input */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                placeholder="Ask in English or हिंदी..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FFD447]"
              />
              <button
                onClick={handleSendChatMessage}
                disabled={!chatInput.trim() || isAssistantThinking}
                className="p-2 bg-[#FFD447] text-slate-950 rounded-xl font-bold disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* PRODUCT DETAIL MODAL / SHEET */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-slate-900 w-full max-w-lg max-h-[92vh] sm:rounded-3xl rounded-t-3xl border border-slate-800 overflow-hidden flex flex-col animate-slideUp">
            {/* Sheet Header */}
            <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between sticky top-0 z-10">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1.5 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-bold text-white truncate max-w-[200px]">
                  {selectedProduct.title}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onToggleWishlist(selectedProduct.id)}
                  className="p-1.5 hover:bg-slate-800 rounded-full text-slate-400 hover:text-red-400"
                >
                  <Heart
                    className={`w-4 h-4 ${wishlist.includes(selectedProduct.id) ? 'text-red-500 fill-current' : ''}`}
                  />
                </button>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1.5 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Scrollable details */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              {/* Product Gallery */}
              <div className="aspect-[4/3] bg-slate-950 rounded-2xl overflow-hidden relative border border-slate-800">
                <img
                  src={selectedProduct.images[0]}
                  alt={selectedProduct.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-2 left-2 bg-[#FFD447] text-slate-950 font-black text-xs px-2 py-0.5 rounded shadow">
                  {selectedProduct.discountPercentage}% OFF
                </span>
              </div>

              {/* Title & Pricing */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#FFD447] tracking-wider uppercase">
                    {selectedProduct.brand} • {selectedProduct.category}
                  </span>
                  <span className="flex items-center gap-1 bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded font-bold">
                    <Star className="w-3 h-3 fill-current" /> {selectedProduct.rating} ({selectedProduct.ratingCount} reviews)
                  </span>
                </div>
                <h2 className="text-sm font-black text-white leading-tight">{selectedProduct.title}</h2>
                <p className="text-[11px] text-slate-300 italic">{selectedProduct.shortHook}</p>
                <div className="pt-1 flex items-baseline gap-2">
                  <span className="text-xl font-black text-white">₹{selectedProduct.price}</span>
                  <span className="text-xs text-slate-400 line-through">₹{selectedProduct.mrp}</span>
                  <span className="text-xs text-emerald-400 font-bold">
                    Save ₹{selectedProduct.mrp - selectedProduct.price}
                  </span>
                </div>
              </div>

              {/* Variants Selector */}
              {selectedProduct.variants && selectedProduct.variants.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <span className="font-bold text-white block">Select Option / Color:</span>
                  <div className="flex flex-wrap gap-2">
                    {selectedProduct.variants.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedProduct({ ...selectedProduct, selectedVariantId: v.id })}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                          selectedProduct.selectedVariantId === v.id
                            ? 'border-[#FFD447] bg-[#FFD447]/10 text-[#FFD447]'
                            : 'border-slate-800 bg-slate-950 text-slate-300'
                        }`}
                      >
                        {v.name} • ₹{v.price}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Pincode & Delivery Date checker */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <span className="font-bold text-white block">Check Delivery & COD Availability</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={deliveryPincode}
                    onChange={(e) => setDeliveryPincode(e.target.value)}
                    maxLength={6}
                    placeholder="Enter 6-digit Pincode"
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                  <button
                    onClick={() => setPincodeVerified(true)}
                    className="px-3 py-1.5 bg-[#1746A2] text-white font-bold text-xs rounded-xl"
                  >
                    Check
                  </button>
                </div>
                {pincodeVerified && (
                  <div className="space-y-1 text-[11px] text-slate-300 pt-1">
                    <p className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                      <Truck className="w-3.5 h-3.5" /> Express delivery in 2 business days to {deliveryPincode}
                    </p>
                    <p className="flex items-center gap-1.5 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#FFD447]" /> Cash on Delivery Available
                    </p>
                  </div>
                )}
              </div>

              {/* Gemini AI Review Sentiment Summary */}
              <div className="p-3 bg-gradient-to-r from-blue-950/40 to-slate-950 rounded-2xl border border-blue-900/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#FFD447]" />
                    <span className="font-bold text-white">Gemini Genuine Review Insights</span>
                  </div>
                  {aiReviewSummary && (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold">
                      {aiReviewSummary.authenticityScore}% Verified Authenticity
                    </span>
                  )}
                </div>

                {isLoadingReviewSummary ? (
                  <div className="py-3 text-center text-slate-400 flex items-center justify-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 animate-spin text-[#FFD447]" />
                    Analyzing customer sentiment...
                  </div>
                ) : aiReviewSummary ? (
                  <div className="space-y-2 text-[11px]">
                    <p className="text-slate-300">{aiReviewSummary.summary}</p>
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div className="bg-emerald-950/30 p-2 rounded-xl border border-emerald-900/40">
                        <span className="font-extrabold text-emerald-400 block mb-1">PROS:</span>
                        <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                          {aiReviewSummary.pros?.map((p: string, idx: number) => (
                            <li key={idx} className="truncate">{p}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-amber-950/30 p-2 rounded-xl border border-amber-900/40">
                        <span className="font-extrabold text-amber-400 block mb-1">NOTES:</span>
                        <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                          {aiReviewSummary.cons?.map((c: string, idx: number) => (
                            <li key={idx} className="truncate">{c}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>

              {/* Seller Information */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">Sold & Fulfilled By</span>
                  <span className="font-bold text-white text-xs">{selectedProduct.sellerName}</span>
                  <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold mt-0.5">
                    <ShieldCheck className="w-3 h-3" /> Verified Marketplace Merchant (★ {selectedProduct.sellerRating})
                  </div>
                </div>
                <div className="text-right text-[10px] text-slate-400">
                  <span>{selectedProduct.warranty}</span>
                  <span className="block text-[#FFD447] font-semibold">{selectedProduct.returnPolicy}</span>
                </div>
              </div>

                {/* Technical Specifications */}
                <div className="space-y-1.5 pt-2">
                  <span className="font-bold text-white block">Key Specifications:</span>
                  <div className="bg-slate-950 rounded-2xl border border-slate-800 divide-y divide-slate-800 text-[11px]">
                    {Object.entries((activeProduct || selectedProduct).specifications).map(([key, value]) => (
                      <div key={key} className="p-2.5 flex justify-between">
                        <span className="text-slate-400">{key}</span>
                        <span className="font-semibold text-white text-right">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Customer Ratings & Reviews Section */}
                <div className="space-y-3 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span>Customer Ratings & Reviews</span>
                      </h3>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Verified ratings from customer delivered orders
                      </span>
                    </div>
                    <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-2.5 py-1 rounded-xl font-black text-xs">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{(activeProduct || selectedProduct).rating.toFixed(1)} / 5</span>
                    </div>
                  </div>

                  {/* Rating Breakdown & Stats */}
                  {(() => {
                    const currentProd = activeProduct || selectedProduct;
                    const revs = currentProd.reviews || [];
                    const c5 = revs.filter((r) => r.rating === 5).length;
                    const c4 = revs.filter((r) => r.rating === 4).length;
                    const c3 = revs.filter((r) => r.rating === 3).length;
                    const c2 = revs.filter((r) => r.rating === 2).length;
                    const c1 = revs.filter((r) => r.rating === 1).length;
                    const total = revs.length || 1;

                    // Find if current customer ordered this product in a DELIVERED order
                    const userDeliveredOrder = orders.find(
                      (o) => o.status === 'DELIVERED' && o.items.some((it) => it.productId === currentProd.id)
                    );
                    const deliveredItem = userDeliveredOrder?.items.find((it) => it.productId === currentProd.id);

                    // Filter reviews
                    const filteredRevs = revs.filter((r) => {
                      if (reviewFilterRating === 'ALL') return true;
                      if (reviewFilterRating === 1) return r.rating <= 2;
                      return r.rating === reviewFilterRating;
                    });

                    return (
                      <div className="space-y-3">
                        {/* Rating Summary Card */}
                        <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                          <div className="grid grid-cols-5 gap-3 items-center">
                            {/* Left: Overall Score */}
                            <div className="col-span-2 text-center border-r border-slate-800 pr-2">
                              <span className="text-3xl font-black text-white block leading-none">
                                {currentProd.rating.toFixed(1)}
                              </span>
                              <div className="flex justify-center gap-0.5 text-amber-400 my-1.5">
                                {[1, 2, 3, 4, 5].map((s) => (
                                  <Star
                                    key={s}
                                    className={`w-3.5 h-3.5 ${
                                      s <= Math.round(currentProd.rating)
                                        ? 'fill-amber-400 text-amber-400'
                                        : 'text-slate-700'
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="text-[10px] text-slate-400 font-medium block">
                                {currentProd.ratingCount || revs.length} Total Ratings
                              </span>
                              <span className="text-[9px] text-emerald-400 font-semibold block mt-0.5">
                                100% Verified Buyers
                              </span>
                            </div>

                            {/* Right: Star Distribution Bars */}
                            <div className="col-span-3 space-y-1 text-[10px]">
                              {[
                                { star: 5, count: c5 },
                                { star: 4, count: c4 },
                                { star: 3, count: c3 },
                                { star: 2, count: c2 },
                                { star: 1, count: c1 },
                              ].map(({ star, count }) => {
                                const pct = Math.round((count / total) * 100);
                                return (
                                  <div key={star} className="flex items-center gap-1.5 text-slate-400">
                                    <span className="w-4 text-right font-bold text-slate-300">{star}★</span>
                                    <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                                      <div
                                        className={`h-full rounded-full transition-all duration-500 ${
                                          star >= 4
                                            ? 'bg-emerald-500'
                                            : star === 3
                                            ? 'bg-amber-400'
                                            : 'bg-red-500'
                                        }`}
                                        style={{ width: `${pct}%` }}
                                      ></div>
                                    </div>
                                    <span className="w-6 text-[9px] text-slate-500 text-right">{count}</span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Customer Verified Order Callout */}
                        {userDeliveredOrder && deliveredItem ? (
                          <div className="p-3 bg-gradient-to-r from-emerald-950/70 via-slate-900 to-slate-950 border border-emerald-500/40 rounded-2xl flex items-center justify-between gap-2 shadow-inner">
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                                <ShieldCheck className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <span className="font-extrabold text-white text-xs block truncate">
                                  You purchased this item
                                </span>
                                <span className="text-[10px] text-emerald-300 block truncate">
                                  Order #{userDeliveredOrder.orderNumber} (Delivered)
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => handleOpenReviewModal(userDeliveredOrder, deliveredItem)}
                              className="px-3 py-1.5 bg-gradient-to-r from-amber-400 to-[#FFD447] text-slate-950 font-black text-xs rounded-xl shadow shrink-0 active:scale-95 transition-all"
                            >
                              <Star className="w-3.5 h-3.5 fill-current inline mr-1" />
                              {deliveredItem.isReviewed ? 'Update Review' : 'Rate Product'}
                            </button>
                          </div>
                        ) : (
                          <div className="p-2.5 bg-slate-950/80 rounded-xl border border-slate-800/80 text-[10px] text-slate-400 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>
                                Genuine reviews can only be submitted after your order is <strong>DELIVERED</strong>.
                              </span>
                            </div>
                          </div>
                        )}

                        {/* Filter Chips */}
                        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                          <button
                            onClick={() => setReviewFilterRating('ALL')}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                              reviewFilterRating === 'ALL'
                                ? 'bg-[#FFD447] text-slate-950'
                                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                            }`}
                          >
                            All ({revs.length})
                          </button>
                          <button
                            onClick={() => setReviewFilterRating(5)}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                              reviewFilterRating === 5
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                            }`}
                          >
                            5 ★ ({c5})
                          </button>
                          <button
                            onClick={() => setReviewFilterRating(4)}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                              reviewFilterRating === 4
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                            }`}
                          >
                            4 ★ ({c4})
                          </button>
                          <button
                            onClick={() => setReviewFilterRating(3)}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                              reviewFilterRating === 3
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                            }`}
                          >
                            3 ★ ({c3})
                          </button>
                          <button
                            onClick={() => setReviewFilterRating(1)}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all ${
                              reviewFilterRating === 1
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                            }`}
                          >
                            1-2 ★ ({c2 + c1})
                          </button>
                        </div>

                        {/* Verified Reviews List */}
                        <div className="space-y-2.5 pt-1">
                          {filteredRevs.length === 0 ? (
                            <div className="p-6 text-center text-slate-400 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                              <MessageSquare className="w-8 h-8 text-slate-600 mx-auto" />
                              <p className="text-xs font-semibold text-slate-300">
                                No customer reviews in this category yet.
                              </p>
                              <p className="text-[10px] text-slate-500">
                                Be the first verified buyer to share feedback after your delivery!
                              </p>
                            </div>
                          ) : (
                            filteredRevs.map((rev) => {
                              const isHelpful = !!votedHelpfulReviews[rev.id];
                              const currentHelpful = rev.helpfulCount + (isHelpful ? 1 : 0);

                              return (
                                <div
                                  key={rev.id}
                                  className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 space-y-2 text-xs"
                                >
                                  {/* Reviewer Meta */}
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#1746A2] to-blue-500 text-white font-extrabold text-[11px] flex items-center justify-center uppercase">
                                        {rev.userName ? rev.userName.charAt(0) : 'U'}
                                      </div>
                                      <div>
                                        <span className="font-bold text-white text-[11px] block">
                                          {rev.userName}
                                        </span>
                                        <span className="text-[9px] text-slate-400">
                                          {rev.date}
                                        </span>
                                      </div>
                                    </div>

                                    {rev.verifiedPurchase && (
                                      <span className="flex items-center gap-1 text-[9px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                                        <Check className="w-3 h-3 text-emerald-400" /> Verified Buyer
                                      </span>
                                    )}
                                  </div>

                                  {/* Star Rating */}
                                  <div className="flex items-center gap-1">
                                    <div className="flex text-amber-400">
                                      {[1, 2, 3, 4, 5].map((s) => (
                                        <Star
                                          key={s}
                                          className={`w-3 h-3 ${
                                            s <= rev.rating
                                              ? 'fill-amber-400 text-amber-400'
                                              : 'text-slate-700'
                                          }`}
                                        />
                                      ))}
                                    </div>
                                    <span className="text-[10px] font-bold text-amber-400 ml-1">
                                      {rev.rating}.0
                                    </span>
                                  </div>

                                  {/* Title & Comment */}
                                  <div className="space-y-0.5">
                                    <h4 className="font-bold text-white text-xs">{rev.title}</h4>
                                    <p className="text-[11px] text-slate-300 leading-relaxed">
                                      {rev.comment}
                                    </p>
                                  </div>

                                  {/* Helpful feedback counter */}
                                  <div className="pt-1 flex items-center justify-between border-t border-slate-900 text-[10px] text-slate-400">
                                    <button
                                      onClick={() => handleToggleHelpful(rev.id)}
                                      className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-colors ${
                                        isHelpful
                                          ? 'bg-amber-400/20 text-amber-300 font-bold'
                                          : 'bg-slate-900 hover:bg-slate-800 text-slate-400'
                                      }`}
                                    >
                                      <ThumbsUp
                                        className={`w-3 h-3 ${
                                          isHelpful ? 'fill-current text-amber-400' : ''
                                        }`}
                                      />
                                      <span>Helpful ({currentHelpful})</span>
                                    </button>
                                    <span className="text-[9px] text-slate-500">
                                      Verified PCMART Order
                                    </span>
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

            {/* Sticky Bottom Actions */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex gap-2">
              <button
                onClick={() => {
                  onAddToCart(selectedProduct, selectedProduct.selectedVariantId, 1);
                  setSelectedProduct(null);
                }}
                className="flex-1 py-3 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow active:scale-98 transition-all flex items-center justify-center gap-1.5"
              >
                <ShoppingCart className="w-4 h-4" /> Add to Cart
              </button>
              <button
                onClick={() => {
                  onAddToCart(selectedProduct, selectedProduct.selectedVariantId, 1);
                  setSelectedProduct(null);
                  setActiveTab('cart');
                  setIsCheckingOut(true);
                  setCheckoutStep('address');
                }}
                className="flex-1 py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow active:scale-98 transition-all"
              >
                Buy Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CHECKOUT FLOW MODAL */}
      {isCheckingOut && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-slate-900 w-full max-w-md max-h-[90vh] sm:rounded-3xl rounded-t-3xl border border-slate-800 overflow-hidden flex flex-col animate-slideUp">
            {/* Header */}
            <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsCheckingOut(false)}
                  className="p-1 hover:bg-slate-800 rounded-full text-slate-400"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  {checkoutStep === 'address'
                    ? 'Step 1: Select Delivery Address'
                    : checkoutStep === 'payment'
                    ? 'Step 2: Approved Payment Gateway'
                    : 'Order Placed Successfully!'}
                </h3>
              </div>
              <button onClick={() => setIsCheckingOut(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              {checkoutStep === 'address' && (
                <div className="space-y-3">
                  <span className="font-bold text-white block">Saved Shipping Addresses</span>
                  {addresses.map((addr, idx) => (
                    <div
                      key={addr.id}
                      onClick={() => setSelectedAddressIndex(idx)}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                        selectedAddressIndex === idx
                          ? 'border-[#FFD447] bg-slate-800/80'
                          : 'border-slate-800 bg-slate-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-white">{addr.fullName}</span>
                        <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-semibold">
                          {addr.addressType}
                        </span>
                      </div>
                      <p className="text-slate-300 mt-1 text-[11px] leading-snug">
                        {addr.streetAddress}, {addr.landmark ? `${addr.landmark}, ` : ''}
                        {addr.city}, {addr.state} - {addr.pincode}
                      </p>
                      <span className="text-[10px] text-slate-400 mt-1 block">Phone: {addr.phoneNumber}</span>
                    </div>
                  ))}

                  <button
                    onClick={() => {
                      const newStreet = prompt('Enter street address:');
                      if (newStreet) {
                        setAddresses([
                          ...addresses,
                          {
                            id: `addr_${Date.now()}`,
                            fullName: 'Karan Sharma',
                            phoneNumber: '+91 98765 43210',
                            streetAddress: newStreet,
                            city: 'Mumbai',
                            state: 'Maharashtra',
                            pincode: '400053',
                            addressType: 'OTHER',
                            isDefault: false,
                          },
                        ]);
                      }
                    }}
                    className="w-full py-2 border border-dashed border-slate-700 hover:border-slate-500 rounded-xl text-slate-300 font-bold flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add New Address
                  </button>

                  <button
                    onClick={() => setCheckoutStep('payment')}
                    className="w-full py-3 bg-[#FFD447] text-slate-950 font-black text-xs rounded-xl shadow-lg mt-4"
                  >
                    Deliver to this Address
                  </button>
                </div>
              )}

              {checkoutStep === 'payment' && (
                <div className="space-y-3">
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Total Payable Amount</span>
                      <span className="text-base font-black text-[#FFD447]">₹{finalPayable}</span>
                    </div>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded font-bold">
                      256-Bit SSL Encrypted
                    </span>
                  </div>

                  <span className="font-bold text-white block">Select Approved Payment Method</span>

                  {/* Payment Option 1: UPI */}
                  <div
                    onClick={() => setSelectedPaymentMethod('UPI')}
                    className={`p-3 rounded-2xl border cursor-pointer flex items-center justify-between ${
                      selectedPaymentMethod === 'UPI'
                        ? 'border-[#FFD447] bg-slate-800'
                        : 'border-slate-800 bg-slate-950'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-purple-950 flex items-center justify-center text-purple-400 font-black text-xs">
                        UPI
                      </div>
                      <div>
                        <span className="font-bold text-white block">Instant UPI Payment</span>
                        <span className="text-[10px] text-slate-400">Google Pay, PhonePe, Paytm, BHIM</span>
                      </div>
                    </div>
                    <span className="text-[#FFD447] font-bold">
                      {selectedPaymentMethod === 'UPI' ? '●' : '○'}
                    </span>
                  </div>

                  {/* Payment Option 2: Cards */}
                  <div
                    onClick={() => setSelectedPaymentMethod('CARD')}
                    className={`p-3 rounded-2xl border cursor-pointer flex items-center justify-between ${
                      selectedPaymentMethod === 'CARD'
                        ? 'border-[#FFD447] bg-slate-800'
                        : 'border-slate-800 bg-slate-950'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-blue-950 flex items-center justify-center text-blue-400">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-bold text-white block">Credit / Debit Card</span>
                        <span className="text-[10px] text-slate-400">Visa, MasterCard, RuPay with OTP</span>
                      </div>
                    </div>
                    <span className="text-[#FFD447] font-bold">
                      {selectedPaymentMethod === 'CARD' ? '●' : '○'}
                    </span>
                  </div>

                  {/* Payment Option 3: COD */}
                  <div
                    onClick={() => setSelectedPaymentMethod('COD')}
                    className={`p-3 rounded-2xl border cursor-pointer flex items-center justify-between ${
                      selectedPaymentMethod === 'COD'
                        ? 'border-[#FFD447] bg-slate-800'
                        : 'border-slate-800 bg-slate-950'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-emerald-950 flex items-center justify-center text-emerald-400">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-bold text-white block">Cash on Delivery (Eligible)</span>
                        <span className="text-[10px] text-slate-400">Pay cash/UPI at doorstep upon delivery</span>
                      </div>
                    </div>
                    <span className="text-[#FFD447] font-bold">
                      {selectedPaymentMethod === 'COD' ? '●' : '○'}
                    </span>
                  </div>

                  <button
                    onClick={handleConfirmOrder}
                    disabled={isProcessingPayment}
                    className="w-full py-3 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg mt-4 flex items-center justify-center gap-2 disabled:opacity-60"
                  >
                    {isProcessingPayment ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                        Verifying Server Payment Signature...
                      </>
                    ) : (
                      `Pay & Place Order (₹${finalPayable})`
                    )}
                  </button>
                </div>
              )}

              {checkoutStep === 'success' && lastPlacedOrder && (
                <div className="py-6 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">Order Confirmed!</h3>
                    <p className="text-xs text-slate-300 mt-1 font-mono">
                      Order ID: {lastPlacedOrder.orderNumber}
                    </p>
                    <span className="text-[11px] text-emerald-400 block mt-1">
                      AWB #{lastPlacedOrder.trackingNumber} assigned via {lastPlacedOrder.carrier}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-left text-xs space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Delivery To:</span>
                      <span className="text-white font-semibold">{lastPlacedOrder.customerName}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Expected By:</span>
                      <span className="text-emerald-400 font-bold">{lastPlacedOrder.estimatedDeliveryDate}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Amount:</span>
                      <span className="text-[#FFD447] font-extrabold">₹{lastPlacedOrder.totalAmount}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setIsCheckingOut(false);
                      setActiveTab('orders');
                    }}
                    className="w-full py-3 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow"
                  >
                    View & Track Order
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* WRITE / EDIT PRODUCT REVIEW MODAL */}
      {reviewModalData && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-slate-900 w-full max-w-md max-h-[92vh] sm:rounded-3xl rounded-t-3xl border border-slate-800 overflow-hidden flex flex-col animate-slideUp shadow-2xl">
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center">
                  <Star className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-white uppercase tracking-wider">
                    Rate & Review Product
                  </h3>
                  <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Delivered Order #{reviewModalData.order.orderNumber}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setReviewModalData(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={handleSubmitReview} className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              {/* Product preview card */}
              <div className="flex gap-3 items-center bg-slate-950 p-3 rounded-2xl border border-slate-800">
                <img
                  src={reviewModalData.item.image}
                  alt={reviewModalData.item.title}
                  className="w-14 h-14 rounded-xl object-cover border border-slate-800 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-white text-xs truncate">
                    {reviewModalData.item.title}
                  </h4>
                  {reviewModalData.item.variantName && (
                    <span className="text-[10px] text-slate-400 block">
                      Option: {reviewModalData.item.variantName}
                    </span>
                  )}
                  <span className="text-[10px] text-slate-400 block">
                    Seller: {reviewModalData.item.sellerName}
                  </span>
                  <span className="text-[10px] font-bold text-emerald-400 mt-0.5 block flex items-center gap-1">
                    <Check className="w-3 h-3" /> Delivered Order Verified
                  </span>
                </div>
              </div>

              {/* Star Rating Picker */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-2">
                <span className="font-extrabold text-white text-xs uppercase tracking-wider block">
                  Select Rating (1 to 5 Stars)
                </span>
                <div className="flex items-center justify-center gap-2 py-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => setReviewRating(star)}
                      className="p-1 text-slate-700 hover:scale-125 transition-transform focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 transition-colors ${
                          (hoverRating || reviewRating) >= star
                            ? 'text-amber-400 fill-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                            : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <div className="text-xs font-bold text-amber-400">
                  {((hoverRating || reviewRating) === 5 && '★★★★★ 5.0 - Excellent! Exceeded Expectations') ||
                    ((hoverRating || reviewRating) === 4 && '★★★★☆ 4.0 - Very Good! Satisfied with Purchase') ||
                    ((hoverRating || reviewRating) === 3 && '★★★☆☆ 3.0 - Good / Average Experience') ||
                    ((hoverRating || reviewRating) === 2 && '★★☆☆☆ 2.0 - Fair / Below Expectations') ||
                    ((hoverRating || reviewRating) === 1 && '★☆☆☆☆ 1.0 - Poor / Did Not Meet Standards')}
                </div>
              </div>

              {/* Review Title Input */}
              <div className="space-y-1">
                <label className="font-bold text-white text-xs block">
                  Review Headline <span className="text-slate-400 font-normal">(Summary)</span>
                </label>
                <input
                  type="text"
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                  placeholder="E.g., Phenomenal sound quality & swift delivery!"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FFD447]"
                  required
                />
              </div>

              {/* Detailed Feedback Textarea */}
              <div className="space-y-1">
                <label className="font-bold text-white text-xs block">
                  Detailed Review <span className="text-slate-400 font-normal">(Your genuine feedback)</span>
                </label>
                <textarea
                  rows={4}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="Share details on build quality, battery, performance, comfort, or packaging..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FFD447] resize-none"
                  required
                />
              </div>

              {/* Verified Badge Notice */}
              <div className="p-3 bg-emerald-950/30 border border-emerald-900/50 rounded-xl flex items-center gap-2 text-[11px] text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Posting as <strong>{reviewModalData.order.customerName || 'Karan Sharma'}</strong>. Your review will display a <strong>Verified Buyer</strong> badge.
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReviewModalData(null)}
                  className="flex-1 py-2.5 border border-slate-800 hover:bg-slate-800 text-slate-300 font-bold text-xs rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-[#FFD447] hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 active:scale-98 transition-all"
                >
                  <Star className="w-3.5 h-3.5 fill-current" /> Post Verified Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FLOATING SUCCESS TOASTS */}
      {reviewToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-900 text-emerald-100 border border-emerald-500/50 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
          <span>{reviewToast}</span>
        </div>
      )}

      {loginToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#1746A2] text-white border border-[#FFD447]/60 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-[#FFD447] shrink-0" />
          <span>{loginToast}</span>
        </div>
      )}

      {/* CUSTOMER ACCOUNT & PROFILE DRAWER / MODAL */}
      {showAccountDrawer && currentCustomer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-slideUp">
            {/* Header */}
            <div className="bg-gradient-to-r from-[#1746A2] to-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={currentCustomer.avatar}
                  alt={currentCustomer.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#FFD447] shadow"
                />
                <div>
                  <h3 className="text-sm font-black text-white">{currentCustomer.name}</h3>
                  <div className="flex items-center gap-1 text-[11px] text-emerald-300 font-medium">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{currentCustomer.phone}</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[9px] px-1.5 py-0.5 rounded font-bold">
                      VERIFIED
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowAccountDrawer(false)}
                className="p-1.5 bg-black/30 hover:bg-black/50 text-white rounded-full transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Stats Grid */}
            <div className="p-4 grid grid-cols-3 gap-2 bg-slate-950/60 border-b border-slate-800 text-center">
              <div className="p-2.5 bg-slate-900/80 rounded-xl border border-slate-800/80">
                <span className="text-xs font-black text-[#FFD447] block">{orders.length}</span>
                <span className="text-[10px] text-slate-400">Total Orders</span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-xl border border-slate-800/80">
                <span className="text-xs font-black text-white block">{cart.length}</span>
                <span className="text-[10px] text-slate-400">In Cart</span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-xl border border-slate-800/80">
                <span className="text-xs font-black text-white block">{wishlist.length}</span>
                <span className="text-[10px] text-slate-400">Wishlist</span>
              </div>
            </div>

            {/* Account Details & Quick Switcher */}
            <div className="p-4 space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Quick Switch Customer Profile
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {DEMO_CUSTOMERS.map((cust) => (
                    <button
                      key={cust.id}
                      onClick={() => {
                        handleLoginSuccess(cust);
                        setShowAccountDrawer(false);
                      }}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 transition-all ${
                        currentCustomer.id === cust.id
                          ? 'border-[#FFD447] bg-[#FFD447]/10 text-white'
                          : 'border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <img src={cust.avatar} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />
                      <div className="truncate">
                        <span className="text-[11px] font-bold block truncate">{cust.name}</span>
                        <span className="text-[9px] text-slate-400 font-mono">+91 {cust.phone.slice(-10)}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Delivery Address Snapshot */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Default Delivery Address
                </span>
                <p className="text-white font-semibold text-xs">{addresses[0]?.fullName}</p>
                <p className="text-slate-400 text-[11px]">
                  {addresses[0]?.streetAddress}, {addresses[0]?.city} - {addresses[0]?.pincode}
                </p>
                <p className="text-slate-400 text-[10px] font-mono">Mobile: {addresses[0]?.phoneNumber}</p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <button
                  onClick={() => {
                    setShowAccountDrawer(false);
                    setShowLoginModal(true);
                  }}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-[#FFD447]" />
                  <span>Login with a Different Number</span>
                </button>

                <button
                  onClick={() => {
                    setShowAccountDrawer(false);
                    setShowApkModal(true);
                  }}
                  className="w-full py-2.5 bg-emerald-950/60 border border-emerald-500/40 hover:bg-emerald-900/60 text-emerald-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download / Build Android APK</span>
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full py-2.5 border border-red-500/40 hover:bg-red-500/10 text-red-400 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out of Account</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOMER MOBILE OTP LOGIN MODAL */}
      <CustomerLoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLoginSuccess={handleLoginSuccess}
        initialPhone={currentCustomer?.phone || ''}
      />

      {/* ANDROID APK DOWNLOAD MODAL */}
      <ApkDownloadModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
      />

      {/* ANDROID BOTTOM NAVIGATION BAR (Material 3 style) */}
      <div className="h-16 bg-slate-900 border-t border-slate-800/80 px-2 flex items-center justify-around shrink-0 z-30">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'home' ? 'text-[#FFD447] font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px]">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'categories' ? 'text-[#FFD447] font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span className="text-[10px]">Categories</span>
        </button>

        <button
          onClick={() => setActiveTab('reels')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all relative ${
            activeTab === 'reels' ? 'text-[#FFD447] font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Film className="w-4 h-4" />
          <span className="text-[10px]">Reels</span>
          <span className="absolute top-1 right-2 w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'orders' ? 'text-[#FFD447] font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span className="text-[10px]">Orders</span>
        </button>

        <button
          onClick={() => setActiveTab('assistant')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
            activeTab === 'assistant' ? 'text-[#FFD447] font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#FFD447]" />
          <span className="text-[10px]">Assistant</span>
        </button>
      </div>

      {/* Android 3-Button or Gesture Bar */}
      <div className="h-4 bg-slate-950 flex items-center justify-center shrink-0">
        <div className="w-28 h-1 bg-slate-600 rounded-full"></div>
      </div>
    </div>
  );

  // If activeViewMode === 'phone', frame inside an Android Phone device shell
  if (activeViewMode === 'phone') {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 bg-slate-950 overflow-y-auto">
        <div className="mb-3 flex items-center justify-between w-full max-w-[390px] text-xs text-slate-400 px-2">
          <span className="flex items-center gap-1.5 font-bold text-white">
            <Smartphone className="w-4 h-4 text-[#FFD447]" /> Google Pixel / Galaxy Android Simulator
          </span>
          <button
            onClick={onToggleViewMode}
            className="text-[11px] text-[#FFD447] hover:underline font-semibold flex items-center gap-1"
          >
            <Maximize2 className="w-3 h-3" /> Fullscreen View
          </button>
        </div>

        {/* Realistic Phone Bezel */}
        <div className="w-full max-w-[390px] h-[780px] bg-slate-900 rounded-[48px] p-2.5 shadow-2xl border-4 border-slate-700/80 relative ring-1 ring-white/10 flex flex-col">
          {/* Top Notch / Camera Cutout */}
          <div className="absolute top-5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-40 flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800"></div>
          </div>

          {/* Screen area with rounded corners */}
          <div className="flex-1 rounded-[38px] overflow-hidden flex flex-col relative bg-slate-950">
            {content}
          </div>
        </div>
      </div>
    );
  }

  // Fullscreen responsive web mode
  return <div className="flex-1 flex flex-col h-full overflow-hidden">{content}</div>;
};
