import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, BrickCategory, Order } from '../../types';
import { LiveTrackingMap } from './LiveTrackingMap';
import {
  Search,
  MapPin,
  Filter,
  Star,
  Truck,
  Building2,
  Store,
  ChevronRight,
  TrendingUp,
  Tag,
  ShieldCheck,
  Plus,
  Minus,
  ShoppingCart,
  CheckCircle2,
  Download,
  AlertTriangle,
  Phone,
  HelpCircle,
  CreditCard,
  Layers,
  ArrowRight,
  Calendar,
  Wallet,
  Clock,
  FileText,
  Factory
} from 'lucide-react';

export const CustomerApp: React.FC<{
  openCartDirectly?: boolean;
  onCloseCartDirectly?: () => void;
}> = ({ openCartDirectly, onCloseCartDirectly }) => {
  const {
    t,
    customerTab,
    setCustomerTab,
    selectedProductId,
    setSelectedProductId,
    trackingOrderId,
    setTrackingOrderId,
    selectedOrderForDetails,
    setSelectedOrderForDetails,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartTotalAmount,
    products,
    orders,
    createOrder,
    advanceOrderStage,
    walletBalance,
    addMoneyToWallet,
    currentUser,
    setInvoiceModalOrderId,
    setComplaintModalOrderId,
    language,
    setLanguage
  } = useApp();

  // Search & Filter state (Screen 08)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<BrickCategory | 'All'>('All');
  const [maxPrice, setMaxPrice] = useState<number>(50000);
  const [sortBy, setSortBy] = useState<'rating' | 'priceAsc' | 'priceDesc'>('rating');

  // Checkout modal / screen state (Screen 11)
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutDate, setCheckoutDate] = useState('2026-09-22');
  const [transportFleet, setTransportFleet] = useState<
    '10-Wheeler Heavy Truck' | '6-Wheeler Dumper' | 'Tractor Trolley' | 'Mini Commercial Pickup'
  >('10-Wheeler Heavy Truck');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'Net Banking' | 'Pay on Delivery'>('UPI');
  const [orderConfirmedData, setOrderConfirmedData] = useState<Order | null>(null);

  // Orders tab filter (Screen 14)
  const [ordersSubTab, setOrdersSubTab] = useState<'Active' | 'Completed' | 'Cancelled'>('Active');

  // Product detail item (Screen 09)
  const activeProduct = products.find((p) => p.id === selectedProductId) || null;
  const [detailQtyThousand, setDetailQtyThousand] = useState<number>(4);

  // Active tracking order (Screen 13)
  const activeTrackingOrder = orders.find((o) => o.id === trackingOrderId) || orders[0];

  // Active details order (Screen 15)
  const activeDetailsOrder = orders.find((o) => o.id === selectedOrderForDetails) || null;

  // Categories list for Screen 07 & 08
  const categories: { label: BrickCategory; desc: string; icon: string }[] = [
    { label: '1st Class Brick', desc: 'Wirecut Kiln Heavy Duty', icon: '🧱' },
    { label: '2nd Class Brick', desc: 'Standard Red Brick', icon: '🏗️' },
    { label: 'Fly Ash Brick', desc: 'Steam-Cured Eco Certified', icon: '🌱' },
    { label: 'Concrete Block', desc: 'AAC Lightweight Blocks', icon: '🏢' },
    { label: 'Building Materials', desc: 'River Sand & Stone Aggregates', icon: '⏳' },
    { label: 'Transport', desc: 'Heavy Haulage Vehicles', icon: '🚛' }
  ];

  // Filtered products logic
  const filteredProducts = products.filter((product) => {
    if (selectedCategory !== 'All' && product.brickType !== selectedCategory) return false;
    if (product.pricePerThousand > maxPrice) return false;
    if (
      searchQuery &&
      !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.manufacturerName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.brickType.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  }).sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'priceAsc') return a.pricePerThousand - b.pricePerThousand;
    if (sortBy === 'priceDesc') return b.pricePerThousand - a.pricePerThousand;
    return 0;
  });

  // Calculate cart freight & tax
  const transportCharge = cart.length > 0 ? 3800 : 0;
  const discountAmount = cart.length > 0 ? 1000 : 0;
  const gstAmount = Math.round((cartTotalAmount * 5) / 100);
  const finalPayable = Math.max(0, cartTotalAmount + transportCharge + gstAmount - discountAmount);

  const handlePlaceOrder = () => {
    if (cart.length === 0) return;
    const items = cart.map((item) => ({
      productId: item.product.id,
      productName: item.product.name,
      brickType: item.product.brickType,
      quantityThousand: item.quantityThousand,
      unitPrice: item.product.pricePerThousand,
      totalProductPrice: item.quantityThousand * item.product.pricePerThousand
    }));

    const primaryProduct = cart[0].product;

    const newOrderId = createOrder({
      items,
      productTotal: cartTotalAmount,
      transportCharge,
      discount: discountAmount,
      gstAmount,
      totalAmount: finalPayable,
      paymentMethod,
      manufacturerId: primaryProduct.manufacturerId,
      manufacturerName: primaryProduct.manufacturerName,
      vehicleType: transportFleet,
      deliveryDate: checkoutDate
    });

    const placedOrder = orders.find((o) => o.id === newOrderId);
    setOrderConfirmedData(placedOrder || {
      id: newOrderId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerMobile: currentUser.mobile,
      deliveryAddress: currentUser.address,
      deliveryPinCode: currentUser.pinCode,
      deliveryDate: checkoutDate,
      items,
      productTotal: cartTotalAmount,
      transportCharge,
      discount: discountAmount,
      gstAmount,
      totalAmount: finalPayable,
      paymentMethod,
      paymentStatus: 'Paid',
      orderStatus: 'Order Confirmed',
      manufacturerId: primaryProduct.manufacturerId,
      manufacturerName: primaryProduct.manufacturerName,
      vehicleType: transportFleet,
      deliveryOtp: '891024',
      createdAt: 'Just now'
    });

    clearCart();
    setIsCheckingOut(false);
  };

  return (
    <div className="min-h-[calc(100vh-110px)] pb-20 sm:pb-8">
      {/* =========================================================================
          SCREEN 12: ORDER CONFIRMATION MODAL / OVERLAY
      ========================================================================= */}
      {orderConfirmedData && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-md bg-[#161c26] border border-[#2e3b4e] rounded-2xl p-6 text-slate-100 shadow-2xl relative">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="text-center mb-6">
              <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-widest">
                Screen 12 • Order Confirmation
              </span>
              <h2 className="text-2xl font-black text-white mt-1">
                {t('orderConfirmation')}!
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Booking registered on Brick Exchange ledger
              </p>
            </div>

            <div className="p-4 bg-[#11161f] border border-[#232d3d] rounded-xl space-y-2.5 text-xs mb-6">
              <div className="flex justify-between pb-2 border-b border-[#1f2736]">
                <span className="text-slate-400">Order ID:</span>
                <span className="font-mono font-bold text-amber-400">
                  {orderConfirmedData.id}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Products:</span>
                <span className="font-semibold text-slate-200 text-right max-w-[200px] truncate">
                  {orderConfirmedData.items[0]?.productName}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Quantity:</span>
                <span className="font-bold text-white">
                  {orderConfirmedData.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Assigned Fleet:</span>
                <span className="font-medium text-slate-300">{orderConfirmedData.vehicleType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Site Address:</span>
                <span className="text-slate-300 text-right max-w-[180px] truncate">
                  {orderConfirmedData.deliveryAddress}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#1f2736] text-sm">
                <span className="font-bold text-slate-200">Amount Paid:</span>
                <span className="font-extrabold text-emerald-400">
                  ₹{orderConfirmedData.totalAmount.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                id="track-order-now-btn"
                onClick={() => {
                  setTrackingOrderId(orderConfirmedData.id);
                  setOrderConfirmedData(null);
                  setCustomerTab('orders');
                }}
                className="w-full py-3 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/25"
              >
                <Truck className="w-4 h-4" />
                <span>Track Live Delivery on Map</span>
              </button>
              <button
                id="close-confirmation-btn"
                onClick={() => setOrderConfirmedData(null)}
                className="w-full py-2.5 bg-[#1f2735] hover:bg-[#273244] text-slate-300 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Back to Marketplace
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 11: CHECKOUT MODAL
      ========================================================================= */}
      {isCheckingOut && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-[#161c26] border border-[#2e3b4e] rounded-2xl p-6 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#242f3e] mb-5">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-wider">
                  Screen 11 • Final Step
                </span>
                <h3 className="text-xl font-bold text-white">{t('checkout')}</h3>
              </div>
              <button
                id="cancel-checkout-btn"
                onClick={() => setIsCheckingOut(false)}
                className="p-1 rounded-lg hover:bg-[#202937] text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* Delivery address */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#e55938]" />
                <span>Delivery Construction Site Address</span>
              </label>
              <div className="p-3 bg-[#111620] border border-[#232e3d] rounded-xl text-xs text-slate-200">
                <p className="font-semibold text-white">{currentUser.name}</p>
                <p className="text-slate-400 mt-0.5">{currentUser.address}</p>
                <p className="text-slate-400">PIN: {currentUser.pinCode} • Ph: {currentUser.mobile}</p>
              </div>
            </div>

            {/* Preferred Delivery Date */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>{t('deliveryDate')}</span>
              </label>
              <input
                id="checkout-delivery-date"
                type="date"
                value={checkoutDate}
                onChange={(e) => setCheckoutDate(e.target.value)}
                className="w-full bg-[#111620] border border-[#243041] rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-[#e55938] outline-none"
              />
            </div>

            {/* Transport Option Selection */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-blue-400" />
                <span>{t('transportOption')}</span>
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { type: '10-Wheeler Heavy Truck' as const, cap: 'Up to 6,000 Bricks', tag: 'Fastest' },
                  { type: '6-Wheeler Dumper' as const, cap: 'Up to 3,500 Bricks', tag: 'Narrow Roads' },
                  { type: 'Tractor Trolley' as const, cap: 'Up to 2,000 Bricks', tag: 'Rural / Semi-urban' },
                  { type: 'Mini Commercial Pickup' as const, cap: 'Up to 1,000 Bricks', tag: 'Express' }
                ].map((vehicle) => (
                  <button
                    key={vehicle.type}
                    id={`transport-${vehicle.type}`}
                    onClick={() => setTransportFleet(vehicle.type)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      transportFleet === vehicle.type
                        ? 'bg-[#e55938]/15 border-[#e55938] text-white'
                        : 'bg-[#121722] border-[#222c3b] text-slate-300 hover:bg-[#18202d]'
                    }`}
                  >
                    <div className="font-bold text-[11px] truncate">{vehicle.type}</div>
                    <div className="text-[10px] text-slate-400">{vehicle.cap}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="mb-6">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                <span>{t('paymentMethod')}</span>
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { method: 'UPI' as const, desc: 'GPay / PhonePe / QR Code' },
                  { method: 'Card' as const, desc: 'Corporate / Commercial Card' },
                  { method: 'Net Banking' as const, desc: 'Direct RTGS / NEFT / IMPS' },
                  { method: 'Pay on Delivery' as const, desc: 'Pay 10% advance + site check' }
                ].map((pay) => (
                  <button
                    key={pay.method}
                    id={`pay-${pay.method}`}
                    onClick={() => setPaymentMethod(pay.method)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentMethod === pay.method
                        ? 'bg-emerald-500/15 border-emerald-500 text-white'
                        : 'bg-[#121722] border-[#222c3b] text-slate-300 hover:bg-[#18202d]'
                    }`}
                  >
                    <div className="font-bold text-[11px]">{pay.method}</div>
                    <div className="text-[10px] text-slate-400">{pay.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Price calculation overview */}
            <div className="p-3.5 bg-[#10141d] border border-[#232e3e] rounded-xl space-y-1.5 text-xs text-slate-300 mb-6">
              <div className="flex justify-between">
                <span>Total Bricks Value:</span>
                <span className="font-medium text-white">₹{cartTotalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Haulage & Driver Freight:</span>
                <span className="text-white">₹{transportCharge.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-emerald-400">
                <span>Contractor Bulk Discount:</span>
                <span>-₹{discountAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>GST Tax (5%):</span>
                <span>₹{gstAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#232e3e] text-sm font-bold text-white">
                <span>Total Payable:</span>
                <span className="text-[#e55938] font-extrabold">₹{finalPayable.toLocaleString()}</span>
              </div>
            </div>

            <button
              id="confirm-checkout-btn"
              onClick={handlePlaceOrder}
              className="w-full py-3.5 bg-[#e55938] hover:bg-[#d44827] text-white font-extrabold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-[#e55938]/25 text-sm"
            >
              <span>{t('confirmOrder')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 09: PRODUCT DETAILS VIEW
      ========================================================================= */}
      {selectedProductId && activeProduct && (
        <div className="max-w-4xl mx-auto px-4 py-4">
          <button
            id="back-to-products-btn"
            onClick={() => setSelectedProductId(null)}
            className="mb-4 text-xs font-semibold text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            ← Back to Marketplace
          </button>

          <div className="bg-[#151b24] border border-[#263242] rounded-2xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2">
            {/* Photos gallery */}
            <div className="p-5 flex flex-col justify-between bg-[#10141c]">
              <div className="rounded-xl overflow-hidden border border-[#273344] mb-3 aspect-[4/3] bg-black">
                <img
                  src={activeProduct.photos[0]}
                  alt={activeProduct.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              {activeProduct.photos[1] && (
                <div className="grid grid-cols-2 gap-2">
                  <img
                    src={activeProduct.photos[0]}
                    alt="thumbnail 1"
                    className="h-16 w-full object-cover rounded-lg border-2 border-[#e55938]"
                    referrerPolicy="no-referrer"
                  />
                  <img
                    src={activeProduct.photos[1]}
                    alt="thumbnail 2"
                    className="h-16 w-full object-cover rounded-lg border border-[#273344] opacity-80"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
            </div>

            {/* Product details */}
            <div className="p-6 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#e55938]/15 text-[#f8714e] border border-[#e55938]/30">
                    {activeProduct.brickType}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-amber-400 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{activeProduct.rating}</span>
                    <span className="text-slate-400 font-normal">({activeProduct.reviewCount} reviews)</span>
                  </div>
                </div>

                <h2 className="text-xl font-extrabold text-white leading-snug mb-2">
                  {activeProduct.name}
                </h2>

                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-2xl font-black text-white">
                    ₹{activeProduct.pricePerThousand.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400">/ 1,000 Bricks</span>
                </div>

                {/* Specs table */}
                <div className="space-y-2 p-3.5 bg-[#10151f] border border-[#232d3d] rounded-xl text-xs mb-5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Dimensions:</span>
                    <span className="font-semibold text-slate-200">{activeProduct.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Quality Grade:</span>
                    <span className="font-semibold text-emerald-400">{activeProduct.quality}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Available Kiln Stock:</span>
                    <span className="font-semibold text-white">
                      {activeProduct.availableStockThousand}k Bricks
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Minimum Order:</span>
                    <span className="font-semibold text-slate-200">
                      {activeProduct.minOrderThousand}k Bricks
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Kiln Manufacturer:</span>
                    <span className="font-semibold text-amber-400">
                      {activeProduct.manufacturerName}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Delivery Radius:</span>
                    <span className="text-slate-300">Within {activeProduct.deliveryAreaRadiusKm} km</span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-6">
                  {activeProduct.description}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-[#232f3f] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">Select Quantity:</span>
                  <div className="flex items-center gap-3 bg-[#18202c] border border-[#2a3648] rounded-xl p-1">
                    <button
                      id="decrease-qty-btn"
                      onClick={() =>
                        setDetailQtyThousand((q) => Math.max(activeProduct.minOrderThousand, q - 1))
                      }
                      className="p-1.5 rounded-lg hover:bg-[#253245] text-slate-300"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-bold text-sm text-white px-2">
                      {detailQtyThousand}k ({detailQtyThousand * 1000} bricks)
                    </span>
                    <button
                      id="increase-qty-btn"
                      onClick={() => setDetailQtyThousand((q) => q + 1)}
                      className="p-1.5 rounded-lg hover:bg-[#253245] text-slate-300"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    id="add-to-cart-detail-btn"
                    onClick={() => {
                      addToCart(activeProduct, detailQtyThousand);
                      setSelectedProductId(null);
                    }}
                    className="py-3 px-4 bg-[#1f2837] hover:bg-[#283548] border border-[#34445c] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ShoppingCart className="w-4 h-4 text-emerald-400" />
                    <span>{t('addToCart')}</span>
                  </button>
                  <button
                    id="buy-now-detail-btn"
                    onClick={() => {
                      addToCart(activeProduct, detailQtyThousand);
                      setSelectedProductId(null);
                      setIsCheckingOut(true);
                    }}
                    className="py-3 px-4 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20"
                  >
                    <span>{t('buyNow')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 10: CART DRAWER / VIEW
      ========================================================================= */}
      {(openCartDirectly || (customerTab as string) === 'cart_screen') && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-md bg-[#161c26] h-full flex flex-col border-l border-[#293547] p-5 shadow-2xl animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between pb-4 border-b border-[#242f3e] mb-4">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-400" />
                <h3 className="text-lg font-bold text-white">{t('cart')}</h3>
              </div>
              <button
                id="close-cart-btn"
                onClick={onCloseCartDirectly}
                className="p-1.5 rounded-lg hover:bg-[#222c3b] text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                <div className="w-16 h-16 rounded-2xl bg-[#1c2431] flex items-center justify-center text-slate-400 mb-4 border border-[#2a374a]">
                  <ShoppingCart className="w-8 h-8 opacity-40" />
                </div>
                <h4 className="text-base font-bold text-white mb-1">Your Cart is Empty</h4>
                <p className="text-xs text-slate-400 mb-6">
                  Browse verified kiln batches and add bricks to schedule delivery
                </p>
                <button
                  id="cart-browse-btn"
                  onClick={onCloseCartDirectly}
                  className="px-4 py-2 bg-[#e55938] text-white font-bold text-xs rounded-xl"
                >
                  Browse Bricks
                </button>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="p-3.5 bg-[#121721] border border-[#243041] rounded-xl flex gap-3 text-xs"
                    >
                      <img
                        src={item.product.photos[0]}
                        alt={item.product.name}
                        className="w-16 h-16 rounded-lg object-cover border border-[#2b384c] shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-bold text-white text-xs leading-snug">
                            {item.product.name}
                          </h4>
                          <button
                            id={`remove-cart-${item.product.id}`}
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-slate-400 hover:text-rose-400 text-xs ml-1"
                          >
                            ✕
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {item.product.manufacturerName}
                        </p>
                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#1f2837]">
                          <span className="font-bold text-amber-400">
                            ₹{(item.quantityThousand * item.product.pricePerThousand).toLocaleString()}
                          </span>
                          <div className="flex items-center gap-2 bg-[#1b2330] rounded-lg px-2 py-0.5 border border-[#293649]">
                            <button
                              id={`cart-minus-${item.product.id}`}
                              onClick={() => updateCartQuantity(item.product.id, item.quantityThousand - 1)}
                              className="text-slate-400 hover:text-white"
                            >
                              -
                            </button>
                            <span className="font-bold text-white">{item.quantityThousand}k</span>
                            <button
                              id={`cart-plus-${item.product.id}`}
                              onClick={() => updateCartQuantity(item.product.id, item.quantityThousand + 1)}
                              className="text-slate-400 hover:text-white"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Price Breakdown */}
                <div className="pt-4 border-t border-[#242f3e] space-y-2 text-xs text-slate-300 mb-4">
                  <div className="flex justify-between">
                    <span>Bricks Subtotal:</span>
                    <span className="font-semibold text-white">₹{cartTotalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Transport Freight:</span>
                    <span className="text-white">₹{transportCharge.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Volume Rebate:</span>
                    <span>-₹{discountAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (5%):</span>
                    <span>₹{gstAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#242f3e] text-sm font-bold text-white">
                    <span>{t('total')}:</span>
                    <span className="text-[#e55938] font-extrabold">₹{finalPayable.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  id="proceed-checkout-btn"
                  onClick={() => {
                    if (onCloseCartDirectly) onCloseCartDirectly();
                    setIsCheckingOut(true);
                  }}
                  className="w-full py-3.5 bg-[#e55938] hover:bg-[#d44827] text-white font-extrabold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20 text-xs uppercase tracking-wider"
                >
                  <span>{t('proceedCheckout')}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MAIN TAB 1: HOME DASHBOARD (Screen 07)
      ========================================================================= */}
      {customerTab === 'home' && !selectedProductId && (
        <div className="max-w-7xl mx-auto px-4 py-5 space-y-6">
          {/* Top Location & Search Bar */}
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-slate-300 bg-[#151b24] border border-[#273343] px-3 py-2 rounded-xl">
              <MapPin className="w-4 h-4 text-[#e55938] shrink-0" />
              <div className="truncate">
                <span className="text-slate-400">Delivering to:</span>{' '}
                <strong className="text-white font-semibold">{currentUser.address}</strong>
              </div>
            </div>

            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="home-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full bg-[#151b24] border border-[#273343] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:border-[#e55938] outline-none"
              />
            </div>
          </div>

          {/* Today's Market Price Banner (Screen 07 Card) */}
          <div className="bg-gradient-to-r from-[#1c2330] via-[#1a202c] to-[#171c26] border border-[#2a3648] rounded-2xl p-4 sm:p-5 relative overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>{t('todayPrice')} (Bengal-Bihar Kiln Corridor)</span>
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Spot Rates: 1st Class Wirecut @ ₹9,400 | Fly Ash @ ₹6,100
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Direct ex-kiln pricing with guaranteed vehicle haulage to site.
                </p>
              </div>
              <button
                id="explore-products-btn"
                onClick={() => setCustomerTab('products')}
                className="px-4 py-2.5 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-[#e55938]/20 transition-all cursor-pointer"
              >
                <span>View Full Catalog</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Categories Grid (Screen 07 Specification) */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                Core Material Categories
              </h3>
              <button
                id="view-all-categories-btn"
                onClick={() => {
                  setSelectedCategory('All');
                  setCustomerTab('products');
                }}
                className="text-xs text-[#f8714e] hover:underline"
              >
                View All →
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  id={`cat-btn-${cat.label.replace(/\s+/g, '-')}`}
                  onClick={() => {
                    setSelectedCategory(cat.label);
                    setCustomerTab('products');
                  }}
                  className="p-3.5 bg-[#141a24] hover:bg-[#1b2330] border border-[#253142] hover:border-[#e55938]/50 rounded-xl text-left transition-all cursor-pointer group flex flex-col justify-between min-h-[90px]"
                >
                  <div className="text-2xl mb-1">{cat.icon}</div>
                  <div>
                    <h4 className="font-bold text-xs text-white group-hover:text-[#f8714e] transition-colors leading-tight">
                      {cat.label}
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5 truncate">{cat.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Special Construction Bulk Offers (Screen 07 Card) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#181f2b] border border-[#293649] rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px] uppercase">
                  Contractor Deal
                </span>
                <h4 className="font-bold text-white text-sm mt-1.5">
                  Order 10,000+ Bricks — Free Freight within 25 km
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct loading from Maa Tara & Royal Fly Ash bhattas.
                </p>
              </div>
              <Tag className="w-8 h-8 text-emerald-400 shrink-0 ml-3 opacity-80" />
            </div>

            <div className="bg-[#181f2b] border border-[#293649] rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px] uppercase">
                  Fly-Ash Promo
                </span>
                <h4 className="font-bold text-white text-sm mt-1.5">
                  Save 20% on Mortar with Certified Fly-Ash Bricks
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  IS 12894 certified with compressive strength &gt; 9 N/mm².
                </p>
              </div>
              <ShieldCheck className="w-8 h-8 text-amber-400 shrink-0 ml-3 opacity-80" />
            </div>
          </div>

          {/* Featured Kiln Batches / Large Product Cards (Screen 07 & 16 Design Style) */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                {t('nearbyManufacturers')}
              </h3>
              <span className="text-xs text-slate-400">Showing verified bhatta dispatches</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.slice(0, 3).map((prod) => (
                <div
                  key={prod.id}
                  className="bg-[#141a24] border border-[#263345] rounded-2xl overflow-hidden hover:border-[#e55938]/60 transition-all flex flex-col justify-between shadow-lg"
                >
                  <div className="relative aspect-[16/10] bg-black">
                    <img
                      src={prod.photos[0]}
                      alt={prod.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-md bg-black/75 backdrop-blur-md text-[11px] font-bold text-[#f8714e] border border-white/10">
                      {prod.brickType}
                    </div>
                    <div className="absolute top-2.5 right-2.5 px-2 py-1 rounded-md bg-black/75 backdrop-blur-md text-[11px] font-bold text-amber-400 flex items-center gap-1 border border-white/10">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{prod.rating}</span>
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm leading-snug line-clamp-2">
                        {prod.name}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                        <Factory className="w-3.5 h-3.5 text-amber-400" />
                        <span className="truncate">{prod.manufacturerName}</span>
                      </p>

                      <div className="mt-3 flex items-center justify-between text-xs text-slate-300 pt-2 border-t border-[#202a39]">
                        <span>Available Stock:</span>
                        <span className="font-bold text-emerald-400">
                          {prod.availableStockThousand}k Bricks
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#202a39] flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase">Rate per 1k</span>
                        <div className="text-base font-black text-white">
                          ₹{prod.pricePerThousand.toLocaleString()}
                        </div>
                      </div>

                      <button
                        id={`view-prod-${prod.id}`}
                        onClick={() => setSelectedProductId(prod.id)}
                        className="px-3 py-1.5 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <span>Details</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MAIN TAB 2: PRODUCT SEARCH & CATALOG (Screen 08)
      ========================================================================= */}
      {customerTab === 'products' && !selectedProductId && (
        <div className="max-w-7xl mx-auto px-4 py-5 space-y-6">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-wider">
                Screen 08 • Marketplace Catalog
              </span>
              <h2 className="text-xl font-bold text-white">
                Brick Batches & Building Materials
              </h2>
            </div>

            {/* Quick Filters */}
            <div className="flex flex-wrap items-center gap-2">
              <select
                id="filter-category"
                aria-label="Filter by Category"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as any)}
                className="bg-[#171e29] border border-[#2c384a] text-slate-200 text-xs rounded-xl px-3 py-2 outline-none"
              >
                <option value="All">All Categories</option>
                {categories.map((c) => (
                  <option key={c.label} value={c.label}>
                    {c.label}
                  </option>
                ))}
              </select>

              <select
                id="sort-by"
                aria-label="Sort products by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#171e29] border border-[#2c384a] text-slate-200 text-xs rounded-xl px-3 py-2 outline-none"
              >
                <option value="rating">Top Rated</option>
                <option value="priceAsc">Price: Low to High</option>
                <option value="priceDesc">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="catalog-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by brick type, manufacturer, dealer, size, or corridor..."
              className="w-full bg-[#151b24] border border-[#273343] rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-slate-400 focus:border-[#e55938] outline-none"
            />
          </div>

          {/* Products List Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredProducts.map((prod) => (
              <div
                key={prod.id}
                className="bg-[#141a24] border border-[#263345] rounded-2xl overflow-hidden hover:border-[#e55938]/60 transition-all flex flex-col justify-between shadow-lg"
              >
                <div className="relative aspect-[16/10] bg-black">
                  <img
                    src={prod.photos[0]}
                    alt={prod.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-md bg-black/75 backdrop-blur-md text-[11px] font-bold text-[#f8714e] border border-white/10">
                    {prod.brickType}
                  </div>
                  <div className="absolute top-2.5 right-2.5 px-2 py-1 rounded-md bg-black/75 backdrop-blur-md text-[11px] font-bold text-amber-400 flex items-center gap-1 border border-white/10">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{prod.rating}</span>
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-white text-sm leading-snug line-clamp-2">
                      {prod.name}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                      <Factory className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="truncate">{prod.manufacturerName}</span>
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                      {prod.description}
                    </p>

                    <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-slate-300 p-2 bg-[#10141d] rounded-lg">
                      <div>
                        Size: <strong className="text-white">{prod.size}</strong>
                      </div>
                      <div>
                        Stock: <strong className="text-emerald-400">{prod.availableStockThousand}k</strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#202a39] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase">Rate per 1,000</span>
                      <div className="text-base font-black text-white">
                        ₹{prod.pricePerThousand.toLocaleString()}
                      </div>
                    </div>

                    <button
                      id={`catalog-detail-${prod.id}`}
                      onClick={() => setSelectedProductId(prod.id)}
                      className="px-3.5 py-1.5 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>View Specs</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          MAIN TAB 3: ORDERS & LIVE TRACKING (Screens 13, 14, 15)
      ========================================================================= */}
      {customerTab === 'orders' && !selectedProductId && (
        <div className="max-w-7xl mx-auto px-4 py-5 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-wider">
                Screen 14 & 15 • Orders & Invoicing
              </span>
              <h2 className="text-xl font-bold text-white">{t('orders')}</h2>
            </div>

            {/* Active / Completed / Cancelled tabs (Screen 14 specification) */}
            <div className="flex items-center gap-1 p-1 bg-[#141a24] border border-[#253243] rounded-xl text-xs">
              {(['Active', 'Completed', 'Cancelled'] as const).map((tab) => (
                <button
                  key={tab}
                  id={`orders-tab-${tab}`}
                  onClick={() => setOrdersSubTab(tab)}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                    ordersSubTab === tab
                      ? 'bg-[#e55938] text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Active order live tracking highlight (Screen 13) */}
          {activeTrackingOrder && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active Trip Live Telemetry Map
                </span>
                <span className="text-xs text-slate-400">
                  Site: {activeTrackingOrder.deliveryAddress}
                </span>
              </div>
              <LiveTrackingMap
                order={activeTrackingOrder}
                onAdvanceStage={() => advanceOrderStage(activeTrackingOrder.id)}
                onCallDriver={() => alert(`Connecting phone call to driver ${activeTrackingOrder.driverName} (${activeTrackingOrder.driverMobile})...`)}
              />
            </div>
          )}

          {/* Orders List Table / Cards (Screen 14 & 15) */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              {ordersSubTab} Orders History
            </h3>

            {orders.map((order) => (
              <div
                key={order.id}
                className="bg-[#141a24] border border-[#263345] rounded-2xl p-4 sm:p-5 text-xs text-slate-300 flex flex-col md:flex-row justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white text-sm">
                      {order.id}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        order.orderStatus === 'Delivered'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : order.orderStatus === 'Cancelled'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-[#e55938]/20 text-[#f8714e] border border-[#e55938]/30'
                      }`}
                    >
                      {order.orderStatus}
                    </span>
                    <span className="text-slate-400">• {order.createdAt}</span>
                  </div>

                  <p className="font-semibold text-slate-200">
                    {order.items[0]?.productName} ({order.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks)
                  </p>
                  <p className="text-slate-400">
                    Kiln: <strong className="text-slate-300">{order.manufacturerName}</strong> • Fleet: {order.vehicleType}
                  </p>
                  <p className="text-slate-400 truncate max-w-lg">
                    Destination: {order.deliveryAddress}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row md:flex-col justify-between items-start md:items-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-[#232f41]">
                  <div className="text-left md:text-right">
                    <span className="text-[10px] text-slate-400 uppercase">Total Amount</span>
                    <div className="text-base font-extrabold text-white">
                      ₹{order.totalAmount.toLocaleString()}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      id={`track-btn-${order.id}`}
                      onClick={() => setTrackingOrderId(order.id)}
                      className="px-3 py-1.5 bg-[#1e2735] hover:bg-[#283547] text-slate-200 font-semibold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Truck className="w-3.5 h-3.5 text-blue-400" />
                      <span>Track</span>
                    </button>

                    <button
                      id={`invoice-btn-${order.id}`}
                      onClick={() => setInvoiceModalOrderId(order.id)}
                      className="px-3 py-1.5 bg-[#1e2735] hover:bg-[#283547] text-slate-200 font-semibold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                      <span>Invoice</span>
                    </button>

                    <button
                      id={`complaint-btn-${order.id}`}
                      onClick={() => setComplaintModalOrderId(order.id)}
                      className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <AlertTriangle className="w-3 h-3 text-rose-400" />
                      <span>Dispute</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          MAIN TAB 4: WALLET & CREDITS (Screen 16)
      ========================================================================= */}
      {customerTab === 'wallet' && !selectedProductId && (
        <div className="max-w-4xl mx-auto px-4 py-5 space-y-6">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-wider">
              Screen 16 • Wallet & Builder Credits
            </span>
            <h2 className="text-xl font-bold text-white">{t('wallet')}</h2>
          </div>

          {/* Balance card */}
          <div className="bg-gradient-to-br from-[#1c2432] to-[#121822] border border-[#2a374b] rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400 font-medium">{t('walletBalance')}</span>
              <div className="text-3xl font-black text-white mt-1">
                ₹{walletBalance.toLocaleString()}
              </div>
              <p className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Instant dispatch enabled with prepaid wallet balance</span>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="wallet-add-5k"
                onClick={() => addMoneyToWallet(5000, 'Direct UPI Top-up')}
                className="px-4 py-2.5 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add ₹5,000</span>
              </button>
              <button
                id="wallet-add-20k"
                onClick={() => addMoneyToWallet(20000, 'Builder Advance Credit')}
                className="px-4 py-2.5 bg-[#1f2838] hover:bg-[#29364a] text-slate-200 border border-[#34445c] font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                <span>Add ₹20,000</span>
              </button>
            </div>
          </div>

          {/* Transaction history */}
          <div className="bg-[#141a24] border border-[#253243] rounded-2xl p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">
              {t('recentTransactions')}
            </h3>

            <div className="space-y-3 text-xs">
              {[
                { id: 'TXN-901', desc: 'Damaged Brick Refund (CMP-401)', date: '18 Sep 2026', type: 'credit', amt: 1098 },
                { id: 'TXN-892', desc: 'Order Payment BRK-ORD-88219 (5k Bricks)', date: '20 Sep 2026', type: 'debit', amt: 52150 },
                { id: 'TXN-880', desc: 'HDFC Bank Direct Wallet Load', date: '17 Sep 2026', type: 'credit', amt: 65000 }
              ].map((txn) => (
                <div
                  key={txn.id}
                  className="p-3 bg-[#10141d] border border-[#202a39] rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-white">{txn.desc}</div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {txn.id} • {txn.date}
                    </div>
                  </div>
                  <div
                    className={`font-mono font-bold text-sm ${
                      txn.type === 'credit' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {txn.type === 'credit' ? '+' : '-'}₹{txn.amt.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MAIN TAB 5: PROFILE & SETTINGS (Screen 17)
      ========================================================================= */}
      {customerTab === 'profile' && !selectedProductId && (
        <div className="max-w-3xl mx-auto px-4 py-5 space-y-6">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#e55938] tracking-wider">
              Screen 17 • Company Account
            </span>
            <h2 className="text-xl font-bold text-white">{t('profile')}</h2>
          </div>

          <div className="bg-[#141a24] border border-[#253243] rounded-2xl p-6 text-xs text-slate-300 space-y-5">
            <div className="flex items-center gap-4 pb-5 border-b border-[#212b3a]">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#e55938] to-[#982f18] text-white font-black text-2xl flex items-center justify-center shadow-lg">
                {currentUser.name.charAt(0)}
              </div>
              <div>
                <h3 className="text-base font-bold text-white">{currentUser.name}</h3>
                <p className="text-slate-400">{currentUser.businessName}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold text-[10px]">
                    GST: {currentUser.gstNumber}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-semibold text-[10px]">
                    PAN: {currentUser.panNumber}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3 bg-[#10151f] border border-[#202937] rounded-xl">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">
                  Phone Number
                </span>
                <p className="font-semibold text-white mt-0.5">{currentUser.mobile}</p>
              </div>
              <div className="p-3 bg-[#10151f] border border-[#202937] rounded-xl">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">
                  Email Address
                </span>
                <p className="font-semibold text-white mt-0.5">{currentUser.email}</p>
              </div>
            </div>

            <div className="p-3 bg-[#10151f] border border-[#202937] rounded-xl">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">
                Saved Site Address
              </span>
              <p className="font-semibold text-white mt-0.5">{currentUser.address}</p>
              <p className="text-slate-400 text-[11px] mt-0.5">PIN: {currentUser.pinCode}</p>
            </div>

            {/* Language switch */}
            <div className="p-4 bg-[#10151f] border border-[#202937] rounded-xl flex items-center justify-between">
              <div>
                <div className="font-bold text-white">App Interface Language</div>
                <div className="text-slate-400 text-[11px]">বাংলা / English / हिंदी</div>
              </div>
              <div className="flex items-center gap-1">
                {(['en', 'bn', 'hi'] as const).map((l) => (
                  <button
                    key={l}
                    onClick={() => setLanguage(l)}
                    className={`px-2.5 py-1 rounded text-xs font-semibold ${
                      language === l
                        ? 'bg-[#e55938] text-white'
                        : 'bg-[#1a222e] text-slate-400 hover:text-white'
                    }`}
                  >
                    {l === 'bn' ? 'বাংলা' : l === 'hi' ? 'हिंदी' : 'EN'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar (Screens 07-17 Specification: Home | Products | Orders | Wallet | Profile) */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-[#10141b]/95 backdrop-blur-md border-t border-[#232d3b] px-2 py-1.5 sm:py-2">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {[
            { id: 'home' as const, label: t('home'), icon: <Building2 className="w-4 h-4" /> },
            { id: 'products' as const, label: t('products'), icon: <Layers className="w-4 h-4" /> },
            { id: 'orders' as const, label: t('orders'), icon: <Truck className="w-4 h-4" /> },
            { id: 'wallet' as const, label: t('wallet'), icon: <Wallet className="w-4 h-4" /> },
            { id: 'profile' as const, label: t('profile'), icon: <ShieldCheck className="w-4 h-4" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`customer-bottom-nav-${tab.id}`}
              onClick={() => {
                setSelectedProductId(null);
                setCustomerTab(tab.id);
              }}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                customerTab === tab.id
                  ? 'text-[#f8714e] font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-lg ${
                  customerTab === tab.id ? 'bg-[#e55938]/15 text-[#f8714e]' : ''
                }`}
              >
                {tab.icon}
              </div>
              <span className="text-[10px] leading-none">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};
