import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Send,
  Lock,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Wallet,
  Coins
} from 'lucide-react';
import { ChatSession } from '../../types';

interface ChatModalProps {
  sessionId: string;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ sessionId, onClose }) => {
  const {
    chatSessions,
    chatMessages,
    sendChatMessage,
    unlockPaidChat,
    user,
    role,
    adminConfig
  } = useApp();

  const [inputVal, setInputVal] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isUnlocking, setIsUnlocking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const session = chatSessions.find(s => s.id === sessionId) || chatSessions[0];
  const messages = (session && chatMessages[session.id]) || [];

  const freeLimit = session?.freeMessagesAllowed ?? adminConfig.chatRules.freeMessageLimit ?? 5;
  const freeUsed = session?.freeMessagesUsed ?? 0;
  const freeRemaining = Math.max(0, freeLimit - freeUsed);
  const isPaidUnlocked = session?.isPaidUnlocked ?? false;
  const unlockPrice = session?.paidUnlockPrice ?? adminConfig.chatRules.unlockFee ?? 29;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    setErrorMessage('');
    const res = await sendChatMessage(session.id, inputVal.trim());
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to send message');
    } else {
      setInputVal('');
    }
  };

  const handleUnlock = async () => {
    setIsUnlocking(true);
    await unlockPaidChat(session.id);
    setIsUnlocking(false);
    setErrorMessage('');
  };

  if (!session) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white text-slate-900 rounded-3xl border border-slate-200 w-full max-w-sm h-[600px] max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden">
        {/* Chat Header */}
        <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-black text-white text-sm">
              {session.participantName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-xs font-bold text-white truncate max-w-[150px]">
                  {session.participantName}
                </h3>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </div>
              <p className="text-[10px] text-slate-400 capitalize">
                {session.participantRole} Partner
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Free Message Limit / Monetization Status Banner */}
        <div className="px-3 py-1.5 bg-amber-50 border-b border-amber-200 flex items-center justify-between text-[11px] shrink-0">
          {isPaidUnlocked ? (
            <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unlimited Direct Chat Active (Paid Plan)</span>
            </div>
          ) : (
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-1 text-slate-700 font-medium">
                <Coins className="w-3.5 h-3.5 text-amber-600" />
                <span>
                  Free Messages: <b className="text-amber-800">{freeRemaining}</b> left of {freeLimit}
                </span>
              </div>
              {freeRemaining <= 2 && (
                <span className="text-[10px] font-extrabold text-amber-700 bg-amber-200/70 px-1.5 py-0.2 rounded-md">
                  Low Quota
                </span>
              )}
            </div>
          )}
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 p-3 overflow-y-auto space-y-2.5 bg-slate-50 text-xs">
          {messages.map(msg => {
            const isMe = msg.senderId === user.id || msg.senderRole === role;
            if (msg.isSystem) {
              return (
                <div key={msg.id} className="text-center my-2">
                  <span className="inline-block px-3 py-1 bg-amber-100/70 text-amber-900 border border-amber-200 rounded-full text-[10px] font-bold">
                    {msg.text}
                  </span>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] px-3 py-2 rounded-2xl ${
                    isMe
                      ? 'bg-amber-500 text-slate-950 font-medium rounded-br-2xs shadow-xs'
                      : 'bg-white text-slate-800 font-normal border border-slate-200 rounded-bl-2xs shadow-xs'
                  }`}
                >
                  <p className="leading-relaxed">{msg.text}</p>
                </div>
                <span className="text-[9px] text-slate-400 mt-0.5 px-1">
                  {new Date(msg.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Error or Limit Banner */}
        {errorMessage && (
          <div className="px-3 py-1.5 bg-rose-50 border-t border-rose-200 text-rose-800 text-[11px] font-semibold flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Paid Chat Unlock Card if Free Limit Exceeded for Customer */}
        {!isPaidUnlocked && freeRemaining === 0 && role === 'customer' ? (
          <div className="p-3 bg-gradient-to-tr from-amber-500/10 via-orange-500/10 to-amber-500/20 border-t border-amber-300 space-y-2 shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 font-bold">
                <Lock className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-black text-slate-900 leading-tight">
                  Free Message Quota Completed ({freeLimit}/{freeLimit})
                </h4>
                <p className="text-[10px] text-slate-600">
                  Unlock unlimited direct chat with your assigned partner for just ₹{unlockPrice}.
                </p>
              </div>
            </div>

            <button
              id="unlock-paid-chat-btn"
              disabled={isUnlocking}
              onClick={handleUnlock}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-black text-xs shadow-md flex items-center justify-center gap-1.5 active:scale-98 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                {isUnlocking ? 'Unlocking...' : `Unlock Unlimited Chat for ₹${unlockPrice}`}
              </span>
            </button>
          </div>
        ) : (
          /* Normal Chat Input */
          <form
            onSubmit={handleSend}
            className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              placeholder={
                isPaidUnlocked
                  ? 'Type your message...'
                  : `Type a message (${freeRemaining} free remaining)...`
              }
              value={inputVal}
              onChange={e => setInputVal(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-100 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-amber-500 border border-transparent"
            />
            <button
              type="submit"
              disabled={!inputVal.trim()}
              className="w-9 h-9 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 flex items-center justify-center disabled:opacity-40 transition-all active:scale-95"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
