import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RIDE_VEHICLE_OPTIONS } from '../../data/mockData';
import { RideVehicleOption } from '../../types';
import {
  ArrowLeft,
  Navigation,
  MapPin,
  ShieldCheck,
  Zap,
  Car,
  Bike,
  Users,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface RideBookingViewProps {
  onBack: () => void;
  onRideConfirmed: (orderId: string) => void;
}

export const RideBookingView: React.FC<RideBookingViewProps> = ({ onBack, onRideConfirmed }) => {
  const { currentLocation, placeOrder, user, deliveryPartners } = useApp();
  const [pickup, setPickup] = useState(currentLocation.locality);
  const [drop, setDrop] = useState('Indira Gandhi International Airport, Terminal 3');
  const [selectedVehicle, setSelectedVehicle] = useState<RideVehicleOption>(RIDE_VEHICLE_OPTIONS[0]);
  const [distanceKm] = useState(7.4);
  const [isBooking, setIsBooking] = useState(false);

  const calculateFare = (option: RideVehicleOption) => {
    return Math.round(option.baseFare + option.perKmRate * distanceKm);
  };

  const handleConfirmRide = async () => {
    setIsBooking(true);
    const fare = calculateFare(selectedVehicle);
    const driver = deliveryPartners[0];

    const newOrder = await placeOrder({
      category: 'ride',
      deliveryPartnerId: driver.id,
      deliveryPartnerName: `${driver.name} (${selectedVehicle.title})`,
      deliveryPartnerPhone: driver.phone,
      itemTotal: fare,
      deliveryFee: 0,
      platformFee: 5,
      taxes: Math.round(fare * 0.05),
      discount: 0,
      grandTotal: fare + 5 + Math.round(fare * 0.05),
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      status: 'assigned',
      eta: '3 mins away',
      rideDetails: {
        vehicleType: selectedVehicle.title,
        pickupLocation: pickup,
        dropLocation: drop,
        distanceKm,
        driverOtp: `${Math.floor(1000 + Math.random() * 9000)}`
      },
      items: [
        {
          serviceId: selectedVehicle.id,
          title: `${selectedVehicle.title} Ride`,
          quantity: 1,
          price: fare
        }
      ]
    });

    setIsBooking(false);
    onRideConfirmed(newOrder.id);
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-black text-slate-900">AllJi Cabs & Rides</h2>
            <p className="text-[11px] text-slate-500 font-semibold">Auto, Moto & AC Cabs</p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 text-[11px] font-bold border border-amber-200 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
          <span>Verified Drivers</span>
        </span>
      </div>

      {/* Pickup & Destination Inputs */}
      <div className="p-4 bg-white border-b border-slate-200 space-y-2">
        <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-2xl border border-slate-200/80">
          <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0 ring-4 ring-emerald-100" />
          <div className="flex-1">
            <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
              Pickup Point
            </span>
            <input
              type="text"
              value={pickup}
              onChange={e => setPickup(e.target.value)}
              className="w-full text-xs font-bold text-slate-800 bg-transparent focus:outline-hidden"
            />
          </div>
        </div>

        <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-2xl border border-slate-200/80">
          <span className="w-3 h-3 rounded-full bg-amber-500 shrink-0 ring-4 ring-amber-100" />
          <div className="flex-1">
            <span className="text-[9px] uppercase font-black tracking-wider text-slate-400 block">
              Destination / Drop
            </span>
            <input
              type="text"
              value={drop}
              onChange={e => setDrop(e.target.value)}
              className="w-full text-xs font-bold text-slate-800 bg-transparent focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Interactive Map Visual Simulation */}
      <div className="relative h-44 bg-slate-900 overflow-hidden flex items-center justify-center">
        {/* Map grid lines simulation */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#33415515_1px,transparent_1px),linear-gradient(to_bottom,#33415515_1px,transparent_1px)] bg-[size:24px_24px] bg-slate-950" />

        {/* Route line SVG */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 380 180">
          <path
            d="M 60 130 Q 140 40 220 110 T 320 60"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="4"
            strokeDasharray="6,4"
            strokeLinecap="round"
          />
        </svg>

        {/* Pickup Marker */}
        <div className="absolute left-10 bottom-8 flex flex-col items-center">
          <div className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[9px] font-bold shadow-md">
            Pickup
          </div>
          <div className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-white shadow-md animate-ping" />
        </div>

        {/* Moving Vehicle */}
        <div className="absolute left-[180px] top-[75px] -translate-x-1/2 -translate-y-1/2 p-2 rounded-full bg-amber-500 text-slate-950 shadow-xl border-2 border-white animate-pulse">
          <Car className="w-4 h-4" />
        </div>

        {/* Drop Marker */}
        <div className="absolute right-8 top-8 flex flex-col items-center">
          <div className="px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 text-[9px] font-bold shadow-md">
            IGI Airport T3
          </div>
          <div className="w-3 h-3 rounded-full bg-amber-500 border-2 border-white shadow-md" />
        </div>

        {/* Route Stats Pill */}
        <div className="absolute bottom-2 px-3 py-1 rounded-full bg-slate-900/90 text-white border border-slate-700 text-[11px] font-semibold flex items-center gap-3 backdrop-blur-md">
          <span>Route: {distanceKm} km</span>
          <span>•</span>
          <span className="text-amber-400 font-bold">16 Mins Traffic Time</span>
        </div>
      </div>

      {/* Vehicle Options */}
      <div className="p-4 space-y-2">
        <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
          Select Vehicle ({RIDE_VEHICLE_OPTIONS.length} Available)
        </h3>

        <div className="space-y-2">
          {RIDE_VEHICLE_OPTIONS.map(opt => {
            const isSelected = selectedVehicle.id === opt.id;
            const fare = calculateFare(opt);

            return (
              <button
                key={opt.id}
                id={`vehicle-opt-${opt.id}`}
                onClick={() => setSelectedVehicle(opt)}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                  isSelected
                    ? 'border-amber-500 bg-amber-50/70 shadow-sm ring-1 ring-amber-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold ${
                      isSelected ? 'bg-amber-500 text-slate-950' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {opt.id === 'bike' ? (
                      <Bike className="w-6 h-6" />
                    ) : opt.id === 'auto' ? (
                      <Zap className="w-6 h-6" />
                    ) : opt.id === 'suv' ? (
                      <Users className="w-6 h-6" />
                    ) : (
                      <Car className="w-6 h-6" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-extrabold text-slate-900">{opt.title}</h4>
                      <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {opt.etaMinutes} min away
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">{opt.description}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-black text-slate-900">₹{fare}</span>
                  <span className="block text-[10px] text-slate-400">Cash / UPI</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Floating Bottom Booking Bar */}
      <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
        <button
          id="confirm-ride-btn"
          disabled={isBooking}
          onClick={handleConfirmRide}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-black rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all disabled:opacity-50"
        >
          {isBooking ? (
            <span>Matching nearest {selectedVehicle.title}...</span>
          ) : (
            <>
              <Car className="w-4 h-4" />
              <span>Book {selectedVehicle.title} • ₹{calculateFare(selectedVehicle)}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
