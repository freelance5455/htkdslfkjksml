import React from 'react';
import { ProviderProfile } from '../../types';
import { useMohalla } from '../../context/MohallaContext';
import {
  Star,
  ShieldCheck,
  MapPin,
  Clock,
  Heart,
  CheckCircle2,
  Wrench,
  Award,
  Zap,
} from 'lucide-react';
import { calculateDistanceKm, formatCurrencyPKR, formatDistance } from '../../utils/geo';

interface ProviderCardProps {
  provider: ProviderProfile;
  onViewProfile: (provider: ProviderProfile) => void;
  onBookNow: (provider: ProviderProfile) => void;
  onInspectTrustScore: (provider: ProviderProfile) => void;
}

export const ProviderCard: React.FC<ProviderCardProps> = ({
  provider,
  onViewProfile,
  onBookNow,
  onInspectTrustScore,
}) => {
  const { selectedArea, favorites, toggleFavorite, language } = useMohalla();

  const isFavorite = favorites.includes(provider.id);
  const distanceKm = calculateDistanceKm(
    selectedArea.lat,
    selectedArea.lng,
    provider.location.lat,
    provider.location.lng
  );

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 hover:border-emerald-300 hover:shadow-lg transition-all duration-200 p-4 sm:p-5 flex flex-col justify-between group relative">
      {/* Top section: Availability, Distance, Favorite */}
      <div className="flex items-start justify-between gap-3">
        {/* Avatar & Main Info */}
        <div className="flex items-start gap-3.5 flex-1 min-w-0">
          <div className="relative shrink-0">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-700 text-white font-bold flex items-center justify-center text-lg shadow-sm overflow-hidden">
              {provider.businessName.charAt(0)}
            </div>
            {/* Status dot */}
            <span
              className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center ${
                provider.isAvailableNow ? 'bg-emerald-500' : 'bg-slate-400'
              }`}
              title={provider.isAvailableNow ? 'Available Now' : 'Busy / Off duty'}
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3
                onClick={() => onViewProfile(provider)}
                className="font-bold text-base text-slate-900 group-hover:text-emerald-700 transition-colors cursor-pointer truncate"
              >
                {provider.businessName}
              </h3>
            </div>

            {/* Verification & Trust badges */}
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              {provider.verificationStatus === 'verified' && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/60">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'ur' ? 'تصدیق شدہ' : 'Verified'}</span>
                </span>
              )}

              {/* Trust score interactive pill */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onInspectTrustScore(provider);
                }}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-amber-50 text-amber-900 border border-amber-200/70 hover:bg-amber-100 transition-colors cursor-pointer"
                title="View Trust Score breakdown"
              >
                <Award className="w-3 h-3 text-amber-600" />
                <span>Trust {provider.trustScore}/100</span>
              </button>
            </div>
          </div>
        </div>

        {/* Favorite heart */}
        <button
          onClick={() => toggleFavorite(provider.id)}
          className={`p-2 rounded-xl transition-colors cursor-pointer shrink-0 ${
            isFavorite
              ? 'text-rose-500 bg-rose-50 hover:bg-rose-100'
              : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100'
          }`}
          title="Save provider"
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Metrics Row: Rating, Distance, Available status */}
      <div className="grid grid-cols-3 gap-2 my-3.5 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
        {/* Rating */}
        <div className="flex flex-col items-center justify-center text-center">
          <div className="flex items-center gap-1 font-bold text-slate-900">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{provider.rating.toFixed(1)}</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5">
            {provider.completedJobs} {language === 'ur' ? 'کام' : 'jobs'}
          </span>
        </div>

        {/* Distance */}
        <div className="flex flex-col items-center justify-center text-center border-x border-slate-200">
          <div className="flex items-center gap-1 font-bold text-emerald-800">
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            <span>{formatDistance(distanceKm)}</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 truncate max-w-full">
            {provider.location.areaName.split(' ')[0]}
          </span>
        </div>

        {/* Availability */}
        <div className="flex flex-col items-center justify-center text-center">
          <div
            className={`font-bold text-[11px] flex items-center gap-1 ${
              provider.isAvailableNow ? 'text-emerald-700' : 'text-slate-500'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                provider.isAvailableNow ? 'bg-emerald-500' : 'bg-slate-400'
              }`}
            />
            <span>
              {provider.isAvailableNow
                ? language === 'ur'
                  ? 'دستیاب'
                  : 'Available'
                : language === 'ur'
                ? 'مصروف'
                : 'Busy'}
            </span>
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5">
            ~{provider.responseTimeMinutes}m response
          </span>
        </div>
      </div>

      {/* Subservices chips */}
      <div className="flex items-center gap-1.5 flex-wrap mb-4 overflow-hidden max-h-12">
        {provider.subServices.slice(0, 3).map((sub, i) => (
          <span
            key={i}
            className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium truncate"
          >
            {sub}
          </span>
        ))}
        {provider.subServices.length > 3 && (
          <span className="text-[10px] text-slate-400 font-medium">
            +{provider.subServices.length - 3} more
          </span>
        )}
      </div>

      {/* Footer: Visit charge + Action buttons */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            {language === 'ur' ? 'وزٹ فیس' : 'Visit Charge'}
          </span>
          <span className="text-sm sm:text-base font-extrabold text-slate-900">
            {formatCurrencyPKR(provider.visitCharge)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onViewProfile(provider)}
            className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
          >
            {language === 'ur' ? 'تفصیل' : 'Details'}
          </button>
          <button
            onClick={() => onBookNow(provider)}
            className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95"
          >
            {language === 'ur' ? 'بک کریں' : 'Book Now'}
          </button>
        </div>
      </div>
    </div>
  );
};
