import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ServiceCategoryType, ServiceItem } from '../../types';
import {
  ArrowLeft,
  Calendar,
  Clock,
  ShieldCheck,
  Star,
  MapPin,
  CheckCircle2,
  Plus,
  Check
} from 'lucide-react';

interface HomeServiceBookingViewProps {
  category: ServiceCategoryType;
  onBack: () => void;
  onBookingSuccess: (orderId: string) => void;
}

export const HomeServiceBookingView: React.FC<HomeServiceBookingViewProps> = ({
  category,
  onBack,
  onBookingSuccess
}) => {
  const { services, providers, placeOrder, currentLocation, user } = useApp();

  const categoryServices = services.filter(s => s.categoryId === category);
  const matchedProvider = providers.find(p => p.category === category) || providers[0];

  const [selectedService, setSelectedService] = useState<ServiceItem>(categoryServices[0] || services[0]);
  const [selectedSlot, setSelectedSlot] = useState('Today, 04:00 PM - 05:00 PM');
  const [address, setAddress] = useState(
    user.savedAddresses[0]?.street || currentLocation.locality
  );
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'wallet'>('cash');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const availableSlots = [
    'Today, 04:00 PM - 05:00 PM',
    'Today, 06:00 PM - 07:00 PM',
    'Tomorrow, 10:00 AM - 11:00 AM',
    'Tomorrow, 02:00 PM - 03:00 PM'
  ];

  const price = selectedService.discountPrice || selectedService.price;
  const platformFee = 5;
  const tax = Math.round(price * 0.05);
  const grandTotal = price + platformFee + tax;

  const handleBookNow = async () => {
    setIsSubmitting(true);
    const newOrder = await placeOrder({
      category,
      providerId: matchedProvider.id,
      providerName: matchedProvider.businessName,
      items: [
        {
          serviceId: selectedService.id,
          title: selectedService.title,
          quantity: 1,
          price
        }
      ],
      scheduledSlot: selectedSlot,
      deliveryAddress: {
        id: `addr_${Date.now()}`,
        label: 'Home',
        street: address,
        locality: currentLocation.locality,
        city: currentLocation.city,
        pincode: '122002'
      },
      itemTotal: price,
      deliveryFee: 0,
      platformFee,
      taxes: tax,
      discount: 0,
      grandTotal,
      paymentMethod: paymentMode,
      paymentStatus: paymentMode === 'cash' ? 'pending' : 'paid',
      status: 'accepted',
      eta: selectedSlot
    });
    setIsSubmitting(false);
    onBookingSuccess(newOrder.id);
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-black text-slate-900 capitalize">
              {category.replace('_', ' ')}
            </h2>
            <p className="text-[11px] text-slate-500 font-semibold">Book Verified Professional</p>
          </div>
        </div>

        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Doorstep Service</span>
        </span>
      </div>

      {/* Provider Snapshot */}
      {matchedProvider && (
        <div className="mx-4 mt-3 p-3 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
          <img
            src={matchedProvider.avatar}
            alt={matchedProvider.businessName}
            className="w-12 h-12 rounded-xl object-cover border border-slate-200"
          />
          <div className="flex-1">
            <h3 className="text-xs font-black text-slate-900 leading-tight">
              {matchedProvider.businessName}
            </h3>
            <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
              <span className="flex items-center text-amber-600 font-bold">
                <Star className="w-3 h-3 fill-amber-500 mr-0.5" />
                {matchedProvider.rating} ({matchedProvider.reviewCount})
              </span>
              <span>•</span>
              <span>{matchedProvider.experienceYears}+ Yrs Exp</span>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            KYC Verified
          </span>
        </div>
      )}

      {/* Services List in this category */}
      <div className="p-4 space-y-2.5">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-500">
          Available Services & Packages
        </h4>

        <div className="space-y-2">
          {categoryServices.map(item => {
            const isSelected = selectedService.id === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setSelectedService(item)}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-50/60 border-amber-500 ring-1 ring-amber-500 shadow-xs'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h5 className="text-xs font-black text-slate-900">{item.title}</h5>
                    {isSelected && (
                      <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center">
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                  <div className="flex items-center gap-3 mt-2 text-[11px]">
                    <span className="font-extrabold text-slate-900">
                      ₹{item.discountPrice || item.price}
                    </span>
                    {item.durationMinutes && (
                      <span className="text-slate-400 flex items-center gap-0.5">
                        <Clock className="w-3 h-3" />
                        {item.durationMinutes} mins
                      </span>
                    )}
                  </div>
                </div>

                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-18 h-18 rounded-xl object-cover shrink-0"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Slot Selection */}
      <div className="px-4 space-y-2">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-amber-600" />
          <span>Select Time Slot</span>
        </h4>

        <div className="grid grid-cols-2 gap-2">
          {availableSlots.map(slot => (
            <button
              key={slot}
              onClick={() => setSelectedSlot(slot)}
              className={`p-2 rounded-xl text-[11px] font-bold border text-left transition-all ${
                selectedSlot === slot
                  ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {slot}
            </button>
          ))}
        </div>
      </div>

      {/* Address */}
      <div className="p-4 space-y-2">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-amber-600" />
          <span>Service Address</span>
        </h4>

        <div className="p-3 bg-white rounded-2xl border border-slate-200">
          <input
            type="text"
            value={address}
            onChange={e => setAddress(e.target.value)}
            placeholder="Complete street address, flat / house no."
            className="w-full text-xs font-semibold text-slate-900 bg-transparent focus:outline-hidden"
          />
        </div>
      </div>

      {/* Payment Mode Selection */}
      <div className="px-4 space-y-2">
        <h4 className="text-xs font-black uppercase tracking-wider text-slate-500">
          Payment Method
        </h4>
        <div className="grid grid-cols-3 gap-2 text-xs">
          <button
            onClick={() => setPaymentMode('cash')}
            className={`p-2 rounded-xl border text-center font-bold transition-all ${
              paymentMode === 'cash' ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            Pay After Work
          </button>
          <button
            onClick={() => setPaymentMode('upi')}
            className={`p-2 rounded-xl border text-center font-bold transition-all ${
              paymentMode === 'upi' ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            UPI Online
          </button>
          <button
            onClick={() => setPaymentMode('wallet')}
            className={`p-2 rounded-xl border text-center font-bold transition-all ${
              paymentMode === 'wallet' ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            AllJi Wallet (₹{user.walletBalance})
          </button>
        </div>
      </div>

      {/* Floating Bottom Confirm Bar */}
      <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
        <button
          id="confirm-home-service-btn"
          disabled={isSubmitting}
          onClick={handleBookNow}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-black rounded-2xl shadow-xl flex items-center justify-between px-5 active:scale-98 transition-all disabled:opacity-50"
        >
          <div className="text-left">
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-900/80 block">
              Total to Pay
            </span>
            <span className="text-sm font-black">₹{grandTotal} (Incl. Taxes)</span>
          </div>
          <span className="bg-slate-950 text-white px-3 py-1.5 rounded-xl text-xs font-bold">
            {isSubmitting ? 'Booking...' : 'Confirm Booking →'}
          </span>
        </button>
      </div>
    </div>
  );
};
