import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import {
  AlertTriangle,
  Zap,
  Droplets,
  Car,
  Bike,
  Flame,
  CheckCircle2,
  Clock,
  X,
  PhoneCall,
} from 'lucide-react';
import { calculateDistanceKm, formatCurrencyPKR } from '../../utils/geo';

interface EmergencyBannerProps {
  onOpenBookingForProvider: (providerId: string, isEmergency?: boolean) => void;
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({
  onOpenBookingForProvider,
}) => {
  const { providers, selectedArea, language } = useMohalla();
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [selectedEmergencyCategory, setSelectedEmergencyCategory] = useState<string>('electrician');

  // Emergency eligible categories
  const emergencyOptions = [
    {
      id: 'electrician',
      title: 'Electrical Short Circuit',
      titleUrdu: 'بجلی کی شارٹ سرکٹ',
      icon: Zap,
      color: 'bg-amber-500',
    },
    {
      id: 'plumber',
      title: 'Water Pipe Burst / Leak',
      titleUrdu: 'پانی کا پائپ پھٹ جانا',
      icon: Droplets,
      color: 'bg-blue-500',
    },
    {
      id: 'car_mechanic',
      title: 'Car Roadside Breakdown',
      titleUrdu: 'گاڑی کی خرابی / بند ہونا',
      icon: Car,
      color: 'bg-rose-500',
    },
    {
      id: 'bike_mechanic',
      title: 'Bike Puncture / Stalled',
      titleUrdu: 'موٹر بائیک خرابی',
      icon: Bike,
      color: 'bg-emerald-500',
    },
  ];

  // Filter available emergency providers sorted by distance to current selected area
  const availableEmergencyProviders = providers
    .filter((p) => p.isAvailableNow && p.emergencyService && p.category === selectedEmergencyCategory)
    .map((p) => ({
      ...p,
      distanceKm: calculateDistanceKm(
        selectedArea.lat,
        selectedArea.lng,
        p.location.lat,
        p.location.lng
      ),
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm);

  return (
    <>
      {/* Prominent Emergency Action Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white p-4 sm:p-5 shadow-lg shadow-rose-600/20">
        {/* Background pulsing glow */}
        <div className="absolute -right-8 -top-8 w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 animate-bounce">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm sm:text-base tracking-wide uppercase">
                  {language === 'ur' ? '🚨 ہنگامی مدد (ایمرجنسی سروس)' : '🚨 Urgent Emergency Service'}
                </span>
                <span className="bg-white text-rose-700 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                  Live Dispatch
                </span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5 max-w-xl">
                {language === 'ur'
                  ? 'بجلی بند، پائپ لیک، یا گاڑی بند ہو گئی؟ کراچی میں دستیاب تصدیق شدہ کاریگر کو 15 منٹ میں طلب کریں۔'
                  : 'Power cut, severe water leak, or vehicle stalled? Dispatch nearest available emergency technician within 15 mins.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowEmergencyModal(true)}
            className="self-start sm:self-center px-4 py-2.5 rounded-xl bg-white text-rose-700 hover:bg-rose-50 font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0"
          >
            {language === 'ur' ? 'فوری مدد مانگیں' : 'Request Emergency Help'}
          </button>
        </div>
      </div>

      {/* Emergency Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-rose-200 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Urgent Rapid Dispatch</h3>
                  <p className="text-xs text-slate-500">
                    Showing emergency providers near {selectedArea.name}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowEmergencyModal(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Emergency Type Selector */}
            <div className="grid grid-cols-2 gap-2 mt-4">
              {emergencyOptions.map((opt) => {
                const Icon = opt.icon;
                const isSelected = selectedEmergencyCategory === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedEmergencyCategory(opt.id)}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-rose-500 bg-rose-50 text-rose-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg text-white flex items-center justify-center shrink-0 ${opt.color}`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="text-xs font-semibold leading-snug">
                      {language === 'ur' ? opt.titleUrdu : opt.title}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Available Emergency Technicians List */}
            <div className="mt-4 flex-1 overflow-y-auto space-y-2.5 pr-1">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                <span>Available Near You</span>
                <span className="text-emerald-700 font-semibold">
                  {availableEmergencyProviders.length} Active Now
                </span>
              </div>

              {availableEmergencyProviders.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  <Clock className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                  No direct emergency providers available for this specific category right now.
                  Please select standard categories or try nearby areas.
                </div>
              ) : (
                availableEmergencyProviders.map((prov) => (
                  <div
                    key={prov.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white transition-all flex items-center justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">
                          {prov.businessName}
                        </span>
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-3 mt-1">
                        <span>⭐ {prov.rating} ({prov.completedJobs} jobs)</span>
                        <span>•</span>
                        <span className="font-semibold text-emerald-700">
                          {prov.distanceKm} km away
                        </span>
                        <span>•</span>
                        <span>Est. {prov.responseTimeMinutes} mins</span>
                      </div>
                      <div className="text-xs text-slate-700 font-medium mt-1">
                        Visit: {formatCurrencyPKR(prov.visitCharge)}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setShowEmergencyModal(false);
                        onOpenBookingForProvider(prov.id, true);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shrink-0 cursor-pointer shadow-sm hover:scale-105 transition-transform"
                    >
                      Dispatch Now
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
