import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Package, MapPin, ShieldCheck, Scale, Phone, User, CheckCircle2 } from 'lucide-react';

interface CourierServiceViewProps {
  onBack: () => void;
  onBookingSuccess: (orderId: string) => void;
}

export const CourierServiceView: React.FC<CourierServiceViewProps> = ({ onBack, onBookingSuccess }) => {
  const { currentLocation, placeOrder, deliveryPartners } = useApp();

  const [senderName, setSenderName] = useState('Aarav Sharma');
  const [senderPhone, setSenderPhone] = useState('+91 98765 43210');
  const [pickupAddress, setPickupAddress] = useState(currentLocation.locality);

  const [receiverName, setReceiverName] = useState('Pooja Mehta');
  const [receiverPhone, setReceiverPhone] = useState('+91 98111 77665');
  const [dropAddress, setDropAddress] = useState('Sector 56, Huda Market, Gurugram');

  const [packageType, setPackageType] = useState<'Document' | 'Food/Tiffin' | 'Electronics' | 'Clothes' | 'Other'>('Document');
  const [weightKg, setWeightKg] = useState<number>(1);
  const [instruction, setInstruction] = useState('Please handle carefully, contains important papers.');

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Price calculation
  const baseCost = 49;
  const perKgCost = 15;
  const estimatedCost = Math.round(baseCost + Math.max(0, weightKg - 0.5) * perKgCost);
  const taxes = Math.round(estimatedCost * 0.05);
  const grandTotal = estimatedCost + taxes;

  const handleBookCourier = async () => {
    setIsSubmitting(true);
    const courierRider = deliveryPartners[0];

    const newOrder = await placeOrder({
      category: 'courier',
      deliveryPartnerId: courierRider.id,
      deliveryPartnerName: courierRider.name,
      deliveryPartnerPhone: courierRider.phone,
      itemTotal: estimatedCost,
      deliveryFee: 0,
      platformFee: 5,
      taxes,
      discount: 0,
      grandTotal: grandTotal + 5,
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      status: 'assigned',
      eta: 'Pick up in 10 mins',
      deliveryOtp: `${Math.floor(1000 + Math.random() * 9000)}`,
      courierDetails: {
        senderName,
        senderPhone,
        pickupAddress,
        receiverName,
        receiverPhone,
        dropAddress,
        packageType,
        weightKg,
        instruction,
        estimatedCost
      },
      items: [
        {
          serviceId: 'cour_1',
          title: `Courier: ${packageType} (${weightKg} kg)`,
          quantity: 1,
          price: estimatedCost
        }
      ]
    });

    setIsSubmitting(false);
    onBookingSuccess(newOrder.id);
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-black text-slate-900">AllJi Parcel Courier</h2>
            <p className="text-[11px] text-slate-500 font-semibold">City Express Pickup & Drop</p>
          </div>
        </div>

        <span className="px-2 py-0.5 rounded-full bg-violet-50 text-violet-800 text-[10px] font-bold border border-violet-200 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-violet-600" />
          <span>Live Tracking</span>
        </span>
      </div>

      <div className="p-4 space-y-3.5">
        {/* Pickup Details */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center gap-2 text-xs font-black text-slate-900">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-4 ring-emerald-100" />
            <span>Pickup From (Sender)</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <input
              type="text"
              placeholder="Sender Name"
              value={senderName}
              onChange={e => setSenderName(e.target.value)}
              className="p-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
            />
            <input
              type="tel"
              placeholder="Sender Mobile"
              value={senderPhone}
              onChange={e => setSenderPhone(e.target.value)}
              className="p-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
            />
          </div>
          <input
            type="text"
            placeholder="Complete Pickup Address"
            value={pickupAddress}
            onChange={e => setPickupAddress(e.target.value)}
            className="w-full p-2 text-xs rounded-xl bg-slate-50 border border-slate-200 font-medium"
          />
        </div>

        {/* Drop Details */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center gap-2 text-xs font-black text-slate-900">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 ring-4 ring-rose-100" />
            <span>Deliver To (Receiver)</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <input
              type="text"
              placeholder="Receiver Name"
              value={receiverName}
              onChange={e => setReceiverName(e.target.value)}
              className="p-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
            />
            <input
              type="tel"
              placeholder="Receiver Mobile"
              value={receiverPhone}
              onChange={e => setReceiverPhone(e.target.value)}
              className="p-2 rounded-xl bg-slate-50 border border-slate-200 font-medium"
            />
          </div>
          <input
            type="text"
            placeholder="Complete Drop Address"
            value={dropAddress}
            onChange={e => setDropAddress(e.target.value)}
            className="w-full p-2 text-xs rounded-xl bg-slate-50 border border-slate-200 font-medium"
          />
        </div>

        {/* Package Category */}
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-wider text-slate-500 block">
            Package Contents
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['Document', 'Food/Tiffin', 'Electronics', 'Clothes', 'Other'] as const).map(type => (
              <button
                key={type}
                type="button"
                onClick={() => setPackageType(type)}
                className={`p-2 rounded-xl text-[11px] font-bold border transition-all ${
                  packageType === type
                    ? 'bg-violet-600 text-white border-violet-700 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Weight Selector */}
        <div className="p-3 bg-white rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-xs font-black text-slate-900">
            <span className="flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-violet-600" />
              <span>Estimated Weight</span>
            </span>
            <span className="text-violet-700">{weightKg} kg</span>
          </div>

          <input
            type="range"
            min={0.5}
            max={10}
            step={0.5}
            value={weightKg}
            onChange={e => setWeightKg(parseFloat(e.target.value))}
            className="w-full accent-violet-600 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
            <span>0.5 kg (Small envelope)</span>
            <span>5 kg</span>
            <span>10 kg (Max Bike)</span>
          </div>
        </div>

        {/* Special Instructions */}
        <div>
          <label className="text-[11px] font-bold text-slate-500 block mb-1">
            Delivery Instructions for Rider
          </label>
          <input
            type="text"
            value={instruction}
            onChange={e => setInstruction(e.target.value)}
            className="w-full p-2.5 text-xs bg-white rounded-xl border border-slate-200 font-medium"
          />
        </div>
      </div>

      {/* Floating Bottom Confirm Bar */}
      <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
        <button
          id="confirm-courier-btn"
          disabled={isSubmitting}
          onClick={handleBookCourier}
          className="w-full py-3.5 bg-gradient-to-r from-violet-600 via-purple-600 to-violet-700 text-white font-black rounded-2xl shadow-xl flex items-center justify-between px-5 active:scale-98 transition-all disabled:opacity-50"
        >
          <div className="text-left">
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-violet-200 block">
              Instant Courier Fare
            </span>
            <span className="text-sm font-black">₹{grandTotal + 5}</span>
          </div>
          <span className="bg-white text-violet-950 px-3.5 py-1.5 rounded-xl text-xs font-bold">
            {isSubmitting ? 'Dispatching...' : 'Dispatch Rider →'}
          </span>
        </button>
      </div>
    </div>
  );
};
