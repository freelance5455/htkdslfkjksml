import React, { useState, useEffect } from 'react';
import { Order } from '../../types';
import {
  Truck,
  MapPin,
  Phone,
  Clock,
  ShieldCheck,
  AlertCircle,
  Navigation,
  CheckCircle2,
  ChevronRight,
  Sparkles
} from 'lucide-react';

interface LiveTrackingMapProps {
  order: Order;
  onAdvanceStage?: () => void;
  onCallDriver?: () => void;
}

export const LiveTrackingMap: React.FC<LiveTrackingMapProps> = ({
  order,
  onAdvanceStage,
  onCallDriver
}) => {
  // Simulated truck animated position along route (0 to 100%)
  const [truckProgress, setTruckProgress] = useState<number>(68);
  const [isDriving, setIsDriving] = useState<boolean>(order.orderStatus === 'Out for Delivery');

  // Stages matching Screen 13 specification
  const stages: Order['orderStatus'][] = [
    'Order Confirmed',
    'Manufacturer Preparing',
    'Vehicle Assigned',
    'Loading',
    'Out for Delivery',
    'Delivered'
  ];

  const currentStageIndex = stages.indexOf(order.orderStatus);

  useEffect(() => {
    let interval: any;
    if (order.orderStatus === 'Out for Delivery') {
      interval = setInterval(() => {
        setTruckProgress((prev) => {
          if (prev >= 94) return 94;
          return prev + 1;
        });
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [order.orderStatus]);

  // Compute SVG route coordinates
  const startX = 60;
  const startY = 220;
  const endX = 440;
  const endY = 90;
  // Control point for smooth bend
  const curveX = 260;
  const curveY = 280;

  // Approximate position of truck along quadratic bezier
  const t = truckProgress / 100;
  const truckX = (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * curveX + t * t * endX;
  const truckY = (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * curveY + t * t * endY;

  return (
    <div className="bg-[#151b24] border border-[#263242] rounded-2xl overflow-hidden shadow-xl">
      {/* Top Header info */}
      <div className="p-4 sm:p-5 border-b border-[#242f3e] flex flex-wrap items-center justify-between gap-3 bg-[#11161d]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#e55938] uppercase tracking-wider">
              Screen 13 • Live Telemetry
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              Live GPS Active
            </span>
          </div>
          <h3 className="text-lg font-bold text-white mt-0.5 flex items-center gap-2">
            <span>Order #{order.id}</span>
            <span className="text-xs font-normal text-slate-400">
              ({order.vehicleType})
            </span>
          </h3>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick simulator button to advance status for testing */}
          {onAdvanceStage && currentStageIndex < stages.length - 1 && (
            <button
              id="advance-stage-simulator-btn"
              onClick={onAdvanceStage}
              className="px-3 py-1.5 bg-[#202937] hover:bg-[#2b3749] border border-[#34445c] text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              title="Simulator: Advance to next delivery stage"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Next Stage</span>
            </button>
          )}

          <button
            id="call-driver-btn"
            onClick={onCallDriver}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Call Driver</span>
          </button>
        </div>
      </div>

      {/* 6-Stage Timeline Bar */}
      <div className="p-4 sm:p-5 bg-[#171e29] border-b border-[#242f3e] overflow-x-auto">
        <div className="min-w-[620px] flex items-center justify-between relative">
          {/* Progress bar background line */}
          <div className="absolute top-4 left-6 right-6 h-1 bg-[#263345] -z-0"></div>
          {/* Active progress fill */}
          <div
            className="absolute top-4 left-6 h-1 bg-[#e55938] -z-0 transition-all duration-500"
            style={{
              width: `${(currentStageIndex / (stages.length - 1)) * 90}%`
            }}
          ></div>

          {stages.map((stage, idx) => {
            const isCompleted = idx < currentStageIndex;
            const isCurrent = idx === currentStageIndex;

            return (
              <div key={stage} className="flex flex-col items-center text-center z-10 w-24">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                    isCompleted
                      ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                      : isCurrent
                      ? 'bg-[#e55938] text-white ring-4 ring-[#e55938]/30 shadow-lg scale-110'
                      : 'bg-[#222c3b] text-slate-400 border border-[#303e54]'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                </div>
                <span
                  className={`text-[11px] mt-2 font-medium leading-tight ${
                    isCurrent
                      ? 'text-[#e55938] font-bold'
                      : isCompleted
                      ? 'text-slate-200'
                      : 'text-slate-400'
                  }`}
                >
                  {stage}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulated Interactive Vector Map View */}
      <div className="relative bg-[#0d1218] p-4 sm:p-6 overflow-hidden min-h-[300px] flex items-center justify-center">
        {/* Subtle grid pattern background */}
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage:
              'radial-gradient(#3a4960 1px, transparent 1px), radial-gradient(#3a4960 1px, #0d1218 1px)',
            backgroundSize: '24px 24px',
            backgroundPosition: '0 0, 12px 12px'
          }}
        ></div>

        {/* SVG Route Visualization */}
        <svg
          viewBox="0 0 500 320"
          className="w-full max-w-xl h-auto drop-shadow-2xl relative z-10"
        >
          {/* Route path dashed casing */}
          <path
            d={`M ${startX} ${startY} Q ${curveX} ${curveY} ${endX} ${endY}`}
            fill="none"
            stroke="#243042"
            strokeWidth="10"
            strokeLinecap="round"
          />

          {/* Route completed segment */}
          <path
            d={`M ${startX} ${startY} Q ${curveX} ${curveY} ${endX} ${endY}`}
            fill="none"
            stroke="#e55938"
            strokeWidth="6"
            strokeDasharray="8 4"
            strokeLinecap="round"
            className="animate-pulse"
          />

          {/* Pickup Kiln point */}
          <g transform={`translate(${startX}, ${startY})`}>
            <circle r="18" fill="#d97706" opacity="0.2" className="animate-ping" />
            <circle r="12" fill="#d97706" stroke="#fff" strokeWidth="2" />
            <text x="-40" y="28" fill="#fbbf24" fontSize="11" fontWeight="bold">
              Bhatta Kiln
            </text>
            <text x="-55" y="40" fill="#94a3b8" fontSize="9">
              Ghatakpukur Kiln Belt
            </text>
          </g>

          {/* Destination Site point */}
          <g transform={`translate(${endX}, ${endY})`}>
            <circle r="20" fill="#10b981" opacity="0.2" className="animate-ping" />
            <circle r="12" fill="#10b981" stroke="#fff" strokeWidth="2" />
            <text x="-45" y="-18" fill="#34d399" fontSize="11" fontWeight="bold">
              Construction Site
            </text>
            <text x="-55" y="-6" fill="#94a3b8" fontSize="9">
              Anandapur Sector 3
            </text>
          </g>

          {/* Real-time Moving Truck Marker */}
          <g transform={`translate(${truckX}, ${truckY})`}>
            <circle r="22" fill="#e55938" opacity="0.25" className="animate-ping" />
            <circle r="15" fill="#e55938" stroke="#ffffff" strokeWidth="2.5" />
            <g transform="translate(-8, -8) scale(0.7)">
              <path
                d="M1 3h15v13H1z M16 8h4l3 3v5h-7z"
                fill="#ffffff"
              />
            </g>
            {/* Speed badge */}
            <rect
              x="18"
              y="-12"
              width="68"
              height="20"
              rx="10"
              fill="#1e2634"
              stroke="#e55938"
              strokeWidth="1"
            />
            <text x="25" y="2" fill="#ffffff" fontSize="9" fontWeight="bold">
              🚚 38 km/h
            </text>
          </g>
        </svg>

        {/* Live Floating Telemetry Card */}
        <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-auto bg-[#17202c]/90 backdrop-blur-md border border-[#2b394d] rounded-xl p-3 sm:p-4 text-xs text-slate-200 shadow-xl z-20 max-w-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-slate-100 flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-[#e55938]" />
              {order.vehicleNumber || 'WB 39 B 4812'}
            </span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px]">
              ETA: {order.liveTracking?.etaMinutes || 24} Mins
            </span>
          </div>

          <p className="text-slate-400 text-[11px] mb-2 leading-tight">
            📍 Current: {order.liveTracking?.currentStage || 'Basanti Highway near Ruby Junction'}
          </p>

          <div className="flex items-center justify-between pt-2 border-t border-[#253245] text-[11px]">
            <span className="text-slate-400">
              Remaining: <strong className="text-white">11.4 km</strong>
            </span>
            <span className="text-slate-400">
              Load: <strong className="text-[#e55938]">5,000 Bricks</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Driver and OTP Details Bar */}
      <div className="p-4 sm:p-5 bg-[#111720] border-t border-[#242f3e] grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full bg-[#1e2736] border border-[#2c3a50] flex items-center justify-center text-slate-200 font-bold text-sm">
            {order.driverName?.charAt(0) || 'R'}
          </div>
          <div>
            <div className="font-bold text-sm text-white flex items-center gap-1.5">
              <span>{order.driverName || 'Ramen Das'}</span>
              <span className="text-[10px] text-amber-400 font-normal">★ 4.9</span>
            </div>
            <p className="text-xs text-slate-400">{order.vehicleType} • Bholanath Roadways</p>
          </div>
        </div>

        {/* Security Delivery OTP box */}
        <div className="p-3 bg-[#18212e] border border-[#29374d] rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Customer Delivery OTP
            </span>
            <div className="text-xs text-slate-400">Share with driver upon site arrival</div>
          </div>
          <div className="text-xl font-black text-[#e55938] tracking-widest bg-[#10151e] px-3 py-1 rounded-lg border border-[#e55938]/40">
            {order.deliveryOtp}
          </div>
        </div>
      </div>
    </div>
  );
};
