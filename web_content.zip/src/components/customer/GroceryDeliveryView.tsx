import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, Clock, Plus, Minus, Zap, ShieldCheck } from 'lucide-react';

interface GroceryDeliveryViewProps {
  onBack: () => void;
  onOpenCart: () => void;
}

export const GroceryDeliveryView: React.FC<GroceryDeliveryViewProps> = ({ onBack, onOpenCart }) => {
  const { services, addToCart, cart, updateCartQuantity } = useApp();
  const [selectedTag, setSelectedTag] = useState<string>('All');

  const groceryServices = services.filter(s => s.categoryId === 'grocery');

  const tags = ['All', 'Staples', 'Dairy', 'Vegetables', 'Fruits'];
  const filteredList =
    selectedTag === 'All'
      ? groceryServices
      : groceryServices.filter(s => s.tags?.includes(selectedTag));

  const getCartQuantity = (id: string) => {
    const item = cart.find(i => i.service.id === id);
    return item ? item.quantity : 0;
  };

  return (
    <div className="pb-24">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <h2 className="text-sm font-black text-slate-900">AllJi 12-Min Mart</h2>
            </div>
            <p className="text-[11px] text-slate-500 font-semibold">Instant Grocery & Daily Essentials</p>
          </div>
        </div>

        <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
          <Zap className="w-3 h-3 text-emerald-600 fill-emerald-500" />
          <span>12 Mins</span>
        </div>
      </div>

      {/* Quick Aisle Filter Tabs */}
      <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 flex gap-2 overflow-x-auto no-scrollbar">
        {tags.map(tag => (
          <button
            key={tag}
            onClick={() => setSelectedTag(tag)}
            className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedTag === tag
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Grocery Items Grid */}
      <div className="p-4 grid grid-cols-2 gap-3">
        {filteredList.map(item => {
          const qty = getCartQuantity(item.id);
          return (
            <div
              key={item.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-2.5 shadow-xs flex flex-col justify-between"
            >
              <div className="relative">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-28 object-cover rounded-xl"
                />
                <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-slate-900/80 text-white text-[9px] font-bold">
                  {item.unit || '1 pack'}
                </span>
              </div>

              <div className="mt-2 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">{item.description}</p>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-slate-900">
                      ₹{item.discountPrice || item.price}
                    </span>
                    {item.discountPrice && (
                      <span className="text-[10px] text-slate-400 line-through">
                        ₹{item.price}
                      </span>
                    )}
                  </div>

                  {qty === 0 ? (
                    <button
                      id={`add-grocery-${item.id}`}
                      onClick={() => addToCart(item)}
                      className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-extrabold text-xs rounded-xl border border-emerald-300 active:scale-95 transition-all"
                    >
                      ADD
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 bg-emerald-600 text-white px-2 py-1 rounded-xl text-xs font-bold">
                      <button onClick={() => updateCartQuantity(item.id, qty - 1)}>
                        <Minus className="w-3 h-3" />
                      </button>
                      <span>{qty}</span>
                      <button onClick={() => updateCartQuantity(item.id, qty + 1)}>
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Bottom Cart Bar */}
      {cart.length > 0 && (
        <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
          <button
            id="view-grocery-cart-btn"
            onClick={onOpenCart}
            className="w-full p-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black rounded-2xl shadow-xl flex items-center justify-between active:scale-98 transition-all"
          >
            <div className="text-left">
              <span className="text-xs uppercase font-extrabold tracking-wider block text-emerald-100">
                {cart.reduce((a, b) => a + b.quantity, 0)} Items in Bag
              </span>
              <span className="text-sm font-black">
                Total: ₹
                {cart.reduce((a, b) => a + (b.service.discountPrice || b.service.price) * b.quantity, 0)}
              </span>
            </div>
            <span className="text-xs bg-white text-emerald-900 px-3 py-1.5 rounded-xl font-bold">
              View Bag →
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
