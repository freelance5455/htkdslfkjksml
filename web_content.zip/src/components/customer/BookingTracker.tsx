import React, { useState } from 'react';
import { Booking } from '../../types';
import { useMohalla } from '../../context/MohallaContext';
import {
  Clock,
  CheckCircle2,
  Phone,
  MessageSquare,
  AlertCircle,
  XCircle,
  Star,
  MapPin,
  Calendar,
  ChevronRight,
  ShieldCheck,
  Receipt,
} from 'lucide-react';
import { formatCurrencyPKR } from '../../utils/geo';

interface BookingTrackerProps {
  onOpenChat: (bookingId: string) => void;
  onOpenReview: (bookingId: string, providerId: string) => void;
  onViewProvider: (providerId: string) => void;
}

export const BookingTracker: React.FC<BookingTrackerProps> = ({
  onOpenChat,
  onOpenReview,
  onViewProvider,
}) => {
  const { bookings, currentUser, updateBookingStatus, language } = useMohalla();
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('active');
  const [cancelModalBooking, setCancelModalBooking] = useState<Booking | null>(null);
  const [cancelReason, setCancelReason] = useState('Change of plans');

  // Customer's bookings
  const myBookings = bookings.filter((b) => b.customerId === currentUser.id);

  const filteredBookings = myBookings.filter((b) => {
    if (filter === 'active') {
      return ['PENDING', 'ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(b.status);
    }
    if (filter === 'completed') {
      return ['COMPLETED', 'CANCELLED'].includes(b.status);
    }
    return true;
  });

  const getStatusBadge = (status: Booking['status']) => {
    switch (status) {
      case 'PENDING':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 animate-spin" />
            Waiting for Acceptance
          </span>
        );
      case 'ACCEPTED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Accepted by Provider
          </span>
        );
      case 'ARRIVING':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 flex items-center gap-1 animate-pulse">
            <MapPin className="w-3.5 h-3.5" />
            On The Way / Arriving
          </span>
        );
      case 'IN_PROGRESS':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Work In Progress
          </span>
        );
      case 'COMPLETED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Work Completed
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 flex items-center gap-1">
            <XCircle className="w-3.5 h-3.5" />
            Cancelled
          </span>
        );
      default:
        return null;
    }
  };

  const handleConfirmCancel = () => {
    if (!cancelModalBooking) return;
    updateBookingStatus(cancelModalBooking.id, 'CANCELLED', `Cancelled by customer: ${cancelReason}`, {
      cancellationReason: cancelReason,
    });
    setCancelModalBooking(null);
  };

  return (
    <div className="space-y-4">
      {/* Top Filter Tabs */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {language === 'ur' ? 'میری بکنگز' : 'My Bookings & Jobs'}
          </h2>
          <p className="text-xs text-slate-500">Track real-time arrival and job progress</p>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setFilter('active')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              filter === 'active' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            Active ({myBookings.filter((b) => !['COMPLETED', 'CANCELLED'].includes(b.status)).length})
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              filter === 'completed' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            Completed ({myBookings.filter((b) => ['COMPLETED', 'CANCELLED'].includes(b.status)).length})
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              filter === 'all' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            All
          </button>
        </div>
      </div>

      {/* Bookings List */}
      {filteredBookings.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
          <Clock className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700 text-sm">No bookings in this tab</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            When you request an electrician, plumber, or technician, your live booking status will appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredBookings.map((b) => {
            const isCompleted = b.status === 'COMPLETED';
            const isCancelled = b.status === 'CANCELLED';
            const isActive = !isCompleted && !isCancelled;

            return (
              <div
                key={b.id}
                className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all p-5 sm:p-6 space-y-4"
              >
                {/* Header: Provider & Status */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white font-bold flex items-center justify-center text-base">
                      {b.providerName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm sm:text-base text-slate-900">
                          {b.providerName}
                        </span>
                        {b.isEmergency && (
                          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                            Emergency SOS
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                        <span className="font-semibold text-emerald-700">{b.categoryName}</span>
                        <span>•</span>
                        <span>{b.location.area}</span>
                        <span>•</span>
                        <span>Booking ID: #{b.id.slice(-6)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="self-start sm:self-center">{getStatusBadge(b.status)}</div>
                </div>

                {/* Problem Description & Preferred Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-50/80 p-3.5 rounded-2xl border border-slate-100">
                  <div>
                    <span className="font-bold text-slate-400 uppercase tracking-wider block text-[10px] mb-1">
                      Problem Reported
                    </span>
                    <p className="text-slate-800 font-medium leading-relaxed">
                      "{b.problemDescription}"
                    </p>
                  </div>
                  <div>
                    <span className="font-bold text-slate-400 uppercase tracking-wider block text-[10px] mb-1">
                      Scheduled Time & Location
                    </span>
                    <p className="text-slate-800 font-medium">
                      ⏰ {b.preferredTime}
                    </p>
                    <p className="text-slate-500 mt-0.5 truncate">
                      📍 {b.location.address}
                    </p>
                  </div>
                </div>

                {/* Progress Stepper for Active Bookings */}
                {isActive && (
                  <div className="pt-2">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
                      <span className={b.status === 'PENDING' ? 'text-amber-700 font-bold' : ''}>
                        1. Request Sent
                      </span>
                      <span className={b.status === 'ACCEPTED' ? 'text-blue-700 font-bold' : ''}>
                        2. Accepted
                      </span>
                      <span className={b.status === 'ARRIVING' ? 'text-purple-700 font-bold' : ''}>
                        3. Arriving
                      </span>
                      <span className={b.status === 'IN_PROGRESS' ? 'text-teal-700 font-bold' : ''}>
                        4. In Progress
                      </span>
                    </div>
                    {/* Visual Bar */}
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 transition-all duration-500 rounded-full"
                        style={{
                          width:
                            b.status === 'PENDING'
                              ? '25%'
                              : b.status === 'ACCEPTED'
                              ? '50%'
                              : b.status === 'ARRIVING'
                              ? '75%'
                              : '90%',
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Receipt breakdown for Completed */}
                {isCompleted && (
                  <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <Receipt className="w-4 h-4 text-emerald-700" />
                        Final Job Receipt Paid
                      </span>
                      <p className="text-[11px] text-emerald-700 mt-0.5">
                        Visit Fee ({formatCurrencyPKR(b.visitFee)}) + Extra Services / Parts (
                        {formatCurrencyPKR(b.additionalCharges || 0)})
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-base font-extrabold text-emerald-950">
                        {formatCurrencyPKR(b.finalBill || b.visitFee)}
                      </span>
                      <span className="block text-[10px] text-emerald-700 font-medium">
                        Cash on Completion
                      </span>
                    </div>
                  </div>
                )}

                {/* Action Buttons Row */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Chat button */}
                    <button
                      onClick={() => onOpenChat(b.id)}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Chat with Provider</span>
                    </button>

                    {/* Call button */}
                    <a
                      href={`tel:${b.providerPhone || '03001234567'}`}
                      className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      <span>Call ({b.providerPhone || '0321-9456781'})</span>
                    </a>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Cancel button if active */}
                    {isActive && (
                      <button
                        onClick={() => setCancelModalBooking(b)}
                        className="px-3 py-2 rounded-xl text-rose-600 hover:bg-rose-50 text-xs font-semibold cursor-pointer transition-colors"
                      >
                        Cancel Booking
                      </button>
                    )}

                    {/* Rate & Review button if completed */}
                    {isCompleted && !b.hasReview && (
                      <button
                        onClick={() => onOpenReview(b.id, b.providerId)}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer hover:scale-105 transition-all"
                      >
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span>Rate & Review</span>
                      </button>
                    )}

                    {isCompleted && b.hasReview && (
                      <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Reviewed
                      </span>
                    )}

                    {/* View Profile */}
                    <button
                      onClick={() => onViewProvider(b.providerId)}
                      className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer"
                    >
                      Provider Profile
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {cancelModalBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-slate-900 text-base">Cancel Booking?</h3>
            <p className="text-xs text-slate-500 mt-1">
              Are you sure you want to cancel this request with {cancelModalBooking.providerName}?
            </p>

            <div className="mt-4">
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Reason for cancellation:
              </label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-xs text-slate-800"
              >
                <option value="Change of plans">Change of plans</option>
                <option value="Fixed problem myself">Fixed problem myself</option>
                <option value="Found alternative local technician">
                  Found alternative local technician
                </option>
                <option value="Provider taking too long to arrive">
                  Provider taking too long to arrive
                </option>
              </select>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setCancelModalBooking(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Keep Booking
              </button>
              <button
                onClick={handleConfirmCancel}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                Yes, Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
