import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Trash2,
  Plus,
  Minus,
  Tag,
  ShieldCheck,
  CreditCard,
  Banknote,
  Wallet,
  Smartphone,
  CheckCircle2
} from 'lucide-react';
import { PaymentMethod } from '../../types';

interface CartViewProps {
  onBack: () => void;
  onOrderPlaced: (orderId: string) => void;
}

export const CartView: React.FC<CartViewProps> = ({ onBack, onOrderPlaced }) => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartTotal,
    placeOrder,
    currentLocation,
    user,
    deliveryPartners,
    providers
  } = useApp();

  const [couponCode, setCouponCode] = useState('ALLJI50');
  const [isCouponApplied, setIsCouponApplied] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [useWallet, setUseWallet] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (cart.length === 0) {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-500 flex items-center justify-center mb-3">
          <Tag className="w-8 h-8" />
        </div>
        <h3 className="text-base font-black text-slate-900">Your Cart is Empty</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-xs">
          Explore delicious meals, fresh groceries, or doorstep home services to add items!
        </p>
        <button
          onClick={onBack}
          className="mt-4 px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
        >
          Browse All Services
        </button>
      </div>
    );
  }

  const category = cart[0].service.categoryId;
  const deliveryFee = cartTotal > 499 ? 0 : 30;
  const platformFee = 5;
  const taxes = Math.round(cartTotal * 0.05);
  const discount = isCouponApplied ? Math.min(50, cartTotal) : 0;
  const rawGrandTotal = cartTotal + deliveryFee + platformFee + taxes - discount;

  const walletDeduction = useWallet ? Math.min(user.walletBalance, rawGrandTotal) : 0;
  const finalToPay = rawGrandTotal - walletDeduction;

  const handlePlaceOrder = async () => {
    setIsSubmitting(true);
    const assignedPartner = deliveryPartners[0];
    const firstProvider = providers.find(p => p.category === category) || providers[0];

    const newOrder = await placeOrder({
      category,
      providerId: firstProvider?.id,
      providerName: firstProvider?.businessName,
      deliveryPartnerId: assignedPartner?.id,
      deliveryPartnerName: assignedPartner?.name,
      deliveryPartnerPhone: assignedPartner?.phone,
      items: cart.map(i => ({
        serviceId: i.service.id,
        title: i.service.title,
        quantity: i.quantity,
        price: i.service.discountPrice || i.service.price,
        selectedOptions: i.selectedOptions
      })),
      deliveryAddress: {
        id: `addr_${Date.now()}`,
        label: 'Home',
        street: user.savedAddresses[0]?.street || 'Flat 402, Lotus Towers',
        locality: currentLocation.locality,
        city: currentLocation.city,
        pincode: '122002'
      },
      itemTotal: cartTotal,
      deliveryFee,
      platformFee,
      taxes,
      discount,
      grandTotal: rawGrandTotal,
      paymentMethod,
      paymentStatus: paymentMethod === 'cash' ? 'pending' : 'paid',
      status: 'out_for_delivery',
      eta: '20-25 mins',
      deliveryOtp: `${Math.floor(1000 + Math.random() * 9000)}`
    });

    setIsSubmitting(false);
    onOrderPlaced(newOrder.id);
  };

  return (
    <div className="pb-28">
      {/* Header */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-black text-slate-900">Checkout Cart</h2>
            <p className="text-[11px] text-slate-500 font-semibold">
              {cart.reduce((a, b) => a + b.quantity, 0)} Items
            </p>
          </div>
        </div>

        <button
          onClick={clearCart}
          className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg text-xs flex items-center gap-1 font-semibold"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear</span>
        </button>
      </div>

      <div className="p-4 space-y-3.5">
        {/* Delivery Address Pill */}
        <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-black tracking-wider text-amber-800 block">
              Delivering To
            </span>
            <p className="text-xs font-bold text-slate-900 mt-0.5">{currentLocation.locality}</p>
            <p className="text-[11px] text-slate-500">{currentLocation.city}</p>
          </div>
          <span className="text-xs font-bold text-amber-700 bg-white px-2.5 py-1 rounded-xl border border-amber-200">
            Change
          </span>
        </div>

        {/* Cart Items List */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
            Order Items
          </h3>

          <div className="divide-y divide-slate-100">
            {cart.map(item => {
              const price = item.service.discountPrice || item.service.price;
              return (
                <div key={item.service.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="flex-1">
                    <h4 className="text-xs font-bold text-slate-900">{item.service.title}</h4>
                    {item.selectedOptions && (
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {item.selectedOptions.join(' • ')}
                      </p>
                    )}
                    <span className="text-xs font-black text-slate-800 mt-0.5 block">
                      ₹{price * item.quantity}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 bg-slate-100 px-2.5 py-1 rounded-xl">
                    <button
                      onClick={() => updateCartQuantity(item.service.id, item.quantity - 1)}
                      className="text-slate-600 hover:text-slate-900"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs font-black text-slate-900 min-w-[14px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.service.id, item.quantity + 1)}
                      className="text-slate-600 hover:text-slate-900"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Coupon Section */}
        <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-amber-600" />
            <input
              type="text"
              value={couponCode}
              onChange={e => setCouponCode(e.target.value.toUpperCase())}
              placeholder="ENTER COUPON"
              className="text-xs font-bold uppercase text-slate-800 tracking-wider bg-transparent focus:outline-hidden"
            />
          </div>
          <button
            onClick={() => setIsCouponApplied(!isCouponApplied)}
            className={`px-3 py-1 rounded-xl text-xs font-black transition-all ${
              isCouponApplied
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-amber-500 text-slate-950 hover:bg-amber-600'
            }`}
          >
            {isCouponApplied ? 'APPLIED (₹50)' : 'APPLY'}
          </button>
        </div>

        {/* Bill Breakdown */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-1">
            Bill Details
          </h3>

          <div className="flex justify-between text-slate-600">
            <span>Item Total</span>
            <span>₹{cartTotal}</span>
          </div>

          <div className="flex justify-between text-slate-600">
            <span>Delivery Partner Fee</span>
            <span>{deliveryFee === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : `₹${deliveryFee}`}</span>
          </div>

          <div className="flex justify-between text-slate-600">
            <span>Platform Fee</span>
            <span>₹{platformFee}</span>
          </div>

          <div className="flex justify-between text-slate-600">
            <span>Taxes & Restaurant Charges (5%)</span>
            <span>₹{taxes}</span>
          </div>

          {discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-bold">
              <span>Coupon Discount (ALLJI50)</span>
              <span>-₹{discount}</span>
            </div>
          )}

          <div className="pt-2 border-t border-slate-200 flex justify-between font-black text-sm text-slate-900">
            <span>To Pay</span>
            <span>₹{rawGrandTotal}</span>
          </div>
        </div>

        {/* Wallet Deduction Checkbox */}
        {user.walletBalance > 0 && (
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-emerald-700" />
              <div>
                <span className="text-xs font-bold text-slate-900">Use AllJi Wallet</span>
                <span className="text-[10px] text-emerald-700 block">
                  Available Balance: ₹{user.walletBalance}
                </span>
              </div>
            </div>
            <input
              type="checkbox"
              checked={useWallet}
              onChange={e => setUseWallet(e.target.checked)}
              className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
            />
          </div>
        )}

        {/* Payment Modes */}
        <div className="space-y-2">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
            Choose Payment Mode
          </h3>

          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'upi', label: 'UPI (GPay, PhonePe, Paytm)', icon: Smartphone },
              { id: 'card', label: 'Credit / Debit Card', icon: CreditCard },
              { id: 'wallet', label: 'AllJi Wallet Pay', icon: Wallet },
              { id: 'cash', label: 'Cash on Delivery (COD)', icon: Banknote }
            ].map(m => {
              const Icon = m.icon;
              const isSelected = paymentMethod === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                  className={`p-2.5 rounded-2xl border text-left flex items-center gap-2.5 transition-all ${
                    isSelected
                      ? 'border-amber-500 bg-amber-50 ring-1 ring-amber-500 shadow-xs'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-600' : 'text-slate-400'}`} />
                  <span className="text-xs font-bold text-slate-800 leading-tight">{m.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Floating Checkout Button */}
      <div className="fixed bottom-14 left-0 right-0 p-3 z-40 max-w-[420px] mx-auto">
        <button
          id="checkout-confirm-btn"
          disabled={isSubmitting}
          onClick={handlePlaceOrder}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-black rounded-2xl shadow-xl flex items-center justify-between px-5 active:scale-98 transition-all disabled:opacity-50"
        >
          <div className="text-left">
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-900/80 block">
              Pay via {paymentMethod.toUpperCase()}
            </span>
            <span className="text-sm font-black">
              ₹{finalToPay} {useWallet && `(₹${walletDeduction} from wallet)`}
            </span>
          </div>
          <span className="bg-slate-950 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold">
            {isSubmitting ? 'Placing Order...' : 'Place Order →'}
          </span>
        </button>
      </div>
    </div>
  );
};
