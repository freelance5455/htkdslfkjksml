import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Wallet,
  MapPin,
  ShieldCheck,
  Headphones,
  HelpCircle,
  Plus,
  Trash2,
  ChevronRight,
  Sparkles,
  PhoneCall,
  LogOut,
  CreditCard
} from 'lucide-react';

export const UserProfileView: React.FC = () => {
  const { user, setUser, setIsSosOpen, setIsAuthOpen } = useApp();
  const [topupAmount, setTopupAmount] = useState<number>(500);
  const [showTopupModal, setShowTopupModal] = useState(false);
  const [showAddAddressModal, setShowAddAddressModal] = useState(false);
  const [newStreet, setNewStreet] = useState('');
  const [newLocality, setNewLocality] = useState('');
  const [newCity, setNewCity] = useState('Gurugram');

  const handleTopup = () => {
    setUser({ ...user, walletBalance: user.walletBalance + topupAmount });
    setShowTopupModal(false);
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStreet || !newLocality) return;
    const newAddr = {
      id: `addr_${Date.now()}`,
      label: 'Other' as const,
      street: newStreet,
      locality: newLocality,
      city: newCity,
      pincode: '122002'
    };
    setUser({ ...user, savedAddresses: [...user.savedAddresses, newAddr] });
    setNewStreet('');
    setNewLocality('');
    setShowAddAddressModal(false);
  };

  return (
    <div className="pb-24">
      {/* Profile Header */}
      <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400"
          />
          <div>
            <h2 className="text-base font-black text-white">{user.name}</h2>
            <p className="text-xs text-slate-300">{user.phone}</p>
            <p className="text-[11px] text-slate-400">{user.email}</p>
          </div>
        </div>

        <button
          onClick={() => setIsAuthOpen(true)}
          className="text-xs font-bold px-2.5 py-1 rounded-xl bg-slate-800 text-amber-400 border border-slate-700"
        >
          Switch
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* AllJi Wallet Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 shadow-lg flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-slate-900/80">
              <Wallet className="w-3.5 h-3.5" />
              <span>AllJi Cash Wallet</span>
            </div>
            <h3 className="text-2xl font-black mt-1">₹{user.walletBalance}</h3>
            <p className="text-[10px] text-slate-900/90 font-medium">Instant refunds & 1-tap checkout</p>
          </div>

          <button
            onClick={() => setShowTopupModal(true)}
            className="px-3 py-2 bg-slate-950 text-white rounded-xl text-xs font-black shadow-md hover:bg-slate-900 active:scale-95 transition-transform"
          >
            + Add Money
          </button>
        </div>

        {/* Saved Addresses */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-600" />
              <span>Saved Addresses</span>
            </h3>
            <button
              onClick={() => setShowAddAddressModal(true)}
              className="text-[11px] font-bold text-amber-600 hover:text-amber-700 flex items-center gap-0.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          <div className="space-y-2 pt-1">
            {user.savedAddresses.map(addr => (
              <div
                key={addr.id}
                className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-900">{addr.label}</span>
                    {addr.isDefault && (
                      <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-sm">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-slate-600 text-[11px] mt-0.5">{addr.street}</p>
                  <p className="text-slate-400 text-[10px]">{addr.locality}, {addr.city}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Safety Contacts */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-red-600" />
              <span>Emergency Contacts</span>
            </h3>
            <button
              onClick={() => setIsSosOpen(true)}
              className="text-[11px] font-bold text-red-600 hover:text-red-700"
            >
              Test SOS
            </button>
          </div>

          <div className="space-y-1.5 pt-1 text-xs">
            {user.emergencyContacts.map(ec => (
              <div
                key={ec.id}
                className="p-2.5 rounded-xl bg-red-50/50 border border-red-100 flex items-center justify-between"
              >
                <div>
                  <p className="font-bold text-slate-900">{ec.name}</p>
                  <p className="text-[11px] text-slate-500">{ec.phone}</p>
                </div>
                <span className="text-[10px] font-semibold text-red-700 bg-red-100 px-2 py-0.5 rounded-md">
                  {ec.relation}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 24x7 Help & Support */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <Headphones className="w-3.5 h-3.5 text-blue-600" />
            <span>AllJi 24x7 Support</span>
          </h3>

          <div className="space-y-2 pt-1 text-xs">
            <a
              href="tel:18002555472"
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between transition-colors"
            >
              <div className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-emerald-600" />
                <div>
                  <p className="font-bold text-slate-900">Toll-Free Customer Care</p>
                  <p className="text-[10px] text-slate-500">1800-ALLJI-CARE (1800-255-5472)</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </a>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <p className="font-bold text-slate-900">FAQs & Cancellation Policy</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Instant refunds credited to AllJi Wallet upon cancellation before partner reaches pickup.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Topup Modal */}
      {showTopupModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3 shadow-2xl">
            <h3 className="text-sm font-black text-slate-900">Add Money to AllJi Wallet</h3>
            <p className="text-xs text-slate-500">Choose quick recharge amount:</p>

            <div className="grid grid-cols-3 gap-2">
              {[200, 500, 1000].map(amt => (
                <button
                  key={amt}
                  onClick={() => setTopupAmount(amt)}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                    topupAmount === amt
                      ? 'bg-amber-500 text-slate-950 border-amber-600'
                      : 'bg-slate-50 text-slate-800 border-slate-200'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowTopupModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleTopup}
                className="flex-1 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Add ₹{topupAmount}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Address Modal */}
      {showAddAddressModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddAddress}
            className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3 shadow-2xl"
          >
            <h3 className="text-sm font-black text-slate-900">Add Delivery Address</h3>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Street / House No.</label>
              <input
                type="text"
                value={newStreet}
                onChange={e => setNewStreet(e.target.value)}
                placeholder="e.g. Flat 104, Sunrise Heights"
                required
                className="w-full p-2 text-xs rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Locality</label>
              <input
                type="text"
                value={newLocality}
                onChange={e => setNewLocality(e.target.value)}
                placeholder="e.g. Sushant Lok Phase 1"
                required
                className="w-full p-2 text-xs rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddAddressModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Save Address
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
