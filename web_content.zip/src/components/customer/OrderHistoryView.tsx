import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Order } from '../../types';
import {
  Clock,
  RotateCcw,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Receipt,
  FileText,
  Star
} from 'lucide-react';

interface OrderHistoryViewProps {
  onSelectOrder: (order: Order) => void;
}

export const OrderHistoryView: React.FC<OrderHistoryViewProps> = ({ onSelectOrder }) => {
  const { orders } = useApp();
  const [tab, setTab] = useState<'active' | 'past'>('active');

  const activeOrders = orders.filter(
    o => o.status !== 'completed' && o.status !== 'cancelled' && o.status !== 'refunded'
  );
  const pastOrders = orders.filter(
    o => o.status === 'completed' || o.status === 'cancelled' || o.status === 'refunded'
  );

  const displayedList = tab === 'active' ? activeOrders : pastOrders;

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-4 py-3 bg-white border-b border-slate-200 sticky top-0 z-20">
        <h2 className="text-sm font-black text-slate-900">Your Bookings & Orders</h2>
        <p className="text-[11px] text-slate-500 font-semibold">Track real-time status & view receipts</p>
      </div>

      {/* Tabs */}
      <div className="px-4 pt-3 flex gap-2">
        <button
          onClick={() => setTab('active')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            tab === 'active'
              ? 'bg-amber-500 text-slate-950 shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Active Bookings ({activeOrders.length})
        </button>
        <button
          onClick={() => setTab('past')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            tab === 'past'
              ? 'bg-amber-500 text-slate-950 shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Past History ({pastOrders.length})
        </button>
      </div>

      {/* Orders List */}
      <div className="p-4 space-y-3">
        {displayedList.length === 0 ? (
          <div className="py-12 text-center">
            <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-600">No {tab} orders found</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Explore services to make a new booking.</p>
          </div>
        ) : (
          displayedList.map(order => {
            const isCompleted = order.status === 'completed';
            const isCancelled = order.status === 'cancelled' || order.status === 'refunded';

            return (
              <div
                key={order.id}
                onClick={() => onSelectOrder(order)}
                className="p-3.5 bg-white rounded-2xl border border-slate-200 hover:border-amber-400 shadow-xs cursor-pointer transition-all space-y-2.5 active:scale-99"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      #{order.orderNumber} • {new Date(order.createdAt).toLocaleDateString()}
                    </span>
                    <h3 className="text-xs font-black text-slate-900 capitalize">
                      {order.category.replace('_', ' ')} • {order.items?.[0]?.title || 'Service'}
                    </h3>
                  </div>

                  <span
                    className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                      isCompleted
                        ? 'bg-emerald-100 text-emerald-800'
                        : isCancelled
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800 animate-pulse'
                    }`}
                  >
                    {order.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100">
                  <span>
                    Total: <b className="text-slate-900 font-black">₹{order.grandTotal}</b>
                  </span>

                  <div className="flex items-center gap-1 text-amber-600 font-bold text-[11px]">
                    <span>View Tracking & Receipt</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>

                {order.refundAmount && order.refundAmount > 0 && (
                  <div className="p-1.5 bg-emerald-50 rounded-lg text-[10px] font-bold text-emerald-800 flex items-center gap-1">
                    <RotateCcw className="w-3 h-3" />
                    <span>Refund of ₹{order.refundAmount} credited to AllJi Wallet</span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
