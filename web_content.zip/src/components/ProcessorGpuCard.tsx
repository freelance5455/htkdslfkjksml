import React from 'react';
import { Cpu, Gauge, Zap, Flame, ShieldAlert } from 'lucide-react';

interface ProcessorGpuCardProps {
  cpuTemp: number;
  gpuTemp: number;
  batteryTemp: number;
}

export const ProcessorGpuCard: React.FC<ProcessorGpuCardProps> = ({
  cpuTemp,
  gpuTemp,
}) => {
  // Valutazione termica CPU
  const isCpuThrottling = cpuTemp >= 70;
  const isCpuWarm = cpuTemp >= 55 && cpuTemp < 70;

  // Valutazione termica GPU
  const isGpuThrottling = gpuTemp >= 65;
  const isGpuWarm = gpuTemp >= 50 && gpuTemp < 65;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* CPU Card */}
      <div className="rounded-2xl bg-neutral-950 border border-neutral-800 p-5 relative overflow-hidden transition-all">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-sky-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                Processore (CPU)
                {isCpuThrottling && (
                  <span className="text-[10px] font-mono uppercase bg-red-950/80 border border-red-700 text-red-400 px-1.5 py-0.5 rounded">
                    Throttling
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-neutral-400">
                Core Cortex / Kryo SoC
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono font-bold text-neutral-100">
              {cpuTemp.toFixed(1)}°C
            </div>
            <span
              className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                isCpuThrottling
                  ? 'bg-red-950 text-red-400 border border-red-800'
                  : isCpuWarm
                  ? 'bg-amber-950 text-amber-400 border border-amber-800'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}
            >
              {isCpuThrottling ? 'Critico' : isCpuWarm ? 'Caldo' : 'Stabile'}
            </span>
          </div>
        </div>

        {/* Barra di temperatura CPU */}
        <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden mt-3 mb-2">
          <div
            className={`h-full transition-all duration-300 ${
              isCpuThrottling
                ? 'bg-red-500'
                : isCpuWarm
                ? 'bg-amber-500'
                : 'bg-sky-500'
            }`}
            style={{ width: `${Math.min(100, Math.max(10, (cpuTemp / 85) * 100))}%` }}
          />
        </div>

        <div className="text-[11px] text-neutral-400 flex items-center justify-between mt-2">
          <span>Soglia termica sicura: &lt; 65°C</span>
          <span className="text-neutral-500">Taglio frequenze a 75°C</span>
        </div>

        <div className="mt-3 pt-3 border-t border-neutral-900 text-xs text-neutral-300 space-y-1">
          <p className="text-[11px] text-neutral-400">
            <span className="text-neutral-200 font-medium">Impatto da surriscaldamento:</span> Quando la CPU scalda oltre i 70°C entra in gioco il thermal throttling che dimezza i clock, rallenta l'interfaccia e causa stuttering nei giochi. Nel tempo, l'elettromigrazione ad alta temperatura riduce l'efficienza dei transistor in scala nanometrica.
          </p>
        </div>
      </div>

      {/* GPU Card */}
      <div className="rounded-2xl bg-neutral-950 border border-neutral-800 p-5 relative overflow-hidden transition-all">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-purple-400">
              <Gauge className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                Processore Grafico (GPU)
                {isGpuThrottling && (
                  <span className="text-[10px] font-mono uppercase bg-red-950/80 border border-red-700 text-red-400 px-1.5 py-0.5 rounded">
                    Thermal Drop
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-neutral-400">
                Pipeline Adreno / Mali / Immortalis
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono font-bold text-neutral-100">
              {gpuTemp.toFixed(1)}°C
            </div>
            <span
              className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                isGpuThrottling
                  ? 'bg-red-950 text-red-400 border border-red-800'
                  : isGpuWarm
                  ? 'bg-amber-950 text-amber-400 border border-amber-800'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}
            >
              {isGpuThrottling ? 'Critico' : isGpuWarm ? 'Attivo' : 'Freddo'}
            </span>
          </div>
        </div>

        {/* Barra di temperatura GPU */}
        <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden mt-3 mb-2">
          <div
            className={`h-full transition-all duration-300 ${
              isGpuThrottling
                ? 'bg-red-500'
                : isGpuWarm
                ? 'bg-amber-500'
                : 'bg-purple-500'
            }`}
            style={{ width: `${Math.min(100, Math.max(10, (gpuTemp / 80) * 100))}%` }}
          />
        </div>

        <div className="text-[11px] text-neutral-400 flex items-center justify-between mt-2">
          <span>Soglia termica sicura: &lt; 60°C</span>
          <span className="text-neutral-500">Thermal drop a 68°C</span>
        </div>

        <div className="mt-3 pt-3 border-t border-neutral-900 text-xs text-neutral-300 space-y-1">
          <p className="text-[11px] text-neutral-400">
            <span className="text-neutral-200 font-medium">Impatto da surriscaldamento:</span> La GPU gestisce shader 3D, animazioni a 120Hz e rendering video. A temperature elevate le tensioni calano drasticamente causando perdita di frame al secondo (FPS drop) e instabilità dell'alimentazione sul bus grafico.
          </p>
        </div>
      </div>
    </div>
  );
};
