import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wrench,
  Search,
  KeyRound,
  QrCode,
  FileText,
  CheckSquare,
  ShoppingCart,
  Users,
  Timer,
  Clock,
  Sparkles,
  RefreshCw,
  Sun,
  Copy,
  Trash2,
  Plus,
  Pin,
  Check,
  Download,
  Upload,
  ArrowRight,
  Volume2,
} from 'lucide-react';
import { UNIT_CATEGORIES, UnitCategory, convertUnits } from '../../utils/unitConverter';
import {
  generateSecurePassword,
  calculatePasswordEntropy,
  generateSecureRandomNumbers,
} from '../../utils/cryptoSecurity';
import QRCode from 'qrcode';

type ToolId =
  | 'directory'
  | 'unit_converter'
  | 'password_gen'
  | 'qr_code'
  | 'notes'
  | 'todo'
  | 'shopping'
  | 'expense'
  | 'text_counter'
  | 'stopwatch'
  | 'timer'
  | 'flashlight';

export const ToolsDirectory: React.FC = () => {
  const {
    triggerHaptic,
    showToast,
    settings,
    notes,
    addNote,
    updateNote,
    deleteNote,
    todos,
    addTodo,
    toggleTodo,
    deleteTodo,
    shoppingList,
    addShoppingItem,
    toggleShoppingItem,
    deleteShoppingItem,
    clearCheckedShopping,
    expenses,
    addExpense,
    deleteExpense,
  } = useApp();

  const [activeTool, setActiveTool] = useState<ToolId>('directory');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // 1. UNIT CONVERTER STATE
  const [unitCategory, setUnitCategory] = useState<UnitCategory>('length');
  const [unitInputValue, setUnitInputValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<string>('m');
  const [toUnit, setToUnit] = useState<string>('km');

  // Update units when category changes
  const handleCategoryChange = (cat: UnitCategory) => {
    setUnitCategory(cat);
    const units = UNIT_CATEGORIES[cat].units;
    if (units.length >= 2) {
      setFromUnit(units[0].id);
      setToUnit(units[1].id);
    }
  };

  // 2. PASSWORD GENERATOR STATE
  const [pwdLength, setPwdLength] = useState<number>(16);
  const [pwdUpper, setPwdUpper] = useState<boolean>(true);
  const [pwdLower, setPwdLower] = useState<boolean>(true);
  const [pwdNumbers, setPwdNumbers] = useState<boolean>(true);
  const [pwdSymbols, setPwdSymbols] = useState<boolean>(true);
  const [pwdNoAmbiguous, setPwdNoAmbiguous] = useState<boolean>(false);
  const [generatedPassword, setGeneratedPassword] = useState<string>('');

  const handleGeneratePassword = () => {
    triggerHaptic();
    const pwd = generateSecurePassword({
      length: pwdLength,
      includeUppercase: pwdUpper,
      includeLowercase: pwdLower,
      includeNumbers: pwdNumbers,
      includeSymbols: pwdSymbols,
      excludeAmbiguous: pwdNoAmbiguous,
    });
    setGeneratedPassword(pwd);
  };

  useEffect(() => {
    handleGeneratePassword();
  }, []);

  // RNG State
  const [rngMin, setRngMin] = useState<string>('1');
  const [rngMax, setRngMax] = useState<string>('100');
  const [rngCount, setRngCount] = useState<string>('5');
  const [rngUnique, setRngUnique] = useState<boolean>(true);
  const [generatedNumbers, setGeneratedNumbers] = useState<number[]>([]);

  const handleGenerateRNG = () => {
    triggerHaptic();
    const min = parseInt(rngMin) || 1;
    const max = parseInt(rngMax) || 100;
    const count = parseInt(rngCount) || 1;
    const nums = generateSecureRandomNumbers(min, max, count, rngUnique);
    setGeneratedNumbers(nums);
  };

  // 3. QR CODE STATE
  const [qrText, setQrText] = useState<string>('https://salmanmehdi.substack.com');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (qrText) {
      QRCode.toDataURL(qrText, { width: 300, margin: 2 })
        .then((url) => setQrDataUrl(url))
        .catch(() => {});
    }
  }, [qrText]);

  // 4. NOTES STATE
  const [noteTitle, setNoteTitle] = useState<string>('');
  const [noteContent, setNoteContent] = useState<string>('');
  const [noteCategory, setNoteCategory] = useState<string>('General');
  const [noteSearch, setNoteSearch] = useState<string>('');

  // 5. TODO STATE
  const [newTodoText, setNewTodoText] = useState<string>('');
  const [newTodoPriority, setNewTodoPriority] = useState<'low' | 'medium' | 'high'>('medium');

  // 6. SHOPPING STATE
  const [shopName, setShopName] = useState<string>('');
  const [shopQty, setShopQty] = useState<string>('1');
  const [shopPrice, setShopPrice] = useState<string>('');

  // 7. EXPENSE SPLITTER STATE
  const [expTitle, setExpTitle] = useState<string>('Dinner with Friends');
  const [expAmount, setExpAmount] = useState<string>('120');
  const [expTip, setExpTip] = useState<string>('10');
  const [expTax, setExpTax] = useState<string>('5');
  const [expPeople, setExpPeople] = useState<string>('4');

  // 8. TEXT COUNTER STATE
  const [countedText, setCountedText] = useState<string>(
    'Pocket Toolkit is an all-in-one utility application built for Android by Syed Salman Mehdi. It features a reliable scientific calculator, storage management, everyday tools, and complete offline capability.'
  );

  // 9. STOPWATCH STATE
  const [stopwatchRunning, setStopwatchRunning] = useState<boolean>(false);
  const [stopwatchTime, setStopwatchTime] = useState<number>(0);
  const [laps, setLaps] = useState<number[]>([]);
  const stopwatchRef = useRef<any>(null);

  useEffect(() => {
    if (stopwatchRunning) {
      stopwatchRef.current = setInterval(() => {
        setStopwatchTime((prev) => prev + 10);
      }, 10);
    } else {
      clearInterval(stopwatchRef.current);
    }
    return () => clearInterval(stopwatchRef.current);
  }, [stopwatchRunning]);

  const handleStopwatchLap = () => {
    triggerHaptic();
    setLaps((prev) => [stopwatchTime, ...prev]);
  };

  const handleStopwatchReset = () => {
    triggerHaptic();
    setStopwatchRunning(false);
    setStopwatchTime(0);
    setLaps([]);
  };

  const formatTimer = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const centis = Math.floor((ms % 1000) / 10);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(centis).padStart(2, '0')}`;
  };

  // 10. COUNTDOWN TIMER STATE
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number>(300);
  const [timerDuration, setTimerDuration] = useState<number>(300);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (timerRunning && timerSecondsLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimerSecondsLeft((prev) => {
          if (prev <= 1) {
            setTimerRunning(false);
            triggerHaptic();
            showToast('Countdown Timer Finished!', 'info');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [timerRunning, timerSecondsLeft]);

  // 11. FLASHLIGHT STATE
  const [screenTorch, setScreenTorch] = useState<boolean>(false);
  const [torchBrightness, setTorchBrightness] = useState<number>(100);

  // Tools List Metadata
  const toolsList = [
    {
      id: 'unit_converter',
      title: 'Unit Converter',
      desc: 'Length, Mass, Speed, Temp, Pressure & Binary Digital Storage',
      icon: RefreshCw,
      color: 'bg-emerald-50 dark:bg-emerald-950/40 text-[#006C4C] dark:text-[#89F8C7]',
    },
    {
      id: 'password_gen',
      title: 'Password & Random Gen',
      desc: 'Cryptographically secure CSPRNG with entropy analysis',
      icon: KeyRound,
      color: 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300',
    },
    {
      id: 'qr_code',
      title: 'QR Code Generator',
      desc: 'Generate crisp QR codes for links, text, and Wi-Fi',
      icon: QrCode,
      color: 'bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300',
    },
    {
      id: 'notes',
      title: 'Local Notes & Memo',
      desc: 'Room-like SQLite offline notepad with search and pinning',
      icon: FileText,
      color: 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300',
    },
    {
      id: 'todo',
      title: 'To-Do & Tasks',
      desc: 'Offline task checklist with priority and completion tracking',
      icon: CheckSquare,
      color: 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300',
    },
    {
      id: 'shopping',
      title: 'Shopping List',
      desc: 'Item quantities, price estimates, and total spending tally',
      icon: ShoppingCart,
      color: 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300',
    },
    {
      id: 'expense',
      title: 'Expense & Bill Splitter',
      desc: 'Split meals, tax, and tips among family and friends',
      icon: Users,
      color: 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300',
    },
    {
      id: 'text_counter',
      title: 'Text & Word Counter',
      desc: 'Character, word, and reading-time analyzer',
      icon: Sparkles,
      color: 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300',
    },
    {
      id: 'stopwatch',
      title: 'Stopwatch & Laps',
      desc: 'Precision millisecond stopwatch with split lap records',
      icon: Timer,
      color: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300',
    },
    {
      id: 'timer',
      title: 'Countdown Timer',
      desc: 'Preset countdown with vibration notifications',
      icon: Clock,
      color: 'bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300',
    },
    {
      id: 'flashlight',
      title: 'Screen Flashlight / Torch',
      desc: 'High-luminance display torch with intensity control',
      icon: Sun,
      color: 'bg-yellow-50 dark:bg-yellow-950/40 text-yellow-700 dark:text-yellow-400',
    },
  ];

  const filteredTools = toolsList.filter(
    (t) =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Search & Navigation Bar */}
      {activeTool === 'directory' ? (
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Search offline utilities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200 dark:border-neutral-800 text-sm shadow-xs focus:outline-hidden focus:ring-2 focus:ring-[#006C4C]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {filteredTools.map((tool) => {
              const Icon = tool.icon;
              return (
                <button
                  key={tool.id}
                  onClick={() => {
                    triggerHaptic();
                    setActiveTool(tool.id as ToolId);
                  }}
                  className="p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all flex items-center justify-between group shadow-xs text-left"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${tool.color}`}>
                      <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">{tool.title}</h3>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-snug line-clamp-1">
                        {tool.desc}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-[#006C4C] dark:group-hover:text-[#89F8C7] shrink-0 ml-2" />
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        /* Back to Directory Top Strip */
        <div className="flex items-center justify-between pb-2 border-b border-neutral-200 dark:border-neutral-800">
          <button
            onClick={() => {
              triggerHaptic();
              setActiveTool('directory');
            }}
            className="flex items-center space-x-1.5 text-xs font-semibold text-[#006C4C] dark:text-[#89F8C7] hover:underline"
          >
            <span>&larr; Back to Tools Directory</span>
          </button>
          <span className="text-xs font-bold text-neutral-600 dark:text-neutral-300">
            {toolsList.find((t) => t.id === activeTool)?.title}
          </span>
        </div>
      )}

      {/* 1. UNIT CONVERTER */}
      {activeTool === 'unit_converter' && (
        <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-4">
          <div className="flex overflow-x-auto space-x-1 pb-1 text-xs">
            {(Object.keys(UNIT_CATEGORIES) as UnitCategory[]).map((cat) => (
              <button
                key={cat}
                onClick={() => handleCategoryChange(cat)}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition-all ${
                  unitCategory === cat
                    ? 'bg-[#006C4C] text-white'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                }`}
              >
                {UNIT_CATEGORIES[cat].title}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* From Input */}
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl space-y-2 border border-neutral-200 dark:border-neutral-700">
              <label className="text-[11px] font-semibold text-neutral-500 uppercase">From</label>
              <input
                type="number"
                value={unitInputValue}
                onChange={(e) => setUnitInputValue(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-neutral-300 dark:border-neutral-600 bg-white dark:bg-neutral-800 font-mono font-bold text-lg"
              />
              <select
                value={fromUnit}
                onChange={(e) => setFromUnit(e.target.value)}
                className="w-full p-2 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-600 text-xs font-medium"
              >
                {UNIT_CATEGORIES[unitCategory].units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>

            {/* To Output */}
            <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-2xl space-y-2 border border-emerald-600/20">
              <label className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 uppercase">
                Converted Result
              </label>
              <div className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 font-mono font-bold text-lg text-[#006C4C] dark:text-[#89F8C7] overflow-x-auto truncate">
                {convertUnits(parseFloat(unitInputValue) || 0, unitCategory, fromUnit, toUnit)}
              </div>
              <select
                value={toUnit}
                onChange={(e) => setToUnit(e.target.value)}
                className="w-full p-2 rounded-xl bg-white dark:bg-neutral-800 border border-emerald-300 dark:border-emerald-700 text-xs font-medium"
              >
                {UNIT_CATEGORIES[unitCategory].units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* 2. PASSWORD & RANDOM GENERATOR */}
      {activeTool === 'password_gen' && (
        <div className="space-y-4">
          {/* Password Gen */}
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-4">
            <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-[#006C4C] dark:text-[#89F8C7]" />
              <span>Cryptographic Password Generator</span>
            </h3>

            {/* Password Display Box */}
            <div className="p-3.5 bg-neutral-100 dark:bg-neutral-800 rounded-2xl flex items-center justify-between border border-neutral-200 dark:border-neutral-700">
              <span className="font-mono text-base font-bold text-neutral-900 dark:text-neutral-100 break-all select-all">
                {generatedPassword}
              </span>
              <div className="flex items-center space-x-1 shrink-0 ml-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedPassword);
                    showToast('Password copied', 'success');
                  }}
                  title="Copy"
                  className="p-2 rounded-xl bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 shadow-xs"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={handleGeneratePassword}
                  title="Regenerate"
                  className="p-2 rounded-xl bg-[#006C4C] text-white shadow-xs"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Entropy & Strength Gauge */}
            {(() => {
              const entropy = calculatePasswordEntropy(generatedPassword);
              return (
                <div className="flex items-center justify-between text-xs px-1">
                  <span className="text-neutral-500">
                    Strength: <strong className="text-emerald-600 dark:text-emerald-400">{entropy.strength}</strong> ({entropy.bits} bits of entropy)
                  </span>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((lvl) => (
                      <div
                        key={lvl}
                        className={`w-4 h-1.5 rounded-full ${
                          lvl <= entropy.score ? 'bg-emerald-600' : 'bg-neutral-200 dark:bg-neutral-700'
                        }`}
                      ></div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* Settings */}
            <div className="space-y-3 pt-2 border-t border-neutral-100 dark:border-neutral-800 text-xs">
              <div>
                <div className="flex justify-between font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  <span>Password Length</span>
                  <span>{pwdLength} characters</span>
                </div>
                <input
                  type="range"
                  min="8"
                  max="48"
                  value={pwdLength}
                  onChange={(e) => {
                    setPwdLength(parseInt(e.target.value));
                    handleGeneratePassword();
                  }}
                  className="w-full accent-[#006C4C]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={pwdUpper}
                    onChange={(e) => setPwdUpper(e.target.checked)}
                    className="rounded text-[#006C4C]"
                  />
                  <span>Uppercase (A-Z)</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={pwdLower}
                    onChange={(e) => setPwdLower(e.target.checked)}
                    className="rounded text-[#006C4C]"
                  />
                  <span>Lowercase (a-z)</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={pwdNumbers}
                    onChange={(e) => setPwdNumbers(e.target.checked)}
                    className="rounded text-[#006C4C]"
                  />
                  <span>Numbers (0-9)</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={pwdSymbols}
                    onChange={(e) => setPwdSymbols(e.target.checked)}
                    className="rounded text-[#006C4C]"
                  />
                  <span>Symbols (!@#$)</span>
                </label>
              </div>
            </div>
          </div>

          {/* Random Numbers Gen */}
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
            <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
              Secure Random Number Generator (RNG)
            </h3>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] uppercase font-bold text-neutral-500">Min</label>
                <input
                  type="number"
                  value={rngMin}
                  onChange={(e) => setRngMin(e.target.value)}
                  className="w-full p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-neutral-500">Max</label>
                <input
                  type="number"
                  value={rngMax}
                  onChange={(e) => setRngMax(e.target.value)}
                  className="w-full p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-neutral-500">Count</label>
                <input
                  type="number"
                  value={rngCount}
                  onChange={(e) => setRngCount(e.target.value)}
                  className="w-full p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                />
              </div>
            </div>

            <button
              onClick={handleGenerateRNG}
              className="w-full py-2.5 rounded-xl bg-[#006C4C] text-white text-xs font-bold hover:bg-[#004D36] active:scale-95 transition-all shadow-xs"
            >
              Generate Numbers
            </button>

            {generatedNumbers.length > 0 && (
              <div className="p-3 rounded-xl bg-neutral-100 dark:bg-neutral-800/60 font-mono text-sm font-bold text-center text-[#006C4C] dark:text-[#89F8C7] flex flex-wrap gap-2 justify-center">
                {generatedNumbers.map((num, i) => (
                  <span key={i} className="px-2.5 py-1 rounded-lg bg-white dark:bg-neutral-700 shadow-2xs">
                    {num}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. QR CODE GENERATOR */}
      {activeTool === 'qr_code' && (
        <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-4">
          <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
            Offline QR Code Generator
          </h3>

          <div>
            <label className="text-xs font-semibold text-neutral-500">Content / URL / Text</label>
            <input
              type="text"
              value={qrText}
              onChange={(e) => setQrText(e.target.value)}
              placeholder="Enter text or link..."
              className="w-full mt-1 p-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-medium"
            />
          </div>

          {qrDataUrl && (
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-2xl border border-neutral-200 shadow-inner">
              <img src={qrDataUrl} alt="Generated QR" className="w-52 h-52 object-contain" />
              <div className="mt-3 flex space-x-2">
                <a
                  href={qrDataUrl}
                  download="pocket-toolkit-qr.png"
                  className="px-4 py-2 rounded-xl bg-[#006C4C] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Image</span>
                </a>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. LOCAL NOTES */}
      {activeTool === 'notes' && (
        <div className="space-y-4">
          {/* New Note Form */}
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
            <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">Create Local Memo</h3>
            <input
              type="text"
              placeholder="Note Title"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
            />
            <textarea
              placeholder="Write note content here..."
              rows={3}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-normal"
            ></textarea>
            <div className="flex justify-between items-center">
              <input
                type="text"
                placeholder="Category (e.g. Work)"
                value={noteCategory}
                onChange={(e) => setNoteCategory(e.target.value)}
                className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs w-32"
              />
              <button
                onClick={() => {
                  if (!noteTitle && !noteContent) return;
                  addNote(noteTitle, noteContent, noteCategory);
                  setNoteTitle('');
                  setNoteContent('');
                }}
                className="px-4 py-2 rounded-xl bg-[#006C4C] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Save Note</span>
              </button>
            </div>
          </div>

          {/* Notes List */}
          <div className="space-y-2">
            {notes.map((note) => (
              <div
                key={note.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  note.isPinned
                    ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-600/30'
                    : 'bg-white dark:bg-[#1B221E] border-neutral-200 dark:border-neutral-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5">
                      {note.isPinned && <Pin className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600" />}
                      <span>{note.title}</span>
                    </h4>
                    <span className="text-[10px] font-medium text-neutral-400">
                      {note.category} • {new Date(note.updatedAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => updateNote(note.id, { isPinned: !note.isPinned })}
                      className="p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteNote(note.id)}
                      className="p-1.5 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-950/40 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <p className="mt-2 text-xs text-neutral-600 dark:text-neutral-300 whitespace-pre-wrap leading-relaxed">
                  {note.content}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. TO-DO & TASKS */}
      {activeTool === 'todo' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
            <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">Add Task</h3>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="What needs to be done?"
                value={newTodoText}
                onChange={(e) => setNewTodoText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    addTodo(newTodoText, newTodoPriority);
                    setNewTodoText('');
                  }
                }}
                className="flex-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-medium"
              />
              <button
                onClick={() => {
                  addTodo(newTodoText, newTodoPriority);
                  setNewTodoText('');
                }}
                className="px-4 rounded-xl bg-[#006C4C] text-white text-xs font-bold"
              >
                Add
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {todos.map((todo) => (
              <div
                key={todo.id}
                onClick={() => toggleTodo(todo.id)}
                className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  todo.completed
                    ? 'bg-neutral-100 dark:bg-neutral-800/40 border-neutral-200 opacity-60'
                    : 'bg-white dark:bg-[#1B221E] border-neutral-200 dark:border-neutral-800 shadow-xs'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                      todo.completed ? 'bg-[#006C4C] border-[#006C4C] text-white' : 'border-neutral-400'
                    }`}
                  >
                    {todo.completed && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <span
                    className={`text-xs font-medium ${
                      todo.completed ? 'line-through text-neutral-400' : 'text-neutral-900 dark:text-neutral-100'
                    }`}
                  >
                    {todo.text}
                  </span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteTodo(todo.id);
                  }}
                  className="p-1 rounded-lg text-neutral-400 hover:text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. SHOPPING LIST */}
      {activeTool === 'shopping' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
            <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">Add Item to List</h3>
            <div className="grid grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="Item name"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="col-span-2 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-medium"
              />
              <input
                type="text"
                placeholder="Qty (e.g. 2 kg)"
                value={shopQty}
                onChange={(e) => setShopQty(e.target.value)}
                className="p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-medium"
              />
            </div>
            <div className="flex justify-between items-center">
              <input
                type="number"
                placeholder="Est. Price ($)"
                value={shopPrice}
                onChange={(e) => setShopPrice(e.target.value)}
                className="p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs w-32"
              />
              <button
                onClick={() => {
                  addShoppingItem(shopName, shopQty, shopPrice ? parseFloat(shopPrice) : undefined);
                  setShopName('');
                  setShopPrice('');
                }}
                className="px-4 py-2 rounded-xl bg-[#006C4C] text-white text-xs font-bold"
              >
                Add Item
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {shoppingList.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleShoppingItem(item.id)}
                className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer ${
                  item.checked
                    ? 'bg-neutral-100 dark:bg-neutral-800/40 opacity-60'
                    : 'bg-white dark:bg-[#1B221E] border-neutral-200 dark:border-neutral-800'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                      item.checked ? 'bg-[#006C4C] border-[#006C4C] text-white' : 'border-neutral-400'
                    }`}
                  >
                    {item.checked && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <div>
                    <span
                      className={`text-xs font-semibold block ${
                        item.checked ? 'line-through text-neutral-400' : 'text-neutral-900 dark:text-neutral-100'
                      }`}
                    >
                      {item.name} ({item.quantity})
                    </span>
                    {item.estimatedPrice && (
                      <span className="text-[10px] text-neutral-500">${item.estimatedPrice.toFixed(2)}</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteShoppingItem(item.id);
                  }}
                  className="p-1 rounded-lg text-neutral-400 hover:text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Total Spending Tally */}
          {shoppingList.length > 0 && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-600/20 flex justify-between items-center text-xs">
              <span className="text-neutral-600 dark:text-neutral-400">Estimated Total:</span>
              <span className="font-bold text-sm text-[#006C4C] dark:text-[#89F8C7]">
                $
                {shoppingList
                  .reduce((sum, item) => sum + (item.estimatedPrice || 0), 0)
                  .toFixed(2)}
              </span>
            </div>
          )}
        </div>
      )}

      {/* 7. EXPENSE SPLITTER */}
      {activeTool === 'expense' && (
        <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
          <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
            Bill & Expense Splitter
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] uppercase font-bold text-neutral-500">Total Bill ($)</label>
              <input
                type="number"
                value={expAmount}
                onChange={(e) => setExpAmount(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-neutral-500">People Count</label>
              <input
                type="number"
                value={expPeople}
                onChange={(e) => setExpPeople(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-neutral-500">Tip (%)</label>
              <input
                type="number"
                value={expTip}
                onChange={(e) => setExpTip(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-neutral-500">Tax (%)</label>
              <input
                type="number"
                value={expTax}
                onChange={(e) => setExpTax(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
              />
            </div>
          </div>

          {(() => {
            const bill = parseFloat(expAmount) || 0;
            const people = Math.max(1, parseInt(expPeople) || 1);
            const tipVal = (bill * (parseFloat(expTip) || 0)) / 100;
            const taxVal = (bill * (parseFloat(expTax) || 0)) / 100;
            const grandTotal = bill + tipVal + taxVal;
            const perPerson = grandTotal / people;
            return (
              <div className="mt-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span>Grand Total (Bill + Tip + Tax):</span>
                  <span className="font-bold text-neutral-900 dark:text-neutral-100">${grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-base font-bold pt-1.5 border-t border-emerald-600/20">
                  <span className="text-[#006C4C] dark:text-[#89F8C7]">Each Person Pays:</span>
                  <span className="text-[#006C4C] dark:text-[#89F8C7]">${perPerson.toFixed(2)}</span>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* 8. TEXT COUNTER */}
      {activeTool === 'text_counter' && (
        <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
          <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
            Text & Character Analyzer
          </h3>
          <textarea
            rows={5}
            value={countedText}
            onChange={(e) => setCountedText(e.target.value)}
            className="w-full p-3 rounded-2xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs"
          ></textarea>

          {(() => {
            const words = countedText.trim() ? countedText.trim().split(/\s+/).length : 0;
            const chars = countedText.length;
            const charsNoSpaces = countedText.replace(/\s/g, '').length;
            const sentences = countedText.split(/[.!?]+/).filter(Boolean).length;
            const readingTimeMin = Math.ceil(words / 200);
            return (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-center">
                  <span className="font-bold text-lg text-[#006C4C] dark:text-[#89F8C7] block">{words}</span>
                  <span className="text-neutral-500 text-[10px] uppercase">Words</span>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-center">
                  <span className="font-bold text-lg text-[#006C4C] dark:text-[#89F8C7] block">{chars}</span>
                  <span className="text-neutral-500 text-[10px] uppercase">Characters</span>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-center">
                  <span className="font-bold text-lg text-[#006C4C] dark:text-[#89F8C7] block">{charsNoSpaces}</span>
                  <span className="text-neutral-500 text-[10px] uppercase">No Spaces</span>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-center">
                  <span className="font-bold text-lg text-[#006C4C] dark:text-[#89F8C7] block">~{readingTimeMin} m</span>
                  <span className="text-neutral-500 text-[10px] uppercase">Reading Time</span>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* 9. STOPWATCH */}
      {activeTool === 'stopwatch' && (
        <div className="bg-white dark:bg-[#1B221E] p-6 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-6 text-center">
          <div className="font-mono text-4xl font-bold tracking-tight text-[#006C4C] dark:text-[#89F8C7]">
            {formatTimer(stopwatchTime)}
          </div>

          <div className="flex justify-center space-x-3">
            <button
              onClick={() => {
                triggerHaptic();
                setStopwatchRunning(!stopwatchRunning);
              }}
              className={`px-6 py-2.5 rounded-2xl text-white font-bold text-sm shadow-md transition-all active:scale-95 ${
                stopwatchRunning ? 'bg-rose-600 hover:bg-rose-700' : 'bg-[#006C4C] hover:bg-[#004D36]'
              }`}
            >
              {stopwatchRunning ? 'Pause' : 'Start'}
            </button>
            <button
              onClick={handleStopwatchLap}
              disabled={!stopwatchRunning}
              className="px-5 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold text-sm active:scale-95 disabled:opacity-40"
            >
              Lap
            </button>
            <button
              onClick={handleStopwatchReset}
              className="px-5 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold text-sm active:scale-95"
            >
              Reset
            </button>
          </div>

          {laps.length > 0 && (
            <div className="max-h-48 overflow-y-auto space-y-1 text-xs pt-4 border-t border-neutral-100 dark:border-neutral-800">
              {laps.map((lapMs, idx) => (
                <div key={idx} className="flex justify-between px-4 py-1.5 rounded-lg bg-neutral-50 dark:bg-neutral-800/40">
                  <span className="text-neutral-500">Lap {laps.length - idx}</span>
                  <span className="font-mono font-bold text-neutral-900 dark:text-neutral-100">
                    {formatTimer(lapMs)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 10. COUNTDOWN TIMER */}
      {activeTool === 'timer' && (
        <div className="bg-white dark:bg-[#1B221E] p-6 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-6 text-center">
          <div className="font-mono text-4xl font-bold tracking-tight text-[#006C4C] dark:text-[#89F8C7]">
            {Math.floor(timerSecondsLeft / 60)}:
            {String(timerSecondsLeft % 60).padStart(2, '0')}
          </div>

          <div className="flex justify-center space-x-2">
            {[60, 180, 300, 600].map((sec) => (
              <button
                key={sec}
                onClick={() => {
                  triggerHaptic();
                  setTimerSecondsLeft(sec);
                  setTimerDuration(sec);
                  setTimerRunning(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-xs font-semibold"
              >
                {sec / 60}m
              </button>
            ))}
          </div>

          <div className="flex justify-center space-x-3">
            <button
              onClick={() => {
                triggerHaptic();
                setTimerRunning(!timerRunning);
              }}
              className="px-6 py-2.5 rounded-2xl bg-[#006C4C] text-white font-bold text-sm shadow-md"
            >
              {timerRunning ? 'Pause' : 'Start'}
            </button>
            <button
              onClick={() => {
                triggerHaptic();
                setTimerRunning(false);
                setTimerSecondsLeft(timerDuration);
              }}
              className="px-5 py-2.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold text-sm"
            >
              Reset
            </button>
          </div>
        </div>
      )}

      {/* 11. SCREEN FLASHLIGHT */}
      {activeTool === 'flashlight' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1B221E] p-6 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-4 text-center">
            <Sun className="w-12 h-12 mx-auto text-amber-500 animate-pulse" />
            <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">Screen Flashlight</h3>
            <p className="text-xs text-neutral-500">
              Turn your entire phone display into a high-brightness white emergency torch.
            </p>
            <button
              onClick={() => setScreenTorch(true)}
              className="px-6 py-3 rounded-2xl bg-[#006C4C] text-white font-bold text-sm shadow-md"
            >
              Turn On Flashlight
            </button>
          </div>

          {/* Full Screen White Torch Overlay */}
          {screenTorch && (
            <div
              onClick={() => setScreenTorch(false)}
              className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-8 text-black cursor-pointer select-none"
            >
              <div className="text-xs font-bold uppercase tracking-widest text-neutral-400">
                Tap anywhere to turn off flashlight
              </div>
              <Sun className="w-20 h-20 text-neutral-300" />
              <div className="text-xs font-semibold text-neutral-400">Pocket Toolkit Torch</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
