import React, { useState } from 'react';
import { X, Check, MapPin, Copy, ExternalLink, Crosshair } from 'lucide-react';
import { Customer } from '../db/indexedDB';
import { ROUTE_DAYS } from '../utils/calc';
import { sound } from '../utils/sound';

interface CustomerEditModalProps {
  customer: Customer | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer) => Promise<void>;
}

export const CustomerEditModal: React.FC<CustomerEditModalProps> = ({
  customer,
  isOpen,
  onClose,
  onSave,
}) => {
  const isNew = !customer?.id;
  const [name, setName] = useState(customer?.name || '');
  const [phone, setPhone] = useState(customer?.phone || '');
  const [address, setAddress] = useState(customer?.address || '');
  const [dayOfWeek, setDayOfWeek] = useState(customer?.dayOfWeek || 'السبت');
  const [balance, setBalance] = useState(customer?.balance || 0);
  const [lat, setLat] = useState(customer?.lat ? String(customer.lat) : '');
  const [lng, setLng] = useState(customer?.lng ? String(customer.lng) : '');
  const [notes, setNotes] = useState(customer?.notes || '');
  const [active, setActive] = useState(customer?.active !== false);
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen) return null;

  const captureGPS = () => {
    if (!navigator.geolocation) {
      setStatusMsg('خاصية GPS غير مدعومة في جهازك');
      sound.playError();
      return;
    }
    setStatusMsg('جاري تحديد الإحداثيات...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude.toFixed(6));
        setLng(pos.coords.longitude.toFixed(6));
        setStatusMsg('تم التقاط إحداثيات موقعك بنجاح');
        sound.playSuccess();
      },
      () => {
        setStatusMsg('تعذر التقاط الموقع - يمكنك كتابة خط العرض والطول يدوياً');
        sound.playError();
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const copyCoords = async () => {
    if (!lat || !lng) return;
    try {
      await navigator.clipboard.writeText(`${lat},${lng}`);
      setStatusMsg('تم نسخ الإحداثيات إلى الحافظة');
      sound.playSuccess();
    } catch {
      setStatusMsg(`${lat},${lng}`);
    }
  };

  const openInMaps = () => {
    if (lat && lng) {
      window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
    } else if (address) {
      window.open(`https://www.google.com/maps?q=${encodeURIComponent(address)}`, '_blank');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setStatusMsg('اسم العميل مطلوب');
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      const parsedLat = lat ? parseFloat(lat) : null;
      const parsedLng = lng ? parseFloat(lng) : null;

      const updated: Customer = {
        id: customer?.id || `CST-${Date.now()}`,
        name: name.trim(),
        phone: phone.trim(),
        address: address.trim(),
        dayOfWeek,
        balance: Number(balance) || 0,
        lat: Number.isFinite(parsedLat) ? parsedLat : null,
        lng: Number.isFinite(parsedLng) ? parsedLng : null,
        locationAccuracy: customer?.locationAccuracy || 10,
        locationSavedAt: parsedLat ? new Date().toISOString() : undefined,
        lastVisit: customer?.lastVisit || null,
        active,
        notes: notes.trim(),
      };

      await onSave(updated);
      sound.playSuccess();
      onClose();
    } catch {
      setStatusMsg('حدث خطأ أثناء حفظ العميل');
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-right flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <h3 className="font-bold text-white text-sm">
            {isNew ? '➕ إضافة عميل جديد لخط السير' : '✏️ تعديل بيانات العميل'}
          </h3>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">اسم العميل / المحل *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: سوبر ماركت الأمانة"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">رقم الهاتف</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="010..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">يوم خط السير</label>
              <select
                value={dayOfWeek}
                onChange={(e) => setDayOfWeek(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                {ROUTE_DAYS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">العنوان بالتفصيل</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="المنطقة - الشارع - علامة مميزة"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الرصيد / المديونية (ج.م)</label>
              <input
                type="number"
                step="0.01"
                value={balance}
                onChange={(e) => setBalance(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">حالة العميل</label>
              <select
                value={active ? '1' : '0'}
                onChange={(e) => setActive(e.target.value === '1')}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="1">عميل نشط</option>
                <option value="0">غير نشط</option>
              </select>
            </div>
          </div>

          {/* GPS Coordinates Group */}
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-750 space-y-2">
            <span className="text-xs font-bold text-amber-400 block">إحداثيات الموقع الجغرافي (GPS)</span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-slate-400 block">خط العرض (Latitude)</span>
                <input
                  type="number"
                  step="any"
                  value={lat}
                  onChange={(e) => setLat(e.target.value)}
                  placeholder="30.0444..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono text-left"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">خط الطول (Longitude)</span>
                <input
                  type="number"
                  step="any"
                  value={lng}
                  onChange={(e) => setLng(e.target.value)}
                  placeholder="31.2357..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono text-left"
                />
              </div>
            </div>

            <div className="flex gap-1.5 pt-1">
              <button
                type="button"
                onClick={captureGPS}
                className="flex-1 py-1.5 px-2 bg-slate-750 hover:bg-slate-700 text-amber-400 rounded-lg text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition"
              >
                <Crosshair className="w-3.5 h-3.5" />
                <span>التقاط موقعي</span>
              </button>
              <button
                type="button"
                onClick={copyCoords}
                className="py-1.5 px-2.5 bg-slate-750 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ</span>
              </button>
              <button
                type="button"
                onClick={openInMaps}
                className="py-1.5 px-2.5 bg-slate-750 hover:bg-slate-700 text-sky-400 rounded-lg text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>الخريطة</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">ملاحظات العميل</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="ملاحظات تفضيلية، مواعيد الفتح والإغلاق..."
              rows={2}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {statusMsg && (
            <p className="text-xs text-amber-400 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
              {statusMsg}
            </p>
          )}

          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg shadow-emerald-950"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'جاري الحفظ…' : isNew ? 'إضافة العميل' : 'حفظ التعديلات'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
