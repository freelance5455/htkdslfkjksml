import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { HistoryEntry } from "@/types/calculator";

interface HistoryPanelProps {
  history: HistoryEntry[];
  onClear: () => void;
}

function timeAgo(ts: number): string {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 5) return "الآن";
  if (diff < 60) return `قبل ${diff} ثانية`;
  if (diff < 3600) return `قبل ${Math.floor(diff / 60)} دقيقة`;
  return `قبل ${Math.floor(diff / 3600)} ساعة`;
}

export function HistoryPanel({ history, onClear }: HistoryPanelProps) {
  return (
    <Card className="flex h-full flex-col rounded-2xl border-teal-100 bg-white shadow-md">
      <CardHeader className="flex flex-row items-center justify-between border-b border-teal-100 bg-teal-50/60 pb-3">
        <CardTitle className="text-base font-bold text-slate-800">
          السجل
        </CardTitle>
        {history.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="text-xs font-semibold text-rose-600 hover:bg-rose-50 hover:text-rose-700"
          >
            حذف
          </Button>
        )}
      </CardHeader>
      <CardContent className="flex-1 p-0">
        {history.length === 0 ? (
          <div className="flex h-full min-h-64 flex-col items-center justify-center gap-2 p-6 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-teal-50 text-2xl">
              🧮
            </div>
            <p className="text-sm font-medium text-slate-500">
              لا توجد عمليات بعد
            </p>
            <p className="text-xs text-slate-400">
              ستظهر نتائج حساباتك هنا
            </p>
          </div>
        ) : (
          <ScrollArea className="h-96 lg:h-full lg:max-h-128">
            <ul className="divide-y divide-slate-100">
              {history.map((entry) => (
                <li
                  key={entry.id}
                  className="px-4 py-3 transition-colors hover:bg-teal-50/40"
                >
                  <div className="truncate text-right font-mono text-xs text-slate-500">
                    {entry.expression}
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-400">
                      {timeAgo(entry.timestamp)}
                    </span>
                    <span className="truncate font-mono text-lg font-bold text-teal-700">
                      = {entry.result}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}