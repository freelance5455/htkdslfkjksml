import { Clock, Trash2, X } from 'lucide-react';
import type { HistoryItem } from '../types/calculator';
import { formatDisplayNumber } from '../utils/mathEngine';

interface HistoryPanelProps {
  history: HistoryItem[];
  forceScientific: boolean;
  onSelectHistory: (item: HistoryItem, loadExpression?: boolean) => void;
  onClearHistory: () => void;
  onClose?: () => void;
  isDrawer?: boolean;
}

export function HistoryPanel({
  history,
  forceScientific,
  onSelectHistory,
  onClearHistory,
  onClose,
  isDrawer = false,
}: HistoryPanelProps) {
  const formatTime = (ts: number) => {
    try {
      return new Intl.DateTimeFormat(undefined, {
        hour: 'numeric',
        minute: '2-digit',
      }).format(new Date(ts));
    } catch {
      return '';
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-zinc-200/80 dark:border-zinc-800/80 shrink-0">
        <div className="flex items-center gap-2.5">
          <Clock className="w-4 h-4 text-zinc-500 dark:text-zinc-400" aria-hidden="true" />
          <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100 whitespace-nowrap">
            History
          </h2>
          {history.length > 0 && (
            <span className="text-xs font-mono tabular-nums text-zinc-500 dark:text-zinc-400">
              · {history.length}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button
              type="button"
              onClick={onClearHistory}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-colors min-h-[36px] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              Clear
            </button>
          )}
          {isDrawer && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close history"
              className="p-2 rounded-xl text-zinc-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* History Items */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
        {history.length === 0 ? (
          <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center px-6 py-10">
            <div className="w-11 h-11 rounded-2xl bg-zinc-100 dark:bg-zinc-800/80 flex items-center justify-center mb-3 text-zinc-400 dark:text-zinc-500">
              <Clock className="w-5 h-5" />
            </div>
            <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
              No calculations yet
            </p>
            <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400 max-w-[220px]">
              Your completed expressions and results appear here for quick reuse.
            </p>
          </div>
        ) : (
          history.map((item) => (
            <div
              key={item.id}
              className="group rounded-xl border border-transparent hover:border-zinc-200 dark:hover:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors p-3"
            >
              <div className="flex items-center justify-between gap-2 text-[11px] text-zinc-400 dark:text-zinc-500 mb-1">
                <span>
                  {item.mode === 'scientific' ? `Scientific · ${item.angleMode}` : 'Regular'}
                </span>
                <span className="tabular-nums">{formatTime(item.timestamp)}</span>
              </div>

              <button
                type="button"
                onClick={() => onSelectHistory(item, true)}
                className="w-full text-right font-mono tabular-nums text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors truncate block"
                title="Load expression"
              >
                {item.expression} =
              </button>

              <button
                type="button"
                onClick={() => onSelectHistory(item, false)}
                className="w-full text-right font-mono tabular-nums text-lg sm:text-xl font-semibold text-zinc-900 dark:text-zinc-100 hover:text-blue-600 dark:hover:text-blue-400 transition-colors truncate block mt-0.5"
                title="Use result"
              >
                {formatDisplayNumber(item.rawResult, forceScientific)}
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
