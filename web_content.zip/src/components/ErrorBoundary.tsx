import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AppLogo } from './AppLogo';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public declare props: Props;

  constructor(props: Props) {
    super(props);
  }

  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in React Component Tree:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleReset = () => {
    try {
      // Clear corrupt state keys safely if needed
      window.localStorage.removeItem('tt_transactions_v1');
    } catch {
      // Ignore
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-800/90 border border-slate-700/80 rounded-3xl p-6 text-center shadow-xl space-y-4">
            <div className="flex justify-center">
              <AppLogo size="xl" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">Onu Finance অ্যাপে সামান্য ত্রুটি হয়েছে</h2>
              <p className="text-xs text-slate-400 mt-1">
                An unexpected interface error occurred. You can reload or refresh your application state safely.
              </p>
            </div>
            {this.state.error?.message && (
              <div className="text-left bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-[11px] font-mono text-rose-300 break-words max-h-32 overflow-y-auto">
                {this.state.error.message}
              </div>
            )}
            <div className="flex gap-2 pt-2">
              <button
                onClick={this.handleReload}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-sm"
              >
                রিলোড করুন (Reload)
              </button>
              <button
                onClick={this.handleReset}
                className="py-2.5 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold transition"
              >
                রিসেট ডেটা (Reset)
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
