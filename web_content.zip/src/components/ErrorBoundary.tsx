import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RotateCw, AlertTriangle, Trash2 } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public override state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in Hebrew Calendar app:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleResetAndReload = () => {
    try {
      if (typeof window !== 'undefined') {
        localStorage.clear();
        sessionStorage.clear();
        if ('caches' in window) {
          caches.keys().then((names) => {
            names.forEach((name) => caches.delete(name));
          });
        }
      }
    } catch (e) {
      console.error('Error clearing storage:', e);
    }
    window.location.href = window.location.origin + window.location.pathname;
  };

  public override render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0F0F0F] text-[#EAEAEA] flex items-center justify-center p-6 font-sans antialiased" dir="rtl">
          <div className="max-w-md w-full bg-[#181818] border border-[#2A2A2A] rounded-2xl p-6 shadow-2xl text-center space-y-5">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="space-y-2">
              <h1 className="text-xl font-bold text-[#EAEAEA] font-serif-hebrew">
                לוחות בה - טעינת האפליקציה
              </h1>
              <p className="text-xs text-[#888888] leading-relaxed">
                אירעה שגיאה בלתי צפויה בעת טעינת נתוני לוח השנה. ניתן לרענן את העמוד או לאפס את זיכרון המטמון.
              </p>
            </div>

            {this.state.error?.message && (
              <div className="p-3 rounded-xl bg-[#121212] border border-[#252525] text-[11px] font-mono text-rose-400 text-left overflow-x-auto max-h-24">
                {this.state.error.message}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="flex-1 py-3 px-4 rounded-xl bg-[#C5A267] hover:bg-[#D4B37F] text-[#0F0F0F] font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <RotateCw className="w-4 h-4" />
                <span>רענן אפליקציה</span>
              </button>

              <button
                type="button"
                onClick={this.handleResetAndReload}
                className="py-3 px-4 rounded-xl bg-[#222222] hover:bg-[#2A2A2A] border border-[#3A3A3A] text-xs font-semibold text-[#888888] hover:text-[#EAEAEA] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>איפוס מטמון</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
