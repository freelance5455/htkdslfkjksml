"use client";

import { Component, type ReactNode } from "react";
import { AlertTriangle, RefreshCcw } from "lucide-react";

interface Props {
  children: ReactNode;
  /** Label shown in the error banner, e.g. the tab name */
  label?: string;
}

interface State {
  hasError: boolean;
  message: string;
}

/**
 * Local React Error Boundary — a runtime exception inside a wrapped tab
 * renders a clean Hebrew error banner instead of blanking the whole app.
 */
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, message: "" };

  static getDerivedStateFromError(err: unknown): State {
    return {
      hasError: true,
      message: err instanceof Error ? err.message : String(err),
    };
  }

  componentDidCatch(error: unknown) {
    // keep the app alive; log for diagnostics
    console.error(`[ErrorBoundary${this.props.label ? `:${this.props.label}` : ""}]`, error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="slide-in rounded-2xl border border-red-500/40 bg-red-500/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-red-400" />
          <h3 className="mt-3 text-sm font-bold text-red-300">
            שגיאה בטעינת {this.props.label ?? "הרכיב"}
          </h3>
          <p className="num mx-auto mt-1 max-w-md break-all text-[11px] text-slate-400" dir="ltr">
            {this.state.message}
          </p>
          <button
            onClick={() => this.setState({ hasError: false, message: "" })}
            className="mx-auto mt-4 flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/60 px-4 py-2 text-xs font-bold text-slate-200 hover:border-emerald-500/50 hover:text-emerald-400"
          >
            <RefreshCcw className="h-3.5 w-3.5" /> נסה שוב
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
