import { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    console.warn('ErrorBoundary caught error:', error);
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.warn('JUHNKRIX MUSIKA non-fatal error caught:', error, errorInfo);
    // If it's a chunk loading or stale hook error, auto-clean caches
    if (error?.message?.includes('useState') || error?.message?.includes('null') || error?.message?.includes('chunk')) {
      try {
        if ('caches' in window) {
          caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
        }
      } catch (e) {
        // ignore
      }
    }
  }

  constructor(props: Props) {
    super(props);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4 animate-pulse">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-amber-400 mb-2">Sanctuary Restoration In Progress</h2>
          <p className="text-slate-400 text-sm max-w-md mb-6">
            The sanctuary altar encountered a temporary module sync state. Click below to restore the altar.
          </p>
          <button
            onClick={() => {
              try {
                if ('caches' in window) {
                  caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
                }
                localStorage.removeItem('juhnkrix_musika_user_profile');
                sessionStorage.clear();
              } catch (e) {}
              window.location.reload();
            }}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-amber-500/20"
          >
            <RefreshCw className="w-4 h-4" />
            Restore Altar
          </button>
        </div>
      );
    }
    return (this as any).props.children;
  }
}
