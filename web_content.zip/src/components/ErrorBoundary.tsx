"use client";

import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw, Loader2 } from "lucide-react";

interface ErrorBoundaryProps {
  children: ReactNode;
  sectionTitleHe?: string;
  onRetry?: () => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: "",
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || "שגיאת רינדור לא צפויה",
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error(
      `[Defensive ErrorBoundary Caught in ${
        this.props.sectionTitleHe || "Module"
      }]:`,
      error,
      errorInfo
    );
  }

  handleReset = () => {
    this.setState({ hasError: false, errorMessage: "" });
    if (this.props.onRetry) {
      this.props.onRetry();
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="w-full rounded-xl border border-[#FF3B69]/40 bg-[#11161F] p-6 text-right shadow-lg"
        >
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-[#FF3B69]/15 text-[#FF3B69]">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-[#F1F5F9]">
                שגיאה בטעינת הנתונים - לחץ לנסות שוב
              </h3>
              <p className="mt-1 text-sm text-[#94A3B8]">
                רכיב ההגנה ({this.props.sectionTitleHe || "מסוף מסחר"}) מנע קריסת מסך
                וריקון תצוגה. הנתונים המקומיים שמורים בבטחה.
              </p>
              {this.state.errorMessage && (
                <p className="mt-2 rounded bg-[#0B0E14] px-3 py-1.5 font-mono text-xs text-[#FF3B69]">
                  {this.state.errorMessage}
                </p>
              )}
              <button
                type="button"
                onClick={this.handleReset}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#2563EB]"
              >
                <RefreshCw className="h-4 w-4" />
                <span>שגיאה בטעינת הנתונים - לחץ לנסות שוב</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export function LoadingSkeletonHe({
  label = "טוען נתונים...",
  rows = 3,
}: {
  label?: string;
  rows?: number;
}) {
  return (
    <div
      dir="rtl"
      className="w-full rounded-xl border border-[#222B3A] bg-[#11161F] p-6 text-right"
    >
      <div className="mb-4 flex items-center gap-3">
        <Loader2 className="h-5 w-5 animate-spin text-[#3B82F6]" />
        <span className="text-sm font-semibold text-[#F1F5F9]">{label}</span>
      </div>
      <div className="space-y-3">
        {Array.from({ length: rows }).map((_, i) => (
          <div
            key={i}
            className="h-12 w-full animate-pulse rounded-lg bg-[#181F2C]"
          />
        ))}
      </div>
    </div>
  );
}
