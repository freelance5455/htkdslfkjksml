"use client";

import React from "react";

type Props = { children: React.ReactNode; title?: string };
type State = { hasError: boolean; message: string };

/** גבול שגיאות - מונע מסך לבן/ריק בכל מסך ובשורש האפליקציה */
export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: unknown): State {
    return { hasError: true, message: error instanceof Error ? error.message : "שגיאה לא ידועה" };
  }

  componentDidCatch(error: unknown) {
    if (typeof console !== "undefined") {
      console.error("[ErrorBoundary]", error);
    }
  }

  reset = () => this.setState({ hasError: false, message: "" });

  render() {
    if (this.state.hasError) {
      return (
        <div className="m-4 rounded-2xl border border-rose-500/40 bg-rose-950/30 p-6 text-center">
          <div className="mb-2 text-3xl">⚠️</div>
          <h3 className="mb-1 text-lg font-bold text-rose-200">
            {this.props.title ?? "שגיאה בטעינת הנתונים - לחץ לנסות שוב"}
          </h3>
          <p className="mb-4 text-xs text-rose-300/70">{this.state.message}</p>
          <button
            onClick={this.reset}
            className="rounded-xl bg-rose-500 px-5 py-2 text-sm font-bold text-white transition hover:bg-rose-400"
          >
            נסה שוב
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
