import React from 'react';
import { motion } from 'motion/react';
import { RotateCcw } from 'lucide-react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      message: error.message || 'حدث خطأ غير متوقع في التطبيق.',
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    console.error('App ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          className="min-h-screen bg-[#F8F9FC] dark:bg-slate-950 flex items-center justify-center p-6"
          dir="rtl"
        >
          <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 text-center shadow-sm">
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white mb-3">
              حدث عطل بسيط
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-base leading-relaxed mb-6">
              لا تقلق، بياناتك الدراسية محفوظة بأمان. اضغط على إعادة المحاولة للمتابعة.
            </p>
            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.location.reload()}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white font-semibold shadow-sm active:shadow-none min-h-[44px] cursor-pointer"
            >
              <RotateCcw className="w-5 h-5" />
              <span>إعادة المحاولة</span>
            </motion.button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
