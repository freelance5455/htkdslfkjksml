import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
}
interface State {
  hasError: boolean;
}

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    // eslint-disable-next-line no-console
    console.error("FormulaVerse encountered an unexpected error:", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto max-w-md px-4 py-20 text-center">
          <div className="text-4xl">⚠️</div>
          <h2 className="mt-3 text-lg font-semibold text-slate-700 dark:text-slate-200">Something went wrong</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            This screen hit an unexpected error. Your saved favorites, formula history and quiz progress are safe.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90"
          >
            Reload FormulaVerse
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
