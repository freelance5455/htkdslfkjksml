import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw, ShieldAlert, Sparkles, Home, CheckCircle2 } from "lucide-react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  recovered: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    recovered: false,
  };

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("[NoteFlow ErrorBoundary] Uncaught React exception:", error, errorInfo);
    this.setState({ errorInfo });

    // Store diagnostic trace to localStorage for TroubleshootingCenter inspection
    try {
      const report = {
        message: error?.message || "Bilinmeyen çalışma zamanı hatası",
        stack: error?.stack || "",
        componentStack: errorInfo?.componentStack || "",
        timestamp: new Date().toISOString(),
        url: window.location.href,
        userAgent: navigator.userAgent,
      };
      localStorage.setItem("noteflow_last_crash_report", JSON.stringify(report));
    } catch {
      // ignore
    }
  }

  private handleSafeModeReload = () => {
    try {
      // Clear volatile corrupted UI caches without touching notes or vault data
      const UI_CACHE_KEYS = [
        "noteflow_display_scale_config_v2",
        "noteflow_paper_notebook_config_v2",
        "noteflow_canvas_theme_style_v1",
        "noteflow_pref_theme_style_v1",
        "noteflow_pref_active_layout_v1",
      ];
      UI_CACHE_KEYS.forEach((k) => localStorage.removeItem(k));
      sessionStorage.clear();
    } catch {
      // ignore
    }

    if (this.props.onReset) {
      this.props.onReset();
    }

    this.setState({ hasError: false, error: null, errorInfo: null, recovered: true });
    window.location.reload();
  };

  private handleAttemptSoftRecovery = () => {
    if (this.props.onReset) {
      this.props.onReset();
    }
    this.setState({ hasError: false, error: null, errorInfo: null, recovered: true });
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 bg-slate-950 text-slate-100 font-sans select-text">
          <div className="w-full max-w-xl p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl backdrop-blur-xl space-y-6 animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 shadow-lg">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-black text-white tracking-tight">
                    NoteFlow Güvenli Kurtarma Modu
                  </h1>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/30">
                    Self-Healing Active
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Arayüz durumunda beklenmedik bir render çakışması yakalandı.{" "}
                  <strong className="text-emerald-400 font-semibold">
                    Notlarınız, şifreli kasanız ve çizim verileriniz tamamen güvendedir.
                  </strong>
                </p>
              </div>
            </div>

            {/* Error Message Box */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between text-slate-400 text-[11px] pb-1 border-b border-slate-800/60 font-sans">
                <span className="font-bold flex items-center gap-1.5 text-rose-400">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Hata Teşhisi
                </span>
                <span>{new Date().toLocaleTimeString("tr-TR")}</span>
              </div>
              <div className="text-rose-300 break-words leading-relaxed text-[11px]">
                {this.state.error?.message || "Bilinmeyen bileşen hatası"}
              </div>
              {this.state.errorInfo?.componentStack && (
                <pre className="text-[9px] text-slate-500 max-h-28 overflow-y-auto p-2 bg-black/40 rounded-lg scrollbar-none">
                  {this.state.errorInfo.componentStack.trim()}
                </pre>
              )}
            </div>

            {/* Recovery Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={this.handleSafeModeReload}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-900/30 transition-all cursor-pointer active:scale-95"
              >
                <Sparkles className="w-4 h-4 text-emerald-200" />
                <span>UI Önbelleğini Onar & Yenile</span>
              </button>

              <button
                type="button"
                onClick={this.handleAttemptSoftRecovery}
                className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95"
              >
                <RefreshCw className="w-4 h-4 text-slate-400" />
                <span>Yeniden Dene (Soft Retry)</span>
              </button>
            </div>

            {/* Safety Assurance Footer */}
            <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                IndexedDB & LocalStorage Notları Korundu
              </span>
              <span>v1.2 Otomatik İyileştirme</span>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
