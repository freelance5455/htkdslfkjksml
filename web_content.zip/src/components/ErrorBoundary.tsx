import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Terminal } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[002 AI Crash Captured by Boundary]:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleResetState = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {
      // Ignored
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen w-full bg-[#080812] text-slate-100 p-6 select-text">
          <div className="max-w-md w-full bg-[#0d0d1c] border border-[#ff2d78]/40 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
            {/* Background cyber glow */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff2d78]/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#ff2d78]/20 border border-[#ff2d78]/50 flex items-center justify-center text-[#ff2d78]">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-cyber font-bold text-white tracking-wide">
                  002 SYSTEM RECOVERY MODE
                </h2>
                <p className="text-xs text-rose-300 font-mono-code">
                  Engine caught unexpected runtime exception
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              The companion encountered a rendering or runtime issue. Your configuration and character data are preserved.
            </p>

            {this.state.error && (
              <div className="bg-[#05050a] border border-rose-500/30 rounded-lg p-3 mb-5 max-h-36 overflow-y-auto font-mono-code text-[11px] text-rose-300">
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-1 border-b border-white/5 pb-1">
                  <Terminal className="w-3 h-3 text-[#ff2d78]" />
                  <span>DIAGNOSTIC ERROR LOG</span>
                </div>
                {this.state.error.message || String(this.state.error)}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={this.handleReload}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff2d78] to-[#9333ea] hover:brightness-110 active:scale-[0.98] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-lg shadow-[#ff2d78]/25 transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reload Companion
              </button>
              <button
                onClick={this.handleResetState}
                className="py-2.5 px-3 rounded-xl bg-[#151528] hover:bg-[#1a1a32] border border-white/10 active:scale-[0.98] text-slate-300 text-xs font-mono-code transition-all"
              >
                Reset Storage
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
