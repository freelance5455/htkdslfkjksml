import React from 'react';
import { Lock, Smartphone, Volume2, X } from 'lucide-react';

interface LockScreenCountdownModalProps {
  isOpen: boolean;
  countdownSec: number | null;
  onCancel: () => void;
  language?: string;
}

export const LockScreenCountdownModal: React.FC<LockScreenCountdownModalProps> = ({
  isOpen,
  countdownSec,
  onCancel,
  language = 'bn',
}) => {
  if (!isOpen || countdownSec === null) return null;

  const isBn = language === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-linear-to-b from-indigo-950 via-slate-900 to-black border border-indigo-500/40 p-6 shadow-2xl text-white text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onCancel}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white bg-slate-800/80 transition-colors"
          aria-label="Cancel"
        >
          <X size={16} />
        </button>

        {/* Big pulsing countdown number */}
        <div className="relative mx-auto my-3 w-24 h-24 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-violet-500/30 animate-ping" />
          <div className="relative w-20 h-20 rounded-full bg-linear-to-tr from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/50">
            <span className="text-3xl font-black text-white font-mono animate-pulse">
              {countdownSec}
            </span>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold uppercase tracking-wider mb-2">
          <Lock size={12} />
          <span>{isBn ? 'লক স্ক্রিন অ্যালার্ম টেস্ট' : 'Lock Screen Alarm Test'}</span>
        </div>

        <h3 className="text-lg font-black text-white tracking-tight mb-2">
          {isBn ? 'এখনই ফোনের স্ক্রিন লক করুন!' : 'Lock Your Phone Screen Now!'}
        </h3>

        <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-xs text-slate-300 space-y-2.5 mb-4 text-left">
          <div className="flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">১</span>
            <p className="leading-relaxed">
              {isBn
                ? 'এখনই আপনার ফোনের মোবাইল ডাটা বা ওয়াইফাই বন্ধ করে অফলাইন করুন।'
                : 'Turn off your mobile data or Wi-Fi right now to go offline.'}
            </p>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">২</span>
            <p className="leading-relaxed">
              {isBn
                ? 'মোবাইলের পাওয়ার বাটন চেপে সাথে সাথে স্ক্রিন লক করে দিন।'
                : 'Press your mobile power button immediately to lock the screen.'}
            </p>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">৩</span>
            <p className="leading-relaxed font-semibold text-white">
              {isBn
                ? `কাউন্টডাউন (${countdownSec}s) শেষ হওয়া মাত্র ডাটা ছাড়াই স্ক্রিন লকে উচ্চস্বরে অ্যালার্ম ও ভাইব্রেশন বাজবে!`
                : `When countdown hits zero, siren alarm & vibration will trigger even with data turned off!`}
            </p>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-[11px] text-emerald-300 mb-3 flex items-center justify-center gap-2">
          <span>📶 {isBn ? '১০০% স্বয়ংসম্পূর্ণ অফলাইন অডিও ইঞ্জিন' : '100% Self-Contained Offline Audio'}</span>
        </div>

        <button
          onClick={onCancel}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
        >
          {isBn ? 'বাতিল করুন' : 'Cancel'}
        </button>
      </div>
    </div>
  );
};
