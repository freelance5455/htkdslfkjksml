/**
 * GODEX v0.0.1 - Human-Facing AI Chat Panel
 * Powered by GodexChatView with AI Studio-style motion & streaming UX.
 */

import React from 'react';
import { ChatMessage, TaskState, ExecutionMode, ActivityLogItem, VerificationReport } from '../types';
import { GodexChatView } from './GodexChatView';

interface AIChatPanelProps {
  messages: ChatMessage[];
  taskState: TaskState;
  executionMode: ExecutionMode;
  activityLogs?: ActivityLogItem[];
  verificationReport?: VerificationReport | null;
  onSendMessage: (prompt: string) => void;
  onClearChat: () => void;
  onToggleExecutionMode: () => void;
  onSelectFile?: (path: string) => void;
}

export const AIChatPanel: React.FC<AIChatPanelProps> = ({
  messages,
  taskState,
  executionMode,
  activityLogs = [],
  verificationReport,
  onSendMessage,
  onClearChat,
  onToggleExecutionMode,
  onSelectFile
}) => {
  return (
    <GodexChatView
      messages={messages}
      taskState={taskState}
      executionMode={executionMode}
      activityLogs={activityLogs}
      verificationReport={verificationReport}
      onSendMessage={onSendMessage}
      onClearChat={onClearChat}
      onToggleExecutionMode={onToggleExecutionMode}
      onSelectFile={onSelectFile}
    />
  );
};
