import React, { useRef, useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Sparkles,
  CheckCircle2,
  Volume2,
  RotateCcw,
  Award,
  PenTool,
  AlertCircle,
  GitBranch,
} from 'lucide-react';
import type { KanaItem, KanjiItem, QuizQuestion, StudyProgressRecord, SupportedLanguage } from '../types';
import {
  CUET_STUDY_SUBJECTS,
  DAKUTEN_DATA,
  HIRAGANA_DATA,
  JAPANESE_GRAMMAR_LESSONS,
  KANJI_DATA,
  KATAKANA_DATA,
} from '../utils/japaneseData';
import { computeMasteryLevel } from '../utils/rajuEngine';
import { AnimatedStrokePlayer } from './AnimatedStrokePlayer';
import { KanjiVisualArtwork } from './KanjiVisualArtwork';

interface StudyModuleProps {
  language: SupportedLanguage;
  progressRecords: StudyProgressRecord[];
  onSaveProgress: (record: {
    subject: string;
    topic: string;
    score: number;
    totalQuestions: number;
    masteryLevel: 'Beginner' | 'Intermediate' | 'Advanced' | 'Mastered';
  }) => Promise<void>;
  onEarnXp: (amount: number) => void;
  onRecordTokens: (tokens: number) => void;
}

export const StudyAssistantModule: React.FC<StudyModuleProps> = ({
  language,
  progressRecords,
  onSaveProgress,
  onEarnXp,
  onRecordTokens,
}) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('Biology');
  const currentSubject =
    CUET_STUDY_SUBJECTS.find((s) => s.id === selectedSubjectId) || CUET_STUDY_SUBJECTS[0];
  const [selectedTopic, setSelectedTopic] = useState<string>(currentSubject.topics[0]);
  const [explanation, setExplanation] = useState<string>(currentSubject.defaultNotes);
  const [revisionPlan, setRevisionPlan] = useState<string[]>([
    'Review foundational definitions and एनसीईआरटी / CUET core concepts',
    'Practice 10 timed domain MCQs with negative-marking awareness (+5 / -1)',
    'Summarize key formulas and exceptions into personal Memory Vault',
  ]);
  const [questions, setQuestions] = useState<QuizQuestion[]>(currentSubject.sampleQuestions);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubjectSwitch = (subjectId: string) => {
    const subj = CUET_STUDY_SUBJECTS.find((s) => s.id === subjectId);
    if (!subj) return;
    setSelectedSubjectId(subjectId);
    setSelectedTopic(subj.topics[0]);
    setExplanation(subj.defaultNotes);
    setQuestions(subj.sampleQuestions);
    setSelectedAnswers({});
    setQuizSubmitted(false);
    setErrorMsg(null);
  };

  const handleGenerateAIStudyPack = async () => {
    setIsGenerating(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/study-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: currentSubject.name,
          topic: selectedTopic,
          difficulty: 'CUET Exam Standard',
          language,
          count: 4,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate AI study pack.');
      }
      if (data.conceptExplanation) setExplanation(data.conceptExplanation);
      if (Array.isArray(data.revisionPlan)) setRevisionPlan(data.revisionPlan);
      if (Array.isArray(data.questions) && data.questions.length > 0) {
        setQuestions(data.questions);
        setSelectedAnswers({});
        setQuizSubmitted(false);
      }
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(25);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error generating study module.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmitQuiz = async () => {
    let score = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) score += 1;
    });
    setQuizSubmitted(true);
    const masteryLevel = computeMasteryLevel(score, questions.length);
    await onSaveProgress({
      subject: currentSubject.id,
      topic: selectedTopic,
      score,
      totalQuestions: questions.length,
      masteryLevel,
    });
    onEarnXp(score * 10 + 10);
  };

  const currentScore = questions.reduce(
    (acc, q, idx) => acc + (selectedAnswers[idx] === q.correctIndex ? 1 : 0),
    0
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Study Assistant (CUET & Domain Mastery)
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Complete exam preparation for Biology, Physics, Chemistry, General Test, English, Mathematics, and Japanese.
          </p>
        </div>

        <button
          type="button"
          onClick={handleGenerateAIStudyPack}
          disabled={isGenerating}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-2 transition whitespace-nowrap shrink-0 disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4" />
          {isGenerating ? 'Generating Fresh Notes & MCQs...' : 'Generate AI Notes & Quiz'}
        </button>
      </div>

      {/* Subject Selector Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-[#0B102B] border border-slate-800 overflow-x-auto">
        {CUET_STUDY_SUBJECTS.map((subj) => (
          <button
            key={subj.id}
            type="button"
            onClick={() => handleSubjectSwitch(subj.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap shrink-0 ${
              selectedSubjectId === subj.id
                ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {subj.name}
          </button>
        ))}
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Topics, Concept Notes & Revision Plan (6 cols) */}
        <div className="lg:col-span-6 space-y-5">
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div>
              <label htmlFor="study-topic-select" className="block text-xs font-medium text-slate-300 mb-1.5">
                Select Syllabus Topic ({currentSubject.examCategory})
              </label>
              <select
                id="study-topic-select"
                value={selectedTopic}
                onChange={(e) => setSelectedTopic(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-400"
              >
                {currentSubject.topics.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                Concept Notes & Formula Breakdown
              </h3>
              <div className="p-4 rounded-xl bg-[#060919]/90 border border-slate-800 text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                {explanation}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800">
              <h4 className="text-xs font-bold text-cyan-300">Structured Revision Plan</h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {revisionPlan.map((step, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Saved Progress Log */}
          {progressRecords.length > 0 && (
            <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Recent Study Mastery Log
              </h3>
              <div className="space-y-2 max-h-44 overflow-y-auto">
                {progressRecords.slice(0, 6).map((rec) => (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-[#060919] border border-slate-800 text-xs"
                  >
                    <div>
                      <span className="font-semibold text-white">{rec.subject}</span>
                      <span className="text-slate-500 mx-1.5">·</span>
                      <span className="text-slate-300">{rec.topic}</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono tabular-nums">
                      <span className="text-cyan-300">
                        {rec.score}/{rec.totalQuestions}
                      </span>
                      <span className="text-slate-500">·</span>
                      <span className="text-emerald-300">{rec.masteryLevel}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Interactive Practice Test / MCQs (6 cols) */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-purple-400" />
              Practice MCQs ({questions.length} Questions)
            </h3>
            {quizSubmitted && (
              <span className="text-xs font-mono tabular-nums text-emerald-300 font-semibold">
                Score: {currentScore} / {questions.length} ({computeMasteryLevel(currentScore, questions.length)})
              </span>
            )}
          </div>

          <div className="space-y-4">
            {questions.map((q, qIdx) => {
              const picked = selectedAnswers[qIdx];
              return (
                <div key={qIdx} className="p-4 rounded-xl bg-[#060919]/85 border border-slate-800 space-y-2.5">
                  <p className="text-xs sm:text-sm font-semibold text-white">
                    {qIdx + 1}. {q.question}
                  </p>
                  <div className="grid grid-cols-1 gap-2">
                    {q.options.map((opt, oIdx) => {
                      const isSelected = picked === oIdx;
                      const isCorrect = q.correctIndex === oIdx;
                      let optionStyle = 'bg-slate-900/90 border-slate-800 text-slate-300 hover:border-slate-700';
                      if (quizSubmitted || picked !== undefined) {
                        if (isCorrect) {
                          optionStyle = 'bg-emerald-950/70 border-emerald-500/60 text-emerald-200 font-medium';
                        } else if (isSelected) {
                          optionStyle = 'bg-rose-950/70 border-rose-500/60 text-rose-200';
                        }
                      }
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          onClick={() => setSelectedAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))}
                          className={`p-2.5 rounded-lg border text-left text-xs transition ${optionStyle}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {(quizSubmitted || picked !== undefined) && (
                    <p className="text-xs text-cyan-200/90 pt-1 leading-relaxed">
                      <strong>Solution:</strong> {q.explanation}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={() => {
                setSelectedAnswers({});
                setQuizSubmitted(false);
              }}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium"
            >
              Reset Answers
            </button>

            <button
              type="button"
              onClick={handleSubmitQuiz}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition"
            >
              Submit & Record Progress
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface JapaneseLearningProps {
  onEarnXp: (amount: number) => void;
  masteredKanji?: string[];
  onToggleMasteredKanji?: (kanji: string) => void;
  onLearnVocab?: (count?: number) => void;
  onOpenVisualDiagrams?: () => void;
}

export const JapaneseLearningModule: React.FC<JapaneseLearningProps> = ({
  onEarnXp,
  masteredKanji = [],
  onToggleMasteredKanji,
  onLearnVocab,
  onOpenVisualDiagrams,
}) => {
  const [activeTab, setActiveTab] = useState<
    'hiragana' | 'katakana' | 'dakuten' | 'kanji' | 'grammar' | 'stroke' | 'quiz'
  >('hiragana');
  const [jlptFilter, setJlptFilter] = useState<'ALL' | 'N5' | 'N4' | 'N3' | 'N2' | 'N1'>('ALL');
  const [dakutenScript, setDakutenScript] = useState<'all' | 'hiragana' | 'katakana'>('all');
  const [selectedKana, setSelectedKana] = useState<KanaItem>(HIRAGANA_DATA[0]);
  const [selectedKanji, setSelectedKanji] = useState<KanjiItem>(KANJI_DATA[0]);
  const [strokePool, setStrokePool] = useState<'hiragana' | 'katakana' | 'kanji'>('hiragana');
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFeedback, setQuizFeedback] = useState<string | null>(null);
  const [writingTestInput, setWritingTestInput] = useState('');
  const [writingTestFeedback, setWritingTestFeedback] = useState<string | null>(null);
  const [ttsLoading, setTtsLoading] = useState(false);

  // Interactive stroke practice canvas ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef(false);

  const speakJapanese = async (text: string, useAiVoice = false) => {
    if (useAiVoice) {
      setTtsLoading(true);
      try {
        const res = await fetch('/api/gemini/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            voiceProfile: 'Japanese Teacher',
            speed: 'slow',
          }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.audioBase64) {
          const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
          await audio.play();
          setTtsLoading(false);
          return;
        }
      } catch {
        // fallback cleanly to browser Web Speech API below
      } finally {
        setTtsLoading(false);
      }
    }

    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'ja-JP';
        utter.rate = 0.88;
        window.speechSynthesis.speak(utter);
      }
    } catch {
      // ignore if browser speech synthesis is blocked
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    isDrawingRef.current = true;
    ctx.strokeStyle = '#00F0FF';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const handlePointerUp = () => {
    if (isDrawingRef.current) {
      isDrawingRef.current = false;
      onEarnXp(5);
    }
  };

  const filteredKanji =
    jlptFilter === 'ALL' ? KANJI_DATA : KANJI_DATA.filter((k) => k.jlpt === jlptFilter);

  const filteredDakuten = DAKUTEN_DATA.filter((item) => {
    if (dakutenScript === 'hiragana') return item.row?.startsWith('Hiragana');
    if (dakutenScript === 'katakana') return item.row?.startsWith('Katakana');
    return true;
  });

  const jpQuizPool = [
    {
      prompt: 'What is the Romaji and Hindi sound of Hiragana 「あ」?',
      options: ['a (अ)', 'i (इ)', 'u (उ)', 'o (ओ)'],
      correct: 0,
      explain: '「あ」 is the first vowel in Hiragana, pronounced "a" (अ in Hindi), as in あさ (Asa - Morning / सुबह).',
    },
    {
      prompt: 'Which Katakana character stands for "ka" (का) as in カメラ (Camera)?',
      options: ['カ', 'キ', 'ク', 'ケ'],
      correct: 0,
      explain: '「カ」 is Katakana "ka" (का), used in loanwords like カメラ (Kamera).',
    },
    {
      prompt: 'Which Kanji means "Mountain" (पहाड़ / पर्वत) with Onyomi サン and Kunyomi やま?',
      options: ['山 (Yama / San)', '木 (Ki / Moku)', '火 (Hi / Ka)', '水 (Mizu / Sui)'],
      correct: 0,
      explain: '山 means Mountain — Kunyomi やま (yama) as in 山道, Onyomi サン (san) as in 富士山.',
    },
    {
      prompt: 'Which Kanji means "Study / Learning" (अध्ययन / सीखना)?',
      options: ['学 (Gaku / Mana.bu)', '日 (Nichi / Hi)', '本 (Hon / Moto)', '心 (Shin / Kokoro)'],
      correct: 0,
      explain: '学 (Gaku) means study or learning, used in 学生 (Gakusei - Student / विद्यार्थी) and 大学 (Daigaku).',
    },
    {
      prompt: 'Which Katakana Handakuten makes the "pa" (पा) sound in パン (Bread)?',
      options: ['パ (pa)', 'バ (ba)', 'ピ (pi)', 'ポ (po)'],
      correct: 0,
      explain: 'Adding the small circle handakuten (゜) to ハ (ha) transforms it into パ (pa).',
    },
    {
      prompt: 'What is the Onyomi and Kunyomi of 「日」 (Sun / Day / सूर्य / दिन)?',
      options: ['Onyomi: ニチ/ジツ · Kunyomi: ひ/-び/-か', 'Onyomi: ガク · Kunyomi: まな.ぶ', 'Onyomi: ゴ · Kunyomi: かた.る', 'Onyomi: シン · Kunyomi: こころ'],
      correct: 0,
      explain: '「日」 has Onyomi ニチ (nichi) / ジツ (jitsu) and Kunyomi ひ (hi) / -び (-bi) / -か (-ka).',
    },
  ];

  const currentQuiz = jpQuizPool[quizIndex % jpQuizPool.length];
  const isCurrentKanjiMastered = masteredKanji.includes(selectedKanji.kanji);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Japanese Visual Learning (日本語・हिंदी・English)
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            All 46 Hiragana, 46 Katakana, Dakuten/Handakuten, animated stroke orders, writing pad, & JLPT N5–N1 verified Kanji ({masteredKanji.length}/{KANJI_DATA.length} Mastered).
          </p>
        </div>

        {onOpenVisualDiagrams && (
          <button
            type="button"
            onClick={onOpenVisualDiagrams}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <GitBranch className="w-4 h-4" />
            Open Visual Diagrams
          </button>
        )}
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl bg-[#0B102B] border border-slate-800">
        {[
          { id: 'hiragana', label: `Hiragana (46 · ひらがな)` },
          { id: 'katakana', label: `Katakana (46 · カタカナ)` },
          { id: 'dakuten', label: `Dakuten & Handakuten (50)` },
          { id: 'kanji', label: `Kanji N5–N1 (${KANJI_DATA.length})` },
          { id: 'grammar', label: 'JLPT N5–N1 Grammar' },
          { id: 'stroke', label: 'Stroke Animation & Pad' },
          { id: 'quiz', label: 'Recognition & Writing Test' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap shrink-0 ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Hiragana (All 46) / Katakana (All 46) / Dakuten & Handakuten (All 50) Views */}
      {(activeTab === 'hiragana' || activeTab === 'katakana' || activeTab === 'dakuten') && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-bold text-white capitalize">
                {activeTab === 'hiragana'
                  ? `All 46 Basic Hiragana Characters (${HIRAGANA_DATA.length})`
                  : activeTab === 'katakana'
                    ? `All 46 Basic Katakana Characters (${KATAKANA_DATA.length})`
                    : `Dakuten (゛) & Handakuten (゜) Matrix (${filteredDakuten.length})`}
              </h3>

              {activeTab === 'dakuten' && (
                <div className="flex items-center gap-1 p-1 rounded-xl bg-[#060919] border border-slate-800 text-xs">
                  {(['all', 'hiragana', 'katakana'] as const).map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setDakutenScript(f)}
                      className={`px-2.5 py-1 rounded-lg capitalize ${
                        dakutenScript === f ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-5 gap-2">
              {(activeTab === 'hiragana'
                ? HIRAGANA_DATA
                : activeTab === 'katakana'
                  ? KATAKANA_DATA
                  : filteredDakuten
              ).map((item) => {
                const isSelected = selectedKana.char === item.char;
                return (
                  <button
                    key={item.char}
                    type="button"
                    onClick={() => {
                      setSelectedKana(item);
                      speakJapanese(item.char);
                      onEarnXp(2);
                    }}
                    className={`p-2.5 rounded-xl border text-center transition ${
                      isSelected
                        ? 'bg-indigo-950/80 border-cyan-400 shadow-[0_0_15px_rgba(0,210,255,0.25)]'
                        : 'bg-[#060919]/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xl sm:text-2xl font-bold text-white">{item.char}</div>
                    <div className="text-[11px] text-cyan-300 font-mono mt-0.5 truncate">
                      {item.romaji} · {item.hindi}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Character Detail, Animated Stroke Player & Audio */}
          <div className="lg:col-span-4 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                {selectedKana.row || 'Flashcard'}
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => speakJapanese(`${selectedKana.char}。 ${selectedKana.exampleWord.split(' ')[0]}`)}
                  className="px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  Speak
                </button>
                <button
                  type="button"
                  disabled={ttsLoading}
                  onClick={() => speakJapanese(`${selectedKana.char}. ${selectedKana.exampleWord.split(' ')[0]}`, true)}
                  className="px-2.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold disabled:opacity-50"
                >
                  {ttsLoading ? '...' : 'Sensei Voice'}
                </button>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#060919] border border-slate-800 text-center space-y-1.5">
              <div className="text-5xl font-bold text-white">{selectedKana.char}</div>
              <p className="text-sm font-semibold text-cyan-300">
                Romaji: <span className="font-mono">{selectedKana.romaji}</span> · हिंदी: <span className="text-amber-300">{selectedKana.hindi}</span>
              </p>
            </div>

            <AnimatedStrokePlayer label={selectedKana.char} strokes={selectedKana.strokes} size={150} />

            <div className="p-3.5 rounded-xl bg-[#060919]/80 border border-slate-800 space-y-1 text-xs">
              <p className="text-slate-400">Vocabulary Example:</p>
              <p className="text-sm font-bold text-white">{selectedKana.exampleWord}</p>
              <p className="text-slate-200">
                <strong>English:</strong> {selectedKana.exampleMeaningEn}
              </p>
              <p className="text-amber-200">
                <strong>हिंदी अर्थ:</strong> {selectedKana.exampleMeaningHi}
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('stroke')}
                className="mt-1.5 text-cyan-300 hover:underline flex items-center gap-1 font-semibold"
              >
                <PenTool className="w-3 h-3" /> Practice Writing "{selectedKana.char}" →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Kanji View (JLPT N5-N1 with Readings, Radicals, Illustration, Memory Trick, Stroke Player, Example Sentence) */}
      {activeTab === 'kanji' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400">Filter by JLPT Level:</span>
              {(['ALL', 'N5', 'N4', 'N3', 'N2', 'N1'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setJlptFilter(lvl)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                    jlptFilter === lvl ? 'bg-cyan-600 text-white' : 'bg-[#0B102B] text-slate-400 hover:text-white'
                  }`}
                >
                  {lvl === 'ALL' ? 'All JLPT' : `JLPT ${lvl}`}
                </button>
              ))}
            </div>
            <span className="text-xs font-mono text-emerald-300">
              Mastered: {masteredKanji.length} / {KANJI_DATA.length}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-5 grid grid-cols-2 gap-3 max-h-[680px] overflow-y-auto pr-1">
              {filteredKanji.map((k) => {
                const isMastered = masteredKanji.includes(k.kanji);
                return (
                  <button
                    key={k.kanji}
                    type="button"
                    onClick={() => {
                      setSelectedKanji(k);
                      speakJapanese(k.kanji);
                    }}
                    className={`p-4 rounded-2xl border text-left transition ${
                      selectedKanji.kanji === k.kanji
                        ? 'bg-indigo-950/80 border-cyan-400'
                        : 'bg-[#0B102B]/90 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-3xl font-bold text-white">{k.kanji}</span>
                      <div className="flex items-center gap-1.5">
                        {isMastered && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                        <span className="text-xs font-mono text-cyan-300">{k.jlpt}</span>
                      </div>
                    </div>
                    <p className="text-xs font-semibold text-slate-200 mt-2">{k.meaningEn}</p>
                    <p className="text-xs text-amber-300 mt-0.5">{k.meaningHi}</p>
                  </button>
                );
              })}
            </div>

            <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <span className="text-xs text-cyan-300 font-mono">
                    JLPT {selectedKanji.jlpt} · {selectedKanji.strokesCount} Strokes
                  </span>
                  <h3 className="text-4xl font-bold text-white mt-1">
                    {selectedKanji.kanji} — {selectedKanji.meaningEn}
                  </h3>
                  <p className="text-sm text-amber-300 font-medium mt-1">
                    हिंदी अर्थ: {selectedKanji.meaningHi}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => speakJapanese(selectedKanji.kanji)}
                    className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Volume2 className="w-4 h-4" />
                    Speak
                  </button>
                  {onToggleMasteredKanji && (
                    <button
                      type="button"
                      onClick={() => onToggleMasteredKanji(selectedKanji.kanji)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition ${
                        isCurrentKanjiMastered
                          ? 'bg-emerald-600 border-emerald-400 text-white'
                          : 'bg-[#060919] border-slate-700 text-slate-200 hover:border-emerald-400'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      {isCurrentKanjiMastered ? 'Mastered' : 'Mark Mastered'}
                    </button>
                  )}
                </div>
              </div>

              {/* Visual Illustration + Animated Stroke Order */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-300">Related Illustration & Concept</p>
                  <KanjiVisualArtwork type={selectedKanji.visualIllustration} kanji={selectedKanji.kanji} />
                  <div className="p-3 rounded-xl bg-[#060919] border border-purple-500/30 text-xs text-slate-200">
                    <strong className="text-purple-300">Memory Trick:</strong> {selectedKanji.memoryTrick}
                  </div>
                </div>
                <AnimatedStrokePlayer label={selectedKanji.kanji} strokes={selectedKanji.strokePaths} size={148} />
              </div>

              {/* Verified Onyomi & Kunyomi */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-[#060919] border border-slate-800">
                  <p className="text-xs text-slate-400">Onyomi (音読み — Compound Reading)</p>
                  <p className="text-sm font-semibold text-cyan-300 mt-1">{selectedKanji.onyomi}</p>
                </div>
                <div className="p-3.5 rounded-xl bg-[#060919] border border-slate-800">
                  <p className="text-xs text-slate-400">Kunyomi (訓読み — Native Reading)</p>
                  <p className="text-sm font-semibold text-purple-300 mt-1">{selectedKanji.kunyomi}</p>
                </div>
              </div>

              {/* Radicals Breakdown */}
              <div className="flex flex-wrap gap-2">
                {selectedKanji.radicals.map((r, i) => (
                  <span key={i} className="px-3 py-1 rounded-lg bg-[#060919] border border-slate-800 text-xs text-slate-200">
                    <strong className="text-cyan-300 text-sm mr-1">{r.part}</strong> {r.name} ({r.meaning})
                  </span>
                ))}
              </div>

              {/* Example Vocabulary */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Verified Example Vocabulary (熟語)
                </h4>
                <div className="space-y-2">
                  {selectedKanji.vocabulary.map((v, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 rounded-xl bg-[#060919]/80 border border-slate-800 text-xs"
                    >
                      <div>
                        <span className="text-sm font-bold text-white">{v.word}</span>
                        <span className="text-cyan-300 ml-2">{v.reading}</span>
                        <p className="text-slate-300 mt-0.5">
                          {v.meaningEn} · <span className="text-amber-200">{v.meaningHi}</span>
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          speakJapanese(v.word);
                          onLearnVocab?.(1);
                          onEarnXp(3);
                        }}
                        aria-label={`Pronounce ${v.word}`}
                        className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Example Sentence */}
              <div className="p-4 rounded-xl bg-[#060919] border border-slate-800 space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-300">Example Sentence</span>
                  <button
                    type="button"
                    onClick={() => speakJapanese(selectedKanji.exampleSentence.jp)}
                    className="text-cyan-300 hover:underline flex items-center gap-1"
                  >
                    <Volume2 className="w-3.5 h-3.5" /> Listen Sentence
                  </button>
                </div>
                <p className="text-sm font-bold text-white">{selectedKanji.exampleSentence.jp}</p>
                <p className="text-slate-400 font-mono">{selectedKanji.exampleSentence.romaji}</p>
                <p className="text-slate-200">{selectedKanji.exampleSentence.en}</p>
                <p className="text-amber-200">{selectedKanji.exampleSentence.hi}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* JLPT Grammar View */}
      {activeTab === 'grammar' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {JAPANESE_GRAMMAR_LESSONS.map((g, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-300">JLPT {g.level}</span>
                <button
                  type="button"
                  onClick={() => speakJapanese(g.exampleJp)}
                  className="text-xs text-cyan-300 hover:underline flex items-center gap-1"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  Listen Sentence
                </button>
              </div>
              <h3 className="text-base font-bold text-white">{g.pattern}</h3>
              <p className="text-xs text-slate-200">
                <strong>English:</strong> {g.meaningEn}
              </p>
              <p className="text-xs text-amber-200">
                <strong>हिंदी व्याख्या:</strong> {g.meaningHi}
              </p>
              <div className="p-3 rounded-xl bg-[#060919] border border-slate-800 text-xs space-y-1">
                <p className="text-sm font-semibold text-white">{g.exampleJp}</p>
                <p className="text-cyan-300 font-mono">{g.exampleRomaji}</p>
                <p className="text-slate-300">{g.exampleEn}</p>
                <p className="text-amber-200/90">{g.exampleHi}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Interactive Stroke-Order Animation & Drawing Practice Pad */}
      {activeTab === 'stroke' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <PenTool className="w-4 h-4 text-cyan-400" />
                Animated Stroke Guide
              </h3>
              <div className="flex gap-1 text-xs">
                {(['hiragana', 'katakana', 'kanji'] as const).map((sp) => (
                  <button
                    key={sp}
                    type="button"
                    onClick={() => setStrokePool(sp)}
                    className={`px-2 py-1 rounded capitalize ${
                      strokePool === sp ? 'bg-cyan-600 text-white' : 'bg-[#060919] text-slate-400'
                    }`}
                  >
                    {sp}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
              {strokePool === 'kanji'
                ? KANJI_DATA.map((item) => (
                    <button
                      key={item.kanji}
                      type="button"
                      onClick={() => {
                        setSelectedKanji(item);
                        setSelectedKana({
                          char: item.kanji,
                          romaji: item.onyomi.split(' ')[0],
                          hindi: item.meaningHi,
                          type: 'hiragana',
                          exampleWord: item.vocabulary[0]?.word || item.kanji,
                          exampleMeaningEn: item.meaningEn,
                          exampleMeaningHi: item.meaningHi,
                          strokes: item.strokePaths,
                        });
                        clearCanvas();
                      }}
                      className={`w-10 h-10 rounded-xl font-bold text-base border transition ${
                        selectedKana.char === item.kanji
                          ? 'bg-cyan-600 border-cyan-400 text-white'
                          : 'bg-[#060919] border-slate-800 text-slate-300'
                      }`}
                    >
                      {item.kanji}
                    </button>
                  ))
                : (strokePool === 'hiragana' ? HIRAGANA_DATA : KATAKANA_DATA).map((item) => (
                    <button
                      key={item.char}
                      type="button"
                      onClick={() => {
                        setSelectedKana(item);
                        clearCanvas();
                      }}
                      className={`w-10 h-10 rounded-xl font-bold text-base border transition ${
                        selectedKana.char === item.char
                          ? 'bg-cyan-600 border-cyan-400 text-white'
                          : 'bg-[#060919] border-slate-800 text-slate-300'
                      }`}
                    >
                      {item.char}
                    </button>
                  ))}
            </div>

            <AnimatedStrokePlayer label={selectedKana.char} strokes={selectedKana.strokes} size={180} />
          </div>

          <div className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">
                  Interactive Writing Pad — {selectedKana.char} ({selectedKana.romaji})
                </h3>
                <p className="text-xs text-slate-400">Trace the ghost strokes to build muscle memory</p>
              </div>
              <button
                type="button"
                onClick={clearCanvas}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Clear Pad
              </button>
            </div>

            <div className="relative flex items-center justify-center p-4 rounded-2xl bg-[#060919] border border-slate-800">
              <span className="absolute text-9xl font-bold text-slate-800/45 select-none pointer-events-none">
                {selectedKana.char}
              </span>
              <canvas
                ref={canvasRef}
                width={340}
                height={280}
                data-testid="japanese-stroke-canvas"
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerUp}
                className="relative z-10 border border-slate-800/80 rounded-xl cursor-crosshair touch-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* Recognition & Writing Test */}
      {activeTab === 'quiz' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-300">
                Recognition Test {(quizIndex % jpQuizPool.length) + 1} of {jpQuizPool.length}
              </span>
              <span className="text-xs font-mono text-emerald-300 tabular-nums">
                Score: {quizScore}
              </span>
            </div>

            <h3 className="text-lg font-bold text-white">{currentQuiz.prompt}</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentQuiz.options.map((opt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if (idx === currentQuiz.correct) {
                      setQuizScore((s) => s + 1);
                      setQuizFeedback(`Correct! ${currentQuiz.explain}`);
                      onEarnXp(15);
                    } else {
                      setQuizFeedback(`Not quite. ${currentQuiz.explain}`);
                    }
                  }}
                  className="p-3.5 rounded-xl bg-[#060919] border border-slate-800 hover:border-cyan-400 text-left text-sm text-white transition"
                >
                  {opt}
                </button>
              ))}
            </div>

            {quizFeedback && (
              <div className="p-4 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-xs text-slate-200 space-y-2">
                <p>{quizFeedback}</p>
                <button
                  type="button"
                  onClick={() => {
                    setQuizFeedback(null);
                    setQuizIndex((i) => i + 1);
                  }}
                  className="px-4 py-2 rounded-lg bg-cyan-600 text-white font-semibold"
                >
                  Next Question →
                </button>
              </div>
            )}
          </div>

          {/* Kana / Katakana Writing Typing Recall Test */}
          <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white">Kana Writing & Recall Challenge</h3>
            <div className="p-5 rounded-xl bg-[#060919] border border-slate-800 text-center space-y-2">
              <p className="text-xs text-slate-400">Listen or read the character and type its Romaji:</p>
              <div className="text-5xl font-bold text-cyan-300">{selectedKana.char}</div>
              <button
                type="button"
                onClick={() => speakJapanese(selectedKana.char)}
                className="text-xs text-cyan-400 hover:underline inline-flex items-center gap-1"
              >
                <Volume2 className="w-3.5 h-3.5" /> Play Sound
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const clean = writingTestInput.trim().toLowerCase();
                if (!clean) return;
                if (selectedKana.romaji.toLowerCase().includes(clean)) {
                  setWritingTestFeedback(`Exact match! ${selectedKana.char} = "${selectedKana.romaji}" (${selectedKana.hindi}).`);
                  onEarnXp(10);
                } else {
                  setWritingTestFeedback(`Not quite. ${selectedKana.char} is "${selectedKana.romaji}" (${selectedKana.hindi}).`);
                }
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={writingTestInput}
                onChange={(e) => setWritingTestInput(e.target.value)}
                placeholder="Type romaji (e.g., ka, shi, mountain)..."
                aria-label="Romaji answer"
                className="flex-1 px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold">
                Check
              </button>
            </form>
            {writingTestFeedback && (
              <p className="text-xs text-cyan-200 bg-indigo-950/50 border border-indigo-500/30 p-3 rounded-xl">
                {writingTestFeedback}
              </p>
            )}
            <button
              type="button"
              onClick={() => {
                const pool = [...HIRAGANA_DATA, ...KATAKANA_DATA];
                const next = pool[Math.floor(Math.random() * pool.length)];
                setSelectedKana(next);
                setWritingTestInput('');
                setWritingTestFeedback(null);
              }}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-semibold"
            >
              Random Hiragana / Katakana Challenge
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
