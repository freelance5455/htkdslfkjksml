import { useEffect, useMemo, useRef, useState } from "react";
import type { ActiveVideo, GenStage, Settings, SubtitleSet, Tab } from "../types";
import { ASR_MODELS, LANGS, MT_MODELS, langName } from "../lib/catalog";
import { runGeneration, STAGE_LABELS } from "../lib/pipeline";
import { downloadText } from "../lib/subtitles";
import { fmtBytes } from "../lib/modelManager";
import { Bar, Btn, Card, Chip, Empty, Icon, useToast } from "./ui";
import { cn } from "../utils/cn";

const ORDER: GenStage["id"][] = ["prep", "asr", "translate", "save"];

const INITIAL: GenStage[] = ORDER.map((id) => ({
  id,
  label: STAGE_LABELS[id],
  state: "pending",
  done: 0,
  total: 0,
}));

interface Props {
  video: ActiveVideo | null;
  videoKey: string;
  settings: Settings;
  onSettings: (p: Partial<Settings>) => void;
  onOpenInPlayer: () => void;
  onGoTo: (t: Tab) => void;
  onChange: () => void;
}

interface LogLine {
  msg: string;
  tone: "info" | "warn";
}

export default function GenerateTab({
  video,
  videoKey,
  settings,
  onSettings,
  onOpenInPlayer,
  onGoTo,
  onChange,
}: Props) {
  const toast = useToast();
  const [stages, setStages] = useState<GenStage[]>(INITIAL);
  const [log, setLog] = useState<LogLine[]>([]);
  const [running, setRunning] = useState(false);
  const [summary, setSummary] = useState<{
    set: SubtitleSet;
    words: number;
    cues: number;
    failed: number;
  } | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const logRef = useRef<HTMLDivElement>(null);

  const asrInstalled = !!settings.installed[settings.asrModel];
  const mtInstalled = !!settings.installed[settings.mtModel];
  const needMt = settings.sourceLang !== "ur";

  const estimate = useMemo(() => {
    if (!video?.duration) return null;
    const chunks = Math.ceil(video.duration / 30);
    const cues = Math.max(1, Math.round(video.duration / 8));
    const asrPer =
      settings.asrModel === "whisper-tiny" ? [2, 8] : settings.asrModel === "whisper-base" ? [5, 15] : [15, 45];
    const mtPer = settings.mtModel === "nllb600m" ? [2, 6] : [1, 4];
    const lo = Math.round((chunks * asrPer[0] + cues * mtPer[0]) / 60);
    const hi = Math.round((chunks * asrPer[1] + cues * mtPer[1]) / 60);
    return { chunks, cues, lo, hi };
  }, [video, settings.asrModel, settings.mtModel]);

  const pushLog = (msg: string, tone: LogLine["tone"] = "info") =>
    setLog((l) => [...l.slice(-40), { msg, tone }]);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [log]);

  const applyStage = (s: GenStage) => {
    setStages((prev) => {
      const next = prev.map((p) => ({ ...p }));
      const idx = ORDER.indexOf(s.id);
      if (s.state === "active")
        for (let k = 0; k < idx; k++)
          if (next[k].state === "pending" || next[k].state === "active")
            next[k].state = "done";
      const cur = next[idx];
      cur.label = s.label;
      cur.state = s.state;
      if (s.done > cur.done) cur.done = s.done;
      if (s.total > cur.total) cur.total = s.total;
      if (s.detail) cur.detail = s.detail;
      return next;
    });
  };

  const start = async () => {
    if (!video) return;
    if (!asrInstalled) {
      toast("Install the speech recognition model first (Models tab)", "warn");
      onGoTo("models");
      return;
    }
    if (needMt && !mtInstalled) {
      toast("Install the Urdu translation model first (Models tab)", "warn");
      onGoTo("models");
      return;
    }
    if (video.duration && video.duration > 45 * 60)
      toast(
        "Long video: processing uses ~32 KB of memory per second of audio and runs in 30 s windows. Over 45 min may be slow or fail on phones.",
        "warn"
      );
    setStages(INITIAL.map((s) => ({ ...s })));
    setLog([]);
    setSummary(null);
    setRunning(true);
    const ac = new AbortController();
    abortRef.current = ac;
    try {
      const set = await runGeneration(
        {
          file: video.blob,
          fileName: video.name,
          asrId: settings.asrModel,
          sourceLang: settings.sourceLang,
          mtId: settings.mtModel,
          videoKey,
        },
        (ev) => {
          if (ev.t === "stage") applyStage(ev.stage);
          else if (ev.t === "info") pushLog(ev.msg);
          else if (ev.t === "warn") pushLog(ev.msg, "warn");
          else if (ev.t === "done") {
            setSummary({ set: ev.set, words: ev.words, cues: ev.cues, failed: ev.failed });
            setStages((prev) =>
              prev.map((p) => ({ ...p, state: "done", done: p.total || p.done, total: p.total || p.done }))
            );
            pushLog(
              `Done — ${ev.cues} cues saved${ev.failed ? ` (${ev.failed} cues kept original)` : ""}`
            );
            toast(
              `Generated ${ev.cues} Urdu cues — saved to library`,
              ev.failed ? "warn" : "ok"
            );
            onChange();
          }
        },
        ac.signal
      );
      if (set) onChange();
    } catch (e: any) {
      if (ac.signal.aborted) {
        pushLog("Stopped by user", "warn");
        toast("Generation stopped", "warn");
      } else {
        setStages((prev) =>
          prev.map((p) =>
            p.state === "active" || p.state === "pending"
              ? { ...p, state: "error" }
              : p
          )
        );
        pushLog("Error: " + String(e?.message || e), "warn");
        toast(String(e?.message || e), "err");
      }
    } finally {
      setRunning(false);
      abortRef.current = null;
    }
  };

  const stop = () => {
    abortRef.current?.abort();
    toast("Stopping after the current step…", "warn");
  };

  if (!video) {
    return (
      <Empty
        icon="sparkles"
        title="No video selected"
        sub="Pick a local video in the Player tab first, then come back to generate Urdu subtitles from its speech."
      >
        <Btn onClick={() => onGoTo("player")}>
          <Icon name="film" className="h-4 w-4" /> Go to Player
        </Btn>
      </Empty>
    );
  }

  return (
    <div className="space-y-4">
      {/* config */}
      <Card className="space-y-4 p-4">
        <div>
          <p className="mb-1.5 text-[11px] font-bold tracking-wide text-mist-500 uppercase">
            Speech model (Whisper)
          </p>
          <div className="space-y-1.5">
            {ASR_MODELS.map((m) => {
              const sel = settings.asrModel === m.id;
              const inst = !!settings.installed[m.id];
              return (
                <button
                  key={m.id}
                  disabled={running}
                  onClick={() => onSettings({ asrModel: m.id })}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors",
                    sel ? "border-brass-500/70 bg-brass-500/10" : "border-ink-600 bg-ink-850",
                    running && "opacity-50"
                  )}
                >
                  <span
                    className={cn(
                      "h-3 w-3 shrink-0 rounded-full border-2",
                      sel ? "border-brass-400 bg-brass-400" : "border-mist-500"
                    )}
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-sm font-semibold text-mist-100">
                      {m.name}
                    </span>
                    <span className="block truncate text-[11px] text-mist-500">
                      {m.sub} · ~{fmtBytes(m.approxMB * 1048576)}
                    </span>
                  </span>
                  {inst ? (
                    <Chip tone="moss">ready</Chip>
                  ) : (
                    <Chip tone="rust">not installed</Chip>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <p className="mb-1.5 text-[11px] font-bold tracking-wide text-mist-500 uppercase">
            Spoken language in the video
          </p>
          <div className="flex flex-wrap gap-1.5">
            <button
              disabled={running}
              onClick={() => onSettings({ sourceLang: "auto" })}
              className={cn(
                "rounded-full border px-2.5 py-1 text-xs font-semibold",
                settings.sourceLang === "auto"
                  ? "border-brass-500 bg-brass-500/15 text-brass-300"
                  : "border-ink-600 text-mist-400"
              )}
            >
              Auto-detect
            </button>
            {LANGS.map((l) => (
              <button
                key={l.code}
                disabled={running}
                onClick={() => onSettings({ sourceLang: l.code })}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-xs font-semibold",
                  settings.sourceLang === l.code
                    ? "border-brass-500 bg-brass-500/15 text-brass-300"
                    : "border-ink-600 text-mist-400"
                )}
              >
                {l.name}
              </button>
            ))}
          </div>
          {settings.sourceLang === "ur" && (
            <p className="mt-1.5 text-[11px] text-jade-300">
              Urdu source: no translation needed — Whisper output is already Urdu script.
            </p>
          )}
        </div>

        {needMt && (
          <div>
            <p className="mb-1.5 text-[11px] font-bold tracking-wide text-mist-500 uppercase">
              Urdu translation model
            </p>
            <div className="space-y-1.5">
              {MT_MODELS.map((m) => {
                const sel = settings.mtModel === m.id;
                const inst = !!settings.installed[m.id];
                const mem = (navigator as any).deviceMemory as number | undefined;
                const tooBig = mem ? mem < m.minMemGB : false;
                return (
                  <button
                    key={m.id}
                    disabled={running}
                    onClick={() => onSettings({ mtModel: m.id })}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors",
                      sel ? "border-brass-500/70 bg-brass-500/10" : "border-ink-600 bg-ink-850",
                      running && "opacity-50"
                    )}
                  >
                    <span
                      className={cn(
                        "h-3 w-3 shrink-0 rounded-full border-2",
                        sel ? "border-brass-400 bg-brass-400" : "border-mist-500"
                      )}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block font-display text-sm font-semibold text-mist-100">
                        {m.name}
                      </span>
                      <span className="block truncate text-[11px] text-mist-500">
                        {m.sub} · ~{fmtBytes(m.approxMB * 1048576)} · {m.license}
                      </span>
                      {tooBig && (
                        <span className="mt-0.5 block text-[11px] font-semibold text-rust-400">
                          ⚠ may not fit in {mem} GB RAM
                        </span>
                      )}
                    </span>
                    {inst ? (
                      <Chip tone="moss">ready</Chip>
                    ) : (
                      <Chip tone="rust">not installed</Chip>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </Card>

      {/* estimate + start */}
      <Card className="p-4">
        {estimate && (
          <p className="mb-3 text-xs leading-relaxed text-mist-400">
            ≈ {estimate.chunks} speech windows · ~{estimate.cues} cues · rough estimate{" "}
            <span className="font-semibold text-mist-200">
              {estimate.lo}–{estimate.hi} min
            </span>{" "}
            on a mid-range phone. Everything runs on-device{""}
            {needMt && " after the translation model is loaded"}.
          </p>
        )}
        {!running ? (
          <Btn size="lg" className="w-full" onClick={() => void start()}>
            <Icon name="sparkles" className="h-5 w-5" />
            Generate Urdu subtitles
          </Btn>
        ) : (
          <Btn size="lg" variant="danger" className="w-full" onClick={stop}>
            <Icon name="pause" className="h-5 w-5" /> Stop
          </Btn>
        )}
        <p className="mt-2 text-center text-[10px] text-mist-600">
          {navigator.onLine ? "Online" : "Offline — using cached models only"} · audio → Whisper →
          segments → M2M/NLLB → SRT/VTT
        </p>
      </Card>

      {/* stages */}
      {(running || stages.some((s) => s.state !== "pending")) && (
        <Card className="space-y-3 p-4">
          {stages.map((s) => (
            <div key={s.id}>
              <div className="mb-1 flex items-center justify-between text-xs">
                <span
                  className={cn(
                    "flex items-center gap-1.5 font-semibold",
                    s.state === "done" && "text-moss-400",
                    s.state === "active" && "text-brass-400",
                    s.state === "error" && "text-rust-400",
                    s.state === "pending" && "text-mist-500"
                  )}
                >
                  <Icon
                    name={
                      s.state === "done" ? "check" : s.state === "error" ? "alert" : s.state === "active" ? "refresh" : "clock"
                    }
                    className={cn("h-4 w-4", s.state === "active" && "pulsedot")}
                  />
                  {s.label}
                </span>
                <span className="tabular-nums text-mist-500">
                  {s.total > 0 ? `${s.done}/${s.total}` : ""}
                </span>
              </div>
              <Bar
                value={s.total > 0 ? s.done / s.total : s.state === "done" ? 1 : 0}
                active={s.state === "active"}
                tone={s.state === "error" ? "rust" : s.state === "done" ? "jade" : "brass"}
              />
              {s.detail && s.state === "active" && (
                <p className="mt-1 truncate text-[11px] text-mist-500">{s.detail}</p>
              )}
            </div>
          ))}
        </Card>
      )}

      {/* log */}
      {log.length > 0 && (
        <div
          ref={logRef}
          className="max-h-40 space-y-1 overflow-y-auto rounded-xl border border-ink-700 bg-ink-950/70 p-3 font-mono text-[11px]"
        >
          {log.map((l, i) => (
            <p key={i} className={l.tone === "warn" ? "text-brass-300" : "text-mist-400"}>
              {l.msg}
            </p>
          ))}
        </div>
      )}

      {/* summary */}
      {summary && (
        <Card className="space-y-3 border-jade-500/40 p-4">
          <div className="flex items-center gap-2">
            <Icon name="check" className="h-5 w-5 text-moss-400" />
            <p className="font-display text-sm font-semibold text-mist-100">
              Saved: {summary.set.title}
            </p>
          </div>
          <p className="text-xs text-mist-400">
            {summary.words} words recognized · {summary.cues} cues
            {summary.failed > 0 && (
              <span className="text-brass-300"> · {summary.failed} kept original (translation failed)</span>
            )}
          </p>
          <p className="urdu text-lg text-mist-100" dir="rtl">
            {summary.set.cues.slice(0, 2).map((c) => c.text).join(" … ")}
          </p>
          <div className="flex flex-wrap gap-2">
            <Btn size="sm" variant="outline" onClick={onOpenInPlayer}>
              <Icon name="play" className="h-4 w-4" /> Open in player
            </Btn>
            <Btn
              size="sm"
              variant="outline"
              onClick={() =>
                downloadText(
                  `${video.name.replace(/\.[^.]+$/, "")}-urdu.srt`,
                  summary.set.srt
                )
              }
            >
              <Icon name="download" className="h-4 w-4" /> Export SRT
            </Btn>
            <Btn
              size="sm"
              variant="outline"
              onClick={() =>
                downloadText(
                  `${video.name.replace(/\.[^.]+$/, "")}-urdu.vtt`,
                  summary.set.vtt
                )
              }
            >
              <Icon name="download" className="h-4 w-4" /> Export VTT
            </Btn>
          </div>
          <p className="text-[11px] text-mist-500">
            {langName(summary.set.sourceLang)} · this set is stored in the library and will
            auto-load when you open {video.name} again — even offline.
          </p>
        </Card>
      )}
    </div>
  );
}
