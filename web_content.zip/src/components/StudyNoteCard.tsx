import React from 'react';
import { StudyModule, ModuleProgress } from '../types/index.ts';
import { BookOpen, HelpCircle, Clock, Sparkles, Bookmark, CheckCircle2 } from 'lucide-react';
import { CircularProgressRing } from './CircularProgressRing.tsx';

interface StudyNoteCardProps {
  module: StudyModule;
  progress?: ModuleProgress;
  language: 'om' | 'en';
  onReadNotes: (module: StudyModule) => void;
  onTakeQuiz: (module: StudyModule) => void;
  isBookmarked: boolean;
  onToggleBookmark: (moduleId: string) => void;
}

export const StudyNoteCard: React.FC<StudyNoteCardProps> = ({
  module,
  progress,
  language,
  onReadNotes,
  onTakeQuiz,
  isBookmarked,
  onToggleBookmark,
}) => {
  const totalQuestions = module.questions?.length || 5;
  const bestScore = progress?.bestScore || 0;
  const isCompleted = progress?.completed || (bestScore === totalQuestions && totalQuestions > 0);
  const isStarted = bestScore > 0;

  // Completion Status helper
  let statusText = '';
  let statusColor = 'text-slate-400';

  if (isCompleted) {
    statusText = language === 'om' ? 'Qophii Guutuu (5/5)' : 'Mastered (5/5)';
    statusColor = 'text-emerald-700 font-semibold';
  } else if (isStarted) {
    statusText = language === 'om' ? `Adeemsarra (${bestScore}/${totalQuestions})` : `In Progress (${bestScore}/${totalQuestions})`;
    statusColor = 'text-amber-700 font-semibold';
  } else {
    statusText = language === 'om' ? 'Hin jalqabamne' : 'Not Started';
    statusColor = 'text-slate-500';
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 hover:border-slate-300 transition-all flex flex-col justify-between group shadow-xs">
      <div className="space-y-3">
        {/* Top row: Category, Grade, Bookmarking & Circular Progress Ring */}
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            {/* Unboxed metadata with typographic separators */}
            <div className="flex items-center gap-1.5 flex-wrap text-xs text-slate-500">
              <span className="font-semibold text-amber-700">{module.subject}</span>
              <span aria-hidden="true">·</span>
              <span>{module.grade}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                <span>{module.estimatedMinutes}m</span>
              </span>
              {module.isAiGenerated && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 text-purple-600 font-medium">
                    <Sparkles className="w-3 h-3" />
                    <span>AI</span>
                  </span>
                </>
              )}
            </div>

            {/* Title */}
            <h2 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-amber-600 transition-colors leading-snug">
              {language === 'om' ? module.title : module.titleEn}
            </h2>
            {language === 'om' && module.titleEn && (
              <p className="text-[11px] text-slate-500 leading-tight">{module.titleEn}</p>
            )}
          </div>

          {/* Right side: Circular Progress Ring & Bookmark */}
          <div className="flex flex-col items-center gap-2 shrink-0">
            <button
              onClick={() => onToggleBookmark(module.id)}
              aria-label="Bookmark module"
              className="min-h-[36px] min-w-[36px] flex items-center justify-center p-1 text-slate-400 hover:text-amber-500 transition-colors cursor-pointer"
            >
              <Bookmark
                className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500 text-amber-500' : ''}`}
              />
            </button>

            {/* Visual Study Progress Ring */}
            <div title={`Progress: ${bestScore}/${totalQuestions} correct`}>
              <CircularProgressRing
                score={bestScore}
                total={totalQuestions}
                size={44}
                strokeWidth={3.5}
              />
            </div>
          </div>
        </div>

        {/* Topic summary */}
        <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed">
          {language === 'om' ? module.topicSummary : (module.topicSummaryEn || module.topicSummary)}
        </p>

        {/* Completion Status Row */}
        <div className="pt-2 text-xs border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {isCompleted ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <span className={`w-2 h-2 rounded-full ${isStarted ? 'bg-amber-500' : 'bg-slate-300'}`} />
            )}
            <span className={statusColor}>{statusText}</span>
          </div>

          <span className="text-[11px] font-medium text-slate-500">
            5 Review MCQs
          </span>
        </div>
      </div>

      {/* Action buttons (min 44px touch hitboxes for mobile phones) */}
      <div className="grid grid-cols-2 gap-2 pt-4 mt-1">
        <button
          onClick={() => onReadNotes(module)}
          className="min-h-[44px] flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all cursor-pointer active:scale-[0.98] shadow-xs"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>{language === 'om' ? 'Qabxii Dubbisi' : 'Read Notes'}</span>
        </button>

        <button
          onClick={() => onTakeQuiz(module)}
          className="min-h-[44px] flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-all cursor-pointer active:scale-[0.98]"
        >
          <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
          <span>
            {isCompleted
              ? language === 'om'
                ? 'Irra Deebi\'i'
                : 'Retake'
              : language === 'om'
              ? 'Qormaata (5)'
              : 'Take 5 MCQs'}
          </span>
        </button>
      </div>
    </div>
  );
};
