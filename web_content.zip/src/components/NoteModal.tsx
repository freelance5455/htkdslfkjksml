import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  X,
  Sparkles,
  Mic,
  Camera,
  Paperclip,
  CheckSquare,
  Clock,
  Lock,
  Star,
  Pin,
  Play,
  Pause,
  Trash2,
  Video,
  Download,
  Share2,
  Loader2,
  Plus,
  Type,
  Palette,
  Highlighter,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Frame,
  Image as ImageIcon,
  Layers,
  Check,
  ChevronDown,
  History,
  Eye,
  Edit3,
  Binary,
  FileText,
  Stamp,
  Scissors,
  Copy,
  Tag,
  Maximize2,
  Minimize2,
  CheckCircle2,
  Save,
  PenTool
} from "lucide-react";
import { Note, Attachment, TaskItem, AudioNote, ImageClip, ElementSnippet, UserProfile, CanvasThemeStyle, StylusToolType, StylusStroke } from "../types";
import { AudioRecorder } from "./AudioRecorder";
import { FileContentViewerModal } from "./FileContentViewerModal";
import { RadialMenu } from "./RadialMenu";
import { StylusCanvasOverlay } from "./StylusCanvasOverlay";
import { FloatingStylusDock } from "./FloatingStylusDock";
import { AdvancedFloatingToolDock } from "./AdvancedFloatingToolDock";
import { FullBleedRuledEditor } from "./FullBleedRuledEditor";
import { DigitalInkRecognitionEngine } from "../utils/digitalInkEngine";
import { downloadFile, compressImageFile } from "../utils/storage";
import {
  CanvasThemeController,
  CANVAS_THEME_DEFINITIONS,
} from "../utils/canvasThemeConfig";
import {
  getStoredElements,
  saveStoredElements,
  createTextSnippetSticker
} from "../utils/elementsLibrary";
import {
  ALL_FRAME_PRESETS,
  FramePreset,
  getRecentFrameIds,
  recordFrameUsage,
  renderFrameToDataUrl
} from "../utils/frames";
import { autoCategorizeSingleNoteWithAI } from "../utils/categorizer";
import { RichTextToolbar } from "./RichTextToolbar";
import {
  extractMindMapFromText,
  extractMindMapFromAudioVideo,
  MindMapNode,
} from "../utils/AudioVideoMindMapExtractor";

interface NoteModalProps {
  note: Note | null;
  categories: string[];
  isVaultOpen: boolean;
  onSave: (note: Note, isVaultDestination: boolean) => void;
  onClose: () => void;
  onAddFlashcardsFromNote?: (cards: Array<{ question: string; answer: string }>) => void;
  onSaveImageClip?: (clip: ImageClip) => void;
  onOpenSideGallery?: () => void;
  isSideGalleryOpen?: boolean;
  pendingImageInsert?: string | null;
  onClearPendingImageInsert?: () => void;
  pendingFrameInsert?: FramePreset | null;
  onClearPendingFrameInsert?: () => void;
  profile?: UserProfile;
  onOpenProfile?: () => void;
}

const COLOR_OPTIONS = [
  { id: "slate", name: "Gri", class: "bg-slate-200 dark:bg-slate-700", border: "border-slate-400" },
  { id: "teal", name: "Teal", class: "bg-teal-500", border: "border-teal-500" },
  { id: "emerald", name: "Yeşil", class: "bg-emerald-500", border: "border-emerald-500" },
  { id: "blue", name: "Mavi", class: "bg-blue-500", border: "border-blue-500" },
  { id: "amber", name: "Sarı", class: "bg-amber-500", border: "border-amber-500" },
  { id: "rose", name: "Kırmızı", class: "bg-rose-500", border: "border-rose-500" },
  { id: "purple", name: "Mor", class: "bg-purple-500", border: "border-purple-500" },
];

const FONT_OPTIONS = [
  { id: "Plus Jakarta Sans", name: "Modern Sans (Varsayılan)", style: "font-sans" },
  { id: "Merriweather", name: "Kitap Serif (Word)", style: "font-serif" },
  { id: "JetBrains Mono", name: "Kod / Monospace", style: "font-mono" },
  { id: "Caveat", name: "El Yazısı (Caveat)", style: "font-handwriting" },
  { id: "Playfair Display", name: "Klasik Başlık (Playfair)", style: "font-display" },
];

const TEXT_COLORS = [
  { label: "Varsayılan", color: "#1e293b" },
  { label: "Kırmızı", color: "#dc2626" },
  { label: "Mavi", color: "#2563eb" },
  { label: "Yeşil", color: "#16a34a" },
  { label: "Turuncu", color: "#ea580c" },
  { label: "Mor", color: "#9333ea" },
  { label: "Pembe", color: "#db2777" },
];

const HIGHLIGHT_COLORS = [
  { label: "Fosforlu Sarı", color: "#fef08a" },
  { label: "Fosforlu Yeşil", color: "#bbf7d0" },
  { label: "Fosforlu Mavi", color: "#bae6fd" },
  { label: "Fosforlu Pembe", color: "#fbcfe8" },
  { label: "Fosforlu Turuncu", color: "#fed7aa" },
  { label: "Temizle", color: "transparent" },
];

export const NoteModal: React.FC<NoteModalProps> = ({
  note,
  categories,
  isVaultOpen,
  onSave,
  onClose,
  onAddFlashcardsFromNote,
  onSaveImageClip,
  onOpenSideGallery,
  isSideGalleryOpen = false,
  pendingImageInsert,
  onClearPendingImageInsert,
  pendingFrameInsert,
  onClearPendingFrameInsert,
  profile,
  onOpenProfile,
}) => {
  // Form State
  const [title, setTitle] = useState(note?.title || "");
  const [content, setContent] = useState(note?.content || "");
  const [category, setCategory] = useState(note?.category || "Kişisel");
  const [tagInput, setTagInput] = useState((note?.tags || []).join(" "));
  const [pinned, setPinned] = useState(note?.pinned || false);
  const [favorite, setFavorite] = useState(note?.favorite || false);
  const [color, setColor] = useState(note?.color || "slate");
  const [reminder, setReminder] = useState(note?.reminder || "");
  const [isVault, setIsVault] = useState(note?.isVault || false);

  // Inline MindMap Overlay State
  const [inlineMindMapNode, setInlineMindMapNode] = useState<MindMapNode | null>(null);
  const [showMindMapOverlay, setShowMindMapOverlay] = useState<boolean>(false);

  const handleGenerateTextMindMap = () => {
    const node = extractMindMapFromText(content || title || "Zihin Haritası");
    setInlineMindMapNode(node);
    setShowMindMapOverlay(true);
  };

  const handleGenerateMediaMindMap = () => {
    const audioName = (audioNotes && audioNotes[0]?.name) || title || "Sesli Kayıt";
    const dur = (audioNotes && audioNotes[0]?.duration) || 120;
    const node = extractMindMapFromAudioVideo(audioName, content, dur);
    setInlineMindMapNode(node);
    setShowMindMapOverlay(true);
  };

  // Distraction-Free & Double-Tap Edit State
  // Default to Read-Only Zen mode for existing notes; if creating fresh note, start in editing mode
  const [isEditing, setIsEditing] = useState<boolean>(!note?.id);
  const [isRadialMenuOpen, setIsRadialMenuOpen] = useState<boolean>(false);
  const [canvasStyle, setCanvasStyle] = useState<CanvasThemeStyle>(
    CanvasThemeController.getStyle()
  );
  const [showCanvasThemeMenu, setShowCanvasThemeMenu] = useState<boolean>(false);
  const [showCategoryMenu, setShowCategoryMenu] = useState<boolean>(false);
  const [customCategoryInput, setCustomCategoryInput] = useState<string>("");

  // Stylus & Digital Pen Canvas Overlay State
  const [isStylusActive, setIsStylusActive] = useState<boolean>(false);
  const [stylusTool, setStylusTool] = useState<StylusToolType>("ballpoint");
  const [stylusColor, setStylusColor] = useState<string>("#0F172A");
  const [stylusSize, setStylusSize] = useState<number>(3);
  const [stylusOpacity, setStylusOpacity] = useState<number>(0.95);
  const [isShapeRecognitionActive, setIsShapeRecognitionActive] = useState<boolean>(false);
  const [stylusStrokes, setStylusStrokes] = useState<StylusStroke[]>([]);

  useEffect(() => {
    const unsubscribe = CanvasThemeController.subscribe((newStyle) => {
      setCanvasStyle(newStyle);
    });
    return unsubscribe;
  }, []);

  // Typography state
  const [selectedFont, setSelectedFont] = useState<string>(note?.fontFamily || "Plus Jakarta Sans");
  const [showColorMenu, setShowColorMenu] = useState(false);
  const [showHighlightMenu, setShowHighlightMenu] = useState(false);
  const [showFontMenu, setShowFontMenu] = useState(false);
  const [showFrameMenu, setShowFrameMenu] = useState(false);

  const activeCanvasDef = CANVAS_THEME_DEFINITIONS[canvasStyle] || CANVAS_THEME_DEFINITIONS.fluid_parchment;
  const activeFontFamily =
    selectedFont && selectedFont !== "Plus Jakarta Sans"
      ? selectedFont
      : activeCanvasDef.fontFamily || selectedFont;
  const [activeSheet, setActiveSheet] = useState<
    "ai" | "color" | "tasks" | "tag_category" | "reminder" | "frame_box" | "audio" | null
  >(null);
  const [selectedFramePreset, setSelectedFramePreset] = useState<FramePreset>(ALL_FRAME_PRESETS[0]);
  const [snapshotSuccess, setSnapshotSuccess] = useState<string | null>(null);

  // Lists & Media
  const [tasks, setTasks] = useState<TaskItem[]>(note?.tasks || []);
  const [newTaskText, setNewTaskText] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>(note?.attachments || []);
  const [audioNotes, setAudioNotes] = useState<AudioNote[]>(note?.audioNotes || []);

  // UI Modals & AI Loading
  const [viewingAttachment, setViewingAttachment] = useState<Attachment | null>(null);
  const [isListeningSpeech, setIsListeningSpeech] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiMessage, setAiMessage] = useState<string | null>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);

  // Double-tap touch tracker for mobile
  const lastTapRef = useRef<number>(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const editorRef = useRef<HTMLDivElement | null>(null);
  const titleInputRef = useRef<HTMLInputElement | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Lasso & Element Library tool states
  const [isLassoActive, setIsLassoActive] = useState<boolean>(false);
  const [lassoPoints, setLassoPoints] = useState<Array<{ x: number; y: number }>>([]);
  const [isLassoDrawing, setIsLassoDrawing] = useState<boolean>(false);
  const [lassoSelectionBox, setLassoSelectionBox] = useState<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  } | null>(null);
  const [lassoMenuPosition, setLassoMenuPosition] = useState<{ x: number; y: number } | null>(null);
  const lassoCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Check if user has AI access activated
  const checkAiAccess = (): boolean => {
    if (profile && (!profile.isLoggedIn || !profile.aiModeEnabled)) {
      const confirmLogin = window.confirm(
        "🤖 NoteFlow Yapay Zeka Özelliklerini Kullanmak İçin Giriş Yapın\n\nGmail veya E-posta adresiniz ile profilinizden giriş yaparak tüm AI özetleme, iyileştirme ve görev çıkarma araçlarını kullanabilirsiniz.\n\nProfile giderek giriş yapmak ister misiniz?"
      );
      if (confirmLogin && onOpenProfile) {
        onOpenProfile();
        onClose();
      }
      return false;
    }
    return true;
  };

  // Offline Sensitive Scanner States
  const [detectedSensitiveType, setDetectedSensitiveType] = useState<string | null>(null);
  const [hasDeclinedVaultSecure, setHasDeclinedVaultSecure] = useState<boolean>(false);

  // Real-time Sensitive Data Scanner Effect
  useEffect(() => {
    if (isVault || hasDeclinedVaultSecure || !content) {
      setDetectedSensitiveType(null);
      return;
    }

    // Clean html tags to scan plain text
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = content;
    const text = tempDiv.innerText || tempDiv.textContent || "";

    const ibanRegex = /\bTR\d{2}\s?(?:\d{4}\s?){5}\d{2}\b/i;
    const ccRegex = /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/;
    const tcRegex = /\b[1-9]\d{10}\b/;
    const seedKeywords = /\b(seed phrase|private key|gizli anahtar|bip39|kurtarma kelimeleri|mnemonic)\b/i;
    const pwKeywords = /\b(şifre|parola|password|pin kodu)\s*[:=]\s*[a-zA-Z0-9@#$!%*?&]{4,}\b/i;

    let detected: string | null = null;
    if (ibanRegex.test(text)) {
      detected = "IBAN Adresi";
    } else if (ccRegex.test(text)) {
      detected = "Kredi Kartı Bilgisi";
    } else if (tcRegex.test(text)) {
      detected = "T.C. Kimlik Numarası";
    } else if (seedKeywords.test(text)) {
      detected = "Kripto Cüzdan Seed Anahtarı (12/24 Kelime)";
    } else if (pwKeywords.test(text)) {
      detected = "Kullanıcı Hesap Şifresi";
    }

    setDetectedSensitiveType(detected);
  }, [content, isVault, hasDeclinedVaultSecure]);

  // Initialize editor content
  useEffect(() => {
    if (editorRef.current && content) {
      if (editorRef.current.innerHTML !== content) {
        editorRef.current.innerHTML = content;
      }
    }
  }, [content, isEditing]);

  // Handle incoming image from side gallery
  useEffect(() => {
    if (pendingImageInsert && editorRef.current) {
      insertImageIntoEditor(pendingImageInsert);
      if (onClearPendingImageInsert) {
        onClearPendingImageInsert();
      }
    }
  }, [pendingImageInsert]);

  // Handle incoming frame preset from side gallery / studio
  useEffect(() => {
    if (pendingFrameInsert && editorRef.current) {
      handleInsertFramePreset(pendingFrameInsert);
      if (onClearPendingFrameInsert) {
        onClearPendingFrameInsert();
      }
    }
  }, [pendingFrameInsert]);

  // Extract YouTube ID if present
  const youtubeMatch = content.match(
    /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/
  );
  const youtubeVideoId = youtubeMatch ? youtubeMatch[1] : null;

  // Double-tap or Double-click gesture handler to enter Edit Mode
  const activateEditMode = () => {
    if (!isEditing) {
      setIsEditing(true);
      setTimeout(() => {
        if (editorRef.current) {
          editorRef.current.focus();
        }
      }, 60);
    }
  };

  const handleCanvasTouchEnd = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      activateEditMode();
    }
    lastTapRef.current = now;
  };

  // Rich Text Commands
  const executeCommand = (command: string, value: string = "") => {
    if (editorRef.current) {
      editorRef.current.focus();
    }
    document.execCommand(command, false, value);
    syncContentFromEditor();
  };

  const syncContentFromEditor = () => {
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  const handleApplyFont = (fontName: string) => {
    setSelectedFont(fontName);
    setShowFontMenu(false);
    executeCommand("fontName", fontName);
  };

  const handleApplyColor = (hex: string) => {
    executeCommand("foreColor", hex);
    setShowColorMenu(false);
  };

  const handleApplyHighlight = (hex: string) => {
    if (hex === "transparent") {
      executeCommand("removeFormat");
    } else {
      executeCommand("hiliteColor", hex);
    }
    setShowHighlightMenu(false);
  };

  // Wrap or insert 30-Preset Boxed Card Frame
  const handleInsertFramePreset = (preset: FramePreset) => {
    setSelectedFramePreset(preset);
    setShowFrameMenu(false);
    recordFrameUsage(preset.id);

    const selection = window.getSelection();
    const selectedText = selection?.toString().trim() || "Kare içerisine alınmış önemli bilgi...";
    const frameHtml = preset.getHtml(selectedText, title || preset.name);
    executeCommand("insertHTML", frameHtml);
  };

  // Insert element sticker cleanly into editor
  const insertElementIntoEditor = (element: ElementSnippet, size: "small" | "medium" | "large" = "medium") => {
    setIsEditing(true);
    if (editorRef.current) {
      editorRef.current.focus();
    }
    const widthPx = size === "small" ? 110 : size === "large" ? 280 : 175;
    const stickerHtml = `<span class="note-element-sticker inline-block my-1 mx-1.5 align-middle select-none" contenteditable="false" data-element-id="${element.id}" title="${element.name}"><img src="${element.data}" alt="${element.name}" style="max-width: ${widthPx}px; height: auto; display: inline-block; vertical-align: middle; border-radius: 8px;" /></span>&nbsp;`;
    document.execCommand("insertHTML", false, stickerHtml);
    syncContentFromEditor();
  };

  // Toggle Lasso Mode
  const toggleLassoMode = () => {
    setIsLassoActive((prev) => !prev);
    setLassoPoints([]);
    setLassoSelectionBox(null);
    setLassoMenuPosition(null);
  };

  // Lasso Drawing Listeners with mobile pointer capture
  const startLassoDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = lassoCanvasRef.current;
    if (!canvas) return;
    try {
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    } catch {}
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setIsLassoDrawing(true);
    setLassoPoints([{ x, y }]);
    setLassoSelectionBox(null);
    setLassoMenuPosition(null);

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const drawLassoPath = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isLassoDrawing) return;
    const canvas = lassoCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setLassoPoints((prev) => [...prev, { x, y }]);

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.strokeStyle = "#0d9488";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([5, 4]);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const finishLassoDrawing = (e?: React.PointerEvent<HTMLCanvasElement>) => {
    if (e) {
      try {
        (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
      } catch {}
    }
    if (!isLassoDrawing) return;
    setIsLassoDrawing(false);

    const canvas = lassoCanvasRef.current;
    if (!canvas || lassoPoints.length < 5) {
      return;
    }

    const minX = Math.min(...lassoPoints.map((p) => p.x));
    const maxX = Math.max(...lassoPoints.map((p) => p.x));
    const minY = Math.min(...lassoPoints.map((p) => p.y));
    const maxY = Math.max(...lassoPoints.map((p) => p.y));

    const width = maxX - minX;
    const height = maxY - minY;

    if (width < 15 || height < 15) {
      return;
    }

    setLassoSelectionBox({ minX, minY, maxX, maxY });
    setLassoMenuPosition({
      x: Math.min(Math.max(90, (minX + maxX) / 2), canvas.width - 90),
      y: Math.max(35, minY - 10),
    });

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "rgba(13, 148, 136, 0.12)";
      ctx.strokeStyle = "#0d9488";
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);

      ctx.beginPath();
      ctx.moveTo(lassoPoints[0].x, lassoPoints[0].y);
      for (let i = 1; i < lassoPoints.length; i++) {
        ctx.lineTo(lassoPoints[i].x, lassoPoints[i].y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  };

  const handleAddLassoToElements = () => {
    let snippetText = "";
    const selection = window.getSelection()?.toString();
    if (selection && selection.trim().length > 0) {
      snippetText = selection.trim();
    } else {
      snippetText = editorRef.current?.innerText.slice(0, 240) || title || "Kement Seçimi";
    }

    const snippet = createTextSnippetSticker(
      title ? `${title.slice(0, 20)} Snippet` : "Kement Kırpıntısı",
      snippetText
    );

    const currentElements = getStoredElements();
    saveStoredElements([snippet, ...currentElements]);

    if (onSaveImageClip) {
      onSaveImageClip(snippet);
    }

    setSnapshotSuccess("✨ Kement kırpıntısı Öğeler Kütüphanesine eklendi!");
    setTimeout(() => setSnapshotSuccess(null), 4000);

    setIsLassoActive(false);
    setLassoPoints([]);
    setLassoSelectionBox(null);
    setLassoMenuPosition(null);

    if (onOpenSideGallery) {
      onOpenSideGallery();
    }
  };

  const handleCopyLassoSelection = () => {
    const selection = window.getSelection()?.toString() || editorRef.current?.innerText.slice(0, 200) || "";
    if (selection) {
      navigator.clipboard.writeText(selection);
      setSnapshotSuccess("📋 Kement alanı panoya kopyalandı!");
      setTimeout(() => setSnapshotSuccess(null), 3000);
    }
    setIsLassoActive(false);
    setLassoPoints([]);
    setLassoSelectionBox(null);
    setLassoMenuPosition(null);
  };

  const handleCancelLasso = () => {
    setIsLassoActive(false);
    setLassoPoints([]);
    setLassoSelectionBox(null);
    setLassoMenuPosition(null);
    const canvas = lassoCanvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // Insert image directly into editor & auto extract text via OCR
  const insertImageIntoEditor = async (imageUrl: string) => {
    setIsEditing(true);
    if (editorRef.current) {
      editorRef.current.focus();
    }
    const imgHtml = `<span class="note-element-sticker inline-block my-1.5 mx-1 align-middle select-none" contenteditable="false"><img src="${imageUrl}" alt="Görsel / Çıkartma" style="max-width: 220px; height: auto; display: inline-block; vertical-align: middle; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);" /></span>&nbsp;`;
    document.execCommand("insertHTML", false, imgHtml);
    syncContentFromEditor();

    if (imageUrl.startsWith("data:image")) {
      setAiMessage("📷 Eklenen görseldeki yazılar okunuyor (OCR)...");
      try {
        const mime = imageUrl.split(";")[0].replace("data:", "") || "image/jpeg";
        const ocrRes = await fetch("/api/gemini/ocr", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageBase64: imageUrl,
            mimeType: mime,
          }),
        });
        const ocrData = await ocrRes.json();
        if (ocrData.text && ocrData.text.trim()) {
          if (editorRef.current) {
            editorRef.current.innerHTML += `<div style="margin:10px 0; padding:12px; background-color:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; font-size:13px; color:#166534; line-height:1.6;"><strong>📷 Görseldeki Metin:</strong><br/>${ocrData.text.replace(/\n/g, "<br/>")}</div><p><br></p>`;
            syncContentFromEditor();
          }
          setAiMessage("✅ Görseldeki yazılar otomatik olarak nota eklendi!");
          setTimeout(() => setAiMessage(null), 5000);
        } else {
          setAiMessage(null);
        }
      } catch (err) {
        console.warn("Gallery OCR error:", err);
        setAiMessage(null);
      }
    }
  };

  // Speech to Text (Web Speech API)
  const toggleSpeechRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSnapshotSuccess("Sesli yazma bu tarayıcıda desteklenmiyor. Chrome veya Edge kullanabilirsiniz.");
      setTimeout(() => setSnapshotSuccess(null), 4000);
      return;
    }

    if (isListeningSpeech) {
      if (speechRecognitionRef.current) {
        try {
          speechRecognitionRef.current.stop();
        } catch (_) {}
      }
      setIsListeningSpeech(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "tr-TR";
      recognition.continuous = true;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListeningSpeech(true);
        setIsEditing(true);
      };

      recognition.onresult = (event: any) => {
        if (!event.results || event.results.length === 0) return;
        const transcript = event.results[event.results.length - 1][0]?.transcript;
        if (transcript && editorRef.current) {
          // If editor is empty or ends with a space/tag, append cleanly
          const space = editorRef.current.innerHTML.endsWith(" ") ? "" : " ";
          editorRef.current.innerHTML += `${space}${transcript}`;
          syncContentFromEditor();
        }
      };

      recognition.onerror = (event: any) => {
        const errorType = event?.error || "unknown";
        setIsListeningSpeech(false);

        if (errorType === "not-allowed" || errorType === "service-not-allowed") {
          setSnapshotSuccess("Mikrofon izni verilmedi. Lütfen adres çubuğundaki kilit simgesinden mikrofon iznini açın.");
        } else if (errorType === "audio-capture") {
          setSnapshotSuccess("Mikrofon cihazı algılanamadı.");
        } else if (errorType === "network") {
          setSnapshotSuccess("Ses tanıma servisine ulaşılamadı. İnternet bağlantınızı kontrol edin.");
        } else if (errorType !== "aborted" && errorType !== "no-speech") {
          console.warn("Speech recognition error:", errorType);
        }
        setTimeout(() => setSnapshotSuccess(null), 4500);
      };

      recognition.onend = () => {
        setIsListeningSpeech(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.warn("Speech recognition start failed:", err?.message || err);
      setIsListeningSpeech(false);
      setSnapshotSuccess("Sesli yazma başlatılamadı.");
      setTimeout(() => setSnapshotSuccess(null), 3000);
    }
  };

  // Attachments file upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsEditing(true);

    for (const file of Array.from(files)) {
      if (file.size > 25 * 1024 * 1024) {
        alert(`${file.name} çok büyük (maksimum 25MB).`);
        continue;
      }

      try {
        const compressed = await compressImageFile(file, 1600, 0.82);
        const fileExt = file.name.split(".").pop()?.toLowerCase() || "";
        const isImg = file.type.startsWith("image/") || ["png", "jpg", "jpeg", "gif", "webp", "bmp", "svg"].includes(fileExt);

        const newAttachment: Attachment = {
          id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: file.name,
          mime: compressed.mime || file.type || "application/octet-stream",
          size: compressed.size,
          data: compressed.dataUrl,
        };
        setAttachments((prev) => [...prev, newAttachment]);

        if (isImg) {
          if (onSaveImageClip) {
            onSaveImageClip({
              id: `clip-upload-${Date.now()}`,
              name: file.name,
              data: compressed.dataUrl,
              createdAt: new Date().toISOString(),
            });
          }

          if (editorRef.current) {
            editorRef.current.innerHTML += `<div class="my-3"><img src="${compressed.dataUrl}" alt="${file.name}" style="max-height:280px; border-radius:12px; border:1px solid #cbd5e1;" /></div>`;
            syncContentFromEditor();
          }

          // OCR
          setAiMessage(`📷 "${file.name}" görselindeki yazılar okunuyor (OCR)...`);
          try {
            const ocrRes = await fetch("/api/gemini/ocr", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                imageBase64: compressed.dataUrl,
                mimeType: compressed.mime || "image/jpeg",
              }),
            });
            const ocrData = await ocrRes.json();
            if (ocrData.text && ocrData.text.trim()) {
              if (editorRef.current) {
                editorRef.current.innerHTML += `<div style="margin:8px 0; padding:12px; background-color:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; font-size:12px; font-family:monospace; color:#166534;"><strong>📷 Görsel Metni (${file.name}):</strong><br/>${ocrData.text.replace(/\n/g, "<br/>")}</div>`;
                syncContentFromEditor();
              }
              setAiMessage(`✅ "${file.name}" metni okundu ve eklendi!`);
            } else {
              setAiMessage(null);
            }
          } catch (err) {
            setAiMessage(null);
          }
        }
      } catch (err) {
        console.warn("File processing error:", err);
      }
    }

    e.target.value = "";
  };

  // Task list refs & interactive helpers
  const taskInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const addNewEmptyTask = (insertAfterIndex?: number) => {
    const newId = `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newTask: TaskItem = {
      id: newId,
      text: "",
      completed: false,
    };

    if (insertAfterIndex !== undefined && insertAfterIndex >= 0) {
      setTasks((prev) => {
        const next = [...prev];
        next.splice(insertAfterIndex + 1, 0, newTask);
        return next;
      });
    } else {
      setTasks((prev) => [...prev, newTask]);
    }

    setTimeout(() => {
      if (taskInputRefs.current[newId]) {
        taskInputRefs.current[newId]?.focus();
      }
    }, 60);
  };

  const updateTaskText = (id: string, text: string) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, text } : t)));
  };

  const toggleTask = (id: string) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const handleTaskKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    index: number,
    task: TaskItem
  ) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addNewEmptyTask(index);
    } else if (e.key === "Backspace" && task.text === "" && tasks.length > 1) {
      e.preventDefault();
      deleteTask(task.id);
      const prevTask = tasks[index - 1] || tasks[index + 1];
      if (prevTask) {
        setTimeout(() => {
          taskInputRefs.current[prevTask.id]?.focus();
        }, 50);
      }
    }
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask: TaskItem = {
      id: `task-${Date.now()}`,
      text: newTaskText.trim(),
      completed: false,
    };
    setTasks((prev) => [...prev, newTask]);
    setNewTaskText("");
  };
  const playAudioNote = (audio: AudioNote) => {
    if (playingAudioId === audio.id) {
      if (activeAudioRef.current) {
        activeAudioRef.current.pause();
      }
      setPlayingAudioId(null);
      return;
    }

    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
    }

    const sound = new Audio(audio.data);
    activeAudioRef.current = sound;
    setPlayingAudioId(audio.id);

    sound.onended = () => {
      setPlayingAudioId(null);
    };

    sound.play().catch((err) => {
      console.error(err);
      setPlayingAudioId(null);
    });
  };

  // AI Actions via server.ts
  const handleAiSemanticCategorize = async () => {
    if (!checkAiAccess()) return;
    const rawContent = editorRef.current?.innerText || content;
    const existingTags = tagInput.split(" ").filter((t) => t.trim().length > 0);

    setAiLoading(true);
    setAiMessage(null);
    try {
      const result = await autoCategorizeSingleNoteWithAI(
        { title, content: rawContent, tasks, tags: existingTags, category },
        categories
      );

      if (result.category) {
        setCategory(result.category);
        if (result.tags && result.tags.length > 0) {
          setTagInput(result.tags.join(" "));
        }
        setAiMessage(`✓ '${result.category}' kategorisine ve akıllı etiketlere atandı! (${result.reason})`);
      }
    } catch (err) {
      console.error(err);
      alert("Anlamsal kategorizasyon hatası oluştu.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiSummarize = async () => {
    if (!checkAiAccess()) return;
    const rawContent = editorRef.current?.innerText || content;
    if (!rawContent.trim()) {
      alert("Özetlemek için lütfen önce not içeriği yazın.");
      return;
    }

    setAiLoading(true);
    setAiMessage(null);
    try {
      const res = await fetch("/api/gemini/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content: rawContent }),
      });
      const data = await res.json();
      if (data.result) {
        if (editorRef.current) {
          editorRef.current.innerHTML += `<hr style="margin: 16px 0;" /><div style="padding: 12px; border-radius: 12px; background: rgba(13,148,136,0.1); border-left: 4px solid #0d9488;"><strong>🤖 Akıllı Özet:</strong><p>${data.result.replace(/\n/g, "<br>")}</p></div>`;
          syncContentFromEditor();
        }
        setAiMessage("Özet notun sonuna eklendi.");
      } else {
        alert(data.error || "Özetleme başarısız oldu.");
      }
    } catch (err: any) {
      console.error(err);
      alert("Yapay zeka sunucusuna bağlanılamadı.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiEnhance = async (mode: string = "polish") => {
    if (!checkAiAccess()) return;
    const rawContent = editorRef.current?.innerText || content;
    if (!rawContent.trim()) {
      alert("Lütfen önce bir içerik girin.");
      return;
    }

    setAiLoading(true);
    setAiMessage(null);
    try {
      const res = await fetch("/api/gemini/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: rawContent, mode }),
      });
      const data = await res.json();
      if (data.result) {
        if (editorRef.current) {
          editorRef.current.innerHTML = data.result.replace(/\n/g, "<br>");
          syncContentFromEditor();
        }
        setAiMessage("Metin yapay zeka ile düzenlendi ve iyileştirildi.");
      } else {
        alert(data.error || "İyileştirme başarısız oldu.");
      }
    } catch (err) {
      console.error(err);
      alert("İşlem sırasında hata oluştu.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiExtractTasks = async () => {
    if (!checkAiAccess()) return;
    const rawContent = editorRef.current?.innerText || content;
    if (!rawContent.trim()) {
      alert("Lütfen önce görevlerin çıkarılacağı içeriği girin.");
      return;
    }

    setAiLoading(true);
    setAiMessage(null);
    try {
      const res = await fetch("/api/gemini/extract-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: rawContent }),
      });
      const data = await res.json();
      if (data.tasks && Array.isArray(data.tasks)) {
        const newExtractedTasks: TaskItem[] = data.tasks.map((t: string) => ({
          id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          text: t,
          completed: false,
        }));
        setTasks((prev) => [...prev, ...newExtractedTasks]);
        setAiMessage(`${newExtractedTasks.length} adet görev listeye eklendi!`);
      } else {
        alert(data.error || "Görev çıkarılamadı.");
      }
    } catch (err) {
      console.error(err);
      alert("Hata oluştu.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiGenerateFlashcards = async () => {
    if (!checkAiAccess()) return;
    const rawContent = editorRef.current?.innerText || content;
    if (!rawContent.trim()) {
      alert("Lütfen önce not içeriği girin.");
      return;
    }

    setAiLoading(true);
    setAiMessage(null);
    try {
      const res = await fetch("/api/gemini/generate-flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content: rawContent }),
      });
      const data = await res.json();
      if (data.flashcards && Array.isArray(data.flashcards)) {
        if (onAddFlashcardsFromNote) {
          onAddFlashcardsFromNote(data.flashcards);
          setAiMessage(`${data.flashcards.length} adet çalışma kartı oluşturuldu ve 'Öğrenme' sekmesine eklendi!`);
        }
      } else {
        alert(data.error || "Kart oluşturulamadı.");
      }
    } catch (err) {
      console.error(err);
      alert("Kart oluşturulamadı.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAiSuggestTags = async () => {
    const rawContent = editorRef.current?.innerText || content;
    if (!rawContent.trim() && !title.trim()) {
      alert("Lütfen başlık veya içerik girin.");
      return;
    }

    setAiLoading(true);
    try {
      const res = await fetch("/api/gemini/suggest-tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content: rawContent }),
      });
      const data = await res.json();
      if (data.tags && Array.isArray(data.tags)) {
        setTagInput((prev) => {
          const existing = prev.split(/\s+/).filter(Boolean);
          const combined = Array.from(new Set([...existing, ...data.tags]));
          return combined.join(" ");
        });
      }
      if (data.category && categories.includes(data.category)) {
        setCategory(data.category);
      }
      setAiMessage("Etiketler ve kategori uygulandı.");
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  // Submit & Save
  const handleSave = () => {
    const finalContent = editorRef.current?.innerHTML || content;
    const trimmedTitle = title.trim();
    const trimmedContent = finalContent.trim();

    if (!trimmedTitle && !trimmedContent) {
      alert("Lütfen en azından bir başlık veya içerik girin.");
      return;
    }

    // Process tags
    const parsedTags = Array.from(
      new Set(
        tagInput
          .split(/\s+/)
          .filter(Boolean)
          .map((t) => (t.startsWith("#") ? t : `#${t}`))
      )
    );

    const savedNote: Note = {
      id: note?.id || `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: trimmedTitle || "Başlıksız Not",
      content: trimmedContent,
      htmlContent: trimmedContent,
      fontFamily: selectedFont,
      category,
      tags: parsedTags,
      pinned,
      favorite,
      color,
      reminder: reminder || undefined,
      attachments,
      tasks,
      audioNotes,
      isVault,
      sourceDocument: note?.sourceDocument,
      createdAt: note?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(savedNote, isVault);
  };

  // Export note as Markdown file
  const handleDownloadMarkdown = () => {
    const rawContent = editorRef.current?.innerText || content;
    const mdContent = `# ${title || "Başlıksız Not"}
*Kategori: ${category} | Tarih: ${new Date().toLocaleString("tr-TR")}*
${reminder ? `*Hatırlatıcı: ${new Date(reminder).toLocaleString("tr-TR")}*\n` : ""}
${tagInput ? `Etiketler: ${tagInput}\n` : ""}
---

${rawContent}

${
  tasks.length > 0
    ? `\n### Görevler\n${tasks.map((t) => `- [${t.completed ? "x" : " "}] ${t.text}`).join("\n")}`
    : ""
}
`;
    downloadFile(`${title.replace(/[^a-zA-Z0-9çÇğĞıİöÖşŞüÜ_-]/g, "_") || "not"}.md`, mdContent, "text/markdown");
  };

  // Radial Action Handler - Maps rotary wheel selection to compact sheets or tools
  const handleRadialAction = (actionId: string) => {
    switch (actionId) {
      case "ai_assistant":
        setActiveSheet((prev) => (prev === "ai" ? null : "ai"));
        break;
      case "speech_to_text":
        toggleSpeechRecognition();
        break;
      case "audio_record":
        setActiveSheet((prev) => (prev === "audio" ? null : "audio"));
        break;
      case "camera_photo":
        cameraInputRef.current?.click();
        break;
      case "color_picker":
        setActiveSheet((prev) => (prev === "color" ? null : "color"));
        break;
      case "tasks_checklist":
        setActiveSheet((prev) => (prev === "tasks" ? null : "tasks"));
        break;
      case "lasso_tool":
        toggleLassoMode();
        break;
      case "elements_stickers":
        if (onOpenSideGallery) {
          onOpenSideGallery();
        }
        break;
      case "tag_category":
        setActiveSheet((prev) => (prev === "tag_category" ? null : "tag_category"));
        break;
      case "reminder_clock":
        setActiveSheet((prev) => (prev === "reminder" ? null : "reminder"));
        break;
      case "vault_lock":
        setIsVault((prev) => !prev);
        setSnapshotSuccess(isVault ? "🔓 Not kasadan çıkarıldı" : "🔒 Not Güvenli Kasaya kilitlendi");
        setTimeout(() => setSnapshotSuccess(null), 3000);
        break;
      case "file_attachment":
        fileInputRef.current?.click();
        break;
      case "frame_box":
        setActiveSheet((prev) => (prev === "frame_box" ? null : "frame_box"));
        break;
      default:
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-3 md:p-6 bg-slate-950/75 backdrop-blur-md overflow-hidden animate-in fade-in duration-200">
      
      {/* Hidden File Inputs */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileUpload}
      />
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="*"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Main Note Modal Container (100% Canvas Zen Design - Mobile Viewport Optimized) */}
      <div className={`relative w-full h-[100dvh] sm:h-[94dvh] sm:max-w-5xl sm:rounded-3xl border shadow-2xl flex flex-col overflow-hidden modal-overscroll-contain transition-all duration-300 ${
        canvasStyle === "fluid_parchment"
          ? "bg-gradient-to-b from-[#FDFBF7] via-[#FAF6F0] to-[#F5EFEB] text-amber-950 border-amber-300/60"
          : canvasStyle === "zen_sapphire"
          ? "bg-gradient-to-b from-[#0A1128] via-[#101A36] to-[#1C2541] text-sky-100 border-sky-900/60 dark"
          : canvasStyle === "timeline_chronicle"
          ? "bg-gradient-to-b from-[#F4EFEA] via-[#F9F7F5] to-[#EFEAE4] text-slate-800 border-amber-200/80"
          : "bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-slate-200/80 dark:border-slate-800"
      }`}>
        
        {/* ========================================================================= */}
        {/* 1. MINIMAL FLOATING GLASS HEADER BAR (Clean & Unobtrusive)                 */}
        {/* ========================================================================= */}
        <div className={`flex items-center justify-between px-4 sm:px-6 py-2.5 backdrop-blur-md border-b z-20 shrink-0 select-none transition-colors ${
          canvasStyle === "fluid_parchment"
            ? "bg-[#FDFBF7]/90 border-amber-200/60 text-amber-950"
            : canvasStyle === "zen_sapphire"
            ? "bg-[#0A1128]/90 border-sky-900/60 text-sky-100"
            : canvasStyle === "timeline_chronicle"
            ? "bg-[#F4EFEA]/90 border-amber-200/60 text-slate-800"
            : "bg-white/80 dark:bg-slate-900/80 border-slate-100 dark:border-slate-800/80"
        }`}>
          
          {/* Left: Category, Vault Badge & Quick Canvas Theme Switcher */}
          <div className="flex items-center gap-2 min-w-0 flex-wrap">
            {/* Interactive Category & Section Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowCategoryMenu(!showCategoryMenu);
                  setShowCanvasThemeMenu(false);
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-teal-50 dark:bg-teal-950/80 text-teal-800 dark:text-teal-200 border border-teal-300 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900 transition-all cursor-pointer shadow-xs truncate max-w-[160px]"
                title="Notun Kategorisini / Bölümünü Değiştir"
              >
                <span className="truncate">📂 {category}</span>
                <ChevronDown className="w-3 h-3 text-teal-600 dark:text-teal-400 shrink-0" />
              </button>

              {showCategoryMenu && (
                <div className="absolute left-0 mt-1.5 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-2.5 z-50 text-xs animate-in zoom-in-95 space-y-2">
                  <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider px-1">
                    Kategori & Bölüm Seçin:
                  </div>

                  <div className="max-h-48 overflow-y-auto space-y-1 pr-1 scrollbar-none">
                    {Array.from(
                      new Set([
                        ...categories.filter((c) => c !== "Tümü"),
                        "Kişisel",
                        "İş",
                        "Fikirler",
                        "Projeler",
                        "Eğitim",
                        "Finans",
                        "Sağlık",
                        "Yazılım",
                      ])
                    ).map((catName) => (
                      <button
                        key={catName}
                        type="button"
                        onClick={() => {
                          setCategory(catName);
                          setShowCategoryMenu(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 rounded-xl font-bold flex items-center justify-between transition-colors cursor-pointer ${
                          category === catName
                            ? "bg-teal-600 text-white shadow-xs"
                            : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200"
                        }`}
                      >
                        <span className="truncate">{catName}</span>
                        {category === catName && <Check className="w-3.5 h-3.5 stroke-[3] shrink-0" />}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 px-1 block">
                      + Yeni Özel Bölüm / Kategori:
                    </span>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={customCategoryInput}
                        onChange={(e) => setCustomCategoryInput(e.target.value)}
                        placeholder="Örn: Bütçe, Hobiler..."
                        className="flex-1 px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            if (customCategoryInput.trim()) {
                              setCategory(customCategoryInput.trim());
                              setCustomCategoryInput("");
                              setShowCategoryMenu(false);
                            }
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (customCategoryInput.trim()) {
                            setCategory(customCategoryInput.trim());
                            setCustomCategoryInput("");
                            setShowCategoryMenu(false);
                          }
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shrink-0 cursor-pointer"
                      >
                        Ekle
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Canvas Theme Switcher Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowCanvasThemeMenu(!showCanvasThemeMenu)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border transition-all cursor-pointer ${
                  canvasStyle === "fluid_parchment"
                    ? "bg-amber-100/80 border-amber-300 text-amber-900 shadow-xs"
                    : canvasStyle === "zen_sapphire"
                    ? "bg-sky-950/90 border-sky-500/50 text-sky-200 shadow-xs"
                    : canvasStyle === "timeline_chronicle"
                    ? "bg-amber-100/90 border-amber-400 text-slate-800 shadow-xs"
                    : "bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-xs"
                }`}
                title="Yazı Tahtası / Kanvas Temasını Değiştir"
              >
                <PenTool className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span className="truncate max-w-[110px]">{activeCanvasDef.title}</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>

              {showCanvasThemeMenu && (
                <div className="absolute left-0 mt-1.5 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-2 z-50 text-xs animate-in zoom-in-95 space-y-1">
                  <div className="px-2 py-1 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    Yazı Tahtası Teması:
                  </div>
                  {(Object.keys(CANVAS_THEME_DEFINITIONS) as CanvasThemeStyle[]).map((stKey) => {
                    const def = CANVAS_THEME_DEFINITIONS[stKey];
                    const isCur = canvasStyle === stKey;
                    return (
                      <button
                        key={stKey}
                        type="button"
                        onClick={() => {
                          CanvasThemeController.setStyle(stKey);
                          setShowCanvasThemeMenu(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all cursor-pointer ${
                          isCur
                            ? "bg-teal-50 dark:bg-teal-950/60 text-teal-900 dark:text-teal-200 font-bold border border-teal-300 dark:border-teal-800"
                            : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                        }`}
                      >
                        <div className="truncate">
                          <div className="font-bold">{def.title}</div>
                          <div className="text-[10px] text-slate-400 truncate">{def.badge}</div>
                        </div>
                        {isCur && <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {isVault && (
              <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100/70 dark:bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-300/60 dark:border-emerald-800">
                <Lock className="w-3 h-3" />
                <span className="hidden sm:inline">Güvenli Kasa</span>
              </span>
            )}

            {note?.sourceDocument && (
              <span
                title={`Bu bağımsız not "${note.sourceDocument}" kaynak dosyasından aktarılmıştır.`}
                className="hidden md:flex items-center gap-1 text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700 truncate max-w-[140px]"
              >
                <Binary className="w-3 h-3 text-teal-600 dark:text-teal-400 shrink-0" />
                <span className="truncate">{note.sourceDocument}</span>
              </span>
            )}
          </div>

          {/* Right: Quick Action Controls */}
          <div className="flex items-center gap-1.5">
            {/* STYLUS & DIGITAL PEN MODE TOGGLE */}
            <button
              type="button"
              onClick={() => setIsStylusActive(!isStylusActive)}
              title="Dijital Kalem / Stylus El Yazısı Modunu Aç/Kapat"
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                isStylusActive
                  ? "bg-amber-600 text-white shadow-md shadow-amber-600/30 ring-2 ring-amber-400/50"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              <PenTool className="w-3.5 h-3.5 text-amber-300" />
              <span>{isStylusActive ? "Kalem Modu Aktif" : "El Yazısı Kalemi"}</span>
            </button>

            {/* Status / Mode Switcher */}
            <button
              type="button"
              onClick={() => {
                if (!isEditing) {
                  activateEditMode();
                } else {
                  setIsEditing(false);
                }
              }}
              title={isEditing ? "Okuma Moduna Dön (Salt Okunur)" : "Yazı Düzenleme Moduna Geç"}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                isEditing
                  ? "bg-teal-600 text-white shadow-xs shadow-teal-600/30 hover:bg-teal-500"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950/50 hover:text-teal-600"
              }`}
            >
              {isEditing ? <Eye className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
              <span>{isEditing ? <>Tamamla<span className="hidden sm:inline"> (Okuma Modu)</span></> : "Düzenle"}</span>
            </button>

            {onOpenSideGallery && (
              <button
                type="button"
                onClick={onOpenSideGallery}
                title="Goodnotes & Notability Çıkartmalarını Aç"
                className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isSideGalleryOpen
                    ? "bg-teal-600 text-white shadow-xs"
                    : "text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                <Stamp className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setFavorite(!favorite)}
              title={favorite ? "Favorilerden Çıkar" : "Favorilere Ekle"}
              className={`p-2 rounded-xl transition-colors ${
                favorite
                  ? "text-amber-500 bg-amber-50 dark:bg-amber-950/40"
                  : "text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              <Star className={`w-4 h-4 ${favorite ? "fill-current" : ""}`} />
            </button>

            <button
              type="button"
              onClick={() => setPinned(!pinned)}
              title={pinned ? "Sabitlemeyi Kaldır" : "Başa Sabitle"}
              className={`p-2 rounded-xl transition-colors ${
                pinned
                  ? "text-teal-600 bg-teal-50 dark:bg-teal-950/40"
                  : "text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              <Pin className={`w-4 h-4 ${pinned ? "fill-current" : ""}`} />
            </button>

            <button
              type="button"
              onClick={handleDownloadMarkdown}
              title="Markdown Olarak İndir"
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleSave}
              title="Kaydet ve Kapat"
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white shadow-md shadow-teal-500/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Kaydet</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              title="Kapat"
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Toast Notification */}
        {snapshotSuccess && (
          <div className="bg-teal-600 text-white text-xs font-bold px-4 py-2 flex items-center justify-between animate-in slide-in-from-top z-30 shrink-0">
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              {snapshotSuccess}
            </span>
            {onOpenSideGallery && (
              <button
                type="button"
                onClick={onOpenSideGallery}
                className="underline hover:text-teal-100"
              >
                Galeriyi Aç →
              </button>
            )}
          </div>
        )}

        {/* Speech Dictation Active Banner */}
        {isListeningSpeech && (
          <div className="bg-rose-500 text-white text-xs font-bold px-4 py-2 flex items-center justify-between animate-pulse z-30 shrink-0">
            <span className="flex items-center gap-2">
              <Mic className="w-4 h-4 animate-bounce" />
              Sesli Yazma Aktif: Konuşun, söyledikleriniz metne dökülüyor...
            </span>
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className="px-2 py-0.5 rounded bg-white text-rose-600 text-[11px] font-bold"
            >
              Durdur
            </button>
          </div>
        )}

        {/* Sensitive Data Auto-Detect Scanner Alert Banner */}
        {detectedSensitiveType && (
          <div className="bg-amber-500 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-between border-b border-amber-600/20 shadow-lg z-30 shrink-0 select-none animate-in slide-in-from-top">
            <span className="flex items-center gap-2">
              <Lock className="w-4 h-4 animate-bounce shrink-0" />
              <span>
                <strong>Güvenlik Taraması:</strong> Bu not içinde hassas veri (<strong>{detectedSensitiveType}</strong>) tespit edildi! Korumak için şifreli Kasaya taşınsın mı?
              </span>
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsVault(true);
                  setCategory("Şifreler");
                  setDetectedSensitiveType(null);
                }}
                className="px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-700 rounded-lg text-[11px] font-black shadow-md transition-all shrink-0 cursor-pointer"
              >
                ✓ Evet, Kasaya Al
              </button>
              <button
                type="button"
                onClick={() => {
                  setHasDeclinedVaultSecure(true);
                  setDetectedSensitiveType(null);
                }}
                className="p-1 hover:bg-white/20 text-white/95 rounded-lg text-[10px] underline font-medium shrink-0 cursor-pointer"
              >
                Yoksay
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. DYNAMIC FORMATTING TOOLBAR (With Inline MindMap Button)                 */}
        {/* ========================================================================= */}
        <AnimatePresence>
          {isEditing && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="bg-slate-50 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700/80 px-4 py-2 space-y-2 z-20 shrink-0"
            >
              <RichTextToolbar
                onGenerateMindMap={handleGenerateTextMindMap}
                onGenerateAudioVideoMindMap={handleGenerateMediaMindMap}
                hasAudioVideoMedia={audioNotes.length > 0}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* ========================================================================= */}
        {/* 3. COLORNOTE FULL-BLEED ÇİZGİLİ DEFTER OKUMA & YAZMA ALANI                */}
        {/* ========================================================================= */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
          <FullBleedRuledEditor
            title={title}
            onChangeTitle={setTitle}
            content={content}
            onChangeContent={setContent}
            updatedAt={note?.updatedAt}
            createdAt={note?.createdAt}
            isEditing={isEditing}
            onToggleEditMode={() => {
              if (!isEditing) {
                activateEditMode();
              } else {
                setIsEditing(false);
              }
            }}
            fontFamily={activeFontFamily}
            category={category}
            tags={tagInput ? tagInput.split(/\s+/).filter(Boolean) : []}
            stylusLayer={
              <StylusCanvasOverlay
                isEnabled={isStylusActive}
                activeTool={stylusTool}
                color={stylusColor}
                strokeSize={stylusSize}
                opacity={1.0}
                initialStrokes={stylusStrokes}
                onStrokesUpdated={(updated, recognizedText) => {
                  setStylusStrokes(updated);
                  if (recognizedText) {
                    setContent((prev) => (prev ? `${prev}\n\n[El Yazısı]: ${recognizedText}` : `[El Yazısı]: ${recognizedText}`));
                  }
                }}
                onToggleTool={() => setStylusTool((prev) => (prev === "eraser" ? "ballpoint" : "eraser"))}
                onUndo={() => setStylusStrokes((prev) => prev.slice(0, -1))}
              />
            }
          >
            {/* Embedded YouTube Video if present */}
            {youtubeVideoId && (
              <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black shadow-md max-w-2xl my-2">
                <div className="p-2 bg-slate-900 text-white text-xs font-semibold flex items-center gap-2">
                  <Video className="w-4 h-4 text-red-500" />
                  <span>YouTube Video Önizleme</span>
                </div>
                <div className="relative pt-[56.25%]">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${youtubeVideoId}`}
                    title="YouTube Preview"
                    className="absolute inset-0 w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              </div>
            )}

            {/* Checklist Tasks Section */}
            {(tasks.length > 0 || isEditing) && (
              <div className="space-y-3 p-3.5 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckSquare className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                    <span className="text-xs font-bold">
                      Kontrol Listesi ({tasks.filter((t) => t.completed).length}/{tasks.length})
                    </span>
                  </div>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={() => addNewEmptyTask()}
                      className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Hızlı Görev Ekle</span>
                    </button>
                  )}
                </div>

                {tasks.length > 0 && (
                  <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-teal-500 to-emerald-500 transition-all duration-300"
                      style={{
                        width: `${(tasks.filter((t) => t.completed).length / (tasks.length || 1)) * 100}%`,
                      }}
                    />
                  </div>
                )}

                <div className="space-y-1.5">
                  {tasks.map((task, index) => (
                    <div
                      key={task.id}
                      className={`flex items-center justify-between gap-2.5 p-2 rounded-xl border transition-all ${
                        task.completed
                          ? "bg-slate-100/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 opacity-75"
                          : "bg-white/80 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 shadow-2xs"
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => toggleTask(task.id)}
                        className="rounded text-teal-600 focus:ring-0 w-4 h-4 cursor-pointer shrink-0 accent-teal-600"
                      />
                      <input
                        ref={(el) => {
                          taskInputRefs.current[task.id] = el;
                        }}
                        type="text"
                        value={task.text}
                        onChange={(e) => updateTaskText(task.id, e.target.value)}
                        onKeyDown={(e) => handleTaskKeyDown(e, index, task)}
                        placeholder="Görev açıklaması..."
                        readOnly={!isEditing}
                        className={`flex-1 text-xs bg-transparent border-0 focus:outline-hidden font-medium ${
                          task.completed ? "line-through opacity-60 font-normal" : ""
                        }`}
                      />
                      {isEditing && (
                        <button
                          type="button"
                          onClick={() => deleteTask(task.id)}
                          className="text-slate-400 hover:text-rose-500 p-1 rounded-lg transition-colors cursor-pointer shrink-0"
                          title="Görevi Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Audio Recordings */}
            {audioNotes.length > 0 && (
              <div className="space-y-2 p-3 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl">
                <span className="text-xs font-bold">Sesli Notlar:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {audioNotes.map((audio) => (
                    <div
                      key={audio.id}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <button
                          type="button"
                          onClick={() => playAudioNote(audio)}
                          className="w-8 h-8 rounded-full bg-teal-600 hover:bg-teal-500 text-white flex items-center justify-center shrink-0 shadow-xs"
                        >
                          {playingAudioId === audio.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                        </button>
                        <div className="min-w-0">
                          <p className="font-semibold truncate">{audio.name || "Ses Kaydı"}</p>
                          <p className="text-[10px] opacity-70">{audio.duration || "0:30"} • {new Date(audio.createdAt).toLocaleDateString("tr-TR")}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Attachments Preview Grid */}
            {attachments.length > 0 && (
              <div className="space-y-2 p-3 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl">
                <span className="text-xs font-bold">Ekli Dosyalar & Belgeler:</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {attachments.map((att) => (
                    <div
                      key={att.id}
                      className="relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-800/80 p-1.5 text-xs"
                    >
                      {att.mime.startsWith("image/") ? (
                        <img src={att.data} alt={att.name} className="w-full h-20 object-cover rounded-lg mb-1" />
                      ) : (
                        <div className="w-full h-20 bg-slate-100 dark:bg-slate-700 rounded-lg flex items-center justify-center font-bold mb-1 opacity-70">
                          DOC
                        </div>
                      )}
                      <p className="truncate text-[11px] font-medium">{att.name}</p>
                      <div className="flex items-center gap-1 mt-1 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setViewingAttachment(att)}
                          className="text-[10px] text-teal-600 dark:text-teal-400 font-bold hover:underline"
                        >
                          📂 Aç
                        </button>
                        {att.mime.startsWith("image/") && (
                          <button
                            type="button"
                            onClick={() => insertImageIntoEditor(att.data)}
                            className="text-[10px] text-teal-600 hover:underline font-bold"
                          >
                            + Ekle
                          </button>
                        )}
                        {isEditing && (
                          <button
                            type="button"
                            onClick={() => setAttachments(attachments.filter((a) => a.id !== att.id))}
                            className="text-[10px] text-rose-500 hover:underline ml-auto"
                          >
                            Sil
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </FullBleedRuledEditor>
        </div>

        {/* ========================================================================= */}
        {/* 4. COMPACT BOTTOM SHEETS (Non-obtrusive popovers for radial tools)        */}
        {/* ========================================================================= */}
        <AnimatePresence>
          {activeSheet && (
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 30, stiffness: 350 }}
              className="absolute bottom-0 inset-x-0 z-35 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-700 p-4 sm:p-5 shadow-2xl rounded-t-3xl max-h-[60vh] overflow-y-auto"
            >
              {/* Sheet Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
                <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
                  {activeSheet === "ai" && <Sparkles className="w-4 h-4 text-amber-500" />}
                  {activeSheet === "color" && <Palette className="w-4 h-4 text-emerald-500" />}
                  {activeSheet === "tasks" && <CheckSquare className="w-4 h-4 text-teal-500" />}
                  {activeSheet === "tag_category" && <Tag className="w-4 h-4 text-amber-500" />}
                  {activeSheet === "reminder" && <Clock className="w-4 h-4 text-violet-500" />}
                  {activeSheet === "frame_box" && <Frame className="w-4 h-4 text-cyan-500" />}
                  {activeSheet === "audio" && <Mic className="w-4 h-4 text-purple-500" />}
                  <span>
                    {activeSheet === "ai" && "Yapay Zeka Not Asistanı"}
                    {activeSheet === "color" && "Not Rengi & Tema"}
                    {activeSheet === "tasks" && "Hızlı Görev Ekle"}
                    {activeSheet === "tag_category" && "Kategori & Etiketler"}
                    {activeSheet === "reminder" && "Hatırlatıcı Ayarla"}
                    {activeSheet === "frame_box" && "30-Şablon Kart Çerçeveleri"}
                    {activeSheet === "audio" && "Ses Kaydı Başlat"}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveSheet(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Sheet Content: AI Assistant */}
              {activeSheet === "ai" && (
                <div className="space-y-3">
                  {aiLoading && (
                    <div className="flex items-center gap-2 text-xs text-amber-600 animate-pulse font-medium">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      İşleniyor, lütfen bekleyin...
                    </div>
                  )}
                  {aiMessage && (
                    <div className="text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-100/60 dark:bg-emerald-950/60 p-2.5 rounded-xl">
                      {aiMessage}
                    </div>
                  )}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-semibold">
                    <button
                      type="button"
                      disabled={aiLoading}
                      onClick={handleAiSemanticCategorize}
                      className="p-3 bg-amber-500/10 dark:bg-amber-500/20 hover:bg-amber-500/20 dark:hover:bg-amber-500/30 border border-amber-300 dark:border-amber-700/60 rounded-xl flex flex-col items-center gap-1.5 text-center transition-all text-amber-900 dark:text-amber-200"
                    >
                      <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
                      <span>🏷️ Semantik Kategorile</span>
                    </button>
                    <button
                      type="button"
                      disabled={aiLoading}
                      onClick={handleAiSummarize}
                      className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-amber-950/40 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-col items-center gap-1.5 text-center transition-all"
                    >
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>✨ Akıllı Özet</span>
                    </button>
                    <button
                      type="button"
                      disabled={aiLoading}
                      onClick={() => handleAiEnhance("polish")}
                      className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950/40 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-col items-center gap-1.5 text-center transition-all"
                    >
                      <Edit3 className="w-4 h-4 text-teal-500" />
                      <span>✍️ Metni İyileştir</span>
                    </button>
                    <button
                      type="button"
                      disabled={aiLoading}
                      onClick={handleAiExtractTasks}
                      className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-col items-center gap-1.5 text-center transition-all"
                    >
                      <CheckSquare className="w-4 h-4 text-cyan-500" />
                      <span>🎯 Görevleri Ayıkla</span>
                    </button>
                    <button
                      type="button"
                      disabled={aiLoading}
                      onClick={handleAiGenerateFlashcards}
                      className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-purple-50 dark:hover:bg-purple-950/40 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-col items-center gap-1.5 text-center transition-all"
                    >
                      <Layers className="w-4 h-4 text-purple-500" />
                      <span>🎓 Çalışma Kartı</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Sheet Content: Color Picker */}
              {activeSheet === "color" && (
                <div className="space-y-3">
                  <span className="text-xs font-semibold text-slate-500">Not Kartı Rengi:</span>
                  <div className="flex items-center gap-3">
                    {COLOR_OPTIONS.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setColor(c.id)}
                        title={c.name}
                        className={`w-8 h-8 rounded-full ${c.class} transition-all ${
                          color === c.id ? "scale-125 ring-3 ring-teal-500 shadow-md" : "opacity-80 hover:opacity-100"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Sheet Content: Tasks Form */}
              {activeSheet === "tasks" && (
                <div className="space-y-3">
                  <form onSubmit={handleAddTask} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      placeholder="Yeni görev veya kontrol maddesi ekle..."
                      className="flex-1 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Ekle</span>
                    </button>
                  </form>
                </div>
              )}

              {/* Sheet Content: Tags & Category */}
              {activeSheet === "tag_category" && (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-semibold text-slate-500 shrink-0">Kategori:</span>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl px-3 py-2 border border-slate-200 dark:border-slate-700 focus:outline-hidden focus:ring-2 focus:ring-teal-500 flex-1"
                    >
                      {categories.filter((c) => c !== "Tümü").map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      placeholder="Etiketler (#fikir #proje #önemli şeklinde ayırın)"
                      className="w-full text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>
              )}

              {/* Sheet Content: Reminder */}
              {activeSheet === "reminder" && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 border border-slate-200 dark:border-slate-700">
                    <Clock className="w-4 h-4 text-violet-500" />
                    <input
                      type="datetime-local"
                      value={reminder}
                      onChange={(e) => setReminder(e.target.value)}
                      className="text-xs bg-transparent text-slate-800 dark:text-slate-200 focus:outline-hidden flex-1"
                    />
                    {reminder && (
                      <button
                        type="button"
                        onClick={() => setReminder("")}
                        className="text-xs text-slate-400 hover:text-slate-600"
                      >
                        ✕ Temizle
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Sheet Content: Frame Presets Box */}
              {activeSheet === "frame_box" && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {ALL_FRAME_PRESETS.slice(0, 8).map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        handleInsertFramePreset(preset);
                        setActiveSheet(null);
                      }}
                      className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 text-left text-xs bg-slate-50 dark:bg-slate-800 hover:bg-teal-50/50 transition-colors"
                    >
                      <p className="font-bold text-slate-800 dark:text-slate-200 truncate">{preset.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{preset.category}</p>
                    </button>
                  ))}
                </div>
              )}

              {/* Sheet Content: Audio Recorder */}
              {activeSheet === "audio" && (
                <AudioRecorder
                  onSaveAudio={(newAudio) => {
                    setAudioNotes((prev) => [...prev, newAudio]);
                    setActiveSheet(null);
                  }}
                  onInsertTranscriptToNote={(transcript) => {
                    setIsEditing(true);
                    if (editorRef.current && transcript.trim()) {
                      const space = editorRef.current.innerHTML.endsWith(" ") ? "" : " ";
                      editorRef.current.innerHTML += `<div style="margin:10px 0; padding:12px; background-color:#eff6ff; border:1px solid #bfdbfe; border-radius:12px; font-size:13px; color:#1e40af; line-height:1.6;"><strong>🎙️ Ses Transkripsiyonu:</strong><br/>${transcript.replace(/\n/g, "<br/>")}</div><p><br></p>`;
                      syncContentFromEditor();
                    }
                  }}
                  onClose={() => setActiveSheet(null)}
                />
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global RadialMenu is rendered in App.tsx */}

        {/* Advanced Floating Stylus & Tool Dock */}
        <AdvancedFloatingToolDock
          isVisible={isStylusActive}
          activeTool={stylusTool}
          onChangeTool={setStylusTool}
          activeColor={stylusColor}
          onChangeColor={setStylusColor}
          strokeSize={stylusSize}
          onChangeStrokeSize={setStylusSize}
          opacity={stylusOpacity}
          onChangeOpacity={setStylusOpacity}
          canvasStyle={canvasStyle}
          isShapeRecognitionActive={isShapeRecognitionActive}
          onToggleShapeRecognition={() => setIsShapeRecognitionActive(!isShapeRecognitionActive)}
          onUndo={() => setStylusStrokes((prev) => prev.slice(0, -1))}
          onRedo={() => {}}
          onClearAll={() => setStylusStrokes([])}
          onRecognizeText={async () => {
            if (stylusStrokes.length === 0) return;
            const res = await DigitalInkRecognitionEngine.recognizeStrokes(stylusStrokes);
            if (res.text) {
              setContent((prev) => (prev ? `${prev}\n\n[El Yazısı Metni]: ${res.text}` : `[El Yazısı Metni]: ${res.text}`));
              setSnapshotSuccess(`El yazısı metne dönüştürüldü: "${res.text}"`);
              setTimeout(() => setSnapshotSuccess(null), 3500);
            }
          }}
          onAddBidirectionalLink={() => {
            const linkTitle = prompt("Bağlanacak not başlığını girin (Örn: Proje Notları):", "");
            if (linkTitle && linkTitle.trim()) {
              const tag = `[[${linkTitle.trim()}]]`;
              setContent((prev) => (prev ? `${prev} ${tag}` : tag));
              setSnapshotSuccess(`🔗 Çift yönlü bağlantı eklendi: ${tag}`);
              setTimeout(() => setSnapshotSuccess(null), 3500);
            }
          }}
          onClose={() => setIsStylusActive(false)}
        />

      </div>

      {/* File Content Viewer Modal */}
      {viewingAttachment && (
        <FileContentViewerModal
          attachment={viewingAttachment}
          onClose={() => setViewingAttachment(null)}
          onAppendToNote={(extractedText) => {
            setIsEditing(true);
            if (editorRef.current) {
              editorRef.current.innerHTML += `<div style="margin:8px 0; padding:12px; background-color:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; font-size:12px; font-family:monospace; color:#166534;"><strong>📄 ${viewingAttachment.name} İçeriği:</strong><br/>${extractedText.replace(/\n/g, "<br/>")}</div>`;
              syncContentFromEditor();
            }
          }}
        />
      )}

      {/* Inline MindMap Modal Overlay */}
      {showMindMapOverlay && inlineMindMapNode && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-5 sm:p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold">
                  🧠
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white">
                    {inlineMindMapNode.label}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Oluşturulan Katmanlı Zihin Haritası Düğüm Grafiği
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowMindMapOverlay(false)}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* MindMap Node Graph Representation */}
            <div className="space-y-3 pt-2">
              {inlineMindMapNode.children?.map((branch) => (
                <div
                  key={branch.id}
                  className="p-3.5 rounded-2xl bg-purple-50/60 dark:bg-purple-950/40 border border-purple-200/80 dark:border-purple-800/80 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-purple-900 dark:text-purple-200 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-purple-500" />
                      <span>{branch.label}</span>
                    </h4>
                    {branch.timestamp && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-purple-200 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                        ⏱️ {branch.timestamp}
                      </span>
                    )}
                  </div>
                  {branch.details && (
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 italic">
                      "{branch.details}"
                    </p>
                  )}
                  {branch.children && branch.children.length > 0 && (
                    <div className="pl-4 pt-1 space-y-1 border-l-2 border-purple-300 dark:border-purple-700">
                      {branch.children.map((leaf) => (
                        <div key={leaf.id} className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                          <span className="text-purple-400">•</span>
                          <span>{leaf.label}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowMindMapOverlay(false)}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all cursor-pointer"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
