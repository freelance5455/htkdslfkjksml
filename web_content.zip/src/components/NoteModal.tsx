import { useState, useEffect } from 'react';
import { Student, NoteEntry } from '../types';
import { X, FileText } from 'lucide-react';

interface NoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  preSelectedStudent?: Student | null;
  onSaveNote: (noteData: Partial<NoteEntry>) => void;
}

export const NoteModal = ({
  isOpen,
  onClose,
  students,
  preSelectedStudent,
  onSaveNote,
}: NoteModalProps) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoteEntry['category']>('Ders Notu');

  useEffect(() => {
    if (preSelectedStudent) {
      setSelectedStudentId(preSelectedStudent.id);
    } else if (students.length > 0 && !selectedStudentId) {
      setSelectedStudentId(students[0].id);
    }
    setTitle('');
    setContent('');
    setCategory('Ders Notu');
  }, [preSelectedStudent, students, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find((s) => s.id === selectedStudentId);
    if (!student || !title.trim() || !content.trim()) return;

    onSaveNote({
      studentId: student.id,
      studentName: student.name,
      title: title.trim(),
      content: content.trim(),
      category,
      date: new Date().toISOString().slice(0, 10),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-zinc-800">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-zinc-900 border border-zinc-800 text-rose-400 rounded-xl">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif text-white">
                Yeni Not & Müfredat Kaydı
              </h3>
              <p className="text-xs text-stone-400">
                Öğrenciye özel ödev, kelime listesi veya ders notu kaydedin
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Öğrenci *
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
            >
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.subject === 'english' ? 'İngilizce' : 'Türkçe'})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Kategori
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full px-3.5 py-2.5 text-xs bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white"
            >
              <option value="Ders Notu">Ders Notu</option>
              <option value="Ödev & Görev">Ödev & Görev</option>
              <option value="Kelime Listesi">Kelime Listesi</option>
              <option value="Genel Değerlendirme">Genel Değerlendirme</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              Not Başlığı *
            </label>
            <input
              type="text"
              required
              placeholder="Örn: Hafta 4 Phrasal Verbs & Ödev"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-zinc-900 border border-zinc-800 rounded-xl focus:bg-zinc-850 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 text-white placeholder:text-stone-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-300 uppercase tracking-wider mb-1">
              İçerik *
            </label>
            <textarea
              required
              rows={4}
              placeholder="Not detayları, verilen sayfalar, yeni kelimeler..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-zinc-900 border border-zinc-800 rounded-xl focus:bg-zinc-850 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 text-white placeholder:text-stone-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-stone-400 hover:text-white rounded-xl transition-all cursor-pointer"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-xl shadow-md shadow-rose-950/40 transition-all cursor-pointer active:scale-95"
            >
              Notu Kaydet
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
