import { itemById } from "../lib/catalog";

/**
 * Real vector artwork for every cosmetic, instead of a flat colour swatch.
 *
 * Each icon is drawn from the item's own two tints so it always matches what
 * actually appears on Jeeko in 3D, and every one carries a gradient plus
 * shading so it reads as a real object rather than a blob.
 */
export function ItemIcon({
  id,
  className = "size-full",
  locked = false,
}: {
  id: string;
  className?: string;
  locked?: boolean;
}) {
  const item = itemById(id);
  if (!item) return null;

  const a = locked ? "#8A93A6" : item.tint;
  const b = locked ? "#5C6575" : (item.tint2 ?? item.tint);
  const gid = `g-${id}`;
  const sid = `s-${id}`;

  const defs = (
    <defs>
      <linearGradient id={gid} x1="0" y1="0" x2="0.6" y2="1">
        <stop offset="0%" stopColor={b} />
        <stop offset="55%" stopColor={a} />
        <stop offset="100%" stopColor={a} stopOpacity="0.75" />
      </linearGradient>
      <linearGradient id={sid} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
        <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
      </linearGradient>
    </defs>
  );

  const P = (props: { d: string; fill?: string; o?: number }) => (
    <path d={props.d} fill={props.fill ?? `url(#${gid})`} opacity={props.o} />
  );

  const art = () => {
    switch (id) {
      /* ---------------- hoodies / jackets ---------------- */
      case "hoodie_cream":
      case "hoodie_night":
      case "hoodie_blood":
      case "hoodie_galaxy":
      case "jacket_neon":
      case "jacket_leather": {
        const knit = id.startsWith("hoodie") && id !== "hoodie_galaxy";
        return (
          <>
            {/* body */}
            <P d="M16 22 L24 15 L32 19 L40 15 L48 22 L50 46 Q32 51 14 46 Z" />
            {/* sleeves */}
            <P d="M16 22 L9 28 L11 40 L17 38 Z" o={0.9} />
            <P d="M48 22 L55 28 L53 40 L47 38 Z" o={0.9} />
            {/* hood */}
            <path
              d="M24 15 Q32 6 40 15 Q32 21 24 15 Z"
              fill={b}
              opacity="0.95"
            />
            {/* pocket */}
            <path d="M22 36 h20 v8 q-10 3 -20 0 Z" fill="#000" opacity="0.16" />
            {/* drawstrings */}
            <path d="M28 18 v7 M36 18 v7" stroke={b} strokeWidth="1.6" strokeLinecap="round" fill="none" />
            {/* knit ribbing or gloss sweep */}
            {knit ? (
              <g stroke="#fff" strokeOpacity="0.22" strokeWidth="0.8">
                {[26, 30, 34, 38, 42].map((y) => (
                  <path key={y} d={`M15 ${y} q17 3 34 0`} fill="none" />
                ))}
              </g>
            ) : (
              <path d="M16 22 L48 22 L50 46 Q32 51 14 46 Z" fill={`url(#${sid})`} />
            )}
            {/* zip for the shiny ones */}
            {!knit && <path d="M32 19 v29" stroke={b} strokeWidth="1.4" opacity="0.95" />}
          </>
        );
      }

      /* ---------------- horns ---------------- */
      case "horns_devil":
      case "horns_demon":
        return (
          <>
            <P d="M22 46 Q14 34 17 20 Q24 26 27 38 Z" />
            <P d="M42 46 Q50 34 47 20 Q40 26 37 38 Z" />
            <path
              d="M22 46 Q14 34 17 20 Q20 30 24 40 Z M42 46 Q50 34 47 20 Q44 30 40 40 Z"
              fill="#fff"
              opacity="0.22"
            />
            {id === "horns_demon" && (
              <g stroke={b} strokeWidth="1.4" strokeLinecap="round" opacity="0.95">
                <path d="M20 40 l3 -6 l-2 -5" fill="none" />
                <path d="M44 40 l-3 -6 l2 -5" fill="none" />
              </g>
            )}
            <ellipse cx="32" cy="48" rx="15" ry="3.5" fill={b} opacity="0.35" />
          </>
        );

      /* ---------------- halo ---------------- */
      case "halo":
        return (
          <>
            <ellipse cx="32" cy="32" rx="20" ry="8" fill="none" stroke={b} strokeWidth="9" opacity="0.28" />
            <ellipse cx="32" cy="32" rx="20" ry="8" fill="none" stroke={`url(#${gid})`} strokeWidth="5" />
            <ellipse cx="26" cy="28" rx="5" ry="1.8" fill="#fff" opacity="0.75" />
          </>
        );

      /* ---------------- glasses ---------------- */
      case "visor_cyber":
        return (
          <>
            <path d="M10 26 Q32 18 54 26 L54 36 Q32 44 10 36 Z" fill={a} />
            <path d="M13 28 Q32 22 51 28 L51 33 Q32 39 13 33 Z" fill={b} />
            <path d="M13 28 Q32 22 51 28 L51 30 Q32 25 13 30 Z" fill="#fff" opacity="0.45" />
            <rect x="29" y="27" width="5" height="5" rx="1" fill="#fff" opacity="0.9" />
          </>
        );
      case "shades_holo":
        return (
          <>
            <path d="M8 26 Q32 20 56 26 L56 30 Q32 24 8 30 Z" fill={a} />
            <ellipse cx="20" cy="34" rx="12" ry="9" fill={`url(#${gid})`} />
            <ellipse cx="44" cy="34" rx="12" ry="9" fill={`url(#${gid})`} />
            <ellipse cx="17" cy="31" rx="4" ry="2.6" fill="#fff" opacity="0.7" />
            <ellipse cx="41" cy="31" rx="4" ry="2.6" fill="#fff" opacity="0.7" />
            <path d="M32 30 h0.5" stroke={a} strokeWidth="3" />
          </>
        );

      /* ---------------- demon wings ---------------- */
      case "wings_demon":
        return (
          <>
            <P d="M32 20 Q16 14 8 26 Q16 28 12 38 Q22 34 24 44 Q30 34 32 24 Z" />
            <P d="M32 20 Q48 14 56 26 Q48 28 52 38 Q42 34 40 44 Q34 34 32 24 Z" />
            <g stroke={b} strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.95">
              <path d="M30 22 L12 27 M30 26 L15 36 M30 30 L24 42" />
              <path d="M34 22 L52 27 M34 26 L49 36 M34 30 L40 42" />
            </g>
          </>
        );

      /* ---------------- animated body colours ---------------- */
      case "c_galaxy":
      case "c_neon":
      case "c_demon":
      case "c_holo":
        return (
          <>
            {/* chick silhouette filled with the colour */}
            <circle cx="32" cy="38" r="17" fill={`url(#${gid})`} />
            <circle cx="32" cy="22" r="11" fill={b} />
            <path d="M29 23 l-4 3 l4 3 Z" fill="#FF9412" />
            <circle cx="28" cy="20" r="1.9" fill="#2A1806" />
            <circle cx="36" cy="20" r="1.9" fill="#2A1806" />
            {id === "c_galaxy" && (
              <g fill="#fff">
                <circle cx="25" cy="41" r="1.1" />
                <circle cx="38" cy="36" r="0.9" />
                <circle cx="33" cy="46" r="1.2" />
                <circle cx="41" cy="44" r="0.8" />
              </g>
            )}
            {id === "c_neon" && (
              <g stroke="#fff" strokeOpacity="0.6" strokeWidth="1" fill="none">
                <path d="M18 38 h28 M18 44 h28" />
              </g>
            )}
            {id === "c_demon" && (
              <g stroke="#FFB03A" strokeWidth="1.3" fill="none" strokeLinecap="round">
                <path d="M24 44 l4 -6 l-2 -4" />
                <path d="M40 42 l-4 -5 l3 -4" />
              </g>
            )}
            {id === "c_holo" && (
              <path d="M15 38 q17 -8 34 0 q-17 8 -34 0 Z" fill="#fff" opacity="0.3" />
            )}
          </>
        );

      /* ---------------- shop items fall back to a tidy generic ---------------- */
      default:
        return <GenericIcon slot={item.slot} gid={gid} sid={sid} b={b} />;
    }
  };

  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      {defs}
      {art()}
    </svg>
  );
}

/** Clean per-slot silhouettes for the regular shop catalogue. */
function GenericIcon({
  slot,
  gid,
  sid,
  b,
}: {
  slot: string;
  gid: string;
  sid: string;
  b: string;
}) {
  if (slot === "hat") {
    return (
      <>
        <path d="M14 42 q18 -6 36 0 l0 4 q-18 5 -36 0 Z" fill={b} />
        <path d="M20 42 q0 -20 12 -20 q12 0 12 20 Z" fill={`url(#${gid})`} />
        <path d="M20 42 q0 -20 12 -20 q-4 8 -4 20 Z" fill={`url(#${sid})`} />
      </>
    );
  }
  if (slot === "glasses") {
    return (
      <>
        <circle cx="21" cy="33" r="11" fill={`url(#${gid})`} />
        <circle cx="43" cy="33" r="11" fill={`url(#${gid})`} />
        <circle cx="21" cy="33" r="11" fill="none" stroke={b} strokeWidth="2.4" />
        <circle cx="43" cy="33" r="11" fill="none" stroke={b} strokeWidth="2.4" />
        <path d="M32 31 h0.5 M10 30 l-4 -3 M54 30 l4 -3" stroke={b} strokeWidth="2.4" strokeLinecap="round" />
        <ellipse cx="18" cy="29" rx="3.4" ry="2.2" fill="#fff" opacity="0.6" />
      </>
    );
  }
  if (slot === "neck") {
    return (
      <>
        <ellipse cx="32" cy="30" rx="19" ry="8" fill="none" stroke={`url(#${gid})`} strokeWidth="6" />
        <circle cx="32" cy="41" r="6" fill={b} />
        <circle cx="30" cy="39" r="2" fill="#fff" opacity="0.6" />
      </>
    );
  }
  if (slot === "buddy") {
    return (
      <>
        <circle cx="32" cy="34" r="14" fill={`url(#${gid})`} />
        <path d="M32 48 v8" stroke={b} strokeWidth="3" strokeLinecap="round" />
        <path d="M24 28 q8 -8 16 0" stroke="#fff" strokeOpacity="0.5" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </>
    );
  }
  if (slot === "suit") {
    return (
      <>
        <path d="M16 22 L24 16 L32 20 L40 16 L48 22 L50 46 Q32 50 14 46 Z" fill={`url(#${gid})`} />
        <path d="M24 16 Q32 8 40 16 Q32 22 24 16 Z" fill={b} />
      </>
    );
  }
  // colour
  return (
    <>
      <circle cx="32" cy="38" r="17" fill={`url(#${gid})`} />
      <circle cx="32" cy="22" r="11" fill={b} />
      <path d="M29 23 l-4 3 l4 3 Z" fill="#FF9412" />
      <circle cx="28" cy="20" r="1.9" fill="#2A1806" />
      <circle cx="36" cy="20" r="1.9" fill="#2A1806" />
    </>
  );
}
