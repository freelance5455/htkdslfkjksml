import React from 'react';
import { ItemIconKind } from '../game/types';

interface ItemIconProps {
  kind: ItemIconKind;
  tintHex: string;
  className?: string;
}

export const ItemIcon: React.FC<ItemIconProps> = ({ kind, tintHex, className = 'h-8 w-8' }) => {
  switch (kind) {
    case 'sword':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path d="M26 3L29 6L15 20L12 17L26 3Z" fill={tintHex} stroke="#0f172a" strokeWidth="1.2" />
          <path d="M26 3L13 16" stroke="#ffffff" strokeWidth="1" opacity="0.65" />
          <path d="M9 15L17 23L15 25L7 17L9 15Z" fill="#fbbf24" stroke="#0f172a" strokeWidth="1.1" />
          <path d="M11 21L6 26" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <circle cx="5.5" cy="26.5" r="2" fill="#fbbf24" stroke="#0f172a" strokeWidth="0.9" />
        </svg>
      );
    case 'axe':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path d="M7 27L24 6" stroke="#78350f" strokeWidth="3.2" strokeLinecap="round" />
          <path d="M15 7C21 4.5 27 9 25 16L17.5 13L15 7Z" fill={tintHex} stroke="#0f172a" strokeWidth="1.2" />
          <path d="M23 9C25.5 11.5 25 14 23.5 15.5" stroke="#ffffff" strokeWidth="1.1" opacity="0.6" strokeLinecap="round" />
        </svg>
      );
    case 'bow':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path d="M9 5C21 7 25 14 23 27" stroke={tintHex} strokeWidth="2.8" strokeLinecap="round" />
          <path d="M9 5L23 27" stroke="#e2e8f0" strokeWidth="1" strokeDasharray="1.5 1" />
          <path d="M8 24L25 7" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
          <polygon points="26,6 21,7.5 24.5,11" fill="#e2e8f0" />
        </svg>
      );
    case 'staff':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path d="M7 27L22 10" stroke="#78350f" strokeWidth="2.8" strokeLinecap="round" />
          <circle cx="23.5" cy="8.5" r="4.5" fill={tintHex} stroke="#fef08a" strokeWidth="1.3" />
          <circle cx="22.5" cy="7.2" r="1.4" fill="#ffffff" opacity="0.7" />
        </svg>
      );
    case 'shield':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M16 3.5L26 7.5V16C26 22 21.5 26.8 16 28.5C10.5 26.8 6 22 6 16V7.5L16 3.5Z"
            fill={tintHex}
            stroke="#e2e8f0"
            strokeWidth="1.6"
          />
          <path d="M16 7V25M10 14H22" stroke="#fbbf24" strokeWidth="1.7" strokeLinecap="round" />
          <circle cx="16" cy="14" r="2.2" fill="#fef08a" />
        </svg>
      );
    case 'helmet':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M7 18C7 11.2 11 6.5 16 6.5C21 6.5 25 11.2 25 18V23.5H20V18H12V23.5H7V18Z"
            fill={tintHex}
            stroke="#e2e8f0"
            strokeWidth="1.4"
          />
          <path d="M16 6.5V13" stroke="#fbbf24" strokeWidth="1.6" />
          <rect x="12.5" y="13.5" width="7" height="2" rx="1" fill="#0f172a" />
        </svg>
      );
    case 'armor':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M10 5.5L16 8.5L22 5.5L27 11L23 15V26.5H9V15L5 11L10 5.5Z"
            fill={tintHex}
            stroke="#e2e8f0"
            strokeWidth="1.4"
          />
          <path d="M11.5 14H20.5M16 9V25" stroke="#fbbf24" strokeWidth="1.4" opacity="0.85" />
        </svg>
      );
    case 'gloves':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <rect x="6.5" y="9.5" width="8.5" height="14.5" rx="3" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.3" />
          <rect x="17" y="9.5" width="8.5" height="14.5" rx="3" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.3" />
          <path d="M7 19H15M17 19H25" stroke="#fbbf24" strokeWidth="1.4" />
        </svg>
      );
    case 'boots':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path d="M7 7H14.5V20H20.5V25H7V7Z" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.4" />
          <path d="M17.5 9H24.5V20H27.5V25H17.5V9Z" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.2" opacity="0.85" />
          <path d="M7 11H14.5" stroke="#fbbf24" strokeWidth="1.4" />
        </svg>
      );
    case 'ring':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <circle cx="16" cy="18.5" r="7.5" stroke="#fbbf24" strokeWidth="3.2" />
          <polygon points="16,4.5 20.5,10 16,13.5 11.5,10" fill={tintHex} stroke="#ffffff" strokeWidth="1.1" />
        </svg>
      );
    case 'potion_hp':
    case 'potion_mp':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <rect x="12.5" y="4.5" width="7" height="4" rx="1" fill="#b45309" stroke="#fde68a" strokeWidth="0.8" />
          <path
            d="M12 9H20L24.5 17C25.5 22.5 22 27.5 16 27.5C10 27.5 6.5 22.5 7.5 17L12 9Z"
            fill={tintHex}
            stroke="#e2e8f0"
            strokeWidth="1.4"
          />
          <circle cx="13" cy="18" r="2.2" fill="#ffffff" opacity="0.5" />
          <path d="M14 23H18" stroke="#ffffff" strokeWidth="1.4" strokeLinecap="round" opacity="0.6" />
        </svg>
      );
    case 'food':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <ellipse cx="16" cy="17" rx="10.5" ry="7" fill={tintHex} stroke="#fde68a" strokeWidth="1.5" />
          <path d="M10.5 15L14 19M16.5 14L20 18" stroke="#451a03" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'water':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M16 4.5C16 4.5 24 14 24 20C24 24.4 20.4 28 16 28C11.6 28 8 24.4 8 20C8 14 16 4.5 16 4.5Z"
            fill={tintHex}
            stroke="#e0f2fe"
            strokeWidth="1.5"
          />
          <path d="M12.5 20.5C12.5 22.6 14 24.2 16 24.2" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      );
    case 'crystal':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <polygon points="16,3 23.5,12 20,28 12,28 8.5,12" fill={tintHex} stroke="#e0f2fe" strokeWidth="1.4" />
          <path d="M16 3V28M8.5 12L23.5 12" stroke="#ffffff" strokeWidth="1.1" opacity="0.55" />
        </svg>
      );
    case 'rune':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <rect x="6.5" y="4.5" width="19" height="23" rx="3.5" fill="#1e1b4b" stroke={tintHex} strokeWidth="1.8" />
          <path d="M16 8.5V23.5M12 13L16 8.5L20 13M12 19L20 15" stroke={tintHex} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'ore':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <polygon points="9,11 17,6 25,12 23,24 11,25 6.5,18" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.4" />
          <polygon points="14,12 19,10 21,15 16,17" fill="#ffffff" opacity="0.35" />
        </svg>
      );
    case 'wood':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <rect x="5" y="11" width="22" height="10" rx="3.5" fill={tintHex} stroke="#451a03" strokeWidth="1.4" />
          <ellipse cx="23.5" cy="16" rx="3" ry="4.8" fill="#fde68a" stroke="#78350f" strokeWidth="1.2" />
          <path d="M8 14.5H17M9 17.5H15" stroke="#451a03" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      );
    case 'stone':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <polygon points="8,13 15,7 24,10 26,20 18,25 7,22" fill={tintHex} stroke="#e2e8f0" strokeWidth="1.4" />
          <path d="M12 14L18 17L15 22" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      );
    case 'bone':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M8.5 19.5C6.8 19.5 5.5 20.8 5.5 22.5C5.5 24.2 6.8 25.5 8.5 25.5C9.7 25.5 10.7 24.8 11.2 23.8L23.8 11.2C24.8 10.7 25.5 9.7 25.5 8.5C25.5 6.8 24.2 5.5 22.5 5.5C20.8 5.5 19.5 6.8 19.5 8.5C19.5 9.1 19.7 9.7 20 10.1L10.1 20C9.7 19.7 9.1 19.5 8.5 19.5Z"
            fill={tintHex}
            stroke="#334155"
            strokeWidth="1.3"
          />
          <circle cx="8" cy="23" r="1.5" fill="#ffffff" opacity="0.5" />
          <circle cx="22.5" cy="8" r="1.5" fill="#ffffff" opacity="0.5" />
        </svg>
      );
    case 'skull':
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <path
            d="M16 5C10.5 5 6.5 9 6.5 14.5C6.5 18 8.3 20.8 10.5 22.2V26H21.5V22.2C23.7 20.8 25.5 18 25.5 14.5C25.5 9 21.5 5 16 5Z"
            fill={tintHex}
            stroke="#1e293b"
            strokeWidth="1.4"
          />
          <circle cx="12.2" cy="14.5" r="2.2" fill="#0f172a" />
          <circle cx="19.8" cy="14.5" r="2.2" fill="#0f172a" />
          <path d="M13 22V25.5M16 22V25.5M19 22V25.5" stroke="#1e293b" strokeWidth="1.2" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 32 32" className={className} fill="none">
          <rect x="6" y="10" width="20" height="12" rx="3" fill={tintHex} stroke="#fde68a" strokeWidth="1.3" />
          <circle cx="23" cy="16" r="3" fill="#b45309" />
        </svg>
      );
  }
};
