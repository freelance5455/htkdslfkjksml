import { Button } from "@/components/range/ui";
import type { Operator } from "@/lib/range/store";

export function Splash({
  operator,
  onEnter,
}: {
  operator: Operator;
  onEnter: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg px-6">
      <div className="hud-grid pointer-events-none absolute inset-0 opacity-70" />
      <div className="rise relative flex w-full max-w-md flex-col items-center text-center">
        <div className="relative mb-8 size-36">
          <div className="absolute inset-0 rounded-full border border-line" />
          <div className="absolute inset-4 rounded-full border border-line" />
          <div className="absolute inset-8 rounded-full border border-primary" />
          <div className="radar-sweep absolute inset-0 rounded-full" />
          <div className="absolute inset-0 m-auto size-2 rounded-full bg-primary" />
        </div>
        <p className="text-sm text-muted">خوش آمدید</p>
        <h1 className="mt-2 text-3xl font-extrabold leading-tight">{operator.name}</h1>
        <p className="mt-3 font-mono text-sm text-primary">
          {operator.device}
          <span className="text-muted"> · </span>
          {operator.fps} FPS
          <span className="text-muted"> · PUBG</span>
        </p>
        <ul className="mt-6 w-full space-y-2 text-start text-sm text-muted">
          <li className="rounded-md border border-border bg-surface px-3 py-2">پروفایل اپراتور بارگذاری شد</li>
          <li className="rounded-md border border-border bg-surface px-3 py-2">کاتالوگ رزولورهای عمومی آماده است</li>
          <li className="rounded-md border border-border bg-surface px-3 py-2">وایرگارد فقط روی همین دستگاه می‌ماند</li>
        </ul>
        <Button className="mt-8 w-full" onClick={onEnter}>
          ورود به رنج
        </Button>
      </div>
    </div>
  );
}
