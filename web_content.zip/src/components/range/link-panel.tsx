import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { Button, Panel } from "@/components/range/ui";
import { dnsPair, findDns } from "@/lib/range/dns-catalog";
import { copyText, downloadText } from "@/lib/range/net";
import { useRange } from "@/lib/range/store";
import { confForMode, parseWg } from "@/lib/range/wireguard";

const MODE_COPY = {
  dns: "فقط رزولور اعمال می‌شود. تونل را روشن نکن. DNS خریده‌شدهٔ داخل وایرگارد دست نمی‌خورد.",
  wg: "فایل همان‌طور که خریدی می‌ماند، شامل DNS خودش اگر داشته باشد. رزولور انتخابی جداگانه اعمال نمی‌شود.",
  both: "DNS انتخابی داخل [Interface] نوشته می‌شود تا تونل همان رزولور را استفاده کند. لازم نیست جداگانه DNS گوشی را عوض کنی.",
} as const;

export function LinkPanel() {
  const mode = useRange((s) => s.mode);
  const dnsId = useRange((s) => s.dnsId);
  const customs = useRange((s) => s.customs);
  const wgId = useRange((s) => s.wgId);
  const profiles = useRange((s) => s.profiles);
  const [armed, setArmed] = useState(false);

  const dns = findDns(dnsId, customs);
  const profile = profiles.find((item) => item.id === wgId) ?? null;
  const pair = dnsPair(dns);

  const output = useMemo(() => {
    if (!profile) return "";
    return confForMode(profile.raw, pair, mode);
  }, [mode, pair, profile]);

  const needsWg = mode !== "dns";

  function arm() {
    if (needsWg && !profile) {
      toast.error("اول یک کانفیگ وایرگارد انتخاب کن");
      return;
    }
    if (needsWg && profile && parseWg(profile.raw).errors.length) {
      toast.error("کانفیگ انتخاب‌شده ناقص است");
      return;
    }
    setArmed(true);
  }

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <h2 className="text-xl font-extrabold">ترکیب و اعمال</h2>
        <p className="mt-1 text-sm text-muted">{MODE_COPY[mode]}</p>
        <p className="mt-3 text-sm text-muted">
          این برنامه تونل را بالا نمی‌آورد و DNS سیستم را عوض نمی‌کند. مرورگر، و بستهٔ وبی که به APK تبدیل شود،
          اجازهٔ VpnService اندروید را ندارد. پروفایل را می‌سازد؛ اعمال با تنظیمات گوشی یا اپ رسمی WireGuard است.
        </p>
        <Button className="mt-4 w-full" onClick={arm}>
          بستن پروفایل
        </Button>
      </Panel>

      {armed && (
        <Panel className="rise">
          <p className="text-sm text-primary">پروفایل مسلح شد — هنوز روی سیستم اعمال نشده</p>
          <ol className="mt-3 list-decimal space-y-2 ps-5 text-sm">
            {mode !== "wg" && (
              <li>
                رزولور {dns.name}:{" "}
                <span dir="ltr" className="font-mono">
                  {pair}
                </span>
                {dns.dot ? (
                  <>
                    . در اندروید: تنظیمات، شبکه، Private DNS، نام میزبان{" "}
                    <span dir="ltr" className="font-mono">
                      {dns.dot}
                    </span>
                    .
                  </>
                ) : (
                  ". اگر نام DoT ندارد، وای‌فای را استاتیک کن و همین دو آدرس را در DNS بگذار. این فقط همان وای‌فای است."
                )}
              </li>
            )}
            {mode === "dns" && <li>وایرگارد را خاموش بگذار تا DNS گوشی دست‌نخورده بماند.</li>}
            {mode === "wg" && profile && (
              <li>فایل اصلی «{profile.name}» را در اپ WireGuard وارد کن و تونل را از همان‌جا روشن کن.</li>
            )}
            {mode === "both" && profile && (
              <li>
                فایل ترکیب‌شده را دانلود کن. خط DNS داخل Interface همان رزولور انتخابی است. در WireGuard ایمپورت کن
                و سوئیچ تونل را آنجا بزن.
              </li>
            )}
            <li>پابجی را بعد از اعمال باز کن. رجیستر سرور را این صفحه تضمین نمی‌کند.</li>
          </ol>

          <div className="mt-4 flex flex-wrap gap-2">
            {mode !== "wg" && (
              <Button
                variant="ghost"
                onClick={async () => {
                  await copyText(pair);
                  toast("DNS کپی شد");
                }}
              >
                کپی DNS
              </Button>
            )}
            {dns.dot && mode !== "wg" && (
              <Button
                variant="ghost"
                onClick={async () => {
                  await copyText(dns.dot!);
                  toast("نام Private DNS کپی شد");
                }}
              >
                کپی Private DNS
              </Button>
            )}
            {needsWg && profile && (
              <Button
                onClick={() => {
                  downloadText(`${profile.name.replace(/\s+/g, "-")}.conf`, output);
                  toast("فایل کانفیگ دانلود شد");
                }}
              >
                <Download className="size-4" />
                دانلود conf
              </Button>
            )}
          </div>

          {needsWg && output && (
            <pre
              dir="ltr"
              className="mt-4 max-h-64 overflow-auto rounded-md bg-bg p-3 text-start font-mono text-xs leading-relaxed text-fg"
            >
              {output.replace(/PrivateKey\s*=\s*\S+/i, "PrivateKey = ••••")}
            </pre>
          )}
        </Panel>
      )}

      <Panel>
        <h3 className="font-semibold">بسته برای گوشی</h3>
        <p className="mt-1 text-sm text-muted">
          فایل زیپ یک نسخهٔ آفلاین از همین کنسول است. اگر آن را به APK وب‌ویو تبدیل کنی، ظاهر برنامه را داری ولی
          همچنان باید DNS را در تنظیمات و وایرگارد را در اپ رسمی روشن کنی.
        </p>
        <a
          href="/sharif-range.zip"
          download
          className="mt-4 inline-flex h-11 items-center justify-center rounded-md border border-border bg-bg-raised px-4 text-sm font-semibold"
        >
          دانلود زیپ
        </a>
      </Panel>
    </div>
  );
}
