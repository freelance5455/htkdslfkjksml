import { useState } from "react";
import { Radar } from "lucide-react";
import { toast } from "sonner";
import { Button, Panel, pingTone } from "@/components/range/ui";
import { CLUSTERS, REGISTER_NOTE, clusterFor, countryFa } from "@/lib/range/clusters";
import { PATH_BEACONS, fetchGeo, measureBeacon } from "@/lib/range/net";
import { useRange } from "@/lib/range/store";

export function RegisterPanel() {
  const geo = useRange((s) => s.geo);
  const paths = useRange((s) => s.paths);
  const setGeo = useRange((s) => s.setGeo);
  const setPath = useRange((s) => s.setPath);
  const [busy, setBusy] = useState(false);

  const active = clusterFor(geo?.countryCode);

  async function read() {
    setBusy(true);
    const place = await fetchGeo();
    setGeo(place);
    if (!place) toast.error("موقعیت شبکه خوانده نشد");
    for (const beacon of PATH_BEACONS) {
      const ms = await measureBeacon(beacon);
      setPath(beacon.id, ms);
    }
    setBusy(false);
    toast(place ? "نقطهٔ شبکه به‌روز شد" : "فقط مسیرها سنجیده شد");
  }

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold">درخت رجیستر</h2>
            <p className="mt-1 text-sm text-muted">{REGISTER_NOTE}</p>
          </div>
          <Button onClick={read} disabled={busy}>
            <Radar className={busy ? "spin size-4" : "size-4"} />
            {busy ? "در حال خواندن" : "خواندن رجیستر"}
          </Button>
        </div>
        {geo && (
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <div className="rounded-md border border-border bg-bg-raised p-3">
              <p className="text-xs text-muted">کشور خروجی</p>
              <p className="mt-1 font-semibold">{countryFa(geo.countryCode, geo.country)}</p>
            </div>
            <div className="rounded-md border border-border bg-bg-raised p-3">
              <p className="text-xs text-muted">شهر تقریبی</p>
              <p className="mt-1 font-semibold">{geo.city || "—"}</p>
            </div>
            <div className="rounded-md border border-border bg-bg-raised p-3">
              <p className="text-xs text-muted">IP خروجی</p>
              <p dir="ltr" className="mt-1 text-start font-mono text-sm">
                {geo.ip || "—"}
              </p>
            </div>
          </div>
        )}
      </Panel>

      <Panel>
        <h3 className="font-semibold">خوشه‌های پابجی</h3>
        <ol className="relative mt-4 border-s border-line ps-5">
          {CLUSTERS.map((cluster) => {
            const on = active?.id === cluster.id;
            return (
              <li key={cluster.id} className="relative mb-3 last:mb-0">
                <span
                  className={`absolute -start-[1.4rem] top-4 size-3 rounded-full ${on ? "bg-primary" : "bg-line"}`}
                />
                <div className={`rounded-md border p-3 ${on ? "border-primary bg-bg-raised" : "border-border"}`}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold">{cluster.title}</p>
                    {on && <span className="text-xs text-primary">رجیستر محتمل</span>}
                  </div>
                  <p className="mt-1 text-sm text-muted">{cluster.hint}</p>
                </div>
              </li>
            );
          })}
        </ol>
      </Panel>

      <Panel>
        <h3 className="font-semibold">تاخیر مسیرهای وب</h3>
        <p className="mt-1 text-sm text-muted">
          این‌ها لبهٔ HTTPS هستند، نه پورت UDP بازی. برای مقایسهٔ مسیر به درد می‌خورند.
        </p>
        <div className="mt-3 flex flex-col gap-2">
          {PATH_BEACONS.map((beacon) => {
            const hit = paths[beacon.id];
            return (
              <div key={beacon.id} className="flex items-center justify-between gap-3 rounded-md bg-bg-raised px-3 py-3">
                <div>
                  <p className="font-semibold">{beacon.name}</p>
                  <p className="text-xs text-muted">{beacon.region}</p>
                </div>
                <p className={`font-mono ${pingTone(hit?.ms)}`}>
                  {hit ? (hit.ms == null ? "بدون پاسخ" : `${hit.ms} ms`) : "—"}
                </p>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
