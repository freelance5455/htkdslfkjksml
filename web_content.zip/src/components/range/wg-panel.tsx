import { useState } from "react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button, Field, Panel, inputClass } from "@/components/range/ui";
import { useRange } from "@/lib/range/store";
import { endpointHost, maskKey, parseWg } from "@/lib/range/wireguard";

export function WgPanel() {
  const profiles = useRange((s) => s.profiles);
  const wgId = useRange((s) => s.wgId);
  const addProfile = useRange((s) => s.addProfile);
  const removeProfile = useRange((s) => s.removeProfile);
  const selectWg = useRange((s) => s.selectWg);
  const [name, setName] = useState("");
  const [raw, setRaw] = useState("");

  function save(text: string, label?: string) {
    const trimmed = text.trim();
    if (trimmed.length < 20 || trimmed.length > 20000) {
      toast.error("متن کانفیگ خالی یا بیش از حد بلند است");
      return;
    }
    const parsed = parseWg(trimmed);
    if (parsed.errors.length) {
      toast.error(parsed.errors[0]);
      return;
    }
    const profileName = (label || name).trim() || endpointHost(parsed.endpoint);
    addProfile({
      id: crypto.randomUUID(),
      name: profileName,
      raw: trimmed,
      createdAt: Date.now(),
    });
    setRaw("");
    setName("");
    toast("کانفیگ ذخیره شد. کلید خصوصی از این دستگاه خارج نمی‌شود.");
  }

  async function onFile(file: File) {
    if (file.size > 64_000) {
      toast.error("فایل بزرگ‌تر از حد کانفیگ است");
      return;
    }
    const text = await file.text();
    save(text, file.name.replace(/\.conf$/i, ""));
  }

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <h2 className="text-xl font-extrabold">وایرگارد</h2>
        <p className="mt-1 text-sm text-muted">
          کانفیگی که خریدی را بچسبان یا فایل .conf را بیاور. هیچ‌چیز به سرور این برنامه فرستاده نمی‌شود و فقط در
          حافظهٔ همین مرورگر می‌ماند.
        </p>
        <div className="mt-4 grid gap-3">
          <Field label="نام پروفایل">
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="مثلاً سرور فرانکفورت"
              className={inputClass}
            />
          </Field>
          <Field label="متن کانفیگ">
            <textarea
              dir="ltr"
              value={raw}
              onChange={(event) => setRaw(event.target.value)}
              placeholder={"[Interface]\nPrivateKey = \nAddress = 10.0.0.2/32\n\n[Peer]\nPublicKey = \nEndpoint = host:51820\nAllowedIPs = 0.0.0.0/0"}
              className={`${inputClass} h-40 py-3 text-start font-mono text-sm`}
            />
          </Field>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => save(raw)}>ذخیرهٔ کانفیگ</Button>
            <label className="inline-flex h-11 cursor-pointer items-center justify-center rounded-md border border-border bg-bg-raised px-4 text-sm font-semibold">
              انتخاب فایل
              <input
                type="file"
                accept=".conf,text/plain"
                className="sr-only"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void onFile(file);
                  event.target.value = "";
                }}
              />
            </label>
          </div>
        </div>
      </Panel>

      {profiles.length === 0 && (
        <Panel>
          <p className="font-semibold">هنوز کانفیگی نیست</p>
          <p className="mt-1 text-sm text-muted">بعد از خرید، خروجی WireGuard را همین‌جا وارد کن. نمونهٔ داخل کادر کلید واقعی نیست.</p>
        </Panel>
      )}

      <div className="flex flex-col gap-3">
        {profiles.map((profile) => {
          const parsed = parseWg(profile.raw);
          const selected = wgId === profile.id;
          return (
            <article
              key={profile.id}
              className={`rounded-lg border p-4 ${selected ? "border-primary bg-surface" : "border-border bg-bg-raised"}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-semibold">{profile.name}</h3>
                  <p dir="ltr" className="mt-1 text-start font-mono text-sm text-muted">
                    {parsed.endpoint || "بدون Endpoint"}
                  </p>
                </div>
                {selected && <span className="text-xs text-primary">فعال در پروفایل</span>}
              </div>
              <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-muted">Address</dt>
                  <dd dir="ltr" className="text-start font-mono">
                    {parsed.address || "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted">DNS داخل فایل</dt>
                  <dd dir="ltr" className="text-start font-mono">
                    {parsed.dns || "ندارد"}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted">کلید خصوصی</dt>
                  <dd dir="ltr" className="text-start font-mono">
                    {maskKey(parsed.privateKey)}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted">AllowedIPs</dt>
                  <dd dir="ltr" className="text-start font-mono">
                    {parsed.allowedIps || "—"}
                  </dd>
                </div>
              </dl>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button variant="ghost" className="h-10 px-3" onClick={() => selectWg(profile.id)}>
                  انتخاب
                </Button>
                <Button variant="danger" className="h-10 px-3" onClick={() => removeProfile(profile.id)}>
                  <Trash2 className="size-4" />
                  حذف
                </Button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
