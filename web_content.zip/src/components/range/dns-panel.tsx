import { useMemo, useState } from "react";
import { Copy, Plus, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button, Field, Panel, inputClass, pingTone } from "@/components/range/ui";
import {
  DNS_CATALOG,
  REGION_FILTERS,
  dnsPair,
  isIpv4,
  isPrivateIpv4,
  type DnsEntry,
  type RegionFilter,
} from "@/lib/range/dns-catalog";
import { copyText, measureDoH } from "@/lib/range/net";
import { useRange } from "@/lib/range/store";

export function DnsPanel() {
  const dnsId = useRange((s) => s.dnsId);
  const customs = useRange((s) => s.customs);
  const pings = useRange((s) => s.pings);
  const selectDns = useRange((s) => s.selectDns);
  const addCustom = useRange((s) => s.addCustom);
  const removeCustom = useRange((s) => s.removeCustom);
  const setPing = useRange((s) => s.setPing);

  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<RegionFilter>("همه");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [openForm, setOpenForm] = useState(false);
  const [draft, setDraft] = useState({ name: "", primary: "", secondary: "", note: "" });

  const list = useMemo(() => {
    const all = [...customs, ...DNS_CATALOG];
    const q = query.trim().toLowerCase();
    return all.filter((item) => {
      if (filter === "بازی" && !item.gaming) return false;
      if (filter !== "همه" && filter !== "بازی" && item.region !== filter) return false;
      if (!q) return true;
      return [item.name, item.provider, item.primary, item.secondary, item.note, item.pubg]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [customs, filter, query]);

  async function scan(entries: DnsEntry[]) {
    const targets = entries.filter((item) => item.doh);
    if (targets.length === 0) {
      toast("این رزولورها مسیر DoH برای سنجش مرورگر ندارند.");
      return;
    }
    setBusy(true);
    let index = 0;
    for (const item of targets) {
      index += 1;
      setProgress(`${index} از ${targets.length}`);
      const ms = await measureDoH(item.doh!);
      setPing(item.id, ms);
    }
    setProgress("");
    setBusy(false);
    toast("سنجش تمام شد");
  }

  function saveCustom() {
    const primary = draft.primary.trim();
    const secondary = draft.secondary.trim();
    if (!draft.name.trim()) {
      toast.error("نام را بنویس");
      return;
    }
    if (!isIpv4(primary) || (secondary && !isIpv4(secondary))) {
      toast.error("آدرس IPv4 معتبر نیست");
      return;
    }
    if (isPrivateIpv4(primary) || (secondary && isPrivateIpv4(secondary))) {
      toast("آدرس خصوصی است و فقط داخل شبکهٔ خودت جواب می‌دهد");
    }
    const entry: DnsEntry = {
      id: `custom-${crypto.randomUUID()}`,
      name: draft.name.trim(),
      provider: "سفارشی",
      primary,
      secondary: secondary || undefined,
      region: "جهانی",
      pubg: "رزولور خودت",
      note: draft.note.trim() || "اضافه‌شده روی همین دستگاه",
      gaming: true,
      filter: "هیچ",
    };
    addCustom(entry);
    setDraft({ name: "", primary: "", secondary: "", note: "" });
    setOpenForm(false);
    toast("DNS اضافه شد و انتخاب شد");
  }

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold">کاتالوگ DNS</h2>
            <p className="mt-1 text-sm text-muted">
              فقط رزولورهای عمومی شناخته‌شده. Mullvad DNS از نوامبر ۲۰۲۶ خاموش است. پینگ، تاخیر HTTPS تا خود
              رزولور است نه ICMP بازی.
            </p>
          </div>
          <Button onClick={() => scan(list)} disabled={busy}>
            <RefreshCw className={busy ? "spin size-4" : "size-4"} />
            {busy ? progress : "پینگ همین فهرست"}
          </Button>
        </div>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="نام، آی‌پی یا توضیح"
          className={`${inputClass} mt-4`}
        />
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {REGION_FILTERS.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setFilter(item)}
              className={`h-10 shrink-0 rounded-md px-3 text-sm ${
                filter === item ? "bg-primary text-primary-ink" : "border border-border bg-bg-raised text-muted"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </Panel>

      <div className="flex gap-2">
        <Button variant="ghost" onClick={() => setOpenForm((value) => !value)}>
          <Plus className="size-4" />
          DNS خودم
        </Button>
        <Button variant="ghost" onClick={() => scan(DNS_CATALOG.filter((item) => item.gaming))} disabled={busy}>
          فقط مناسب بازی
        </Button>
      </div>

      {openForm && (
        <Panel className="grid gap-3 sm:grid-cols-2">
          <Field label="نام">
            <input
              value={draft.name}
              onChange={(event) => setDraft({ ...draft, name: event.target.value })}
              className={inputClass}
            />
          </Field>
          <Field label="اصلی">
            <input
              dir="ltr"
              value={draft.primary}
              onChange={(event) => setDraft({ ...draft, primary: event.target.value })}
              className={`${inputClass} text-start font-mono`}
            />
          </Field>
          <Field label="ثانویه، اختیاری">
            <input
              dir="ltr"
              value={draft.secondary}
              onChange={(event) => setDraft({ ...draft, secondary: event.target.value })}
              className={`${inputClass} text-start font-mono`}
            />
          </Field>
          <Field label="یادداشت">
            <input
              value={draft.note}
              onChange={(event) => setDraft({ ...draft, note: event.target.value })}
              className={inputClass}
            />
          </Field>
          <Button className="sm:col-span-2" onClick={saveCustom}>
            ذخیره و انتخاب
          </Button>
        </Panel>
      )}

      <div className="flex flex-col gap-3">
        {list.map((item) => {
          const hit = pings[item.id];
          const selected = dnsId === item.id;
          const custom = item.id.startsWith("custom-");
          return (
            <article
              key={item.id}
              className={`rounded-lg border p-4 ${selected ? "border-primary bg-surface" : "border-border bg-bg-raised"}`}
            >
              <div className="flex items-start justify-between gap-3">
                <button type="button" onClick={() => selectDns(item.id)} className="min-w-0 flex-1 text-start">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold">{item.name}</span>
                    <span className="rounded-sm bg-bg px-2 py-0.5 text-xs text-muted">{item.region}</span>
                    {item.gaming && <span className="text-xs text-primary">بازی</span>}
                    {selected && <span className="text-xs text-primary">انتخاب شده</span>}
                  </span>
                  <span dir="ltr" className="mt-2 block text-start font-mono text-sm">
                    {dnsPair(item)}
                  </span>
                </button>
                <div className="text-end">
                  <p className={`font-mono text-lg ${pingTone(hit?.ms)}`}>
                    {hit ? (hit.ms == null ? "—" : hit.ms) : "–"}
                  </p>
                  <p className="text-xs text-muted">{item.doh ? "ms DoH" : "بدون DoH"}</p>
                </div>
              </div>
              <p className="mt-2 text-sm text-fg">{item.pubg}</p>
              <p className="mt-1 text-sm text-muted">{item.note}</p>
              {hit?.ms != null && (
                <div className="mt-3 h-1.5 overflow-hidden rounded-sm bg-bg">
                  <div
                    className="bar-in h-full bg-primary"
                    style={{ width: `${Math.max(8, Math.min(100, 100 - hit.ms / 4))}%` }}
                  />
                </div>
              )}
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  variant="ghost"
                  className="h-10 px-3"
                  onClick={async () => {
                    await copyText(dnsPair(item));
                    toast("آدرس کپی شد");
                  }}
                >
                  <Copy className="size-4" />
                  کپی
                </Button>
                {item.dot && (
                  <Button
                    variant="ghost"
                    className="h-10 px-3"
                    onClick={async () => {
                      await copyText(item.dot!);
                      toast("نام Private DNS کپی شد");
                    }}
                  >
                    Private DNS
                  </Button>
                )}
                {item.doh && (
                  <Button variant="ghost" className="h-10 px-3" disabled={busy} onClick={() => scan([item])}>
                    پینگ
                  </Button>
                )}
                <Button variant="ghost" className="h-10 px-3" onClick={() => selectDns(item.id)}>
                  انتخاب
                </Button>
                {custom && (
                  <Button variant="danger" className="h-10 px-3" onClick={() => removeCustom(item.id)}>
                    <Trash2 className="size-4" />
                    حذف
                  </Button>
                )}
              </div>
            </article>
          );
        })}
        {list.length === 0 && <Panel>چیزی با این فیلتر پیدا نشد.</Panel>}
      </div>
    </div>
  );
}
