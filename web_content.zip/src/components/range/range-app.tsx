import { useEffect, useState } from "react";
import { House, Link2, Server, Settings, Shield, Waypoints } from "lucide-react";
import { Toaster } from "sonner";
import { Dashboard } from "@/components/range/dashboard";
import { DnsPanel } from "@/components/range/dns-panel";
import { LinkPanel } from "@/components/range/link-panel";
import { RegisterPanel } from "@/components/range/register-panel";
import { Splash } from "@/components/range/splash";
import { WgPanel } from "@/components/range/wg-panel";
import { Button, Field, Panel, inputClass } from "@/components/range/ui";
import { cn } from "@/lib/cn";
import { useRange, type Operator } from "@/lib/range/store";
import type { Mode } from "@/lib/range/wireguard";

type Tab = "home" | "dns" | "tree" | "wg" | "link";

const TABS: { id: Tab; label: string; icon: typeof House }[] = [
  { id: "home", label: "خانه", icon: House },
  { id: "dns", label: "DNS", icon: Server },
  { id: "tree", label: "رجیستر", icon: Waypoints },
  { id: "wg", label: "وایرگارد", icon: Shield },
  { id: "link", label: "ترکیب", icon: Link2 },
];

const MODES: { id: Mode; label: string; hint: string }[] = [
  { id: "dns", label: "فقط DNS", hint: "فقط رزولور. تونل دست نمی‌خورد." },
  { id: "wg", label: "فقط وایرگارد", hint: "کانفیگ خریداری‌شده، بدون دستکاری DNS." },
  { id: "both", label: "ترکیب هر دو", hint: "همان وایرگارد، با DNS انتخابی داخل تونل." },
];

export function RangeApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [splash, setSplash] = useState(true);
  const [settings, setSettings] = useState(false);
  const mode = useRange((s) => s.mode);
  const setMode = useRange((s) => s.setMode);
  const operator = useRange((s) => s.operator);
  const setOperator = useRange((s) => s.setOperator);
  const active = MODES.find((item) => item.id === mode) ?? MODES[2];

  useEffect(() => {
    void useRange.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--color-surface)",
            color: "var(--color-fg)",
            border: "1px solid var(--color-border)",
            fontFamily: "var(--font-sans)",
          },
        }}
      />
      {splash && <Splash operator={operator} onEnter={() => setSplash(false)} />}
      <header className="sticky top-0 z-20 border-b border-border bg-bg/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <p className="text-xs text-muted">RANGE</p>
            <h1 className="truncate text-lg font-extrabold">شریف‌رنج</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-end">
              <p className="font-mono text-xs text-primary">{operator.device}</p>
              <p className="text-xs text-muted">{operator.fps} FPS · PUBG</p>
            </div>
            <button
              type="button"
              aria-label="مشخصات دستگاه"
              onClick={() => setSettings(true)}
              className="inline-flex size-11 items-center justify-center rounded-md border border-border bg-bg-raised"
            >
              <Settings className="size-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 pt-4 pb-28">
        <div role="radiogroup" aria-label="حالت اتصال" className="grid grid-cols-3 gap-1 rounded-lg border border-border bg-bg-raised p-1">
          {MODES.map((item) => (
            <button
              key={item.id}
              type="button"
              role="radio"
              aria-checked={mode === item.id}
              onClick={() => setMode(item.id)}
              className={cn(
                "h-11 rounded-md px-1 text-sm font-semibold",
                mode === item.id ? "bg-primary text-primary-ink" : "text-muted",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
        <p className="text-sm text-muted">{active.hint}</p>
        {tab === "home" && <Dashboard onNavigate={setTab} />}
        {tab === "dns" && <DnsPanel />}
        {tab === "tree" && <RegisterPanel />}
        {tab === "wg" && <WgPanel />}
        {tab === "link" && <LinkPanel />}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg-raised/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl pb-[max(0.25rem,env(safe-area-inset-bottom))]">
          {TABS.map((item) => {
            const Icon = item.icon;
            const on = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={cn(
                  "flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs",
                  on ? "text-primary" : "text-muted",
                )}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>

      {settings && (
        <SettingsSheet
          operator={operator}
          onClose={() => setSettings(false)}
          onSave={(next) => {
            setOperator(next);
            setSettings(false);
          }}
        />
      )}
    </div>
  );
}

function SettingsSheet({
  operator,
  onClose,
  onSave,
}: {
  operator: Operator;
  onClose: () => void;
  onSave: (next: Operator) => void;
}) {
  const [draft, setDraft] = useState(operator);
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/80 sm:items-center">
      <Panel className="m-4 w-full max-w-md">
        <h2 className="text-lg font-extrabold">مشخصات دستگاه</h2>
        <p className="mt-1 text-sm text-muted">این پروفایل نمایشی است، نه اسپوف برای بازی.</p>
        <div className="mt-4 flex flex-col gap-3">
          <Field label="نام">
            <input
              value={draft.name}
              onChange={(event) => setDraft({ ...draft, name: event.target.value })}
              className={inputClass}
            />
          </Field>
          <Field label="دستگاه">
            <input
              dir="ltr"
              value={draft.device}
              onChange={(event) => setDraft({ ...draft, device: event.target.value })}
              className={`${inputClass} text-start font-mono`}
            />
          </Field>
          <Field label="فریم هدف در پابجی">
            <input
              dir="ltr"
              inputMode="numeric"
              value={draft.fps}
              onChange={(event) => setDraft({ ...draft, fps: Number(event.target.value) || 0 })}
              className={`${inputClass} text-start font-mono`}
            />
          </Field>
        </div>
        <div className="mt-4 flex gap-2">
          <Button
            className="flex-1"
            onClick={() => {
              const fps = Math.min(144, Math.max(1, Math.round(draft.fps)));
              onSave({
                name: draft.name.trim() || operator.name,
                device: draft.device.trim() || operator.device,
                fps,
              });
            }}
          >
            ذخیره
          </Button>
          <Button variant="ghost" className="flex-1" onClick={onClose}>
            بستن
          </Button>
        </div>
      </Panel>
    </div>
  );
}
