import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Panel({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section className={cn("rounded-lg border border-border bg-surface p-4", className)}>{children}</section>
  );
}

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-opacity disabled:opacity-50",
        variant === "primary" && "bg-primary text-primary-ink",
        variant === "ghost" && "border border-border bg-bg-raised text-fg",
        variant === "danger" && "border border-border bg-bg-raised text-accent",
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm">
      <span className="text-muted">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary";

export function pingTone(ms: number | null | undefined): string {
  if (ms == null) return "text-muted";
  if (ms < 80) return "text-primary";
  if (ms < 180) return "text-fg";
  return "text-accent";
}
