import { useEffect, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, Shield, Waypoints } from "lucide-react";
import { Button, Panel, pingTone } from "@/components/range/ui";
import { DNS_CATALOG, dnsPair, findDns, recommendIds } from "@/lib/range/dns-catalog";
import { countryFa } from "@/lib/range/clusters";
import { useRange } from "@/lib/range/store";
import { endpointHost } from "@/lib/range/wireguard";

const MODE_LABEL = {
  dns: "فقط DNS",
  wg: "فقط وایرگارد",
  both: "ترکیب هر دو",
} as const;

export function Dashboard({ onNavigate }: { onNavigate: (tab: "dns" | "tree" | "wg" | "link") => void }) {
  const mode = useRange((s) => s.mode);
  const dnsId = useRange((s) => s.dnsId);
  const customs = useRange((s) => s.customs);
  const wgId = useRange((s) => s.wgId);
  const profiles = useRange((s) => s.profiles);
  const pings = useRange((s) => s.pings);
  const geo = useRange((s) => s.geo);
  const operator = useRange((s) => s.operator);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const dns = findDns(dnsId, customs);
  const profile = profiles.find((item) => item.id === wgId);
  const ping = pings[dns.id];
  const suggestions = recommendIds(geo?.countryCode)
    .map((id) => DNS_CATALOG.find((item) => item.id === id))
    .filter((item) => item != null);

  const chart = DNS_CATALOG.map((item) => {
    const hit = pings[item.id];
    if (!hit || hit.ms == null) return null;
    return { name: item.name, ms: hit.ms };
  })
    .filter((item) => item != null)
    .sort((a, b) => a.ms - b.ms)
    .slice(0, 8);

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <p className="text-sm text-muted">اپراتور</p>
        <h2 className="mt-1 text-2xl font-extrabold">{operator.name}</h2>
        <p className="mt-2 text-sm text-muted">
          حالت فعال: <span className="text-fg">{MODE_LABEL[mode]}</span>
          {geo ? ` · خروجی از ${countryFa(geo.countryCode, geo.country)}` : ""}
        </p>
      </Panel>

      <div className="grid gap-3 sm:grid-cols-3">
        <Panel>
          <div className="flex items-center gap-2 text-muted">
            <Waypoints className="size-4 text-primary" />
            <span className="text-sm">رزولور</span>
          </div>
          <p className="mt-3 font-semibold">{dns.name}</p>
          <p dir="ltr" className="mt-1 text-start font-mono text-sm text-muted">
            {dnsPair(dns)}
          </p>
          <p className={`mt-2 font-mono text-sm ${pingTone(ping?.ms)}`}>
            {ping?.ms != null ? `${ping.ms} ms` : "هنوز سنجیده نشده"}
          </p>
        </Panel>
        <Panel>
          <div className="flex items-center gap-2 text-muted">
            <Shield className="size-4 text-primary" />
            <span className="text-sm">وایرگارد</span>
          </div>
          <p className="mt-3 font-semibold">{profile ? profile.name : "کانفیگی نیست"}</p>
          <p className="mt-1 text-sm text-muted">
            {profile ? "روی دستگاه ذخیره شده" : "کانفیگ خریداری‌شده را اضافه کن"}
          </p>
        </Panel>
        <Panel>
          <div className="flex items-center gap-2 text-muted">
            <Activity className="size-4 text-primary" />
            <span className="text-sm">دستگاه</span>
          </div>
          <p className="mt-3 font-mono text-sm text-primary">{operator.device}</p>
          <p className="mt-1 text-sm text-muted">{operator.fps} FPS در پابجی · پروفایل ثبت‌شده</p>
        </Panel>
      </div>

      <Panel>
        <div className="flex items-center justify-between gap-3">
          <h3 className="font-semibold">نزدیک به موقعیت تو</h3>
          <Button variant="ghost" className="h-9 px-3" onClick={() => onNavigate("tree")}>
            درخت رجیستر
          </Button>
        </div>
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {suggestions.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                useRange.getState().selectDns(item.id);
                onNavigate("dns");
              }}
              className="min-w-36 shrink-0 rounded-md border border-border bg-bg-raised px-3 py-3 text-start"
            >
              <span className="block text-sm font-semibold">{item.name}</span>
              <span className="mt-1 block text-xs text-muted">{item.region}</span>
            </button>
          ))}
        </div>
      </Panel>

      <Panel>
        <h3 className="font-semibold">تاخیر DoH رزولورها</h3>
        <p className="mt-1 text-sm text-muted">میلی‌ثانیه تا خود رزولور، نه پینگ UDP سرور بازی.</p>
        {mounted && chart.length > 0 ? (
          <div dir="ltr" className="mt-3 h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 11 }} interval={0} angle={-25} height={56} textAnchor="end" />
                <YAxis tick={{ fill: "var(--color-muted)", fontSize: 11 }} width={36} />
                <Tooltip
                  cursor={{ fill: "transparent" }}
                  contentStyle={{
                    background: "var(--color-bg-raised)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                    color: "var(--color-fg)",
                  }}
                />
                <Bar dataKey="ms" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">از برگهٔ DNS یک دور پینگ بگیر تا نمودار پر شود.</p>
        )}
      </Panel>

      <div className="grid gap-3 sm:grid-cols-2">
        <Button onClick={() => onNavigate("dns")}>سنجش DNS</Button>
        <Button variant="ghost" onClick={() => onNavigate("link")}>
          ساخت پروفایل ترکیب
        </Button>
      </div>
    </div>
  );
}
