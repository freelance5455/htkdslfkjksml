import React, { useRef, useState, useEffect } from 'react';
import { 
  Scan, Camera, RefreshCw, X, Sparkles, AlertCircle, 
  Layers, Volume2, Flashlight, Info, Eye, Gauge, Shield, Cpu,
  Maximize2, Play, Square, Upload
} from 'lucide-react';
import { BlueprintData, BlueprintComponent } from '../types';
import { voiceEngine } from '../services/voiceService';
import { safeFetchJson } from '../services/apiClient';

interface BlueprintScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveToChat?: (blueprint: BlueprintData) => void;
  initialPrompt?: string;
}

export const BlueprintScannerModal: React.FC<BlueprintScannerModalProps> = ({
  isOpen,
  onClose,
  onSaveToChat,
  initialPrompt,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const liveScanTimerRef = useRef<any>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isLiveScanning, setIsLiveScanning] = useState(false);
  const [blueprintData, setBlueprintData] = useState<BlueprintData | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<BlueprintComponent | null>(null);
  const [viewMode, setViewMode] = useState<'optical' | 'blueprint'>('optical');
  const [activeTab, setActiveTab] = useState<'overview' | 'subsystems' | 'engine' | 'blueprint'>('overview');
  const [language, setLanguage] = useState<'en' | 'hi' | 'pa'>('en');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isTorchOn, setIsTorchOn] = useState(false);

  // Optical HUD Telemetry
  const [hudTelemetry, setHudTelemetry] = useState({
    fps: 30,
    fov: '78° WIDE',
    resolution: '1080p FHD',
    lux: '420 lx',
    targetLock: 'ACQUIRING...',
  });

  // Handle modal lifecycle
  useEffect(() => {
    if (isOpen) {
      startCamera(facingMode);
    } else {
      stopCamera();
      stopLiveScan();
    }
    return () => {
      stopCamera();
      stopLiveScan();
    };
  }, [isOpen, facingMode]);

  // Simulate subtle HUD telemetry updates
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setHudTelemetry(prev => ({
        ...prev,
        fps: 28 + Math.floor(Math.random() * 5),
        lux: `${400 + Math.floor(Math.random() * 50)} lx`,
      }));
    }, 1500);
    return () => clearInterval(interval);
  }, [isOpen]);

  const startCamera = async (mode: 'environment' | 'user') => {
    setErrorMsg(null);
    try {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setHudTelemetry(prev => ({ ...prev, targetLock: 'OPTICAL LOCK ENGAGED' }));
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setErrorMsg('Camera access is not permitted or unavailable. You can upload an image or select a sample schematic below.');
      setHudTelemetry(prev => ({ ...prev, targetLock: 'NO OPTICAL FEED' }));
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsTorchOn(false);
  };

  const toggleTorch = async () => {
    if (!stream) return;
    const track = stream.getVideoTracks()[0];
    const capabilities = (track.getCapabilities?.() as any) || {};
    if (capabilities.torch) {
      try {
        const next = !isTorchOn;
        await (track as any).applyConstraints({ advanced: [{ torch: next }] });
        setIsTorchOn(next);
      } catch (e) {
        console.warn('Torch constraint error:', e);
      }
    } else {
      setIsTorchOn(!isTorchOn); // Software fallback
    }
  };

  const toggleCameraFacing = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
  };

  // Capture frame to base64
  const captureFrame = (): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    if (video.videoWidth === 0) return null;

    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  };

  // Perform AI Blueprint Scan
  const executeScan = async (imageData: string, isLiveCall = false) => {
    if (!isLiveCall) {
      setIsScanning(true);
      setErrorMsg(null);
    }

    try {
      voiceEngine.playHudBeep('wake');
      const data = await safeFetchJson<{ blueprint: BlueprintData }>('/api/gemini/blueprint-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imageData,
          userLanguage: language,
          scanMode: isLiveCall ? 'live' : 'snapshot',
        }),
      });

      if (data.blueprint) {
        setBlueprintData(data.blueprint);
        setSelectedComponent(data.blueprint.components?.[0] || null);

        // Vocal delivery in configured male voice
        const spoken = language === 'hi' 
          ? (data.blueprint.hindiExplanation || data.blueprint.explanation)
          : language === 'pa'
          ? (data.blueprint.punjabiExplanation || data.blueprint.explanation)
          : data.blueprint.explanation;

        if (!isLiveCall) {
          voiceEngine.speak(spoken, { pitch: 0.85 });
          onSaveToChat?.(data.blueprint);
        }
      }
    } catch (err: any) {
      console.error('Blueprint Scan Error:', err);
      if (!isLiveCall) {
        setErrorMsg(err.message || 'Blueprint analysis timed out. Check network connection.');
      }
    } finally {
      if (!isLiveCall) {
        setIsScanning(false);
      }
    }
  };

  const handleCaptureSnapshot = () => {
    stopLiveScan();
    const frame = captureFrame();
    if (frame) {
      setCapturedImage(frame);
      executeScan(frame);
    } else {
      setErrorMsg('Failed to grab camera frame. Please ensure camera is active.');
    }
  };

  // Continuous Live Scan Loop (Throttled every 5 seconds)
  const toggleLiveScan = () => {
    if (isLiveScanning) {
      stopLiveScan();
    } else {
      setIsLiveScanning(true);
      setCapturedImage(null);
      // Run first frame immediately
      const frame = captureFrame();
      if (frame) executeScan(frame, true);

      // Throttled loop to avoid expensive flood
      liveScanTimerRef.current = setInterval(() => {
        const nextFrame = captureFrame();
        if (nextFrame) executeScan(nextFrame, true);
      }, 5500);
    }
  };

  const stopLiveScan = () => {
    setIsLiveScanning(false);
    if (liveScanTimerRef.current) {
      clearInterval(liveScanTimerRef.current);
      liveScanTimerRef.current = null;
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    stopLiveScan();
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setCapturedImage(result);
        executeScan(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    stopLiveScan();
    setCapturedImage(null);
    setBlueprintData(null);
    setSelectedComponent(null);
    setErrorMsg(null);
    setViewMode('optical');
  };

  // Preset Sample Mechanical Objects for instant demonstration if camera has no engine
  const loadPresetSample = (type: 'v8' | 'bike' | 'phone') => {
    stopLiveScan();
    const presets: Record<string, BlueprintData> = {
      v8: {
        objectName: "Twin-Turbocharged V8 Engine Assembly",
        category: "Automotive High-Performance Powertrain",
        brandModel: "4.0L Hot-V Twin-Turbocharged V8",
        confidenceScore: 96,
        confidenceNotes: "High-contrast visual match with 90° cylinder bank and dual monoscroll turbochargers.",
        dimensionsEstimate: "W: 710mm | H: 650mm | L: 690mm",
        engineSpecs: {
          isVehicleOrEngine: true,
          displacement: "3982 cc",
          cylinderConfig: "90° V8 DOHC 32-Valve",
          coolingSystem: "Dual-circuit liquid intercooling with electric auxiliary pump",
          transmissionPairing: "8-Speed Dual-Clutch Sequential",
          estimatedOutput: "640 HP @ 6,000 RPM | 850 Nm Torque",
        },
        subsystems: [
          { name: "Twin Turbochargers", status: "Nominal", description: "Hot-inside-V architecture minimizing turbo lag and optimizing exhaust pulse resonance.", importance: "High" },
          { name: "Dual Overhead Camshafts", status: "Mapped", description: "Variable valve timing with hydraulic actuators on intake and exhaust cam phasers.", importance: "High" },
          { name: "High-Pressure Direct Injection", status: "Operational", description: "Piezoelectric injectors operating at 350 bar for ultra-fine atomization.", importance: "High" },
          { name: "Dry-Sump Lubrication Loop", status: "Active", description: "Multi-stage scavenge pumps with remote reservoir preventing oil starvation under high lateral G.", importance: "Medium" },
          { name: "Electronic Wastegate Actuators", status: "Standby", description: "Fast-acting stepper motors precisely governing boost pressure up to 1.8 bar.", importance: "Medium" }
        ],
        components: [
          { id: "c1", label: "Left Cylinder Head & Cams", x: 28, y: 32, system: "Valvetrain", desc: "Quad-valve lightweight alloy head housing dual hollow camshafts" },
          { id: "c2", label: "Right Cylinder Head & Cams", x: 72, y: 32, system: "Valvetrain", desc: "Opposing cylinder bank with carbon-coated roller finger followers" },
          { id: "c3", label: "Hot-V Twin Turbochargers", x: 50, y: 22, system: "Forced Induction", desc: "Center-mounted dual turbochargers with liquid-cooled center housings" },
          { id: "c4", label: "Front Serpentine Drive Belt", x: 50, y: 78, system: "Accessory Drive", desc: "Reinforced EPDM belt driving water pump and 48V starter-generator" },
          { id: "c5", label: "High-Volume Intake Charge Pipes", x: 50, y: 46, system: "Air Induction", desc: "Carbon-reinforced conduits channeling pressurized charge air" }
        ],
        blueprintWireframe: {
          schematicType: "Orthographic Engineering Blueprint",
          primaryDimensions: "710mm × 650mm × 690mm",
          isometricAngle: "30° Isometric Wireframe",
          schematicSummary: "Engineering layout mapping Hot-V geometry, crankshaft journals, and twin exhaust conduits.",
          wireframeShapes: [
            { type: "rect", x: 18, y: 18, width: 64, height: 64, stroke: "#00f0ff", label: "V8 Engine Envelope" },
            { type: "circle", x: 50, y: 55, r: 16, stroke: "#38bdf8", label: "Crankshaft Centerline" },
            { type: "circle", x: 34, y: 28, r: 10, stroke: "#00d4ff", label: "Bank 1 Turbo" },
            { type: "circle", x: 66, y: 28, r: 10, stroke: "#00d4ff", label: "Bank 2 Turbo" },
            { type: "line", x1: 18, y1: 55, x2: 82, y2: 55, stroke: "#0284c7", label: "Horizontal Sump Datum" }
          ]
        },
        explanation: "Sir, I have rendered the complete architectural blueprint for this Twin-Turbo V8. The Hot-V turbo layout, cylinder banks, and valve mechanisms have been isolated with 96% confidence.",
        hindiExplanation: "सर, ट्विन-टर्बो V8 इंजन का पूरा ब्लूप्रिंट तैयार है। इसके सभी कंपोनेंट्स और टर्बोचार्जर्स स्क्रीन पर मैप कर दिए गए हैं।",
        punjabiExplanation: "ਸਰ, V8 ਇੰਜਣ ਦਾ ਬਲੂਪ੍ਰਿੰਟ ਸਕੈਨ ਮੁਕੰਮਲ ਹੋ ਗਿਆ ਹੈ।"
      },
      bike: {
        objectName: "Sport Motorcycle Chassis & Powertrain",
        category: "Two-Wheeler Automotive Engineering",
        brandModel: "Supersport 600cc Trellis Frame",
        confidenceScore: 92,
        confidenceNotes: "Identified inverted telescopic forks, radial calipers, and liquid-cooled inline engine.",
        dimensionsEstimate: "Wheelbase: 1400mm | Rake: 24°",
        engineSpecs: {
          isVehicleOrEngine: true,
          displacement: "599 cc",
          cylinderConfig: "Inline-4 16-Valve Liquid Cooled",
          coolingSystem: "Curved Aluminum Radiator",
          transmissionPairing: "6-Speed Quickshifter Assisted",
          estimatedOutput: "120 HP @ 13,500 RPM",
        },
        subsystems: [
          { name: "Braking System", status: "Monitored", description: "Dual 320mm floating discs with radially mounted 4-piston monobloc calipers.", importance: "High" },
          { name: "Suspension Telemetry", status: "Calibrated", description: "43mm fully adjustable inverted cartridge front fork with titanium coating.", importance: "High" },
          { name: "Aluminum Trellis Chassis", status: "Structural", description: "Gravity die-cast perimeter frame delivering optimal torsional rigidity.", importance: "High" },
          { name: "Ram-Air Intake Duct", status: "Active", description: "Central nose cowl intake utilizing positive aerodynamic pressure at speed.", importance: "Medium" }
        ],
        components: [
          { id: "b1", label: "Radial Brake Caliper", x: 30, y: 70, system: "Hydraulic Brakes", desc: "Brembo 4-piston radial caliper with sintered pads" },
          { id: "b2", label: "Inverted Front Fork", x: 32, y: 38, system: "Suspension", desc: "Inverted fork leg governing compression and rebound damping" },
          { id: "b3", label: "Inline-4 Engine Block", x: 55, y: 55, system: "Powertrain", desc: "High-revving 4-cylinder engine stressed member within frame" },
          { id: "b4", label: "Exhaust Header Collector", x: 62, y: 72, system: "Exhaust", desc: "4-into-2-into-1 tuned titanium header pipes" }
        ],
        blueprintWireframe: {
          schematicType: "Chassis Geometry Blueprint",
          primaryDimensions: "L: 2040mm | W: 705mm | H: 1100mm",
          isometricAngle: "Side Elevation Technical Wireframe",
          schematicSummary: "Motorcycle wheelbase, rake angle, and suspension compression travel.",
          wireframeShapes: [
            { type: "circle", x: 26, y: 72, r: 16, stroke: "#00f0ff", label: "Front Wheel & Rotor" },
            { type: "circle", x: 80, y: 72, r: 16, stroke: "#00f0ff", label: "Rear Wheel & Sprocket" },
            { type: "line", x1: 26, y1: 72, x2: 44, y2: 32, stroke: "#38bdf8", label: "Steering Head Angle" },
            { type: "rect", x: 42, y: 46, width: 28, height: 24, stroke: "#00d4ff", label: "Engine Housing Perimeter" }
          ]
        },
        explanation: "Sir, motorcycle chassis and suspension geometry blueprint mapped. Radial braking systems and inline engine are locked in.",
        hindiExplanation: "सर, मोटरसाइकिल चेसिस और इंजन का ब्लूप्रिंट तैयार है।",
        punjabiExplanation: "ਸਰ, ਮੋਟਰਸਾਈਕਲ ਚੈਸਿਸ ਦਾ ਬਲੂਪ੍ਰਿੰਟ ਤਿਆਰ ਹੈ।"
      },
      phone: {
        objectName: "Advanced Smartphone Motherboard Architecture",
        category: "Micro-Electronics & Integrated Circuits",
        brandModel: "Multi-Layer PCB with System-on-Chip",
        confidenceScore: 94,
        confidenceNotes: "Identified camera module array, RF shielding, and high-density battery cell.",
        dimensionsEstimate: "162mm × 76mm × 8.2mm",
        engineSpecs: {
          isVehicleOrEngine: false,
        },
        subsystems: [
          { name: "Processor Core (SoC)", status: "Active", description: "4nm Octa-core CPU with Integrated Neural Processing Unit.", importance: "High" },
          { name: "Optical Image Stabilization Module", status: "Calibrated", description: "Voice-coil motor suspension stabilizing primary sensor.", importance: "High" },
          { name: "Power Management IC (PMIC)", status: "Optimal", description: "Synchronous buck converters regulating stepped system voltages.", importance: "High" },
          { name: "Liquid Vapor Chamber", status: "Dissipating", description: "Sealed copper vapor chamber spreading heat away from processor.", importance: "Medium" }
        ],
        components: [
          { id: "p1", label: "Primary SoC / Processor", x: 48, y: 38, system: "Computing", desc: "High-density multi-core chipset under EMI shield" },
          { id: "p2", label: "Triple Camera Sensor Array", x: 28, y: 24, system: "Optics", desc: "Multi-lens module with periscope telephoto prism" },
          { id: "p3", label: "Lithium-Polymer Cell", x: 50, y: 68, system: "Energy Storage", desc: "5000 mAh dual-cell pack with protection circuitry" },
          { id: "p4", label: "Vapor Chamber Heat Sink", x: 68, y: 42, system: "Thermal", desc: "0.4mm micro-grooved capillary wick dissipating thermal load" }
        ],
        blueprintWireframe: {
          schematicType: "PCB Surface Mount Schematic",
          primaryDimensions: "162mm × 76mm",
          isometricAngle: "Plan Orthographic Layer 1",
          schematicSummary: "Printed circuit routing, IC footprint coordinates, and heat spreading zones.",
          wireframeShapes: [
            { type: "rect", x: 20, y: 15, width: 60, height: 75, stroke: "#00f0ff", label: "Substrate Boundary" },
            { type: "rect", x: 38, y: 30, width: 24, height: 20, stroke: "#38bdf8", label: "SoC Shielding" },
            { type: "rect", x: 30, y: 55, width: 40, height: 30, stroke: "#00d4ff", label: "Battery Enclosure" }
          ]
        },
        explanation: "Sir, high-density micro-electronics schematic mapped. SoC packaging, optical sensors, and thermal dissipation paths are active.",
        hindiExplanation: "सर, माइक्रो-इलेक्ट्रॉनिक्स और मदरबोर्ड का विस्तृत ब्लूप्रिंट तैयार है।",
        punjabiExplanation: "ਸਰ, ਸਰਕਟ ਬੋਰਡ ਦਾ ਬਲੂਪ੍ਰਿੰਟ ਤਿਆਰ ਕਰ ਲਿਆ ਗਿਆ ਹੈ।"
      }
    };

    const selected = presets[type];
    setBlueprintData(selected);
    setSelectedComponent(selected.components[0]);
    voiceEngine.speak(selected.explanation, { pitch: 0.85 });
    onSaveToChat?.(selected);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-5xl bg-gray-950 border border-cyan-400/60 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[94vh] glow-cyan">
        {/* Holographic Glowing Header */}
        <div className="flex items-center justify-between px-3 sm:px-5 py-2.5 bg-gray-950/95 border-b border-cyan-500/40 relative z-20">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-400 flex items-center justify-center glow-cyan-sm">
              <Scan className="w-4 h-4 text-cyan-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-tech text-sm sm:text-base font-bold tracking-wider text-cyan-100 uppercase flex items-center gap-2">
                  JARVIS BLUEPRINT VISION CORE
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono-tech border border-cyan-400/40">
                    MARK VII HUD
                  </span>
                </h2>
              </div>
              <div className="text-[10px] font-mono-tech text-cyan-400/70 hidden sm:block">
                OPTICAL TARGETING • CAD BLUEPRINT ENGINE • COMPONENT TELEMETRY
              </div>
            </div>
          </div>

          {/* Top Controls: View Mode Switch & Close */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-gray-900 border border-cyan-500/30 rounded-xl p-0.5 text-xs font-tech">
              <button
                onClick={() => setViewMode('optical')}
                className={`px-2.5 py-1 rounded-lg uppercase transition-all ${
                  viewMode === 'optical'
                    ? 'bg-cyan-500 text-gray-950 font-bold glow-cyan-sm'
                    : 'text-cyan-300 hover:text-cyan-100'
                }`}
              >
                <Eye className="w-3.5 h-3.5 inline mr-1" />
                Optical
              </button>
              <button
                onClick={() => setViewMode('blueprint')}
                className={`px-2.5 py-1 rounded-lg uppercase transition-all ${
                  viewMode === 'blueprint'
                    ? 'bg-cyan-500 text-gray-950 font-bold glow-cyan-sm'
                    : 'text-cyan-300 hover:text-cyan-100'
                }`}
              >
                <Layers className="w-3.5 h-3.5 inline mr-1" />
                Blueprint
              </button>
            </div>

            {/* Language Selector */}
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-gray-900 border border-cyan-500/30 text-cyan-300 rounded-xl px-2 py-1 text-xs font-mono-tech focus:outline-none focus:border-cyan-400"
            >
              <option value="en">EN</option>
              <option value="hi">HI (हिंदी)</option>
              <option value="pa">PA (ਪੰਜਾਬੀ)</option>
            </select>

            <button
              onClick={onClose}
              title="Close Scanner"
              className="p-1.5 rounded-xl text-cyan-400 hover:bg-cyan-500/20 border border-cyan-500/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center Main Stage (Split View: Viewport on Left, Specs on Right) */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
          {/* VIEWPORT: Camera or Blueprint Canvas */}
          <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden min-h-[300px] lg:min-h-full">
            {viewMode === 'optical' ? (
              /* OPTICAL CAMERA HUD VIEW */
              <div className="relative w-full h-full flex items-center justify-center">
                {!capturedImage ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <img
                    src={capturedImage}
                    alt="Captured Target"
                    className="w-full h-full object-contain bg-gray-950"
                  />
                )}

                {/* Electric-Blue Laser Scanline */}
                {(isScanning || isLiveScanning) && (
                  <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#00f0ff] animate-blueprint-laser pointer-events-none z-10" />
                )}

                {/* Holographic HUD Targeting Reticle & Grids */}
                <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between z-10">
                  {/* Top HUD Readouts */}
                  <div className="flex items-start justify-between text-[10px] font-mono-tech text-cyan-400/90">
                    <div className="space-y-0.5 bg-gray-950/70 p-1.5 rounded border border-cyan-500/30 backdrop-blur-xs">
                      <div>TARGET: {hudTelemetry.targetLock}</div>
                      <div>RES: {hudTelemetry.resolution} | FOV: {hudTelemetry.fov}</div>
                      <div>FPS: {hudTelemetry.fps} | SENSOR: {hudTelemetry.lux}</div>
                    </div>

                    <div className="text-right bg-gray-950/70 p-1.5 rounded border border-cyan-500/30 backdrop-blur-xs">
                      <div>SPECTRUM: 450nm BLUE</div>
                      <div>STATUS: {isScanning ? 'CALCULATING WIREFRAME' : isLiveScanning ? 'LIVE TELEMETRY' : 'READY'}</div>
                    </div>
                  </div>

                  {/* Center Target Box with Angular Brackets */}
                  <div className="self-center w-56 h-56 sm:w-72 sm:h-72 border border-dashed border-cyan-400/40 rounded-2xl relative flex items-center justify-center">
                    <div className="absolute -top-1 -left-1 w-5 h-5 border-t-2 border-l-2 border-cyan-300" />
                    <div className="absolute -top-1 -right-1 w-5 h-5 border-t-2 border-r-2 border-cyan-300" />
                    <div className="absolute -bottom-1 -left-1 w-5 h-5 border-b-2 border-l-2 border-cyan-300" />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 border-b-2 border-r-2 border-cyan-300" />
                    
                    {/* Crosshairs */}
                    <div className="w-6 h-[1px] bg-cyan-400/80" />
                    <div className="h-6 w-[1px] bg-cyan-400/80 absolute" />
                    <div className="w-16 h-16 rounded-full border border-cyan-400/30 animate-ping" />
                  </div>

                  {/* Bottom Camera Tools */}
                  <div className="flex items-center justify-between text-[11px] font-mono-tech text-cyan-300 pointer-events-auto">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={toggleTorch}
                        className={`p-2 rounded-xl border transition-colors ${
                          isTorchOn
                            ? 'bg-amber-400 text-gray-950 border-amber-300'
                            : 'bg-gray-950/70 border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20'
                        }`}
                        title="Toggle Torch"
                      >
                        <Flashlight className="w-4 h-4" />
                      </button>
                      <button
                        onClick={toggleCameraFacing}
                        className="p-2 rounded-xl bg-gray-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20"
                        title="Switch Camera (Front/Back)"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="bg-gray-950/80 px-2 py-1 rounded border border-cyan-500/30 text-[10px]">
                      {blueprintData ? `MATCH: ${blueprintData.objectName}` : 'POINT AT ENGINE, VEHICLE OR OBJECT'}
                    </div>
                  </div>
                </div>

                {/* Interactive Overlaid Component Markers */}
                {blueprintData?.components && blueprintData.components.map((comp) => {
                  const isSelected = selectedComponent?.id === comp.id;
                  return (
                    <div
                      key={comp.id}
                      style={{ left: `${comp.x}%`, top: `${comp.y}%` }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-auto group cursor-pointer"
                      onClick={() => {
                        setSelectedComponent(comp);
                        voiceEngine.speak(`${comp.label}. ${comp.desc}`, { pitch: 0.85 });
                      }}
                    >
                      {/* Pulse target ring */}
                      <div className={`relative flex items-center justify-center transition-transform ${
                        isSelected ? 'scale-125' : 'group-hover:scale-110'
                      }`}>
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                          isSelected
                            ? 'border-cyan-300 bg-cyan-400/40 glow-cyan shadow-[0_0_12px_#00f0ff]'
                            : 'border-cyan-400 bg-cyan-950/70'
                        }`}>
                          <div className="w-1.5 h-1.5 rounded-full bg-cyan-300" />
                        </div>
                        <div className="absolute inset-0 rounded-full border border-cyan-400 animate-ping" />
                      </div>

                      {/* Technical callout label */}
                      <div className={`absolute left-7 top-1/2 -translate-y-1/2 whitespace-nowrap px-2 py-1 rounded bg-gray-950/90 border text-[10px] font-mono-tech transition-all pointer-events-none ${
                        isSelected
                          ? 'border-cyan-300 text-cyan-100 glow-cyan-sm scale-105'
                          : 'border-cyan-500/40 text-cyan-300 opacity-80 group-hover:opacity-100'
                      }`}>
                        <span className="text-cyan-400 font-bold uppercase mr-1">[{comp.system}]</span>
                        {comp.label}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* CAD BLUEPRINT SCHEMATIC VIEW */
              <div className="relative w-full h-full blueprint-grid flex flex-col items-center justify-center p-4">
                {/* Blueprint Header Stamp */}
                <div className="absolute top-3 left-3 text-[10px] font-mono-tech text-cyan-400/90 border border-cyan-400/40 p-2 bg-gray-950/80 rounded">
                  <div className="font-bold text-cyan-200">STARK INDUSTRIES // CAD SPECIFICATION</div>
                  <div>DRAWING: {blueprintData?.blueprintWireframe?.schematicType || 'ORTHOGRAPHIC 2D/3D WIREFRAME'}</div>
                  <div>SCALE: 1:1 APPLIED | PROJECTION: {blueprintData?.blueprintWireframe?.isometricAngle || '30° ISOMETRIC'}</div>
                  <div>DIMENSIONS: {blueprintData?.dimensionsEstimate || blueprintData?.blueprintWireframe?.primaryDimensions || 'CALCULATING'}</div>
                </div>

                {/* SVG Technical Wireframe Vector Canvas */}
                <div className="w-full max-w-md aspect-square relative flex items-center justify-center">
                  <svg
                    viewBox="0 0 100 100"
                    className="w-full h-full drop-shadow-[0_0_10px_rgba(0,240,255,0.4)]"
                  >
                    {/* Coordinate axes */}
                    <line x1="10" y1="50" x2="90" y2="50" stroke="#00f0ff" strokeWidth="0.3" strokeDasharray="1,1" />
                    <line x1="50" y1="10" x2="50" y2="90" stroke="#00f0ff" strokeWidth="0.3" strokeDasharray="1,1" />
                    <circle cx="50" cy="50" r="38" stroke="#00f0ff" strokeWidth="0.4" fill="none" strokeDasharray="2,2" />

                    {/* Dynamic wireframe shapes generated by AI */}
                    {blueprintData?.blueprintWireframe?.wireframeShapes ? (
                      blueprintData.blueprintWireframe.wireframeShapes.map((shape, idx) => {
                        if (shape.type === 'rect') {
                          return (
                            <rect
                              key={idx}
                              x={shape.x}
                              y={shape.y}
                              width={shape.width}
                              height={shape.height}
                              stroke={shape.stroke || '#00f0ff'}
                              strokeWidth="0.8"
                              fill="rgba(0,240,255,0.06)"
                            />
                          );
                        } else if (shape.type === 'circle') {
                          return (
                            <circle
                              key={idx}
                              cx={shape.x}
                              cy={shape.y}
                              r={shape.r || 10}
                              stroke={shape.stroke || '#38bdf8'}
                              strokeWidth="0.8"
                              fill="rgba(56,189,248,0.08)"
                            />
                          );
                        } else if (shape.type === 'line') {
                          return (
                            <line
                              key={idx}
                              x1={shape.x1}
                              y1={shape.y1}
                              x2={shape.x2}
                              y2={shape.y2}
                              stroke={shape.stroke || '#00d4ff'}
                              strokeWidth="0.6"
                            />
                          );
                        }
                        return null;
                      })
                    ) : (
                      /* Default Technical Wireframe Silhouette */
                      <g stroke="#00f0ff" strokeWidth="0.8" fill="none">
                        <rect x="22" y="24" width="56" height="52" rx="4" />
                        <circle cx="50" cy="50" r="16" />
                        <circle cx="50" cy="50" r="6" fill="#00f0ff" opacity="0.3" />
                        <line x1="22" y1="24" x2="78" y2="76" strokeDasharray="1,1" opacity="0.5" />
                        <line x1="22" y1="76" x2="78" y2="24" strokeDasharray="1,1" opacity="0.5" />
                      </g>
                    )}

                    {/* Blueprint Component Callout Anchors */}
                    {blueprintData?.components?.map((c) => (
                      <g key={c.id}>
                        <circle cx={c.x} cy={c.y} r="1.8" fill="#00f0ff" />
                        <circle cx={c.x} cy={c.y} r="3.2" stroke="#00f0ff" strokeWidth="0.4" fill="none" />
                      </g>
                    ))}
                  </svg>
                </div>

                {/* Blueprint Summary Callout Footer */}
                <div className="w-full text-center max-w-lg mt-2 p-2 bg-gray-950/80 border border-cyan-500/30 rounded text-[11px] font-mono-tech text-cyan-200">
                  {blueprintData?.blueprintWireframe?.schematicSummary || 'Technical wireframe schematic based on computer vision geometry.'}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT SIDE: TECHNICAL SPECIFICATIONS & HUD TELEMETRY */}
          <div className="w-full lg:w-96 bg-gray-900/95 border-t lg:border-t-0 lg:border-l border-cyan-500/30 flex flex-col max-h-[50vh] lg:max-h-full">
            {/* Tab navigation */}
            <div className="flex border-b border-cyan-500/30 bg-gray-950/80 text-xs font-tech">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-1 py-2 text-center uppercase transition-colors ${
                  activeTab === 'overview'
                    ? 'text-cyan-300 border-b-2 border-cyan-400 font-bold bg-cyan-950/30'
                    : 'text-gray-400 hover:text-cyan-300'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('subsystems')}
                className={`flex-1 py-2 text-center uppercase transition-colors ${
                  activeTab === 'subsystems'
                    ? 'text-cyan-300 border-b-2 border-cyan-400 font-bold bg-cyan-950/30'
                    : 'text-gray-400 hover:text-cyan-300'
                }`}
              >
                Systems ({blueprintData?.subsystems?.length || 0})
              </button>
              {blueprintData?.engineSpecs?.isVehicleOrEngine && (
                <button
                  onClick={() => setActiveTab('engine')}
                  className={`flex-1 py-2 text-center uppercase transition-colors ${
                    activeTab === 'engine'
                      ? 'text-cyan-300 border-b-2 border-cyan-400 font-bold bg-cyan-950/30'
                      : 'text-gray-400 hover:text-cyan-300'
                  }`}
                >
                  Powertrain
                </button>
              )}
            </div>

            {/* Tab Content Body */}
            <div className="flex-1 p-3 sm:p-4 overflow-y-auto space-y-3 text-xs">
              {errorMsg && (
                <div className="p-2.5 bg-red-950/60 border border-red-500/40 rounded-xl flex items-center gap-2 text-red-200 text-xs">
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {blueprintData ? (
                <>
                  {activeTab === 'overview' && (
                    <div className="space-y-3">
                      {/* Identified Target Header */}
                      <div className="p-3 rounded-xl bg-gray-950/80 border border-cyan-500/30 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono-tech text-cyan-400 uppercase">CLASSIFICATION</span>
                          <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
                            CONFIDENCE: {blueprintData.confidenceScore}%
                          </span>
                        </div>
                        <h3 className="font-tech text-base font-bold text-cyan-100">
                          {blueprintData.objectName}
                        </h3>
                        <div className="text-xs text-cyan-300 font-medium">
                          {blueprintData.brandModel}
                        </div>
                        <div className="text-[11px] text-cyan-400/70 font-mono-tech pt-1">
                          Category: {blueprintData.category}
                        </div>
                        {blueprintData.dimensionsEstimate && (
                          <div className="text-[11px] text-cyan-400/70 font-mono-tech">
                            Dimensions: {blueprintData.dimensionsEstimate}
                          </div>
                        )}
                      </div>

                      {/* Vocal Briefing Card */}
                      <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-tech text-cyan-300 uppercase text-[11px] flex items-center gap-1">
                            <Volume2 className="w-3.5 h-3.5" /> JARVIS Audio Briefing
                          </span>
                          <button
                            onClick={() => {
                              const spoken = language === 'hi'
                                ? (blueprintData.hindiExplanation || blueprintData.explanation)
                                : language === 'pa'
                                ? (blueprintData.punjabiExplanation || blueprintData.explanation)
                                : blueprintData.explanation;
                              voiceEngine.speak(spoken, { pitch: 0.85 });
                            }}
                            className="text-[10px] text-cyan-300 hover:text-cyan-100 underline font-mono-tech"
                          >
                            Replay Voice
                          </button>
                        </div>
                        <p className="text-cyan-100/90 leading-relaxed text-xs">
                          {language === 'hi' 
                            ? (blueprintData.hindiExplanation || blueprintData.explanation)
                            : language === 'pa'
                            ? (blueprintData.punjabiExplanation || blueprintData.explanation)
                            : blueprintData.explanation}
                        </p>
                      </div>

                      {/* Selected Component Inspection */}
                      {selectedComponent && (
                        <div className="p-3 rounded-xl bg-gray-950/90 border border-cyan-400/50 space-y-1 glow-cyan-sm">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono-tech text-cyan-400 uppercase">
                              SELECTED COMPONENT
                            </span>
                            <span className="text-[10px] font-mono-tech text-cyan-300">
                              [{selectedComponent.system}]
                            </span>
                          </div>
                          <div className="font-tech text-sm font-bold text-cyan-100">
                            {selectedComponent.label}
                          </div>
                          <p className="text-cyan-200/80 text-[11px] leading-relaxed">
                            {selectedComponent.desc}
                          </p>
                        </div>
                      )}

                      {/* Components Quick List */}
                      <div>
                        <div className="text-[11px] font-tech text-cyan-300 uppercase mb-1.5">
                          Detected Component Markers ({blueprintData.components.length})
                        </div>
                        <div className="grid grid-cols-1 gap-1.5">
                          {blueprintData.components.map((c) => (
                            <button
                              key={c.id}
                              onClick={() => {
                                setSelectedComponent(c);
                                voiceEngine.speak(`${c.label}. ${c.desc}`, { pitch: 0.85 });
                              }}
                              className={`p-2 rounded-lg border text-left flex items-center justify-between transition-colors ${
                                selectedComponent?.id === c.id
                                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-100'
                                  : 'bg-gray-950/60 border-cyan-500/20 text-cyan-300 hover:border-cyan-400/50'
                              }`}
                            >
                              <span className="font-medium text-xs truncate">{c.label}</span>
                              <span className="text-[10px] font-mono-tech text-cyan-400/70">{c.system}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'subsystems' && (
                    <div className="space-y-2">
                      <div className="text-[11px] font-tech text-cyan-300 uppercase">
                        Active Subsystems & Mechanical Loops:
                      </div>
                      {blueprintData.subsystems?.map((sys, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-gray-950/70 border border-cyan-500/25 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-cyan-100">{sys.name}</span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono-tech">
                              {sys.status}
                            </span>
                          </div>
                          <p className="text-[11px] text-cyan-300/80 leading-relaxed">
                            {sys.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {activeTab === 'engine' && blueprintData.engineSpecs?.isVehicleOrEngine && (
                    <div className="space-y-2.5">
                      <div className="text-[11px] font-tech text-cyan-300 uppercase">
                        Vehicle & Engine Engineering Specifications:
                      </div>
                      <div className="grid grid-cols-1 gap-2">
                        {blueprintData.engineSpecs.displacement && (
                          <div className="p-2.5 bg-gray-950/70 rounded-xl border border-cyan-500/25">
                            <span className="text-[10px] text-cyan-400 font-mono-tech uppercase">Displacement</span>
                            <div className="font-tech text-sm text-cyan-100 font-bold">{blueprintData.engineSpecs.displacement}</div>
                          </div>
                        )}
                        {blueprintData.engineSpecs.cylinderConfig && (
                          <div className="p-2.5 bg-gray-950/70 rounded-xl border border-cyan-500/25">
                            <span className="text-[10px] text-cyan-400 font-mono-tech uppercase">Configuration & Valvetrain</span>
                            <div className="font-tech text-sm text-cyan-100 font-bold">{blueprintData.engineSpecs.cylinderConfig}</div>
                          </div>
                        )}
                        {blueprintData.engineSpecs.coolingSystem && (
                          <div className="p-2.5 bg-gray-950/70 rounded-xl border border-cyan-500/25">
                            <span className="text-[10px] text-cyan-400 font-mono-tech uppercase">Cooling Circuit</span>
                            <div className="text-xs text-cyan-100">{blueprintData.engineSpecs.coolingSystem}</div>
                          </div>
                        )}
                        {blueprintData.engineSpecs.transmissionPairing && (
                          <div className="p-2.5 bg-gray-950/70 rounded-xl border border-cyan-500/25">
                            <span className="text-[10px] text-cyan-400 font-mono-tech uppercase">Transmission / Drivetrain</span>
                            <div className="text-xs text-cyan-100">{blueprintData.engineSpecs.transmissionPairing}</div>
                          </div>
                        )}
                        {blueprintData.engineSpecs.estimatedOutput && (
                          <div className="p-2.5 bg-gray-950/70 rounded-xl border border-cyan-500/25">
                            <span className="text-[10px] text-cyan-400 font-mono-tech uppercase">Estimated Power Output</span>
                            <div className="font-tech text-sm text-amber-300 font-bold">{blueprintData.engineSpecs.estimatedOutput}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                /* Empty state / instructions */
                <div className="text-center py-6 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-cyan-950 border border-cyan-400/50 flex items-center justify-center mx-auto text-cyan-300 glow-cyan-sm">
                    <Scan className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="font-tech text-sm font-bold uppercase text-cyan-200">
                      Optical Targeting Active
                    </h4>
                    <p className="text-[11px] text-cyan-300/70 mt-1 leading-relaxed">
                      Aim camera at any engine, vehicle, motorcycle, car, smartphone, machinery, or tool and tap <span className="text-cyan-200 font-semibold">Snapshot & Blueprint</span>.
                    </p>
                  </div>

                  {/* Preset Quick Demonstration Buttons */}
                  <div className="pt-2 border-t border-cyan-500/20 text-left">
                    <span className="text-[10px] font-mono-tech text-cyan-400 uppercase block mb-1.5">
                      Or Test with Sample Schematics:
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        onClick={() => loadPresetSample('v8')}
                        className="p-1.5 rounded-lg bg-gray-950 border border-cyan-500/30 hover:border-cyan-400 text-[10px] font-tech text-cyan-200 transition-colors"
                      >
                        V8 Engine
                      </button>
                      <button
                        onClick={() => loadPresetSample('bike')}
                        className="p-1.5 rounded-lg bg-gray-950 border border-cyan-500/30 hover:border-cyan-400 text-[10px] font-tech text-cyan-200 transition-colors"
                      >
                        Superbike
                      </button>
                      <button
                        onClick={() => loadPresetSample('phone')}
                        className="p-1.5 rounded-lg bg-gray-950 border border-cyan-500/30 hover:border-cyan-400 text-[10px] font-tech text-cyan-200 transition-colors"
                      >
                        PCB Chip
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Disclaimer Banner */}
            <div className="p-2.5 bg-gray-950/90 border-t border-cyan-500/20 text-[10px] text-cyan-400/60 leading-tight">
              <span className="text-cyan-300 font-semibold">Honest Disclosure:</span> Technical schematic generated from verified engineering database & computer vision. Not an OEM manufacturer CAD file.
            </div>
          </div>
        </div>

        {/* BOTTOM HUD ACTION BAR */}
        <div className="p-3 bg-gray-950/95 border-t border-cyan-500/40 flex flex-wrap items-center justify-between gap-2 z-20">
          <div className="flex items-center gap-2">
            {/* Live Continuous Scan Button */}
            <button
              onClick={toggleLiveScan}
              className={`py-2 px-3 rounded-xl font-tech text-xs uppercase flex items-center gap-1.5 transition-all cursor-pointer ${
                isLiveScanning
                  ? 'bg-amber-400 text-gray-950 font-bold glow-gold animate-pulse'
                  : 'bg-gray-900 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20'
              }`}
            >
              {isLiveScanning ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5" />}
              {isLiveScanning ? 'Stop Live Scan' : 'Live Scan'}
            </button>

            {/* Upload image alternative */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              title="Upload Photo for Blueprint Scan"
              className="p-2 rounded-xl bg-gray-900 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 transition-colors"
            >
              <Upload className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            {capturedImage && (
              <button
                onClick={handleReset}
                className="py-2 px-3 rounded-xl border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 font-tech text-xs uppercase transition-colors"
              >
                Scan Another
              </button>
            )}

            {/* Primary Action Button: Snapshot & Blueprint */}
            <button
              onClick={handleCaptureSnapshot}
              disabled={isScanning}
              className="py-2 px-4 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-gray-950 font-tech font-bold uppercase text-xs flex items-center gap-2 glow-cyan transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              {isScanning ? 'Analyzing Wireframe...' : 'Snapshot & Blueprint'}
            </button>
          </div>
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};
