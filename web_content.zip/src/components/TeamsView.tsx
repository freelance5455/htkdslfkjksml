import React, { useState, useEffect } from 'react';
import { Team, TeamMember, TeamMemberRole, Manhwa, TEAM_ROLE_LABELS, TeamInvitation, UserProfile } from '../types';
import { useAuth } from '../context/AuthContext';
import { hartHost } from '../services/hartHostService';
import { hartTeamService } from '../services/hartTeamService';
import { SmartImage } from './SmartImage';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  query,
  where,
  onSnapshot
} from 'firebase/firestore';
import {
  Users,
  Plus,
  Shield,
  ExternalLink,
  Upload,
  UserPlus,
  Trash2,
  BookOpen,
  X,
  Crown,
  CheckCircle,
  AlertCircle,
  Search,
  Settings,
  Mail,
  Send,
  Globe,
  MessageCircle,
  UserCheck,
  ArrowRightLeft,
  Hash
} from 'lucide-react';

interface TeamsViewProps {
  teams: Team[];
  manhwas: Manhwa[];
  onSelectManhwa: (m: Manhwa) => void;
  onOpenPublisherForTeam: (team: Team) => void;
  onOpenInvitations?: () => void;
  pendingInvitationsCount?: number;
}

export const TeamsView: React.FC<TeamsViewProps> = ({
  teams,
  manhwas,
  onSelectManhwa,
  onOpenPublisherForTeam,
  onOpenInvitations,
  pendingInvitationsCount = 0
}) => {
  const { user, profile, isOwner, signInWithGoogle, updateUserProfile } = useAuth();
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'works' | 'members' | 'invite' | 'settings'>('works');

  // Create Team Form State
  const [teamName, setTeamName] = useState('');
  const [teamDesc, setTeamDesc] = useState('');
  const [teamDiscord, setTeamDiscord] = useState('');
  const [teamTelegram, setTeamTelegram] = useState('');
  const [teamWebsite, setTeamWebsite] = useState('');
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string>('');
  const [isCreatingTeam, setIsCreatingTeam] = useState(false);
  const [createProgressText, setCreateProgressText] = useState('');
  const [createError, setCreateError] = useState('');

  // Team Edit Settings State
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editDiscord, setEditDiscord] = useState('');
  const [editTelegram, setEditTelegram] = useState('');
  const [editWebsite, setEditWebsite] = useState('');
  const [editLogoFile, setEditLogoFile] = useState<File | null>(null);
  const [editLogoPreview, setEditLogoPreview] = useState<string>('');
  const [editBannerFile, setEditBannerFile] = useState<File | null>(null);
  const [editBannerPreview, setEditBannerPreview] = useState<string>('');
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);
  const [settingsError, setSettingsError] = useState('');

  // Search & Invite Member State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchingUser, setIsSearchingUser] = useState(false);
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [searchError, setSearchError] = useState('');
  const [inviteRole, setInviteRole] = useState<TeamMemberRole>('translator');
  const [isSendingInvite, setIsSendingInvite] = useState(false);
  const [inviteSuccessMsg, setInviteSuccessMsg] = useState('');
  const [teamPendingInvites, setTeamPendingInvites] = useState<TeamInvitation[]>([]);

  // Member Management Messages
  const [memberActionError, setMemberActionError] = useState('');
  const [memberActionSuccess, setMemberActionSuccess] = useState('');

  // Sync selected team with prop updates
  useEffect(() => {
    if (selectedTeam) {
      const refreshed = teams.find((t) => t.id === selectedTeam.id);
      if (refreshed) {
        setSelectedTeam(refreshed);
      }
    }
  }, [teams]);

  // When selected team changes, populate edit settings form & listen to team's pending invites
  useEffect(() => {
    if (selectedTeam) {
      setEditName(selectedTeam.name);
      setEditDesc(selectedTeam.description || '');
      setEditDiscord(selectedTeam.discordUrl || '');
      setEditTelegram(selectedTeam.telegramUrl || '');
      setEditWebsite(selectedTeam.websiteUrl || '');
      setEditLogoPreview(selectedTeam.logoUrl || '');
      setEditBannerPreview(selectedTeam.bannerUrl || '');
      setEditLogoFile(null);
      setEditBannerFile(null);
      setFoundUser(null);
      setSearchQuery('');
      setSearchError('');
      setInviteSuccessMsg('');
      setMemberActionError('');
      setMemberActionSuccess('');

      // Listen to pending invitations sent by this team
      const q = query(
        collection(db, 'team_invitations'),
        where('teamId', '==', selectedTeam.id),
        where('status', '==', 'pending')
      );
      const unsubscribe = onSnapshot(
        q,
        (snap) => {
          const invs: TeamInvitation[] = [];
          snap.forEach((d) => invs.push({ id: d.id, ...(d.data() as Omit<TeamInvitation, 'id'>) }));
          setTeamPendingInvites(invs);
        },
        (err) => console.warn('Team invites sync notice:', err)
      );

      return () => unsubscribe();
    }
  }, [selectedTeam?.id]);

  // Check user permissions on selected team
  const isTeamLeader = Boolean(user && selectedTeam && (selectedTeam.leaderId === user.uid || isOwner));
  const isTeamManager = Boolean(
    user && selectedTeam && (isTeamLeader || selectedTeam.members?.some((m) => m.uid === user.uid && m.role === 'manager'))
  );
  const isTeamMember = Boolean(
    user && selectedTeam && (isTeamManager || selectedTeam.members?.some((m) => m.uid === user.uid))
  );

  // Logo & Banner File Handlers for Creation
  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setLogoFile(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };

  const handleBannerSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setBannerFile(file);
      setBannerPreview(URL.createObjectURL(file));
    }
  };

  // Logo & Banner File Handlers for Edit
  const handleEditLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setEditLogoFile(file);
      setEditLogoPreview(URL.createObjectURL(file));
    }
  };

  const handleEditBannerSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setEditBannerFile(file);
      setEditBannerPreview(URL.createObjectURL(file));
    }
  };

  // CREATE TEAM
  const handleCreateTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');
    if (!user) {
      setCreateError('يرجى تسجيل الدخول أولاً لتتمكن من إنشاء فريق');
      return;
    }
    if (!teamName.trim()) {
      setCreateError('يرجى كتابة اسم الفريق');
      return;
    }

    setIsCreatingTeam(true);
    setCreateProgressText('جاري معالجة الشعار والغلاف...');

    try {
      let finalLogoUrl = logoPreview;
      let finalBannerUrl = bannerPreview;

      // 1. Upload Team Logo to permanent storage
      if (logoFile) {
        setCreateProgressText('جاري ضغط ورفع شعار الفريق...');
        const optimizedLogo = await hartHost.optimizeImage(logoFile, 400, 0.85);
        finalLogoUrl = await hartHost.uploadMedia(optimizedLogo, 'teams', `${teamName}_logo`);
      } else if (!finalLogoUrl) {
        finalLogoUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(teamName)}&background=7c3aed&color=fff&size=256`;
      }

      // 2. Upload Team Banner to permanent storage
      if (bannerFile) {
        setCreateProgressText('جاري ضغط ورفع غلاف الفريق...');
        const optimizedBanner = await hartHost.optimizeImage(bannerFile, 1200, 0.85);
        finalBannerUrl = await hartHost.uploadMedia(optimizedBanner, 'teams', `${teamName}_banner`);
      }

      setCreateProgressText('جاري إنشاء وتثبيت سجل الفريق في قاعدة البيانات...');

      const leaderMember: TeamMember = {
        uid: user.uid,
        uniqueId: profile?.uniqueId,
        email: user.email || '',
        displayName: profile?.displayName || user.displayName || 'قائد الفريق',
        photoUrl: profile?.photoUrl || user.photoURL || '',
        role: 'leader',
        joinedAt: new Date().toISOString()
      };

      const teamPayload: Omit<Team, 'id'> = {
        name: teamName.trim(),
        description: teamDesc.trim(),
        logoUrl: finalLogoUrl,
        bannerUrl: finalBannerUrl || '',
        leaderId: user.uid,
        leaderName: profile?.displayName || user.displayName || 'قائد الفريق',
        discordUrl: teamDiscord.trim(),
        telegramUrl: teamTelegram.trim(),
        websiteUrl: teamWebsite.trim(),
        members: [leaderMember],
        worksCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // 3. Save to Firestore
      const docRef = await addDoc(collection(db, 'teams'), teamPayload);
      const newTeam: Team = { id: docRef.id, ...teamPayload };

      // 4. Update Leader's User Profile
      await updateUserProfile({
        role: isOwner ? 'owner' : 'team_leader',
        teamId: docRef.id
      });

      // 5. Open newly created team immediately
      setShowCreateModal(false);
      setTeamName('');
      setTeamDesc('');
      setTeamDiscord('');
      setTeamTelegram('');
      setTeamWebsite('');
      setLogoFile(null);
      setLogoPreview('');
      setBannerFile(null);
      setBannerPreview('');
      setSelectedTeam(newTeam);
      setActiveTab('works');
    } catch (err: any) {
      console.error('Create team error:', err);
      setCreateError(err.message || 'فشل إنشاء الفريق، يرجى التحقق من الاتصال');
    } finally {
      setIsCreatingTeam(false);
      setCreateProgressText('');
    }
  };

  // SAVE TEAM SETTINGS
  const handleSaveTeamSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeam || !user) return;
    setSettingsError('');
    setSettingsSuccess(false);
    setIsSavingSettings(true);

    try {
      let finalLogo = selectedTeam.logoUrl;
      let finalBanner = selectedTeam.bannerUrl;

      if (editLogoFile) {
        const optimizedLogo = await hartHost.optimizeImage(editLogoFile, 400, 0.85);
        finalLogo = await hartHost.uploadMedia(optimizedLogo, 'teams', `${editName}_logo`);
      }

      if (editBannerFile) {
        const optimizedBanner = await hartHost.optimizeImage(editBannerFile, 1200, 0.85);
        finalBanner = await hartHost.uploadMedia(optimizedBanner, 'teams', `${editName}_banner`);
      }

      const updates: Partial<Team> = {
        name: editName.trim(),
        description: editDesc.trim(),
        logoUrl: finalLogo,
        bannerUrl: finalBanner || '',
        discordUrl: editDiscord.trim(),
        telegramUrl: editTelegram.trim(),
        websiteUrl: editWebsite.trim()
      };

      await hartTeamService.updateTeamSettings(selectedTeam.id, updates);

      setSelectedTeam({ ...selectedTeam, ...updates });
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 3000);
    } catch (err: any) {
      console.error('Save team settings error:', err);
      setSettingsError(err.message || 'فشل حفظ الإعدادات');
    } finally {
      setIsSavingSettings(false);
    }
  };

  // SEARCH USER BY UNIQUE ID / EMAIL / TAG
  const handleSearchUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    setInviteSuccessMsg('');
    setFoundUser(null);

    if (!searchQuery.trim()) {
      setSearchError('يرجى كتابة معرّف الحساب الفريد أو البريد الإلكتروني أو اسم المستخدم.');
      return;
    }

    setIsSearchingUser(true);
    try {
      const result = await hartTeamService.searchUser(searchQuery.trim());
      if (!result) {
        setSearchError('لم يتم العثور على أي مستخدم مطابق لهذا المعرّف أو البريد.');
      } else {
        // Check if already in team
        const alreadyIn = selectedTeam?.members.some((m) => m.uid === result.uid);
        if (alreadyIn) {
          setSearchError(`المستخدم "${result.displayName}" موجود بالفعل ضمن طاقم الفريق.`);
        }
        setFoundUser(result);
      }
    } catch (err: any) {
      console.error('Search user error:', err);
      setSearchError(err.message || 'خطأ أثناء البحث');
    } finally {
      setIsSearchingUser(false);
    }
  };

  // SEND INVITATION
  const handleSendInvite = async () => {
    if (!selectedTeam || !user || !profile || !foundUser) return;
    setIsSendingInvite(true);
    setSearchError('');
    setInviteSuccessMsg('');

    try {
      await hartTeamService.sendTeamInvitation({
        team: selectedTeam,
        sender: profile,
        targetUser: foundUser,
        role: inviteRole
      });

      setInviteSuccessMsg(`تم إرسال دعوة رسمية بنجاح إلى "${foundUser.displayName}" بدور ${TEAM_ROLE_LABELS[inviteRole]}.`);
      setFoundUser(null);
      setSearchQuery('');
    } catch (err: any) {
      console.error('Send invite error:', err);
      setSearchError(err.message || 'فشل إرسال الدعوة');
    } finally {
      setIsSendingInvite(false);
    }
  };

  // CANCEL PENDING INVITATION
  const handleCancelInvite = async (invId: string) => {
    try {
      await hartTeamService.cancelInvitation(invId);
    } catch (err: any) {
      console.error('Cancel invite error:', err);
      alert(err.message || 'فشل إلغاء الدعوة');
    }
  };

  // CHANGE MEMBER ROLE
  const handleUpdateMemberRole = async (targetUid: string, newRole: TeamMemberRole) => {
    if (!selectedTeam || !user) return;
    setMemberActionError('');
    setMemberActionSuccess('');

    try {
      const updated = await hartTeamService.updateMemberRole({
        team: selectedTeam,
        targetUid,
        newRole,
        currentUid: user.uid,
        isPlatformOwner: isOwner
      });

      setSelectedTeam({ ...selectedTeam, members: updated });
      setMemberActionSuccess('تم تحديث دور العضو بنجاح!');
      setTimeout(() => setMemberActionSuccess(''), 2500);
    } catch (err: any) {
      console.error('Update member role error:', err);
      setMemberActionError(err.message || 'فشل تحديث الدور');
    }
  };

  // REMOVE MEMBER
  const handleRemoveMember = async (targetUid: string, targetName: string) => {
    if (!selectedTeam || !user) return;
    if (!window.confirm(`هل أنت متأكد من إزالة العضو "${targetName}" من الفريق؟`)) return;

    setMemberActionError('');
    setMemberActionSuccess('');

    try {
      const updated = await hartTeamService.removeMember({
        team: selectedTeam,
        targetUid,
        currentUid: user.uid,
        isPlatformOwner: isOwner
      });

      setSelectedTeam({ ...selectedTeam, members: updated });
      setMemberActionSuccess(`تمت إزالة العضو "${targetName}" بنجاح.`);
      setTimeout(() => setMemberActionSuccess(''), 2500);
    } catch (err: any) {
      console.error('Remove member error:', err);
      setMemberActionError(err.message || 'فشل إزالة العضو');
    }
  };

  // TRANSFER OWNERSHIP
  const handleTransferOwnership = async (newLeader: TeamMember) => {
    if (!selectedTeam || !user) return;
    if (!window.confirm(`تحذير هام: هل أنت متأكد تماماً من نقل ملكية وقيادة الفريق إلى "${newLeader.displayName}"؟ ستصبح مديراً في الفريق ولن يمكنك التراجع إلا بطلب منه.`)) return;

    setMemberActionError('');
    setMemberActionSuccess('');

    try {
      await hartTeamService.transferOwnership({
        team: selectedTeam,
        newLeaderUid: newLeader.uid,
        currentUid: user.uid,
        isPlatformOwner: isOwner
      });

      setMemberActionSuccess(`تم نقل ملكية الفريق بنجاح إلى "${newLeader.displayName}".`);
      setTimeout(() => setMemberActionSuccess(''), 3000);
    } catch (err: any) {
      console.error('Transfer ownership error:', err);
      setMemberActionError(err.message || 'فشل نقل الملكية');
    }
  };

  // DELETE TEAM
  const handleDeleteTeam = async (teamId: string) => {
    if (!window.confirm('تحذير خطير: هل أنت متأكد من حذف هذا الفريق نهائياً؟ هذا الإجراء لا يمكن التراجع عنه.')) return;
    try {
      await deleteDoc(doc(db, 'teams', teamId));
      setSelectedTeam(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `teams/${teamId}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      
      {/* Pending Invitations Banner (If any) */}
      {user && pendingInvitationsCount > 0 && (
        <div className="mb-6 p-4 rounded-3xl bg-gradient-to-r from-purple-900/60 via-indigo-900/40 to-pink-900/40 border border-purple-500/40 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600/30 border border-purple-400/40 flex items-center justify-center text-purple-300 shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">
                لديك {pendingInvitationsCount} دعوة انضمام رسمية معلقة!
              </h4>
              <p className="text-xs text-purple-200">
                أرسل لك قادة فرق الترجمة دعوات للانضمام إلى طواقمهم بالمعرّف الفريد الخاص بك.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenInvitations}
            className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-purple-900/40 transition-transform active:scale-95 shrink-0"
          >
            <Mail className="w-4 h-4" />
            <span>عرض الدعوات الآن</span>
          </button>
        </div>
      )}

      {/* Top Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 bg-[#101627] p-6 rounded-3xl border border-white/5 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-6 h-6 text-purple-400" />
            <h1 className="text-2xl font-black text-white">فرق الترجمة والنشر (Hart Teams)</h1>
          </div>
          <p className="text-xs text-gray-400">
            تصفح فرق الترجمة الرسمية أو أنشئ فريقك الخاص وأدر أعضاءك بالمعرّف الفريد لنشر المانهوا والمانجا والروايات.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-purple-900/40 transition-transform hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>إنشاء فريق ترجمة جديد</span>
            </button>
          ) : (
            <button
              onClick={signInWithGoogle}
              className="px-5 py-2.5 bg-[#171f33] hover:bg-[#202b46] border border-white/10 text-white text-xs font-bold rounded-xl"
            >
              تسجيل الدخول لإنشاء فريق
            </button>
          )}
        </div>
      </div>

      {/* Teams Grid */}
      {teams.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teams.map((team) => {
            const teamWorks = manhwas.filter((m) => m.teamId === team.id);
            const isUserLeader = user && (team.leaderId === user.uid || isOwner);
            const isUserInTeam = user && team.members?.some((m) => m.uid === user.uid);

            return (
              <div
                key={team.id}
                onClick={() => {
                  setSelectedTeam(team);
                  setActiveTab('works');
                }}
                className="bg-[#101627] hover:bg-[#141b2f] border border-white/5 hover:border-purple-500/40 rounded-3xl p-6 shadow-xl transition-all cursor-pointer flex flex-col justify-between group overflow-hidden relative"
              >
                {team.bannerUrl && (
                  <div className="absolute top-0 inset-x-0 h-16 opacity-30 overflow-hidden pointer-events-none">
                    <SmartImage src={team.bannerUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#101627]"></div>
                  </div>
                )}

                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <SmartImage
                      src={team.logoUrl}
                      alt={team.name}
                      fallbackText={team.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      containerClassName="w-16 h-16 rounded-2xl border-2 border-purple-500/30 shadow-lg shrink-0 bg-[#151b2d]"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-base text-white truncate group-hover:text-purple-300">
                          {team.name}
                        </h3>
                        {isUserLeader && (
                          <span title="أنت قائد هذا الفريق">
                            <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                          </span>
                        )}
                        {!isUserLeader && isUserInTeam && (
                          <span title="أنت عضو في هذا الفريق">
                            <Shield className="w-4 h-4 text-purple-400 shrink-0" />
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400 flex items-center gap-1.5 mt-0.5">
                        <Shield className="w-3.5 h-3.5 text-purple-400" />
                        <span>القائد: <strong className="text-gray-300">{team.leaderName}</strong></span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed mb-4">
                    {team.description || 'فريق ترجمة شغوف بتقديم أفضل الأعمال بجودة عالية.'}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs relative z-10">
                  <div className="flex items-center gap-3 text-gray-400">
                    <span className="font-semibold text-purple-300">{team.members?.length || 1} أعضاء</span>
                    <span>•</span>
                    <span>{teamWorks.length} أعمال منشورة</span>
                  </div>

                  <span className="text-[11px] font-bold text-purple-400 group-hover:translate-x-[-4px] transition-transform">
                    {isUserLeader || isUserInTeam ? 'إدارة وتصفح الفريق ←' : 'عرض الفريق ←'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-20 text-center max-w-md mx-auto bg-[#101627] rounded-3xl border border-white/5 p-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-900/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Users className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">لا توجد فرق ترجمة مسجلة بعد</h3>
          <p className="text-xs text-gray-400 mb-6 leading-relaxed">
            كن أول من ينشئ فريق ترجمة واجمع أصدقائك من مترجمين ومحررين ومدققين لنشر أعمالكم معاً!
          </p>
          {user && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-900/40"
            >
              إنشاء أول فريق الآن
            </button>
          )}
        </div>
      )}

      {/* CREATE TEAM MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto no-scrollbar p-6 sm:p-8 shadow-2xl relative">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-6">إنشاء فريق ترجمة ونشر جديد</h2>

            {createError && (
              <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{createError}</span>
              </div>
            )}

            <form onSubmit={handleCreateTeam} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">اسم الفريق *</label>
                <input
                  type="text"
                  required
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="مثال: فريق الفرسان الذهبيين"
                  className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                />
              </div>

              {/* Logo Upload */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">شعار الفريق (Logo)</label>
                <div className="flex items-center gap-4">
                  {logoPreview ? (
                    <img src={logoPreview} alt="Logo" className="w-16 h-16 rounded-2xl object-cover border border-purple-500/40 shrink-0" />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-xs shrink-0">
                      شعار
                    </div>
                  )}
                  <div>
                    <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-purple-300 cursor-pointer transition-colors">
                      <Upload className="w-4 h-4" />
                      <span>اختر الشعار من جهازك</span>
                      <input type="file" accept="image/*" onChange={handleLogoSelect} className="hidden" />
                    </label>
                    <p className="text-[10px] text-gray-500 mt-1">يتم ضغطه وحفظه بشكل دائم لجميع المستخدمين</p>
                  </div>
                </div>
              </div>

              {/* Banner Upload */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">غلاف الفريق (Banner اختياري)</label>
                <div className="flex items-center gap-4">
                  {bannerPreview ? (
                    <img src={bannerPreview} alt="Banner" className="w-24 h-14 rounded-xl object-cover border border-purple-500/40 shrink-0" />
                  ) : (
                    <div className="w-24 h-14 rounded-xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-[10px] shrink-0">
                      غلاف
                    </div>
                  )}
                  <div>
                    <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-pink-300 cursor-pointer transition-colors">
                      <Upload className="w-4 h-4" />
                      <span>اختر الغلاف العريض</span>
                      <input type="file" accept="image/*" onChange={handleBannerSelect} className="hidden" />
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">نبذة عن الفريق</label>
                <textarea
                  rows={3}
                  value={teamDesc}
                  onChange={(e) => setTeamDesc(e.target.value)}
                  placeholder="اكتب نبذة عن فريقكم وأعمالكم..."
                  className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                />
              </div>

              {/* Social Links */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">ديسكورد</label>
                  <input
                    type="text"
                    value={teamDiscord}
                    onChange={(e) => setTeamDiscord(e.target.value)}
                    placeholder="discord.gg/..."
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">تليجرام</label>
                  <input
                    type="text"
                    value={teamTelegram}
                    onChange={(e) => setTeamTelegram(e.target.value)}
                    placeholder="t.me/..."
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">الموقع الإلكتروني</label>
                  <input
                    type="text"
                    value={teamWebsite}
                    onChange={(e) => setTeamWebsite(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                  />
                </div>
              </div>

              {createProgressText && (
                <div className="p-3 bg-purple-950/50 border border-purple-800/40 rounded-xl text-xs text-purple-300 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping"></span>
                  <span>{createProgressText}</span>
                </div>
              )}

              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-gray-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isCreatingTeam}
                  className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-900/40"
                >
                  {isCreatingTeam ? 'جاري الحفظ الفعلي...' : 'إنشاء الفريق وتثبيته الآن'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TEAM DETAILS & FULL MANAGEMENT MODAL */}
      {selectedTeam && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl relative p-6 sm:p-8 flex flex-col">
            <button
              onClick={() => setSelectedTeam(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white z-20"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Team Banner / Header */}
            {selectedTeam.bannerUrl && (
              <div className="w-full h-36 rounded-2xl overflow-hidden mb-6 border border-white/5 shrink-0">
                <SmartImage src={selectedTeam.bannerUrl} alt="Team Banner" className="w-full h-full object-cover" showFallbackText={false} />
              </div>
            )}

            {/* Team Main Info Header */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 pb-6 border-b border-white/5 mb-6">
              <SmartImage
                src={selectedTeam.logoUrl}
                alt={selectedTeam.name}
                fallbackText={selectedTeam.name}
                className="w-full h-full object-cover"
                containerClassName="w-20 h-20 rounded-2xl border-2 border-purple-500/40 shadow-xl shrink-0 bg-[#151b2d]"
              />

              <div className="flex-1 text-center sm:text-right">
                <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                  <h2 className="text-2xl font-black text-white">{selectedTeam.name}</h2>
                  {isTeamLeader && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                      <Crown className="w-3 h-3" />
                      <span>أنت قائد الفريق</span>
                    </span>
                  )}
                  {!isTeamLeader && isTeamManager && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      <span>أنت مدير الفريق</span>
                    </span>
                  )}
                </div>

                <div className="text-xs text-gray-400 flex flex-wrap items-center gap-3 justify-center sm:justify-start my-2">
                  <span>القائد: <strong className="text-purple-300">{selectedTeam.leaderName}</strong></span>
                  <span>•</span>
                  <span>{selectedTeam.members?.length || 1} أعضاء</span>
                  <span>•</span>
                  <span>{manhwas.filter((m) => m.teamId === selectedTeam.id).length} أعمال</span>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed mb-4 max-w-2xl">
                  {selectedTeam.description || 'فريق ترجمة شغوف بتقديم أفضل الأعمال بجودة عالية.'}
                </p>

                {/* Social Badges & Actions */}
                <div className="flex flex-wrap items-center gap-3 justify-center sm:justify-start">
                  <button
                    onClick={() => {
                      onOpenPublisherForTeam(selectedTeam);
                      setSelectedTeam(null);
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-violet-600 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40 hover:scale-105 transition-transform"
                  >
                    <Plus className="w-4 h-4" />
                    <span>نشر عمل أو فصل لهذا الفريق</span>
                  </button>

                  {selectedTeam.discordUrl && (
                    <a
                      href={selectedTeam.discordUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 text-xs font-bold text-purple-300 rounded-xl"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>ديسكورد</span>
                    </a>
                  )}

                  {selectedTeam.telegramUrl && (
                    <a
                      href={selectedTeam.telegramUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 text-xs font-bold text-sky-300 rounded-xl"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>تليجرام</span>
                    </a>
                  )}

                  {selectedTeam.websiteUrl && (
                    <a
                      href={selectedTeam.websiteUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 text-xs font-bold text-pink-300 rounded-xl"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      <span>الموقع الرسمي</span>
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* TAB NAVIGATION */}
            <div className="flex items-center gap-2 border-b border-white/5 pb-3 mb-6 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setActiveTab('works')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'works'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                    : 'text-gray-400 hover:text-white bg-white/5'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>أعمال الفريق ({manhwas.filter((m) => m.teamId === selectedTeam.id).length})</span>
              </button>

              <button
                onClick={() => setActiveTab('members')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'members'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                    : 'text-gray-400 hover:text-white bg-white/5'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>طاقم العمل والأدوار ({selectedTeam.members?.length || 1})</span>
              </button>

              {isTeamManager && (
                <button
                  onClick={() => setActiveTab('invite')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                    activeTab === 'invite'
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-900/40'
                      : 'text-purple-300 hover:text-white bg-purple-950/40 border border-purple-500/30'
                  }`}
                >
                  <UserPlus className="w-4 h-4" />
                  <span>دعوة أعضاء بالمعرّف الفريد</span>
                  {teamPendingInvites.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {teamPendingInvites.length}
                    </span>
                  )}
                </button>
              )}

              {isTeamManager && (
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                    activeTab === 'settings'
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                      : 'text-gray-400 hover:text-white bg-white/5'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>إعدادات الفريق</span>
                </button>
              )}
            </div>

            {/* TAB CONTENT */}

            {/* TAB 1: WORKS */}
            {activeTab === 'works' && (
              <div>
                {manhwas.filter((m) => m.teamId === selectedTeam.id).length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {manhwas
                      .filter((m) => m.teamId === selectedTeam.id)
                      .map((m) => (
                        <div
                          key={m.id}
                          onClick={() => {
                            onSelectManhwa(m);
                            setSelectedTeam(null);
                          }}
                          className="p-3 bg-[#151b2d] hover:bg-[#1d2640] rounded-2xl border border-white/5 cursor-pointer transition-all flex flex-col group"
                        >
                          <SmartImage
                            src={m.coverUrl}
                            alt={m.title}
                            fallbackText={m.title}
                            className="w-full h-full object-cover rounded-xl mb-2.5 group-hover:scale-105 transition-transform"
                            aspectRatio="aspect-[3/4]"
                            containerClassName="w-full rounded-xl mb-2.5 overflow-hidden"
                          />
                          <span className="text-xs font-bold text-white truncate w-full group-hover:text-purple-300">
                            {m.title}
                          </span>
                          <div className="flex items-center justify-between text-[10px] text-gray-400 mt-1">
                            <span>{m.status === 'completed' ? 'مكتملة' : 'مستمرة'}</span>
                            <span className="text-purple-300 font-semibold">{m.views || 0} قراءة</span>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="p-8 bg-[#151b2d] rounded-2xl text-center">
                    <BookOpen className="w-10 h-10 text-gray-500 mx-auto mb-2" />
                    <p className="text-xs text-gray-300 font-bold mb-1">لم يتم نشر أي عمل تحت اسم هذا الفريق بعد</p>
                    <p className="text-[11px] text-gray-500 mb-4">
                      استخدم زر النشر المتاح لإضافة أول عمل وربطه بفريقكم مباشرة!
                    </p>
                    <button
                      onClick={() => {
                        onOpenPublisherForTeam(selectedTeam);
                        setSelectedTeam(null);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-purple-600 to-violet-600 text-white rounded-xl text-xs font-bold"
                    >
                      إضافة أول مانهوا أو مانجا الآن
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: MEMBERS & ROLES */}
            {activeTab === 'members' && (
              <div className="space-y-4">
                {memberActionSuccess && (
                  <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>{memberActionSuccess}</span>
                  </div>
                )}

                {memberActionError && (
                  <div className="p-3 rounded-2xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <span>{memberActionError}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedTeam.members?.map((member) => {
                    const isMemberLeader = member.uid === selectedTeam.leaderId;
                    const canEditThisMember = isTeamManager && !isMemberLeader;

                    return (
                      <div
                        key={member.uid}
                        className="p-3.5 bg-[#151b2d] rounded-2xl border border-white/5 flex flex-col justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl overflow-hidden border border-purple-500/30 bg-[#0d121f] shrink-0 flex items-center justify-center">
                            {member.photoUrl ? (
                              <SmartImage src={member.photoUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
                            ) : (
                              <span className="font-bold text-sm text-purple-300">
                                {member.displayName[0]?.toUpperCase()}
                              </span>
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold text-white truncate">{member.displayName}</h4>
                              {isMemberLeader && (
                                <span title="قائد ومالك الفريق">
                                  <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                              {member.uniqueId && (
                                <span className="font-mono text-purple-300 dir-ltr">{member.uniqueId}</span>
                              )}
                              <span>•</span>
                              <span>انضم {new Date(member.joinedAt).toLocaleDateString('ar-EG')}</span>
                            </div>
                          </div>
                        </div>

                        {/* Role selection & management controls */}
                        <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
                          {canEditThisMember ? (
                            <div className="flex items-center gap-2 flex-1">
                              <label className="text-[10px] text-gray-400 shrink-0">الدور:</label>
                              <select
                                value={member.role}
                                onChange={(e) => handleUpdateMemberRole(member.uid, e.target.value as TeamMemberRole)}
                                className="bg-[#101627] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-purple-300 outline-none flex-1"
                              >
                                <option value="manager">مدير الفريق (Manager)</option>
                                <option value="editor">محرر أعمال (Editor)</option>
                                <option value="translator">مترجم (Translator)</option>
                                <option value="typesetter">محرر نصوص (Typesetter)</option>
                                <option value="cleaner">مبيّض (Cleaner)</option>
                                <option value="proofreader">مدقق لغوي (Proofreader)</option>
                                <option value="member">عضو عادي (Member)</option>
                              </select>
                            </div>
                          ) : (
                            <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800/40">
                              {TEAM_ROLE_LABELS[member.role] || member.role}
                            </span>
                          )}

                          {/* Leader Actions on member: Transfer Ownership or Remove */}
                          {isTeamLeader && !isMemberLeader && (
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleTransferOwnership(member)}
                                className="p-1.5 text-amber-400 hover:text-amber-300 hover:bg-amber-950/40 rounded-lg transition-colors"
                                title="نقل ملكية الفريق إلى هذا العضو"
                              >
                                <ArrowRightLeft className="w-3.5 h-3.5" />
                              </button>

                              <button
                                type="button"
                                onClick={() => handleRemoveMember(member.uid, member.displayName)}
                                className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-950/40 rounded-lg transition-colors"
                                title="إزالة العضو من الفريق"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 3: INVITE BY UNIQUE ID (CRITICAL REQUIREMENT 1 & 2) */}
            {activeTab === 'invite' && isTeamManager && (
              <div className="space-y-6">
                
                {/* Search & Invite Box */}
                <div className="p-5 bg-[#151b2d] rounded-2xl border border-purple-500/30">
                  <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                    <UserPlus className="w-4 h-4 text-purple-400" />
                    <span>البحث عن مستخدم وإرسال دعوة انضمام رسمية</span>
                  </h3>
                  <p className="text-xs text-gray-400 mb-4 leading-relaxed">
                    اطلب من المترجم أو المحرر معرّفه الفريد المكتوب في ملفه الشخصي (مثل <span className="font-mono text-purple-300">MH-849201</span>) أو بريده الإلكتروني للبحث عنه ودعوته فوراً.
                  </p>

                  <form onSubmit={handleSearchUser} className="flex gap-2 mb-4">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="أدخل معرّف المستخدم (MH-XXXXXX) أو البريد الإلكتروني أو @اسم_المستخدم"
                        className="w-full bg-[#101627] border border-white/10 rounded-xl pr-9 pl-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSearchingUser}
                      className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all"
                    >
                      {isSearchingUser ? 'جاري البحث...' : 'بحث'}
                    </button>
                  </form>

                  {/* Search Error */}
                  {searchError && (
                    <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                      <span>{searchError}</span>
                    </div>
                  )}

                  {/* Invite Success */}
                  {inviteSuccessMsg && (
                    <div className="p-3 mb-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{inviteSuccessMsg}</span>
                    </div>
                  )}

                  {/* Found User Result Card */}
                  {foundUser && (
                    <div className="p-4 bg-[#101627] rounded-xl border border-purple-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl overflow-hidden border border-purple-500/40 bg-[#0d121f] shrink-0 flex items-center justify-center">
                          {foundUser.photoUrl ? (
                            <SmartImage src={foundUser.photoUrl} alt="" className="w-full h-full object-cover" showFallbackText={false} />
                          ) : (
                            <span className="font-bold text-base text-purple-300">
                              {foundUser.displayName[0]?.toUpperCase()}
                            </span>
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-white">{foundUser.displayName}</h4>
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-950 text-purple-300 border border-purple-800/50">
                              {foundUser.uniqueId}
                            </span>
                          </div>
                          <span className="text-[11px] text-gray-400 dir-ltr text-right block mt-0.5">
                            {foundUser.email}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 w-full sm:w-auto">
                        <select
                          value={inviteRole}
                          onChange={(e) => setInviteRole(e.target.value as TeamMemberRole)}
                          className="bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                        >
                          <option value="translator">مترجم (Translator)</option>
                          <option value="editor">محرر أعمال (Editor)</option>
                          <option value="typesetter">محرر نصوص (Typesetter)</option>
                          <option value="cleaner">مبيّض (Cleaner)</option>
                          <option value="proofreader">مدقق لغوي (Proofreader)</option>
                          <option value="manager">مدير الفريق (Manager)</option>
                          <option value="member">عضو (Member)</option>
                        </select>

                        <button
                          type="button"
                          disabled={isSendingInvite}
                          onClick={handleSendInvite}
                          className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40 transition-all disabled:opacity-50 shrink-0"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{isSendingInvite ? 'جاري الإرسال...' : 'إرسال الدعوة'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                </div>

                {/* Team's Pending Sent Invitations */}
                <div>
                  <h4 className="text-xs font-bold text-gray-300 mb-3 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-purple-400" />
                    <span>الدعوات المرسلة المعلقة ({teamPendingInvites.length})</span>
                  </h4>

                  {teamPendingInvites.length > 0 ? (
                    <div className="space-y-2">
                      {teamPendingInvites.map((inv) => (
                        <div
                          key={inv.id}
                          className="p-3 bg-[#151b2d] rounded-xl border border-white/5 flex items-center justify-between text-xs"
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-purple-300 font-bold">{inv.receiverUniqueId}</span>
                            <span className="font-bold text-white">{inv.receiverName}</span>
                            <span className="px-2 py-0.5 rounded text-[10px] bg-purple-950 text-purple-300 border border-purple-800/40">
                              {TEAM_ROLE_LABELS[inv.role] || inv.role}
                            </span>
                            <span className="text-[10px] text-gray-500">
                              أُرسلت: {new Date(inv.createdAt).toLocaleDateString('ar-EG')}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleCancelInvite(inv.id)}
                            className="text-xs text-red-400 hover:text-red-300 font-bold px-3 py-1 rounded-lg bg-red-950/30 hover:bg-red-950/60 transition-colors"
                          >
                            إلغاء الدعوة
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 bg-[#151b2d] rounded-xl text-center text-xs text-gray-500">
                      لا توجد دعوات معلقة مرسلة من هذا الفريق حالياً.
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* TAB 4: SETTINGS & BRANDING */}
            {activeTab === 'settings' && isTeamManager && (
              <form onSubmit={handleSaveTeamSettings} className="space-y-4">
                {settingsSuccess && (
                  <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>تم حفظ وتحديث إعدادات الفريق بنجاح!</span>
                  </div>
                )}

                {settingsError && (
                  <div className="p-3 rounded-2xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <span>{settingsError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">اسم الفريق *</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                  />
                </div>

                {/* Edit Logo */}
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">شعار الفريق (Logo)</label>
                  <div className="flex items-center gap-4">
                    {editLogoPreview ? (
                      <img src={editLogoPreview} alt="Logo" className="w-16 h-16 rounded-2xl object-cover border border-purple-500/40 shrink-0" />
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-xs shrink-0">
                        شعار
                      </div>
                    )}
                    <div>
                      <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-purple-300 cursor-pointer transition-colors">
                        <Upload className="w-4 h-4" />
                        <span>تغيير الشعار</span>
                        <input type="file" accept="image/*" onChange={handleEditLogoSelect} className="hidden" />
                      </label>
                      <p className="text-[10px] text-gray-500 mt-1">يتم رفعه عبر نظام Hart Host الدائم</p>
                    </div>
                  </div>
                </div>

                {/* Edit Banner */}
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">غلاف الفريق (Banner)</label>
                  <div className="flex items-center gap-4">
                    {editBannerPreview ? (
                      <img src={editBannerPreview} alt="Banner" className="w-24 h-14 rounded-xl object-cover border border-purple-500/40 shrink-0" />
                    ) : (
                      <div className="w-24 h-14 rounded-xl bg-[#151b2d] border border-dashed border-white/20 flex items-center justify-center text-gray-500 text-[10px] shrink-0">
                        غلاف
                      </div>
                    )}
                    <div>
                      <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-pink-300 cursor-pointer transition-colors">
                        <Upload className="w-4 h-4" />
                        <span>تغيير الغلاف العريض</span>
                        <input type="file" accept="image/*" onChange={handleEditBannerSelect} className="hidden" />
                      </label>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">الوصف والنبذة</label>
                  <textarea
                    rows={3}
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">ديسكورد</label>
                    <input
                      type="text"
                      value={editDiscord}
                      onChange={(e) => setEditDiscord(e.target.value)}
                      placeholder="https://discord.gg/..."
                      className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">تليجرام</label>
                    <input
                      type="text"
                      value={editTelegram}
                      onChange={(e) => setEditTelegram(e.target.value)}
                      placeholder="https://t.me/..."
                      className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">الموقع الإلكتروني</label>
                    <input
                      type="text"
                      value={editWebsite}
                      onChange={(e) => setEditWebsite(e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none dir-ltr text-right"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  {isTeamLeader ? (
                    <button
                      type="button"
                      onClick={() => handleDeleteTeam(selectedTeam.id)}
                      className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-red-400 hover:text-red-300 bg-red-950/30 hover:bg-red-950/60 rounded-xl border border-red-500/20 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>حذف الفريق نهائياً</span>
                    </button>
                  ) : <div></div>}

                  <button
                    type="submit"
                    disabled={isSavingSettings}
                    className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-900/40"
                  >
                    {isSavingSettings ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
