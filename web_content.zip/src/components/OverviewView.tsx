import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Building2,
  Castle,
  ChevronRight,
  Hammer,
  Loader2,
  RefreshCw,
  Search,
  Shield,
  Swords,
  Wrench,
} from 'lucide-react';
import {
  CATEGORY_LABELS_RU,
  ClanDashboardState,
  PlayerProfile,
  VillageCategory,
  VillageId,
} from '../shared/cocData';
import {
  formatDateTimeRu,
  formatRelativeTimeRu,
  TH_SERIES_COLORS,
} from '../utils/formatters';
import {
  SnapshotSeriesDef,
  SnapshotSeriesPoint,
  SnapshotTimeSeriesChart,
} from './ProgressCharts';
import { AppTab } from './TopBar';
import {
  formatCountdownRu,
  getDataSourceLabel,
  getVillageShortTitle,
  isActualUpgradeEvent,
} from './CocUnitBadge';
import { apiFetchJson } from '../utils/apiClient';
import clanCrestFallback from '../assets/images/clan_shield_crest_1794517401613.jpg';

interface OverviewViewProps {
  state: ClanDashboardState;
  nowMs: number;
  isSyncing: boolean;
  onSyncNow: () => void;
  onOpenJsonImport?: (playerTag?: string) => void;
  onOpenVillage: (village: VillageId) => void;
  onSelectPlayer: (tag: string) => void;
  onSelectThGroup: (th: number) => void;
  onSelectTab: (tab: AppTab) => void;
  onOpenClanConnect: () => void;
  onClanConnected: (nextState: ClanDashboardState) => void;
  onOpenExternalPlayer: (player: PlayerProfile) => void;
}

interface SearchItem {
  tag: string;
  name: string;
  clanLevel: number;
  badgeUrl?: string;
  warLeague: string;
  locationName?: string;
  memberCount: number;
  clanPoints: number;
}

const CLAN_CREST_PATH = clanCrestFallback;

const WAR_STATE_LABELS: Record<string, string> = {
  preparation: 'Подготовка к войне',
  inWar: 'Идёт боевой день',
  warEnded: 'Война завершена',
  notInWar: 'Нет активной войны',
};

export const OverviewView: React.FC<OverviewViewProps> = ({
  state,
  nowMs,
  isSyncing,
  onSyncNow,
  onOpenVillage,
  onSelectPlayer,
  onSelectThGroup,
  onSelectTab,
  onOpenClanConnect,
  onClanConnected,
  onOpenExternalPlayer,
}) => {
  const [chartMetric, setChartMetric] = useState<'trophies' | 'points' | 'donations'>('trophies');
  const [feedFilter, setFeedFilter] = useState<'all' | VillageCategory | 'townhall'>('all');
  const [imgError, setImgError] = useState(false);

  // Inline search state when no clan is connected yet
  const [searchMode, setSearchMode] = useState<'clan' | 'player'>('clan');
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [connectingTag, setConnectingTag] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<SearchItem[]>([]);
  const [foundPlayer, setFoundPlayer] = useState<PlayerProfile | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const snapshotPoints: SnapshotSeriesPoint[] = useMemo(() => {
    return state.snapshots.slice(-30).map((s) => ({
      id: s.id,
      timestamp: s.timestamp,
      values: {
        clanPoints: s.clanPoints,
        clanCapitalPoints: s.clanCapitalPoints,
        totalTrophies: s.totalTrophies,
        totalDonations: s.totalDonations,
        totalDonationsReceived: s.totalDonationsReceived,
      },
    }));
  }, [state.snapshots]);

  const activeSeries: SnapshotSeriesDef[] = useMemo(() => {
    if (chartMetric === 'trophies') {
      return [
        { key: 'totalTrophies', label: 'Сумма трофеев участников', color: '#F59E0B' },
      ];
    }
    if (chartMetric === 'points') {
      return [
        { key: 'clanPoints', label: 'Очки клана', color: '#38BDF8' },
        { key: 'clanCapitalPoints', label: 'Очки столицы', color: '#10B981' },
      ];
    }
    return [
      { key: 'totalDonations', label: 'Отдано войск', color: '#10B981' },
      { key: 'totalDonationsReceived', label: 'Получено войск', color: '#A78BFA' },
    ];
  }, [chartMetric]);

  const upgradeEventsOnly = useMemo(
    () => state.events.filter(isActualUpgradeEvent),
    [state.events]
  );

  const filteredEvents = useMemo(() => {
    if (feedFilter === 'all') return upgradeEventsOnly.slice(0, 15);
    return upgradeEventsOnly.filter((e) => e.category === feedFilter).slice(0, 15);
  }, [upgradeEventsOnly, feedFilter]);

  const handleInlineSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (!q) return;
    setSearchError(null);
    setSearching(true);
    setHasSearched(true);
    setFoundPlayer(null);
    setSearchResults([]);

    try {
      if (searchMode === 'clan') {
        const data = await apiFetchJson<{ items?: SearchItem[] }>(
          `/api/coc/search?query=${encodeURIComponent(q)}`
        );
        setSearchResults(data.items ?? []);
      } else {
        const cleanTag = q.toUpperCase().replace(/\s+/g, '').replace(/^#+/, '');
        const normalized = `#${cleanTag}`;
        if (!/^#[0289CGJLPQRUVY]{3,14}$/.test(normalized)) {
          setSearchError(
            'Введите корректный игровой тег игрока (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2PP).'
          );
          return;
        }
        const data = await apiFetchJson<{ player?: PlayerProfile | null }>(
          `/api/coc/players?tag=${encodeURIComponent(normalized)}`
        );
        setFoundPlayer(data.player ?? null);
      }
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'Ошибка при обращении к серверу');
    } finally {
      setSearching(false);
    }
  };

  const handleInlineConnect = async (tag: string) => {
    setSearchError(null);
    setConnectingTag(tag);
    try {
      const data = await apiFetchJson<{ state?: ClanDashboardState }>('/api/coc/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clanTag: tag }),
        timeoutMs: 35000,
      });
      if (data.state) {
        onClanConnected(data.state);
      }
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'Не удалось загрузить клан');
    } finally {
      setConnectingTag(null);
    }
  };

  if (!state.clan) {
    const trimmed = searchQuery.trim();
    const looksLikeTag = trimmed.startsWith('#') || /^[0289CGJLPQRUVY]{3,12}$/i.test(trimmed);

    return (
      <div className="mx-auto max-w-4xl space-y-6 py-4">
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-6 space-y-5">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
              Подключите клан или найдите игрока Clash of Clans
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Все данные загружаются в реальном времени через серверный прокси к официальному Supercell Clash of Clans API v1.
            </p>
          </div>

          {!state.hasApiToken && (
            <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 leading-relaxed space-y-1">
              <div className="font-semibold text-amber-300">
                Требуется настройка серверного секрета SUPERCELL_API_KEY
              </div>
              <p>
                1. Получите API-ключ в портале <span className="font-mono">developer.clashofclans.com</span> и добавьте IP-адрес сервера в белый список ключа.
              </p>
              <p>
                2. Сохраните ключ в переменную окружения (Secrets) под именем <span className="font-mono font-semibold">SUPERCELL_API_KEY</span> и перезапустите сервер.
              </p>
            </div>
          )}

          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0B0F17] p-1 w-fit">
            <button
              type="button"
              onClick={() => {
                setSearchMode('clan');
                setSearchError(null);
                setHasSearched(false);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                searchMode === 'clan'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Поиск клана (название / #тег)
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchMode('player');
                setSearchError(null);
                setHasSearched(false);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                searchMode === 'player'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Поиск игрока (по #тегу)
            </button>
          </div>

          <form onSubmit={handleInlineSearch} className="flex flex-col gap-2.5 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  searchMode === 'clan'
                    ? 'Название клана (например, QARACHILAR) или тег (#2UPULGJVC)...'
                    : 'Игровой тег (например, #2PP)...'
                }
                className="w-full rounded-md border border-slate-700 bg-[#0B0F17] py-2.5 pl-9 pr-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={searching || !trimmed}
              className="inline-flex items-center justify-center gap-2 rounded-md border border-slate-700 bg-[#0B0F17] px-4 py-2.5 text-xs font-semibold text-slate-100 hover:border-amber-500/60 hover:text-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              {searching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
              <span>{searchMode === 'clan' ? 'Найти клан' : 'Найти игрока'}</span>
            </button>

            {searchMode === 'clan' && looksLikeTag && (
              <button
                type="button"
                disabled={Boolean(connectingTag)}
                onClick={() => handleInlineConnect(trimmed)}
                className="inline-flex items-center justify-center gap-2 rounded-md bg-amber-500 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                {connectingTag === trimmed && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                <span>Подключить по тегу</span>
              </button>
            )}
          </form>

          {searchError && (
            <div className="rounded-md border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs text-rose-300 leading-relaxed">
              {searchError}
            </div>
          )}

          {connectingTag && (
            <div className="flex items-center gap-2.5 rounded-md border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-xs text-amber-300">
              <Loader2 className="h-4 w-4 animate-spin shrink-0" />
              <span>Загружаем клан, участников, войны, CWL, столицу и сохраняем первый снимок...</span>
            </div>
          )}

          <div className="divide-y divide-slate-800/70 rounded-md border border-slate-800 bg-[#0B0F17]">
            {searchMode === 'clan' &&
              searchResults.map((item) => (
                <div
                  key={item.tag}
                  className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-slate-800/30 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-10 w-10 shrink-0 rounded bg-[#121824] border border-slate-800 flex items-center justify-center overflow-hidden">
                      {item.badgeUrl ? (
                        <img
                          src={item.badgeUrl}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <Shield className="h-5 w-5 text-amber-400" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-slate-100">{item.name}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                        <span className="font-mono text-slate-300">{item.tag}</span>
                        <span>·</span>
                        <span>Ур. {item.clanLevel}</span>
                        <span>·</span>
                        <span>{item.memberCount} уч.</span>
                        <span>·</span>
                        <span>{item.clanPoints.toLocaleString('ru-RU')} очк.</span>
                        <span>·</span>
                        <span>{item.warLeague}</span>
                        {item.locationName && (
                          <>
                            <span>·</span>
                            <span>{item.locationName}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={Boolean(connectingTag)}
                    onClick={() => handleInlineConnect(item.tag)}
                    className="rounded-md bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
                  >
                    {connectingTag === item.tag ? 'Загрузка...' : 'Подключить'}
                  </button>
                </div>
              ))}

            {searchMode === 'player' && foundPlayer && (
              <div className="flex items-center justify-between gap-3 px-4 py-3.5">
                <div>
                  <div className="text-sm font-semibold text-slate-100">
                    {foundPlayer.name} · TH{foundPlayer.townHallLevel}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-400 font-mono">
                    {foundPlayer.tag} · {foundPlayer.trophies.toLocaleString('ru-RU')} кубков · {foundPlayer.warStars} звёзд КВ
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenExternalPlayer(foundPlayer)}
                  className="rounded-md bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0"
                >
                  Открыть профиль
                </button>
              </div>
            )}

            {!searching && hasSearched && searchResults.length === 0 && !foundPlayer && !searchError && (
              <div className="py-8 text-center text-xs text-slate-500">
                По вашему запросу ничего не найдено. Проверьте название или точный тег с #.
              </div>
            )}

            {!hasSearched && (
              <div className="py-8 text-center text-xs text-slate-500">
                Введите название или #тег клана (например, QARACHILAR или #2UPULGJVC), чтобы начать работу с реальными данными.
              </div>
            )}
          </div>
        </section>
      </div>
    );
  }

  const crestSrc = state.clan.badgeUrl || CLAN_CREST_PATH;
  const activeWar =
    state.currentWar && state.currentWar.state !== 'notInWar' ? state.currentWar : null;

  return (
    <div className="space-y-6">
      {/* Clan Identity Header */}
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-5 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-slate-700/80 bg-[#121824] flex items-center justify-center">
            {!imgError ? (
              <img
                src={crestSrc}
                alt={`Значок клана ${state.clan.name}`}
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="h-full w-full object-contain p-0.5"
              />
            ) : (
              <Shield className="h-7 w-7 text-amber-400" />
            )}
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
              {state.clan.name}
            </h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-400">
              <span className="font-mono text-amber-400 font-medium">{state.clan.tag}</span>
              <span aria-hidden="true">·</span>
              <span>Уровень клана {state.clan.level}</span>
              <span aria-hidden="true">·</span>
              <span>{state.clan.warLeague}</span>
              {state.clan.locationName && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{state.clan.locationName}</span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-400">
          <span className="font-mono tabular-nums">
            Синхронизация: {formatDateTimeRu(state.clan.lastSyncedAt)} ({formatRelativeTimeRu(state.clan.lastSyncedAt, nowMs)})
          </span>
          <button
            type="button"
            onClick={onSyncNow}
            disabled={isSyncing}
            className="inline-flex items-center gap-1.5 rounded-md bg-amber-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'СИНХРОНИЗАЦИЯ...' : 'СИНХРОНИЗИРОВАТЬ ДАННЫЕ'}</span>
          </button>
          <button
            type="button"
            onClick={onOpenClanConnect}
            className="rounded-md border border-slate-700 bg-[#121824] px-3 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 transition-colors whitespace-nowrap shrink-0"
          >
            Сменить клан
          </button>
        </div>
      </section>

      {/* 3 Big Village Switchers */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <button
          type="button"
          onClick={() => onOpenVillage('home')}
          className="rounded-xl border border-amber-500/35 bg-[#121824] p-5 text-left hover:border-amber-500 transition-all"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-amber-400">
              <Building2 className="h-4 w-4" />
              HOME VILLAGE
            </span>
            <span className="font-mono text-xs text-slate-400">
              {state.clan.clanPoints.toLocaleString('ru-RU')} очк.
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Родная деревня
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
            <span>
              Средняя TH:{' '}
              <strong className="font-mono text-amber-300">
                {state.players.length > 0
                  ? (state.players.reduce((s, p) => s + p.townHallLevel, 0) / state.players.length).toFixed(1)
                  : '—'}
              </strong>
            </span>
            <span className="text-amber-400 font-medium inline-flex items-center gap-1">
              Открыть <ChevronRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onOpenVillage('builderBase')}
          className="rounded-xl border border-sky-500/35 bg-[#121824] p-5 text-left hover:border-sky-500 transition-all"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-sky-400">
              <Wrench className="h-4 w-4" />
              BUILDER BASE
            </span>
            <span className="font-mono text-xs text-slate-400">
              {(state.clan.clanBuilderBasePoints ?? 0).toLocaleString('ru-RU')} очк.
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Деревня строителя
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
            <span>
              Средний BH:{' '}
              <strong className="font-mono text-sky-300">
                {(() => {
                  const bh = state.players.filter((p) => p.builderHallLevel > 0);
                  return bh.length > 0
                    ? (bh.reduce((s, p) => s + p.builderHallLevel, 0) / bh.length).toFixed(1)
                    : '—';
                })()}
              </strong>
            </span>
            <span className="text-sky-400 font-medium inline-flex items-center gap-1">
              Открыть <ChevronRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onOpenVillage('clanCapital')}
          className="rounded-xl border border-emerald-500/35 bg-[#121824] p-5 text-left hover:border-emerald-500 transition-all"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-2 font-display text-xs font-extrabold tracking-wider text-emerald-400">
              <Castle className="h-4 w-4" />
              CLAN CAPITAL
            </span>
            <span className="font-mono text-xs text-slate-400">
              CH {state.clan.capitalHallLevel ?? '—'} · {state.clan.clanCapitalPoints.toLocaleString('ru-RU')} очк.
            </span>
          </div>
          <div className="mt-1.5 font-display text-lg font-bold text-slate-100">
            Столица клана
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
            <span>
              Районов:{' '}
              <strong className="font-mono text-emerald-300">
                {state.clan.capitalDistricts?.length ?? 0}
              </strong>
            </span>
            <span className="text-emerald-400 font-medium inline-flex items-center gap-1">
              Открыть <ChevronRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </button>
      </section>

      {/* Live Active Upgrades Summary ("Сейчас улучшается") */}
      {(() => {
        const inProgress = (state.activeUpgrades ?? []).filter((a) => a.status === 'in_progress');
        return (
          <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Hammer className="h-4 w-4 text-amber-400" />
                <h2 className="font-display text-base font-semibold text-slate-100">
                  Сейчас улучшается {inProgress.length > 0 ? `(${inProgress.length})` : ''}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onSelectTab('active_upgrades')}
                className="inline-flex items-center gap-1 text-xs font-medium text-amber-400 hover:text-amber-300"
              >
                Открыть мониторинг
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {inProgress.length === 0 ? (
              <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 leading-relaxed">
                <span>
                  Информация о текущем строительстве зданий и активных таймерах недоступна через официальный Supercell API. Автоматическое отслеживание новых уровней Ратуши, Дома строителя, героев, оборудования, войск, заклинаний и питомцев выполняется при каждой синхронизации.
                </span>
                <button
                  type="button"
                  onClick={() => onSelectTab('upgrade_history')}
                  className="text-xs font-medium text-amber-400 hover:text-amber-300 whitespace-nowrap"
                >
                  История улучшений →
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
                {inProgress.slice(0, 6).map((item) => {
                  const cd = formatCountdownRu(item.estimatedFinishesAt, nowMs);
                  return (
                    <div
                      key={item.id}
                      className="rounded-md border border-amber-500/35 bg-[#0B0F17] p-3.5 space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <button
                          type="button"
                          onClick={() => onSelectPlayer(item.playerTag)}
                          className="font-semibold text-slate-100 hover:text-amber-400 truncate"
                        >
                          {item.playerName}
                        </button>
                        <span className="font-mono text-sky-300 shrink-0">
                          {getVillageShortTitle(item.village)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-bold text-slate-100 truncate">{item.objectName}</span>
                        <span className="inline-flex items-center gap-1 font-mono font-bold text-amber-400 shrink-0">
                          {item.fromLevel} <ArrowRight className="h-3 w-3" /> {item.toLevel}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2 font-mono text-[11px] text-slate-400">
                        <span>{getDataSourceLabel(item.source)}</span>
                        <span className="text-emerald-300">{cd ? cd.label : 'УЛУЧШАЕТСЯ'}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        );
      })()}

      {/* 4-Column Primary KPI Strip */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Участники клана</div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-100">
              {state.clan.membersCount}/50
            </span>
            <span className="text-xs text-slate-500">в {state.thGroups.length} группах TH</span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Трофеи клана</div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-amber-400">
              {state.clan.clanPoints.toLocaleString('ru-RU')}
            </span>
            <span className="text-xs text-slate-500">очков клана</span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Очки столицы</div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-emerald-400">
              {state.clan.clanCapitalPoints.toLocaleString('ru-RU')}
            </span>
            <span className="text-xs text-slate-500">
              {state.clan.capitalLeague ?? 'Столица'}
            </span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Победы в войнах</div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-sky-400">
              {state.clan.warWins.toLocaleString('ru-RU')}
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              серия: {state.clan.warWinStreak}
            </span>
          </div>
        </div>
      </section>

      {/* Active War Banner (only shown if war is active or available) */}
      {activeWar ? (
        <section className="rounded-lg border border-amber-500/35 bg-[#121824] p-5">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-medium text-amber-400">
                <Swords className="h-4 w-4" />
                <span>{WAR_STATE_LABELS[activeWar.state] ?? activeWar.state}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{activeWar.teamSize}×{activeWar.teamSize}</span>
              </div>
              <div className="font-display text-lg font-bold text-slate-100">
                {activeWar.clan.name} vs {activeWar.opponent.name}{' '}
                <span className="font-mono text-xs font-normal text-slate-400">
                  {activeWar.opponent.tag}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 font-mono tabular-nums">
                <span>
                  Звёзды: <strong className="text-amber-400">{activeWar.clan.stars}</strong> :{' '}
                  {activeWar.opponent.stars}
                </span>
                <span>
                  Разрушение: <strong>{activeWar.clan.destructionPercentage.toFixed(1)}%</strong> :{' '}
                  {activeWar.opponent.destructionPercentage.toFixed(1)}%
                </span>
                <span>
                  Атаки: {activeWar.clan.attacks}/{activeWar.teamSize * activeWar.attacksPerMember}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onSelectTab('wars')}
              className="inline-flex items-center gap-1.5 rounded-md border border-amber-500/50 bg-amber-500/10 px-4 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0 self-start md:self-auto"
            >
              <span>Открыть таблицу войны</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </section>
      ) : (
        <section className="rounded-lg border border-slate-800 bg-[#121824] px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <span>
            Активная клановая война сейчас не идёт (или журнал войн закрыт настройками приватности).
          </span>
          <button
            type="button"
            onClick={() => onSelectTab('wars')}
            className="text-amber-400 hover:text-amber-300 font-medium whitespace-nowrap"
          >
            Перейти в раздел «Войны»
          </button>
        </section>
      )}

      {/* Main Focal Split: Real Snapshot History Chart + Upgrade/Sync Feed */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-stretch">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-8 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-3.5">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-100">
                  Динамика показателей по снимкам ({state.snapshots.length})
                </h2>
                <p className="mt-0.5 text-xs text-slate-400">
                  Реальные измерения с момента первого подключения клана
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-md bg-[#0B0F17] p-1 border border-slate-800">
                {(
                  [
                    { id: 'trophies', label: 'Трофеи' },
                    { id: 'points', label: 'Очки и столица' },
                    { id: 'donations', label: 'Донаты' },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setChartMetric(m.id)}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                      chartMetric === m.id
                        ? 'bg-slate-800 text-amber-400'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <SnapshotTimeSeriesChart points={snapshotPoints} series={activeSeries} height={270} />
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-3 text-xs">
            <div className="flex flex-wrap items-center gap-4">
              {activeSeries.map((s) => (
                <span key={s.key} className="flex items-center gap-2 text-slate-300">
                  <span className="inline-block h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
                  <span>{s.label}</span>
                </span>
              ))}
            </div>
            <button
              type="button"
              onClick={() => onSelectTab('history')}
              className="text-amber-400 hover:text-amber-300 font-medium"
            >
              Подробная история →
            </button>
          </div>
        </div>

        {/* Right: Real Upgrade Change Stream */}
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-4 flex flex-col">
          <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Последние улучшения ({upgradeEventsOnly.length})
            </h2>
            <button
              type="button"
              onClick={() => onSelectTab('upgrade_history')}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 whitespace-nowrap"
            >
              Журнал →
            </button>
          </div>

          <div className="mt-3 flex items-center gap-1 overflow-x-auto pb-1">
            {(
              [
                { id: 'all', label: 'Все' },
                { id: 'heroes', label: 'Герои' },
                { id: 'lab', label: 'Лаб.' },
                { id: 'townhall', label: 'Ратуша' },
              ] as const
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFeedFilter(f.id)}
                className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap shrink-0 ${
                  feedFilter === f.id
                    ? 'bg-amber-500/15 text-amber-400 font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="mt-2 max-h-[280px] flex-1 divide-y divide-slate-800/70 overflow-y-auto pr-1">
            {filteredEvents.map((evt) => (
              <button
                key={evt.id}
                type="button"
                onClick={() => onSelectPlayer(evt.playerTag)}
                className="w-full py-2.5 text-left transition-colors hover:bg-slate-800/30 rounded px-1.5"
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-200 truncate">
                    {evt.playerName}
                    <span className="ml-1.5 text-slate-500 font-normal">TH{evt.townHallLevel}</span>
                  </span>
                  <span className="font-mono text-[11px] text-slate-500 whitespace-nowrap shrink-0">
                    {formatRelativeTimeRu(evt.timestamp, nowMs)}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center justify-between gap-2 text-xs">
                  <span className="text-slate-300 truncate">
                    {evt.apiName || evt.itemNameRu}
                    {evt.instanceNumber ? ` #${evt.instanceNumber}` : ''}
                    <span className="ml-1.5 text-slate-500">· {CATEGORY_LABELS_RU[evt.category]}</span>
                  </span>
                  <span className="font-mono font-semibold tabular-nums text-emerald-400 whitespace-nowrap shrink-0">
                    {evt.fromLevel > 0 ? `${evt.fromLevel} → ${evt.toLevel}` : `TH${evt.toLevel}`}
                  </span>
                </div>
              </button>
            ))}
            {filteredEvents.length === 0 && (
              <div className="py-10 text-center text-xs text-slate-500 leading-relaxed">
                События появятся при следующих синхронизациях, когда у участников вырастет уровень Ратуши, героев, войск или заклинаний.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Town Hall Groups Overview Table */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 px-5 py-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Состав клана по уровням Ратуши
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Реальное распределение участников клана, средний прогресс героев/лаборатории и быстрый переход к группе
            </p>
          </div>
          <button
            type="button"
            onClick={() => onSelectTab('player')}
            className="text-xs font-medium text-amber-400 hover:text-amber-300"
          >
            Все участники ({state.players.length}) →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400">
                <th className="px-5 py-3">Ратуша</th>
                <th className="px-4 py-3 text-right">Игроков</th>
                <th className="px-4 py-3 text-right">Прогресс (API)</th>
                <th className="px-4 py-3 text-right">Герои</th>
                <th className="px-4 py-3 text-right">Лаборатория</th>
                <th className="px-5 py-3 text-right">Детали</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {state.thGroups.map((grp) => (
                <tr
                  key={grp.townHallLevel}
                  onClick={() => onSelectThGroup(grp.townHallLevel)}
                  className="cursor-pointer transition-colors hover:bg-slate-800/40"
                >
                  <td className="px-5 py-3 font-medium text-slate-100 whitespace-nowrap">
                    <span className="inline-flex items-center gap-2.5">
                      <span
                        className="h-2.5 w-2.5 rounded-xs"
                        style={{ backgroundColor: TH_SERIES_COLORS[grp.townHallLevel] ?? '#94A3B8' }}
                      />
                      <span>Ратуша {grp.townHallLevel}</span>
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-300">
                    {grp.playerCount}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-semibold tabular-nums text-amber-400">
                    {grp.avgOverallPct.toFixed(1)}%
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-emerald-400">
                    {grp.avgHeroesPct.toFixed(1)}%
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-sky-400">
                    {grp.avgLabPct.toFixed(1)}%
                  </td>
                  <td className="px-5 py-3 text-right">
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-400">
                      Открыть
                      <ChevronRight className="h-3.5 w-3.5" />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
