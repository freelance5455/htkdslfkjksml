import React, { useState } from 'react';
import { UserProfile, RoyalGift } from '../types';
import { Gift, X, Sparkles, AlertCircle } from 'lucide-react';
import { playAppSound } from '../utils/audio';
import confetti from 'canvas-confetti';

interface GiftModalProps {
  currentUser: UserProfile;
  recipientUser?: UserProfile | null;
  groupMembers?: UserProfile[];
  isGroup?: boolean;
  onSendGift: (gift: RoyalGift, targetRecipient: UserProfile) => Promise<void>;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const ROYAL_GIFTS: RoyalGift[] = [
  {
    id: 'rose',
    name: 'وردة ملكية فاخرة',
    icon: '🌹',
    cost: 1,
    description: 'تحية رقيقة فاخرة وجميلة'
  },
  {
    id: 'coffee',
    name: 'قهوة ملكية ذهبية',
    icon: '☕',
    cost: 3,
    description: 'مزاج ملكي راقٍ ومميز'
  },
  {
    id: 'diamond',
    name: 'ألماسة ملكية براقة',
    icon: '💎',
    cost: 5,
    description: 'بريق الألماس النقي والأناقة'
  },
  {
    id: 'lion',
    name: 'الأسد الذهبي الملكي',
    icon: '🦁',
    cost: 10,
    description: 'رمز الهيبة والقوة الملكية'
  },
  {
    id: 'cyber_heart',
    name: 'قلب حب أسطوري حديث',
    icon: '💖',
    cost: 15,
    description: 'نبضات حب أسطورية ومضيئة'
  },
  {
    id: 'crown',
    name: 'التاج الإمبراطوري',
    icon: '👑',
    cost: 25,
    description: 'تاج الفخامة لأصحاب السمو'
  },
  {
    id: 'rocket',
    name: 'صاروخ الثراء الملكي',
    icon: '🚀',
    cost: 50,
    description: 'انطلاقة صاروخية إلى قمة الفخامة'
  },
  {
    id: 'supercar',
    name: 'سيارة سوبر سبورت ذهبية',
    icon: '🏎️',
    cost: 100,
    description: 'الهدية الأغلى والأفخم في عالم عاصف'
  }
];

export const GiftModal: React.FC<GiftModalProps> = ({
  currentUser,
  recipientUser,
  groupMembers = [],
  isGroup = false,
  onSendGift,
  onClose,
  onToast
}) => {
  const [selectedGift, setSelectedGift] = useState<RoyalGift>(ROYAL_GIFTS[0]);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(
    recipientUser?.id || (groupMembers[0]?.id || '')
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Determine chosen recipient
  const targetRecipient: UserProfile | null = isGroup
    ? groupMembers.find((m) => m.id === selectedRecipientId) || recipientUser || null
    : recipientUser || null;

  const userStars = currentUser.points || 0;
  const canAfford = userStars >= selectedGift.cost;

  const handleSend = async () => {
    if (!targetRecipient) {
      onToast('يرجى تحديد الشخص المستلم للهدية');
      return;
    }

    if (targetRecipient.id === currentUser.id) {
      onToast('لا يمكنك إرسال هدية لنفسك! اختر صديقاً لمكافأته');
      return;
    }

    if (!canAfford) {
      playAppSound('alert');
      onToast(`نقاطك غير كافية! الهدية تتطلب ${selectedGift.cost} نجوم ورصيدك الحالي ${userStars} نجوم`);
      return;
    }

    setIsSubmitting(true);
    try {
      playAppSound('vip');
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore
      }

      const preparedGift: RoyalGift = {
        ...selectedGift,
        recipientId: targetRecipient.id,
        recipientName: targetRecipient.name
      };

      await onSendGift(preparedGift, targetRecipient);
      onToast(`🎁 تم إرسال هدية ${selectedGift.name} ${selectedGift.icon} إلى ${targetRecipient.name} بنجاح!`);
      onClose();
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء إرسال الهدية');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md glass-panel-heavy rounded-3xl border border-[#ffd700]/30 p-5 shadow-2xl animate-in fade-in zoom-in-95 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
          <div className="flex items-center gap-2 text-[#ffd700]">
            <Gift className="w-5 h-5" />
            <h3 className="font-black text-base text-white">إرسال الهدايا الملكية</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Stars Balance */}
        <div className="bg-gradient-to-r from-[#ffd700]/15 via-black/40 to-[#ffd700]/15 p-3 rounded-2xl border border-[#ffd700]/30 flex items-center justify-between mb-3 text-xs">
          <span className="text-gray-300 font-bold">رصيد نجومك الحالي:</span>
          <span className="text-[#ffd700] font-black text-sm flex items-center gap-1">
            <span>⭐ {userStars}</span>
            <small className="text-[10px] text-gray-400 font-normal">نجمة</small>
          </span>
        </div>

        {/* Recipient Selection (especially useful for Group chats) */}
        {isGroup && groupMembers.length > 0 && (
          <div className="mb-3">
            <label className="block text-xs font-bold text-gray-300 mb-1 text-right">
              إهداء إلى العضو:
            </label>
            <select
              value={selectedRecipientId}
              onChange={(e) => setSelectedRecipientId(e.target.value)}
              className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#ffd700] bg-[#111b21]"
            >
              {groupMembers
                .filter((m) => m.id !== currentUser.id)
                .map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} (@{m.username || 'user'})
                  </option>
                ))}
            </select>
          </div>
        )}

        {!isGroup && targetRecipient && (
          <div className="text-right text-xs text-gray-300 mb-2.5">
            إرسال الهدية الملكية إلى: <b className="text-[#25d366]">{targetRecipient.name}</b>
          </div>
        )}

        {/* Gifts Grid */}
        <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          {ROYAL_GIFTS.map((g) => {
            const isSelected = selectedGift.id === g.id;
            const affordable = userStars >= g.cost;

            return (
              <div
                key={g.id}
                onClick={() => {
                  setSelectedGift(g);
                  playAppSound('click');
                }}
                className={`p-2.5 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition border relative group ${
                  isSelected
                    ? 'border-[#ffd700] bg-[#ffd700]/15 ring-2 ring-[#ffd700]/40 scale-105 shadow-lg shadow-[#ffd700]/20'
                    : 'border-white/10 hover:border-white/20 bg-white/5'
                }`}
              >
                <div className="text-3xl mb-1 transform group-hover:scale-110 transition duration-300">
                  {g.icon}
                </div>
                <div className="text-xs font-black text-white leading-tight mb-1 truncate w-full">
                  {g.name}
                </div>
                <div className={`text-[11px] font-black px-2 py-0.5 rounded-full ${affordable ? 'text-[#ffd700] bg-black/40' : 'text-red-400 bg-red-950/40'}`}>
                  ⭐ {g.cost}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Gift Details Card */}
        <div className="bg-black/40 rounded-2xl p-2.5 border border-white/5 mb-3 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{selectedGift.icon}</span>
            <div className="text-right">
              <b className="text-white block font-black">{selectedGift.name}</b>
              <span className="text-[10px] text-gray-400">{selectedGift.description}</span>
            </div>
          </div>
          <div className="text-right shrink-0">
            <span className="text-[#ffd700] font-black text-xs block">
              السعر: {selectedGift.cost} نجمة
            </span>
            <span className="text-[10px] text-gray-400">
              تُحوّل تلقائياً للمستلم
            </span>
          </div>
        </div>

        {!canAfford && (
          <div className="flex items-center gap-1.5 text-xs text-red-400 bg-red-950/30 border border-red-500/20 p-2 rounded-xl mb-3 text-right">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>رصيدك غير كافٍ. ادعُ أصدقاءك لكسب 5 نجوم مجاناً لكل دعوة!</span>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={handleSend}
          disabled={!canAfford || isSubmitting || !targetRecipient}
          className={`w-full py-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition shadow-lg ${
            canAfford && targetRecipient
              ? 'bg-gradient-to-r from-[#ffd700] via-[#ffa500] to-[#ffd700] text-black hover:opacity-95 shadow-[#ffd700]/30 cursor-pointer active:scale-98'
              : 'bg-white/10 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>
            {isSubmitting
              ? 'جارِ إرسال الهدية وتحويل النجوم...'
              : `إرسال ${selectedGift.name} (${selectedGift.cost} ⭐) الآن 🎁`}
          </span>
        </button>
      </div>
    </div>
  );
};
