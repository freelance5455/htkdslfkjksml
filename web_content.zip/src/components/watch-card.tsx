import {
  Bell,
  Crosshair,
  Globe,
  MessageSquare,
  Pause,
  Play,
  ScanSearch,
  Timer,
} from "lucide-react";
import { checkWatchNow, crossesTarget, sendTestAlert } from "@/hooks/use-engine";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/i18n";
import { useLaksha, type Watch, type WatchKind } from "@/lib/store";
import { cn, formatRelative } from "@/lib/utils";

const KIND_ICON: Record<WatchKind, typeof Globe> = {
  site: Globe,
  reminder: Timer,
  target: Crosshair,
  keyword: ScanSearch,
  custom: Bell,
};

export function WatchCard({ watch, featured = false }: { watch: Watch; featured?: boolean }) {
  const lang = useLaksha((s) => s.lang);
  const primaryId = useLaksha((s) => s.primaryId);
  const updateWatch = useLaksha((s) => s.updateWatch);
  const removeWatch = useLaksha((s) => s.removeWatch);
  const pinWatch = useLaksha((s) => s.pinWatch);
  const t = copy[lang];
  const Icon = KIND_ICON[watch.kind];
  const kindLabel: Record<WatchKind, string> = {
    site: t.kindSite,
    reminder: t.kindReminder,
    target: t.kindTarget,
    keyword: t.kindKeyword,
    custom: t.kindCustom,
  };

  const statusVariant = !watch.enabled
    ? "default"
    : watch.lastStatus === "alert"
      ? "alert"
      : watch.lastStatus === "ok"
        ? "ok"
        : "live";
  const statusText = !watch.enabled
    ? t.paused
    : watch.lastStatus === "alert"
      ? t.statusAlert
      : watch.lastStatus === "ok"
        ? t.statusOk
        : t.unknown;

  return (
    <article
      className={cn(
        "flex flex-col gap-3 border border-border bg-surface p-4",
        featured ? "rounded-xl p-5" : "rounded-lg",
      )}
    >
      <header className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-surface-2 text-muted">
            <Icon className="size-4" />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate font-display text-lg leading-snug text-fg">{watch.title}</h3>
              <Badge variant={statusVariant}>{statusText}</Badge>
            </div>
            <p className="mt-0.5 text-xs text-muted">{kindLabel[watch.kind]}</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-muted">
          {watch.channels.notification ? <Bell className="size-3.5" /> : null}
          {watch.channels.sms ? <MessageSquare className="size-3.5" /> : null}
        </div>
      </header>

      <p className="text-sm leading-normal text-fg/90">{watch.note}</p>

      {watch.kind === "site" && (
        <p className="truncate font-mono text-xs text-muted">{watch.url ?? t.noUrl}</p>
      )}
      {watch.kind === "target" && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm tabular-nums text-fg">
            {t.valueNow} {watch.currentValue ?? "—"}
          </span>
          <span className="text-xs text-muted">
            / {watch.targetValue} ({watch.targetDirection === "below" ? t.below : t.above})
          </span>
          <div className="flex gap-1">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                const next = (watch.currentValue ?? 0) - 250;
                updateWatch(watch.id, { currentValue: next });
                const updated = { ...watch, currentValue: next };
                if (crossesTarget(updated)) checkWatchNow(updated);
              }}
            >
              −250
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                const next = (watch.currentValue ?? 0) + 250;
                updateWatch(watch.id, { currentValue: next });
              }}
            >
              +250
            </Button>
          </div>
        </div>
      )}
      {watch.kind === "keyword" && (
        <p className="text-xs text-muted">
          {t.keyword}: <span className="text-fg">{watch.keyword}</span>
        </p>
      )}
      {watch.kind === "reminder" && (
        <p className="text-xs text-muted">
          {watch.reminderMode === "daily"
            ? `${t.daily} ${watch.reminderAt}`
            : watch.reminderMode === "every5"
              ? t.every5
              : watch.reminderMode === "everyHour"
                ? t.everyHour
                : t.every6h}
        </p>
      )}

      {watch.lastMessage ? (
        <p className="text-xs text-muted">
          {watch.lastCheckedAt ? `${formatRelative(watch.lastCheckedAt, lang)} · ` : null}
          {watch.lastMessage}
          {watch.lastLatencyMs != null ? ` · ${watch.lastLatencyMs}ms` : null}
        </p>
      ) : null}

      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={() => checkWatchNow(watch)}>
          {watch.kind === "keyword" ? t.markSeen : t.checkNow}
        </Button>
        <Button size="sm" variant="secondary" onClick={() => sendTestAlert(watch)}>
          {t.testAlert}
        </Button>
        <Button
          size="icon"
          variant="ghost"
          className="size-9"
          aria-label={watch.enabled ? t.pause : t.resume}
          onClick={() => updateWatch(watch.id, { enabled: !watch.enabled })}
        >
          {watch.enabled ? <Pause className="size-3.5" /> : <Play className="size-3.5" />}
        </Button>
        {primaryId !== watch.id ? (
          <Button size="sm" variant="ghost" onClick={() => pinWatch(watch.id)}>
            {t.pin}
          </Button>
        ) : null}
        <Button size="sm" variant="ghost" onClick={() => removeWatch(watch.id)}>
          {t.delete}
        </Button>
      </div>
    </article>
  );
}
