import React, { useState } from 'react';
import { Flame, Lock, Sparkles, X, Layers, CheckCircle2 } from 'lucide-react';
import {
  ELEMENT_FUSIONS,
  ELEMENT_ORDER,
  ELEMENTS,
  getActiveFusion,
  getMasteryXpRequired,
  MASTERY_MILESTONES,
} from '../game/data/elements';
import { ElementId, ElementProgress } from '../game/types';

interface ElementsModalProps {
  open: boolean;
  elements: Record<ElementId, ElementProgress>;
  equippedElements: [ElementId | null, ElementId | null];
  elementShards: number;
  onClose: () => void;
  onUnlockElement: (id: ElementId) => void;
  onSetEquippedSlot: (slotIndex: 0 | 1, elementId: ElementId | null) => void;
}

export const ElementsModal: React.FC<ElementsModalProps> = ({
  open,
  elements,
  equippedElements,
  elementShards,
  onClose,
  onUnlockElement,
  onSetEquippedSlot,
}) => {
  const [selectedId, setSelectedId] = useState<ElementId>(equippedElements[0] ?? 'fire');
  const [tab, setTab] = useState<'loadout' | 'fusions'>('loadout');

  if (!open) return null;

  const selectedDef = ELEMENTS[selectedId];
  const selectedProg = elements[selectedId];
  const activeFusion = getActiveFusion(equippedElements[0], equippedElements[1], elements);
  const xpNeeded = getMasteryXpRequired(selectedProg.masteryLevel);
  const xpPct = Math.min(100, Math.round((selectedProg.xp / xpNeeded) * 100));

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-2 sm:p-5"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-amber-500/35 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <Flame className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-bold text-amber-100 sm:text-lg">
              العناصر السحرية الـ 14 وتجهيز الخانتين
            </h2>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="flex items-center gap-1 rounded-lg border border-sky-500/35 bg-sky-500/15 px-3 py-1 text-xs font-bold text-sky-200">
              <Sparkles className="h-3.5 w-3.5" />
              شظايا العناصر: {elementShards}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Equipped 2-Slot Loadout Bar */}
        <div className="border-b border-slate-800 bg-slate-950/75 px-4 py-3 sm:px-5">
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            {[0, 1].map((idx) => {
              const slotIndex = idx as 0 | 1;
              const eqId = equippedElements[slotIndex];
              const eqDef = eqId ? ELEMENTS[eqId] : null;
              return (
                <div
                  key={slotIndex}
                  className="flex items-center justify-between rounded-xl border border-slate-700 bg-slate-900 px-3 py-2"
                >
                  <div>
                    <div className="text-[10px] text-slate-400">
                      {slotIndex === 0 ? 'الخانة الأولى (أساسي)' : 'الخانة الثانية (اختياري)'}
                    </div>
                    <div
                      className="text-sm font-bold"
                      style={{ color: eqDef ? eqDef.colorHex : '#64748b' }}
                    >
                      {eqDef ? `${eqDef.nameAr} (إتقان ${elements[eqId!].masteryLevel})` : 'فارغة'}
                    </div>
                  </div>
                  {slotIndex === 1 && eqId !== null && (
                    <button
                      type="button"
                      onClick={() => onSetEquippedSlot(1, null)}
                      className="rounded-lg border border-slate-600 bg-slate-800 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-700"
                    >
                      تفريغ
                    </button>
                  )}
                </div>
              );
            })}

            <div className="flex items-center justify-between rounded-xl border border-purple-500/35 bg-purple-950/30 px-3 py-2">
              <div>
                <div className="text-[10px] text-purple-300">حالة دمج العناصر</div>
                <div className="text-xs font-bold text-white">
                  {activeFusion ? activeFusion.nameAr : 'اختر عنصرين متوافقين'}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setTab((t) => (t === 'loadout' ? 'fusions' : 'loadout'))}
                className="flex items-center gap-1 rounded-lg border border-purple-400/50 bg-purple-500/20 px-2.5 py-1.5 text-[11px] font-bold text-purple-200"
              >
                <Layers className="h-3.5 w-3.5" />
                {tab === 'loadout' ? 'دليل الدمج' : 'العناصر'}
              </button>
            </div>
          </div>
        </div>

        {/* Body */}
        {tab === 'fusions' ? (
          <div className="hud-scroll grid flex-1 grid-cols-1 gap-3 overflow-y-auto p-4 sm:grid-cols-2">
            {ELEMENT_FUSIONS.map((f) => {
              const e1 = ELEMENTS[f.elements[0]];
              const e2 = ELEMENTS[f.elements[1]];
              const ready =
                elements[f.elements[0]].unlocked && elements[f.elements[1]].unlocked;
              return (
                <div
                  key={f.id}
                  className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-950/70 p-3.5"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold" style={{ color: f.colorHex }}>
                        {f.nameAr}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {e1.nameAr} + {e2.nameAr}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-300">{f.descriptionAr}</p>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-[11px]">
                    <span className="text-sky-300">المانا: {f.manaCost} • القوة: {f.power}</span>
                    {ready ? (
                      <button
                        type="button"
                        onClick={() => {
                          onSetEquippedSlot(0, f.elements[0]);
                          onSetEquippedSlot(1, f.elements[1]);
                          setTab('loadout');
                        }}
                        className="rounded-lg bg-purple-600 px-2.5 py-1 font-bold text-white hover:bg-purple-500"
                      >
                        تجهيز الدمج
                      </button>
                    ) : (
                      <span className="text-slate-500">افتح العنصرين أولاً</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid flex-1 grid-cols-1 overflow-hidden sm:grid-cols-12">
            {/* 14 Elements Grid */}
            <div className="hud-scroll grid grid-cols-3 gap-2 overflow-y-auto p-4 sm:col-span-5 sm:grid-cols-2">
              {ELEMENT_ORDER.map((id) => {
                const def = ELEMENTS[id];
                const prog = elements[id];
                const isEq0 = equippedElements[0] === id;
                const isEq1 = equippedElements[1] === id;
                const isSel = selectedId === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setSelectedId(id)}
                    className={`relative flex flex-col items-start rounded-xl border-2 p-2.5 text-right transition ${
                      isSel
                        ? 'border-amber-400 bg-slate-800'
                        : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex w-full items-center justify-between">
                      <span
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: def.colorHex }}
                      />
                      {!prog.unlocked ? (
                        <Lock className="h-3.5 w-3.5 text-slate-500" />
                      ) : isEq0 || isEq1 ? (
                        <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
                          {isEq0 ? 'خانة 1' : 'خانة 2'}
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-1.5 text-xs font-bold text-white">{def.nameAr}</div>
                    <div className="text-[10px] text-slate-400">
                      {prog.unlocked ? `إتقان ${prog.masteryLevel}/50` : `فتح: ${def.unlockCostShards} شظية`}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Element Details & Abilities */}
            <div className="hud-scroll flex flex-col justify-between overflow-y-auto border-t border-slate-800 bg-slate-950/60 p-4 sm:col-span-7 sm:border-t-0 sm:border-r">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-lg font-extrabold" style={{ color: selectedDef.colorHex }}>
                      عنصر {selectedDef.nameAr}
                    </h3>
                    <div className="text-xs text-slate-400">
                      قوي ضد: {selectedDef.strongAgainst.map((e) => ELEMENTS[e].nameAr).join('، ')} •
                      ضعيف ضد: {selectedDef.weakAgainst.map((e) => ELEMENTS[e].nameAr).join('، ')}
                    </div>
                  </div>
                  {selectedProg.unlocked ? (
                    <div className="flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSetEquippedSlot(0, selectedId)}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold ${
                          equippedElements[0] === selectedId
                            ? 'bg-amber-500 text-slate-950'
                            : 'border border-amber-500/50 bg-amber-500/15 text-amber-200'
                        }`}
                      >
                        تجهيز خانة 1
                      </button>
                      <button
                        type="button"
                        onClick={() => onSetEquippedSlot(1, selectedId)}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold ${
                          equippedElements[1] === selectedId
                            ? 'bg-sky-500 text-slate-950'
                            : 'border border-sky-500/50 bg-sky-500/15 text-sky-200'
                        }`}
                      >
                        تجهيز خانة 2
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onUnlockElement(selectedId)}
                      className="rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-amber-500"
                    >
                      فتح العنصر ({selectedDef.unlockCostShards} شظايا)
                    </button>
                  )}
                </div>

                {/* Mastery Progress & Milestones */}
                <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-3">
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200">
                      مستوى الإتقان: {selectedProg.masteryLevel} / 50
                    </span>
                    <span className="text-slate-400">
                      {selectedProg.xp} / {xpNeeded} XP
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full transition-all"
                      style={{ width: `${xpPct}%`, backgroundColor: selectedDef.colorHex }}
                    />
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {MASTERY_MILESTONES.map((m) => (
                      <span
                        key={m}
                        className={`flex items-center gap-0.5 rounded px-1.5 py-0.5 text-[10px] font-bold ${
                          selectedProg.masteryLevel >= m
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {selectedProg.masteryLevel >= m && <CheckCircle2 className="h-2.5 w-2.5" />}
                        Lv.{m}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 4 Abilities */}
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {selectedDef.abilities.map((ab) => {
                    const unlockedAb =
                      selectedProg.unlocked && selectedProg.masteryLevel >= ab.unlockMastery;
                    return (
                      <div
                        key={ab.id}
                        className={`rounded-xl border p-2.5 ${
                          unlockedAb
                            ? 'border-slate-700 bg-slate-900'
                            : 'border-slate-800/70 bg-slate-950/60 opacity-65'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">{ab.nameAr}</span>
                          <span className="text-[10px] text-sky-300">
                            {ab.manaCost} MP • {ab.cooldownSec}ث
                          </span>
                        </div>
                        <p className="mt-1 text-[11px] text-slate-400">{ab.descriptionAr}</p>
                        <div className="mt-1.5 text-[10px] font-semibold text-amber-300">
                          {unlockedAb ? `قوة: ${ab.power}` : `يفتح عند إتقان ${ab.unlockMastery}`}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
