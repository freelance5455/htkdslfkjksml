"use client";

import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

type ToastItem = { id: number; text: string; tone: "success" | "error" | "info" };
type ToastCtx = { toast: (text: string, tone?: ToastItem["tone"]) => void };

const Ctx = createContext<ToastCtx>({ toast: () => undefined });

export function useToast() {
  return useContext(Ctx);
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const toast = useCallback((text: string, tone: ToastItem["tone"] = "info") => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, text, tone }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, []);

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-24 left-1/2 z-50 flex -translate-x-1/2 flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto rounded-xl border px-4 py-2 text-sm font-bold shadow-xl backdrop-blur ${
              t.tone === "success"
                ? "border-emerald-500/50 bg-emerald-950/90 text-emerald-200"
                : t.tone === "error"
                  ? "border-rose-500/50 bg-rose-950/90 text-rose-200"
                  : "border-sky-500/50 bg-sky-950/90 text-sky-200"
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
