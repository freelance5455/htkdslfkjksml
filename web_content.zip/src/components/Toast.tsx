import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2 } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 pointer-events-none transition-all duration-300 ease-out animate-in fade-in slide-in-from-top-4">
      <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-neutral-900/90 text-white text-xs font-medium backdrop-blur-xl shadow-lg border border-white/10">
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        <span className="whitespace-nowrap">{toastMessage}</span>
      </div>
    </div>
  );
};
