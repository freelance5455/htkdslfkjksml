import React, { useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type?: 'success' | 'info' | 'warning';
  text: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 max-w-sm pointer-events-none">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={() => onDismiss(toast.id)} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onDismiss: () => void }> = ({ toast, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 3200);
    return () => clearTimeout(timer);
  }, [onDismiss]);

  const Icon =
    toast.type === 'warning'
      ? AlertCircle
      : toast.type === 'info'
      ? Info
      : CheckCircle2;

  const colorClass =
    toast.type === 'warning'
      ? 'bg-amber-50 text-amber-900 border-amber-200'
      : toast.type === 'info'
      ? 'bg-indigo-50 text-indigo-900 border-indigo-200'
      : 'bg-emerald-50 text-emerald-900 border-emerald-200';

  const iconClass =
    toast.type === 'warning'
      ? 'text-amber-600'
      : toast.type === 'info'
      ? 'text-indigo-600'
      : 'text-emerald-600';

  return (
    <div
      className={`pointer-events-auto flex items-center justify-between p-3 rounded-xl border shadow-md text-xs font-medium transition-all transform translate-y-0 ${colorClass}`}
    >
      <div className="flex items-center space-x-2 mr-2">
        <Icon className={`w-4 h-4 shrink-0 ${iconClass}`} />
        <span>{toast.text}</span>
      </div>
      <button
        onClick={onDismiss}
        aria-label="Dismiss notification"
        className="p-1 hover:opacity-75 transition rounded"
      >
        <X className="w-3.5 h-3.5 opacity-60 hover:opacity-100" />
      </button>
    </div>
  );
};
