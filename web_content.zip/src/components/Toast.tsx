import React, { useEffect } from 'react';

interface ToastProps {
  message: string | null;
  onClose: () => void;
  isBlackPatti?: boolean;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose, isBlackPatti = false }) => {
  useEffect(() => {
    if (!message) return;
    // Exactly 2 seconds limit as requested: "Har popup 2 second se zyada show na ho"
    const timer = setTimeout(() => {
      onClose();
    }, 2000);
    return () => clearTimeout(timer);
  }, [message, onClose]);

  if (!message) return null;

  if (isBlackPatti) {
    return (
      <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-pulse">
        <div className="bg-black text-white text-xs sm:text-sm font-bold tracking-wider px-6 py-2.5 rounded-full shadow-2xl border border-white/20 select-none">
          {message}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-in fade-in zoom-in-95 duration-100">
      <div className="bg-black text-white text-xs sm:text-sm font-semibold px-5 py-2.5 rounded-full shadow-2xl border border-slate-800 flex items-center gap-2 select-none">
        <span>{message}</span>
      </div>
    </div>
  );
};
