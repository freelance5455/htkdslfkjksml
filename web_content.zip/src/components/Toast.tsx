import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2 } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-3 duration-200 pointer-events-none max-w-xs w-full px-4">
      <div className="bg-[#062c20]/95 dark:bg-[#021811]/95 text-[#e8f5ee] border border-emerald-500/40 rounded-2xl py-2.5 px-4 shadow-xl backdrop-blur-md flex items-center justify-center gap-2 text-center text-xs font-semibold font-tajawal">
        <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
        <span>{toastMessage}</span>
      </div>
    </div>
  );
};
