import React from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toast, hideToast } = useParentControl();

  if (!toast) return null;

  const getStyle = () => {
    switch (toast.type) {
      case 'success':
        return {
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />,
          bg: 'bg-white dark:bg-slate-900 border-emerald-500/40 text-slate-900 dark:text-white shadow-emerald-500/10',
          accent: 'bg-emerald-500'
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />,
          bg: 'bg-white dark:bg-slate-900 border-amber-500/40 text-slate-900 dark:text-white shadow-amber-500/10',
          accent: 'bg-amber-500'
        };
      case 'error':
        return {
          icon: <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />,
          bg: 'bg-white dark:bg-slate-900 border-rose-500/40 text-slate-900 dark:text-white shadow-rose-500/10',
          accent: 'bg-rose-500'
        };
      case 'info':
      default:
        return {
          icon: <Info className="w-5 h-5 text-indigo-500 shrink-0" />,
          bg: 'bg-white dark:bg-slate-900 border-indigo-500/40 text-slate-900 dark:text-white shadow-indigo-500/10',
          accent: 'bg-indigo-500'
        };
    }
  };

  const { icon, bg, accent } = getStyle();

  return (
    <div className="fixed top-4 inset-x-0 z-50 flex justify-center px-4 pointer-events-none animate-in fade-in slide-in-from-top-3 duration-200">
      <div 
        role="alert"
        className={`pointer-events-auto max-w-md w-full rounded-2xl border shadow-xl backdrop-blur-md p-3.5 flex items-center justify-between gap-3 relative overflow-hidden transition-all ${bg}`}
      >
        <div className={`absolute top-0 inset-x-0 h-1 ${accent}`} />
        <div className="flex items-center gap-2.5 min-w-0">
          {icon}
          <span className="text-xs sm:text-sm font-semibold truncate leading-relaxed">
            {toast.message}
          </span>
        </div>
        <button
          onClick={hideToast}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
