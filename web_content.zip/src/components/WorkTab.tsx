/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Check, Trash2, Edit3, ChevronRight, ChevronDown, ChevronUp, ArrowUp, ArrowDown, GripVertical } from 'lucide-react';
import { WorkGroup, WorkTask } from '../types.ts';
import { toBengaliNum } from '../utils/dateUtils.ts';
import { MAX_GROUP_LIMIT } from '../utils/storage.ts';
import { ConfirmModal } from './ConfirmModal.tsx';
import { EmptyState } from './EmptyState.tsx';

interface WorkTabProps {
  groups: WorkGroup[];
  selectedGroupId: string | null;
  isEditMode: boolean;
  onSelectGroup: (groupId: string | null) => void;
  onAddGroup: (title: string) => void;
  onUpdateGroup: (groupId: string, title: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onReorderGroups: (newGroups: WorkGroup[]) => void;
  onAddTask: (groupId: string, title: string, details?: string) => void;
  onUpdateTask: (groupId: string, taskId: string, title: string, details?: string) => void;
  onDeleteTask: (groupId: string, taskId: string) => void;
  onToggleTask: (groupId: string, taskId: string) => void;
  onReorderTasks: (groupId: string, newTasks: WorkTask[]) => void;
  onResetGroupTasks: (groupId: string) => void;
  showResetConfirm: boolean;
  setShowResetConfirm: (show: boolean) => void;
}

export const WorkTab: React.FC<WorkTabProps> = ({
  groups,
  selectedGroupId,
  isEditMode,
  onSelectGroup,
  onAddGroup,
  onUpdateGroup,
  onDeleteGroup,
  onReorderGroups,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onToggleTask,
  onReorderTasks,
  onResetGroupTasks,
  showResetConfirm,
  setShowResetConfirm,
}) => {
  // Modal states
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [editingGroup, setEditingGroup] = useState<WorkGroup | null>(null);
  const [editingTask, setEditingTask] = useState<WorkTask | null>(null);

  // Deletion confirm states
  const [groupToDelete, setGroupToDelete] = useState<WorkGroup | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<WorkTask | null>(null);

  // Form input states
  const [inputTitle, setInputTitle] = useState('');
  const [inputDetails, setInputDetails] = useState('');
  const [limitWarning, setLimitWarning] = useState<string | null>(null);

  // Expanded task details state in Work tab
  const [expandedWorkTasks, setExpandedWorkTasks] = useState<Record<string, boolean>>({});

  const toggleTaskDetails = (taskId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedWorkTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  const selectedGroup = groups.find((g) => g.id === selectedGroupId) ?? null;

  // Handlers for Groups
  const handleOpenAddGroup = () => {
    if (groups.length >= MAX_GROUP_LIMIT) {
      setLimitWarning(`ওয়ার্ক ট্যাবে সর্বোচ্চ ${toBengaliNum(MAX_GROUP_LIMIT)}টি গ্রুপ তৈরি করা সম্ভব। নতুন গ্রুপ যোগ করা যাবে না।`);
      return;
    }
    setInputTitle('');
    setShowAddGroupModal(true);
  };

  const handleSaveAddGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputTitle.trim()) return;
    onAddGroup(inputTitle.trim());
    setInputTitle('');
    setShowAddGroupModal(false);
  };

  const handleOpenEditGroup = (group: WorkGroup, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingGroup(group);
    setInputTitle(group.title);
  };

  const handleSaveEditGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGroup || !inputTitle.trim()) return;
    onUpdateGroup(editingGroup.id, inputTitle.trim());
    setEditingGroup(null);
    setInputTitle('');
  };

  const handleMoveGroup = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= groups.length) return;
    const reordered = [...groups];
    const temp = reordered[index];
    reordered[index] = reordered[targetIndex];
    reordered[targetIndex] = temp;
    // update order
    reordered.forEach((g, idx) => {
      g.order = idx;
    });
    onReorderGroups(reordered);
  };

  // Handlers for Tasks inside Selected Group
  const handleOpenAddTask = () => {
    setInputTitle('');
    setInputDetails('');
    setShowAddTaskModal(true);
  };

  const handleSaveAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !inputTitle.trim()) return;
    onAddTask(selectedGroup.id, inputTitle.trim(), inputDetails.trim() || undefined);
    setInputTitle('');
    setInputDetails('');
    setShowAddTaskModal(false);
  };

  const handleOpenEditTask = (task: WorkTask) => {
    setEditingTask(task);
    setInputTitle(task.title);
    setInputDetails(task.details || '');
  };

  const handleSaveEditTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !editingTask || !inputTitle.trim()) return;
    onUpdateTask(selectedGroup.id, editingTask.id, inputTitle.trim(), inputDetails.trim() || undefined);
    setEditingTask(null);
    setInputTitle('');
    setInputDetails('');
  };

  const handleMoveTask = (index: number, direction: 'up' | 'down') => {
    if (!selectedGroup) return;
    const tasks = [...selectedGroup.tasks];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= tasks.length) return;
    const temp = tasks[index];
    tasks[index] = tasks[targetIndex];
    tasks[targetIndex] = temp;
    tasks.forEach((t, idx) => {
      t.order = idx;
    });
    onReorderTasks(selectedGroup.id, tasks);
  };

  // ================= VIEW: Inside a Group =================
  if (selectedGroup) {
    return (
      <div className="pb-28 max-w-md mx-auto px-4 pt-3">
        {selectedGroup.tasks.length === 0 ? (
          <EmptyState
            message="এই গ্রুপে এখনও কোনো কাজ নেই।"
            subMessage="নিচের + চাপলে কাজ যোগ করার ফর্ম আসবে।"
          />
        ) : (
          <div className="space-y-2.5">
            {selectedGroup.tasks.map((task, index) => {
              const bengaliNum = toBengaliNum(index + 1);
              const isExpanded = !!expandedWorkTasks[task.id];

              return (
                <div
                  key={task.id}
                  onClick={() => {
                    if (!isEditMode) {
                      if (task.details) {
                        toggleTaskDetails(task.id);
                      } else {
                        onToggleTask(selectedGroup.id, task.id);
                      }
                    }
                  }}
                  className={`relative flex flex-col p-3.5 rounded-2xl border transition-all duration-200 select-none ${
                    isEditMode
                      ? 'bg-amber-50/70 border-amber-200/80 shadow-xs'
                      : task.completed
                      ? 'bg-slate-50 border-slate-200 text-slate-400 opacity-75'
                      : 'bg-white border-slate-200/80 shadow-xs hover:border-emerald-300 active:scale-[0.99] cursor-pointer'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    {/* Left Section: Reorder handles in Edit Mode OR Sequential Number + Checkbox */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {isEditMode ? (
                        <div className="flex items-center gap-1 shrink-0 text-slate-500">
                          <GripVertical className="w-5 h-5 text-amber-600" />
                          <div className="flex flex-col gap-0.5">
                            <button
                              type="button"
                              disabled={index === 0}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveTask(index, 'up');
                              }}
                              aria-label="উপরে নিন"
                              className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              disabled={index === selectedGroup.tasks.length - 1}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveTask(index, 'down');
                              }}
                              aria-label="নিচে নিন"
                              className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleTask(selectedGroup.id, task.id);
                          }}
                          aria-label={task.completed ? 'বাকি করুন' : 'সম্পন্ন করুন'}
                          className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold transition-all active:scale-90 ${
                            task.completed
                              ? 'bg-emerald-500 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-700 border border-slate-200 hover:border-emerald-400'
                          }`}
                        >
                          {task.completed ? <Check className="w-4 h-4 stroke-[3]" /> : bengaliNum}
                        </button>
                      )}

                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline gap-1.5">
                          {isEditMode && (
                            <span className="text-xs font-bold text-amber-700">
                              {bengaliNum}.
                            </span>
                          )}
                          <h4
                            className={`text-base font-semibold leading-snug break-words ${
                              task.completed ? 'line-through text-slate-400' : 'text-slate-800'
                            }`}
                          >
                            {task.title}
                          </h4>
                        </div>
                      </div>
                    </div>

                    {/* Right Section: Edit Mode Actions (✎ / 🗑) OR Details Indicator */}
                    {isEditMode ? (
                      <div className="flex items-center gap-1.5 ml-2 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenEditTask(task);
                          }}
                          aria-label="নাম ও বিস্তারিত পরিবর্তন করুন"
                          className="p-2 rounded-xl bg-white border border-slate-200 text-blue-600 hover:bg-blue-50 active:scale-95 transition-all shadow-xs"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setTaskToDelete(task);
                          }}
                          aria-label="কাজ মুছুন"
                          className="p-2 rounded-xl bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 active:scale-95 transition-all shadow-xs"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : task.details ? (
                      <div className="text-slate-400 pl-2 shrink-0 flex items-center">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    ) : null}
                  </div>

                  {/* Expanded Details section: only shown when user taps "উপরে মানে চাদর দুয়ার উপর" */}
                  {!isEditMode && isExpanded && task.details && (
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="mt-2.5 pt-2 border-t border-slate-100 bg-slate-50/90 -mx-1 px-3 py-2 rounded-xl animate-in slide-in-from-top-1 duration-150"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[11px] font-bold text-slate-500">বিস্তারিত বিবরণ:</span>
                        <button
                          type="button"
                          onClick={() => onToggleTask(selectedGroup.id, task.id)}
                          className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-200 transition-colors"
                        >
                          {task.completed ? 'বাকি করুন' : '✔ সম্পন্ন করুন'}
                        </button>
                      </div>
                      <p
                        className={`text-xs leading-relaxed break-words ${
                          task.completed ? 'text-slate-400 line-through' : 'text-slate-700'
                        }`}
                      >
                        {task.details}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Floating Action Button (+) */}
        <button
          type="button"
          onClick={handleOpenAddTask}
          aria-label="নতুন কাজ যোগ করুন"
          className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-600/30 flex items-center justify-center hover:bg-emerald-500 active:scale-95 transition-all"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>

        {/* Add Task Modal */}
        {showAddTaskModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
              <form onSubmit={handleSaveAddTask}>
                <div className="p-5">
                  <h3 className="text-base font-bold text-slate-900 mb-4">নতুন কাজ যোগ করুন</h3>
                  <div className="space-y-3.5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        কাজ <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        autoFocus
                        required
                        value={inputTitle}
                        onChange={(e) => setInputTitle(e.target.value)}
                        placeholder="যেমন: ঘর গুছানো"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        বিস্তারিত (ঐচ্ছিক)
                      </label>
                      <textarea
                        rows={2}
                        value={inputDetails}
                        onChange={(e) => setInputDetails(e.target.value)}
                        placeholder="যেমন: চাদর ও বালিশ গুছানো"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 resize-none"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddTaskModal(false)}
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-98 transition-all shadow-sm"
                  >
                    যোগ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Task Modal */}
        {editingTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
              <form onSubmit={handleSaveEditTask}>
                <div className="p-5">
                  <h3 className="text-base font-bold text-slate-900 mb-4">কাজের তথ্য পরিবর্তন</h3>
                  <div className="space-y-3.5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        কাজ <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        autoFocus
                        required
                        value={inputTitle}
                        onChange={(e) => setInputTitle(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        বিস্তারিত (ঐচ্ছিক)
                      </label>
                      <textarea
                        rows={2}
                        value={inputDetails}
                        onChange={(e) => setInputDetails(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingTask(null)}
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all shadow-sm"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Task Confirmation Modal */}
        <ConfirmModal
          isOpen={taskToDelete !== null}
          title="কাজটি মুছে ফেলবেন?"
          message={`"${taskToDelete?.title}" কাজটি তালিকা থেকে মুছে ফেলতে চান?`}
          confirmLabel="মুছে ফেলুন"
          cancelLabel="না"
          isDestructive={true}
          onConfirm={() => {
            if (taskToDelete && selectedGroup) {
              onDeleteTask(selectedGroup.id, taskToDelete.id);
              setTaskToDelete(null);
            }
          }}
          onCancel={() => setTaskToDelete(null)}
        />

        {/* Reset Confirmation Modal */}
        <ConfirmModal
          isOpen={showResetConfirm}
          title="সব কাজ রিসেট করবেন?"
          message="এই গ্রুপের সব কাজ নতুন করে শুরু হবে এবং সব টিক চিহ্ন মুছে যাবে (কাজগুলো মুছবে না)। আপনি কি নিশ্চিত?"
          confirmLabel="হ্যাঁ, রিসেট করুন"
          cancelLabel="বাতিল"
          isDestructive={false}
          onConfirm={() => {
            onResetGroupTasks(selectedGroup.id);
            setShowResetConfirm(false);
          }}
          onCancel={() => setShowResetConfirm(false)}
        />
      </div>
    );
  }

  // ================= VIEW: Work Main Screen (Group List) =================
  return (
    <div className="pb-28 max-w-md mx-auto px-4 pt-3">
      {/* 100 Group Limit Notice if warning active */}
      {limitWarning && (
        <div className="mb-3 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between">
          <span>{limitWarning}</span>
          <button
            type="button"
            onClick={() => setLimitWarning(null)}
            className="text-amber-800 font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {groups.length === 0 ? (
        <EmptyState
          message="এখনও কোনো গ্রুপ নেই।"
          subMessage="নিচের + চেপে নতুন গ্রুপ তৈরি করুন।"
        />
      ) : (
        <div className="space-y-2.5">
          {groups.map((group, index) => {
            const completedCount = group.tasks.filter((t) => t.completed).length;
            const totalCount = group.tasks.length;

            return (
              <div
                key={group.id}
                onClick={() => {
                  if (!isEditMode) {
                    onSelectGroup(group.id);
                  }
                }}
                className={`relative flex items-center justify-between p-4 rounded-2xl border transition-all duration-200 select-none ${
                  isEditMode
                    ? 'bg-amber-50/70 border-amber-200/80 shadow-xs'
                    : 'bg-white border-slate-200/80 shadow-xs hover:border-emerald-300 hover:shadow-sm active:scale-[0.99] cursor-pointer'
                }`}
              >
                {/* Left Section: Reorder or Drag handle + Title */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {isEditMode ? (
                    <div className="flex items-center gap-1 shrink-0 text-slate-500">
                      <GripVertical className="w-5 h-5 text-amber-600" />
                      <div className="flex flex-col gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveGroup(index, 'up');
                          }}
                          aria-label="উপরে নিন"
                          className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={index === groups.length - 1}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveGroup(index, 'down');
                          }}
                          aria-label="নিচে নিন"
                          className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100 flex items-center justify-center font-bold text-sm shrink-0">
                      {toBengaliNum(index + 1)}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900 leading-snug break-words">
                      {group.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {totalCount === 0 ? (
                        'কোনো কাজ নেই'
                      ) : (
                        <span>
                          {toBengaliNum(completedCount)} / {toBengaliNum(totalCount)} টি সম্পন্ন
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Right Section: In Edit Mode show (✎ / 🗑), else Chevron */}
                {isEditMode ? (
                  <div className="flex items-center gap-1.5 ml-2 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => handleOpenEditGroup(group, e)}
                      aria-label="নাম পরিবর্তন করুন"
                      className="p-2 rounded-xl bg-white border border-slate-200 text-blue-600 hover:bg-blue-50 active:scale-95 transition-all shadow-xs"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setGroupToDelete(group);
                      }}
                      aria-label="গ্রুপ মুছুন"
                      className="p-2 rounded-xl bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 active:scale-95 transition-all shadow-xs"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="text-slate-400 pl-2 shrink-0">
                    <ChevronRight className="w-5 h-5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button (+) */}
      <button
        type="button"
        onClick={handleOpenAddGroup}
        aria-label="নতুন গ্রুপ যোগ করুন"
        className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-600/30 flex items-center justify-center hover:bg-emerald-500 active:scale-95 transition-all"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* Add Group Modal (Only 1 input field: "কাজ") */}
      {showAddGroupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <form onSubmit={handleSaveAddGroup}>
              <div className="p-5">
                <h3 className="text-base font-bold text-slate-900 mb-4">নতুন গ্রুপ তৈরি করুন</h3>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    কাজ <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    autoFocus
                    required
                    value={inputTitle}
                    onChange={(e) => setInputTitle(e.target.value)}
                    placeholder="যেমন: ঘর"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
              </div>
              <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddGroupModal(false)}
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-98 transition-all shadow-sm"
                >
                  তৈরি করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Group Modal */}
      {editingGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <form onSubmit={handleSaveEditGroup}>
              <div className="p-5">
                <h3 className="text-base font-bold text-slate-900 mb-4">গ্রুপের নাম পরিবর্তন</h3>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    কাজ <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    autoFocus
                    required
                    value={inputTitle}
                    onChange={(e) => setInputTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                <button
                  type="button"
                  onClick={() => setEditingGroup(null)}
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Group Confirmation Modal (Clear notice that all tasks & history inside will be deleted) */}
      <ConfirmModal
        isOpen={groupToDelete !== null}
        title="গ্রুপটি মুছে ফেলবেন?"
        message={`"${groupToDelete?.title}" গ্রুপ মুছলে তার ভেতরের সব কাজ ও ইতিহাসও মুছে যাবে। আপনি কি নিশ্চিত?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="না, রাখুন"
        isDestructive={true}
        onConfirm={() => {
          if (groupToDelete) {
            onDeleteGroup(groupToDelete.id);
            setGroupToDelete(null);
          }
        }}
        onCancel={() => setGroupToDelete(null)}
      />
    </div>
  );
};
