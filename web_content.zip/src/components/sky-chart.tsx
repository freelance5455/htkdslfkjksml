import { useEffect, useRef } from "react";
import { CONSTELLATIONS, LINES, STARS, type Star } from "@/data/catalog";
import { bodiesAt, eclipticSamples, toAltAz, lstHours, type SkyBody } from "@/lib/astro";
import { drawMoonDisk } from "@/lib/moon-draw";

const INK = "#0b0f14";
const WELL = "#10161d";
const LINE = "#2c3a48";
const GOLD = "#e2b15a";
const FG = "#efe7d6";
const MUTED = "#a7b0bd";

const TINT: Record<Star["tint"], string> = {
  blue: "#d5e4ff",
  white: "#f7f4ec",
  gold: "#ffe3a6",
  amber: "#ffc58a",
  rose: "#ffb1a4",
};

type Hit = { id: string; x: number; y: number; r: number };

type Props = {
  when: Date;
  lat: number;
  lon: number;
  lines: boolean;
  guides: boolean;
  names: boolean;
  ecliptic: boolean;
  focus: string | null;
  selected: string | null;
  onSelect: (id: string | null) => void;
};

function project(alt: number, az: number, cx: number, cy: number, R: number) {
  const dist = ((90 - alt) / 90) * R;
  const a = (az * Math.PI) / 180;
  return { x: cx + dist * Math.sin(a), y: cy - dist * Math.cos(a), dist };
}

function starLit(id: string, focus: string | null): boolean {
  if (!focus) return true;
  const star = STARS.find((s) => s.id === id);
  if (star?.con === focus) return true;
  return LINES.some((l) => !l.guide && l.con === focus && (l.a === id || l.b === id));
}

export function SkyChart({ when, lat, lon, lines, guides, names, ecliptic, focus, selected, onSelect }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hits = useRef<Hit[]>([]);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    let cancelled = false;

    const draw = () => {
      if (cancelled) return;
      const cssW = wrap.clientWidth;
      const cssH = wrap.clientHeight;
      if (cssW < 8 || cssH < 8) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(cssW * dpr);
      canvas.height = Math.round(cssH * dpr);
      canvas.style.width = `${cssW}px`;
      canvas.style.height = `${cssH}px`;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = INK;
      ctx.fillRect(0, 0, cssW, cssH);

      const cx = cssW / 2;
      const cy = cssH / 2;
      const R = Math.min(cssW, cssH) / 2 - 26;
      const lst = lstHours(when, lon);
      const bodies = bodiesAt(when);
      const nextHits: Hit[] = [];

      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = WELL;
      ctx.fill();
      ctx.strokeStyle = LINE;
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.clip();

      for (const ring of [30, 60]) {
        const rr = ((90 - ring) / 90) * R;
        ctx.beginPath();
        ctx.arc(cx, cy, rr, 0, Math.PI * 2);
        ctx.strokeStyle = LINE;
        ctx.stroke();
      }
      ctx.strokeStyle = LINE;
      ctx.beginPath();
      ctx.moveTo(cx - R, cy);
      ctx.lineTo(cx + R, cy);
      ctx.moveTo(cx, cy - R);
      ctx.lineTo(cx, cy + R);
      ctx.stroke();

      const at = (ra: number, dec: number) => {
        const { alt, az } = toAltAz(ra, dec, lat, lst);
        return { alt, ...project(alt, az, cx, cy, R) };
      };

      if (ecliptic) {
        const pts = eclipticSamples().map((p) => at(p.ra, p.dec));
        ctx.beginPath();
        let pen = false;
        for (const p of pts) {
          if (p.alt <= 0) {
            pen = false;
            continue;
          }
          if (!pen) ctx.moveTo(p.x, p.y);
          else ctx.lineTo(p.x, p.y);
          pen = true;
        }
        ctx.strokeStyle = "rgba(226,177,90,0.45)";
        ctx.setLineDash([4, 6]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      const byId = new Map(STARS.map((s) => [s.id, s]));
      for (const line of LINES) {
        if (line.guide && !guides) continue;
        if (!line.guide && !lines) continue;
        const a = byId.get(line.a);
        const b = byId.get(line.b);
        if (!a || !b) continue;
        const pa = at(a.ra, a.dec);
        const pb = at(b.ra, b.dec);
        const hot = !focus || line.con === focus || (line.guide && (starLit(a.id, focus) || starLit(b.id, focus)));
        ctx.beginPath();
        ctx.moveTo(pa.x, pa.y);
        ctx.lineTo(pb.x, pb.y);
        ctx.strokeStyle = line.guide ? "rgba(226,177,90,0.55)" : "rgba(167,176,189,0.75)";
        ctx.globalAlpha = hot ? 0.9 : 0.12;
        ctx.setLineDash(line.guide ? [3, 5] : []);
        ctx.lineWidth = line.guide ? 1 : 1.25;
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 1;
      }

      const placed: { x: number; y: number }[] = [];
      const labelIt = (x: number, y: number, text: string, fill: string, bold = false) => {
        if (placed.some((p) => Math.hypot(p.x - x, p.y - y) < 14)) return;
        placed.push({ x, y });
        ctx.font = `${bold ? 600 : 500} 12px Outfit, sans-serif`;
        ctx.fillStyle = fill;
        ctx.fillText(text, x + 8, y - 6);
      };

      for (const star of STARS) {
        const p = at(star.ra, star.dec);
        if (p.alt <= 0) continue;
        const hot = starLit(star.id, focus);
        const radius = Math.max(0.8, (3.4 - star.mag) * 1.25);
        ctx.globalAlpha = hot ? 1 : 0.28;
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = TINT[star.tint];
        ctx.fill();
        if (selected === star.id) {
          ctx.strokeStyle = GOLD;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(p.x, p.y, radius + 5, 0, Math.PI * 2);
          ctx.stroke();
        }
        const show =
          selected === star.id ||
          (focus ? hot && star.mag < 3.2 : names ? star.mag < 2.6 : star.mag < 0.9);
        if (show) labelIt(p.x, p.y, star.name, hot ? FG : MUTED, selected === star.id);
        ctx.globalAlpha = 1;
        nextHits.push({ id: star.id, x: p.x, y: p.y, r: Math.max(radius + 8, 16) });
      }

      for (const body of bodies) {
        const p = at(body.ra, body.dec);
        if (p.alt <= -2) continue;
        ctx.globalAlpha = p.alt > 0 ? 1 : 0.35;
        if (body.kind === "moon") {
          drawMoonDisk(ctx, p.x, p.y, 8, body.elongation, lat < 0);
        } else if (body.kind === "sun") {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 9, 0, Math.PI * 2);
          ctx.fillStyle = GOLD;
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 4.5, 0, Math.PI * 2);
          ctx.fillStyle = body.id === "mars" ? "#ffb1a4" : GOLD;
          ctx.fill();
          ctx.strokeStyle = FG;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        if (selected === body.id) {
          ctx.strokeStyle = GOLD;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 14, 0, Math.PI * 2);
          ctx.stroke();
        }
        labelIt(p.x, p.y, body.name, GOLD, true);
        ctx.globalAlpha = 1;
        nextHits.push({ id: body.id, x: p.x, y: p.y, r: 18 });
      }

      ctx.restore();

      ctx.fillStyle = MUTED;
      ctx.font = "500 12px Outfit, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("N", cx, cy - R - 8);
      ctx.fillText("S", cx, cy + R + 16);
      ctx.textAlign = "left";
      ctx.fillText("E", cx + R + 8, cy + 4);
      ctx.textAlign = "right";
      ctx.fillText("W", cx - R - 8, cy + 4);
      ctx.textAlign = "start";

      if (focus && CONSTELLATIONS[focus]) {
        ctx.fillStyle = GOLD;
        ctx.font = "600 13px Fraunces, serif";
        ctx.fillText(CONSTELLATIONS[focus].name, 12, 22);
      }

      hits.current = nextHits;
    };

    draw();
    document.fonts?.ready.then(() => {
      if (!cancelled) draw();
    });
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    return () => {
      cancelled = true;
      ro.disconnect();
    };
  }, [when, lat, lon, lines, guides, names, ecliptic, focus, selected]);

  function pick(clientX: number, clientY: number) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    let best: Hit | null = null;
    let bestD = 1e9;
    for (const h of hits.current) {
      const d = Math.hypot(h.x - x, h.y - y);
      if (d < h.r && d < bestD) {
        best = h;
        bestD = d;
      }
    }
    onSelect(best ? best.id : null);
  }

  return (
    <div ref={wrapRef} className="aspect-square w-full">
      <canvas
        ref={canvasRef}
        className="h-full w-full touch-manipulation"
        onClick={(e) => pick(e.clientX, e.clientY)}
      />
    </div>
  );
}

export function visibleObjects(when: Date, lat: number, lon: number): {
  stars: (Star & { alt: number; az: number })[];
  bodies: (SkyBody & { alt: number; az: number })[];
} {
  const lst = lstHours(when, lon);
  const stars = STARS.map((s) => ({ ...s, ...toAltAz(s.ra, s.dec, lat, lst) }))
    .filter((s) => s.alt > 0)
    .sort((a, b) => a.mag - b.mag);
  const bodies = bodiesAt(when)
    .map((b) => ({ ...b, ...toAltAz(b.ra, b.dec, lat, lst) }))
    .filter((b) => b.alt > 0)
    .sort((a, b) => b.alt - a.alt);
  return { stars, bodies };
}
