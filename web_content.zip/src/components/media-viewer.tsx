import { X, ZoomIn, ZoomOut } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

const MIN = 0.15;
const MAX = 80;

export function MediaViewer({
  src,
  onClose,
}: {
  src: string;
  onClose: () => void;
}) {
  const [scale, setScale] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const dragging = useRef(false);
  const last = useRef({ x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ dist: number; scale: number } | null>(null);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const clampScale = (n: number) => Math.min(MAX, Math.max(MIN, n));

  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.12;
    setScale((s) => clampScale(s * delta));
  }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 1) {
      dragging.current = true;
      last.current = { x: e.clientX, y: e.clientY };
    } else if (pointers.current.size === 2) {
      const pts = [...pointers.current.values()];
      const dx = pts[0]!.x - pts[1]!.x;
      const dy = pts[0]!.y - pts[1]!.y;
      pinch.current = { dist: Math.hypot(dx, dy) || 1, scale };
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size >= 2 && pinch.current) {
      const pts = [...pointers.current.values()];
      const dx = pts[0]!.x - pts[1]!.x;
      const dy = pts[0]!.y - pts[1]!.y;
      const dist = Math.hypot(dx, dy) || 1;
      setScale(clampScale(pinch.current.scale * (dist / pinch.current.dist)));
      return;
    }
    if (!dragging.current) return;
    const dx = e.clientX - last.current.x;
    const dy = e.clientY - last.current.y;
    last.current = { x: e.clientX, y: e.clientY };
    setTx((v) => v + dx);
    setTy((v) => v + dy);
  };

  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinch.current = null;
    if (pointers.current.size === 0) dragging.current = false;
  };

  const node = (
    <div
      className="fixed inset-0 z-[80] flex touch-none flex-col bg-background"
      style={{ background: "#000000" }}
      onWheel={onWheel}
    >
      <div className="pointer-events-auto absolute inset-x-0 top-0 z-10 flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button
          type="button"
          onClick={onClose}
          className="flex size-11 items-center justify-center rounded-full bg-secondary text-foreground"
          aria-label="Close"
        >
          <X className="size-5" />
        </button>
        <div className="flex gap-2">
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full bg-secondary text-foreground"
            onClick={() => setScale((s) => clampScale(s / 1.4))}
            aria-label="Zoom out"
          >
            <ZoomOut className="size-5" />
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full bg-secondary text-foreground"
            onClick={() => setScale((s) => clampScale(s * 1.4))}
            aria-label="Zoom in"
          >
            <ZoomIn className="size-5" />
          </button>
        </div>
      </div>
      <div
        className="flex min-h-0 flex-1 items-center justify-center overflow-hidden"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={() => {
          setScale((s) => (s > 1.4 ? 1 : 3));
          if (scale > 1.4) {
            setTx(0);
            setTy(0);
          }
        }}
      >
        <img
          src={src}
          alt=""
          draggable={false}
          className="max-h-none max-w-none select-none object-contain"
          style={{
            transform: `translate3d(${tx}px, ${ty}px, 0) scale(${scale})`,
            transformOrigin: "center center",
            willChange: "transform",
          }}
        />
      </div>
    </div>
  );

  if (typeof document === "undefined") return null;
  return createPortal(node, document.body);
}
