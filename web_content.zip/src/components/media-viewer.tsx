import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useVault, type MediaMeta } from "@/store/vault";

export function MediaViewer({
  item,
  onClose,
}: {
  item: MediaMeta | null;
  onClose: () => void;
}) {
  const getBlob = useVault((s) => s.getBlob);
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!item) {
      setUrl(null);
      return;
    }
    let revoke: string | null = null;
    let alive = true;
    getBlob(item.id).then((got) => {
      if (!alive || !got) return;
      revoke = URL.createObjectURL(got.blob);
      setUrl(revoke);
    });
    return () => {
      alive = false;
      if (revoke) URL.revokeObjectURL(revoke);
    };
  }, [getBlob, item]);

  return (
    <Dialog open={Boolean(item)} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92dvh] overflow-hidden p-0 sm:max-w-4xl">
        <DialogTitle className="sr-only">{item?.name ?? "Media"}</DialogTitle>
        <div className="flex max-h-[92dvh] flex-col bg-ink">
          <div className="flex min-h-0 flex-1 items-center justify-center p-3">
            {url && item?.kind === "video" ? (
              <video src={url} controls autoPlay playsInline className="max-h-[80dvh] w-full rounded-md" />
            ) : url ? (
              <img src={url} alt={item?.name ?? ""} className="max-h-[80dvh] w-full rounded-md object-contain" />
            ) : (
              <p className="text-sm text-muted-foreground">Loading</p>
            )}
          </div>
          <p className="truncate px-4 pb-4 text-sm text-muted-foreground">{item?.name}</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
