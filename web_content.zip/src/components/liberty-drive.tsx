import { useEffect, useRef, type PointerEvent } from "react";
import { mountLiberty, type LibertyHandle } from "@/game/engine";

export function LibertyDrive() {
  const rootRef = useRef<HTMLDivElement>(null);
  const apiRef = useRef<LibertyHandle | null>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const canvas = root.querySelector("canvas.ld-view");
    if (!(canvas instanceof HTMLCanvasElement)) return;
    const handle = mountLiberty(canvas, root);
    apiRef.current = handle;
    return () => {
      handle.dispose();
      apiRef.current = null;
    };
  }, []);

  const hold = (key: "fire" | "sprint" | "brake", value: boolean) => (event: PointerEvent) => {
    event.preventDefault();
    apiRef.current?.setHold(key, value);
  };

  return (
    <div ref={rootRef} className="ld-root">
      <canvas className="ld-view" />
      <div className="ld-vignette" />
      <div className="ld-cross" />
      <div className="ld-pain" />

      <div className="ld-hud">
        <div className="ld-help">
          <span><b>WASD</b> drive</span>
          <span><b>Mouse</b> look</span>
          <span><b>Click</b> fire</span>
          <span><b>Shift</b> nitro</span>
          <span><b>Space</b> brake</span>
          <span><b>E</b> enter</span>
          <span><b>1-4</b> guns</span>
          <span><b>M</b> radio</span>
        </div>

        <section className="ld-mission">
          <p id="ld-mission-kicker" className="ld-kicker">Contract</p>
          <h2 id="ld-mission-title">Loading the city</h2>
          <p id="ld-mission-desc" className="ld-dim">Markets, motors, and trouble.</p>
          <p id="ld-mission-status" className="ld-status" />
        </section>

        <div className="ld-cluster">
          <div id="ld-stars" className="ld-stars" aria-label="Wanted">
            <i /><i /><i /><i /><i />
          </div>
          <p id="ld-money" className="ld-money">$0</p>
          <p id="ld-clock" className="ld-clock">18:12</p>
          <canvas id="ld-map" className="ld-map" width={168} height={168} />
        </div>

        <div className="ld-hp-wrap">
          <span className="ld-kicker">Health</span>
          <div className="ld-hp"><span id="ld-hp" /></div>
        </div>

        <div className="ld-combat">
          <div className="ld-nitro">
            <span className="ld-kicker">Nitro</span>
            <div className="ld-nitro-track"><span id="ld-nitro" /></div>
          </div>
          <p id="ld-radio" className="ld-radio">Radio off</p>
          <p id="ld-weapon" className="ld-weapon">Pistol</p>
          <p id="ld-ammo" className="ld-ammo">12 / 120</p>
          <p id="ld-speed" className="ld-speed">On foot</p>
          <div className="ld-slots">
            <button type="button" onClick={() => apiRef.current?.weapon(0)}>1</button>
            <button type="button" onClick={() => apiRef.current?.weapon(1)}>2</button>
            <button type="button" onClick={() => apiRef.current?.weapon(2)}>3</button>
            <button type="button" onClick={() => apiRef.current?.weapon(3)}>4</button>
          </div>
        </div>

        <p id="ld-hint" className="ld-hint" />
        <p id="ld-combo" className="ld-combo" />
        <p id="ld-toast" className="ld-toast" />
        <button type="button" className="ld-pause-btn" onClick={() => apiRef.current?.togglePause()}>
          Pause
        </button>
      </div>

      <div id="ld-wasted" className="ld-wasted">Wasted</div>

      <div id="ld-pause" className="ld-pause">
        <div className="ld-card">
          <p className="ld-kicker">Paused</p>
          <h2>Liberty Drive</h2>
          <ul>
            <li>WASD drives and walks. A turns left, D turns right.</li>
            <li>Hold Shift for nitro. Space brakes. Air off the ramps pays.</li>
            <li>E enters cars and uses street shops. L toggles headlights.</li>
            <li>M cycles the radio. C switches crew. H hits the horn.</li>
            <li>Four stars calls a helicopter. Rockets swat it down.</li>
          </ul>
          <p id="ld-best" className="ld-dim" />
          <button type="button" className="ld-start-btn" onClick={() => apiRef.current?.resume()}>
            Resume
          </button>
        </div>
      </div>

      <div className="ld-mob">
        <div className="ld-stick" id="ld-stick-l"><i id="ld-knob-l" /></div>
        <div className="ld-stick" id="ld-stick-r"><i id="ld-knob-r" /></div>
        <button type="button" className="ld-fire" id="ld-fire" onPointerDown={hold("fire", true)} onPointerUp={hold("fire", false)} onPointerCancel={hold("fire", false)}>
          Fire
        </button>
        <button type="button" className="ld-mini ld-nos" onPointerDown={hold("sprint", true)} onPointerUp={hold("sprint", false)} onPointerCancel={hold("sprint", false)}>
          Nos
        </button>
        <button type="button" className="ld-mini ld-brake" onPointerDown={hold("brake", true)} onPointerUp={hold("brake", false)} onPointerCancel={hold("brake", false)}>
          Stop
        </button>
        <button type="button" className="ld-mini ld-use" onClick={() => apiRef.current?.interact()}>
          Use
        </button>
      </div>

      <div className="ld-start">
        <div className="ld-title">
          <p className="ld-kicker">Open city</p>
          <h1>
            Liberty
            <span>Drive</span>
          </h1>
          <p className="ld-deck">Steal a car, run the contracts, and keep the lights behind you.</p>
          <button type="button" className="ld-start-btn" onClick={() => apiRef.current?.begin()}>
            Start
          </button>
          <p className="ld-fine">Mouse look after you start. Cash saves on this device.</p>
        </div>
      </div>
    </div>
  );
}
