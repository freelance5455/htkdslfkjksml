import React, { useRef, useState } from 'react';
import { ArrowUp, Flame, Shield, Swords, Zap } from 'lucide-react';

interface VirtualControlsProps {
  onVirtualMove: (x: number, z: number) => void;
  onTriggerAttack: () => void;
  onTriggerJump: () => void;
  onTriggerFlashStep: () => void;
  onTriggerSkill: (key: 'Z' | 'X' | 'C' | 'V' | 'F') => void;
  onToggleHaki?: () => void;
  onToggleObservation?: () => void;
  hasFruit?: boolean;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  onVirtualMove,
  onTriggerAttack,
  onTriggerJump,
  onTriggerFlashStep,
  onTriggerSkill,
  onToggleHaki,
  onToggleObservation,
  hasFruit = true,
}) => {
  const joystickRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const touchIdRef = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (touchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        updateJoystick(e.changedTouches[i].clientX, e.changedTouches[i].clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        touchIdRef.current = null;
        setKnobPos({ x: 0, y: 0 });
        onVirtualMove(0, 0);
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    if (!joystickRef.current) return;
    const rect = joystickRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const deltaX = clientX - centerX;
    const deltaY = clientY - centerY;
    const maxRadius = rect.width / 2;

    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const clampedDist = Math.min(distance, maxRadius);
    const angle = Math.atan2(deltaY, deltaX);

    const normX = clampedDist > 8 ? (Math.cos(angle) * clampedDist) / maxRadius : 0;
    const normY = clampedDist > 8 ? (Math.sin(angle) * clampedDist) / maxRadius : 0;

    setKnobPos({
      x: normX * (maxRadius * 0.7),
      y: normY * (maxRadius * 0.7),
    });

    onVirtualMove(normX, -normY);
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-20 select-none md:hidden overflow-hidden">
      {/* Virtual Joystick (Left Thumb) */}
      <div
        ref={joystickRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="absolute bottom-6 left-4 w-28 h-28 rounded-full bg-slate-900/70 border-2 border-slate-600/50 backdrop-blur-md pointer-events-auto flex items-center justify-center touch-none shadow-2xl"
      >
        <div
          className="w-11 h-11 rounded-full bg-slate-200/90 border border-white shadow-lg pointer-events-none transition-transform duration-75"
          style={{ transform: `translate(${knobPos.x}px, ${knobPos.y}px)` }}
        />
      </div>

      {/* Action Cluster (Right Thumb) */}
      <div className="absolute bottom-6 right-4 flex flex-col items-end gap-2.5 pointer-events-auto touch-none">
        {/* Fruit Skill Buttons Row */}
        {hasFruit && (
          <div className="flex items-center gap-1.5 mb-1">
            {(['Z', 'X', 'C', 'V'] as const).map((key) => (
              <button
                key={key}
                onTouchStart={(e) => {
                  e.preventDefault();
                  onTriggerSkill(key);
                }}
                className="w-9 h-9 rounded-full bg-slate-900/90 border border-amber-500/60 text-amber-300 font-mono font-bold text-xs flex items-center justify-center shadow-md active:scale-90 active:bg-amber-600 active:text-white transition-all cursor-pointer"
              >
                {key}
              </button>
            ))}
          </div>
        )}

        {/* Haki & Utility Row */}
        <div className="flex items-center gap-2">
          {onToggleHaki && (
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                onToggleHaki();
              }}
              className="w-10 h-10 rounded-full bg-purple-950/90 border border-purple-500/60 text-purple-300 flex items-center justify-center shadow-md active:scale-90 transition-all cursor-pointer"
              title="Aura Haki [J]"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}

          {onToggleObservation && (
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                onToggleObservation();
              }}
              className="w-10 h-10 rounded-full bg-sky-950/90 border border-sky-500/60 text-sky-300 flex items-center justify-center shadow-md active:scale-90 transition-all cursor-pointer"
              title="Observation [E]"
            >
              <Zap className="w-4 h-4" />
            </button>
          )}

          <button
            onTouchStart={(e) => {
              e.preventDefault();
              onTriggerFlashStep();
            }}
            className="w-11 h-11 rounded-full bg-cyan-700/90 border border-cyan-400/60 text-white flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer"
            title="Soru / Flash Step [Q]"
          >
            <Zap className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Combat & Jump Row */}
        <div className="flex items-center gap-3">
          {/* Jump / Geppo button */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              onTriggerJump();
            }}
            className="w-13 h-13 rounded-full bg-amber-500 text-slate-950 font-black flex flex-col items-center justify-center shadow-xl active:scale-90 transition-transform border border-amber-300 cursor-pointer"
            title="Jump / Sky Leap"
          >
            <ArrowUp className="w-5 h-5 stroke-[2.5]" />
            <span className="text-[9px] uppercase font-bold leading-none">Jump</span>
          </button>

          {/* Large Attack M1 button */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              onTriggerAttack();
            }}
            className="w-16 h-16 rounded-full bg-rose-600 text-white flex flex-col items-center justify-center shadow-2xl active:scale-90 transition-transform border-2 border-rose-400 cursor-pointer"
            title="Attack / Punch"
          >
            <Swords className="w-6 h-6" />
            <span className="text-[10px] font-black uppercase tracking-wider leading-none mt-0.5">Atk</span>
          </button>
        </div>
      </div>
    </div>
  );
};
