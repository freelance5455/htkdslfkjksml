import React, { useRef, useState, useCallback, useEffect } from 'react';
import { CustomControlsSettings, WeaponConfig } from '../types';
import {
  Crosshair,
  RefreshCw,
  Hammer,
  Radio,
  Flame,
  Zap,
  Shield,
} from 'lucide-react';

interface VirtualControlsProps {
  settings: CustomControlsSettings;
  currentWeapon: WeaponConfig;
  currentAmmo: number;
  maxAmmo: number;
  isReloading: boolean;
  grenades: number;
  dashCooldown: number;
  wood: number;
  metal: number;
  onMove: (x: number, y: number) => void;
  onAim: (angle: number) => void;
  onFireStart: () => void;
  onFireEnd: () => void;
  onReload: () => void;
  onRepair: () => void;
  onSwitchWeapon: () => void;
  onGrenade: () => void;
  onDash: () => void;
  onPlaceTurret: () => void;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  settings,
  currentWeapon,
  currentAmmo,
  maxAmmo,
  isReloading,
  grenades,
  dashCooldown,
  wood,
  metal,
  onMove,
  onAim,
  onFireStart,
  onFireEnd,
  onReload,
  onRepair,
  onSwitchWeapon,
  onGrenade,
  onDash,
  onPlaceTurret,
}) => {
  const joystickRef = useRef<HTMLDivElement>(null);
  const [joystickThumb, setJoystickThumb] = useState({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState(false);
  const joystickPointerId = useRef<number | null>(null);

  const { buttons } = settings;

  // Joystick Pointer Handling
  const handleJoystickDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    joystickPointerId.current = e.pointerId;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsJoystickActive(true);
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoystickMove = (e: React.PointerEvent) => {
    if (joystickPointerId.current === e.pointerId) {
      updateJoystick(e.clientX, e.clientY);
    }
  };

  const handleJoystickUp = (e: React.PointerEvent) => {
    if (joystickPointerId.current === e.pointerId) {
      joystickPointerId.current = null;
      setIsJoystickActive(false);
      setJoystickThumb({ x: 0, y: 0 });
      onMove(0, 0);
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    if (!joystickRef.current) return;
    const rect = joystickRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const maxRadius = rect.width / 2 - 12;
    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);

    if (dist === 0) {
      setJoystickThumb({ x: 0, y: 0 });
      onMove(0, 0);
      return;
    }

    const angle = Math.atan2(dy, dx);
    const clampedDist = Math.min(dist, maxRadius);
    const thumbX = Math.cos(angle) * clampedDist;
    const thumbY = Math.sin(angle) * clampedDist;

    setJoystickThumb({ x: thumbX, y: thumbY });
    onMove(thumbX / maxRadius, thumbY / maxRadius);
  };

  // Keyboard controls listener for Desktop testing convenience
  useEffect(() => {
    const keysDown = new Set<string>();

    const updateKeyboardMove = () => {
      let mx = 0;
      let my = 0;
      if (keysDown.has('KeyW') || keysDown.has('ArrowUp')) my -= 1;
      if (keysDown.has('KeyS') || keysDown.has('ArrowDown')) my += 1;
      if (keysDown.has('KeyA') || keysDown.has('ArrowLeft')) mx -= 1;
      if (keysDown.has('KeyD') || keysDown.has('ArrowRight')) mx += 1;

      const len = Math.hypot(mx, my);
      if (len > 0) {
        onMove(mx / len, my / len);
      } else if (!isJoystickActive) {
        onMove(0, 0);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      keysDown.add(e.code);

      if (e.code === 'KeyR') onReload();
      if (e.code === 'KeyE') onRepair();
      if (e.code === 'KeyQ') onSwitchWeapon();
      if (e.code === 'KeyG') onGrenade();
      if (e.code === 'Space') onDash();
      if (e.code === 'KeyT') onPlaceTurret();

      updateKeyboardMove();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysDown.delete(e.code);
      updateKeyboardMove();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onMove, onReload, onRepair, onSwitchWeapon, onGrenade, onDash, onPlaceTurret, isJoystickActive]);

  return (
    <div id="virtual-controls-container" className="absolute inset-0 pointer-events-none select-none z-30">
      {/* 1. Joystick */}
      <div
        ref={joystickRef}
        id="control-joystick"
        onPointerDown={handleJoystickDown}
        onPointerMove={handleJoystickMove}
        onPointerUp={handleJoystickUp}
        onPointerCancel={handleJoystickUp}
        style={{
          left: `${buttons.joystick.xPercent}%`,
          top: `${buttons.joystick.yPercent}%`,
          width: `${buttons.joystick.size}px`,
          height: `${buttons.joystick.size}px`,
          opacity: buttons.joystick.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-950/60 border-2 border-zinc-700/80 shadow-2xl backdrop-blur-sm flex items-center justify-center touch-none"
      >
        {/* Joystick Thumb */}
        <div
          style={{
            transform: `translate(${joystickThumb.x}px, ${joystickThumb.y}px)`,
          }}
          className={`w-12 h-12 rounded-full border-2 transition-all flex items-center justify-center ${
            isJoystickActive
              ? 'bg-red-600/80 border-red-400 scale-110 shadow-lg shadow-red-950'
              : 'bg-zinc-800/80 border-zinc-500'
          }`}
        >
          <div className="w-4 h-4 rounded-full bg-white/70" />
        </div>
      </div>

      {/* 2. Fire Button */}
      <button
        id="control-fire-btn"
        onPointerDown={(e) => {
          e.stopPropagation();
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          onFireStart();
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          onFireEnd();
        }}
        onPointerCancel={(e) => {
          e.stopPropagation();
          onFireEnd();
        }}
        style={{
          left: `${buttons.fire.xPercent}%`,
          top: `${buttons.fire.yPercent}%`,
          width: `${buttons.fire.size}px`,
          height: `${buttons.fire.size}px`,
          opacity: buttons.fire.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-gradient-to-tr from-red-700 to-red-500 border-2 border-red-400 shadow-2xl active:scale-90 transition-transform flex flex-col items-center justify-center text-white touch-none"
      >
        <Crosshair className="w-8 h-8 drop-shadow" />
        <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">OTISH</span>
      </button>

      {/* 3. Reload Button */}
      <button
        id="control-reload-btn"
        onClick={onReload}
        style={{
          left: `${buttons.reload.xPercent}%`,
          top: `${buttons.reload.yPercent}%`,
          width: `${buttons.reload.size}px`,
          height: `${buttons.reload.size}px`,
          opacity: buttons.reload.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-900/80 border-2 border-amber-500/70 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center text-amber-300 touch-none"
      >
        <RefreshCw className={`w-5 h-5 ${isReloading ? 'animate-spin text-amber-400' : ''}`} />
        <span className="text-[9px] font-bold uppercase mt-0.5">
          {currentWeapon.id === 'pistol' ? '∞' : `${currentAmmo}`}
        </span>
      </button>

      {/* 4. Repair Base Button */}
      <button
        id="control-repair-btn"
        onClick={onRepair}
        style={{
          left: `${buttons.repair.xPercent}%`,
          top: `${buttons.repair.yPercent}%`,
          width: `${buttons.repair.size}px`,
          height: `${buttons.repair.size}px`,
          opacity: buttons.repair.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-900/80 border-2 border-sky-500/80 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center text-sky-300 touch-none"
      >
        <Hammer className="w-5 h-5" />
        <span className="text-[8px] font-bold uppercase mt-0.5">TAʼMIR</span>
      </button>

      {/* 5. Switch Weapon Button */}
      <button
        id="control-switch-weapon-btn"
        onClick={onSwitchWeapon}
        style={{
          left: `${buttons.switchWeapon.xPercent}%`,
          top: `${buttons.switchWeapon.yPercent}%`,
          width: `${buttons.switchWeapon.size}px`,
          height: `${buttons.switchWeapon.size}px`,
          opacity: buttons.switchWeapon.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-900/80 border-2 border-cyan-500/80 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center text-cyan-300 touch-none"
      >
        <Radio className="w-5 h-5" />
        <span className="text-[8px] font-bold uppercase mt-0.5 max-w-[50px] truncate">QUROL</span>
      </button>

      {/* 6. Grenade Button */}
      <button
        id="control-grenade-btn"
        onClick={onGrenade}
        style={{
          left: `${buttons.grenade.xPercent}%`,
          top: `${buttons.grenade.yPercent}%`,
          width: `${buttons.grenade.size}px`,
          height: `${buttons.grenade.size}px`,
          opacity: buttons.grenade.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-900/80 border-2 border-emerald-500/80 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center text-emerald-300 touch-none"
      >
        <Flame className="w-5 h-5" />
        <span className="text-[8px] font-bold uppercase mt-0.5">x{grenades}</span>
      </button>

      {/* 7. Dash Sprint Button */}
      <button
        id="control-dash-btn"
        onClick={onDash}
        disabled={dashCooldown > 0}
        style={{
          left: `${buttons.dash.xPercent}%`,
          top: `${buttons.dash.yPercent}%`,
          width: `${buttons.dash.size}px`,
          height: `${buttons.dash.size}px`,
          opacity: buttons.dash.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className={`absolute rounded-full pointer-events-auto border-2 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center touch-none ${
          dashCooldown > 0
            ? 'bg-zinc-950/80 border-zinc-700 text-zinc-500 cursor-not-allowed'
            : 'bg-zinc-900/80 border-sky-400 text-sky-300'
        }`}
      >
        <Zap className="w-5 h-5" />
        <span className="text-[8px] font-bold uppercase mt-0.5">
          {dashCooldown > 0 ? `${dashCooldown.toFixed(1)}s` : 'SPRINT'}
        </span>
      </button>

      {/* 8. Deploy Turret Button */}
      <button
        id="control-turret-btn"
        onClick={onPlaceTurret}
        style={{
          left: `${buttons.placeTurret.xPercent}%`,
          top: `${buttons.placeTurret.yPercent}%`,
          width: `${buttons.placeTurret.size}px`,
          height: `${buttons.placeTurret.size}px`,
          opacity: buttons.placeTurret.opacity,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute rounded-full pointer-events-auto bg-zinc-900/80 border-2 border-purple-500/80 shadow-lg active:scale-90 transition-transform flex flex-col items-center justify-center text-purple-300 touch-none"
      >
        <Shield className="w-5 h-5" />
        <span className="text-[8px] font-bold uppercase mt-0.5">MINORA</span>
      </button>
    </div>
  );
};
