import React, { useState, useEffect } from 'react';
import {
  Search,
  Heart,
  Bookmark,
  Share2,
  Globe,
  Lightbulb,
  Sparkles,
  ChevronRight,
  Check,
  ShieldCheck,
  X,
  Info,
  Calendar,
  Clock,
  Award,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { TipLanguage, TipCategoryMeta, HealthTipItem } from '../types/tip';
import { ReadAloudButton } from './ReadAloudButton';
import { PreferredLanguage } from '../types';
import {
  TIP_CATEGORIES,
  ALL_HEALTH_TIPS,
  getTipsByCategory,
  searchHealthTips,
  getTipOfTheDay
} from '../data/tipData';

interface DailyHealthTipsViewProps {
  onBack: () => void;
}

export const DailyHealthTipsView: React.FC<DailyHealthTipsViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<TipLanguage>('English');
  const [activeTab, setActiveTab] = useState<'categories' | 'saved' | 'search'>('categories');
  const [selectedCategory, setSelectedCategory] = useState<TipCategoryMeta | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Local storage bookmarks state
  const [savedTipIds, setSavedTipIds] = useState<string[]>([]);
  const [favoriteTipIds, setFavoriteTipIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // Tip of the Day
  const dailyTip = getTipOfTheDay();

  // Date formatting
  const todayDateString = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  // Load saved/favorited tips from LocalStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_saved_tips_v1');
      if (saved) setSavedTipIds(JSON.parse(saved));

      const favs = localStorage.getItem('mediguide_favorite_tips_v1');
      if (favs) setFavoriteTipIds(JSON.parse(favs));
    } catch (e) {
      console.warn('Failed to load saved tips:', e);
    }
  }, []);

  // Save bookmarked tips
  const toggleSaveTip = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let updated: string[];
    if (savedTipIds.includes(id)) {
      updated = savedTipIds.filter((item) => item !== id);
    } else {
      updated = [...savedTipIds, id];
    }
    setSavedTipIds(updated);
    try {
      localStorage.setItem('mediguide_saved_tips_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to persist saved tips:', e);
    }
  };

  // Toggle Favorite
  const toggleFavoriteTip = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let updated: string[];
    if (favoriteTipIds.includes(id)) {
      updated = favoriteTipIds.filter((item) => item !== id);
    } else {
      updated = [...favoriteTipIds, id];
    }
    setFavoriteTipIds(updated);
    try {
      localStorage.setItem('mediguide_favorite_tips_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to persist favorite tips:', e);
    }
  };

  // Share card handler
  const handleShareTip = async (tip: HealthTipItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const content = tip.content[selectedLanguage] || tip.content.English;
    const text = `💡 HEALTH TIP: ${content.title}\n\n📌 TIP: ${content.tip}\n\n📖 EXPLANATION: ${content.explanation}\n\n🌟 BENEFITS:\n${content.benefits.map(b => '• ' + b).join('\n')}\n\n⏰ FREQUENCY: ${content.recommendedFrequency}\n\n📚 Source: ${content.source} (via MediGuide AI Daily Health Tips)`;

    if (navigator.share) {
      try {
        await navigator.share({ title: `Daily Health Tip - ${content.title}`, text });
        return;
      } catch (err) {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(tip.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  // Determine list of displayed tips
  const getDisplayedTips = (): HealthTipItem[] => {
    if (activeTab === 'saved') {
      return ALL_HEALTH_TIPS.filter((t) => savedTipIds.includes(t.id) || favoriteTipIds.includes(t.id));
    }

    if (searchQuery.trim().length > 0) {
      return searchHealthTips(searchQuery, selectedLanguage);
    }

    if (selectedCategory) {
      return getTipsByCategory(selectedCategory.id);
    }

    return ALL_HEALTH_TIPS;
  };

  const displayedTips = getDisplayedTips();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Daily Health Tips"
        subtitle="Medically Verified Wellness Guidance"
        onBack={
          selectedCategory
            ? () => setSelectedCategory(null)
            : activeTab !== 'categories'
            ? () => setActiveTab('categories')
            : onBack
        }
        badge="Material Design 3"
        badgeColor="bg-emerald-100 text-emerald-800 border-emerald-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Top Control Bar: Search & Language Switcher */}
        <div className="bg-white p-3 sm:p-4 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (e.target.value.trim().length > 0 && activeTab !== 'search') {
                    setActiveTab('search');
                  } else if (e.target.value.trim().length === 0 && activeTab === 'search') {
                    setActiveTab('categories');
                  }
                }}
                placeholder={
                  selectedLanguage === 'Hindi'
                    ? 'बीमारी, दवा, पोषण, व्यायाम या स्वास्थ्य खोजें...'
                    : selectedLanguage === 'Marathi'
                    ? 'आजार, औषध, पोषण, व्यायाम किंवा आरोग्य शोधा...'
                    : 'Search by disease, medicine, nutrition, exercise, topic...'
                }
                className="w-full pl-10 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Language Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
              <Globe className="w-3.5 h-3.5 text-emerald-600 ml-1.5 hidden sm:block" />
              {(['English', 'Hindi', 'Marathi'] as TipLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Navigation: Categories vs Bookmarks */}
          <div className="flex items-center gap-2 pt-1 border-t border-slate-100 text-xs">
            <button
              onClick={() => {
                setActiveTab('categories');
                setSelectedCategory(null);
                setSearchQuery('');
              }}
              className={`px-4 py-2 rounded-xl font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'categories' && !selectedCategory
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>Explore Categories (15)</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('saved');
                setSelectedCategory(null);
              }}
              className={`px-4 py-2 rounded-xl font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'saved'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>
                Saved & Favorites ({savedTipIds.length + favoriteTipIds.length})
              </span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* HERO BANNER: TODAY'S HEALTH TIP */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'categories' && !selectedCategory && !searchQuery && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white p-6 rounded-3xl shadow-xl space-y-4 border border-emerald-800 relative overflow-hidden"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-black uppercase tracking-wider border border-emerald-500/30">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                  <span>⭐ Tip of the Day</span>
                </div>
                <span className="text-[11px] text-slate-300 font-bold flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{todayDateString}</span>
                </span>
              </div>

              {(() => {
                const cat = TIP_CATEGORIES.find((c) => c.id === dailyTip.categoryId);
                return (
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-white/10 border border-white/15 text-emerald-200 font-extrabold">
                    {cat ? cat.emoji + ' ' + (selectedLanguage === 'Hindi' ? cat.nameHi : selectedLanguage === 'Marathi' ? cat.nameMr : cat.nameEn) : 'Health Tip'}
                  </span>
                );
              })()}
            </div>

            {(() => {
              const content = dailyTip.content[selectedLanguage] || dailyTip.content.English;
              const isSaved = savedTipIds.includes(dailyTip.id);
              const isFav = favoriteTipIds.includes(dailyTip.id);

              return (
                <div className="space-y-4">
                  {/* Title & Core Tip */}
                  <div className="space-y-2">
                    <h2 className="text-lg sm:text-xl font-extrabold text-white leading-snug">
                      {content.title}
                    </h2>
                    <div className="p-4 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-xs text-emerald-50 space-y-1">
                      <p className="text-[11px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1">
                        <Lightbulb className="w-4 h-4 text-amber-300" />
                        <span>Core Actionable Tip</span>
                      </p>
                      <p className="text-xs sm:text-sm font-bold leading-relaxed">{content.tip}</p>
                    </div>
                  </div>

                  {/* Detailed Explanation */}
                  <div className="p-4 rounded-2xl bg-black/20 border border-white/10 space-y-2 text-xs">
                    <p className="leading-relaxed text-slate-200">
                      <strong className="text-emerald-300 font-extrabold">Medical Rationale: </strong>
                      {content.explanation}
                    </p>

                    {/* Key Benefits */}
                    <div className="pt-2 border-t border-white/10 space-y-1">
                      <p className="text-[11px] font-bold text-emerald-300 uppercase tracking-wider">Proven Key Benefits:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-slate-100">
                        {content.benefits.map((benefit, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Footer Info & Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] pt-1">
                    <div className="flex flex-wrap items-center gap-3 text-slate-300 font-bold">
                      <div className="flex items-center gap-1 text-emerald-300">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Freq: {content.recommendedFrequency}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-300">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Source: {content.source}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <ReadAloudButton
                        id={`daily-tip-${dailyTip.id}`}
                        text={`${content.title}. ${content.tip}. Medical Rationale: ${content.explanation}. Key Benefits: ${content.benefits.join(', ')}.`}
                        language={selectedLanguage as PreferredLanguage}
                        variant="pill"
                        className="bg-white/20 hover:bg-white/30 text-white border border-white/20 rounded-xl"
                      />

                      <button
                        onClick={(e) => toggleFavoriteTip(dailyTip.id, e)}
                        className={`p-2 rounded-xl transition-all cursor-pointer ${
                          isFav ? 'bg-rose-600 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
                        }`}
                        title="Favorite"
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                      </button>

                      <button
                        onClick={(e) => toggleSaveTip(dailyTip.id, e)}
                        className={`p-2 rounded-xl transition-all cursor-pointer ${
                          isSaved ? 'bg-amber-500 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
                        }`}
                        title="Save for Later"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
                      </button>

                      <button
                        onClick={(e) => handleShareTip(dailyTip, e)}
                        className="px-3 py-1.5 bg-white text-slate-900 font-black rounded-xl hover:bg-slate-100 transition-all cursor-pointer flex items-center gap-1"
                      >
                        {copiedShareId === dailyTip.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                        <span>{copiedShareId === dailyTip.id ? 'Copied' : 'Share'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 1: CATEGORY GRID (HOME VIEW) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'categories' && !selectedCategory && !searchQuery && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                {selectedLanguage === 'Hindi'
                  ? 'स्वास्थ्य श्रेणियां (Health Categories)'
                  : selectedLanguage === 'Marathi'
                  ? 'आरोग्य श्रेणी निवडा (Health Categories)'
                  : 'Health Categories'}
              </h3>
              <span className="text-xs text-emerald-700 font-bold">15 Categories Available</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {TIP_CATEGORIES.map((cat) => {
                const title =
                  selectedLanguage === 'Hindi'
                    ? cat.nameHi
                    : selectedLanguage === 'Marathi'
                    ? cat.nameMr
                    : cat.nameEn;

                const desc =
                  selectedLanguage === 'Hindi'
                    ? cat.descriptionHi
                    : selectedLanguage === 'Marathi'
                    ? cat.descriptionMr
                    : cat.descriptionEn;

                const count = getTipsByCategory(cat.id).length;

                return (
                  <motion.div
                    key={cat.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => setSelectedCategory(cat)}
                    className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                  >
                    <div className="flex items-start gap-3.5">
                      <div
                        className={`w-11 h-11 rounded-2xl ${cat.iconBg} text-white flex items-center justify-center text-xl shadow-inner shrink-0 group-hover:scale-110 transition-transform`}
                      >
                        <span>{cat.emoji}</span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-emerald-700 transition-colors">
                            {title}
                          </h4>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed font-medium line-clamp-2">{desc}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${cat.badgeBg}`}>
                        {count > 0 ? `${count} Verified Tips` : 'Verified Tips'}
                      </span>

                      <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 2: CATEGORY FILTERED OR SEARCH OR SAVED CARDS LIST */}
        {/* ------------------------------------------------------------- */}
        {(selectedCategory || activeTab === 'saved' || searchQuery.trim().length > 0) && (
          <div className="space-y-4">
            {/* List Header */}
            <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                {selectedCategory ? (
                  <div className={`w-10 h-10 rounded-2xl ${selectedCategory.iconBg} text-white flex items-center justify-center text-xl shadow-xs`}>
                    <span>{selectedCategory.emoji}</span>
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl shadow-xs">
                    {activeTab === 'saved' ? <Bookmark className="w-5 h-5 text-amber-400 fill-amber-400" /> : <Search className="w-5 h-5" />}
                  </div>
                )}

                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">
                    {selectedCategory
                      ? selectedLanguage === 'Hindi'
                        ? selectedCategory.nameHi
                        : selectedLanguage === 'Marathi'
                        ? selectedCategory.nameMr
                        : selectedCategory.nameEn
                      : activeTab === 'saved'
                      ? 'Saved & Favorite Health Tips'
                      : `Search Results for "${searchQuery}"`}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Showing {displayedTips.length} medically verified health tips
                  </p>
                </div>
              </div>

              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  View All Categories
                </button>
              )}
            </div>

            {/* Empty state when no cards match */}
            {displayedTips.length === 0 && (
              <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <Info className="w-8 h-8" />
                </div>
                <h4 className="font-extrabold text-slate-800 text-sm">No Health Tips Found</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {activeTab === 'saved'
                    ? 'You have not bookmarked any Daily Health Tips yet. Click the heart or bookmark icon on any tip card to save it here.'
                    : 'Try searching with a keyword like "water", "sleep", "walking", "salt", or "immunity".'}
                </p>
              </div>
            )}

            {/* List of Health Tip Cards */}
            <div className="space-y-4">
              {displayedTips.map((tip) => {
                const content = tip.content[selectedLanguage] || tip.content.English;
                const cat = TIP_CATEGORIES.find((c) => c.id === tip.categoryId);
                const isSaved = savedTipIds.includes(tip.id);
                const isFav = favoriteTipIds.includes(tip.id);

                return (
                  <motion.div
                    key={tip.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-emerald-300 transition-all overflow-hidden"
                  >
                    <div className="p-5 space-y-3.5">
                      {/* Header Badge & Title */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                        {cat && (
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${cat.badgeBg}`}>
                            {cat.emoji} {selectedLanguage === 'Hindi' ? cat.nameHi : selectedLanguage === 'Marathi' ? cat.nameMr : cat.nameEn}
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                          <Award className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Medically Verified</span>
                        </span>
                      </div>

                      {/* Title */}
                      <h4 className="text-base font-extrabold text-slate-900 leading-snug">
                        {content.title}
                      </h4>

                      {/* Actionable Tip Box */}
                      <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-1">
                        <span className="text-[11px] font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                          <Lightbulb className="w-4 h-4 text-emerald-600" />
                          <span>💡 Health Tip</span>
                        </span>
                        <p className="text-xs sm:text-sm font-bold text-emerald-950 leading-relaxed">{content.tip}</p>
                      </div>

                      {/* Detailed Explanation */}
                      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                        <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                          <Info className="w-4 h-4 text-blue-600" />
                          <span>📖 Detailed Explanation</span>
                        </span>
                        <p className="text-xs text-slate-800 font-medium leading-relaxed">{content.explanation}</p>
                      </div>

                      {/* Key Benefits */}
                      <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
                        <span className="text-[11px] font-black uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-amber-600" />
                          <span> Key Benefits</span>
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          {content.benefits.map((benefit, idx) => (
                            <div key={idx} className="flex items-center gap-1.5 text-xs text-amber-950 font-bold">
                              <Check className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              <span>{benefit}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Frequency */}
                      <div className="flex items-center gap-2 text-xs text-slate-600 font-bold bg-slate-100 px-3.5 py-2 rounded-xl border border-slate-200">
                        <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Recommended Frequency: <span className="text-slate-900 font-extrabold">{content.recommendedFrequency}</span></span>
                      </div>
                    </div>

                    {/* Card Footer with Trusted Reference & Action Buttons */}
                    <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* TRUSTED MEDICAL SOURCE */}
                      <div className="flex items-center gap-1.5 text-slate-600 font-extrabold text-[11px]">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Source: <span className="text-slate-900">{content.source}</span></span>
                      </div>

                      {/* ACTIONS */}
                      <div className="flex items-center gap-2 ml-auto">
                        <button
                          onClick={(e) => toggleFavoriteTip(tip.id, e)}
                          className={`p-2 rounded-xl transition-all cursor-pointer border ${
                            isFav
                              ? 'bg-rose-600 text-white border-rose-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                          title="Favorite"
                        >
                          <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => toggleSaveTip(tip.id, e)}
                          className={`p-2 rounded-xl transition-all cursor-pointer border ${
                            isSaved
                              ? 'bg-amber-500 text-white border-amber-500'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                          title="Save for Later"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => handleShareTip(tip, e)}
                          className="px-3.5 py-2 bg-slate-900 hover:bg-black text-white font-black rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-[11px] shadow-2xs"
                        >
                          {copiedShareId === tip.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Share2 className="w-3.5 h-3.5 text-slate-300" />
                              <span>Share</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
