import React, { useState } from 'react';
import { ShieldCheck, UserCheck, Lock, X } from 'lucide-react';
import { UserRole, StoreProfile } from '../../types';

interface RoleSwitchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  storeProfile: StoreProfile;
}

export const RoleSwitchModal: React.FC<RoleSwitchModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onSelectRole,
  storeProfile,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [targetRole, setTargetRole] = useState<UserRole>(currentRole === 'OWNER' ? 'CASHIER' : 'OWNER');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSwitch = (e: React.FormEvent) => {
    e.preventDefault();
    if (targetRole === 'OWNER') {
      const correctPin = storeProfile.ownerPin || '1234';
      if (pinInput !== correctPin) {
        setErrorMsg('ভুল সিকিউরিটি পিন! ডিফল্ট পিন: 1234');
        return;
      }
    }
    onSelectRole(targetRole);
    setPinInput('');
    setErrorMsg('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
        
        <div className="flex justify-between items-center border-b border-slate-100 pb-2">
          <h3 className="font-bold text-slate-900 text-sm">ইউজার রোল ও এক্সেস কন্ট্রোল</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <button
            type="button"
            onClick={() => {
              setTargetRole('OWNER');
              setErrorMsg('');
            }}
            className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition ${
              targetRole === 'OWNER'
                ? 'border-amber-400 bg-amber-50 text-amber-950 font-bold'
                : 'border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ShieldCheck className="w-6 h-6 text-amber-600" />
            <span>দোকান মালিক (Admin)</span>
            <span className="text-[10px] text-slate-500 font-normal">সকল হিসাব ও লাভ দৃশ্যমান</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setTargetRole('CASHIER');
              setErrorMsg('');
            }}
            className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition ${
              targetRole === 'CASHIER'
                ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                : 'border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <UserCheck className="w-6 h-6 text-emerald-700" />
            <span>ক্যাশিয়ার (Staff)</span>
            <span className="text-[10px] text-slate-500 font-normal">শুধুমাত্র বিক্রয় ও মেমো প্রদান</span>
          </button>
        </div>

        <form onSubmit={handleSwitch} className="space-y-3 text-xs">
          {targetRole === 'OWNER' && (
            <div>
              <label className="block text-slate-700 font-semibold mb-1 flex items-center justify-between">
                <span>মালিকের সিকিউরিটি পিন দিন:</span>
                <span className="text-[10px] text-slate-400 font-normal">(ডিফল্ট: 1234)</span>
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="password"
                  maxLength={6}
                  value={pinInput}
                  onChange={(e) => {
                    setPinInput(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder="৪ ডিজিট পিন"
                  className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg font-mono text-center tracking-widest text-base"
                  required
                />
              </div>
            </div>
          )}

          {errorMsg && (
            <p className="text-[11px] text-red-600 font-semibold text-center">{errorMsg}</p>
          )}

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
            >
              নিশ্চিত করুন
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
