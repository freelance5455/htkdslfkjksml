import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Building2, 
  Users, 
  UtensilsCrossed, 
  Home, 
  Coins, 
  Wallet, 
  ArrowDownLeft, 
  X,
  CheckCircle2
} from 'lucide-react';

interface QuickEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type EntryType = 'attendance' | 'advance' | 'eng_payment' | 'mess_expense' | 'collection' | 'landlord_payment';

export const QuickEntryModal: React.FC<QuickEntryModalProps> = ({ isOpen, onClose }) => {
  const { 
    sites, 
    labours, 
    roomOwnerConfig, 
    selectedSiteId,
    addAttendanceRecord,
    addLabourAdvance,
    addEngineerPayment,
    addMessExpense,
    addMessCollection,
    addLandlordPayment 
  } = useApp();

  const [selectedType, setSelectedType] = useState<EntryType>('attendance');
  const [successMsg, setSuccessMsg] = useState(false);

  // Forms
  const [attForm, setAttForm] = useState({
    siteId: selectedSiteId || sites[0]?.id || '',
    labourId: labours[0]?.id || '',
    date: new Date().toISOString().slice(0, 10),
    daysWorked: 1,
    wageRate: labours[0]?.dailyWageRate || 650,
    note: ''
  });

  const [advForm, setAdvForm] = useState({
    siteId: selectedSiteId || sites[0]?.id || '',
    labourId: labours[0]?.id || '',
    date: new Date().toISOString().slice(0, 10),
    amount: 1500,
    paymentMethod: 'cash' as const,
    note: ''
  });

  const [engForm, setEngForm] = useState({
    siteId: selectedSiteId || sites[0]?.id || '',
    date: new Date().toISOString().slice(0, 10),
    amount: 25000,
    paymentMethod: 'bank' as const,
    receiptNo: '',
    note: ''
  });

  const [messExpForm, setMessExpForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    category: 'bazar' as const,
    title: '',
    amount: 1200,
    paidBy: 'মেস ম্যানেজার তহবিল',
    note: ''
  });

  const [colForm, setColForm] = useState({
    labourId: labours.find(l => l.roleType !== 'site_only')?.id || labours[0]?.id || '',
    type: 'meal_cost' as const,
    periodLabel: 'চলতি সপ্তাহ',
    date: new Date().toISOString().slice(0, 10),
    amount: 750,
    paymentMethod: 'cash' as const,
    note: ''
  });

  const [landlordForm, setLandlordForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    amount: 2500,
    forMonth: roomOwnerConfig.billingMonth,
    paymentMethod: 'cash' as const,
    receiptNo: '',
    note: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedType === 'attendance') {
      addAttendanceRecord({
        siteId: attForm.siteId,
        labourId: attForm.labourId,
        date: attForm.date,
        daysWorked: Number(attForm.daysWorked),
        wageRate: Number(attForm.wageRate),
        note: attForm.note
      });
    } else if (selectedType === 'advance') {
      addLabourAdvance({
        siteId: advForm.siteId,
        labourId: advForm.labourId,
        date: advForm.date,
        amount: Number(advForm.amount),
        paymentMethod: advForm.paymentMethod,
        note: advForm.note
      });
    } else if (selectedType === 'eng_payment') {
      addEngineerPayment({
        siteId: engForm.siteId,
        date: engForm.date,
        amount: Number(engForm.amount),
        paymentMethod: engForm.paymentMethod,
        receiptNo: engForm.receiptNo,
        note: engForm.note
      });
    } else if (selectedType === 'mess_expense') {
      addMessExpense({
        date: messExpForm.date,
        category: messExpForm.category,
        title: messExpForm.title || 'মেস বাজার খরচ',
        amount: Number(messExpForm.amount),
        paidBy: messExpForm.paidBy,
        note: messExpForm.note
      });
    } else if (selectedType === 'collection') {
      addMessCollection({
        labourId: colForm.labourId,
        type: colForm.type,
        periodLabel: colForm.periodLabel,
        date: colForm.date,
        amount: Number(colForm.amount),
        paymentMethod: colForm.paymentMethod,
        note: colForm.note
      });
    } else if (selectedType === 'landlord_payment') {
      addLandlordPayment({
        date: landlordForm.date,
        amount: Number(landlordForm.amount),
        forMonth: landlordForm.forMonth,
        paymentMethod: landlordForm.paymentMethod,
        receiptNo: landlordForm.receiptNo,
        note: landlordForm.note
      });
    }

    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        
        {/* হেডার */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-base font-bold text-slate-900">দ্রুত হিসাব এন্ট্রি (Quick Entry)</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* এন্ট্রি টাইপ বাটন গ্রিড */}
        <div className="grid grid-cols-3 gap-2 mt-3">
          {[
            { id: 'attendance', label: 'লেবার হাজিরা', icon: Users },
            { id: 'advance', label: 'লেবার অগ্রিম', icon: Wallet },
            { id: 'eng_payment', label: 'ইঞ্জিনিয়ার পেমেন্ট', icon: ArrowDownLeft },
            { id: 'mess_expense', label: 'মেস খরচ ভাউচার', icon: UtensilsCrossed },
            { id: 'collection', label: 'মিল/ভাড়া সংগ্রহ', icon: Coins },
            { id: 'landlord_payment', label: 'বাড়িওয়ালার কিস্তি', icon: Home },
          ].map(item => {
            const Icon = item.icon;
            const isSelected = selectedType === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedType(item.id as EntryType)}
                className={`p-2.5 rounded-lg border text-xs font-medium text-center transition-all flex flex-col items-center justify-center gap-1 ${
                  isSelected 
                    ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold shadow-xs' 
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-700' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* ফর্ম কনটেন্ট */}
        <form onSubmit={handleSubmit} className="space-y-3.5 mt-4 text-xs sm:text-sm">
          
          {/* ১. লেবার হাজিরা ফর্ম */}
          {selectedType === 'attendance' && (
            <>
              <div>
                <label className="block font-medium text-slate-700 mb-1">সাইট</label>
                <select
                  value={attForm.siteId}
                  onChange={e => setAttForm({ ...attForm, siteId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  {sites.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">লেবার নির্বাচন *</label>
                <select
                  required
                  value={attForm.labourId}
                  onChange={e => {
                    const lId = e.target.value;
                    const labour = labours.find(l => l.id === lId);
                    setAttForm({
                      ...attForm,
                      labourId: lId,
                      wageRate: labour?.dailyWageRate || attForm.wageRate
                    });
                  }}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  {labours.map(l => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.trade})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">কাজের দিন (Days)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    required
                    value={attForm.daysWorked}
                    onChange={e => setAttForm({ ...attForm, daysWorked: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">দৈনিক রেট (₹)</label>
                  <input
                    type="number"
                    required
                    value={attForm.wageRate}
                    onChange={e => setAttForm({ ...attForm, wageRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>
            </>
          )}

          {/* ২. লেবার অগ্রিম ফর্ম */}
          {selectedType === 'advance' && (
            <>
              <div>
                <label className="block font-medium text-slate-700 mb-1">লেবার নির্বাচন *</label>
                <select
                  required
                  value={advForm.labourId}
                  onChange={e => setAdvForm({ ...advForm, labourId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  {labours.map(l => (
                    <option key={l.id} value={l.id}>{l.name} ({l.trade})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">অগ্রিম টাকা (₹) *</label>
                  <input
                    type="number"
                    required
                    min="50"
                    step="50"
                    value={advForm.amount}
                    onChange={e => setAdvForm({ ...advForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-800"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={advForm.paymentMethod}
                    onChange={e => setAdvForm({ ...advForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="cash">নগদ (Cash)</option>
                    <option value="upi">UPI / অনলাইন</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* ৩. ইঞ্জিনিয়ার পেমেন্ট ফর্ম */}
          {selectedType === 'eng_payment' && (
            <>
              <div>
                <label className="block font-medium text-slate-700 mb-1">সাইট নির্বাচন *</label>
                <select
                  value={engForm.siteId}
                  onChange={e => setEngForm({ ...engForm, siteId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  {sites.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.engineerName})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                  <input
                    type="number"
                    required
                    min="500"
                    step="500"
                    value={engForm.amount}
                    onChange={e => setEngForm({ ...engForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-blue-300 rounded-lg font-mono font-bold text-blue-900 bg-blue-50/30"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={engForm.paymentMethod}
                    onChange={e => setEngForm({ ...engForm, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="bank">ব্যাংক ট্রান্সফার</option>
                    <option value="cheque">চেক</option>
                    <option value="upi">UPI</option>
                    <option value="cash">নগদ</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* ৪. মেস খরচ ফর্ম */}
          {selectedType === 'mess_expense' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ক্যাটাগরি *</label>
                  <select
                    value={messExpForm.category}
                    onChange={e => setMessExpForm({ ...messExpForm, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="bazar">কাঁচাবাজার</option>
                    <option value="gas">গ্যাস সিলিন্ডার</option>
                    <option value="cook_salary">বাবুর্চির বেতন</option>
                    <option value="electricity">বিদ্যুৎ বিল</option>
                    <option value="water_repairs">জল/মেরামত</option>
                    <option value="other">অন্যান্য</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                  <input
                    type="number"
                    required
                    min="10"
                    step="10"
                    value={messExpForm.amount}
                    onChange={e => setMessExpForm({ ...messExpForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">খরচের বিবরণ *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: সপ্তাহের চাল-ডাল ও সবজি"
                  value={messExpForm.title}
                  onChange={e => setMessExpForm({ ...messExpForm, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>
            </>
          )}

          {/* ৫. কালেকশন ফর্ম */}
          {selectedType === 'collection' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">সংগ্রহের ধরন</label>
                  <select
                    value={colForm.type}
                    onChange={e => setColForm({ ...colForm, type: e.target.value as any, amount: e.target.value === 'meal_cost' ? 750 : 1500 })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    <option value="meal_cost">সাপ্তাহিক খাবার খরচ</option>
                    <option value="room_rent">মাসিক রুম ভাড়া</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">লেবার *</label>
                  <select
                    value={colForm.labourId}
                    onChange={e => setColForm({ ...colForm, labourId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  >
                    {labours.filter(l => l.roleType !== 'site_only').map(l => (
                      <option key={l.id} value={l.id}>{l.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">টাকার পরিমাণ (₹) *</label>
                  <input
                    type="number"
                    required
                    value={colForm.amount}
                    onChange={e => setColForm({ ...colForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-emerald-800"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">পিরিয়ড</label>
                  <input
                    type="text"
                    value={colForm.periodLabel}
                    onChange={e => setColForm({ ...colForm, periodLabel: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </>
          )}

          {/* ৬. বাড়িওয়ালা কিস্তি ফর্ম */}
          {selectedType === 'landlord_payment' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">কিস্তির টাকা (₹) *</label>
                  <input
                    type="number"
                    required
                    min="100"
                    step="100"
                    value={landlordForm.amount}
                    onChange={e => setLandlordForm({ ...landlordForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-800"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">মাস</label>
                  <input
                    type="text"
                    value={landlordForm.forMonth}
                    onChange={e => setLandlordForm({ ...landlordForm, forMonth: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>
            </>
          )}

          {/* সেভ ও সাবমিট */}
          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium transition-colors flex items-center gap-1.5"
            >
              {successMsg ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>সংরক্ষিত!</span>
                </>
              ) : (
                <span>এন্ট্রি জমা দিন</span>
              )}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
