import { Subject, ExamType } from './types';

export interface SampleScan {
  id: string;
  title: string;
  subject: Subject;
  description: string;
  image: string; // base64 placeholder or sample descriptor
}

export const SAMPLE_SCANS: SampleScan[] = [
  {
    id: 'history-sample',
    title: 'পলাশীর যুদ্ধ (Battle of Plassey)',
    subject: 'History',
    description: 'ইতিহাস বইয়ের ১৭৫৭ সালের পলাশীর যুদ্ধের বিবরণ পৃষ্ঠা',
    image: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'science-sample',
    title: 'সালোকসংশ্লেষ প্রক্রিয়া (Photosynthesis)',
    subject: 'Science',
    description: 'বিজ্ঞান বইয়ের উদ্ভিদের খাদ্য তৈরি বা সালোকসংশ্লেষের অধ্যায়',
    image: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'math-sample',
    title: 'দ্বিঘাত সমীকরণ (Quadratic Equation)',
    subject: 'Mathematics',
    description: 'গণিত বইয়ের একচল বিশিষ্ট দ্বিঘাত সমীকরণের জটিল অংক',
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=600'
  }
];

export const SUBJECT_METADATA: { subject: Subject; icon: string; color: string; description: string }[] = [
  {
    subject: 'History',
    icon: 'BookOpen',
    color: 'from-amber-500 to-orange-600',
    description: 'ইতিহাসের সাল, ঘটনা ও রাজবংশের মজার গল্প'
  },
  {
    subject: 'Science',
    icon: 'FlaskConical',
    color: 'from-emerald-500 to-teal-600',
    description: 'জীববিদ্যা, পদার্থবিদ্যা ও রসায়নের রোমাঞ্চকর রহস্য'
  },
  {
    subject: 'Mathematics',
    icon: 'Calculator',
    color: 'from-blue-500 to-indigo-600',
    description: 'সহজ ধাপে অংক শেখা ও সমাধান করার কৌশল'
  },
  {
    subject: 'Geography',
    icon: 'Globe',
    color: 'from-sky-500 to-blue-600',
    description: 'পৃথিবী, বায়ুমণ্ডল ও জলবায়ুর মানচিত্র পাঠ'
  },
  {
    subject: 'Bengali',
    icon: 'Languages',
    color: 'from-rose-500 to-pink-600',
    description: 'মাতৃভাষার সাহিত্য, গল্প, কবিতা ও ব্যাকরণ'
  },
  {
    subject: 'English',
    icon: 'GraduationCap',
    color: 'from-violet-500 to-purple-600',
    description: 'Grammar, vocabulary & speaking skills'
  },
  {
    subject: 'Political Science',
    icon: 'Users',
    color: 'from-cyan-500 to-sky-600',
    description: 'সংবিধান, অধিকার ও শাসন ব্যবস্থার ধারণা'
  },
  {
    subject: 'Economics',
    icon: 'TrendingUp',
    color: 'from-green-500 to-emerald-600',
    description: 'অর্থনীতি, বাজার ও পঞ্চবার্ষিকী পরিকল্পনার গতিপথ'
  },
  {
    subject: 'Computer',
    icon: 'Cpu',
    color: 'from-slate-600 to-slate-800',
    description: 'প্রোগ্রামিং, হার্ডওয়্যার ও ইন্টারনেটের সহজ শিক্ষা'
  },
  {
    subject: 'Competitive Exams',
    icon: 'Award',
    color: 'from-yellow-500 to-amber-600',
    description: 'WBCS, SSC, PSC ও অন্যান্য চাকরির প্রস্তুতি'
  }
];

export const ACADEMIC_SUBJECTS = [
  'History',
  'Geography',
  'Political Science / Civics',
  'Economics',
  'General Science',
  'Physics',
  'Chemistry',
  'Biology',
  'Mathematics',
  'Environmental Science (EVS)',
  'Computer & IT',
  'English',
  'Hindi',
  'Bengali',
  'Assamese',
  'Odia',
  'Tamil',
  'Telugu',
  'Kannada',
  'Malayalam',
  'Marathi',
  'Gujarati',
  'Punjabi',
  'Urdu'
];

export const COMPETITIVE_SUBJECTS = [
  'General Knowledge (GK)',
  'Current Affairs',
  'Reasoning',
  'Logical Reasoning',
  'Quantitative Aptitude',
  'Indian History',
  'Indian Geography',
  'Indian Polity & Constitution',
  'Indian Economy',
  'Static GK',
  'Sports & Games',
  'Awards & Honors',
  'Books & Authors',
  'Important Days & Years',
  'Government Schemes',
  'Indian Culture & Heritage',
  'Indian Art & Literature',
  'Indian Rivers & Geography',
  'Indian States & Capitals',
  'Indian Monuments & Heritage Sites',
  'Indian National Parks & Wildlife',
  'Indian & International Organizations',
  'Science & Technology',
  'Space & ISRO',
  'Defence & Security',
  'Railway-related GK',
  'Banking & Financial Awareness',
  'Computer Awareness'
];

export const ALL_STANDARD_SUBJECTS = [
  ...ACADEMIC_SUBJECTS,
  ...COMPETITIVE_SUBJECTS
];

export const EXAM_SUBJECTS_MAP: Record<string, string[]> = {
  // Railway
  'RRB NTPC': ['Mathematics', 'Reasoning', 'General Knowledge', 'General Awareness', 'Current Affairs', 'General Science', 'Computer Awareness'],
  'RRB Group D': ['Mathematics', 'Reasoning', 'General Science', 'General Awareness', 'Current Affairs'],
  'RRB ALP': ['Mathematics', 'Reasoning', 'General Science', 'Basic Engineering & Trades', 'Current Affairs'],
  'RRB Technician': ['Mathematics', 'Reasoning', 'General Science', 'Trade Theory', 'Current Affairs'],
  'RRB JE': ['Mathematics', 'Reasoning', 'General Awareness', 'General Science', 'Technical Engineering', 'Current Affairs'],
  'RPF': ['Mathematics', 'Reasoning', 'General Knowledge', 'Current Affairs', 'General Science'],
  'Other Railway Exams': ['Mathematics', 'Reasoning', 'General Knowledge', 'General Awareness', 'Current Affairs', 'General Science'],

  // SSC
  'SSC CGL': ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'General Awareness', 'Current Affairs', 'English Language', 'Computer Knowledge'],
  'SSC CHSL': ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'Current Affairs', 'English Language'],
  'SSC MTS': ['Numerical Ability & Math', 'Reasoning', 'General Awareness', 'Current Affairs', 'English Language'],
  'SSC GD': ['Elementary Mathematics', 'Reasoning', 'General Knowledge', 'Current Affairs', 'English / Hindi'],
  'SSC CPO': ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'Current Affairs', 'English Comprehension'],
  'Other SSC Exams': ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'Current Affairs', 'English Language'],

  // Banking
  'IBPS PO': ['Quantitative Aptitude', 'Reasoning Ability', 'English Language', 'General Awareness', 'Banking & Financial Awareness', 'Computer Knowledge'],
  'IBPS Clerk': ['Numerical Ability', 'Reasoning Ability', 'English Language', 'General Awareness', 'Banking Awareness'],
  'SBI PO': ['Quantitative Aptitude', 'Reasoning Ability', 'English Language', 'General & Banking Awareness', 'Data Analysis & Interpretation'],
  'SBI Clerk': ['Quantitative Aptitude', 'Reasoning Ability', 'English Language', 'General Awareness', 'Financial Awareness'],
  'RRB Banking': ['Quantitative Aptitude', 'Reasoning Ability', 'English / Hindi Language', 'General Awareness', 'Computer Knowledge', 'Financial Awareness'],
  'Other Banking Exams': ['Quantitative Aptitude', 'Reasoning Ability', 'English Language', 'General Awareness', 'Banking Awareness'],

  // State Govt & PSC
  'WBCS': ['Indian History & Freedom Struggle', 'Geography of India & West Bengal', 'Indian Polity & Constitution', 'Indian Economy', 'General Science', 'Reasoning & Mental Ability', 'Current Affairs', 'English Language'],
  'WBPSC': ['General Knowledge', 'Current Affairs', 'Arithmetic & Math', 'Reasoning', 'Bengali Language', 'English Language'],
  'Food SI': ['Arithmetic & Mathematics', 'General Studies', 'Current Affairs', 'General Science'],
  'Clerkship': ['Arithmetic', 'General Studies', 'English', 'Bengali'],

  // Police & Defence
  'WB Police SI/Constable': ['General Knowledge & Awareness', 'Current Affairs', 'Elementary Mathematics', 'Logical Reasoning', 'English', 'Bengali'],
  'Kolkata Police': ['General Knowledge', 'Current Affairs', 'Mathematics', 'Reasoning', 'English'],
  'Police & Defence': ['General Knowledge', 'Current Affairs', 'Elementary Mathematics', 'Reasoning', 'English', 'Science'],
  'NDA / CDS': ['Mathematics', 'General Ability Test', 'English Language', 'Physics & Chemistry', 'General Knowledge & Current Affairs'],

  // Teaching
  'Primary TET & Teaching': ['Child Development & Pedagogy', 'Bengali Language', 'English Language', 'Mathematics', 'Environmental Studies (EVS)'],
  'Upper Primary TET': ['Child Development & Pedagogy', 'Bengali Language', 'English Language', 'Mathematics & Science', 'Social Studies'],
  'CTET': ['Child Development & Pedagogy', 'Language I (Bengali/Hindi)', 'Language II (English)', 'Mathematics', 'Environmental Studies / Social Science'],

  // School
  'Class 1-5 Primary': ['Bengali', 'English', 'Mathematics', 'Environmental Studies'],
  'Class 6-9': ['Physical Science', 'Life Science', 'Mathematics', 'History', 'Geography', 'Bengali', 'English'],
  'Class 10 / Madhyamik Board': ['Physical Science', 'Life Science', 'Mathematics', 'History', 'Geography', 'Bengali', 'English'],
  'Madhyamik': ['Physical Science', 'Life Science', 'Mathematics', 'History', 'Geography', 'Bengali', 'English'],
  'Higher Secondary': ['Physics', 'Chemistry', 'Mathematics', 'Biology', 'History', 'Political Science', 'Geography', 'Economics', 'English', 'Bengali'],
  'Class 11 - Class 12 / Higher Secondary (Science/Arts/Commerce)': ['Physics', 'Chemistry', 'Mathematics', 'Biology', 'History', 'Political Science', 'Geography', 'Economics', 'Accountancy', 'English', 'Bengali'],

  // College & Competitive
  'College Semester': ['Core Major Subject', 'Minor Subject', 'General Studies', 'Practical & Research', 'English Communication'],
  'University Exam': ['Core Postgraduate Module', 'Research Methodology', 'Specialized Elective', 'Project Work'],
  'UPSC Civil Services': ['Indian Polity & Governance', 'Indian History & Art/Culture', 'Geography & Environment', 'Indian Economy', 'General Science', 'CSAT Aptitude & Logic', 'Current Affairs'],
  'Private Job & Placement': ['Quantitative Aptitude', 'Logical Reasoning', 'Verbal Ability & English', 'Computer Science & Coding', 'HR & Interview Communication'],
  'Aptitude & Reasoning': ['Quantitative Aptitude', 'Logical Reasoning', 'Data Interpretation', 'Verbal Ability'],
  'Custom Exam': ['Mathematics', 'Reasoning', 'General Knowledge', 'Current Affairs', 'General Science', 'English', 'Bengali', 'Computer Awareness']
};

export function getExamSubjects(examName: string): string[] {
  if (EXAM_SUBJECTS_MAP[examName]) {
    return EXAM_SUBJECTS_MAP[examName];
  }
  // Fallback search
  for (const key of Object.keys(EXAM_SUBJECTS_MAP)) {
    if (examName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(examName.toLowerCase())) {
      return EXAM_SUBJECTS_MAP[key];
    }
  }
  return ['Mathematics', 'Reasoning', 'General Knowledge', 'General Awareness', 'Current Affairs', 'General Science', 'English', 'Computer Awareness'];
}

export const EXAM_CATEGORIES = [
  {
    id: 'school',
    title: { en: 'School Students', bn: 'স্কুল শিক্ষার্থী (Class 1 to Class 12)' },
    icon: 'GraduationCap',
    exams: [
      { id: 'Class 1-5 Primary', label: 'Primary School (Class 1 - Class 5)' },
      { id: 'Class 6-9', label: 'High School (Class 6 - Class 9)' },
      { id: 'Madhyamik', label: 'Class 10 / Madhyamik Board' },
      { id: 'Higher Secondary', label: 'Class 11 - Class 12 / Higher Secondary' }
    ]
  },
  {
    id: 'govt',
    title: { en: 'Government Jobs', bn: 'সরকারি চাকরি পরীক্ষা (Govt Jobs)' },
    icon: 'Building2',
    subCategories: [
      {
        id: 'railway',
        name: { en: 'Railway Exams', bn: 'রেলওয়ে পরীক্ষা (RRB)' },
        exams: ['RRB NTPC', 'RRB Group D', 'RRB ALP', 'RRB Technician', 'RRB JE', 'RPF', 'Other Railway Exams']
      },
      {
        id: 'ssc',
        name: { en: 'SSC Exams', bn: 'এসএসসি পরীক্ষা (SSC)' },
        exams: ['SSC CGL', 'SSC CHSL', 'SSC MTS', 'SSC GD', 'SSC CPO', 'Other SSC Exams']
      },
      {
        id: 'banking',
        name: { en: 'Banking Exams', bn: 'ব্যাংক পরীক্ষা (Banking)' },
        exams: ['IBPS PO', 'IBPS Clerk', 'SBI PO', 'SBI Clerk', 'RRB Banking', 'Other Banking Exams']
      },
      {
        id: 'state_govt',
        name: { en: 'State Govt & PSC', bn: 'রাজ্য সরকার ও পিএসসি (WBCS/WBPSC)' },
        exams: ['WBCS', 'WBPSC', 'Food SI', 'Clerkship']
      },
      {
        id: 'police',
        name: { en: 'Police & Defence', bn: 'পুলিশ ও ডিফেন্স (Police & Defence)' },
        exams: ['WB Police SI/Constable', 'Kolkata Police', 'NDA / CDS']
      },
      {
        id: 'teaching',
        name: { en: 'Teaching Exams', bn: 'শিক্ষক নিয়োগ (TET / Teaching)' },
        exams: ['Primary TET & Teaching', 'Upper Primary TET', 'CTET']
      },
      {
        id: 'other_govt',
        name: { en: 'UPSC & Central Govt', bn: 'ইউপিএসসি ও কেন্দ্রীয় পরীক্ষা' },
        exams: ['UPSC Civil Services']
      }
    ],
    exams: [
      { id: 'RRB NTPC', label: 'RRB NTPC' },
      { id: 'RRB Group D', label: 'RRB Group D' },
      { id: 'SSC CGL', label: 'SSC CGL' },
      { id: 'SSC CHSL', label: 'SSC CHSL' },
      { id: 'IBPS PO', label: 'IBPS PO' },
      { id: 'SBI PO', label: 'SBI PO' },
      { id: 'WBCS', label: 'WBCS (West Bengal Civil Service)' },
      { id: 'WB Police SI/Constable', label: 'WB Police SI & Constable' },
      { id: 'Primary TET & Teaching', label: 'Primary TET & Teaching' }
    ]
  },
  {
    id: 'college',
    title: { en: 'College / University', bn: 'কলেজ ও বিশ্ববিদ্যালয় (Graduation & PG)' },
    icon: 'BookOpen',
    exams: [
      { id: 'College Semester', label: 'Undergraduate Semester (BA / B.Sc / B.Com / B.Tech / BCA)' },
      { id: 'University Exam', label: 'Postgraduate (MA / M.Sc / M.Tech / MCA)' },
      { id: 'College Entrance', label: 'Entrance Exams (CUET, WBJEE, GATE, NET/SET)' }
    ]
  },
  {
    id: 'private',
    title: { en: 'Private Jobs & Placement', bn: 'প্রাইভেট চাকরি ও প্লেসমেন্ট' },
    icon: 'Briefcase',
    exams: [
      { id: 'Private Job & Placement', label: 'IT & Corporate Job Placement' },
      { id: 'Aptitude & Reasoning', label: 'Quantitative Aptitude & Logical Reasoning' },
      { id: 'Interview Prep', label: 'Technical & HR Mock Interview Preparation' }
    ]
  },
  {
    id: 'custom',
    title: { en: 'Competitive / Custom Exam', bn: 'কাস্টম ও অন্যান্য প্রতিযোগিতা' },
    icon: 'Sparkles',
    exams: [
      { id: 'Custom Exam', label: 'Custom Target Exam (Custom Subjects)' }
    ]
  }
];

export const EXAM_PREPS: { exam: ExamType | string; description: string; syllabus: string[] }[] = [
  {
    exam: 'Madhyamik',
    description: 'পশ্চিমবঙ্গ মধ্যশিক্ষা পর্ষদ (WBBSE) দশম শ্রেণীর মাধ্যমিক পরীক্ষা।',
    syllabus: ['ভৌত বিজ্ঞান ও জীবন বিজ্ঞান', 'ইতিহাস ও ভূগোল', 'পাটিগণিত, বীজগণিত ও জ্যামিতি', 'বাংলা ও ইংরেজি সাহিত্য']
  },
  {
    exam: 'Higher Secondary',
    description: 'উচ্চমাধ্যমিক (WBCHSE / CBSE / ISC) একাদশ ও দ্বাদশ শ্রেণীর ফাইনাল পরীক্ষা।',
    syllabus: ['বিজ্ঞান (Physics, Chem, Math, Bio)', 'কলা (History, Pol Sci, Geography, Phil)', 'বাণিজ্য (Accounts, Business, Eco)', 'বাধ্যতামূলক বাংলা ও ইংরেজি']
  },
  {
    exam: 'RRB NTPC',
    description: 'ভারতীয় রেলওয়ে নিয়োগ বোর্ডের (RRB) নন-টেকনিক্যাল পপুলার ক্যাটাগরি (NTPC) পরীক্ষা।',
    syllabus: ['Mathematics (পাটিগণিত, বীজগণিত, জ্যামিতি)', 'General Intelligence & Reasoning', 'General Awareness & Current Affairs', 'General Science']
  },
  {
    exam: 'RRB Group D',
    description: 'ভারতীয় রেলওয়ে নিয়োগ বোর্ডের Group D নিয়োগ পরীক্ষা।',
    syllabus: ['General Science (পদার্থ, রসায়ন, জীবনবিজ্ঞান)', 'Mathematics', 'General Intelligence & Reasoning', 'Current Affairs']
  },
  {
    exam: 'SSC CGL',
    description: 'Staff Selection Commission - Combined Graduate Level Exam (CGL).',
    syllabus: ['Quantitative Aptitude & Advance Math', 'General Intelligence & Logical Reasoning', 'English Language & Comprehension', 'General Awareness & Computer']
  },
  {
    exam: 'SSC CHSL',
    description: 'Staff Selection Commission - Combined Higher Secondary Level (CHSL).',
    syllabus: ['Quantitative Aptitude', 'General Intelligence & Reasoning', 'English Language', 'General Awareness & Current Affairs']
  },
  {
    exam: 'IBPS PO',
    description: 'Institute of Banking Personnel Selection - Probationary Officer (PO).',
    syllabus: ['Quantitative Aptitude & Data Interpretation', 'Reasoning Ability & Puzzles', 'English Language', 'Banking & Financial Awareness']
  },
  {
    exam: 'SBI PO',
    description: 'State Bank of India - Probationary Officer Examination.',
    syllabus: ['Quantitative Aptitude & Data Analysis', 'Reasoning Ability & Critical Reasoning', 'English Language', 'General & Banking Awareness']
  },
  {
    exam: 'WBCS',
    description: 'West Bengal Civil Service (Exe.) - পশ্চিমবঙ্গ সিভিল সার্ভিস।',
    syllabus: ['ভারতের ইতিহাস ও স্বাধীনতা সংগ্রাম', 'পশ্চিমবঙ্গের ভূগোল ও ভারতের ভূগোল', 'ভারতের সংবিধান ও অর্থনীতি', 'সাধারণ বিজ্ঞান & রিজনিং']
  },
  {
    exam: 'WB Police SI/Constable',
    description: 'পশ্চিমবঙ্গ পুলিশ SI ও কনস্টেবল নিয়োগ পরীক্ষা।',
    syllabus: ['General Knowledge & Current Affairs', 'Elementary Mathematics', 'Reasoning & Mental Ability', 'English & Vernacular Language']
  },
  {
    exam: 'Primary TET & Teaching',
    description: 'প্রাথমিক ও উচ্চ প্রাথমিক শিক্ষক শিক্ষিকা নিয়োগ (WB TET, CTET)।',
    syllabus: ['শিশু মনস্তত্ত্ব ও শিখন বিজ্ঞান (Child Development)', 'প্রথম ও দ্বিতীয় ভাষা (বাংলা/ইংরেজি)', 'পরিবেশ বিদ্যা (EVS) ও গণিত শিক্ষা']
  },
  {
    exam: 'Private Job & Placement',
    description: 'প্রাইভেট আইটি, কর্পোরেট চাকরি ও ক্যাম্পাস ইন্টারভিউ প্লেসমেন্ট।',
    syllabus: ['Quantitative Aptitude & Problem Solving', 'Logical Reasoning & Coding Logic', 'Verbal English & Grammar', 'Interview & HR Communication']
  },
  {
    exam: 'Custom Exam',
    description: 'আপনার সুবিধামতো কাস্টম টার্গেট পরীক্ষা ও বিষয় তালিকা।',
    syllabus: ['কাস্টম সিলেবাস', 'এআই মক টেস্ট', 'দৈনিক পড়াশোনার রুটিন']
  }
];

export const DEFAULT_USER_PROFILE = {
  name: 'Rahul',
  role: 'user' as const,
  category: 'govt' as const,
  subCategory: 'railway',
  qualification: 'Graduate',
  boardOrUniversity: 'RRB Board',
  targetExam: 'RRB NTPC',
  selectedSubjects: ['Reasoning', 'General Knowledge', 'Current Affairs'],
  dailyQuestionTarget: 100,
  targetYear: '2026',
  examDate: '2026-09-15',
  dailyStudyTimeMinutes: 120,
  currentLevel: 'Intermediate' as const,
  preferredLanguage: 'en' as const,
  parentPin: '',
  notificationsEnabled: true,
  theme: 'light' as const,
  onboardingCompleted: false,
  streakDays: 7,
  lastActiveDate: new Date().toISOString().split('T')[0],
  isPro: false,
  proPlan: undefined,
  proExpiryDate: undefined,
  proOrderId: undefined
};

export const INITIAL_STUDY_PLAN_EN = [
  {
    id: 'p1',
    day: 'Monday',
    time: '07:00 AM - 09:00 AM',
    subject: 'Science' as Subject,
    topic: 'Photosynthesis & Plant Physiological Processes',
    completed: true
  },
  {
    id: 'p2',
    day: 'Tuesday',
    time: '08:00 AM - 10:00 AM',
    subject: 'Mathematics' as Subject,
    topic: 'Solving Quadratic Equations in One Variable',
    completed: false
  },
  {
    id: 'p3',
    day: 'Wednesday',
    time: '06:00 PM - 08:00 PM',
    subject: 'History' as Subject,
    topic: 'Battle of Plassey (1757) and Historical Impacts',
    completed: false
  },
  {
    id: 'p4',
    day: 'Thursday',
    time: '08:00 AM - 10:00 AM',
    subject: 'Geography' as Subject,
    topic: 'Major River Systems & Climate Features',
    completed: false
  }
];

export const INITIAL_STUDY_PLAN = [
  {
    id: 'p1',
    day: 'সোমবার',
    time: 'সকাল ০৭:০০ - ০৯:০০',
    subject: 'Science' as Subject,
    topic: 'সালোকসংশ্লেষ ও উদ্ভিদের শারীরবৃত্তীয় প্রক্রিয়া',
    completed: true
  },
  {
    id: 'p2',
    day: 'মঙ্গলবার',
    time: 'সকাল ০৮:০০ - ১০:০০',
    subject: 'Mathematics' as Subject,
    topic: 'একচল বিশিষ্ট দ্বিঘাত সমীকরণের মূল নির্ণয়',
    completed: false
  },
  {
    id: 'p3',
    day: 'বুধবার',
    time: 'সন্ধ্যা ০৬:০০ - ০৮:০০',
    subject: 'History' as Subject,
    topic: '১৭৫৭ সালের পলাশীর যুদ্ধ এবং এর ঐতিহাসিক ফলাফল',
    completed: false
  },
  {
    id: 'p4',
    day: 'বৃহস্পতিবার',
    time: 'সকাল ০৮:০০ - ১০:০০',
    subject: 'Geography' as Subject,
    topic: 'পশ্চিমবঙ্গের নদনদী ও জলবায়ুর বৈশিষ্ট্য',
    completed: false
  }
];

export const SAMPLE_MINDMAP = {
  nodes: [
    { id: '1', label: 'সালোকসংশ্লেষ', description: 'উদ্ভিদের খাদ্য তৈরির জৈব রাসায়নিক প্রক্রিয়া', type: 'root' },
    { id: '2', label: 'প্রয়োজনীয় উপাদান', description: 'যা ছাড়া সালোকসংশ্লেষ অসম্ভব', type: 'main' },
    { id: '3', label: 'পদ্ধতি বা পর্যায়', description: 'আলোক দশা ও অন্ধকার দশা', type: 'main' },
    { id: '4', label: 'গুরুত্ব', description: 'পরিবেশে সালোকসংশ্লেষের অবদান', type: 'main' },
    { id: '5', label: 'সূর্যালোক ও ক্লোরোফিল', description: 'শক্তির উৎস ও শোষক', type: 'sub' },
    { id: '6', label: 'জল ও কার্বন ডাইঅক্সাইড', description: 'কাঁচামাল', type: 'sub' },
    { id: '7', label: 'আলোক দশা', description: 'গ্রানা অঞ্চলে ঘটে, আলোর উপস্থিতি জরুরি', type: 'sub' },
    { id: '8', label: 'অন্ধকার দশা', description: 'স্ট্রোমা অঞ্চলে ঘটে, আলো ছাড়াই সম্ভব', type: 'sub' },
    { id: '9', label: 'অক্সিজেন নির্গমন', description: 'প্রাণীকুলের জন্য প্রাণবায়ু সরবরাহ', type: 'sub' },
    { id: '10', label: 'খাদ্য তৈরি', description: 'গ্লুকোজ বা শর্করা জাতীয় খাদ্যের স্থিতি', type: 'sub' }
  ],
  edges: [
    { from: '1', to: '2' },
    { from: '1', to: '3' },
    { from: '1', to: '4' },
    { from: '2', to: '5' },
    { from: '2', to: '6' },
    { from: '3', to: '7' },
    { from: '3', to: '8' },
    { from: '4', to: '9' },
    { from: '4', to: '10' }
  ]
};

// Exactly 3 Supported Languages: 1. English (Global Language), 2. Indian Bengali, 3. Hindi
export const INDIAN_LANGUAGES = [
  { code: 'en', label: 'English (Global Language)', nativeName: 'English' },
  { code: 'bn', label: 'ভারতীয় বাংলা (Indian Bengali)', nativeName: 'বাংলা' },
  { code: 'hi', label: 'हिन्दी (Hindi)', nativeName: 'हिन्दी' }
] as const;

