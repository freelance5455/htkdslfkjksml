import test from 'node:test';
import assert from 'node:assert/strict';
import { formatearBytes, formatearFecha, generarNombreFoto } from './storage';

test('formatearBytes formatea unidades correctamente', () => {
  assert.equal(formatearBytes(0), '0 B');
  assert.equal(formatearBytes(1024), '1 KB');
  assert.equal(formatearBytes(1024 * 1024 * 3.5), '3.5 MB');
});

test('generarNombreFoto genera nombre con prefijo IMG_ y extension .jpg', () => {
  const nombre = generarNombreFoto();
  assert.match(nombre, /^IMG_\d{8}_\d{6}\.jpg$/);
});

test('formatearFecha formatea fecha con dia, mes, anio y hora', () => {
  const timestamp = new Date(2026, 10, 3, 9, 30).getTime();
  const fechaStr = formatearFecha(timestamp);
  assert.match(fechaStr, /^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/);
});

test('validacion de nombres de carpetas rechaza caracteres no permitidos y vacios', () => {
  const validarNombre = (nombre: string, existentes: string[]): string | null => {
    const n = nombre.trim();
    if (n.length === 0) return 'El nombre no puede estar vacío';
    if (/[/\\:*?"<>|.]/.test(n)) return 'Caracteres no permitidos';
    if (existentes.some((e) => e.toLowerCase() === n.toLowerCase())) {
      return 'Ya existe una carpeta con ese nombre';
    }
    return null;
  };

  assert.equal(validarNombre('', []), 'El nombre no puede estar vacío');
  assert.equal(validarNombre('   ', []), 'El nombre no puede estar vacío');
  assert.equal(validarNombre('Placa/123', []), 'Caracteres no permitidos');
  assert.equal(validarNombre('Placa*Auto', []), 'Caracteres no permitidos');
  assert.equal(validarNombre('Placa ABC-123', ['placa abc-123']), 'Ya existe una carpeta con ese nombre');
  assert.equal(validarNombre('Placa XYZ-999', ['Placa ABC-123']), null);
});
