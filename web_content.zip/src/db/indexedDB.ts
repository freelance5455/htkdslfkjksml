/**
 * IndexedDB persistence layer for Sales & Logistics Mobile App
 * Direct Native IndexedDB: 100% offline, zero external CDN or cloud lock-in
 */

export interface Product {
  id: string;
  code: string;
  name: string;
  price: number;
  cost: number;
  barcode: string;
  minQty: number;
  group: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  dayOfWeek: string;
  balance: number;
  lat: number | null;
  lng: number | null;
  locationAccuracy?: number;
  locationSavedAt?: string;
  lastVisit: string | null;
  active: boolean;
  notes: string;
}

export interface Visit {
  id: string;
  customerId: string;
  customerName?: string;
  date: string; // YYYY-MM-DD
  status: 'تمت الزيارة' | 'لم تتم - المحل مغلق' | 'مؤجلة' | string;
  notes: string;
  timestamp: string;
}

export interface Invoice {
  id: string;
  invoiceNo: string;
  customerId: string;
  customerName: string;
  date: string; // ISO
  payType: 'كاش' | 'آجل' | 'جزئي';
  requestedPayType?: string;
  subtotal: number;
  monthlyDiscountRate: number;
  monthlyDiscountValue: number;
  grandTotal: number;
  paidAmount: number;
  remainingAmount: number;
  syncStatus: 'pending' | 'synced';
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  productId: string;
  name: string;
  price: number;
  qty: number;
  itemDiscount: number;
  lineTotal: number;
}

export interface ReturnRecord {
  id: string;
  returnNo: string;
  customerId: string;
  customerName?: string;
  date: string;
  amount: number;
  invoiceNo: string;
  reason: string;
  type: 'سليم' | 'تالف' | 'منتهي' | 'خطأ توريد' | string;
  destination: 'السيارة' | 'المخزن' | string;
  productId: string;
  qty: number;
  refundType: 'آجل' | 'كاش' | string;
  syncStatus: 'pending' | 'synced';
}

export interface VanInventoryItem {
  productId: string;
  qty: number;
}

export interface MainInventoryItem {
  productId: string;
  qty: number;
  updatedAt?: string;
}

export interface PaymentRecord {
  id: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  date: string;
  amount: number;
  notes: string;
}

export interface TreasuryMove {
  id: string;
  date: string;
  type: 'إيراد' | 'مصروف';
  amount: number;
  notes: string;
}

export interface SettingItem {
  key: string;
  value: string | number;
}

export interface DayClosing {
  date: string; // YYYY-MM-DD
  closed: boolean;
  closedAt: string;
  sales: number;
  returns: number;
  visits: number;
}

export interface ChangeLogItem {
  id: string;
  table: string;
  action: string;
  data: unknown;
  timestamp: string;
  synced: boolean;
}

const DB_NAME = 'SalesLogisticsProDB';
const DB_VERSION = 3;

const STORES: Record<string, string> = {
  users: 'id',
  customers: 'id',
  visits: 'id',
  invoices: 'id',
  invoiceItems: 'id',
  returns: 'id',
  returnItems: 'id',
  products: 'id',
  vanInventory: 'productId',
  mainInventory: 'productId',
  vanLoadRequests: 'id',
  payments: 'id',
  treasuryMoves: 'id',
  settings: 'key',
  dayClosings: 'date',
  changeLog: 'id',
};

let dbInstance: IDBDatabase | null = null;

export function openDatabase(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      for (const [storeName, keyPath] of Object.entries(STORES)) {
        if (!db.objectStoreNames.contains(storeName)) {
          db.createObjectStore(storeName, { keyPath });
        }
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onerror = () => reject(request.error);
  });
}

export async function getAll<T>(storeName: string): Promise<T[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

export async function getById<T>(storeName: string, key: IDBValidKey): Promise<T | undefined> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

export async function putItem<T>(storeName: string, item: T): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteItem(storeName: string, key: IDBValidKey): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function clearStore(storeName: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function generateUID(prefix = ''): string {
  const rand = Math.random().toString(36).substring(2, 8);
  const time = Date.now().toString(36);
  return prefix ? `${prefix}-${time}-${rand}` : `${time}-${rand}`;
}

export async function logChange(table: string, action: string, data: unknown): Promise<void> {
  const item: ChangeLogItem = {
    id: generateUID('LOG'),
    table,
    action,
    data,
    timestamp: new Date().toISOString(),
    synced: false,
  };
  await putItem('changeLog', item);
}

/**
 * Seed initial catalog, route customers, settings and inventory
 */
export async function seedInitialDataIfNeeded(): Promise<void> {
  const existingProducts = await getAll<Product>('products');
  if (existingProducts.length === 0) {
    const seedProducts: Array<[string, string, string, number, string, number, number, number, string]> = [
      ['P1', 'PROD-01', 'زيت طعام ممتاز 1 لتر', 65, '622001', 20, 500, 52, 'بقالة'],
      ['P2', 'PROD-02', 'أرز فاخر 5 كجم', 180, '622002', 20, 300, 150, 'بقالة'],
      ['P3', 'PROD-03', 'سكر نقي 1 كجم', 35, '622003', 30, 1000, 28, 'بقالة'],
      ['P4', 'PROD-04', 'مكرونة 400 جرام', 15, '622004', 40, 800, 11, 'معلبات'],
      ['P5', 'PROD-05', 'حليب كامل الدسم 1 لتر', 42, '622005', 25, 400, 34, 'ألبان'],
      ['P6', 'PROD-06', 'عصير برتقال طبيعي 1 لتر', 32, '622006', 15, 350, 24, 'مشروبات'],
      ['P7', 'PROD-07', 'مسحوق غسيل أوتوماتيك 2.5 كجم', 145, '622007', 15, 200, 118, 'منظفات'],
      ['P8', 'PROD-08', 'بسكويت ويفر بالشوكولاتة (علبة)', 75, '622008', 20, 250, 58, 'حلويات'],
    ];

    for (const p of seedProducts) {
      const prod: Product = {
        id: p[0],
        code: p[1],
        name: p[2],
        price: p[3],
        barcode: p[4],
        minQty: p[5],
        cost: p[7],
        group: p[8],
      };
      await putItem('products', prod);
      await putItem('vanInventory', { productId: p[0], qty: Math.floor(p[6] / 10) });
      await putItem('mainInventory', { productId: p[0], qty: p[6], updatedAt: new Date().toISOString() });
    }
  }

  // Check customer count per day (Sat - Thu)
  const routeDays = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];
  const existingCustomers = await getAll<Customer>('customers');
  
  if (existingCustomers.length === 0) {
    let count = 1;
    for (const day of routeDays) {
      for (let i = 1; i <= 50; i++) {
        const id = `CST-${count.toString().padStart(3, '0')}`;
        await putItem('customers', {
          id,
          name: `ماركت ${day === 'السبت' ? 'النور' : day === 'الأحد' ? 'البركة' : day === 'الإثنين' ? 'السلام' : day === 'الثلاثاء' ? 'الأمانة' : day === 'الأربعاء' ? 'الهدى' : 'الفرقان'} - ${day} (${i})`,
          phone: `010${(count + 1000000).toString().slice(1)}`,
          address: `حي الزهور - شارع التجاري رقم ${i}`,
          dayOfWeek: day,
          balance: i % 4 === 0 ? (i * 120) : 0,
          lat: 30.0444 + (Math.random() - 0.5) * 0.05,
          lng: 31.2357 + (Math.random() - 0.5) * 0.05,
          locationAccuracy: 12,
          lastVisit: i % 3 === 0 ? '2026-10-15' : null,
          active: true,
          notes: i % 5 === 0 ? 'عميل مميز - يفضل الزيارة الصباحية' : '',
        } as Customer);
        count++;
      }
    }
  }

  // Ensure default Settings
  const defaults: Array<[string, string | number]> = [
    ['companyName', 'شركة البركة للتوزيع واللوجستيات'],
    ['companyPhone', '0123456789'],
    ['companyAddress', 'القاهرة - المنطقة الصناعية والتوزيع'],
    ['taxNo', '300-455-901'],
    ['receiptFooter', 'شكراً لتعاملكم معنا • خدمة العملاء 19888'],
    ['monthlyDiscountRate', 5],
    ['dailyTarget', 15000],
    ['monthlyTarget', 350000],
    ['vanSafetyThreshold', 15],
    ['group1', 'بقالة'],
    ['group2', 'مشروبات'],
    ['group3', 'ألبان'],
    ['group4', 'حلويات'],
    ['group5', 'منظفات'],
    ['group6', 'معلبات'],
    ['group7', 'ورقيات'],
    ['group8', 'مجمدات'],
    ['group9', 'عناية شخصية'],
    ['group10', 'أخرى'],
  ];

  for (const [key, value] of defaults) {
    const cur = await getById<SettingItem>('settings', key);
    if (!cur) {
      await putItem('settings', { key, value });
    }
  }

  // Seed sample visits for today if visits table is empty
  const existingVisits = await getAll<Visit>('visits');
  const todayStr = new Date().toISOString().slice(0, 10);
  if (existingVisits.length === 0) {
    const custs = await getAll<Customer>('customers');
    if (custs.length >= 6) {
      const sampleStatuses = [
        { status: 'تمت الزيارة', notes: 'تمت مقابلة المشتري واعتماد طلبية أسبوعية' },
        { status: 'تمت الزيارة', notes: 'سداد دفعة نقدية مع استلام الفاتورة' },
        { status: 'لم تتم - المحل مغلق', notes: 'المحل مغلق وقت المرور، تم التواصل هاتفياً' },
        { status: 'تمت الزيارة', notes: 'تم تسليم فاتورة البقالة والمنظفات بالكامل' },
        { status: 'مؤجلة', notes: 'طلب إعادة المرور بعد العصر لتوفر السيولة' },
        { status: 'تمت الزيارة', notes: 'زيارة ترويجية وعرض أصناف جديدة' },
      ];
      for (let i = 0; i < sampleStatuses.length; i++) {
        const c = custs[i];
        await putItem('visits', {
          id: `VIS-INIT-0${i + 1}`,
          customerId: c.id,
          customerName: c.name,
          date: todayStr,
          status: sampleStatuses[i].status,
          notes: sampleStatuses[i].notes,
          timestamp: new Date(Date.now() - (6 - i) * 3600000).toISOString(),
        });
      }
    }
  }

  // Seed sample invoices for today if invoices table is empty
  const existingInvoices = await getAll<Invoice>('invoices');
  if (existingInvoices.length === 0) {
    const custs = await getAll<Customer>('customers');
    const prods = await getAll<Product>('products');
    if (custs.length >= 2 && prods.length >= 3) {
      // Invoice 1: Cash
      const inv1Id = 'INV-INIT-001';
      const inv1: Invoice = {
        id: inv1Id,
        invoiceNo: 'INV-2026-101',
        customerId: custs[0].id,
        customerName: custs[0].name,
        date: new Date(Date.now() - 7200000).toISOString(),
        payType: 'كاش',
        subtotal: 1250,
        monthlyDiscountRate: 5,
        monthlyDiscountValue: 62.5,
        grandTotal: 1187.5,
        paidAmount: 1187.5,
        remainingAmount: 0,
        syncStatus: 'synced',
      };
      await putItem('invoices', inv1);
      await putItem('invoiceItems', {
        id: 'ITEM-INIT-001',
        invoiceId: inv1Id,
        productId: prods[0].id,
        name: prods[0].name,
        qty: 10,
        price: prods[0].price,
        itemDiscount: 0,
        lineTotal: prods[0].price * 10,
      });
      await putItem('invoiceItems', {
        id: 'ITEM-INIT-002',
        invoiceId: inv1Id,
        productId: prods[1].id,
        name: prods[1].name,
        qty: 5,
        price: prods[1].price,
        itemDiscount: 0,
        lineTotal: prods[1].price * 5,
      });
      await putItem('treasuryMoves', {
        id: 'TR-INIT-001',
        date: new Date(Date.now() - 7200000).toISOString(),
        type: 'إيراد',
        amount: 1187.5,
        notes: `مبيعات نقدية فاتورة ${inv1.invoiceNo} - ${custs[0].name}`,
      });

      // Invoice 2: Partial/Credit
      const inv2Id = 'INV-INIT-002';
      const inv2: Invoice = {
        id: inv2Id,
        invoiceNo: 'INV-2026-102',
        customerId: custs[1].id,
        customerName: custs[1].name,
        date: new Date(Date.now() - 3600000).toISOString(),
        payType: 'جزئي',
        subtotal: 2100,
        monthlyDiscountRate: 5,
        monthlyDiscountValue: 105,
        grandTotal: 1995,
        paidAmount: 1000,
        remainingAmount: 995,
        syncStatus: 'synced',
      };
      await putItem('invoices', inv2);
      await putItem('invoiceItems', {
        id: 'ITEM-INIT-003',
        invoiceId: inv2Id,
        productId: prods[2].id,
        name: prods[2].name,
        qty: 15,
        price: prods[2].price,
        itemDiscount: 0,
        lineTotal: prods[2].price * 15,
      });
      await putItem('treasuryMoves', {
        id: 'TR-INIT-002',
        date: new Date(Date.now() - 3600000).toISOString(),
        type: 'إيراد',
        amount: 1000,
        notes: `دفعة نقدية مسددة من فاتورة ${inv2.invoiceNo} - ${custs[1].name}`,
      });
      await putItem('payments', {
        id: 'PAY-INIT-001',
        customerId: custs[1].id,
        customerName: custs[1].name,
        date: new Date(Date.now() - 3600000).toISOString(),
        amount: 1000,
        notes: `سداد جزئي لفاتورة ${inv2.invoiceNo}`,
      });
    }
  }
}

/**
 * Fetch 10 custom category groups
 */
export async function getGroups(): Promise<string[]> {
  const groups: string[] = [];
  for (let i = 1; i <= 10; i++) {
    const setting = await getById<SettingItem>('settings', `group${i}`);
    groups.push(setting ? String(setting.value).trim() : `مجموعة ${i}`);
  }
  return groups;
}

/**
 * Check if today is closed
 */
export async function isDayClosed(dateString: string): Promise<boolean> {
  const closing = await getById<DayClosing>('dayClosings', dateString);
  return !!closing?.closed;
}

/**
 * Backup entire DB to JSON
 */
export async function exportDatabaseBackup(): Promise<string> {
  const dbData: Record<string, unknown> = {
    version: 3,
    exportedAt: new Date().toISOString(),
  };

  for (const store of Object.keys(STORES)) {
    dbData[store] = await getAll(store);
  }

  return JSON.stringify(dbData, null, 2);
}

/**
 * Restore DB from JSON
 */
export async function importDatabaseBackup(jsonContent: string): Promise<void> {
  const data = JSON.parse(jsonContent);
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON backup file');
  }

  for (const store of Object.keys(STORES)) {
    if (Array.isArray(data[store])) {
      await clearStore(store);
      for (const item of data[store]) {
        await putItem(store, item);
      }
    }
  }
}
