import { SubjectCategory, Topic, Flashcard, MotivationalReminder } from '../types';
import { INITIAL_CATEGORIES, INITIAL_TOPICS, INITIAL_REMINDERS } from '../data/initialData';

const DB_NAME = 'RecallCurve_RoomDB';
const DB_VERSION = 1;

export interface DeviceSettings {
  theme: 'light' | 'dark';
  timerDurationMinutes: number;
  breakDurationMinutes: number;
  soundEnabled: boolean;
  dailyReviewGoal: number;
}

export const DEFAULT_DEVICE_SETTINGS: DeviceSettings = {
  theme: 'light',
  timerDurationMinutes: 25,
  breakDurationMinutes: 5,
  soundEnabled: true,
  dailyReviewGoal: 10,
};

/**
 * SharedPreferences implementation for simple on-device settings.
 * Uses persistent client-side key-value storage without any cloud backend.
 */
export const SharedPreferences = {
  getSettings(): DeviceSettings {
    try {
      if (typeof window === 'undefined') return DEFAULT_DEVICE_SETTINGS;
      const raw = localStorage.getItem('shared_preferences_settings');
      if (!raw) return DEFAULT_DEVICE_SETTINGS;
      return { ...DEFAULT_DEVICE_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return DEFAULT_DEVICE_SETTINGS;
    }
  },

  setSettings(settings: Partial<DeviceSettings>): DeviceSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem('shared_preferences_settings', JSON.stringify(updated));
      }
    } catch {
      // storage quota fallback
    }
    return updated;
  },

  getItem<T>(key: string, fallback: T): T {
    try {
      if (typeof window === 'undefined') return fallback;
      const val = localStorage.getItem(`pref_${key}`);
      return val ? (JSON.parse(val) as T) : fallback;
    } catch {
      return fallback;
    }
  },

  setItem<T>(key: string, value: T): void {
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(`pref_${key}`, JSON.stringify(value));
      }
    } catch {
      // fallback
    }
  },
};

/**
 * On-Device Room-style SQLite/IndexedDB Local Database
 * Fully client-side with zero Firebase, zero external APIs, and zero cloud backend.
 */
class RoomDatabase {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB is not available in this environment'));
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Topics Table / Store
        if (!db.objectStoreNames.contains('topics')) {
          const topicStore = db.createObjectStore('topics', { keyPath: 'id' });
          topicStore.createIndex('categoryId', 'categoryId', { unique: false });
          topicStore.createIndex('nextReviewDate', 'nextReviewDate', { unique: false });
        }

        // Categories Table / Store
        if (!db.objectStoreNames.contains('categories')) {
          db.createObjectStore('categories', { keyPath: 'id' });
        }

        // Reminders Table / Store
        if (!db.objectStoreNames.contains('reminders')) {
          db.createObjectStore('reminders', { keyPath: 'id' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  // --- TOPIC DAO ---
  public topicDao = {
    getAll: async (): Promise<Topic[]> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('topics', 'readonly');
          const store = tx.objectStore('topics');
          const req = store.getAll();
          req.onsuccess = () => {
            const results = (req.result as Topic[]) || [];
            // If empty on first boot, seed with initial topics
            if (results.length === 0) {
              const seedPromises = INITIAL_TOPICS.map((t) => this.topicDao.insert(t));
              Promise.all(seedPromises).then(() => resolve(INITIAL_TOPICS));
            } else {
              resolve(results);
            }
          };
          req.onerror = () => reject(req.error);
        });
      } catch {
        // Fallback to localStorage if IndexedDB is blocked in sandboxes
        const saved = localStorage.getItem('recall_curve_topics');
        return saved ? JSON.parse(saved) : INITIAL_TOPICS;
      }
    },

    insert: async (topic: Topic): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('topics', 'readwrite');
          const store = tx.objectStore('topics');
          const req = store.put(topic);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        // LocalStorage fallback
        const current = await this.topicDao.getAll();
        const updated = [topic, ...current.filter((t) => t.id !== topic.id)];
        localStorage.setItem('recall_curve_topics', JSON.stringify(updated));
      }
    },

    update: async (topic: Topic): Promise<void> => {
      return this.topicDao.insert(topic);
    },

    delete: async (topicId: string): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('topics', 'readwrite');
          const store = tx.objectStore('topics');
          const req = store.delete(topicId);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        const current = await this.topicDao.getAll();
        const updated = current.filter((t) => t.id !== topicId);
        localStorage.setItem('recall_curve_topics', JSON.stringify(updated));
      }
    },
  };

  // --- CATEGORY DAO ---
  public categoryDao = {
    getAll: async (): Promise<SubjectCategory[]> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('categories', 'readonly');
          const store = tx.objectStore('categories');
          const req = store.getAll();
          req.onsuccess = () => {
            const results = (req.result as SubjectCategory[]) || [];
            if (results.length === 0) {
              const seedPromises = INITIAL_CATEGORIES.map((c) => this.categoryDao.insert(c));
              Promise.all(seedPromises).then(() => resolve(INITIAL_CATEGORIES));
            } else {
              resolve(results);
            }
          };
          req.onerror = () => reject(req.error);
        });
      } catch {
        const saved = localStorage.getItem('recall_curve_categories');
        return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
      }
    },

    insert: async (category: SubjectCategory): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('categories', 'readwrite');
          const store = tx.objectStore('categories');
          const req = store.put(category);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        const current = await this.categoryDao.getAll();
        const updated = [...current.filter((c) => c.id !== category.id), category];
        localStorage.setItem('recall_curve_categories', JSON.stringify(updated));
      }
    },

    update: async (category: SubjectCategory): Promise<void> => {
      return this.categoryDao.insert(category);
    },

    delete: async (categoryId: string): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('categories', 'readwrite');
          const store = tx.objectStore('categories');
          const req = store.delete(categoryId);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        const current = await this.categoryDao.getAll();
        const updated = current.filter((c) => c.id !== categoryId);
        localStorage.setItem('recall_curve_categories', JSON.stringify(updated));
      }
    },
  };

  // --- REMINDER DAO ---
  public reminderDao = {
    getAll: async (): Promise<MotivationalReminder[]> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('reminders', 'readonly');
          const store = tx.objectStore('reminders');
          const req = store.getAll();
          req.onsuccess = () => {
            const results = (req.result as MotivationalReminder[]) || [];
            if (results.length === 0) {
              const seedPromises = INITIAL_REMINDERS.map((r) => this.reminderDao.insert(r));
              Promise.all(seedPromises).then(() => resolve(INITIAL_REMINDERS));
            } else {
              resolve(results);
            }
          };
          req.onerror = () => reject(req.error);
        });
      } catch {
        const saved = localStorage.getItem('recall_curve_reminders');
        return saved ? JSON.parse(saved) : INITIAL_REMINDERS;
      }
    },

    insert: async (reminder: MotivationalReminder): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('reminders', 'readwrite');
          const store = tx.objectStore('reminders');
          const req = store.put(reminder);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        const current = await this.reminderDao.getAll();
        const updated = [...current.filter((r) => r.id !== reminder.id), reminder];
        localStorage.setItem('recall_curve_reminders', JSON.stringify(updated));
      }
    },

    update: async (reminder: MotivationalReminder): Promise<void> => {
      return this.reminderDao.insert(reminder);
    },

    delete: async (reminderId: string): Promise<void> => {
      try {
        const db = await this.open();
        return new Promise((resolve, reject) => {
          const tx = db.transaction('reminders', 'readwrite');
          const store = tx.objectStore('reminders');
          const req = store.delete(reminderId);
          req.onsuccess = () => resolve();
          req.onerror = () => reject(req.error);
        });
      } catch {
        const current = await this.reminderDao.getAll();
        const updated = current.filter((r) => r.id !== reminderId);
        localStorage.setItem('recall_curve_reminders', JSON.stringify(updated));
      }
    },
  };

  /**
   * Export all local database records as a standalone JSON backup
   */
  public async exportDatabaseDump(): Promise<{
    version: number;
    timestamp: string;
    topics: Topic[];
    categories: SubjectCategory[];
    reminders: MotivationalReminder[];
    settings: DeviceSettings;
  }> {
    const [topics, categories, reminders] = await Promise.all([
      this.topicDao.getAll(),
      this.categoryDao.getAll(),
      this.reminderDao.getAll(),
    ]);

    return {
      version: DB_VERSION,
      timestamp: new Date().toISOString(),
      topics,
      categories,
      reminders,
      settings: SharedPreferences.getSettings(),
    };
  }
}

export const LocalRoomDatabase = new RoomDatabase();
