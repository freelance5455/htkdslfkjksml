import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const portfolioAccounts = pgTable("portfolio_accounts", {
  id: serial("id").primaryKey(),
  accountKey: text("account_key").notNull().unique(),
  virtualBalanceUsdt: doublePrecision("virtual_balance_usdt").notNull().default(10000),
  initialBalanceUsdt: doublePrecision("initial_balance_usdt").notNull().default(10000),
  realizedPnlUsdt: doublePrecision("realized_pnl_usdt").notNull().default(0),
  totalTradesCount: integer("total_trades_count").notNull().default(0),
  winningTradesCount: integer("winning_trades_count").notNull().default(0),
  evaluatorStrictMode: boolean("evaluator_strict_mode").notNull().default(false),
  minConfluenceThreshold: integer("min_confluence_threshold").notNull().default(74),
  rollingWinRatePct: doublePrecision("rolling_win_rate_pct").notNull().default(78.5),
  taxClassification: text("tax_classification").notNull().default("capital_gains_25"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const paperPositions = pgTable("paper_positions", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // "LONG" | "SHORT"
  entryPrice: doublePrecision("entry_price").notNull(),
  exitPrice: doublePrecision("exit_price"),
  sizeUsdt: doublePrecision("size_usdt").notNull(), // Margin allocated in USDT
  notionalUsdt: doublePrecision("notional_usdt").notNull(), // Margin * Leverage
  quantity: doublePrecision("quantity").notNull(),
  leverage: integer("leverage").notNull().default(3),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  liquidationPrice: doublePrecision("liquidation_price").notNull(),
  status: text("status").notNull().default("OPEN"), // "OPEN" | "CLOSED"
  realizedPnlUsdt: doublePrecision("realized_pnl_usdt").default(0),
  closeReason: text("close_reason"), // "MANUAL" | "TP_HIT" | "SL_HIT" | "LIQUIDATED"
  copiedFromTrader: text("copied_from_trader"),
  openedAt: timestamp("opened_at").defaultNow().notNull(),
  closedAt: timestamp("closed_at"),
});

export const paperLimitOrders = pgTable("paper_limit_orders", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // "LONG" | "SHORT"
  limitPrice: doublePrecision("limit_price").notNull(),
  sizeUsdt: doublePrecision("size_usdt").notNull(),
  leverage: integer("leverage").notNull().default(3),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  status: text("status").notNull().default("PENDING"), // "PENDING" | "FILLED" | "CANCELLED"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const copiedTraders = pgTable("copied_traders", {
  id: serial("id").primaryKey(),
  traderId: text("trader_id").notNull().unique(),
  traderName: text("trader_name").notNull(),
  allocatedBudgetUsdt: doublePrecision("allocated_budget_usdt").notNull().default(1000),
  stopLossPct: doublePrecision("stop_loss_pct").notNull().default(12),
  maxLeverage: integer("max_leverage").notNull().default(5),
  maxOpenPositions: integer("max_open_positions").notNull().default(4),
  isActive: boolean("is_active").notNull().default(false),
  totalCopiedTrades: integer("total_copied_trades").notNull().default(0),
  copiedPnlUsdt: doublePrecision("copied_pnl_usdt").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const evaluatorLogs = pgTable("evaluator_logs", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  signalSide: text("signal_side").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  exitPrice: doublePrecision("exit_price").notNull(),
  outcome: text("outcome").notNull(), // "WIN" | "LOSS"
  pnlPct: doublePrecision("pnl_pct").notNull(),
  rootCauseCode: text("root_cause_code").notNull(),
  hebrewDiagnosis: text("hebrew_diagnosis").notNull(),
  adxValue: doublePrecision("adx_value").notNull(),
  rsiValue: doublePrecision("rsi_value").notNull(),
  volumeRatio: doublePrecision("volume_ratio").notNull(),
  actionTaken: text("action_taken").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const taxInvoices = pgTable("tax_invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull(),
  clientOrExchange: text("client_or_exchange").notNull(),
  descriptionHe: text("description_he").notNull(),
  amountUsdt: doublePrecision("amount_usdt").notNull(),
  usdIlsRate: doublePrecision("usd_ils_rate").notNull().default(3.72),
  amountIls: doublePrecision("amount_ils").notNull(),
  taxCategory: text("tax_category").notNull(), // "רווח הון (25%)" | "הכנסה עסקית (שולי)"
  estimatedTaxIls: doublePrecision("estimated_tax_ils").notNull(),
  form909Status: text("form_909_status").notNull().default("מוכן לדיווח - טופס 909"),
  txHash: text("tx_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
