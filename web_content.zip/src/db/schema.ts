import { boolean, index, jsonb, pgTable, text, timestamp, uuid, varchar } from "drizzle-orm/pg-core";

export type StoredMessage = {
  role: "user" | "assistant";
  content: string;
  attachmentName?: string;
  attachmentText?: string;
};

export const conversations = pgTable(
  "conversations",
  {
    id: uuid("id").primaryKey(),
    ownerId: uuid("owner_id").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    tool: varchar("tool", { length: 30 }).notNull(),
    messages: jsonb("messages").$type<StoredMessage[]>().notNull().default([]),
    prompt: text("prompt"),
    option: varchar("option", { length: 80 }),
    favorite: boolean("favorite").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("conversations_owner_updated_idx").on(table.ownerId, table.updatedAt)],
);

