import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import type { L10n, SiteSettings } from "@/lib/types";

const emptyArray = sql`'[]'::jsonb`;
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () => timestamp("updated_at", { withTimezone: true }).notNull().defaultNow();

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  address: text("address").notNull().default(""),
  role: text("role").notNull().default("patient"),
  isActive: boolean("is_active").notNull().default(true),
  locale: text("locale").notNull().default("ar"),
  emergencyContactName: text("emergency_contact_name").notNull().default(""),
  emergencyContactPhone: text("emergency_contact_phone").notNull().default(""),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const professionals = pgTable("professionals", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .unique()
    .references(() => users.id, { onDelete: "cascade" }),
  profession: text("profession").notNull().default("nurse"),
  photoUrl: text("photo_url").notNull().default(""),
  bio: jsonb("bio").$type<L10n>().notNull(),
  licenseNumber: text("license_number").notNull(),
  qualifications: text("qualifications").notNull().default(""),
  specializations: jsonb("specializations").$type<string[]>().notNull().default(emptyArray),
  experienceYears: integer("experience_years").notNull().default(0),
  serviceCodes: jsonb("service_codes").$type<string[]>().notNull().default(emptyArray),
  serviceCities: jsonb("service_cities").$type<string[]>().notNull().default(emptyArray),
  availableDays: jsonb("available_days").$type<string[]>().notNull().default(emptyArray),
  availableFrom: integer("available_from").notNull().default(8),
  availableTo: integer("available_to").notNull().default(18),
  verificationStatus: text("verification_status").notNull().default("pending"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  ratingAvg: real("rating_avg").notNull().default(0),
  ratingCount: integer("rating_count").notNull().default(0),
  createdAt: createdAt(),
});

export const services = pgTable("services", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  category: text("category").notNull(),
  name: jsonb("name").$type<L10n>().notNull(),
  description: jsonb("description").$type<L10n>().notNull(),
  priceMad: integer("price_mad").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  requiresVerifiedPro: boolean("requires_verified_pro").notNull().default(false),
  icon: text("icon").notNull().default("stethoscope"),
  isFeatured: boolean("is_featured").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const categories = pgTable("categories", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  name: jsonb("name").$type<L10n>().notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(),
});

export const articles = pgTable("articles", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  kind: text("kind").notNull().default("article"),
  category: text("category").notNull(),
  title: jsonb("title").$type<L10n>().notNull(),
  summary: jsonb("summary").$type<L10n>().notNull(),
  body: jsonb("body").$type<L10n>().notNull(),
  sources: jsonb("sources").$type<string[]>().notNull().default(emptyArray),
  emoji: text("emoji").notNull().default("📘"),
  readMinutes: integer("read_minutes").notNull().default(3),
  reviewedBy: text("reviewed_by").notNull().default(""),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  isPublished: boolean("is_published").notNull().default(true),
  isFeatured: boolean("is_featured").notNull().default(false),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const favorites = pgTable(
  "favorites",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    articleId: uuid("article_id")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.articleId] })],
);

export const appointments = pgTable(
  "appointments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reference: text("reference").notNull().unique(),
    patientId: uuid("patient_id").references(() => users.id, { onDelete: "set null" }),
    professionalId: uuid("professional_id").references(() => professionals.id, {
      onDelete: "set null",
    }),
    serviceId: uuid("service_id")
      .notNull()
      .references(() => services.id),
    scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
    status: text("status").notNull().default("pending"),
    patientName: text("patient_name").notNull(),
    phone: text("phone").notNull(),
    city: text("city").notNull(),
    address: text("address").notNull(),
    medicalNotes: text("medical_notes").notNull().default(""),
    priceMad: integer("price_mad").notNull(),
    durationMinutes: integer("duration_minutes").notNull(),
    cancelReason: text("cancel_reason").notNull().default(""),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("appointments_patient_idx").on(t.patientId),
    index("appointments_professional_idx").on(t.professionalId),
    index("appointments_scheduled_idx").on(t.scheduledAt),
  ],
);

export const reviews = pgTable("reviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  appointmentId: uuid("appointment_id")
    .notNull()
    .unique()
    .references(() => appointments.id, { onDelete: "cascade" }),
  professionalId: uuid("professional_id").references(() => professionals.id, { onDelete: "cascade" }),
  patientId: uuid("patient_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull().default(""),
  createdAt: createdAt(),
});

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: jsonb("title").$type<L10n>().notNull(),
    message: jsonb("message").$type<L10n>().notNull(),
    link: text("link").notNull().default(""),
    isRead: boolean("is_read").notNull().default(false),
    createdAt: createdAt(),
  },
  (t) => [index("notifications_user_idx").on(t.userId)],
);

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: createdAt(),
});

export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  actorId: uuid("actor_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id").notNull().default(""),
  details: text("details").notNull().default(""),
  createdAt: createdAt(),
});

/** Editable website content (contact, WhatsApp, home text, nurse profile, testimonials). One row, key = "main". */
export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").$type<SiteSettings>().notNull(),
  updatedAt: updatedAt(),
});

export type UserRow = typeof users.$inferSelect;
export type ProfessionalRow = typeof professionals.$inferSelect;
export type ServiceRow = typeof services.$inferSelect;
export type ArticleRow = typeof articles.$inferSelect;
export type AppointmentRow = typeof appointments.$inferSelect;
