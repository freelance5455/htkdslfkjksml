import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Users & auth                                                        */
/* ------------------------------------------------------------------ */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 255 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    name: varchar("name", { length: 120 }).notNull().default(""),
    role: varchar("role", { length: 20 }).notNull().default("user"),
    planKey: varchar("plan_key", { length: 32 }).notNull().default("free"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 96 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const passwordResets = pgTable(
  "password_resets",
  {
    token: varchar("token", { length: 96 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("password_resets_user_idx").on(t.userId)],
);

/* ------------------------------------------------------------------ */
/* Preferences                                                         */
/* ------------------------------------------------------------------ */

export const userPreferences = pgTable("user_preferences", {
  userId: integer("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  defaultPlatform: varchar("default_platform", { length: 40 }).notNull().default("youtube"),
  defaultNiche: varchar("default_niche", { length: 60 }).notNull().default("motivation"),
  defaultTone: varchar("default_tone", { length: 60 }).notNull().default("energetic"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Subscriptions (DB driven, admin editable plans)                     */
/* ------------------------------------------------------------------ */

export const plans = pgTable(
  "plans",
  {
    id: serial("id").primaryKey(),
    key: varchar("key", { length: 32 }).notNull(),
    name: varchar("name", { length: 80 }).notNull(),
    tagline: varchar("tagline", { length: 160 }).notNull().default(""),
    priceCents: integer("price_cents").notNull().default(0),
    currency: varchar("currency", { length: 8 }).notNull().default("USD"),
    interval: varchar("interval", { length: 20 }).notNull().default("month"),
    monthlyLimit: integer("monthly_limit").notNull().default(10),
    isActive: boolean("is_active").notNull().default(true),
    isPublic: boolean("is_public").notNull().default(true),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    sortOrder: integer("sort_order").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("plans_key_unique").on(t.key)],
);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    planKey: varchar("plan_key", { length: 32 }).notNull(),
    status: varchar("status", { length: 24 }).notNull().default("active"),
    amountCents: integer("amount_cents").notNull().default(0),
    currentPeriodStart: timestamp("current_period_start", { withTimezone: true }).notNull().defaultNow(),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }).notNull(),
    cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("subscriptions_user_idx").on(t.userId), index("subscriptions_plan_idx").on(t.planKey)],
);

/* ------------------------------------------------------------------ */
/* Generations, saves, usage                                           */
/* ------------------------------------------------------------------ */

export const generations = pgTable(
  "generations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tool: varchar("tool", { length: 48 }).notNull(),
    platform: varchar("platform", { length: 40 }).notNull().default(""),
    topic: text("topic").notNull().default(""),
    niche: varchar("niche", { length: 60 }).notNull().default(""),
    tone: varchar("tone", { length: 60 }).notNull().default(""),
    inputs: jsonb("inputs").$type<Record<string, unknown>>().notNull().default({}),
    output: jsonb("output").$type<Record<string, unknown>>().notNull().default({}),
    engine: varchar("engine", { length: 40 }).notNull().default("template"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("generations_user_idx").on(t.userId, t.createdAt), index("generations_tool_idx").on(t.tool)],
);

export const savedItems = pgTable(
  "saved_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    generationId: integer("generation_id").references(() => generations.id, { onDelete: "set null" }),
    tool: varchar("tool", { length: 48 }).notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    body: text("body").notNull().default(""),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("saved_items_user_idx").on(t.userId, t.createdAt)],
);

export const usageRecords = pgTable(
  "usage_records",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tool: varchar("tool", { length: 48 }).notNull(),
    credits: integer("credits").notNull().default(1),
    periodKey: varchar("period_key", { length: 7 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("usage_records_user_period_idx").on(t.userId, t.periodKey)],
);

/* ------------------------------------------------------------------ */
/* Content calendars                                                   */
/* ------------------------------------------------------------------ */

export const contentCalendars = pgTable(
  "content_calendars",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 160 }).notNull(),
    planLength: integer("plan_length").notNull().default(7),
    days: jsonb("days")
      .$type<{ day: number; date?: string; topic: string; platform: string; contentType: string; postTime: string }[]>()
      .notNull()
      .default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("calendars_user_idx").on(t.userId, t.createdAt)],
);

/* ------------------------------------------------------------------ */
/* Admin editable app settings (niches, feature flags, limits)          */
/* ------------------------------------------------------------------ */

export const appSettings = pgTable("app_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Plan = typeof plans.$inferSelect;
export type Generation = typeof generations.$inferSelect;
export type SavedItem = typeof savedItems.$inferSelect;
export type ContentCalendar = typeof contentCalendars.$inferSelect;
