import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const squads = pgTable("squads", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  squadId: integer("squad_id")
    .notNull()
    .references(() => squads.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  avatar: text("avatar").notNull().default("🦸"),
  color: text("color").notNull().default("#e62429"),
  code: text("code").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  year: integer("year").notNull(),
  phase: integer("phase").notNull().default(0),
  saga: text("saga").notNull().default("MCU"),
  palette: text("palette").notNull().default("iron"),
  runtime: integer("runtime").notNull().default(0),
  synopsis: text("synopsis").notNull().default(""),
  upcoming: boolean("upcoming").notNull().default(false),
  releaseDate: text("release_date"),
  sortIndex: integer("sort_index").notNull().default(0),
  posterUrl: text("poster_url"),
});

export const entries = pgTable(
  "entries",
  {
    id: serial("id").primaryKey(),
    memberId: integer("member_id")
      .notNull()
      .references(() => members.id, { onDelete: "cascade" }),
    movieId: integer("movie_id")
      .notNull()
      .references(() => movies.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("watched"),
    rating: integer("rating"),
    review: text("review"),
    favorite: boolean("favorite").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("entries_member_movie_unique").on(table.memberId, table.movieId)],
);

export type Squad = typeof squads.$inferSelect;
export type Member = typeof members.$inferSelect;
export type Movie = typeof movies.$inferSelect;
export type Entry = typeof entries.$inferSelect;
