import { integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import type { Awards, MatchEvent, MatchSetup } from "@/lib/types";

/**
 * Event-sourced match storage.
 *
 * `setup` holds MATCH / TEAM / PLAYER / PLAYING XI data, and `events` holds the
 * immutable BALL EVENT log. INNINGS, COMMENTARY, batting/bowling statistics,
 * partnerships and fall-of-wickets are derived deterministically from those two
 * columns by the single centralised scoring engine (`src/lib/engine.ts`), so
 * they are never stored twice and can never drift out of sync.
 *
 * The denormalised columns below exist purely so match history can be queried
 * and sorted in SQL without replaying every innings.
 */
export const matches = pgTable("matches", {
  id: uuid("id").primaryKey().defaultRandom(),
  setup: jsonb("setup").$type<MatchSetup>().notNull(),
  events: jsonb("events").$type<MatchEvent[]>().notNull().default([]),
  awards: jsonb("awards").$type<Awards>(),
  title: text("title").notNull(),

  // Denormalised, derived from setup/events on every write.
  format: text("format"),
  venue: text("venue"),
  matchDate: timestamp("match_date", { withTimezone: true }),
  status: text("status"),
  result: text("result"),

  /** Monotonic revision from the scoring device; guards against stale syncs. */
  rev: integer("rev").notNull().default(0),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type MatchRow = typeof matches.$inferSelect;
