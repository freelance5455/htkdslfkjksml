import {
  pgTable,
  serial,
  text,
  timestamp,
  doublePrecision,
  integer,
  boolean,
  jsonb,
} from "drizzle-orm/pg-core";

/** חשבון מסחר דמו (Paper Trading) */
export const paperAccounts = pgTable("paper_accounts", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  balance: doublePrecision("balance").notNull().default(10000),
  equityPeak: doublePrecision("equity_peak").notNull().default(10000),
  realizedPnl: doublePrecision("realized_pnl").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** פקודות (Market / Limit) */
export const paperOrders = pgTable("paper_orders", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // LONG | SHORT
  orderType: text("order_type").notNull().default("MARKET"), // MARKET | LIMIT
  status: text("status").notNull().default("PENDING"), // PENDING | FILLED | CANCELLED
  qty: doublePrecision("qty").notNull(),
  limitPrice: doublePrecision("limit_price"),
  filledPrice: doublePrecision("filled_price"),
  leverage: integer("leverage").notNull().default(1),
  stopLoss: doublePrecision("stop_loss"),
  takeProfit: doublePrecision("take_profit"),
  source: text("source").notNull().default("MANUAL"), // MANUAL | SIGNAL | COPY
  masterTraderId: integer("master_trader_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** פוזיציות פתוחות / סגורות */
export const paperPositions = pgTable("paper_positions", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(),
  qty: doublePrecision("qty").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  leverage: integer("leverage").notNull().default(1),
  margin: doublePrecision("margin").notNull().default(0),
  liquidationPrice: doublePrecision("liquidation_price"),
  stopLoss: doublePrecision("stop_loss"),
  takeProfit: doublePrecision("take_profit"),
  status: text("status").notNull().default("OPEN"), // OPEN | CLOSED
  exitPrice: doublePrecision("exit_price"),
  realizedPnl: doublePrecision("realized_pnl"),
  closeReason: text("close_reason"),
  source: text("source").notNull().default("MANUAL"),
  masterTraderId: integer("master_trader_id"),
  signalId: integer("signal_id"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

/** אותות מסחר שנוצרו ע"י מנוע הניתוח */
export const tradeSignals = pgTable("trade_signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(), // LONG | SHORT | WAIT
  confidence: doublePrecision("confidence").notNull().default(0),
  entry: doublePrecision("entry").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit1: doublePrecision("take_profit_1").notNull(),
  takeProfit2: doublePrecision("take_profit_2").notNull(),
  leverage: integer("leverage").notNull().default(2),
  positionPct: doublePrecision("position_pct").notNull().default(0),
  rsi: doublePrecision("rsi"),
  macd: doublePrecision("macd"),
  atr: doublePrecision("atr"),
  adx: doublePrecision("adx"),
  ema20: doublePrecision("ema20"),
  ema50: doublePrecision("ema50"),
  ema200: doublePrecision("ema200"),
  volumeRatio: doublePrecision("volume_ratio"),
  reasons: jsonb("reasons").$type<string[]>().default([]),
  source: text("source").notNull().default("bybit"),
  outcome: text("outcome"), // WIN | LOSS | OPEN | EXPIRED
  outcomePrice: doublePrecision("outcome_price"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  evaluatedAt: timestamp("evaluated_at"),
});

/** סוחרי על / אסטרטגיות AI לחיקוי */
export const masterTraders = pgTable("master_traders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  handle: text("handle").notNull(),
  strategy: text("strategy").notNull(),
  winRate: doublePrecision("win_rate").notNull().default(0),
  roi7d: doublePrecision("roi_7d").notNull().default(0),
  roi30d: doublePrecision("roi_30d").notNull().default(0),
  maxDrawdown: doublePrecision("max_drawdown").notNull().default(0),
  profitFactor: doublePrecision("profit_factor").notNull().default(0),
  riskScore: integer("risk_score").notNull().default(5),
  followers: integer("followers").notNull().default(0),
  avgLeverage: integer("avg_leverage").notNull().default(3),
  markets: jsonb("markets").$type<string[]>().default([]),
  bio: text("bio").notNull().default(""),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** מעקב / חיקוי אחרי סוחר */
export const copyFollows = pgTable("copy_follows", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  masterTraderId: integer("master_trader_id").notNull(),
  budget: doublePrecision("budget").notNull().default(1000),
  copyStopLossPct: doublePrecision("copy_stop_loss_pct").notNull().default(15),
  maxOpenPositions: integer("max_open_positions").notNull().default(3),
  maxLeverage: integer("max_leverage").notNull().default(5),
  active: boolean("active").notNull().default(true),
  copiedPnl: doublePrecision("copied_pnl").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** יומן אבחונים וסריקה עצמית (Evaluator Agent) */
export const evaluatorLogs = pgTable("evaluator_logs", {
  id: serial("id").primaryKey(),
  level: text("level").notNull().default("info"), // info | warn | error | fix
  symbol: text("symbol"),
  signalId: integer("signal_id"),
  message: text("message").notNull(),
  rootCause: text("root_cause"),
  action: text("action"),
  winRateSnapshot: doublePrecision("win_rate_snapshot"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** כללי ביטחון מתכווננים (Adaptive rules) */
export const engineSettings = pgTable("engine_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: jsonb("value").$type<Record<string, number | string | boolean>>().notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** חשבוניות Invoapp */
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  invoiceNumber: text("invoice_number").notNull(),
  clientName: text("client_name").notNull(),
  clientTaxId: text("client_tax_id").notNull().default(""),
  description: text("description").notNull().default(""),
  amountUsdt: doublePrecision("amount_usdt").notNull().default(0),
  usdIlsRate: doublePrecision("usd_ils_rate").notNull().default(3.7),
  amountIls: doublePrecision("amount_ils").notNull().default(0),
  vatPct: doublePrecision("vat_pct").notNull().default(18),
  totalIls: doublePrecision("total_ils").notNull().default(0),
  status: text("status").notNull().default("ISSUED"), // ISSUED | PAID
  issuedAt: timestamp("issued_at").notNull().defaultNow(),
});

/** התראות פוש */
export const pushTokens = pgTable("push_tokens", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  token: text("token").notNull(),
  platform: text("platform").notNull().default("expo"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userKey: text("user_key").notNull().default("demo"),
  title: text("title").notNull(),
  body: text("body").notNull(),
  kind: text("kind").notNull().default("signal"), // signal | copy | sltp | evaluator
  delivered: boolean("delivered").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type PaperAccount = typeof paperAccounts.$inferSelect;
export type PaperOrder = typeof paperOrders.$inferSelect;
export type PaperPosition = typeof paperPositions.$inferSelect;
export type TradeSignal = typeof tradeSignals.$inferSelect;
export type MasterTrader = typeof masterTraders.$inferSelect;
export type CopyFollow = typeof copyFollows.$inferSelect;
export type EvaluatorLog = typeof evaluatorLogs.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type AppNotification = typeof notifications.$inferSelect;
