import { pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

/** Submissions of "نموذج أ" (the application form). */
export const formASubmissions = pgTable("form_a_submissions", {
  id: serial("id").primaryKey(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  email: varchar("email", { length: 160 }),
  governorate: varchar("governorate", { length: 60 }).notNull(),
  mosqueName: varchar("mosque_name", { length: 160 }),
  role: varchar("role", { length: 60 }).notNull(),
  requestType: varchar("request_type", { length: 60 }).notNull(),
  details: text("details").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type FormASubmission = typeof formASubmissions.$inferSelect;
