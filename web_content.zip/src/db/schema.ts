import {
  pgTable,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
  uuid,
  index,
} from "drizzle-orm/pg-core";

/* A "Mind" is not a player. It is a cognitive entity graded across the
   Three Pillars: Creativity, Imagination, Pattern & Knowledge. */
export const minds = pgTable("minds", {
  id: uuid("id").defaultRandom().primaryKey(),
  alias: text("alias").notNull(),
  creativity: integer("creativity").notNull().default(0),
  imagination: integer("imagination").notNull().default(0),
  pattern: integer("pattern").notNull().default(0),
  mindIndex: integer("mind_index").notNull().default(0),
  bestRing: integer("best_ring").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  bestStreak: integer("best_streak").notNull().default(0),
  trialsSolved: integer("trials_solved").notNull().default(0),
  trialsFailed: integer("trials_failed").notNull().default(0),
  isBenchmark: boolean("is_benchmark").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Pillar = { c: number; i: number; p: number };

export const questions = pgTable(
  "questions",
  {
    id: text("id").primaryKey(),
    domain: text("domain").notNull(), // pattern | science | strategy | paradox | lateral | imagination
    kind: text("kind").notNull(), // mcq | sequence | analogy | boss
    difficulty: integer("difficulty").notNull(), // 1..10
    prompt: text("prompt").notNull(),
    options: jsonb("options").$type<string[]>().notNull(),
    answerIndex: integer("answer_index").notNull(),
    explanation: text("explanation").notNull(),
    pillar: jsonb("pillar").$type<Pillar>().notNull(),
    timeLimit: integer("time_limit").notNull().default(60),
    isBoss: boolean("is_boss").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("questions_domain_diff_idx").on(t.domain, t.difficulty)],
);

export type DecisionChoice = {
  text: string;
  score: number; // 0..10 — hidden mastermind weighting
  cascade: string; // revealed consequence
};

export const decisions = pgTable("decisions", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  narrative: text("narrative").notNull(),
  choices: jsonb("choices").$type<DecisionChoice[]>().notNull(),
  difficulty: integer("difficulty").notNull(),
  pillar: jsonb("pillar").$type<Pillar>().notNull(),
  tags: text("tags").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const attempts = pgTable(
  "attempts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    mindId: uuid("mind_id").notNull(),
    kind: text("kind").notNull(), // trial | decision
    subjectId: text("subject_id").notNull(),
    choiceIndex: integer("choice_index").notNull(),
    correct: boolean("correct").notNull(),
    score: integer("score").notNull().default(0),
    elapsedMs: integer("elapsed_ms").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("attempts_mind_subject_idx").on(t.mindId, t.subjectId)],
);
