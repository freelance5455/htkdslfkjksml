import {
  boolean,
  date,
  index,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  pinHash: text("pin_hash").notNull(),
  pinSalt: text("pin_salt").notNull(),
  currency: text("currency").notNull().default("USD"),
  theme: text("theme").notNull().default("dark"),
  requirePin: boolean("require_pin").notNull().default(true),
  startBalance: numeric("start_balance", {
    precision: 14,
    scale: 2,
    mode: "number",
  })
    .notNull()
    .default(0),
  weekStart: integer("week_start").notNull().default(0),
  compactNumbers: boolean("compact_numbers").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    profileId: integer("profile_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(), // "earn" | "spend"
    title: text("title").notNull(),
    amount: numeric("amount", { precision: 14, scale: 2, mode: "number" }).notNull(),
    day: date("day", { mode: "string" }).notNull(), // YYYY-MM-DD
    category: text("category").notNull().default("Other"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("transactions_profile_day_idx").on(t.profileId, t.day)],
);

export const bills = pgTable(
  "bills",
  {
    id: serial("id").primaryKey(),
    profileId: integer("profile_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    category: text("category").notNull().default("Custom"),
    amount: numeric("amount", { precision: 14, scale: 2, mode: "number" }).notNull(),
    dueDay: integer("due_day").notNull().default(1),
    startMonth: text("start_month").notNull(), // YYYY-MM
    active: boolean("active").notNull().default(true),
    autoCarry: boolean("auto_carry").notNull().default(true),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("bills_profile_idx").on(t.profileId)],
);

export const billPeriods = pgTable(
  "bill_periods",
  {
    id: serial("id").primaryKey(),
    billId: integer("bill_id")
      .notNull()
      .references(() => bills.id, { onDelete: "cascade" }),
    profileId: integer("profile_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    period: text("period").notNull(), // YYYY-MM
    baseDue: numeric("base_due", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    carry: numeric("carry", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    paid: numeric("paid", { precision: 14, scale: 2, mode: "number" }).notNull().default(0),
    status: text("status").notNull().default("upcoming"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("bill_periods_bill_period_idx").on(t.billId, t.period),
    index("bill_periods_profile_idx").on(t.profileId),
  ],
);

export const billPayments = pgTable(
  "bill_payments",
  {
    id: serial("id").primaryKey(),
    billId: integer("bill_id")
      .notNull()
      .references(() => bills.id, { onDelete: "cascade" }),
    profileId: integer("profile_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    period: text("period").notNull(),
    amount: numeric("amount", { precision: 14, scale: 2, mode: "number" }).notNull(),
    note: text("note"),
    paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("bill_payments_profile_idx").on(t.profileId)],
);

export type Profile = typeof profiles.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Bill = typeof bills.$inferSelect;
export type BillPeriod = typeof billPeriods.$inferSelect;
export type BillPayment = typeof billPayments.$inferSelect;
