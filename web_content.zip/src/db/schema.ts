import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  integer,
  jsonb,
} from "drizzle-orm/pg-core";

// Профили для синхронизации между устройствами (простой sync-код)
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  syncCode: text("sync_code").notNull().unique(),
  name: text("name").notNull().default("Пользователь"),
  settings: jsonb("settings").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const history = pgTable("history", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull().default(0),
  url: text("url").notNull(),
  title: text("title").notNull().default(""),
  visitedAt: timestamp("visited_at").defaultNow().notNull(),
});

export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull().default(0),
  url: text("url").notNull(),
  title: text("title").notNull().default(""),
  folder: text("folder").notNull().default("Панель закладок"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull().default(0),
  url: text("url").notNull(),
  filename: text("filename").notNull(),
  size: integer("size").notNull().default(0),
  mime: text("mime").notNull().default(""),
  status: text("status").notNull().default("completed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull().default(0),
  title: text("title").notNull().default("Новый диалог"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  role: text("role").notNull(), // user | assistant | system
  content: text("content").notNull(),
  sources: jsonb("sources").$type<{ title: string; url: string }[]>().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const blockedTrackers = pgTable("blocked_trackers", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull().default(0),
  host: text("host").notNull(),
  count: integer("count").notNull().default(1),
  pinned: boolean("pinned").notNull().default(false),
});
