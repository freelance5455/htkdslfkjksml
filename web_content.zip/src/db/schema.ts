import {
  boolean,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const attractions = pgTable("attractions", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  nameEn: text("name_en").notNull(),
  nameAr: text("name_ar").notNull(),
  countryCode: text("country_code").notNull(),
  cityEn: text("city_en").notNull(),
  cityAr: text("city_ar").notNull(),
  category: text("category").notNull(),
  descEn: text("desc_en").notNull(),
  descAr: text("desc_ar").notNull(),
  price: integer("price").notNull(),
  durationMin: integer("duration_min").notNull(),
  rating: real("rating").notNull(),
  reviews: integer("reviews").notNull(),
  image: text("image").notNull(),
  keywords: text("keywords").notNull().default(""),
  featured: boolean("featured").notNull().default(false),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  ref: text("ref").notNull().unique(),
  attractionId: integer("attraction_id").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  visitDate: text("visit_date").notNull(),
  tickets: integer("tickets").notNull(),
  total: integer("total").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Attraction = typeof attractions.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
