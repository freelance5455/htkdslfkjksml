import type {
  AppSettings,
  AuditLogEntry,
  BackupPackage,
  Committee,
  CommitteeTransaction,
  CustomModule,
  CustomRecord,
  CustomReportConfig,
  CustomSubmodule,
  DashboardCardConfig,
  FieldDefinition,
  FieldMapping,
  FormulaDefinition,
  LoanPerson,
  LoanTransaction,
  MasterList,
  RecycleBinItem,
} from '../types/app';
import { APP_BACKUP_ID, DB_NAME, DB_VERSION, DEFAULT_DASHBOARD_CARDS, DEFAULT_SETTINGS } from './defaults';

export const STORE_NAMES = [
  'loanPersons',
  'loanTransactions',
  'committees',
  'committeeTransactions',
  'modules',
  'submodules',
  'fields',
  'masterLists',
  'formulas',
  'fieldMappings',
  'customRecords',
  'dashboardCards',
  'reports',
  'settings',
  'auditLogs',
  'recycleBin',
] as const;

export type StoreName = (typeof STORE_NAMES)[number];

export interface DatabaseSnapshot {
  loanPersons: LoanPerson[];
  loanTransactions: LoanTransaction[];
  committees: Committee[];
  committeeTransactions: CommitteeTransaction[];
  modules: CustomModule[];
  submodules: CustomSubmodule[];
  fields: FieldDefinition[];
  masterLists: MasterList[];
  formulas: FormulaDefinition[];
  fieldMappings: FieldMapping[];
  customRecords: CustomRecord[];
  dashboardCards: DashboardCardConfig[];
  reports: CustomReportConfig[];
  settings: AppSettings;
  auditLogs: AuditLogEntry[];
  recycleBin: RecycleBinItem[];
}

export function generateId(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      for (const storeName of STORE_NAMES) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: 'id' });
          if (storeName === 'loanTransactions') {
            store.createIndex('by_person', 'personId', { unique: false });
            store.createIndex('by_date', 'date', { unique: false });
          } else if (storeName === 'committeeTransactions') {
            store.createIndex('by_committee', 'committeeId', { unique: false });
            store.createIndex('by_date', 'date', { unique: false });
          } else if (storeName === 'submodules') {
            store.createIndex('by_module', 'moduleId', { unique: false });
          } else if (storeName === 'fields') {
            store.createIndex('by_submodule', 'submoduleId', { unique: false });
          } else if (storeName === 'customRecords') {
            store.createIndex('by_submodule', 'submoduleId', { unique: false });
          }
        }
      }
    };

    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };

    req.onerror = () => {
      dbPromise = null;
      reject(req.error || new Error('Failed to open IndexedDB database'));
    };
  });
  return dbPromise;
}

function readStore<T>(db: IDBDatabase, storeName: StoreName): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve((req.result as T[]) || []);
    req.onerror = () => reject(req.error || new Error(`Failed reading ${storeName}`));
  });
}

export async function loadFullSnapshot(): Promise<DatabaseSnapshot> {
  const db = await openDatabase();
  const [
    loanPersons,
    loanTransactions,
    committees,
    committeeTransactions,
    modules,
    submodules,
    fields,
    masterLists,
    formulas,
    fieldMappings,
    customRecords,
    dashboardCardsRaw,
    reports,
    settingsList,
    auditLogs,
    recycleBin,
  ] = await Promise.all([
    readStore<LoanPerson>(db, 'loanPersons'),
    readStore<LoanTransaction>(db, 'loanTransactions'),
    readStore<Committee>(db, 'committees'),
    readStore<CommitteeTransaction>(db, 'committeeTransactions'),
    readStore<CustomModule>(db, 'modules'),
    readStore<CustomSubmodule>(db, 'submodules'),
    readStore<FieldDefinition>(db, 'fields'),
    readStore<MasterList>(db, 'masterLists'),
    readStore<FormulaDefinition>(db, 'formulas'),
    readStore<FieldMapping>(db, 'fieldMappings'),
    readStore<CustomRecord>(db, 'customRecords'),
    readStore<DashboardCardConfig>(db, 'dashboardCards'),
    readStore<CustomReportConfig>(db, 'reports'),
    readStore<AppSettings>(db, 'settings'),
    readStore<AuditLogEntry>(db, 'auditLogs'),
    readStore<RecycleBinItem>(db, 'recycleBin'),
  ]);

  let settings = settingsList.find((s) => s.id === 'app_settings');
  let dashboardCards = dashboardCardsRaw;

  // Bootstrap initial system settings & 4 system summary cards on very first launch
  if (!settings || dashboardCards.length === 0) {
    const tx = db.transaction(['settings', 'dashboardCards'], 'readwrite');
    if (!settings) {
      settings = { ...DEFAULT_SETTINGS, updatedAt: new Date().toISOString() };
      tx.objectStore('settings').put(settings);
    }
    if (dashboardCards.length === 0) {
      dashboardCards = [...DEFAULT_DASHBOARD_CARDS];
      for (const card of dashboardCards) {
        tx.objectStore('dashboardCards').put(card);
      }
    }
    await transactionDone(tx);
  }

  return {
    loanPersons,
    loanTransactions,
    committees,
    committeeTransactions,
    modules: modules.sort((a, b) => a.position - b.position),
    submodules: submodules.sort((a, b) => a.position - b.position),
    fields: fields.sort((a, b) => a.position - b.position),
    masterLists,
    formulas,
    fieldMappings,
    customRecords,
    dashboardCards: dashboardCards.sort((a, b) => a.position - b.position),
    reports,
    settings,
    auditLogs: auditLogs.sort((a, b) => b.timestamp.localeCompare(a.timestamp)),
    recycleBin: recycleBin.sort((a, b) => b.deletedAt.localeCompare(a.deletedAt)),
  };
}

function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
  });
}

export interface TransactionalWriteOp {
  store: StoreName;
  type: 'put' | 'delete' | 'clear';
  value?: unknown;
  key?: string;
}

export async function runTransactionalWrites(ops: TransactionalWriteOp[]): Promise<void> {
  const db = await openDatabase();
  const stores = Array.from(new Set(ops.map((o) => o.store)));
  const tx = db.transaction(stores, 'readwrite');

  for (const op of ops) {
    const store = tx.objectStore(op.store);
    if (op.type === 'put' && op.value !== undefined) {
      store.put(op.value);
    } else if (op.type === 'delete' && op.key !== undefined) {
      store.delete(op.key);
    } else if (op.type === 'clear') {
      store.clear();
    }
  }

  await transactionDone(tx);
}

export function buildBackupPackage(snapshot: DatabaseSnapshot): BackupPackage {
  return {
    schemaVersion: DB_VERSION,
    appId: APP_BACKUP_ID,
    exportedAt: new Date().toISOString(),
    data: {
      loanPersons: snapshot.loanPersons,
      loanTransactions: snapshot.loanTransactions,
      committees: snapshot.committees,
      committeeTransactions: snapshot.committeeTransactions,
      modules: snapshot.modules,
      submodules: snapshot.submodules,
      fields: snapshot.fields,
      masterLists: snapshot.masterLists,
      formulas: snapshot.formulas,
      fieldMappings: snapshot.fieldMappings,
      customRecords: snapshot.customRecords,
      dashboardCards: snapshot.dashboardCards,
      reports: snapshot.reports,
      settings: snapshot.settings,
      auditLogs: snapshot.auditLogs,
      recycleBin: snapshot.recycleBin,
    },
  };
}

export interface BackupValidationResult {
  valid: boolean;
  error?: string;
  stats?: {
    loanPersons: number;
    loanTransactions: number;
    committees: number;
    committeeTransactions: number;
    modules: number;
    submodules: number;
    fields: number;
    customRecords: number;
    reports: number;
    exportedAt: string;
    schemaVersion: number;
  };
  parsed?: BackupPackage;
}

export function validateBackupJson(rawText: string): BackupValidationResult {
  try {
    const parsed = JSON.parse(rawText) as Partial<BackupPackage>;
    if (!parsed || typeof parsed !== 'object') {
      return { valid: false, error: 'Backup file is not a valid JSON object.' };
    }
    if (parsed.appId !== APP_BACKUP_ID) {
      return { valid: false, error: 'Incompatible backup file: missing application identifier.' };
    }
    if (typeof parsed.schemaVersion !== 'number' || parsed.schemaVersion > DB_VERSION) {
      return {
        valid: false,
        error: `Unsupported database schema version (${parsed.schemaVersion}). Current version is ${DB_VERSION}.`,
      };
    }
    const d = parsed.data;
    if (!d || typeof d !== 'object') {
      return { valid: false, error: 'Backup file is missing the "data" payload.' };
    }

    const requiredArrays: (keyof BackupPackage['data'])[] = [
      'loanPersons',
      'loanTransactions',
      'committees',
      'committeeTransactions',
      'modules',
      'submodules',
      'fields',
      'masterLists',
      'formulas',
      'fieldMappings',
      'customRecords',
      'dashboardCards',
      'reports',
      'auditLogs',
      'recycleBin',
    ];
    for (const key of requiredArrays) {
      if (!Array.isArray(d[key])) {
        return { valid: false, error: `Corrupt backup: "${key}" must be an array.` };
      }
    }
    if (!d.settings || typeof d.settings !== 'object') {
      return { valid: false, error: 'Corrupt backup: "settings" object is missing.' };
    }

    return {
      valid: true,
      parsed: parsed as BackupPackage,
      stats: {
        loanPersons: d.loanPersons.length,
        loanTransactions: d.loanTransactions.length,
        committees: d.committees.length,
        committeeTransactions: d.committeeTransactions.length,
        modules: d.modules.length,
        submodules: d.submodules.length,
        fields: d.fields.length,
        customRecords: d.customRecords.length,
        reports: d.reports.length,
        exportedAt: parsed.exportedAt || 'Unknown',
        schemaVersion: parsed.schemaVersion,
      },
    };
  } catch (err) {
    return {
      valid: false,
      error: err instanceof Error ? `Invalid JSON: ${err.message}` : 'Failed to parse backup file.',
    };
  }
}

export async function restoreFullBackup(pkg: BackupPackage): Promise<void> {
  const ops: TransactionalWriteOp[] = [];
  for (const storeName of STORE_NAMES) {
    ops.push({ store: storeName, type: 'clear' });
  }
  const d = pkg.data;
  const addItems = (store: StoreName, items: unknown[]) => {
    for (const item of items) {
      ops.push({ store, type: 'put', value: item });
    }
  };
  addItems('loanPersons', d.loanPersons);
  addItems('loanTransactions', d.loanTransactions);
  addItems('committees', d.committees);
  addItems('committeeTransactions', d.committeeTransactions);
  addItems('modules', d.modules);
  addItems('submodules', d.submodules);
  addItems('fields', d.fields);
  addItems('masterLists', d.masterLists);
  addItems('formulas', d.formulas);
  addItems('fieldMappings', d.fieldMappings);
  addItems('customRecords', d.customRecords);
  addItems('dashboardCards', d.dashboardCards);
  addItems('reports', d.reports);
  ops.push({ store: 'settings', type: 'put', value: { ...d.settings, id: 'app_settings' } });
  addItems('auditLogs', d.auditLogs);
  addItems('recycleBin', d.recycleBin);

  await runTransactionalWrites(ops);
}
