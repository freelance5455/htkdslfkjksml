import test from 'node:test';
import assert from 'node:assert/strict';
import { SharedPreferences, DEFAULT_DEVICE_SETTINGS } from './localDatabase';

test('SharedPreferences returns default settings when uninitialized', () => {
  const settings = SharedPreferences.getSettings();
  assert.equal(settings.timerDurationMinutes, 25);
  assert.equal(settings.breakDurationMinutes, 5);
  assert.equal(settings.soundEnabled, true);
  assert.equal(typeof settings.theme, 'string');
});

test('SharedPreferences getItem with fallback works properly', () => {
  const val = SharedPreferences.getItem('non_existent_key', 42);
  assert.equal(val, 42);

  const str = SharedPreferences.getItem('streak_goal', 'daily');
  assert.equal(str, 'daily');
});
