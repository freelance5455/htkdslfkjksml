import { sql } from "drizzle-orm";
import { getDb } from "./index";

/**
 * Schema reconciliation that is safe for least-privilege production roles.
 *
 * WHY THIS EXISTS
 * ---------------
 * Match Sharing failed in production for two reasons:
 *
 *  1. The migration config had a hardcoded localhost connection string, so
 *     `drizzle-kit push` never reached the deployed database and its schema
 *     drifted behind the code and columns were missing.
 *
 *  2. The first fix always issued `ALTER TABLE`. Managed Postgres deployments
 *     commonly run the app under a role that has DML but NOT DDL rights, so
 *     the repair itself raised `permission denied` / `must be owner of table`
 *     and every cloud request failed with a 503.
 *
 * The strategy is therefore: INSPECT FIRST, and only attempt DDL for the
 * pieces that are genuinely missing. On a correctly-migrated database no DDL
 * is issued at all, so a restricted role works perfectly. If something IS
 * missing and the role cannot fix it, we log precise operator guidance and
 * let the caller decide — a missing optional column must never take down a
 * feature that does not depend on it.
 */

export type SchemaState = {
  /** The matches table is reachable. */
  tableExists: boolean;
  /** Columns the code expects that are absent from the database. */
  missing: string[];
  /** Set when repair was attempted but the role lacked permission. */
  needsMigration: boolean;
};

const EXPECTED: { name: string; ddl: string }[] = [
  { name: "awards", ddl: "ADD COLUMN IF NOT EXISTS awards jsonb" },
  { name: "format", ddl: "ADD COLUMN IF NOT EXISTS format text" },
  { name: "venue", ddl: "ADD COLUMN IF NOT EXISTS venue text" },
  { name: "match_date", ddl: "ADD COLUMN IF NOT EXISTS match_date timestamptz" },
  { name: "status", ddl: "ADD COLUMN IF NOT EXISTS status text" },
  { name: "result", ddl: "ADD COLUMN IF NOT EXISTS result text" },
  { name: "rev", ddl: "ADD COLUMN IF NOT EXISTS rev integer NOT NULL DEFAULT 0" },
];

const globalForSchema = globalThis as typeof globalThis & {
  __matchCricketSchema?: Promise<SchemaState>;
};

/**
 * Detects a privilege failure. Drizzle wraps the driver error, so the whole
 * cause chain is inspected rather than just the top-level message.
 */
function isPermissionError(error: unknown): boolean {
  const parts: string[] = [];
  let cur: unknown = error;
  for (let i = 0; i < 5 && cur; i++) {
    if (cur instanceof Error) {
      parts.push(cur.message);
      const code = (cur as Error & { code?: string }).code;
      if (code) parts.push(code);
      cur = (cur as Error & { cause?: unknown }).cause;
    } else {
      parts.push(String(cur));
      break;
    }
  }
  // 42501 is the Postgres SQLSTATE for insufficient_privilege.
  return /permission denied|must be owner|insufficient privilege|42501/i.test(parts.join(" "));
}

async function readColumns(): Promise<string[] | null> {
  try {
    const res = await getDb().execute<{ column_name: string }>(sql`
      SELECT column_name FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'matches'
    `);
    const rows = (res as unknown as { rows?: { column_name: string }[] }).rows ?? [];
    return rows.map((r) => r.column_name);
  } catch {
    return null;
  }
}

async function reconcile(): Promise<SchemaState> {
  const db = getDb();
  let columns = await readColumns();

  // No table at all — try to create it (a fresh database owned by this role).
  if (columns === null || columns.length === 0) {
    try {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS matches (
          id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
          setup jsonb NOT NULL,
          events jsonb NOT NULL DEFAULT '[]'::jsonb,
          awards jsonb,
          title text NOT NULL,
          format text,
          venue text,
          match_date timestamptz,
          status text,
          result text,
          rev integer NOT NULL DEFAULT 0,
          created_at timestamptz NOT NULL DEFAULT now(),
          updated_at timestamptz NOT NULL DEFAULT now()
        )
      `);
      columns = await readColumns();
    } catch (error) {
      console.error(
        "[match-cricket] SCHEMA_CREATE_FAILED: cannot create the matches table.",
        isPermissionError(error)
          ? "The database role lacks DDL permission. Run `npx drizzle-kit push` with an owner role."
          : error,
      );
      return { tableExists: false, missing: EXPECTED.map((c) => c.name), needsMigration: true };
    }
  }

  const present = new Set(columns ?? []);
  const missing = EXPECTED.filter((c) => !present.has(c.name));

  // Nothing to do — the common production path issues ZERO DDL, so a
  // least-privilege role is never rejected.
  if (missing.length === 0) {
    return { tableExists: true, missing: [], needsMigration: false };
  }

  // Something is genuinely missing: attempt a targeted repair.
  try {
    await db.execute(sql.raw(`ALTER TABLE matches ${missing.map((c) => c.ddl).join(", ")}`));
    console.warn(
      `[match-cricket] SCHEMA_REPAIRED: added ${missing.map((c) => c.name).join(", ")}`,
    );
    return { tableExists: true, missing: [], needsMigration: false };
  } catch (error) {
    const names = missing.map((c) => c.name).join(", ");
    console.error(
      `[match-cricket] SCHEMA_MIGRATION_REQUIRED: missing column(s) [${names}].`,
      isPermissionError(error)
        ? "The database role cannot run DDL. Apply the schema with an owner role: `DATABASE_URL=... npx drizzle-kit push`."
        : error,
    );
    return {
      tableExists: true,
      missing: missing.map((c) => c.name),
      needsMigration: true,
    };
  }
}

/**
 * Returns the current schema state, repairing it when possible.
 * Never throws: callers branch on the returned state instead.
 */
export function ensureSchema(): Promise<SchemaState> {
  if (!globalForSchema.__matchCricketSchema) {
    globalForSchema.__matchCricketSchema = reconcile().catch((error) => {
      globalForSchema.__matchCricketSchema = undefined;
      console.error("[match-cricket] SCHEMA_CHECK_FAILED:", error);
      return {
        tableExists: false,
        missing: EXPECTED.map((c) => c.name),
        needsMigration: true,
      } satisfies SchemaState;
    });
  }
  return globalForSchema.__matchCricketSchema;
}
