import {
  BusinessProfile,
  Product,
  Customer,
  SaleInvoice,
  DueCollection,
  ProductReturn,
  Expense,
  FinancialTransaction,
  StockAddLog,
  CartItem,
  TopSellingProductItem,
  QuickReportSummary,
} from '../types/business';

const STORAGE_KEYS = {
  PROFILE: 'bm_business_profile_v1',
  PRODUCTS: 'bm_products_v1',
  STOCK_LOGS: 'bm_stock_logs_v1',
  CUSTOMERS: 'bm_customers_v1',
  INVOICES: 'bm_invoices_v1',
  DUE_PAYMENTS: 'bm_due_payments_v1',
  RETURNS: 'bm_returns_v1',
  EXPENSES: 'bm_expenses_v1',
  TRANSACTIONS: 'bm_transactions_v1',
  LANGUAGE: 'bm_lang_v1',
};

// Safe localStorage helper
function getLocalItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return fallback;
  }
}

function setLocalItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
}

// Generate human-friendly sequential ID
export function generateInvoiceNumber(existingInvoices: SaleInvoice[]): string {
  const currentYear = new Date().getFullYear();
  const validInvoices = existingInvoices.filter((inv) => !inv.isDeleted);
  const count = validInvoices.length + 1;
  return `INV-${currentYear}-${count.toString().padStart(4, '0')}`;
}

export const StorageService = {
  // 1. BUSINESS PROFILE
  getBusinessProfile(): BusinessProfile | null {
    return getLocalItem<BusinessProfile | null>(STORAGE_KEYS.PROFILE, null);
  },

  saveBusinessProfile(profile: BusinessProfile): void {
    setLocalItem(STORAGE_KEYS.PROFILE, {
      ...profile,
      updatedAt: new Date().toISOString(),
    });
  },

  // 2. PRODUCTS
  getProducts(): Product[] {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    return products.filter((p) => !p.isDeleted);
  },

  getAllProductsIncludingDeleted(): Product[] {
    return getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
  },

  getProductById(id: string): Product | undefined {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    return products.find((p) => p.id === id);
  },

  addProduct(productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const newProduct: Product = {
      ...productData,
      id: `prod_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    products.unshift(newProduct);
    setLocalItem(STORAGE_KEYS.PRODUCTS, products);

    // Initial stock log
    if (newProduct.stockQuantity > 0) {
      this.logStockAdd({
        productId: newProduct.id,
        productName: newProduct.name,
        addedQuantity: newProduct.stockQuantity,
        purchasePrice: newProduct.purchasePrice,
        supplierNote: 'Initial Inventory Setup',
      });
    }

    return newProduct;
  },

  updateProduct(updatedProduct: Product): void {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const index = products.findIndex((p) => p.id === updatedProduct.id);
    if (index !== -1) {
      products[index] = {
        ...updatedProduct,
        updatedAt: new Date().toISOString(),
      };
      setLocalItem(STORAGE_KEYS.PRODUCTS, products);
    }
  },

  deleteProduct(productId: string): boolean {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const index = products.findIndex((p) => p.id === productId);
    if (index !== -1) {
      // Soft delete to ensure historical transactions/invoices remain intact
      products[index].isDeleted = true;
      products[index].updatedAt = new Date().toISOString();
      setLocalItem(STORAGE_KEYS.PRODUCTS, products);
      return true;
    }
    return false;
  },

  addStockToProduct(productId: string, addedQty: number, purchasePrice: number, note?: string): boolean {
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const index = products.findIndex((p) => p.id === productId);
    if (index !== -1 && addedQty > 0) {
      products[index].stockQuantity += addedQty;
      if (purchasePrice > 0) {
        products[index].purchasePrice = purchasePrice;
      }
      products[index].updatedAt = new Date().toISOString();
      setLocalItem(STORAGE_KEYS.PRODUCTS, products);

      this.logStockAdd({
        productId,
        productName: products[index].name,
        addedQuantity: addedQty,
        purchasePrice: purchasePrice > 0 ? purchasePrice : products[index].purchasePrice,
        supplierNote: note,
      });

      return true;
    }
    return false;
  },

  // STOCK ADD LOGS
  logStockAdd(log: Omit<StockAddLog, 'id' | 'date' | 'time'>): void {
    const logs = getLocalItem<StockAddLog[]>(STORAGE_KEYS.STOCK_LOGS, []);
    const now = new Date();
    logs.unshift({
      ...log,
      id: `stock_${Date.now()}`,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString(),
    });
    setLocalItem(STORAGE_KEYS.STOCK_LOGS, logs);
  },

  getStockLogs(): StockAddLog[] {
    return getLocalItem<StockAddLog[]>(STORAGE_KEYS.STOCK_LOGS, []);
  },

  // 3. CUSTOMERS
  getCustomers(): Customer[] {
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    return customers.filter((c) => !c.isDeleted);
  },

  getCustomerById(id: string): Customer | undefined {
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    return customers.find((c) => c.id === id);
  },

  addCustomer(customerData: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalPaid' | 'currentDue'>): Customer {
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const newCustomer: Customer = {
      ...customerData,
      id: `cust_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      totalPurchases: 0,
      totalPaid: 0,
      currentDue: 0,
      createdAt: new Date().toISOString(),
    };
    customers.unshift(newCustomer);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    return newCustomer;
  },

  updateCustomer(updatedCustomer: Customer): void {
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const index = customers.findIndex((c) => c.id === updatedCustomer.id);
    if (index !== -1) {
      customers[index] = updatedCustomer;
      setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    }
  },

  deleteCustomer(customerId: string): boolean {
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const index = customers.findIndex((c) => c.id === customerId);
    if (index !== -1) {
      customers[index].isDeleted = true;
      setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
      return true;
    }
    return false;
  },

  // 4. SALES / INVOICES (ATOMIC EXECUTION)
  getInvoices(): SaleInvoice[] {
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    return invoices.filter((inv) => !inv.isDeleted);
  },

  getInvoiceById(id: string): SaleInvoice | undefined {
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    return invoices.find((inv) => inv.id === id);
  },

  createSaleInvoice(data: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    customerAddress?: string;
    items: CartItem[];
    discount: number;
    paymentMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Due';
    paidAmount: number;
    dueDate?: string;
  }): SaleInvoice {
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    // 1. Calculate totals
    const totalProducts = data.items.length;
    const totalQuantity = data.items.reduce((sum, item) => sum + item.quantity, 0);
    const totalSalesAmount = data.items.reduce((sum, item) => sum + item.totalPrice, 0);
    const totalPurchaseAmount = data.items.reduce((sum, item) => sum + (item.purchasePrice * item.quantity), 0);
    const grossProfit = totalSalesAmount - totalPurchaseAmount;
    const discount = Number(data.discount) || 0;
    const finalPayableAmount = Math.max(0, totalSalesAmount - discount);
    const netProfit = grossProfit - discount;

    const paidAmount = Number(data.paidAmount) || 0;
    const dueAmount = Math.max(0, finalPayableAmount - paidAmount);

    const now = new Date();
    const invoiceNumber = generateInvoiceNumber(invoices);
    const newInvoice: SaleInvoice = {
      id: `inv_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      invoiceNumber,
      customerId: data.customerId,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      customerAddress: data.customerAddress,
      items: data.items,
      totalProducts,
      totalQuantity,
      totalSalesAmount,
      totalPurchaseAmount,
      grossProfit,
      discount,
      finalPayableAmount,
      netProfit,
      paymentMethod: data.paymentMethod,
      paidAmount,
      dueAmount,
      dueDate: data.dueDate,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      returnedQuantities: {},
    };

    // 2. Decrease product stock atomically
    data.items.forEach((item) => {
      const pIndex = products.findIndex((p) => p.id === item.productId);
      if (pIndex !== -1) {
        products[pIndex].stockQuantity = Math.max(0, products[pIndex].stockQuantity - item.quantity);
        products[pIndex].updatedAt = now.toISOString();
      }
    });

    // 3. Update customer purchase & due history
    if (data.customerId && data.customerId !== 'walk-in') {
      const cIndex = customers.findIndex((c) => c.id === data.customerId);
      if (cIndex !== -1) {
        customers[cIndex].totalPurchases += finalPayableAmount;
        customers[cIndex].totalPaid += paidAmount;
        customers[cIndex].currentDue += dueAmount;
      }
    }

    // 4. Record financial transaction
    transactions.unshift({
      id: `txn_${Date.now()}`,
      type: 'Sale',
      refId: newInvoice.id,
      invoiceNumber: newInvoice.invoiceNumber,
      customerName: newInvoice.customerName,
      amount: finalPayableAmount,
      paid: paidAmount,
      due: dueAmount,
      paymentMethod: data.paymentMethod,
      description: `বিক্রয়: ${newInvoice.items.map((i) => `${i.modelNumber} (${i.quantity})`).join(', ')}`,
      date: newInvoice.date,
      time: newInvoice.time,
    });

    // Commit all changes atomically
    invoices.unshift(newInvoice);
    setLocalItem(STORAGE_KEYS.INVOICES, invoices);
    setLocalItem(STORAGE_KEYS.PRODUCTS, products);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions);

    return newInvoice;
  },

  // 5. EDIT SALE (Reverse old effect -> Apply new effect)
  updateSaleInvoice(invoiceId: string, updatedData: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    items: CartItem[];
    discount: number;
    paymentMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Due';
    paidAmount: number;
    dueDate?: string;
  }): SaleInvoice | null {
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    const invIndex = invoices.findIndex((i) => i.id === invoiceId);
    if (invIndex === -1) return null;

    const oldInvoice = invoices[invIndex];
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    // 1. REVERSE OLD SALE EFFECTS
    // Restore product stock
    oldInvoice.items.forEach((oldItem) => {
      const pIndex = products.findIndex((p) => p.id === oldItem.productId);
      if (pIndex !== -1) {
        products[pIndex].stockQuantity += oldItem.quantity;
      }
    });

    // Reverse old customer totals
    if (oldInvoice.customerId && oldInvoice.customerId !== 'walk-in') {
      const cIndex = customers.findIndex((c) => c.id === oldInvoice.customerId);
      if (cIndex !== -1) {
        customers[cIndex].totalPurchases -= oldInvoice.finalPayableAmount;
        customers[cIndex].totalPaid -= oldInvoice.paidAmount;
        customers[cIndex].currentDue -= oldInvoice.dueAmount;
      }
    }

    // 2. CALCULATE NEW TOTALS
    const totalProducts = updatedData.items.length;
    const totalQuantity = updatedData.items.reduce((sum, item) => sum + item.quantity, 0);
    const totalSalesAmount = updatedData.items.reduce((sum, item) => sum + item.totalPrice, 0);
    const totalPurchaseAmount = updatedData.items.reduce((sum, item) => sum + (item.purchasePrice * item.quantity), 0);
    const grossProfit = totalSalesAmount - totalPurchaseAmount;
    const discount = Number(updatedData.discount) || 0;
    const finalPayableAmount = Math.max(0, totalSalesAmount - discount);
    const netProfit = grossProfit - discount;

    const paidAmount = Number(updatedData.paidAmount) || 0;
    const dueAmount = Math.max(0, finalPayableAmount - paidAmount);

    const now = new Date();

    // 3. APPLY NEW PRODUCT STOCK DECREMENT
    updatedData.items.forEach((item) => {
      const pIndex = products.findIndex((p) => p.id === item.productId);
      if (pIndex !== -1) {
        products[pIndex].stockQuantity = Math.max(0, products[pIndex].stockQuantity - item.quantity);
      }
    });

    // 4. APPLY NEW CUSTOMER TOTALS
    if (updatedData.customerId && updatedData.customerId !== 'walk-in') {
      const cIndex = customers.findIndex((c) => c.id === updatedData.customerId);
      if (cIndex !== -1) {
        customers[cIndex].totalPurchases += finalPayableAmount;
        customers[cIndex].totalPaid += paidAmount;
        customers[cIndex].currentDue += dueAmount;
      }
    }

    // 5. UPDATE INVOICE
    const updatedInvoice: SaleInvoice = {
      ...oldInvoice,
      customerId: updatedData.customerId,
      customerName: updatedData.customerName,
      customerPhone: updatedData.customerPhone,
      items: updatedData.items,
      totalProducts,
      totalQuantity,
      totalSalesAmount,
      totalPurchaseAmount,
      grossProfit,
      discount,
      finalPayableAmount,
      netProfit,
      paymentMethod: updatedData.paymentMethod,
      paidAmount,
      dueAmount,
      dueDate: updatedData.dueDate,
      updatedAt: now.toISOString(),
    };

    invoices[invIndex] = updatedInvoice;

    // Update transaction
    const txnIndex = transactions.findIndex((t) => t.refId === invoiceId);
    if (txnIndex !== -1) {
      transactions[txnIndex] = {
        ...transactions[txnIndex],
        amount: finalPayableAmount,
        paid: paidAmount,
        due: dueAmount,
        paymentMethod: updatedData.paymentMethod,
        customerName: updatedData.customerName,
        description: `বিক্রয় (সম্পাদিত): ${updatedInvoice.items.map((i) => `${i.modelNumber} (${i.quantity})`).join(', ')}`,
      };
    }

    // Commit all
    setLocalItem(STORAGE_KEYS.INVOICES, invoices);
    setLocalItem(STORAGE_KEYS.PRODUCTS, products);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions);

    return updatedInvoice;
  },

  // 6. DELETE SALE (Reverse all accounting & return stock)
  deleteSaleInvoice(invoiceId: string): boolean {
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    const invIndex = invoices.findIndex((i) => i.id === invoiceId);
    if (invIndex === -1) return false;

    const oldInvoice = invoices[invIndex];
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    // 1. Return sold items to stock
    oldInvoice.items.forEach((item) => {
      const pIndex = products.findIndex((p) => p.id === item.productId);
      if (pIndex !== -1) {
        products[pIndex].stockQuantity += item.quantity;
      }
    });

    // 2. Adjust customer totals
    if (oldInvoice.customerId && oldInvoice.customerId !== 'walk-in') {
      const cIndex = customers.findIndex((c) => c.id === oldInvoice.customerId);
      if (cIndex !== -1) {
        customers[cIndex].totalPurchases = Math.max(0, customers[cIndex].totalPurchases - oldInvoice.finalPayableAmount);
        customers[cIndex].totalPaid = Math.max(0, customers[cIndex].totalPaid - oldInvoice.paidAmount);
        customers[cIndex].currentDue = Math.max(0, customers[cIndex].currentDue - oldInvoice.dueAmount);
      }
    }

    // 3. Mark invoice deleted
    invoices[invIndex].isDeleted = true;
    invoices[invIndex].updatedAt = new Date().toISOString();

    // 4. Log or filter out transaction
    const remainingTransactions = transactions.filter((t) => t.refId !== invoiceId);

    // Commit
    setLocalItem(STORAGE_KEYS.INVOICES, invoices);
    setLocalItem(STORAGE_KEYS.PRODUCTS, products);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, remainingTransactions);

    return true;
  },

  // 7. DUE PAYMENTS / COLLECTION
  getDueCollections(): DueCollection[] {
    return getLocalItem<DueCollection[]>(STORAGE_KEYS.DUE_PAYMENTS, []);
  },

  recordDuePayment(data: {
    customerId: string;
    customerName: string;
    invoiceId?: string;
    invoiceNumber?: string;
    amount: number;
    paymentMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank';
    note?: string;
  }): DueCollection {
    const dueCollections = getLocalItem<DueCollection[]>(STORAGE_KEYS.DUE_PAYMENTS, []);
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    const now = new Date();
    const newCollection: DueCollection = {
      id: `due_pay_${Date.now()}`,
      customerId: data.customerId,
      customerName: data.customerName,
      invoiceId: data.invoiceId,
      invoiceNumber: data.invoiceNumber,
      amount: data.amount,
      paymentMethod: data.paymentMethod,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: data.note,
    };

    // Update customer due
    const cIndex = customers.findIndex((c) => c.id === data.customerId);
    if (cIndex !== -1) {
      customers[cIndex].currentDue = Math.max(0, customers[cIndex].currentDue - data.amount);
      customers[cIndex].totalPaid += data.amount;
    }

    // If specific invoice linked, reduce due on invoice as well
    if (data.invoiceId) {
      const invIndex = invoices.findIndex((i) => i.id === data.invoiceId);
      if (invIndex !== -1) {
        invoices[invIndex].dueAmount = Math.max(0, invoices[invIndex].dueAmount - data.amount);
        invoices[invIndex].paidAmount += data.amount;
      }
    }

    // Record transaction
    transactions.unshift({
      id: `txn_${Date.now()}`,
      type: 'Due Collection',
      refId: newCollection.id,
      invoiceNumber: data.invoiceNumber,
      customerName: data.customerName,
      amount: data.amount,
      paid: data.amount,
      due: 0,
      paymentMethod: data.paymentMethod,
      description: `বাকি আদায়: ${data.customerName}${data.invoiceNumber ? ` (${data.invoiceNumber})` : ''}`,
      date: newCollection.date,
      time: newCollection.time,
    });

    dueCollections.unshift(newCollection);
    setLocalItem(STORAGE_KEYS.DUE_PAYMENTS, dueCollections);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    setLocalItem(STORAGE_KEYS.INVOICES, invoices);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions);

    return newCollection;
  },

  // 8. PRODUCT RETURNS
  getReturns(): ProductReturn[] {
    return getLocalItem<ProductReturn[]>(STORAGE_KEYS.RETURNS, []);
  },

  recordProductReturn(data: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    invoiceId: string;
    invoiceNumber: string;
    productId: string;
    productName: string;
    brand: string;
    model: string;
    quantity: number;
    unitPrice: number;
    refundMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Deduct Due';
    reason?: string;
  }): ProductReturn {
    const returns = getLocalItem<ProductReturn[]>(STORAGE_KEYS.RETURNS, []);
    const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
    const products = getLocalItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
    const customers = getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    const now = new Date();
    const returnAmount = data.quantity * data.unitPrice;

    // Find original product purchase cost for profit adjustment
    const pIndex = products.findIndex((p) => p.id === data.productId);
    const purchaseCost = pIndex !== -1 ? products[pIndex].purchasePrice : data.unitPrice * 0.7;
    const profitAdjustment = (data.unitPrice - purchaseCost) * data.quantity;

    const newReturn: ProductReturn = {
      id: `ret_${Date.now()}`,
      customerId: data.customerId,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      invoiceId: data.invoiceId,
      invoiceNumber: data.invoiceNumber,
      productId: data.productId,
      productName: data.productName,
      brand: data.brand,
      model: data.model,
      quantity: data.quantity,
      unitPrice: data.unitPrice,
      returnAmount,
      profitAdjustment,
      refundMethod: data.refundMethod,
      reason: data.reason,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // 1. Restore product stock
    if (pIndex !== -1) {
      products[pIndex].stockQuantity += data.quantity;
      products[pIndex].updatedAt = now.toISOString();
    }

    // 2. Link return to original invoice
    const invIndex = invoices.findIndex((i) => i.id === data.invoiceId);
    if (invIndex !== -1) {
      if (!invoices[invIndex].returnedQuantities) {
        invoices[invIndex].returnedQuantities = {};
      }
      invoices[invIndex].returnedQuantities![data.productId] =
        (invoices[invIndex].returnedQuantities![data.productId] || 0) + data.quantity;
      // Adjust invoice net profit
      invoices[invIndex].netProfit = Math.max(0, invoices[invIndex].netProfit - profitAdjustment);
    }

    // 3. Customer adjustment
    if (data.customerId && data.customerId !== 'walk-in') {
      const cIndex = customers.findIndex((c) => c.id === data.customerId);
      if (cIndex !== -1) {
        customers[cIndex].totalPurchases = Math.max(0, customers[cIndex].totalPurchases - returnAmount);
        if (data.refundMethod === 'Deduct Due') {
          customers[cIndex].currentDue = Math.max(0, customers[cIndex].currentDue - returnAmount);
        }
      }
    }

    // 4. Log transaction
    transactions.unshift({
      id: `txn_${Date.now()}`,
      type: 'Return',
      refId: newReturn.id,
      invoiceNumber: data.invoiceNumber,
      customerName: data.customerName,
      amount: returnAmount,
      paid: data.refundMethod === 'Deduct Due' ? 0 : returnAmount,
      due: 0,
      paymentMethod: data.refundMethod === 'Deduct Due' ? 'Due' : (data.refundMethod as any),
      description: `রিটার্ন: ${data.model} (${data.quantity} পিস) - চালান: ${data.invoiceNumber}`,
      date: newReturn.date,
      time: newReturn.time,
    });

    returns.unshift(newReturn);
    setLocalItem(STORAGE_KEYS.RETURNS, returns);
    setLocalItem(STORAGE_KEYS.INVOICES, invoices);
    setLocalItem(STORAGE_KEYS.PRODUCTS, products);
    setLocalItem(STORAGE_KEYS.CUSTOMERS, customers);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions);

    return newReturn;
  },

  // 9. EXPENSES
  getExpenses(): Expense[] {
    return getLocalItem<Expense[]>(STORAGE_KEYS.EXPENSES, []);
  },

  addExpense(data: {
    category: string;
    description: string;
    amount: number;
    paymentMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank';
    note?: string;
  }): Expense {
    const expenses = getLocalItem<Expense[]>(STORAGE_KEYS.EXPENSES, []);
    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);

    const now = new Date();
    const newExpense: Expense = {
      id: `exp_${Date.now()}`,
      category: data.category,
      description: data.description,
      amount: data.amount,
      paymentMethod: data.paymentMethod,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: data.note,
    };

    transactions.unshift({
      id: `txn_${Date.now()}`,
      type: 'Expense',
      refId: newExpense.id,
      amount: data.amount,
      paid: data.amount,
      due: 0,
      paymentMethod: data.paymentMethod,
      description: `খরচ (${data.category}): ${data.description}`,
      date: newExpense.date,
      time: newExpense.time,
    });

    expenses.unshift(newExpense);
    setLocalItem(STORAGE_KEYS.EXPENSES, expenses);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions);

    return newExpense;
  },

  deleteExpense(expenseId: string): boolean {
    const expenses = getLocalItem<Expense[]>(STORAGE_KEYS.EXPENSES, []);
    const remaining = expenses.filter((e) => e.id !== expenseId);
    setLocalItem(STORAGE_KEYS.EXPENSES, remaining);

    const transactions = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    setLocalItem(STORAGE_KEYS.TRANSACTIONS, transactions.filter((t) => t.refId !== expenseId));

    return true;
  },

  // 10. FINANCIAL TRANSACTIONS
  getTransactions(): FinancialTransaction[] {
    return getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
  },

  // 11. DASHBOARD LIVE CALCULATED METRICS
  getDashboardMetrics() {
    const today = new Date().toISOString().split('T')[0];
    const invoices = this.getInvoices();
    const returns = this.getReturns();
    const expenses = this.getExpenses();
    const customers = this.getCustomers();
    const products = this.getProducts();
    const dueCollections = this.getDueCollections();

    // Today's Sales: sum of finalPayableAmount of today's invoices minus returns today
    const todayInvoices = invoices.filter((i) => i.date === today);
    const todayReturns = returns.filter((r) => r.date === today);
    const todayReturnAmount = todayReturns.reduce((sum, r) => sum + r.returnAmount, 0);
    const todaySales = Math.max(0, todayInvoices.reduce((sum, i) => sum + i.finalPayableAmount, 0) - todayReturnAmount);

    // Total Sales: sum of all invoices minus returns
    const allReturnAmount = returns.reduce((sum, r) => sum + r.returnAmount, 0);
    const totalSales = Math.max(0, invoices.reduce((sum, i) => sum + i.finalPayableAmount, 0) - allReturnAmount);

    // Today's Profit: today's invoice netProfit - today's return profit adjustment - today's expenses
    const todayExpenses = expenses.filter((e) => e.date === today).reduce((sum, e) => sum + e.amount, 0);
    const todayReturnProfitAdj = todayReturns.reduce((sum, r) => sum + r.profitAdjustment, 0);
    const todayProfit = todayInvoices.reduce((sum, i) => sum + i.netProfit, 0) - todayReturnProfitAdj - todayExpenses;

    // Total Profit: all invoice netProfit - all return profit adjustments - all expenses
    const allExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const allReturnProfitAdj = returns.reduce((sum, r) => sum + r.profitAdjustment, 0);
    const totalProfit = invoices.reduce((sum, i) => sum + i.netProfit, 0) - allReturnProfitAdj - allExpenses;

    // Total Stock: total pieces & total purchase valuation
    const totalStockQty = products.reduce((sum, p) => sum + p.stockQuantity, 0);
    const totalStockValue = products.reduce((sum, p) => sum + (p.stockQuantity * p.purchasePrice), 0);

    // Total Due: sum of customer dues
    const totalDue = customers.reduce((sum, c) => sum + (c.currentDue || 0), 0);

    // Cash Balance:
    // Cash received from sales + Cash collected from dues - Cash refunds on returns - Cash expenses
    const cashSales = invoices.reduce((sum, i) => {
      if (i.paymentMethod === 'Cash') return sum + i.paidAmount;
      return sum;
    }, 0);
    const cashDueCollected = dueCollections.reduce((sum, d) => {
      if (d.paymentMethod === 'Cash') return sum + d.amount;
      return sum;
    }, 0);
    const cashReturnsRefunded = returns.reduce((sum, r) => {
      if (r.refundMethod === 'Cash') return sum + r.returnAmount;
      return sum;
    }, 0);
    const cashExpenses = expenses.reduce((sum, e) => {
      if (e.paymentMethod === 'Cash') return sum + e.amount;
      return sum;
    }, 0);

    const cashBalance = cashSales + cashDueCollected - cashReturnsRefunded - cashExpenses;

    return {
      todayProfit,
      totalProfit,
      todaySales,
      totalSales,
      totalStockQty,
      totalStockValue,
      totalDue,
      cashBalance,
    };
  },

  // 12. STOCK ALERT PRODUCTS
  getStockAlertProducts() {
    const products = this.getProducts();
    const stockOut = products.filter((p) => p.stockQuantity === 0);
    const limitedStock = products.filter((p) => p.stockQuantity > 0 && p.stockQuantity <= p.alertLimit);
    return {
      stockOut,
      limitedStock,
      totalAlerts: stockOut.length + limitedStock.length,
    };
  },

  // 13. PRODUCT-WISE PROFIT
  getProductProfitSummary() {
    const products = this.getAllProductsIncludingDeleted();
    const invoices = this.getInvoices();
    const returns = this.getReturns();

    const summaryMap: {
      [productId: string]: {
        product: Product;
        quantitySold: number;
        purchaseValue: number;
        salesValue: number;
        totalProfit: number;
        returnedQuantity: number;
        adjustedProfit: number;
      };
    } = {};

    products.forEach((p) => {
      summaryMap[p.id] = {
        product: p,
        quantitySold: 0,
        purchaseValue: 0,
        salesValue: 0,
        totalProfit: 0,
        returnedQuantity: 0,
        adjustedProfit: 0,
      };
    });

    invoices.forEach((inv) => {
      inv.items.forEach((item) => {
        if (!summaryMap[item.productId]) {
          const fallbackProduct: Product = {
            id: item.productId,
            name: item.productName,
            category: item.category,
            brand: item.brand,
            modelNumber: item.modelNumber,
            supportedModels: '',
            condition: 'New',
            frontPhoto: '',
            backPhoto: '',
            stockQuantity: 0,
            purchasePrice: item.purchasePrice,
            retailPrice: item.unitPrice,
            wholesalePrice: item.unitPrice,
            alertLimit: 5,
            createdAt: '',
            updatedAt: '',
          };
          summaryMap[item.productId] = {
            product: fallbackProduct,
            quantitySold: 0,
            purchaseValue: 0,
            salesValue: 0,
            totalProfit: 0,
            returnedQuantity: 0,
            adjustedProfit: 0,
          };
        }
        summaryMap[item.productId].quantitySold += item.quantity;
        summaryMap[item.productId].purchaseValue += item.purchasePrice * item.quantity;
        summaryMap[item.productId].salesValue += item.totalPrice;
        summaryMap[item.productId].totalProfit += item.profit;
      });
    });

    returns.forEach((ret) => {
      if (summaryMap[ret.productId]) {
        summaryMap[ret.productId].returnedQuantity += ret.quantity;
        summaryMap[ret.productId].adjustedProfit += ret.profitAdjustment;
      }
    });

    return Object.values(summaryMap)
      .map((entry) => ({
        ...entry,
        netProfit: entry.totalProfit - entry.adjustedProfit,
      }))
      .filter((e) => e.quantitySold > 0 || e.product.stockQuantity > 0);
  },

  // 14. DUE CUSTOMERS ALERT
  getDueCustomers() {
    const customers = this.getCustomers();
    const invoices = this.getInvoices();

    return customers
      .filter((c) => c.currentDue > 0)
      .map((c) => {
        const customerInvoices = invoices.filter((i) => i.customerId === c.id && i.dueAmount > 0);
        const latestInvoice = customerInvoices[0];
        let overdueDays = 0;
        if (latestInvoice) {
          const invDate = new Date(latestInvoice.date);
          const diffMs = Date.now() - invDate.getTime();
          overdueDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        }
        return {
          customer: c,
          dueAmount: c.currentDue,
          latestInvoiceNumber: latestInvoice?.invoiceNumber,
          latestInvoiceId: latestInvoice?.id,
          dueDate: latestInvoice?.dueDate,
          overdueDays,
        };
      })
      .sort((a, b) => b.dueAmount - a.dueAmount);
  },

  // 14B. QUICK REPORT: TOP SELLING PRODUCTS FOR CURRENT MONTH (QUERIED FROM TRANSACTION DATA)
  getQuickReportTopProducts(limit: number = 3): QuickReportSummary {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonthNum = now.getMonth() + 1;
    const currentMonthKey = `${currentYear}-${String(currentMonthNum).padStart(2, '0')}`;

    const monthNamesBn = [
      'জানুয়ারী', 'ফেব্রুয়ারী', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];
    const monthNameBn = `${monthNamesBn[now.getMonth()]} ${currentYear}`;

    // Query financial transactions and invoices for current month
    const allTransactions = this.getTransactions();
    const currentMonthSaleTxns = allTransactions.filter(
      (t) => t.type === 'Sale' && t.date && t.date.startsWith(currentMonthKey)
    );
    const saleInvoiceRefIds = new Set(currentMonthSaleTxns.map((t) => t.refId));

    // Get non-deleted invoices matching the current month's sales transactions
    const allInvoices = this.getInvoices();
    const invoices = allInvoices.filter(
      (inv) =>
        !inv.isDeleted &&
        inv.date &&
        inv.date.startsWith(currentMonthKey) &&
        (saleInvoiceRefIds.size === 0 || saleInvoiceRefIds.has(inv.id))
    );

    const returns = this.getReturns().filter((ret) => ret.date && ret.date.startsWith(currentMonthKey));
    const products = this.getAllProductsIncludingDeleted();
    const productMap = new Map<string, Product>();
    products.forEach((p) => productMap.set(p.id, p));

    const salesByProduct: {
      [productId: string]: {
        productId: string;
        productName: string;
        category: any;
        brand: any;
        modelNumber: string;
        frontPhoto?: string;
        quantitySold: number;
        totalSalesValue: number;
        purchasePrice: number;
        retailPrice: number;
        wholesalePrice: number;
      };
    } = {};

    let totalUnitsSoldInMonth = 0;
    let totalSalesValueInMonth = 0;

    invoices.forEach((inv) => {
      inv.items.forEach((item) => {
        if (!salesByProduct[item.productId]) {
          const liveProd = productMap.get(item.productId);
          salesByProduct[item.productId] = {
            productId: item.productId,
            productName: liveProd?.name || item.productName,
            category: liveProd?.category || item.category,
            brand: liveProd?.brand || item.brand,
            modelNumber: liveProd?.modelNumber || item.modelNumber,
            frontPhoto: liveProd?.frontPhoto || item.frontPhoto,
            quantitySold: 0,
            totalSalesValue: 0,
            purchasePrice: liveProd?.purchasePrice || item.purchasePrice,
            retailPrice: liveProd?.retailPrice || item.unitPrice,
            wholesalePrice: liveProd?.wholesalePrice || item.unitPrice,
          };
        }
        salesByProduct[item.productId].quantitySold += item.quantity;
        salesByProduct[item.productId].totalSalesValue += item.totalPrice;
        totalUnitsSoldInMonth += item.quantity;
        totalSalesValueInMonth += item.totalPrice;
      });
    });

    // Subtract returns in current month
    returns.forEach((ret) => {
      if (salesByProduct[ret.productId]) {
        const netQty = Math.max(0, salesByProduct[ret.productId].quantitySold - ret.quantity);
        const netVal = Math.max(0, salesByProduct[ret.productId].totalSalesValue - ret.returnAmount);
        totalUnitsSoldInMonth = Math.max(0, totalUnitsSoldInMonth - ret.quantity);
        totalSalesValueInMonth = Math.max(0, totalSalesValueInMonth - ret.returnAmount);
        salesByProduct[ret.productId].quantitySold = netQty;
        salesByProduct[ret.productId].totalSalesValue = netVal;
      }
    });

    // Query previous month sales to calculate trend & growth percentage
    const prevMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const prevMonthKey = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}`;
    const prevInvoices = allInvoices.filter(
      (inv) => !inv.isDeleted && inv.date && inv.date.startsWith(prevMonthKey)
    );
    const prevReturns = this.getReturns().filter(
      (ret) => ret.date && ret.date.startsWith(prevMonthKey)
    );

    const prevMonthSalesByProduct: { [productId: string]: number } = {};
    prevInvoices.forEach((inv) => {
      inv.items.forEach((item) => {
        prevMonthSalesByProduct[item.productId] =
          (prevMonthSalesByProduct[item.productId] || 0) + item.quantity;
      });
    });
    prevReturns.forEach((ret) => {
      if (prevMonthSalesByProduct[ret.productId]) {
        prevMonthSalesByProduct[ret.productId] = Math.max(
          0,
          prevMonthSalesByProduct[ret.productId] - ret.quantity
        );
      }
    });

    // Transform and calculate replenishment recommendations & monthly popularity shift
    const rankedList: TopSellingProductItem[] = Object.values(salesByProduct)
      .filter((item) => item.quantitySold > 0)
      .map((item) => {
        const liveProd = productMap.get(item.productId);
        const currentStock = liveProd ? liveProd.stockQuantity : 0;
        const alertLimit = liveProd ? liveProd.alertLimit : 5;

        let replenishmentUrgency: 'critical' | 'warning' | 'caution' | 'healthy' = 'healthy';
        let replenishmentLabel = 'পর্যাপ্ত মজুদ (Healthy)';
        let replenishmentRecommendation = 'চলতি চাহিদার জন্য বর্তমান মজুদ পর্যাপ্ত রয়েছে';

        if (currentStock === 0) {
          replenishmentUrgency = 'critical';
          replenishmentLabel = 'স্টক শেষ / জরুরী রিস্টক (Urgent)';
          replenishmentRecommendation = `চলতি মাসে ${item.quantitySold} পিস বিক্রি হয়েছে কিন্তু বর্তমানে স্টক শূন্য! জরুরী ভিত্তিতে মাল সংগ্রহ করুন।`;
        } else if (currentStock <= alertLimit) {
          replenishmentUrgency = 'warning';
          replenishmentLabel = 'সীমিত স্টক / দ্রুত অর্ডার করুন (Low Stock)';
          replenishmentRecommendation = `মাত্র ${currentStock} পিস অবশিষ্ট রয়েছে (অ্যালার্ট লেভেল ${alertLimit})। দ্রুত নতুন লট অর্ডার দিন।`;
        } else if (currentStock <= Math.ceil(item.quantitySold * 0.7)) {
          replenishmentUrgency = 'caution';
          replenishmentLabel = 'উচ্চ চাহিদা / মজুদ বৃদ্ধির সুপারিশ (High Demand)';
          replenishmentRecommendation = `বিক্রির গতি বেশি (${item.quantitySold} পিস/মাস)। চাহিদা অনুযায়ী মজুদ বাড়ানোর পরিকল্পনা করুন।`;
        }

        // Calculate growth trend compared to previous month
        const lastMonthQuantitySold = prevMonthSalesByProduct[item.productId] || 0;
        let growthPercentage = 0;
        let growthDirection: 'up' | 'down' | 'neutral' | 'new' = 'neutral';
        let growthLabel = '০%';

        if (lastMonthQuantitySold === 0) {
          if (item.quantitySold > 0) {
            growthDirection = 'new';
            growthPercentage = 100;
            growthLabel = 'নতুন (New)';
          } else {
            growthDirection = 'neutral';
            growthPercentage = 0;
            growthLabel = '০%';
          }
        } else {
          const diff = item.quantitySold - lastMonthQuantitySold;
          const pct = Math.round((diff / lastMonthQuantitySold) * 100);
          growthPercentage = pct;
          if (pct > 0) {
            growthDirection = 'up';
            growthLabel = `+${pct}%`;
          } else if (pct < 0) {
            growthDirection = 'down';
            growthLabel = `${pct}%`;
          } else {
            growthDirection = 'neutral';
            growthLabel = '০%';
          }
        }

        return {
          ...item,
          currentStock,
          alertLimit,
          replenishmentUrgency,
          replenishmentLabel,
          replenishmentRecommendation,
          lastMonthQuantitySold,
          growthPercentage,
          growthDirection,
          growthLabel,
        };
      })
      .sort((a, b) => b.quantitySold - a.quantitySold);

    const topProducts = rankedList.slice(0, limit);

    return {
      monthName: monthNameBn,
      monthKey: currentMonthKey,
      year: currentYear,
      topProducts,
      totalUnitsSoldInMonth,
      totalSalesValueInMonth,
      totalProductsSoldInMonth: rankedList.length,
    };
  },

  // 15. GLOBAL SEARCH
  searchAll(query: string) {
    const q = query.trim().toLowerCase();
    if (!q) {
      return { products: [], customers: [], invoices: [] };
    }

    const products = this.getProducts().filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.modelNumber.toLowerCase().includes(q) ||
        p.supportedModels.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
    );

    const customers = this.getCustomers().filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        (c.whatsapp && c.whatsapp.toLowerCase().includes(q)) ||
        (c.address && c.address.toLowerCase().includes(q))
    );

    const invoices = this.getInvoices().filter(
      (i) =>
        i.invoiceNumber.toLowerCase().includes(q) ||
        i.customerName.toLowerCase().includes(q) ||
        i.customerPhone.toLowerCase().includes(q) ||
        i.items.some((it) => it.modelNumber.toLowerCase().includes(q) || it.brand.toLowerCase().includes(q))
    );

    return { products, customers, invoices };
  },

  // 16. BACKUP & RESTORE
  exportBackupJson(): string {
    const backupData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      profile: this.getBusinessProfile(),
      products: getLocalItem(STORAGE_KEYS.PRODUCTS, []),
      stockLogs: getLocalItem(STORAGE_KEYS.STOCK_LOGS, []),
      customers: getLocalItem(STORAGE_KEYS.CUSTOMERS, []),
      invoices: getLocalItem(STORAGE_KEYS.INVOICES, []),
      duePayments: getLocalItem(STORAGE_KEYS.DUE_PAYMENTS, []),
      returns: getLocalItem(STORAGE_KEYS.RETURNS, []),
      expenses: getLocalItem(STORAGE_KEYS.EXPENSES, []),
      transactions: getLocalItem(STORAGE_KEYS.TRANSACTIONS, []),
    };
    return JSON.stringify(backupData, null, 2);
  },

  importBackupJson(jsonString: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data.profile && !data.products && !data.invoices) {
        return { success: false, message: 'অকার্যকর ব্যাকআপ ফাইল' };
      }

      if (data.profile) setLocalItem(STORAGE_KEYS.PROFILE, data.profile);
      if (Array.isArray(data.products)) setLocalItem(STORAGE_KEYS.PRODUCTS, data.products);
      if (Array.isArray(data.stockLogs)) setLocalItem(STORAGE_KEYS.STOCK_LOGS, data.stockLogs);
      if (Array.isArray(data.customers)) setLocalItem(STORAGE_KEYS.CUSTOMERS, data.customers);
      if (Array.isArray(data.invoices)) setLocalItem(STORAGE_KEYS.INVOICES, data.invoices);
      if (Array.isArray(data.duePayments)) setLocalItem(STORAGE_KEYS.DUE_PAYMENTS, data.duePayments);
      if (Array.isArray(data.returns)) setLocalItem(STORAGE_KEYS.RETURNS, data.returns);
      if (Array.isArray(data.expenses)) setLocalItem(STORAGE_KEYS.EXPENSES, data.expenses);
      if (Array.isArray(data.transactions)) setLocalItem(STORAGE_KEYS.TRANSACTIONS, data.transactions);

      return { success: true, message: 'ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!' };
    } catch (e: any) {
      return { success: false, message: e.message || 'রিস্টোর করতে সমস্যা হয়েছে' };
    }
  },

  // 17. LOAD SAMPLE MOBILE PARTS DATA (Optional for instant testing)
  loadSampleMobileParts(): void {
    const sampleProducts: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        name: 'Samsung Galaxy A12 Original LCD Display Touch Assembly',
        category: 'LCD/Display',
        brand: 'Samsung',
        modelNumber: 'Galaxy A12 (SM-A125F)',
        supportedModels: 'A12 / M12 / A02s',
        condition: 'New',
        frontPhoto: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&auto=format&fit=crop&q=80',
        backPhoto: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=400&auto=format&fit=crop&q=80',
        stockQuantity: 12,
        purchasePrice: 1150,
        retailPrice: 1650,
        wholesalePrice: 1350,
        alertLimit: 5,
      },
      {
        name: 'Oppo A57 / A57s IPS LCD Screen with Touch Screen',
        category: 'LCD/Display',
        brand: 'Oppo',
        modelNumber: 'A57 4G / 5G',
        supportedModels: 'Oppo A57, A77, Realme C33',
        condition: 'New',
        frontPhoto: 'https://images.unsplash.com/photo-1511707171634-5f897ff02560?w=400&auto=format&fit=crop&q=80',
        backPhoto: 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=400&auto=format&fit=crop&q=80',
        stockQuantity: 8,
        purchasePrice: 1080,
        retailPrice: 1550,
        wholesalePrice: 1280,
        alertLimit: 4,
      },
      {
        name: 'Redmi Note 10 AMOLED Display Assembly with Frame',
        category: 'LCD/Display',
        brand: 'Xiaomi / Redmi',
        modelNumber: 'Note 10 / Note 10S',
        supportedModels: 'Redmi Note 10 4G (M2101K7AI)',
        condition: 'New',
        frontPhoto: 'https://images.unsplash.com/photo-1546054454-aa26e2b734c7?w=400&auto=format&fit=crop&q=80',
        backPhoto: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=400&auto=format&fit=crop&q=80',
        stockQuantity: 2, // Limited stock trigger!
        purchasePrice: 2200,
        retailPrice: 3200,
        wholesalePrice: 2650,
        alertLimit: 3,
      },
      {
        name: 'Vivo Y20 / Y20s OG Charging Port PCB Board Ribbon',
        category: 'Charging Ribbon',
        brand: 'Vivo',
        modelNumber: 'Y20 (V2029)',
        supportedModels: 'Vivo Y20 / Y20i / Y12s',
        condition: 'New',
        frontPhoto: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=400&auto=format&fit=crop&q=80',
        backPhoto: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&auto=format&fit=crop&q=80',
        stockQuantity: 0, // Stock out trigger!
        purchasePrice: 180,
        retailPrice: 450,
        wholesalePrice: 280,
        alertLimit: 5,
      },
    ];

    sampleProducts.forEach((p) => this.addProduct(p));

    // Also populate initial sample customers and sales so the Quick Report & Dashboard have real data immediately
    this.seedSampleMonthlySales();
  },

  seedSampleMonthlySales(): void {
    const products = this.getProducts();
    if (products.length === 0) return;

    let customers = this.getCustomers();
    if (customers.length === 0) {
      const c1 = this.addCustomer({
        name: 'তানভীর টেলিকম (Tanvir Telecom)',
        phone: '01711223344',
        whatsapp: '01711223344',
        address: 'বালাগঞ্জ বাজার, সিলেট',
      });
      const c2 = this.addCustomer({
        name: 'সুমন মোবাইল সার্ভিসিং সেন্টার',
        phone: '01899887766',
        whatsapp: '01899887766',
        address: 'তাজপুর, ওসমানীনগর, সিলেট',
      });
      customers = [c1, c2];
    }

    const currentInvoices = this.getInvoices();
    if (currentInvoices.length > 0) return; // Don't overwrite if invoices already exist

    const samsung = products.find((p) => p.modelNumber.includes('A12')) || products[0];
    const oppo = products.find((p) => p.modelNumber.includes('A57')) || products[1];
    const redmi = products.find((p) => p.modelNumber.includes('Note 10')) || products[2];

    const c1 = customers[0];
    const c2 = customers[1] || customers[0];

    // Sale 1: Samsung A12 (7 pcs)
    if (samsung) {
      this.createSaleInvoice({
        customerId: c1.id,
        customerName: c1.name,
        customerPhone: c1.phone,
        customerAddress: c1.address,
        items: [
          {
            productId: samsung.id,
            productName: samsung.name,
            category: samsung.category,
            brand: samsung.brand,
            modelNumber: samsung.modelNumber,
            frontPhoto: samsung.frontPhoto,
            quantity: 7,
            purchasePrice: samsung.purchasePrice,
            unitPrice: samsung.retailPrice,
            priceType: 'Retail',
            totalPrice: samsung.retailPrice * 7,
            profit: (samsung.retailPrice - samsung.purchasePrice) * 7,
          },
        ],
        discount: 200,
        paymentMethod: 'Cash',
        paidAmount: samsung.retailPrice * 7 - 200,
      });
    }

    // Sale 2: Samsung A12 (4 pcs) + Oppo A57 (6 pcs)
    if (samsung && oppo) {
      const items: CartItem[] = [
        {
          productId: samsung.id,
          productName: samsung.name,
          category: samsung.category,
          brand: samsung.brand,
          modelNumber: samsung.modelNumber,
          frontPhoto: samsung.frontPhoto,
          quantity: 4,
          purchasePrice: samsung.purchasePrice,
          unitPrice: samsung.wholesalePrice,
          priceType: 'Wholesale',
          totalPrice: samsung.wholesalePrice * 4,
          profit: (samsung.wholesalePrice - samsung.purchasePrice) * 4,
        },
        {
          productId: oppo.id,
          productName: oppo.name,
          category: oppo.category,
          brand: oppo.brand,
          modelNumber: oppo.modelNumber,
          frontPhoto: oppo.frontPhoto,
          quantity: 6,
          purchasePrice: oppo.purchasePrice,
          unitPrice: oppo.wholesalePrice,
          priceType: 'Wholesale',
          totalPrice: oppo.wholesalePrice * 6,
          profit: (oppo.wholesalePrice - oppo.purchasePrice) * 6,
        },
      ];
      const subtotal = items.reduce((s, it) => s + it.totalPrice, 0);
      this.createSaleInvoice({
        customerId: c2.id,
        customerName: c2.name,
        customerPhone: c2.phone,
        customerAddress: c2.address,
        items,
        discount: 300,
        paymentMethod: 'bKash',
        paidAmount: subtotal - 300,
      });
    }

    // Sale 3: Oppo A57 (3 pcs) + Redmi Note 10 (4 pcs)
    if (oppo && redmi) {
      const items: CartItem[] = [
        {
          productId: oppo.id,
          productName: oppo.name,
          category: oppo.category,
          brand: oppo.brand,
          modelNumber: oppo.modelNumber,
          frontPhoto: oppo.frontPhoto,
          quantity: 3,
          purchasePrice: oppo.purchasePrice,
          unitPrice: oppo.retailPrice,
          priceType: 'Retail',
          totalPrice: oppo.retailPrice * 3,
          profit: (oppo.retailPrice - oppo.purchasePrice) * 3,
        },
        {
          productId: redmi.id,
          productName: redmi.name,
          category: redmi.category,
          brand: redmi.brand,
          modelNumber: redmi.modelNumber,
          frontPhoto: redmi.frontPhoto,
          quantity: 4,
          purchasePrice: redmi.purchasePrice,
          unitPrice: redmi.retailPrice,
          priceType: 'Retail',
          totalPrice: redmi.retailPrice * 4,
          profit: (redmi.retailPrice - redmi.purchasePrice) * 4,
        },
      ];
      const subtotal = items.reduce((s, it) => s + it.totalPrice, 0);
      this.createSaleInvoice({
        customerId: 'walk-in',
        customerName: 'নগদ ক্রেতা (Walk-in Customer)',
        customerPhone: '01700000000',
        items,
        discount: 0,
        paymentMethod: 'Cash',
        paidAmount: subtotal,
      });
    }

    // Baseline sales for the previous month to provide realistic shift/trend indicators
    const now = new Date();
    const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 15);
    const prevDateStr = prevDate.toISOString().split('T')[0];

    if (samsung && oppo) {
      const pastItems: CartItem[] = [
        {
          productId: samsung.id,
          productName: samsung.name,
          category: samsung.category,
          brand: samsung.brand,
          modelNumber: samsung.modelNumber,
          frontPhoto: samsung.frontPhoto,
          quantity: 8,
          purchasePrice: samsung.purchasePrice,
          unitPrice: samsung.retailPrice,
          priceType: 'Retail',
          totalPrice: samsung.retailPrice * 8,
          profit: (samsung.retailPrice - samsung.purchasePrice) * 8,
        },
        {
          productId: oppo.id,
          productName: oppo.name,
          category: oppo.category,
          brand: oppo.brand,
          modelNumber: oppo.modelNumber,
          frontPhoto: oppo.frontPhoto,
          quantity: 10,
          purchasePrice: oppo.purchasePrice,
          unitPrice: oppo.wholesalePrice,
          priceType: 'Wholesale',
          totalPrice: oppo.wholesalePrice * 10,
          profit: (oppo.wholesalePrice - oppo.purchasePrice) * 10,
        },
      ];
      const invPast = this.createSaleInvoice({
        customerId: c1.id,
        customerName: c1.name,
        customerPhone: c1.phone,
        customerAddress: c1.address,
        items: pastItems,
        discount: 250,
        paymentMethod: 'Cash',
        paidAmount: pastItems.reduce((s, it) => s + it.totalPrice, 0) - 250,
      });

      // Update date of this invoice and transaction to previous month
      const invoices = getLocalItem<SaleInvoice[]>(STORAGE_KEYS.INVOICES, []);
      const pIdx = invoices.findIndex((i) => i.id === invPast.id);
      if (pIdx !== -1) {
        invoices[pIdx].date = prevDateStr;
        setLocalItem(STORAGE_KEYS.INVOICES, invoices);
      }
      const txns = getLocalItem<FinancialTransaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
      const tIdx = txns.findIndex((t) => t.refId === invPast.id);
      if (tIdx !== -1) {
        txns[tIdx].date = prevDateStr;
        setLocalItem(STORAGE_KEYS.TRANSACTIONS, txns);
      }
    }
  },
};
