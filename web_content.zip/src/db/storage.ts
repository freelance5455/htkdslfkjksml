import JSZip from 'jszip';
import { Carpeta, Foto } from '../types';

const DB_NAME = 'galeria_taller_mecanico_db';
const DB_VERSION = 1;
const STORE_CARPETAS = 'carpetas';
const STORE_FOTOS = 'fotos';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_CARPETAS)) {
        const carpetaStore = db.createObjectStore(STORE_CARPETAS, { keyPath: 'id' });
        carpetaStore.createIndex('nombre', 'nombre', { unique: false });
        carpetaStore.createIndex('fechaModificacion', 'fechaModificacion', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_FOTOS)) {
        const fotoStore = db.createObjectStore(STORE_FOTOS, { keyPath: 'id' });
        fotoStore.createIndex('carpetaId', 'carpetaId', { unique: false });
        fotoStore.createIndex('fecha', 'fecha', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function formatearBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatearFecha(timestamp: number): string {
  const d = new Date(timestamp);
  const pad = (n: number) => n.toString().padStart(2, '0');
  const dia = pad(d.getDate());
  const mes = pad(d.getMonth() + 1);
  const anio = d.getFullYear();
  const hora = pad(d.getHours());
  const min = pad(d.getMinutes());
  return `${dia}/${mes}/${anio} ${hora}:${min}`;
}

export function generarNombreFoto(): string {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, '0');
  const anio = d.getFullYear();
  const mes = pad(d.getMonth() + 1);
  const dia = pad(d.getDate());
  const hora = pad(d.getHours());
  const min = pad(d.getMinutes());
  const seg = pad(d.getSeconds());
  return `IMG_${anio}${mes}${dia}_${hora}${min}${seg}.jpg`;
}

// Repositorio de Carpetas
export async function listarCarpetas(): Promise<Carpeta[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_CARPETAS, 'readonly');
    const store = tx.objectStore(STORE_CARPETAS);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function obtenerCarpeta(id: string): Promise<Carpeta | undefined> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_CARPETAS, 'readonly');
    const store = tx.objectStore(STORE_CARPETAS);
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function crearCarpeta(nombre: string, descripcion?: string): Promise<Carpeta> {
  const db = await openDB();
  const nueva: Carpeta = {
    id: 'c_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    nombre: nombre.trim(),
    fechaCreacion: Date.now(),
    fechaModificacion: Date.now(),
    descripcion: descripcion?.trim(),
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_CARPETAS, 'readwrite');
    const store = tx.objectStore(STORE_CARPETAS);
    const req = store.add(nueva);
    req.onsuccess = () => resolve(nueva);
    req.onerror = () => reject(req.error);
  });
}

export async function renombrarCarpeta(id: string, nuevoNombre: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_CARPETAS, 'readwrite');
    const store = tx.objectStore(STORE_CARPETAS);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const carpeta = getReq.result as Carpeta;
      if (!carpeta) {
        reject(new Error('Carpeta no encontrada'));
        return;
      }
      carpeta.nombre = nuevoNombre.trim();
      carpeta.fechaModificacion = Date.now();
      const putReq = store.put(carpeta);
      putReq.onsuccess = () => resolve();
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function eliminarCarpeta(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_CARPETAS, STORE_FOTOS], 'readwrite');
    const carpetaStore = tx.objectStore(STORE_CARPETAS);
    const fotoStore = tx.objectStore(STORE_FOTOS);

    // Borrar carpeta
    carpetaStore.delete(id);

    // Borrar fotos de la carpeta
    const index = fotoStore.index('carpetaId');
    const req = index.openCursor(IDBKeyRange.only(id));
    req.onsuccess = (e) => {
      const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Repositorio de Fotos
export async function listarFotos(carpetaId: string): Promise<Foto[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FOTOS, 'readonly');
    const store = tx.objectStore(STORE_FOTOS);
    const index = store.index('carpetaId');
    const req = index.getAll(IDBKeyRange.only(carpetaId));
    req.onsuccess = () => {
      const fotos: Foto[] = req.result || [];
      // Orden descendente por defecto (más recientes primero)
      fotos.sort((a, b) => b.fecha - a.fecha);
      resolve(fotos);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function contarFotosPorCarpeta(carpetaId: string): Promise<number> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FOTOS, 'readonly');
    const store = tx.objectStore(STORE_FOTOS);
    const index = store.index('carpetaId');
    const req = index.count(IDBKeyRange.only(carpetaId));
    req.onsuccess = () => resolve(req.result || 0);
    req.onerror = () => reject(req.error);
  });
}

export async function obtenerTodasLasFotos(): Promise<Foto[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FOTOS, 'readonly');
    const store = tx.objectStore(STORE_FOTOS);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function guardarFoto(
  carpetaId: string,
  fotoData: {
    nombre?: string;
    dataUrl: string;
    tamanoBytes: number;
    ancho?: number;
    alto?: number;
  }
): Promise<Foto> {
  const db = await openDB();
  const nombre = fotoData.nombre || generarNombreFoto();
  const nueva: Foto = {
    id: 'f_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    carpetaId,
    nombre,
    dataUrl: fotoData.dataUrl,
    fecha: Date.now(),
    tamanoBytes: fotoData.tamanoBytes,
    ancho: fotoData.ancho,
    alto: fotoData.alto,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_CARPETAS, STORE_FOTOS], 'readwrite');
    const fotoStore = tx.objectStore(STORE_FOTOS);
    const carpetaStore = tx.objectStore(STORE_CARPETAS);

    fotoStore.add(nueva);

    // Actualizar fecha de modificación de carpeta
    const getCarpeta = carpetaStore.get(carpetaId);
    getCarpeta.onsuccess = () => {
      const c = getCarpeta.result as Carpeta;
      if (c) {
        c.fechaModificacion = Date.now();
        carpetaStore.put(c);
      }
    };

    tx.oncomplete = () => resolve(nueva);
    tx.onerror = () => reject(tx.error);
  });
}

export async function eliminarFoto(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FOTOS, 'readwrite');
    const store = tx.objectStore(STORE_FOTOS);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function moverFoto(fotoId: string, nuevaCarpetaId: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_FOTOS, STORE_CARPETAS], 'readwrite');
    const fotoStore = tx.objectStore(STORE_FOTOS);
    const carpetaStore = tx.objectStore(STORE_CARPETAS);

    const getFoto = fotoStore.get(fotoId);
    getFoto.onsuccess = () => {
      const foto = getFoto.result as Foto;
      if (!foto) {
        reject(new Error('Foto no encontrada'));
        return;
      }
      foto.carpetaId = nuevaCarpetaId;
      fotoStore.put(foto);

      // Actualizar carpeta destino
      const getCarpeta = carpetaStore.get(nuevaCarpetaId);
      getCarpeta.onsuccess = () => {
        const c = getCarpeta.result as Carpeta;
        if (c) {
          c.fechaModificacion = Date.now();
          carpetaStore.put(c);
        }
      };
    };

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Estadísticas de almacenamiento
export async function obtenerEstadisticas(): Promise<{
  totalCarpetas: number;
  totalFotos: number;
  totalBytes: number;
  espacioLibreTexto: string;
}> {
  const carpetas = await listarCarpetas();
  const fotos = await obtenerTodasLasFotos();

  const totalBytes = fotos.reduce((acc, f) => acc + (f.tamanoBytes || 0), 0);

  let espacioLibreTexto = 'Disponible en el navegador';
  if (navigator.storage && navigator.storage.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      if (estimate.quota && estimate.usage) {
        const libre = estimate.quota - estimate.usage;
        espacioLibreTexto = `${formatearBytes(libre)} de ${formatearBytes(estimate.quota)}`;
      }
    } catch {
      // Ignorar
    }
  }

  return {
    totalCarpetas: carpetas.length,
    totalFotos: fotos.length,
    totalBytes,
    espacioLibreTexto,
  };
}

// Exportar copia de seguridad en formato ZIP
export async function exportarTodasLasFotosZip(): Promise<Blob> {
  const zip = new JSZip();
  const carpetas = await listarCarpetas();
  const fotos = await obtenerTodasLasFotos();

  const carpetasMap = new Map<string, string>();
  carpetas.forEach((c) => carpetasMap.set(c.id, c.nombre));

  for (const foto of fotos) {
    const carpetaNombre = carpetasMap.get(foto.carpetaId) || 'Sin_Carpeta';
    // Extraer base64
    const base64Data = foto.dataUrl.replace(/^data:image\/\w+;base64,/, '');
    zip.folder(carpetaNombre)?.file(foto.nombre, base64Data, { base64: true });
  }

  return await zip.generateAsync({ type: 'blob' });
}

// Cargar datos de demostración para taller
export async function sembrarDatosDemo(): Promise<void> {
  const existentes = await listarCarpetas();
  if (existentes.length > 0) return;

  const c1 = await crearCarpeta('Placa ABC-123 (Toyota Hilux)');
  const c2 = await crearCarpeta('Placa XYZ-789 (Ford Ranger)');
  const c3 = await crearCarpeta('Placa JKL-456 (Chevrolet Onix)');

  // Intentar cargar la imagen del carro como foto de demo en c1
  try {
    const resp = await fetch('/carro.png');
    if (resp.ok) {
      const blob = await resp.blob();
      const reader = new FileReader();
      reader.onloadend = async () => {
        const dataUrl = reader.result as string;
        await guardarFoto(c1.id, {
          nombre: 'IMG_20261103_093012_Frente.jpg',
          dataUrl,
          tamanoBytes: blob.size,
          ancho: 1200,
          alto: 800,
        });
      };
      reader.readAsDataURL(blob);
    }
  } catch {
    // Si no se puede cargar, omitir
  }
}
