import sqlite3 from 'sqlite3';
import { promisify } from 'util';
import path from 'path';

const dbPath = path.resolve(process.cwd(), 'database.sqlite');
const db = new sqlite3.Database(dbPath);

export const run = (sql: string, params: any[] = []): Promise<sqlite3.RunResult> => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
};

export const get = <T>(sql: string, params: any[] = []): Promise<T | undefined> => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row as T);
    });
  });
};

export const all = <T>(sql: string, params: any[] = []): Promise<T[]> => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows as T[]);
    });
  });
};

export const initDb = async () => {
  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT,
      email TEXT,
      dob TEXT,
      plan TEXT DEFAULT 'FREE',
      status TEXT DEFAULT 'ACTIVE',
      message_count INTEGER DEFAULT 0,
      stripe_customer_id TEXT,
      stripe_subscription_id TEXT,
      payment_id TEXT,
      start_date DATETIME,
      current_period_start INTEGER,
      current_period_end INTEGER,
      cancelled_at INTEGER,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
};

export const getUser = async (id: string) => {
  let user = await get<any>('SELECT * FROM users WHERE id = ?', [id]);
  if (!user) {
    await run('INSERT INTO users (id, plan, status) VALUES (?, ?, ?)', [id, 'FREE', 'ACTIVE']);
    user = await get<any>('SELECT * FROM users WHERE id = ?', [id]);
  }
  return user;
};

export const incrementMessageCount = async (id: string) => {
  await run('UPDATE users SET message_count = message_count + 1 WHERE id = ?', [id]);
};

export const getUserByStripeCustomerId = async (customerId: string) => {
  return await get<any>('SELECT * FROM users WHERE stripe_customer_id = ?', [customerId]);
};

export const updateUserSubscription = async (userId: string, plan: string, status: string, subId: string, currentPeriodEnd: number, customerId?: string) => {
  if (customerId) {
    await run(`UPDATE users SET plan = ?, status = ?, stripe_subscription_id = ?, current_period_end = ?, stripe_customer_id = ? WHERE id = ?`, 
    [plan, status, subId, currentPeriodEnd, customerId, userId]);
  } else {
    await run(`UPDATE users SET plan = ?, status = ?, stripe_subscription_id = ?, current_period_end = ? WHERE id = ?`, 
    [plan, status, subId, currentPeriodEnd, userId]);
  }
};

export const cancelSubscription = async (userId: string) => {
  await run(`UPDATE users SET plan = 'FREE', status = 'CANCELLED' WHERE id = ?`, [userId]);
};
