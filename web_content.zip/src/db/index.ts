import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Lazy database initialisation.
 *
 * IMPORTANT: nothing in this module may throw at import time.
 *
 * Next.js imports every route module during the build ("Collecting page data")
 * in order to read its route segment config, even for routes marked
 * `dynamic = "force-dynamic"`. A top-level `throw new Error("DATABASE_URL is
 * required")` therefore crashed the production build on Netlify, where
 * DATABASE_URL is (correctly) not present at build time.
 *
 * The pool and the Drizzle client are created on first real use instead, so
 * the environment variable is validated at request time on the server only.
 */

export class DatabaseNotConfiguredError extends Error {
  constructor() {
    super(
      "DATABASE_URL is not set. Configure it in your hosting provider's environment variables.",
    );
    this.name = "DatabaseNotConfiguredError";
  }
}

const globalForDb = globalThis as typeof globalThis & {
  __matchCricketPool?: Pool;
  __matchCricketDb?: NodePgDatabase;
};

/** True when a connection string is available. Never throws. */
export function isDatabaseConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL);
}

/** Returns the pooled connection, creating it on first use. Server-side only. */
export function getPool(): Pool {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) throw new DatabaseNotConfiguredError();

  if (!globalForDb.__matchCricketPool) {
    globalForDb.__matchCricketPool = new Pool({
      connectionString: databaseUrl,
      // Managed Postgres providers (Neon, Supabase, RDS…) require TLS.
      // Local development connections do not.
      ssl: /\bsslmode=(require|verify-full|verify-ca)\b/.test(databaseUrl)
        ? { rejectUnauthorized: false }
        : undefined,
    });
  }
  return globalForDb.__matchCricketPool;
}

/** Returns the Drizzle client, creating it on first use. Server-side only. */
export function getDb(): NodePgDatabase {
  if (!globalForDb.__matchCricketDb) {
    globalForDb.__matchCricketDb = drizzle(getPool());
  }
  return globalForDb.__matchCricketDb;
}

/**
 * Drop-in replacement for the previous eager `db` export.
 *
 * Every property access is forwarded to the real client, which is only built
 * the first time a query actually runs. This keeps all existing call sites
 * (`import { db } from "@/db"`) working unchanged.
 */
export const db: NodePgDatabase = new Proxy({} as NodePgDatabase, {
  get(_target, prop, receiver) {
    const client = getDb() as unknown as Record<string | symbol, unknown>;
    const value = Reflect.get(client, prop, receiver);
    return typeof value === "function" ? value.bind(client) : value;
  },
  has(_target, prop) {
    return Reflect.has(getDb() as object, prop);
  },
});

/** Lazily-resolved pool, kept for backwards compatibility. */
export const pool: Pool = new Proxy({} as Pool, {
  get(_target, prop, receiver) {
    const real = getPool() as unknown as Record<string | symbol, unknown>;
    const value = Reflect.get(real, prop, receiver);
    return typeof value === "function" ? value.bind(real) : value;
  },
});
