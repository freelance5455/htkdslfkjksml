import Dexie from 'dexie'
import { round2 } from '../lib/format.js'
import { hashPin } from '../lib/pin.js'

export const db = new Dexie('kirana-pos')

const STORES = {
  products: '++id, &barcode, name, category',
  customers: '++id, &name, phone',
  bills: '++id, billNo, customerId, createdAt, payMode',
  ledger: '++id, customerId, type, createdAt',
  stockLog: '++id, productId, type, createdAt',
  settings: 'key',
}

db.version(1).stores(STORES)

db.version(2)
  .stores(STORES)
  .upgrade(async (tx) => {
    const customers = await tx.table('customers').toArray()
    const groups = new Map()
    for (const c of customers) {
      const key = nameKey(c.name)
      if (!key) continue
      const group = groups.get(key)
      if (group) group.push(c)
      else groups.set(key, [c])
    }

    const merges = new Map()
    for (const group of groups.values()) {
      if (group.length < 2) continue
      const keeper = group.reduce((a, b) => (a.id <= b.id ? a : b))
      for (const c of group) {
        if (c.id === keeper.id) continue
        merges.set(c.id, keeper.id)
        if (!keeper.phone && c.phone) {
          keeper.phone = c.phone
          await tx.table('customers').update(keeper.id, { phone: c.phone })
        }
      }
    }

    for (const [from, to] of merges) {
      await tx.table('ledger').where('customerId').equals(from).modify({ customerId: to })
      await tx.table('bills').where('customerId').equals(from).modify({ customerId: to })
      await tx.table('customers').delete(from)
    }
  })

db.version(3).stores(STORES).upgrade(async () => {})

export async function ensureSettings() {
  const shopName = await db.settings.get('shopName')
  if (!shopName) {
    await db.settings.bulkPut([
      { key: 'shopName', value: 'Mera Kirana' },
      { key: 'shopPhone', value: '' },
      { key: 'shopAddress', value: '' },
      { key: 'lastBillNo', value: 0 },
    ])
  }
}

export async function getSettings() {
  const rows = await db.settings.toArray()
  const out = {}
  for (const r of rows) out[r.key] = r.value
  return out
}

export async function setShopInfo({ shopName, shopPhone, shopAddress }) {
  await db.settings.bulkPut([
    { key: 'shopName', value: shopName },
    { key: 'shopPhone', value: shopPhone },
    { key: 'shopAddress', value: shopAddress },
  ])
}

export async function setAdminPin(pin) {
  const clean = String(pin || '').trim()
  if (!clean) throw new Error('PIN to do, khaali nahi rakh sakte')
  if (!/^\d{4,6}$/.test(clean)) throw new Error('PIN 4-6 digit ka hona chahiye')
  await db.settings.put({ key: 'adminPinHash', value: hashPin(clean) })
}

export async function clearAdminPin() {
  const row = await db.settings.get('adminPinHash')
  if (row) await db.settings.delete('adminPinHash')
}

export async function verifyAdminPin(pin) {
  const row = await db.settings.get('adminPinHash')
  if (!row) return true
  return String(row.value) === hashPin(String(pin || ''))
}

export async function hasAdminPin() {
  return Boolean((await db.settings.get('adminPinHash'))?.value)
}

function makeBillNo(last) {
  return String(last + 1).padStart(4, '0')
}

export async function findProductByBarcode(barcode) {
  return db.products.where('barcode').equals(barcode).first()
}

export async function searchProducts(query) {
  const q = String(query || '').toLowerCase().trim()
  const all = await db.products.toArray()
  if (!q) return all
  return all.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.barcode.includes(q),
  )
}

export async function deleteProduct(id) {
  await db.products.delete(id)
}

export async function adjustStock(id, delta) {
  await db.transaction('rw', db.products, db.stockLog, async () => {
    const p = await db.products.get(id)
    if (!p) throw new Error('Product nahi mila')
    const stock = Math.max(0, round2((p.stock || 0) + delta))
    await db.products.update(id, { stock })
    await logStock(p, 'adjust', Number(delta) || 0, createdAtNow())
  })
}

export async function stockHistory(limit = 100) {
  return db.stockLog.orderBy('createdAt').reverse().limit(limit).toArray()
}

function createdAtNow() {
  return new Date().toISOString()
}

async function logStock(product, type, qty, createdAt) {
  await db.stockLog.add({
    productId: product.id,
    productName: product.name,
    type,
    qty: Number(qty) || 0,
    createdAt,
  })
}

export function cleanName(name) {
  return String(name ?? '')
    .trim()
    .replace(/\s+/g, ' ')
}

export function nameKey(name) {
  return cleanName(name).toLowerCase()
}

export async function addCustomer(name, phone = '') {
  const clean = cleanName(name)
  const cleanPhone = cleanName(phone)
  if (!clean) throw new Error('Customer naam chahiye')

  const existing = await db.customers
    .filter((c) => nameKey(c.name) === nameKey(clean))
    .first()
  if (existing) {
    if (!existing.phone && cleanPhone)
      await db.customers.update(existing.id, { phone: cleanPhone })
    return existing
  }

  try {
    const id = await db.customers.add({ name: clean, phone: cleanPhone })
    return { id, name: clean, phone: cleanPhone }
  } catch (e) {
    if (e && e.name === 'ConstraintError') {
      const again = await db.customers.where('name').equals(clean).first()
      if (again) return again
    }
    throw e
  }
}

export async function customerBalance(customerId) {
  const entries = await db.ledger.where('customerId').equals(customerId).toArray()
  let due = 0
  let paid = 0
  for (const e of entries) {
    if (e.type === 'due') due += e.amount
    else paid += e.amount
  }
  return { due, paid, balance: due - paid }
}

export async function updateCustomerPhone(id, phone) {
  const clean = cleanName(phone)
  await db.customers.update(id, { phone: clean })
  return clean
}

export async function addPayment(customerId, amount, note = '') {
  await db.ledger.add({
    customerId,
    type: 'payment',
    amount: Number(amount),
    note,
    createdAt: new Date().toISOString(),
  })
}

export async function customerLedger(customerId) {
  const rows = await db.ledger.where('customerId').equals(customerId).toArray()
  return rows.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
}

export function changeFor(total, cashGiven) {
  const given = Number(cashGiven)
  if (!cashGiven || !Number.isFinite(given)) return 0
  return Math.round((given - total) * 100) / 100
}

export async function saveBill({
  items,
  total,
  payMode,
  customerName,
  customerPhone = '',
  cashGiven = 0,
}) {
  const settings = await getSettings()
  const billNo = makeBillNo(settings.lastBillNo || 0)
  const createdAt = new Date().toISOString()
  const bill = {
    billNo,
    items,
    total,
    payMode,
    customerId: null,
    customerName: null,
    customerPhone: null,
    cashGiven: payMode === 'CASH' ? Number(cashGiven) || 0 : 0,
    changeReturned: payMode === 'CASH' ? changeFor(total, cashGiven) : 0,
    createdAt,
  }

  let created = null

  await db.transaction(
    'rw',
    db.bills,
    db.products,
    db.customers,
    db.ledger,
    db.settings,
    db.stockLog,
    async () => {
      if (payMode === 'UDHAR') {
        if (!cleanName(customerName)) {
          throw new Error('Udhar ke liye customer name chahiye')
        }
        const customer = await addCustomer(customerName, customerPhone)
        bill.customerId = customer.id
        bill.customerName = customer.name
        bill.customerPhone = customer.phone || null
        await db.ledger.add({
          customerId: customer.id,
          type: 'due',
          amount: total,
          billNo,
          createdAt,
        })
      }

      for (const it of items) {
        const qty = Number(it.qty) || 0
        if (qty <= 0) continue
        const p = await db.products.get(it.productId)
        if (p) {
          await db.products.update(p.id, {
            stock: Math.max(0, round2((p.stock || 0) - qty)),
          })
          await logStock(p, 'sale', -qty, createdAt)
        }
      }

      const id = await db.bills.add(bill)

      await db.settings.put({ key: 'lastBillNo', value: settings.lastBillNo + 1 })

      created = { ...bill, id }
    },
  )

  return created
}

export async function recentBills(limit = 50) {
  return db.bills.orderBy('createdAt').reverse().limit(limit).toArray()
}

export async function salesBetween(fromISO, toISO) {
  const all = await db.bills.orderBy('createdAt').toArray()
  return all.filter(
    (b) => !b.voidedAt && b.createdAt >= fromISO && b.createdAt <= toISO,
  )
}

export async function voidBill(billId, reason = '') {
  await db.transaction(
    'rw',
    db.bills,
    db.products,
    db.ledger,
    db.stockLog,
    async () => {
      const bill = await db.bills.get(billId)
      if (!bill) throw new Error('Bill nahi mila')
      if (bill.voidedAt) throw new Error('Ye bill pehle hi void ho chuka hai')

      for (const it of bill.items || []) {
        const qty = Number(it.qty) || 0
        if (qty <= 0) continue
        const p = await db.products.get(it.productId)
        if (p) {
          await db.products.update(p.id, { stock: round2((p.stock || 0) + qty) })
          await logStock(
            { id: p.id, name: it.name || p.name },
            'void',
            qty,
            createdAtNow(),
          )
        }
      }

      if (bill.payMode === 'UDHAR' && bill.customerId) {
        await db.ledger.add({
          customerId: bill.customerId,
          type: 'void',
          amount: bill.total,
          billNo: bill.billNo,
          note: reason,
          createdAt: createdAtNow(),
        })
      }

      await db.bills.update(billId, {
        voidedAt: createdAtNow(),
        voidReason: reason,
      })
    },
  )
}

export async function backupData() {
  const [products, customers, bills, ledger, stockLog, settings] = await Promise.all([
    db.products.toArray(),
    db.customers.toArray(),
    db.bills.toArray(),
    db.ledger.toArray(),
    db.stockLog.toArray(),
    db.settings.toArray(),
  ])
  return JSON.stringify({ products, customers, bills, ledger, stockLog, settings }, null, 2)
}

export async function restoreData(json) {
  let data
  try {
    data = JSON.parse(json)
  } catch {
    throw new Error(
      'Backup file galat hai — ye kirana-pos ka backup nahi lagta (sahi JSON nahi hai).',
    )
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Backup file galat hai — isme koi data nahi mila.')
  }
  const hasAny = ['products', 'customers', 'bills', 'ledger', 'settings'].some(
    (k) => Array.isArray(data[k]),
  )
  if (!hasAny) {
    throw new Error(
      'Backup file galat hai — isme na products, na bills, na customers. Sahi file lo.',
    )
  }

  const now = Date.now()
  await db.transaction(
    'rw',
    db.products,
    db.customers,
    db.bills,
    db.ledger,
    db.stockLog,
    db.settings,
    async () => {
      await Promise.all([
        db.products.clear(),
        db.customers.clear(),
        db.bills.clear(),
        db.ledger.clear(),
        db.stockLog.clear(),
        db.settings.clear(),
      ])
      if (Array.isArray(data.products)) await db.products.bulkAdd(data.products)
      if (Array.isArray(data.customers)) await db.customers.bulkAdd(data.customers)
      if (Array.isArray(data.bills)) await db.bills.bulkAdd(data.bills)
      if (Array.isArray(data.ledger)) await db.ledger.bulkAdd(data.ledger)
      if (Array.isArray(data.stockLog)) await db.stockLog.bulkAdd(data.stockLog)
      if (data.settings && Array.isArray(data.settings))
        await db.settings.bulkPut(data.settings)
    },
  )
  return now
}