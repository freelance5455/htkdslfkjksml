import { config } from "dotenv";
config();

import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { minds, questions, decisions } from "./schema";

const databaseUrl =
  process.env.DATABASE_URL ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
const db = drizzle(new Pool({ connectionString: databaseUrl }));
import { allQuestions, allDecisions } from "../lib/questions";
import { BENCHMARKS } from "../lib/ranks";
import { mindIndex } from "../lib/scoring";
import { sql } from "drizzle-orm";

async function main() {
  console.log("Reseeding the Crucible…");

  await db.execute(sql`TRUNCATE questions, decisions, minds RESTART IDENTITY CASCADE`);

  const qs = allQuestions();
  const ds = allDecisions();

  const CHUNK = 200;
  for (let i = 0; i < qs.length; i += CHUNK) {
    await db.insert(questions).values(
      qs.slice(i, i + CHUNK).map((q) => ({
        id: q.id,
        domain: q.domain,
        kind: q.kind,
        difficulty: q.difficulty,
        prompt: q.prompt,
        options: q.options,
        answerIndex: q.answerIndex,
        explanation: q.explanation,
        pillar: q.pillar,
        timeLimit: q.timeLimit,
        isBoss: q.isBoss,
      })),
    );
  }

  await db.insert(decisions).values(
    ds.map((d) => ({
      id: d.id,
      title: d.title,
      narrative: d.narrative,
      choices: d.choices,
      difficulty: d.difficulty,
      pillar: d.pillar,
      tags: d.tags,
    })),
  );

  await db.insert(minds).values(
    BENCHMARKS.map((b) => ({
      alias: b.alias,
      creativity: b.c,
      imagination: b.i,
      pattern: b.p,
      bestRing: b.ring,
      bestStreak: 20,
      mindIndex: mindIndex(b.c, b.i, b.p, b.ring, 20),
      isBenchmark: true,
    })),
  );

  const counts = await db.execute(sql`SELECT (SELECT count(*) FROM questions) q, (SELECT count(*) FROM decisions) d, (SELECT count(*) FROM minds) m`);
  console.log("Seeded:", counts.rows[0]);
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
