import { count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  appointments,
  articles,
  categories,
  notifications,
  services,
  siteSettings,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/crypto";
import { DEFAULT_SITE_SETTINGS } from "@/lib/site-defaults";
import type { L10n } from "@/lib/types";

const DEMO_PASSWORD = "Demo@2026";
const ADMIN_PASSWORD = "Admin@2026";
const REVIEW_NOTE = "Medical validation pending (to be checked by a licensed physician)";

/* ----------------------------- Categories (12) ----------------------------- */

const CATEGORIES: Array<{ slug: string; name: L10n }> = [
  { slug: "general-health", name: { fr: "Santé générale", en: "General Health", ar: "الصحة العامة" } },
  { slug: "nutrition", name: { fr: "Nutrition et alimentation saine", en: "Nutrition and Healthy Eating", ar: "التغذية والأكل الصحي" } },
  { slug: "diabetes", name: { fr: "Sensibilisation au diabète", en: "Diabetes Awareness", ar: "التوعية بالسكري" } },
  { slug: "blood-pressure", name: { fr: "Tension artérielle", en: "Blood Pressure", ar: "ضغط الدم" } },
  { slug: "heart-health", name: { fr: "Santé du cœur", en: "Heart Health", ar: "صحة القلب" } },
  { slug: "maternal-child", name: { fr: "Santé de la mère et de l'enfant", en: "Maternal and Child Health", ar: "صحة الأم والطفل" } },
  { slug: "elderly-care", name: { fr: "Soins des personnes âgées", en: "Elderly Care", ar: "رعاية كبار السن" } },
  { slug: "first-aid", name: { fr: "Premiers secours", en: "First Aid", ar: "الإسعافات الأولية" } },
  { slug: "wound-care", name: { fr: "Soins des plaies", en: "Wound Care", ar: "العناية بالجروح" } },
  { slug: "common-diseases", name: { fr: "Maladies courantes", en: "Common Diseases", ar: "الأمراض الشائعة" } },
  { slug: "healthy-lifestyle", name: { fr: "Mode de vie sain", en: "Healthy Lifestyle", ar: "نمط حياة صحي" } },
  { slug: "prevention-hygiene", name: { fr: "Prévention et hygiène", en: "Prevention and Hygiene", ar: "الوقاية والنظافة" } },
];

/* ----------------------------- Services (9, exact prices) ----------------------------- */

const SERVICES: Array<{
  slug: string;
  category: string;
  icon: string;
  priceMad: number;
  durationMinutes: number;
  sortOrder: number;
  name: L10n;
  description: L10n;
}> = [
  {
    slug: "blood-pressure-measurement",
    category: "monitoring",
    icon: "heart-pulse",
    priceMad: 80,
    durationMinutes: 20,
    sortOrder: 1,
    name: { fr: "Mesure de la tension artérielle", en: "Blood Pressure Measurement", ar: "قياس ضغط الدم" },
    description: {
      fr: "Mesure de la tension artérielle à domicile, avec enregistrement des valeurs pour votre suivi.",
      en: "Blood pressure measurement at home, with values recorded for your follow-up.",
      ar: "قياس ضغط الدم في المنزل مع تسجيل القيم للمتابعة.",
    },
  },
  {
    slug: "blood-glucose-measurement",
    category: "monitoring",
    icon: "activity",
    priceMad: 80,
    durationMinutes: 20,
    sortOrder: 2,
    name: { fr: "Mesure de la glycémie", en: "Blood Glucose Measurement", ar: "قياس نسبة السكر في الدم" },
    description: {
      fr: "Contrôle de la glycémie capillaire à domicile, avec enregistrement des résultats pour votre médecin.",
      en: "Capillary blood glucose check at home, with results recorded for your doctor.",
      ar: "فحص سكر الدم بالوخز في المنزل مع تسجيل النتائج لطبيبك.",
    },
  },
  {
    slug: "injections",
    category: "injections",
    icon: "syringe",
    priceMad: 100,
    durationMinutes: 20,
    sortOrder: 3,
    name: { fr: "Injections", en: "Injections", ar: "الحقن" },
    description: {
      fr: "Administration d'injections prescrites par votre médecin, dans le respect strict des règles d'hygiène.",
      en: "Administration of injections prescribed by your doctor, following strict hygiene rules.",
      ar: "إعطاء الحقن الموصوفة من طبيبك مع احترام قواعد النظافة الصارمة.",
    },
  },
  {
    slug: "wound-dressing",
    category: "wound",
    icon: "bandage",
    priceMad: 120,
    durationMinutes: 45,
    sortOrder: 4,
    name: { fr: "Pansements et soins des plaies", en: "Wound Dressing and Wound Care", ar: "تضميد الجروح والعناية بها" },
    description: {
      fr: "Nettoyage, pansement stérile et surveillance des plaies, selon la prescription médicale.",
      en: "Cleaning, sterile dressing and monitoring of wounds, according to medical prescription.",
      ar: "تنظيف الجروح وتضميدها بضمادات معقمة ومتابعتها وفق الوصفة الطبية.",
    },
  },
  {
    slug: "basic-nursing-care",
    category: "nursing",
    icon: "stethoscope",
    priceMad: 120,
    durationMinutes: 45,
    sortOrder: 5,
    name: { fr: "Soins infirmiers de base à domicile", en: "Basic Nursing Care at Home", ar: "الرعاية التمريضية الأساسية في المنزل" },
    description: {
      fr: "Soins infirmiers courants à domicile : contrôle des signes vitaux, conseils et surveillance de l'état général.",
      en: "Routine nursing care at home: vital signs checks, advice and general condition monitoring.",
      ar: "رعاية تمريضية روتينية في المنزل: قياس العلامات الحيوية والنصح ومتابعة الحالة العامة.",
    },
  },
  {
    slug: "patient-hygiene",
    category: "hygiene",
    icon: "droplets",
    priceMad: 150,
    durationMinutes: 60,
    sortOrder: 6,
    name: { fr: "Hygiène et soins personnels du patient", en: "Patient Hygiene and Personal Care", ar: "نظافة المريض والعناية الشخصية" },
    description: {
      fr: "Toilette, aide à l'habillage et soins de la peau pour les personnes alitées ou en perte d'autonomie.",
      en: "Washing, dressing assistance and skin care for bedridden people or those with reduced autonomy.",
      ar: "الاستحمام والمساعدة في ارتداء الملابس والعناية بالجلد للأشخاص الملازمين للفراش أو المحدودي الاستقلالية.",
    },
  },
  {
    slug: "post-operative-care",
    category: "postop",
    icon: "bed",
    priceMad: 180,
    durationMinutes: 60,
    sortOrder: 7,
    name: { fr: "Soins post-opératoires", en: "Post-Operative Nursing Care", ar: "الرعاية التمريضية بعد العمليات" },
    description: {
      fr: "Suivi après une opération : pansements, surveillance et aide à la mobilisation, selon les consignes de votre chirurgien.",
      en: "Follow-up after surgery: dressings, monitoring and mobilisation support, following your surgeon's instructions.",
      ar: "متابعة ما بعد الجراحة: الضمادات والمراقبة والمساعدة على الحركة وفق تعليمات الجراح.",
    },
  },
  {
    slug: "elderly-care-assistance",
    category: "elderly",
    icon: "heart-handshake",
    priceMad: 200,
    durationMinutes: 60,
    sortOrder: 8,
    name: { fr: "Accompagnement des personnes âgées", en: "Elderly Care Assistance", ar: "المساعدة في رعاية كبار السن" },
    description: {
      fr: "Aide aux gestes du quotidien, rappel des prises de médicaments et présence bienveillante à domicile.",
      en: "Help with daily activities, medication reminders and caring company at home.",
      ar: "المساعدة في الأنشطة اليومية وتذكير الأدوية والمرافقة اللطيفة في المنزل.",
    },
  },
  {
    slug: "general-home-visit",
    category: "nursing",
    icon: "clipboard-plus",
    priceMad: 200,
    durationMinutes: 60,
    sortOrder: 9,
    name: { fr: "Visite infirmière générale à domicile", en: "General Home Nursing Visit", ar: "زيارة تمريضية عامة إلى المنزل" },
    description: {
      fr: "Visite infirmière générale pour évaluer les besoins de soins et organiser le suivi.",
      en: "General nursing home visit to assess care needs and organise follow-up.",
      ar: "زيارة تمريضية عامة للمنزل لتقييم الاحتياجات التمريضية وتنظيم المتابعة.",
    },
  },
];

/* ----------------------------- Articles (one per category) ----------------------------- */

interface ArticleSeed {
  slug: string;
  category: string;
  emoji: string;
  readMinutes: number;
  isFeatured: boolean;
  title: L10n;
  summary: L10n;
  body: L10n;
  sources: string[];
}

const ARTICLES: ArticleSeed[] = [
  {
    slug: "why-regular-checkups",
    category: "general-health",
    emoji: "🩺",
    readMinutes: 3,
    isFeatured: true,
    title: { fr: "Pourquoi faire des bilans de santé réguliers", en: "Why regular health check-ups matter", ar: "لماذا تهم الفحوصات الصحية الدورية" },
    summary: {
      fr: "Connaître ses chiffres clés permet de repérer tôt les problèmes et d'en parler à son médecin.",
      en: "Knowing your key numbers helps spot problems early and talk to your doctor.",
      ar: "معرفة أرقامك الصحية الأساسية تساعد على اكتشاف المشكلات مبكراً والتحدث مع طبيبك.",
    },
    body: {
      fr: "Un bilan de santé régulier permet de suivre des indicateurs simples comme la tension artérielle, le poids, la glycémie ou le cholestérol. Ces mesures donnent une image de votre santé à un moment donné et aident votre médecin à décider si des examens complémentaires sont utiles.\n\nNotez vos chiffres avec leur date et apportez ce carnet lors des consultations. Ce guide ne remplace pas une consultation : posez vos questions sur vos résultats à votre médecin.",
      en: "A regular health check-up tracks simple indicators such as blood pressure, weight, blood glucose or cholesterol. These measurements give a picture of your health at a given time and help your doctor decide whether further tests are useful.\n\nWrite down your numbers with the date and bring the record to appointments. This guide does not replace a consultation: ask your doctor about any questions regarding your results.",
      ar: "يتابع الفحص الصحي الدوري مؤشرات بسيطة مثل ضغط الدم والوزن وسكر الدم أو الكوليسترول. تعطي هذه القياسات صورة عن صحتك في وقت محدد، وتساعد الطبيب على تقرير إن كانت فحوص إضافية مفيدة.\n\nدوّن قيمك مع تاريخها واحمل السجل معك إلى المواعيد. هذا الدليل لا يغني عن الاستشارة: اطرح أسئلتك حول نتائجك على طبيبك.",
    },
    sources: ["World Health Organization – Health topics (who.int)"],
  },
  {
    slug: "healthy-eating-daily",
    category: "nutrition",
    emoji: "🥗",
    readMinutes: 3,
    isFeatured: true,
    title: { fr: "Manger équilibré au quotidien", en: "Eating well every day", ar: "الأكل الصحي كل يوم" },
    summary: {
      fr: "Légumes, fruits, céréales complètes, et peu de sel et de sucre : des repères simples.",
      en: "Vegetables, fruit, whole grains, and less salt and sugar: simple guidelines.",
      ar: "خضروات وفواكه وحبوب كاملة وقليل من الملح والسكر: إرشادات بسيطة.",
    },
    body: {
      fr: "L'OMS recommande de consommer au moins 400 g de fruits et légumes par jour, de limiter le sel à moins de 5 g par jour et de réduire les sucres ajoutés. La cuisine marocaine offre de bonnes bases : légumineuses, légumes de saison, poissons et huile d'olive.\n\nPour réduire le sel, utilisez citron, herbes fraîches et épices plutôt que le sel de table, et limitez les produits transformés. En cas de maladie chronique, votre médecin ou un diététicien adaptera vos besoins.",
      en: "WHO recommends eating at least 400 g of fruit and vegetables per day, keeping salt below 5 g per day, and reducing added sugars. Moroccan cooking has good foundations: pulses, seasonal vegetables, fish and olive oil.\n\nTo cut salt, use lemon, fresh herbs and spices instead of table salt, and limit processed foods. For a chronic condition, your doctor or a dietitian should adapt your needs.",
      ar: "توصي منظمة الصحة العالمية بتناول 400 غرام على الأقل من الفواكه والخضروات يومياً، وإبقاء الملح أقل من 5 غرامات يومياً، والحد من السكريات المضافة. يتميز المطبخ المغربي بأسس جيدة: البقوليات والخضروات الموسمية والسمك وزيت الزيتون.\n\nلتقليل الملح استعمل الليمون والأعشاب الطازجة والتوابل بدل ملح الطعام، وقلّل الأطعمة المصنعة. وفي حال وجود مرض مزمن يكيّف الطبيب أو أخصائي التغذية احتياجاتك.",
    },
    sources: ["WHO – Healthy diet fact sheet (who.int)"],
  },
  {
    slug: "diabetes-warning-signs",
    category: "diabetes",
    emoji: "🩸",
    readMinutes: 4,
    isFeatured: true,
    title: { fr: "Diabète : reconnaître les signes d'alerte", en: "Diabetes: recognising warning signs", ar: "السكري: التعرف على علامات الإنذار" },
    summary: {
      fr: "Soif intense, fatigue, envie fréquente d'uriner : quand demander un avis médical.",
      en: "Intense thirst, tiredness, frequent urination: when to ask for medical advice.",
      ar: "عطش شديد وإرهاق وكثرة التبول: متى تطلب رأياً طبياً.",
    },
    body: {
      fr: "Le diabète se caractérise par une glycémie (taux de sucre dans le sang) durablement élevée. Il peut évoluer sans symptômes pendant longtemps. Une soif inhabituelle, des mictions fréquentes, une fatigue, une perte de poids inexpliquée, une vision floue ou une cicatrisation lente doivent amener à consulter.\n\nLe diagnostic repose sur des analyses de sang prescrites par un médecin. Une fois le diabète diagnostiqué, le suivi régulier (glycémie, HbA1c, pieds, yeux, reins) aide à prévenir les complications. Un infirmier peut, sur prescription, aider à la surveillance de la glycémie à domicile.",
      en: "Diabetes means blood glucose stays high over a long period. It can progress for years without symptoms. Unusual thirst, frequent urination, tiredness, unexplained weight loss, blurred vision or slow-healing wounds should prompt a medical visit.\n\nDiagnosis relies on blood tests ordered by a doctor. Once diagnosed, regular follow-up (glucose, HbA1c, feet, eyes, kidneys) helps prevent complications. A nurse can support home glucose monitoring when prescribed.",
      ar: "يعني السكري ارتفاع نسبة الغلوكوز في الدم لفترة طويلة، وقد يتطور لسنوات دون أعراض. العطش غير المعتاد وكثرة التبول والإرهاق وفقدان الوزن غير المفسَّر وضبابية الرؤية وبطء التئام الجروح تستدعي استشارة طبية.\n\nيعتمد التشخيص على تحاليل دم يطلبها الطبيب. وبعد التشخيص تساعد المتابعة المنتظمة (السكر، HbA1c، القدمان، العينان، الكلى) على الوقاية من المضاعفات. ويمكن للممرض، عند الوصفة، المساعدة في مراقبة السكر في المنزل.",
    },
    sources: [
      "International Diabetes Federation – IDF Diabetes Atlas (diabetesatlas.org)",
      "American Diabetes Association – Standards of Care in Diabetes (current edition)",
    ],
  },
  {
    slug: "measure-blood-pressure",
    category: "blood-pressure",
    emoji: "💓",
    readMinutes: 4,
    isFeatured: true,
    title: { fr: "Mesurer correctement sa tension artérielle", en: "How to measure your blood pressure correctly", ar: "كيفية قياس ضغط الدم بشكل صحيح" },
    summary: {
      fr: "Position, matériel et régularité : les bases pour une mesure fiable.",
      en: "Position, equipment and regularity: the basics of a reliable reading.",
      ar: "الوضعية والجهاز والانتظام: أساسيات قياس موثوق.",
    },
    body: {
      fr: "Asseyez-vous calmement pendant cinq minutes, le dos appuyé, les pieds à plat et le bras posé à hauteur du cœur. Ne parlez pas et ne croisez pas les jambes pendant la mesure. Une mesure isolée ne suffit pas : répétez-la à différents moments de la journée et notez les valeurs.\n\nSelon les recommandations ACC/AHA 2017, une tension de 130/80 mmHg ou plus est considérée comme élevée chez l'adulte ; l'OMS utilise le seuil de 140/90 mmHg. Seul un médecin peut poser un diagnostic. Consultez en urgence en cas de douleur thoracique, de troubles de la parole ou de faiblesse soudaine d'un côté du corps (appelez le 15).",
      en: "Sit quietly for five minutes with your back supported, feet flat and arm resting at heart level. Do not talk or cross your legs during the reading. One reading is not enough: repeat measurements at different times of day and record the values.\n\nAccording to the 2017 ACC/AHA guideline, 130/80 mmHg or higher is considered high in adults; WHO uses 140/90 mmHg. Only a doctor can make a diagnosis. Seek urgent help for chest pain, slurred speech or sudden weakness on one side of the body (call 15).",
      ar: "اجلس بهدوء خمس دقائق مع إسناد الظهر وتثبيت القدمين على الأرض وذراع في مستوى القلب. لا تتكلم ولا تتقاطع ساقيك أثناء القياس. قياس واحد لا يكفي: كرره في أوقات مختلفة من اليوم وسجّل القيم.\n\nحسب إرشادات ACC/AHA لعام 2017 يُعد 130/80 mmHg أو أكثر مرتفعاً لدى البالغين، بينما تعتمد منظمة الصحة العالمية عتبة 140/90 mmHg. التشخيص من اختصاص الطبيب وحده. اطلب المساعدة فوراً عند ألم الصدر أو اضطراب الكلام أو ضعف مفاجئ في جانب من الجسم (اتصل بالرقم 15).",
    },
    sources: [
      "WHO – Hypertension fact sheet (who.int)",
      "2017 ACC/AHA Guideline for the Prevention, Detection, Evaluation and Management of High Blood Pressure in Adults",
    ],
  },
  {
    slug: "heart-health-daily-habits",
    category: "heart-health",
    emoji: "❤️",
    readMinutes: 4,
    isFeatured: false,
    title: { fr: "Santé du cœur : les habitudes qui comptent", en: "Heart health: habits that matter", ar: "صحة القلب: عادات تُحدث فرقاً" },
    summary: {
      fr: "Activité physique, alimentation, tabac et sommeil influencent le risque cardiovasculaire.",
      en: "Physical activity, diet, tobacco and sleep all influence cardiovascular risk.",
      ar: "النشاط البدني والتغذية والتدخين والنوم تؤثر في خطر أمراض القلب والأوعية.",
    },
    body: {
      fr: "Les maladies cardiovasculaires sont la première cause de décès dans le monde, selon l'OMS. Pour réduire le risque, l'OMS recommande aux adultes au moins 150 à 300 minutes d'activité d'intensité modérée par semaine, une alimentation pauvre en sel et en graisses saturées, et l'arrêt du tabac.\n\nUne douleur ou une oppression thoracique, un essoufflement inhabituel ou un malaise doivent être pris au sérieux : appelez immédiatement le 15 et ne conduisez pas vous-même.",
      en: "Cardiovascular diseases are the leading cause of death worldwide, according to WHO. To reduce risk, WHO recommends at least 150 to 300 minutes of moderate-intensity activity per week for adults, a diet low in salt and saturated fat, and not smoking.\n\nChest pain or pressure, unusual breathlessness or fainting must be taken seriously: call 15 immediately and do not drive yourself.",
      ar: "أمراض القلب والأوعية هي السبب الأول للوفاة في العالم وفق منظمة الصحة العالمية. للحد من الخطر توصي المنظمة البالغين بممارسة 150 إلى 300 دقيقة من النشاط المعتدل أسبوعياً، واتباع نظام غذائي قليل الملح والدهون المشبعة، والإقلاع عن التدخين.\n\nألم الصدر أو ضغطه والضيق غير المعتاد في التنفس أو الإغماء أمور جدية: اتصل بالرقم 15 فوراً ولا تقد السيارة بنفسك.",
    },
    sources: [
      "WHO – Cardiovascular diseases fact sheet (who.int)",
      "American Heart Association – Life's Essential 8",
    ],
  },
  {
    slug: "prenatal-visits",
    category: "maternal-child",
    emoji: "🤰",
    readMinutes: 4,
    isFeatured: false,
    title: { fr: "Suivi de grossesse : les consultations prénatales", en: "Pregnancy follow-up: prenatal visits", ar: "متابعة الحمل: الفحوص قبل الولادة" },
    summary: {
      fr: "Pourquoi le suivi prénatal est important et les signes qui justifient un avis rapide.",
      en: "Why prenatal follow-up matters and the signs that need prompt advice.",
      ar: "لماذا تهم المتابعة قبل الولادة والعلامات التي تستدعي استشارة سريعة.",
    },
    body: {
      fr: "Le suivi prénatal permet de surveiller la santé de la mère et du bébé. L'Organisation mondiale de la santé recommande au moins huit contacts prénatals pendant la grossesse, avec mesure de la tension, du poids et examens prescrits.\n\nConsultez rapidement en cas de saignement vaginal, de maux de tête intenses, de troubles visuels, de gonflement brutal du visage ou des mains, de fièvre, ou si les mouvements du bébé diminuent. Une sage-femme ou un médecin doit suivre votre grossesse.",
      en: "Prenatal follow-up monitors the health of mother and baby. The World Health Organization recommends at least eight antenatal contacts during pregnancy, including blood pressure and weight checks and prescribed tests.\n\nSeek prompt advice for vaginal bleeding, severe headache, vision changes, sudden swelling of the face or hands, fever, or if the baby moves less. A midwife or doctor should follow your pregnancy.",
      ar: "تراقب المتابعة قبل الولادة صحة الأم والجنين. توصي منظمة الصحة العالمية بثماني زيارات على الأقل أثناء الحمل، تشمل قياس الضغط والوزن والفحوص المقررة.\n\nاستشر بسرعة عند النزيف المهبلي أو الصداع الشديد أو اضطراب الرؤية أو التورم المفاجئ للوجه واليدين أو الحمى أو نقص حركة الجنين. يجب أن تتابع الحمل قابلة أو طبيب.",
    },
    sources: ["WHO – Recommendations on antenatal care for a positive pregnancy experience (2016)"],
  },
  {
    slug: "prevent-falls-at-home",
    category: "elderly-care",
    emoji: "🧓",
    readMinutes: 4,
    isFeatured: true,
    title: { fr: "Prévenir les chutes à domicile", en: "Preventing falls at home", ar: "الوقاية من السقوط في المنزل" },
    summary: {
      fr: "Aménager le logement et garder l'équilibre pour rester autonome.",
      en: "Adapt the home and keep your balance to stay independent.",
      ar: "تهيئة المنزل والحفاظ على التوازن للبقاء مستقلاً.",
    },
    body: {
      fr: "Les chutes sont une cause importante de blessures chez les personnes âgées, et beaucoup sont évitables. Retirez les tapis glissants ou fixez-les, installez un éclairage nocturne, placez des barres d'appui dans la salle de bain et portez des chaussures stables.\n\nLa marche régulière et des exercices d'équilibre adaptés renforcent la stabilité. Faites revoir vos médicaments par votre médecin ou pharmacien, car certains provoquent des vertiges. Un aide-soignant ou un infirmier peut évaluer le domicile.",
      en: "Falls are a major cause of injury in older people, and many are preventable. Remove or secure loose rugs, install night lighting, add grab bars in the bathroom and wear stable shoes.\n\nRegular walking and suitable balance exercises build stability. Ask your doctor or pharmacist to review your medicines, as some can cause dizziness. A caregiver or nurse can assess the home.",
      ar: "السقوط سبب رئيسي للإصابات لدى كبار السن، وكثير منه يمكن تفاديه. أزل السجاد المنزلق أو ثبّته، وركّب إضاءة ليلية، وضع مقابض دعم في الحمام، وارتدِ أحذية ثابتة.\n\nالمشي المنتظم وتمارين التوازن المناسبة تقوي الثبات. اطلب من طبيبك أو صيدلانيك مراجعة أدويتك، فبعضها قد يسبب الدوخة. ويمكن لمساعد طبي أو ممرض تقييم المنزل.",
    },
    sources: ["WHO – Falls fact sheet (who.int)"],
  },
  {
    slug: "first-aid-minor-burns",
    category: "first-aid",
    emoji: "🔥",
    readMinutes: 3,
    isFeatured: true,
    title: { fr: "Premiers secours : les petites brûlures", en: "First aid: minor burns", ar: "الإسعافات الأولية: الحروق البسيطة" },
    summary: {
      fr: "Les gestes immédiats à faire et les signes qui imposent d'appeler les secours.",
      en: "Immediate steps to take and the signs that mean you must call emergency services.",
      ar: "الإجراءات الفورية، والعلامات التي تستوجب الاتصال بالإسعاف.",
    },
    body: {
      fr: "Pour une petite brûlure, refroidissez la zone sous de l'eau courante fraîche ou tempérée pendant au moins 20 minutes, dès que possible. Retirez bijoux et vêtements non collés avant que la zone ne gonfle, puis couvrez avec une compresse propre et non pelucheuse. N'appliquez ni beurre, ni dentifrice, ni glace.\n\nAppelez le 15 si la brûlure est étendue, profonde, située au visage, aux mains, aux articulations ou aux organes génitaux, ou si elle concerne un enfant ou une personne âgée. Ne percez jamais les cloques.",
      en: "For a small burn, cool the area under cool running water for at least 20 minutes as soon as possible. Remove jewellery and loose clothing before swelling starts, then cover with a clean, non-fluffy dressing. Do not apply butter, toothpaste or ice.\n\nCall 15 if the burn is large or deep, on the face, hands, joints or genitals, or affects a child or an older adult. Never pop blisters.",
      ar: "في حالة الحرق البسيط، برّد المنطقة تحت ماء جارٍ بارد أو فاتر لمدة 20 دقيقة على الأقل وفي أقرب وقت. انزع الحلي والملابس غير الملتصقة قبل أن تتورم المنطقة، ثم غطِّها بضمادة نظيفة لا تترك وبراً. لا تضع الزبدة أو معجون الأسنان أو الثلج.\n\nاتصل بالرقم 15 إذا كان الحرق واسعاً أو عميقاً أو في الوجه أو اليدين أو المفاصل أو الأعضاء التناسلية، أو إذا أصاب طفلاً أو مسناً. لا تفقأ البثور أبداً.",
    },
    sources: [
      "European Resuscitation Council – First aid guidelines (cprguidelines.eu)",
      "International Federation of Red Cross and Red Crescent Societies – First Aid Guidelines",
    ],
  },
  {
    slug: "caring-for-minor-wound",
    category: "wound-care",
    emoji: "🩹",
    readMinutes: 3,
    isFeatured: false,
    title: { fr: "Soigner une petite plaie", en: "Caring for a minor wound", ar: "العناية بالجرح البسيط" },
    summary: {
      fr: "Nettoyage, pansement propre et signes qui peuvent indiquer une infection.",
      en: "Cleaning, a clean dressing, and signs that may indicate infection.",
      ar: "التنظيف والضمادة النظيفة وعلامات الالتهاب.",
    },
    body: {
      fr: "Pour une petite plaie superficielle, lavez-vous les mains, nettoyez la plaie à l'eau propre ou au savon doux, puis couvrez-la d'un pansement stérile. Changez le pansement lorsqu'il est mouillé ou souillé, et gardez la zone propre.\n\nConsultez un professionnel de santé si la rougeur s'étend, si la plaie devient chaude, gonflée ou douloureuse, si du pus apparaît, ou si vous avez de la fièvre. Les plaies chroniques (diabète, troubles circulatoires, escarres) nécessitent un suivi régulier.",
      en: "For a small superficial wound, wash your hands, rinse the wound with clean water or mild soap, then cover it with a sterile dressing. Change the dressing when it is wet or dirty, and keep the area clean.\n\nSee a health professional if redness spreads, the wound becomes hot, swollen or painful, pus appears, or you develop a fever. Chronic wounds (diabetes, circulation problems, pressure sores) need regular professional follow-up.",
      ar: "للجرح السطحي البسيط اغسل يديك، ثم نظّف الجرح بماء نظيف أو صابون لطيف، وغطِّه بضمادة معقمة. غيّر الضمادة عندما تتبلل أو تتسخ، وحافظ على نظافة المنطقة.\n\nاستشر مختصاً صحياً إذا امتد الاحمرار أو أصبح الجرح ساخناً أو متورماً أو مؤلماً، أو ظهر القيح، أو ارتفعت حرارتك. الجروح المزمنة (السكري، اضطرابات الدورة الدموية، قرح الضغط) تحتاج متابعة منتظمة من مختص.",
    },
    sources: [
      "NICE – Wound care guidance (nice.org.uk)",
      "WHO – Clean Care is Safer Care (who.int)",
    ],
  },
  {
    slug: "flu-or-cold",
    category: "common-diseases",
    emoji: "🤧",
    readMinutes: 3,
    isFeatured: false,
    title: { fr: "Grippe ou rhume : comment les distinguer", en: "Flu or cold: how to tell them apart", ar: "الأنفلونزا أم نزلة البرد: كيف تميّز بينهما" },
    summary: {
      fr: "Mode d'apparition, intensité des symptômes et signes d'alerte.",
      en: "Onset, symptom intensity and warning signs.",
      ar: "بداية الأعراض وشدتها وعلامات الإنذار.",
    },
    body: {
      fr: "Le rhume touche surtout le nez et la gorge et s'installe progressivement. La grippe, due aux virus influenza, débute souvent brutalement avec fièvre, douleurs musculaires et grande fatigue. Dans les deux cas, le repos, l'hydratation et la surveillance suffisent souvent.\n\nConsultez rapidement si la fièvre persiste plus de 3 jours, si la respiration devient difficile, si une douleur thoracique apparaît, ou si vous êtes une personne âgée, enceinte ou atteinte d'une maladie chronique. Ce texte ne remplace pas l'avis d'un médecin.",
      en: "A cold mainly affects the nose and throat and builds up gradually. Influenza, caused by influenza viruses, often starts suddenly with fever, muscle aches and marked tiredness. In both cases, rest, fluids and monitoring are often enough.\n\nSeek advice promptly if fever lasts more than 3 days, breathing becomes difficult, chest pain appears, or if you are an older adult, pregnant or living with a chronic condition. This text does not replace a doctor's advice.",
      ar: "يصيب الرشح الأنف والحلق غالباً ويتطور تدريجياً. أما الأنفلونزا، الناتجة عن فيروسات الإنفلونزا، فتبدأ غالباً فجأة بحمى وآلام عضلية وتعب شديد. في الحالتين يكفي غالباً الراحة وشرب السوائل والمتابعة.\n\nاستشر بسرعة إذا استمرت الحمى أكثر من 3 أيام، أو صعب التنفس، أو ظهر ألم في الصدر، أو كنت من كبار السن أو حاملاً أو تعاني مرضاً مزمناً. هذا النص لا يغني عن رأي الطبيب.",
    },
    sources: ["WHO – Influenza (seasonal) fact sheet (who.int)"],
  },
  {
    slug: "adult-physical-activity",
    category: "healthy-lifestyle",
    emoji: "🏃",
    readMinutes: 3,
    isFeatured: false,
    title: { fr: "Bouger chaque jour : repères pour adultes", en: "Moving every day: guidance for adults", ar: "الحركة اليومية: إرشادات للبالغين" },
    summary: {
      fr: "Combien d'activité, quels types, et comment commencer progressivement.",
      en: "How much activity, which types, and how to start gradually.",
      ar: "كم من النشاط، وأي أنواع، وكيف تبدأ تدريجياً.",
    },
    body: {
      fr: "L'OMS recommande aux adultes au moins 150 à 300 minutes d'activité d'intensité modérée par semaine, ou 75 à 150 minutes d'intensité soutenue, avec des activités de renforcement musculaire au moins deux fois par semaine. La marche rapide, le vélo ou la natation comptent.\n\nCommencez doucement et augmentez progressivement. Si vous avez une maladie chronique, une douleur ou que vous n'avez pas été actif depuis longtemps, demandez l'avis de votre médecin avant de commencer.",
      en: "WHO recommends that adults do at least 150 to 300 minutes of moderate-intensity activity per week, or 75 to 150 minutes of vigorous activity, plus muscle-strengthening activities at least twice a week. Brisk walking, cycling and swimming all count.\n\nStart gently and build up gradually. If you have a chronic condition, pain, or have been inactive for a long time, ask your doctor before starting.",
      ar: "توصي منظمة الصحة العالمية البالغين بممارسة 150 إلى 300 دقيقة أسبوعياً من النشاط المعتدل، أو 75 إلى 150 دقيقة من النشاط القوي، مع تمارين تقوية العضلات مرتين على الأقل في الأسبوع. المشي السريع وركوب الدراجة والسباحة كلها مفيدة.\n\nابدأ بلطف وزد الشدة تدريجياً. وإذا كنت تعاني مرضاً مزمناً أو ألماً أو خاملاً منذ مدة طويلة، استشر طبيبك قبل البدء.",
    },
    sources: ["WHO – Guidelines on physical activity and sedentary behaviour (2020)"],
  },
  {
    slug: "hand-hygiene-at-home",
    category: "prevention-hygiene",
    emoji: "🧼",
    readMinutes: 3,
    isFeatured: false,
    title: { fr: "Hygiène des mains à la maison", en: "Hand hygiene at home", ar: "نظافة اليدين في البيت" },
    summary: {
      fr: "Quand et comment se laver les mains pour limiter la transmission des microbes.",
      en: "When and how to wash your hands to reduce the spread of germs.",
      ar: "متى وكيف تغسل يديك للحد من انتقال الجراثيم.",
    },
    body: {
      fr: "Lavez-vous les mains à l'eau et au savon pendant au moins 20 secondes : avant de préparer ou de manger un repas, après être allé aux toilettes, après avoir changé une couche ou soigné un proche, et après avoir toussé ou éternué. Séchez-les bien avec un linge propre ou du papier.\n\nL'OMS indique qu'un lavage soigneux des mains réduit les infections, y compris celles transmises pendant les soins. Sans savon, une solution hydro-alcoolique peut être utilisée sur des mains non visiblement sales.",
      en: "Wash your hands with soap and water for at least 20 seconds: before preparing or eating food, after using the toilet, after changing a nappy or caring for someone, and after coughing or sneezing. Dry them well with a clean towel or paper.\n\nWHO notes that thorough handwashing reduces infections, including those spread during care. If soap is unavailable, an alcohol-based hand rub can be used on hands that are not visibly dirty.",
      ar: "اغسل يديك بالماء والصابون لمدة 20 ثانية على الأقل: قبل تحضير الطعام أو تناوله، وبعد استعمال المرحاض، وبعد تغيير الحفاض أو رعاية أحد أفراد الأسرة، وبعد السعال أو العطس. جفّفهما جيداً بمنشفة نظيفة أو ورق.\n\nتشير منظمة الصحة العالمية إلى أن غسل اليدين بعناية يقلل العدوى، بما فيها العدوى المنتقلة أثناء الرعاية. وإذا لم يتوفر الصابون، يمكن استعمال معقم كحولي على يدين غير متسخة بشكل واضح.",
    },
    sources: [
      "WHO – Guidelines on hand hygiene in health care (2009)",
      "WHO – SAVE LIVES: Clean Your Hands campaign (who.int)",
    ],
  },
];

/* ----------------------------- Daily tips ----------------------------- */

const TIPS: Array<{ category: string; emoji: string; title: L10n; summary: L10n }> = [
  {
    category: "healthy-lifestyle",
    emoji: "🚶",
    title: { fr: "Marchez 30 minutes par jour", en: "Walk 30 minutes a day", ar: "امشِ 30 دقيقة يومياً" },
    summary: {
      fr: "Une marche d'un bon pas la plupart des jours aide le cœur et le moral.",
      en: "A brisk walk most days supports your heart and mood.",
      ar: "امشِ بخطوات سريعة معظم أيام الأسبوع لدعم القلب والمزاج.",
    },
  },
  {
    category: "nutrition",
    emoji: "🥕",
    title: { fr: "Mangez cinq portions de fruits et légumes", en: "Eat five portions of fruit and vegetables", ar: "تناول خمس حصص من الفواكه والخضروات" },
    summary: {
      fr: "Variez les couleurs : simple, économique et bénéfique.",
      en: "Vary the colours: simple, affordable and beneficial.",
      ar: "نوّع الألوان: بسيط واقتصادي ومفيد.",
    },
  },
  {
    category: "nutrition",
    emoji: "🧂",
    title: { fr: "Réduisez le sel", en: "Cut back on salt", ar: "قلّل الملح" },
    summary: {
      fr: "Utilisez citron et herbes fraîches à la place d'une partie du sel.",
      en: "Use lemon and fresh herbs in place of some of the salt.",
      ar: "استبدل جزءاً من الملح بالليمون والأعشاب الطازجة.",
    },
  },
  {
    category: "diabetes",
    emoji: "💧",
    title: { fr: "Buvez de l'eau tout au long de la journée", en: "Drink water throughout the day", ar: "اشرب الماء طوال اليوم" },
    summary: {
      fr: "Privilégiez l'eau plutôt que les boissons sucrées.",
      en: "Choose water over sugary drinks.",
      ar: "فضّل الماء على المشروبات المحلاة.",
    },
  },
  {
    category: "blood-pressure",
    emoji: "🩺",
    title: { fr: "Notez votre tension", en: "Keep a blood pressure log", ar: "دوّن قياسات ضغطك" },
    summary: {
      fr: "Un carnet de mesures aide votre médecin à mieux vous suivre.",
      en: "A measurement log helps your doctor follow you more accurately.",
      ar: "سجل القياسات يساعد طبيبك على متابعتك بدقة أكبر.",
    },
  },
  {
    category: "heart-health",
    emoji: "❤️",
    title: { fr: "Arrêtez le tabac", en: "Quit tobacco", ar: "أقلع عن التدخين" },
    summary: {
      fr: "Chaque jour sans tabac compte pour votre cœur. Demandez de l'aide à votre médecin.",
      en: "Every smoke-free day counts for your heart. Ask your doctor for support.",
      ar: "كل يوم بدون تدخين يفيد قلبك. اطلب الدعم من طبيبك.",
    },
  },
  {
    category: "maternal-child",
    emoji: "🤰",
    title: { fr: "Ne manquez pas vos consultations prénatales", en: "Do not miss prenatal visits", ar: "لا تفوّت الزيارات قبل الولادة" },
    summary: {
      fr: "L'OMS recommande au moins huit contacts pendant la grossesse.",
      en: "WHO recommends at least eight contacts during pregnancy.",
      ar: "توصي منظمة الصحة العالمية بثماني زيارات على الأقل أثناء الحمل.",
    },
  },
  {
    category: "elderly-care",
    emoji: "💡",
    title: { fr: "Éclairez les couloirs la nuit", en: "Light hallways at night", ar: "أنر الممرات ليلاً" },
    summary: {
      fr: "Une veilleuse dans le couloir réduit le risque de chute.",
      en: "A night light in the hallway reduces the risk of falls.",
      ar: "مصباح ليلي في الممر يقلل خطر السقوط.",
    },
  },
  {
    category: "first-aid",
    emoji: "🧊",
    title: { fr: "Refroidir une brûlure", en: "Cool a burn", ar: "برّد الحرق" },
    summary: {
      fr: "Eau fraîche pendant au moins 20 minutes. Ni beurre ni dentifrice.",
      en: "Cool water for at least 20 minutes. No butter or toothpaste.",
      ar: "ماء بارد لمدة 20 دقيقة على الأقل. لا زبدة ولا معجون أسنان.",
    },
  },
  {
    category: "prevention-hygiene",
    emoji: "🧼",
    title: { fr: "Lavez-vous les mains", en: "Wash your hands", ar: "اغسل يديك" },
    summary: {
      fr: "20 secondes à l'eau et au savon avant de manger et après les toilettes.",
      en: "20 seconds with water and soap before eating and after using the toilet.",
      ar: "20 ثانية بالماء والصابون قبل الأكل وبعد المرحاض.",
    },
  },
];

/* ----------------------------- Seeding ----------------------------- */

/** Seeds the database once, when the website settings row does not exist yet. Idempotent. */
export async function ensureSeeded(): Promise<void> {
  try {
    const [row] = await db
      .select({ key: siteSettings.key })
      .from(siteSettings)
      .where(eq(siteSettings.key, "main"))
      .limit(1);
    if (!row) await seedDemoData();
  } catch (err) {
    console.error("[seed] failed", err);
  }
}

async function seedDemoData() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(724202)`);
    const [existing] = await tx
      .select({ key: siteSettings.key })
      .from(siteSettings)
      .where(eq(siteSettings.key, "main"))
      .limit(1);
    if (existing) return;

    await tx.insert(siteSettings).values({ key: "main", value: DEFAULT_SITE_SETTINGS });

    await tx.insert(categories).values(CATEGORIES.map((c, i) => ({ slug: c.slug, name: c.name, sortOrder: i + 1 })));

    const serviceRows = await tx
      .insert(services)
      .values(
        SERVICES.map((s) => ({
          slug: s.slug,
          category: s.category,
          icon: s.icon,
          priceMad: s.priceMad,
          durationMinutes: s.durationMinutes,
          sortOrder: s.sortOrder,
          requiresVerifiedPro: false,
          isFeatured: true,
          name: s.name,
          description: s.description,
        })),
      )
      .returning({ id: services.id, slug: services.slug, price: services.priceMad, duration: services.durationMinutes, name: services.name });
    const serviceBySlug = new Map(serviceRows.map((s) => [s.slug, s]));

    await tx.insert(articles).values([
      ...ARTICLES.map((a) => ({
        slug: a.slug,
        kind: "article",
        category: a.category,
        emoji: a.emoji,
        readMinutes: a.readMinutes,
        isFeatured: a.isFeatured,
        title: a.title,
        summary: a.summary,
        body: a.body,
        sources: a.sources,
        reviewedBy: "",
        reviewedAt: null,
      })),
      ...TIPS.map((t, i) => ({
        slug: `tip-${i + 1}`,
        kind: "tip",
        category: t.category,
        emoji: t.emoji,
        readMinutes: 1,
        isFeatured: false,
        title: t.title,
        summary: t.summary,
        body: { fr: "", en: "", ar: "" },
        sources: [] as string[],
        reviewedBy: "",
        reviewedAt: null,
      })),
    ]);

    // Demo accounts (fictional). Clearly labelled on the login page.
    const adminHash = await hashPassword(ADMIN_PASSWORD);
    const demoHash = await hashPassword(DEMO_PASSWORD);
    const [admin] = await tx
      .insert(users)
      .values({
        email: "admin@shifacare.ma",
        passwordHash: adminHash,
        fullName: "Administrateur ShifaCare (démo)",
        phone: "0600000000",
        city: "Fès",
        role: "admin",
        locale: "fr",
      })
      .returning({ id: users.id });
    const [patient] = await tx
      .insert(users)
      .values({
        email: "patient@shifacare.ma",
        passwordHash: demoHash,
        fullName: "Patient démo (fictif)",
        phone: "0600000001",
        city: "Fès",
        address: "Adresse fictive, Fès",
        role: "patient",
        locale: "fr",
      })
      .returning({ id: users.id });

    // Sample booking requests (fictional people and addresses).
    const at = (days: number, hour: number) => {
      const d = new Date();
      d.setUTCDate(d.getUTCDate() + days);
      d.setUTCHours(hour - 1, 0, 0, 0); // Morocco is UTC+1 outside Ramadan
      return d;
    };
    const bpSvc = serviceBySlug.get("blood-pressure-measurement");
    const woundSvc = serviceBySlug.get("wound-dressing");
    const injSvc = serviceBySlug.get("injections");
    if (bpSvc && woundSvc && injSvc) {
      await tx.insert(appointments).values([
        {
          reference: "SC-DEMO-0001",
          patientId: null,
          serviceId: bpSvc.id,
          scheduledAt: at(2, 10),
          status: "pending",
          patientName: "Patient fictif A",
          phone: "0600000002",
          city: "Fès",
          address: "Adresse fictive, Fès",
          medicalNotes: "Demande d'exemple (fictive).",
          priceMad: bpSvc.price,
          durationMinutes: bpSvc.duration,
        },
        {
          reference: "SC-DEMO-0002",
          patientId: patient.id,
          serviceId: woundSvc.id,
          scheduledAt: at(3, 11),
          status: "confirmed",
          patientName: "Patient démo (fictif)",
          phone: "0600000001",
          city: "Fès",
          address: "Adresse fictive, Fès",
          medicalNotes: "Réservation d'exemple (fictive).",
          priceMad: woundSvc.price,
          durationMinutes: woundSvc.duration,
        },
        {
          reference: "SC-DEMO-0003",
          patientId: null,
          serviceId: injSvc.id,
          scheduledAt: at(-5, 9),
          status: "completed",
          patientName: "Famille fictive B",
          phone: "0600000003",
          city: "Fès",
          address: "Adresse fictive, Fès",
          medicalNotes: "Exemple terminé (fictif).",
          priceMad: injSvc.price,
          durationMinutes: injSvc.duration,
        },
      ]);
    }

    await tx.insert(notifications).values([
      {
        userId: patient.id,
        title: { fr: "Bienvenue sur ShifaCare (démo)", en: "Welcome to ShifaCare (demo)", ar: "مرحباً بك في شفاء كير (نسخة تجريبية)" },
        message: {
          fr: "Ceci est un compte de démonstration fictif. Vos demandes apparaîtront ici.",
          en: "This is a fictional demonstration account. Your requests will appear here.",
          ar: "هذا حساب تجريبي خيالي. ستظهر طلباتك هنا.",
        },
        link: "/appointments",
      },
      {
        userId: admin.id,
        title: { fr: "Contenu prêt à valider", en: "Content ready for validation", ar: "محتوى جاهز للمراجعة" },
        message: {
          fr: `${REVIEW_NOTE}. Ajoutez le nom du relecteur dans le tableau admin lorsque la validation est faite.`,
          en: `${REVIEW_NOTE}. Add the reviewer's name in the admin dashboard once validated.`,
          ar: "المراجعة الطبية قيد الانتظار. أضف اسم المراجع في لوحة الإدارة بعد التحقق.",
        },
        link: "/admin",
      },
    ]);
  });
}
