import * as THREE from 'three';
import { Reflector } from 'three/addons/objects/Reflector.js';
import type { Settings, WorldId } from '../data/worlds';

function seededRandom(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

export function lakeDistance(x: number, z: number) {
  return Math.hypot(x / 33, (z + 8) / 37);
}

export function terrainHeight(x: number, z: number) {
  const distance = lakeDistance(x, z);
  if (distance < 1) return -2.3 * Math.min(1, (1 - distance) * 8);
  const bank = THREE.MathUtils.smoothstep(distance, 1, 1.3);
  const rolling = 1.2 + Math.sin(x * 0.055) * Math.cos(z * 0.044) * 1.5
    + Math.sin(x * 0.12 + z * 0.03) * 0.45;
  return bank * rolling + Math.max(0, distance - 1.5) * 1.65;
}

function createDeer() {
  const group = new THREE.Group();
  const fur = new THREE.MeshStandardMaterial({ color: '#aa7952', roughness: 1 });
  const cream = new THREE.MeshStandardMaterial({ color: '#e4cfac', roughness: 1 });
  const dark = new THREE.MeshStandardMaterial({ color: '#40352c', roughness: 1 });
  const ellipsoid = (scale: [number, number, number], position: [number, number, number], material = fur) => {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), material);
    mesh.scale.set(...scale);
    mesh.position.set(...position);
    mesh.castShadow = true;
    group.add(mesh);
    return mesh;
  };
  ellipsoid([0.38, 0.46, 0.86], [0, 1.12, 0]);
  const neck = ellipsoid([0.23, 0.62, 0.25], [0, 1.65, -0.62]);
  neck.rotation.x = -0.3;
  ellipsoid([0.24, 0.28, 0.4], [0, 2.13, -0.84]);
  ellipsoid([0.18, 0.14, 0.2], [0, 2.05, -1.12], dark);
  ellipsoid([0.18, 0.26, 0.18], [0, 1.25, 0.73], cream);
  for (const side of [-1, 1]) {
    const ear = ellipsoid([0.1, 0.27, 0.085], [side * 0.24, 2.4, -0.75]);
    ear.rotation.z = side * -0.5;
    ellipsoid([0.033, 0.033, 0.033], [side * 0.215, 2.17, -0.99], dark);
    for (const front of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.04, 0.95, 7), fur);
      leg.position.set(side * 0.25, 0.5, front * 0.53);
      group.add(leg);
      ellipsoid([0.075, 0.08, 0.12], [side * 0.25, 0.06, front * 0.53], dark);
    }
    for (let branch = 0; branch < 3; branch += 1) {
      const antler = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.026, 0.35, 5), cream);
      antler.position.set(side * (0.16 + branch * 0.075), 2.51 + branch * 0.15, -0.78 + branch * 0.04);
      antler.rotation.z = side * -0.5;
      group.add(antler);
    }
  }
  return group;
}

export function createNatureWorld(world: WorldId, settings: Settings) {
  const random = seededRandom(41827);
  const scene = new THREE.Scene();
  const sunset = settings.timeOfDay === 'sunset';
  const noon = settings.timeOfDay === 'day';
  const horizon = new THREE.Color(sunset ? '#edbb96' : noon ? '#d5e8e4' : '#e7dbc3');
  scene.background = horizon;
  scene.fog = new THREE.FogExp2(horizon, world === 'forest' ? 0.008 : 0.0045);
  const sunDirection = new THREE.Vector3(-0.5, noon ? 0.8 : sunset ? 0.16 : 0.32, -0.8).normalize();
  const sky = new THREE.Mesh(new THREE.SphereGeometry(480, 32, 20), new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      zenith: { value: new THREE.Color(sunset ? '#8d9db6' : '#8cb8cb') },
      horizon: { value: horizon },
      sunDirection: { value: sunDirection },
      sunColor: { value: new THREE.Color(sunset ? '#ffe1a0' : '#fff5d6') },
    },
    vertexShader: `varying vec3 vDirection;
      void main() { vDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `uniform vec3 zenith; uniform vec3 horizon; uniform vec3 sunDirection; uniform vec3 sunColor;
      varying vec3 vDirection;
      void main() {
        vec3 direction = normalize(vDirection);
        float h = pow(max(direction.y, 0.0), 0.5);
        vec3 sky = mix(horizon, zenith, h);
        float sun = max(dot(direction, sunDirection), 0.0);
        sky += sunColor * pow(sun, 110.0) * 0.35;
        sky += sunColor * pow(sun, 2200.0) * 2.0;
        gl_FragColor = vec4(sky, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  }));
  scene.add(sky);
  scene.add(new THREE.HemisphereLight('#eaf4ed', '#5b6244', noon ? 2 : 1.65));
  const sun = new THREE.DirectionalLight(sunset ? '#ffd09a' : '#fff0ce', 2.2);
  sun.position.copy(sunDirection).multiplyScalar(100);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -55;
  sun.shadow.camera.right = 55;
  sun.shadow.camera.top = 55;
  sun.shadow.camera.bottom = -55;
  sun.shadow.camera.far = 230;
  sun.shadow.bias = -0.001;
  sun.shadow.normalBias = 0.035;
  scene.add(sun);

  const groundGeometry = new THREE.PlaneGeometry(330, 330, 120, 120);
  groundGeometry.rotateX(-Math.PI / 2);
  const groundPositions = groundGeometry.attributes.position;
  const colors: number[] = [];
  const color = new THREE.Color();
  for (let i = 0; i < groundPositions.count; i += 1) {
    const x = groundPositions.getX(i);
    const z = groundPositions.getZ(i);
    groundPositions.setY(i, terrainHeight(x, z));
    const d = lakeDistance(x, z);
    color.set(d < 1.12 ? '#b6b396' : '#7e965a');
    color.multiplyScalar(0.85 + random() * 0.25);
    colors.push(color.r, color.g, color.b);
  }
  groundGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  groundGeometry.computeVertexNormals();
  const ground = new THREE.Mesh(groundGeometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 }));
  ground.receiveShadow = true;
  scene.add(ground);

  const pathGeometry = new THREE.RingGeometry(1.055, 1.115, 140, 2);
  pathGeometry.rotateX(-Math.PI / 2);
  const pathPositions = pathGeometry.attributes.position;
  for (let i = 0; i < pathPositions.count; i += 1) {
    const x = pathPositions.getX(i) * 33;
    const z = pathPositions.getZ(i) * 37 - 8;
    pathPositions.setXYZ(i, x, terrainHeight(x, z) + 0.035, z);
  }
  pathGeometry.computeVertexNormals();
  const path = new THREE.Mesh(pathGeometry, new THREE.MeshStandardMaterial({ color: '#c8bc97', roughness: 1, side: THREE.DoubleSide }));
  path.receiveShadow = true;
  scene.add(path);

  // A planar reflection is rendered for each eye; ripples gently distort its projection.
  const waterShader = {
    uniforms: { color: { value: new THREE.Color() }, tDiffuse: { value: null }, textureMatrix: { value: new THREE.Matrix4() }, time: { value: 0 } },
    vertexShader: `uniform mat4 textureMatrix; varying vec4 vReflection; varying vec3 vWorld;
      void main() {
        vReflection = textureMatrix * vec4(position, 1.0);
        vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `uniform sampler2D tDiffuse; uniform vec3 color; uniform float time;
      varying vec4 vReflection; varying vec3 vWorld;
      void main() {
        vec4 uv = vReflection;
        float ripple = sin(vWorld.x * 2.1 + time * 0.7) * cos(vWorld.z * 1.4 + time * 0.4);
        uv.xy += vec2(ripple, sin(vWorld.z * 2.6 - time * 0.6)) * 0.0011 * uv.w;
        vec3 reflection = texture2DProj(tDiffuse, uv).rgb;
        vec3 tint = vec3(0.16, 0.34, 0.29);
        float facing = clamp(distance(cameraPosition.xz, vWorld.xz) / 65.0, 0.0, 1.0);
        vec3 water = mix(tint, reflection, 0.64 + facing * 0.31);
        water += vec3(0.015, 0.021, 0.014) * ripple;
        gl_FragColor = vec4(water, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  };
  const lake = new Reflector(new THREE.CircleGeometry(1, 96), {
    textureWidth: settings.quality === 'high' ? 768 : 384,
    textureHeight: settings.quality === 'high' ? 768 : 384,
    clipBias: 0.003,
    multisample: 0,
    shader: waterShader,
  });
  lake.rotation.x = -Math.PI / 2;
  lake.scale.set(33, 37, 1);
  lake.position.set(0, 0.065, -8);
  const originalReflection = lake.onBeforeRender.bind(lake);
  const savedViewport = new THREE.Vector4();
  const savedScissor = new THREE.Vector4();
  lake.onBeforeRender = (renderer, ...args) => {
    // Stereo eye cameras have matrixAutoUpdate disabled; their mirror cameras must not.
    const reflectionCamera = lake.getReflectionCamera(args[1]);
    reflectionCamera.matrixAutoUpdate = true;
    const scissorEnabled = renderer.getScissorTest();
    renderer.getViewport(savedViewport);
    renderer.getScissor(savedScissor);
    renderer.setScissorTest(false);
    originalReflection(renderer, ...args);
    renderer.setViewport(savedViewport);
    renderer.setScissor(savedScissor);
    renderer.setScissorTest(scissorEnabled);
  };
  scene.add(lake);

  for (let i = 0; i < 12; i += 1) {
    const height = 37 + random() * 42;
    const geometry = new THREE.ConeGeometry(24 + random() * 20, height, 15, 10);
    const positions = geometry.attributes.position;
    const shades: number[] = [];
    for (let vertex = 0; vertex < positions.count; vertex += 1) {
      const y = positions.getY(vertex);
      const x = positions.getX(vertex);
      const z = positions.getZ(vertex);
      const elevation = y / height + 0.5;
      const angleAround = Math.atan2(z, x);
      const ridge = 1 + Math.sin(angleAround * 5 + i) * 0.16 + Math.cos(angleAround * 3 - i) * 0.12;
      const distortion = Math.sin(x * 0.4 + z * 0.3 + i) * 2.1;
      positions.setXYZ(vertex, x * ridge + elevation * 7, y + Math.sin(angleAround * 3 + i) * 3 * (1 - elevation), z * ridge + distortion * (1 - elevation));
      const snow = elevation > 0.76 + Math.sin(x * 0.28) * 0.07;
      color.set(snow ? '#edf0e7' : i % 2 ? '#758983' : '#647a72');
      color.multiplyScalar(0.9 + Math.sin(z * 0.5 + x) * 0.1);
      shades.push(color.r, color.g, color.b);
    }
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(shades, 3));
    geometry.computeVertexNormals();
    const mountain = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, flatShading: true }));
    const angle = Math.PI + (i / 11) * Math.PI;
    mountain.position.set(Math.cos(angle) * (114 + random() * 30), height / 2 - 3, Math.sin(angle) * 90 - 65);
    mountain.rotation.y = random() * 6;
    scene.add(mountain);
  }

  const treeCount = settings.quality === 'high' ? 500 : 320;
  const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.13, 0.23, 1, 7), new THREE.MeshStandardMaterial({ color: '#665541', roughness: 1 }), treeCount);
  const foliageMaterial = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, flatShading: true });
  const foliage = [0, 1, 2, 3].map(() => new THREE.InstancedMesh(new THREE.ConeGeometry(1, 1, 9), foliageMaterial, treeCount));
  const dummy = new THREE.Object3D();
  const treeLocations: { x: number; z: number }[] = [{ x: -12, z: 31 }, { x: 14, z: 30 }, { x: -15, z: 36 }, { x: 16, z: 35 }];
  while (treeLocations.length < treeCount) {
    const x = (random() - 0.5) * 220;
    const z = (random() - 0.5) * 220 - 14;
    if (lakeDistance(x, z) < 1.18 || (x > 35 && z > -30 && random() < 0.9)) continue;
    if (Math.hypot(x, z - 34) < 8 || Math.hypot(x + 45, z - 28) < 5) continue;
    treeLocations.push({ x, z });
  }
  treeLocations.forEach(({ x, z }, i) => {
    const y = terrainHeight(x, z);
    const height = 6 + random() * 8;
    const width = 1.5 + random() * 1.3;
    dummy.position.set(x, y + height * 0.35, z);
    dummy.scale.set(1, height * 0.7, 1);
    dummy.rotation.set(0, random() * 6.28, 0);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    foliage.forEach((layer, tier) => {
      dummy.position.set(x, y + height * (0.39 + tier * 0.145), z);
      const tierWidth = width * (1 - tier * 0.18);
      dummy.scale.set(tierWidth, height * (0.43 - tier * 0.025), tierWidth);
      dummy.updateMatrix();
      layer.setMatrixAt(i, dummy.matrix);
      color.setHSL(0.3 + random() * 0.055, 0.38 + random() * 0.15, 0.15 + tier * 0.022 + random() * 0.055);
      layer.setColorAt(i, color);
    });
  });
  trunks.castShadow = true;
  scene.add(trunks);
  foliage.forEach(layer => { layer.castShadow = true; layer.receiveShadow = true; scene.add(layer); });

  const rockGeometry = new THREE.IcosahedronGeometry(1, 1);
  const rockPositions = rockGeometry.attributes.position;
  for (let i = 0; i < rockPositions.count; i += 1) {
    const x = rockPositions.getX(i);
    const y = rockPositions.getY(i);
    const z = rockPositions.getZ(i);
    const distortion = 0.9 + Math.sin(x * 5 + y * 3 + z * 4) * 0.1;
    rockPositions.setXYZ(i, x * distortion, y * 0.7, z * distortion);
  }
  rockGeometry.computeVertexNormals();
  const rocks = new THREE.InstancedMesh(rockGeometry, new THREE.MeshStandardMaterial({ color: '#9a9d8f', roughness: 1, flatShading: true }), 90);
  for (let i = 0; i < 90; i += 1) {
    const angle = random() * Math.PI * 2;
    const radius = 1.01 + random() * 0.07;
    const x = Math.cos(angle) * 33 * radius;
    const z = Math.sin(angle) * 37 * radius - 8;
    const size = 0.25 + random() * 1;
    dummy.position.set(x, Math.max(0.06, terrainHeight(x, z)) + size * 0.2, z);
    dummy.rotation.set(random() * 0.3, random() * 6, 0);
    dummy.scale.set(size * 1.4, size, size);
    dummy.updateMatrix();
    rocks.setMatrixAt(i, dummy.matrix);
  }
  rocks.castShadow = true;
  scene.add(rocks);

  const grassCount = settings.quality === 'high' ? 6500 : 4200;
  const grassGeometry = new THREE.BufferGeometry();
  const bladeVertices: number[] = [];
  for (let blade = 0; blade < 3; blade += 1) {
    const angle = blade * Math.PI / 3;
    const widthX = Math.cos(angle) * 0.025;
    const widthZ = Math.sin(angle) * 0.025;
    const bendX = Math.sin(angle) * 0.075;
    const bendZ = Math.cos(angle) * 0.075;
    bladeVertices.push(-widthX, 0, -widthZ, widthX, 0, widthZ, bendX, 0.32 + blade * 0.055, bendZ);
  }
  grassGeometry.setAttribute('position', new THREE.Float32BufferAttribute(bladeVertices, 3));
  grassGeometry.computeVertexNormals();
  const grass = new THREE.InstancedMesh(grassGeometry, new THREE.MeshStandardMaterial({ color: '#7e9652', roughness: 1, side: THREE.DoubleSide }), grassCount);
  const flowers = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.13, 0), new THREE.MeshStandardMaterial({ roughness: 1 }), 500);
  let flowerIndex = 0;
  for (let i = 0; i < grassCount; i += 1) {
    let x: number;
    let z: number;
    do { x = (random() - 0.5) * 150; z = (random() - 0.5) * 130 + 10; } while (lakeDistance(x, z) < 1.13);
    const y = terrainHeight(x, z);
    dummy.position.set(x, y, z);
    dummy.rotation.set((random() - 0.5) * 0.45, random() * 6, (random() - 0.5) * 0.3);
    dummy.scale.setScalar(0.65 + random() * 0.8);
    dummy.updateMatrix();
    grass.setMatrixAt(i, dummy.matrix);
    if (flowerIndex < 500 && x > 0) {
      dummy.position.y = y + 0.32;
      dummy.scale.set(1, 0.5, 1);
      dummy.updateMatrix();
      flowers.setMatrixAt(flowerIndex, dummy.matrix);
      flowers.setColorAt(flowerIndex, new THREE.Color(['#f4df8a', '#ead6d2', '#f6f0d5', '#b4abd0'][flowerIndex % 4]));
      flowerIndex += 1;
    }
  }
  flowers.count = flowerIndex;
  scene.add(grass, flowers);

  const wood = new THREE.MeshStandardMaterial({ color: '#9e825d', roughness: 0.9 });
  const darkWood = new THREE.MeshStandardMaterial({ color: '#65523d', roughness: 1 });
  const box = (size: [number, number, number], position: [number, number, number], material: THREE.Material = wood, parent: THREE.Object3D = scene) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
    mesh.position.set(...position);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  };
  for (let i = 0; i < 17; i += 1) box([2.3, 0.15, 0.39], [7.6, 0.53, 23 + i * 0.43]);
  for (const x of [6.65, 8.55]) {
    for (const z of [23.2, 26.2, 29.4]) box([0.15, 1.8, 0.15], [x, -0.05, z], darkWood);
  }
  const benchY = terrainHeight(-7, 34);
  for (const z of [33.6, 34, 34.4]) box([3, 0.12, 0.32], [-7, benchY + 0.7, z]);
  for (const x of [-8.15, -5.85]) {
    box([0.15, 0.7, 0.85], [x, benchY + 0.35, 34], darkWood);
    box([0.12, 1.3, 0.12], [x, benchY + 0.65, 34.5], darkWood);
  }
  box([3, 0.32, 0.12], [-7, benchY + 1.12, 34.5]);

  const boat = new THREE.Group();
  const hullShape = new THREE.Shape();
  hullShape.moveTo(0, -1.8);
  hullShape.bezierCurveTo(0.9, -1.3, 0.9, 1.2, 0, 1.8);
  hullShape.bezierCurveTo(-0.9, 1.2, -0.9, -1.3, 0, -1.8);
  const hull = new THREE.Mesh(new THREE.ExtrudeGeometry(hullShape, { depth: 0.35, bevelEnabled: true, bevelSize: 0.13, bevelThickness: 0.15, bevelSegments: 2, steps: 1 }), darkWood);
  hull.rotation.x = -Math.PI / 2;
  boat.add(hull);
  box([1.15, 0.12, 0.3], [0, 0.47, -0.55], wood, boat);
  box([1.15, 0.12, 0.3], [0, 0.47, 0.6], wood, boat);
  const oar = box([0.07, 0.07, 3.6], [0.8, 0.5, 0.3], wood, boat);
  oar.rotation.y = -0.65;
  boat.position.set(11, 0.1, 21);
  boat.rotation.y = 0.5;
  scene.add(boat);

  const deer = createDeer();
  deer.position.set(-18, terrainHeight(-18, 29), 29);
  deer.rotation.y = 1;
  scene.add(deer);
  const smallerDeer = deer.clone();
  smallerDeer.scale.setScalar(0.7);
  smallerDeer.position.set(-21, terrainHeight(-21, 29), 29);
  scene.add(smallerDeer);

  const birds: THREE.Group[] = [];
  const wingGeometry = new THREE.BufferGeometry();
  wingGeometry.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0.8, 0.02, 0.1, 0.25, 0, 0.3], 3));
  wingGeometry.computeVertexNormals();
  const wingMaterial = new THREE.MeshStandardMaterial({ color: '#44534a', roughness: 1, side: THREE.DoubleSide });
  for (let i = 0; i < 9; i += 1) {
    const bird = new THREE.Group();
    const left = new THREE.Mesh(wingGeometry, wingMaterial);
    const right = new THREE.Mesh(wingGeometry, wingMaterial);
    right.scale.x = -1;
    bird.add(left, right);
    birds.push(bird);
    scene.add(bird);
  }

  const clouds: THREE.Group[] = [];
  const cloudMaterial = new THREE.MeshBasicMaterial({ color: '#fffaf0', transparent: true, opacity: 0.35, depthWrite: false });
  for (let i = 0; i < 7; i += 1) {
    const cloud = new THREE.Group();
    for (let part = 0; part < 4; part += 1) {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), cloudMaterial);
      puff.scale.set(12 + random() * 10, 2 + random() * 3, 6 + random() * 8);
      puff.position.x = part * 12;
      cloud.add(puff);
    }
    cloud.position.set((random() - 0.5) * 320, 65 + random() * 30, -120 - random() * 90);
    clouds.push(cloud);
    scene.add(cloud);
  }

  const waterMaterial = lake.material as THREE.ShaderMaterial;
  return {
    scene,
    getHeight: terrainHeight,
    startPosition:
      world === 'forest'
        ? new THREE.Vector3(-45, 0, 28)
        : world === 'meadow'
        ? new THREE.Vector3(45, 0, 34)
        : new THREE.Vector3(-2, 0, 41),
    animate(time: number) {
      waterMaterial.uniforms.time.value = time;
      boat.position.y = 0.08 + Math.sin(time * 0.7) * 0.035;
      boat.rotation.z = Math.sin(time * 0.55) * 0.025;
      birds.forEach((bird, i) => {
        const angle = time * 0.055 + i * 0.65;
        bird.position.set(Math.cos(angle) * (20 + i * 2), 15 + Math.sin(time * 0.3 + i) * 1.5 + i * 0.6, Math.sin(angle) * 16 - 18);
        bird.rotation.y = -angle;
        bird.children[0].rotation.z = Math.sin(time * 4.5 + i) * 0.45;
        bird.children[1].rotation.z = -Math.sin(time * 4.5 + i) * 0.45;
      });
      clouds.forEach((cloud, i) => { cloud.position.x += Math.sin(time * 0.008 + i) * 0.001; });
      deer.rotation.y = 1 + Math.sin(time * 0.13) * 0.12;
    },
    dispose() {
      lake.dispose();
      sun.shadow.dispose();
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse(object => {
        if (object instanceof THREE.Mesh) {
          geometries.add(object.geometry);
          const list = Array.isArray(object.material) ? object.material : [object.material];
          list.forEach(material => materials.add(material));
        }
      });
      geometries.forEach(geometry => geometry.dispose());
      materials.forEach(material => material.dispose());
      scene.clear();
    },
  };
}
