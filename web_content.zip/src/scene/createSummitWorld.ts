import * as THREE from 'three';
import { Reflector } from 'three/addons/objects/Reflector.js';
import type { Settings } from '../data/worlds';

export function createSummitWorld(settings: Settings) {
  const scene = new THREE.Scene();
  const sunset = settings.timeOfDay === 'sunset';
  const noon = settings.timeOfDay === 'day';

  // Crisp, radiant panoramic mountain sky
  const horizon = new THREE.Color(sunset ? '#f59e6c' : noon ? '#92c5de' : '#d2e2f2');
  const zenith = new THREE.Color(sunset ? '#2a3458' : noon ? '#1d63aa' : '#396090');
  scene.background = horizon;
  scene.fog = new THREE.FogExp2(horizon, 0.0016); // Very long clear view across miles of valley

  const sunDirection = new THREE.Vector3(-0.45, noon ? 0.9 : sunset ? 0.16 : 0.5, -0.65).normalize();
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(700, 32, 20),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        zenith: { value: zenith },
        horizon: { value: horizon },
        sunDirection: { value: sunDirection },
        sunColor: { value: new THREE.Color(sunset ? '#ffd28a' : '#fff9e6') },
      },
      vertexShader: `
        varying vec3 vDirection;
        void main() {
          vDirection = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 zenith;
        uniform vec3 horizon;
        uniform vec3 sunDirection;
        uniform vec3 sunColor;
        varying vec3 vDirection;
        void main() {
          vec3 dir = normalize(vDirection);
          float h = pow(max(dir.y + 0.05, 0.0), 0.5);
          vec3 col = mix(horizon, zenith, h);
          float sun = max(dot(dir, sunDirection), 0.0);
          col += sunColor * pow(sun, 120.0) * 0.4;
          col += sunColor * pow(sun, 2800.0) * 2.5;
          gl_FragColor = vec4(col, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }
      `,
    })
  );
  scene.add(sky);

  // Sunlight and ambient
  scene.add(new THREE.HemisphereLight('#f2f8ff', '#41523a', noon ? 2.4 : 1.9));
  const sun = new THREE.DirectionalLight(sunset ? '#ffbe82' : '#fff3dc', 2.8);
  sun.position.copy(sunDirection).multiplyScalar(250);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -50;
  sun.shadow.camera.right = 50;
  sun.shadow.camera.top = 50;
  sun.shadow.camera.bottom = -50;
  sun.shadow.camera.far = 500;
  sun.shadow.bias = -0.001;
  scene.add(sun);

  // Height formula for the mountain summit and deep valleys below:
  // - Center cliff plateau at (0, 0), player stands at y ~ 42.
  // - In front (z in [6, 45]), the ground drops 30 meters into an enormous lush green valley bowl.
  // - A gleaming river winds through the valley floor at y = 5.
  // - Thousands of pine trees and lush vegetation fill the slopes and valley floor below.
  const getSummitHeight = (x: number, z: number): number => {
    // Summit cliff ledge where player stands and looks out
    const distFromOrigin = Math.hypot(x, z);
    if (distFromOrigin < 7) {
      // Top platform
      return 42 + Math.cos(x * 0.4) * Math.sin(z * 0.4) * 0.35;
    }

    // In front looking forward (+z), dramatic sheer vertical drop from summit ledge (y=42) down into the deep green valley floor (y=5)
    if (z > 3.5 && z < 120 && Math.abs(x) < 130) {
      const dropProgress = Math.min(1, Math.max(0, (z - 3.5) / 10));
      const valleyFloor = 5.0 + Math.sin(x * 0.06) * 2.0 + Math.cos(z * 0.05) * 1.5;
      return THREE.MathUtils.lerp(42, valleyFloor, Math.pow(dropProgress, 0.5));
    }

    // Mountain ridges flanking the sides and rear
    const sideRidge = Math.sin(x * 0.07 + z * 0.04) * 8 + Math.cos(z * 0.08) * 6;
    const radialDrop = Math.max(0, 42 - Math.pow(distFromOrigin - 7, 0.75) * 4.2);
    return Math.max(2.5, radialDrop + sideRidge * 0.4);
  };

  // 1. Terrain Mesh (High-detail mountain terrain)
  const terrainGeo = new THREE.PlaneGeometry(360, 360, 150, 150);
  terrainGeo.rotateX(-Math.PI / 2);
  const tPos = terrainGeo.attributes.position;
  const colors: number[] = [];
  const col = new THREE.Color();

  for (let i = 0; i < tPos.count; i++) {
    const x = tPos.getX(i);
    const z = tPos.getZ(i);
    const y = getSummitHeight(x, z);
    tPos.setY(i, y);

    // Natural mountain color zoning:
    if (y > 39) {
      // Rocky crag summit with patches of alpine snow/frost
      col.set('#edf2f7').multiplyScalar(0.9 + Math.sin(x * 2 + z) * 0.1);
    } else if (y > 24) {
      // Steep granite cliff walls and scree
      col.set(i % 3 === 0 ? '#586166' : '#495256').multiplyScalar(0.85 + Math.cos(x + z) * 0.15);
    } else if (y > 14) {
      // Subalpine hillside meadows and moss
      col.set('#48603e').multiplyScalar(0.9 + Math.sin(x * 0.2) * 0.1);
    } else {
      // Rich vibrant emerald valley floor far below
      col.set('#2f5225').multiplyScalar(0.92 + Math.cos(x * 0.15 + z * 0.2) * 0.1);
    }
    colors.push(col.r, col.g, col.b);
  }
  terrainGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeo.computeVertexNormals();

  const terrainMesh = new THREE.Mesh(
    terrainGeo,
    new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, flatShading: true })
  );
  terrainMesh.receiveShadow = true;
  terrainMesh.castShadow = true;
  scene.add(terrainMesh);

  // 2. Sparkling River Winding Through the Valley Floor Below (Real-time Mirror Reflector)
  // Perfectly positioned right in front of the summit cliff outlook (z between 20 and 90)
  const riverCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-150, 5.2, 32),
    new THREE.Vector3(-70, 5.2, 22),
    new THREE.Vector3(0, 5.2, 28),
    new THREE.Vector3(65, 5.2, 24),
    new THREE.Vector3(125, 5.2, 38),
    new THREE.Vector3(170, 5.2, 50),
  ]);

  const riverRibbonGeo = new THREE.PlaneGeometry(330, 26, 70, 6);
  riverRibbonGeo.rotateX(-Math.PI / 2);
  const rPos = riverRibbonGeo.attributes.position;
  for (let i = 0; i < rPos.count; i++) {
    const rx = rPos.getX(i);
    const rz = rPos.getZ(i);
    const t = (rx + 165) / 330;
    const pt = riverCurve.getPoint(Math.max(0, Math.min(1, t)));
    rPos.setZ(i, pt.z + rz);
    rPos.setY(i, 5.2);
  }
  riverRibbonGeo.computeVertexNormals();

  const riverWater = new Reflector(riverRibbonGeo, {
    textureWidth: settings.quality === 'high' ? 512 : 256,
    textureHeight: settings.quality === 'high' ? 512 : 256,
    clipBias: 0.003,
    color: 0x54bfd4,
    multisample: 0,
  });
  const origRiverRender = riverWater.onBeforeRender.bind(riverWater);
  riverWater.onBeforeRender = (renderer, ...args) => {
    const reflCam = riverWater.getReflectionCamera(args[1]);
    reflCam.matrixAutoUpdate = true;
    const sc = renderer.getScissorTest();
    const sv = new THREE.Vector4();
    const ss = new THREE.Vector4();
    renderer.getViewport(sv);
    renderer.getScissor(ss);
    renderer.setScissorTest(false);
    origRiverRender(renderer, ...args);
    renderer.setViewport(sv);
    renderer.setScissor(ss);
    renderer.setScissorTest(sc);
  };
  scene.add(riverWater);

  // 3. THOUSANDS OF PINE TREES in the Valley and Lower Slopes Below!
  // Placed right where the user looks down from the peak: in front (z > 14) and covering the valley.
  const treeCount = settings.quality === 'high' ? 1400 : 900;
  const treeTrunks = new THREE.InstancedMesh(
    new THREE.CylinderGeometry(0.18, 0.32, 1, 6),
    new THREE.MeshStandardMaterial({ color: '#3d2e20', roughness: 1 }),
    treeCount
  );
  const foliageTiers = [0, 1, 2].map(
    () =>
      new THREE.InstancedMesh(
        new THREE.ConeGeometry(1, 1, 7),
        new THREE.MeshStandardMaterial({ roughness: 0.9, flatShading: true }),
        treeCount
      )
  );

  const dummy = new THREE.Object3D();
  let placedTrees = 0;

  // Fill the valley floor and slopes directly beneath our vantage point with thousands of visible pine trees
  for (let i = 0; i < treeCount * 5 && placedTrees < treeCount; i++) {
    // Spread across the vast panoramic valley in front of our eyes (z in [9, 140])
    const x = (Math.random() - 0.5) * 240;
    const z = 9 + Math.random() * 130;
    const y = getSummitHeight(x, z);

    // Don't grow inside the middle of the river water channel
    const pt = riverCurve.getPoint(Math.max(0, Math.min(1, (x + 165) / 330)));
    const distToRiver = Math.abs(z - pt.z);
    if (distToRiver < 13) continue;

    // Trees blanket the valleys, lower slopes, and river banks below y = 30
    if (y < 32 && y > 4.5) {
      const height = 6.5 + Math.random() * 7;
      dummy.position.set(x, y + height * 0.35, z);
      dummy.scale.set(1, height * 0.7, 1);
      dummy.updateMatrix();
      treeTrunks.setMatrixAt(placedTrees, dummy.matrix);

      foliageTiers.forEach((layer, tier) => {
        dummy.position.set(x, y + height * (0.38 + tier * 0.16), z);
        const w = (1.8 - tier * 0.32) * (0.85 + Math.random() * 0.4);
        dummy.scale.set(w, height * 0.45, w);
        dummy.updateMatrix();
        layer.setMatrixAt(placedTrees, dummy.matrix);

        // Vibrant rich emerald and deep forest greens so they stand out clearly from high above!
        col.setHSL(0.33 + Math.random() * 0.04, 0.65, 0.18 + tier * 0.03 + (Math.random() * 0.05));
        layer.setColorAt(placedTrees, col);
      });
      placedTrees++;
    }
  }

  // Also add clusters of trees on side ridges
  for (let i = 0; i < treeCount && placedTrees < treeCount; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = 32 + Math.random() * 110;
    const x = Math.cos(angle) * dist;
    const z = Math.sin(angle) * dist;
    const y = getSummitHeight(x, z);
    if (y < 34 && y > 4) {
      const height = 4.5 + Math.random() * 4.5;
      dummy.position.set(x, y + height * 0.35, z);
      dummy.scale.set(1, height * 0.7, 1);
      dummy.updateMatrix();
      treeTrunks.setMatrixAt(placedTrees, dummy.matrix);

      foliageTiers.forEach((layer, tier) => {
        dummy.position.set(x, y + height * (0.38 + tier * 0.16), z);
        const w = (1.5 - tier * 0.28) * (0.8 + Math.random() * 0.3);
        dummy.scale.set(w, height * 0.42, w);
        dummy.updateMatrix();
        layer.setMatrixAt(placedTrees, dummy.matrix);
        col.setHSL(0.31 + Math.random() * 0.05, 0.5, 0.14 + tier * 0.03);
        layer.setColorAt(placedTrees, col);
      });
      placedTrees++;
    }
  }

  treeTrunks.count = placedTrees;
  foliageTiers.forEach(tier => {
    tier.count = placedTrees;
    tier.castShadow = true;
    tier.receiveShadow = true;
    scene.add(tier);
  });
  treeTrunks.castShadow = true;
  scene.add(treeTrunks);

  // 4. Distant 360° Alpine Mountains in the Background
  const mountainCount = 18;
  for (let i = 0; i < mountainCount; i++) {
    const angle = (i / mountainCount) * Math.PI * 2;
    const dist = 160 + (i % 3) * 35;
    const peakHeight = 55 + (i % 4) * 25;
    const peakBase = 38 + (i % 3) * 14;
    const mGeo = new THREE.ConeGeometry(peakBase, peakHeight, 12, 8);
    const mPos = mGeo.attributes.position;
    const mColors: number[] = [];
    for (let k = 0; k < mPos.count; k++) {
      const my = mPos.getY(k) + peakHeight / 2;
      const mx = mPos.getX(k);
      const mz = mPos.getZ(k);
      mPos.setX(k, mx + Math.sin(my * 0.2 + i) * 3.0);
      mPos.setZ(k, mz + Math.cos(my * 0.2 + i) * 3.0);
      const isSnow = my > peakHeight * 0.65;
      col.set(isSnow ? '#edf2f7' : '#455359');
      mColors.push(col.r, col.g, col.b);
    }
    mGeo.setAttribute('color', new THREE.Float32BufferAttribute(mColors, 3));
    mGeo.computeVertexNormals();
    const mountainMesh = new THREE.Mesh(
      mGeo,
      new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, flatShading: true })
    );
    mountainMesh.position.set(
      Math.cos(angle) * dist,
      peakHeight / 2 - 5,
      Math.sin(angle) * dist
    );
    scene.add(mountainMesh);
  }

  // 5. Summit Platform Props: Lookout edge safety ropes, flag/marker, & panoramic resting bench
  const woodMat = new THREE.MeshStandardMaterial({ color: '#54412e', roughness: 0.9 });
  const stoneMat = new THREE.MeshStandardMaterial({ color: '#737a7f', roughness: 0.95, flatShading: true });

  // Open panoramic cliff viewpoint overlooking the endless green valley and winding river (no obstruction)
  const railingGroup = new THREE.Group();
  for (let rx = -5; rx <= 5; rx += 2.5) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.65, 6), woodMat);
    post.position.set(rx, 42.3, 4.8);
    railingGroup.add(post);
  }
  const topRail = new THREE.Mesh(new THREE.BoxGeometry(11.2, 0.07, 0.07), woodMat);
  topRail.position.set(0, 42.6, 4.8);
  railingGroup.add(topRail);
  scene.add(railingGroup);

  // Summit Stone Cairn
  const cairnGroup = new THREE.Group();
  for (let layer = 0; layer < 6; layer++) {
    const count = 7 - layer;
    const r = 1.1 - layer * 0.18;
    for (let s = 0; s < count; s++) {
      const a = (s / count) * Math.PI * 2 + layer * 0.3;
      const stone = new THREE.Mesh(new THREE.DodecahedronGeometry(0.22, 0), stoneMat);
      stone.position.set(Math.cos(a) * r, layer * 0.25, Math.sin(a) * r);
      stone.rotation.set(Math.random(), Math.random(), Math.random());
      stone.scale.set(1.2, 0.8, 1);
      cairnGroup.add(stone);
    }
  }
  cairnGroup.position.set(3.2, 42.1, -1.8);
  scene.add(cairnGroup);

  // Summit Trail Signpost
  const signpost = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 2.0, 6), woodMat);
  signpost.position.set(-3.2, 42.8, -1.5);
  scene.add(signpost);

  const signBoard = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.28, 0.08), woodMat);
  signBoard.position.set(-3.2, 43.6, -1.5);
  signBoard.rotation.y = 0.25;
  scene.add(signBoard);

  // Summit Panoramic Lookout Bench
  const bench = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.12, 0.45), woodMat);
  bench.position.set(0, 42.45, -2.5);
  scene.add(bench);
  for (const bx of [-1.0, 1.0]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.45, 0.4), woodMat);
    leg.position.set(bx, 42.22, -2.5);
    scene.add(leg);
  }

  // 6. Mountain Eagles Gliding High Above the Summit
  const eagleGroup = new THREE.Group();
  const wingGeo = new THREE.BufferGeometry();
  wingGeo.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 1.5, 0.04, 0.2, 0.4, 0, 0.55], 3));
  wingGeo.computeVertexNormals();
  const eagleMat = new THREE.MeshStandardMaterial({ color: '#251c14', roughness: 0.9, side: THREE.DoubleSide });
  const eagles: THREE.Group[] = [];
  for (let i = 0; i < 4; i++) {
    const eagle = new THREE.Group();
    const leftWing = new THREE.Mesh(wingGeo, eagleMat);
    const rightWing = new THREE.Mesh(wingGeo, eagleMat);
    rightWing.scale.x = -1;
    eagle.add(leftWing, rightWing);
    eagles.push(eagle);
    eagleGroup.add(eagle);
  }
  scene.add(eagleGroup);

  // 7. Light Floating Fluffy Clouds in the Distance
  const cloudMat = new THREE.MeshBasicMaterial({
    color: '#ffffff',
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  const puffGeo = new THREE.SphereGeometry(1, 8, 6);
  const cloudGroup = new THREE.Group();
  for (let i = 0; i < 16; i++) {
    const puff = new THREE.Mesh(puffGeo, cloudMat);
    const angle = Math.random() * Math.PI * 2;
    const dist = 90 + Math.random() * 100;
    puff.scale.set(24 + Math.random() * 20, 3 + Math.random() * 2.5, 20 + Math.random() * 18);
    puff.position.set(Math.cos(angle) * dist, 18 + Math.sin(i) * 3, Math.sin(angle) * dist);
    cloudGroup.add(puff);
  }
  scene.add(cloudGroup);

  return {
    scene,
    // Start on summit platform facing directly outward toward the valley (+z)
    startPosition: new THREE.Vector3(0, 0, 0),
    getHeight: getSummitHeight,
    animate(time: number) {
      cloudGroup.rotation.y = time * 0.005;

      // Soaring eagles circling majestically overhead
      eagles.forEach((eagle, i) => {
        const a = time * 0.25 + i * 1.57;
        const radius = 24 + i * 8;
        eagle.position.set(
          Math.cos(a) * radius,
          52 + Math.sin(time * 0.5 + i) * 2.5,
          Math.sin(a) * radius
        );
        eagle.rotation.y = -a + Math.PI / 2;
        eagle.children[0].rotation.z = Math.sin(time * 1.2 + i) * 0.12;
        eagle.children[1].rotation.z = -Math.sin(time * 1.2 + i) * 0.12;
      });
    },
    dispose() {
      sun.shadow.dispose();
      riverWater.dispose();
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse(obj => {
        if (obj instanceof THREE.Mesh) {
          geometries.add(obj.geometry);
          const list = Array.isArray(obj.material) ? obj.material : [obj.material];
          list.forEach(m => materials.add(m));
        }
      });
      geometries.forEach(g => g.dispose());
      materials.forEach(m => m.dispose());
      scene.clear();
    },
  };
}
