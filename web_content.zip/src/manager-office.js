import { getLunarDate } from './lunar-calendar.js';
export const STAFF_ROLES = Object.freeze([
  { id: 'assistant', label: 'Adjoint', task: 'Conseils tactiques et suivi du vestiaire' },
  { id: 'coach', label: 'Entraîneur', task: 'Préparation et progression des damistes' },
  { id: 'scout', label: 'Recruteur', task: 'Observation des talents et rapports' },
  { id: 'physio', label: 'Kiné', task: 'Condition physique et récupération' },
  { id: 'youth', label: 'Responsable des jeunes', task: 'Suivi du centre de formation' }
]);
export const BOARD_DOMAINS = Object.freeze(['Matchs', 'Transferts', 'Harmonie', 'Supporters', 'Finances', 'Jeunes']);
export const DELEGATION_TASKS = Object.freeze([
  { id: 'match-preparation', label: 'Préparation des matchs', role: 'assistant' },
  { id: 'loan-management', label: 'Gestion des prêts', role: 'scout' },
  { id: 'youth-advice', label: 'Conseils aux jeunes', role: 'youth' }
]);
const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, Number(n) || 0));

export function ensureClubOffice(state) {
  if (!state?.career?.manager || !state.userClubId) return null;
  const club = state?.divisions?.flatMap(d => d.clubs).find(c => c.id === state.userClubId);
  if (!club) return null;
  club.office ??= {};
  const office = club.office;
  office.finance ??= {
    cash: Number(club.budget) || 0,
    transferBudget: Math.round((Number(club.budget) || 0) * 0.2),
    wageBudget: Math.round((Number(club.budget) || 0) * 0.15),
    dailyIncome: 0, dailyCosts: 0, ledger: []
  };
  office.facilities ??= { training: 1, youth: 1, arenaCapacity: 5000, averageAttendance: 0, arenaLevel: 1 };
  office.staff ??= STAFF_ROLES.map(role => ({ ...role, name: `${role.label} du club`, profile: 'À évaluer', rating: 50 }));
  office.delegation ??= Object.fromEntries(DELEGATION_TASKS.map(task => [task.id, false]));
  office.board ??= { confidence: Number(state.management?.relations?.boardConfidence ?? 50), domains: Object.fromEntries(BOARD_DOMAINS.map(domain => [domain, 50])), objectives: [
    { id: 'league', label: 'Obtenir des résultats réguliers en championnat', target: 'Saison en cours', status: 'En cours' },
    { id: 'finance', label: 'Maintenir les finances sous contrôle', target: 'Toute la saison', status: 'En cours' },
    { id: 'harmony', label: 'Préserver l’harmonie du vestiaire', target: 'Toute la saison', status: 'En cours' }
  ], requests: [] };
  office.lastProcessedDay ??= Number(state.calendar?.currentDay || state.day || 1);
  return { club, office };
}

export function updateDelegation(state, taskId, delegated) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club n’est actuellement dirigé.');
  if (!DELEGATION_TASKS.some(task => task.id === taskId)) throw new Error('Tâche de délégation inconnue.');
  found.office.delegation[taskId] = Boolean(delegated);
  return found.office.delegation[taskId];
}

export function updateFacility(state, facility, level) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club n’est actuellement dirigé.');
  if (!['training', 'youth', 'arenaLevel'].includes(facility)) throw new Error('Installation inconnue.');
  const value = Math.max(1, Math.min(10, Math.floor(Number(level))));
  found.office.facilities[facility] = value;
  return value;
}

export function recordDailyClubFinance(state, day) {
  const found = ensureClubOffice(state);
  if (!found) return null;
  const finance = found.office.finance;
  const income = Math.max(0, Number(finance.dailyIncome) || 0);
  const costs = Math.max(0, Number(finance.dailyCosts) || 0);
  const net = income - costs;
  finance.cash = Math.max(0, Number(finance.cash || 0) + net);
  found.club.budget = finance.cash;
  finance.ledger ??= [];
  finance.ledger.unshift({ day, income, costs, net, balance: finance.cash });
  finance.ledger = finance.ledger.slice(0, 60);
  finance.status = finance.cash < 100000 ? 'Pauvre' : finance.cash < 1000000 ? 'Normal' : 'Riche';
  return finance.ledger[0];
}

export function advanceManagerOneDay(state) {
  if (!state?.career?.manager) throw new Error('Crée d’abord ton profil de manager.');
  const today = Number(state.calendar?.currentDay || state.day || 1);
  const nextDay = today + 1;
  state.calendar ??= {};
  state.calendar.currentDay = nextDay;
  state.calendar.currentDate = { season: state.season, seasonDay: nextDay, ...getLunarDate(nextDay) };
  state.day = nextDay;
  const finance = recordDailyClubFinance(state, nextDay);
  const found = ensureClubOffice(state);
  if (found) found.office.lastProcessedDay = nextDay;
  return { day: nextDay, finance, weekday: state.calendar.currentDate.weekday };
}

export function updateBoardDomain(state, domain, scoreDelta, reason = 'Décision du manager') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  if (!BOARD_DOMAINS.includes(domain)) throw new Error('Domaine du conseil inconnu.');
  const board = found.office.board;
  board.domains[domain] = clamp(board.domains[domain] + Number(scoreDelta), 0, 100);
  const values = Object.values(board.domains);
  board.confidence = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  if (state.management?.relations) state.management.relations.boardConfidence = board.confidence;
  board.history ??= [];
  board.history.unshift({ day: state.calendar?.currentDay || state.day || 1, domain, delta: Number(scoreDelta), reason, confidence: board.confidence });
  return board.confidence;
}

export function submitBoardRequest(state, type, details = '') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  const allowed = ['transfer-budget', 'wage-budget', 'training-facility', 'youth-facility', 'arena-expansion', 'rebuild-time', 'new-sponsor', 'resignation'];
  if (!allowed.includes(type)) throw new Error('Demande au conseil inconnue.');
  const request = { id: `board-request-${state.season}-${state.calendar?.currentDay || state.day || 1}-${found.office.board.requests.length + 1}`, type, details: String(details).slice(0, 240), status: 'submitted', day: state.calendar?.currentDay || state.day || 1 };
  found.office.board.requests.unshift(request);
  return request;
}

export function validateClubOffice(state) {
  const found = ensureClubOffice(state);
  if (!found) return true;
  const { office } = found;
  if (!Number.isFinite(office.finance.cash) || office.finance.cash < 0) throw new Error('Solde financier du club invalide.');
  if (office.staff.length !== STAFF_ROLES.length) throw new Error('Le registre du staff est incomplet.');
  for (const task of DELEGATION_TASKS) if (typeof office.delegation[task.id] !== 'boolean') throw new Error('Préférence de délégation invalide.');
  return true;
}

export function updateStaffMember(state, staffId, changes = {}) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  const member = found.office.staff.find(item => item.id === staffId || item.role === staffId);
  if (!member) throw new Error('Membre du staff introuvable.');
  if (changes.name !== undefined) {
    const name = String(changes.name).trim();
    if (!name || name.length > 64) throw new Error('Le nom du membre du staff doit contenir entre 1 et 64 caractères.');
    member.name = name;
  }
  if (changes.profile !== undefined) {
    const profile = String(changes.profile).trim();
    if (!profile || profile.length > 120) throw new Error('Le profil du staff doit contenir entre 1 et 120 caractères.');
    member.profile = profile;
  }
  if (changes.rating !== undefined) {
    const rating = Number(changes.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 100) throw new Error('La compétence du staff doit être comprise entre 1 et 100.');
    member.rating = rating;
  }
  if (changes.specialty !== undefined) member.specialty = String(changes.specialty).trim().slice(0, 80);
  if (changes.contractSeasons !== undefined) {
    const seasons = Number(changes.contractSeasons);
    if (!Number.isInteger(seasons) || seasons < 1 || seasons > 5) throw new Error('La durée du contrat du staff doit être comprise entre 1 et 5 saisons.');
    member.contractSeasons = seasons;
  }
  return structuredClone(member);
}

export function resolveBoardRequest(state, requestId, decision, details = '') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  if (!['approved', 'rejected'].includes(decision)) throw new Error('Décision du conseil invalide.');
  const request = found.office.board.requests.find(item => item.id === requestId);
  if (!request) throw new Error('Demande au conseil introuvable.');
  if (request.status !== 'submitted') throw new Error('Cette demande a déjà reçu une décision.');
  request.status = decision;
  request.decisionDay = Number(state.calendar?.currentDay || state.day || 1);
  request.decisionDetails = String(details).trim().slice(0, 240);
  request.history ??= [];
  request.history.push({ status: decision, day: request.decisionDay, details: request.decisionDetails });
  found.office.board.history ??= [];
  found.office.board.history.unshift({ type: 'request-decision', requestId, decision, day: request.decisionDay, details: request.decisionDetails });
  updateBoardDomain(state, 'Finances', decision === 'approved' ? 2 : -1, decision === 'approved' ? 'Demande validée par le conseil' : 'Demande refusée par le conseil');
  return structuredClone(request);
}


export function processBoardRequests(state) {
  const found = ensureClubOffice(state);
  if (!found) return [];
  const board = found.office.board;
  const confidence = Number(board.confidence || 0);
  const processed = [];
  for (const request of board.requests) {
    if (request.status !== 'submitted') continue;
    const threshold = request.type === 'rebuild-time' ? 45 : request.type === 'resignation' ? 0 : 50;
    const decision = confidence >= threshold ? 'approved' : 'rejected';
    processed.push(resolveBoardRequest(state, request.id, decision, decision === 'approved' ? 'Accord du conseil enregistré' : 'La confiance du conseil est insuffisante'));
  }
  const resignation = processed.find(item => item.type === 'resignation' && item.status === 'approved');
  if (resignation) {
    const manager = state.career?.manager;
    const club = found.club;
    if (manager) {
      manager.clubId = null;
      manager.mode = 'unemployed';
      state.career.mode = 'unemployed';
      state.career.history ??= [];
      state.career.history.unshift({ type: 'resignation', clubId: club.id, clubName: club.name, season: state.season, day: resignation.decisionDay });
    }
    club.manager = null;
    state.userClubId = null;
  }
  return processed;
}
