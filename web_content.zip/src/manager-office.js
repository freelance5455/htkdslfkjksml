import { getLunarDate } from './lunar-calendar.js';
export const STAFF_ROLES = Object.freeze([
  { id: 'assistant', label: 'Adjoint', task: 'Conseils tactiques et suivi du vestiaire' },
  { id: 'coach', label: 'Entraîneur', task: 'Préparation et progression des damistes' },
  { id: 'scout', label: 'Recruteur', task: 'Observation des talents et rapports' },
  { id: 'physio', label: 'Kiné', task: 'Condition physique et récupération' },
  { id: 'youth', label: 'Responsable des jeunes', task: 'Suivi du centre de formation' }
]);
export const BOARD_DOMAINS = Object.freeze(['Matchs', 'Transferts', 'Harmonie', 'Supporters', 'Finances', 'Jeunes']);
export const DELEGATION_TASKS = Object.freeze([
  { id: 'match-preparation', label: 'Préparation des matchs', role: 'assistant' },
  { id: 'loan-management', label: 'Gestion des prêts', role: 'scout' },
  { id: 'youth-advice', label: 'Conseils aux jeunes', role: 'youth' }
]);
const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, Number(n) || 0));

export function ensureClubOffice(state) {
  if (!state?.career?.manager || !state.userClubId) return null;
  const club = state?.divisions?.flatMap(d => d.clubs).find(c => c.id === state.userClubId);
  if (!club) return null;
  club.office ??= {};
  const office = club.office;
  office.finance ??= {
    cash: Number(club.budget) || 0,
    transferBudget: Math.round((Number(club.budget) || 0) * 0.2),
    wageBudget: Math.round((Number(club.budget) || 0) * 0.15),
    dailyIncome: 0, dailyCosts: 0, ledger: []
  };
  // Le budget du club est la source de vérité commune à tous les modules.
  office.finance.cash = Math.max(0, Number(club.budget) || 0);
  office.finance.ledger ??= [];
  office.finance.arrears ??= [];
  office.finance.nextArrearId ??= 1;
  office.finance.dailyOperatingCosts ??= 0;
  office.finance.ticketPrice ??= 0;
  office.finance.broadcastPerMatch ??= 0;
  office.finance.winBonus ??= 0;
  office.finance.drawBonus ??= 0;
  office.finance.transferBudget ??= Math.round(office.finance.cash * 0.2);
  office.finance.wageBudget ??= Math.round(office.finance.cash * 0.15);
  office.facilities ??= { training: 1, youth: 1, arenaCapacity: 5000, averageAttendance: 0, arenaLevel: 1 };
  office.staff ??= STAFF_ROLES.map(role => ({ ...role, name: `${role.label} du club`, profile: 'À évaluer', rating: 50 }));
  office.delegation ??= Object.fromEntries(DELEGATION_TASKS.map(task => [task.id, false]));
  office.board ??= { confidence: Number(state.management?.relations?.boardConfidence ?? 50), domains: Object.fromEntries(BOARD_DOMAINS.map(domain => [domain, 50])), objectives: [
    { id: 'league', label: 'Obtenir des résultats réguliers en championnat', target: 'Saison en cours', status: 'En cours' },
    { id: 'finance', label: 'Maintenir les finances sous contrôle', target: 'Toute la saison', status: 'En cours' },
    { id: 'harmony', label: 'Préserver l’harmonie du vestiaire', target: 'Toute la saison', status: 'En cours' }
  ], requests: [] };
  office.lastProcessedDay ??= Number(state.calendar?.currentDay || state.day || 1);
  return { club, office };
}

export function updateDelegation(state, taskId, delegated) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club n’est actuellement dirigé.');
  if (!DELEGATION_TASKS.some(task => task.id === taskId)) throw new Error('Tâche de délégation inconnue.');
  found.office.delegation[taskId] = Boolean(delegated);
  return found.office.delegation[taskId];
}

export function updateFacility(state, facility, level) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club n’est actuellement dirigé.');
  if (!['training', 'youth', 'arenaLevel'].includes(facility)) throw new Error('Installation inconnue.');
  const value = Math.max(1, Math.min(10, Math.floor(Number(level))));
  found.office.facilities[facility] = value;
  return value;
}

export function recordClubTransaction(state, club, { income = 0, costs = 0, reason = 'Opération du club', reference = null, day = null, trackArrears = true } = {}) {
  if (!club) throw new Error('Club introuvable pour cette opération financière.');
  const revenue = Math.max(0, Number(income) || 0);
  const requestedCosts = Math.max(0, Number(costs) || 0);
  const available = Math.max(0, Number(club.budget) || 0) + revenue;
  const paidCosts = Math.min(available, requestedCosts);
  club.budget = Math.max(0, available - paidCosts);
  let finance = club.office?.finance;
  if (club.id === state?.userClubId && state?.career?.manager) finance = ensureClubOffice(state)?.office.finance;
  if (finance) {
    finance.cash = club.budget;
    finance.ledger ??= [];
    const transaction = { day: Number(day ?? state?.calendar?.currentDay ?? state?.day ?? 1), income: revenue, costs: paidCosts, requestedCosts, net: revenue - paidCosts, balance: club.budget, reason, ...(reference ? { reference } : {}), ...(paidCosts < requestedCosts ? { shortfall: requestedCosts - paidCosts } : {}) };
    finance.ledger.unshift(transaction);
    finance.ledger = finance.ledger.slice(0, 60);
    if (trackArrears && transaction.shortfall > 0) {
      finance.arrears ??= [];
      finance.nextArrearId ??= 1;
      finance.arrears.push({ id: `arrear-${finance.nextArrearId++}`, amount: transaction.shortfall, originalAmount: transaction.shortfall, reason, reference, createdDay: transaction.day, status: 'unpaid' });
    }
    finance.status = finance.cash < 100000 ? 'Pauvre' : finance.cash < 1000000 ? 'Normal' : 'Riche';
    return transaction;
  }
  return { income: revenue, costs: paidCosts, requestedCosts, net: revenue - paidCosts, balance: club.budget, ...(paidCosts < requestedCosts ? { shortfall: requestedCosts - paidCosts } : {}) };
}

/** Règle les dettes enregistrées dès que la trésorerie le permet, dans l’ordre chronologique. */
export function settleClubArrears(state, day = null) {
  const found = ensureClubOffice(state);
  if (!found) return { paid: 0, remaining: 0, entries: [] };
  const finance = found.office.finance;
  finance.arrears ??= [];
  let paid = 0;
  const entries = [];
  for (const arrear of finance.arrears) {
    const due = Math.max(0, Number(arrear.amount) || 0);
    if (!due || found.club.budget <= 0) continue;
    const payment = Math.min(due, Math.max(0, Number(found.club.budget) || 0));
    if (!payment) continue;
    const transaction = recordClubTransaction(state, found.club, {
      costs: payment,
      reason: `Règlement d’impayé · ${arrear.reason}`,
      reference: arrear.id,
      day,
      trackArrears: false
    });
    arrear.amount = Math.max(0, due - transaction.costs);
    arrear.status = arrear.amount === 0 ? 'paid' : 'partially-paid';
    arrear.lastPaymentDay = Number(day ?? state.calendar?.currentDay ?? state.day ?? 1);
    paid += transaction.costs;
    entries.push(transaction);
  }
  finance.arrears = finance.arrears.filter(item => Number(item.amount) > 0);
  return { paid, remaining: finance.arrears.reduce((sum, item) => sum + Math.max(0, Number(item.amount) || 0), 0), entries };
}

export function recordDailyClubFinance(state, day) {
  const found = ensureClubOffice(state);
  if (!found) return null;
  const finance = found.office.finance;
  const plannedIncome = Math.max(0, Number(finance.dailyIncome) || 0);
  const plannedCosts = Math.max(0, Number(finance.dailyCosts) || 0);
  const operatingCosts = Math.max(0, Number(finance.dailyOperatingCosts) || 0);
  const results = [];
  const operatingDayKey = `${Number(state.season || 1)}:${Number(day)}`;
  if (found.office.lastDailyFinanceKey !== operatingDayKey) {
    if (plannedIncome || plannedCosts) results.push(recordClubTransaction(state, found.club, { income: plannedIncome, costs: plannedCosts, reason: 'Prévisions quotidiennes du club', day }));
    found.office.lastDailyFinanceKey = operatingDayKey;
  }
  if (operatingCosts && found.office.lastOperatingCostDay !== operatingDayKey) {
    results.push(recordClubTransaction(state, found.club, { costs: operatingCosts, reason: 'Frais quotidiens d’exploitation des installations', day }));
    found.office.lastOperatingCostDay = operatingDayKey;
  }
  const arrears = settleClubArrears(state, day);
  if (arrears.paid) results.push(...arrears.entries);
  return results.length ? results : null;
}

/** Comptabilise une seule fois les recettes et primes du match du club dirigé. */
export function recordManagedMatchFinance(state, fixture, homeScore, awayScore, matchDetails = {}) {
  const found = ensureClubOffice(state);
  if (!found || !fixture || fixture.financialSettlement?.clubId === found.club.id) return null;
  const { club, office } = found;
  const isHome = fixture.home === club.id;
  const isAway = fixture.away === club.id;
  if (!isHome && !isAway) return null;
  const finance = office.finance;
  const attendance = isHome ? Number(matchDetails.attendance?.home ?? matchDetails.attendance ?? 0) : Number(matchDetails.attendance?.away ?? 0);
  const validAttendance = Number.isFinite(attendance) ? Math.max(0, Math.min(Number(office.facilities.arenaCapacity) || 0, attendance)) : 0;
  const ticketIncome = isHome ? validAttendance * Math.max(0, Number(finance.ticketPrice) || 0) : 0;
  const broadcastIncome = Math.max(0, Number(finance.broadcastPerMatch) || 0);
  const goalsFor = isHome ? homeScore : awayScore;
  const goalsAgainst = isHome ? awayScore : homeScore;
  const sportingBonus = goalsFor > goalsAgainst ? Math.max(0, Number(finance.winBonus) || 0) : goalsFor === goalsAgainst ? Math.max(0, Number(finance.drawBonus) || 0) : 0;
  const totalIncome = ticketIncome + broadcastIncome + sportingBonus;
  const entries = [];
  if (ticketIncome) entries.push(recordClubTransaction(state, club, { income: ticketIncome, reason: 'Recette de billetterie · rencontre à domicile', reference: fixture.id }));
  if (broadcastIncome) entries.push(recordClubTransaction(state, club, { income: broadcastIncome, reason: 'Droits de diffusion · rencontre', reference: fixture.id }));
  if (sportingBonus) entries.push(recordClubTransaction(state, club, { income: sportingBonus, reason: goalsFor > goalsAgainst ? 'Prime sportive · victoire' : 'Prime sportive · match nul', reference: fixture.id }));
  fixture.financialSettlement = { clubId: club.id, attendance: validAttendance, ticketIncome, broadcastIncome, sportingBonus, totalIncome, day: Number(state.calendar?.currentDay || state.day || 1) };
  return { ticketIncome, broadcastIncome, sportingBonus, totalIncome, entries };
}


/** Les salaires des damistes sont exprimés par saison et provisionnés sur les 153 jours de carrière. */
export function processDailyDamistePayroll(state) {
  const found = ensureClubOffice(state);
  if (!found) return { processed: false, paid: 0, shortfall: 0 };
  const { club, office } = found;
  const day = Number(state.calendar?.currentDay || state.day || 1);
  const payrollDayKey = `${Number(state.season || 1)}:${day}`;
  if (office.lastPlayerPayrollDay === payrollDayKey) return { processed: false, paid: 0, shortfall: 0, reason: 'already-processed' };
  const active = (club.damistes || []).filter(player => player.contract?.status === 'active');
  const due = active.reduce((sum, player) => sum + Math.max(0, Number(player.contract.wage) || 0) / 153, 0);
  const transaction = due > 0 ? recordClubTransaction(state, club, { costs: due, reason: 'Provision quotidienne des salaires des damistes', day }) : { costs: 0, shortfall: 0 };
  office.lastPlayerPayrollDay = payrollDayKey;
  for (const player of active) player.contract.paymentStatus = transaction.shortfall ? 'partially-paid' : 'paid';
  if (transaction.shortfall) updateBoardDomain(state, 'Finances', -2, 'Retard de paiement des damistes');
  return { processed: true, paid: transaction.costs, shortfall: transaction.shortfall || 0, players: active.map(player => player.id), transaction };
}

export function advanceManagerOneDay(state) {
  if (!state?.career?.manager) throw new Error('Crée d’abord ton profil de manager.');
  const today = Number(state.calendar?.currentDay || state.day || 1);
  const nextDay = today + 1;
  state.calendar ??= {};
  state.calendar.currentDay = nextDay;
  state.calendar.currentDate = { season: state.season, seasonDay: nextDay, ...getLunarDate(nextDay) };
  state.day = nextDay;
  const finance = recordDailyClubFinance(state, nextDay);
  const found = ensureClubOffice(state);
  if (found) found.office.lastProcessedDay = nextDay;
  return { day: nextDay, finance, weekday: state.calendar.currentDate.weekday };
}

export function updateBoardDomain(state, domain, scoreDelta, reason = 'Décision du manager') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  if (!BOARD_DOMAINS.includes(domain)) throw new Error('Domaine du conseil inconnu.');
  const board = found.office.board;
  board.domains[domain] = clamp(board.domains[domain] + Number(scoreDelta), 0, 100);
  const values = Object.values(board.domains);
  board.confidence = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  if (state.management?.relations) state.management.relations.boardConfidence = board.confidence;
  board.history ??= [];
  board.history.unshift({ day: state.calendar?.currentDay || state.day || 1, domain, delta: Number(scoreDelta), reason, confidence: board.confidence });
  return board.confidence;
}

export function submitBoardRequest(state, type, details = '') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  const allowed = ['transfer-budget', 'wage-budget', 'training-facility', 'youth-facility', 'arena-expansion', 'rebuild-time', 'new-sponsor', 'resignation'];
  if (!allowed.includes(type)) throw new Error('Demande au conseil inconnue.');
  const request = { id: `board-request-${state.season}-${state.calendar?.currentDay || state.day || 1}-${found.office.board.requests.length + 1}`, type, details: String(details).slice(0, 240), status: 'submitted', day: state.calendar?.currentDay || state.day || 1 };
  found.office.board.requests.unshift(request);
  return request;
}

export function validateClubOffice(state) {
  const found = ensureClubOffice(state);
  if (!found) return true;
  const { office } = found;
  if (!Number.isFinite(office.finance.cash) || office.finance.cash < 0) throw new Error('Solde financier du club invalide.');
  if (office.staff.length !== STAFF_ROLES.length) throw new Error('Le registre du staff est incomplet.');
  for (const task of DELEGATION_TASKS) if (typeof office.delegation[task.id] !== 'boolean') throw new Error('Préférence de délégation invalide.');
  return true;
}

export function updateStaffMember(state, staffId, changes = {}) {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  const member = found.office.staff.find(item => item.id === staffId || item.role === staffId);
  if (!member) throw new Error('Membre du staff introuvable.');
  if (changes.name !== undefined) {
    const name = String(changes.name).trim();
    if (!name || name.length > 64) throw new Error('Le nom du membre du staff doit contenir entre 1 et 64 caractères.');
    member.name = name;
  }
  if (changes.profile !== undefined) {
    const profile = String(changes.profile).trim();
    if (!profile || profile.length > 120) throw new Error('Le profil du staff doit contenir entre 1 et 120 caractères.');
    member.profile = profile;
  }
  if (changes.rating !== undefined) {
    const rating = Number(changes.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 100) throw new Error('La compétence du staff doit être comprise entre 1 et 100.');
    member.rating = rating;
  }
  if (changes.specialty !== undefined) member.specialty = String(changes.specialty).trim().slice(0, 80);
  if (changes.contractSeasons !== undefined) {
    const seasons = Number(changes.contractSeasons);
    if (!Number.isInteger(seasons) || seasons < 1 || seasons > 5) throw new Error('La durée du contrat du staff doit être comprise entre 1 et 5 saisons.');
    member.contractSeasons = seasons;
  }
  return structuredClone(member);
}

export function resolveBoardRequest(state, requestId, decision, details = '') {
  const found = ensureClubOffice(state);
  if (!found) throw new Error('Aucun club dirigé.');
  if (!['approved', 'rejected'].includes(decision)) throw new Error('Décision du conseil invalide.');
  const request = found.office.board.requests.find(item => item.id === requestId);
  if (!request) throw new Error('Demande au conseil introuvable.');
  if (request.status !== 'submitted') throw new Error('Cette demande a déjà reçu une décision.');
  request.status = decision;
  request.decisionDay = Number(state.calendar?.currentDay || state.day || 1);
  request.decisionDetails = String(details).trim().slice(0, 240);
  request.history ??= [];
  request.history.push({ status: decision, day: request.decisionDay, details: request.decisionDetails });
  found.office.board.history ??= [];
  found.office.board.history.unshift({ type: 'request-decision', requestId, decision, day: request.decisionDay, details: request.decisionDetails });
  updateBoardDomain(state, 'Finances', decision === 'approved' ? 2 : -1, decision === 'approved' ? 'Demande validée par le conseil' : 'Demande refusée par le conseil');
  return structuredClone(request);
}


export function processBoardRequests(state) {
  const found = ensureClubOffice(state);
  if (!found) return [];
  const board = found.office.board;
  const confidence = Number(board.confidence || 0);
  const processed = [];
  for (const request of board.requests) {
    if (request.status !== 'submitted') continue;
    const threshold = request.type === 'rebuild-time' ? 45 : request.type === 'resignation' ? 0 : 50;
    const decision = confidence >= threshold ? 'approved' : 'rejected';
    processed.push(resolveBoardRequest(state, request.id, decision, decision === 'approved' ? 'Accord du conseil enregistré' : 'La confiance du conseil est insuffisante'));
  }
  const resignation = processed.find(item => item.type === 'resignation' && item.status === 'approved');
  if (resignation) {
    const manager = state.career?.manager;
    const club = found.club;
    if (manager) {
      manager.clubId = null;
      manager.mode = 'unemployed';
      state.career.mode = 'unemployed';
      state.career.history ??= [];
      state.career.history.unshift({ type: 'resignation', clubId: club.id, clubName: club.name, season: state.season, day: resignation.decisionDay });
    }
    club.manager = null;
    state.userClubId = null;
  }
  return processed;
}
