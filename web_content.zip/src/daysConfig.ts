/**
 * جدول الأيام الأسبوعي الافتراضي لـ Gym Tracker
 */
export interface DayConfig {
  id: number;
  title: string;
  description: string;
}

export const DAYS_PLAN: DayConfig[] = [
  {
    id: 1,
    title: 'كتف / Pull',
    description: 'تمارين الأكتاف',
  },
  {
    id: 2,
    title: 'برا / Biceps',
    description: 'تمارين الذراعين',
  },
  {
    id: 3,
    title: 'الظهر / Dos',
    description: 'تمارين عضلات الظهر',
  },
  {
    id: 4,
    title: 'راحة / Rest',
    description: 'استشفاء وراحة العضلات',
  },
  {
    id: 5,
    title: 'الأرجل / Jambes',
    description: 'الفخذ + السمانة + الأرداف',
  },
  {
    id: 6,
    title: 'الصدر / Triceps',
    description: 'الصدر + خلف الذراع',
  },
  {
    id: 7,
    title: 'راحة / Rest',
    description: 'استشفاء وراحة العضلات',
  },
];
