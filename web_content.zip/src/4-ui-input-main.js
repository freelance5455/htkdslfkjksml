
/* =====================================================================
   UI / INPUT / MAIN LOOP
   ===================================================================== */
const stageEl=$('stage'),uiEl=$('ui'),touchEl=$('touch'),pauseBtn=$('pausebtn');
let selMap=1,selStage=0,settingsFrom='menu',sawTouch=false,confirmYes=null;
const SCREENS=['s-menu','s-chars','s-world','s-settings','s-pause','s-victory','s-defeat'];
function show(id){SCREENS.forEach(s=>$(s).classList.toggle('on',s===id));$('s-confirm').classList.remove('on')}
const fmtTime=s=>{s=Math.round(s);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function touchWanted(){return S.touch==='on'||(S.touch==='auto'&&(sawTouch||('ontouchstart' in window)||(window.matchMedia&&matchMedia('(pointer:coarse)').matches)))}
function refreshTouch(){
  const inPlay=G.scene==='play'&&!G.paused&&!G.over;
  touchEl.classList.toggle('on',inPlay&&touchWanted());
  pauseBtn.classList.toggle('on',inPlay);
}
function applyTouchStyle(){touchEl.style.setProperty('--bs',S.btn);touchEl.style.setProperty('--bo',S.opa)}
function setScene(s){
  G.scene=s;G.paused=false;G.over=false;
  const m={menu:'s-menu',chars:'s-chars',world:'s-world',settings:'s-settings'};
  show(m[s]||null);
  if(s==='menu')renderMenu();else if(s==='chars')renderChars();else if(s==='world')renderWorld();else if(s==='settings')renderSettings();
  if(s!=='play')AU.music('menu');
  IN.held={};IN.p={};IN.x=0;IN.jx=0;
  refreshTouch();
}
/* ---------- renderers ---------- */
function renderMenu(){
  const hs=hasSave();
  const it=(a,label,o)=>{o=o||{};return '<button class="btn'+(o.dis?' dis':'')+'" data-a="'+a+'">'+label+(o.soon?'<small>'+T('soon')+'</small>':'')+'</button>'};
  $('s-menu').innerHTML='<div class="title"><h1>SHADOW<br>OF THE <span>ABYSS</span></h1><p>DARK FANTASY · HACK &amp; SLASH</p></div>'+
   '<div class="menu">'+it('continue',T('continue'),{dis:!hs})+it('new',T('newgame'))+it('world',T('worldmap'),{dis:!SV})+it('chars',T('character'),{dis:!SV})+
   it('x',T('inventory'),{dis:1,soon:1})+it('x',T('skill'),{dis:1,soon:1})+it('x',T('quest'),{dis:1,soon:1})+it('x',T('shop'),{dis:1,soon:1})+it('settings',T('settings'))+'</div>'+
   '<button class="fsbtn" data-a="fs">⛶ '+T('fullscreen')+'</button><a class="credit" href="https://t.me/PengodeHandal01" target="_blank" rel="noopener">Developer: t.me/PengodeHandal01</a>';
}
function renderChars(){
  const ids=['slayer','assassin','mage'];
  $('s-chars').innerHTML='<div class="head"><h2>'+T('character')+'</h2><button class="btn sm" data-a="back">'+T('back')+'</button></div><div class="body">'+
  ids.map(id=>{
    const c=DATA.chars[id],locked=!SV||!SV.unlockedChars.includes(id),sel=SV&&SV.char===id&&!locked;
    const lv=(SV&&SV.chars[id])?SV.chars[id].lv:1,st=c.grow?pStats(id,lv):{hp:c.base.hp,mp:c.base.mp,atk:c.base.atk,def:c.base.def,spd:c.base.spd};
    const sk=c.skills.map((s,i)=>'<li>'+esc(s.name)+(c.unlock?'<em>Lv.'+c.unlock['s'+(i+1)]+'</em>':'')+'</li>').join('')+
      '<li>'+esc(c.dashName||T('dash'))+'<em>'+T('dash')+'</em></li><li class="ul">'+esc(c.ultName)+'<em>'+T('ult')+(c.unlock?' Lv.'+c.unlock.ult:'')+'</em></li>'+(c.passive?'<li class="ps">'+esc(c.passive.name)+'<em>'+T('passive')+'</em></li>':'');
    return '<div class="card'+(locked?' lockc':'')+(sel?' sel':'')+'" '+(locked?'':'data-a="pickchar" data-id="'+id+'"')+'>'+
      '<div class="art" style="background-image:var(--card_'+id+')"></div>'+
      '<div class="info"><h3>'+c.name.toUpperCase()+(c.grow?' <span>Lv.'+lv+'</span>':'')+'</h3><div class="role">'+esc(TR(c.role))+' · '+esc(c.weapon)+'</div>'+
      '<div class="stats"><div><b>'+st.hp+'</b>'+T('hp')+'</div><div><b>'+st.mp+'</b>'+T('mp')+'</div><div><b>'+Math.round(st.atk)+'</b>'+T('atk')+'</div><div><b>'+Math.round(st.def)+'</b>'+T('def')+'</div><div><b>'+st.spd+'</b>'+T('speed')+'</div></div>'+
      '<ul class="sk">'+sk+'</ul><p class="desc">'+esc(TR(c.desc))+'</p></div>'+
      (locked?'<div class="lockov">🔒 '+T('locked')+'</div>':'')+(sel?'<div class="tag">'+T('selected')+'</div>':'')+'</div>';
  }).join('')+'</div>';
}
function renderWorld(){
  const cards=[1,2,3].map(id=>{
    const m=DATA.maps[id],un=SV.maps[id].unlocked;
    return '<div class="mapcard'+(selMap===id?' sel':'')+(un?'':' lock')+'" data-a="map" data-id="'+id+'"><div class="mimg" style="background-image:var(--'+m.thumb+')"></div>'+
      '<div class="mtxt"><b>'+T('map')+' '+id+'</b><span>'+esc(m.name)+'</span></div>'+(un?'':'<div class="lockov">🔒 '+T('locked')+'</div>')+'</div>';
  }).join('');
  const m=DATA.maps[selMap],ms=SV.maps[selMap];let panel='';
  if(!ms.unlocked)panel='<p class="note c">🔒 '+T('locked')+'</p>';
  else if(!m.stages.length)panel='<p class="note c">'+T('comingsoon')+'</p>';
  else{
    const st=m.stages[selStage];
    const names=[...new Set(st.waves.flatMap(w=>w.e))].map(k=>DATA.enemies[k].name).join(' · ');
    panel='<div class="chap">'+esc(TR(m.chapter))+'</div><div class="nodes">'+m.stages.map((s,i)=>{
      const un=i<=ms.cleared;
      return '<button class="node'+(i===selStage?' on':'')+(un?'':' dis')+(s.boss?' boss':'')+'" data-a="stage" data-i="'+i+'"><b>'+s.id+'</b><span>'+(s.boss?T('boss'):(i<ms.cleared?'✓ '+T('cleared'):T('stage')))+'</span></button>';
    }).join('')+'</div><div class="sinfo"><div><b>'+esc(st.id)+(st.boss?' — '+esc(DATA.enemies[st.waves[0].e[0]].name):'')+'</b><br><span>'+esc(names)+'</span><br><em>'+T('recLv')+' '+st.lv+'</em></div><button class="btn go" data-a="start">'+T('start')+' ▶</button></div>';
  }
  $('s-world').innerHTML='<div class="head"><h2>'+T('worldmap')+'</h2><button class="btn sm" data-a="back">'+T('back')+'</button></div><div class="maps">'+cards+'</div><div class="stages">'+panel+'</div>';
}
function renderSettings(){
  const seg=(k,opts)=>opts.map(o=>'<button class="seg'+(String(S[k])===String(o[0])?' on':'')+'" data-a="set" data-k="'+k+'" data-v="'+o[0]+'">'+o[1]+'</button>').join('');
  const rng=(k,min,max,val)=>'<input type="range" min="'+min+'" max="'+max+'" value="'+val+'" data-k="'+k+'"><output>'+Math.round(val)+'</output>';
  const row=(l,c)=>'<div class="srow"><label>'+l+'</label><div class="sc">'+c+'</div></div>';
  $('s-settings').innerHTML='<div class="head"><h2>'+T('settings')+'</h2><button class="btn sm" data-a="sback">'+T('back')+'</button></div><div class="sbody"><div class="scol">'+
    row(T('gfx'),seg('gfx',[[0,T('low')],[1,T('med')],[2,T('high')]]))+row(T('fps'),seg('fps',[[30,'30'],[60,'60']]))+
    row(T('sound'),rng('sfx',0,100,S.sfx*100))+row(T('music'),rng('mus',0,100,S.mus*100))+
    row(T('vib'),seg('vib',[[true,T('on')],[false,T('off')]]))+row(T('lang'),seg('lang',[['id','Indonesia'],['en','English']]))+
    '</div><div class="scol"><div class="shd">'+T('ctrl')+'</div>'+
    row(T('touch'),seg('touch',[['auto',T('auto')],['on',T('on')],['off',T('off')]]))+row(T('autofs'),seg('autoFs',[[true,T('on')],[false,T('off')]]))+
    row(T('btnsize'),rng('btn',70,140,S.btn*100))+row(T('btnopa'),rng('opa',30,100,S.opa*100))+
    '<div class="srow"><button class="btn sm" data-a="fs">'+T('fullscreen')+'</button><button class="btn sm danger" data-a="reset">'+T('reset')+'</button></div></div></div>';
}
function renderPause(){
  $('s-pause').innerHTML='<div class="panel"><h2 class="vt">'+T('pause')+'</h2><div class="col"><button class="btn" data-a="resume">'+T('resume')+'</button><button class="btn" data-a="psettings">'+T('settings')+'</button><button class="btn" data-a="fs">⛶ '+T('fullscreen')+'</button><button class="btn" data-a="pworld">'+T('worldmap')+'</button><button class="btn" data-a="pmenu">'+T('mainmenu')+'</button></div></div>';
}
function openPause(){if(G.scene!=='play'||G.over)return;G.paused=true;IN.held={};IN.x=0;IN.jx=0;renderPause();show('s-pause');refreshTouch()}
function resumeGame(){G.paused=false;show(null);IN.held={};IN.p={};refreshTouch()}
function showVictory(o){
  G.paused=true;refreshTouch();const s=G.stats;
  const items=[];if(s.items.hp)items.push('HP Potion ×'+s.items.hp);if(s.items.mp)items.push('MP Potion ×'+s.items.mp);if(o.crystals)items.push(T('crystal')+' +'+o.crystals);
  $('s-victory').innerHTML='<div class="panel wide"><h2 class="vt">'+T('victory')+'</h2><p class="sub">'+T('stageclear')+' — '+o.st.id+'</p><div class="vgrid"><div class="rankbox"><small>'+T('rank')+'</small><span class="rank r'+o.rank+'">'+o.rank+'</span></div>'+
   '<table class="tbl"><tr><td>'+T('time')+'</td><td>'+fmtTime(s.time)+'</td></tr><tr><td>'+T('combo')+'</td><td>'+s.maxCombo+'</td></tr><tr><td>'+T('enemies')+'</td><td>'+s.kills+'</td></tr>'+
   '<tr><td>'+T('exp')+'</td><td>+'+s.exp+'</td></tr><tr><td>'+T('gold')+'</td><td>+'+s.gold+'</td></tr><tr><td>'+T('items')+'</td><td>'+(items.join(', ')||'—')+'</td></tr></table></div>'+
   (o.bossNote?'<p class="note c">'+o.bossNote+'</p>':'')+'<div class="row">'+(o.hasNext?'<button class="btn go" data-a="vnext">'+T('next')+' ▶</button>':'')+'<button class="btn" data-a="vworld">'+T('worldmap')+'</button></div></div>';
  show('s-victory');
}
function showDefeat(){
  G.paused=true;refreshTouch();AU.jingle('lose');
  const cost=5*(G.revives+1),can=SV.crystal>=cost;
  $('s-defeat').innerHTML='<div class="panel"><h2 class="vt red">'+T('defeated')+'</h2><div class="col"><button class="btn'+(can?'':' dis')+'" data-a="revive">'+T('revive')+'<small>'+cost+' ◆ / '+SV.crystal+'</small></button>'+
   '<button class="btn" data-a="retry">'+T('retry')+'</button><button class="btn" data-a="dworld">'+T('worldmap')+'</button><button class="btn" data-a="dmenu">'+T('mainmenu')+'</button></div></div>';
  show('s-defeat');
}
function ask(msg,yes){confirmYes=yes;$('s-confirm').innerHTML='<div class="panel"><p class="cm">'+esc(msg)+'</p><div class="row"><button class="btn" data-a="cyes">'+T('yes')+'</button><button class="btn" data-a="cno">'+T('no')+'</button></div></div>';$('s-confirm').classList.add('on')}
function doNew(){SV=newSave();persist();selMap=1;selStage=0;setScene('chars')}
function enterWorld(){selMap=selMap||1;const m=DATA.maps[selMap];selStage=m.stages.length?Math.min(SV.maps[selMap].cleared,m.stages.length-1):0;setScene('world')}
function setTouchLabels(){
  const c=P.c;
  touchEl.querySelector('[data-act=s1]').firstChild.textContent=c.skills[0].short||c.skills[0].name.split(' ')[0].toUpperCase();
  touchEl.querySelector('[data-act=s2]').firstChild.textContent=c.skills[1].short||c.skills[1].name.split(' ')[0].toUpperCase();
  touchEl.querySelector('[data-act=s3]').firstChild.textContent=c.skills[2].short||c.skills[2].name.split(' ')[0].toUpperCase();
}
/* ---------- aksi UI ---------- */
function handle(a,ds){
  switch(a){
    case 'continue':if(loadSave())enterWorld();break;
    case 'new':if(hasSave())ask(T('confirmnew'),doNew);else doNew();break;
    case 'world':enterWorld();break;
    case 'chars':setScene('chars');break;
    case 'settings':settingsFrom='menu';setScene('settings');break;
    case 'back':setScene('menu');break;
    case 'pickchar':SV.char=ds.id;persist();enterWorld();break;
    case 'map':selMap=+ds.id;{const m=DATA.maps[selMap];selStage=m.stages.length?Math.min(SV.maps[selMap].cleared,m.stages.length-1):0}renderWorld();break;
    case 'stage':selStage=+ds.i;renderWorld();break;
    case 'start':tryFs();startStage(selMap,selStage);setTouchLabels();show(null);refreshTouch();break;
    case 'resume':resumeGame();break;
    case 'psettings':settingsFrom='pause';renderSettings();show('s-settings');break;
    case 'sback':if(settingsFrom==='pause'){renderPause();show('s-pause')}else setScene('menu');break;
    case 'pworld':persist();AU.stop();enterWorld();break;
    case 'pmenu':persist();AU.stop();setScene('menu');break;
    case 'vnext':tryFs();selStage++;startStage(selMap,selStage);setTouchLabels();show(null);refreshTouch();break;
    case 'vworld':enterWorld();break;
    case 'retry':startStage(selMap,selStage);setTouchLabels();show(null);refreshTouch();break;
    case 'revive':if(doRevive()){G.paused=false;show(null);refreshTouch()}else toast(T('crystal')+'!');break;
    case 'dworld':persist();enterWorld();break;
    case 'dmenu':persist();setScene('menu');break;
    case 'cyes':{const f=confirmYes;confirmYes=null;$('s-confirm').classList.remove('on');if(f)f();break}
    case 'cno':confirmYes=null;$('s-confirm').classList.remove('on');break;
    case 'set':{
      let v=ds.v;if(v==='true')v=true;else if(v==='false')v=false;else if(!isNaN(+v)&&ds.k!=='lang'&&ds.k!=='touch')v=+v;
      S[ds.k]=v;applySettings(ds.k);saveSettings();
      if(ds.k==='lang'){const cur=$('s-settings').classList.contains('on');renderSettings();if(!cur)0}else renderSettings();
      break}
    case 'fs':goFullscreen();break;
    case 'reset':ask(T('confirmnew'),()=>{store.del(SAVE_KEY);SV=null;setScene('menu')});break;
  }
}
function applySettings(k){
  if(k==='gfx'){setupCanvas();initEmbers()}
  if(k==='sfx'||k==='mus')AU.vol();
  if(k==='btn'||k==='opa'||k==='touch'){applyTouchStyle();refreshTouch()}
}
const isFs=()=>!!(document.fullscreenElement||document.webkitFullscreenElement);
function enterFs(){
  const el=document.documentElement;
  try{const r=el.requestFullscreen?el.requestFullscreen():(el.webkitRequestFullscreen&&el.webkitRequestFullscreen());if(r&&r.catch)r.catch(()=>{})}catch(e){}
  try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}catch(e){}
}
function goFullscreen(){
  if(isFs()){try{(document.exitFullscreen||document.webkitExitFullscreen).call(document)}catch(e){}}else enterFs();
}
function tryFs(){if(S.autoFs&&!isFs())enterFs()}
document.addEventListener('fullscreenchange',resize);document.addEventListener('webkitfullscreenchange',resize);
uiEl.addEventListener('click',ev=>{
  const el=ev.target.closest('[data-a]');if(!el||el.tagName==='A')return;
  if(el.classList.contains('dis'))return;
  AU.init();AU.play('click');handle(el.dataset.a,el.dataset);
});
uiEl.addEventListener('input',ev=>{
  const el=ev.target;if(!el.dataset||!el.dataset.k||el.type!=='range')return;
  const k=el.dataset.k,v=+el.value;
  S[k]=(k==='sfx'||k==='mus'||k==='btn'||k==='opa')?v/100:v;
  if(el.nextElementSibling)el.nextElementSibling.textContent=Math.round(v);
  applySettings(k);saveSettings();
});
pauseBtn.addEventListener('click',()=>{AU.init();AU.play('click');openPause()});

/* ---------- keyboard ---------- */
const KEYS={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'up',KeyW:'up',Space:'jump',KeyJ:'atk',KeyZ:'atk',KeyK:'s1',KeyU:'s1',KeyI:'s2',KeyO:'s3',KeyL:'dash',ShiftLeft:'dash',KeyR:'ult',KeyQ:'potHp',KeyE:'potMp',Escape:'pause',KeyP:'pause'};
window.addEventListener('keydown',e=>{
  AU.init();if(e.code==='KeyF'&&!e.repeat){goFullscreen();return}const k=KEYS[e.code];if(!k)return;
  if(G.scene==='play')e.preventDefault();
  if(e.repeat)return;
  if(k==='pause'){if(G.scene==='play'&&!G.over){if(G.paused&&$('s-pause').classList.contains('on'))resumeGame();else if(!G.paused)openPause()}return}
  if(G.scene!=='play'||G.paused)return;
  if(k==='left'||k==='right'){IN.held[k]=true;return}
  if(k==='up'){press('jump');return}
  press(k);
});
window.addEventListener('keyup',e=>{const k=KEYS[e.code];if(!k)return;if(k==='left'||k==='right')IN.held[k]=false;else if(k!=='up')release(k)});
window.addEventListener('pointerdown',()=>{AU.init()},{passive:true});

/* ---------- touch: tombol + joystick melayang ---------- */
touchEl.querySelectorAll('.tb').forEach(b=>{
  const a=b.dataset.act;
  b.addEventListener('pointerdown',e=>{e.preventDefault();sawTouch=e.pointerType==='touch'||sawTouch;AU.init();try{b.setPointerCapture(e.pointerId)}catch(x){}b.classList.add('down');press(a)});
  const up=()=>{b.classList.remove('down');release(a)};
  b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);
});
const joy={id:null,ox:0,oy:0,up:false};
const jz=$('joyzone'),jb=$('joybase'),jk=$('joyknob');
function jpos(el,x,y){el.style.left=x+'px';el.style.top=y+'px'}
jz.addEventListener('pointerdown',e=>{
  if(joy.id!==null)return;e.preventDefault();sawTouch=e.pointerType==='touch'||sawTouch;AU.init();
  joy.id=e.pointerId;try{jz.setPointerCapture(e.pointerId)}catch(x){}
  const r=stageEl.getBoundingClientRect();joy.ox=e.clientX;joy.oy=e.clientY;joy.up=false;
  jpos(jb,e.clientX-r.left,e.clientY-r.top);jpos(jk,e.clientX-r.left,e.clientY-r.top);jb.classList.add('on');jk.classList.add('on');
});
jz.addEventListener('pointermove',e=>{
  if(e.pointerId!==joy.id)return;
  const r=stageEl.getBoundingClientRect(),R=r.height/540*58;
  let dx=e.clientX-joy.ox,dy=e.clientY-joy.oy;const L=Math.hypot(dx,dy);if(L>R){dx=dx/L*R;dy=dy/L*R}
  const nx=dx/R,ny=dy/R;IN.jx=Math.abs(nx)<.2?0:nx;
  if(ny<-.65&&!joy.up){joy.up=true;press('jump')}if(ny>-.4)joy.up=false;
  jpos(jk,joy.ox-r.left+dx,joy.oy-r.top+dy);
});
function joyEnd(e){if(e.pointerId!==joy.id)return;joy.id=null;IN.jx=0;jb.classList.remove('on');jk.classList.remove('on')}
jz.addEventListener('pointerup',joyEnd);jz.addEventListener('pointercancel',joyEnd);
const tbEls={};touchEl.querySelectorAll('.tb').forEach(b=>tbEls[b.dataset.act]=b);
const tbCache={};
function setTb(k,frac,cls){
  const b=tbEls[k],c=tbCache[k]||(tbCache[k]={f:-1,c:''});
  const f=Math.round(frac*30)/30;if(f!==c.f){b.style.setProperty('--cd',f);c.f=f}
  if(cls!==c.c){b.className='tb'+(b.dataset.act.indexOf('pot')===0?' pot':'')+(b.classList.contains('down')?' down':'')+(cls?' '+cls:'');c.c=cls}
}
function updTouchUI(){
  if(!touchEl.classList.contains('on')||!P)return;
  const c=P.c;
  ['s1','s2','s3'].forEach((k,i)=>setTb(k,P.cd[k]/c.skills[i].cd,!skillUnlocked(k)?'lk':(P.mp<c.skills[i].mp?'nomp':'')));
  setTb('dash',P.cd.dash/.85,'');
  setTb('ult',1-P.rage/100,!skillUnlocked('ult')?'lk':(P.rage>=100?'ready':''));
  setTb('potHp',P.cd.pot/6,SV.pot.hp<=0?'lk':'');setTb('potMp',P.cd.pot/6,SV.pot.mp<=0?'lk':'');
  const ch=tbEls.potHp.querySelector('em');if(ch&&ch.textContent!==String(SV.pot.hp))ch.textContent=SV.pot.hp;
  const cm=tbEls.potMp.querySelector('em');if(cm&&cm.textContent!==String(SV.pot.mp))cm.textContent=SV.pot.mp;
}

/* ---------- ukuran layar 16:9 ---------- */
function resize(){
  const iw=window.innerWidth,ih=window.innerHeight,asp=iw/ih;
  let sw,sh,nw;
  if(asp<=16/9){sw=iw;sh=iw*9/16;nw=960}
  else{const a=Math.min(asp,2.4);sh=ih;sw=ih*a;nw=Math.round(540*a)}   // layar lebar: dunia game ikut melebar, tanpa pita hitam
  stageEl.style.width=sw+'px';stageEl.style.height=sh+'px';stageEl.style.fontSize=(sh/540*16)+'px';
  if(nw!==W){W=nw;setupCanvas();initEmbers()}
  $('rotate').textContent=T('landscape');
}
window.addEventListener('resize',resize);
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('visibilitychange',()=>{if(document.hidden){persist();if(G.scene==='play'&&!G.paused&&!G.over)openPause()}});
window.addEventListener('pagehide',persist);

/* ---------- loop ---------- */
let lastTs=performance.now();
function frame(ts){
  requestAnimationFrame(frame);
  const minDt=1000/S.fps-2;if(ts-lastTs<minDt)return;
  const rdt=Math.min(.05,(ts-lastTs)/1000);lastTs=ts;G.now+=rdt;
  const kx=(IN.held.right?1:0)-(IN.held.left?1:0);IN.x=kx||IN.jx||0;
  if(IN.held.atk&&G.now-(IN.p.atk||-9)>.24)IN.p.atk=G.now;
  updEmbers(rdt);
  if(G.scene==='play'&&P){
    if(!G.paused)updatePlay(rdt);
    cx.setTransform(cvScale,0,0,cvScale,0,0);drawWorld();updTouchUI();
  }else{
    updFx(rdt);cx.setTransform(cvScale,0,0,cvScale,0,0);drawMenuBg();
  }
}
/* ---------- boot ---------- */
function loadAll(){
  return Promise.all(Object.keys(ASSETS).map(k=>new Promise(res=>{const im=new Image();im.onload=()=>{IMG[k]=im;res()};im.onerror=res;im.src=ASSETS[k]})));
}
resize();
loadAll().then(()=>{
  ['thumb_map1','thumb_map2','thumb_map3','card_slayer','card_assassin','card_mage'].forEach(k=>{stageEl.style.setProperty('--'+k,'url('+ASSETS[k]+')')});
  buildRigs();setupCanvas();initEmbers();applyTouchStyle();
  if(hasSave())loadSave();
  setScene('menu');
  const b=$('boot');if(b)b.remove();
  requestAnimationFrame(frame);
});
window.__SOTA={G,E,PR,FX,PT,get P(){return P},get SV(){return SV},startStage,startAttack,newSave,setScene,gainExp,hitEnemy,spawnEnemy,handle,press,release,DATA,doNew,hurtPlayer,killEnemy,renderWorld,resumeGame,openPause};
})();
