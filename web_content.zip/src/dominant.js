/**
 * Dominant host — file tree on Backblaze B2, keys/tokens on D1.
 *
 * Public:
 *   GET /api/dominant/load?key=REGEX_xxx
 *   GET /api/dominant/module?path=...&token=...
 *
 * Admin / tool:
 *   GET|PUT|DELETE /api/dominant/files
 *   POST /api/dominant/import
 *   DELETE /api/dominant/folder?prefix=
 *   GET /api/dominant/meta
 *   GET /api/dominant/file?path=  (preview, base64 for binary)
 */

import { json, text, sha256Hex, randomToken } from './security.js';
import {
  b2Config,
  b2Put,
  b2Get,
  b2GetText,
  b2Delete,
  b2List,
  contentTypeForPath,
  isBinaryPath,
} from './b2.js';

const TOKEN_TTL_MS = 30 * 60 * 1000;
const MAX_TEXT = 2_000_000;
const MAX_IMPORT = 400;
const PREFIX = 'dominant/'; // all Dominant objects under this prefix in the bucket

function sanitizePath(path) {
  if (typeof path !== 'string') return null;
  const p = path.replace(/\\/g, '/').replace(/^\/+/, '').replace(/\/+$/, '').trim();
  if (!p || p.length > 400) return null;
  if (/[\x00-\x1f\x7f]/.test(p)) return null;
  if (p.split('/').some((part) => part === '' || part === '.' || part === '..')) return null;
  return p;
}

function objectKey(path) {
  return PREFIX + path;
}

// Version history: the previous content of a file is kept before it is overwritten or deleted.
const HISTORY_PREFIX = 'dominant-history/';
const HISTORY_MAX = 50;

async function snapshotDominantFile(env, clean, reason) {
  if (!b2Config(env).configured) return null;
  const meta = await env.DB.prepare('SELECT size, sha256 FROM dominant_file_index WHERE path = ?').bind(clean).first();
  if (!meta) return null;
  const current = await b2Get(env, objectKey(clean));
  if (!current) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const key = HISTORY_PREFIX + clean + '/' + stamp;
  await b2Put(env, key, current.body, current.contentType);
  await env.DB.prepare(
    'INSERT INTO dominant_versions(path, history_key, content_type, size, sha256, is_binary, created_at, reason) VALUES(?,?,?,?,?,?,?,?)'
  ).bind(clean, key, current.contentType, Number(meta.size || 0), meta.sha256 || null, current.binary ? 1 : 0, new Date().toISOString(), reason).run();
  const old = await env.DB.prepare('SELECT id, history_key FROM dominant_versions WHERE path = ? ORDER BY id DESC LIMIT -1 OFFSET ?')
    .bind(clean, HISTORY_MAX).all();
  for (const row of old.results || []) {
    await b2Delete(env, row.history_key);
    await env.DB.prepare('DELETE FROM dominant_versions WHERE id = ?').bind(row.id).run();
  }
  return key;
}

export async function listDominantVersions(env, path) {
  const clean = sanitizePath(path || '');
  if (!clean) throw new Error('path required');
  const r = await env.DB.prepare(
    'SELECT id, created_at, size, sha256, is_binary, reason FROM dominant_versions WHERE path = ? ORDER BY id DESC'
  ).bind(clean).all();
  return (r.results || []).map((v) => ({
    version: v.id, createdAt: v.created_at, size: v.size, sha256: v.sha256, binary: v.is_binary === 1, reason: v.reason,
  }));
}

export async function restoreDominantVersion(env, path, version, actor = '') {
  const clean = sanitizePath(path || '');
  if (!clean) throw new Error('path required');
  if (!Number.isSafeInteger(version)) throw new Error('version must be an integer');
  const row = await env.DB.prepare('SELECT history_key, is_binary FROM dominant_versions WHERE path = ? AND id = ?')
    .bind(clean, version).first();
  if (!row) throw new Error('version not found');
  const saved = await b2Get(env, row.history_key);
  if (!saved) throw new Error('version content is missing from storage');
  // Goes through the normal write, so the content being replaced is saved as a version too.
  if (saved.binary) return putDominantFile(env, clean, base64FromArrayBuffer(saved.body), true, actor);
  return putDominantFile(env, clean, saved.body, false, actor);
}

function buildBootstrap({ origin, key, token, entry, assetsBase }) {
  const runtime = `
local KEY=${JSON.stringify(key)}
local ORIGIN=${JSON.stringify(origin.replace(/\/$/, ''))}
local TOKEN=${JSON.stringify(token)}
local ENTRY=${JSON.stringify(entry || 'loader.lua')}
local ASSETS=${JSON.stringify((assetsBase || '').replace(/\/$/, ''))}
local Hs=game:GetService("HttpService")
local function get(u)
  local ok,body=pcall(function()
    if syn and syn.request then
      local r=syn.request({Url=u,Method="GET",Headers={
        ["X-Dominant-Token"]=TOKEN,["X-Dominant-Key"]=KEY,["User-Agent"]="DominantExecutor/1"
      }})
      return r and r.Body
    end
    return game:HttpGet(u)
  end)
  if ok and type(body)=="string" and #body>0 then return body end
  return nil
end
local G=getgenv and getgenv() or _G
G.DOMINANT_CODE_ORIGIN=ORIGIN
G.DOMINANT_LOAD_TOKEN=TOKEN
G.DOMINANT_ASSETS_BASE=ASSETS~="" and (ASSETS.."/") or nil
local url=ORIGIN.."/api/dominant/module?path="..Hs:UrlEncode(ENTRY).."&token="..Hs:UrlEncode(TOKEN)
local src=get(url)
if not src then error("Dominant: failed to download entry module") end
local fn,err=loadstring(src)
if not fn then error(err or "compile") end
fn()
`.trim();

  const codes = [];
  for (let i = 0; i < runtime.length; i++) codes.push(runtime.charCodeAt(i));
  const parts = [];
  for (let i = 0; i < codes.length; i += 100) {
    parts.push(codes.slice(i, i + 100).join(','));
  }
  const build = parts.map((p, i) => `t[${i + 1}]={${p}}`).join(';');
  return `-- Dominant (B2-backed). Modules stream after key check.
local t={};${build}
local s="" for i=1,#t do for j=1,#t[i] do s=s..string.char(t[i][j]) end end
assert(loadstring(s))()`;
}

async function issueToken(db, hint) {
  const token = randomToken(24);
  const hash = await sha256Hex(token);
  const expires = Date.now() + TOKEN_TTL_MS;
  await db
    .prepare('INSERT INTO load_tokens(token_hash, key_hint, expires_at, used) VALUES(?,?,?,0)')
    .bind(hash, hint || '', expires)
    .run();
  return token;
}

async function consumeToken(db, token) {
  if (!token) return false;
  const hash = await sha256Hex(token);
  const row = await db.prepare('SELECT expires_at, used FROM load_tokens WHERE token_hash = ?').bind(hash).first();
  if (!row) return false;
  if (row.expires_at < Date.now()) return false;
  await db.prepare('UPDATE load_tokens SET used = used + 1 WHERE token_hash = ?').bind(hash).run();
  return true;
}

export async function validateRegexKey(db, key) {
  if (!key || typeof key !== 'string' || key.length < 8) {
    return { ok: false, error: 'invalid key' };
  }
  const hash = await sha256Hex(key);
  const row = await db
    .prepare('SELECT status, expires_at, key_hint FROM regex_keys WHERE key_hash = ? LIMIT 1')
    .bind(hash)
    .first();
  if (!row) return { ok: false, error: 'key not found' };
  if (row.status !== 'active') return { ok: false, error: 'key revoked' };
  if (row.expires_at && Date.parse(row.expires_at) < Date.now()) {
    return { ok: false, error: 'key expired' };
  }
  await db
    .prepare('UPDATE regex_keys SET last_used_at = ? WHERE key_hash = ?')
    .bind(new Date().toISOString(), hash)
    .run()
    .catch(() => {});
  return { ok: true, hint: row.key_hint || key.slice(0, 6) };
}

async function readLegacyFileRow(env, path) {
  return env.DB.prepare('SELECT path, content, updated_at, size, sha256 FROM dominant_files WHERE path = ?')
    .bind(path).first();
}

async function readIndexRow(env, path) {
  return env.DB.prepare('SELECT path, b2_key, content_type, updated_at, size, sha256, is_binary FROM dominant_file_index WHERE path = ?')
    .bind(path).first().catch(() => null);
}

async function listDominantFiles(env, prefix = '') {
  const full = PREFIX + (prefix || '');
  const cfg = b2Config(env);
  if (!cfg.configured) {
    const { results } = await env.DB.prepare(
      'SELECT path, size, updated_at, sha256 FROM dominant_files ORDER BY path'
    ).all();
    return (results || []).filter((f) => f.path.startsWith(prefix)).map((f) => ({
      path: f.path,
      size: f.size,
      updated_at: f.updated_at,
      sha256: f.sha256 || null,
      binary: isBinaryPath(f.path),
      storage: 'd1',
    }));
  }

  // B2 owns file contents. D1 stores only the index/metadata for new objects.
  const { files: b2Files } = await b2List(env, full, '');
  const { results: indexRows } = await env.DB.prepare(
    'SELECT path, size, updated_at, sha256, content_type, is_binary FROM dominant_file_index'
  ).all().catch(() => ({ results: [] }));
  const metadata = new Map((indexRows || []).map((r) => [r.path, r]));
  const seen = new Set();
  const output = [];

  for (const f of b2Files) {
    if (!f.path.startsWith(PREFIX)) continue;
    const path = f.path.slice(PREFIX.length);
    if (!path || path.endsWith('/') || !path.startsWith(prefix)) continue;
    const meta = metadata.get(path);
    seen.add(path);
    output.push({
      path,
      size: f.size,
      updated_at: meta?.updated_at || f.updated_at,
      sha256: meta?.sha256 || null,
      content_type: meta?.content_type || null,
      binary: meta ? Boolean(meta.is_binary) : isBinaryPath(path),
      storage: 'b2',
    });
  }

  // Expose legacy D1-only files during migration without duplicating new B2 files.
  const { results: legacyRows } = await env.DB.prepare(
    'SELECT path, size, updated_at, sha256 FROM dominant_files ORDER BY path'
  ).all().catch(() => ({ results: [] }));
  for (const f of legacyRows || []) {
    if (f.path.startsWith(prefix) && !seen.has(f.path)) {
      output.push({ ...f, binary: isBinaryPath(f.path), storage: 'd1' });
    }
  }
  return output.sort((a, b) => a.path.localeCompare(b.path));
}

function base64FromArrayBuffer(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function putDominantFile(env, path, content, isBase64 = false, actor = '') {
  const clean = sanitizePath(path);
  if (!clean) throw new Error('invalid path');
  let body = content ?? '';
  const ct = contentTypeForPath(clean);
  let isBinary = false;

  if (isBase64 && typeof body === 'string') {
    try {
      body = Uint8Array.from(atob(body), (c) => c.charCodeAt(0));
      isBinary = true;
    } catch {
      throw new Error('invalid base64 content');
    }
  } else if (typeof body !== 'string') {
    throw new Error('content must be text or base64');
  }

  if (typeof body === 'string' && textByteLength(body) > MAX_TEXT) throw new Error('file too large');
  if (isBinary && body.byteLength > 8_000_000) throw new Error('binary file too large (maximum 8 MB per file)');

  const cfg = b2Config(env);
  const updatedAt = new Date().toISOString();
  const size = typeof body === 'string' ? textByteLength(body) : body.byteLength;
  const hash = typeof body === 'string' ? await sha256Hex(body) : null;

  if (cfg.configured) {
    await snapshotDominantFile(env, clean, actor ? 'overwrite by ' + actor : 'overwrite');
    // Write the object first; only then publish its metadata in D1.
    await b2Put(env, objectKey(clean), body, ct);
    await env.DB.prepare(
      `INSERT INTO dominant_file_index(path, b2_key, content_type, updated_at, size, sha256, is_binary)
       VALUES(?,?,?,?,?,?,?)
       ON CONFLICT(path) DO UPDATE SET b2_key=excluded.b2_key, content_type=excluded.content_type,
       updated_at=excluded.updated_at, size=excluded.size, sha256=excluded.sha256, is_binary=excluded.is_binary`
    ).bind(clean, objectKey(clean), ct, updatedAt, size, hash, isBinary ? 1 : 0).run();
    // A successful B2 write supersedes the old duplicated D1 content, freeing D1 space.
    await env.DB.prepare('DELETE FROM dominant_files WHERE path = ?').bind(clean).run().catch(() => {});
  } else {
    if (typeof body !== 'string') throw new Error('B2 is required for binary files; configure B2 before uploading this file');
    // Backward-compatible D1-only mode while B2 is not configured.
    await env.DB.prepare(
      `INSERT INTO dominant_files(path, content, updated_at, size, sha256)
       VALUES(?,?,?,?,?)
       ON CONFLICT(path) DO UPDATE SET content=excluded.content, updated_at=excluded.updated_at, size=excluded.size, sha256=excluded.sha256`
    ).bind(clean, body, updatedAt, size, hash).run();
  }
  return { path: clean, size, storage: cfg.configured ? 'b2' : 'd1' };
}

function textByteLength(value) {
  return new TextEncoder().encode(value).byteLength;
}

/**
 * @param {Request} request
 * @param {any} env
 * @param {{ admin?: boolean, tool?: { scopes: string[] } }} opts
 */
export async function handleDominant(request, env, opts = {}) {
  const url = new URL(request.url);
  const sub = url.pathname.replace(/^.*\/api\/dominant\/?/, '');
  const action = sub.split('/').filter(Boolean)[0] || '';
  const admin = opts.admin === true;
  const tool = opts.tool || null;
  const can = (scope) => admin || (tool && tool.scopes.includes(scope));

  const assetsBase =
    env.ASSETS_BASE || 'https://raw.githubusercontent.com/HS1HYDRAX7/444F4D494E414E54/main/assets';

  // ---------- public load ----------
  if (action === 'load' && request.method === 'GET') {
    const key = url.searchParams.get('key') || '';
    const check = await validateRegexKey(env.DB, key);
    if (!check.ok) {
      return text(`-- denied\nerror(${JSON.stringify(check.error)})`, 403);
    }
    const token = await issueToken(env.DB, check.hint);
    const origin = `${url.protocol}//${url.host}${opts.base || ''}`;
    const boot = buildBootstrap({
      origin,
      key,
      token,
      entry: url.searchParams.get('entry') || 'loader.lua',
      assetsBase,
    });
    return text(boot, 200, { 'X-Dominant': 'b2-protected' });
  }

  // ---------- public module stream ----------
  if (action === 'module' && request.method === 'GET') {
    const token = url.searchParams.get('token') || request.headers.get('X-Dominant-Token') || '';
    const ok = await consumeToken(env.DB, token);
    if (!ok) return text('-- unauthorized', 401);
    const path = sanitizePath(url.searchParams.get('path') || '');
    if (!path) return text('-- bad path', 400);
    try {
      if (b2Config(env).configured) {
        const body = await b2GetText(env, objectKey(path));
        if (body != null) return text(body, 200, { 'X-Dominant-Path': path, 'X-Dominant-Source': 'b2' });
      }
      // Backward-compatible fallback for files that existed in D1 before B2 migration.
      const row = await env.DB.prepare('SELECT content FROM dominant_files WHERE path = ?').bind(path).first();
      if (row?.content) return text(row.content, 200, { 'X-Dominant-Path': path, 'X-Dominant-Source': 'd1' });
      return text(`-- missing\nerror(${JSON.stringify(path)})`, 404);
    } catch (e) {
      return text(`-- error\nerror(${JSON.stringify(String(e.message || e))})`, 500);
    }
  }

  // ---------- authenticated routes ----------
  if (!admin && !tool) {
    return json({ error: 'unauthorized' }, 401);
  }

  if (action === 'files' && request.method === 'GET') {
    if (!can('list') && !can('read')) return json({ error: 'forbidden' }, 403);
    try {
      const files = await listDominantFiles(env);
      return json({ files, storage: b2Config(env).configured ? 'b2+d1-index' : 'd1' });
    } catch (e) {
      return json({ error: String(e.message || e), hint: 'Check B2_KEY_ID, B2_APPLICATION_KEY, B2_BUCKET, region and endpoint.' }, 502);
    }
  }

  if (action === 'file' && request.method === 'GET') {
    if (!can('read')) return json({ error: 'forbidden' }, 403);
    const path = sanitizePath(url.searchParams.get('path') || '');
    if (!path) return json({ error: 'path required' }, 400);
    try {
      const meta = await readIndexRow(env, path);
      if (b2Config(env).configured) {
        const obj = await b2Get(env, objectKey(path));
        if (obj) {
          if (obj.binary) {
            return json({ file: {
              path, content: null, base64: base64FromArrayBuffer(obj.body), contentType: obj.contentType,
              binary: true, size: obj.body.byteLength, updated_at: meta?.updated_at || null, sha256: meta?.sha256 || null,
            } });
          }
          return json({ file: {
            path, content: obj.body, contentType: obj.contentType, binary: false,
            size: textByteLength(obj.body), updated_at: meta?.updated_at || null, sha256: meta?.sha256 || null,
          } });
        }
      }
      // Legacy D1 content remains readable throughout migration.
      const row = await readLegacyFileRow(env, path);
      if (!row) return json({ error: 'not found' }, 404);
      return json({ file: { ...row, contentType: 'text/plain; charset=utf-8', binary: false } });
    } catch (e) {
      return json({ error: String(e.message || e) }, 502);
    }
  }

  if (action === 'files' && request.method === 'PUT') {
    if (!can('write')) return json({ error: 'forbidden' }, 403);
    const body = await request.json().catch(() => null);
    if (!body?.path) return json({ error: 'path required' }, 400);
    try {
      const file = await putDominantFile(env, body.path, body.content ?? '', body.base64 === true, opts.model || '');
      return json({ ok: true, file });
    } catch (e) {
      return json({ error: String(e.message || e) }, 400);
    }
  }

  if (action === 'import' && request.method === 'POST') {
    if (!can('write')) return json({ error: 'forbidden' }, 403);
    const body = await request.json().catch(() => null);
    const list = Array.isArray(body?.files) ? body.files.slice(0, MAX_IMPORT) : [];
    const saved = [];
    const errors = [];
    for (const f of list) {
      try {
        saved.push(await putDominantFile(env, f.path, f.content ?? '', f.base64 === true));
      } catch (e) {
        errors.push({ path: f?.path, error: String(e.message || e) });
      }
    }
    return json({ ok: true, count: saved.length, saved, errors });
  }

  if (action === 'migrate' && request.method === 'POST') {
    if (!can('write')) return json({ error: 'forbidden' }, 403);
    if (!b2Config(env).configured) return json({ error: 'B2 is not configured; set a standard B2 application key and B2_BUCKET first.' }, 400);
    const body = await request.json().catch(() => ({}));
    const rawLimit = Number(body?.limit || 10);
    const limit = Number.isFinite(rawLimit) ? Math.min(20, Math.max(1, Math.floor(rawLimit))) : 10;
    const { results: legacyRows } = await env.DB.prepare(
      'SELECT path, content FROM dominant_files ORDER BY path LIMIT ?'
    ).bind(limit).all();
    const moved = [];
    const errors = [];
    for (const row of legacyRows || []) {
      try {
        await putDominantFile(env, row.path, row.content, false);
        moved.push(row.path);
      } catch (e) {
        errors.push({ path: row.path, error: String(e.message || e) });
      }
    }
    const remainingRow = await env.DB.prepare('SELECT COUNT(*) AS n FROM dominant_files').first();
    return json({ ok: errors.length === 0, moved: moved.length, paths: moved, remaining: Number(remainingRow?.n || 0), errors });
  }

  if (action === 'files' && request.method === 'DELETE') {
    if (!can('delete')) return json({ error: 'forbidden' }, 403);
    const path = sanitizePath(url.searchParams.get('path') || '');
    if (!path) return json({ error: 'path required' }, 400);
    try {
      if (b2Config(env).configured) {
        await snapshotDominantFile(env, path, opts.model ? 'delete by ' + opts.model : 'delete');
        await b2Delete(env, objectKey(path));
      }
      await env.DB.prepare('DELETE FROM dominant_file_index WHERE path = ?').bind(path).run().catch(() => {});
      await env.DB.prepare('DELETE FROM dominant_files WHERE path = ?').bind(path).run().catch(() => {});
      return json({ ok: true });
    } catch (e) {
      return json({ error: String(e.message || e) }, 500);
    }
  }

  if (action === 'folder' && request.method === 'DELETE') {
    if (!can('delete')) return json({ error: 'forbidden' }, 403);
    const prefix = sanitizePath(url.searchParams.get('prefix') || '');
    if (!prefix) return json({ error: 'prefix required' }, 400);
    try {
      let deleted = 0;
      if (b2Config(env).configured) {
        const allFiles = await listDominantFiles(env);
        const targets = allFiles.filter((f) => f.path === prefix || f.path.startsWith(prefix + '/'));
        for (const file of targets) {
          await b2Delete(env, objectKey(file.path));
          deleted++;
        }
      }
      const like = prefix.replace(/[\\%_]/g, (c) => '\\' + c) + '/%';
      const r = await env.DB.prepare("DELETE FROM dominant_files WHERE path LIKE ? ESCAPE '\\' OR path = ?")
        .bind(like, prefix)
        .run()
        .catch(() => ({ meta: { changes: 0 } }));
      await env.DB.prepare("DELETE FROM dominant_file_index WHERE path LIKE ? ESCAPE '\\' OR path = ?")
        .bind(like, prefix)
        .run()
        .catch(() => {});
      deleted += r.meta?.changes || 0;
      return json({ ok: true, deleted });
    } catch (e) {
      return json({ error: String(e.message || e) }, 500);
    }
  }

  if (action === 'meta' && request.method === 'GET') {
    const cfg = b2Config(env);
    return json({
      storage: cfg.configured ? 'b2' : 'd1',
      b2Configured: cfg.configured,
      bucket: cfg.configured ? cfg.bucket : null,
      assetsBase,
      note: 'B2 stores file contents; D1 stores Regex keys/sessions and a metadata index. Legacy D1 file contents remain readable during migration. GitHub is only a public asset mirror.',
      d1: 'keys, sessions, audit log, file metadata and legacy fallback',
      b2: 'source of truth for new file contents when configured',
    });
  }

  return json({ error: 'unknown route', action }, 404);
}
