// 极简 MQTT 3.1.1 over WebSocket 客户端（QoS 0，够用）
// 不需要任何服务器：消息走公共 MQTT 代理（broker.emqx.io）

function MQTTClient(opts) {
  this.url = opts.url || 'wss://broker.emqx.io:8084/mqtt';
  this.clientId = opts.clientId || ('fgame_' + Math.random().toString(36).slice(2, 10));
  this.topic = opts.topic;
  this.onMessage = opts.onMessage || function () {};
  this.onOpen = opts.onOpen || function () {};
  this.onClose = opts.onClose || function () {};
  this.ws = null;
  this.buf = new Uint8Array(0);
  this.pid = 1;
  this.alive = false;
  this.timer = null;
  this.keep = null;
}

MQTTClient.prototype._encLen = function (n) {
  var out = [];
  do {
    var d = n % 128;
    n = Math.floor(n / 128);
    if (n > 0) d |= 128;
    out.push(d);
  } while (n > 0);
  return out;
};

MQTTClient.prototype._encStr = function (s) {
  var b = new TextEncoder().encode(s);
  return [(b.length >> 8) & 255, b.length & 255].concat(Array.from(b));
};

MQTTClient.prototype._send = function (bytes) {
  if (!this.ws || this.ws.readyState !== 1) return;
  this.ws.send(new Uint8Array(bytes));
};

MQTTClient.prototype.connect = function () {
  var self = this;
  this.alive = true;
  try {
    this.ws = new WebSocket(this.url, 'mqtt');
  } catch (e) {
    this.onClose('websocket init failed');
    return;
  }
  this.ws.binaryType = 'arraybuffer';

  this.ws.onopen = function () {
    var payload = self._encStr(self.clientId);
    var vh = self._encStr('MQTT').concat([4, 2, 0, 60]); // level 4, clean session, keepalive 60s
    var pkt = [0x10].concat(self._encLen(vh.length + payload.length), vh, payload);
    self._send(pkt);
  };

  this.ws.onmessage = function (ev) {
    var data = new Uint8Array(ev.data);
    var all = new Uint8Array(self.buf.length + data.length);
    all.set(self.buf, 0);
    all.set(data, self.buf.length);
    self.buf = all;
    self._parse();
  };

  this.ws.onclose = function () {
    self.onClose('closed');
    if (self.keep) { clearInterval(self.keep); self.keep = null; }
    if (self.alive) {
      self.timer = setTimeout(function () { self.connect(); }, 2000);
    }
  };

  this.ws.onerror = function () {};
};

MQTTClient.prototype._parse = function () {
  var b = this.buf, i = 0;
  while (i < b.length) {
    var type = b[i] >> 4;
    var mult = 1, len = 0, j = i + 1, d;
    do {
      if (j >= b.length) { this.buf = b.slice(i); return; }
      d = b[j++];
      len += (d & 127) * mult;
      mult *= 128;
    } while (d & 128);
    var total = (j - i) + len;
    if (b.length - i < total) { this.buf = b.slice(i); return; }
    var body = b.slice(j, j + len);
    this._handle(type, body);
    i += total;
  }
  this.buf = new Uint8Array(0);
};

MQTTClient.prototype._handle = function (type, body) {
  var self = this;
  if (type === 2) { // CONNACK
    var rc = body.length > 1 ? body[1] : 1;
    if (rc === 0) {
      var vh = [0, self.pid++].concat(this._encStr(this.topic), [0]);
      this._send([0x82].concat(this._encLen(vh.length), vh));
      this.onOpen();
      if (!this.keep) {
        this.keep = setInterval(function () { self._send([0xC0, 0x00]); }, 25000);
      }
    } else {
      this.onClose('mqtt refused ' + rc);
    }
  } else if (type === 3) { // PUBLISH
    var tlen = (body[0] << 8) | body[1];
    var payload = body.slice(2 + tlen);
    var txt = new TextDecoder().decode(payload);
    try { this.onMessage(JSON.parse(txt)); } catch (e) {}
  }
};

MQTTClient.prototype.publish = function (obj) {
  if (!this.ws || this.ws.readyState !== 1) return;
  var vh = this._encStr(this.topic);
  var body = new TextEncoder().encode(JSON.stringify(obj));
  var pkt = [0x30].concat(this._encLen(vh.length + body.length), vh, Array.from(body));
  this._send(pkt);
};

MQTTClient.prototype.close = function () {
  this.alive = false;
  if (this.timer) { clearTimeout(this.timer); this.timer = null; }
  if (this.keep) { clearInterval(this.keep); this.keep = null; }
  if (this.ws) { try { this.ws.close(); } catch (e) {} }
};
